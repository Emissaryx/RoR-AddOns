--this file contains code to mitigate damage of a typo in the main lua file

--keep these here so I stop losing my saved variables
CramTheSpam = {}
CramTheSpam.SavedVars = {};


local CramTheSpamFailedToLoadShouldSpew = true;
local CramTheSpamFailedToLoadTimer = 0;

--stop filling my text log with the fact that CramTheSpam.OnUpdate does not exist
function CramTheSpam.OnUpdateProxy(elapsedTime)
	if( CramTheSpam.OnUpdate ~= nil ) then
		--d( L"Handing over CramTheSpam.OnUpdate" );
		CramTheSpam.OnUpdateProxy = CramTheSpam.OnUpdate; --call the real deal directly next time		
		CramTheSpam.OnUpdate(elapsedTime);
	elseif( CramTheSpamFailedToLoadShouldSpew ) then
		CramTheSpamFailedToLoadTimer = CramTheSpamFailedToLoadTimer + elapsedTime;
		if( CramTheSpamFailedToLoadTimer > 5 ) then
			CramTheSpamFailedToLoadShouldSpew = false;
			EA_ChatWindow.Print( L"[CramTheSpam] FAILED TO LOAD", ChatSettings.Channels[SystemData.ChatLogFilters.SHOUT].id );
			EA_ChatWindow.Print( L"[CramTheSpam] FAILED TO LOAD", ChatSettings.Channels[SystemData.ChatLogFilters.SHOUT].id );
			EA_ChatWindow.Print( L"[CramTheSpam] FAILED TO LOAD", ChatSettings.Channels[SystemData.ChatLogFilters.SHOUT].id );
			EA_ChatWindow.Print( L"[CramTheSpam] FAILED TO LOAD", ChatSettings.Channels[SystemData.ChatLogFilters.SHOUT].id );
			EA_ChatWindow.Print( L"[CramTheSpam] FAILED TO LOAD", ChatSettings.Channels[SystemData.ChatLogFilters.SHOUT].id );
		end
	end
	--else do nothing
end