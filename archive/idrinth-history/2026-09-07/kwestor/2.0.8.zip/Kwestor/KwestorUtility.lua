KwestorUtility = {};

setmetatable( KwestorUtility, RMetUtility );
KwestorUtility.__index = KwestorUtility;

