KwestorGuiUtility = {};

function KwestorGuiUtility.Initialize()

	RMetGuiUtility.Initialize();

	setmetatable( KwestorGuiUtility, RMetGuiUtility );
	KwestorGuiUtility.__index = KwestorGuiUtility;

end
