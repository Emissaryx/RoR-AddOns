<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <UiMod name="Swinger" version="1.1" date="09/09/2017">

    <VersionSettings
      gameVersion="1.4.8"
      windowsVersion="1.0" />

    <Author name="Sullemunk" />
    <Description text="A melee auto-attack timer." />

    <Files>
      <!-- Lua first: defines functions -->
      <File name="Swinger.lua" />
      <!-- XML second: creates windows -->
      <File name="Swinger.xml" />
    </Files>

    <OnInitialize>
      <CallFunction name="Swinger.OnInitialize" />
    </OnInitialize>

    <OnUpdate>
      <CallFunction name="Swinger.Update" />
    </OnUpdate>

  </UiMod>
</ModuleFile>
