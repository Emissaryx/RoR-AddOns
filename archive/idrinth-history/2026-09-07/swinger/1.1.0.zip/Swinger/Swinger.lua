--==================================================
-- Swinger.lua
-- WAR Auto-Attack Timer
--==================================================

Swinger = Swinger or {}

local VERSION = "1.1"

-- Window names
local WIN        = "SwingerWindow"
local W_ICON     = "SwingerWindowMoraleImage"
local W_BUILDUP  = "SwingerWindowBuildUp"
local W_LABEL    = "SwingerWindowRangeLabel"
local W_LABEL_BG = "SwingerWindowRangeLabelBG"

--==================================================
-- Internal State
--==================================================

Swinger.Initialized     = false
Swinger.InCombat        = false
Swinger.IconReady       = false

Swinger.BaseSpeed       = 0
Swinger.SwingRemaining  = 0
Swinger.SwingActive     = false

Swinger.LastTint        = nil

--==================================================
-- Helpers
--==================================================

local function GetRightHand()
    if not CharacterWindow or not CharacterWindow.equipmentData then return nil end
    return CharacterWindow.equipmentData[GameData.EquipSlots.RIGHT_HAND]
end

local function SetStateText(text)
    LabelSetText(W_LABEL, text)
end

local function SetTint(state)
    if Swinger.LastTint == state then return end
    Swinger.LastTint = state

    if state == "idle" then
        WindowSetTintColor(W_BUILDUP, 0, 255, 0)
    elseif state == "early" then
        WindowSetTintColor(W_BUILDUP, 255, 255, 0)
    elseif state == "late" then
        WindowSetTintColor(W_BUILDUP, 255, 0, 0)
    end
end

--==================================================
-- Weapon / Icon Cache
--==================================================

function Swinger.RefreshWeapon(forceIcon)
    local slot = GetRightHand()
    if not slot or not slot.speed then
        Swinger.BaseSpeed = 0
        return false
    end

    Swinger.BaseSpeed =
        GetBonus(GameData.BonusTypes.EBONUS_AUTO_ATTACK_SPEED, slot.speed) or 0

    if forceIcon and slot.iconNum and DoesWindowExist(W_ICON) then
        local texture = GetIconData(slot.iconNum)
        CircleImageSetTexture(W_ICON, texture, 32, 32)
        Swinger.IconReady = true
    end

    return true
end

--==================================================
-- Swing Detection
--==================================================

function Swinger.OnSwing()
    if not Swinger.RefreshWeapon(false) then
        Swinger.SwingActive = false
        Swinger.SwingRemaining = 0
        return
    end

    Swinger.SwingActive = true
    Swinger.SwingRemaining = Swinger.BaseSpeed
end

--==================================================
-- Combat Log Hook
--==================================================

function Swinger.OnCombatLogUpdated(updateType, filterType)
    if updateType ~= SystemData.TextLogUpdate.ADDED then return end
    if filterType ~= SystemData.ChatLogFilters.YOUR_HITS then return end

    local count = TextLogGetNumEntries("Combat")
    if not count or count <= 0 then return end

    local _, _, text = TextLogGetEntry("Combat", count - 1)
    if not text then return end

    -- Localization-fragile but WAR-standard heuristic
    if text:find(L"attack") or text:find(L"ability") then
        Swinger.OnSwing()
    end
end

--==================================================
-- Lifecycle
--==================================================

function Swinger.OnInitialize()
    RegisterEventHandler(
        TextLogGetUpdateEventId("Combat"),
        "Swinger.OnCombatLogUpdated"
    )

    TextLogAddEntry(
        "Chat",
        0,
        L"<icon00057> Swinger " .. towstring(VERSION) .. L" Loaded."
    )

    CreateWindow(WIN, true)
    LayoutEditor.RegisterWindow(WIN, L"Swinger", L"Swinger", true, true, true, nil)
    WindowSetShowing(WIN, false)

    Swinger.Initialized = true
end

--==================================================
-- Update Loop
--==================================================
function Swinger.Update(dt)
    if not Swinger.Initialized then return end

    -- Ensure icon is initialized once windows exist
    if not Swinger.IconReady then
        Swinger.RefreshWeapon(true)
    end

    --==============================
    -- Combat state transition
    --==============================
    local inCombat = (GameData.Player and GameData.Player.inCombat) or false
    if inCombat ~= Swinger.InCombat then
        Swinger.InCombat = inCombat

        if inCombat then
            Swinger.RefreshWeapon(true)
            WindowSetShowing(WIN, true)
        else
            WindowSetShowing(WIN, false)
            Swinger.SwingActive = false
            Swinger.SwingRemaining = 0
            SetTint("idle")
            SetStateText(L"GO")
            return
        end
    end

    if not Swinger.InCombat then return end

    --==============================
    -- Swing timer update
    --==============================
    if Swinger.SwingActive then
        Swinger.SwingRemaining = Swinger.SwingRemaining - dt
        if Swinger.SwingRemaining < 0 then
            Swinger.SwingRemaining = 0
        end

        if Swinger.BaseSpeed > 0 then
            local pct = Swinger.SwingRemaining / Swinger.BaseSpeed

            if pct > 0.8 then
                SetTint("idle")
                SetStateText(L"GO")
            elseif pct > 0.33 then
                SetTint("early")
                SetStateText(L"USE")
            else
                SetTint("late")
                SetStateText(L"WAIT")
            end
        end

        if Swinger.SwingRemaining <= 0 then
            Swinger.SwingRemaining = 0
            Swinger.SwingActive = false
            SetTint("idle")
            SetStateText(L"GO")
        end
    else
        -- Idle (between swings)
        SetTint("idle")
        SetStateText(L"GO")
    end

    --==============================
    -- Cooldown visual
    --==============================
    if Swinger.BaseSpeed > 0 then
        CooldownDisplaySetCooldown(
            W_BUILDUP,
            Swinger.SwingRemaining,
            Swinger.BaseSpeed
        )
    else
        CooldownDisplaySetCooldown(W_BUILDUP, 0, 1)
    end

    --==============================
    -- Numeric timer (ALWAYS visible)
    --==============================
    LabelSetText(
        W_LABEL_BG,
        wstring.format(L"%.1f", Swinger.SwingRemaining)
    )
end