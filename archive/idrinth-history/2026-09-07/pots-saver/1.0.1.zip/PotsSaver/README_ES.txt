Pots Saver v1.0.1

Qué hace
Pots Saver bloquea habilidades configuradas usando uno de estos dos tipos de regla:
- Regla AP: bloquea la habilidad mientras tus AP actuales estén por encima del tope guardado.
- Regla HP: bloquea la habilidad mientras tu porcentaje actual de vida esté por encima del umbral guardado.

Cómo configurar habilidades
1. Abre la configuración con /potssaver.
2. Ve a la pestaña Programming.
3. Pulsa Program AP o Program HP para elegir qué grabará CTRL + clic izquierdo.
4. Haz CTRL + clic izquierdo sobre una casilla de la hotbar para ir cambiando la regla de esa habilidad.

Ciclos
- Modo AP: limpiar -> 0 -> 10 -> 20 -> ... -> 200 -> limpiar
- Modo HP: limpiar -> 0% -> 10% -> 20% -> ... -> 100% -> limpiar

Texto en el botón
- AP30 = máximo 30 AP
- HP30% = solo usable con 30% de vida o menos

Macro de configuración
- El addon puede crear una macro que abre la ventana de configuración.
- Texto de la macro: /script PotsSaver.OpenConfig()
- El addon también intenta crear o refrescar esa macro al cargarse.

Comandos
- /potssaver
- /appotssaver
- /hppotssaver

Notas
- Este addon puede importar reglas antiguas de APPotsSaver y HPPotsSaver.
- Incluye optimización Smart GCD y actualización solo de las casillas vigiladas.
- Autor: Kpihuss
