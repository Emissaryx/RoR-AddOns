LibConfig = LibStub("LibConfig")

PotsSaver_Config = {}

local GUI
local ProgrammingUI = {}

function PotsSaver_Config.RoundTenth(value)
	if type(value) ~= "number" then
		value = tonumber(value) or 0
	end
	value = math.floor((value * 10) + 0.5) / 10
	return value
end

function PotsSaver_Config.FormatTenthSeconds(value)
	value = PotsSaver_Config.RoundTenth(value)
	return string.format("%.1fs", value)
end

function PotsSaver_Config.RefreshProgrammingUI()
	if not ProgrammingUI.mode then
		return
	end
	if PotsSaver.Settings.ProgramAPMode then
		ProgrammingUI.mode:SetText("Current mode: Program AP")
		ProgrammingUI.apButton:Disable()
		ProgrammingUI.hpButton:Enable()
	else
		ProgrammingUI.mode:SetText("Current mode: Program HP")
		ProgrammingUI.hpButton:Disable()
		ProgrammingUI.apButton:Enable()
	end
end

function PotsSaver_Config.SetProgramMode(isAP)
	PotsSaver.Settings.ProgramAPMode = isAP and true or false
	PotsSaver.NormalizeSettings()
	PotsSaver_Config.RefreshProgrammingUI()
	PotsSaver.UpdateSettings()
end

function PotsSaver_Config.CreateConfigMacro()
	PotsSaver.EnsureConfigMacro(true)
end

function PotsSaver_Config.Slash(input)
	if (not GUI) then
		GUI = LibConfig("Pots Saver v" .. tostring(PotsSaver.Settings.Version), PotsSaver.Settings, true, PotsSaver_Config.SettingsChanged)

		GUI:AddTab("Info")
		local infoText
		infoText = GUI("label", "Pots Saver blocks configured abilities using either an AP cap or an HP threshold, depending on the rule stored on that ability.")
		infoText.label:Font("font_default_text_small")
		infoText.label:Align("left")

		infoText = GUI("label", "CTRL + left click a hotbar slot to cycle its rule using the current programming mode from the Programming tab.")
		infoText.label:Font("font_default_text_small")
		infoText.label:Align("left")

		infoText = GUI("label", "AP rules cycle clear -> 0 -> 10 -> ... -> 200 -> clear. HP rules cycle clear -> 0% -> 10% -> ... -> 100% -> clear.")
		infoText.label:Font("font_default_text_small")
		infoText.label:Align("left")

		infoText = GUI("label", "Button text shows the rule type: AP30 means max 30 AP. HP30% means the action is only usable at 30% HP or lower.")
		infoText.label:Font("font_default_text_small")
		infoText.label:Align("left")

		infoText = GUI("label", "This version only checks watched slots and can sleep through most of the GCD.")
		infoText.label:Font("font_default_text_small")
		infoText.label:Align("left")

		infoText = GUI("label", "Use + and - to change values in 0.1s steps. Recommended defaults: Idle 0.5s, Burst 0.1s, GCD Sleep 1.4s, Burst Window 0.2s.")
		infoText.label:Font("font_default_text_small")
		infoText.label:Align("left")

		GUI:AddTab("Settings")
		local enabled = GUI("checkbox", "Enabled", "Enabled")
		enabled.label:Font("font_default_text_small")
		local desc = GUI("label", "Master switch for the addon. When off, no actions are blocked.")
		desc.label:Font("font_default_text_small")
		desc.label:Align("left")

		local symbols = GUI("checkbox", "Show Symbols", "Symbols")
		symbols.label:Font("font_default_text_small")
		desc = GUI("label", "Shows the configured AP or HP rule on watched hotbar buttons.")
		desc.label:Font("font_default_text_small")
		desc.label:Align("left")

		local errors = GUI("checkbox", "Show Combat Error messages", "ErrorMessages")
		errors.label:Font("font_default_text_small")
		desc = GUI("label", "Shows a combat alert if you try to use a blocked action.")
		desc.label:Font("font_default_text_small")
		desc.label:Align("left")


		GUI:AddTab("Programming")
		local programmingLayer = GUI.layers[GUI.currentTab]

		ProgrammingUI.info = programmingLayer("label")
		ProgrammingUI.info:Resize(programmingLayer.width, 36)
		ProgrammingUI.info:AnchorTo(programmingLayer, "topleft", "topleft", 0, 0)
		ProgrammingUI.info:WordWrap(true)
		ProgrammingUI.info:Align("left")
		ProgrammingUI.info:SetText("Choose what CTRL + left click will write to a hotbar slot.")
		ProgrammingUI.info:Font("font_default_text_small")

		ProgrammingUI.mode = programmingLayer("label")
		ProgrammingUI.mode:Resize(programmingLayer.width, 24)
		ProgrammingUI.mode:AnchorTo(ProgrammingUI.info, "bottomleft", "topleft", 0, 8)
		ProgrammingUI.mode:Align("left")
		ProgrammingUI.mode:Font("font_default_text_small")

		ProgrammingUI.hpButton = programmingLayer("button")
		ProgrammingUI.hpButton:Resize(180)
		ProgrammingUI.hpButton:AnchorTo(ProgrammingUI.mode, "bottomleft", "topleft", 0, 12)
		ProgrammingUI.hpButton:SetText("Program HP")

		ProgrammingUI.apButton = programmingLayer("button")
		ProgrammingUI.apButton:Resize(180)
		ProgrammingUI.apButton:AnchorTo(ProgrammingUI.hpButton, "topright", "topleft", 20, 0)
		ProgrammingUI.apButton:SetText("Program AP")

		ProgrammingUI.macroInfo = programmingLayer("label")
		ProgrammingUI.macroInfo:Resize(programmingLayer.width, 36)
		ProgrammingUI.macroInfo:AnchorTo(ProgrammingUI.hpButton, "bottomleft", "topleft", 0, 18)
		ProgrammingUI.macroInfo:WordWrap(true)
		ProgrammingUI.macroInfo:Align("left")
		ProgrammingUI.macroInfo:SetText("Create or refresh a macro that opens the addon configuration.")
		ProgrammingUI.macroInfo:Font("font_default_text_small")

		ProgrammingUI.macroButton = programmingLayer("button")
		ProgrammingUI.macroButton:Resize(220)
		ProgrammingUI.macroButton:AnchorTo(ProgrammingUI.macroInfo, "bottomleft", "topleft", 0, 12)
		ProgrammingUI.macroButton:SetText("Create Config Macro")

		ProgrammingUI.macroNote = programmingLayer("label")
		ProgrammingUI.macroNote:Resize(programmingLayer.width, 48)
		ProgrammingUI.macroNote:AnchorTo(ProgrammingUI.macroButton, "bottomleft", "topleft", 0, 10)
		ProgrammingUI.macroNote:WordWrap(true)
		ProgrammingUI.macroNote:Align("left")
		ProgrammingUI.macroNote:SetText("Macro text: /script PotsSaver.OpenConfig()")
		ProgrammingUI.macroNote:Font("font_default_text_small")

		ProgrammingUI.hpButton.OnLButtonUp = function() PotsSaver_Config.SetProgramMode(false) end
		ProgrammingUI.apButton.OnLButtonUp = function() PotsSaver_Config.SetProgramMode(true) end
		ProgrammingUI.macroButton.OnLButtonUp = function() PotsSaver_Config.CreateConfigMacro() end

		GUI:AddTab("Performance")
		local smartGCD = GUI("checkbox", "Use Smart GCD Optimization", "UseSmartGCD")
		smartGCD.label:Font("font_default_text_small")
		desc = GUI("label", "Sleeps through most of the GCD, then checks again near the end to reduce UI work.")
		desc.label:Font("font_default_text_small")
		desc.label:Align("left")

		local idleStepper = GUI("stepper", "Idle Check Interval", "IdleInterval", PotsSaver_Config.RoundTenth)
		idleStepper.label:Font("font_default_text_small")
		idleStepper:SetRange(0.1, 2.0, 0.1)
		idleStepper:SetFormatter(PotsSaver_Config.FormatTenthSeconds)
		desc = GUI("label", "How often watched slots are checked outside Smart GCD mode. Lower reacts faster.")
		desc.label:Font("font_default_text_small")
		desc.label:Align("left")

		local burstStepper = GUI("stepper", "Burst Check Interval", "BurstInterval", PotsSaver_Config.RoundTenth)
		burstStepper.label:Font("font_default_text_small")
		burstStepper:SetRange(0.1, 2.0, 0.1)
		burstStepper:SetFormatter(PotsSaver_Config.FormatTenthSeconds)
		desc = GUI("label", "How often watched slots are checked near the end of the GCD. 0.1s is fastest.")
		desc.label:Font("font_default_text_small")
		desc.label:Align("left")

		local sleepStepper = GUI("stepper", "GCD Sleep Duration", "GCDSleepDuration", PotsSaver_Config.RoundTenth)
		sleepStepper.label:Font("font_default_text_small")
		sleepStepper:SetRange(0.0, 2.0, 0.1)
		sleepStepper:SetFormatter(PotsSaver_Config.FormatTenthSeconds)
		desc = GUI("label", "How long the addon waits after an action before resuming checks. Default: 1.4s.")
		desc.label:Font("font_default_text_small")
		desc.label:Align("left")

		local windowStepper = GUI("stepper", "GCD Burst Window", "GCDBurstWindow", PotsSaver_Config.RoundTenth)
		windowStepper.label:Font("font_default_text_small")
		windowStepper:SetRange(0.1, 1.0, 0.1)
		windowStepper:SetFormatter(PotsSaver_Config.FormatTenthSeconds)
		desc = GUI("label", "Length of the fast-check window after sleep ends. Default: 0.2s.")
		desc.label:Font("font_default_text_small")
		desc.label:Align("left")
	end
	PotsSaver_Config.RefreshProgrammingUI()
	GUI:Show()
end

function PotsSaver_Config.SettingsChanged()
	GUI:Hide()
	PotsSaver.NormalizeSettings()
	PotsSaver.UpdateSettings()
	PotsSaver_Config.RefreshProgrammingUI()
end
