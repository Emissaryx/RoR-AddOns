-- Local data
local VERSION = "1.0.1"
local MAX_BUTTONS = 60
local MAX_AP = 200
local AP_STEP = 10
local MAX_HP_PERCENT = 100
local HP_PERCENT_STEP = 10
local MIN_INTERVAL = 0.1
local MAX_INTERVAL = 2.0
local MIN_BURST_WINDOW = 0.1
local MAX_BURST_WINDOW = 1.0
local DEFAULT_IDLE_INTERVAL = 0.5
local DEFAULT_BURST_INTERVAL = 0.1
local DEFAULT_GCD_SLEEP_DURATION = 1.4
local DEFAULT_GCD_BURST_WINDOW = 0.2
local MODE_AP = "AP"
local MODE_HP = "HP"
local CONFIG_MACRO_NAME = towstring("PotsSaver")
local CONFIG_MACRO_TEXT = towstring("/script PotsSaver.OpenConfig()")
local CONFIG_MACRO_ICON_ID = 57

local eventsRegistered = false
local loadingEnd = false
local currentTime = 0
local nextCheckAt = 0
local gcdSleepUntil = 0
local gcdBurstUntil = 0

-- Localized functions
local tostring = tostring
local towstring = towstring
local floor = math.floor
local GetAbilityData = GetAbilityData
local GetHotbarData = GetHotbarData
local BroadcastEvent = BroadcastEvent
local TextLogAddEntry = TextLogAddEntry
local RegisterEventHandler = RegisterEventHandler
local UnregisterEventHandler = UnregisterEventHandler

local orgWindowGameAction = WindowGameAction
local orgActionBarsUpdateSlotEnabledState = ActionBars.UpdateSlotEnabledState
local orgActionButtonOnLButtonDown = ActionButton.OnLButtonDown
local orgActionButtonOnLButtonUp = ActionButton.OnLButtonUp
local orgActionButtonUpdateInventory = ActionButton.UpdateInventory

local function clamp(value, minValue, maxValue)
	if value < minValue then return minValue end
	if value > maxValue then return maxValue end
	return value
end

local function roundToStep(value, step)
	if type(value) ~= "number" then
		return value
	end
	return floor((value / step) + 0.5) * step
end

local function sanitizeInterval(value, defaultValue)
	value = tonumber(value) or defaultValue
	value = roundToStep(value, 0.1)
	value = clamp(value, MIN_INTERVAL, MAX_INTERVAL)
	return value
end

local function sanitizeWindow(value, defaultValue)
	value = tonumber(value) or defaultValue
	value = roundToStep(value, 0.1)
	value = clamp(value, MIN_BURST_WINDOW, MAX_BURST_WINDOW)
	return value
end

local function sanitizeSleep(value, defaultValue)
	value = tonumber(value) or defaultValue
	value = roundToStep(value, 0.1)
	value = clamp(value, 0.0, MAX_INTERVAL)
	return value
end

local function boolDefault(value, defaultValue)
	if value == nil then return defaultValue end
	return value and true or false
end

local function copySimpleSettings(fromSettings, toSettings)
	if type(fromSettings) ~= "table" or type(toSettings) ~= "table" then
		return
	end
	local keys = {
		"Enabled",
		"Symbols",
		"ErrorMessages",
		"UseSmartGCD",
		"IdleInterval",
		"BurstInterval",
		"GCDSleepDuration",
		"GCDBurstWindow",
		"ProgramAPMode",
	}
	for _, key in ipairs(keys) do
		if fromSettings[key] ~= nil then
			toSettings[key] = fromSettings[key]
		end
	end
end

local function alertText(text)
	if SettingsWindowTabInterface and SettingsWindowTabInterface.SavedMessageSettings and SettingsWindowTabInterface.SavedMessageSettings.combat then
		SystemData.AlertText.VecType = {SystemData.AlertText.Types.COMBAT}
		SystemData.AlertText.VecText = {towstring(text)}
		BroadcastEvent(SystemData.Events.SHOW_ALERT_TEXT)
	end
end

local function getCurrentAP()
	if GameData and GameData.Player and GameData.Player.actionPoints then
		local ap = GameData.Player.actionPoints.current
		if type(ap) == "number" then
			return ap
		end
	end
	return 0
end

local function getCurrentHPPercent()
	if not (GameData and GameData.Player) then
		return 0
	end

	local hpData = GameData.Player.hitPoints or GameData.Player.health or GameData.Player.HitPoints
	if type(hpData) ~= "table" then
		return 0
	end

	local current = hpData.current or hpData.Current or hpData.cur or hpData.value
	local maximum = hpData.maximum or hpData.max or hpData.Max or hpData.maxValue

	if type(current) ~= "number" or type(maximum) ~= "number" or maximum <= 0 then
		return 0
	end

	return clamp((current / maximum) * 100, 0, 100)
end

local function sanitizeMode(value)
	if value == MODE_HP then
		return MODE_HP
	end
	return MODE_AP
end

local function sanitizeThresholdForMode(mode, value)
	mode = sanitizeMode(mode)
	value = tonumber(value)
	if type(value) ~= "number" then
		return nil
	end

	if mode == MODE_AP then
		value = roundToStep(value, AP_STEP)
		return clamp(value, 0, MAX_AP)
	end

	value = roundToStep(value, HP_PERCENT_STEP)
	return clamp(value, 0, MAX_HP_PERCENT)
end

local function normalizeRule(rule)
	if rule == nil then
		return nil
	end

	if type(rule) == "number" then
		local defaultMode = PotsSaver.Settings and PotsSaver.Settings.ProgramAPMode and MODE_AP or MODE_HP
		local threshold = sanitizeThresholdForMode(defaultMode, rule)
		if threshold == nil then
			return nil
		end
		return { Mode = defaultMode, Threshold = threshold }
	end

	if type(rule) ~= "table" then
		return nil
	end

	local mode = sanitizeMode(rule.Mode or rule.mode or rule.RuleMode or rule.ruleMode)
	local threshold = sanitizeThresholdForMode(mode, rule.Threshold or rule.threshold or rule.Value or rule.value)
	if threshold == nil then
		return nil
	end

	return {
		Mode = mode,
		Threshold = threshold,
	}
end

local function getRule(actionId)
	if actionId == nil or actionId == 0 or not PotsSaver.Settings or type(PotsSaver.Settings.AbilityRules) ~= "table" then
		return nil
	end
	return normalizeRule(PotsSaver.Settings.AbilityRules[actionId])
end

local function storeRule(actionId, rule)
	if actionId == nil or actionId == 0 then
		return
	end
	if rule == nil then
		PotsSaver.Settings.AbilityRules[actionId] = nil
		return
	end
	local normalized = normalizeRule(rule)
	if normalized == nil then
		PotsSaver.Settings.AbilityRules[actionId] = nil
		return
	end
	PotsSaver.Settings.AbilityRules[actionId] = normalized
end

local function formatRuleShort(rule)
	if rule == nil then
		return nil
	end
	if rule.Mode == MODE_AP then
		return "AP" .. tostring(rule.Threshold)
	end
	return "HP" .. tostring(rule.Threshold) .. "%"
end

local function chatInfo(actionId, rule)
	local ability = GetAbilityData(actionId)
	if not ability then return end
	local name = tostring(ability.name)
	local icon = "<icon" .. tostring(ability.iconNum) .. ">"
	if rule == nil then
		TextLogAddEntry("Chat", 0, towstring("Pots Saver: Clearing rule for " .. icon .. " " .. name))
	elseif rule.Mode == MODE_AP then
		TextLogAddEntry("Chat", 0, towstring("Pots Saver: Setting AP cap to " .. tostring(rule.Threshold) .. " for " .. icon .. " " .. name))
	else
		TextLogAddEntry("Chat", 0, towstring("Pots Saver: Setting HP threshold to " .. tostring(rule.Threshold) .. "% for " .. icon .. " " .. name))
	end
end

local function nextThresholdForMode(mode, current)
	if mode == MODE_AP then
		if current == nil then
			return 0
		elseif current >= MAX_AP then
			return nil
		else
			return current + AP_STEP
		end
	end

	if current == nil then
		return 0
	elseif current >= MAX_HP_PERCENT then
		return nil
	else
		return current + HP_PERCENT_STEP
	end
end

local function nextRule(currentRule)
	local mode = PotsSaver.Settings.ProgramAPMode and MODE_AP or MODE_HP
	local currentThreshold = nil
	if currentRule and currentRule.Mode == mode then
		currentThreshold = currentRule.Threshold
	end
	local nextThreshold = nextThresholdForMode(mode, currentThreshold)
	if nextThreshold == nil then
		return nil
	end
	return {
		Mode = mode,
		Threshold = nextThreshold,
	}
end

local function isConfiguredAction(actionId)
	return actionId ~= nil and actionId ~= 0 and getRule(actionId) ~= nil
end

local function isRuleBlocked(rule, showError)
	if not PotsSaver.Settings.Enabled or rule == nil then
		return false
	end

	if rule.Mode == MODE_AP then
		local currentAP = getCurrentAP()
		if currentAP > rule.Threshold then
			if showError and PotsSaver.Settings.ErrorMessages then
				alertText("Too much AP: " .. tostring(currentAP) .. " / max " .. tostring(rule.Threshold))
			end
			return true
		end
		return false
	end

	local currentHPPercent = getCurrentHPPercent()
	if currentHPPercent > rule.Threshold then
		if showError and PotsSaver.Settings.ErrorMessages then
			alertText("HP too high: " .. tostring(floor(currentHPPercent + 0.5)) .. "% / max " .. tostring(rule.Threshold) .. "%")
		end
		return true
	end
	return false
end

local function isAbilityBlocked(actionId, showError)
	return isRuleBlocked(getRule(actionId), showError)
end

local function importLegacyAbilities(targetRules, sourceAbilities, mode)
	if type(targetRules) ~= "table" or type(sourceAbilities) ~= "table" then
		return
	end
	for actionId, threshold in pairs(sourceAbilities) do
		if targetRules[actionId] == nil then
			local normalizedThreshold = sanitizeThresholdForMode(mode, threshold)
			if normalizedThreshold ~= nil then
				targetRules[actionId] = {
					Mode = mode,
					Threshold = normalizedThreshold,
				}
			end
		end
	end
end

local function tryGetWindowGameActionData(windowName)
	if type(WindowGetGameActionData) ~= "function" then
		return nil
	end

	local ok, a, b, c, d = pcall(WindowGetGameActionData, windowName)
	if not ok then
		return nil
	end

	if type(a) == "table" then
		return a
	end

	return { a, b, c, d }
end

local function resolveActionIdFromWindow(windowName)
	if not windowName then
		return nil
	end

	local data = tryGetWindowGameActionData(windowName)
	if not data then
		return nil
	end

	if data.actionId then return data.actionId end
	if data.ActionId then return data.ActionId end
	if data.abilityId then return data.abilityId end
	if data.AbilityId then return data.AbilityId end
	if data.id then return data.id end
	if data.Id then return data.Id end

	local slot = data.hotbarSlot or data.HotbarSlot or data.slot or data.Slot or data[1]
	local maybeActionId = data[2]
	if type(maybeActionId) == "number" and maybeActionId ~= 0 then
		return maybeActionId
	end
	if type(slot) == "number" and slot >= 1 and slot <= MAX_BUTTONS then
		local _, actionId = GetHotbarData(slot)
		if type(actionId) == "number" and actionId ~= 0 then
			return actionId
		end
	end

	return nil
end


local function normalizeMacroText(value)
	if value == nil then return nil end
	if type(value) == "wstring" then return WStringToString(value) end
	if type(value) == "string" then return value end
	return tostring(value)
end

local function tryGetMacros()
	if type(DataUtils) == "table" and type(DataUtils.GetMacros) == "function" then
		local ok, macros = pcall(DataUtils.GetMacros)
		if ok and type(macros) == "table" then
			return macros
		end
	end
	return nil
end

local function getMatchingMacroSlot(targetText)
	local macros = tryGetMacros()
	if type(EA_Window_Macro) ~= "table" or type(EA_Window_Macro.NUM_MACROS) ~= "number" or type(macros) ~= "table" then
		return nil
	end
	local wanted = normalizeMacroText(targetText)
	for slot = 1, EA_Window_Macro.NUM_MACROS do
		local macro = macros[slot]
		local macroText = macro and macro.text or nil
		if normalizeMacroText(macroText) == wanted then
			return slot
		end
	end
	return nil
end

local function getEmptyMacroSlot()
	local macros = tryGetMacros()
	if type(EA_Window_Macro) ~= "table" or type(EA_Window_Macro.NUM_MACROS) ~= "number" or type(macros) ~= "table" then
		return nil
	end
	for slot = 1, EA_Window_Macro.NUM_MACROS do
		local macro = macros[slot]
		local macroText = macro and macro.text or nil
		local normalized = normalizeMacroText(macroText)
		if normalized == nil or normalized == "" then
			return slot
		end
	end
	return nil
end

PotsSaver = PotsSaver or {}
PotsSaver.EnabledStatesNeedUpdate = true
PotsSaver.ButtonIconsNeedUpdate = true
PotsSaver.FullRefreshNeeded = true
PotsSaver.WatchedSlots = {}
PotsSaver.LastSlotStates = {}

PotsSaver.DefaultSettings = {
	Version = VERSION,
	Enabled = true,
	ProgramAPMode = true,
	Symbols = true,
	ErrorMessages = true,
	UseSmartGCD = true,
	IdleInterval = DEFAULT_IDLE_INTERVAL,
	BurstInterval = DEFAULT_BURST_INTERVAL,
	GCDSleepDuration = DEFAULT_GCD_SLEEP_DURATION,
	GCDBurstWindow = DEFAULT_GCD_BURST_WINDOW,
	AbilityRules = {},
}

function PotsSaver.NormalizeSettings()
	PotsSaver.Settings.Version = PotsSaver.DefaultSettings.Version
	PotsSaver.Settings.Enabled = boolDefault(PotsSaver.Settings.Enabled, PotsSaver.DefaultSettings.Enabled)
	PotsSaver.Settings.ProgramAPMode = boolDefault(PotsSaver.Settings.ProgramAPMode, PotsSaver.DefaultSettings.ProgramAPMode)
	PotsSaver.Settings.Symbols = boolDefault(PotsSaver.Settings.Symbols, PotsSaver.DefaultSettings.Symbols)
	PotsSaver.Settings.ErrorMessages = boolDefault(PotsSaver.Settings.ErrorMessages, PotsSaver.DefaultSettings.ErrorMessages)
	PotsSaver.Settings.UseSmartGCD = boolDefault(PotsSaver.Settings.UseSmartGCD, PotsSaver.DefaultSettings.UseSmartGCD)
	PotsSaver.Settings.IdleInterval = sanitizeInterval(PotsSaver.Settings.IdleInterval, PotsSaver.DefaultSettings.IdleInterval)
	PotsSaver.Settings.BurstInterval = sanitizeInterval(PotsSaver.Settings.BurstInterval, PotsSaver.DefaultSettings.BurstInterval)
	PotsSaver.Settings.GCDSleepDuration = sanitizeSleep(PotsSaver.Settings.GCDSleepDuration, PotsSaver.DefaultSettings.GCDSleepDuration)
	PotsSaver.Settings.GCDBurstWindow = sanitizeWindow(PotsSaver.Settings.GCDBurstWindow, PotsSaver.DefaultSettings.GCDBurstWindow)

	if type(PotsSaver.Settings.AbilityRules) ~= "table" then
		PotsSaver.Settings.AbilityRules = {}
	end

	if type(PotsSaver.Settings.Abilities) == "table" then
		local mode = PotsSaver.Settings.ProgramAPMode and MODE_AP or MODE_HP
		importLegacyAbilities(PotsSaver.Settings.AbilityRules, PotsSaver.Settings.Abilities, mode)
		PotsSaver.Settings.Abilities = nil
	end

	for actionId, rule in pairs(PotsSaver.Settings.AbilityRules) do
		local normalized = normalizeRule(rule)
		if normalized == nil then
			PotsSaver.Settings.AbilityRules[actionId] = nil
		else
			PotsSaver.Settings.AbilityRules[actionId] = normalized
		end
	end
end

function PotsSaver.ScheduleNextCheck(forceImmediate)
	if forceImmediate then
		nextCheckAt = currentTime
		return
	end

	if PotsSaver.Settings.UseSmartGCD and currentTime < gcdSleepUntil then
		nextCheckAt = gcdSleepUntil
		return
	end

	local interval = PotsSaver.Settings.IdleInterval
	if PotsSaver.Settings.UseSmartGCD and currentTime < gcdBurstUntil then
		interval = PotsSaver.Settings.BurstInterval
	end

	nextCheckAt = currentTime + interval
end

function PotsSaver.MarkDirty(forceImmediate, fullRefresh)
	PotsSaver.EnabledStatesNeedUpdate = true
	if fullRefresh then
		PotsSaver.FullRefreshNeeded = true
		PotsSaver.LastSlotStates = {}
	end
	PotsSaver.ScheduleNextCheck(forceImmediate)
end

function PotsSaver.MarkIconsDirty()
	PotsSaver.ButtonIconsNeedUpdate = true
end

function PotsSaver.RebuildWatchedSlots()
	local watched = {}
	for slot = 1, MAX_BUTTONS do
		local _, actionId = GetHotbarData(slot)
		if PotsSaver.Settings.Enabled and isConfiguredAction(actionId) then
			watched[slot] = true
		end
	end
	PotsSaver.WatchedSlots = watched
end

function PotsSaver.NotifyPossibleGlobalCooldown(actionId)
	if not PotsSaver.Settings.Enabled then return end
	if not PotsSaver.Settings.UseSmartGCD then return end
	if not actionId or actionId == 0 then return end

	gcdSleepUntil = currentTime + PotsSaver.Settings.GCDSleepDuration
	gcdBurstUntil = gcdSleepUntil + PotsSaver.Settings.GCDBurstWindow
	if gcdBurstUntil < gcdSleepUntil then
		gcdBurstUntil = gcdSleepUntil
	end
	PotsSaver.ScheduleNextCheck(false)
end

function PotsSaver.OpenConfig()
	PotsSaver_Config.Slash("")
end

function PotsSaver.EnsureConfigMacro(showFeedback)
	if type(SetMacroData) ~= "function" then
		if showFeedback then
			TextLogAddEntry("Chat", 0, towstring("Pots Saver: Macro API not available."))
		end
		return nil
	end

	local slot = getMatchingMacroSlot(CONFIG_MACRO_TEXT) or getEmptyMacroSlot()
	if not slot then
		if showFeedback then
			TextLogAddEntry("Chat", 0, towstring("Pots Saver: No free macro slot found."))
		end
		return nil
	end

	SetMacroData(CONFIG_MACRO_NAME, CONFIG_MACRO_TEXT, CONFIG_MACRO_ICON_ID, slot)
	if type(EA_Window_Macro) == "table" and type(EA_Window_Macro.UpdateDetails) == "function" then
		EA_Window_Macro.UpdateDetails(slot)
	end

	if showFeedback then
		TextLogAddEntry("Chat", 0, towstring("Pots Saver: Config macro ready in slot " .. tostring(slot) .. "."))
	end
	return slot
end

function PotsSaver.Initialize()
	if type(PotsSaver.Settings) ~= "table" then
		PotsSaver.Settings = {}
	end

	local importedSettings = {}
	if type(APPotsSaver) == "table" and type(APPotsSaver.Settings) == "table" then
		copySimpleSettings(APPotsSaver.Settings, importedSettings)
		if type(importedSettings.AbilityRules) ~= "table" then
			importedSettings.AbilityRules = {}
		end
		importLegacyAbilities(importedSettings.AbilityRules, APPotsSaver.Settings.Abilities, MODE_AP)
	end
	if type(HPPotsSaver) == "table" and type(HPPotsSaver.Settings) == "table" then
		copySimpleSettings(HPPotsSaver.Settings, importedSettings)
		if type(importedSettings.AbilityRules) ~= "table" then
			importedSettings.AbilityRules = {}
		end
		importLegacyAbilities(importedSettings.AbilityRules, HPPotsSaver.Settings.Abilities, MODE_HP)
		if HPPotsSaver.Settings.ProgramAPMode ~= nil then
			importedSettings.ProgramAPMode = HPPotsSaver.Settings.ProgramAPMode
		end
	end

	for key, value in pairs(PotsSaver.DefaultSettings) do
		if PotsSaver.Settings[key] == nil then
			if importedSettings[key] ~= nil then
				PotsSaver.Settings[key] = importedSettings[key]
			elseif type(value) == "table" then
				PotsSaver.Settings[key] = {}
			else
				PotsSaver.Settings[key] = value
			end
		end
	end

	if type(PotsSaver.Settings.AbilityRules) ~= "table" then
		PotsSaver.Settings.AbilityRules = importedSettings.AbilityRules or {}
	end

	PotsSaver.NormalizeSettings()
	PotsSaver.RebuildWatchedSlots()
	PotsSaver.MarkDirty(true, true)
	PotsSaver.MarkIconsDirty()

	LibSlash.RegisterSlashCmd("potssaver", function(input) PotsSaver_Config.Slash(input) end)
	LibSlash.RegisterSlashCmd("appotssaver", function(input) PotsSaver_Config.Slash(input) end)
	LibSlash.RegisterSlashCmd("hppotssaver", function(input) PotsSaver_Config.Slash(input) end)

	PotsSaver.EnsureConfigMacro(false)

	if PotsSaver.Settings.Enabled then PotsSaver.RegisterEvents() end

	TextLogAddEntry("Chat", 0, towstring("<icon57> Pots Saver v" .. tostring(PotsSaver.Settings.Version) .. " by Kpihuss loaded. Type /potssaver or use the PotsSaver macro for settings."))
end

function PotsSaver.OnShutdown()
	PotsSaver.UnregisterEvents()
end

function PotsSaver.RegisterEvents()
	if not eventsRegistered then
		RegisterEventHandler(SystemData.Events.ENTER_WORLD, "PotsSaver.ENTER_WORLD")
		RegisterEventHandler(SystemData.Events.PLAYER_ZONE_CHANGED, "PotsSaver.PLAYER_ZONE_CHANGED")
		RegisterEventHandler(SystemData.Events.INTERFACE_RELOADED, "PotsSaver.INTERFACE_RELOADED")
		RegisterEventHandler(SystemData.Events.PLAYER_HOT_BAR_UPDATED, "PotsSaver.PLAYER_HOT_BAR_UPDATED")
	end
	eventsRegistered = true
end

function PotsSaver.UnregisterEvents()
	if eventsRegistered then
		UnregisterEventHandler(SystemData.Events.ENTER_WORLD, "PotsSaver.ENTER_WORLD")
		UnregisterEventHandler(SystemData.Events.PLAYER_ZONE_CHANGED, "PotsSaver.PLAYER_ZONE_CHANGED")
		UnregisterEventHandler(SystemData.Events.INTERFACE_RELOADED, "PotsSaver.INTERFACE_RELOADED")
		UnregisterEventHandler(SystemData.Events.PLAYER_HOT_BAR_UPDATED, "PotsSaver.PLAYER_HOT_BAR_UPDATED")
	end
	eventsRegistered = false
end

function PotsSaver.ENTER_WORLD()
	loadingEnd = true
	PotsSaver.RebuildWatchedSlots()
	PotsSaver.MarkIconsDirty()
	PotsSaver.MarkDirty(true, true)
end

function PotsSaver.PLAYER_ZONE_CHANGED()
	loadingEnd = true
	PotsSaver.RebuildWatchedSlots()
	PotsSaver.MarkIconsDirty()
	PotsSaver.MarkDirty(true, true)
end

function PotsSaver.INTERFACE_RELOADED()
	loadingEnd = true
	PotsSaver.RebuildWatchedSlots()
	PotsSaver.MarkIconsDirty()
	PotsSaver.MarkDirty(true, true)
end

function PotsSaver.PLAYER_HOT_BAR_UPDATED(slot, actionType, actionId)
	PotsSaver.RebuildWatchedSlots()
	PotsSaver.UpdateButtonIcon(slot, (PotsSaver.Settings.Enabled and PotsSaver.Settings.Symbols and getRule(actionId)) or nil)
	PotsSaver.MarkIconsDirty()
	PotsSaver.MarkDirty(true, true)
end

function PotsSaver.OnUpdate(elapsed)
	currentTime = currentTime + elapsed

	if not loadingEnd then return end

	if PotsSaver.ButtonIconsNeedUpdate then
		PotsSaver.UpdateButtonIcons()
		PotsSaver.ButtonIconsNeedUpdate = false
	end

	if not PotsSaver.Settings.Enabled then
		return
	end

	if currentTime < nextCheckAt then
		return
	end

	if PotsSaver.FullRefreshNeeded then
		PotsSaver.UpdateButtonsEnabledStates(true)
		PotsSaver.FullRefreshNeeded = false
		PotsSaver.EnabledStatesNeedUpdate = false
		PotsSaver.ScheduleNextCheck(false)
		return
	end

	PotsSaver.UpdateButtonsEnabledStates(false)
	PotsSaver.EnabledStatesNeedUpdate = false
	PotsSaver.ScheduleNextCheck(false)
end

function PotsSaver.UpdateSettings()
	PotsSaver.NormalizeSettings()

	if PotsSaver.Settings.Enabled and not eventsRegistered then
		PotsSaver.RegisterEvents()
	elseif not PotsSaver.Settings.Enabled and eventsRegistered then
		PotsSaver.UnregisterEvents()
	end

	PotsSaver.RebuildWatchedSlots()
	PotsSaver.MarkIconsDirty()
	PotsSaver.MarkDirty(true, true)
	PotsSaver.UpdateButtonIcons()
	PotsSaver.UpdateButtonsEnabledStates(true)

	TextLogAddEntry("Chat", 0, towstring("Pots Saver v" .. tostring(PotsSaver.Settings.Version) .. " settings: /potssaver"))
	if PotsSaver.Settings.Enabled then
		TextLogAddEntry("Chat", 0, L"--- <icon57> Enabled")
	else
		TextLogAddEntry("Chat", 0, L"--- <icon58> Enabled")
	end
	if PotsSaver.Settings.ProgramAPMode then
		TextLogAddEntry("Chat", 0, L"--- <icon57> Programming Mode: Program AP")
	else
		TextLogAddEntry("Chat", 0, L"--- <icon57> Programming Mode: Program HP")
	end
	if PotsSaver.Settings.Symbols then
		TextLogAddEntry("Chat", 0, L"--- <icon57> Show Symbols")
	else
		TextLogAddEntry("Chat", 0, L"--- <icon58> Show Symbols")
	end
	if PotsSaver.Settings.ErrorMessages then
		TextLogAddEntry("Chat", 0, L"--- <icon57> Show Combat Error Messages")
	else
		TextLogAddEntry("Chat", 0, L"--- <icon58> Show Combat Error Messages")
	end
	if PotsSaver.Settings.UseSmartGCD then
		TextLogAddEntry("Chat", 0, L"--- <icon57> Smart GCD Optimization")
	else
		TextLogAddEntry("Chat", 0, L"--- <icon58> Smart GCD Optimization")
	end
	TextLogAddEntry("Chat", 0, towstring("--- Idle interval: " .. tostring(PotsSaver.Settings.IdleInterval) .. "s"))
	TextLogAddEntry("Chat", 0, towstring("--- Burst interval: " .. tostring(PotsSaver.Settings.BurstInterval) .. "s"))
	TextLogAddEntry("Chat", 0, towstring("--- GCD sleep: " .. tostring(PotsSaver.Settings.GCDSleepDuration) .. "s"))
	TextLogAddEntry("Chat", 0, towstring("--- GCD burst window: " .. tostring(PotsSaver.Settings.GCDBurstWindow) .. "s"))
end

function PotsSaver.UpdateButtonIcons()
	for slot = 1, MAX_BUTTONS do
		local _, actionId = GetHotbarData(slot)
		if PotsSaver.Settings.Enabled and PotsSaver.Settings.Symbols then
			PotsSaver.UpdateButtonIcon(slot, getRule(actionId))
		else
			PotsSaver.UpdateButtonIcon(slot, nil)
		end
	end
end

function PotsSaver.UpdateButtonIcon(slot, rule)
	local hbar, buttonid = ActionBars:BarAndButtonIdFromSlot(slot)
	if hbar and buttonid then
		local button = hbar.m_Buttons[buttonid]
		if button and button.m_Windows and button.m_Windows[7] then
			if rule == nil then
				button.m_Windows[7]:Show(false)
			else
				button.m_Windows[7]:Show(true)
				button.m_Windows[7]:SetFont("font_clear_small_bold", 10)
				button.m_Windows[7]:SetTextColor(255, 255, 0)
				button.m_Windows[7]:SetText(formatRuleShort(rule))
			end
		end
	end
end

function PotsSaver.BuildSlotStateSignature(actionId, isSlotEnabled, isTargetValid, isSlotBlocked, ruleBlocked, ruleMode, ruleThreshold)
	return tostring(actionId) .. "|" .. tostring(isSlotEnabled) .. "|" .. tostring(isTargetValid) .. "|" .. tostring(isSlotBlocked) .. "|" .. tostring(ruleBlocked) .. "|" .. tostring(ruleMode) .. "|" .. tostring(ruleThreshold)
end

function PotsSaver.UpdateButtonsEnabledStates(forceAll)
	if forceAll then
		for slot = 1, MAX_BUTTONS do
			PotsSaver.UpdateButtonEnabledState(slot, true)
		end
		return
	end

	for slot, _ in pairs(PotsSaver.WatchedSlots) do
		PotsSaver.UpdateButtonEnabledState(slot, false)
	end
end

function PotsSaver.UpdateButtonEnabledState(slot, force)
	local actionType, actionId, isSlotEnabled, isTargetValid, isSlotBlocked = GetHotbarData(slot)
	local rule = getRule(actionId)
	local ruleBlocked = false

	if PotsSaver.Settings.Enabled and rule ~= nil then
		if isRuleBlocked(rule, false) then
			isSlotEnabled = false
			ruleBlocked = true
		end
	elseif not force then
		return
	end

	local signature = PotsSaver.BuildSlotStateSignature(actionId, isSlotEnabled, isTargetValid, isSlotBlocked, ruleBlocked, rule and rule.Mode or "", rule and rule.Threshold or "")
	if not force and PotsSaver.LastSlotStates[slot] == signature then
		return
	end

	PotsSaver.LastSlotStates[slot] = signature
	orgActionBarsUpdateSlotEnabledState(slot, isSlotEnabled, isTargetValid, isSlotBlocked)
end

WindowGameAction = function(windowName, ...)
	local actionId = resolveActionIdFromWindow(windowName)
	if actionId and isConfiguredAction(actionId) and isAbilityBlocked(actionId, true) then
		return
	end
	if actionId then
		PotsSaver.NotifyPossibleGlobalCooldown(actionId)
	end
	return orgWindowGameAction(windowName, ...)
end

local function hasProgrammingModifier(flags)
	if flags == nil then return false end
	if flags == SystemData.ButtonFlags.CONTROL then return true end
	if type(BitAnd) == "function" then
		return BitAnd(flags, SystemData.ButtonFlags.CONTROL) ~= 0
	end
	return false
end

function ActionButton.OnLButtonDown(self, flags, x, y)
	if hasProgrammingModifier(flags) and self and self.m_ActionId ~= 0 then
		local updatedRule = nextRule(getRule(self.m_ActionId))
		storeRule(self.m_ActionId, updatedRule)
		PotsSaver.RebuildWatchedSlots()
		PotsSaver.MarkIconsDirty()
		PotsSaver.MarkDirty(true, true)
		chatInfo(self.m_ActionId, updatedRule)
		return
	end

	if self and self.m_ActionId ~= 0 and isConfiguredAction(self.m_ActionId) and isAbilityBlocked(self.m_ActionId, true) then
		return
	end

	if self and self.m_ActionId ~= 0 then
		PotsSaver.NotifyPossibleGlobalCooldown(self.m_ActionId)
	end

	return orgActionButtonOnLButtonDown(self, flags, x, y)
end

if type(orgActionButtonOnLButtonUp) == "function" then
	function ActionButton.OnLButtonUp(self, flags, x, y)
		if self and self.m_ActionId ~= 0 and isConfiguredAction(self.m_ActionId) and isAbilityBlocked(self.m_ActionId, false) then
			return
		end
		return orgActionButtonOnLButtonUp(self, flags, x, y)
	end
end

function ActionBars.UpdateSlotEnabledState(slot, isSlotEnabled, isTargetValid, isSlotBlocked)
	local hbar, buttonid = ActionBars:BarAndButtonIdFromSlot(slot)
	if hbar and buttonid then
		local button = hbar.m_Buttons[buttonid]
		if button and PotsSaver.Settings and PotsSaver.Settings.Enabled then
			local rule = getRule(button.m_ActionId)
			if rule ~= nil and isRuleBlocked(rule, false) then
				isSlotEnabled = false
			end
		end
	end
	orgActionBarsUpdateSlotEnabledState(slot, isSlotEnabled, isTargetValid, isSlotBlocked)
end

function ActionButton.UpdateInventory(self)
	if not PotsSaver.Settings or not PotsSaver.Settings.Enabled or getRule(self.m_ActionId) == nil then
		orgActionButtonUpdateInventory(self)
	end
end
