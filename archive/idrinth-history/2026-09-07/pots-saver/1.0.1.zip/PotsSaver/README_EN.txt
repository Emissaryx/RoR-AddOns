Pots Saver v1.0.1

What it does
Pots Saver blocks configured abilities using one of two rule types:
- AP rule: blocks the ability while your current AP is above the stored cap.
- HP rule: blocks the ability while your current HP percentage is above the stored threshold.

How to configure abilities
1. Open the settings with /potssaver.
2. Go to the Programming tab.
3. Click Program AP or Program HP to choose what CTRL + left click will write.
4. CTRL + left click a hotbar slot to cycle the rule for that ability.

Cycles
- AP mode: clear -> 0 -> 10 -> 20 -> ... -> 200 -> clear
- HP mode: clear -> 0% -> 10% -> 20% -> ... -> 100% -> clear

Button text
- AP30 = max 30 AP
- HP30% = usable only at 30% HP or lower

Config macro
- The addon can create a macro that opens the settings window.
- Macro text: /script PotsSaver.OpenConfig()
- The addon also tries to create or refresh that macro when it loads.

Commands
- /potssaver
- /appotssaver
- /hppotssaver

Notes
- This addon can import legacy rules from APPotsSaver and HPPotsSaver.
- Smart GCD optimization and watched-slot updates are included.
- Author: Kpihuss
