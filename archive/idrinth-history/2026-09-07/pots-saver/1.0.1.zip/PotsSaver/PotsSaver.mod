<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
	<UiMod name="PotsSaver" version="1.0.1" date="05/04/2026" >
		<Author name="Kpihuss" email="" />
		<Description text="Pots Saver. Unified AP and HP threshold addon based on GCDSaver, with watched-slot updates, smart GCD checks, and a config macro launcher." />
		<VersionSettings gameVersion="1.9.9" windowsVersion="1.0" savedVariablesVersion="1.0" />

		<Dependencies>
			<Dependency name="EA_ActionBars" />
			<Dependency name="LibSlash" />
		</Dependencies>
			
		<Files>
			<File name="libs\LibStub.lua" />
			<File name="libs\LibGUI.lua" />
			<File name="libs\LibConfig.lua" />		
			<File name="PotsSaver.lua" />			
			<File name="PotsSaver_Config.lua" />					
		</Files>

		<SavedVariables>
			<SavedVariable name="PotsSaver.Settings" />
			<SavedVariable name="APPotsSaver.Settings" />
			<SavedVariable name="HPPotsSaver.Settings" />
		</SavedVariables>

		<OnInitialize>
			<CallFunction name="PotsSaver.Initialize" />
		</OnInitialize>

		<OnUpdate>
			<CallFunction name="PotsSaver.OnUpdate" />
		</OnUpdate>

		<OnShutdown>
			<CallFunction name="PotsSaver.OnShutdown" />
		</OnShutdown>
	</UiMod>
</ModuleFile>
