RoR_SoR= {}
local version = "0.94"

function RoR_SoR.OnInitialize()
if not RoR_SoR.ShowTier then RoR_SoR.ShowTier = 1 end
--RoR_SoR.ShowTier = 1

CreateWindow("RoR_SoR_Window", true)
CreateWindow("RoR_SoR_Button", true)

RegisterEventHandler( SystemData.Events.ENTER_WORLD, "RoR_SoR.Register" )
RegisterEventHandler( SystemData.Events.INTERFACE_RELOADED, "RoR_SoR.Register" )	

LayoutEditor.RegisterWindow( "RoR_SoR_Window", L"RoR_SoR", L"RoR_SoR", true, true, true, nil )
LayoutEditor.RegisterWindow( "RoR_SoR_Button", L"RoR_SoR_Button", L"RoR_SoR_Button", false, false, false, nil )


ButtonSetText( "RoR_SoR_WindowT1Tab",  L"T1"	)
ButtonSetText( "RoR_SoR_WindowT2Tab",  L"T2"	)
ButtonSetText( "RoR_SoR_WindowT3Tab",  L"T3"	)
ButtonSetText( "RoR_SoR_WindowT4Tab",  L"T4"	)

--ButtonSetPressedFlag( "RoR_SoR_WindowT1Tab",true)



RoR_SoR.HideChannel(65)

TextLogAddEntry("Chat", 0, L"<icon00057> RoR_SoR "..towstring(version)..L" Loaded.")


end


function RoR_SoR.HideChannel(channelId)
	for _, wndGroup in ipairs(EA_ChatWindowGroups) do 
		if wndGroup.used == true then
			for tabId, tab in ipairs(wndGroup.Tabs) do
				local tabName = EA_ChatTabManager.GetTabName( tab.tabManagerId )
		
				if tabName then
					if tab.tabText ~= L"RoR_SoR" then
						LogDisplaySetFilterState(tabName.."TextLog", "Chat", channelId, false)
					else
						LogDisplaySetFilterState(tabName.."TextLog", "Chat", channelId, true)
						LogDisplaySetFilterColor(tabName.."TextLog", "Chat", channelId, 168, 187, 160 )
					end
				end
				
			end
			
		end
		
	end	
end


function RoR_SoR.OnTabLBU()
local tabNumber	= WindowGetId (SystemData.ActiveWindow.name)
if (tabNumber == 1) then 
ButtonSetPressedFlag( "RoR_SoR_WindowT1Tab",true)
ButtonSetPressedFlag( "RoR_SoR_WindowT2Tab",false)
ButtonSetPressedFlag( "RoR_SoR_WindowT3Tab",false)
ButtonSetPressedFlag( "RoR_SoR_WindowT4Tab",false)
RoR_SoR.ShowTier = 1
elseif (tabNumber == 2) then 
ButtonSetPressedFlag( "RoR_SoR_WindowT1Tab",false)
ButtonSetPressedFlag( "RoR_SoR_WindowT2Tab",true)
ButtonSetPressedFlag( "RoR_SoR_WindowT3Tab",false)
ButtonSetPressedFlag( "RoR_SoR_WindowT4Tab",false)
RoR_SoR.ShowTier = 2
elseif (tabNumber == 3) then 
ButtonSetPressedFlag( "RoR_SoR_WindowT1Tab",false)
ButtonSetPressedFlag( "RoR_SoR_WindowT2Tab",false)
ButtonSetPressedFlag( "RoR_SoR_WindowT3Tab",true)
ButtonSetPressedFlag( "RoR_SoR_WindowT4Tab",false)
RoR_SoR.ShowTier = 3
elseif (tabNumber == 4) then 
ButtonSetPressedFlag( "RoR_SoR_WindowT1Tab",false)
ButtonSetPressedFlag( "RoR_SoR_WindowT2Tab",false)
ButtonSetPressedFlag( "RoR_SoR_WindowT3Tab",false)
ButtonSetPressedFlag( "RoR_SoR_WindowT4Tab",true)
RoR_SoR.ShowTier = 4
end

end

function RoR_SoR.Update(timeElapsed)
if WindowGetShowing("RoR_SoR_Window") == true then

local WinSize = WindowGetScale("RoR_SoR_Window")
WindowSetScale("RoR_SoR_T1Window",WinSize)
WindowSetScale("RoR_SoR_T2Window",WinSize)
WindowSetScale("RoR_SoR_T3Window",WinSize)
WindowSetScale("RoR_SoR_T4Window",WinSize)

if RoR_SoR.ShowTier == 1 then
ButtonSetPressedFlag( "RoR_SoR_WindowT1Tab",true)
WindowSetShowing("RoR_SoR_T1Window",true)
WindowSetShowing("RoR_SoR_T3Window",false)
WindowSetShowing("RoR_SoR_T2Window",false)
WindowSetShowing("RoR_SoR_T4Window",false)
elseif RoR_SoR.ShowTier == 2 then
ButtonSetPressedFlag( "RoR_SoR_WindowT2Tab",true)
WindowSetShowing("RoR_SoR_T1Window",false)
WindowSetShowing("RoR_SoR_T2Window",true)
WindowSetShowing("RoR_SoR_T3Window",false)
WindowSetShowing("RoR_SoR_T4Window",false)
elseif RoR_SoR.ShowTier == 3 then
ButtonSetPressedFlag( "RoR_SoR_WindowT3Tab",true)
WindowSetShowing("RoR_SoR_T1Window",false)
WindowSetShowing("RoR_SoR_T3Window",true)
WindowSetShowing("RoR_SoR_T2Window",false)
WindowSetShowing("RoR_SoR_T4Window",false)
elseif RoR_SoR.ShowTier == 4 then
ButtonSetPressedFlag( "RoR_SoR_WindowT4Tab",true)
WindowSetShowing("RoR_SoR_T1Window",false)
WindowSetShowing("RoR_SoR_T3Window",false)
WindowSetShowing("RoR_SoR_T2Window",false)
WindowSetShowing("RoR_SoR_T4Window",true)
end
else
WindowSetShowing("RoR_SoR_T1Window",false)
WindowSetShowing("RoR_SoR_T3Window",false)
WindowSetShowing("RoR_SoR_T2Window",false)
WindowSetShowing("RoR_SoR_T4Window",false)
end

if RoR_SoR.Register == true then
if RoR_SoR.RegisterDelay < 20 then
RoR_SoR.RegisterDelay = RoR_SoR.RegisterDelay + timeElapsed
end
if RoR_SoR.RegisterDelay > 20 then
RoR_SoR.Enable()
RoR_SoR.Register = false

end
end


end

function RoR_SoR.Enable()
SendChatText(L".sorenable", L"")
RoR_SoR.Register = false
d("SoR Registered")
end



function RoR_SoR.GetTooltipIcon(BO_OWNER,BO_STATE)
local Owner = tonumber(BO_OWNER)
local State = tonumber(BO_STATE)

if State == 0 then
	if Owner == 0 then return L"<icon29982> Neutral" end --neutral
	if Owner == 1 then return L"<icon29990> Order" end
	if Owner == 2 then return L"<icon29985> Destro" end
elseif State == 4 then
	if Owner == 0 then return L"<icon29984> Capping" end
	if Owner == 1 then return L"<icon29992> Destro Capping" end
	if Owner == 2 then return L"<icon29987> Order Capping" end
elseif State == 8 then
	if Owner == 0 then return L"<icon29983> Unlocking" end
	if Owner == 1 then return L"<icon29991> Order Locked" end
	if Owner == 2 then return L"<icon29986> Destro Locked" end
elseif State == 9 then
	if Owner == 0 then return L"<icon29983> Locked" end
	if Owner == 1 then return L"<icon29991> Order Locked" end
	if Owner == 2 then return L"<icon29986> Destro Locked" end	
elseif State == 10 then
	if Owner == 0 then return L"<icon29982> Neutral" end--neutral
	if Owner == 1 then return L"<icon29991> Order Locked" end
	if Owner == 2 then return L"<icon29986> Destro Locked" end		
elseif State == 16 then
	if Owner == 0 then return "FlagNeutral-Glowing" end
	if Owner == 1 then return L"<icon29993> Order securing" end -- securing / holding
	if Owner == 2 then return L"<icon29988> Destro securing" end
else
	if Owner == 0 then return L"<icon29982> Neutral" end--neutral
	if Owner == 1 then return L"<icon29990> Order" end
	if Owner == 2 then return L"<icon29985> Destro" end
end

end

function RoR_SoR.GetKeepIcon(KEEP_OWNER,KEEP_STATE)
local Owner = tonumber(KEEP_OWNER)
local State = tonumber(KEEP_STATE)

if State == 1 then
	if Owner == 0 then return L"<icon29995> Neutral Keep" end
	if Owner == 1 then return L"<icon29998> Order Keep" end
	if Owner == 2 then return L"<icon29996> Destro Keep" end
elseif State == 2 then
	if Owner == 0 then return "FlagNeutral-Burning" end
	if Owner == 1 then return L"<icon29999> Under Attack" end
	if Owner == 2 then return L"<icon29997> Under Attack" end
elseif State == 3 then
	if Owner == 0 then return "FlagNeutral-Burning" end
	if Owner == 1 then return L"<icon29999> Under Attack" end
	if Owner == 2 then return L"<icon29997> Under Attack" end	
elseif State == 4 then
	if Owner == 0 then return "BombNeutral" end
	if Owner == 1 then return L"<icon29999> Under Attack" end
	if Owner == 2 then return L"<icon29997> Under Attack" end
elseif State == 5 then
	if Owner == 0 then return "FlagNeutral-Burning" end
	if Owner == 1 then return L"<icon29998> Order Keep" end
	if Owner == 2 then return L"<icon29996> Destro Keep" end
elseif State == 6 then
	if Owner == 0 then return "FlagNeutral-Burning" end
	if Owner == 1 then return L"<icon29998> Order Keep" end
	if Owner == 2 then return L"<icon29996> Destro Keep" end
else
	if Owner == 0 then return L"<icon29995> Neutral Keep" end
	if Owner == 1 then return L"<icon29998> Order Keep" end
	if Owner == 2 then return L"<icon29996> Destro Keep" end
end

end

function RoR_SoR.GetKeepRank(KeepRank)
local Rank = tonumber(KeepRank)

if Rank == 1 then return L"<icon43>"
elseif Rank == 2 then return L"<icon43><icon43>"
elseif Rank == 3 then return L"<icon43><icon43><icon43>"
elseif Rank == 4 then return L"<icon43><icon43><icon43><icon43>"
elseif Rank == 5 then return L"<icon43><icon43><icon43><icon43><icon43>"
else return L""

end
end

function RoR_SoR.OnMouseOverStart()


end


function RoR_SoR.Toggle()
if WindowGetShowing("RoR_SoR_Window") == false then
WindowSetShowing("RoR_SoR_Window", true)
else
WindowSetShowing("RoR_SoR_Window", false)
end

end

function RoR_SoR.Register()
RoR_SoR.RegisterDelay = 0
RoR_SoR.Register = true
end

