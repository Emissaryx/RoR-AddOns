RoR_SoR= {}
local version = "103"

function RoR_SoR.OnInitialize()
if not RoR_SoR.ShowTier then RoR_SoR.ShowTier = 1 end


RoR_SoR.Registerd = true
RoR_SoR.RegisterDelay = 0
--RoR_SoR.ShowTier = 1
RoR_SoR.UpdateVersion = 0
CreateWindow("RoR_SoR_Window", true)
CreateWindow("RoR_SoR_Button", true)

RegisterEventHandler( SystemData.Events.ENTER_WORLD, "RoR_SoR.Register" )
RegisterEventHandler( SystemData.Events.INTERFACE_RELOADED, "RoR_SoR.Register" )	
RegisterEventHandler(TextLogGetUpdateEventId("System"), "RoR_SoR.OnChatLogUpdated")

LayoutEditor.RegisterWindow( "RoR_SoR_Window", L"RoR_SoR", L"RoR_SoR", true, true, true, nil )
LayoutEditor.RegisterWindow( "RoR_SoR_Button", L"RoR_SoR_Button", L"RoR_SoR_Button", false, false, false, nil )


ButtonSetText( "RoR_SoR_WindowT1Tab",  L"T1"	)
ButtonSetText( "RoR_SoR_WindowT2Tab",  L"T2"	)
ButtonSetText( "RoR_SoR_WindowT3Tab",  L"T3"	)
ButtonSetText( "RoR_SoR_WindowT4Tab",  L"T4"	)

--ButtonSetPressedFlag( "RoR_SoR_WindowT1Tab",true)

RoR_SoR.TextLock = towstring(GetStringFromTable("MapSystem", StringTables.MapSystem.TEXT_CAMPAIGN_PAIRING_LOCKED ) )
RoR_SoR.TextZoneLocked =	towstring(GetStringFromTable("Hardcoded", 1268))
RoR_SoR.TextTaken = towstring(GetStringFromTable("Hardcoded", 274))

RoR_SoR.TextNeutral = towstring(GetStringFromTable("Default", StringTables.Default.LABEL_UNCONTROLLED ) )
RoR_SoR.TextOrder = towstring(GetStringFromTable("Default", StringTables.Default.LABEL_UNCONTROLLED ) )
RoR_SoR.TextDestro = towstring(GetStringFromTable("Default", StringTables.Default.LABEL_ORDER_CONTROLLED ) )


RoR_SoR.HideChannel(65)

TextLogAddEntry("Chat", 0, L"<icon00057> RoR_SoR "..towstring(version)..L" Loaded.")


local siegeWindow = "SiegeWeaponGeneralFireWindowChatLogDisplay"
LogDisplaySetFilterState(siegeWindow, "Chat", 65, false)

--for k in pairs(EA_ChatWindowGroups[1].Tabs[1].Filters) do 
--LogDisplaySetFilterState(siegeWindow, "Chat", tonumber(k), tostring(EA_ChatWindowGroups[1].Tabs[1].Filters[k]))
--end


WindowSetTintColor( "RoR_SoR_ButtonBtn", 50,50,50 )
end

function RoR_SoR.OnChatLogUpdated(updateType, filterType) --premade chat checker for future chat updates
	if( updateType == SystemData.TextLogUpdate.ADDED ) then 

--					local _, filterId, text = TextLogGetEntry( "System", TextLogGetNumEntries("System") - 1 ) 
			
--			if text:find(L"State of the Realm") then RoR_SoR_T1.CheckVer(text) end
			
			
	
			local _, filterId, text = TextLogGetEntry( "System", TextLogGetNumEntries("System") - 1 ) 
				if text:find(L"State of the Realm") then 
				RoR_SoR.CheckVer(text)
			--	RoR_SoR_T1.ZoneUpdate()
--			RoR_SoR_T1.CheckVer(text)
			end

			
	end
end




function RoR_SoR.CheckVer(text)
d(text)
local num1,num2,num3 = text:match(L"[^%.]+: ([0-9]+).([0-9]+).([0-9]+)")
VersionNumber = tonumber(num1)..tonumber(num2)..tonumber(num3)

if tonumber(VersionNumber) > tonumber(version) and RoR_SoR.UpdateVersion == 0 then 
SystemData.AlertText.VecType = {4}
SystemData.AlertText.VecText = {L"Notice: Your State of Realm is Outdated, Please Update!"}
AlertTextWindow.AddAlert()
TextLogAddEntry("Chat", 0, L"Notice: Your State of Realm is Outdated, Please Update! (your ver: "..towstring(version)..L", Newest ver: "..towstring(VersionNumber)..L")")

RoR_SoR.UpdateVersion = 1
end

end




function RoR_SoR.SiegeChat()

local siegeWindow = "SiegeWeaponGeneralFireWindowChatLogDisplay"
LogDisplaySetFilterState(siegeWindow, "Chat", 65, false)

for k in pairs(EA_ChatWindowGroups[1].Tabs[1].Filters) do 
LogDisplaySetFilterState(siegeWindow, "Chat", tonumber(k), tostring(EA_ChatWindowGroups[1].Tabs[1].Filters[k]))
end

	for _, wndGroup in ipairs(EA_ChatWindowGroups) do 
		if wndGroup.used == true then
			for tabId, tab in ipairs(wndGroup.Tabs) do
				local tabName = EA_ChatTabManager.GetTabName( tab.tabManagerId )
		
				if tabName then
					if tab.tabText == L"Siege" then
					

							for k in pairs(tab.Filters) do 
							LogDisplaySetFilterState("SiegeWeaponGeneralFireWindowChatLogDisplay", "Chat", tonumber(k), tostring(tab.Filters[k]))
							LogDisplaySetFilterState("SiegeWeaponGeneralFireWindowChatLogDisplay", "Combat", tonumber(k), tostring(tab.Filters[k]))
							LogDisplaySetFilterState("SiegeWeaponGeneralFireWindowChatLogDisplay", "System", tonumber(k), tostring(tab.Filters[k]))
							--d(L"setting "..towstring(k)..L" to "..towstring(tostring(tab.Filters[k])))
							end

							LogDisplaySetFilterState("SiegeWeaponGeneralFireWindowChatLogDisplay", "Chat", 65, false)
					
					
					end
				end
				
			end
			
		end
		
	end	


end



function RoR_SoR.HideChannel(channelId)
	for _, wndGroup in ipairs(EA_ChatWindowGroups) do 
		if wndGroup.used == true then
			for tabId, tab in ipairs(wndGroup.Tabs) do
				local tabName = EA_ChatTabManager.GetTabName( tab.tabManagerId )
		
				if tabName then
					if tab.tabText ~= L"Debug" then
						LogDisplaySetFilterState(tabName.."TextLog", "Chat", channelId, false)
					else
						LogDisplaySetFilterState(tabName.."TextLog", "Chat", channelId, true)
						LogDisplaySetFilterColor(tabName.."TextLog", "Chat", channelId, 168, 187, 160 )
					end
				end
				
			end
			
		end
		
	end	
end


function RoR_SoR.OnTabLBU()
local tabNumber	= WindowGetId (SystemData.ActiveWindow.name)
if (tabNumber == 1) then 
ButtonSetPressedFlag( "RoR_SoR_WindowT1Tab",true)
ButtonSetPressedFlag( "RoR_SoR_WindowT2Tab",false)
ButtonSetPressedFlag( "RoR_SoR_WindowT3Tab",false)
ButtonSetPressedFlag( "RoR_SoR_WindowT4Tab",false)
RoR_SoR.ShowTier = 1
elseif (tabNumber == 2) then 
ButtonSetPressedFlag( "RoR_SoR_WindowT1Tab",false)
ButtonSetPressedFlag( "RoR_SoR_WindowT2Tab",true)
ButtonSetPressedFlag( "RoR_SoR_WindowT3Tab",false)
ButtonSetPressedFlag( "RoR_SoR_WindowT4Tab",false)
RoR_SoR.ShowTier = 2
elseif (tabNumber == 3) then 
ButtonSetPressedFlag( "RoR_SoR_WindowT1Tab",false)
ButtonSetPressedFlag( "RoR_SoR_WindowT2Tab",false)
ButtonSetPressedFlag( "RoR_SoR_WindowT3Tab",true)
ButtonSetPressedFlag( "RoR_SoR_WindowT4Tab",false)
RoR_SoR.ShowTier = 3
elseif (tabNumber == 4) then 
ButtonSetPressedFlag( "RoR_SoR_WindowT1Tab",false)
ButtonSetPressedFlag( "RoR_SoR_WindowT2Tab",false)
ButtonSetPressedFlag( "RoR_SoR_WindowT3Tab",false)
ButtonSetPressedFlag( "RoR_SoR_WindowT4Tab",true)
RoR_SoR.ShowTier = 4
end

end

function RoR_SoR.Update(timeElapsed)
--[[
	for _, wndGroup in ipairs(EA_ChatWindowGroups) do 
		if wndGroup.used == true then
			for tabId, tab in ipairs(wndGroup.Tabs) do
				local tabName = EA_ChatTabManager.GetTabName( tab.tabManagerId )
		
				if tabName then
					if GameData.Player.isInSiege == true then WindowSetShowing(tabName,false) else WindowSetShowing(tabName,true) end
				end
				
			end
			
		end
		
	end	
--]]

if WindowGetShowing("RoR_SoR_Window") == true then

local WinSize = WindowGetScale("RoR_SoR_Window")
WindowSetScale("RoR_SoR_T1Window",WinSize)
WindowSetScale("RoR_SoR_T2Window",WinSize)
WindowSetScale("RoR_SoR_T3Window",WinSize)
WindowSetScale("RoR_SoR_T4Window",WinSize)

if RoR_SoR.ShowTier == 1 then
ButtonSetPressedFlag( "RoR_SoR_WindowT1Tab",true)
WindowSetShowing("RoR_SoR_T1Window",true)
WindowSetShowing("RoR_SoR_T3Window",false)
WindowSetShowing("RoR_SoR_T2Window",false)
WindowSetShowing("RoR_SoR_T4Window",false)
elseif RoR_SoR.ShowTier == 2 then
ButtonSetPressedFlag( "RoR_SoR_WindowT2Tab",true)
WindowSetShowing("RoR_SoR_T1Window",false)
WindowSetShowing("RoR_SoR_T2Window",true)
WindowSetShowing("RoR_SoR_T3Window",false)
WindowSetShowing("RoR_SoR_T4Window",false)
elseif RoR_SoR.ShowTier == 3 then
ButtonSetPressedFlag( "RoR_SoR_WindowT3Tab",true)
WindowSetShowing("RoR_SoR_T1Window",false)
WindowSetShowing("RoR_SoR_T3Window",true)
WindowSetShowing("RoR_SoR_T2Window",false)
WindowSetShowing("RoR_SoR_T4Window",false)
elseif RoR_SoR.ShowTier == 4 then
ButtonSetPressedFlag( "RoR_SoR_WindowT4Tab",true)
WindowSetShowing("RoR_SoR_T1Window",false)
WindowSetShowing("RoR_SoR_T3Window",false)
WindowSetShowing("RoR_SoR_T2Window",false)
WindowSetShowing("RoR_SoR_T4Window",true)
end
else
WindowSetShowing("RoR_SoR_T1Window",false)
WindowSetShowing("RoR_SoR_T3Window",false)
WindowSetShowing("RoR_SoR_T2Window",false)
WindowSetShowing("RoR_SoR_T4Window",false)
end

if RoR_SoR.Registerd == true then
if RoR_SoR.RegisterDelay < 20 then
RoR_SoR.RegisterDelay = RoR_SoR.RegisterDelay + timeElapsed
end
if RoR_SoR.RegisterDelay > 20 then
RoR_SoR.Enable()
RoR_SoR.Registerd = false

end
end


end

function RoR_SoR.Enable()
SendChatText(L".sorenable", L"")
RoR_SoR.Register = false
d("SoR Registered")
WindowSetTintColor( "RoR_SoR_ButtonBtn", 255,255,255 )
end



function RoR_SoR.GetTooltipIcon(BO_OWNER,BO_STATE)
local Owner = tonumber(BO_OWNER)
local State = tonumber(BO_STATE)

if State == 0 then
	if Owner == 0 then return L"<icon29982> "..towstring(RoR_SoR.TextNeutral) end --neutral
	if Owner == 1 then return L"<icon29990> "..towstring(RoR_SoR.TextDestro) end
	if Owner == 2 then return L"<icon29985> "..towstring(RoR_SoR.TextOrder) end
elseif State == 2 then
	if Owner == 0 then return L"<icon29982> Abandoned" end
	if Owner == 1 then return L"<icon29990> Order Abandoned" end
	if Owner == 2 then return L"<icon29985> Destro Abandoned" end		
elseif State == 4 then
	if Owner == 0 then return L"<icon29984> Capping" end
	if Owner == 1 then return L"<icon29992> Destro Capping" end
	if Owner == 2 then return L"<icon29987> Order Capping" end
elseif State == 8 then
	if Owner == 0 then return L"<icon29983> Unlocking" end
	if Owner == 1 then return L"<icon29991> Order "..towstring(RoR_SoR.TextLock) end
	if Owner == 2 then return L"<icon29986> Destro "..towstring(RoR_SoR.TextLock) end
elseif State == 9 then
	if Owner == 0 then return L"<icon29983> "..towstring(RoR_SoR.TextLock) end
	if Owner == 1 then return L"<icon29991> Order "..towstring(RoR_SoR.TextLock) end
	if Owner == 2 then return L"<icon29986> Destro "..towstring(RoR_SoR.TextLock) end	
elseif State == 10 then
	if Owner == 0 then return L"<icon29982> Neutral "..towstring(RoR_SoR.TextLock) end--neutral
	if Owner == 1 then return L"<icon29991> Order "..towstring(RoR_SoR.TextLock) end
	if Owner == 2 then return L"<icon29986> Destro "..towstring(RoR_SoR.TextLock) end		
elseif State == 16 then
	if Owner == 0 then return L"<icon29982> Securing" end
	if Owner == 1 then return L"<icon29993> Order securing" end -- securing / holding
	if Owner == 2 then return L"<icon29988> Destro securing" end
else
	if Owner == 0 then return L"<icon29982> Neutral" end--neutral
	if Owner == 1 then return L"<icon29990> Order" end
	if Owner == 2 then return L"<icon29985> Destro" end
end

end

function RoR_SoR.GetKeepIcon(KEEP_OWNER,KEEP_STATE)
local Owner = tonumber(KEEP_OWNER)
local State = tonumber(KEEP_STATE)

if State == 1 then
	if Owner == 0 then return L"<icon29995> Neutral Keep" end
	if Owner == 1 then return L"<icon29998> Order Keep" end
	if Owner == 2 then return L"<icon29996> Destro Keep" end
elseif State == 2 then
	if Owner == 0 then return L"<icon29995> Under Attack" end
	if Owner == 1 then return L"<icon29999> Under Attack" end
	if Owner == 2 then return L"<icon29997> Under Attack" end
elseif State == 3 then
	if Owner == 0 then return L"<icon29995> Under Attack" end
	if Owner == 1 then return L"<icon29999> Under Attack" end
	if Owner == 2 then return L"<icon29997> Under Attack" end	
elseif State == 4 then
	if Owner == 0 then return L"<icon29995> Under Attack" end
	if Owner == 1 then return L"<icon29999> Under Attack" end
	if Owner == 2 then return L"<icon29997> Under Attack" end
elseif State == 5 then
	if Owner == 0 then return L"<icon29995> Neutral Keep" end
	if Owner == 1 then return L"<icon29998> Order Keep" end
	if Owner == 2 then return L"<icon29996> Destro Keep" end
elseif State == 6 then
	if Owner == 0 then return L"<icon29995> Neutral Keep" end
	if Owner == 1 then return L"<icon29998> Order Keep" end
	if Owner == 2 then return L"<icon29996> Destro Keep" end
else
	if Owner == 0 then return L"<icon29995> Neutral Keep" end
	if Owner == 1 then return L"<icon29998> Order Keep" end
	if Owner == 2 then return L"<icon29996> Destro Keep" end
end

end

function RoR_SoR.GetKeepRank(KeepRank)
local Rank = tonumber(KeepRank)

if Rank == 1 then return L"1 <icon43>"
elseif Rank == 2 then return L"2 <icon43><icon43>"
elseif Rank == 3 then return L"3 <icon43><icon43><icon43>"
elseif Rank == 4 then return L"4 <icon43><icon43><icon43><icon43>"
elseif Rank == 5 then return L"5 <icon43><icon43><icon43><icon43><icon43>"
else return L""

end
end

function RoR_SoR.OnMouseOverStart()


		Tooltips.CreateTextOnlyTooltip(SystemData.MouseOverWindow.name,nil)
		Tooltips.SetTooltipText( 1, 1, L"State Of Realm")
		Tooltips.SetTooltipColorDef( 1, 1, Tooltips.MAP_DESC_TEXT_COLOR )
		Tooltips.SetTooltipText( 1, 3, towstring(version))	
		Tooltips.SetTooltipText( 2, 1, L"LMB: Toggle Show/Hide<br>RMB: Force Update")
		Tooltips.Finalize()    
		Tooltips.AnchorTooltip( Tooltips.ANCHOR_WINDOW_TOP )


end


function RoR_SoR.Toggle()
if WindowGetShowing("RoR_SoR_Window") == false then
WindowSetShowing("RoR_SoR_Window", true)
else
WindowSetShowing("RoR_SoR_Window", false)
end

end

function RoR_SoR.Register()
RoR_SoR.RegisterDelay = 0
RoR_SoR.Registerd = true
end

