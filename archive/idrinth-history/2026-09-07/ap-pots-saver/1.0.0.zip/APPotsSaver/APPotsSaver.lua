-- Local data
local VERSION = 1.02
local TIME_DELAY = 0.1
local timeLeft = TIME_DELAY
local MAX_BUTTONS = 60
local MAX_AP = 200
local AP_STEP = 10
local eventsRegistered = false
local loadingEnd = false

-- Localized functions
local tostring = tostring
local towstring = towstring
local GetAbilityData = GetAbilityData
local GetHotbarData = GetHotbarData
local BroadcastEvent = BroadcastEvent
local TextLogAddEntry = TextLogAddEntry
local RegisterEventHandler = RegisterEventHandler
local UnregisterEventHandler = UnregisterEventHandler

local function alertText(text)
	if SettingsWindowTabInterface.SavedMessageSettings.combat then
		SystemData.AlertText.VecType = {SystemData.AlertText.Types.COMBAT}
		SystemData.AlertText.VecText = {towstring(text)}
		BroadcastEvent(SystemData.Events.SHOW_ALERT_TEXT)
	end
end

local function getCurrentAP()
	if GameData and GameData.Player and GameData.Player.actionPoints then
		local ap = GameData.Player.actionPoints.current
		if type(ap) == "number" then
			return ap
		end
	end
	return 0
end

local function chatInfo(actionId, threshold)
	local ability = GetAbilityData(actionId)
	if not ability then return end
	local name = tostring(ability.name)
	local icon = "<icon" .. tostring(ability.iconNum) .. ">"
	if threshold == nil then
		TextLogAddEntry("Chat", 0, towstring("APPotsSaver: Clearing AP cap for " .. icon .. " " .. name))
	else
		TextLogAddEntry("Chat", 0, towstring("APPotsSaver: Setting max AP " .. threshold .. " for " .. icon .. " " .. name))
	end
end

local function nextThreshold(current)
	if current == nil then
		return 0
	elseif current >= MAX_AP then
		return nil
	else
		return current + AP_STEP
	end
end

local function isAbilityBlocked(actionId)
	if not APPotsSaver.Settings.Enabled then
		return false
	end

	local threshold = APPotsSaver.Settings.Abilities[actionId]
	if threshold == nil then
		return false
	end

	local currentAP = getCurrentAP()
	if currentAP > threshold then
		if APPotsSaver.Settings.ErrorMessages then
			alertText("Too much AP: " .. currentAP .. " / max " .. threshold)
		end
		return true
	end

	return false
end

-- Global execution wrapper
local orgWindowGameAction = WindowGameAction

local function blockedWindowGameAction(...)
	return
end

local function tryGetWindowGameActionData(windowName)
	if type(WindowGetGameActionData) ~= "function" then
		return nil
	end

	local ok, a, b, c, d = pcall(WindowGetGameActionData, windowName)
	if not ok then
		return nil
	end

	if type(a) == "table" then
		return a
	end

	return { a, b, c, d }
end

local function resolveActionIdFromWindow(windowName)
	if not windowName then
		return nil
	end

	local data = tryGetWindowGameActionData(windowName)
	if not data then
		return nil
	end

	if data.actionId then return data.actionId end
	if data.ActionId then return data.ActionId end
	if data.abilityId then return data.abilityId end
	if data.AbilityId then return data.AbilityId end
	if data.id then return data.id end
	if data.Id then return data.Id end

	local slot = data.hotbarSlot or data.HotbarSlot or data.slot or data.Slot or data[1]
	local maybeActionId = data[2]
	if type(maybeActionId) == "number" and maybeActionId ~= 0 then
		return maybeActionId
	end
	if type(slot) == "number" and slot >= 1 and slot <= MAX_BUTTONS then
		local _, actionId = GetHotbarData(slot)
		if type(actionId) == "number" and actionId ~= 0 then
			return actionId
		end
	end

	return nil
end

WindowGameAction = function(windowName, ...)
	local actionId = resolveActionIdFromWindow(windowName)
	if actionId and APPotsSaver and APPotsSaver.Settings and APPotsSaver.Settings.Abilities and APPotsSaver.Settings.Abilities[actionId] ~= nil and isAbilityBlocked(actionId) then
		return
	end
	return orgWindowGameAction(windowName, ...)
end

APPotsSaver = APPotsSaver or {}
APPotsSaver.EnabledStatesNeedUpdate = true
APPotsSaver.ButtonIconsNeedUpdate = true

APPotsSaver.DefaultSettings = {
	Version = VERSION,
	Enabled = true,
	Symbols = true,
	ErrorMessages = true,
	Abilities = {},
}

function APPotsSaver.Initialize()
	if not APPotsSaver.Settings then
		APPotsSaver.Settings = APPotsSaver.DefaultSettings
	else
		APPotsSaver.Settings.Version = APPotsSaver.DefaultSettings.Version
		if APPotsSaver.Settings.Enabled == nil then APPotsSaver.Settings.Enabled = APPotsSaver.DefaultSettings.Enabled end
		if APPotsSaver.Settings.Symbols == nil then APPotsSaver.Settings.Symbols = APPotsSaver.DefaultSettings.Symbols end
		if APPotsSaver.Settings.ErrorMessages == nil then APPotsSaver.Settings.ErrorMessages = APPotsSaver.DefaultSettings.ErrorMessages end
		if APPotsSaver.Settings.Abilities == nil then APPotsSaver.Settings.Abilities = APPotsSaver.DefaultSettings.Abilities end
	end

	LibSlash.RegisterSlashCmd("appotssaver", function(input) APPotsSaver_Config.Slash(input) end)

	if APPotsSaver.Settings.Enabled then APPotsSaver.RegisterEvents() end

	TextLogAddEntry("Chat", 0, towstring("<icon57> APPotsSaver by Kpihuss loaded. Type /appotssaver for settings."))
end

function APPotsSaver.OnShutdown()
	APPotsSaver.UnregisterEvents()
end

function APPotsSaver.RegisterEvents()
	if not eventsRegistered then
		RegisterEventHandler(SystemData.Events.ENTER_WORLD, "APPotsSaver.ENTER_WORLD")
		RegisterEventHandler(SystemData.Events.PLAYER_ZONE_CHANGED, "APPotsSaver.PLAYER_ZONE_CHANGED")
		RegisterEventHandler(SystemData.Events.INTERFACE_RELOADED, "APPotsSaver.INTERFACE_RELOADED")
		RegisterEventHandler(SystemData.Events.PLAYER_HOT_BAR_UPDATED, "APPotsSaver.PLAYER_HOT_BAR_UPDATED")
	end
	eventsRegistered = true
end

function APPotsSaver.UnregisterEvents()
	if eventsRegistered then
		UnregisterEventHandler(SystemData.Events.ENTER_WORLD, "APPotsSaver.ENTER_WORLD")
		UnregisterEventHandler(SystemData.Events.PLAYER_ZONE_CHANGED, "APPotsSaver.PLAYER_ZONE_CHANGED")
		UnregisterEventHandler(SystemData.Events.INTERFACE_RELOADED, "APPotsSaver.INTERFACE_RELOADED")
		UnregisterEventHandler(SystemData.Events.PLAYER_HOT_BAR_UPDATED, "APPotsSaver.PLAYER_HOT_BAR_UPDATED")
	end
	eventsRegistered = false
end

function APPotsSaver.ENTER_WORLD()
	loadingEnd = true
	APPotsSaver.ButtonIconsNeedUpdate = true
	APPotsSaver.EnabledStatesNeedUpdate = true
end

function APPotsSaver.PLAYER_ZONE_CHANGED()
	loadingEnd = true
	APPotsSaver.ButtonIconsNeedUpdate = true
	APPotsSaver.EnabledStatesNeedUpdate = true
end

function APPotsSaver.INTERFACE_RELOADED()
	loadingEnd = true
	APPotsSaver.ButtonIconsNeedUpdate = true
	APPotsSaver.EnabledStatesNeedUpdate = true
end

function APPotsSaver.PLAYER_HOT_BAR_UPDATED(slot, actionType, actionId)
	APPotsSaver.UpdateButtonIcon(slot, APPotsSaver.Settings.Abilities[actionId])
	APPotsSaver.UpdateButtonEnabledState(slot)
end

function APPotsSaver.OnUpdate(elapsed)
	if not loadingEnd then return end
	if not APPotsSaver.Settings.Enabled then return end

	timeLeft = timeLeft - elapsed
    if timeLeft > 0 then
        return
    end
    timeLeft = TIME_DELAY

	if APPotsSaver.ButtonIconsNeedUpdate then
		APPotsSaver.UpdateButtonIcons()
		APPotsSaver.ButtonIconsNeedUpdate = false
	end

	if APPotsSaver.EnabledStatesNeedUpdate then
		APPotsSaver.UpdateButtonsEnabledStates()
		APPotsSaver.EnabledStatesNeedUpdate = false
	else
		-- AP can change without a clean event, so refresh enabled state continuously.
		APPotsSaver.UpdateButtonsEnabledStates()
	end
end

function APPotsSaver.UpdateSettings()
	if APPotsSaver.Settings.Enabled and not eventsRegistered then
		APPotsSaver.RegisterEvents()
	elseif not APPotsSaver.Settings.Enabled and eventsRegistered then
		APPotsSaver.UnregisterEvents()
	end

	APPotsSaver.ButtonIconsNeedUpdate = true
	APPotsSaver.EnabledStatesNeedUpdate = true
	APPotsSaver.UpdateButtonIcons()

	TextLogAddEntry("Chat", 0, towstring("APPotsSaver v" .. tostring(APPotsSaver.Settings.Version) .. " settings: /appotssaver"))
	if APPotsSaver.Settings.Enabled then
		TextLogAddEntry("Chat", 0, L"--- <icon57> Enabled")
	else
		TextLogAddEntry("Chat", 0, L"--- <icon58> Enabled")
	end
	if APPotsSaver.Settings.Symbols then
		TextLogAddEntry("Chat", 0, L"--- <icon57> Show Symbols")
	else
		TextLogAddEntry("Chat", 0, L"--- <icon58> Show Symbols")
	end
	if APPotsSaver.Settings.ErrorMessages then
		TextLogAddEntry("Chat", 0, L"--- <icon57> Show Combat Error Messages")
	else
		TextLogAddEntry("Chat", 0, L"--- <icon58> Show Combat Error Messages")
	end
end

function APPotsSaver.UpdateButtonIcons()
	local actionType, actionId
	for i = 1, MAX_BUTTONS do
		actionType, actionId = GetHotbarData(i)
		if APPotsSaver.Settings.Enabled and APPotsSaver.Settings.Symbols and APPotsSaver.Settings.Abilities[actionId] ~= nil then
			APPotsSaver.UpdateButtonIcon(i, APPotsSaver.Settings.Abilities[actionId])
		else
			APPotsSaver.UpdateButtonIcon(i, nil)
		end
	end
end

function APPotsSaver.UpdateButtonIcon(slot, value)
	local hbar, buttonid = ActionBars:BarAndButtonIdFromSlot(slot)
	if hbar and buttonid then
		local button = hbar.m_Buttons[buttonid]
		if button and button.m_Windows and button.m_Windows[7] then
			if value == nil then
				button.m_Windows[7]:Show(false)
			else
				button.m_Windows[7]:Show(true)
				button.m_Windows[7]:SetFont("font_clear_small_bold", 10)
				button.m_Windows[7]:SetTextColor(255, 255, 0)
				local displayText = (value == 0) and "=0AP" or (">" .. tostring(value) .. "AP")
				button.m_Windows[7]:SetText(displayText)
			end
		end
	end
end

function APPotsSaver.UpdateButtonsEnabledStates()
	for i = 1, MAX_BUTTONS do
		APPotsSaver.UpdateButtonEnabledState(i)
	end
end

function APPotsSaver.UpdateButtonEnabledState(slot)
	local actionType, actionId, isSlotEnabled, isTargetValid, isSlotBlocked = GetHotbarData(slot)
	if APPotsSaver.Settings.Abilities[actionId] ~= nil then
		ActionBars.UpdateSlotEnabledState(slot, isSlotEnabled, isTargetValid, isSlotBlocked)
	end
end

-- Hooked Functions
local orgActionButtonOnLButtonDown = ActionButton.OnLButtonDown
function ActionButton.OnLButtonDown(self, flags, x, y)
	if flags == SystemData.ButtonFlags.CONTROL and self and self.m_ActionId ~= 0 then
		APPotsSaver.Settings.Abilities[self.m_ActionId] = nextThreshold(APPotsSaver.Settings.Abilities[self.m_ActionId])

		APPotsSaver.UpdateButtonIcon(self.m_HotBarSlot, APPotsSaver.Settings.Abilities[self.m_ActionId])
		APPotsSaver.UpdateButtonEnabledState(self.m_HotBarSlot)
		APPotsSaver.EnabledStatesNeedUpdate = true
		APPotsSaver.ButtonIconsNeedUpdate = true
		chatInfo(self.m_ActionId, APPotsSaver.Settings.Abilities[self.m_ActionId])
		return
	end

	if self and self.m_ActionId ~= 0 and APPotsSaver.Settings.Abilities[self.m_ActionId] ~= nil and isAbilityBlocked(self.m_ActionId) then
		return
	end

	return orgActionButtonOnLButtonDown(self, flags, x, y)
end

local orgActionButtonOnLButtonUp = ActionButton.OnLButtonUp
if type(orgActionButtonOnLButtonUp) == "function" then
	function ActionButton.OnLButtonUp(self, flags, x, y)
		if self and self.m_ActionId ~= 0 and APPotsSaver.Settings.Abilities[self.m_ActionId] ~= nil and isAbilityBlocked(self.m_ActionId) then
			return
		end
		return orgActionButtonOnLButtonUp(self, flags, x, y)
	end
end

local orgActionBarsUpdateSlotEnabledState = ActionBars.UpdateSlotEnabledState
function ActionBars.UpdateSlotEnabledState(slot, isSlotEnabled, isTargetValid, isSlotBlocked)
	local hbar, buttonid = ActionBars:BarAndButtonIdFromSlot(slot)
	if hbar and buttonid then
		local button = hbar.m_Buttons[buttonid]
		if button and APPotsSaver.Settings.Abilities[button.m_ActionId] ~= nil then
			local threshold = APPotsSaver.Settings.Abilities[button.m_ActionId]
			if getCurrentAP() > threshold then
				isSlotEnabled = false
			end
		end
	end
	orgActionBarsUpdateSlotEnabledState(slot, isSlotEnabled, isTargetValid, isSlotBlocked)
end

local orgActionButtonUpdateInventory = ActionButton.UpdateInventory
function ActionButton.UpdateInventory(self)
	if APPotsSaver.Settings.Abilities[self.m_ActionId] == nil then
		orgActionButtonUpdateInventory(self)
	end
end
