LibConfig = LibStub("LibConfig")

APPotsSaver_Config = {}

local GUI

function APPotsSaver_Config.Slash(input)
	if (not GUI) then
		GUI = LibConfig("APPotsSaver v" .. tostring(APPotsSaver.Settings.Version), APPotsSaver.Settings, true, APPotsSaver_Config.SettingsChanged)

		GUI:AddTab("Info")
		local infoText
		infoText = GUI("label", "APPotsSaver blocks configured abilities when your current AP is ABOVE the cap set on that ability.")
		infoText.label:Font("font_default_text_small")
		infoText.label:Align("left")

		infoText = GUI("label", "The number shown on the hotbar button is the maximum AP allowed to use that ability.")
		infoText.label:Font("font_default_text_small")
		infoText.label:Align("left")

		infoText = GUI("label", "Examples: 30 = ability is blocked at 31+ AP. 0 = ability only works at 0 AP.")
		infoText.label:Font("font_default_text_small")
		infoText.label:Align("left")

		infoText = GUI("label", "To change the AP cap on an ability, CTRL-LEFT CLICK the ability on your hotbar.")
		infoText.label:Font("font_default_text_small")
		infoText.label:Align("left")

		infoText = GUI("label", "Cycle: clear -> 0 -> 10 -> 20 -> ... -> 200 -> clear")
		infoText.label:Font("font_default_text_small")
		infoText.label:Align("left")

		GUI:AddTab("Settings")
		GUI("checkbox", "Enabled", "Enabled")
		GUI("checkbox", "Show Symbols", "Symbols")
		GUI("checkbox", "Show Combat Error messages", "ErrorMessages")
	end
	GUI:Show()
end

function APPotsSaver_Config.SettingsChanged()
	GUI:Hide()
	APPotsSaver.UpdateSettings()
end
