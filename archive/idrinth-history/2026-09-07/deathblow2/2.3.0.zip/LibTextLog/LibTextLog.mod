<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
	<UiMod name="LibTextLog" version="1.0.0" date="08/05/2026">
		<Author name="Caffeine" />
		<Description text="Central parsed text log and alert event library." />
		<VersionSettings gameVersion="1.4.8" windowsVersion="1.0" savedVariablesVersion="1.0" />
		<Dependencies>
			<Dependency name="EA_ChatWindow" />
			<Dependency name="EA_AlertTextWindow" />
		</Dependencies>
		<Files>
			<File name="LibTextLog.lua" />
		</Files>
		<OnInitialize>
			<CallFunction name="LibTextLog.Initialize" />
		</OnInitialize>
		<OnShutdown>
			<CallFunction name="LibTextLog.Shutdown" />
		</OnShutdown>
		<WARInfo>
			<Categories>
				<Category name="OTHER" />
			</Categories>
		</WARInfo>
	</UiMod>
</ModuleFile>