-- =============================================================================
--
--                                  LibTextLog
--
-- Shared library that turns Warhammer Online's native combat log, chat log, and
-- alert text feeds into structured Lua events. Consumers register a callback
-- per event id and receive a parsed payload table; the library owns all native
-- event registrations, parser localization, and re-entrant dispatch safety.
--
-- Public API surface
--   LibTextLog.Events                  -- event id table (KILL/LOOT/RVR/SERVER)
--   LibTextLog.Register(event, func)   -- subscribe a callback
--   LibTextLog.Unregister(event, func) -- remove a previously registered cb
--   LibTextLog.GetSubscriberCount(ev)  -- query current subscriber count
--   LibTextLog.Initialize()            -- (re)bind native handlers, called from .mod
--   LibTextLog.Shutdown()              -- detach native handlers
--   LibTextLog.SetKillParser(id, fn)   -- inject or override a per-language parser
--   LibTextLog.ParseKillMessage(text, filterId, timestamp) -- parse a raw kill line
--   LibTextLog.ParseKillEntry(index)   -- parse a Combat log entry by index
--   LibTextLog.CleanName(name)         -- strip rank/title markers from a player name
--
-- Payload schemas
--   KILL                 = { event, timestamp, filterId, text, victim, verb, killer, weapon, location, killerFilter, victimFilter }
--   LOOT (lootType=item) = { event, lootType, timestamp, filterId, text, itemName, quantity }
--   LOOT (lootType=bag)  = { event, lootType, timestamp, filterId, text, bagType }
--   RVR_DOOR_STATUS      = { event, alertType, vecType, vecText, text }
--   SERVER_ANNOUNCEMENT  = { event, alertType, vecType, vecText, text }
--
-- =============================================================================

local VERSION = 1;

LibTextLog = LibTextLog or {};
LibTextLog.Version = VERSION;

-------------------------------------------------------------------------------
-- Localized upvalues and constants
-------------------------------------------------------------------------------

local pcall = pcall;
local tostring = tostring;
local towstring = towstring;
local wstring_gsub = wstring.gsub;
local TextLogGetEntry = TextLogGetEntry;
local TextLogGetNumEntries = TextLogGetNumEntries;
local TextLogGetUpdateEventId = TextLogGetUpdateEventId;
local RegisterEventHandler = RegisterEventHandler;
local UnregisterEventHandler = UnregisterEventHandler;

local UPDATE_ADDED = SystemData.TextLogUpdate.ADDED;
local KILLS_ORDER = SystemData.ChatLogFilters.RVR_KILLS_ORDER;
local KILLS_DESTRUCTION = SystemData.ChatLogFilters.RVR_KILLS_DESTRUCTION;
local LOOT = SystemData.ChatLogFilters.LOOT or 30;

-- AlertTextWindow.SetAlertData receives a vecType[1] discriminator.
local ALERT_SERVER = 4;
local ALERT_RVR_ORDER = 21;
local ALERT_RVR_DESTRUCTION = 22;
local ALERT_RVR_INFO = 23;

-- GameData.ChatData.type discriminator for the system loot-bag announcement.
local CHAT_TYPE_LOOT = 3;

LibTextLog.Events =
{
	KILL = 1,
	LOOT = 2,
	RVR_DOOR_STATUS = 3,
	-- RVR_DOOR / RVR_STATUS are public aliases preserved for legacy consumers.
	RVR_DOOR = 3,
	RVR_STATUS = 3,
	SERVER_ANNOUNCEMENT = 4,
	SERVER = 4,
};

LibTextLog.RegisteredEvents = {};

local EVENT_KILL = LibTextLog.Events.KILL;
local EVENT_LOOT = LibTextLog.Events.LOOT;
local EVENT_RVR_DOOR_STATUS = LibTextLog.Events.RVR_DOOR_STATUS;
local EVENT_SERVER_ANNOUNCEMENT = LibTextLog.Events.SERVER_ANNOUNCEMENT;

local CHAT_EVENT = TextLogGetUpdateEventId("Chat");
local COMBAT_EVENT = TextLogGetUpdateEventId("Combat");

-------------------------------------------------------------------------------
-- Internal state
-------------------------------------------------------------------------------

local subscriberCounts = {};
local combatSubscribers = 0;
local chatSubscribers = 0;
local alertSubscribers = 0;

local combatRegistered = false;
local chatRegistered = false;
local chatTextRegistered = false;
local alertHooked = false;
local alertHook = nil;

local killParser = nil;

-------------------------------------------------------------------------------
-- Diagnostics
-------------------------------------------------------------------------------

local function PrintError(errmsg)
	if d then
		d("LibTextLog callback error: " .. tostring(errmsg));
	end
end

local function PrintWarning(msg)
	if d then
		d("LibTextLog: " .. msg);
	end
end

-------------------------------------------------------------------------------
-- Helpers
-------------------------------------------------------------------------------

-- Normalize a player name by stripping the rank/title sentinel ('^...') and any
-- trailing fragment after a space. Idempotent: clean names pass through unchanged.
local function CleanName(name)
	if (name == nil or name == L"") then return name end

	local pos = name:find(L"^", 1, true);
	if (pos) then name = name:sub(1, pos - 1) end

	pos = name:find(L" ", 1, true);
	if (pos) then name = name:sub(1, pos - 1) end

	return name;
end

local function OtherKillFilter(filterId)
	if (filterId == KILLS_ORDER) then
		return KILLS_DESTRUCTION;
	end

	return KILLS_ORDER;
end

local function IsCombatEvent(event)
	return event == EVENT_KILL;
end

local function IsChatEvent(event)
	return event == EVENT_LOOT;
end

local function IsAlertEvent(event)
	return event == EVENT_RVR_DOOR_STATUS or event == EVENT_SERVER_ANNOUNCEMENT;
end

local function GetSubscriberCount(event)
	return subscriberCounts[event] or 0;
end

-------------------------------------------------------------------------------
-- Dispatch core
-------------------------------------------------------------------------------

-- Dispatch is re-entrancy safe: a callback may Register or Unregister during
-- iteration. Removed callbacks become `false` tombstones in `entry.list`; once
-- the outermost dispatch frame returns, the list is compacted in one pass.
local function Dispatch(event, data)
	local entry = LibTextLog.RegisteredEvents[event];
	if (not entry) then return end

	local list = entry.list;
	local last = entry.count;

	entry.dispatchDepth = entry.dispatchDepth + 1;

	for i = 1, last do
		local callback = list[i];
		if (callback) then
			local ok, errmsg = pcall(callback, data);
			if (not ok) then
				PrintError(errmsg);
			end
		end
	end

	entry.dispatchDepth = entry.dispatchDepth - 1;

	if (entry.dispatchDepth == 0 and entry.dirty) then
		local writeIndex = 1;
		local compactLast = entry.count;
		local byFunc = entry.byFunc;

		for i = 1, compactLast do
			local callback = list[i];
			if (callback) then
				list[writeIndex] = callback;
				byFunc[callback] = writeIndex;
				writeIndex = writeIndex + 1;
			end
		end

		for i = writeIndex, compactLast do
			list[i] = nil;
		end

		entry.count = writeIndex - 1;
		entry.dirty = false;
	end
end

-------------------------------------------------------------------------------
-- Native registration lifecycle
--
-- Each native binding (combat log, chat log, chat text arrived, alert hook) is
-- guarded by a boolean flag so RefreshRegistrations is idempotent. The library
-- only binds when at least one consumer is interested, sparing the hot paths
-- when the addons are disabled.
-------------------------------------------------------------------------------

local function RegisterCombat(enabled)
	if (enabled and not combatRegistered) then
		RegisterEventHandler(COMBAT_EVENT, "LibTextLog.OnCombatLogUpdated");
		combatRegistered = true;
	elseif (not enabled and combatRegistered) then
		UnregisterEventHandler(COMBAT_EVENT, "LibTextLog.OnCombatLogUpdated");
		combatRegistered = false;
	end
end

local function RegisterChat(enabled)
	if (enabled and not chatRegistered) then
		RegisterEventHandler(CHAT_EVENT, "LibTextLog.OnChatLogUpdated");
		chatRegistered = true;
	elseif (not enabled and chatRegistered) then
		UnregisterEventHandler(CHAT_EVENT, "LibTextLog.OnChatLogUpdated");
		chatRegistered = false;
	end

	if (enabled and not chatTextRegistered) then
		RegisterEventHandler(SystemData.Events.CHAT_TEXT_ARRIVED, "LibTextLog.OnChatTextArrived");
		chatTextRegistered = true;
	elseif (not enabled and chatTextRegistered) then
		UnregisterEventHandler(SystemData.Events.CHAT_TEXT_ARRIVED, "LibTextLog.OnChatTextArrived");
		chatTextRegistered = false;
	end
end

-- Alert dispatch is delivered through a function-pointer hook on
-- AlertTextWindow.SetAlertData. The original is captured and forwarded so the
-- hook is non-destructive even if a third party hooks before us.
local function RegisterAlert(enabled)
	if (enabled and not alertHooked) then
		alertHook = AlertTextWindow.SetAlertData;
		AlertTextWindow.SetAlertData = LibTextLog.AlertHook;
		alertHooked = true;
	elseif (not enabled and alertHooked) then
		if (AlertTextWindow.SetAlertData == LibTextLog.AlertHook) then
			AlertTextWindow.SetAlertData = alertHook;
			alertHooked = false;
			alertHook = nil;
		end
	end
end

local function RefreshRegistrations()
	RegisterCombat(combatSubscribers > 0);
	RegisterChat(chatSubscribers > 0);
	RegisterAlert(alertSubscribers > 0);
end

-------------------------------------------------------------------------------
-- Kill-message parsers
--
-- Each parser receives the raw wide-string kill line and returns
-- (victim, verb, killer, weapon, location). Empty/missing fields return L"" so
-- callers can rely on a stable arity.
--
-- The format corpus comments preserved per parser are real kill lines captured
-- by KillSpam over years of live play. Treat them as the regression-test
-- reference: any pattern change must keep all corpus lines parseable.
-------------------------------------------------------------------------------

-- The "Unknown" location quirk: the engine occasionally returns L"Unknown" as
-- the parsed location and emits the real zone in a trailing fragment after the
-- period (e.g. "... in Unknown. Praag"). Promote the tail when present.
local function FixUnknownLocation(location, tail)
	if (location == L"Unknown" and tail and tail ~= L"") then
		return tail;
	end

	return location;
end

-- ParseKillEN
--   Denoto has been annihilated by Grikson's Hip Shot in Shadow Spire.
--   Kento has been annihilated by Zoozu's Agonizing Wound in Shadow Spire.
--   Kento has been annihilated by Diplomat's Right in Da Jibblies in Shadow Spire.
--   Gogo has been killed by Darkaim in Unknown. Praag
--   Spinage has been killed by Gitsun in Unknown. Praag
--   Lupin has been killed by Mamasha in Unknown. Oathsworn Valley
local function ParseKillEN(text)
	local victim, verb, killer, weapon, location, tail =
		text:match(L"^([%a]+) has been ([%a]+) by ([%a]+)'s (.+) in ([^%.]+)%.%s*([^%.]*)");

	if (victim) then
		return victim, verb, killer, weapon, FixUnknownLocation(location, tail);
	end

	victim, verb, killer, location, tail =
		text:match(L"^([%a]+) has been ([%a]+) by ([%a]+) in ([^%.]+)%.%s*([^%.]*)");

	if (victim) then
		return victim, verb, killer, L"", FixUnknownLocation(location, tail);
	end
end

-- ParseKillDE
--   Muzrok wurde von Hellomababy bei der Nordland XI mit seiner Chraceaxt der Rachsucht zerhackt.
--   Naryrs wurde von Domigni auf dem Festplatz mit seiner Musketensalve vernichtet.
--   Dorunor wurde von Lasall auf dem Festplatz mit seinem schnellen Einschnitt vernichtet.
--   Sallandra wurde von Dugrond auf dem Festplatz mit seiner Musketensalve vernichtet.
--   Bendip wurde von Skalartik auf dem Festplatz mit seiner Musketensalve ausgelöscht. Skalartik verfällt in Raserei!
--   Anoriella wurde von Marhin auf dem Festplatz mit seinem Bihänder der Rachsucht zerschnitten.
--   Tondert wurde von Marhin auf dem Festplatz mit seinem behexten Hieb vernichtet.
--   Thiqo wurde von Skalartik auf dem Festplatz mit seinem Brandschuss ausgelöscht. Skalartik verfällt in einen Amoklauf!
local function ParseKillDE(text)
	-- The German format uses one of seven prepositions before the location.
	-- Each variant is tried in turn; the first match wins.
	local victim, killer, location = text:match(L"(%a+) wurde von (%a+) auf de[mnr] (.-) mit .*");
	if (not victim) then victim, killer, location = text:match(L"(%a+) wurde von (%a+) bei de[mnr] (.-) mit .*"); end
	if (not victim) then victim, killer, location = text:match(L"(%a+) wurde von (%a+) [ai]n de[mnr] (.-) mit .*"); end
	if (not victim) then victim, killer, location = text:match(L"(%a+) wurde von (%a+) inmitten de[rs] (.-) mit .*"); end
	if (not victim) then victim, killer, location = text:match(L"(%a+) wurde von (%a+) [ai][nm] (.-) mit .*"); end
	if (not victim) then victim, killer, location = text:match(L"(%a+) wurde von (%a+) beim? (.-) mit .*"); end
	if (not victim) then victim, killer, location = text:match(L"(%a+) wurde von (%a+) auf (.-) mit .*"); end
	if (not victim) then victim, killer, location = text:match(L"(%a+) wurde von (%a+) inmitten (.-) mit .*"); end

	if (not victim) then return end

	local weapon = text:match(L"mit [%a]+ ([%a%d%p ]+) [%a]+%.") or L"";
	local verb = text:match(L"mit [%a]+ [%a%d%p ]+ ([%a]+)%.") or L"";

	return victim, verb, killer, weapon, location;
end

-- ParseKillFR
--   Galathe s'est fait anéantir par le Couperet de l'âme de Killhan dans Vallée de Jure-serment.
--   Célina s'est fait anéantir par les Douleurs lancinantes de Sheneri dans Vallée de Jure-serment.
--   Harell s'est fait anéantir par la Toxine cardiaque de Limpide dans Vallée de Jure-serment.
--   Cerbhair a été détruit par l'Affolement de Diskar dans Vallée de Jure-serment. Diskar fait un carnage !
--   Gedadriel a été détruit par le Souffle de feu de Lurgic dans Vallée de Jure-serment. Lurgic fait un carnage !
--   Lurgic a été taillé en pièces par le Krogenz, latte du Destin de Stunk dans Vallée de Jure-serment. Stunk fait un carnage !
--   Duregart a été détruit par le Couperet de l'âme de Killhan dans Vallée de Jure-serment.
--   Angelhus s'est fait anéantir par l'Afflux de douleur d'Elhodia dans Vallée de Jure-serment. Elhodia se déchaîne !
--   Wok a été haché menu par le kikoup d'anathème du titan d'Irock dans Vallée de Jure-serment. Irock fait un carnage !
--   Gnedo a été détruit par la Cascade désastreuse d'Evince dans Vallée de Jure-serment. Evince fait un carnage !
--   Willounet a été détruit par le Puits des ombres de Bernik dans Vallée de Jure-serment.
--   Loseline s'est fait anéantir par la Cascade désastreuse de Shinmen dans Vallée de Jure-serment. Shinmen fait un carnage !
--   Elhodia a été détruit par la Fin inexorable de Diskar dans Vallée de Jure-serment. Diskar fait un carnage !
--   Arson a été détruit par l'Afflux de douleur d'Evince dans Vallée de Jure-serment. Evince fait un carnage !
--   Nainportout s'est fait anéantir par Libérer les vents de Gristonas dans Vallée de Jure-serment. Gristonas se déchaîne !
--   Vendêtto s'est fait anéantir par l'Affolement de Diskar dans Vallée de Jure-serment. Diskar fait un carnage !
--   Wothan s'est fait anéantir par la Répulsion de Gwahyr dans Vallée de Jure-serment. Gwahyr fait un carnage !
--
-- Edge cases where the killer's name appears inside the weapon clause; the
-- second pattern is intentionally looser to catch them.
--
--   Pandorus s'est fait anéantir par l'Explosion de Pandorus dans Vallée de Jure-serment.
--   Thaddee s'est fait anéantir par le Mot de douleur de Spykked dans Kazad Dammaz.
--   Ghep s'est fait écraser par l'écraseur d'hors-la-loi de Vendêtto dans Vallée de Jure-serment.
--   Amaurea s'est fait anéantir par l'Afflux de douleur d'Evince dans Vallée de Jure-serment. Evince fait un carnage !
local function ParseKillFR(text)
	local victim, killer, location = text:match(L"(%a+) .*[%s%'](%a+) dans (.+)%..*");
	if (not victim) then
		victim, killer, location = text:match(L"(%a+) .-(%a+) dans (.+)%..*");
	end

	if (not victim) then return end

	local verb = text:match(L"^[^%.]+ ([%a]+) par [^%.]+%.") or L"";
	local weapon = text:match(L"^[^%.]+ par ([^%.]+) de ") or L"";

	return victim, verb, killer, weapon, location;
end

-- ParseKillRU
--   Игрок Мурбаг растерзан игроком Сквирес (Точный удар) на территории Путь Змеи.
--   Игрок Брост растерзан игроком Барракуда (Уничтожение мысли) на территории Путь Змеи.
--   Игрок Мурбаг уничтожен игроком Карго (Пламя Рхайна) на территории Путь Змеи.
--   Игрок Барракуда уничтожен игроком Брост (Сверхновая) на территории Путь Змеи.
--   Игрок Ретурн зарублен игроком Карго (секира Песчаной бури) на территории Путь Змеи. Карго впадает в ярость!
--   Игрок Верзиул уничтожен игроком Таир (Просачивающаяся сила) на территории Путь Змеи.
--   Игрок Сугби разрублен на куски игроком Сквирес (клеймор натиска) на территории Путь Змеи. Сквирес впадает в ярость!
--   Игрок Смокерз растерзан игроком Ромео (Выжигание лжи) на территории Путь Змеи. Ромео впадает в ярость!
--   Игрок Морриол пристукнут игроком Брост (Акире, создатель) на территории Путь Змеи. Брост впадает в ярость!
--   Игрок Вратарь растерзан игроком Гиперион (Пламя Рхайна) на территории рейкландская фабрика.
local function ParseKillRU(text)
	-- Strict pattern: weapon wrapped in (parens). Captures the weapon name.
	local victim, killer, weapon, location =
		text:match(L"Игрок (%a+) .+ игроком (%a+) %((.+)%) на территории (.+)%..*");

	if (victim) then
		local verb = text:match(L"Игрок %a+ (.+) игроком") or L"";
		return victim, verb, killer, weapon, location;
	end

	-- Loose fallback: matches lines without a (weapon) clause. Mirrors the
	-- defensive pattern carried by KillSpam for years.
	local lvictim, lkiller, llocation =
		text:match(L"Игрок (%a+) .+ игроком (%a+) .+ на территории (.+)%..*");

	if (lvictim) then
		local verb = text:match(L"Игрок %a+ (.+) игроком") or L"";
		return lvictim, verb, lkiller, L"", llocation;
	end
end

-- ParseKillIT
local function ParseKillIT(text)
	local victim, verb, weapon, killer, location =
		text:match(L"([%a]+) è stato ([%a]+) da (.+) di ([%a]+) a ([^%.]+)%.");

	if (victim) then
		return victim, verb, killer, weapon, location;
	end
end

-- ParseKillES
local function ParseKillES(text)
	local victim, verb, killer, weapon, location =
		text:match(L"([%a]+) ha sido ([%a%d%p ]+) por ([%a]+)'s ([^%.]+) en ([^%.]+)%.");

	if (victim) then
		return victim, verb, killer, weapon, location;
	end
end

-- ParseKillKO
local function ParseKillKO(text)
	local victim, location, killer = text:match(L"(%a+) 님이 (.-)에서 (%a+)의 .*");

	if (victim) then
		return victim, L"", killer, L"", location;
	end
end

-- Dispatch table keyed by SystemData language id. Using the named constants
-- avoids hard-coded numeric ids drifting against the client.
local LANG = SystemData.Settings.Language;
local killParsers =
{
	[LANG.ENGLISH] = ParseKillEN,
	[LANG.FRENCH]  = ParseKillFR,
	[LANG.GERMAN]  = ParseKillDE,
	[LANG.ITALIAN] = ParseKillIT,
	[LANG.SPANISH] = ParseKillES,
	[LANG.RUSSIAN] = ParseKillRU,
	[LANG.KOREAN]  = ParseKillKO,
};

-- Set the active parser at file load so any pre-Initialize kill events on
-- non-English clients still parse correctly. Initialize() will refresh it if
-- the active language ever changes at runtime.
killParser = killParsers[LANG.active] or ParseKillEN;

local function ParseKill(text)
	local parser = killParser or ParseKillEN;
	local victim, verb, killer, weapon, location = parser(text);

	-- Two safety nets: try English (covers cross-locale system messages) and
	-- finally Korean (its glyph set never collides with the others, so trying
	-- it last is free of false positives).
	if (not victim and parser ~= ParseKillEN) then
		victim, verb, killer, weapon, location = ParseKillEN(text);
	end

	if (not victim) then
		victim, verb, killer, weapon, location = ParseKillKO(text);
	end

	return victim, verb, killer, weapon, location;
end

-------------------------------------------------------------------------------
-- Event payload builders
-------------------------------------------------------------------------------

local function BuildKillEvent(timestamp, filterId, text)
	local victim, verb, killer, weapon, location = ParseKill(text);
	if (not (victim and killer and location)) then return nil end

	-- Hand subscribers normalized names so they never carry rank markers.
	victim = CleanName(victim);
	killer = CleanName(killer);

	return
	{
		event = EVENT_KILL,
		timestamp = timestamp,
		filterId = filterId,
		text = text,
		victim = victim,
		verb = verb or L"",
		killer = killer,
		weapon = weapon or L"",
		location = location,
		killerFilter = filterId,
		victimFilter = OtherKillFilter(filterId),
	};
end

local function BuildLootEvent(timestamp, filterId, text)
	-- ROR-style "You receive a Foo (3)." bakes the stack count into the
	-- trailing "(N).". Peel it off first so the article/digit patterns
	-- below see the bare item name, and so consumers get a real numeric
	-- quantity instead of having to scrape it out of itemName.
	local parseText = text;
	local trailingQuantity;
	local body, paren = text:match(L"^(.-)%s*%((%d+)%)%s*%.$");
	if (body and body ~= L"") then
		parseText = body .. L".";
		trailingQuantity = paren;
	end

	local quantity, itemName = parseText:match(L"You receive ([%d]+) ([^%.]+)%.");
	if (not itemName) then
		itemName = parseText:match(L"You receive [%a]+ ([^%.]+)%.");
	end

	if (itemName and itemName ~= L"") then
		itemName = wstring_gsub(itemName, L"%s+$", L"");
		return
		{
			event = EVENT_LOOT,
			lootType = "item",
			timestamp = timestamp,
			filterId = filterId,
			text = text,
			itemName = itemName,
			quantity = quantity or trailingQuantity,
		};
	end

	local bagType = text:match(L"You won a ([^%.%!]+) bag[%.!]");
	if (bagType and bagType ~= L"") then
		return
		{
			event = EVENT_LOOT,
			lootType = "bag",
			timestamp = timestamp,
			filterId = filterId,
			text = text,
			bagType = bagType,
		};
	end
end

local function BuildLootBagEvent(text)
	local bagType = text:match(L"You have won a ([%a]+) loot bag[%.!]");
	if (not (bagType and bagType ~= L"")) then return nil end

	return
	{
		event = EVENT_LOOT,
		lootType = "bag",
		filterId = GameData.ChatData.type,
		text = text,
		bagType = bagType,
	};
end

local function BuildAlertEvent(event, vecType, vecText)
	return
	{
		event = event,
		alertType = vecType[1],
		vecType = vecType,
		vecText = vecText,
		text = vecText[1],
	};
end

-------------------------------------------------------------------------------
-- Public API
-------------------------------------------------------------------------------

-- LibTextLog.Initialize
--   Refreshes the active kill parser from the current SystemData language and
--   rebinds native handlers based on the current subscriber tally. Bound from
--   LibTextLog.mod's OnInitialize. Safe to call repeatedly.
function LibTextLog.Initialize()
	local activeLanguage = LANG.active;
	killParser = killParsers[activeLanguage] or ParseKillEN;
	RefreshRegistrations();
end

-- LibTextLog.Shutdown
--   Detaches every native handler the library may have bound and restores the
--   original AlertTextWindow.SetAlertData. Subscriber tables are preserved so
--   the library can be re-initialized without losing registrations.
function LibTextLog.Shutdown()
	RegisterCombat(false);
	RegisterChat(false);

	if (alertHooked and AlertTextWindow.SetAlertData == LibTextLog.AlertHook) then
		AlertTextWindow.SetAlertData = alertHook;
		alertHooked = false;
		alertHook = nil;
	end
end

-- LibTextLog.Register
--   Subscribes `func` to `event`. Duplicate registrations of the same callback
--   for the same event are silently ignored. The native handler for the
--   underlying feed is bound on demand on the first subscriber.
function LibTextLog.Register(event, func)
	if (not event or not func) then return end

	local entry = LibTextLog.RegisteredEvents[event];
	if (not entry) then
		entry = { byFunc = {}, list = {}, count = 0, dispatchDepth = 0, dirty = false };
		LibTextLog.RegisteredEvents[event] = entry;
	end

	if (entry.byFunc[func]) then return end

	local index = entry.count + 1;
	entry.count = index;
	entry.list[index] = func;
	entry.byFunc[func] = index;

	subscriberCounts[event] = GetSubscriberCount(event) + 1;

	if (IsCombatEvent(event)) then
		combatSubscribers = combatSubscribers + 1;
	elseif (IsChatEvent(event)) then
		chatSubscribers = chatSubscribers + 1;
	elseif (IsAlertEvent(event)) then
		alertSubscribers = alertSubscribers + 1;
	end

	RefreshRegistrations();
end

-- LibTextLog.Unregister
--   Removes a previously-registered callback. If a dispatch is currently in
--   flight the slot is tombstoned with `false` and compacted later; otherwise
--   the trailing entry is swapped in place for O(1) removal. Underflow on the
--   subscriber counters indicates a double-unregister upstream and is surfaced
--   via PrintWarning rather than silently clamped.
function LibTextLog.Unregister(event, func)
	if (not event or not func) then return end

	local entry = LibTextLog.RegisteredEvents[event];
	if (not entry) then return end

	local index = entry.byFunc[func];
	if (not index) then return end

	local list = entry.list;

	if (entry.dispatchDepth > 0) then
		list[index] = false;
		entry.byFunc[func] = nil;
		entry.dirty = true;
	else
		local last = entry.count;

		if (index ~= last) then
			local moved = list[last];
			list[index] = moved;
			entry.byFunc[moved] = index;
		end

		list[last] = nil;
		entry.byFunc[func] = nil;
		entry.count = last - 1;
	end

	local current = GetSubscriberCount(event);
	if (current > 0) then
		subscriberCounts[event] = current - 1;
	else
		--PrintWarning("subscriber underflow on event " .. tostring(event));
		subscriberCounts[event] = 0;
	end

	if (IsCombatEvent(event)) then
		if (combatSubscribers > 0) then
			combatSubscribers = combatSubscribers - 1;
		else
			--PrintWarning("combat subscriber underflow");
		end
	elseif (IsChatEvent(event)) then
		if (chatSubscribers > 0) then
			chatSubscribers = chatSubscribers - 1;
		else
			--PrintWarning("chat subscriber underflow");
		end
	elseif (IsAlertEvent(event)) then
		if (alertSubscribers > 0) then
			alertSubscribers = alertSubscribers - 1;
		else
			--PrintWarning("alert subscriber underflow");
		end
	end

	RefreshRegistrations();
end

-- LibTextLog.GetSubscriberCount
--   Returns the number of callbacks currently registered for `event`.
function LibTextLog.GetSubscriberCount(event)
	return GetSubscriberCount(event);
end

-- LibTextLog.CleanName
--   Normalizes a player name wstring: strips the rank/title sentinel ('^...')
--   and any trailing fragment after a space. Use for names that come from
--   GameData, PartyUtils, or any other source outside the library payloads;
--   KILL payloads are already cleaned by the library itself.
function LibTextLog.CleanName(name)
	return CleanName(name);
end

-- LibTextLog.SetKillParser
--   Installs or replaces the parser for a SystemData language id. If the id
--   matches the active language, the new parser is wired in immediately.
function LibTextLog.SetKillParser(languageId, parser)
	if (not languageId or not parser) then return end

	killParsers[languageId] = parser;
	if (LANG.active == languageId) then
		killParser = parser;
	end
end

-- LibTextLog.ParseKillMessage
--   Parses a single kill line into a KILL payload. `filterId` defaults to
--   KILLS_ORDER when not supplied; `timestamp` is passed through unchanged.
--   Returns nil if the line cannot be parsed in any supported language.
function LibTextLog.ParseKillMessage(text, filterId, timestamp)
	if (not text) then return nil end

	return BuildKillEvent(timestamp, filterId or KILLS_ORDER, text);
end

-- LibTextLog.ParseKillEntry
--   Parses the Combat log entry at `index` into a KILL payload, restricted to
--   RVR_KILLS_ORDER and RVR_KILLS_DESTRUCTION rows. Used by reparse passes.
function LibTextLog.ParseKillEntry(index)
	local timestamp, filterId, text = TextLogGetEntry("Combat", index);
	if (filterId ~= KILLS_ORDER and filterId ~= KILLS_DESTRUCTION) then return nil end
	if (not text) then return nil end

	return BuildKillEvent(timestamp, filterId, text);
end

-------------------------------------------------------------------------------
-- Native event handlers (string-bound, must be globals on LibTextLog)
-------------------------------------------------------------------------------

function LibTextLog.OnCombatLogUpdated(updateType, filterType)
	if (updateType ~= UPDATE_ADDED or combatSubscribers == 0) then return end
	if (filterType ~= KILLS_ORDER and filterType ~= KILLS_DESTRUCTION) then return end

	local timestamp, filterId, text = TextLogGetEntry("Combat", TextLogGetNumEntries("Combat") - 1);
	if (not text) then return end

	local event = BuildKillEvent(timestamp, filterId, text);
	if (event) then
		Dispatch(EVENT_KILL, event);
	end
end

function LibTextLog.OnChatLogUpdated(updateType, filterType)
	if (updateType ~= UPDATE_ADDED or chatSubscribers == 0) then return end
	if (filterType ~= LOOT) then return end

	local timestamp, filterId, text = TextLogGetEntry("Chat", TextLogGetNumEntries("Chat") - 1);
	if (not text) then return end

	local event = BuildLootEvent(timestamp, filterId, text);
	if (event) then
		Dispatch(EVENT_LOOT, event);
	end
end

function LibTextLog.OnChatTextArrived()
	if (chatSubscribers == 0) then return end
	if (GameData.ChatData.type ~= CHAT_TYPE_LOOT) then return end

	local event = BuildLootBagEvent(GameData.ChatData.text);
	if (event) then
		Dispatch(EVENT_LOOT, event);
	end
end

-- LibTextLog.AlertHook
--   Replaces AlertTextWindow.SetAlertData while the library is active. The
--   original function pointer is captured in `alertHook` and forwarded after
--   our own dispatch so downstream UI continues to receive every alert.
function LibTextLog.AlertHook(vecType, vecText)
	if (alertSubscribers > 0 and vecType and vecText) then
		local alertType = vecType[1];

		if (alertType == ALERT_SERVER and GetSubscriberCount(EVENT_SERVER_ANNOUNCEMENT) > 0) then
			Dispatch(EVENT_SERVER_ANNOUNCEMENT, BuildAlertEvent(EVENT_SERVER_ANNOUNCEMENT, vecType, vecText));
		elseif ((alertType == ALERT_RVR_ORDER
				or alertType == ALERT_RVR_DESTRUCTION
				or alertType == ALERT_RVR_INFO)
			and GetSubscriberCount(EVENT_RVR_DOOR_STATUS) > 0) then
			Dispatch(EVENT_RVR_DOOR_STATUS, BuildAlertEvent(EVENT_RVR_DOOR_STATUS, vecType, vecText));
		end
	end

	if (alertHook) then
		alertHook(vecType, vecText);
	end
end
