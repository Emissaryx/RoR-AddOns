if not QueuePopTimer then QueuePopTimer = {} end

local find = find
local match = match
local tonumber = tonumber

QueuePopTimer.queueTime = 0
QueuePopTimer.queuePopTime = 0
QueuePopTimer.elapsedTime = 0
QueuePopTimer.currentWaitTime = L"Estimated wait time: no data"

QueuePopTimer.careers = {
    [GameData.CareerLine.WITCH_ELF] = L"DPS",
    [GameData.CareerLine.BRIGHT_WIZARD]  = L"DPS",
    [GameData.CareerLine.CHOPPA]  = L"DPS",
    [GameData.CareerLine.ENGINEER]  = L"DPS",
    [GameData.CareerLine.SLAYER]  = L"DPS",
    [GameData.CareerLine.MAGUS]  = L"DPS",
    [GameData.CareerLine.WHITE_LION]  = L"DPS",
    [GameData.CareerLine.SHADOW_WARRIOR]  = L"DPS",
    [GameData.CareerLine.SORCERER]  = L"DPS",
    [GameData.CareerLine.SQUIG_HERDER]  = L"DPS",
    [GameData.CareerLine.MARAUDER]  = L"DPS",
    [GameData.CareerLine.WITCH_HUNTER]  = L"DPS",
    [GameData.CareerLine.ARCHMAGE] = L"Heal",
    [GameData.CareerLine.DISCIPLE] = L"Heal",
    [GameData.CareerLine.RUNE_PRIEST] = L"Heal",
    [GameData.CareerLine.WARRIOR_PRIEST] = L"Heal",
    [GameData.CareerLine.SHAMAN] = L"Heal",
    [GameData.CareerLine.ZEALOT] = L"Heal",
    [GameData.CareerLine.BLACK_ORC] = L"Tank",
    [GameData.CareerLine.CHOSEN] = L"Tank",
    [GameData.CareerLine.IRON_BREAKER] = L"Tank",
    [GameData.CareerLine.SWORDMASTER] = L"Tank",
    [GameData.CareerLine.BLACKGUARD] = L"Tank",
    [GameData.CareerLine.KNIGHT] = L"Tank",
}

QueuePopTimer.waitTimes = {}

local function Print(str)
	EA_ChatWindow.Print(towstring(str))
end

function QueuePopTimer.Initialize()
	RegisterEventHandler(SystemData.Events.SCENARIO_ACTIVE_QUEUE_UPDATED, "QueuePopTimer.UpdateScenarioQueue")
	RegisterEventHandler(SystemData.Events.SCENARIO_SHOW_JOIN_PROMPT, "QueuePopTimer.UpdateScenarioPop")
	RegisterEventHandler( TextLogGetUpdateEventId("Chat"), "QueuePopTimer.OnChatLogUpdated");


	Print(L"<LINK data=\"0\" text=\"[QueuePopTimer]\" color=\"50,255,10\"> Addon initialized.");
end

--/script QueuePopTimer.UpdateScenarioQueue()
function QueuePopTimer.UpdateScenarioQueue()
	local queueData = GetScenarioQueueData()
	if (queueData ~= nil and queueData.totalQueuedScenarios >= 1) then
		QueuePopTimer.queueTime = GetComputerTime()
	end	
end
--/script QueuePopTimer.UpdateScenarioPop()
function QueuePopTimer.UpdateScenarioPop()
	QueuePopTimer.queuePopTime = GetComputerTime()

	if(QueuePopTimer.queueTime <= QueuePopTimer.queuePopTime) then
		QueuePopTimer.elapsedTime = QueuePopTimer.queuePopTime - QueuePopTimer.queueTime
	else
		--a new day has begun while we waited
		QueuePopTimer.elapsedTime = QueuePopTimer.queuePopTime + (86400 - QueuePopTimer.queueTime)
	end

	QueuePopTimer.SendChatMessage()
end


function QueuePopTimer.SendChatMessage()

	local timer, Time = 0, QueuePopTimer.elapsedTime
	local dSec = Time % 60
	Time = (Time - dSec) / 60
	local dMin = Time % 60
	Time = (Time - dMin) / 60
	local dHour = Time

	if dHour == 24 then dHour = 0 end

	local message = L"QPT,"
	if(GameData.Player.level <= 16) then
		message = message .. L"T1,"
	elseif (GameData.Player.level <= 40) then
	    message = message .. L"T3,"
	else
		message = message .. L"T4,"
	end

	message = message .. QueuePopTimer.careers[GameData.Player.career.line] ..L","
	message = message .. wstring.format(L"%02d:%02d:%02d", dHour, dMin, dSec)
	EA_ChatWindow.Print(message, SystemData.ChatLogFilters.CHANNEL_9)

end

function QueuePopTimer.OnChatLogUpdated(updateType, filterType)
	if (updateType ~= SystemData.TextLogUpdate.ADDED) then return end
	if (filterType ~= SystemData.ChatLogFilters.CHANNEL_9) then return end

	local _, filterId, text = TextLogGetEntry( "Chat", TextLogGetNumEntries("Chat") - 1 );
	text = towstring(text);


	if not text:find(L"QPT") then return end

	local tier,archetype,hour,mini,sec = text:match( L"QPT,([^%.]-),([^%.]-),(%d-):(%d-):(%d+)" );

	local playerTier = ""
	hour = tonumber(hour)
	mini = tonumber(mini)
	sec = tonumber(sec)

	if(GameData.Player.level <= 16) then
		playerTier = L"T1"
	elseif (GameData.Player.level <= 40) then
	    playerTier =  L"T3"
	else
		playerTier =  L"T4"
	end

	if (playerTier == tier and QueuePopTimer.careers[GameData.Player.career.line] == archetype) then 
		local timeInSec = (hour * 60 * 60) + (mini * 60) + sec
		table.insert(QueuePopTimer.waitTimes, {time = timeInSec, added = GetComputerTime()})

		local meanTime = QueuePopTimer.mean(QueuePopTimer.waitTimes)
		local timer, Time = 0, meanTime
		local dSec = Time % 60
		Time = (Time - dSec) / 60
		local dMin = Time % 60
		Time = (Time - dMin) / 60
		local dHour = Time


		if (dHour == 0 and dMin == 0) then
			QueuePopTimer.currentWaitTime = L"Estimated wait time: " .. wstring.format(L"%02d", dSec) .. L" sec"
		elseif (dHour == 0) then
		    QueuePopTimer.currentWaitTime = L"Estimated wait time: " .. wstring.format(L"%02d:%02d", dMin, dSec) .. L" min"
		else
			QueuePopTimer.currentWaitTime = L"Estimated wait time: " .. wstring.format(L"%02d:%02d:%02d", dHour, dMin, dSec) .. L" h"
		end

		QueuePopTimer.CleanWaitTimes()
		
	end

end

function QueuePopTimer.CleanWaitTimes()
	local removedKeys = {}
	local time = GetComputerTime()
	for k,v in pairs(QueuePopTimer.waitTimes) do
    	if(time >= v.added) then
			if(time - v.added >= 900) then
				table.insert(removedKeys,k)
			end
		else
			--a new day has begun while we waited
			local elapsedTime = time + (86400 - v.added)
			if(elapsedTime >= 900) then
				table.insert(removedKeys,k)
			end
		end
  	end

  	for _,v in pairs(removedKeys) do
  		QueuePopTimer.waitTimes[v] = nil
  	end
end

function QueuePopTimer.Update()
	if(Tooltips.curMouseOverWindow == "CMapWindowMapScenarioQueue") then
		Tooltips.SetExtraText("DefaultTooltip", "ActionText", "ActionTextLine", QueuePopTimer.currentWaitTime, nil)
		Tooltips.Finalize()
    end
end

function QueuePopTimer.mean( t )
  local sum = 0
  local count= 0

  for k,v in pairs(t) do
    if type(v.time) == 'number' then
      sum = sum + v.time
      count = count + 1
    end
  end

  return (sum / count)
end

