TTitan = {}
TTitan.ShowButton = true
if not TTitan.Settings then TTitan.Settings = {} end

-- setup default settings, don't forget to add to TTitan.CheckSettings() function below
TTitan.DefaultSettings = {
	["showbutton"] = true,
	["hidecompleted"] = true,
}

TTitan.Type =
{
	BESTIARY = 1,
	HISTORY = 2,
	NOTEWORTHY = 3,
}

function TTitan.Init()
	LibSlash.RegisterSlashCmd("ttitan", function(input)  TTitan.SlashCmd(input) end)
	LibSlash.RegisterSlashCmd("tometitan", function(input)  TTitan.SlashCmd(input) end)

	RegisterEventHandler(SystemData.Events.LOADING_END, "TTitan.Data.Load")
	RegisterEventHandler(SystemData.Events.RELOAD_INTERFACE, "TTitan.Data.Load")
	RegisterEventHandler(SystemData.Events.TOME_ALERT_ADDED, "TTitan.Data.OnTomeAlertAdded")
	RegisterEventHandler(SystemData.Events.TOGGLE_WORLD_MAP_WINDOW, "TTitan.Data.OnWorldMapToggle")
	
	TTitan.CheckSettings() 
end

-- This is for future TT versions if you add any new settings which need to be saved/loaded, they needed to be added in here and to the DefaultSettings table above.
-- This will insure the default setting is loaded since obviously a new setting won't have a value stored in the SavedVariables.lua (thus they will == nil)
function TTitan.CheckSettings()
	if TTitan.Settings["showbutton"] == nil then TTitan.Settings["showbutton"] = TTitan.DefaultSettings["showbutton"] end
	if TTitan.Settings["hidecompleted"] == nil then TTitan.Settings["hidecompleted"] = TTitan.DefaultSettings["hidecompleted"] end
end

function TTitan.Print(txt)
    EA_ChatWindow.Print(towstring(tostring(txt)));
end

function TTitan.SlashCmd(input) -- Handles the /ttitan commands

	-- ==========================
	-- Unified ToK-only search
	-- /ttitan find text
	-- /ttitan find "text with spaces"
	-- ==========================
	if string.sub(input, 1, 4) == "find" then
		local term = string.match(input, '^find%s+"(.-)"%s*$') or string.match(input, "^find%s+(.+)$")
		if not term or term == "" then
			TTitan.Print([[Usage: /ttitan find <text>   OR   /ttitan find "text with spaces"]])
		else
			if TTitan.Data and TTitan.Data.FindTokAll then
				TTitan.Data.FindTokAll(term)
			else
				TTitan.Print("FindTokAll() not loaded. Check TTitan_Data.lua.")
			end
		end
		return
	end

	if input == "findbestiaryids" then
		if TTitan.Data and TTitan.Data.FindTaggedBestiaryIds then
			TTitan.Data.FindTaggedBestiaryIds()
		else
			TTitan.Print("FindTaggedBestiaryIds() not loaded. Check TTitan_Data.lua.")
		end
		return
	end

	if string.sub(input, 1, 5) == "icons" then
		if TTitan.IconBrowser and TTitan.IconBrowser.SlashCmd then
			TTitan.IconBrowser.SlashCmd(input)
		else
			TTitan.Print("Icon browser is not loaded. Check TTitan_IconBrowser.lua.")
		end
		return
	end

	-- Existing commands
	if input == "" then
		TTitan.UI.ToggleShowing()

	elseif input == "current" then
		TTitan.UI.ExpandCurrentZone()
		TTitan.UI.Show()

	elseif input == "showcompleted" then
		TTitan.UI.ToggleHideCompleted()

	elseif input == "button" then
		TTitan.UI.ToggleButton()

	elseif input == "help" then
		TTitan.Print("-----------------------------------------------------")
		TTitan.Print("----Tome Titan ToK Unlock Helper----")
		TTitan.Print("-------------Main Commands---------------")
		TTitan.Print([[Use "/ttitan" to toggle the helper window on or off.]])
		TTitan.Print([[Use "/ttitan current" open to the current zone.]])
		TTitan.Print([[Use "/ttitan showcompleted" to show entries for completed unlocks. Use again to hide entries for completed unlocks.]])
		TTitan.Print([[Use "/ttitan button" to toggle the button showing on or off.]])
		TTitan.Print([[Use "/ttitan dumpach" for apostrophe debugging in Achievements.]])
		TTitan.Print([[Use "/ttitan find <text>" or /ttitan find "text with spaces" to search ALL Tome unlocks (ToK-only output).]])
		TTitan.Print([[Use "/ttitan icons" to browse icon IDs. Mouse wheel scrolls the icon browser.]])

	elseif input == "debug" then
		debugvar1 = towstring(GameData.Player.zone)
		debugvar2 = GetZoneName(GameData.Player.zone)
		EA_ChatWindow.Print(L"Zone ID: "..debugvar1..L"  -  Zone Name: "..debugvar2)

	elseif input == "zonelist" then
		function zonelistprint(zoneid)
			testvar1 = GetZoneName(zoneid)
			if testvar1 == "" then testvar1 = "None" end
			if testvar1 == GetZoneName(GameData.Player.zone) then EA_ChatWindow.Print(L"Hey this is where you are!") end
			EA_ChatWindow.Print(L"Zone id number: "..zoneid..L" - Zone name: "..testvar1)
		end
		for i=1,300,1 do
			zonelistprint(i)
		end

	else
		TTitan.Print("/ttitan "..input.." is not a valid command, use /ttitan help")
	end
end
