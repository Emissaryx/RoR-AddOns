<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
    <UiMod name="Tome Titan" version="v3.0.4" date="13/07/2026">
	<VersionSettings gameVersion="1.4.8" />
	
        <Author name="RoR: Ardora, Zaru 	
Original: Oscarr/Squigy/Aenathel "/>
        <Description text="Tome Titan is the compiled information of Bestiary, History &amp; Lore, Noteworthy Persons and Achievements sections of your Tome of Knowledge for Return of Reckoning.
Map markers have been added to show the locations of the unlocks, completed pins toggle with the Hide Completed Entries"/>
		
		<WARInfo>
			<Categories>
				<Category name="MAP" />
				<Category name="OTHER" />
			</Categories>
		    <Careers>
		    </Careers>
		</WARInfo>

		<Dependencies>
			<Dependency name="LibSlash" />
        </Dependencies>

		<Files>
			<File name="TTitan.lua" />

			<File name="TTitan_IconBrowser.lua" />
			<File name="TTitan_IconBrowser.xml" />
			<File name="TTitan_UI.lua" />
			<File name="TTitan_UI.xml" />
			<File name="TTitan_TTButton.lua" />
			<File name="TTitan_TTButton.xml" />
			<File name="TTitan_MapPin.xml" />
			<File name="TTitan_Data.lua" />
			
			<File name="TTBar\TTmodules.lua" />

			<File name="Data\Credits.lua" />

			<File name="Data\Bestiary_DvG.lua" />
			<File name="Data\Bestiary_EvC.lua" />
			<File name="Data\Bestiary_HEvDE.lua" />

			<File name="Data\History_DvG.lua" />
			<File name="Data\History_EvC.lua" />
			<File name="Data\History_HEvDE.lua" />

			<File name="Data\Noteworthy_DvG.lua" />
			<File name="Data\Noteworthy_EvC.lua" />
			<File name="Data\Noteworthy_HEvDE.lua" />

			<File name="Data\Dungeons.lua" />
			<File name="Data\Explorations.lua" />
			<File name="Data\Pursuits.lua" />
			<File name="Data\LoTD.lua" />
			<File name="Data\Kills.lua" />
		</Files>

        <OnInitialize>
			<CreateWindow name="TTitanUI" show="false" />
			<CreateWindow name="TTitanTTButtonWindow" show="true" />
			<CreateWindow name="TTitanIconBrowser" show="false" />

			<CallFunction name="TTitan.Init" />
			<CallFunction name="TTitan.UI.Init" />
			
        </OnInitialize>

		<OnUpdate>
			<CallFunction name="TTitan.UI.OnUpdate" />
			<CallFunction name="TTitan.IconBrowser.OnUpdate" />
		</OnUpdate>
		
		<SavedVariables>
			<SavedVariable name="TTitan.Settings" />
		</SavedVariables>
    </UiMod>
</ModuleFile>
