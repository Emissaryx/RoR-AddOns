TTitan.IconBrowser = TTitan.IconBrowser or {}

TTitan.IconBrowser.StartIndex = TTitan.IconBrowser.StartIndex or 1
TTitan.IconBrowser.PageSize = 64
TTitan.IconBrowser.Columns = 8
TTitan.IconBrowser.SlotGapX = 88
TTitan.IconBrowser.SlotGapY = 66
TTitan.IconBrowser.CreatedSlots = false
TTitan.IconBrowser.MaxIconId = 100000
TTitan.IconBrowser.ValidIcons = nil
TTitan.IconBrowser.LastScrollPosition = nil
TTitan.IconBrowser.SyncingScrollbar = false

local function TTitanIconBrowserToWString(value)
	return towstring(tostring(value or ""))
end

function TTitan.IconBrowser.Initialize()
	LabelSetText("TTitanIconBrowserTitle", L"Icon Browser")
	LabelSetText("TTitanIconBrowserHint", L"Click an icon to print its ID.")
	TTitan.IconBrowser.EnsureSlots()
end

function TTitan.IconBrowser.IsMissingIcon(texture, x, y, missingTexture, missingX, missingY)
	if not texture then
		return true
	end

	return texture == missingTexture and x == missingX and y == missingY
end

function TTitan.IconBrowser.BuildIconList()
	if TTitan.IconBrowser.ValidIcons then
		return
	end

	local missingTexture, missingX, missingY = GetIconData(999999)
	TTitan.IconBrowser.ValidIcons = {}

	for iconId = 1, TTitan.IconBrowser.MaxIconId do
		local texture, x, y = GetIconData(iconId)
		if not TTitan.IconBrowser.IsMissingIcon(texture, x, y, missingTexture, missingX, missingY) then
			table.insert(TTitan.IconBrowser.ValidIcons, { id = iconId, texture = texture, x = x, y = y })
		end
	end
end

function TTitan.IconBrowser.EnsureSlots()
	if TTitan.IconBrowser.CreatedSlots then
		return
	end

	for index = 1, TTitan.IconBrowser.PageSize do
		local slotName = "TTitanIconBrowserSlot" .. index
		CreateWindowFromTemplate(slotName, "TTitanIconBrowserSlot", "TTitanIconBrowserGrid")
		WindowSetId(slotName, index)
		WindowClearAnchors(slotName)

		local col = (index - 1) % TTitan.IconBrowser.Columns
		local row = math.floor((index - 1) / TTitan.IconBrowser.Columns)
		WindowAddAnchor(slotName, "topleft", "TTitanIconBrowserGrid", "topleft", col * TTitan.IconBrowser.SlotGapX, row * TTitan.IconBrowser.SlotGapY)
	end

	TTitan.IconBrowser.CreatedSlots = true
end

function TTitan.IconBrowser.Refresh()
	TTitan.IconBrowser.BuildIconList()
	TTitan.IconBrowser.EnsureSlots()

	TTitan.IconBrowser.ClampStartIndex()

	for index = 1, TTitan.IconBrowser.PageSize do
		local iconData = TTitan.IconBrowser.ValidIcons[TTitan.IconBrowser.StartIndex + index - 1]
		local slotName = "TTitanIconBrowserSlot" .. index

		if iconData then
			WindowSetId(slotName, iconData.id)
			DynamicImageSetTexture(slotName .. "Icon", iconData.texture, iconData.x, iconData.y)
			WindowSetAlpha(slotName .. "Icon", 1)
			WindowSetShowing(slotName, true)
		else
			WindowSetAlpha(slotName .. "Icon", 0)
			WindowSetShowing(slotName, false)
		end
	end

	TTitan.IconBrowser.UpdateScrollbar()
end

function TTitan.IconBrowser.ClampStartIndex()
	local maxStartIndex = TTitan.IconBrowser.GetMaxStartIndex()

	if TTitan.IconBrowser.StartIndex < 1 then
		TTitan.IconBrowser.StartIndex = 1
	elseif TTitan.IconBrowser.StartIndex > maxStartIndex then
		TTitan.IconBrowser.StartIndex = maxStartIndex
	end
end

function TTitan.IconBrowser.GetMaxStartIndex()
	local iconCount = 0

	if TTitan.IconBrowser.ValidIcons then
		iconCount = #TTitan.IconBrowser.ValidIcons
	end

	return math.max(1, iconCount - TTitan.IconBrowser.PageSize + 1)
end

function TTitan.IconBrowser.UpdateScrollbar()
	local scrollbarName = "TTitanIconBrowserScrollbar"
	local maxStartIndex = TTitan.IconBrowser.GetMaxStartIndex()

	TTitan.IconBrowser.SyncingScrollbar = true
	VerticalScrollbarSetMaxScrollPosition(scrollbarName, maxStartIndex)
	VerticalScrollbarSetPageSize(scrollbarName, TTitan.IconBrowser.Columns)
	VerticalScrollbarSetLineSize(scrollbarName, TTitan.IconBrowser.PageSize)
	VerticalScrollbarSetScrollPosition(scrollbarName, TTitan.IconBrowser.StartIndex)
	TTitan.IconBrowser.LastScrollPosition = TTitan.IconBrowser.StartIndex
	TTitan.IconBrowser.SyncingScrollbar = false
end

function TTitan.IconBrowser.Show(startId)
	if startId then
		TTitan.IconBrowser.BuildIconList()
		TTitan.IconBrowser.StartIndex = TTitan.IconBrowser.FindIconIndex(startId)
	end

	TTitan.IconBrowser.Refresh()
	WindowSetShowing("TTitanIconBrowser", true)
end

function TTitan.IconBrowser.Hide()
	WindowSetShowing("TTitanIconBrowser", false)
end

function TTitan.IconBrowser.ChangePage(amount)
	TTitan.IconBrowser.StartIndex = TTitan.IconBrowser.StartIndex + amount
	TTitan.IconBrowser.Refresh()
end

function TTitan.IconBrowser.Prev()
	TTitan.IconBrowser.ChangePage(-TTitan.IconBrowser.Columns)
end

function TTitan.IconBrowser.Next()
	TTitan.IconBrowser.ChangePage(TTitan.IconBrowser.Columns)
end

function TTitan.IconBrowser.OnMouseWheel(x, y, delta, flags)
	if delta < 0 then
		TTitan.IconBrowser.Next()
	elseif delta > 0 then
		TTitan.IconBrowser.Prev()
	end
end

function TTitan.IconBrowser.FindIconIndex(iconId)
	for index, iconData in ipairs(TTitan.IconBrowser.ValidIcons or {}) do
		if iconData.id >= iconId then
			return index
		end
	end

	return TTitan.IconBrowser.GetMaxStartIndex()
end

function TTitan.IconBrowser.GetScrollbarStartIndex()
	local scrollbarName = "TTitanIconBrowserScrollbar"
	local rawPosition = VerticalScrollbarGetScrollPosition(scrollbarName) or 1
	local maxStartIndex = TTitan.IconBrowser.GetMaxStartIndex()

	if rawPosition <= 1 and maxStartIndex > 1 then
		return 1 + math.floor(rawPosition * (maxStartIndex - 1) + 0.5)
	end

	return math.floor(rawPosition + 0.5)
end

function TTitan.IconBrowser.OnScrollbarChanged()
	if TTitan.IconBrowser.SyncingScrollbar then
		return
	end

	local startIndex = TTitan.IconBrowser.GetScrollbarStartIndex()
	if startIndex ~= TTitan.IconBrowser.StartIndex then
		TTitan.IconBrowser.StartIndex = startIndex
		TTitan.IconBrowser.Refresh()
	end
end

function TTitan.IconBrowser.OnUpdate()
	if not WindowGetShowing("TTitanIconBrowser") or TTitan.IconBrowser.SyncingScrollbar then
		return
	end

	local startIndex = TTitan.IconBrowser.GetScrollbarStartIndex()
	if startIndex ~= TTitan.IconBrowser.LastScrollPosition then
		TTitan.IconBrowser.LastScrollPosition = startIndex
		TTitan.IconBrowser.StartIndex = startIndex
		TTitan.IconBrowser.Refresh()
	end
end

function TTitan.IconBrowser.SlotMouseOver()
	local iconId = WindowGetId(SystemData.ActiveWindow.name)
	Tooltips.CreateTextOnlyTooltip(SystemData.ActiveWindow.name)
	Tooltips.SetTooltipText(1, 1, TTitanIconBrowserToWString("Icon ID: " .. iconId))
	Tooltips.Finalize()
	Tooltips.AnchorTooltip(Tooltips.ANCHOR_CURSOR)
end

function TTitan.IconBrowser.SlotClick()
	local iconId = WindowGetId(SystemData.ActiveWindow.name)
	TTitan.Print("Selected icon ID: " .. tostring(iconId))
end

function TTitan.IconBrowser.SlashCmd(input)
	local startId = tonumber(string.match(input or "", "^icons%s+(%d+)%s*$"))
	TTitan.IconBrowser.Show(startId)
end
