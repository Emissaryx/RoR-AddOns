TTitan.Data = {}

TTitan.Data.Realm =
{
	ORDER = GameData.Realm.ORDER,
	DESTRUCTION = GameData.Realm.DESTRUCTION,
}

TTitan.Data.MapPins = {}

TTitan.Data.PinSize = 32				-- change once, affects all pins
TTitan.Data.PinBorderPadding = 4
TTitan.Data.PinTooltip = {}				-- pinName -> entry name (wstring)
TTitan.Data.PinTooltipText = {}			-- pinName -> unlock instructions (wstring)
TTitan.Data.IconNativeSize = 64			-- WAR icon textures are typically 64x64


TTitan.Data.ZoneMapBounds =
{
	-- zoneId = { minX, minY, maxX, maxY }
	[36] = { minX = 21500, minY = 20830, maxX = 43800, maxY = 43125 }, -- Dragonback Pass
	[50] = { minX = 16400, minY = 16388, maxX = 49150, maxY = 49120 }, -- Hunter's Vale
	[60] = { minX = 16240, minY = 27425, maxX = 47935, maxY = 59120 }, -- Mount Gunbad
	[61] = { minX = 15529, minY = 11978, maxX = 49571, maxY = 46097 }, -- Karak Eight Peaks
	[62] = { minX = 3574, minY = 6478, maxX = 47561, maxY = 50464 }, -- Karaz-a-Karak
	[96] = { minX = 2678, minY = 496, maxX = 53330, maxY = 51147 }, -- Karak Eight Peaks Da Deeps
	[97] = { minX = 5199, minY = 10736, maxX = 57030, maxY = 62567 }, -- Karaz-a-Karak Middle Deeps
	[152] = { minX = 31940, minY = 27181, maxX = 38620, maxY = 33820}, -- The Sewers of Altdorf (South Wing)
	[156] = { minX = 53126, minY = 25736, maxX = 65631, maxY = 38234 }, -- Sacellum Dungeons (East Wing)
	[160] = { minX = 0, minY = -6000, maxX = 64700, maxY = 58690 }, -- Bastion Stair
	[161] = { minX = 10840, minY = 15720, maxX = 54880, maxY = 59756 }, -- The Inevitable City
	[162] = { minX = 6295, minY = 14085, maxX = 48010, maxY = 55820 }, -- Altdorf
	[169] = { minX = 36680, minY = 29153, maxX = 44831, maxY = 37308}, -- The Sewers of Altdorf (Middle Wing)
}

TTitan.Data.PinIcons =
{
    -- symbolic name        -- WAR icon texture
    TTitan_Pin_Bestiary		= "icon000937",
    TTitan_Pin_History		= "icon000583",
    TTitan_Pin_Noteworthy	= "icon000779",
	TTitan_Pin_Dungeons		= "icon000749",
	TTitan_Pin_Exploration	= "icon000732",
	TTitan_Pin_Pursuits		= "icon000761",

    -- fallback
    Default               = "icon000278",
}

TTitan.Data.MapWatcherActive = false
TTitan.Data.LastBuiltMap = nil

function TTitan.Data.ClearMapPins()
    for _, pin in pairs(TTitan.Data.MapPins) do
        if DoesWindowExist(pin) then
            DestroyWindow(pin)
        end
    end
    TTitan.Data.MapPins = {}
    TTitan.Data.PinTooltip = {}
    TTitan.Data.PinTooltipText = {}
end

function TTitan.Data.CreateMapPin(pin)
    local mapWindow = "EA_Window_WorldMapZoneViewMapDisplay"
    if not DoesWindowExist(mapWindow) then return end

    local mapWidth, mapHeight = WindowGetDimensions(mapWindow)
    if mapWidth == 0 or mapHeight == 0 then return end

	local nx, ny

	local bounds = TTitan.Data.ZoneMapBounds and TTitan.Data.ZoneMapBounds[pin.zoneId]
	if bounds then
		local dx = (bounds.maxX - bounds.minX)
		local dy = (bounds.maxY - bounds.minY)

		if dx ~= 0 and dy ~= 0 then
			nx = (pin.x - bounds.minX) / dx
			ny = (pin.y - bounds.minY) / dy
		else
			-- bad bounds entry; fall back
			nx = pin.x / 65535
			ny = pin.y / 65535
		end
	else
		-- standard zones
		nx = pin.x / 65535
		ny = pin.y / 65535
	end

    local pinName = "TTitanMapPin_" .. tostring(#TTitan.Data.MapPins + 1)
    CreateWindowFromTemplate(pinName, "TTitanMapPin", mapWindow)
    WindowSetShowing(pinName, true)

    -- Centralised size
    local size = TTitan.Data.PinSize or 32
	local padding = TTitan.Data.PinBorderPadding or 4
    local half = math.floor(size / 2)
    WindowSetDimensions(pinName, size, size)

    -- Position
    WindowClearAnchors(pinName)
    WindowAddAnchor(
        pinName,
        "topleft",
        mapWindow,
        "topleft",
        (nx * mapWidth) - half,
        (ny * mapHeight) - half
    )

    -- =========================
    -- Border (checkbox style)
    -- =========================
    local borderWin = pinName .. "Border"
    if DoesWindowExist(borderWin) then
        -- Make sure border fills the parent exactly (template also does this; we force it anyway)
        WindowClearAnchors(borderWin)
        WindowAddAnchor(borderWin, "topleft",     pinName, "topleft",     0, 0)
        WindowAddAnchor(borderWin, "bottomright", pinName, "bottomright", 0, 0)

        DynamicImageSetTexture(borderWin, "icon000058", 2, 2)
        WindowSetShowing(borderWin, true)

        -- Scale border texture to match the PIN SIZE
        local native = TTitan.Data.IconNativeSize or 64
        local borderScale = size / 17
        if borderScale <= 0 then borderScale = 1 end
        DynamicImageSetTextureScale(borderWin, borderScale)
    end

    -- =========================
    -- Main pin icon (inset)
    -- =========================
    local iconWin = pinName .. "Icon"
    if DoesWindowExist(iconWin) then
        local pad = TTitan.Data.PinBorderPadding

        -- Clamp padding so it can’t invert/zero the inner area
        local maxPad = math.floor((size - 4) / 2)  -- leaves at least 4px inner size
        if pad > maxPad then pad = maxPad end
        if pad < 0 then pad = 0 end

        -- Force icon anchors to create a true inset area (do not rely on XML constants)
        WindowClearAnchors(iconWin)
        WindowAddAnchor(iconWin, "topleft",     pinName, "topleft",     pad,  pad)
        WindowAddAnchor(iconWin, "bottomright", pinName, "bottomright", -pad, -pad)

        -- Resolve icon texture
        local iconKey = pin.icon or "Default"
        local texture = TTitan.Data.PinIcons[iconKey] or TTitan.Data.PinIcons.Default
        DynamicImageSetTexture(iconWin, texture, 0, 0)
        WindowSetShowing(iconWin, true)

        -- CRITICAL FIX:
        -- Scale to the *inner* icon area, not the full pin size.
        local native = TTitan.Data.IconNativeSize or 64
        local innerSize = size - (pad * 2)
        local scale = innerSize / native
        if scale <= 0 then scale = 1 end
        DynamicImageSetTextureScale(iconWin, scale)
    end

    -- Tooltip mapping (parent + children)
    local tip = pin.tooltip or L""
    local tipText = L""
    if pin.entryText and pin.entryText ~= "" then
        local rawText = string.gsub(pin.entryText, "^%s*(.-)%s*$", "%1")
        if pin.icon == "TTitan_Pin_Bestiary" then
            rawText = string.gsub(rawText, "^[^\r\n]*[\r\n]+%s*", "")
        end
        rawText = string.gsub(rawText, "(%d+%s*,%s*%d+)%s*%-%s*[Ii]n%s+[^\r\n]+", "%1")
        tipText = towstring(rawText)
    end
    for _, w in ipairs({ pinName, pinName .. "Icon", pinName .. "Border" }) do
        if w == pinName or DoesWindowExist(w) then
            TTitan.Data.PinTooltip[w] = tip
            TTitan.Data.PinTooltipText[w] = tipText
        end
    end

    table.insert(TTitan.Data.MapPins, pinName)
end

function TTitan.Data.GetMapPinsForZone(zoneId)
    local pins = {}
	
	local hideCompleted = (TTitan.Settings and TTitan.Settings["hidecompleted"] == true)

    for _, dataSource in ipairs({
        -- Bestiary Data
        TTitan.Data.BestiaryDvG,
        TTitan.Data.BestiaryEvC,
        TTitan.Data.BestiaryHEvDE,
        TTitan.Data.LoTD,

        -- History & Lore Data
        TTitan.Data.HistoryDvG,
        TTitan.Data.HistoryEvC,
        TTitan.Data.HistoryHEvDE,

        -- Noteworthy Persons Data
        TTitan.Data.NoteworthyDvG,
        TTitan.Data.NoteworthyEvC,
        TTitan.Data.NoteworthyHEvDE,

        -- Achievements Data
		TTitan.Data.Dungeons,
        TTitan.Data.Pursuits,
        TTitan.Data.Explorations,
    }) do
        if dataSource and dataSource.RawData then
            for _, category in ipairs(dataSource.RawData.categories or {}) do
                for _, entry in ipairs(category.entries or {}) do

                    -- If hideCompleted is enabled, skip entries already marked completed.
                    if entry.mapPins and (not hideCompleted or not entry.completed) then
                        for _, pin in ipairs(entry.mapPins) do
                            if pin.zoneId == zoneId then
                                local enriched = {}
                                for k, v in pairs(pin) do enriched[k] = v end
                                enriched.entryText = entry.text
                                table.insert(pins, enriched)
                            end
                        end
                    end

                end
            end
        end
    end

    return pins
end

function TTitan.Data.MapPinMouseOver()
    local win = SystemData.ActiveWindow.name
    local tip = TTitan.Data.PinTooltip[win]

    if not tip or tip == L"" then return end

    Tooltips.CreateTextOnlyTooltip(win, nil)
    Tooltips.AnchorTooltip(Tooltips.ANCHOR_CURSOR)
    Tooltips.SetTooltipText(1, 1, tip)
    Tooltips.SetTooltipColorDef(1, 1, Tooltips.COLOR_HEADING)
    local text = TTitan.Data.PinTooltipText[win]
    if text and text ~= L"" then
        Tooltips.SetTooltipText(2, 1, text)
    end
    Tooltips.Finalize()
end

function TTitan.Data.MapPinMouseOverEnd()
    Tooltips.ClearTooltip()
end

-- Called by the TOGGLE_WORLD_MAP_WINDOW event
function TTitan.Data.OnWorldMapToggle()
    if not TTitan.Data.MapWatcherActive then
        TTitan.Data.MapWatcherActive = true
        TTitan.Data.LastBuiltMap = nil
        RegisterEventHandler(SystemData.Events.UPDATE_PROCESSED, "TTitan.Data.MapWatcher")
    end
end

-- Runs every frame while the world map is open.
-- Detects zone changes via EA_Window_WorldMap.currentMap and rebuilds pins.
function TTitan.Data.MapWatcher()
    local mapWindow = "EA_Window_WorldMapZoneViewMapDisplay"

    -- Map closed: clean up and stop
    if not DoesWindowExist("EA_Window_WorldMap") or not WindowGetShowing("EA_Window_WorldMap") then
        TTitan.Data.ClearMapPins()
        TTitan.Data.LastBuiltMap = nil
        TTitan.Data.MapWatcherActive = false
        UnregisterEventHandler(SystemData.Events.UPDATE_PROCESSED, "TTitan.Data.MapWatcher")
        return
    end

    -- Zone display must exist and have dimensions
    if not DoesWindowExist(mapWindow) then return end
    local w, h = WindowGetDimensions(mapWindow)
    if w == 0 or h == 0 then return end

    -- Detect zone change
    local currentMap = (EA_Window_WorldMap and EA_Window_WorldMap.currentMap) or GameData.Player.zone
    if currentMap == TTitan.Data.LastBuiltMap then return end

    -- Zone changed: rebuild pins
    TTitan.Data.LastBuiltMap = currentMap
    TTitan.Data.ClearMapPins()
    local pins = TTitan.Data.GetMapPinsForZone(currentMap)
    for _, pin in ipairs(pins) do
        TTitan.Data.CreateMapPin(pin)
    end
end

function TTitan.Data.Load()
	TTitan.Data.FilterAll()
	TTitan.Data.SynchronizeAll()
end

function TTitan.Data.FilterAll()
	for _, dataSource in ipairs({ TTitan.Data.BestiaryDvG, TTitan.Data.BestiaryEvC, TTitan.Data.BestiaryHEvDE, TTitan.Data.LoTD, TTitan.Data.HistoryDvG, TTitan.Data.HistoryEvC, TTitan.Data.HistoryHEvDE, TTitan.Data.NoteworthyDvG, TTitan.Data.NoteworthyEvC, TTitan.Data.NoteworthyHEvDE, TTitan.Data.Dungeons, TTitan.Data.Explorations, TTitan.Data.Pursuits }) do
		dataSource.FilterData()
	end
end

-- converts to lua string, trims, normalises common punctuation, and lowercases
function TTitan.Data.CleanString(v)
	local s = ""

	-- Prefer proper conversion for wstring
	if type(v) == "wstring" and WStringToString then
		local ok, out = pcall(WStringToString, v)
		if ok and out then s = out else s = "" end
	else
		s = tostring(v or "")
	end

	-- Trim
	s = string.gsub(s, "^%s*(.-)%s*$", "%1")

	-- Normalise apostrophe variants + a couple of common “invisible” offenders
	-- UTF-8 curly quotes
	s = s:gsub("\226\128\153", "'")  -- ’
	     :gsub("\226\128\152", "'")  -- ‘
	-- NBSP -> normal space
	s = s:gsub("\194\160", " ")
	-- Collapse whitespace
	s = s:gsub("%s+", " ")
	
	s = s:gsub(string.char(0x19), "'")

	-- Lowercase
	s = string.lower(s)

	return s
end


function TTitan.Data.FilterByRealm(data)
	for categoryIndex, category in ipairs(data.categories) do
		local entries = {}

		for entryIndex, entry in ipairs(category.entries) do
			if not entry.realm or entry.realm == GameData.Player.realm then
				table.insert(entries, entry)
			end
		end

		category.entries = entries
	end
end

function TTitan.Data.SynchronizeAll()
	TTitan.Data.SynchronizeAchievements()
	TTitan.Data.SynchronizeBestiary()
	TTitan.Data.SynchronizeHistoryAndLore()
	TTitan.Data.SynchronizeNoteworthyPersons()
end

function TTitan.Data.ScanAchievements()
	local entries = {}

	for _, typeData in ipairs(TomeGetAchievementsTOC()) do
		for _, subTypeData in ipairs(typeData.subtypes) do

			if subTypeData.isUnlocked then
				currentSubTypeData = TomeGetAchievementsSubTypeData(subTypeData.id)

				for _, entryData in ipairs(currentSubTypeData.entries) do
					if entryData.isUnlocked then
						local name = TTitan.Data.CleanString(entryData.name)
						entries[name] = true
					end
				end
			end
		end
	end

	return entries
end

function TTitan.Data.SynchronizeAchievements()
	local achievements = TTitan.Data.ScanAchievements()
	for _, dataSource in ipairs({ TTitan.Data.Explorations, TTitan.Data.Pursuits, TTitan.Data.Dungeons }) do
		local data = dataSource.RawData

		for _, category in ipairs(data.categories) do
			category.completed = true

			for _, entry in ipairs(category.entries) do
				local name = TTitan.Data.CleanString(entry.name)
				entry.completed = name ~= nil and achievements[name] ~= nil
				category.completed = category.completed and entry.completed
			end
		end

		dataSource.RawData = data
	end
end

function TTitan.Data.ScanBestiary()
	local entries = {}
	entries.byBestiaryId = {}
	entries.byBestiaryName = {}

	for _, typeData in ipairs(TomeGetBestiaryTOC()) do
		for _, subtypeData in ipairs(typeData.subtypes) do

		  	if(TomeIsBestiarySubTypeUnlocked(subtypeData.id) == true) then
				local currentSubtypeData = TomeGetBestiarySubTypeData(subtypeData.id)

				for _, speciesData in ipairs(currentSubtypeData.species) do
				  	if(TomeIsBestiarySpeciesUnlocked(speciesData.id) == true) then
						local currentSpeciesData = TomeGetBestiarySpeciesData(speciesData.id)

						for _, taskData in ipairs(currentSpeciesData.tasks) do
							if taskData.isComplete then
								local taskName = TTitan.Data.CleanString(taskData.text)
								entries[taskName] = true

								local speciesId = tonumber(speciesData.id)
								if speciesId ~= nil then
									if not entries.byBestiaryId[speciesId] then
										entries.byBestiaryId[speciesId] = {}
									end
									entries.byBestiaryId[speciesId][taskName] = true
								end

								local speciesName = TTitan.Data.CleanString((currentSpeciesData and currentSpeciesData.name) or speciesData.name)
								if speciesName ~= nil and speciesName ~= "" then
									if not entries.byBestiaryName[speciesName] then
										entries.byBestiaryName[speciesName] = {}
									end
									entries.byBestiaryName[speciesName][taskName] = true
								end
							end
						end
					end
				end
			end
		end
	end

	return entries
end

function TTitan.Data.SynchronizeBestiary()
	local bestiary = TTitan.Data.ScanBestiary()
	for _, dataSource in ipairs({ TTitan.Data.BestiaryDvG, TTitan.Data.BestiaryEvC, TTitan.Data.BestiaryHEvDE }) do
		local data = dataSource.RawData

		for _, category in ipairs(data.categories) do
			category.completed = true

			for _, entry in ipairs(category.entries) do
				if entry.noAutoSync then
					entry.completed = false
				else
					local entryText = tostring(entry.text)
					local taskName = TTitan.Data.CleanString(entryText:match("[^-]+- (.-)\n"));
					entry.completed = false

					local bestiaryId = tonumber(entry.tomeBestiaryId)
					if bestiaryId ~= nil and bestiary.byBestiaryId[bestiaryId] then
						entry.completed = taskName ~= nil and bestiary.byBestiaryId[bestiaryId][taskName] == true
					end

					if not entry.completed and entry.tomeBestiaryName then
						local bestiaryName = TTitan.Data.CleanString(entry.tomeBestiaryName)
						entry.completed = taskName ~= nil
							and bestiary.byBestiaryName[bestiaryName] ~= nil
							and bestiary.byBestiaryName[bestiaryName][taskName] == true
					end

					if bestiaryId == nil and not entry.tomeBestiaryName then
						entry.completed = taskName ~= nil and bestiary[taskName] ~= nil
					end
				end
				category.completed = category.completed and entry.completed
			end
		end
	end
end

function TTitan.Data.ScanHistoryAndLore()
	local entries = {}

	for _, pairingData in ipairs(TomeGetHistoryAndLoreTOC()) do
		for _, tierData in ipairs(pairingData.tiers) do
			for _, zoneData in ipairs(tierData.zones) do
				local currentZoneData = TomeGetHistoryAndLoreZoneData(zoneData.id)

				for _, entryData in ipairs(currentZoneData.entries) do
					if entryData.isUnlocked then
						local name = TTitan.Data.CleanString(entryData.name)
						entries[name] = true
					end
				end
			end
		end
	end

	return entries
end

function TTitan.Data.SynchronizeHistoryAndLore()
	local historyAndLore = TTitan.Data.ScanHistoryAndLore()
	for _, dataSource in ipairs({ TTitan.Data.HistoryDvG, TTitan.Data.HistoryEvC, TTitan.Data.HistoryHEvDE }) do
		local data = dataSource.RawData

		for _, category in ipairs(data.categories) do
			category.completed = true

			for _, entry in ipairs(category.entries) do
				local name = TTitan.Data.CleanString(entry.name)
				entry.completed = name ~= nil and historyAndLore[name] ~= nil
				category.completed = category.completed and entry.completed
			end
		end
	end
end

function TTitan.Data.ScanNoteworthyPersons()
	local entries = {}

	for _, pairingData in ipairs(TomeGetNoteworthyPersonsTOC()) do
		for _, tierData in ipairs(pairingData.tiers) do
			for _, zoneData in ipairs(tierData.zones) do
				local currentZoneData = TomeGetNoteworthyPersonsZoneData(zoneData.id)

				for _, entryData in ipairs(currentZoneData.entries) do
					if entryData.isUnlocked then
						local name = TTitan.Data.CleanString(entryData.name)
						entries[name] = true
					end
				end
			end
		end
	end

	return entries
end

function TTitan.Data.SynchronizeNoteworthyPersons()
	local noteworthyPersons = TTitan.Data.ScanNoteworthyPersons()
	for _, dataSource in ipairs({ TTitan.Data.NoteworthyDvG, TTitan.Data.NoteworthyEvC, TTitan.Data.NoteworthyHEvDE }) do
		local data = dataSource.RawData

		for _, category in ipairs(data.categories) do
			category.completed = true

			for _, entry in ipairs(category.entries) do
				local name = TTitan.Data.CleanString(entry.name)
				entry.completed = name ~= nil and noteworthyPersons[name] ~= nil
				category.completed = category.completed and entry.completed
			end
		end

		dataSource.RawData = data
	end
end

function TTitan.Data.OnTomeAlertAdded()
	local alert = DataUtils.GetTomeAlerts()[1]
	if not alert then return end

	if alert.section == GameData.Tome.SECTION_BESTIARY then
		TTitan.Data.SynchronizeBestiary()
		if TTitan.UI.DataSource == TTitan.Data.Kills then
			TTitan.UI.Data = TTitan.Data.Kills.GetData()
		end
		TTitan.UI.PrepareData()
	elseif alert.section == GameData.Tome.SECTION_HISTORY_AND_LORE then
		TTitan.Data.SynchronizeHistoryAndLore()
		TTitan.UI.PrepareData()
	elseif alert.section == GameData.Tome.SECTION_NOTEWORTHY_PERSONS then
		TTitan.Data.SynchronizeNoteworthyPersons()
		TTitan.UI.PrepareData()
	else
		TTitan.Data.SynchronizeAchievements()
		TTitan.UI.PrepareData()
	end

	TTitan.UI.TomeClearNewEntriesCheckForNew()
end

local function TTitan_ToLuaString(v)
	if v == nil then return "" end
	if type(v) == "wstring" and WStringToString then
		local ok, s = pcall(WStringToString, v)
		if ok and s then return s end
	end
	return tostring(v)
end

local function TTitan_HexBytes(s)
	if not s or s == "" then return "" end
	local t = {}
	for i = 1, #s do
		t[#t+1] = string.format("%02X", string.byte(s, i))
	end
	return table.concat(t, " ")
end

local function TTitan_HasApostropheLike(s)
	if not s or s == "" then return false end
	-- ASCII apostrophe
	if s:find("'", 1, true) then return true end
	-- UTF-8 curly apostrophes
	if s:find("\226\128\153", 1, true) then return true end -- ’
	if s:find("\226\128\152", 1, true) then return true end -- ‘
	return false
end


local function _ToStr(v)
	if v == nil then return "" end
	if type(v) == "wstring" and WStringToString then
		local ok, s = pcall(WStringToString, v)
		if ok and s then return s end
	end
	return tostring(v)
end

local function _Hex(s)
	local t = {}
	for i = 1, #s do t[#t+1] = string.format("%02X", string.byte(s, i)) end
	return table.concat(t, " ")
end

function TTitan.Data.FindAchievement(term)
	term = string.lower(tostring(term or ""))

	if not TomeGetAchievementsTOC or not TomeGetAchievementsSubTypeData then
		TTitan.Print("FINDACH: Tome achievement API not available.")
		return
	end

	local found = 0

	for _, typeData in ipairs(TomeGetAchievementsTOC()) do
		for _, subTypeData in ipairs(typeData.subtypes) do
			local st = TomeGetAchievementsSubTypeData(subTypeData.id)
			if st and st.entries then
				for _, entryData in ipairs(st.entries) do
					local raw = _ToStr(entryData.name)
					local rawLower = string.lower(raw)

					if string.find(rawLower, term, 1, true) then
						found = found + 1
						local clean = TTitan.Data.CleanString(entryData.name)
						TTitan.Print("FINDACH: " .. raw)
						TTitan.Print("  unlocked=" .. tostring(entryData.isUnlocked))
						TTitan.Print("  TOKHEX=" .. _Hex(raw))
						TTitan.Print("  CLEAN=" .. tostring(clean))
					end
				end
			end
		end
	end

	TTitan.Print("FINDACH: matches = " .. tostring(found))
end

-- =========================================================
--  ToK-only unified finder: /ttitan find "<term>"
--  Searches and prints ONLY Tome-reported strings:
--    - Achievements (entryData.name)
--    - Bestiary (taskData.text)
--    - History & Lore (entryData.name)
--    - Noteworthy Persons (entryData.name)
--  Output style matches your screenshot.
-- =========================================================

local function TT_Find_ToStr(v)
	if v == nil then return "" end
	if type(v) == "wstring" and WStringToString then
		local ok, s = pcall(WStringToString, v)
		if ok and s then return s end
	end
	return tostring(v)
end

local function TT_Find_HexBytes(s)
	if not s or s == "" then return "" end
	local t = {}
	for i = 1, #s do
		t[#t+1] = string.format("%02X", string.byte(s, i))
	end
	return table.concat(t, " ")
end

local function TT_Find_Trim(s)
	return (string.gsub(tostring(s or ""), "^%s*(.-)%s*$", "%1"))
end

local function TT_Find_PrintBlock(prefix, raw, status, clean)
	TTitan.Print(prefix .. ":" .. raw)
	TTitan.Print("unlocked=" .. tostring(status))
	TTitan.Print("TOKHEX=" .. TT_Find_HexBytes(raw))
	TTitan.Print("CLEAN=" .. tostring(clean))
end

function TTitan.Data.FindTokAll(term)
	term = TT_Find_Trim(term)
	if term == "" then
		TTitan.Print([[Usage: /ttitan find <text>   OR   /ttitan find "text with spaces"]])
		return
	end

	local termLower = string.lower(term)
	local cleanTerm = (TTitan.Data.CleanString and TTitan.Data.CleanString(term)) or string.lower(term)

	TTitan.Print("CLEAN=" .. tostring(cleanTerm))

	local maxPrint = 60
	local printed = 0

	local countAch, countBest, countHist, countNote = 0, 0, 0, 0

	-- -------------------------
	-- Achievements
	-- -------------------------
	if TomeGetAchievementsTOC and TomeGetAchievementsSubTypeData then
		for _, typeData in ipairs(TomeGetAchievementsTOC()) do
			for _, subTypeData in ipairs(typeData.subtypes or {}) do
				local st = TomeGetAchievementsSubTypeData(subTypeData.id)
				if st and st.entries then
					for _, entryData in ipairs(st.entries) do
						local raw = TT_Find_ToStr(entryData.name)
						if raw ~= "" and string.find(string.lower(raw), termLower, 1, true) then
							countAch = countAch + 1
							if printed < maxPrint then
								local clean = TTitan.Data.CleanString(entryData.name)
								TT_Find_PrintBlock("FINDACH", raw, entryData.isUnlocked, clean)
								printed = printed + 1
							end
						end
					end
				end
			end
		end
	end

	-- -------------------------
	-- Bestiary (task text)
	-- -------------------------
	if TomeGetBestiaryTOC and TomeGetBestiarySubTypeData and TomeGetBestiarySpeciesData then
		for _, typeData in ipairs(TomeGetBestiaryTOC()) do
			for _, subtypeData in ipairs(typeData.subtypes or {}) do
				local st = TomeGetBestiarySubTypeData(subtypeData.id)
				if st and st.species then
					for _, speciesData in ipairs(st.species) do
						local sp = TomeGetBestiarySpeciesData(speciesData.id)
						if sp and sp.tasks then
							for _, taskData in ipairs(sp.tasks) do
								local raw = TT_Find_ToStr(taskData.text)
								if raw ~= "" and string.find(string.lower(raw), termLower, 1, true) then
									countBest = countBest + 1
									if printed < maxPrint then
										local clean = TTitan.Data.CleanString(taskData.text)
										-- for Bestiary, completion flag is isComplete
										TT_Find_PrintBlock("FINDBEST", raw, taskData.isComplete, clean)
										TTitan.Print("BESTID=" .. tostring(speciesData.id))
										TTitan.Print("BESTNAME=" .. TT_Find_ToStr((sp and sp.name) or speciesData.name))
										printed = printed + 1
									end
								end
							end
						end
					end
				end
			end
		end
	end

	-- -------------------------
	-- History & Lore
	-- -------------------------
	if TomeGetHistoryAndLoreTOC and TomeGetHistoryAndLoreZoneData then
		for _, pairingData in ipairs(TomeGetHistoryAndLoreTOC()) do
			for _, tierData in ipairs(pairingData.tiers or {}) do
				for _, zoneData in ipairs(tierData.zones or {}) do
					local z = TomeGetHistoryAndLoreZoneData(zoneData.id)
					if z and z.entries then
						for _, entryData in ipairs(z.entries) do
							local raw = TT_Find_ToStr(entryData.name)
							if raw ~= "" and string.find(string.lower(raw), termLower, 1, true) then
								countHist = countHist + 1
								if printed < maxPrint then
									local clean = TTitan.Data.CleanString(entryData.name)
									TT_Find_PrintBlock("FINDHIST", raw, entryData.isUnlocked, clean)
									printed = printed + 1
								end
							end
						end
					end
				end
			end
		end
	end

	-- -------------------------
	-- Noteworthy Persons
	-- -------------------------
	if TomeGetNoteworthyPersonsTOC and TomeGetNoteworthyPersonsZoneData then
		for _, pairingData in ipairs(TomeGetNoteworthyPersonsTOC()) do
			for _, tierData in ipairs(pairingData.tiers or {}) do
				for _, zoneData in ipairs(tierData.zones or {}) do
					local z = TomeGetNoteworthyPersonsZoneData(zoneData.id)
					if z and z.entries then
						for _, entryData in ipairs(z.entries) do
							local raw = TT_Find_ToStr(entryData.name)
							if raw ~= "" and string.find(string.lower(raw), termLower, 1, true) then
								countNote = countNote + 1
								if printed < maxPrint then
									local clean = TTitan.Data.CleanString(entryData.name)
									TT_Find_PrintBlock("FINDNOTE", raw, entryData.isUnlocked, clean)
									printed = printed + 1
								end
							end
						end
					end
				end
			end
		end
	end

	TTitan.Print(string.format("FIND: matches Ach=%d Best=%d Hist=%d Note=%d Total=%d",
		countAch, countBest, countHist, countNote, (countAch + countBest + countHist + countNote)))

	if (countAch + countBest + countHist + countNote) > maxPrint then
		TTitan.Print("FIND: (showing first " .. tostring(maxPrint) .. " results)")
	end
end

function TTitan.Data.FindTaggedBestiaryIds()
	if not TomeGetBestiaryTOC or not TomeGetBestiarySubTypeData or not TomeGetBestiarySpeciesData then
		TTitan.Print("BESTIDS: Tome bestiary API not available.")
		return
	end

	local wanted = {}
	for _, dataSource in ipairs({ TTitan.Data.BestiaryDvG, TTitan.Data.BestiaryEvC, TTitan.Data.BestiaryHEvDE }) do
		local data = dataSource and dataSource.RawData
		for _, category in ipairs((data and data.categories) or {}) do
			for _, entry in ipairs(category.entries or {}) do
				if entry.tomeBestiaryName then
					local clean = TTitan.Data.CleanString(entry.tomeBestiaryName)
					wanted[clean] = TT_Find_ToStr(entry.tomeBestiaryName)
				end
			end
		end
	end

	local found = 0
	for _, typeData in ipairs(TomeGetBestiaryTOC()) do
		for _, subtypeData in ipairs(typeData.subtypes or {}) do
			local st = TomeGetBestiarySubTypeData(subtypeData.id)
			for _, speciesData in ipairs((st and st.species) or {}) do
				local sp = TomeGetBestiarySpeciesData(speciesData.id)
				local rawName = TT_Find_ToStr((sp and sp.name) or speciesData.name)
				local cleanName = TTitan.Data.CleanString(rawName)
				if wanted[cleanName] then
					found = found + 1
					TTitan.Print("BESTIDS: " .. rawName .. " = " .. tostring(speciesData.id))
				end
			end
		end
	end

	TTitan.Print("BESTIDS: matches = " .. tostring(found))
end
