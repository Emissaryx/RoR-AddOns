TTitan.Data.BestiaryEvC = {}

function TTitan.Data.BestiaryEvC.GetData()
	return TTitan.Data.BestiaryEvC.RawData
end

function TTitan.Data.BestiaryEvC.FilterData()
	TTitan.Data.FilterByRealm(TTitan.Data.BestiaryEvC.RawData)
end

TTitan.Data.BestiaryEvC.RawData =
{
	header = L"Beastiary Unlocks - Empire vs Chaos",
	categories =
	{
		{
			name = L"Non Zone-Based",
			entries =
			{
				{
					name = L"Chaos (Title)",
					text = 
[[
Chaos - Complete a Chaos Scenario
"The Sentinel of Sanity"

Win a Maw of Madness Scenario.
]],
				},

				{
					name = L"Empire (Title)",
					text =
[[
Empire - Complete an Empire Scenario
"Man Hunter"

Win a Reikland Hills Scenario.
]],
				},
			},
		},

		{
			name = L"Nordland",
			entries =
			{
				{
					name = L"Beastman (Title)",
					mapPins =
					{
						{
							x = 40500,
							y = 36400,
							zoneId = 106,
							tooltip = L"Beastman, Gor - The Murder Wood",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Beastman, Gor - The Murder Wood
"Road Warden"

40500, 36400

Click on "Herdstone" on the east side of "Murder Wood" major landmark.
]],
				},

				{
					name = L"Beastman (Title)",
					mapPins =
					{
						{
							x = 37100,
							y = 34800,
							zoneId = 106,
							tooltip = L"Beastman, Ungor - Who Wud Murder",
							icon = "TTitan_Pin_Bestiary",
						},
					},


					text =
[[
Beastman, Ungor - Who Wud Murder
"The Brute"

37100, 34800

Click on "Unfortunate Victim" up against the cliff edge next to a large tree.
]],
				},

				{
					name = L"Boar (Title)",
					mapPins =
					{
						{
							x = 55000,
							y = 500,
							zoneId = 106,
							tooltip = L"Boar - Surrounded by Swine",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Boar - Surrounded by Swine
"Huntsman"

55000, 500

Talk to "Hanke the Boar Tackler" standing on a small hill with two other hunters.
]],
				},

				{
					name = L"Bright Wizard (Pocket)",
					mapPins =
					{
						{
							x = 24000,
							y = 11000,
							zoneId = 106,
							tooltip = L"Empire, Bright Wizard - What do We Have Here?",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					tomeBestiaryId = 48,
					tomeBestiaryName = L"Empire, Bright Wizard",
					text =
[[
Empire, Bright Wizard - What do We Have Here?
POCKET ITEM

24000, 11000 - In RvR Lake

Click on "Hidden Scroll" behind a bush against the rocks.

]],
				},

				{
					name = L"Hound (Title)",
					mapPins =
					{
						{
							x = 56500,
							y = 42000,
							zoneId = 106,
							tooltip = L"Hound - Hungry, Hungry Hounds",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Hound - Hungry, Hungry Hounds
"The Hound Hunter"

56500, 42000

Click on "Kibbles 'n Scraps" a sack at the bottom of a tree on the edge of a small camp.
]],
				},

				{
					name = L"Plague Victim (Title)",
					mapPins =
					{
						{
							x = 58800,
							y = 11600,
							zoneId = 106,
							tooltip = L"Plague Victim - People Pop Up",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Plague Victim - People Pop Up
"The Infected"

58800, 11600

Kill "Plagued Farmer" mob lying down behind a tree.
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Skeleton (Title)",
					mapPins =
					{
						{
							x = 19400,
							y = 39400,
							zoneId = 106,
							tooltip = L"Skeleton - What Lay Ahead",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Skeleton - What Lay Ahead
"Skeleton Hunter"

19400, 39400

Click on "Gravestone" on the left side before you enter "Grimmenhagen Barrows" major landmark.
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Spider (Tactic)",
					mapPins =
					{
						{
							x = 48900,
							y = 39500,
							zoneId = 106,
							tooltip = L"Spider, Giant - Fast Finds",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Spider, Giant - Fast Finds
BESTIAL TOME TACTIC

48900, 39500

Kill "Grey Wolf Spider" or "Scarlet Wolf Spider" mobs around this area for the Kill Collector at "Authun's Host", Chaos Chapter 4 camp.
]],
				},
			},
		},

		{
			name = L"Norsca",
			entries =
			{
				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Plague Victim (Tactic)",
										mapPins =
					{
						{
							x = 18500,
							y = 48600,
							zoneId = 100,
							tooltip = L"Plague Victim - Epic Epidemic",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Plague Victim - Epic Epidemic
CHAOS TOME TACTIC

18500, 48600

Talk to "Mathis Rittenhouse" sitting on a rock, at the bottom of the cliff.
]],
				},
				
				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Plage Victim (Tactic)",
					mapPins =
					{
						{
							x = 51600,
							y = 57000,
							zoneId = 100,
							tooltip = L"Plague Victim - Epic Epidemic",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Plague Victim - Epic Epidemic
CHAOS TOME TACTIC

51600, 57000

Talk to "Sister Raffaela" just SE of "Jaarpen" minor landmark. She's sitting on the ground near the hills next to some bushes.
]],
				},
				
				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Skeleton (Title)",
					mapPins =
					{
						{
							x = 33000,
							y = 7100,
							zoneId = 100,
							tooltip = L"Skeleton - What Lay Ahead",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Skeleton - What Lay Ahead
"The Skeleton Hunter"

33000, 7100

Click on "Gravestone" in the cemetery outside of "Thorshafn Crypt" Major Landmark.
]],
				},

				{
					name = L"Spirit Host (Title)",
					mapPins =
					{
						{
							x = 48300,
							y = 44400,
							zoneId = 100,
							tooltip = L"Spirit Host - Place of the Dead",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Spirit Host - Place of the Dead
"The Fearless"

48300, 44400

Click on "Crypt Gate" the entry gate to the "Amund's Barrow" major landmark.
]],
				},

				{
					name = L"Zealot (Pocket)",
					mapPins =
					{
						{
							x = 42000,
							y = 63000,
							zoneId = 100,
							tooltip = L"Chaos, Zealot - What do We Have Here?",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					tomeBestiaryId = 17,
					tomeBestiaryName = L"Chaos, Zealot",
					text =
[[
Chaos, Zealot - What do We Have Here?
POCKET ITEM

42000, 63000 - In RvR Lake

Click on "Hidden Scroll" behind the burned house.

]],
				},
			},
		},

		{
			name = L"Troll Country",
			entries =
			{
				{	--  Destro version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Bat (Title)",
					mapPins =
					{
						{
							x = 14300,
							y = 46600,
							zoneId = 101,
							tooltip = L"Bat, Giant - For Once It Isn't Guano",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Bat, Giant - For Once It Isn't Guano
"Echo Hunter"

14300, 46600

Kill "Leatherwing Bat" mobs around this area for a "Bat Wing" drop.

Then head to "Felde" Chaos Chapter 6, and purchase "Bat Hunter's Snout" from "Voxanna the Transmuter". Equip the pocket item to get the unlock.
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Bat (Title)",
					mapPins =
					{
						{
							x = 14300,
							y = 46600,
							zoneId = 101,
							tooltip = L"Bat, Giant - For Once It Isn't Guano",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Bat, Giant - For Once It Isn't Guano
"Echo Hunter"

14300, 46600

Kill "Leatherwing Bat" mobs around this area for a "Bat Wing" drop.

Then head to "Felde Castle" Empire Chapter 6, and purchase "Bat Hunter's Snout" from "Brenard the Alchemist". Equip the pocket item to get the unlock.
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Lizard (Tactic)",
					mapPins =
					{
						{
							x = 25800,
							y = 50900,
							zoneId = 101,
							tooltip = L"Giant Lizard - Hunger Pangs",
							icon = "TTitan_Pin_Bestiary",
						},
					},


					text =
[[
Giant Lizard - Hunger Pangs
BESTIAL TOME TACTIC UNLOCK

25800, 50900

Kill "Bluespine Salamander" mobs around this area for the Kill Collector at "Felde Castle", Empire Chapter 6 camp.
]],
				},

				{
					name = L"Gorger (Title)",
					mapPins =
					{
						{
							x = 26700,
							y = 10100,
							zoneId = 101,
							tooltip = L"Gorger - Questionable Fashion",
							icon = "TTitan_Pin_Bestiary",
						},
					},


					text =
[[
Gorger - Questionable Fashion
"The Foolhardy"

26700, 10100

Equip "Gorger Bone Decoration" pocket item, dropped by "Bonegash Gorger" mobs around this area.
]],
				},

				{
					name = L"Plaguebearer (Tactic)",
					mapPins =
					{
						{
							x = 54900,
							y = 26900,
							zoneId = 101,
							tooltip = L"Plaguebearer - Finding Foul Flesh",
							icon = "TTitan_Pin_Bestiary",
						},
					},


					text =
[[
Plaguebearer - Finding Foul Flesh
DAEMONIC TOME TACTIC UNLOCK

54900, 26900

Click on "Festering Corpse" a corpse slumped over between a large tree and a rock.
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Spider (Title)",
					mapPins =
					{
						{
							x = 800,
							y = 38100,
							zoneId = 101,
							tooltip = L"Spider, Giant - Tacky Decor",
							icon = "TTitan_Pin_Bestiary",
						},
					},


					text =
[[
Spider, Giant - Tacky Decor
"The Spider-Slayer"

800, 38100

Approach the back of "Suskarg Caves" minor landmark.
]],
				},

				{
					name = L"Spite (Tactic)",
					mapPins =
					{
						{
							x = 8400,
							y = 47200,
							zoneId = 101,
							tooltip = L"Spite - Lost and Found",
							icon = "TTitan_Pin_Bestiary",
						},
					},


					text =
[[
Spite - Lost and Found
MYTHICAL TOME TACTIC UNLOCK

8400, 47200

Kill "Elorian" a single Spite amoungst the trolls in this area.
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Troll (Title)",
					mapPins =
					{
						{
							x = 61300,
							y = 29600,
							zoneId = 101,
							tooltip = L"Troll - Troll Tales",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Troll - Troll Tales
"The Trollwise"

61300, 29600

Talk to "Afvaldr" hidden a little up on the hill on the right of the path, just behind some large rocks.
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Troll (Title)",
					mapPins =
					{
						{
							x = 26300,
							y = 41500,
							zoneId = 101,
							tooltip = L"Troll - Troll Tales",
							icon = "TTitan_Pin_Bestiary",
						},
					},


					text =
[[
Troll - Troll Tales
"The Trollwise"

26300, 41500

Talk to "Walbrecht Veit" standing next to a large tree.
]],
				},

				{
					name = L"Troll (Tactic)",
					mapPins =
					{
						{
							x = 9800,
							y = 5700,
							zoneId = 101,
							tooltip = L"Troll, Stone - It's a Snap",
							icon = "TTitan_Pin_Bestiary",
						},
					},


					text =
[[
Troll, Stone - It's a Snap
GIANT TOME TACTIC

9800, 5700

Kill "Coldsnap" a champion troll, on the route up to the lair of Metoh.
]],
				},

				{
					name = L"Troll (Title)",
					mapPins =
					{
						{
							x = 7500,
							y = 46400,
							zoneId = 101,
							tooltip = L"Troll, Chaos - Gone But Not Forgotten",
							icon = "TTitan_Pin_Bestiary",
						},
					},


					text =
[[
Troll, Chaos - Gone But Not Forgotten
"The Undaunted"

7500, 46400

Equip "Lost Locket" pocket item, dropped by "Wart Troll" mobs around this area.
]],
				},

				{	--Destro version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Troll (Tactic)",
					mapPins =
					{
						{
							x = 49700,
							y = 49100,
							zoneId = 101,
							tooltip = L"Troll, River - Gotta Go",
							icon = "TTitan_Pin_Bestiary",
						},
						{
							x = 50100,
							y = 44900,
							zoneId = 101,
							tooltip = L"Troll, River - Gotta Go",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Troll, River - Gotta Go
GIANT TOME TACTIC

49700, 49100 or 50100, 44900

Click on "Troll Droppings" to start the quest 'Poo Peddler'.

Head west to "Felde" Chaos Chapter 6, use the "river Troll Droppings" in you quest inventory while targeting "Voxanna the Transmuter". Then talk to him to complete the quest.
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Troll (Tactic)",
					mapPins =
					{
						{
							x = 49700,
							y = 49100,
							zoneId = 101,
							tooltip = L"Troll, River - Gotta Go",
							icon = "TTitan_Pin_Bestiary",
						},
						{
							x = 50100,
							y = 44900,
							zoneId = 101,
							tooltip = L"Troll, River - Gotta Go",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Troll, River - Gotta Go
GIANT TOME TACTIC

49700, 49100 or 50100, 44900

Click on "Troll Droppings" to start the quest 'Poo Peddler'.

Head west to "Felde Castle" Empire Chapter 6, use the "river Troll Droppings" in you quest inventory while targeting "Brenard the Alchemist". Then talk to him to complete the quest.
]],
				},

				{	
					name = L"Troll (Title)",
					mapPins =
					{
						{
							x = 47500,
							y = 36800,
							zoneId = 101,
							tooltip = L"Troll, River  - Mass Exstinktion",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Troll, River  - Mass Exstinktion
"River Troll Ravager"

47500, 36800

Approach this area which is full of trolls.
]],
				},

				{
					name = L"Troll (Pocket)",
					mapPins =
					{
						{
							x = 53600,
							y = 37800,
							zoneId = 101,
							tooltip = L"Troll, River - Takes its Toll",
							icon = "TTitan_Pin_Bestiary",
						},
						{
							x = 47600,
							y = 39900,
							zoneId = 101,
							tooltip = L"Troll, River - Takes its Toll",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Troll, River - Takes its Toll
POCKET ITEM

53600, 37800 or 47600, 39900

Kill "Bridge Troll" in the water under either of the two bridges.
]],
				},

				{
					name = L"Troll (Tactic)",
					mapPins =
					{
						{
							x = 55500,
							y = 47500,
							zoneId = 101,
							tooltip = L"Troll, River - O'de Toilet",
							icon = "TTitan_Pin_Bestiary",
						},
					},


					text =
[[
Troll, River - O'de Toilet
GIANT TOME TACTIC

55500, 47500

Click on "Barrel of Perfume" to start the quest 'Masking the Smell'.  

Head directly north and you will see "Brackmaw" in a small group of troll to the right.  

Kill him and then right click the "Barrel of Perfume" item in your quest inventory to finish the quest.
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Troll (Title)",
					mapPins =
					{
						{
							x = 12400,
							y = 29500,
							zoneId = 101,
							tooltip = L"Troll, Stone - Uneasy Stomach",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Troll, Stone - Uneasy Stomach
"The Boulderbane"

12400, 29500

Kill "Stormblight Dolt", "Stormblight Brute" or "Stormblight Lout" mobs around this area, for 5 "Intact Troll Stomach" drops.  

Then head to "Felde" Chaos Chapter 6, and purchase "Acidic Troll Bile" from "Voxanna the Transmuter". Equip the pocket item to get the unlock.
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Troll (Title)",
					mapPins =
					{
						{
							x = 12400,
							y = 29500,
							zoneId = 101,
							tooltip = L"Troll, Stone - Uneasy Stomach",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Troll, Stone - Uneasy Stomach
"The Boulderbane"

12400, 29500

Kill "Stormblight Dolt", "Stormblight Brute" or "Stormblight Lout" mobs around this area, for 5 "Intact Troll Stomach" drops.  

Then head to "Felde Castle" Empire Chapter 6, and purchase "Acidic Troll Bile" from "Brenard the Alchemist". Equip the pocket item to get the unlock.
]],
				},

				{
					name = L"Witch Hunter (Pocket)",
					mapPins =
					{
						{
							x = 3500,
							y = 54000,
							zoneId = 101,
							tooltip = L"Empire, Witch Hunter - What do We Have Here?",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					tomeBestiaryId = 51,
					tomeBestiaryName = L"Empire, Witch Hunter",
					text =
[[
Empire, Witch Hunter - What do We Have Here?
POCKET ITEM

3500, 54000 - In RvR Lake

Click on "Hidden Scroll" slightly north of Stonetroll Keep, in some bushes.

]],
				},
			},
		},

		{
			name = L"Ostland",
			entries =
			{
				{
					name = L"Bandit (Tactic)",
					mapPins =
					{
						{
							x = 55900,
							y = 25100,
							zoneId = 107,
							tooltip = L"Bandit - Wanted!",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Bandit - Wanted!
MAN TOME TACTIC

55900, 25100

Kill "Lodwig Falkenheim" a level 17 champion, standing at the north end of the lakes.
]],
				},

				{
					name = L"Bat, Giant (Tactic)",
					mapPins =
					{
						{
							x = 21100,
							y = 28400,
							zoneId = 107,
							tooltip = L"Bat, Giant - Things with Wings...",
							icon = "TTitan_Pin_Bestiary",
						},
					},


					text =
[[
Bat, Giant - Things with Wings...
BESTIAL TOME TACTIC

21100, 28400

Kill "Heartraker" a level 17 champion, found around here near the ridgeline, and floats around a bit.
]],
				},

				{
					name = L"Beastmen (Title)",
					mapPins =
					{
						{
							x = 20900,
							y = 36200,
							zoneId = 107,
							tooltip = L"Beastman, Bestigor - Meat for the Beast",
							icon = "TTitan_Pin_Bestiary",
						},
					},


					text =
[[
Beastman, Bestigor - Meat for the Beast
"The Raw"

20900, 36200

Click on "Witch Hunter Corpse" at the base of a blackened tree, just north of "Gashthorn Herdstone" major landmark.
]],
				},

				{   -- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Beastmen (Tactic)",
					mapPins =
					{
						{
							x = 16400,
							y = 10400,
							zoneId = 107,
							tooltip = L"Beastmen, Gor - Thin the Herd",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Beastmen, Gor - Thin the Herd
CHAOS TOME TACTIC

16400, 10400

Kill "Darkhorn Gor" mobs around this area, to complete the Kill Collector at "Felde", Chaos Chapter 6.
]],
				},

				{   -- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Beastmen (Tactic)",
					mapPins =
					{
						{
							x = 20800,
							y = 37800,
							zoneId = 107,
							tooltip = L"Beastmen, Gor - Thin the Herd",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Beastmen, Gor - Thin the Herd
CHAOS TOME TACTIC

20800, 37800

Kill "Gashthorn Gor" mobs at "Gashthorn Herstone" major landmark, to complete the Kill Collector at "Bohsenfels", Empire Chapter 8.
]],
				},

				{
					name = L"Dryad (Cloak)",
					mapPins =
					{
						{
							x = 8000,
							y = 16300,
							zoneId = 107,
							tooltip = L"Dryad - Death in Green and Brown",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Dryad - Death in Green and Brown
CLOAK ITEM UNLOCK

8000, 16300

Kill "Sheen Gloomleaf" a level 12 champion, standing at the north end of the small lake.
]],
				},

				{
					name = L"Marauder (Pocket)",
					mapPins =
					{
						{
							x = 34800,
							y = 8300,
							zoneId = 107,
							tooltip = L"Chaos, Marauder - What do We Have Here?",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					tomeBestiaryId = 16,
					tomeBestiaryName = L"Chaos, Marauder",
					text =
[[
Chaos, Marauder - What do We Have Here?
POCKET ITEM

34800, 8300 - In RvR Lake

Click on "Hidden Scroll" at the Crypt of Weapons BO, near the Tainted Earth for the quest, by one of the fallen pillars is a scroll.

]],
				},
				
				{
					name = L"Plaguebeast of Nurgle (Title)",
					mapPins =
					{
						{
							x = 20600,
							y = 14500,
							zoneId = 107,
							tooltip = L"Plaguebeast of Nurgle - A Trail of Pure Vile Evil",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Plaguebeast of Nurgle - A Trail of Pure Vile Evil
"The Rank"

20600, 14500

Kill "Plaguesworn Pariah" in front of the Nurgle symbol, and then Kill "Noxious Plaguebeast" a level 15 champion that spawns on the Pariah's death.
]],
				},

				{
					name = L"Plague Feaster (Tactic)",
					mapPins =
					{
						{
							x = 48400,
							y = 32500,
							zoneId = 107,
							tooltip = L"Plague Feaster - Wash Your Hands",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Plague Feaster - Wash Your Hands
CHAOS TOME TACTIC UNLOCK

48400, 32500

Click on "Basket of Fish" and then kill "Plague Feaster" a level 19 champion.
]],
				},

				{
					name = L"H. of Tzeentch (Title)",
					mapPins =
					{
						{
							x = 42400,
							y = 52800,
							zoneId = 107,
							tooltip = L"Horror of Tzeentch - The Colors of Horror",
							icon = "TTitan_Pin_Bestiary",
						},
					},


					text =
[[
Horror of Tzeentch - The Colors of Horror
"Aethyr Guard"

42400, 52800

Kill "Blue Horror"s and loot for "Blue Horror's Flesh" item and Kill "Pink Horror"s for "Pink Horror's Flesh" item, once you have both click on "Tzeentch Bonfire", which will spawn a "Purple Horror", kill it for the unlock.
]],
				},

				{
					name = L"Skeleton (Tactic)",
					mapPins =
					{
						{
							x = 30700,
							y = 18300,
							zoneId = 107,
							tooltip = L"Skeleton - When There's a Will",
							icon = "TTitan_Pin_Bestiary",
						},
					},


					text =
[[
Skeleton - When There's a Will
UNDEAD TOME TACTIC

30700, 183000

Equip "Faded Scroll" dropped by "Boneshard Minion" inside "Gerstmann Crypt" major landmark.
]],
				},

				{
					name = L"Skeleton (Tactic)",
					mapPins =
					{
						{
							x = 49600,
							y = 18300,
							zoneId = 107,
							tooltip = L"Skeleton - Bones Have Names Too",
							icon = "TTitan_Pin_Bestiary",
						},
					},


					text =
[[
Skeleton - Bones Have Names Too
UNDEAD TOME TACTIC UNLOCK

49600, 18300

Kill "Halman Meusmann" a level 16 champion. Standing just inside the gate of the small dilapidated cemetery.
]],
				},

				{   -- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Spirit Host (Pocket)",
					mapPins =
					{
						{
							x = 48800,
							y = 57300,
							zoneId = 107,
							tooltip = L"Spirit Host - Time is of the Essence",
							icon = "TTitan_Pin_Bestiary",
						},
					},


					text =
[[
Spirit Host - Time is of the Essence
POCKET ITEM

48800, 57300 - Quest start location

Click on "Body of Jekil Behn" to start the quest.

Then go east to "The Catacombs" major landmark, and click on "Hilde Behn's Grave" which will spawn a spirt host NPC. Target "Hilde Behn" the spawned NPC and use the "Jekil's Wedding Band" in your quest items. Complete the quest with her for the unlock.
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Spite (Title)",
					mapPins =
					{
						{
							x = 13400,
							y = 14800,
							zoneId = 107,
							tooltip = L"Spite - Looking for Shinnies",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Spite - Looking for Shinnies
"The Spite Splitter"

13400, 14800

Equip "Shining Ring" dropped by "Shadow Spite" around this area.
]],
				},

				{
					name = L"Troll (Pocket)",
					mapPins =
					{
						{
							x = 22100,
							y = 12500,
							zoneId = 107,
							tooltip = L"Troll - Who Is Up for Seconds",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Troll - Who Is Up for Seconds
POCKET ITEM UNLOCK

22100, 12500

Equip "Troll's Dinner" dropped by "Heathgut Troll"s around this area.
]],
				},

				{   -- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Wolf (Cloak)",
					mapPins =
					{
						{
							x = 59100,
							y = 9700,
							zoneId = 107,
							tooltip = L"Wolf - Picking Up The Pieces",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Wolf - Picking Up The Pieces
CLOAK ITEM

59100, 9700

Kill "Bloodfog Wolf" mobs around this area, to complete the Kill Collector at "Kournar's Encampment", Chaos Chapter 7.
]],
				},
			},
		},

		{
			name = L"High Pass",
			entries =
			{
				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Tuskgor (Tactic)",
					text =
[[
Tuskgor - Saving Face
CHAOS TOME TACTIC

(D) HIGH PASS @ 41, 46. Gather Unchipped Tusks by killing Bloodsnout Tuskgors in HIGH PASS.

By Mourngrym, Socran, Karylet & Grishnar
20090107
]],
				},

				{
					name = L"Beastman (Tactic)",
					mapPins =
					{
						{
							x = 47400,
							y = 50300,
							zoneId = 102,
							tooltip = L"Beastman, Ungor - Thorn in My Side",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Beastman, Ungor - Thorn in My Side
CHAOS TOME TACTIC

47400, 50300

Kill "Gurrvek Shorthorns" north of the main road, standing by the bonfire.
]],
				},

				{
					name = L"B. of Khorne (Title)",
					mapPins =
					{
						{
							x = 38000,
							y = 40600,
							zoneId = 102,
							tooltip = L"Bloodthirster of Khorne - Dire News Indeed",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Bloodthirster of Khorne - Dire News Indeed
"Heritor of War"

38000, 40600

Click on "Empire Runner Corpse" at the bottom of the cliffs.
]],
				},

				{	
					name = L"Chaos Fury (Title)",
					mapPins =
					{
						{
							x = 51900,
							y = 50000,
							zoneId = 102,
							tooltip = L"Chaos Fury - Nefarious Force",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Chaos Fury - Nefarious Force
"The Warpbinder"

51900, 50000

Kill "Zchekil the Vile" a L25 Hero.
]],
				},

				{	
					name = L"Chaos Hound (Title)",
					mapPins =
					{
						{
							x = 57200,
							y = 50300,
							zoneId = 102,
							tooltip = L"Chaos Hound - Seeker in the Snow",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Chaos Hound - Seeker in the Snow
"The Gnawed"

57200, 50300

Kill "Bradiclaw the Seeker" up on a ledge on the cliff.
]],
				},

				{
					name = L"Chaos Spawn (Title)",
					mapPins =
					{
						{
							x = 28100,
							y = 30100,
							zoneId = 102,
							tooltip = L"Chaos Spawn - Beyond Definition",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Chaos Spawn - Beyond Definition
"The Serene"

28100, 30100

Click on "Sixth Journal of Lliean" a blue book on the ground between three trees.
]],
				},

				{
					name = L"Magus (Pocket)",
					mapPins =
					{
						{
							x = 15000,
							y = 63000,
							zoneId = 102,
							tooltip = L"Chaos, Magus - What do We Have Here?",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					tomeBestiaryId = 15,
					tomeBestiaryName = L"Chaos, Magus",
					text =
[[
Chaos, Magus - What do We Have Here?
POCKET ITEM

15000, 63000 - In RvR Lake

Click on "Hidden Scroll" beside a broken section of the wall, the scroll is semi buried in the snow...not that hard to see.

]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Flayerkin (Title)",
					mapPins =
					{
						{
							x = 10700,
							y = 58800,
							zoneId = 102,
							tooltip = L"Flayerkin - One Part Agony, Three Parts Cold Wrought Iron",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Flayerkin - One Part Agony, Three Parts Cold Wrought Iron
"The Flayer"

10700, 58800 - Quest start location

Talk to "????" and purchase "Tangible Proof" for 50 War Tokens. Right click it from your quest inventory to start the quest "Tangible Proof". Two parts for the quest are in High Pass, the other on is in West Praag.

HIGH PASS:

For the Flayer-Kin's Scaling Hooks, click on "Dead Flayerkin" inside the cave in the "Cult of the Magus" PQ @ 11500, 48600, towards the back on the right, between the two rocks.
For the Flayer-Kin's Scaling Chains, click on "Dead Flayerkin" inside the "Tomb of the Traitor" PQ @ 4900, 39000, go through the first chamber and turn left, corpses is at the end of the corridor.

WEST Praag:

For the Flayer-Kin's Iron Helm, click on "Dead Flayerkin" in the "The Sundered Fortress" PQ @ 47500, 33200, in the south west corner of the fortress, just behind the small well.

Talk to "Kreelik of Clan Moulder" at "Korzah's Assault" Chaos Chapter 17,to complete the quest and receive the unlock.
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Flayerkin (Title)",
					mapPins =
					{
						{
							x = 10700,
							y = 58800,
							zoneId = 102,
							tooltip = L"Flayerkin - One Part Agony, Three Parts Cold Wrought Iron",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Flayerkin - One Part Agony, Three Parts Cold Wrought Iron
"The Flayer"

10700, 58800 - Quest start location

Talk to "Eustace Cloudedsight" and purchase "Tangible Proof" for 50 War Tokens. Right click it from your quest inventory to start the quest "Tangible Proof".

Two parts for the quest are in High Pass, the other on is in West Praag.

HIGH PASS:

 - For the Flayer-Kin's Scaling Hooks, click on "Dead Flayerkin" inside the cave in the "Cult of the Magus" PQ @ 11500, 48600, towards the back on the right, between the two rocks.
 - For the Flayer-Kin's Scaling Chains, click on "Dead Flayerkin" inside the "Tomb of the Traitor" PQ @ 4900, 39000, go through the first chamber and turn left, corpses is at the end of the corridor.

WEST Praag:

 - For the Flayer-Kin's Iron Helm, click on "Dead Flayerkin" in the "The Sundered Fortress" PQ @ 47500, 33200, in the south west corner of the fortress, just behind the small well.

Talk to "Breitenhoff the Faithfull" at "Lieberholz's Command" Empire Chapter 17, to complete the quest and receive the unlock.
]],
				},

				{
					name = L"Gorger (Token)",
					mapPins =
					{
						{
							x = 18600,
							y = 7100,
							zoneId = 102,
							tooltip = L"Gorger - Engage the Gorger",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Gorger - Engage the Gorger
BESTIAL TOKEN UNLOCK

18600, 7100

Kill "Bloodscent".
]],
				},

				{	-- Order entry
					realm = TTitan.Data.Realm.ORDER,
					name = L"Great Cat (Title)",
					mapPins =
					{
						{
							x = 9400,
							y = 38700,
							zoneId = 102,
							tooltip = L"Great Cat - A Run for Rolf",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Great Cat - A Run for Rolf
"The Clawed"

9400, 38700

Kill "Snarling Razortooth" mobs around this area ("Rabid" ones do not count) to complete the Kill Collector at "Nuhr's Crest", Empire Chapter 10 camp.
]],
				},

				{
					name = L"Great Unclean (Title)",
					mapPins =
					{
						{
							x = 26300,
							y = 41300,
							zoneId = 102,
							tooltip = L"Great Unclean One - The Unclean",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Great Unclean One - The Unclean
"Herald of the Vital"

26300, 41300

Click on "Heinrich's Stew Pot" in the trees near an NPC called "Old Hienrich"
]],
				},

				{
					name = L"Ogre, Bull (Tactic)",
					mapPins =
					{
						{
							x = 4400,
							y = 34400,
							zoneId = 102,
							tooltip = L"Ogre, Bull - It's Safer Outside",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Ogre, Bull - It's Safer Outside
GIANT TOME TACTIC UNLOCK

4400, 34400

Clcik on "Butchered Livestock" next to the bonefire.
]],
				},

				{
					name = L"Ogre, Bull (Tactic)",
					mapPins =
					{
						{
							x = 5200,
							y = 46500,
							zoneId = 102,
							tooltip = L"Ogre, Bull - Bigger They Are...",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Ogre, Bull - Bigger They Are...
GIANT TOME TACTIC

5200, 46500

Kill "Marl the Maneater" standing on the main road.
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Warhawk (Pocket)",
					mapPins =
					{
						{
							x = 4500,
							y = 53200,
							zoneId = 102,
							tooltip = L"Warhawk - Poached, Scrambled, or Fried",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Warhawk - Poached, Scrambled, or Fried
POCKET ITEM

4500, 53200 - Quest start location

Click on "Cracked Warhawk Egg" to start the quest "Winter Rations". 

Then collect 5 "Warhawk Egg" quest items by clicking on "Warhawk Egg" around the area. There are two location very close by, 6100, 53500 and 7400, 54500, there are others but they have a short re-click time.

Then head to "Eustace Cloudedsight" in "Raven's End" Empire Chapter 11 camp, to complete the quest. 
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Wight (Cloak)",
					mapPins =
					{
						{
							x = 33200,
							y = 24000,
							zoneId = 102,
							tooltip = L"Wight - Broken Men, Broken Blades",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Wight - Broken Men, Broken Blades
CLOAK ITEM

33200, 24000

Kill "Kulian Bonewarrior" or "Kulian Bonearcher" mobs in this area to collect 5 "Broken Wight Blade" items.

Then trade them in at The Inevitable City library for "Restored Wight Blade" and equip it for the unlock.
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Wight (Cloak)",
					mapPins =
					{
						{
							x = 33200,
							y = 24000,
							zoneId = 102,
							tooltip = L"Wight - Broken Men, Broken Blades",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Wight - Broken Men, Broken Blades
CLOAK ITEM

33200, 24000

Kill "Kulian Bonewarrior" or "Kulian Bonearcher" mobs in this area to collect 5 "Broken Wight Blade" items.

Then trade them in at Altdorf library for "Restored Wight Blade" and equip it for the unlock.
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Wolf (Tactic)",
					mapPins =
					{
						{
							x = 46700,
							y = 51300,
							zoneId = 102,
							tooltip = L"Wolf - Alpha in Bits",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Wolf - Alpha in Bits
BESTIAL TOME TACTIC

46700, 51300

Kill "Lishka" just north of the main road.
]],
				},

				{
					name = L"Yhetee (Cloak)",
					mapPins =
					{
						{
							x = 10500,
							y = 44800,
							zoneId = 102,
							tooltip = L"Yhetee - Appropriately Named",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Yhetee - Appropriately Named
CLOAK ITEM

10500, 44800

Kill "Killing Frost" standing on the peak.
]],
				},

				{
					name = L"Yhetee (Title)",
					mapPins =
					{
						{
							x = 25600,
							y = 27200,
							zoneId = 102,
							tooltip = L"Yhetee - Warrior, Your Life Force is Running Out",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Yhetee - Warrior, Your Life Force is Running Out
"The Defrosted"

25600, 27200

Click on "Drowned Body" at the bottom of the lake, hard to spot!
]],
				},
			},
		},

		{
			name = L"Talabecland",
			entries =
			{
				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Beastman (Tactic)",
					text =
[[
Beastman, Bestigor - Appalling Fashion
CHAOS TOME TACTIC

TALABECLAND @ 55, 35 or 48, 42. Confirmed at 1st coords by right clicking Casimir Por in the Beastman area E of the Herdstone. At 2nd coords, killing blow the L9 champ Witch Hunter Adept and he will give you the necklace that you click on for the unlock.

By Blodsalv, armorum, Archaides, Kellithe & Shaz
20081124
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Beastman (Tactic)",
					mapPins =
					{
						{
							x = 48300,
							y = 38900,
							zoneId = 108,
							tooltip = L"Beastman, Bestigor - Appalling Fashion",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Beastman, Bestigor - Appalling Fashion
CHAOS TOME TACTIC

48300, 38900

Equip "Grisly Necklace" drop by "Blackhorn Bestigor" mobs around the "Blackhorn Heardstone" major landmark.
]],
				},

				{
					name = L"Beastman (Tactic)",
					mapPins =
					{
						{
							x = 48300,
							y = 38900,
							zoneId = 108,
							tooltip = L"Beastman, Ungor - Trinkets for Treasure",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Beastman, Ungor - Trinkets for Treasure
CHAOS TOME TACTIC

48300, 38900

Equip "Ungor Talisman" drop by "Blackhorn Ungor" mobs around the "Blackhorn Heardstone" major landmark.
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Chaos Mutant (Title)",
					mapPins =
					{
						{
							x = 22700,
							y = 31900,
							zoneId = 108,
							tooltip = L"Chaos Mutant - Handy Dandy",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Chaos Mutant - Handy Dandy
"The Unsullied"

22700, 31900

Kill "Deathbed Mutant" or "Grave Mutant" mobs in this area to collect 10 "Mutant Hand" items.

Then trade them in at at The Inevitable City Lyceum for "Right Hand" and "Left Hand" and equip them for the unlocks.
]],
				},
				
				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Chaos Mutant (Title)",
					mapPins =
					{
						{
							x = 22700,
							y = 31900,
							zoneId = 108,
							tooltip = L"Chaos Mutant - Handy Dandy",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Chaos Mutant - Handy Dandy
"The Unsullied"

22700, 31900

Kill "Deathbed Mutant" or "Grave Mutant" mobs in this area to collect 10 "Mutant Hand" items.

Then trade them in at Altdorf library for "Right Hand" and "Left Hand" and equip them for the unlocks.
]],
				},

				{
					name = L"Great Stag (Title)",
					mapPins =
					{
						{
							x = 8400,
							y = 62500,
							zoneId = 108,
							tooltip = L"Great Stag - An Apple A Day",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Great Stag - An Apple A Day
"Fleet-Footed"

8400, 62500


Click on "Offering to Taal", a basket a the base of the woodern icon, next to the path junction.
]],
				},

				{
					name = L"Plaguebearer (Tactic)",
					mapPins =
					{
						{
							x = 36300,
							y = 50400,
							zoneId = 108,
							tooltip = L"Plaguebearer - Let It Fly or Let It Die",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Plaguebearer - Let It Fly or Let It Die
DAEMONIC TOME TACTIC UNLOCK

36300, 50400

Kill "Blight Spew" across the river south of "Unterbaum" major landmark
]],
				},

				{
					name = L"Plague Victim (Pocket)",
					mapPins =
					{
						{
							x = 5000,
							y = 42200,
							zoneId = 108,
							tooltip = L"Plague Victim - Side Effects Include Mutation and Death",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Plague Victim - Side Effects Include Mutation and Death
POCKET ITEM

5000, 42200

Click on "Chest of Plagues" at the base of the large rocks, on the north side.
]],
				},

				{
					name = L"Skaven (Tactic)",
					mapPins =
					{
						{
							x = 30100,
							y = 18200,
							zoneId = 108,
							tooltip = L"Skaven - What a Rat's Nest",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Skaven - What a Rat's Nest
SKAVEN TOME TACTIC

30100, 18200

Click on "Verminkin Banner" right at the top of the "Horned Tower" major landmark
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Vulture (Pocket)",
					mapPins =
					{
						{
							x = 10700,
							y = 44000,
							zoneId = 108,
							tooltip = L"Vulture - Diseased Pecking Order",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Vulture - Diseased Pecking Order
POCKET ITEM

10700, 44000

Equip "Blightbeak Beak" drop by "Blightbeak Carrion" or "Blightbeak Vulture" mobs along the southside of the river.
]],
				},

				{
					name = L"Vulture (Tactic)",
					mapPins =
					{
						{
							x = 5300,
							y = 43100,
							zoneId = 108,
							tooltip = L"Vulture - More Than Just a Foul Feather",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Vulture - More Than Just a Foul Feather
BESTIAL TOME TACTIC

5300, 43100

Kill "Plaguefeather" at the base of the large rocks, on the south side.
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Wolf (Tactic)",
					mapPins =
					{
						{
							x = 45200,
							y = 7700,
							zoneId = 108,
							tooltip = L"Wolf - Alpha in Bits",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Wolf - Alpha in Bits
BEASTIAL TOME TACTIC UNLOCK

45200, 7700

Kill "Sorenna", just SE of Volgen, Chaos Chapter 12.
]],
				},

				{
					name = L"Zombie (Title)",
					mapPins =
					{
						{
							x = 40000,
							y = 45600,
							zoneId = 108,
							tooltip = L"Zombie - Dare to Tread With the Undead",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Zombie - Dare to Tread With the Undead
"The Gory"

40000, 45600

Click on "Unterbaum's Recently Deceased" a cart containing dead bodies at the south tip of the graveyard.
]],
				},
			},
		},

		{
			name = L"Reikland",
			entries =
			{
				{
					name = L"Chaos (Title)",
					mapPins =
					{
						{
							x = 17100,
							y = 64000,
							zoneId = 109,
							tooltip = L"Chaos - The History of the servants of Chaos",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Chaos - The History of the servants of Chaos
"Foe of the Dark Gods"

17100, 64000

Click on 'Hidden Scroll' located between the 2 piles of wooden beams.
]],
				},

				{	
					name = L"Giant (Tactic)",
					mapPins =
					{
						{
							x = 46300,
							y = 26200,
							zoneId = 109,
							tooltip = L"Giant - Brutal Nose Ring",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Giant - Brutal Nose Ring
GIANT TOME TACTIC

46300, 26200

Equip "Giant Nosering" drop by "Uglik", who stands below the breidge.
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Great Cat (Tactic)",
					mapPins =
					{
						{
							x = 59000,
							y = 19000,
							zoneId = 109,
							tooltip = L"Great Cat - Not So Great Any More",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Great Cat - Not So Great Any More
BESTIAL TOME TACTIC

59000, 19000

Kill "Bloodmane".
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Great Cat (Tactic)",
					mapPins =
					{
						{
							x = 2000,
							y = 19300,
							zoneId = 109,
							tooltip = L"Great Cat - Not So Great Any More",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Great Cat - Not So Great Any More
BESTIAL TOME TACTIC

2000, 19300

Kill "Grinya" in the hills west for the path.
]],
				},

				{
					name = L"Great Stag (Title)",
					mapPins =
					{
						{
							x = 61800,
							y = 15100,
							zoneId = 109,
							tooltip = L"Great Stag - Well-Laid Trap",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Great Stag - Well-Laid Trap
"Always Alert"

61800, 15100

Click on "Hidden Trap", a leaf covered pit trap East of the path just behind a rock.
]],
				},

				{
					name = L"Hound (Pocket)",
					mapPins =
					{
						{
							x = 46200,
							y = 37600,
							zoneId = 109,
							tooltip = L"Hound - Dog Catcher",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Hound - Dog Catcher
POCKET ITEM

46200, 37600

Click on "Pet Trap" just south of "Vanik's Horde" Chaos chapter 21 camp.
]],
				},

				{
					name = L"Knight of the Blazing Sun (Pocket)",
					mapPins =
					{
						{
							x = 31500,
							y = 3800,
							zoneId = 109,
							tooltip = L"Empire, Knight of the Blazing Sun - What do We Have Here?",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					tomeBestiaryId = 49,
					tomeBestiaryName = L"Empire, Knight of the Blazing Sun",
					text =
[[
Empire, Knight of the Blazing Sun - What do We Have Here?
POCKET ITEM

31500, 3800

Click on the 'Hidden Scroll' located between a large tree stump and a log.

]],
				},

				{
					name = L"Spirit Host (Tactic)",
					mapPins =
					{
						{
							x = 12500,
							y = 43400,
							zoneId = 109,
							tooltip = L"Spirit Host - Worth the Waiting For",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text = 
[[
Spirit Host - Worth the Waiting For
Undead Tactic Fragment

12500, 43400

Kill "Mabel Riess" a neutral NPC standing amoungst some trees, just west of "Raven Landing" major landmark.
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Wolf (Tactic)",
					mapPins =
					{
						{
							x = 8100,
							y = 46300,
							zoneId = 109,
							tooltip = L"Wolf - Fall Fur Fashions",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Wolf - Fall Fur Fashions
BESTIAL TOME TACTIC

8100, 46300

Kill "Reik Wolf" mobs in this area to collect 5 "Fine Wolf Pelt" items.

Then trade them in to "Multan the Huntsman" in "Kreuznach" Empire Chapter 15, for "Wolf Pelt Cloak" and equip it for the unlock.
]],
				},
			},
		},

		{
			name = L"Praag",
			entries =
			{

				{
					name = L"Chosen (Pocket)",
					mapPins =
					{
						{
							x = 30000,
							y = 17000,
							zoneId = 105,
							tooltip = L"Chaos, Chosen - What do We Have Here?",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					tomeBestiaryId = 14,
					tomeBestiaryName = L"Chaos, Chosen",
					text =
[[
Chaos, Chosen - What do We Have Here?
POCKET ITEM

30000, 17000 - In RvR Lake

Click on "Hidden Scroll" in a burning half building underneath the little ramp.

]],
				},

				{
					name = L"Warrior Priest (Pocket)",
					mapPins =
					{
						{
							x = 35000,
							y = 58000,
							zoneId = 105,
							tooltip = L"Empire, Warrior Priest - What Do We Have Here?",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					tomeBestiaryId = 50,
					tomeBestiaryName = L"Empire, Warrior Priest",
					text =
[[
Empire, Warrior Priest - What Do We Have Here?
POCKET ITEM

35000, 58000 - In RvR Lake

Click on "Hidden Scroll" in the water of the fountain, on the south side of it.

]],
				},

				{ 	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Bear (Pocket)",
					mapPins =
					{
						{
							x = 64400,
							y = 33000,
							zoneId = 105,
							tooltip = L"Bear - Getting Ahead",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Bear - Getting Ahead
POCKET ITEM

64400, 33000

Kill"Boris the Mauler" inside "Ursan's Den" major landmark.
]],
				},
				
				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Bear (Pocket)",
					mapPins =
					{
						{
							x = 64400,
							y = 33000,
							zoneId = 105,
							tooltip = L"Bear - Getting Ahead",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Bear - Getting Ahead
POCKET ITEM

64400, 33000

Talk to "Boris the Mauler" inside "Ursan's Den" major landmark.
]],
				},

				{	
					name = L"Bear (Tactic)",
					mapPins =
					{
						{
							x = 59500,
							y = 19900,
							zoneId = 105,
							tooltip = L"Bear - Heading for Profit",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Bear - Heading for Profit
BESTIAL TOME TACTIC

59500, 19900

Equip "Deadmaul's Paw" dropped by "Deadmaul" at the end of the cave.
]],
				},

				{
					name = L"Beastman (Tactic)",
					mapPins =
					{
						{
							x = 6800,
							y = 17900,
							zoneId = 105,
							tooltip = L"Beastman, Gor - For the Greater Gor",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Beastman, Gor - For the Greater Gor
CHAOS TOME TACTIC

6800, 17900

Kill "Drahamesh" a neutral mob, standing in front of the herdstone.
]],
				},

				{
					name = L"Beastman (Acc)",
					mapPins =
					{
						{
							x = 700,
							y = 28400,
							zoneId = 105,
							tooltip = L"Beastman, Ungor - Thick-Headed",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Beastman, Ungor - Thick-Headed
JEWELRY ITEM

700, 28400

Kill "Grentic the Thick-Headed".
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Big Cat (Title)",
					mapPins =
					{
						{
							x = 49300,
							y = 42900,
							zoneId = 105,
							tooltip = L"Big Cat - A Run for Rolf",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Big Cat - A Run for Rolf
"The Clawed"

49300, 42900

Kill "Winter Lynx" mobs around this area, to complete the Kill Collector at "Southern Breach", Chaos Chapter 19.
]],
				},

				{	
					name = L"Chaos Giant (Title)",
					mapPins =
					{
						{
							x = 58400,
							y = 10700,
							zoneId = 105,
							tooltip = L"Chaos Giant - What's Inside is What Counts",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Chaos Giant - What's Inside is What Counts
"The Unflinching"

58400, 10700

Kill "Geral the Dim" sitting against a large rock, down by the water's edge.
]],
				},

				{
					name = L"Chaos Mutant (Token)",
					mapPins =
					{
						{
							x = 15500,
							y = 12600,
							zoneId = 105,
							tooltip = L"Chaos Mutant - Leader of the Lost",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Chaos Mutant - Leader of the Lost
BEAST TOKEN

15500, 12600

Kill "Calvin Lankdorf" just next to the main road.
]],
				},

				{
					name = L"Chaos Spawn (Acc)",
					mapPins =
					{
						{
							x = 13500,
							y = 2500,
							zoneId = 105,
							tooltip = L"Chaos Spawn - Empirical Proof",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Chaos Spawn - Empirical Proof
JEWELRY ITEM

13500, 2500

Click on "Third Journal of Lilean" follow the inside of the left wall behind the build, when entering walled area from the east side.
]],
				},

				{	
					name = L"Hound (Tactic)",
					mapPins =
					{
						{
							x = 2100,
							y = 60000,
							zoneId = 105,
							tooltip = L"Hound - Picky Eater",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Hound - Picky Eater
BESTIAL TOME TACTIC

2100, 60000

Equip "Fresh Meat" pocket item dropped by "Warpwind Gutter Runner" mobs around this area.
]],
				},

				{
					name = L"Skaven (Pocket)",
					mapPins =
					{
						{
							x = 1800,
							y = 65100,
							zoneId = 105,
							tooltip = L"Skaven - Dead Eye",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Skaven - Dead Eye
POCKET ITEM UNLOCK

1800, 65100

Kill "Thashtak Bloodeye" at the very south west inside the "Skaven Tunnels" major landmark.
]],
				},

				{
					name = L"Tuskgor (Pocket)",
					mapPins =
					{
						{
							x = 18900,
							y = 14300,
							zoneId = 105,
							tooltip = L"Tuskgor - Tough Meat",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Tuskgor - Tough Meat
POCKET ITEM

18900, 14300

Kill "Scythetusk".
]],
				},

				{
					name = L"Warhawk (Tactic)",
					mapPins =
					{
						{
							x = 59900,
							y = 49100,
							zoneId = 105,
							tooltip = L"Bird, Warhawk - Well Watched Weaklings",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Bird, Warhawk - Well Watched Weaklings
BESTIAL TOME TACTIC

59900, 49100

Kill "Snowperch Matriarch" on top of the hill, watching over four "Snowperch Fledgling" below.
]],
				},

				{
					name = L"Wraith (Acc)",
					mapPins =
					{
						{
							x = 22500,
							y = 53900,
							zoneId = 105,
							tooltip = L"Wraith - Soul Catcher",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Wraith - Soul Catcher
JEWELRY ITEM

22500, 53900

Kill "Gloomveil" under the waterfall.
]],
				},
			},
		},

		{
			name = L"West Praag",
			entries =
			{
				{
					name = L"Centigor (Title)",
					mapPins =
					{
						{
							x = 43800,
							y = 45300,
							zoneId = 120,
							tooltip = L"Centigor - Good to the Last Drop",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Centigor - Good to the Last Drop
"The Unruly"

43800, 45300

Click on "Noxious Ale" in the bush next to the herdstone.
]],
				},

				{	
					name = L"Daemonvine (Pocket)",
					mapPins =
					{
						{
							x = 46700,
							y = 4900,
							zoneId = 120,
							tooltip = L"Chaos Spawn, Daemonvine - Cutting Bonds",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Chaos Spawn, Daemonvine - Cutting Bonds
POCKET ITEM UNLOCK

46700, 4900

Kill "Xavian's Pride" just to the west of the farm building.
]],
				},

				{
					name = L"Great Cat (Acc)",
					mapPins =
					{
						{
							x = 58000,
							y = 42500,
							zoneId = 120,
							tooltip = L"Great Cat - Refined Tastes",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Great Cat - Refined Tastes
SET ITEM

58000, 42500

Equip "Fine Fur Pelt" pocket item, dropped by "Frost Growler" and "Frost Sabretusk" mobs around this area.
]],
				},

				{
					name = L"Hound (Tactic)",
					mapPins =
					{
						{
							x = 32100,
							y = 19900,
							zoneId = 120,
							tooltip = L"Hound - Dog Gone Crazy",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Hound - Dog Gone Crazy
BESTIAL TOME TACTIC

32100, 19900

Kill "Lost Hound".
]],
				},
			},
		},

		{
			name = L"Chaos Wastes",
			entries =
			{
				{
					name = L"Empire (Title)",
					mapPins =
					{
						{
							x = 22500,
							y = 9200,
							zoneId = 103,
							tooltip = L"Empire - The History of the Empire",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Empire - The History of the Empire
"The Anarchist"

22500, 9200 - In the RvR lake

Click on "Hidden Scroll" just behind the NE stone pillar on the "Thaugamond Massif" BO.
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Beastmen (Tactic)",
					mapPins =
					{
						{
							x = 56600,
							y = 20400,
							zoneId = 103,
							tooltip = L"Beastman, Bestigor - Nacht to Dread",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Beastman, Bestigor - Nacht to Dread
CHAOS TOME TACTIC UNLOCK

56600, 20400

Kill "Dreadhorn" Beastman mobs around this area, to complete the Kill Collector at "Fire of Sigmar", Empire Chapter 22 camp.
]],
				},

				{
					name = L"Beastmen (Token)",
					mapPins =
					{
						{
							x = 56700,
							y = 25800,
							zoneId = 103,
							tooltip = L"Beastmen, Bray Shaman - Bigger Bray to Make Your Day",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Beastmen, Bray Shaman - Bigger Bray to Make Your Day
BEASTIAL TOKEN

56700, 25800

Kill "Kratkar" just off to the side of the main road.
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"B. of Khorne (Token)",
					mapPins =
					{
						{
							x = 39100,
							y = 12300,
							zoneId = 103,
							tooltip = L"Bloodletter of Khorne - The Key to Success",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Bloodletter of Khorne - The Key to Success
BEAST TOKEN

39100, 12300 - Start location

Talk to "Mikhail the Profane" for the item "Talisman Key".

Then head to 5900, 33000 and click on "Batter Strongbox to spawn "Cithym". Kill him for the unlock.
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"B. of Khorne (Token)",
					mapPins =
					{
						{
							x = 39100,
							y = 12300,
							zoneId = 103,
							tooltip = L"Bloodletter of Khorne - The Key to Success",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Bloodletter of Khorne - The Key to Success
BEAST TOKEN

39100, 12300 - Start location

Kill "Mikhail the Profane" and loot for the item "Talisman Key".  

Then head to 59500, 32700 and click on "Batter Strongbox to spawn "Cithym". Kill him for the unlock.
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"B. of Khorne (Title)",
					mapPins =
					{
						{
							x = 39100,
							y = 12300,
							zoneId = 103,
							tooltip = L"Bloodletter of Khorne - Battered But Not Forgotten",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Bloodletter of Khorne - Battered But Not Forgotten
"The Sanguinary"

39100, 12300

Talk to "Mikhail the Profane".
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"B. of Khorne (Title)",
					mapPins =
					{
						{
							x = 39100,
							y = 12300,
							zoneId = 103,
							tooltip = L"Bloodletter of Khorne - Battered But Not Forgotten",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Bloodletter of Khorne - Battered But Not Forgotten
"The Sanguinary"

39100, 12300

Kill "Mikhail the Profane".
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Daemonvine (Title)",
					mapPins =
					{
						{
							x = 5600,
							y = 10000,
							zoneId = 103,
							tooltip = L"Chaos Spawn, Daemonvine - Hide and Seek",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Chaos Spawn, Daemonvine - Hide and Seek
"The Weed Whacker"

5600, 10000

Talk to "Anya Gerrad", cowering in the bushes just off the road.
]],
				},

				{	-- Orderversion
					realm = TTitan.Data.Realm.ORDER,
					name = L"Daemonvine (Title)",
					mapPins =
					{
						{
							x = 50700,
							y = 60700,
							zoneId = 103,
							tooltip = L"Chaos Spawn, Daemonvine - Hide and Seek",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Chaos Spawn, Daemonvine - Hide and Seek
"The Weed Whacker"

50700, 60700

Talk to "Xavian Gerrad" up a gully just west of the "Cave of Despair" minor landmark.
]],
				},

				{	
					name = L"D. of Slaanesh (Title)",
					mapPins =
					{
						{
							x = 15400,
							y = 39700,
							zoneId = 103,
							tooltip = L"Daemonette of Slaanesh - Song and Dance",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Daemonette of Slaanesh - Song and Dance
"The Chaste"

15400, 39700

Kill "Eidih the Helator" in a gully up into the mountains.
]],
				},

				{
					name = L"Dragon Orge (Title)",
					mapPins =
					{
						{
							x = 55600,
							y = 20100,
							zoneId = 103,
							tooltip = L"Dragon Ogre - The Most Ancient of Evil",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Dragon Ogre - The Most Ancient of Evil
"Storm Lord"

55600, 20100

Kill "Ghrual the Nightbringer" the final stage champ on "The Fall of Night" PQ.
]],
				},

				{
					name = L"F. of Tzeentch (Title)",
					mapPins =
					{
						{
							x = 22700,
							y = 52300,
							zoneId = 103,
							tooltip = L"Firewyrm of Tzeentch - Insane in the Membrane",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Firewyrm of Tzeentch - Insane in the Membrane
"The Insane"

22700, 52300

Kill "Corrupt Spawn" in a gully out of the RvR lake.
]],
				},

				{	
					name = L"F. of Tzeentch (Title)",
					mapPins =
					{
						{
							x = 48100,
							y = 6700,
							zoneId = 103,
							tooltip = L"Flamer of Tzeentch - Hot Deal",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Flamer of Tzeentch - Hot Deal
"The Banisher"

48100, 6700

Equip "Mote of Change" pocket item, dropped by "Soulflame".
]],
				},

				{
					name = L"Giant Bat (Acc)",
					mapPins =
					{
						{
							x = 44700,
							y = 3400,
							zoneId = 103,
							tooltip = L"Giant Bat - Not Available in Any Stores",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Giant Bat - Not Available in Any Stores
SET ITEM

44700, 3400

Equip "Deathwing's Fangs" dropped by "Deathwing" in the end chamber inside "Caverns of Terror" minor landmark.
]],
				},

				{
					name = L"J. of Khorne (Title)",
					mapPins =
					{
						{
							x = 39600,
							y = 15300,
							zoneId = 103,
							tooltip = L"Juggernaut of Khorne - Between a Rock and a...",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Juggernaut of Khorne - Between a Rock and a...
"The Immoveable Object"

39600, 15300

Click on "Pile of Rubble" in a corner of the broken wall sections.
]],
				},

				{
					name = L"L. of Change (Title)",
					mapPins =
					{
						{
							x = 63900,
							y = 28700,
							zoneId = 103,
							tooltip = L"Lord of Change - I Spy With My Eye",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Lord of Change - I Spy With My Eye
"Scion of Anarchy"

63900, 28700

Click on "Eye of Change" up on the side of the mountain. To reach it, start around 62000, 36500 and run up the ridge lines to drop down to it from the south side.
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Nurgling (Tactic)",
					mapPins =
					{
						{
							x = 9100,
							y = 56200,
							zoneId = 103,
							tooltip = L"Nurgling - No End to the Oozing",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Nurgling - No End to the Oozing
DAEMONIC TOME TACTIC

9100, 56200

Kill "Corpulent Nurgling" mobs in this area to collect 20 "Nurgling Ooze Sample" items.

Then trade them in at The Inevitable City Lyceum for "Ooze Booze" and equip it for the unlock.
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Nurgling (Tactic)",
					mapPins =
					{
						{
							x = 9100,
							y = 56200,
							zoneId = 103,
							tooltip = L"Nurgling - No End to the Oozing",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Nurgling - No End to the Oozing
DAEMONIC TOME TACTIC

9100, 56200

Kill "Corpulent Nurgling" mobs in this area to collect 20 "Nurgling Ooze Sample" items.

Then trade them in at Altdorf library for "Ooze Booze" and equip it for the unlock.
]],
				},

				{
					name = L"Plaguebearer (Acc)",
					mapPins =
					{
						{
							x = 50700,
							y = 52600,
							zoneId = 103,
							tooltip = L"Plaguebearer - Organ Grinder",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Plaguebearer - Organ Grinder
SET ITEM

50700, 52600

Equip "Pestilent Organ" dropped by "Grotesque Plaguebearer" mobs in this area.
]],
				},

				{
					name = L"S. of Tzeentch (Title)",
					mapPins =
					{
						{
							x = 11800,
							y = 59200,
							zoneId = 103,
							tooltip = L"Screamer - Puddles of Points",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Screamer - Puddles of Points
"The Screamer Seeker"

11800, 59200

Click on "Sunken Altar" in the pool out the front of the cave.
]],
				},

				{
					name = L"S. of Tzeentch (Cloak)",
					mapPins =
					{
						{
							x = 3800,
							y = 24300,
							zoneId = 103,
							tooltip = L"Screamer of Tzeentch - Poke'm If You Got'em",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Screamer of Tzeentch - Poke'm If You Got'em
CLOAK ITEM

3800, 24300

Kill "Vilemaw" south east of the "Lonely Tower" PQ, on the waters edge.
]],
				},

				{
					name = L"Spirit Host (Tactic)",
					mapPins =
					{
						{
							x = 40300,
							y = 56400,
							zoneId = 103,
							tooltip = L"Spirit Host - Higher Caliber of Soul",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Spirit Host - Higher Caliber of Soul
UNDEAD TOME TACTIC UNLOCK

40300, 56400

Kill "Vilesoul" on top of the cliff overlooking the RvR lake.
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Wight (Title)",
					mapPins =
					{
						{
							x = 5600,
							y = 2300,
							zoneId = 103,
							tooltip = L"Wight - Dead Weight",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Wight - Dead Weight
"King Slayer"

5600, 2300

Kill "Brimdall Yggdreidar" a lvl 1 mob standing at the north of this area, below the cliff line.
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Wolf (Cloak)",
					mapPins =
					{
						{
							x = 20200,
							y = 1500,
							zoneId = 105,
							tooltip = L"Wolf - Picking Up The Pieces",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Wolf - Picking Up The Pieces
CLOAK ITEM

20200, 1500 - In Praag

Kill "Winter Wolf" or "Winter Howler" mobs around this area for the Kill Collector at "Kaltenbach Expedition", Empire Chapter 20 camp.
]],
				},

				{	
					name = L"Wraith (Title)",
					mapPins =
					{
						{
							x = 41400,
							y = 64200,
							zoneId = 103,
							tooltip = L"Wraith - The Best Secrets Are Worth Dying For",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Wraith - The Best Secrets Are Worth Dying For
"The Intractable"

41400, 64200

Kill "Ma'leeng", click on "Obscure Rock" at the end of "Twisted Caves" minor landmark to spawn the mob.
]],
				},

				{
					name = L"Zombie (Tactic)",
					mapPins =
					{
						{
							x = 14700,
							y = 58400,
							zoneId = 103,
							tooltip = L"Zombie - The Family That Dies Together",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Zombie - The Family That Dies Together
UNDEAD TOME TACTIC

14700, 58400

Click on "Family Dining Table" inside at the back of the ruined house.
]],
				},
			},
		},

		{
			name = L"Bastion Stair",
			entries =
			{
				{
					name = L"Beastman, Gor (Acc.)",
					mapPins =
					{
						{
							x = 21800,
							y = 14200,
							zoneId = 160,
							tooltip = L"Beastman, Gor - Lair of the Brute",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Beastman, Gor - Lair of the Brute
SET ITEM

Equip "Skull of a Bray-shaman" dropped by "Bloodherd Gor" in the first wing of Bastion Stair, as you go down the stairwell.
]],
				},

				{
					name = L"Bloodbeast of K. (Title)",
					mapPins =
					{
						{
							x = 17300,
							y = 26100,
							zoneId = 160,
							tooltip = L"Bloodbeast of Khorne - Free of Chains",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Bloodbeast of Khorne - Free of Chains
"The Unshackled"

17300, 26100

Click on "Victim of the Bloodherd" to get the item "Bloodforged Axe", then kill the 3rd boss "Azuk'Thul" at 8800, 11300, with the item in your inventory.

(NOTE: Only those with the axe in their inventory will get the unlock for the kill, so each member of the party needs to pick one up.)
]],
				},
				
				{
					name = L"Bloodbeast of K. (Title)",
					mapPins =
					{
						{
							x = 36400,
							y = 34600,
							zoneId = 160,
							tooltip = L"Bloodbeast of Khorne - My Life for Azuk'Thul!",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Bloodbeast of Khorne - My Life for Azuk'Thul!
"Blood is in the Air"

36400, 34600

Kill "Bloodspawn of Azuk'Thul" spawned by clicking on the "Bloodicon" towards the corner of the platform.
]],
				},
								
				{
					name = L"Bloodletter of K. (Acc)",
					mapPins =
					{
						{
							tooltip = L"Bloodletter of Khorne - Now My Collection's Complete",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Bloodletter of Khorne - Now My Collection's Complete
SET ITEM

???, ???

Kill "The Collector".
]],
				},
								
				{
					name = L"Bloodthirster of K. (Title)",
					mapPins =
					{
						{
							x = 32700,
							y = 12500,
							zoneId = 160,
							tooltip = L"Bloodthirster of Khorne - Lure of the Rift",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Bloodthirster of Khorne - Lure of the Rift
"The Bloodthirsty"

32700, 12500

Click on "Rift Conduit" at the very back behind Skull Lord Var'ithrok.
]],
				},
								
				{
					name = L"Bray Shaman (Title)",
					mapPins =
					{
						{
							x = 3100,
							y = 13300,
							zoneId = 160,
							tooltip = L"Bray Shaman - Bray Before Khorne",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Bray Shaman - Bray Before Khorne
"Sacrificial Offering"

3100, 13300

Kill "Bloodherd Great Bray" in the west side chamber.
]],
				},
												
				{
					name = L"Centigor (Tactic)",
					mapPins =
					{
						{
							x = 11000,
							y = 4500,
							zoneId = 160,
							tooltip = L"Centigor - Rage is All I Feel",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Centigor - Rage is All I Feel
Chaos Tactic Fragment

11000, 4500

Kill "Krakthar" in the north side chamber.
]],
				},
																
				{
					name = L"Chaos Fury (Title)",
					mapPins =
					{
						{
							x = 32900,
							y = 33400,
							zoneId = 160,
							tooltip = L"Chaos Fury - Earning Its Name",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Chaos Fury - Earning Its Name
"The Furious"

32900, 33400

Kill "Kar'tyk Ragefury" spawned by click on "???" on the altar.
]],
				},
																				
				{
					name = L"Chaos Giant (Title)",
					mapPins =
					{
						{
							x = 43100,
							y = 12900,
							zoneId = 160,
							tooltip = L"Chaos Giant - Down by the River",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Chaos Giant - Down by the River
"Hot and Bothered"

43100, 12900

Click on "Bloodgiant Bait" a barrel on the island in the lava, in front of the Khorne icon.
]],
				},
																								
				{
					name = L"Chaos Hound (Title)",
					mapPins =
					{
						{
							x = 61500,
							y = 8700,
							zoneId = 160,
							tooltip = L"Chaos Hound - Great Aspirations",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Chaos Hound - Great Aspirations
"The Aspiring"

61500, 8700

Kill "Aspiring Flesh Hound" in the North East side room off the right wing stairwell.
]],
				},

				{
					name = L"Daemon Prince (Title)",
					text =
[[
Daemon Prince - Such Are the Gifts of Chaos
"The Ascendant"

Kill "Kaarn the Vanquisher" in the middle wing of Bastion Stair.
]],
				},
																												
				{
					name = L"Doombull (Title)",
					mapPins =
					{
						{
							x = 15900,
							y = 1800,
							zoneId = 160,
							tooltip = L"Doombull - Son of the Brazen One",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Doombull - Son of the Brazen One
"The Brassy"

15900, 1800

Kill "Thar'Ignan" the final boss of the left wing.
]],
				},

				{	
					name = L"F.Hound of Khorne (Token)",
					mapPins =
					{
						{
							x = 32700,
							y = 38800,
							zoneId = 160,
							tooltip = L"Flesh Hound of Khorne - Hunters of Blood",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Flesh Hound of Khorne - Hunters of Blood
BEAST TOKEN

Kill "Fleshhounds" mobs in the middle wing as you climb up, to collect 10 "Razor Sharp Fangs" items.

Then trade them in to "Grulgaar the Maker" in the entance lobby area for "Hound's Fang Dagger" and equip it for the unlock.
]],
				},

				{	
					name = L"F.Hound of Khorne (Title)",
					mapPins =
					{
						{
							x = 15000,
							y = 12200,
							zoneId = 160,
							tooltip = L"Flesh Hound of Khorne - Sins of the Flesh",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Flesh Hound of Khorne - Sins of the Flesh
"The Bloodhound"

15000, 12200

Equip "Rage Forged Collar" dropped by "Beastrip" the fleshhound companion of Gahlvoth Darkrage (2nd boss, left wing).
]],
				},
																																
				{
					name = L"Ogre Tyrant (Tactic)",
					mapPins =
					{
						{
							x = 17400,
							y = 26000,
							zoneId = 160,
							tooltip = L"Ogre Tyrant - Back Room Dealings",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Ogre Tyrant - Back Room Dealings
Giant Tactic Fragment

17400, 26000

Kill "Bulrok Headsmasher" at the end of the corridor.
]],
				},
																																				
				{
					name = L"Ragebeast (Title)",
					mapPins =
					{
						{
							x = 35600,
							y = 31700,
							zoneId = 160,
							tooltip = L"Ragebeast - The Sound of Dinner",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Ragebeast - The Sound of Dinner
"Step-taker"

35600, 31700

Kill "Unbroken Ragebeast" spawned by clicking on "Feeding Basket" with "Ragebeast Feed" in your inventory, which is picked up in the corner as you climb the steps of ruin.
]],
				},

				{
					name = L"Tuskgor (Title)",
					mapPins =
					{
						{
							x = 21300,
							y = 16000,
							zoneId = 160,
							tooltip = L"Beastman, Gor - Lair of the Brute",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Tuskgor - Not Trying To Hide
"The Tuskgor Hunter"

Equip "Thick Tuskgor Hide" dropped by "Bloodherd Tuskgor" in the first wing of Bastion Stair, as you go down the stairwell and along the corridors.
]],
				},
			},
		},

		{
			name = L"Reikwald",
			entries =
			{
				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Empire (Title)",
					mapPins =
					{
						{
							x = 22100,
							y = 16700,
							zoneId = 110,
							tooltip = L"Empire - Vanquish the Empire Fortress Lord",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Empire - Vanquish the Empire Fortress Lord
"The Hand of Chaos"

Be in the vicinity of a Fortress Lord kill.
]],
				},


			},
		},

		{
			name = L"Altdorf",
			entries =
			{
				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Skaven (Tactic)",
					mapPins =
					{
						{
							x = 42800,
							y = 30200,
							zoneId = 169,
							tooltip = L"Skaven - Septic Sanitation",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Skaven - Septic Sanitation
SKAVEN TOME TACTIC

42800, 30200 - In The Sewers of Altdorf (Middle Wing)

Kill "Master Moulder Vitchek".
]],
				},
			},
		},

		{
			name = L"The Maw",
			entries =
			{

			},
		},

		{
			name = L"The Inevitable City",
			entries =
			{
				{	
					name = L"Watcher (Title)",
					mapPins =
					{
						{
							x = 46700,
							y = 33100,
							zoneId = 161,
							tooltip = L"Watcher - I Spy...",
							icon = "TTitan_Pin_Bestiary",
						},
					},


					text =
[[
Watcher - I Spy...
"The Blinder"

46700, 33100

Talk to "Sightless Watcher" on the left side of the tent at the end of the path way.
]],
				},

				{	
					name = L"Walker (Title)",
					mapPins =
					{
						{
							x = 26200,
							y = 40800,
							zoneId = 161,
							tooltip = L"Walker - Walk? No. Run!",
							icon = "TTitan_Pin_Bestiary",
						},
					},


					text =
[[
Walker - Walk? No. Run!
"The Leg Breaker"

26200, 40800

Kill "Timelost Soul" that runs north south along the area west of The Apex, between 26100, 34400 and 26200, 40800.
]],
				},
			},
		},
	},		
}
