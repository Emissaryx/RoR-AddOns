TTitan.Data.BestiaryDvG = {}

function TTitan.Data.BestiaryDvG.GetData()
	return TTitan.Data.BestiaryDvG.RawData
end

function TTitan.Data.BestiaryDvG.FilterData()
	TTitan.Data.FilterByRealm(TTitan.Data.BestiaryDvG.RawData)
end

TTitan.Data.BestiaryDvG.RawData =
{
	header = L"Beastiary Unlocks - Dwarfs vs Greenskins",
	categories =
	{
		{
			name = L"Non Zone-Based",
			entries =
			{				
				{
					name = L"Dwarf (Title)",
					text =
[[
Dwarf - Complete a Dwarf Scenario
"Foe of the Dawi"

Win a Gromril Crossing Scenario.
]],
				},

				{
					name = L"Goblin (Title)",
					text =
[[
Goblin - Complete a Greenskin Scenario
"The Avenging Brewmaster"

Win a Howling Gorge scenario.
]],
				},

				{
					name = L"Orc (Title)",
					text =
[[
Orc - Complete a Greenskin Scenario
"The Mangler"

Win a Howling Gorge scenario.
]],
				},
			},
		},

		{
			name = L"Ekrund",
			entries =
			{
				{
					name = L"Ironbreaker (Pocket)",
					mapPins =
					{
						{
							x = 50000,
							y = 8500,
							zoneId = 6,
							tooltip = L"Dwarf, Ironbreaker - What do We Have Here?",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					tomeBestiaryId = 44,
					tomeBestiaryName = L"Dwarf, Ironbreaker",
					text =
[[
Dwarf, Ironbreaker - What do We Have Here?
POCKET ITEM

50000, 8500 - In RvR Lake

Click on "Hidden Scroll" just to the left of the dwarf gate, between "Cannon Battery" and "Stonemine Tower" BOs.

]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Squig (Title)",
					mapPins =
					{
						{
							x = 21200,
							y = 38900,
							zoneId = 6,
							tooltip = L"Squig - The Other, Other Red Meat",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Squig - The Other, Other Red Meat
"The Gourmand"

21200, 38900

Talk to "Lormina Falinsdotr" on the left inside "Pick & Google" major landmark, then purchase and use "Squig-On-A-Stick".
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Plaguebearer (Title)",
					mapPins =
					{
						{
							x = 45400,
							y = 29800,
							zoneId = 6,
							tooltip = L"Plaguebearer - A Tale by the Fire",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Plaguebearer - A Tale by the Fire
"The Plaguebearer Hunter"

45400, 29800

Talk to "Witch Hunter Adept" standing by the fire inside "Redhammer Brewery" Dwarf Chapter 2.
]],
				},

			},
		},
		
		{
			name = L"Dragonback Pass",
			entries =
			{
				{
					name = L"Troll (Cloak)",
					mapPins =
					{
						{
							x = 33300,
							y = 40300,
							zoneId = 36,
							tooltip = L"Troll, Chaos - All for One and One for All",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Troll, Chaos - All for One and One for All
CLOAK ITEM

33300, 40300

Kill "Stichwort" the final secret chaos troll unlocked by killing the 3 other secret troll bosses.
]],
				},
			},
		},

		{
			name = L"Mount Bloodhorn",
			entries =
			{
				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Boar (Tactic)",
					mapPins =
					{
						{
							x = 16700,
							y = 49600,
							zoneId = 11,
							tooltip = L"Boar - Avoid a Gory End",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Boar - Avoid a Gory End
BESTIAL TOME TACTIC

16700, 49600

Kill "Shapthorn Boar" mobs around this area, to complete the Kill Collector at "Da War Maker", Greenskin Chapter 2.
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Spite (Pocket)",
					mapPins =
					{
						{
							x = 3500,
							y = 61200,
							zoneId = 11,
							tooltip = L"Spite - De-spite",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Spite - De-spite
POCKET ITEM

3500, 61200

Kill "Maegda".
]],
				},
				
				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Spite (Pocket)",
					mapPins =
					{
						{
							x = 54900,
							y = 27700,
							zoneId = 11,
							tooltip = L"Spite - De-spite",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Spite - De-spite
POCKET ITEM

54900, 27700

Kill "Tarestil".
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Spite (Tactic)",
					mapPins =
					{
						{
							x = 8200,
							y = 62800,
							zoneId = 11,
							tooltip = L"Spite - A Defiled Life-Force",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Spite - A Defiled Life-Force
MYTHICAL TOME TACTIC

8200, 62800

Kill "Tainted Grove Spite" and loot "Tainted Spite Essence".

Then return the item to "Bloody Sun Burner" a merchant inside one of the huts in "Komar", Greenskin Chapter 3. Trade the "Tainted Spite Essence" for "Burnt Spite Remains" and equip the pockt item for the unlock.
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Spite (Tactic)",
					mapPins =
					{
						{
							x = 8200,
							y = 62800,
							zoneId = 11,
							tooltip = L"Spite - A Defiled Life-Force",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Spite - A Defiled Life-Force
MYTHICAL TOME TACTIC

8200, 62800

Kill "Tainted Grove Spite" and loot "Tainted Spite Essence". 

Then return the item to "Hammerstriker Hasher" a merchant inside the building at Komar, Dwarf chapter 3. Trade the Tainted Spite Essence for "Burnt Spite Remains" and equip the pockt item for the unlock.
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Squig (Title)",
					mapPins =
					{
						{
							x = 16200,
							y = 53500,
							zoneId = 11,
							tooltip = L"Squig - The Other, Other Red Meat",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Squig - The Other, Other Red Meat
"The Gourmand"

16200, 53500

Talk to "Tochez da Slop Slinger" by Da War Maker, then purchase and use "Squig-On-A-Stick".
]],
				},

				{
					name = L"Squig Herder (Pocket)",
					mapPins =
					{
						{
							x = 25200,
							y = 4300,
							zoneId = 11,
							tooltip = L"Goblin, Squig Herder - What do We Have Here?",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					tomeBestiaryId = 91,
					tomeBestiaryName = L"Goblin, Squig Herder",
					text =
[[
Goblin, Squig Herder - What do We Have Here?
POCKET ITEM

25200, 4300 - In RvR Lake

Click on "Hidden Scroll" at the very end of "Ironmane Mine" tunnels, on the ground between the orc bodies at the cave-in and a large stone column.

]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Vulture (Tactic)",
					mapPins =
					{
						{
							x = 3100,
							y = 25500,
							zoneId = 11,
							tooltip = L"Vulture - Slop-of-the-Day",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Vulture - Slop-of-the-Day
BESTIAL TOME TACTIC

3100, 25500 - Quest Start Location

Talk to "Bloody Sun Burner" a merchant inside the hut at "Komar", Greenskin chapter 3. 

Purchase and use "Sack of Rotting Fruit" in your quest items. 

This will start the quest "Rotten Business", and you need to head to around 22400, 25700, where you will find three "Slop Basket" to click on, and kill the mob that spawns. Complete this stage and then return to "Bloody Sun Burner" to complete the 2nd stage of the questline and receive the unlock.
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Vulture (Tactic)",
					mapPins =
					{
						{
							x = 7600,
							y = 24600,
							zoneId = 11,
							tooltip = L"Vulture - Slop-of-the-Day",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Vulture - Slop-of-the-Day
BESTIAL TOME TACTIC

7600, 24600 - Quest Start Location

Talk to "Hammerstriker Hasher" a merchant inside the building at "Komar", Dwarf chapter 3. 

Purchase and use "Sack of Rotting Fruit" in your quest items. 

This will start the quest "Rotten Business", and you need to head to around 22400, 25700, where you will find three "Slop Basket" to click on, and kill the mob that spawns. Complete this stage and then return to "Hammerstriker Hasher" to complete the 2nd stage of the questline and receive the unlock.
]],
				},
								
			},
		},

		{
			name = L"Barak Varr",
			entries =
			{
				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Boar (Tactic)",
					mapPins =
					{
						{
							x = 20300,
							y = 55800,
							zoneId = 7,
							tooltip = L"Boar - Avoid a Gory End",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Boar - Avoid a Gory End
BEASTIAL TOME TACTIC UNLOCK

20300, 55800

Kill "Great Warsnout" or "Bloodtusk Warsnout" mobs around this area, to complete the Kill Collector at "Thane's Defense", Dwarf Chapter 7 camp.
]],
				},

				{
					name = L"Boar (Tactic)",
					mapPins =
					{
						{
							x = 20600,
							y = 51600,
							zoneId = 7,
							tooltip = L"Boar - Great Tusk",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Boar - Great Tusk
BESTIAL TOME TACTIC

20600, 51600

Kill "Jowler" under the bridge.
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Dwarf Slayer (Tactic)",
					mapPins =
					{
						{
							x = 11300,
							y = 49000,
							zoneId = 7,
							tooltip = L"Dwarf Slayer - Off With His ...",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Dwarf Slayer - Off With His ...
MAN TOME TACTIC

Kill "Sea Anvil Slayer" mobs, and collect 20 "Slayer Scalps" drops. 

Then trade them in to "Kregit Saltspitta" at Nogaz's Boyz, Greenskin chapter 5, for "Snotling's Head" and equip it for the unlock.
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Dwarf Slayer (Tactic)",
					mapPins =
					{
						{
							x = 20700,
							y = 44600,
							zoneId = 7,
							tooltip = L"Dwarf Slayer - Off With His ...",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Dwarf Slayer - Off With His ...
MAN TOME TACTIC

20700, 44600

Talk to "Captain Brinebeard" standing in front of the tent, over the small bridge in the south west of "Goldpeak's Warcamp".
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Dwarf Slayer (Title)",
					mapPins =
					{
						{
							x = 10400,
							y = 46600,
							zoneId = 7,
							tooltip = L"Dwarf Slayer - First of Many",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Dwarf Slayer - First of Many
"Doom Bringer"

10400, 46600

Kill "First Mate Kjaelsson" a mob standing at the front of "The Sea's Anvil" major landmark.
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Dwarf Slayer (Title)",
					mapPins =
					{
						{
							x = 10400,
							y = 46600,
							zoneId = 7,
							tooltip = L"Dwarf Slayer - First of Many",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Dwarf Slayer - First of Many
"Doom Bringer"

10400, 46600

Talk to "First Mate Kjaelsson" a mob standing at the front of "The Sea's Anvil" major landmark.
]],
				},

				{
					name = L"Giant Lizard (Tactic)",
					mapPins =
					{
						{
							x = 4400,
							y = 19200,
							zoneId = 7,
							tooltip = L"Giant Lizard - Poached",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Giant Lizard - Poached
BESTIAL TOME TACTIC

4400, 19200

Click on "Broken Salamander Egg" towards the north end of the beach.
]],
				},

				{
					name = L"Giant Lizard (Title)",
					mapPins =
					{
						{
							x = 4400,
							y = 20800,
							zoneId = 7,
							tooltip = L"Giant Lizard - A Matter of Scales",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Giant Lizard - A Matter of Scales
"The Lizard Hunter"

4400, 20800

Equip "Scaly Skin" pocket item dropped by "Beach Salamander" mobs in this area.
]],
				},

				{
					name = L"Giant Lizard (Title)",
					mapPins =
					{
						{
							x = 18500,
							y = 16000,
							zoneId = 7,
							tooltip = L"Giant Lizard - Blood from a Stone",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Giant Lizard - Blood from a Stone
"Stony-Hearted"

18500, 16000

Kill "Stonescale" near the waters edge along the beach.
]],
				},

				{
					name = L"Nurgling (Title)",
					mapPins =
					{
						{
							x = 54200,
							y = 49700,
							zoneId = 7,
							tooltip = L"Nurgling - Getting it off Your Chest",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Nurgling - Getting it off Your Chest
"The Denier of Disease"

54200, 49700

Click on "Festering Corpse" a dead dwarf at the bottom of the cliff, just east of the marked path.
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Ogre, Bull (Title)",
					mapPins =
					{
						{
							x = 21000,
							y = 47600,
							zoneId = 7,
							tooltip = L"Ogre, Bull - Loose-Lipped",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Ogre, Bull - Loose-Lipped
"The Crusher"

21000, 47600

Talk to "Ragakk" an ogre, inside a little camp along with some gobbos.
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Ogre, Bull (Title)",
					mapPins =
					{
						{
							x = 49000,
							y = 58000,
							zoneId = 7,
							tooltip = L"Ogre, Bull - Loose-Lipped",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Ogre, Bull - Loose-Lipped
"The Crusher"

49000, 58000

Talk to "Lead Belcher" an orge, standing at the front of the little camp, next to a cannon.
]],
				},

				{
					name = L"Rune Priest (Pocket)",
					mapPins =
					{
						{
							x = 31500,
							y = 36000,
							zoneId = 7,
							tooltip = L"Dwarf, Rune Priest - What do We Have Here?",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					tomeBestiaryId = 45,
					tomeBestiaryName = L"Dwarf, Rune Priest",
					text =
[[
Dwarf, Rune Priest - What do We Have Here?
POCKET ITEM

31500, 36000 - In RvR Lake

Click on "Hidden Scroll", it is behind the keep just under the tree close to the postern door.

]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Spider, Giant (Title)",
					mapPins =
					{
						{
							x = 5000,
							y = 28000,
							zoneId = 7,
							tooltip = L"Spider, Giant - Tacky Decor",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Spider, Giant - Tacky Decor
"Spider-Slayer"

5000, 28000

Enter the "Wetfang Cave" Minor Landmark, west of "Nogaz's Boyz", Greenskin Chapter 5.
]],
				},
			},
		},

		{
			name = L"Marshes of Madness",
			entries =
			{
				{
					name = L"Banshee (Title)",
					mapPins =
					{
						{
							x = 56600,
							y = 30900,
							zoneId = 1,
							tooltip = L"Banshee - A Sound to Silence",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Banshee - A Sound to Silence
"The Silencer"

56600, 30900

Click on "Shallow Grave" behind a tree down in the valley.
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Ghoul (Title)",
					mapPins =
					{
						{
							x = 31300,
							y = 10600,
							zoneId = 1,
							tooltip = L"Ghoul - Ghoul to be Gone",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Ghoul - Ghoul to be Gone
"Foe of the Cannibal"

31300, 10600

Talk to "Noglik" inside "Hargruk's Camp" Major Landmark. He is hidden under a tree, near some rocks, northeast of the big greenskin totem.
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Ghoul (Title)",
					mapPins =
					{
						{
							x = 50400,
							y = 40500,
							zoneId = 1,
							tooltip = L"Ghoul - Ghoul to be Gone",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Ghoul - Ghoul to be Gone
"Foe of the Cannibal"

50400, 40500

Talk to "Acolyte Scherer" on the right side of the entance to "Marshlight Cave" minor landmark.
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Gnoblar (Tactic)",
					mapPins =
					{
						{
							x = 56800,
							y = 7800,
							zoneId = 1,
							tooltip = L"Gnoblar - Cull the Weak",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Gnoblar - Cull the Weak
GREENSKIN TOME TACTIC

56800, 7800

Kill "Boglar" mobs, and collect 5 "Boglar Ear" drops, then trade them in at The Inevitable City Lyceum for "Collection of Ears" and equip it for the unlock.
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Gnoblar (Tactic)",
					mapPins =
					{
						{
							x = 56800,
							y = 7800,
							zoneId = 1,
							tooltip = L"Gnoblar - Cull the Weak",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Gnoblar - Cull the Weak
GREENSKIN TOME TACTIC

56800, 7800

Kill "Boglar" mobs, and collect 5 "Boglar Ear" drops, then trade them in at Altdorf library for "Collection of Ears" and equip it for the unlock.
]],
				},

				{
					name = L"Gnoblar (Tactic)",
					mapPins =
					{
						{
							x = 36000,
							y = 60200,
							zoneId = 1,
							tooltip = L"Gnoblar - Tiny Tyrant",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Gnoblar - Tiny Tyrant
GREENSKIN TOME

36000, 60200

Kill "Honcho Bogwash".
]],
				},

				{
					name = L"Giant (Title)",
					mapPins =
					{
						{
							x = 55000,
							y = 60000,
							zoneId = 1,
							tooltip = L"Giant - Bare the Brunt",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Giant - Bare the Brunt
"The Earth Shaker"

55000, 60000

Kill "Thrags" at the top of the ramp.
]],
				},

				{
					name = L"Shaman (Pocket)",
					mapPins =
					{
						{
							x = 29000,
							y = 29500,
							zoneId = 1,
							tooltip = L"Goblin, Shaman - What do We Have Here?",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					tomeBestiaryId = 90,
					tomeBestiaryName = L"Goblin, Shaman",
					text =
[[
Goblin, Shaman - What do We Have Here?
POCKET ITEM

29000, 29500 - In RvR Lake

Click on "Hidden Scroll" it is on top of a trash pile NW of "Fangbreaka Swamp" Keep.

]],
				},

				{
					name = L"Vampire (Title)",
					mapPins =
					{
						{
							x = 50000,
							y = 53000,
							zoneId = 1,
							tooltip = L"Vampire - Hail to the Horror",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Vampire - Hail to the Horror
"The Dawnbringer"

50000, 53000

Click on "Vampire Marker"
]],
				},
			},
		},

		{
			name = L"The Badlands",
			entries =
			{

				{
					name = L"Black Orc (Pocket)",
					mapPins =
					{
						{
							x = 22000,
							y = 55000,
							zoneId = 2,
							tooltip = L"Orc, Black Orc - What do We Have Here?",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					tomeBestiaryId = 92,
					tomeBestiaryName = L"Orc, Black Orc",
					text =
[[
Orc, Black Orc - What do We Have Here?
POCKET ITEM

22000, 55000 - In RvR Lake

Click on "Hidden Scroll" it is on a trash pile under the giant bones, just beside a barrel.

]],
				},

				{
					name = L"Ghoul (Tactic)",
					mapPins =
					{
						{
							x = 17600,
							y = 10500,
							zoneId = 2,
							tooltip = L"Ghoul - Foul Amongst the Fowl",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Ghoul - Foul Amongst the Fowl
BESTIAL TOME TACTIC

17600, 10500

Kill "Rauklus" in the valley with the other ghouls and birds.
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Gnoblar (Acc)",
					mapPins =
					{
						{
							x = 40000,
							y = 37000,
							zoneId = 2,
							tooltip = L"Gnoblar - Sum of the Whole",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Gnoblar - Sum of the Whole
JEWELRY ITEM

Quest start in Altdorf Library from "Rogni Ironsight" on the upper floor, then head to The Badlands.

40000, 37000 - Kill "Bloodmaw Gnoblar" for a "Bloodmaw Gnoblar's Nose".

Three other parts are in Black Crag and Cinderfall, see entries in those zones for info.  Once you have all 4 parts skulls, return to "Rogni Ironsight" in the Altdorf library to complete the quest, then equip "Limited Edition Gnoblar Collectables!" and get the unlock.
]],
				},
				
				{
					name = L"Night Goblin (Title)",
					mapPins =
					{
						{
							x = 5400,
							y = 7800,
							zoneId = 2,
							tooltip = L"Goblin, Night Goblin - Good Night Goblin",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Goblin, Night Goblin - Good Night Goblin
"The Frightful"

5400, 7800

Kill "Uzfang" inside the right huts just outside Mount Gunbad.
]],
				},

				{
					name = L"Ogre Tyrant (Title)",
					mapPins =
					{
						{
							x = 63500,
							y = 28800,
							zoneId = 2,
							tooltip = L"Ogre Tyrant - Not What it Appears",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Ogre Tyrant - Not What it Appears
"The Liberator"

63500, 28800

Equip "Tarnished Medal" pocket item droped by "Graw Leadgut" inside "Bloodmaw Cave" closest entance to him is the north one.
]],
				},

				{
					name = L"Savage Orc (Token)",
					mapPins =
					{
						{
							x = 2700,
							y = 52900,
							zoneId = 2,
							tooltip = L"Savage Orc - Scar'd for Life",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Savage Orc - Scar'd for Life
BEASTIAL TOKEN UNLOCK

2700, 52900

Kill "Skaar Vidash" standing next to a large dead tree on the hills above "Geyser Den" minor landmark. Use the cave entrance to climb up to him.
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Savage Orc (Title)",
					mapPins =
					{
						{
							x = 14300,
							y = 19800,
							zoneId = 2,
							tooltip = L"Savage Orc - Fungus Amoung Us",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Savage Orc - Fungus Amoung Us
"The Civil"

14300, 19800

Click on "Thornberry Bush" on a small island to start the quest "Fungal Warfare".

Head to 5900, 17000 and use "Strange Mushroom" in your quest inventory on "Gruk'trok", and then kill him. 

Afterwards head to Trug's Hut, Greenskin Chapter 11, and talk to "Chagas" to complete the quest for the unlock.
]],
				},
				
				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Savage Orc (Title)",
					mapPins =
					{
						{
							x = 14300,
							y = 19800,
							zoneId = 2,
							tooltip = L"Savage Orc - Fungus Amoung Us",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Savage Orc - Fungus Amoung Us
"The Civil"

14300, 19800

Click on "Thornberry Bush" on a small island to start the quest "Fungal Warfare".

Head to 5900, 17000 and use "Strange Mushroom" in your quest inventory on "Gruk'trok", and then kill him. 

Afterwards head to Copperstone's River Crossing, Dwarf Chapter 11, and talk to "Damnir Lostore" to complete the quest for the unlock.
]],
				},

				{
					name = L"Skaven (Title)",
					mapPins =
					{
						{
							x = 7400,
							y = 53900,
							zoneId = 2,
							tooltip = L"Skaven - Sign of the Times",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Skaven - Sign of the Times
"Skaven Splitter"

7400, 53900

Click on "Man Trap" just to the right in the main chamber inside "Warpclaw Hideout" minor landmark.
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Snotling (Pocket)",
					mapPins =
					{
						{
							x = 37900,
							y = 19000,
							zoneId = 2,
							tooltip = L"Snotling - Miscreant Memories",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Snotling - Miscreant Memories
POCKET ITEM

37900, 19000

Talk to "Elke Raub", she is hidden behind a big stone.
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Snotling (Pocket)",
					mapPins =
					{
						{
							x = 23700,
							y = 26600,
							zoneId = 2,
							tooltip = L"Snotling - Miscreant Memories",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Snotling - Miscreant Memories
POCKET ITEM

23700, 26600

Talk to "Foigak", a goblin on a small island in the river.
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Vulture (Title)",
					mapPins =
					{
						{
							x = 34300,
							y = 27300,
							zoneId = 2,
							tooltip = L"Vulture - Feeding Time...",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Vulture - Feeding Time...
"The Main Course"

34300, 27300

Click on "Vulture Feeder Parts" some small planks between a tree and a large rock at the bottom of the cliff.
]],
				},
			},
		},

		{
			name = L"Mount Gunbad",
			entries =
			{	
				{
					name = L"Banshee (Title)",
					mapPins =
					{
						{
							x = 33200,
							y = 39500,
							zoneId = 60,
							tooltip = L"Banshee - Stop Your Screaming",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Banshee - Stop Your Screaming
"The Mournful"

33200, 39500

Kill "Arathremia" the 3rd boss of the middle wing.
]],
				},
				
				{
					name = L"Night Goblin (Pocket)",
					mapPins =
					{
						{
							x = 33700,
							y = 43900,
							zoneId = 60,
							tooltip = L"Night Goblin - Night-Time is the Right Time",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Night Goblin - Night-Time is the Right Time
POCKET ITEM

33700, 43900

Kill "Morgit da Waaagher" in the middle wing, in the area with the giants, he on the left side as you go down tucked into the right side of one of the huts.
]],
				},
				
				{
					name = L"Plaguebeast of Nurgle (Title)",
					mapPins =
					{
						{
							x = 45600,
							y = 35300,
							zoneId = 60,
							tooltip = L"Plaguebeast of Nurgle - Say Hello to My Little Friend",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Plaguebeast of Nurgle - Say Hello to My Little Friend
"Bathes... Occasionally"

45600, 35300

Click on "Garrolath's Spawn" after killing 'Garrolath the Poxbearer' the 3rd boss of the East wing.
]],
				},

				{
					name = L"Snotling (Tactic)",
					mapPins =
					{
						{
							x = 38000,
							y = 36300,
							zoneId = 60,
							tooltip = L"Snotling - Green Lightning",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Snotling - Green Lightning
GREENSKIN TOME TACTIC

38000, 36300

Kill "Kezzen" to the right as you enter the East wing.
]],
				},

				{
					name = L"Squig (Title)",
					text =
[[
Squig ('Ard ta Feed) - Feeding Time...
"'Ard ta Eat"

Kill "Ard Ta Feed", the final dungeon boss.
]],
				},
				
				{
					name = L"Wight (Title)",
					text =
[[
Wight - Wight Place, Wight Time
"I Remember When..."

Click on "Mourkain Hourglass" above the entrance inside the Wight Lord Solithex boss room.
]],
				},
				
				{
					name = L"Winged Nightmare (Title)",
					mapPins =
					{
						{
							x = 35600,
							y = 44200,
							zoneId = 60,
							tooltip = L"Winged Nightmare - Echoes in the Deep",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Winged Nightmare - Echoes in the Deep
"Stuff of Nightmares"

35600, 44200

Kill "Vraxlyr Deepscream" straight ahead as you cross the bridge in the lowest point of the middle wing.
]],
				},
								
				{
					name = L"Wraith (Title)",
					mapPins =
					{
						{
							x = 24200,
							y = 42900,
							zoneId = 60,
							tooltip = L"Wraith - Grapes of Wraith",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Wraith - Grapes of Wraith
"Ages Like Wine"

24200, 42900

Click on "Mourkain Wine" in front of the cave that looks like a mouth with teeth, on the west side of the Herald of Solithex.
]],
				},
			},
		},

		{
			name = L"Black Fire Pass",
			entries =
			{
				{
					name = L"Bandit (Tactic)",
					mapPins =
					{
						{
							x = 57400,
							y = 44200,
							zoneId = 8,
							tooltip = L"Bandit - Robbery",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Bandit - Robbery
MAN TOME TACTIC

57400, 44200

Kill "Haaloth Bloodreaver".
]],
				},

				{
					name = L"Engineer (Pocket)",
					mapPins =
					{
						{
							x = 13600,
							y = 14500,
							zoneId = 8,
							tooltip = L"Dwarf, Engineer - What do We Have Here?",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					tomeBestiaryId = 42,
					tomeBestiaryName = L"Dwarf, Engineer",
					text =
[[
Dwarf, Engineer - What do We Have Here?
POCKET ITEM

13600, 14500 - In RvR Lake

Click on "Hidden Scroll" east of "Gnol Baraz" keep, between a broken siege weapon and a bush.

]],
				},

				{
					name = L"Squig (Tactic)",
					mapPins =
					{
						{
							x = 37200,
							y = 59500,
							zoneId = 8,
							tooltip = L"Squig - Forgotten and Famished",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Squig - Forgotten and Famished
BESTIAL TOME TACTIC

37200, 59500

Kill "Famished Squig".
]],
				},
			},
		},

		{
			name = L"Kadrin Valley",
			entries =
			{
				{
					name = L"Bloodbeast of K. (Title)",
					mapPins =
					{
						{
							x = 30300,
							y = 18900,
							zoneId = 9,
							tooltip = L"Bloodbeast of Khorne - Broken Bones",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Bloodbeast of Khorne - Broken Bones
"The Wrathful"

30300, 18900

Click on "Bones of a Bloodbeast" on the hills above "Icehearth Crossing" BO.
]],
				},

				{
					name = L"Dwarf (Title)",
					mapPins =
					{
						{
							x = 34500,
							y = 7000,
							zoneId = 9,
							tooltip = L"Dwarf - The History of the Dwarfs",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Dwarf - The History of the Dwarfs
"Forgebreaker"

34500, 7000 - In RvR Lake

Click on "Hidden Scroll" NW of the "Hardwater Falls" BO, behind some rocks.
]],
				},

				{
					name = L"Slayer (Pocket)",
					mapPins =
					{
						{
							x = 34000,
							y = 4000,
							zoneId = 9,
							tooltip = L"Dwarf, Slayer - What do We Have Here?",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					tomeBestiaryId = 43,
					tomeBestiaryName = L"Dwarf, Slayer",
					text =
[[
Dwarf, Slayer - What do We Have Here?
POCKET ITEM

34000, 4000 - In RvR Lake

Click on "Hidden Scroll" East from "Gharvin's Brace" warcamp under a tree.

]],
				},

				{
					name = L"Dwarf Slayer (Tactic)",
					mapPins =
					{
						{
							x = 28700,
							y = 40200,
							zoneId = 9,
							tooltip = L"Dwarf, Slayer - Look Out Below!",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Dwarf, Slayer - Look Out Below!
MAN TOME TACTIC

28700, 40200

Click on "Stonesmith Supplies" a barrel on the end of the north east section of the broken bridge.
]],
				},

				{
					name = L"Bear (Tactic)",
					mapPins =
					{
						{
							x = 4900,
							y = 14800,
							zoneId = 9,
							tooltip = L"Bear - Sharpen Your Knives",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Bear - Sharpen Your Knives
BEASTIAL TOME TACTIC

4900, 14800

Kill "Thag Bolgar" wandering in the valley area behind "Plague Mist Vale" PQ.
]],
				},

				{
					name = L"Beastman, Gor (Tactic)",
					mapPins =
					{
						{
							x = 26100,
							y = 23200,
							zoneId = 9,
							tooltip = L"Beastman, Gor - For the Greater Gor",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Beastman, Gor - For the Greater Gor
CHAOS TOME TACTIC

26100, 23200

Kill "Yarrgan The Fiendish" a large gor, standing on the edge of the camp.
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Dwarf Slayer (Acc)",
					mapPins =
					{
						{
							x = 58100,
							y = 49500,
							zoneId = 9,
							tooltip = L"Dwarf Slayer - Looking for Trouble",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Dwarf Slayer - Looking for Trouble
JEWELRY ITEM

58100, 49500

Kill "Argnus Rockskull", a slayer NPC next to a small tent.
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Dwarf Slayer (Acc)",
					mapPins =
					{
						{
							x = 58100,
							y = 49500,
							zoneId = 9,
							tooltip = L"Dwarf Slayer - Looking for Trouble",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Dwarf Slayer - Looking for Trouble
JEWELRY ITEM

58100, 49500

Talk to "Argnus Rockskull", a slayer NPC next to a small tent.
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Giant Lizard (Tactic)",
					mapPins =
					{
						{
							x = 35000,
							y = 36600,
							zoneId = 9,
							tooltip = L"Giant - Brutal Nose Ring",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Giant Lizard - Hunger Pangs
BESTIAL TOME TACTIC

35000, 36600

Kill "Snowfury Fork-tongue" mobs around this area, to complete the Kill Collector at "Gashfang's Warband", Greenskin Chapter 21 camp.
]],
				},

				{
					name = L"Giant (Tactic)",
					mapPins =
					{
						{
							x = 33400,
							y = 28000,
							zoneId = 9,
							tooltip = L"Giant - Brutal Nose Ring",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Giant - Brutal Nose Ring
GIANT TOME TACTIC

33400, 28000

Equip "Giant Nosering" pocket item droped by "Vragi the Brute" standing on the top of the cliff looking down over the dwarf fort.
]],
				},

				{
					name = L"Nurgling (Tactic)",
					mapPins =
					{
						{
							x = 40400,
							y = 24800,
							zoneId = 9,
							tooltip = L"Nurgling - Say Hello to My Little Friends",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Nurgling - Say Hello to My Little Friends
DAEMONIC TOME TACTIC

40400, 24800

Kill "Vlasi Ipatiev" standing on the edge of the cliff, with 3 nurglings.
]],
				},

				{
					name = L"Rat Ogre (Title)",
					mapPins =
					{
						{
							x = 57800,
							y = 45000,
							zoneId = 9,
							tooltip = L"Rat Ogre - To the Death",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Rat Ogre - To the Death
"The Scarred"

57800, 45000

Kill "Burrow Champion" a level 38 champion at the back of the cave. Go up the slope on the left, NOT into Tunnel of Baradum.
]],
				},

				{
					name = L"Troll, Stone (Acc)",
					mapPins =
					{
						{
							x = 31200,
							y = 26500,
							zoneId = 9,
							tooltip = L"Stone Troll - Diamond in the Rough",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Stone Troll - Diamond in the Rough
JEWELRY ITEM

31200, 26500

Equip "Consumed Rough Diamond" pocket item droped by "Boulder Chukka" mobs along the top of the cliff in this area.
]],
				},
			},
		},

		{
			name = L"Thunder Mountain",
			entries =
			{
				{
					name = L"Bull Ogre (Acc)",
					mapPins =
					{
						{
							x = 48000,
							y = 55200,
							zoneId = 5,
							tooltip = L"Bull Ogre - You Going to Eat That?",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Bull Ogre - You Going to Eat That?
JEWELRY ITEM

48000, 55200

Click on "Cauldron".
]],
				},

				{
					name = L"Dragon (Title)",
					mapPins =
					{
						{
							x = 1100,
							y = 21400,
							zoneId = 5,
							tooltip = L"Dragon - All That Remains",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Dragon - All That Remains
"Fireborn"

1100, 21400

Click on "The Broken Axe Sindir Cragborn" on top of the mountain above "Nothing Cave" minor landmark.
]],
				},

				{
					name = L"Drakk Cultist (Tactic)",
					mapPins =
					{
						{
							x = 18700,
							y = 3500,
							zoneId = 5,
							tooltip = L"Drakk Cultist - Hard To Be a Leader",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Drakk Cultist - Hard To Be a Leader
MAN TOME TACTIC

18700, 3500

Kill a "Lehnera", at the very end of the "Dragon Breath Cave" major landmark.
]],
				},

				{
					name = L"Drakk Cultist (Title)",
					mapPins =
					{
						{
							x = 20300,
							y = 7200,
							zoneId = 5,
							tooltip = L"Drakk Cultist - Where the Blood Flows",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Drakk Cultist - Where the Blood Flows
"The Harrier"

20300, 7200

Click on "Drakk Altar", at the very end of the "Dragon Breath Cave" major landmark.
]],
				},

				{
					name = L"Giant (Pocket)",
					mapPins =
					{
						{
							x = 11700,
							y = 24600,
							zoneId = 5,
							tooltip = L"Giant - X Marks the Spot",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Giant - X Marks the Spot
POCKET ITEM

11700, 24600

Click on "Bugman's XXXXXX" a barrel amoungst a pile of others, just west of the merchant in "Palik Watch" Dwarf Chapter 18 camp.
]],
				},

				{
					name = L"Spider (Tactic)",
					mapPins =
					{
						{
							x = 62700,
							y = 23000,
							zoneId = 5,
							tooltip = L"Giant Spider - Big Identity Crisis",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Giant Spider - Big Identity Crisis
BESTIAL TOME TACTIC

62700, 23000

Kill "Graelba" in amoungst the other spiders in the area.
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Spider (Acc)",
					mapPins =
					{
						{
							x = 42000,
							y = 6900,
							zoneId = 5,
							tooltip = L"Giant Spider - Sacking for Sacs",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Giant Spider - Sacking for Sacs
JEWELRY ITEM

42000, 6900

Kill "Magma Crawler" mobs, and collect 5 "Arachnid Poison Sac" drops, then trade them in at The Inevitable City Lyceum for "Vial of Concentrated Venom" and equip it for the unlock.
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Spider (Acc)",
					mapPins =
					{
						{
							x = 42000,
							y = 6900,
							zoneId = 5,
							tooltip = L"Giant Spider - Sacking for Sacs",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Giant Spider - Sacking for Sacs
JEWELRY ITEM

42000, 6900

Kill "Magma Crawler" mobs, and collect 5 "Arachnid Poison Sac" drops, then trade them in at Altdorf library for "Vial of Concentrated Venom" and equip it for the unlock.
]],
				},

				{
					name = L"H. of Tzeentch (Tactic)",
					mapPins =
					{
						{
							x = 16100,
							y = 17900,
							zoneId = 5,
							tooltip = L"Horror of Tzeentch - What Horrifies Horrors?",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Horror of Tzeentch - What Horrifies Horrors?
DAEMONIC TOME TACTIC

16100, 17900

Equip "An Odd Doll" pocket item droped by "Mysterious Horror" mobs around the lava lake on top of the hill.
]],
				},

				{
					name = L"Rhinox (Title)",
					mapPins =
					{
						{
							x = 49000,
							y = 55600,
							zoneId = 5,
							tooltip = L"Rhinox - Dense and Denser",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Rhinox - Dense and Denser
"The Rhinox Rocker"

49000, 55600

Click on "Rhinox Bonepile" in the edge of the lava.
]],
				},
			},
		},

		{
			name = L"Cinderfall",
			entries =
			{
				{
					name = L"Basilisk (Acc)",
					mapPins =
					{
						{
							x = 38300,
							y = 35400,
							zoneId = 26,
							tooltip = L"Basilisk - No Reflection of Your Skill",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Basilisk - No Reflection of Your Skill
SET ITEM

38300, 35400

Click on "Komnor Bronzemug" behind the rock spike, near the edge of the lava.
]],
				},

				{
					name = L"Dragon (Title)",
					mapPins =
					{
						{
							x = 46600,
							y = 25500,
							zoneId = 26,
							tooltip = L"Dragon - Son of A...",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Dragon - Son of A...
"Hot-Blooded"

46600, 25500

Kill "Arathien" the lord from the final 5th stage of "The Cult of Drakk" PQ.
]],
				},

				{
					name = L"Drakk Cultist (Tactic)",
					mapPins =
					{
						{
							x = 46600,
							y = 25500,
							zoneId = 26,
							tooltip = L"Drakk Cultist - Don't Die All At Once",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Drakk Cultist - Don't Die All At Once
MAN TOME TACTIC

46600, 25500

Kill "Merona the Scaleseeker" the Hero from the final 4th stage of "The Cult of Drakk" PQ.
]],
				},

				{
					name = L"Drakk Cultist (Pocket)",
					mapPins =
					{
						{
							x = 57300,
							y = 29900,
							zoneId = 26,
							tooltip = L"Drakk Cultist - The Sacrifice Has Been Canceled for Today",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Drakk Cultist - The Sacrifice Has Been Canceled for Today
POCKET ITEM

57300, 29900

Click on "Drakk Offering", three humans waiting to be burnt at the stake. Anyone of the three will work.
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Ghoul (Tactic)",
					mapPins =
					{
						{
							x = 54000,
							y = 43000,
							zoneId = 26,
							tooltip = L"Ghoul - Finger Lickign Good",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Ghoul - Finger Lickign Good
BESTIAL TOME TACTIC

54000, 43000

Kill "Deathflame Ghoul" mobs around this area, to complete the Kill Collector at "Da Scrappin' Camp", Greenskin Chapter 18 camp.
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Ghoul (Tactic)",
					mapPins =
					{
						{
							x = 20300,
							y = 55800,
							zoneId = 26,
							tooltip = L"Ghoul - Finger Licking Good",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Ghoul - Finger Licking Good
BESTIAL TOME TACTIC

20300, 55800

Kill "Flamepicked Ghoul" mobs around this area, to complete the Kill Collector at "Palik Watch", Dwarf Chapter 18 camp.
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Gnoblar (Acc)",
					mapPins =
					{
						{
							x = 58500,
							y = 53200,
							zoneId = 26,
							tooltip = L"Gnoblar - Sum of the Whole",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Gnoblar - Sum of the Whole
JEWELRY ITEM

Quest start in Altdorf Library from "Rogni Ironsight" on the upper floor, then head to Cinderfall.

58500, 53200 - Kill "Gutbash Trappers" for a "Gnoblar Trapper's Trap Part".

56700, 51700 - Kill "Gutbash Tooth Gnoblars" for a "Tooth Gnoblar's Tooth".

Two other parts are in Badlands and Black Crag, see entries in those zones for info.  

Once you have all 4 parts skulls, return to "Rogni Ironsight" in the Altdorf library to complete the quest, then equip "Limited Edition Gnoblar Collectables!" and get the unlock.
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Skeleton (Acc)",
					mapPins =
					{
						{
							x = 61800,
							y = 3320,
							zoneId = 26,
							tooltip = L"Skeleton - Coin of the Trade",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Skeleton - Coin of the Trade
JEWELRY ITEM

Quest start in Thunder Mountain at "Palik Watch", Dwarf Chapter 18. Speak to "Grimdron Lorebeard", next to the mailbox, to start the quest "Remembering the Fallen", then head to Cinderfall.

61800, 3320 - Click on "Deanimated Dwarf Skeleton" inside "Cave" on the map which goes into "Emberlight Mine" PQ.  Up the ramp on the left in the main chamber. "Undead Dwarf Skull" will be added to your quest inventory.

64300, 49600 - Click on "Deanimated Human Skeleton" inside "Cave" straight ahead as you enter against the right tunnel support. "Undead Human Skull" will be added to your quest inventory.

57400, 58300 - Click on "Deanimated Elven Skeleton" just outside the entrance to "Cave" after crossing the bridge. "Undead Elven Skull" will be added to your quest inventory.

Once you have all three skulls, return to "Grimdron Lorebeard" at chapter 18 to complete the quest, then equip "Skulls of the Fallen" and get the unlock.
]],
				},

				{
					name = L"Zombie (Tactic)",
					mapPins =
					{
						{
							x = 43800,
							y = 2500,
							zoneId = 26,
							tooltip = L"Zombie - Wulgrig",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Zombie - Wulgrig
UNDEAD TOME TACTIC UNLOCK

43800, 2500

Kill "Wulgrig" inside "Palik Tunnels" major landmark, go straight ahead and down the spiral, then turn left and click on "Pile of Rocks" in the first chamber to spawn him.
]],
				},
			},
		},

		{
			name = L"Death Peak",
			entries =
			{
				{
					name = L"Ghoul (Acc)",
					mapPins =
					{
						{
							x = 10800,
							y = 36300,
							zoneId = 27,
							tooltip = L"Ghoul - Demoted",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Ghoul - Demoted
JEWLERY ITEM

10800, 36300

Kill "Pisacha the Rank" standing just north of the road.
]],
				},

				{	
					name = L"Wight (Title)",
					mapPins =
					{
						{
							x = 3200,
							y = 11700,
							zoneId = 27,
							tooltip = L"Wight - Dead Weight",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Wight - Dead Weight
"The King Slayer"

3200, 11700

Kill "Seno Cirrus", inside "Acidburn Cave" major landmark. He is at the end of the first right way of the cave.
]],
				},

				{
					name = L"Winged N. (Title)",
					mapPins =
					{
						{
							x = 12000,
							y = 11200,
							zoneId = 27,
							tooltip = L"Winged Nightmare - Clip Its Wings",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Winged Nightmare - Clip Its Wings
"The Dreamstealer"

12000, 11200

Kill "Terrorwing" tucked into the hill, west of the broken tower.
]],
				},

				{
					name = L"Wyvern (Title)",
					mapPins =
					{
						{
							x = 10000,
							y = 45600,
							zoneId = 27,
							tooltip = L"Wyvern - In the Wild",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Wyvern - In the Wild
"The Wyvern Watcher"

10000, 45600

Click on "Damaged Wyvern Egg" in the small nook in the lower part of the final chamber of an unmarked cave due south of "Whoosha's Boyz" PQ.
]],
				},
			},
		},

		{
			name = L"Black Crag",
			entries =
			{
				{
					name = L"Basilisk (Title)",
					mapPins =
					{
						{
							x = 5600,
							y = 8900,
							zoneId = 3,
							tooltip = L"Basilisk - Cave of Stone",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Basilisk - Cave of Stone
"The Rock"

5600, 8900

Enter "Sulfur Caves" minor landmark.
]],
				},

				{	
					name = L"Basilisk (Tactic)",
					mapPins =
					{
						{
							x = 9500,
							y = 10800,
							zoneId = 3,
							tooltip = L"Basilisk - It's in the Bag",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Basilisk - It's in the Bag
BESTIAL TOME TACTIC

9500, 10800

Equip "Bag of 'Lisk Meat" purchased from your city library vendor. You need 6 "Lisk Meat" items dropped by killing "Young Basilisk" mobs at the above location.
]],
				},

				{
					name = L"Basilisk (Tactic)",
					mapPins =
					{
						{
							x = 39800,
							y = 39400,
							zoneId = 3,
							tooltip = L"Basilisk - Scales of Mourning",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Basilisk - Scales of Mourning
BEASTIAL TOME TACTIC UNLOCK

39800, 39400

Kill "Black Scale" a level 39 champion amoungst the burnt hunts.
]],
				},

				{
					name = L"Bat, Giant (Tactic)",
					mapPins =
					{
						{
							x = 11500,
							y = 33800,
							zoneId = 3,
							tooltip = L"Bat, Giant - In the Dark of Day",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Bat, Giant - In the Dark of Day
BEASTIAL TOME TACTIC UNLOCK

11500, 33800

Enter the last chamber of "Bat Hollow" major landmark area.
]],
				},

				{
					name = L"Choppa (Pocket)",
					mapPins =
					{
						{
							x = 28500,
							y = 49900,
							zoneId = 3,
							tooltip = L"Orc, Choppa - What do We Have Here?",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					tomeBestiaryId = 93,
					tomeBestiaryName = L"Orc, Choppa",
					text =
[[
Orc, Choppa - What do We Have Here?
POCKET ITEM

28500, 49900 - In RvR Lake

Click on "Hidden Scroll" on the east side of the path under a bush at the base of the large tree..

]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Dryad (Tactic)",
					mapPins =
					{
						{
							x = 38600,
							y = 45200,
							zoneId = 3,
							tooltip = L"Dryad - Fire Seldom Dies Alone",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Dryad - Fire Seldom Dies Alone
MYTHICAL TOME TACTIC

38600, 45200 - Quest Start Location

Click on "Crate of Torches" to receive a "Torch" into you quest inventory. Right click the torch to start the quest "A Burning Desire", then head to the marked areas in the rvr lake and kill 10 "Ashridden Dryad" mobs for the ash.  Once completed return to the crate and hand the quest into "Godor Bronzemug" for the unlock.
]],
				},

				{
					name = L"Giant (Tactic)",
					mapPins =
					{
						{
							x = 35600,
							y = 52700,
							zoneId = 3,
							tooltip = L"Giant - Giant Amongst Giants",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Giant - Giant Amongst Giants
GIANT TOME TACTIC

35600, 52700

Kill "Ufgor" standing on the back right corner of the broken tower, near a couple of outher seated giants.
]],
				},

				{	
					name = L"Gnoblar (Title)",
					mapPins =
					{
						{
							x = 40900,
							y = 12000,
							zoneId = 3,
							tooltip = L"Gnoblar - Mixed Company",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Gnoblar - Mixed Company
"The Bully"

40900, 12000

Approach "Burnmaw Tower" major landmark, which is surrounded with Ogres and Gnoblars.
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Gnoblar (Acc)",
					mapPins =
					{
						{
							x = 41700,
							y = 10500,
							zoneId = 3,
							tooltip = L"Gnoblar - Sum of the Whole",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Gnoblar - Sum of the Whole
JEWELRY ITEM

Quest start in Altdorf Library from "Rogni Ironsight" on the upper floor, then head to Black Crag.

41700, 10500 - Kill "Burnmaw Gnoblar" for a "Burnmaw Gnoblar's Shiny Bits".

Three other parts are in Badlands and Cinderfall, see entries in those zones for info.  Once you have all 4 parts skulls, return to "Rogni Ironsight" in the Altdorf library to complete the quest, then equip "Limited Edition Gnoblar Collectables!" and get the unlock.
]],
				},

				{	name = L"Goblin (Title)",
					mapPins =
					{
						{
							x = 39500,
							y = 61000,
							zoneId = 3,
							tooltip = L"Goblin - The History of the Goblins",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Goblin - The History of the Goblins
"Grot's Doom"

39500, 61000 - In RvR Lake

Click on "Hidden Scroll" inside the south entance down to "Badmoon Hole" keep. At the base of a big rock column between two mushrooms.
]],
				},

				{
					name = L"Slimehound (Title)",
					mapPins =
					{
						{
							x = 29700,
							y = 29100,
							zoneId = 3,
							tooltip = L"Slimehound - An Easy Trail to Follow",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Slimehound - An Easy Trail to Follow
"The Slime-Trodder"

29700, 29100

Click on "Slimehound Remains", on the left side of the entance to "Stonemane Mine" major landmark, behind some bushes.
]],
				},

				{
					name = L"Snotling (Tactic)",
					mapPins =
					{
						{
							x = 62200,
							y = 61400,
							zoneId = 3,
							tooltip = L"Snotling - Relish the Relics",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Snotling - Relish the Relics
GREENSKIN TOME TACTIC

62200, 61400

Equip "Relic Sword of Verena" pocket item, droped by "Hoarding Burrower" mob, standing in the corner of the last room in Cliffrunners Den.
]],
				},

				{	
					name = L"Wyvern (Acc)",
					mapPins =
					{
						{
							x = 21300,
							y = 9100,
							zoneId = 3,
							tooltip = L"Wyvern - Let's See What This Does",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Wyvern - Let's See What This Does
JEWELRY ITEM

21300, 9100

Click on "Wyvern Trap" looks like a ring of 8 pegs on the ground. Requires "Fresh Squig Meat" obtained from nearby "Rustspatter Squig" mobs. 
]],
				},

				{
					name = L"Troll (Tactic)",
					mapPins =
					{
						{
							x = 6300,
							y = 24600,
							zoneId = 3,
							tooltip = L"Troll - Rock in the Maw of Darkness",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Troll - Rock in the Maw of Darkness
GIANT TOME TACTIC

6300, 24600

Kill "Rockmaw" a level 31 champion.
]],
				},

				{
					name = L"Troll (Tactic)",
					mapPins =
					{
						{
							x = 2700,
							y = 27900,
							zoneId = 3,
							tooltip = L"Troll - Prescribed Flesh",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Troll - Prescribed Flesh
GIANT TOME TACTIC

2700, 27900

Equip "Troll Flesh" pocket item, droped by "Stonegullet Troll" mobs, in "The Despair Pits" major landmark area.
]],
				},

				{
					name = L"Troll (Tactic)",
					mapPins =
					{
						{
							x = 600,
							y = 20300,
							zoneId = 3,
							tooltip = L"Troll, Stone - Indigestion",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Troll, Stone - Indigestion
GIANT TOME TACTIC

600, 20300

Click on "Drul's Lunch" a group of 4 rocks, near the end of the north tunnel inside "The Despair Pits" major landmark. Requires "Poison Gland" obtained from "Skittering Scorpion" mobs on the left as you enter the cave.
]],
				},
			},
		},

		{
			name = L"Butcher's Pass",
			entries =
			{
				{
					name = L"Orc (Title)",
					mapPins =
					{
						{
							x = 23600,
							y = 12600,
							zoneId = 4,
							tooltip = L"Orc - The History of the Orcs",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Orc - The History of the Orcs
"The Orc Flayer"

23600, 12600 - In RvR Lake

Click on "Hidden Scroll" a the base of the large tree, outside the west gate.
]],
				},
			},
		},
	},
}
