TTitan.Data.HistoryDvG = {}

function TTitan.Data.HistoryDvG.GetData()
	return TTitan.Data.HistoryDvG.RawData
end

function TTitan.Data.HistoryDvG.FilterData()
	TTitan.Data.FilterByRealm(TTitan.Data.HistoryDvG.RawData)
end

TTitan.Data.HistoryDvG.RawData =
{
	header = L"History & Lore Unlocks - Dwarfs vs Greenskins",
	categories =
	{
		{
			name = L"Ekrund",
			entries =
			{
				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Gold",
					mapPins =
					{
						{
							x = 64000,
							y = 57600,
							zoneId = 6,
							tooltip = L"Gold",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
64000, 57600

Click on "Goldfist's Gold" at south end of Goldfist's Tomb, hidden behind Goldfist's Sarcophagus.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Gold",
					mapPins =
					{
						{
							x = 15300,
							y = 45100,
							zoneId = 6,
							tooltip = L"Gold",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
15300, 45100

Click on "Gold Nugget" at the mouth of the middle tunnel in the Stonemane's Junction major landmark. Right next to the tipped mine cart.
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Reclaiming Ekrund",
					mapPins =
					{
						{
							x = 51700,
							y = 40100,
							zoneId = 6,
							tooltip = L"Reclaiming Ekrund",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
51700, 40100

Click on "Royal Mining Corps" banner in Goldfist's Hole Recovery PQ.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Reclaiming Ekrund",
					mapPins =
					{
						{
							x = 19600,
							y = 46900,
							zoneId = 6,
							tooltip = L"Reclaiming Ekrund",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
19600, 46900

Click on "Commemorative Plaque" in the middle of the wall with the 4 golden gates, directly behind the dwarven champter 1 kill collector.
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Helga",
					mapPins =
					{
						{
							x = 54000,
							y = 37000,
							zoneId = 6,
							tooltip = L"Helga",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
54000, 37000

Click on "Railgun Ammo Mold" on the platform at the end of the rail line.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Helga",
					mapPins =
					{
						{
							x = 24800,
							y = 38500,
							zoneId = 6,
							tooltip = L"Helga",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
24800, 38500

Click on "Helga" the giant cannon at the top of the dwarven starting area, which looks out to the NE.
]],
				},


				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Oathbearers",
					mapPins =
					{
						{
							x = 48000,
							y = 34000,
							zoneId = 6,
							tooltip = L"Oathbearers",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
48000, 34000

Kill an "Oathbearer Ranger" just SE of Redhammer Brewery.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Oathbearers",
					mapPins =
					{
						{
							x = 21500,
							y = 40000,
							zoneId = 6,
							tooltip = L"Oathbearers",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
21500, 40000

Talk to any "Oathbearer Keeper" NPC in dwarven starting area.
]],
				},


				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Grudges",
					mapPins =
					{
						{
							x = 59400,
							y = 39100,
							zoneId = 6,
							tooltip = L"Grudges",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
59400, 39100

Click on "Slain Irontoe" behind the hut in Gorgor's Smash, Grenskin Chapter 4.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Grudges",
					mapPins =
					{
						{
							x = 20800,
							y = 41200,
							zoneId = 6,
							tooltip = L"Grudges",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
20800, 41200

Click on "Grudge Book" on a bench round a large stone column, the bench faces to the archway leaving the dwarven starting area.
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"The Pick & Goggles",
					mapPins =
					{
						{
							x = 42500,
							y = 41400,
							zoneId = 6,
							tooltip = L"The Pick & Goggles",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
42500, 41400

Click on "Stolen Stein" on a small chest at the top of Raider's Haven PQ.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"The Pick & Goggles",
					mapPins =
					{
						{
							x = 21900,
							y = 39600,
							zoneId = 6,
							tooltip = L"The Pick & Goggles",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
21900, 39600

Enter the "Picks & Goggles" tavern a major landmark in the dwarven starting area.
]],
				},

				{
					name = L"Rune Magic",
					mapPins =
					{
						{
							x = 53100,
							y = 49700,
							zoneId = 6,
							tooltip = L"Rune Magic",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
53100, 49700

Click on "Book of Runes" next to a dead dwarf skeleton up the first part of the ramp, inside Broketoof Tower.
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Cannons",
					mapPins =
					{
						{
							x = 54500,
							y = 4400,
							zoneId = 6,
							tooltip = L"Cannons",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
54500, 4400 - In RvR Lake

Click on "Cannonballs" amongst some cannons and crates.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Cannons",
					mapPins =
					{
						{
							x = 21700,
							y = 41900,
							zoneId = 6,
							tooltip = L"Cannons",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
21700, 41900

Click on "Crate of Cannonballs", any around the this area will give the unlock.
]],
				},

				{
					name = L"Ancestor Worship",
					mapPins =
					{
						{
							x = 64100,
							y = 19500,
							zoneId = 6,
							tooltip = L"Ancestor Worship",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
64100, 19500

Click on "Ancestral Statue" a large dwarven statue covered in orc mess, just off to the left-hand side of the road as you head towards Mount Bloodhorn.
]],
				},

				{
					name = L"Durak Bitterstone",
					mapPins =
					{
						{
							x = 44500,
							y = 21100,
							zoneId = 6,
							tooltip = L"Durak Bitterstone",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
44500, 21100

Approach the dwarven structure at the top of Durak's Gate PQ.  The trigger area is very tight, so hug the walls around the structure to get it to unlock.
]],
				},
			},
		},

		{
			name = L"Mount Bloodhorn",
			entries =
			{
				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Waaagh!",
					mapPins =
					{
						{
							x = 37000,
							y = 49500,
							zoneId = 11,
							tooltip = L"Waaagh!",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
37000, 49500

Approach and hug the back wall of the hut with big bones on top inside the Greenskin starting area.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Waaagh!",
					mapPins =
					{
						{
							x = 33700,
							y = 27700,
							zoneId = 11,
							tooltip = L"Waaagh!",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
33700, 27700

Click on "Orc Corpse" under the bridge at Komar Dwarf chapter 3.
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Simple Minds",
					mapPins =
					{
						{
							x = 47000,
							y = 56500,
							zoneId = 11,
							tooltip = L"Simple Minds",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
47000, 56500

Click on "Observation Point", can be accessed by climbing up the fallen log inside the Greenskin starting area.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Simple Minds",
					mapPins =
					{
						{
							x = 45800,
							y = 34800,
							zoneId = 11,
							tooltip = L"Simple Minds",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
45800, 34800

Click on "Observation Point" at Gran Thewn Watch major landmark.
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Bloody Sun Boyz",
					mapPins =
					{
						{
							x = 41500,
							y = 52500,
							zoneId = 11,
							tooltip = L"Bloody Sun Boyz",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
41500, 52500

Click on "Bloody Sun Banner", in the middle of Greenskin chapter 1.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Bloody Sun Boyz",
					mapPins =
					{
						{
							x = 45400,
							y = 44100,
							zoneId = 11,
							tooltip = L"Bloody Sun Boyz",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
45400, 44100

Click on "Bloody Sun Banner",  in the Bloody Sun Camp major landmark.
]],
				},
				
				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Choppas",
					mapPins =
					{
						{
							x = 31500,
							y = 47500,
							zoneId = 11,
							tooltip = L"Choppas",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
31500, 47500

Click on "Stunty Chopped Gud", a dwarf corpse, found in the woods north of Snout's Pens inside the Greenskin starting area.
]],
				},
			
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Choppas",
					mapPins =
					{
						{
							x = 55600,
							y = 11200,
							zoneId = 11,
							tooltip = L"Choppas",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
55600, 11200

Kill an "Invada Boy" at Forgehand's Workshop major landmark..
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Ironmane's Lock",
					mapPins =
					{
						{
							x = 40500,
							y = 60500,
							zoneId = 11,
							tooltip = L"Ironmane's Lock",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
40500, 60500

Click on "Memorial Plaque" at the bottom of the ramp on the east side of the Ironmane's Lock major landmark inside the Greenskin starting area.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Ironmane's Lock",
					mapPins =
					{
						{
							x = 30400,
							y = 41400,
							zoneId = 11,
							tooltip = L"Ironmane's Lock",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
30400, 41400

Click on "Ironclad Oil".
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Greenskin Technology",
					mapPins =
					{
						{
							x = 12500,
							y = 52000,
							zoneId = 11,
							tooltip = L"Greenskin Technology",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
12500, 52000

Talk to "Siege Git" standing on the tree stump between the two siege towers to the north west of "Da War Maka" Destruction Chapter 2 camp.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Greenskin Technology",
					mapPins =
					{
						{
							x = 12500,
							y = 52000,
							zoneId = 11,
							tooltip = L"Greenskin Technology",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
12500, 52000

Kill "Siege Git" standing on the tree stump between the two siege towers to the north west of "Da War Maka" Destruction Chapter 2 camp.
]],
				},

				{
					name = L"Da War Maka",
					mapPins =
					{
						{
							x = 18200,
							y = 54200,
							zoneId = 11,
							tooltip = L"Da War Maka",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
18200, 54200

Click on "Orc Corpse" below the north-facing blade of "Da War Maka" Greenskin Chapter 2 camp. Walk between the logs and chippings pile and you can safely get to it.
]],
				},

				{
					name = L"Rock Lobbers",
					mapPins =
					{
						{
							x = 16800,
							y = 39200,
							zoneId = 11,
							tooltip = L"Rock Lobbers",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
16800, 39200

Click on "Rock Lobber" on the south west side of "Da Gobbo Camp" major landmark, staight ahead inside from the south gate.
]],
				},

				{
					name = L"Greenskin Food",
					mapPins =
					{
						{
							x = 38900,
							y = 38800,
							zoneId = 11,
							tooltip = L"Greenskin Food",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
38900, 38800

Click on "Dinner Scraps" inside the hut, 3 piles to choose from.
]],
				},

				{
					name = L"Dragonbone Pass",
					mapPins =
					{
						{
							x = 42600,
							y = 23500,
							zoneId = 11,
							tooltip = L"Dragonbone Pass",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
42600, 23500

Click on "Drakk Bone" located at the road crossing.
]],
				},
			},
		},

		{
			name = L"Barak Varr",
			entries =
			{
				{
					name = L"Long Drong and his Slayer Pirates",
					mapPins =
					{
						{
							x = 6400,
							y = 45700,
							zoneId = 7,
							tooltip = L"Long Drong and his Slayer Pirates",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
6400, 45700

Click on "Rarest Ale" a barrel washed up on the beach west of "The Sea's Anvil" major landmark.
]],
				},

				{
					name = L"Sacred Oaths",
					mapPins =
					{
						{
							x = 36700,
							y = 45600,
							zoneId = 7,
							tooltip = L"Sacred Oaths",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
36700, 45600

Enter the damaged Dwarf tower at this location.
]],
				},

				{
					name = L"Waaagh! Magic",
					mapPins =
					{
						{
							x = 42200,
							y = 51000,
							zoneId = 7,
							tooltip = L"Waaagh! Magic",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
42200, 51000

Click on "Orc Remains" a corpse on top of the small rise, next to the road.

]],
				},

				{
					name = L"Size Matters",
					mapPins =
					{
						{
							x = 6200,
							y = 27100,
							zoneId = 7,
							tooltip = L"Size Matters",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
6200, 27100

Approach the statue missing at this location.
]],
				},

				{
					name = L"Greenskin Battle Barges",
					mapPins =
					{
						{
							x = 15400,
							y = 26900,
							zoneId = 7,
							tooltip = L"Greenskin Battle Barges",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
15400, 26900 - In RvR Lake

Go onto the docked barge at the NW end of the RvR lake.
]],
				},

				{
					name = L"One Tusk Tribe",
					mapPins =
					{
						{
							x = 4500,
							y = 30400,
							zoneId = 7,
							tooltip = L"One Tusk Tribe",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
4500, 30400

Click on "Bloody Sun Goblin", a goblin head on a small pike next to the sign posts.
]],
				},

				{
					name = L"Overlook Bridge",
					mapPins =
					{
						{
							x = 47900,
							y = 26700,
							zoneId = 7,
							tooltip = L"Overlook Bridge",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
47900, 26700

Click on "Harbor Master's Spyglass" at the south end of the large bridge inside the underground Port of Barak Varr.
]],
				},

				{
					name = L"Tribal Assimilation",
					mapPins =
					{
						{
							x = 33000,
							y = 19000,
							zoneId = 7,
							tooltip = L"Tribal Assimilation",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
33000, 19000

Click on "Fallen Banner" a large orc banner, part buried in the sand on the beach.
]],
				},

				{
					name = L"Ironclads",
					mapPins =
					{
						{
							x = 27600,
							y = 29100,
							zoneId = 7,
							tooltip = L"Ironclads",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
27600, 29100

Approach the sunken Ironclad.
]],
				},

				{
					name = L"Leviathan",
					mapPins =
					{
						{
							x = 34800,
							y = 34500,
							zoneId = 7,
							tooltip = L"Leviathan",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
34800, 34500 - In RvR Lake

Click on "Sunbaked Vertebrae" near the big bones on the beach south of "The Ironclad" BO.
]],
				},
			},
		},

		{
			name = L"Marshes of Madness",
			entries =
			{
				{
					name = L"Oathgold",
					mapPins =
					{
						{
							x = 50800,
							y = 8400,
							zoneId = 1,
							tooltip = L"Oathgold",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
50800, 8400

Click on "Oathgold" a chest next to a broken cart and dead dwarf.
]],
				},

				{
					name = L"The Mourkain",
					mapPins =
					{
						{
							x = 9500,
							y = 28800,
							zoneId = 1,
							tooltip = L"The Mourkain",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
9500, 28800

Approach the arch.
]],
				},

				{
					name = L"Who's Da Boss?",
					mapPins =
					{
						{
							x = 14500,
							y = 21000,
							zoneId = 1,
							tooltip = L"Who's Da Boss?",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
14500, 21000

Click on "Trophy Teef" at the base of the watch tower.
]],
				},

				{
					name = L"The World's Best Miners",
					mapPins =
					{
						{
							x = 61900,
							y = 52300,
							zoneId = 1,
							tooltip = L"The World's Best Miners",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
61900, 52300

Click on "Mining Tools" behind the log pile outside "Falcon's Tomb" major landmark.
]],
				},

				{
					name = L"Nebhorest, the Vampire Lord",
					mapPins =
					{
						{
							x = 27700,
							y = 22700,
							zoneId = 1,
							tooltip = L"Nebhorest, the Vampire Lord",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
27700, 22700

Click on "Grim Warning" a woodern stand with a crucifixed dwarf skeleton on it.
]],
				},

				{
					name = L"The Marsh Road",
					mapPins =
					{
						{
							x = 12700,
							y = 7400,
							zoneId = 1,
							tooltip = L"The Marsh Road",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
12700, 7400

Click on "Marsh Skeleton" one of three dwarf skeletons just of the road.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"The Black Skulls",
					mapPins =
					{
						{
							x = 33800,
							y = 12500,
							zoneId = 1,
							tooltip = L"The Black Skulls",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
33800, 12500

Talk to "Hargruk" the big orc in the red hut at the top of the "Hargruk's Camp" major landmark.
]],
				},
				
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"The Black Skulls",
					mapPins =
					{
						{
							x = 33800,
							y = 12500,
							zoneId = 1,
							tooltip = L"The Black Skulls",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
33800, 12500

Kill "Hargruk" the big orc in the red hut at the top of the "Hargruk's Camp" major landmark.
]],
				},

				{
					name = L"Vital Supplies",
					mapPins =
					{
						{
							x = 32000,
							y = 57600,
							zoneId = 1,
							tooltip = L"Vital Supplies",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
32000, 57600

Click on "Stolen Supplies" a stack of three crates on the small island, up against the large rocks.
]],
				},

				{
					name = L"Knowledge Has Its Price",
					mapPins =
					{
						{
							x = 4500,
							y = 33400,
							zoneId = 1,
							tooltip = L"Knowledge Has Its Price",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
4500, 33400

Click on "Leopold Schaffer" an empire corpse in the left chamber inside "Dawr Galaz Grung" major landmark.
]],
				},

				{
					name = L"Greenskin Stupidity",
					mapPins =
					{
						{
							x = 56400,
							y = 52400,
							zoneId = 1,
							tooltip = L"Greenskin Stupidity",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
56400, 52400

Click on "Really Empty Barrel" amoungst a group of four barrels in the north end of the lake.
]],
				},
			},
		},

		{
			name = L"The Badlands",
			entries =
			{
				{
					name = L"Animosity",
					mapPins =
					{
						{
							x = 53100,
							y = 39200,
							zoneId = 2,
							tooltip = L"Animosity",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
53100, 39200

Cross the bridge north east of "Muggar's Choppaz" Greenskins warcamp.
]],
				},

				{
					name = L"The Cauldron",
					mapPins =
					{
						{
							x = 3400,
							y = 26700,
							zoneId = 2,
							tooltip = L"The Cauldron",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
3400, 26700

Stand in 'The Cauldron' at the top of "The Cauldron" PQ.
]],
				},

				{
					name = L"Likwid Courage",
					mapPins =
					{
						{
							x = 25200,
							y = 42200,
							zoneId = 60,
							tooltip = L"Likwid Courage",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
25200, 42200

Walk near the giant cauldron in the west wing of Mount Gunbad, the one just behind Herald of Solithex.
]],
				},

				{
					name = L"Gork and Mork",
					mapPins =
					{
						{
							x = 43700,
							y = 25100,
							zoneId = 2,
							tooltip = L"Gork and Mork",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
43700, 25100

Click on "Gork'n'Mork's Fings" a rubbish pile next to the large fist and skull totem, on the ridge above to the east of "Skullbreak Ridge" PQ.
]],
				},

				{
					name = L"Blue Face Orcs",
					mapPins =
					{
						{
							x = 9000,
							y = 33200,
							zoneId = 2,
							tooltip = L"Blue Face Orcs",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
9000, 33200

Click on "Savage Corpse" in the center pit of "Savage Assault" PQ.
]],
				},

				{
					name = L"Tribal Culture",
					mapPins =
					{
						{
							x = 47100,
							y = 8500,
							zoneId = 2,
							tooltip = L"Tribal Culture",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
47100, 8500

Approach the hut on the platform west of "Bloodgash Ravine" major landmark.
]],
				},

				{
					name = L"Moonfang Tribe",
					mapPins =
					{
						{
							x = 11800,
							y = 8900,
							zoneId = 2,
							tooltip = L"Moonfang Tribe",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
11800, 8900

Click on "Moonfang Banner" on the top of the cliff edge.
]],
				},

				{
					name = L"Red Eye Tribe",
					mapPins =
					{
						{
							x = 31800,
							y = 29900,
							zoneId = 60,
							tooltip = L"Red Eye Tribe",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
31800, 29900 - In Mount Gunbad

Click on "Goblin Supplies" on the right before crossing the bridge to the west wing, next to the portal.
]],
				},

				{
					name = L"Da Little Waaagh!",
					mapPins =
					{
						{
							x = 10600,
							y = 4200,
							zoneId = 2,
							tooltip = L"Da Little Waaagh!",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
10600, 4200

Click on "Goblin Map" on a small table next to a hut up the ramp in the Night Goblin village outside Mount Gunbad.
]],
				},

				{
					name = L"Brightstone",
					mapPins =
					{
						{
							x = 26000,
							y = 32300,
							zoneId = 60,
							tooltip = L"Brightstone",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
26000, 32300 - In Mount Gunbad

Click on "Brightstone Deposit" on the right side, on the cliff edge, after entering the first chamber of the west wing (before you reach the first boss).
]],
				},

				{
					name = L"Dragon's Gut",
					mapPins =
					{
						{
							x = 22400,
							y = 54900,
							zoneId = 2,
							tooltip = L"Dragon's Gut",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
22400, 54900 - In RvR Lake

Click on the Dwarf corpse.
]],
				},

				{
					name = L"Warpstone",
					mapPins =
					{
						{
							x = 4900,
							y = 30900,
							zoneId = 2,
							tooltip = L"Warpstone",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
4900, 30900

Click on "Skaven Corpse" on the ground below the collapsed arch, near the bottom of the ramp.
]],
				},

				{
					name = L"Warpaint",
					mapPins =
					{
						{
							x = 3700,
							y = 37000,
							zoneId = 2,
							tooltip = L"Warpaint",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
3700, 37000

Click on "Table of Supplies" inside the hut.
]],
				},

				{
					name = L"Phineas Fireforge",
					mapPins =
					{
						{
							x = 3800,
							y = 28900,
							zoneId = 2,
							tooltip = L"Phineas Fireforge",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
3800, 28900

Click on "Rusty Scrollcase" on the ground behind a low broken wall.
]],
				},

				{
					name = L"Bloodspike Mesa",
					mapPins =
					{
						{
							x = 7100,
							y = 16100,
							zoneId = 2,
							tooltip = L"Bloodspike Mesa",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
7100, 16100

Click on "Slain Oathbearer" at the top of the slope slumped against the orc watchtower.
]],
				},
			},
		},

		{
			name = L"Black Fire Pass",
			entries =
			{
				{
					name = L"Beer",
					mapPins =
					{
						{
							x = 48100,
							y = 58800,
							zoneId = 8,
							tooltip = L"Beer",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
48100, 58800

Click on "Keg of Beer" just on the NW corner of the broken tower in Dwarf chapter 12 camp.
]],
				},

				{
					name = L"Battle of Black Fire Pass",
					mapPins =
					{
						{
							x = 43800,
							y = 21200,
							zoneId = 8,
							tooltip = L"Battle of Black Fire Pass",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
43800, 21200

Enter the tower at "Ancient's Reach" major landmark.
]],
				},

				{
					name = L"The Oath between Men and Dwarfs",
					mapPins =
					{
						{
							x = 5900,
							y = 22200,
							zoneId = 8,
							tooltip = L"The Oath between Men and Dwarfs",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
5900, 22200 - In RvR Lake

Click on "Plunger" at the end of tunnel, inside "Orehound's Lament" major landmark .
]],
				},

				{
					name = L"Bugman's Brewery",
					mapPins =
					{
						{
							x = 25200,
							y = 19900,
							zoneId = 8,
							tooltip = L"Bugman's Brewery",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
25200, 19900 - In RvR Lake

Click on "Long Forgotten Tools" behind "Bugman's Brewery" BO next to the ramp. 
]],
				},

				{
					name = L"Dwarf Craftsmanship",
					mapPins =
					{
						{
							x = 5100,
							y = 56800,
							zoneId = 8,
							tooltip = L"Dwarf Craftsmanship",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
5100, 56800

Click on "Dwarf Anvil" behind the building on the north side of "Tharadrik Smashin'" PQ.
]],
				},

				{
					name = L"Sisters of Shallya",
					mapPins =
					{
						{
							x = 55600,
							y = 57500,
							zoneId = 8,
							tooltip = L"Sisters of Shallya",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
55600, 57500

Click on "Medicine" a group of three small bottle by a crate, just to the right of the gate into "Hindelburg" PQ.
]],
				},

				{
					name = L"Dwarf Trains",
					mapPins =
					{
						{
							x = 23100,
							y = 42100,
							zoneId = 8,
							tooltip = L"Dwarf Trains",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
23100, 42100

Click on "Manual for New Engineers" on top of the tower.
]],
				},

				{
					name = L"Ghal Maraz",
					mapPins =
					{
						{
							x = 38900,
							y = 6100,
							zoneId = 8,
							tooltip = L"Ghal Maraz",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
38900, 6100

Approach the giant dwarf head statue that is part of the mountainside.
]],
				},

				{
					name = L"Worlds Edge Mountains",
					mapPins =
					{
						{
							x = 900,
							y = 4400,
							zoneId = 8,
							tooltip = L"Worlds Edge Mountains",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
900, 4400 - In RvR Lake

Approach the gates in the north west corner of the map.
]],
				},

				{
					name = L"The Time of Woes",
					mapPins =
					{
						{
							x = 46100,
							y = 12900,
							zoneId = 8,
							tooltip = L"The Time of Woes",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
46100, 12900

Approach the large dwarven statue.
]],
				},

				{
					name = L"The Path of Sigmar - Part One",
					mapPins =
					{
						{
							x = 14100,
							y = 44100,
							zoneId = 8,
							tooltip = L"The Path of Sigmar - Part One",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
14100, 44100

Click on "Roadside Plague" on the left side of the path. Start 'The Path of Sigmar' climb from the south side of "Snow Peak Temple" major landmark.
]],
				},

				{
					name = L"The Path of Sigmar - Part Two",
					mapPins =
					{
						{
							x = 10200,
							y = 41500,
							zoneId = 8,
							tooltip = L"The Path of Sigmar - Part Two",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
10200, 41500

Click on "Roadside Plague" on the right side of the path, after dropping down a zig zag, just in front of an angel statue.
]],
				},

				{
					name = L"The Path of Sigmar - Part Three",
					mapPins =
					{
						{
							x = 4200,
							y = 46900,
							zoneId = 8,
							tooltip = L"The Path of Sigmar - Part Three",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
4200, 46900

Click on "Roadside Plague" on the right side of the path, just in front of a Statue of Sigmar.
]],
				},

				{
					name = L"The Path of Sigmar - Part Four",
					mapPins =
					{
						{
							x = 2000,
							y = 34400,
							zoneId = 8,
							tooltip = L"The Path of Sigmar - Part Four",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
2000, 34400

Click on "Roadside Plague" on the right side of the path, on it's own in a small open area.
]],
				},

				{
					name = L"The Path of Sigmar - Conclusion",
					mapPins =
					{
						{
							x = 1400,
							y = 28900,
							zoneId = 8,
							tooltip = L"The Path of Sigmar - Conclusion",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
1400, 28900

Click on "Roadside Plague" at the end of the path, in front of a large golden Statue of Sigmar.
]],
				},
			},
		},

		{
			name = L"Kadrin Valley",
			entries =
			{
				{
					name = L"Karak Ankor",
					mapPins =
					{
						{
							x = 58100,
							y = 11900,
							zoneId = 9,
							tooltip = L"Karak Ankor",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
58100, 11900

Click on "Gold Chest" in the back right corner of the second hut as you enter on the south side (right).
]],
				},

				{
					name = L"Grimnir",
					mapPins =
					{
						{
							x = 26100,
							y = 10600,
							zoneId = 9,
							tooltip = L"Grimnir",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
26100, 10600

Click on "Shrine" the door into the "Shrire of Grimnir" major landmark.
]],
				},

				{
					name = L"Valaya",
					mapPins =
					{
						{
							x = 4900,
							y = 43600,
							zoneId = 9,
							tooltip = L"Valaya",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
4900, 43600

Click on "Prayer Book" inside the west side house, inside "Gates of Grung Grimaz" PQ.
]],
				},

				{
					name = L"Grungni",
					mapPins =
					{
						{
							x = 43400,
							y = 59400,
							zoneId = 9,
							tooltip = L"Grungni",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
43400, 59400

Click on "Mine Barrow" just at the front of "Kloingar Mine" major landmark, next to a pile of beams.
]],
				},

				{
					name = L"The King's Flying Corps",
					mapPins =
					{
						{
							x = 52700,
							y = 31400,
							zoneId = 9,
							tooltip = L"The King's Flying Corps",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
52700, 31400

Approach the Gyrocopter on the pad, south of the "Slayer Keep" major landmark.
]],
				},

				{
					name = L"Dwarf Engineers",
					mapPins =
					{
						{
							x = 7600,
							y = 44100,
							zoneId = 9,
							tooltip = L"Dwarf Engineers",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
7600, 44100

Click on "Dwarf Corpse" on the platform next to the broken gyrocopter, inside "Gates of Grung Grimaz" PQ.
]],
				},

				{
					name = L"The Slayer Oath",
					mapPins =
					{
						{
							x = 42300,
							y = 4300,
							zoneId = 9,
							tooltip = L"The Slayer Oath",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
42300, 4300

Click on "Bottles", on the first left-hand side outside table.
]],
				},

				{
					name = L"Ghavrin's Brace",
					mapPins =
					{
						{
							x = 58900,
							y = 11300,
							zoneId = 9,
							tooltip = L"Ghavrin's Brace",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
58900, 11300

Approach the statue in the middle of the walled area.
]],
				},

				{
					name = L"Karak Kadrin",
					mapPins =
					{
						{
							x = 54400,
							y = 25700,
							zoneId = 9,
							tooltip = L"Karak Kadrin",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
54400, 25700

Click on "Slayer Keep" door at the entance to "Slayer Keep" major landmark.
]],
				},

				{
					name = L"Flame Cannons",
					mapPins =
					{
						{
							x = 34500,
							y = 32000,
							zoneId = 9,
							tooltip = L"Flame Cannons",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
34500, 32000

Click on "Flame Cannon" in the corner of the wall.
]],
				},

				{
					name = L"Peak Pass",
					mapPins =
					{
						{
							x = 57400,
							y = 2600,
							zoneId = 9,
							tooltip = L"Peak Pass",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
57400, 2600

Enter "Everpeak Mine" major landmark.
]],
				},

				{
					name = L"Gyrocopters",
					mapPins =
					{
						{
							x = 58700,
							y = 43000,
							zoneId = 9,
							tooltip = L"Gyrocopters",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
58700, 43000

Approach the Gyrocopter on the pad.
]],
				},

				{
					name = L"The Slayer Heirarchy",
					mapPins =
					{
						{
							x = 46600,
							y = 36000,
							zoneId = 9,
							tooltip = L"The Slayer Heirarchy",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
46600, 36000 - In RvR Lake

Click on "Brugi" a corpse on a rock.
]],
				},

				{
					name = L"Dogs of War",
					mapPins =
					{
						{
							x = 60700,
							y = 59300,
							zoneId = 9,
							tooltip = L"Dogs of War",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
60700, 59300

Click on "Chest" in the middle one of the five smaller buildings at the back, on the right-hand side as you go in.
]],
				},

				{
					name = L"Organ Guns",
					mapPins =
					{
						{
							x = 34400,
							y = 40700,
							zoneId = 9,
							tooltip = L"Organ Guns",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
34400, 40700

Click on "Deceased Gunner" next to the destroyed organ gun.
]],
				},
			},
		},

		{
			name = L"Thunder Mountain",
			entries =
			{
				{
					name = L"Hurgan's Vent",
					mapPins =
					{
						{
							x = 10200,
							y = 18300,
							zoneId = 5,
							tooltip = L"Hurgan's Vent",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
10200, 18300

Cross the bridge over the lava.
]],
				},

				{
					name = L"The Final Grudge of Drangin Ironboots",
					mapPins =
					{
						{
							x = 40300,
							y = 55100,
							zoneId = 5,
							tooltip = L"The Final Grudge of Drangin Ironboots",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
40300, 55100

Click on "Drangin Ironboots" on the stone spike jutting out south over the lave lake, just east from "Mudja's Warcamp".
]],
				},

				{
					name = L"The Long Defeat",
					mapPins =
					{
						{
							x = 12300,
							y = 36800,
							zoneId = 5,
							tooltip = L"The Long Defeat",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
12300, 36800 - In RvR Lake

Click on "Destroyed Wagon" under the bridge.
]],
				},

				{
					name = L"Not Much Grows Here",
					mapPins =
					{
						{
							x = 15000,
							y = 59200,
							zoneId = 27,
							tooltip = L"Not Much Grows Here",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
15000, 59200 - In Death Peak

Click on "Ashen Bramble" just South of the path.
]],
				},

				{
					name = L"Last Stand at Karak Palik",
					mapPins =
					{
						{
							x = 23400,
							y = 43300,
							zoneId = 5,
							tooltip = L"Last Stand at Karak Palik",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
23400, 43300 - In RvR Lake

Click on "Slain Defender" behind the wall, on the South West side of "Karak Palik" BO.
]],
				},

				{
					name = L"Und-a-Runki Book of Grudges",
					mapPins =
					{
						{
							x = 3000,
							y = 62800,
							zoneId = 5,
							tooltip = L"Und-a-Runki Book of Grudges",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
3000, 62800

Click on "Book of Grudges" inside "Und-a-Runki" PQ. Straight ahead as you enter, on some crates by the right statue.
]],
				},

				{
					name = L"Ash Crawler Victims",
					mapPins =
					{
						{
							x = 15300,
							y = 55000,
							zoneId = 5,
							tooltip = L"Ash Crawler Victims",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
15300, 55000

Click on "Pile of Skulls" to the side of the path.
]],
				},

				{
					name = L"Runelords",
					mapPins =
					{
						{
							x = 6300,
							y = 10100,
							zoneId = 27,
							tooltip = L"Runelords",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
6300, 10100 - In Death Peak

Click on "Ancient Anvil" at "Sinar Orcstom" major landmark.
]],
				},

				{
					name = L"Sons of Valaya",
					mapPins =
					{
						{
							x = 62000,
							y = 6200,
							zoneId = 5,
							tooltip = L"Sons of Valaya",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
62000, 6200

Enter the building at the far east of the "Sons Of Valaya" PQ.
]],
				},

				{
					name = L"The Golden Lumps",
					mapPins =
					{
						{
							x = 17600,
							y = 49300,
							zoneId = 5,
							tooltip = L"The Golden Lumps",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
17600, 49300

Click on "Golden Lumps" on the edge of the lava.
]],
				},

				{
					name = L"Reichert's Red Raiders",
					mapPins =
					{
						{
							x = 5200,
							y = 12800,
							zoneId = 5,
							tooltip = L"Reichert's Red Raiders",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
5200, 12800

Click on "Ill-Gotten Goods", a chest inside the South West tent.
]],
				},

				{
					name = L"The Throng of Karaz-a-Karak",
					mapPins =
					{
						{
							x = 47800,
							y = 14700,
							zoneId = 5,
							tooltip = L"The Throng of Karaz-a-Karak",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
47800, 14700

Click on "Remnant of Battle" on top of the broken piece of wall, just north of the main road. 
]],
				},

				{
					name = L"View from the Top",
					mapPins =
					{
						{
							x = 25700,
							y = 1000,
							zoneId = 5,
							tooltip = L"View from the Top",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
25700, 1000

Click on "Congratulatory Plaque" on top of the mountain. Can start the climb from the road at 10000, 1000.
]],
				},

				{
					name = L"The Bone Field",
					mapPins =
					{
						{
							x = 50000,
							y = 8500,
							zoneId = 5,
							tooltip = L"The Bone Field",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
50000, 8500

Click on "Fertilizer" a skeletal arm on the ground, close to the obelisk.
]],
				},

				{
					name = L"Built to Last",
					mapPins =
					{
						{
							x = 38900,
							y = 48800,
							zoneId = 26,
							tooltip = L"Built to Last",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
38900, 48800 - In Cinderfall

Click on "Pressurized Steam Vat", inside an unmarked the cave that opens out into a dwarf hall, just at the top of the big ramp on the left side.
]],
				},
			},
		},

		{
			name = L"Black Crag",
			entries =
			{
				{
					name = L"Morkfang and Grimgork",
					mapPins =
					{
						{
							x = 11600,
							y = 28600,
							zoneId = 3,
							tooltip = L"Morkfang and Grimgork",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
11700, 28800

Walk on the platform with the three barrels and the crane. trigger is very small on or around the patch of dirt.
]],
				},

				{
					name = L"Squigger",
					mapPins =
					{
						{
							x = 17900,
							y = 36400,
							zoneId = 3,
							tooltip = L"Squigger",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
17900, 36400

Click on "Orc Banner" west of Greenskin chapter 15 camp.
]],
				},

				{
					name = L"Frenzy",
					mapPins =
					{
						{
							x = 50700,
							y = 12800,
							zoneId = 3,
							tooltip = L"Frenzy",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
50700, 12800

Click on "Orc Corpse" on the south side of the road under a bush, south of Dwarf Chapter 20. 
]],
				},

				{
					name = L"Vandalism",
					mapPins =
					{
						{
							x = 46100,
							y = 44500,
							zoneId = 3,
							tooltip = L"Vandalism",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
46100, 44500

Click on "Vandalized Statue" up against the rock.
]],
				},

				{
					name = L"Effigies and Totems",
					mapPins =
					{
						{
							x = 16000,
							y = 10200,
							zoneId = 3,
							tooltip = L"Effigies and Totems",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
16000, 10200

Click on "Gork'n'Mork Totem" on the North edge of the canyons.
]],
				},

				{
					name = L"The Throngmortar of Sturlin Thunderhelm",
					mapPins =
					{
						{
							x = 20100,
							y = 19300,
							zoneId = 3,
							tooltip = L"The Throngmortar of Sturlin Thunderhelm",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
20100, 19300 - In RvR lake

Click on "Charred skull" amongst a small group of rocks, west of Ironskin Skar keep, near the bottom of the cliff.
]],
				},

				{
					name = L"The Greenskin Muck Pen",
					mapPins =
					{
						{
							x = 32700,
							y = 26800,
							zoneId = 3,
							tooltip = L"The Greenskin Muck Pen",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
32700, 26800

Click on "Slimy Muck Bubble" a white blob in the water.
]],
				},

				{
					name = L"Ur'kar's Lair",
					mapPins =
					{
						{
							x = 10400,
							y = 38900,
							zoneId = 3,
							tooltip = L"Ur'kar's Lair",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
10400, 38900

Click on "Jarl Themsbold" a corpse caught on top of the rocks, you can walk up them from the NE corner.
]],
				},

				{
					name = L"The Brothers Damgrundsson",
					mapPins =
					{
						{
							x = 19100,
							y = 56800,
							zoneId = 3,
							tooltip = L"The Brothers Damgrundsson",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
19100, 56800

Click on "Ammo Crate" behind all the boulders to the north "Gudmud's Strong-Huts" warcamp. 
]],
				},

				{
					name = L"Keebsta's Dead Giant-Killin' Gits",
					mapPins =
					{
						{
							x = 12300,
							y = 41400,
							zoneId = 3,
							tooltip = L"Keebsta's Dead Giant-Killin' Gits",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
12300, 41400

Click on "Goblin Weapons" nearish to the edge of the cliff, at the top.
]],
				},

				{
					name = L"Morkfang Treasure Chest",
					mapPins =
					{
						{
							x = 8800,
							y = 27800,
							zoneId = 3,
							tooltip = L"Morkfang Treasure Chest",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
8800, 27800

Click on "Morkfang Treasure" a chest inside the hut up on the platform.
]],
				},

				{
					name = L"Echo Bluff Watchpoint",
					mapPins =
					{
						{
							x = 23300,
							y = 26500,
							zoneId = 3,
							tooltip = L"Echo Bluff Watchpoint",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
23300, 26500

Click on "Oathbearer Tent" on top of the plateau.
]],
				},

				{
					name = L"King's Bluff",
					mapPins =
					{
						{
							x = 34700,
							y = 38600,
							zoneId = 3,
							tooltip = L"King's Bluff",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
34700, 38600

Click on "Historian's Kit" on the ramp into the RvR lake.
]],
				},

				{
					name = L"Redfang Camp",
					mapPins =
					{
						{
							x = 50600,
							y = 58100,
							zoneId = 3,
							tooltip = L"Redfang Camp",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
50600, 58100

Click on "Kazador's Kin" a crucified dwarf skeleton next to the path.
]],
				},

				{
					name = L"Shiny Trinkets",
					mapPins =
					{
						{
							x = 56800,
							y = 27600,
							zoneId = 3,
							tooltip = L"Shiny Trinkets",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
56800, 27600

Click on "Crate of Shinies" on the left as you enter "Da Great Smashin' Pit" PQ.
]],
				},
			},
		},
		
		{
			name = L"Karaz-a-Karak",
			entries =
			{
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Warrior's Stand",
					mapPins =
					{
						{
							x = 28600,
							y = 44700,
							zoneId = 62,
							tooltip = L"Warrior's Stand",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
28600, 44700

Go up onto the raised platform area in the Warrior's Stand area on the map (Red area).
]],
				},
				
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"The Forge",
					mapPins =
					{
						{
							x = 20500,
							y = 33000,
							zoneId = 62,
							tooltip = L"The Forge",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
20500, 33000

Approach "The Forge" major landmark on the map at this location.
]],
				},
				
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"The Great Vault",
					mapPins =
					{
						{
							x = 25700,
							y = 31500,
							zoneId = 62,
							tooltip = L"The Great Vault",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
25700, 31500

Approach the bankers inside "The Vault" major landmark, in the Merchant District. (Blue area)
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"The Feast Hall",
					mapPins =
					{
						{
							x = 38600,
							y = 36500,
							zoneId = 62,
							tooltip = L"The Feast Hall",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
38600, 36500

Enter the area around the "Feast Hall" major landmark.
]],
				},
				
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"The Brewery",
					mapPins =
					{
						{
							x = 41600,
							y = 36500,
							zoneId = 62,
							tooltip = L"The Brewery",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
41600, 36500

Enter the area east of the "Feast Hall" major landmark, unlocked just up the stairs between the two Brewery Warden NPCs.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"The Steadfast Inn",
					mapPins =
					{
						{
							x = 39800,
							y = 26300,
							zoneId = 62,
							tooltip = L"The Steadfast Inn",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
39800, 26300

Approach the back of the tavern to trigger the unlock.
]],
				},
				
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"The High King's Hold",
					mapPins =
					{
						{
							x = 28500,
							y = 26500,
							zoneId = 62,
							tooltip = L"The High King's Hold",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
28500, 26500

Enter the area "High King's Hold" on the map (Green area).
]],
				},
				
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"The Great Gate",
					mapPins =
					{
						{
							x = 28700,
							y = 49200,
							zoneId = 62,
							tooltip = L"The Great Gate",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
28500, 49200

Talk to "The Gatekeeper" NPC, in the middle right in front of the huge door, at the very south of the map.
]],
				},
				
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Stonebread",
					mapPins =
					{
						{
							x = 39800,
							y = 31300,
							zoneId = 62,
							tooltip = L"Stonebread",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
39800, 31300

Click on "Durazbrog" some bread on a wooden table inside the pub, the table is just behind Josef Bugman.
]],
				},
				
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Anvil of Doom",
					mapPins =
					{
						{
							x = 11750,
							y = 33000,
							zoneId = 62,
							tooltip = L"Anvil of Doom",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
11750, 33000

Approach the Anvil of Doom at this location.
]],
				},
				
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Thungni",
					mapPins =
					{
						{
							x = 21500,
							y = 31900,
							zoneId = 62,
							tooltip = L"Thungni",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
21500, 31900

Click on "Gromril Ore" at the base of the alter on the east side of the "The Forge" major landmark, alter is on the left side of the archway through to the Merchant Distrist (Blue area).
]],
				},
				
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Thunderbarges",
					mapPins =
					{
						{
							x = 7500,
							y = 21000,
							zoneId = 62,
							tooltip = L"Thunderbarges",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
7500, 21000

Enter the guild area on the west side of the "Flight Master" major landmark. Unlocked straight away outside the portal up.
]],
				},
				
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Royal Hammerers",
					mapPins =
					{
						{
							x = 28700,
							y = 23700,
							zoneId = 62,
							tooltip = L"Royal Hammerers",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
28700, 23700

Talk to "Hammerer Bodyguard" NPCs around the "Throne Room" major landmark.
]],
				},
				
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Dammaz Kron",
					mapPins =
					{
						{
							x = 28700,
							y = 22600,
							zoneId = 62,
							tooltip = L"Dammaz Kron",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
28700, 22600

Click on "Book of Grudges" right in front of the High King at the "Throne Room" major landmark.
]],
				},
				
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"High King Alriksson",
					mapPins =
					{
						{
							x = 30100,
							y = 32900,
							zoneId = 62,
							tooltip = L"High King Alriksson",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
30100, 32900

Click on "Battle a the Gates of Kislev" a huge red and gold tapstery hanging in the hallway. You need to look up and click on the ranging rail.
]],
				},
				
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Age of Heroes",
					mapPins =
					{
						{
							x = 26900,
							y = 47900,
							zoneId = 62,
							tooltip = L"Age of Heroes",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
26900, 47900

Click on "Memorial Plaque" low on the west side of the south wall of Warrior's Stand area on the map (Red area)
]],
				},
				
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Royal Clans",
					mapPins =
					{
						{
							x = 28700,
							y = 26700,
							zoneId = 62,
							tooltip = L"Royal Clans",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
28700, 26700

Click on "Clan Registry", the closed book on the table infront of the "Royal Reception" (Name Registrar) NPC.
]],
				},
				
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"The Grand Alliance",
					mapPins =
					{
						{
							x = 31900,
							y = 30100,
							zoneId = 62,
							tooltip = L"The Grand Alliance",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
31900, 30100

Click on "Book of Days" on a table just in front of "Teclis" NPC, inside the Elf Order Headquarters (West most yellow area).
]],
				},
				
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"The Long Migration",
					mapPins =
					{
						{
							x = 24300,
							y = 37400,
							zoneId = 62,
							tooltip = L"The Long Migration",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
24300, 37400

Click on "The Long Migration" a large gold tapestry hanging in the archway into the west "Ancestor Temples" (Orange area).
]],
				},
				
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Alaric the Mad",
					mapPins =
					{
						{
							x = 19900,
							y = 23000,
							zoneId = 62,
							tooltip = L"Alaric the Mad",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
19900, 23000

Click on "On Runic Properties of Metals" a book on a small bench near the back of the room, behind Grimm Buloksson.
]],
				},
				
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Doomstrikers",
					mapPins =
					{
						{
							x = 10550,
							y = 33000,
							zoneId = 62,
							tooltip = L"Doomstrikers",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
10550, 33000

Talk to the Doomstriker Tester behind the Anvil of Doom.
]],
				},
				
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Smednir, Shaper of Ores",
					mapPins =
					{
						{
							x = 20500,
							y = 44300,
							zoneId = 97,
							tooltip = L"Smednir, Shaper of Ores",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
20500, 44300 - In Karaz-a-Karak Middle Deeps

Click on "Small Find" at the base of the alter.  The alter is on the level with the pub that is half way down the stairs.
]],
				},
				
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Ungdrin Ankor",
					mapPins =
					{
						{
							x = 16300,
							y = 49300,
							zoneId = 97,
							tooltip = L"Ungdrin Ankor",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
16300, 49300 - In Karaz-a-Karak Middle Deeps

Approach the giant doorway on the west side of "Grungni's Citadel" major landmark, unlock triggered after going up the stairs.
]],
				},
				
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Engineer's Guild",
					mapPins =
					{
						{
							x = 39200,
							y = 29900,
							zoneId = 97,
							tooltip = L"Engineer's Guild",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
39200, 29900 - In Karaz-a-Karak Middle Deeps

Click on the scroll casing called "Turret Designs", on a bench in the upper workshop area.
]],
				},
				
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Goblin-Hewer",
					mapPins =
					{
						{
							x = 24700,
							y = 29000,
							zoneId = 97,
							tooltip = L"Goblin-Hewer",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
24700, 29000 - In Karaz-a-Karak Middle Deeps

Talk to "Goblin Hewer", these are the 3 warmachine contraptions in this area.
]],
				},
				
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Morgrim",
					mapPins =
					{
						{
							x = 35700,
							y = 37400,
							zoneId = 97,
							tooltip = L"Morgrim",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
35700, 37400 - In Karaz-a-Karak Middle Deeps

Click on "Knublsprube" at the base of the alter on the west side of the "Cannon Foundry" major landmark.
]],
				},
				
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Crypt of the High Kings",
					mapPins =
					{
						{
							x = 14800,
							y = 31300,
							zoneId = 97,
							tooltip = L"Crypt of the High Kings",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
14800, 31300 - In Karaz-a-Karak Middle Deeps

Approach the gold door at the end of the room, where the major landmark "The Crypt" is on the map. Unlocks after basically hugging the door.
]],
				},
				
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Gazul, Lord of Underearth",
					mapPins =
					{
						{
							x = 18700,
							y = 33300,
							zoneId = 97,
							tooltip = L"Gazul, Lord of Underearth",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
18700, 33300 - In Karaz-a-Karak Middle Deeps

Click on "Dharkhangron Flame" at the base of the alter at the back of the room.
]],
				},
				
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Order of Guardians",
					mapPins =
					{
						{
							x = 18800,
							y = 29700,
							zoneId = 97,
							tooltip = L"Order of Guardians",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
18800, 29700 - In Karaz-a-Karak Middle Deeps

Talk to one of the "Guardian" NPCs in the library room.
]],
				},
				
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Irondrakes",
					mapPins =
					{
						{
							x = 28800,
							y = 36800,
							zoneId = 97,
							tooltip = L"Irondrakes",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
28800, 36800 - In Karaz-a-Karak Middle Deeps

Talk to one of the "Norgrimling Irondrake" NPCs in this area.
]],
				},
			},
		},
		
		{
			name = L"Karak Eight Peaks",
			entries =
			{
				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Da Biggest, Da Toughest, Da Bestest",
					mapPins =
					{
						{
							x = 32600,
							y = 30400,
							zoneId = 61,
							tooltip = L"Da Biggest, Da Toughest, Da Bestest",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
32600, 30400

Enter the Hall of Da Bestest.
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Waaaagh Boss",
					mapPins =
					{
						{
							x = 32600,
							y = 35500,
							zoneId = 61,
							tooltip = L"Waaaagh Boss",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
32600, 35500

Enter Hall of Da Gorkiest and Morkiest
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Da Waaagh Machine",
					mapPins =
					{
						{
							x = 26700,
							y = 36600,
							zoneId = 61,
							tooltip = L"Da Waaagh Machine",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
26700, 36600

Approach the area just west of the flight master, where you port in.
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Dem Shinies",
					mapPins =
					{
						{
							x = 40600,
							y = 28600,
							zoneId = 61,
							tooltip = L"Dem Shinies",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
40600, 28600

Enter "Shineyz Keepin' Place" major landmark (Blue area).
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"The Kataklysm",
					mapPins =
					{
						{
							x = 27500,
							y = 7300,
							zoneId = 96,
							tooltip = L"The Kataklysm",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
27500, 7300 - In Karak Eight Peaks Da Deeps

Approach the back of the room inside Rat Ridge centre area.
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"The Goblin Wars",
					mapPins =
					{
						{
							x = 25300,
							y = 19800,
							zoneId = 96,
							tooltip = L"The Goblin Wars",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
25300, 19800 - In Karak Eight Peaks Da Deeps

Click on "Memorial Plaque" inside the tower before crossing the west bridge a Kataclysm Chasm.
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Warlord Urgluk Bloodfang",
					mapPins =
					{
						{
							x = 41200,
							y = 41100,
							zoneId = 61,
							tooltip = L"Warlord Urgluk Bloodfang",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
41200, 41100

Click on "Bloodfang" a banner to the right of a pooh statue.
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Greenskin Anatomy",
					mapPins =
					{
						{
							x = 27100,
							y = 29100,
							zoneId = 61,
							tooltip = L"Greenskin Anatomy",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
27100, 29100

Click on "Sigwald's Journal" on a small woodern table in the south Hedkwaterz (Yellow) area.
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Moving Ecosystem",
					mapPins =
					{
						{
							x = 17700,
							y = 45700,
							zoneId = 96,
							tooltip = L"Moving Ecosystem",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
17700, 45700 - In Karak Eight Peaks Da Deeps

Click on the "Squirming Goo" in the squig pit.
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Da Big Waaagh!",
					mapPins =
					{
						{
							x = 37700,
							y = 34300,
							zoneId = 61,
							tooltip = L"Da Big Waaagh!",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
37700, 34300

Approach the ramp down to the "Temple of Gork" major landmark.
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Black Orcs",
					mapPins =
					{
						{
							x = 28800,
							y = 25800,
							zoneId = 61,
							tooltip = L"Black Orcs",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
28800, 25800

Talk to "Bloody Sunbeater" mobs in the "WAAAGH! Room" (purple area).
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Night Gobboz",
					mapPins =
					{
						{
							x = 40900,
							y = 34500,
							zoneId = 96,
							tooltip = L"Night Gobboz",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
40900, 34500 - In Karak Eight Peaks Da Deeps

Click on the "Lil Pot" behind Nubz Brainsporez.
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Fungal Brew",
					mapPins =
					{
						{
							x = 37200,
							y = 32900,
							zoneId = 96,
							tooltip = L"Fungal Brew",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
37200, 32900 - In Karak Eight Peaks Da Deeps

Click on "Caveshroom Stew" on ledge, near the caldrun.
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Art of the Squig",
					mapPins =
					{
						{
							x = 29200,
							y = 45200,
							zoneId = 96,
							tooltip = L"Art of the Squig",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
29200, 45200 - In Karak Eight Peaks Da Deeps

Talk to "Butcha Gleek".
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Goblin Cunning",
					mapPins =
					{
						{
							x = 23600,
							y = 40200,
							zoneId = 61,
							tooltip = L"Goblin Cunning",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
23600, 40200

Click on "Vork", a goblin head on a pike next to "Grottnik" on the central platform.
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Big 'Uns",
					mapPins =
					{
						{
							x = 32600,
							y = 39000,
							zoneId = 61,
							tooltip = L"Big 'Uns",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
32600, 39000

Talk to "Bloody Sun Brute" NPCs.
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Ironclaw Tribe",
					mapPins =
					{
						{
							x = 18700,
							y = 28700,
							zoneId = 61,
							tooltip = L"Ironclaw Tribe",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
18700, 28700

Click on "Ironclaw Spektator" a dead orc, slumped on the ground near the "Ironclaw" banner.
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Pit Fightin'",
					mapPins =
					{
						{
							x = 19600,
							y = 29700,
							zoneId = 61,
							tooltip = L"Pit Fightin'",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
19600, 29700

Enter the Arena area.
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Spear Chukkas",
					mapPins =
					{
						{
							x = 19200,
							y = 34100,
							zoneId = 61,
							tooltip = L"Spear Chukkas",
							icon = "TTitan_Pin_History",
						},
					},

					text =
[[
19200, 34100

Click on "Spearchukka" at the end of the wooden platform.
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Doom Diver Catapults",
					mapPins =
					{
						{
							x = 21600,
							y = 24600,
							zoneId = 61,
							tooltip = L"Doom Diver Catapults",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
21600, 24600

Click on "Doomflyer" a flying contraption to the right of the giant catapult.
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Wyvern Taming",
					mapPins =
					{
						{
							x = 25300,
							y = 35500,
							zoneId = 61,
							tooltip = L"Wyvern Taming",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
25300, 35500

Talk to "Ridin' Wyvern", just up top of the pooh slope.
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Nasty Skulkers",
					mapPins =
					{
						{
							x = 18000,
							y = 28800,
							zoneId = 96,
							tooltip = L"Nasty Skulkers",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
18000, 28800 - In Karak Eight Peaks Da Deeps

Talk to "Nasty Skulkers", there are two tucked away behind the large woodern orc face.
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Know Yer Place",
					mapPins =
					{
						{
							x = 28700,
							y = 42500,
							zoneId = 96,
							tooltip = L"Know Yer Place",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
28700, 42500 - In Karak Eight Peaks Da Deeps

Talk to "Dinna Snottie", in the hanging cage inside the fencing with Deez Eyenflaw.
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Frenzy Power",
					mapPins =
					{
						{
							x = 37100,
							y = 44600,
							zoneId = 96,
							tooltip = L"Frenzy Power",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
37100, 44600 - In Karak Eight Peaks Da Deeps

Click on "Frenzy Brew", a collection of bottles next to the cauldron.
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Yer Full o' Hot Air!",
					mapPins =
					{
						{
							x = 21000,
							y = 26300,
							zoneId = 61,
							tooltip = L"Yer Full o' Hot Air!",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
21000, 26300 

Walk up the ramp and into the area.
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Dis Iz Our Place!",
					mapPins =
					{
						{
							x = 29900,
							y = 11500,
							zoneId = 96,
							tooltip = L"Dis Iz Our Place!",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
29900, 11500 - In Karak Eight Peaks Da Deeps

Click on "Border Banner" a large fallen banner on the floor, just inside the broken arches.
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Stunty Trophies",
					mapPins =
					{
						{
							x = 37000,
							y = 22600,
							zoneId = 61,
							tooltip = L"Stunty Trophies",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
37000, 22600

Click on "Defenders of Eight Peaks" in the NE corner of the room.  It is pike with two dwarf skulls on it.
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Spida Worshippers",
					mapPins =
					{
						{
							x = 32300,
							y = 44700,
							zoneId = 96,
							tooltip = L"Spida Worshippers",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
32300, 44700 - In Karak Eight Peaks Da Deeps

Click on "Gork o' Eight Eyes Offerin'" a cocooned body a front of the pooh spider totem.
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Gork Sez Huh?",
					mapPins =
					{
						{
							x = 24400,
							y = 31200,
							zoneId = 96,
							tooltip = L"Gork Sez Huh?",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
24400, 31200 - In Karak Eight Peaks Da Deeps

Click on "Gork's Trophies", a junk pile infront of the big skull totem.
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Mork Sez Wut?",
					mapPins =
					{
						{
							x = 23000,
							y = 36900,
							zoneId = 96,
							tooltip = L"Mork Sez Wut?",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
23000, 36900 - In Karak Eight Peaks Da Deeps

Click on "Mork's Teefbag", just behind Kazgi in the Temple of Mork.
]],
				},
			},
		},
	},
}
