TTitan.Data.NoteworthyDvG = {}

function TTitan.Data.NoteworthyDvG.GetData()
	return TTitan.Data.NoteworthyDvG.RawData
end

function TTitan.Data.NoteworthyDvG.FilterData()
	TTitan.Data.FilterByRealm(TTitan.Data.NoteworthyDvG.RawData)
end

TTitan.Data.NoteworthyDvG.RawData =
{
	header = L"Noteworthy Persons Unlocks - Dwarfs vs Greenskins",
	categories =
	{
		{
			name = L"Ekrund",
			entries =
			{
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Grimilda Mughammer",
					mapPins =
					{
						{
							x = 18900,
							y = 46200,
							zoneId = 6,
							tooltip = L"Grimilda Mughammer",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
18900, 46200

Talk to "Grimilda Mughammer" the Kill Collector for Dwarf Chapter 1, standing on the edge of the raised platform in front of the golden gates.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Rordin Ironmane",
					mapPins =
					{
						{
							x = 34900,
							y = 37300,
							zoneId = 6,
							tooltip = L"Rordin Ironmane",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
34900, 37300

Talk to "Rordin Ironmane" the Rally Master for Dwarf Chapter 1. Just north of the road after crossing the bridge out of the Dwarf starting area.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Skolm Goldskaar",
					mapPins =
					{
						{
							x = 46500,
							y = 30100,
							zoneId = 6,
							tooltip = L"Skolm Goldskaar",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
46500, 30100

Talk to "Skolm Goldskaar" the Kill Collector at Redhammer Brewery, Dwarf Chapter 2.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Krogan Redhammer",
					mapPins =
					{
						{
							x = 46000,
							y = 31500,
							zoneId = 6,
							tooltip = L"Krogan Redhammer",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
4600, 31500

Talk to "Krogan Redhammer" the Rally Master at Redhammer Brewery, Dwarf Chapter 2.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Moranir Grudgekeg",
					mapPins =
					{
						{
							x = 43000,
							y = 46500,
							zoneId = 6,
							tooltip = L"Moranir Grudgekeg",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
43000, 46500

Talk to "Moranir Grudgekeg" an NPC at GrudgeKeg's Guard warcamp. They are on the south side standing next to the giant brewing machine.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Gorgor",
					mapPins =
					{
						{
							x = 58000,
							y = 38000,
							zoneId = 6,
							tooltip = L"Gorgor",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
58000, 38000

Talk to "Gorgor" the Rally Master at Gorgor's Smash, Greenskins Chapter 4.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Gorsh Smashmouf",
					mapPins =
					{
						{
							x = 57600,
							y = 36000,
							zoneId = 6,
							tooltip = L"Gorsh Smashmouf",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
57600, 36000

Talk to "Gorsh Smashmouf" in Gorgor's Smash, Greenskins Chapter 4.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Xobz Madgut",
					mapPins =
					{
						{
							x = 59000,
							y = 39000,
							zoneId = 6,
							tooltip = L"Xobz Madgut",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
59000, 39000

Talk to "Xobz Madgut" the Kill Collector at Gorgor's Smash, Greenskins Chapter 4.
]],
				},
			},
		},

		{
			name = L"Mount Bloodhorn",
			entries =
			{
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Odarik Rorkisson",
					mapPins =
					{
						{
							x = 7300,
							y = 25000,
							zoneId = 11,
							tooltip = L"Odarik Rorkisson",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
7300, 25000

Talk to "Odarik Rorkisson" the Rally Master at Komar, Dwarf Chapter 3.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Captain Skalfson",
					mapPins =
					{
						{
							x = 44400,
							y = 16600,
							zoneId = 11,
							tooltip = L"Captain Skalfson",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
44400, 16600

Talk to "Captain Skalfson" the Rally Master at Skalson's Watch, Dwarf Chapter 4.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Zamgund Roarhammer",
					mapPins =
					{
						{
							x = 17700,
							y = 24100,
							zoneId = 11,
							tooltip = L"Zamgund Roarhammer",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
17700, 24100

Talk to "Zamgund Roarhammer" an NPC at this location, standing accross from the building next to the right side low wall section.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Dodrum Ironsplitter",
					mapPins =
					{
						{
							x = 46500,
							y = 30100,
							zoneId = 11,
							tooltip = L"Dodrum Ironsplitter",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
46500, 30100

Talk to "Dodrum Ironsplitter" the Kill Collector at Komar, Dwarf Chapter 3.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Barin Grimbeard",
					mapPins =
					{
						{
							x = 44400,
							y = 16600,
							zoneId = 11,
							tooltip = L"Barin Grimbeard",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
44400, 16600

Talk to "Barin Grimbeard" the Kill Collector at Skalson's Watch, Dwarf Chapter 4.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Maggut",
					mapPins =
					{
						{
							x = 33500,
							y = 54000,
							zoneId = 11,
							tooltip = L"Maggut",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
33500, 54000

Talk to "Maggut" the Rally Master for Skarzag's Stompin Grounds, Greenskin Chapter 1.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Grokk",
					mapPins =
					{
						{
							x = 17500,
							y = 54000,
							zoneId = 11,
							tooltip = L"Grokk",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
17500, 54000

Talk to "Grokk" the Rally Master at Da War Maker, Greenskin Chapter 2. 
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Splinta",
					mapPins =
					{
						{
							x = 3800,
							y = 27500,
							zoneId = 11,
							tooltip = L"Splinta",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
3800, 27500

Talk to "Splinta" the Rally Master at Komar, Greenskin Chapter 3.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Screeb",
					mapPins =
					{
						{
							x = 9600,
							y = 21000,
							zoneId = 11,
							tooltip = L"Screeb",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
9600, 21000

Talk to "Screeb" an NPC at Screeb's Stunty Killin' Campp.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Wobna Slipsquig",
					mapPins =
					{
						{
							x = 40000,
							y = 54500,
							zoneId = 11,
							tooltip = L"Wobna Slipsquig",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
40000, 54500

Talk to "Wobna Slipsquig" the Kill Collector at Skarzag's Stompin Grounds, Greenskin Chapter 1.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Sneakfang",
					mapPins =
					{
						{
							x = 16000,
							y = 52400,
							zoneId = 11,
							tooltip = L"Sneakfang",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
16000, 52400

Talk to "Sneakfang" the Kill Collector at Da War Maker, Greenskin Chapter 2. 
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Virrik",
					mapPins =
					{
						{
							x = 1700,
							y = 27000,
							zoneId = 11,
							tooltip = L"Virrik",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
1700, 27000

Talk to "Virrik" the Kill Collector at Komar, Greenskin Chapter 3.
]],
				},
			},
		},

		{
			name = L"Barak Varr",
			entries =
			{
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Thane Karrasteel",
					mapPins =
					{
						{
							x = 31200,
							y = 50100,
							zoneId = 7,
							tooltip = L"Thane Karrasteel",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
31200, 50100

Talk to "Thane Karrasteel" the Rally Master at Thane's Defense, Dwarf Chapter 7.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Farnir Goldpeak",
					mapPins =
					{
						{
							x = 22600,
							y = 43900,
							zoneId = 7,
							tooltip = L"Farnir Goldpeak",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
22600, 43900

Talk to "Farnir Goldpeak" at Goldpeak's Warcamp, standing behind a makeshift table next to one of the tents.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Elgaroth Karginson",
					mapPins =
					{
						{
							x = 31900,
							y = 51000,
							zoneId = 7,
							tooltip = L"Elgaroth Karginson",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
31900, 51000

Talk to "Elgaroth Karginson" the Kill Collector at Thane's Defense, Dwarf Chapter 7.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Thorgar Deephelm",
					mapPins =
					{
						{
							x = 31500,
							y = 36416,
							zoneId = 7,
							tooltip = L"Thorgar Deephelm",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
31500, 36416 - In RvR lake

Talk to "Thorgar Deephelm" the Keep Lord at Dok Karaz.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Nogaz",
					mapPins =
					{
						{
							x = 9100,
							y = 31000,
							zoneId = 7,
							tooltip = L"Nogaz",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
9100, 31000

Talk to "Nogaz" the Rally Master at Nogaz's Boyz, Greenskin Chapter 5.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Rottoof",
					mapPins =
					{
						{
							x = 32800,
							y = 60300,
							zoneId = 7,
							tooltip = L"Rottoof",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
32800, 60300

Talk to "Rottoof" the Rally Master at Rottoof's Mugz, Greenskin Chapter 7.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Malgrog",
					mapPins =
					{
						{
							x = 43000,
							y = 24200,
							zoneId = 7,
							tooltip = L"Malgrog",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
43000, 24200

Talk to "Malgrog" the Rally Master at Port of Barak Varr, Greenskin Chapter 8.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Mobash",
					mapPins =
					{
						{
							x = 28100,
							y = 18000,
							zoneId = 7,
							tooltip = L"Mobash",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
28100, 18000

Talk to "Mobash" the Rally Master at Mobash's Place, Greenskin Chapter 9.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Faduk Foultoof",
					mapPins =
					{
						{
							x = 41000,
							y = 42900,
							zoneId = 7,
							tooltip = L"Faduk Foultoof",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
41000, 42900

Talk to "Faduk Foultoof" at Foultooth's Warcamp.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Runtskull",
					mapPins =
					{
						{
							x = 9100,
							y = 31000,
							zoneId = 7,
							tooltip = L"Runtskull",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
9100, 31000

Talk to "Runtskull" the Kill Collector at Nogaz's Boyz, Greenskin Chapter 5.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Reezel",
					mapPins =
					{
						{
							x = 32800,
							y = 60300,
							zoneId = 7,
							tooltip = L"Reezel",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
32800, 60300

Talk to "Reezel" the Kill Collector at Rottoof's Mugz, Greenskin Chapter 7.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Sneaks",
					mapPins =
					{
						{
							x = 43000,
							y = 24200,
							zoneId = 7,
							tooltip = L"Sneaks",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
43000, 24200

Talk to "Sneaks" the Kill Collectorat Port of Barak Varr, Greenskin Chapter 8.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Moozle",
					mapPins =
					{
						{
							x = 28100,
							y = 18000,
							zoneId = 7,
							tooltip = L"Moozle",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
28100, 18000

Talk to "Moozle" the Kill Collector at Mobash's Place, Greenskin Chapter 9.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Kap'n Grok Saltysnot",
					mapPins =
					{
						{
							x = 31500,
							y = 36416,
							zoneId = 7,
							tooltip = L"Kap'n Grok Saltysnot",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
31500, 36416 - In RvR lake

Talk to "Kap'n Grok Saltysnot" the Keep Lord at Dok Karaz.
]],
				},
			}
		},

		{
			name = L"Marshes of Madness",
			entries =
			{
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Durrig Olfrinson",
					mapPins =
					{
						{
							x = 3300,
							y = 22600,
							zoneId = 1,
							tooltip = L"Durrig Olfrinson",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
3300, 22600

Talk to "Durrig Olfrinson" the Rally Master at Olfrinson's Outpost, Dwarf Chapter 5.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Murdogh Kadrikson",
					mapPins =
					{
						{
							x = 13000,
							y = 5700,
							zoneId = 1,
							tooltip = L"Murdogh Kadrikson",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
13000, 5700

Talk to "Murdogh Kadrikson" the Rally Master at Murdogh's Hold, Dwarf Chapter 6.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Barin Oathsmiter",
					mapPins =
					{
						{
							x = 55500,
							y = 14700,
							zoneId = 1,
							tooltip = L"Barin Oathsmiter",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
55500, 14700

Talk to "Barin Oathsmiter" the Rally Master at Reekmarsh Camp, Dwarf Chapter 8.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Droki Redbeard",
					mapPins =
					{
						{
							x = 56000,
							y = 42000,
							zoneId = 1,
							tooltip = L"Droki Redbeard",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
56000, 42000

Talk to "Droki Redbeard" the Rally Master at Oathhold, Dwarf Chapter 9.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Balabin Thurarikson",
					mapPins =
					{
						{
							x = 40200,
							y = 42900,
							zoneId = 1,
							tooltip = L"Balabin Thurarikson",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
40200, 42900

Talk to "Balabin Thurarikson" on the east side of Thurarikson's Warcamp, near a tent and two organ guns.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Kurgan Ironfist",
					mapPins =
					{
						{
							x = 2500,
							y = 23500,
							zoneId = 1,
							tooltip = L"Kurgan Ironfist",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
2500, 23500

Talk to "Kurgan Ironfist" the Kill Collector at Olfrinson's Outpost, Dwarf Chapter 5.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Estelle Meyer",
					mapPins =
					{
						{
							x = 11300,
							y = 5000,
							zoneId = 1,
							tooltip = L"Estelle Meyer",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
11300, 5000

Talk to "Estelle Meyer" the Kill Collector at Murdogh's Hold, Dwarf Chapter 6.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Grunlok Steelspade",
					mapPins =
					{
						{
							x = 55400,
							y = 14300,
							zoneId = 1,
							tooltip = L"Grunlok Steelspade",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
55400, 14300

Talk to "Grunlok Steelspade" the Kill Collector at Reekmarsh Camp, Dwarf Chapter 8.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Lokki Redbeard",
					mapPins =
					{
						{
							x = 55700,
							y = 42000,
							zoneId = 1,
							tooltip = L"Lokki Redbeard",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
55700, 42000

Talk to "Lokki Redbeard" the Kill Collector at Oathhold, Dwarf Chapter 9.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Durak Moorstone",
					mapPins =
					{
						{
							x = 32700,
							y = 32500,
							zoneId = 1,
							tooltip = L"Durak Moorstone",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
32700, 32500 - In RvR lake

Talk to "Durak Moorstone" the Keep Lord at Fangbreaka Swamp.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Bonerender",
					mapPins =
					{
						{
							x = 20700,
							y = 6900,
							zoneId = 1,
							tooltip = L"Bonerender",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
20700, 6900

Talk to "Bonerender" the Rally Master at Bonerender's Bash, Greenskins Chapter 6.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Morth",
					mapPins =
					{
						{
							x = 26700,
							y = 26800,
							zoneId = 1,
							tooltip = L"Morth",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
26700, 26800

Talk to "Morth" at Morth's Mire Warcamp.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Thudfist",
					mapPins =
					{
						{
							x = 20000,
							y = 7300,
							zoneId = 1,
							tooltip = L"Thudfist",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
20000, 7300

Talk to "Thudfist" the Kill Collector at Bonerender's Bash, Greenskins Chapter 6.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Snotsqueak Swampstink",
					mapPins =
					{
						{
							x = 32700,
							y = 32500,
							zoneId = 1,
							tooltip = L"Snotsqueak Swampstink",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
32700, 32500 - In RvR lake

Talk to "Snotsqueak Swampstink" the Keep Lord at Fangbreaka Swamp.
]],
				},
			}
		},

		{
			name = L"The Badlands",
			entries =
			{
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Alethewn Stoutgut",
					mapPins =
					{
						{
							x = 10800,
							y = 39200,
							zoneId = 2,
							tooltip = L"Alethewn Stoutgut",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
10800, 39200

Talk to "Alethewn Stoutgut" the Rally Master at Norrikson's Excavation, Dwarf Chapter 10.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Skaf Copperstone",
					mapPins =
					{
						{
							x = 13000,
							y = 17000,
							zoneId = 2,
							tooltip = L"Skaf Copperstone",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
13000, 17000

Talk to "Skaf Copperstone" the Rally Master at Copperstone's River Crossing, Dwarf Chapter 11.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Dunhilda Grodrikson",
					mapPins =
					{
						{
							x = 33000,
							y = 12300,
							zoneId = 2,
							tooltip = L"Dunhilda Grodrikson",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
33000, 12300

Talk to "Dunhilda Grodrikson" the Rally Master at Dunhilda's Lads, Dwarf Chapter 13.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Athran Ironbeard",
					mapPins =
					{
						{
							x = 48000,
							y = 14600,
							zoneId = 2,
							tooltip = L"Athran Ironbeard",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
48000, 14600

Talk to "Athran Ironbeard" the Rally Master at Ironbeard's Assault, Dwarf Chapter 14.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Lungni the Dour",
					mapPins =
					{
						{
							x = 15400,
							y = 33100,
							zoneId = 2,
							tooltip = L"Lungni the Dour",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
15400, 33100

Talk to "Lungni the Dour" on the north side of Dour Guard warcamp, infront of a tent next to a small table.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Bragni Tunnelcut",
					mapPins =
					{
						{
							x = 10000,
							y = 38200,
							zoneId = 2,
							tooltip = L"Bragni Tunnelcut",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
10000, 38200

Talk to "Bragni Tunnelcut" the Kill Collector at Norrikson's Excavation, Dwarf Chapter 10.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Doragrum Stouthammer",
					mapPins =
					{
						{
							x = 12400,
							y = 15700,
							zoneId = 2,
							tooltip = L"Doragrum Stouthammer",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
12400, 15700

Talk to "Doragrum Stouthammer" the Kill Collector at Copperstone's River Crossing, Dwarf Chapter 11.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Hlom Hrnghamson",
					mapPins =
					{
						{
							x = 33300,
							y = 13000,
							zoneId = 2,
							tooltip = L"Hlom Hrnghamson",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
33300, 13000

Talk to "Hlom Hrnghamson" the Kill Collector at Dunhilda's Lads, Dwarf Chapter 13.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Mak Kleintrek",
					mapPins =
					{
						{
							x = 47400,
							y = 16300,
							zoneId = 2,
							tooltip = L"Mak Kleintrek",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
47400, 16300

Talk to "Mak Kleintrek" the Kill Collector at Ironbeard's Assault, Dwarf Chapter 14.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Thrain Stonefist",
					mapPins =
					{
						{
							x = 20200,
							y = 41400,
							zoneId = 2,
							tooltip = L"Thrain Stonefist",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
20200, 41400 - In RvR lake

Talk to "Thrain Stonefist" the Keep Lord at Thickmuck Pit.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Trug",
					mapPins =
					{
						{
							x = 17000,
							y = 5400,
							zoneId = 2,
							tooltip = L"Trug",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
17000, 5400

Talk to "Trug" the Rally Master at Trug's Hut, Greenskin Chapter 11.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Muggar",
					mapPins =
					{
						{
							x = 47000,
							y = 45000,
							zoneId = 2,
							tooltip = L"Muggar",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
47000, 45000

Talk to "Muggar" at Muggar's Choppaz warcamp.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Shaman Greyfrobba",
					mapPins =
					{
						{
							x = 17000,
							y = 5400,
							zoneId = 2,
							tooltip = L"Shaman Greyfrobba",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
17000, 5400

Talk to "Shaman Greyfrobba" the Kill Collector at Trug's Hut, Greenskin Chapter 11.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Grok Bonesnappa",
					mapPins =
					{
						{
							x = 20200,
							y = 41400,
							zoneId = 2,
							tooltip = L"Grok Bonesnappa",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
20200, 41400 - In RvR lake

Talk to "Grok Bonesnappa" the Keep Lord at Thickmuck Pit.
]],
				},
			}
		},

		{
			name = L"Black Fire Pass",
			entries =
			{
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Varmir Proudrock",
					mapPins =
					{
						{
							x = 47500,
							y = 60000,
							zoneId = 8,
							tooltip = L"Varmir Proudrock",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
47500, 60000

Talk to "Varmir Proudrock" the Rally Master at Proudrock, Dwarf Chapter 12.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Gamira Odinadotr",
					mapPins =
					{
						{
							x = 35800,
							y = 21600,
							zoneId = 8,
							tooltip = L"Gamira Odinadotr",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
35800, 21600

Talk to "Gamira Odinadotr" an NPC at "Odinadotr's Watch" warcamp, standing on the corner of the tower platform across from the flight master.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Thurn Goldbrewer",
					mapPins =
					{
						{
							x = 46000,
							y = 58600,
							zoneId = 8,
							tooltip = L"Thurn Goldbrewer",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
46000, 58600

Talk to "Thurn Goldbrewer" the Kill Collector at Proudrock, Dwarf Chapter 12.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Hadrik Thundershot",
					mapPins =
					{
						{
							x = 2700,
							y = 16300,
							zoneId = 8,
							tooltip = L"Hadrik Thundershot",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
2700, 16300  - In RvR lake

Talk to "Hadrik Thundershot" the Keep Lord at Gnol Baraz.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Moogz",
					mapPins =
					{
						{
							x = 4000,
							y = 54900,
							zoneId = 8,
							tooltip = L"Moogz",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
4000, 54900

Talk to "Moogz" the Rally Master at Moogz's Brawl, Greenskin Chapter 10.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Drok Gunash",
					mapPins =
					{
						{
							x = 31100,
							y = 51900,
							zoneId = 8,
							tooltip = L"Drok Gunash",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
31100, 51900

Talk to "Drok Gunash" the Rally Master at Drok's Fist, Greenskin Chapter 12.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Gorthug",
					mapPins =
					{
						{
							x = 32500,
							y = 37000,
							zoneId = 8,
							tooltip = L"Gorthug",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
32500, 37000

Talk to "Gorthug" the Rally Master at Gorthug's Chew, Greenskin Chapter 13.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Skargor",
					mapPins =
					{
						{
							x = 46900,
							y = 27200,
							zoneId = 8,
							tooltip = L"Skargor",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
46900, 27200

Talk to "Skargor" the Rally Master at Da Big Burn, Greenskin Chapter 14.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Torka",
					mapPins =
					{
						{
							x = 32600,
							y = 8900,
							zoneId = 8,
							tooltip = L"Torka",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
32600, 8900

Talk to "Torka" at Blackteef's Boyz warcamp.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Gremgob",
					mapPins =
					{
						{
							x = 4000,
							y = 54900,
							zoneId = 8,
							tooltip = L"Gremgob",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
4000, 54900

Talk to "Gremgob" the Kill Collector at Moogz's Brawl, Greenskin Chapter 10.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Smashmur",
					mapPins =
					{
						{
							x = 31100,
							y = 51900,
							zoneId = 8,
							tooltip = L"Smashmur",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
31100, 51900

Talk to "Smashmur" the Kill Collector at Drok's Fist, Greenskin Chapter 12.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Grik",
					mapPins =
					{
						{
							x = 32500,
							y = 37000,
							zoneId = 8,
							tooltip = L"Grik",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
32500, 37000

Talk to "Grik" the Kill Collector at Gorthug's Chew, Greenskin Chapter 13.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Tog Nailclub",
					mapPins =
					{
						{
							x = 46900,
							y = 27200,
							zoneId = 8,
							tooltip = L"Tog Nailclub",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
46900, 27200

Talk to "Tog Nailclub" the Kill Collector at Da Big Burn, Greenskin Chapter 14.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Snagga da Toofsnatcha",
					mapPins =
					{
						{
							x = 2700,
							y = 16300,
							zoneId = 8,
							tooltip = L"Snagga da Toofsnatcha",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
2700, 16300 - In RvR lake

Talk to "Snagga da Toofsnatcha" the Keep Lord at Gnol Baraz.
]],
				},
			}
		},

		{
			name = L"Kadrin Valley",
			entries =
			{
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Skoragrin Drokison",
					mapPins =
					{
						{
							x = 14400,
							y = 11000,
							zoneId = 9,
							tooltip = L"Skoragrin Drokison",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
14400, 11000

Talk to "Skoragrin Drokison" the Rally Master at Kazad Gromar, Dwarf Chapter 15.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Furen Brazenbrow",
					mapPins =
					{
						{
							x = 17000,
							y = 42000,
							zoneId = 9,
							tooltip = L"Furen Brazenbrow",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
17000, 42000

Talk to "Furen Brazenbrow" the Rally Master at Hungry Troll Pub, Dwarf Chapter 16.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Grumir Orcslayer",
					mapPins =
					{
						{
							x = 27400,
							y = 6700,
							zoneId = 9,
							tooltip = L"Grumir Orcslayer",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
27400, 6700

Talk to "Grumir Orcslayer" an NPC at Gharvin's Brace warcamp. In front of the south tent by the small table.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Karon Vigridson",
					mapPins =
					{
						{
							x = 11600,
							y = 14200,
							zoneId = 9,
							tooltip = L"Karon Vigridson",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
11600, 14200

Talk to "Karon Vigridson" the Kill Collector at Kazad Gromar, Dwarf Chapter 15.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Olfgrond Hammerson",
					mapPins =
					{
						{
							x = 15400,
							y = 43400,
							zoneId = 9,
							tooltip = L"Olfgrond Hammerson",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
15400, 43400

Talk to "Olfgrond Hammerson" the Kill Collector at Hungry Troll Pub, Dwarf Chapter 16.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Kolbjorn Ironcleave",
					text =
[[
???, ??? - In RvR lake

Talk to "Kolbjorn Ironcleave" the Keep Lord at ???.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Thangrin Ragesight",
					text =
[[
???, ??? - In RvR lake

Talk to "Thangrin Ragesight" the Keep Lord at ???.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Naguk",
					mapPins =
					{
						{
							x = 51800,
							y = 58100,
							zoneId = 9,
							tooltip = L"Naguk",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
51800, 58100

Talk to "Naguk" the Rally Master at Naguk's Cold Camp, Greenskins Chapter 20.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Gashfang",
					mapPins =
					{
						{
							x = 40500,
							y = 41500,
							zoneId = 9,
							tooltip = L"Gashfang",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
40500, 41500

Talk to "Gashfang" the Rally Master at Gashfang's Warband, Greenskins Chapter 21.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Badrot",
					mapPins =
					{
						{
							x = 43000,
							y = 33700,
							zoneId = 9,
							tooltip = L"Badrot",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
43000, 33700

Talk to "Badrot" the Rally Master at Badrot's Bashin' Place, Greenskins Chapter 22.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Odug Hut-Burna",
					mapPins =
					{
						{
							x = 36500,
							y = 51400,
							zoneId = 9,
							tooltip = L"Odug Hut-Burna",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
36500, 51400

Talk to "Odug Hut-Burna" an NPC at Krung's Scrappin' Spot warcamp.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Ripgut",
					mapPins =
					{
						{
							x = 52500,
							y = 56800,
							zoneId = 9,
							tooltip = L"Ripgut",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
52500, 56800

Talk to "Ripgut" the Kill Collector at Naguk's Cold Camp, Greenskins Chapter 20.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Dragna",
					mapPins =
					{
						{
							x = 40800,
							y = 39500,
							zoneId = 9,
							tooltip = L"Dragna",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
40800, 39500

Talk to "Dragna" the Kill Collector at Gashfang's Warband, Greenskins Chapter 21.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Snogrot",
					mapPins =
					{
						{
							x = 40200,
							y = 32100,
							zoneId = 9,
							tooltip = L"Snogrot",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
40200, 32100

Talk to "Snogrot" the Kill Collector at Badrot's Bashin' Place, Greenskins Chapter 22.
]],
				},
			},
		},

		{
			name = L"Thunder Mountain",
			entries =
			{
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Zamgrund Lorkison",
					mapPins =
					{
						{
							x = 5200,
							y = 8200,
							zoneId = 5,
							tooltip = L"Zamgrund Lorkison",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
5200, 8200

Talk to "Zamgrund Lorkison" the Rally Master at Lorkinson's Excavation Gromar, Dwarf Chapter 17.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Bari Hlavengr",
					mapPins =
					{
						{
							x = 12800,
							y = 26000,
							zoneId = 5,
							tooltip = L"Bari Hlavengr",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
12800, 26000

Talk to "Bari Hlavengr" the Rally Master at Palik Watch, Dwarf Chapter 18.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Dolgr Grinarson",
					mapPins =
					{
						{
							x = 55000,
							y = 25200,
							zoneId = 5,
							tooltip = L"Dolgr Grinarson",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
55000, 25200

Talk to "Dolgr Grinarson" the Rally Master at Dragonslayer Ridge, Dwarf Chapter 19.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Bodor Greymere",
					mapPins =
					{
						{
							x = 36400,
							y = 10100,
							zoneId = 5,
							tooltip = L"Bodor Greymere",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
36400, 10100

Talk to "Bodor Greymere" an NPC at Greymere Point warcamp, standing watching the meat on the spit, near to the flight master.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Leo Heller",
					mapPins =
					{
						{
							x = 4600,
							y = 8900,
							zoneId = 5,
							tooltip = L"Leo Heller",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
4600, 8900

Talk to "Leo Heller" the Kill Collector at Lorkinson's Excavation Gromar, Dwarf Chapter 17.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Rori Mailcutter",
					mapPins =
					{
						{
							x = 11900,
							y = 27300,
							zoneId = 5,
							tooltip = L"Rori Mailcutter",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
11900, 27300

Talk to "Rori Mailcutter" the Kill Collector at Palik Watch, Dwarf Chapter 18.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Rafi Throstsson",
					mapPins =
					{
						{
							x = 56200,
							y = 25200,
							zoneId = 5,
							tooltip = L"Rafi Throstsson",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
56200, 25200

Talk to "Rafi Throstsson" the Kill Collector at Dragonslayer Ridge, Dwarf Chapter 19.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Borgo Thundercaller",
					text =
[[
???, ??? - In RvR lake

Talk to "Borgo Thundercaller" the Keep Lord at ???.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Yuril Trueforge",
					text =
[[
???, ??? - In RvR lake

Talk to "Yuril Trueforge" the Keep Lord at ???.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Slagrot",
					mapPins =
					{
						{
							x = 12300,
							y = 60300,
							zoneId = 5,
							tooltip = L"Slagrot",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
12300, 60300

Talk to "Slagrot" the Rally Master at Hot Foot Boyz, Greenskins Chapter 17.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Brugg One-Eye",
					mapPins =
					{
						{
							x = 13800,
							y = 42000,
							zoneId = 5,
							tooltip = L"Brugg One-Eye",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
13800, 42000

Talk to "Brugg One-Eye" the Rally Master at Da Scrappin' Camp, Greenskins Chapter 18.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Fudja Mudnose",
					mapPins =
					{
						{
							x = 56400,
							y = 45200,
							zoneId = 5,
							tooltip = L"Fudja Mudnose",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
56400, 45200

Talk to "Fudja Mudnose" the Rally Master at Da Big Bones, Greenskins Chapter 19.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Saggrutz Bonechucka",
					mapPins =
					{
						{
							x = 37700,
							y = 59000,
							zoneId = 5,
							tooltip = L"Saggrutz Bonechucka",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
37700, 59000

Talk to "Saggrutz Bonechucka" an NPC at Mudja's Warcamp.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Grimor",
					mapPins =
					{
						{
							x = 12000,
							y = 61000,
							zoneId = 5,
							tooltip = L"Grimor",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
12000, 61000

Talk to "Grimor" the Kill Collector at Hot Foot Boyz, Greenskins Chapter 17.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Gorlub",
					mapPins =
					{
						{
							x = 10600,
							y = 39500,
							zoneId = 5,
							tooltip = L"Gorlub",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
10600, 39500

Talk to "Gorlub" the Kill Collector at Da Scrappin' Camp, Greenskins Chapter 18.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Gurglesmear",
					mapPins =
					{
						{
							x = 58300,
							y = 42300,
							zoneId = 5,
							tooltip = L"Gurglesmear",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
58300, 42300

Talk to "Gurglesmear" the Kill Collector at Da Big Bones, Greenskins Chapter 19.
]],
				},
			}
		},

		{
			name = L"Black Crag",
			entries =
			{
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Ellamina Craghelm",
					mapPins =
					{
						{
							x = 51000,
							y = 10000,
							zoneId = 3,
							tooltip = L"Ellamina Craghelm",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
51000, 10000

Talk to "Slayer Bolgun" the Rally Master at Craghelm's Hold, Dwarf Chapter 20.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Gargrim Oathgrund",
					mapPins =
					{
						{
							x = 34100,
							y = 19500,
							zoneId = 3,
							tooltip = L"Gargrim Oathgrund",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
34100, 19500

Talk to "Gargrim Oathgrund" the Rally Master at Craghelm's Hold, Dwarf Chapter 21.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Gav Hallmundr",
					mapPins =
					{
						{
							x = 36500,
							y = 47400,
							zoneId = 3,
							tooltip = L"Gav Hallmundr",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
36500, 47400

Talk to "Gav Hallmundr" the Rally Master at Gav's Oathbearers, Dwarf Chapter 22.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Rogrin Weatheredmane",
					mapPins =
					{
						{
							x = 45000,
							y = 7300,
							zoneId = 3,
							tooltip = L"Rogrin Weatheredmane",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
45000, 7300

Talk to "Rogrin Weatheredmane" an NPC at Kargrund's Stand warcamp, standing behind the middle tent looking at the ramp into the RvR lake.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Slayer Bolgun",
					mapPins =
					{
						{
							x = 51500,
							y = 8600,
							zoneId = 3,
							tooltip = L"Slayer Bolgun",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
51500, 8600

Talk to "Slayer Bolgun" the Kill Collector at Craghelm's Hold, Dwarf Chapter 20. Inside the left building.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Bogni Goblingrinder",
					mapPins =
					{
						{
							x = 33500,
							y = 19400,
							zoneId = 3,
							tooltip = L"Bogni Goblingrinder",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
33500, 19400

Talk to "Bogni Goblingrinder" the Kill Collector at Craghelm's Hold, Dwarf Chapter 21.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Hanri Raudson",
					mapPins =
					{
						{
							x = 36600,
							y = 46000,
							zoneId = 3,
							tooltip = L"Hanri Raudson",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
36600, 46000

Talk to "Hanri Raudson" the Kill Collector at Gav's Oathbearers, Dwarf Chapter 22.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Keldor Granursson",
					text =
[[
???, ??? - In RvR lake

Talk to "Keldor Granursson" the Keep Lord at ???.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Graymir Ironhide",
					text =
[[
???, ??? - In RvR lake

Talk to "Graymir Ironhide" the Keep Lord at ???.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Grimgork",
					mapPins =
					{
						{
							x = 23300,
							y = 35700,
							zoneId = 3,
							tooltip = L"Grimgork",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
23300, 35700

Talk to "Grimgork" the Rally Master at Red Dust Camp, Greenskins Chapter 15.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Mugash",
					mapPins =
					{
						{
							x = 9900,
							y = 14500,
							zoneId = 3,
							tooltip = L"Mugash",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
9900, 14500

Talk to "Mugash" the Rally Master at Da Great Big Food Pot, Greenskins Chapter 16.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Shaz da Bleeda",
					mapPins =
					{
						{
							x = 20200,
							y = 61600,
							zoneId = 3,
							tooltip = L"Shaz da Bleeda",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
20200, 61600

Talk to "Shaz da Bleeda" an NPC at Gudmud's Strong-Huts warcamp.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Kark",
					mapPins =
					{
						{
							x = 20800,
							y = 35500,
							zoneId = 3,
							tooltip = L"Kark",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
20800, 35500

Talk to "Kark" the Kill Collector at Red Dust Camp, Greenskins Chapter 15.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Bloodtoof",
					mapPins =
					{
						{
							x = 9700,
							y = 14800,
							zoneId = 3,
							tooltip = L"Bloodtoof",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
9700, 14800

Talk to "Bloodtoof" the Kill Collector at Da Great Big Food Pot, Greenskins Chapter 16.
]],
				},
			}
		},
		
		{
			name = L"Karaz-a-Karak",
			entries =
			{
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"High King Thorgrim Grudgebearer",
					mapPins =
					{
						{
							x = 28700,
							y = 22600,
							zoneId = 62,
							tooltip = L"High King Thorgrim Grudgebearer",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
28700, 22600

Talk to "High King Thorgrim Grudgebearer", on the throne at the "Throne Room" major landmark.
]],
				},
				
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Ulther Stonehammer",
					mapPins =
					{
						{
							x = 29500,
							y = 27400,
							zoneId = 62,
							tooltip = L"Ulther Stonehammer",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
29500, 27400

Talk to "Prince Ulther Stonehammer", on the right side as you come up the 2nd ramp section into the High King's Hold (Green area).
]],
				},
				
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"King Belegar Ironhammer",
					mapPins =
					{
						{
							x = 28400,
							y = 26600,
							zoneId = 62,
							tooltip = L"King Belegar Ironhammer",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
28400, 26600

Talk to "King Belegar Ironhammer", on the left side next to the tables in the lower section of the High King's Hold (Green area). 
]],
				},
				
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Teclis",
					mapPins =
					{
						{
							x = 31800,
							y = 30000,
							zoneId = 62,
							tooltip = L"Teclis",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
31800, 30000

Talk to "Teclis" inside the Elf Order Headquarters (West most yellow area).
]],
				},
				
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Josef Bugman",
					mapPins =
					{
						{
							x = 39700,
							y = 31400,
							zoneId = 62,
							tooltip = L"Josef Bugman",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
39700, 31400

Talk to "Josef Bugman" in the tavern, next to the fireplace.
]],
				},
				
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Snorri Nosebiter",
					mapPins =
					{
						{
							x = 36600,
							y = 36600,
							zoneId = 62,
							tooltip = L"Snorri Nosebiter",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
36600, 36600

Talk to "Snorri Nosebiter" at the west end of the "Feast Hall" major landmark, on a platform looking down over the tables.
]],
				},
				
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Queen Karga",
					mapPins =
					{
						{
							x = 32000,
							y = 37700,
							zoneId = 62,
							tooltip = L"Queen Karga",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
32000, 37700

Talk to "Queen Karga" in the eastern Ancestor Temples area on the map (Orange area).
]],
				},
				
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Malakai Makaisson",
					mapPins =
					{
						{
							x = 7000,
							y = 22400,
							zoneId = 62,
							tooltip = L"Malakai Makaisson",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
7000, 22400

Talk to "Malakai Makaisson" standing next to the table at the top of the tower in the guild flight deck area, west of the "Flight Master" major landmark.
]],
				},
				
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Kragg the Grim",
					mapPins =
					{
						{
							x = 11750,
							y = 33000,
							zoneId = 62,
							tooltip = L"Kragg the Grim",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
11750, 33000

Talk to "Kragg The Grim" standing next to the Anvil of Doom.
]],
				},
				
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Burlok Damminsson",
					mapPins =
					{
						{
							x = 38200,
							y = 31250,
							zoneId = 97,
							tooltip = L"Burlok Damminsson",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
38200, 31250 - In Karaz-a-Karak Middle Deeps

Talk to "Burlok Damminsson" standing on the end of the platform sticking out from the upper workshop area at the "Engineers' Guild" major landmark.
]],
				},
				
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Garagrim Ironfist",
					mapPins =
					{
						{
							x = 15600,
							y = 31200,
							zoneId = 97,
							tooltip = L"Garagrim Ironfist",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
15600, 31200 - In Karaz-a-Karak Middle Deeps

Talk to "Garagrim Ironfist" standing at the end of the carpet infront of the tomb.
]],
				},
				
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Gotrek Athranborson",
					mapPins =
					{
						{
							x = 20700,
							y = 48900,
							zoneId = 97,
							tooltip = L"Gotrek Athranborson",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
20700, 48900 - In Karaz-a-Karak Middle Deeps

Talk to "Gotrek Athranborson" standing on top of "Grungni's Citadel" major landmark.
]],
				},
				
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Grombrindal",
					mapPins =
					{
						{
							x = 26300,
							y = 16400,
							zoneId = 97,
							tooltip = L"Grombrindal",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
26300, 16400 - In Karaz-a-Karak Middle Deeps

Talk to "Dawi-Wyr" standing at the east end of the "Ungdrin Grimazul" major landmark, he is on the right-hand side on the edge near a golden telescope.
]],
				},
			}
		},

		{
			name = L"Karak Eight Peaks",
			entries =
			{
				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Grumlok & Gazbag",
					mapPins =
					{
						{
							x = 32600,
							y = 41400,
							zoneId = 61,
							tooltip = L"Grumlok & Gazbag",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
32600, 41400

Talk to "Grumlok" or "Gazbag".
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Borgut Facebeater",
					mapPins =
					{
						{
							x = 18400,
							y = 30800,
							zoneId = 61,
							tooltip = L"Borgut Facebeater",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
18400, 30800

Talk to "Borgut Facebeater", in the large hut overlooking the arena.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Morglum Necksnapper",
					mapPins =
					{
						{
							x = 27600,
							y = 23300,
							zoneId = 96,
							tooltip = L"Morglum Necksnapper",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
27600, 23300 - In Karak Eight Peaks Da Deeps

Talk to "Morglum Necksnapper" on the top of "Ratbreaka Stand" major landmark.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Wurrzag Ud Ura Zahubu",
					mapPins =
					{
						{
							x = 32400,
							y = 16200,
							zoneId = 61,
							tooltip = L"Wurrzag Ud Ura Zahubu",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
32400, 16200

Talk to "Wurrzag Ud Ura Zahubu", up on the platform.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Kazgi",
					mapPins =
					{
						{
							x = 23000,
							y = 36800,
							zoneId = 96,
							tooltip = L"Kazgi",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
23000, 36800 - In Karak Eight Peaks Da Deeps

Talk to "Kazgi" standing by the totem in the middle of this room.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Grottnik",
					mapPins =
					{
						{
							x = 23300,
							y = 40000,
							zoneId = 61,
							tooltip = L"Grottnik",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
23300, 40000

Talk to "Grottnik" at the top of the wooden platform in the middle of "Stunty Diggin' Pit".
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Gitilla da Hunter",
					mapPins =
					{
						{
							x = 20400,
							y = 40700,
							zoneId = 96,
							tooltip = L"Gitilla da Hunter",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
20400, 40700 - In Karak Eight Peaks Da Deeps

Talk to "Gitilla da Hunter" a wolfrider stood on a platform, in Beastie Penz.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Urk da Stuntystomper",
					mapPins =
					{
						{
							x = 24900,
							y = 30800,
							zoneId = 96,
							tooltip = L"Urk da Stuntystomper",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
24900, 30800 - In Karak Eight Peaks Da Deeps

Talk to "Urk da Stuntystomper" on the west side of the "Weaponz Hall".
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Asperon Khitain",
					mapPins =
					{
						{
							x = 26200,
							y = 24200,
							zoneId = 61,
							tooltip = L"Asperon Khitain",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
26200, 24200

Talk to "Asperon Khitain" in the north Hedkwaterz (Yellow) area.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Aekold Helbrass",
					mapPins =
					{
						{
							x = 26200,
							y = 29700,
							zoneId = 61,
							tooltip = L"Aekold Helbrass",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
26200, 29700

Talk to "Aekold Helbrass" in the south Hedkwaterz (Yellow) area.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Skargaz Gutrippa",
					mapPins =
					{
						{
							x = 23800,
							y = 27000,
							zoneId = 61,
							tooltip = L"Skargaz Gutrippa",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
23800, 27000

Talk to "Skargaz Gutrippa" in the west Hedkwaterz (Yellow) area.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Vargit Slimefoot",
					mapPins =
					{
						{
							x = 15100,
							y = 47900,
							zoneId = 96,
							tooltip = L"Vargit Slimefoot",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
15100, 47900 - In Karak Eight Peaks Da Deeps

Talk to "Vargit Slimefoot" at west side of the Squig Nursery.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Gitslit Spleenspit",
					mapPins =
					{
						{
							x = 37600,
							y = 43400,
							zoneId = 96,
							tooltip = L"Gitslit Spleenspit",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
37600, 43400 - In Karak Eight Peaks Da Deeps

Talk to "Gitslit Spleenspit" at the south end of the Poisoned Skulls Hall.
]],
				},
			}
		},
	},
}
