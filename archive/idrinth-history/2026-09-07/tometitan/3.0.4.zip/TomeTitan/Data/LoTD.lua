TTitan.Data.LoTD = {}

function TTitan.Data.LoTD.GetData()
	return TTitan.Data.LoTD.RawData
end

function TTitan.Data.LoTD.FilterData()
	TTitan.Data.FilterByRealm(TTitan.Data.LoTD.RawData)
end

TTitan.Data.LoTD.RawData =
{
	header = L"Bestiary Unlocks - Land of The Dead",
	categories =
	{
		{
			name = L"Necroplis of Zandri",
			entries =
			{
				{
					name = L"Swarm (Trophy)",
					mapPins =
					{
						{
							x = 14600,
							y = 24000,
							zoneId = 191,
							tooltip = L"Swarm - A Voracious Tomb Swarm Leaves Nothing to Waste",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Swarm - A Voracious Tomb Swarm Leaves Nothing to Waste
TROPHY

14600, 24000

NOT IMPLEMENTED YET

Click on "Pile of Bones" inside the tomb, down the eastern tunnel at the first turn, then kill "Tomb Swarm".
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Carrion (Trophy)",
					mapPins =
					{
						{
							x = 55600,
							y = 41200,
							zoneId = 191,
							tooltip = L"Carrion - You Can't Make an Omelet Without Breaking Some Eggs",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Carrion - You Can't Make an Omelet Without Breaking Some Eggs
TROPHY

55600, 41200

NOT IMPLEMENTED YET

At your realm PQ, use the "Vulture Glyph" to be carried to the nests. Search the nests for "Shiny Trinket" until you have 5, then deliver them to "Vanden Lightwind" in "Goldbarrow" camp.
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Carrion (Trophy)",
					mapPins =
					{
						{
							x = 45000,
							y = 18900,
							zoneId = 191,
							tooltip = L"Carrion - You Can't Make an Omelet Without Breaking Some Eggs",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Carrion - You Can't Make an Omelet Without Breaking Some Eggs
TROPHY

45000, 18900

NOT IMPLEMENTED YET

At your realm PQ, use the "Vulture Glyph" to be carried to the nests. Search the nests for "Shiny Trinket" until you have 5, then deliver them to "Xalyn Eboneye" in "Da Dusty Dry" camp.
]],
				},

				{
					name = L"Scorpion (Trophy)",
					mapPins =
					{
						{
							x = 30468,
							y = 6785,
							zoneId = 191,
							tooltip = L"Scorpion - The Dead Can (And Do) Speak",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Scorpion - The Dead Can (And Do) Speak
TROPHY

30468, 6785

NOT IMPLEMENTED YET

Use the head dropped by the Amen Sher PQ boss.
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Scarab Bone Construct (EXP)",
					mapPins =
					{
						{
							x = 59474,
							y = 46536,
							zoneId = 191,
							tooltip = L"Scarab Bone Construct - The Eyes Have It",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Scarab Bone Construct - The Eyes Have It
XP

59474, 46536

NOT IMPLEMENTED YET

Collect 10 "Scarab Construct Eye" and take them to "Calvan Teurin" in "Goldbarrow" camp..
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Scarab Bone Construct (EXP)",
					mapPins =
					{
						{
							x = 57630,
							y = 7977,
							zoneId = 191,
							tooltip = L"Scarab Bone Construct - The Eyes Have It",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Scarab Bone Construct - The Eyes Have It
XP

57630, 7977

NOT IMPLEMENTED YET

Collect 10 "Scarab Construct Eye" and take them to "Dregg Stinkeye" in "Da Dusty Dry" camp.
]],
				},
			},
		},
	},
}
