TTitan.Data.Pursuits = {}

function TTitan.Data.Pursuits.GetData()
	return TTitan.Data.Pursuits.RawData
end

function TTitan.Data.Pursuits.FilterData()
	TTitan.Data.FilterByRealm(TTitan.Data.Pursuits.RawData)
end

TTitan.Data.Pursuits.RawData =
{
	header = L"Pursuit Achievements",
	categories =
	{
		{
			name = L"A Delicate Art",
			entries =
			{

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Delicate Negotiations",
					mapPins =
					{
						{
							x = 56200,
							y = 27800,
							zoneId = 7,
							tooltip = L"Delicate Negotiations",
							icon = "TTitan_Pin_Pursuits",
						},
					},
					text =
[[
56200, 27800 - In Barak Varr

Kill "Roarin' Choppa" a level 2 mob. There are two of them in a group with cheering Bloody Sun Stompas, they are just inside the Greenskin camp. They can be hit with ranged attacks if entering from the south "Khaz Kol Bar" major landmark entrance, hug the left wall to avoid line of sight from the 55 guard.
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Delicate Negotiations",
					mapPins =
					{
						{
							x = 56200,
							y = 27800,
							zoneId = 7,
							tooltip = L"Delicate Negotiations",
							icon = "TTitan_Pin_Pursuits",
						},
					},
					text =
[[
56200, 27800 - In Barak Varr

Talk to "Roarin' Choppa" an NPC in Greenskin chapter 8 camp, there are two of them in a group with cheering Bloody Sun Stompas.
]],
				},
			},
		},

		{
			name = L"Ale Run",
			entries =
			{
				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Ale: The Thirst Quencher",
					mapPins =
					{
						{
							x = 10900,
							y = 300,
							zoneId = 1,
							tooltip = L"Ale: The Thirst Quencher",
							icon = "TTitan_Pin_Pursuits",
						},
					},
					text =
[[
10900, 300 - In Marshes of Madness

Talk to "Durgan Grimminsson" inside "Hunk Grung" major landmark
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Alebearer",
					mapPins =
					{
						{
							x = 54800,
							y = 17900,
							zoneId = 1,
							tooltip = L"Alebearer",
							icon = "TTitan_Pin_Pursuits",
						},
					},
					text =
[[
54800, 17900 - In Marshes of Madness

Talk to "Oathbearer Gunner" any one of the four dwarfs south of "Reekmarsh Camp" Dwarf Chapter 8 camp, working on a machine of some sort.
]],
				},
			},
		},

		{
			name = L"Beauty of Pain",
			entries =
			{
				{
					name = L"Beauty of Pain",
					mapPins =
					{
						{
							x = 63000,
							y = 47600,
							zoneId = 201,
							tooltip = L"Beauty of Pain",
							icon = "TTitan_Pin_Pursuits",
						},
					},
					text =
[[
63000, 47600 - In The Shadowlands

Click on "Blood Cauldron" near the two cages and three witch elfs in the lower section of "Preemptive Strike" PQ.
]],
				},
			},
		},

		{
			name = L"Cannonball!",
			entries =
			{
				{
					name = L"Cannonball!",
					mapPins =
					{
						{
							x = 10800,
							y = 45800,
							zoneId = 7,
							tooltip = L"Cannonball!",
							icon = "TTitan_Pin_Pursuits",
						},
					},
					text =
[[
10800, 45800 - In Barak Varr

Click on "Crate of Cannonballs" at the "The Sea's Anvil" major landmark, inside on the north west side of the upper deck.
]],
				},
			},
		},

		{
			name = L"Come One, Come All",
			entries =
			{
				{
					name = L"Wandering Rock",
					mapPins =
					{
						{
							x = 6200,
							y = 25400,
							zoneId = 101,
							tooltip = L"Wandering Rock",
							icon = "TTitan_Pin_Pursuits",
						},
					},
					text =
[[
6200, 25400 - In Troll Country

Talk to "Raving Waldo" he is sitting down against some rocks, facing the "Welcome to Troll Country" PQ on the edge of Empire Chapter 5 camp. 
]],
				},

				{
					name = L"Lesson Learned",
					mapPins =
					{
						{
							x = 19100,
							y = 55500,
							zoneId = 101,
							tooltip = L"Lesson Learned",
							icon = "TTitan_Pin_Pursuits",
						},
					},
					text =
[[
19100, 55500 - In Troll Country

Talk to "Raving Waldo" he is sitting down against a tree looking down over the road, just east of "Felde Castle" Empire chapter 6 camp.
]],
				},

				{
					name = L"Burdens and Bunions",
					mapPins =
					{
						{
							x = 38800,
							y = 58900,
							zoneId = 101,
							tooltip = L"Burdens and Bunions",
							icon = "TTitan_Pin_Pursuits",
						},
					},
					text =
[[
38800, 58900 - In Troll Country

Talk to "Raving Waldo" he is sitting down against a huge tree by the road on the left side of the ramp up to Order warcamp.
]],
				},

				{
					name = L"Mucking Green",
					mapPins =
					{
						{
							x = 39900,
							y = 40700,
							zoneId = 101,
							tooltip = L"Mucking Green",
							icon = "TTitan_Pin_Pursuits",
						},
					},
					text =
[[
39900, 40700 - In Troll Country

Talk to "Raving Waldo" he is sitting down against a carved totem between to bushes, on the bend in the road just SW of "Trovolek Advance" Chaos chapter 8 camp.
]],
				},

				{
					name = L"Making Space",
					mapPins =
					{
						{
							x = 54100,
							y = 18900,
							zoneId = 101,
							tooltip = L"Making Space",
							icon = "TTitan_Pin_Pursuits",
						},
					},
					text =
[[
54100, 18900 - In Troll Country

Talk to "Raving Waldo" he is sitting down against a large tree, on the SW side of "Trollhaugen" Chaos chapter 9 camp.
]],
				},

				{
					name = L"One For All",
					mapPins =
					{
						{
							x = 22600,
							y = 22100,
							zoneId = 101,
							tooltip = L"One For All",
							icon = "TTitan_Pin_Pursuits",
						},
					},
					text =
[[
22600, 22100 - In Troll Country

Talk to "Raving Waldo" he is sitting down against a large rock, on the mound.
]],
				},
			},
		},

		{
			name = L"Da Bigga 'Un",
			entries =
			{
				{
					name = L"Da Bigga 'Un",
					mapPins =
					{
						{
							x = 26300,
							y = 12000,
							zoneId = 1,
							tooltip = L"Da Bigga 'Un",
							icon = "TTitan_Pin_Pursuits",
						},
					},
					text =
[[
26300, 12000 - In Marshes of Madness

Kill "Da Bigga 'Un", a level 1 Orc standing in the middle of the road, with 4 other orcs around him.
]],
				},

				{
					name = L"Bosses",
					mapPins =
					{
						{
							x = 29900,
							y = 11000,
							zoneId = 1,
							tooltip = L"Bosses",
							icon = "TTitan_Pin_Pursuits",
						},
					},
					text =
[[
29900, 11000 - In Marshes of Madness

Kill "Black Skull Boss", there are two (either work) standing near the large ork totem.
]],
				},

				{
					name = L"Da Biggest Un'",
					mapPins =
					{
						{
							x = 24600,
							y = 30400,
							zoneId = 1,
							tooltip = L"Da Biggest Un'",
							icon = "TTitan_Pin_Pursuits",
						},
					},
					text =
[[
24600, 30400 - In Marshes of Madness

Kill "Da Biggest 'Un", inside the hut at the end of the path.
]],
				},
			},
		},

		{
			name = L"Dirty Dealings",
			entries =
			{
				{
					name = L"Enemy of my Enemy",
					mapPins =
					{
						{
							x = 41800,
							y = 18900,
							zoneId = 11,
							tooltip = L"Enemy of my Enemy",
							icon = "TTitan_Pin_Pursuits",
						},
					},
					text =
[[
41800, 18900 - In Mount Bloodhorn

Enter the ruined tower just west of Skalfson's Watch, Dwarf chapter 4.
]],
				},

				{
					name = L"Profiteering",
					mapPins =
					{
						{
							x = 42200,
							y = 10800,
							zoneId = 11,
							tooltip = L"Profiteering",
							icon = "TTitan_Pin_Pursuits",
						},
					},
					text =
[[
42200, 10800 - In Mount Bloodhorn

Kill "Dog Paymaster" during the second stage of "Traitor's Watch" PQ.
]],
				},

				{
					name = L"Supply & Demand",
					mapPins =
					{
						{
							x = 35700,
							y = 14800,
							zoneId = 11,
							tooltip = L"Supply & Demand",
							icon = "TTitan_Pin_Pursuits",
						},
					},
					text =
[[
35700, 14800 - In Mount Bloodhorn

Click on "Merchant's Traveling Gear" a backpack on the floor behind the blue tent.
]],
				},

				{
					name = L"Dirty Dealin'",
					mapPins =
					{
						{
							x = 52000,
							y = 8500,
							zoneId = 11,
							tooltip = L"Dirty Dealin'",
							icon = "TTitan_Pin_Pursuits",
						},
					},
					text =
[[
52000, 8500 - In Mount Bloodhorn

Kill "Ranulf Baumann" a level 8 hero. Standing just in front of a patchwork tent.
]],
				},
			},
		},

		{
			name = L"Durak's Journal",
			entries =
			{
				{
					name = L"Durak's Journal",
					mapPins =
					{
						{
							x = 26400,
							y = 32000,
							zoneId = 11,
							tooltip = L"Durak's Journal",
							icon = "TTitan_Pin_Pursuits",
						},
					},
					text =
[[
26400, 32000 - In Mount Bloodhorn

Click on "Durak's Journal" inside "Forgotten Hold" major landmark, you'll find a sarcophagus with the journal sitting next to it.
]],
				},

				{
					name = L"Durak's Last Days",
					mapPins =
					{
						{
							x = 53100,
							y = 13700,
							zoneId = 11,
							tooltip = L"Durak's Last Days",
							icon = "TTitan_Pin_Pursuits",
						},
					},
					text =
[[
53100, 13700 - In Mount Bloodhorn

Click on "Durak's Tome" on the floor on the lowest level of "Gnol Barak" major landmark, between a pillar and a cannon.
]],
				},
			},
		},

		{
			name = L"Grebo's Pile",
			entries =
			{
				{
					name = L"Grebo's Pile",
					mapPins =
					{
						{
							x = 5800,
							y = 34400,
							zoneId = 7,
							tooltip = L"Grebo's Pile",
							icon = "TTitan_Pin_Pursuits",
						},
					},
					text =
[[
5800, 34400 - In Barak Varr

Click on "Grebo's Pile" inside the ruined tower, SW of "Nogaz's Boyz" Greenskin chapter 5 camp.
]],
				},

				{
					name = L"Oltrak Steelbarrel",
					mapPins =
					{
						{
							x = 5200,
							y = 34000,
							zoneId = 7,
							tooltip = L"Oltrak Steelbarrel",
							icon = "TTitan_Pin_Pursuits",
						},
					},
					text =
[[
5200, 34000 - In Barak Varr

Talk to "Oltrak Steelbarrel" standing infront of the ruined tower.
]],
				},
			},
		},

		{
			name = L"Greenskin Games",
			entries =
			{
				{
					name = L"Greenskin Games",
					mapPins =
					{
						{
							x = 62000,
							y = 31500,
							zoneId = 3,
							tooltip = L"Greenskin Games",
							icon = "TTitan_Pin_Pursuits",
						},
					},
					text =
[[
62000, 31500 - In Black Crag

Click on "Smashed Orc" in the cave at the back of the fighting pit, in "Da Great Smashin' Pit" PQ.
]],
				},
			},
		},

		{
			name = L"Greenskin Humor",
			entries =
			{
				{
					name = L"Greenskin Humor",
					mapPins =
					{
						{
							x = 23100,
							y = 43200,
							zoneId = 3,
							tooltip = L"Greenskin Humor",
							icon = "TTitan_Pin_Pursuits",
						},
					},
					text =
[[
23100, 43200 - In Black Crag

Click on "Git-in-a-Barrel" next to the end of the bridge.
]],
				},
			},
		},

		{
			name = L"Harsh Punishment",
			entries =
			{
				{
					name = L"Harsh Punishment",
					mapPins =
					{
						{
							x = 27800,
							y = 17000,
							zoneId = 107,
							tooltip = L"Harsh Punishment",
							icon = "TTitan_Pin_Pursuits",
						},
					},
					text =
[[
27800, 17000 - In Ostland

Click on "Signpost" in the center of the Destruction PQ "Reaper's Circle".
]],
				},
			},
		},

		{
			name = L"Illiteracy",
			entries =
			{
				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Illiteracy",
					mapPins =
					{
						{
							x = 26600,
							y = 55500,
							zoneId = 106,
							tooltip = L"Illiteracy",
							icon = "TTitan_Pin_Pursuits",
						},
					},
					text =
[[
26600, 55500 - In Nordland

Click on "Sheet of Paper" on the centre table out of three, on the SE side of Grimmenhagen Village, Empire chapter 1.
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Wolfram's Letter",
					mapPins =
					{
						{
							x = 24300,
							y = 34900,
							zoneId = 162,
							tooltip = L"Wolfram's Letter",
							icon = "TTitan_Pin_Pursuits",
						},
					},
					text =
[[
24300, 34900 - In Altdorf - Quest Start Location

Talk to "Wolfram Becker" to starter the quest "Alive and Well". He asks you to take his letter which is inside building behind him. Click on "Wolfram's Letter" to collect it, then fly to Nordland and head to "Grimmenhagen Village" Empire chapter 1 camp.  Talk to his wife "Agatha Becker" at 26500, 53200 to complete the quest.  Take the follow up part of "Alive and Well" from her and complete it by talking to her again, this will give you a trophy reward called "Agatha's Thanks", equip this for the unlock.
]],
				},
			},
		},

		{
			name = L"Loyal Companion",
			entries =
			{
				{
					name = L"Loyal Mastiff",
					mapPins =
					{
						{
							x = 48700,
							y = 52200,
							zoneId = 107,
							tooltip = L"Loyal Mastiff",
							icon = "TTitan_Pin_Pursuits",
						},
					},
					text =
[[
48700, 52200 - In Ostland

Talk to "Randulf Ackermann" an NPC in "Wolfenburg Inn" Empire chapter 9 camp. He is standing to the side of a tent in the middle.
]],
				},

				{
					name = L"Better Off Dead",
					mapPins =
					{
						{
							x = 47300,
							y = 62300,
							zoneId = 107,
							tooltip = L"Better Off Dead",
							icon = "TTitan_Pin_Pursuits",
						},
					},
					text =
[[
47300, 62300 - In Ostland

Kill "Zombified Hound" on the far southside of "Wolfenburg" major landmark. It is between the mill and the large house, towards the back.
]],
				},

				{
					name = L"Bruno's Safe Return",
					mapPins =
					{
						{
							x = 47300,
							y = 62300,
							zoneId = 107,
							tooltip = L"Bruno's Safe Return",
							icon = "TTitan_Pin_Pursuits",
						},
					},
					text =
[[
47300, 62300 - In Ostland

Kill "Zombified Hound" to get the quest item "Bruno's Collar". Click it to start the quest "Bruno's Fate", and return it to "Randulf Ackermann" at 48700, 55200. Complete the quest for the unlock.
]],
				},

				{
					name = L"Who's A Good Boy?",
					mapPins =
					{
						{
							x = 48700,
							y = 52200,
							zoneId = 107,
							tooltip = L"Who's A Good Boy?",
							icon = "TTitan_Pin_Pursuits",
						},
					},
					text =
[[
48700, 52200 - In Ostland

Talk to "Bruno", he appears once you complete the above achievement.
]],
				},
			},
		},

		{
			name = L"Medicinal Purposes",
			entries =
			{
				{
					name = L"Shameful Ailments",
					mapPins =
					{
						{
							x = 20100,
							y = 62600,
							zoneId = 9,
							tooltip = L"Shameful Ailments",
							icon = "TTitan_Pin_Pursuits",
						},
					},
					text =
[[
20100, 62600 - In Kadrin Valley

Click on "Elgi Wine" on the left side of the entrance to the tower, in "The Sealed Tower" PQ.
]],
				},

				{
					name = L"Bleed it out",
					mapPins =
					{
						{
							x = 59100,
							y = 35800,
							zoneId = 26,
							tooltip = L"Bleed it out",
							icon = "TTitan_Pin_Pursuits",
						},
					},
					text =
[[
59100, 35800 - In Cinderfall

Click on "Cultist Blades" on a couple of crates, to the side of the cart.
]],
				},

				{
					name = L"Sweat it out",
					mapPins =
					{
						{
							x = 10900,
							y = 29200,
							zoneId = 27,
							tooltip = L"Sweat it out",
							icon = "TTitan_Pin_Pursuits",
						},
					},
					text =
[[
10900, 29200 - In Death Peak

Click on "Sauna Water" next to the lake of lava.
]],
				},

				{
					name = L"Grease for the Gut",
					mapPins =
					{
						{
							x = 46300,
							y = 9800,
							zoneId = 26,
							tooltip = L"Grease for the Gut",
							icon = "TTitan_Pin_Pursuits",
						},
					},
					text =
[[
46300, 9800 - In Cinderfall

Click on "Rhinox Lard", a small barrel on the mortar platform.
]],
				},

				{
					name = L"Shock it up",
					mapPins =
					{
						{
							x = 62500,
							y = 41500,
							zoneId = 5,
							tooltip = L"Shock it up",
							icon = "TTitan_Pin_Pursuits",
						},
					},
					text =
[[
62500, 41500 - In Thunder Mountain

Click on "Azorgari Lightning Rod", west of the road, next to the dragon skull.
]],
				},

				{
					name = L"Chills for the Chills",
					mapPins =
					{
						{
							x = 48600,
							y = 11200,
							zoneId = 9,
							tooltip = L"Chills for the Chills",
							icon = "TTitan_Pin_Pursuits",
						},
					},
					text =
[[
48600, 11200 - In Kadrin Valley

Click on "Box of Ice", round the North West side of "Peak Tower" Major Landmark.
]],
				},

				{
					name = L"The Cure for What Ales You",
					mapPins =
					{
						{
							x = 2100,
							y = 60000,
							zoneId = 27,
							tooltip = L"The Cure for What Ales You",
							icon = "TTitan_Pin_Pursuits",
						},
					},
					text =
[[
2100, 60000 - In Death Peak

Click on "Aged Bugman's" a barrel inside the building, just left of the fireplace.
]],
				},
			},
		},

		{
			name = L"Ostland Corruption",
			entries =
			{
				{
					name = L"Ostland Corruption",
					mapPins =
					{
						{
							x = 45000,
							y = 15300,
							zoneId = 107,
							tooltip = L"Ostland Corruption",
							icon = "TTitan_Pin_Pursuits",
						},
					},
					text =
[[
45000, 15300 - In Ostland

Click on "Magistrate's Warrant" a piece of paper at the top of the stairs, round the back of the large building.
]],
				},

				{
					name = L"A Cry in the Night",
					mapPins =
					{
						{
							x = 36800,
							y = 35600,
							zoneId = 107,
							tooltip = L"A Cry in the Night",
							icon = "TTitan_Pin_Pursuits",
						},
					},
					text =
[[
36800, 35600 - In Ostland

Kill "Rupert Millson" a level 15 mob, standing outside by the tower, just to the right of the stairs.
]],
				},

				{
					name = L"Purchased Silence",
					mapPins =
					{
						{
							x = 36800,
							y = 35600,
							zoneId = 107,
							tooltip = L"Purchased Silence",
							icon = "TTitan_Pin_Pursuits",
						},
					},
					text =
[[
36800, 35600 - In Ostland

Equip "Pouch full of Karls" pocket items, dropped by "Rupert Millson".
]],
				},

			},
		},

		{
			name = L"Random Sacrifice",
			entries =
			{
				{
					name = L"Ritual of Tzeentch",
					mapPins =
					{
						{
							x = 54700,
							y = 37200,
							zoneId = 100,
							tooltip = L"Ritual of Tzeentch",
							icon = "TTitan_Pin_Pursuits",
						},
					},
					text =
[[
54700, 37200 - In Norsca

Click on "Altar of the Raven".
]],
				},

				{
					name = L"Ritual of Khorne",
					mapPins =
					{
						{
							x = 48600,
							y = 60700,
							zoneId = 100,
							tooltip = L"Ritual of Khorne",
							icon = "TTitan_Pin_Pursuits",
						},
					},
					text =
[[
48600, 60700 - In Norsca

Click on "Altar of Bloodshed".
]],
				},

				{
					name = L"Ritual of Nurgle",
					mapPins =
					{
						{
							x = 45400,
							y = 53800,
							zoneId = 100,
							tooltip = L"Ritual of Nurgle",
							icon = "TTitan_Pin_Pursuits",
						},
					},
					text =
[[
45400, 53800 - In Norsca

Click on "Altar of Decay".
]],
				},

				{
					name = L"Ritual of Slaanesh",
					mapPins =
					{
						{
							x = 34200,
							y = 41400,
							zoneId = 100,
							tooltip = L"Ritual of Slaanesh",
							icon = "TTitan_Pin_Pursuits",
						},
					},
					text =
[[
34200, 41400 - In Norsca

Click on "Altar of the Shameless".
]],
				},
			},
		},

		{
			name = L"Shameful Behavior",
			entries =
			{
				{
					name = L"Out of Sorts",
					mapPins =
					{
						{
							x = 31600,
							y = 28100,
							zoneId = 107,
							tooltip = L"Out of Sorts",
							icon = "TTitan_Pin_Pursuits",
						},
					},
					text =
[[
31600, 28100 - In Ostland

Click on "Bohsenfels Ale" a stein on the bar counter inside the tavern.
]],
				},
			},
		},

		{
			name = L"Sign of Change",
			entries =
			{
				{
					name = L"Sign of Change",
					mapPins =
					{
						{
							x = 39100,
							y = 20000,
							zoneId = 100,
							tooltip = L"Sign of Change",
							icon = "TTitan_Pin_Pursuits",
						},
					},
					text =
[[
39100, 20000 - In Norsca

Click on "Eye of Change" at the centre of the chaos crater, the first Chaos PQ Ruinous Powers.
]],
				},
			},
		},

		{
			name = L"Special Character",
			entries =
			{
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Special Character",
					mapPins =
					{
						{
							x = 41000,
							y = 59000,
							zoneId = 103,
							tooltip = L"Special Character",
							icon = "TTitan_Pin_Pursuits",
						},
					},
					text =
[[
41000, 59000 - In Chaos Wastes

Kill "Grunthar Deathwielder", and loot the item "Vandalized Imperial Cross".
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Challenge of Champions",
					mapPins =
					{
						{
							x = 56500,
							y = 48400,
							zoneId = 103,
							tooltip = L"Challenge of Champions",
							icon = "TTitan_Pin_Pursuits",
						},
					},
					text =
[[
56500, 48400 - In Chaos Wastes

Kill "Vy'tak Tz'kul", and loot the item "Looted Twin-tailed Comet Icon".
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Ultimate Destiny",
					mapPins =
					{
						{
							x = 49400,
							y = 2200,
							zoneId = 103,
							tooltip = L"Ultimate Destiny",
							icon = "TTitan_Pin_Pursuits",
						},
					},
					text =
[[
49400, 2200 - In Chaos Wastes

Kill "Bellande Soultaker", and loot the item "Stolen Imperial Amulet".
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Championhood",
					mapPins =
					{
						{
							x = 61100,
							y = 4200,
							zoneId = 103,
							tooltip = L"Championhood",
							icon = "TTitan_Pin_Pursuits",
						},
					},
					text =
[[
61100, 4200 - In Chaos Wastes

Trade the 3 items from the above unlocks, for "Imperial Chapion's Mark" at the merchant "Theofil Karstgard" in Empire Chapter 22 camp. Then equip it for the unlock.
]],
				},			

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Special Character",
					mapPins =
					{
						{
							x = 56400,
							y = 18900,
							zoneId = 109,
							tooltip = L"Special Character",
							icon = "TTitan_Pin_Pursuits",
						},
					},
					text =
[[
56400, 18900 - In Reikland

Kill "Lemuel Kleiner", and get the item "???".
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Challenge of Champions",
					mapPins =
					{
						{
							x = 52400,
							y = 34700,
							zoneId = 109,
							tooltip = L"Challenge of Champions",
							icon = "TTitan_Pin_Pursuits",
						},
					},
					text =
[[
52400, 34700 - In Reikland

Kill "Lenora Kleingart", and get the item "???".
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Ultimate Destiny",
					mapPins =
					{
						{
							x = 50900,
							y = 52600,
							zoneId = 109,
							tooltip = L"Ultimate Destiny",
							icon = "TTitan_Pin_Pursuits",
						},
					},
					text =
[[
50900, 52600 - In Reikland

Kill "Paulus Hurtenbaum", and get the item "???".
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Championhood",
					mapPins =
					{
						{
							x = 35800,
							y = 53900,
							zoneId = 109,
							tooltip = L"Championhood",
							icon = "TTitan_Pin_Pursuits",
						},
					},
					text =
[[
35800, 53900 - In Reikland

Trade the 3 items from the above unlocks, for "Tzeentchian Chapion's Mark" at the merchant "Wergard Tz'Ulkar" in Chaos Chapter 22 camp. Then equip it for the unlock.
]],
				},
			},
		},

		{
			name = L"Squig'uns!",
			entries =
			{
				{
					name = L"Getting Et",
					mapPins =
					{
						{
							x = 38900,
							y = 31000,
							zoneId = 60,
							tooltip = L"Getting Et",
							icon = "TTitan_Pin_Pursuits",
						},
					},
					text =
[[
38900, 31000 - In Gunbad

Click on "Dead Squig Trainer" behind the wooden stake barrier.
]],
				},

				{
					name = L"Not Getting Et",
					mapPins =
					{
						{
							x = 38900,
							y = 42900,
							zoneId = 60,
							tooltip = L"Not Getting Et",
							icon = "TTitan_Pin_Pursuits",
						},
					},
					text =
[[
38900, 42900 - In Gunbad

Kill "Squig Bait" a snotling, standing on the little island.
]],
				},
			},
		},

		{
			name = L"Squig Taming",
			entries =
			{
				{
					name = L"Squig Training",
					mapPins =
					{
						{
							x = 60300,
							y = 15600,
							zoneId = 2,
							tooltip = L"Squig Training",
							icon = "TTitan_Pin_Pursuits",
						},
					},
					text =
[[
60300, 15600 - In The Badlands

Kill "Squigkeeper Rizzik", a level 31 Hero neutral standing in the mouth of the cave.
]],
				},
			},
		},

		{
			name = L"Stirring up Trouble",
			entries =
			{
				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Stirring up Trouble",
					mapPins =
					{
						{
							x = 26600,
							y = 52800,
							zoneId = 106,
							tooltip = L"Stirring up Trouble",
							icon = "TTitan_Pin_Pursuits",
						},
					},
					text =
[[
26600, 52800 - In Nordland

Talk to "Frightened Peasant" a cowering NPC on the right as you head north out of the central circle of "Grimmenhagen Village", Empire chapter 1 camp.
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Stirring up More Trouble",
					mapPins =
					{
						{
							x = 20200,
							y = 28300,
							zoneId = 106,
							tooltip = L"Stirring up More Trouble",
							icon = "TTitan_Pin_Pursuits",
						},
					},
					text =
[[
20200, 28300 - In Nordland

Talk to "Frightened Peasant" a cowering NPC on the upper level inside the tavern at "Grey Lady Coaching Inn", Empire chapter 2 camp.
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Troubling Indeed",
					mapPins =
					{
						{
							x = 32400,
							y = 19200,
							zoneId = 106,
							tooltip = L"Troubling Indeed",
							icon = "TTitan_Pin_Pursuits",
						},
					},
					text =
[[
32400, 19200 - In Nordland

Talk to "Frightened Peasant" a cowering NPC by the mailbox in "Breuer's Regiment", Empire chapter 3 camp. He is being harrassed by 3 other NPCs, once called "Pious Hunter".
]],
				},
			},
		},

		{
			name = L"Subversion",
			entries =
			{
				{
					name = L"Subversion",
					mapPins =
					{
						{
							x = 52000,
							y = 53800,
							zoneId = 106,
							tooltip = L"Subversion",
							icon = "TTitan_Pin_Pursuits",
						},
					},
					text =
[[
52000, 53800 - In Nordland

Kill "Dirk Eisenhauer" a neutral mob inside a blue tent, who will drop a quest item "Wizard's Box". Right click this in your quest items, to start the quest "Lure of Power", click it again to complete the quest and get the unlock.  You will also get the item "Wizard's Key" which is for the next unlock part.
]],
				},

				{
					name = L"Brotherhood of Nuln",
					mapPins =
					{
						{
							x = 52000,
							y = 53800,
							zoneId = 106,
							tooltip = L"Brotherhood of Nuln",
							icon = "TTitan_Pin_Pursuits",
						},
					},
					text =
[[
52000, 53800 - In Nordland - Quest Start Location

Talk to "Hieronymus of Huln" inside "Salzenmund Tower" major landmark. To get there use the "Wizard's Key" from the "Lure of Power" quest reward above.  This will teleport you into the bottom of the tower, climb up to the top to find him.
]],
				},
			},
		},

		{
			name = L"The Creator",
			entries =
			{
				{
					name = L"The Creator",
					mapPins =
					{
						{
							x = 15700,
							y = 23200,
							zoneId = 220,
							tooltip = L"The Creator",
							icon = "TTitan_Pin_Pursuits",
						},
					},
					text =
[[
15700, 23200 - In Isle of the Dead

Equip "The Creator's Mark" pocket item dropped by killing "The Creator".
]],
				},

				{
					name = L"Of Beginnings",
					mapPins =
					{
						{
							x = 15700,
							y = 23200,
							zoneId = 220,
							tooltip = L"Of Beginnings",
							icon = "TTitan_Pin_Pursuits",
						},
					},
					text =
[[
15700, 23200 - In Isle of the Dead

Kill "The Creator".
]],
				},

				{
					name = L"Of Endings",
					mapPins =
					{
						{
							x = 15700,
							y = 23200,
							zoneId = 220,
							tooltip = L"Of Endings",
							icon = "TTitan_Pin_Pursuits",
						},
					},
					text =
[[
15700, 23200 - In Isle of the Dead

Click on "Time-Lost Dead".
]],
				},
			},
		},

		{
			name = L"The Forgekeepers",
			entries =
			{
				{
					name = L"The Forgekeepers",
					mapPins =
					{
						{
							x = 57900,
							y = 57100,
							zoneId = 5,
							tooltip = L"The Forgekeepers",
							icon = "TTitan_Pin_Pursuits",
						},
					},
					text =
[[
57900, 57100 - In Thunder Mountain

Click on "Ancient Skeleton", one of two skeletons on the ground, at the back of the broken tower, on the North side of "Ankul Grob" PQ.
]],
				},

				{
					name = L"Fire Under the Mountain",
					mapPins =
					{
						{
							x = 47513,
							y = 34600,
							zoneId = 5,
							tooltip = L"Fire Under the Mountain",
							icon = "TTitan_Pin_Pursuits",
						},
					},
					text =
[[
47513, 34600 - In Thunder Mountain - In RvR Lake

Click on "Ancient Skeleton" at the back of "Gromril Kruk" BO.
]],
				},

				{
					name = L"World Ember",
					mapPins =
					{
						{
							x = 58200,
							y = 31500,
							zoneId = 5,
							tooltip = L"World Ember",
							icon = "TTitan_Pin_Pursuits",
						},
					},
					text =
[[
58200, 31500 - In Thunder Mountain - In RvR Lake

Equip "Spark of Karag Dron", obtained by click on "Rune-Sealed Container" behind the forge.
]],
				},

				{
					name = L"Forgekeeper",
					text =
[[
Complete all 3 of the above unlocks.
]],
				},
			},
		},

		{
			name = L"The Gateway to Ultimate Knowledge",
			entries =
			{
				{
					name = L"Mysterious Gateway",
					mapPins =
					{
						{
							x = 35600,
							y = 16000,
							zoneId = 200,
							tooltip = L"Mysterious Gateway",
							icon = "TTitan_Pin_Pursuits",
						},
					},
					text =
		[[
		35600, 16000 - In The Blighted Isle

		Click on "Gateway Crystal" one of the outer five pink crystals.
		]],
				},

				{
					name = L"Chasing Wisdom",
					mapPins =
					{
						{
							x = 35600,
							y = 16000,
							zoneId = 200,
							tooltip = L"Chasing Wisdom",
							icon = "TTitan_Pin_Pursuits",
						},
					},
					text =
		[[
		35600, 16000 - In The Blighted Isle

		Click on "Crystal of Wisdom" one of the outer five pink crystals.
		]],
				},

				{
					name = L"Pursuit of Knowledge",
					mapPins =
					{
						{
							x = 35600,
							y = 16000,
							zoneId = 200,
							tooltip = L"Pursuit of Knowledge",
							icon = "TTitan_Pin_Pursuits",
						},
					},
					text =
		[[
		35600, 16000 - In The Blighted Isle

		Click on "Crystal of Knowledge" one of the outer five pink crystals.
		]],
				},

				{
					name = L"Deep in Study",
					mapPins =
					{
						{
							x = 35600,
							y = 16000,
							zoneId = 200,
							tooltip = L"Deep in Study",
							icon = "TTitan_Pin_Pursuits",
						},
					},
					text =
		[[
		35600, 16000 - In The Blighted Isle

		Click on "Crystal of Study" one of the outer five pink crystals.
		]],
				},

				{
					name = L"Teach Them Well",
					mapPins =
					{
						{
							x = 35600,
							y = 16000,
							zoneId = 200,
							tooltip = L"Teach Them Well",
							icon = "TTitan_Pin_Pursuits",
						},
					},
					text =
		[[
		35600, 16000 - In The Blighted Isle

		Click on "Crystal of Learning" one of the outer five pink crystals.
		]],
				},

				{
					name = L"The Gateway to Ultimate Knowledge",
					mapPins =
					{
						{
							x = 35600,
							y = 16000,
							zoneId = 200,
							tooltip = L"The Gateway to Ultimate Knowledge",
							icon = "TTitan_Pin_Pursuits",
						},
					},
					text =
		[[
		35600, 16000 - In The Blighted Isle

		Click on "Redeemed Crystal" the central blue crystal.
		]],
				},
			},
		},

		{
			name = L"The Herald",
			entries =
			{
				{
					name = L"The Herald",
					mapPins =
					{
						{
							x = 22000,
							y = 11000,
							zoneId = 101,
							tooltip = L"The Herald",
							icon = "TTitan_Pin_Pursuits",
						},
					},
					text =
[[
22000, 11000 - In Troll Country

Kill "The Herald".
]],
				},

				{
					name = L"Wandering Alone",
					mapPins =
					{
						{
							x = 22000,
							y = 11000,
							zoneId = 101,
							tooltip = L"Wandering Alone",
							icon = "TTitan_Pin_Pursuits",
						},
					},
					text =
[[
22000, 11000 - In Troll Country

The Herald (Wandering Alone) - TROLL COUNTRY. Both factions. After killing the Herald, a Horror will spawn. Killing it should grant the unlock.
]],
				},

				{
					name = L"Carrying His Word",
					mapPins =
					{
						{
							x = 22000,
							y = 11000,
							zoneId = 101,
							tooltip = L"Carrying His Word",
							icon = "TTitan_Pin_Pursuits",
						},
					},
					text =
[[
22000, 11000 - In Troll Country

Equip "Profane Writ" pocket item, dropped by "Thew Herald".
]],
				},
			},
		},

		{
			name = L"The Last Upholder",
			entries =
			{
				{
					name = L"The Last Upholder",
					mapPins =
					{
						{
							x = 13400,
							y = 36200,
							zoneId = 8,
							tooltip = L"The Last Upholder",
							icon = "TTitan_Pin_Pursuits",
						},
					},
					text =
[[
13400, 36200 - In Black Fire Pass

Talk to "The Last Upholder" a NPC praying at an alter on the west side of "Snow Peak Temple" major landmark.
]],
				},

				{
					name = L"Standing Against the Tide",
					mapPins =
					{
						{
							x = 13500,
							y = 35900,
							zoneId = 8,
							tooltip = L"Standing Against the Tide",
							icon = "TTitan_Pin_Pursuits",
						},
					},
					text =
[[
13500, 35900 - In Black Fire Pass

Click on "The Last Upholder's Pack" to start the quest "One Man's Struggle". Click on the pack again to complete the quest and get the unlock.
]],
				},

				{
					name = L"Borrowed Time",
					mapPins =
					{
						{
							x = 13500,
							y = 35900,
							zoneId = 8,
							tooltip = L"Borrowed Time",
							icon = "TTitan_Pin_Pursuits",
						},
					},
					text =
[[
13500, 35900 - In Black Fire Pass

Equip "The Last Upholder's Watch" pocket item, rewarded when completing the quest "One Man's Struggle" for the above unlock.
]],
				},
			},
		},

		{
			name = L"The Littlest Beastmaster",
			entries =
			{
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Littlest Beastmaster",
					mapPins =
					{
						{
							x = 45200,
							y = 19800,
							zoneId = 207,
							tooltip = L"Littlest Beastmaster",
							icon = "TTitan_Pin_Pursuits",
						},
					},
					text =
[[
45200, 19800 - In Ellyrion

Kill "Cold One Whelp" inside the coral.
]],
				},
				
				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Littlest Beastmaster",
					mapPins =
					{
						{
							x = 45200,
							y = 19800,
							zoneId = 207,
							tooltip = L"Littlest Beastmaster",
							icon = "TTitan_Pin_Pursuits",
						},
					},
					text =
[[
45200, 19800 - In Ellyrion

Talk to "Cold One Whelp" inside the coral.
]],
				},
			},	
		},

		{
			name = L"The Teacher",
			entries =
			{
				{
					name = L"The Teacher",
					mapPins =
					{
						{
							x = 1300,
							y = 45700,
							zoneId = 207,
							tooltip = L"The Teacher",
							icon = "TTitan_Pin_Pursuits",
						},
					},
					text =
[[
1300, 45700 - In Ellyrion

Kill "The Teacher" a level 20 Hero.  Click on "Asur Tablet" to spawn him if he is not there.
]],
				},

				{
					name = L"Lesson to be Learned",
					mapPins =
					{
						{
							x = 1300,
							y = 45700,
							zoneId = 207,
							tooltip = L"Lesson to be Learned",
							icon = "TTitan_Pin_Pursuits",
						},
					},
					text =
[[
1300, 45700 - In Ellyrion

Kill "The Teacher" a level 20 Hero, again.  Click on "Asur Tablet" to spawn him.
]],
				},

				{
					name = L"The Master",
					mapPins =
					{
						{
							x = 1300,
							y = 45700,
							zoneId = 207,
							tooltip = L"The Master",
							icon = "TTitan_Pin_Pursuits",
						},
					},
					text =
[[
1300, 45700 - In Ellyrion

Equip "Teacher's Chain" pocket item, dropped by "The Teacher".
]],
				},
			},
		},
	},
}