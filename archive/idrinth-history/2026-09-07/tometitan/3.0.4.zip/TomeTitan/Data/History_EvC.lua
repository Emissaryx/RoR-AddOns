TTitan.Data.HistoryEvC = {}

function TTitan.Data.HistoryEvC.GetData()
	return TTitan.Data.HistoryEvC.RawData
end

function TTitan.Data.HistoryEvC.FilterData()
	TTitan.Data.FilterByRealm(TTitan.Data.HistoryEvC.RawData)
end

TTitan.Data.HistoryEvC.RawData =
{
	header = L"History & Lore Unlocks - Empire vs Chaos",
	categories =
	{
		{
			name = L"Nordland",
			entries =
			{
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"The Order of the Griffon",
					mapPins =
					{
						{
							x = 29100,
							y = 19700,
							zoneId = 106,
							tooltip = L"The Order of the Griffon",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
29100, 19700

Talk to "Griffon ..." NPCs, worked on the "Griffon Striker" in the Nordland warcamp, but there are many other NPCs that will trigger this unlock all over Norland.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"The Order of the Griffon",
					mapPins =
					{
						{
							x = 53000,
							y = 5000,
							zoneId = 106,
							tooltip = L"The Order of the Griffon",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
53000, 5000

Kill any "Griffon Striker" mob along the main road near the Ravenraid Mill, Major Landmark.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Sigmar",
					mapPins =
					{
						{
							x = 24700,
							y = 55700,
							zoneId = 106,
							tooltip = L"Sigmar",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
24700, 55700

Click on "Life of Sigmar" a book on the upper level inside Grimmenhagen Inn, in Grimmenhagen Village, Empire chapter 1 camp.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Sigmar",
					mapPins =
					{
						{
							x = 57500,
							y = 60600,
							zoneId = 106,
							tooltip = L"Sigmar",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
57500, 60600

Click on 'Life of Sigmar' on an outdoor table at the Salzemund Book Vendor.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Militia",
					mapPins =
					{
						{
							x = 27500,
							y = 51600,
							zoneId = 106,
							tooltip = L"Militia",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
27500, 51600

Talk to "Jakob Hekel", he is up by a building on the right-side side as you head north out of Grimmenhagen Village.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Militia",
					mapPins =
					{
						{
							x = 46200,
							y = 5100,
							zoneId = 106,
							tooltip = L"Militia",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
46200, 5100

Kill a "Citizen Militia" mob east of Blessed Gathering Warcamp.
]],
				},

				{
					name = L"Ill Omens",
					mapPins =
					{
						{
							x = 42100,
							y = 25400,
							zoneId = 106,
							tooltip = L"Ill Omens",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
42100, 25400

Click on "Dead Sparrow" directly east of "Faewulf's Rest" PQ, amongst all the other dead birds.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Superstition",
					mapPins =
					{
						{
							x = 25300,
							y = 55600,
							zoneId = 106,
							tooltip = L"Superstition",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
25300, 55600

Click on "Empire Bar Door" the entrance door to Grimmenhagen Inn, in Grimmenhagen Village, Empire chapter 1 camp.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Superstition",
					mapPins =
					{
						{
							x = 49500,
							y = 57100,
							zoneId = 106,
							tooltip = L"Superstition",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
49500, 57100

Click on "Tavern Door" and enter the Fishes Flask in the Salzenmund PQ.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"The Plague",
					mapPins =
					{
						{
							x = 27200,
							y = 54100,
							zoneId = 106,
							tooltip = L"The Plague",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
27200, 54100

Click on "Plague Corpse" in front of a building on the east side of Grimmenhagen Village, Empire chapter 1 camp.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"The Plague",
					mapPins =
					{
						{
							x = 62900,
							y = 22800,
							zoneId = 106,
							tooltip = L"The Plague",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
62900, 22800

Click on "Plague Corpse" next to unearthed grave in the Beeckerhoven Graveyard.
]],
				},				

				{
					name = L"The Colleges of Magic",
					mapPins =
					{
						{
							x = 11300,
							y = 24000,
							zoneId = 106,
							tooltip = L"The Colleges of Magic",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
11300, 24000

Click on "A Dusty Tome" in a small depression north of "Ruins of Schloss von Rubendorff" PQ. It's hidden up on the ledge behind a tree and a couple of bushes.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Isolated Settlements",
					mapPins =
					{
						{
							x = 14500,
							y = 50500,
							zoneId = 106,
							tooltip = L"Isolated Settlements",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
14500, 50500

Click on "Midnight Rider" a dead man behind the tent in Empire starting area.
]],
				},
				
				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Isolated Settlements",
					mapPins =
					{
						{
							x = 40800,
							y = 1500,
							zoneId = 106,
							tooltip = L"Isolated Settlements",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
40800, 1500

Click on "Midnight Rider" behind a house in Death’s Brink, Chaos Chapter 3.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Elector Counts",
					mapPins =
					{
						{
							x = 31000,
							y = 46300,
							zoneId = 106,
							tooltip = L"Elector Counts",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
31000, 46300

Click on "Dedication Plaque" south of the "Grimmenhagen Farm" major landmark, it is just up on the end of the rise.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Elector Counts",
					mapPins =
					{
						{
							x = 62000,
							y = 45600,
							zoneId = 106,
							tooltip = L"Elector Counts",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
62000, 45600

Kill "Steward Lord Geinhardt" at Salzenmund Keep.
]],
				},

				{
					name = L"Corruption from Within",
					mapPins =
					{
						{
							x = 38500,
							y = 25000,
							zoneId = 106,
							tooltip = L"Corruption from Within",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
38500, 25000

Click on "Runic Tablet" it is at the centre of "Faewulf's Rest" PQ, underneath the large stone.
]],
				},
			},
		},

		{
			name = L"Norsca",
			entries =
			{
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Chaos Portal",
					mapPins =
					{
						{
							x = 58800,
							y = 23800,
							zoneId = 100,
							tooltip = L"Chaos Portal",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
58800, 23800

Click on "Changer's Eye" on the east side of the "Pit of the Forsaken" PQ, behind the broken sections of wall surrounded by Zealot mobs performing a ritual.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Chaos Portal",
					mapPins =
					{
						{
							x = 27500,
							y = 9700,
							zoneId = 100,
							tooltip = L"Chaos Portal",
							icon = "TTitan_Pin_History",
						},
					},


					text =
[[
27500, 9700

Click on "Changer's Eye" on the tip of the rock ramp leading up to the chaos portal, inside the Chaos starting area.
]],
				},

				{
					name = L"The Raven Host",
					mapPins =
					{
						{
							x = 16800,
							y = 38200,
							zoneId = 100,
							tooltip = L"The Raven Host",
							icon = "TTitan_Pin_History",
						},
					},


					text =
[[
16800, 38200

Click on "Dead Magus" in last area of "Tomb of Ravenborne" major landmark, body is at the bottom on the ledge by the altar and five mobs, on the left side of the walkway.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Hellcannons",
					mapPins =
					{
						{
							x = 42300,
							y = 62500,
							zoneId = 100,
							tooltip = L"Hellcannons",
							icon = "TTitan_Pin_History",
						},
					},


					text =
[[
42300, 62500

Kill the "Hellcannon" overlooking the RvR lake.
]],
				},
				
				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Hellcannons",
					mapPins =
					{
						{
							x = 38300,
							y = 9900,
							zoneId = 100,
							tooltip = L"Hellcannons",
							icon = "TTitan_Pin_History",
						},
					},


					text =
[[
38300, 9900

Click on "Ammunition" close to the Hellfire Cannon.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"The Raven God",
					mapPins =
					{
						{
							x = 46600,
							y = 34500,
							zoneId = 100,
							tooltip = L"The Raven God",
							icon = "TTitan_Pin_History",
						},
					},


					text =
[[
46600, 34500

Click on "Tomes of the Raven" inside "Amund's Barrow" major landmark. Head inside at 48200, 44900 and stick to the left all the way through as far as you can.
]],
				},			

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"The Raven God",
					mapPins =
					{
						{
							x = 31200,
							y = 12400,
							zoneId = 100,
							tooltip = L"The Raven God",
							icon = "TTitan_Pin_History",
						},
					},


					text =
[[
31200, 12400

Click on "Tomes of the Raven" near the fence.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Daemons",
					mapPins =
					{
						{
							x = 52800,
							y = 30300,
							zoneId = 100,
							tooltip = L"Daemons",
							icon = "TTitan_Pin_History",
						},
					},


					text =
[[
52800, 30300

Kill the "Foul Nurgling" just to the NE of "Ulfenwyr" PQ.
]],
				},
				
				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Daemons",
					mapPins =
					{
						{
							x = 29200,
							y = 9600,
							zoneId = 100,
							tooltip = L"Daemons",
							icon = "TTitan_Pin_History",
						},
					},


					text =
[[
29200, 9600

Talk to "Screamer" just to the East of the chaos portal in "Unshackled Host", Chaos Chapter 1 camp.
]],
				},

				{	
					name = L"Norse Tribes",
					mapPins =
					{
						{
							x = 31600,
							y = 41700,
							zoneId = 100,
							tooltip = L"Norse Tribes",
							icon = "TTitan_Pin_History",
						},
					},


					text =
[[
31600, 41700

Click on "Sarl Banner" at the base of the large stone in the middle of "Skaldbjorn" major landmark.
]],
				},
				
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Raiding and Pillaging",
					mapPins =
					{
						{
							x = 58700,
							y = 63700,
							zoneId = 100,
							tooltip = L"Raiding and Pillaging",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
58700, 63700

Click on "Caravan Crate" on of the wooden boxes that has fallen out of the overturned wagon.
]],
				},
				
				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Raiding and Pillaging",
					mapPins =
					{
						{
							x = 37500,
							y = 22300,
							zoneId = 100,
							tooltip = L"Raiding and Pillaging",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
37500, 22300

Click on "Broken Wheelbarrow" amongst the barrels and other wheelbarrows.
]],
				},

				{
					name = L"Nomads",
					mapPins =
					{
						{
							x = 57100,
							y = 39500,
							zoneId = 100,
							tooltip = L"Nomads",
							icon = "TTitan_Pin_History",
						},
					},


					text =
[[
57100, 39500

Click on "Hide Stretcher" in the camp, by a large tree in front of a tent.
]],
				},

				{
					name = L"Sorcery",
					mapPins =
					{
						{
							x = 60100,
							y = 48900,
							zoneId = 100,
							tooltip = L"Sorcery",
							icon = "TTitan_Pin_History",
						},
					},


					text =
[[
60100, 48900

Click on "Another Dusty Tome" at the centre of the "Altar of the Bloodbane" PQ, it is a book lying on the ground by the altar and stones.
]],
				},

				{
					name = L"Marauders",
					mapPins =
					{
						{
							x = 31000,
							y = 47200,
							zoneId = 100,
							tooltip = L"Marauders",
							icon = "TTitan_Pin_History",
						},
					},


					text =
[[
31000, 47200

Click on "Logi" a dead horse on top of the cliff.
]],
				},
			},
		},

		{
			name = L"Troll Country",
			entries =
			{
				{
					name = L"Cult of the Plaguesworn",
					mapPins =
					{
						{
							x = 30500,
							y = 52800,
							zoneId = 101,
							tooltip = L"Cult of the Plaguesworn",
							icon = "TTitan_Pin_History",
						},
					},


					text =
[[
30500, 52800

Kill the "Blighted Prophet" standing infront of a burning building at the end of the path, on the east side of "The Blighted Farm" PQ.
]],
				},

				{
					name = L"Scarce Resources",
					mapPins =
					{
						{
							x = 22800,
							y = 52400,
							zoneId = 101,
							tooltip = L"Scarce Resources",
							icon = "TTitan_Pin_History",
						},
					},


					text =
[[
22800, 52400

Click on "Destroyed Supplies" some crates up against the burning building on the west side of "The Blighted Farm" PQ.
]],
				},

				{
					name = L"Sacred Totems",
					mapPins =
					{
						{
							x = 39200,
							y = 46200,
							zoneId = 101,
							tooltip = L"Sacred Totems",
							icon = "TTitan_Pin_History",
						},
					},


					text =
[[
39200, 46200

Approach the central one of the three wooden eagle-like totems on the beach.
]],
				},

				{
					name = L"The End Times",
					mapPins =
					{
						{
							x = 34700,
							y = 32400,
							zoneId = 101,
							tooltip = L"The End Times",
							icon = "TTitan_Pin_History",
						},
					},


					text =
[[
34700, 32400

Click on "This Will Be Your Doom" a book inside the nest, near the edge of the cliff.
]],
				},

				{
					name = L"The Cult of Sigmar",
					mapPins =
					{
						{
							x = 10400,
							y = 53000,
							zoneId = 101,
							tooltip = L"The Cult of Sigmar",
							icon = "TTitan_Pin_History",
						},
					},


					text =
[[
10400, 53000

Click on "Statue of Sigmar" at a small shire off the path in the RvR lake.
]],
				},

				{
					name = L"Nobility",
					mapPins =
					{
						{
							x = 8000,
							y = 23000,
							zoneId = 101,
							tooltip = L"Nobility",
							icon = "TTitan_Pin_History",
						},
					},


					text =
[[
8000, 23000

Click on "Fine Tools" lying on the ground, just off the cliff of Suskarg Empire chapter 5 camp.
]],
				},

				{
					name = L"Nurgle",
					mapPins =
					{
						{
							x = 52000,
							y = 30000,
							zoneId = 101,
							tooltip = L"Nurgle",
							icon = "TTitan_Pin_History",
						},
					},


					text =
[[
52000, 30000

Kill "Corvak the Mained" at the centre of "Lursa's Blight" PQ, next to the Nurgle Symbol.
]],
				},

				{
					name = L"Soulblight Stone",
					mapPins =
					{
						{
							x = 50200,
							y = 54500,
							zoneId = 101,
							tooltip = L"Soulblight Stone",
							icon = "TTitan_Pin_History",
						},
					},


					text =
[[
50200, 54500

Click on "Dead Maurauder" one amoungst 6 dead bodys on the little island between "Slayer's Demise" PQ and "Plague Trolls" PQ.
]],
				},

				{
					name = L"Taal",
					mapPins =
					{
						{
							x = 7400,
							y = 52700,
							zoneId = 101,
							tooltip = L"Taal",
							icon = "TTitan_Pin_History",
						},
					},


					text =
[[
7400, 52700

Click on "Wine in a Casket" a small barrel on a rise by some bushes in the RvR lake.
]],
				},

				{
					name = L"Mannslieb and Morrslieb",
					mapPins =
					{
						{
							x = 16200,
							y = 55400,
							zoneId = 101,
							tooltip = L"Mannslieb and Morrslieb",
							icon = "TTitan_Pin_History",
						},
					},


					text =
[[
16200, 55400

Click on "Very Large Telescope" just south of "Felde Castle" Empire chapter 6 camp. It is up on a broken piece of wall pointing into the RvR lake.
]],
				},
			},
		},

		{
			name = L"Ostland",
			entries =
			{
				{
					name = L"Twin-tailed comets and other Omens",
					mapPins =
					{
						{
							x = 32400,
							y = 13500,
							zoneId = 107,
							tooltip = L"Twin-tailed comets and other Omens",
							icon = "TTitan_Pin_History",
						},
					},


					text =
[[
32400, 13500

Click on "Sigmar Wayshrine" in the middle of the PQ.
]],
				},

				{
					name = L"Magnus the Pious",
					mapPins =
					{
						{
							x = 12600,
							y = 32500,
							zoneId = 107,
							tooltip = L"Magnus the Pious",
							icon = "TTitan_Pin_History",
						},
					},


					text =
[[
12600, 32500

Click on "The Canonization of Magus the Pious" a smail pile of books behind a bush as you go up the ramp north of the path.
]],
				},

				{
					name = L"Loathsome Rat Men",
					mapPins =
					{
						{
							x = 52000,
							y = 51900,
							zoneId = 107,
							tooltip = L"Loathsome Rat Men",
							icon = "TTitan_Pin_History",
						},
					},


					text =
[[
52000, 51900

Click on "Dead Skaven" tucked behind the grate under the bridge just east of Empire chapter 9 camp
]],
				},

				{
					name = L"Favored of the Gods",
					mapPins =
					{
						{
							x = 31700,
							y = 11800,
							zoneId = 107,
							tooltip = L"Favored of the Gods",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
31700, 11800 - In RvR lake

Click on "Dagny Betz" a corpse behind a tree with a another corpse hanging from it and a couple of other bodies surrounding it.
]],
				},

				{
					name = L"Dark Rites",
					mapPins =
					{
						{
							x = 17500,
							y = 20900,
							zoneId = 107,
							tooltip = L"Dark Rites",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
17500, 20900

Click on "Altar of the Scepter", next to the herdstone.
]],
				},

				{
					name = L"Wilderness",
					mapPins =
					{
						{
							x = 35700,
							y = 25300,
							zoneId = 107,
							tooltip = L"Wilderness",
							icon = "TTitan_Pin_History",
						},
					},


					text =
[[
35700, 25300

Click on "Empire Signpost" it is just south of the road east from "Bohsenfels" Empire chapter 8 camp.
]],
				},

				{
					name = L"Khorne",
					mapPins =
					{
						{
							x = 6300,
							y = 58600,
							zoneId = 107,
							tooltip = L"Khorne",
							icon = "TTitan_Pin_History",
						},
					},


					text =
[[
6300, 58600

Click on "Powder Barrel" just in front of the ruined tent, at the back of "Gore Wood" PQ.
]],
				},

				{
					name = L"Blood for the Blood God",
					mapPins =
					{
						{
							x = 10800,
							y = 56200,
							zoneId = 107,
							tooltip = L"Blood for the Blood God",
							icon = "TTitan_Pin_History",
						},
					},


					text =
[[
10800, 56200

Click on "Altar", just in front of the Khorne symbol in the "Gore Wood" PQ
]],
				},

				{
					name = L"The Howling Vale",
					mapPins =
					{
						{
							x = 32400,
							y = 52100,
							zoneId = 107,
							tooltip = L"The Howling Vale",
							icon = "TTitan_Pin_History",
						},
					},


					text =
[[
32400, 52100

Click on "Dead Caravan Horse" at the middle of Howling Vale PQ.
]],
				},

				{
					name = L"Forest Vipers",
					mapPins =
					{
						{
							x = 22400,
							y = 21200,
							zoneId = 107,
							tooltip = L"Forest Vipers",
							icon = "TTitan_Pin_History",
						},
					},


					text =
[[
22400, 21200

Click on "Butchered Livestock" a dead pig in the middle of the path amoungst other dead animals.
]],
				},
			},
		},

		{
			name = L"High Pass",
			entries =
			{
				{
					name = L"Doctor Zumwald",
					mapPins =
					{
						{
							x = 31200,
							y = 41400,
							zoneId = 102,
							tooltip = L"Doctor Zumwald",
							icon = "TTitan_Pin_History",
						},
					},


					text =
[[
31200, 41400

Click on "Zumwald's Supplies" a chest in the "Shrine of Tzeentch" PQ.
]],
				},

				{
					name = L"Temple of Change",
					mapPins =
					{
						{
							x = 24600,
							y = 48400,
							zoneId = 102,
							tooltip = L"Temple of Change",
							icon = "TTitan_Pin_History",
						},
					},


					text =
[[
24600, 48400

Click on "Changer's All-Seeing Eye" in the middle of the "Temple of Change" PQ, next to the centre rift straight ahead as you walk in.
]],
				},

				{
					name = L"Ranald",
					mapPins =
					{
						{
							x = 26900,
							y = 18500,
							zoneId = 102,
							tooltip = L"Ranald",
							icon = "TTitan_Pin_History",
						},
					},


					text =
[[
26900, 18500

Click on "Bag of Dice" between two dead marauders near a cooking pot.
]],
				},

				{
					name = L"The Luminous Veil",
					mapPins =
					{
						{
							x = 62400,
							y = 37400,
							zoneId = 102,
							tooltip = L"The Luminous Veil",
							icon = "TTitan_Pin_History",
						},
					},


					text =
[[
62400, 37400

Click on "Blast Victim" in the crater next to the fire.
]],
				},

				{
					name = L"Empire Steam Tank",
					mapPins =
					{
						{
							x = 11600,
							y = 58900,
							zoneId = 102,
							tooltip = L"Empire Steam Tank",
							icon = "TTitan_Pin_History",
						},
					},


					text =
[[
11600, 58900

Approach the steam tank east of "Raven's End" Empire chapter 11.
]],
				},

				{
					name = L"The Sigil of Malice",
					mapPins =
					{
						{
							x = 10400,
							y = 11500,
							zoneId = 102,
							tooltip = L"The Sigil of Malice",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
10400, 11500

Click on "Bloody Sigil" hanging from the ceiling above the balcony overlooking the main entance hall inside the temple.
]],
				},

				{
					name = L"Shallya",
					mapPins =
					{
						{
							x = 49100,
							y = 55500,
							zoneId = 102,
							tooltip = L"Shallya",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
49100, 55500 - In RvR Lake

Click on "Plague Victim" on the right side of the door into the tower at "Hallenfurt Manor" BO, behind the rocks. 
]],
				},

				{
					name = L"Ogrund's Tavern",
					mapPins =
					{
						{
							x = 27800,
							y = 60100,
							zoneId = 102,
							tooltip = L"Ogrund's Tavern",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
27800, 60100 - In RvR Lake

Click on "Tavern Door" the entry door to the "Ogrund's Tavern" BO.
]],
				},

				{
					name = L"Feiten's Lock",
					mapPins =
					{
						{
							x = 13000,
							y = 64600,
							zoneId = 102,
							tooltip = L"Feiten's Lock",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
13000, 64600 - In RvR Lake

Click on "Door" in the gateway to "Feiten's Lock" BO on the south side.
]],
				},

				{
					name = L"Fort Marvik",
					mapPins =
					{
						{
							x = 4900,
							y = 56600,
							zoneId = 102,
							tooltip = L"Fort Marvik",
							icon = "TTitan_Pin_History",
						},
					},					
					text =
[[
4900, 56600 - In RvR Lake

Click on "Massive Bloodwrought Chain" attached to the East side of Stoneclaw Castle inner keep.
]],
				},

				{
					name = L"Black Powder",
					mapPins =
					{
						{
							x = 27800,
							y = 58700,
							zoneId = 102,
							tooltip = L"Black Powder",
							icon = "TTitan_Pin_History",
						},
					},	
					text =
[[
27800, 58700 - In RvR Lake

Click on "Black Powder Keg" behind "Ogrund's Tavern" BO, just next to the giant barrels.
]],
				},

				{
					name = L"Myrmidia",
					mapPins =
					{
						{
							x = 46700,
							y = 62000,
							zoneId = 102,
							tooltip = L"Myrmidia",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
46700, 62000 - In RvR Lake

Click on "On Warfare" a pile of three books on the inside of the outer wall of "Hallenfurt Manor" BO in the RvR lake, right up against the wall. 
]],
				},

				{
					name = L"The Grand Conclave",
					mapPins =
					{
						{
							x = 51700,
							y = 63600,
							zoneId = 102,
							tooltip = L"The Grand Conclave",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
51700, 63600 - In RvR Lake

Click on "Letter to the Order of Luck" a scroll with a dead horse and rider nearby. 
]],
				},

				{
					name = L"Verena",
					mapPins =
					{
						{
							x = 30500,
							y = 44200,
							zoneId = 102,
							tooltip = L"Verena",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
30500, 44200

Click on "Dietrich's Letter" at scroll in the snow, up in the cliff edge near the base on one of the big rock spikes, on the south side of "Shrine of Tzeentch" PQ.
]],
				},

				{
					name = L"Exorcism",
					mapPins =
					{
						{
							x = 42100,
							y = 55900,
							zoneId = 102,
							tooltip = L"Exorcism",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
42100, 55900

Click on "Blair's Raiments" a chest in the middle of the camp near the steam tank.
]],
				},
			},
		},

		{
			name = L"Talabecland",
			entries =
			{
				{
					name = L"Serpent Fang Bandits",
					mapPins =
					{
						{
							x = 2700,
							y = 18500,
							zoneId = 108,
							tooltip = L"Serpent Fang Bandits",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
2700, 18500

Click on "Far-Too-Lavish Pillows" a group of floor cushions, just inside the tent on the right side.
]],
				},

				{
					name = L"Slaanesh",
					mapPins =
					{
						{
							x = 13800,
							y = 49300,
							zoneId = 108,
							tooltip = L"Slaanesh",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
13800, 49300

Click on "Albert Calvert Sr." a dead body on the north side of the building next to the path. It's is between the entrance stairs and the large doorway.
]],
				},

				{
					name = L"Corruptor's Crown",
					mapPins =
					{
						{
							x = 39500,
							y = 800,
							zoneId = 108,
							tooltip = L"Corruptor's Crown",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
39500, 800 - In RvR Lake

Click on "Frozen Corpse" inside the cave.
]],
				},

				{
					name = L"Lady Kreuger",
					mapPins =
					{
						{
							x = 40400,
							y = 17300,
							zoneId = 108,
							tooltip = L"Lady Kreuger",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
40400, 17300

Click on "Implement of Vanity" in the final room at the very top of Lady Krueger's manor.
]],
				},

				{
					name = L"Verentane's Keep",
										mapPins =
					{
						{
							x = 28900,
							y = 8300,
							zoneId = 108,
							tooltip = L"Verentane's Keep",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
28900, 8300

Click on "Door" to "Verentane's Tower" BO.
]],
				},

				{
					name = L"Dragonships",
					mapPins =
					{
						{
							x = 50900,
							y = 17200,
							zoneId = 108,
							tooltip = L"Dragonships",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
50900, 17200

Click on "Raider's Kindling" in front of the middle ship at "Blackwood Shore Landing" major landmark.
]],
				},

				{
					name = L"Necromancy",
					mapPins =
					{
						{
							x = 45500,
							y = 49300,
							zoneId = 108,
							tooltip = L"Necromancy",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
45500, 49300

Click on "Gosbert Troutman" a coffin underneath the "Haunted Windmill" major landmark.
]],
				},

				{
					name = L"Witch Hunts",
					mapPins =
					{
						{
							x = 24100,
							y = 28500,
							zoneId = 108,
							tooltip = L"Witch Hunts",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
24100, 28500

Click on "Here lies Hester Prynne" a gravestone inside the graveyard.
]],
				},

				{
					name = L"Talabec River",
					mapPins =
					{
						{
							x = 17900,
							y = 41900,
							zoneId = 108,
							tooltip = L"Talabec River",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
17900, 41900

Click on "Basket of Fish" on the boat at "Unterbaum Docks" major landmark.
]],
				},

				{
					name = L"Woodsmen",
					mapPins =
					{
						{
							x = 13300,
							y = 7400,
							zoneId = 108,
							tooltip = L"Woodsmen",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
13300, 7400

Click on "Basket of Apples" on a wagon just off the south end of the bridge.
]],
				},

				{
					name = L"Talabecland Thunder-Water",
					mapPins =
					{
						{
							x = 54100,
							y = 30000,
							zoneId = 108,
							tooltip = L"Talabecland Thunder-Water",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
54100, 30000

Click on "Tasty Beverage" a very small gold goblet and green bottle off the south east side of the main road.
]],
				},

				{
					name = L"Longshanks",
					mapPins =
					{
						{
							x = 8200,
							y = 21700,
							zoneId = 108,
							tooltip = L"Longshanks",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
8200, 21700

Click on "Longshanks" a corpse face down on the ground.
]],
				},

				{
					name = L"Rhya",
					mapPins =
					{
						{
							x = 41700,
							y = 40100,
							zoneId = 108,
							tooltip = L"Rhya",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
41700, 40100 

Click on "Rest in Peace" a tombstone in the graveyard.
]],
				},

				{
					name = L"Eye of the Beholder",
					mapPins =
					{
						{
							x = 32200,
							y = 22900,
							zoneId = 108,
							tooltip = L"Eye of the Beholder",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
32200, 22900

Click on "Stirland Red" a barrel off the west end of the bridge.
]],
				},

				{
					name = L"Moral Oppression",
					mapPins =
					{
						{
							x = 33000,
							y = 45600,
							zoneId = 108,
							tooltip = L"Moral Oppression",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
33000, 45600

Click on "Torture Stake" just east of Unterbaum.
]],
				},
			},
		},

		{
			name = L"Reikland",
			entries =
			{
				{
					name = L"The Reiksguard",
					mapPins =
					{
						{
							x = 25900,
							y = 52000,
							zoneId = 109,
							tooltip = L"The Reiksguard",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
25900, 52000 - In RvR Lake

Click on "Reiksguard Guide" next to the fenced tomb.
]],
				},

				{
					name = L"The River Reik",
					mapPins =
					{
						{
							x = 29000,
							y = 48000,
							zoneId = 109,
							tooltip = L"The River Reik",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
29000, 48000 - In RvR Lake

Ride over the bridge.
]],
				},

				{
					name = L"Slaves to Fashion",
					mapPins =
					{
						{
							x = 49700,
							y = 63900,
							zoneId = 109,
							tooltip = L"Slaves to Fashion",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
49700, 63900

Click on "Empire Couture", a rock with a couple of ragged clothes lying on it. 
]],
				},

				{
					name = L"The Cult of Shallya",
					mapPins =
					{
						{
							x = 57700,
							y = 10300,
							zoneId = 109,
							tooltip = L"The Cult of Shallya",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
57700, 10300

Click on "Pligrim's Bedroll" behind the tent.
]],
				},

				{
					name = L"Reikflies",
					mapPins =
					{
						{
							x = 53000,
							y = 51500,
							zoneId = 109,
							tooltip = L"Reikflies",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
53000, 51500

Click on "Barrel of Ale", on the outside of the walls.
]],
				},

             			{
                 			name = L"Agitators",
					mapPins =
					{
						{
							x = 6200,
							y = 9100,
							zoneId = 109,
							tooltip = L"Agitators",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
6200, 9100

Click on "Soap Box", on ther steps up to a house, in the Castle Grauenburg PQ area. 
]],
				},

				{
					name = L"Abject Poverty",
					mapPins =
					{
						{
							x = 11000,
							y = 16300,
							zoneId = 109,
							tooltip = L"Abject Poverty",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
11000, 16300

Click on "Raven Ward" between two of the houses.
]],
				},

				{
					name = L"The Celestial College",
					mapPins =
					{
						{
							x = 28700,
							y = 26900,
							zoneId = 109,
							tooltip = L"The Celestial College",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
28700, 26900 - In RvR Lake

Click on "Dwarven Refractory Contraption" just west of Wilhem's Fist main keep.
]],
				},

				{
					name = L"Reik River Bandits",
					mapPins =
					{
						{
							x = 6700,
							y = 27900,
							zoneId = 109,
							tooltip = L"Reik River Bandits",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
6700, 27900

Click on "Bag of Gold" on the East side of the tent.
]],
				},

				{
					name = L"Reikland Blackswords",
					mapPins =
					{
						{
							x = 40600,
							y = 20700,
							zoneId = 109,
							tooltip = L"Reikland Blackswords",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
40600, 20700

Click on "Company Ledger" on the table inside the tent.
]],
				},

				{
					name = L"Morr's Maze",
					mapPins =
					{
						{
							x = 63100,
							y = 36200,
							zoneId = 109,
							tooltip = L"Morr's Maze",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
63100, 36200

Click on "Crypt Gate" the entance gates to "Morr's Maze" major landmark.
]],
				},

				{
					name = L"Hedge Wizards",
					mapPins =
					{
						{
							x = 33200,
							y = 23000,
							zoneId = 109,
							tooltip = L"Hedge Wizards",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
33200, 23000 - In RvR Lake

Click on "Stolen Wizard's Notes" a pile of buring scrolls, on the ledge East of Wilhelm's Fist main gate.
]],
				},

				{
					name = L"Detachments",
					mapPins =
					{
						{
							x = 47900,
							y = 60300,
							zoneId = 109,
							tooltip = L"Detachments",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
47900, 60300

Click on "Nuln Cannonballs" next to the three cannons looking down the hill.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"The Jade Order",
					mapPins =
					{
						{
							x = 11600,
							y = 35900,
							zoneId = 109,
							tooltip = L"The Jade Order",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
11600, 35900

Kill "Conrad Groenfeld" sitting by a large tree, just East of "Kreuznach", Empire Chapter 15.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"The Jade Order",
					mapPins =
					{
						{
							x = 11600,
							y = 35900,
							zoneId = 109,
							tooltip = L"The Jade Order",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
11600, 35900

Talk to "Conrad Groenfeld" sitting by a large tree, just East of "Kreuznach", Empire Chapter 15.
]],
				},

				{
					name = L"Tilea",
					mapPins =
					{
						{
							x = 46600,
							y = 28600,
							zoneId = 109,
							tooltip = L"Tilea",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
46600, 28600

Click on "Man O'War", a dead horse, just at the south end of the bridge.
]],
				},
			},
		},

		{
			name = L"Praag",
			entries =
			{
				{
					name = L"Kislev",
					mapPins =
					{
						{
							x = 38000,
							y = 25900,
							zoneId = 105,
							tooltip = L"Kislev",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
38000, 25900 - In RvR lake

Click on "Sergey Babyuk" hung from the side of the building.
]],
				},

				{
					name = L"The Steppes",
					mapPins =
					{
						{
							x = 25900,
							y = 3900,
							zoneId = 105,
							tooltip = L"The Steppes",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
25900, 3900

Click on "Broken Plow" half hidden in the bush. 
]],
				},

				{
					name = L"Ungol Horsemen",
					mapPins =
					{
						{
							x = 8900,
							y = 19100,
							zoneId = 105,
							tooltip = L"Ungol Horsemen",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
8900, 19100

Click on "Archery Target".
]],
				},

				{
					name = L"Tor",
					mapPins =
					{
						{
							x = 10800,
							y = 3100,
							zoneId = 105,
							tooltip = L"Tor",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
10800, 3100

Click on "A Treatise on the Gods" a book on the ground next to a brazier.
]],
				},

				{
					name = L"Warpwind Clan",
					mapPins =
					{
						{
							x = 4200,
							y = 64500,
							zoneId = 105,
							tooltip = L"Warpwind Clan",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
4200, 64500

Click on "Warpwind Clan Banner" inside "Skaven Tunnels" major landmark.
]],
				},

				{
					name = L"Vodka",
					mapPins =
					{
						{
							x = 17300,
							y = 42800,
							zoneId = 105,
							tooltip = L"Vodka",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
17300, 42800

Click on "Cup" on the steps of a small building.
]],
				},

				{
					name = L"Dazh",
					mapPins =
					{
						{
							x = 63100,
							y = 20600,
							zoneId = 105,
							tooltip = L"Dazh",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
63100, 20600

Click on "Breath of Dazh" a brazier on the ground floor of "Cinderash Tower" major landmark.
]],
				},

				{
					name = L"Gospodars",
					mapPins =
					{
						{
							x = 8800,
							y = 39400,
							zoneId = 105,
							tooltip = L"Gospodars",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
8800, 39400

Click on "Sascha Makiev" a corpse up on a platform.
]],
				},

				{
					name = L"Winged Lancers",
					mapPins =
					{
						{
							x = 52200,
							y = 51500,
							zoneId = 120,
							tooltip = L"Winged Lancers",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
52200, 51500 - In West Praag

Click on "Lancer's Horse".
]],
				},

				{
					name = L"Ursun",
					mapPins =
					{
						{
							x = 63500,
							y = 31900,
							zoneId = 105,
							tooltip = L"Ursun",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
63500, 31900

Click on "Sacred Pelts", on the right side as you enter inside "Ursun's Den" major landmark.
]],
				},

				{
					name = L"Gryphon Legion",
										mapPins =
					{
						{
							x = 29300,
							y = 27600,
							zoneId = 105,
							tooltip = L"Gryphon Legion",
							icon = "TTitan_Pin_History",
						},
					},
					
					text =
[[
29300, 27600 - In RvR lake

Click on "Banner of Praag" flying on the city wall.
]],
				},

				{
					name = L"The Ice Queen of Kislev",
					mapPins =
					{
						{
							x = 50800,
							y = 62100,
							zoneId = 105,
							tooltip = L"The Ice Queen of Kislev",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
50800, 62100

Click on "Kislevite Aid", a pile of sacks up against the large cart.
]],
				},

				{
					name = L"The Great War Against Chaos",
					mapPins =
					{
						{
							x = 50800,
							y = 24400,
							zoneId = 120,
							tooltip = L"The Great War Against Chaos",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
50800, 24400 - In West Pragg

Click on "Sundered Memorial" on the ground, left of the steps to the small building.
]],
				},

				{
					name = L"Ice Magic",
					mapPins =
					{
						{
							x = 28300,
							y = 37900,
							zoneId = 120,
							tooltip = L"Ice Magic",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
28300, 37900 - In West Pragg

Click on "Ice Conduit", on the right just as you enter Frostshard Prison.
]],
				},

				{
					name = L"The Cursed City",
					mapPins =
					{
						{
							x = 46500,
							y = 19100,
							zoneId = 105,
							tooltip = L"The Cursed City",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
46500, 19100

Click on "Daemon's Finger", a small rock spike at the base of the larger one.
]],
				},
			},
		},

		{
			name = L"Chaos Wastes",
			entries =
			{
				{
					name = L"Mutation",
					mapPins =
					{
						{
							x = 33400,
							y = 16200,
							zoneId = 103,
							tooltip = L"Mutation",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
33400, 16200 - In RvR lake

Click on "Journal of Teppo Benzinger" under a couple of bushes, near "Zimmeron's Hold" east postern.
]],
				},

				{
					name = L"Change Storms",
					mapPins =
					{
						{
							x = 55900,
							y = 3000,
							zoneId = 103,
							tooltip = L"Change Storms",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
55900, 3000

Click on "Forlorn Skull" on the ground at the based of the crucified empire soilder.
]],
				},

				{
					name = L"Changing Terrain",
					mapPins =
					{
						{
							x = 33800,
							y = 35300,
							zoneId = 103,
							tooltip = L"Changing Terrain",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
33800, 35300 - In RvR lake

Click on "Ragnar Danneskjold" a corpse at the bottom of the ridge line.
]],
				},

				{
					name = L"Tribal Rivalries",
					mapPins =
					{
						{
							x = 49100,
							y = 18400,
							zoneId = 103,
							tooltip = L"Tribal Rivalries",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
49100, 18400

Click on "Tong Curr" a corpse round the back of "Altar of Madness" PQ.
]],
				},

				{
					name = L"The Lonely Tower",
					mapPins =
					{
						{
							x = 2300,
							y = 22100,
							zoneId = 103,
							tooltip = L"The Lonely Tower",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
2300, 22100

Approach the steps leading to tower door in "Lonely Tower" PQ.
]],
				},

				{
					name = L"Monoliths",
					mapPins =
					{
						{
							x = 46900,
							y = 46500,
							zoneId = 103,
							tooltip = L"Monoliths",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
46900, 46500 - In RvR Lake

Click on "Chaotic Writings" just East of "The Shrine of Time" BO, behind the broken wall.
]],
				},

				{
					name = L"Grimclan",
					mapPins =
					{
						{
							x = 12400,
							y = 53800,
							zoneId = 103,
							tooltip = L"Grimclan",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
12400, 53800

Click on "Grimclan Banner" just on the outside of the outer ring of teeth/spikes.
]],
				},

				{
					name = L"Grimnir's Journey",
					mapPins =
					{
						{
							x = 31100,
							y = 2400,
							zoneId = 103,
							tooltip = L"Grimnir's Journey",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
31100, 2400 - In RvR lake

Click on "Grimnir's Axe" on the hill to the north of "Chokethorn Bramble" BO, you have to go into The Maw to climb to it.
]],
				},

				{
					name = L"Soul Gem",
					mapPins =
					{
						{
							x = 15700,
							y = 56300,
							zoneId = 103,
							tooltip = L"Soul Gem",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
15700, 56300

Click on "Altera's Scribbles" a book the book a short distance away from the front of the ruined house , on the edge of the ridge.
]],
				},

				{
					name = L"Corruption",
					mapPins =
					{
						{
							x = 10900,
							y = 16700,
							zoneId = 103,
							tooltip = L"Corruption",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
10900, 16700

Click on "Local Flora" a large mutant plant south of the road.
]],
				},

				{
					name = L"Teef",
					mapPins =
					{
						{
							x = 46900,
							y = 4100,
							zoneId = 103,
							tooltip = L"Teef",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
46900, 4100

Click on "Grobbag's Teef" on the north side of the road, next to a dead bush.
]],
				},

				{
					name = L"Gifts of the Gods",
					mapPins =
					{
						{
							x = 48000,
							y = 43300,
							zoneId = 103,
							tooltip = L"Gifts of the Gods",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
48000, 43300

Click on "Destroyed Desk" inside the south tent in the camp.
]],
				},

				{
					name = L"Rise of a Champion",
					mapPins =
					{
						{
							x = 29200,
							y = 46500,
							zoneId = 103,
							tooltip = L"Rise of a Champion",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
29200, 46500 - In RvR lake

Click on "Champion's Tribute" a brazier next to the huge statue head, south east of "The Statue of the Everchosen" BO..
]],
				},

				{
					name = L"The Hill of the Dead",
					mapPins =
					{
						{
							x = 25500,
							y = 39500,
							zoneId = 103,
							tooltip = L"The Hill of the Dead",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
25500, 39500 - In RvR lake

Approach the totem on the rise.
]],
				},

				{
					name = L"Daemon Weapon",
					mapPins =
					{
						{
							x = 35500,
							y = 40400,
							zoneId = 103,
							tooltip = L"Daemon Weapon",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
35500, 40400 - In RvR lake

Click on "Soul's Kiss" under the arch in the broken piece of wall, item has a low purple glow.
]],
				},
			},
		},

		{
			name = L"Bastion Stair",
			entries =
			{
				{	
					name = L"Trail of Carnage",
					mapPins =
					{
						{
							x = 31700,
							y = 44100,
							zoneId = 160,
							tooltip = L"Trail of Carnage",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
31700, 44100

Click on "Tablet of Carnage" in the lobby area of the dungeon, on the West side of the stairs.
]],
				},
				
				{	
					name = L"Path of Fury",
					mapPins =
					{
						{
							x = 33600,
							y = 44100,
							zoneId = 160,
							tooltip = L"Path of Fury",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
33600, 44100

Click on "Tablet of Fury" in the lobby area of the dungeon, on the East side of the stairs.
]],
				},
								
				{	
					name = L"Steps of Ruin",
					mapPins =
					{
						{
							x = 32700,
							y = 42900,
							zoneId = 160,
							tooltip = L"Steps of Ruin",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
32700, 42900

Click on "Tablet of Ruin" in the lobby area of the dungeon, in the centre up the first flight of the stairs.
]],
				},
															
				{	
					name = L"The Blood Meadows",
					mapPins =
					{
						{
							x = 55900,
							y = 12900,
							zoneId = 160,
							tooltip = L"The Blood Meadows",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
55900, 12900

Click on "Aged Blood Fruit", a basket on the altar.
]],
				},
																			
				{	
					name = L"Contempt of Magic",
					mapPins =
					{
						{
							x = 59300,
							y = 12500,
							zoneId = 160,
							tooltip = L"Contempt of Magic",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
59300, 12500

Click on "Slain Coward" a magus corpse in the side room, while climbing the stairwell.
]],
				},
																										
				{	
					name = L"The Bloodherd",
					mapPins =
					{
						{
							x = 17300,
							y = 14800,
							zoneId = 160,
							tooltip = L"The Bloodherd",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
17300, 14800

Click on "The Defeated" a large bone pile at the side of the corridor.
]],
				},
																														
				{	
					name = L"The Skulltakers",
					mapPins =
					{
						{
							x = 50600,
							y = 17800,
							zoneId = 160,
							tooltip = L"The Skulltakers",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
50600, 17800

Click on "Skulltaker Banner" on the side of the corridor.
]],
				},
																																		
				{	
					name = L"The Brass Legion",
					mapPins =
					{
						{
							x = 35700,
							y = 41600,
							zoneId = 160,
							tooltip = L"The Brass Legion",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
35700, 41600

Click on "Brass Legion Banner" on edge of the platform area.
]],
				},
			},
		},	

		{
			name = L"Altdorf",
			entries =
			{
				{	
					name = L"The Altdorf Docks",
					mapPins =
					{
						{
							x = 34500,
							y = 32300,
							zoneId = 162,
							tooltip = L"The Altdorf Docks",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
34500, 32300

Enter the Docks area, unlocked at this location but shoudl work anywhere along quayside.
]],
				},

				{	
					name = L"Ol' Knuckles' Ring",
					mapPins =
					{
						{
							x = 31800,
							y = 28100,
							zoneId = 162,
							tooltip = L"Ol' Knuckles' Ring",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
31800, 28100

Enter the boxing ring area at the far north end of the docks, across from "The Blowhole" tavern.
]],
				},

				{	
					name = L"Pale-Eye Hideout",
					mapPins =
					{
						{
							x = 34700,
							y = 33900,
							zoneId = 162,
							tooltip = L"Pale-Eye Hideout",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
34700, 33900

Approach the Pale-Eye Hideout, it is inside a building just east of the entrance to Bright Wizard College. Can be unlocked in areas around the building, without the need to go in.
]],
				},

				{	
					name = L"The Sewers of Altdorf",
					mapPins =
					{
						{
							x = 37300,
							y = 30600,
							zoneId = 152,
							tooltip = L"The Sewers of Altdorf",
							icon = "TTitan_Pin_History",
						},
					},


					text =
[[
37300, 30600 - Inside The Sewers of Altdorf (South Wing)

Click on "Slain City Guard" just inside the south sewer instance, a corpse slumped over against a pile of pooh on the rightside.
]],
				},

				{	
					name = L"The Blowhole Tavern",
					mapPins =
					{
						{
							x = 31100,
							y = 28500,
							zoneId = 162,
							tooltip = L"The Blowhole Tavern",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
31100, 28500

Enter "The Blowhole" tavern, located on far north end of the docks.
]],
				},

				{	
					name = L"The Cult of the Feathered Coin",
					mapPins =
					{
						{
							x = 20300,
							y = 34200,
							zoneId = 162,
							tooltip = L"The Cult of the Feathered Coin",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
20300, 34200

To the north of the Temple of Sigmar, keep going north until you see a fence gate in front of you, turn right and go into the small alley, unlocks just inside the door.
]],
				},

				{	
					name = L"The City Guard",
					mapPins =
					{
						{
							x = 29900,
							y = 32400,
							zoneId = 162,
							tooltip = L"The City Guard",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
29900, 32400

Talk to "City Guard" NPC, worked on ones just outside the north sewers entrance.
]],
				},

				{	
					name = L"The First Bank of Altdorf",
					mapPins =
					{
						{
							x = 21200,
							y = 38200,
							zoneId = 162,
							tooltip = L"The First Bank of Altdorf",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
21200, 38200

Enter The First Bank of Altdorf, unlocks just inside the door
]],
				},

				{	
					name = L"The Emperor's Palace",
					mapPins =
					{
						{
							x = 25500,
							y = 29900,
							zoneId = 162,
							tooltip = L"The Emperor's Palace",
							icon = "TTitan_Pin_History",
						},
					},


					text =
[[
25500, 29900

Enter "Palace" area on the map, (Green area).
]],
				},

				{	
					name = L"The Temple of Sigmar",
					mapPins =
					{
						{
							x = 15400,
							y = 38100,
							zoneId = 162,
							tooltip = L"The Temple of Sigmar",
							icon = "TTitan_Pin_History",
						},
					},


					text =
[[
15400, 38100

Enter "Temple" area on the map (Orange area).
]],
				},

				{	
					name = L"The Reikland Arms",
					mapPins =
					{
						{
							x = 19700,
							y = 38200,
							zoneId = 162,
							tooltip = L"The Reikland Arms",
							icon = "TTitan_Pin_History",
						},
					},


					text =
[[
19700, 38200

Enter "Reikland Arms" tavern, across from First Bank of Altdorf.
]],
				},

				{	
					name = L"The Clank",
					mapPins =
					{
						{
							x = 23400,
							y = 42000,
							zoneId = 162,
							tooltip = L"The Clank",
							icon = "TTitan_Pin_History",
						},
					},


					text =
[[
23400, 42000

Enter The Clank on the west side of Emperors Cirle (central area of the map with the statue).
]],
				},

				{	
					name = L"Aqshy Fountain",
					mapPins =
					{
						{
							x = 32200,
							y = 34300,
							zoneId = 162,
							tooltip = L"Aqshy Fountain",
							icon = "TTitan_Pin_History",
						},
					},


					text =
[[
32200, 34300 - Inside the Bright Wizard College, enter at this location.

Click "Aqshy Conduit" right at the top of the Bright Wizard College on a balcony
]],
				},

				{	
					name = L"The Slums",
					mapPins =
					{
						{
							x = 28900,
							y = 37300,
							zoneId = 162,
							tooltip = L"The Slums",
							icon = "TTitan_Pin_History",
						},
					},


					text =
[[
28900, 37300

Enter the Slums.
]],
				},

				{	
					name = L"Lord's Row",
					mapPins =
					{
						{
							x = 20500,
							y = 38700,
							zoneId = 162,
							tooltip = L"Lord's Row",
							icon = "TTitan_Pin_History",
						},
					},


					text =
[[
20500, 38700

Enter the Lord's Row (Pink Area).
]],
				},

				{	
					name = L"War Quarters",
					mapPins =
					{
						{
							x = 19500,
							y = 49500,
							zoneId = 162,
							tooltip = L"War Quarters",
							icon = "TTitan_Pin_History",
						},
					},


					text =
[[
19500, 49500

Enter the War Quarters area (Red area).
]],
				},

				{	
					name = L"Legacy of the Emperors",
					mapPins =
					{
						{
							x = 25700,
							y = 30300,
							zoneId = 162,
							tooltip = L"Legacy of the Emperors",
							icon = "TTitan_Pin_History",
						},
					},


					text =
[[
25700, 30300

Click on "Old Empire Standard" a red standard on the wall on the right side of the 2nd doorway to the Palace from the Marketplace.
]],
				},

				{	
					name = L"The Bright College",
					mapPins =
					{
						{
							x = 32200,
							y = 34300,
							zoneId = 162,
							tooltip = L"The Bright College",
							icon = "TTitan_Pin_History",
						},
					},


					text =
[[
32200, 34300

Enter the Bright Wizard College.
]],
				},

				{	
					name = L"Market Square",
					mapPins =
					{
						{
							x = 25500,
							y = 33300,
							zoneId = 162,
							tooltip = L"Market Square",
							icon = "TTitan_Pin_History",
						},
					},


					text =
[[
25500, 33300

Enter the Market Square (Blue area).
]],
				},

				{	
					name = L"Goradian's Fall",
					mapPins =
					{
						{
							x = 38500,
							y = 32600,
							zoneId = 169,
							tooltip = L"Goradian's Fall",
							icon = "TTitan_Pin_History",
						},
					},


					text =
[[
38500, 32600 - Inside The Sewers of Altdorf (Middle Wing)

Click on "Well Worn Book", outside the room with Goradian The Creator. It is on the right-hand side in the corner before you go in.
]],
				},
			},
		},

		{
			name = L"The Inevitable City",
			entries =
			{
				{	
					name = L"The Sacellum",
					mapPins =
					{
						{
							x = 41700,
							y = 34700,
							zoneId = 161,
							tooltip = L"The Sacellum",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
41700, 34700

Approach the area with the "Sacellum Dungeons" major landmarks.
]],
				},

				{	
					name = L"The Holding Pits",
					mapPins =
					{
						{
							x = 57600,
							y = 31600,
							zoneId = 156,
							tooltip = L"The Holding Pits",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
57600, 31600

Kill "Malghar Ragehorn" in the Sacellum Dungeon East Wing. He can be found behind the first set of gates on the right as you go into the East Wing.
]],
				},

				{	
					name = L"The Cult of the Plaguesworn",
					mapPins =
					{
						{
							x = 50200,
							y = 35500,
							zoneId = 161,
							tooltip = L"The Cult of the Plaguesworn",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
50200, 35500

Talk to "Shargra Glutmire" in Fleshrot Alley.
]],
				},

				{	
					name = L"The Bloodfiends",
					mapPins =
					{
						{
							x = 40300,
							y = 40700,
							zoneId = 161,
							tooltip = L"The Bloodfiends",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
40300, 40700

Click on "Mark of Khorne" symbol hanging in the archway south of the Sacellum.
]],
				},

				{	
					name = L"The Battle for the Herdstone",
					mapPins =
					{
						{
							x = 35500,
							y = 36000,
							zoneId = 161,
							tooltip = L"The Battle for the Herdstone",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
35500, 36000

Approach the large Herdstone.
]],
				},

				{	
					name = L"The Temple of the Damned",
					mapPins =
					{
						{
							x = 36600,
							y = 38900,
							zoneId = 161,
							tooltip = L"The Temple of the Damned",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
36600, 38900

Kill "Sovek the Merciless" inside the temple, during the publ;ic quest.
]],
				},

				{	
					name = L"The Lost Narrows",
					mapPins =
					{
						{
							x = 34800,
							y = 40200,
							zoneId = 161,
							tooltip = L"The Lost Narrows",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
34800, 40200

Approach this area, east of The Apex (blue area on the map).
]],
				},

				{	
					name = L"The Apex",
					mapPins =
					{
						{
							x = 30400,
							y = 37500,
							zoneId = 161,
							tooltip = L"The Apex",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
30400, 37500

Approach The Apex (blue area on the map).
]],
				},

				{	
					name = L"Soul Vaults",
					mapPins =
					{
						{
							x = 28600,
							y = 43000,
							zoneId = 161,
							tooltip = L"Soul Vaults",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
28600, 43000

Enter the bank area, south of The Apex 
]],
				},

				{	
					name = L"The Eternal Citadel",
					mapPins =
					{
						{
							x = 30900,
							y = 25600,
							zoneId = 161,
							tooltip = L"The Eternal Citadel",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
30900, 25600

Approach The Eternal Citadel (pink area on the map).
]],
				},

				{	
					name = L"The Scrying Vats",
					mapPins =
					{
						{
							x = 28200,
							y = 36600,
							zoneId = 161,
							tooltip = L"The Scrying Vats",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
28200, 36600

Click on "Image of the Emperor" just south of the auction house in The Apex (blue area on the map).
]],
				},

				{	
					name = L"Journey's End",
					mapPins =
					{
						{
							x = 22000,
							y = 44200,
							zoneId = 161,
							tooltip = L"Journey's End",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
22000, 44200

Click on "Agder Rotwing" a pertified corpse in the corner at this location.
]],
				},

				{	
					name = L"The Price of Knowledge",
					mapPins =
					{
						{
							x = 18200,
							y = 34900,
							zoneId = 161,
							tooltip = L"The Price of Knowledge",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
18200, 34900

Click on "Treatise of Dire Caution" in The Lyceum.
]],
				},

				{	
					name = L"The Foreboding Lyceum",
					mapPins =
					{
						{
							x = 14700,
							y = 37100,
							zoneId = 161,
							tooltip = L"The Foreboding Lyceum",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
14700, 37100

Talk to "Disciple Everdamned", in the room at the end of left wing of the Lyceum.
]],
				},

				{	
					name = L"The Monolith",
					mapPins =
					{
						{
							x = 22500,
							y = 37500,
							zoneId = 161,
							tooltip = L"The Monolith",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
22500, 37500

Approach the Monolith (orange area on the map).
]],
				},

				{	
					name = L"The Sentries",
					mapPins =
					{
						{
							x = 30000,
							y = 32000,
							zoneId = 161,
							tooltip = L"The Sentries",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
30000, 32000

Talk to a "Dread Sentry".  Many to choose from all around this area and others.
]],
				},

				{	
					name = L"Fate's Edge",
					mapPins =
					{
						{
							x = 28700,
							y = 32100,
							zoneId = 161,
							tooltip = L"Fate's Edge",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
28700, 32100

Approach the area around the flight master (will unlock when you fly in).
]],
				},

				{	
					name = L"Dhar'ek Cores",
					mapPins =
					{
						{
							x = 36100,
							y = 32900,
							zoneId = 161,
							tooltip = L"Dhar'ek Cores",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
36100, 32900

Click on "Dhar'ek Core".
]],
				},

				{	
					name = L"Imbalance of Power",
					mapPins =
					{
						{
							x = 32400,
							y = 27900,
							zoneId = 161,
							tooltip = L"Imbalance of Power",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
32400, 27900

Kill "Blue Speckled Crow" outside of The Viper Pit on the north side.
]],
				},

				{	
					name = L"The Watchers",
					mapPins =
					{
						{
							x = 30500,
							y = 44400,
							zoneId = 161,
							tooltip = L"The Watchers",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
30500, 44400

Approach this area south of The Aprex (blue area on the map).
]],
				},
			},
		},
	},
}
