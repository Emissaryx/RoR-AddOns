TTitan.Data.Explorations = {}

function TTitan.Data.Explorations.GetData()
	return TTitan.Data.Explorations.RawData
end

function TTitan.Data.Explorations.FilterData()
	TTitan.Data.FilterByRealm(TTitan.Data.Explorations.RawData)
end

TTitan.Data.Explorations.RawData =
{
	header = L"Exploration Achievements",
	categories =
	{
		{
			name = L"Ancient Lament",
			entries =
			{
				{
					name = L"Ancient Lament",
					mapPins =
					{
						{
							x = 45000,
							y = 24100,
							zoneId = 200,
							tooltip = L"Ancient Lament",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
45000, 24100 - In The Blighted Isle

Click on "Ancient Scroll" on the small stone bench.
]],
				},
			},
		},

		{
			name = L"Cold One Hunters",
			entries =
			{
				{
					name = L"Cold One Hunters",
					mapPins =
					{
						{
							x = 58000,
							y = 41200,
							zoneId = 200,
							tooltip = L"Cold One Hunters",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
58000, 41200 - In The Blighted Isle

Click on "Corral" the gate into the Coldone pen.
]],
				},
			},
		},

		{
			name = L"Dangers of Deadwater",
			entries =
			{
				{
					name = L"Dangers of Deadwater",
					mapPins =
					{
						{
							x = 15200,
							y = 31200,
							zoneId = 1,
							tooltip = L"Dangers of Deadwater",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
15200, 31200 - In Marshes of Madness

Click on "Rotting Ratman" on the edge of the green water.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Marsh Fever",
					mapPins =
					{
						{
							x = 15200,
							y = 31200,
							zoneId = 1,
							tooltip = L"Marsh Fever",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
15200, 31200 - In Marshes of Madness - Quest start location

Click on "Rotting Ratman" on the edge of the green water to start the quest "Rotten Luck". 

Then head "Morth's Mire" warcamp and talk to "Odgit Shineymaka" to complete the quest, which gives the unlock.
]],
				},
				
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Marsh Fever",
					mapPins =
					{
						{
							x = 15200,
							y = 31200,
							zoneId = 1,
							tooltip = L"Marsh Fever",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
15200, 31200 - In Marshes of Madness - Quest start location

Click on "Rotting Ratman" on the edge of the green water to start the quest "Rotten Luck". 

Then head "Olfrinson's Outpost" Dwarf Chapter 5 camp and talk to "Hegakin Behrson" to complete the quest, which gives the unlock.
]],
				},
			},
		},

		{
			name = L"Darkhelm Residence",
			entries =
			{
				{
					name = L"Darkhelm Residence",
					mapPins =
					{
						{
							x = 47500,
							y = 15300,
							zoneId = 7,
							tooltip = L"Darkhelm Residence",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
47500, 15300 - In Barak Varr

Click on "Dwarf Post" in Khaz Kor Bar tunnels, in front of a dwarf door.
]],
				},
			},
		},

		{
			name = L"Dead in the Water",
			entries =
			{
				{
					name = L"Dead in the Water",
					mapPins =
					{
						{
							x = 31300,
							y = 26900,
							zoneId = 7,
							tooltip = L"Dead in the Water",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
31300, 26900 - In Barak Varr

Click on "Deteriorating Sea Mine" out in the middle of the water directly north from the back of "Dok Karaz" keep.
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Settin' Things Straight",
					mapPins =
					{
						{
							x = 31100,
							y = 49100,
							zoneId = 7,
							tooltip = L"Settin' Things Straight",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
31100, 49100 - In Barak Varr

Kill "Siege Engineer", a dwarf with a large metal helmet, on the north side of "Thane's Defense" Dwarf Chapter 7 camp.
]],
				},
				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Settin' Things Straight",
					mapPins =
					{
						{
							x = 31100,
							y = 49100,
							zoneId = 7,
							tooltip = L"Settin' Things Straight",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
31100, 49100 - In Barak Varr

Talk to "Siege Engineer", a dwarf with a large metal helmet, on the north side of "Thane's Defense" Dwarf Chapter 7 camp.
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Wot's Dis Den?",
					mapPins =
					{
						{
							x = 29200,
							y = 18600,
							zoneId = 7,
							tooltip = L"Wot's Dis Den?",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
29200, 18600 - In Barak Varr

Talk to "Bloody Sun Metal 'Ead", a goblin with a large metal helmet, on the north east edge of "Mobash's Place" Greenskin Chapter 9 camp.
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Wot's Dis Den?",
					mapPins =
					{
						{
							x = 29200,
							y = 18600,
							zoneId = 7,
							tooltip = L"Wot's Dis Den?",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
29200, 18600 - In Barak Varr

Kill "Bloody Sun Metal 'Ead", a goblin with a large metal helmet, on the north east edge of "Mobash's Place" Greenskin Chapter 9 camp.
]],
				},
			},
		},

		{
			name = L"Everlastink Nob Toppa",
			entries =
			{
				{
					name = L"Everlastink Nob Toppa",
					mapPins =
					{
						{
							x = 17600,
							y = 36500,
							zoneId = 11,
							tooltip = L"Everlastink Nob Toppa",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
17600, 36500 - In Mount Bloodhorn

Click on "Ranklot's Pile" some rusted armour just to the side of two large trash piles towards the back of "Da Gobbo Camp" major landmark.
]],
				},
			},
		},

		{
			name = L"Firebrew",
			entries =
			{
				{
					name = L"Firebrew",
					mapPins =
					{
						{
							x = 53500,
							y = 24700,
							zoneId = 7,
							tooltip = L"Firebrew",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
53500, 24700 - In Barak Varr

Click on "Floating Barrel" in the Barak Varr port, it is in the water next to a grill.
]],
				},
			},
		},

		{
			name = L"Gettin' Slopped",
			entries =
			{
				{
					name = L"Getting' Sloped",
					mapPins =
					{
						{
							x = 15000,
							y = 36900,
							zoneId = 11,
							tooltip = L"Getting' Sloped",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
15000, 36900 - In Mount Bloodhorn

Click on "Slop Bucket" in Ranklot's hut up the ramp on the west side of "Da Gobbo Camp" major landmark. There are 3 buckets all give the unlock.
]],
				},
			},
		},

		{
			name = L"Ghoulish Gourmet",
			entries =
			{
				{
					name = L"Ghoulish Gormet",
					mapPins =
					{
						{
							x = 56500,
							y = 39000,
							zoneId = 107,
							tooltip = L"Ghoulish Gormet",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
56500, 39000 - In Ostland

Talk to "Nathore Gristlechewer" a neutal mob, standing beside and cooking pot, with a dead horse on a rock in front of him.
]],
				},

				{
					name = L"Cadaverous Casseroles",
					mapPins =
					{
						{
							x = 56500,
							y = 39000,
							zoneId = 107,
							tooltip = L"Cadaverous Casseroles",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
56500, 39000 - In Ostland - Quest start location

Click on "Pungent Cooking Pot" next to "Nathore Gristlechewer" and take the quest "Aged Meat". Then head to 40900, 33600 in Norsca, and kill "Seared Ghoul" mobs for "Portion of Ghoul Meat". Return to "Nathore Gristlechewer" in Ostland to complete the quest and get the unlock.
]],
				},

				{
					name = L"Stitchy Fingers",
					mapPins =
					{
						{
							x = 56500,
							y = 39000,
							zoneId = 107,
							tooltip = L"Stitchy Fingers",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
56500, 39000 - In Ostland - Quest start location

Click on "Pungent Cooking Pot" next to "Nathore Gristlechewer" and take the quest "Marbled Meat". Then head to 22000, 20700 in Barak Varr, and click on "Washed-Up Corpse" for "Portion of Dwarf Meat". Return to "Nathore Gristlechewer" in Ostland to complete the quest and get the unlock.
]],
				},

				{
					name = L"Fried Green Waaagh",
					mapPins =
					{
						{
							x = 56500,
							y = 39000,
							zoneId = 107,
							tooltip = L"Fried Green Waaagh",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
56500, 39000 - In Ostland - Quest start location

Click on "Pungent Cooking Pot" next to "Nathore Gristlechewer" and take the quest "Green Meat". Then head to 9000, 54100 in Mount Bloodhorn, and kill "Scartusk Bruisa" mobs for "Orc Skull". Return to "Nathore Gristlechewer" in Ostland to complete the quest and get the unlock.
]],
				},

				{
					name = L"Baked Tzeentch",
					mapPins =
					{
						{
							x = 56500,
							y = 39000,
							zoneId = 107,
							tooltip = L"Baked Tzeentch",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
56500, 39000 - In Ostland - Quest start location

Click on "Pungent Cooking Pot" next to "Nathore Gristlechewer" and take the quest "Curious Meat". Then head to 16700, 27300 in High Pass, and kill "Flameborn" a flamer champion for "Flamer Flesh". Return to "Nathore Gristlechewer" in Ostland to complete the quest and get the unlock.
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Fired Cracklins",
					mapPins =
					{
						{
							x = 56500,
							y = 39000,
							zoneId = 107,
							tooltip = L"Fired Cracklins",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
56500, 39000 - In Ostland - Quest start location

Click on "Pungent Cooking Pot" next to "Nathore Gristlechewer" and take the quest "Crackling Meat".

NOT TESTED AS STILL CORRECT:
Kill 'Bright Wizard Acolyte' in Norsca at 43.6k 12.7k. He is at the first floor of the tower of Major Landmark 'Thorshafn'. Kill him until he drops a 'Chunk of Flesh', then talk to 'Nathore Gristlechewer' in Ostland at 56.8k 39.1k.
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Fired Cracklins",
					mapPins =
					{
						{
							x = 56500,
							y = 39000,
							zoneId = 107,
							tooltip = L"Fired Cracklins",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
56500, 39000 - In Ostland - Quest start location

Click on "Pungent Cooking Pot" next to "Nathore Gristlechewer" and take the quest "Crackling Meat". Then head to 50200, 26000 in Norsca, and click on "Gotland's Pyromancer" a body burnt at the stake in the middle of the town, for "Chunk of Human Flesh". Return to "Nathore Gristlechewer" in Ostland to complete the quest and get the unlock.
]],
				},
			},
		},

		{
			name = L"Grave of the Unknown Acolyte",
			entries =
			{
				{
					name = L"Grave of the Unknown Acolyte",
					mapPins =
					{
						{
							x = 62400,
							y = 45800,
							zoneId = 107,
							tooltip = L"Grave of the Unknown Acolyte",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
62400, 45800 - In Ostland

Click on "Tombstone" in the cemetery around the exit from "The Catacombs" major landmark.
]],
				},
			},
		},
	
		{
			name = L"Iceshard Blade",
			entries =
			{
				{
					name = L"Iceshard Blade",
					mapPins =
					{
						{
							x = 37000,
							y = 600,
							zoneId = 101,
							tooltip = L"Iceshard Blade",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
37000, 600 - In Troll Country

Click on "Iceshard Blade" inside Shiver Hollow. Go in and to the left it is behind some rocky ice spikes.
]],
				},
			},
		},

		{
			name = L"Lairs in Dwarf & Greenskin Lands",
			entries =
			{
				{
					name = L"Lair of Goretusk",
					mapPins =
					{
						{
							x = 26600,
							y = 29300,
							zoneId = 6,
							tooltip = L"Lair of Goretusk",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
26600, 29300 - In Ekrund

Enter inside the Lair of Goretusk. Click on "Bloody Sun Lobber" to throw you over to the ledge.
]],
				},

				{
					name = L"Lair of the Bandit Queen",
					mapPins =
					{
						{
							x = 61400,
							y = 1600,
							zoneId = 6,
							tooltip = L"Lair of the Bandit Queen",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
61400, 1600 - In Ekrund - In RvR Lake

Enter inside the Lair of the Bandit Queen.
]],
				},

				{
					name = L"Lair of the Fleshrender",
					mapPins =
					{
						{
							x = 2900,
							y = 31600,
							zoneId = 9,
							tooltip = L"Lair of the Fleshrender",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
2900, 31600 - In Kadrin Valley - In RvR Lake

Enter inside the Lair of the Fleshrender.
]],
				},

				{
					name = L"Lair of Gutslime",
					mapPins =
					{
						{
							x = 53500,
							y = 45000,
							zoneId = 11,
							tooltip = L"Lair of Gutslime",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
53500, 45000 - In Mount Bloodhorn

Enter inside the Lair of Gutslime.
]],
				},

				{
					name = L"Lair of the Shambler",
					mapPins =
					{
						{
							x = 3600,
							y = 25200,
							zoneId = 8,
							tooltip = L"Lair of the Shambler",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
3600, 25200 - In Black Fire Pass - In RvR Lake

Enter inside the Lair of the Shambler.
]],
				},

				{
					name = L"Lair of Ravack",
					mapPins =
					{
						{
							x = 62100,
							y = 7600,
							zoneId = 8,
							tooltip = L"Lair of Ravack",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
62100, 7600 - In Black Fire Pass

Enter inside the Lair of the Ravack.
]],
				},

				{
					name = L"Lair of the Reaver",
					mapPins =
					{
						{
							x = 1600,
							y = 21500,
							zoneId = 7,
							tooltip = L"Lair of the Reaver",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
1600, 21500 - In Barak Varr

Enter inside the Lair of Reaver.
]],
				},

				{
					name = L"Lair of Old Oozeback",
					mapPins =
					{
						{
							x = 24400,
							y = 60600,
							zoneId = 1,
							tooltip = L"Lair of Old Oozeback",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
24400, 60600 - In Marshes of Madness

Enter inside the Lair of Old Oozeback.
]],
				},

				{
					name = L"Lair of Krela Darkshroud",
					mapPins =
					{
						{
							x = 23300,
							y = 63300,
							zoneId = 2,
							tooltip = L"Lair of Krela Darkshroud",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
23300, 63300 - In Badlands

Enter inside the Lair of Krela Darkshroud.
]],
				},

				{
					name = L"Tomb of the Fallen Slayer",
					mapPins =
					{
						{
							x = 64700,
							y = 53400,
							zoneId = 9,
							tooltip = L"Tomb of the Fallen Slayer",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
64700, 53400 - In Kadrin Valley

Enter the lair. Climb up the small snowy path around 59200, 55000. Large rocks block your path.
]],
				},

				{
					name = L"Malachia's Lair",
					mapPins =
					{
						{
							x = 63000,
							y = 13000,
							zoneId = 3,
							tooltip = L"Malachia's Lair",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
63000, 13000 - In Black Crag

Enter the lair. Climb up the very small rocky path, from the east side of "Venom Lake" PQ.
]],
				},
			},
		},

		{
			name = L"Lairs in Empire & Chaos Lands",
			entries =
			{
				{
					name = L"Migliod's Menagerie",
					mapPins =
					{
						{
							x = 39700,
							y = 54700,
							zoneId = 104,
							tooltip = L"Migliod's Menagerie",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
39700, 54700 - In The Maw - In RvR Lake

Enter inside Migliod's Menagerie.
]],
				},

				{
					name = L"Lair of the Defiler",
					mapPins =
					{
						{
							x = 9600,
							y = 63100,
							zoneId = 107,
							tooltip = L"Lair of the Defiler",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
9600, 63100 - In Ostland

Enter inside the Lair of the Defiler.
]],
				},

				{
					name = L"Frostshard Prison",
					mapPins =
					{
						{
							x = 28200,
							y = 41800,
							zoneId = 120,
							tooltip = L"Frostshard Prison",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
28200, 41800 - In West Pragg

Enter inside Frostshard Prison, accessed by swimming along the river.
]],
				},

				{
					name = L"Lair of Metoh",
					mapPins =
					{
						{
							x = 9300,
							y = 3000,
							zoneId = 101,
							tooltip = L"Lair of Metoh",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
9300, 3000 - In Troll Country

Enter inside the Lair of Metoh.
]],
				},

				{
					name = L"Lair of Morra",
					mapPins =
					{
						{
							x = 31300,
							y = 60700,
							zoneId = 106,
							tooltip = L"Lair of Morra",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
31300, 60700 - Nordland

Enter inside the Lair of Morra.
]],
				},

				{
					name = L"Lair of Silveroak",
					mapPins =
					{
						{
							x = 18200,
							y = 27000,
							zoneId = 100,
							tooltip = L"Lair of Silveroak",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
18200, 27000 - In Norsca

Enter inside the Lair of Silveroak.
]],
				},

				{
					name = L"Lair of Gnawbone",
					mapPins =
					{
						{
							x = 37500,
							y = 5200,
							zoneId = 103,
							tooltip = L"Lair of Gnawbone",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
37500, 5200 - In Chaos Wastes

Enter inside the Lair of Gnawbone.
]],
				},

				{
					name = L"Traitor's Rest",
					mapPins =
					{
						{
							x = 28000,
							y = 62300,
							zoneId = 100,
							tooltip = L"Traitor's Rest",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
28000, 62300 - In Norsca

Enter inside Traitor's Rest.
]],
				},

				{
					name = L"Lair of the Bleakwing Matriarch",
					mapPins =
					{
						{
							x = 45900,
							y = 63900,
							zoneId = 108,
							tooltip = L"Lair of the Bleakwing Matriarch",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
45900, 63900 - In Talabecland

Enter the lair. To get up to it, start breaking "Unattended Griffon Egg"s in the nests, until a "Bleakwing Patriarch" spawns. Start fighting it and put your back to the upper ledge area, at some point the patriarch will punt you upto the ledge.
]],
				},
			},
		},

		{
			name = L"Lairs in High & Dark Elven Lands",
			entries =
			{
				{
					name = L"Lair of Stinkfang the Vomitous",
					mapPins =
					{
						{
							x = 54300,
							y = 42600,
							zoneId = 207,
							tooltip = L"Lair of Stinkfang the Vomitous",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
54300, 42600 - In Ellyrion

Enter inside the Lair of Stinkfang the Vomitous.
]],
				},

				{
					name = L"Lair of Kelbrax",
					mapPins =
					{
						{
							x = 18900,
							y = 62500,
							zoneId = 206,
							tooltip = L"Lair of Kelbrax",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
18900, 62500 - In Chrace

Enter inside the Lair of Kelbrax.
]],
				},

				{
					name = L"Lair of Gorthlak",
					mapPins =
					{
						{
							x = 35200,
							y = 18200,
							zoneId = 200,
							tooltip = L"Lair of Gorthlak",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
35200, 18200 - In The Blighted Isle

Enter inside the Lair of Gorthlak.
]],
				},

				{
					name = L"Lair of Lady Alisha",
					mapPins =
					{
						{
							x = 35200,
							y = 51100,
							zoneId = 200,
							tooltip = L"Lair of Lady Alisha",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
35200, 51100 - In The Blighted Isle - In RvR Lake

Enter inside the Lair of Lady Alisha.
]],
				},

				{
					name = L"Lair of Elrin Helfried",
					mapPins =
					{
						{
							x = 61400,
							y = 48200,
							zoneId = 202,
							tooltip = L"Lair of Elrin Helfried",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
61400, 48200 - Avelorn

Enter inside the Lair of Elrin Helfried.
]],
				},

				{
					name = L"Lair of Gholnaros the Deathless",
					mapPins =
					{
						{
							x = 53500,
							y = 30600,
							zoneId = 205,
							tooltip = L"Lair of Gholnaros the Deathless",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
53500, 30600 - In Dragonwake

Enter inside the Lair of Gholnaros the Deathless. Take the portal at 23400, 44200 in the RvR lake to reach him.
]],
				},

				{
					name = L"Lair of Festitt",
					mapPins =
					{
						{
							x = 34000,
							y = 38000,
							zoneId = 203,
							tooltip = L"Lair of Festitt",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
34000, 38000 - In Caledor - In RvR Lake

Enter inside the Lair of Festitt.
]],
				},

				{
					name = L"Lair of Xaphan of the Pyre",
					mapPins =
					{
						{
							x = 53500,
							y = 27700,
							zoneId = 203,
							tooltip = L"Lair of Xaphan of the Pyre",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
53500, 27700 - In Calador - In RvR Lake

Enter inside the Lair of Xaphan of the Pyre.
]],
				},

				{
					name = L"Lair of Lady Grimgyre",
					mapPins =
					{
						{
							x = 46200,
							y = 62300,
							zoneId = 208,
							tooltip = L"Lair of Lady Grimgyre",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
46200, 62300 - In Saphery

Enter the lair. Kill "Arixxis the Scout" a level 39 champion Imp and loot the item "Grimshimmer's Ley Stone". Use the item from your Quest items, and it will spawn a portal which takes you upto the platform.  Go straight ahead and down the tower into the lair.
]],
				},
			},
		},

		{
			name = L"Litany of Death",
			entries =
			{
				{
					name = L"Song of the Rose",
					mapPins =
					{
						{
							x = 2800,
							y = 20000,
							zoneId = 107,
							tooltip = L"Song of the Rose",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
2800, 20000 - In Ostland

Click on "Song of the Rose" a book inside "Lost Cavern" minor landmark at the very back of the cave.
]],
				},

				{
					name = L"Boneweave Cypher",
					mapPins =
					{
						{
							x = 2800,
							y = 20000,
							zoneId = 107,
							tooltip = L"Boneweave Cypher",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
2800, 20000 - In Ostland - Quest start location

Click on "Song of the Rose" a book inside "Lost Cavern" minor landmark at the very back of the cave. Then complete the quest given called "Song of the Rose", by using the item in your quest items.
]],
				},

				{
					name = L"Markus Gebauer",
					mapPins =
					{
						{
							x = 9200,
							y = 30300,
							zoneId = 107,
							tooltip = L"Markus Gebauer",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
9200, 30300 - In Ostland

Talk to "Markus Gebauer" a cowering man, next to the 4 outhouses, just south of "Ferlangen" Chaos chapter 5.
]],
				},

				{
					name = L"Litany of Death",
					mapPins =
					{
						{
							x = 15100,
							y = 28800,
							zoneId = 107,
							tooltip = L"Litany of Death",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
15100, 28800 - In Ostland

Click on "Mildewy Page", inside "Ferlangen Crypt" major landmark,  in the eastern large chamber, on the ground to the right of the side altar thing.
]],
				},

				{
					name = L"Blackthorn Key",
					mapPins =
					{
						{
							x = 11200,
							y = 23100,
							zoneId = 107,
							tooltip = L"Blackthorn Key",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
11200, 23100 - In Ostland

Click on "Crypt Keys" on the side of the crypt, which will teleport you inside.
]],
				},

				{
					name = L"Blackthorn Crypt",
					mapPins =
					{
						{
							x = 12000,
							y = 24000,
							zoneId = 107,
							tooltip = L"Blackthorn Crypt",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
12000, 24000 - In Ostland

Click on "Memorial Plaque" in the middle of the crypt room.
]],
				},

				{
					name = L"Blackthorn Rite",
					mapPins =
					{
						{
							x = 12700,
							y = 24700,
							zoneId = 107,
							tooltip = L"Blackthorn Rite",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
12700, 24700 - In Ostland

Click on "Apothecary's Vials" on the floor, to the left of the archway, going to the left set of stairs inside the crypt.
]],
				},
				
				{
					name = L"Shadows of Death",
					text =
[[
Complete all 7 of the above unlocks.
]],
				},
			},
		},

		{
			name = L"Marsh Choppa",
			entries =
			{
				{
					name = L"Marsh Choppa",
					mapPins =
					{
						{
							x = 32800,
							y = 5100,
							zoneId = 1,
							tooltip = L"Marsh Choppa",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
32800, 5100 - In Marshes of Madness

Click on "Marsh Axe" at the back of the north east chamber, inside "Marshfang Spider Cave" minor landmark.
]],
				},
			},
		},

		{
			name = L"Missions of Mercy",
			entries =
			{
				{
					name = L"Lady in Distress",
					mapPins =
					{
						{
							x = 19400,
							y = 28500,
							zoneId = 106,
							tooltip = L"Lady in Distress",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
19400, 28500 - In Nordland

Kill "Pub Rat" round the back of the tavern at Grey Lady Coaching Inn, Empire chapter 2 camp.
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Waterbearer",
					mapPins =
					{
						{
							x = 20100,
							y = 26500,
							zoneId = 106,
							tooltip = L"Waterbearer",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
20100, 26500 - In Nordland

Click on "Water Bucket" next to the well in the middle of Grey Lady Coaching Inn, Empire chapter 2 camp.
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Tending the Sick",
					mapPins =
					{
						{
							x = 33100,
							y = 18500,
							zoneId = 106,
							tooltip = L"Tending the Sick",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
33100, 18500 - In Nordland - Quest start location

Click on "Supply Chest" a crate by one of the wagons, accept the quest and head west along the road to the tent outside the camp. Target the "Sick Peasant" NPC in the tent, and use the item "Food" in your quest items.  Talk to "Doctor Heino" an NPC walking around the tent area, to complete the quest and get the unlock.
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Missions of Mercy",
					text =
[[
Complete "Lady in Distress", "Waterbearer" and "Tending the Sick" and this will unlock.
]],
				},
			},
		},

		{
			name = L"Mourkain Treasure",
			entries =
			{
				{
					name = L"Crystal Skull",
					mapPins =
					{
						{
							x = 55600,
							y = 57000,
							zoneId = 1,
							tooltip = L"Crystal Skull",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
55600, 57000 - In Marshes of Madness

Click on "Crystal Skull", it is a very small white skull, between the pillar and the rock.
]],
				},
				
				{
					name = L"Cult of Ushoran",
					mapPins =
					{
						{
							x = 55600,
							y = 57000,
							zoneId = 1,
							tooltip = L"Cult of Ushoran",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
55600, 57000 - In Marshes of Madness - Quest start location

Click on "Crystal Skull" to start the quest "Legend of the Crystal Skull". Then head to "The Tower of Neborhest" major landmark, enter the tower and go down 2 level to the bottom floor and click on the "Mourkain Reliquary" in the centre of the room. Complete the quest for the unlock.
]],
				},
				
				{
					name = L"A Useful Pawn",
					mapPins =
					{
						{
							x = 55600,
							y = 57000,
							zoneId = 1,
							tooltip = L"A Useful Pawn",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
55600, 57000 - In Marshes of Madness - Quest start location

Kill "Raxsus Fleshfeeder" a mob that spawns at the back of the room, when clicking on the "Mourkain Reliquary" in the above unlock.
]],
				},
			},
		},

		{
			name = L"Raiders",
			entries =
			{
				{
					name = L"Northern Raiding Route",
					mapPins =
					{
						{
							x = 9000,
							y = 23100,
							zoneId = 206,
							tooltip = L"Northern Raiding Route",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
9000, 23100 - In Chrace

Approach the back of the cave in the final room of "Emlyria Caverns" minor landmark.
]],
				},
			},
		},

		{
			name = L"Ranks of the Damned",
			entries =
			{
				{
					name = L"Ranks of the Damned, Kalarthay the Mad",
					mapPins =
					{
						{
							x = 14300,
							y = 37100,
							zoneId = 161,
							tooltip = L"Ranks of the Damned, Kalarthay the Mad",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
14300, 37100 - In The Inevitable City

Click on "Ranks of the Damned" a pile of books at the back of the room, at the end of the south wing of the Lyceum.
]],
				},

				{
					name = L"Ranks of the Damned, Ileon Blackwing",
					mapPins =
					{
						{
							x = 47900,
							y = 39900,
							zoneId = 161,
							tooltip = L"Ranks of the Damned, Ileon Blackwing",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
47900, 39900 - In The Inevitable City

Click on "Fount of Souls".
]],
				},

				{
					name = L"Ranks of the Damned, Maesius Blackwing",
					mapPins =
					{
						{
							x = 47300,
							y = 44100,
							zoneId = 161,
							tooltip = L"Ranks of the Damned, Maesius Blackwing",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
47300, 44100 - In The Inevitable City

Click on "Tomes of the Draconis Chaotica" a pile of books at the back of the room.
]],
				},

				{
					name = L"Ranks of the Damned, Darul Kingslayer",
					mapPins =
					{
						{
							x = 41300,
							y = 32500,
							zoneId = 161,
							tooltip = L"Ranks of the Damned, Darul Kingslayer",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
41300, 32500 - In The Inevitable City

Click on "Kingslayer's Blade" stuck into the floating rock.
]],
				},
			},
		},

		{
			name = L"Riphorn Challenge",
			entries =
			{
				{
					name = L"Riphorn Challenge",
					mapPins =
					{
						{
							x = 63800,
							y = 48400,
							zoneId = 101,
							tooltip = L"Riphorn Challenge",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
63800, 48400 - In Troll Country

Click on "Urghu's Foes" a pike with three skulls on it.
]],
				},

				{
					name = L"Blood Rite",
					mapPins =
					{
						{
							x = 63800,
							y = 47800,
							zoneId = 101,
							tooltip = L"Blood Rite",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
63800, 47800 - In Troll Country

Equip "Redhorn's Skull" pocket item dropped by "Urghu Redhorn"
]],
				},
			},
		},

		{
			name = L"Seven Lords and Seven Sons",
			entries =
			{
				{
					name = L"The grave of Ronal Grumman",
					mapPins =
					{
						{
							x = 59900,
							y = 59900,
							zoneId = 107,
							tooltip = L"The grave of Ronal Grumman",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
59900, 59900 - In Ostland

Click on "Grave" on the left as you enter the cemetery in front of "The Catacombs" major landmark.
]],
				},

				{
					name = L"The grave of Bomit Bumbleshoot",
					mapPins =
					{
						{
							x = 1500,
							y = 5800,
							zoneId = 109,
							tooltip = L"The grave of Bomit Bumbleshoot",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
1500, 5800 - In Reikland

Click on "Grave", on top of the crypts, in the North West corner of "Castle Grauenburg" PQ.
]],
				},

				{
					name = L"The grave of Barnabas Hirtzel",
					mapPins =
					{
						{
							x = 27500,
							y = 59100,
							zoneId = 105,
							tooltip = L"The grave of Barnabas Hirtzel",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
27500, 59100 - In Pragg - In PvP Lake

Click on "Grave", in the row of graves next to the path.
]],
				},

				{
					name = L"The grave of Faustus Kummel",
					mapPins =
					{
						{
							x = 61000,
							y = 20000,
							zoneId = 106,
							tooltip = L"The grave of Faustus Kummel",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
61000, 20000 - In Nordland

Click on "Grave" just West of the enterance to "Beeckerhoven Crypt" major landmark.
]],
				},

				{
					name = L"The grave of Xavier Nuhr",
					mapPins =
					{
						{
							x = 24000,
							y = 27000,
							zoneId = 108,
							tooltip = L"The grave of Xavier Nuhr",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
24000, 27000 - In Talabecland

Click on "Grave" towards the north gate of the small graveyard area, slightly hidden behind the tree and brush.
]],
				},

				{
					name = L"The grave of Kazagund Alnirson",
					mapPins =
					{
						{
							x = 12000,
							y = 31000,
							zoneId = 9,
							tooltip = L"The grave of Kazagund Alnirson",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
12000, 31000 - In Kadrin Valley - In RvR Lake

Click on "Grave" behind the house on the north side of "Gromril Junction" BO. 
]],
				},

				{
					name = L"The grave of Mororthel Hawkwood",
					mapPins =
					{
						{
							x = 39500,
							y = 34500,
							zoneId = 200,
							tooltip = L"The grave of Mororthel Hawkwood",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
39500, 34500 - In The Blighted Isle

Click on "Grave" on the east side of the path, behind a tree near the cliff each. 
]],
				},

				{
					name = L"The grave of Hanse Grumman",
					mapPins =
					{
						{
							x = 61700,
							y = 14500,
							zoneId = 103,
							tooltip = L"The grave of Hanse Grumman",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
61700, 14500 - In Chaos Wastes

Click on "Grave" up the hill on a ledge, looking back down to the road.
]],
				},

				{
					name = L"The grave of Bilton Bumbleshoot",
					mapPins =
					{
						{
							x = 18000,
							y = 28000,
							zoneId = 108,
							tooltip = L"The grave of Bilton Bumbleshoot",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
18000, 28000 - In Talabecland

Click on "Grave" just north east of the "Steinbruck Farm" major landmark, on the stepped slope.
]],
				},

				{
					name = L"The grave of Konrad Hirtzel",
					mapPins =
					{
						{
							x = 33300,
							y = 34300,
							zoneId = 162,
							tooltip = L"The grave of Konrad Hirtzel",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
33300, 34300 - In Altdorf

Click on "Grave" on the left side of the enterance to the Bright Wizard College, behind the broken wall section.
]],
				},

				{
					name = L"The grave of Fabian Kummel",
					mapPins =
					{
						{
							x = 47000,
							y = 39100,
							zoneId = 161,
							tooltip = L"The grave of Fabian Kummel",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
47000, 39100 - In Inevitable City

Click on "Grave" on the right as you go through the broken wall passage way.
]],
				},

				{
					name = L"The grave of Nicodemus Nuhr",
					mapPins =
					{
						{
							x = 35500,
							y = 11400,
							zoneId = 109,
							tooltip = L"The grave of Nicodemus Nuhr",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
35500, 11400 - In Reikland - In RvR Lake

Click on "Grave" next to a large tree stump.
]],
				},

				{
					name = L"The grave of Skordin Kazagundson",
					mapPins =
					{
						{
							x = 58000,
							y = 54000,
							zoneId = 2,
							tooltip = L"The grave of Skordin Kazagundson",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
58000, 54000 - In Badlands

Click on "Grave" behind the five cages.
]],
				},

				{
					name = L"The grave of Galdulrel Hawkwood",
					mapPins =
					{
						{
							x = 31000,
							y = 37000,
							zoneId = 205,
							tooltip = L"The grave of Galdulrel Hawkwood",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
31000, 37000 - In Dragonwake - In RvR Lake

Click on "Grave" next to the tree.
]],
				},
			},
		},

		{
			name = L"The Land of the Dead",
			entries =
			{
				{
					name = L"The Stela of Ahara",
					mapPins =
					{
						{
							x = 30600,
							y = 3600,
							zoneId = 191,
							tooltip = L"The Stela of Ahara",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
30600, 3600 - In Necropolis of Zandri

Click on "Stela of Ahara" on the front of the sarcophagus at the end of a tunnel.
]],
				},

				{
					name = L"The Stela of Ahaphet",
					mapPins =
					{
						{
							x = 16500,
							y = 64000,
							zoneId = 191,
							tooltip = L"The Stela of Ahaphet",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
16500, 64000 - In Necropolis of Zandri

Click on "Stela of Ahaphet" up on the top of the sand dune.
]],
				},

				{
					name = L"The Stela of Ahataht",
					mapPins =
					{
						{
							x = 17000,
							y = 35700,
							zoneId = 191,
							tooltip = L"The Stela of Ahataht",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
17000, 35700 - In Necropolis of Zandri

Click on "Stela of Ahataht" at the base of the monolith.
]],
				},

				{
					name = L"The Stela of Ahasebah",
					mapPins =
					{
						{
							x = 15000,
							y = 17900,
							zoneId = 191,
							tooltip = L"The Stela of Ahasebah",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
15000, 17900 - In Necropolis of Zandri

Click on "Stela of Ahasebah" inside the corner section of broken wall.
]],
				},
			},
		},

		{
			name = L"The Mysterious M.B.",
			entries =
			{
				{
					name = L"Precious Flask",
					mapPins =
					{
						{
							x = 39800,
							y = 2000,
							zoneId = 200,
							tooltip = L"Precious Flask",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
39800, 2000 - In The Blighted Isle

Click on "Precious Flask" on the north side of High Elf chapter 1 camp. It is next to a knocked over chair at the side of the tower.
]],
				},

				{
					name = L"Rare Flask",
					mapPins =
					{
						{
							x = 49000,
							y = 27100,
							zoneId = 6,
							tooltip = L"Rare Flask",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
49000, 27100 - Ekrund

Click on "Rare Flask" on top of a crate, on the top of the fortified hill at the bottom of "Durak's Gate" PQ.  Climb up the fallen statue to reach it.
]],
				},

				{
					name = L"Unique Flask",
					mapPins =
					{
						{
							x = 36100,
							y = 18600,
							zoneId = 106,
							tooltip = L"Unique Flask",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
36100, 18600 - Norland

Click on "Unique Flask" on the ground next to a dwarf corpse and a broken barrel cart.
]],
				},

				{
					name = L"The Mystery Continues",
					text =
[[
Earned when you complete the first three achievements in this category.
]],
				},

				{
					name = L"Less than Meets the Eye",
					mapPins =
					{
						{
							x = 56800,
							y = 36200,
							zoneId = 1,
							tooltip = L"Less than Meets the Eye",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
56800, 36200 - In Marshes of Madness

Click on "Dust Covered Flasks" inside "Oathhold Breach" minor landmark, go in turn right, then straight ahead on the left against the pillar.
]],
				},

				{
					name = L"M.B. Shipping Co.",
					mapPins =
					{
						{
							x = 25400,
							y = 22000,
							zoneId = 7,
							tooltip = L"M.B. Shipping Co.",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
25400, 22000 - In Barak Varr

Click on "Sand-Covered Flasks" between the spiky rock just east of "Grudgebearer's Fury" major landmark.
]],
				},

				{
					name = L"The Mysterious M.B.",
					text =
[[
Earned when you complete the above two achievements in this category.
]],
				},
			},
		},

		{
			name = L"Visions",
			entries =
			{
				{
					name = L"Visions of Danger",
					mapPins =
					{
						{
							x = 47700,
							y = 49700,
							zoneId = 206,
							tooltip = L"Visions of Danger",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
47700, 49700 - In Chrace

Approach the centre of the pool just south of "Lyriana's Repose" major landmark.
]],
				},

				{
					name = L"Importance of Life",
					mapPins =
					{
						{
							x = 48300,
							y = 54800,
							zoneId = 206,
							tooltip = L"Importance of Life",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
48300, 54800 - In Chrace

Click on "Slain Chracian" slumped against the broken altar/fountain thing.
]],
				},
			},
		},

		{
			name = L"Wanderers Among the Lost",
			entries =
			{
				{
					name = L"To Feel the Sun",
					mapPins =
					{
						{
							x = 22800,
							y = 50400,
							zoneId = 260,
							tooltip = L"To Feel the Sun",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
22800, 50400 - In The Lost Vale

Click on "Elven Poetry" on the ledge, looking out to sea. To reach it, jump down the cliff ledges from the 2nd boss area.
]],
				},

				{
					name = L"To See The Views",
					mapPins =
					{
						{
							x = 41800,
							y = 40800,
							zoneId = 260,
							tooltip = L"To See The Views",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
41800, 40800 - In The Lost Vale

Click on "Elven Poetry" near the 4 pads to unlock the barrier, on the cliff edge looking down on the route up.
]],
				},

				{
					name = L"To Smell the Flowers",
					mapPins =
					{
						{
							x = 32700,
							y = 24100,
							zoneId = 260,
							tooltip = L"To Smell the Flowers",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
32700, 24100 - In The Lost Vale

Click on "Elven Poetry" on top of the platform, amongst the trees and flowers, to access click on the "Ropecoil" on the west side.
]],
				},

				{
					name = L"To Hear the Waters",
					mapPins =
					{
						{
							x = 36800,
							y = 7600,
							zoneId = 260,
							tooltip = L"To Hear the Waters",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
36800, 7600 - In The Lost Vale

Click on "Elven Poetry" at the base of the tree, overlooking the waterfall.
]],
				},

				{
					name = L"The Wayward Soul",
					text =
[[
Complete all four of the above unlocks.
]],
				},
			},
		},

		{
			name = L"Will of the Assured",
			entries =
			{
				{
					name = L"The Rune of Cython",
					mapPins =
					{
						{
							x = 59000,
							y = 12000,
							zoneId = 200,
							tooltip = L"The Rune of Cython",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
59000, 12000 - In The Blighted Isle

Click on "Rune of Cython" a white runestone near the cliff edge. Head round the back of one of the towers in "House Arkaneth" PQ to reach it.
]],
				},

				{
					name = L"The Asking",
					mapPins =
					{
						{
							x = 59000,
							y = 12000,
							zoneId = 200,
							tooltip = L"The Asking",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
59000, 12000 - In The Blighted Isle

Talk to "Sprite of Cython" one of the NPC Spites that spawns with you click on "Rune of Cython".
]],
				},

				{
					name = L"The Testing",
					mapPins =
					{
						{
							x = 48000,
							y = 39100,
							zoneId = 200,
							tooltip = L"The Testing",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
48000, 39100 - In The Blighted Isle

Click on "Rune of Cython" a white runestone against a rock on a rise north west of "Sternbrow's Lament" major landmark.
]],
				},
			},
		},

		{
			name = L"Wolfenburg",
			entries =
			{
				{
					name = L"Wolfenburg",
					mapPins =
					{
						{
							x = 45300,
							y = 57800,
							zoneId = 107,
							tooltip = L"Wolfenburg",
							icon = "TTitan_Pin_Exploration",
						},
					},
					text =
[[
45300, 57800 - In Ostland

Click on "Wolfenburg Noticeboard" in the middle "Wolfenburg" major landmark.
]],
				},
			},
		},
	},
}