TTitan.Data.HistoryHEvDE = {}

function TTitan.Data.HistoryHEvDE.GetData()
	return TTitan.Data.HistoryHEvDE.RawData
end

function TTitan.Data.HistoryHEvDE.FilterData()
	TTitan.Data.FilterByRealm(TTitan.Data.HistoryHEvDE.RawData)
end

TTitan.Data.HistoryHEvDE.RawData =
{
	header = L"History & Lore Unlocks - High Elves vs Dark Elves",
	categories =
	{
		{
			name = L"The Blighted Isle",
			entries =
			{
				{   -- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"The Shining Guard",
					mapPins =
					{
						{
							x = 43100,
							y = 8800,
							zoneId = 200,
							tooltip = L"The Shining Guard",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
43100, 8800

Talk to "Eliryel Sorrowblade" the career trainer near Prince Eldrion.
]],
				},

				{   -- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"The Shining Guard",
					mapPins =
					{
						{
							x = 20400,
							y = 54500,
							zoneId = 200,
							tooltip = L"The Shining Guard",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
20400, 54500

Kill "Shining Commander" on the beach area to the west of the road up from "Cyanthai Span" warcamp.
]],
				},

				{   -- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Eltharin, Language of the High Elves",
					mapPins =
					{
						{
							x = 39900,
							y = 1800,
							zoneId = 200,
							tooltip = L"Eltharin, Language of the High Elves",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
39900, 1800

Click on "A Dusty Old Tome" a book lying on a piece of wall in Elf chapter 1 camp, just north of the tower.
]],
				},

				{   -- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Eltharin, Language of the High Elves",
					mapPins =
					{
						{
							x = 17400,
							y = 16400,
							zoneId = 200,
							tooltip = L"Eltharin, Language of the High Elves",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
17400, 16400

Click on "A Dusty Old Tome" in the last room of "Halls of Aenarion" major landmark.
]],
				},

				{
					name = L"The Beasts of Karond Kar",
					mapPins =
					{
						{
							x = 14800,
							y = 47800,
							zoneId = 200,
							tooltip = L"The Beasts of Karond Kar",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
14800, 47800

Click on "Manacles of Wrought Iron," in ruins to the north of Dark Elf Chapter 3 camp.
]],
				},

				{
					name = L"Benevolent Protectors",
					mapPins =
					{
						{
							x = 39400,
							y = 36900,
							zoneId = 200,
							tooltip = L"Benevolent Protectors",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
39400, 36900

Talk to "Wounded Swale Mare" at the bottom of the cliff.
]],
				},

				{   -- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Masters of Sword, Bow and Spear",
					mapPins =
					{
						{
							x = 52100,
							y = 8500,
							zoneId = 200,
							tooltip = L"Masters of Sword, Bow and Spear",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
52100, 8500

Click on "Plundered Weapon Rack".
]],
				},

				{   -- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Masters of Sword, Bow and Spear",
					mapPins =
					{
						{
							x = 9300,
							y = 38000,
							zoneId = 200,
							tooltip = L"Masters of Sword, Bow and Spear",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
9300, 38000

Click on "Weapon Rack" in the "Nimosar" PQ.
]],
				},

				{   -- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Ancient History",
					mapPins =
					{
						{
							x = 55700,
							y = 13800,
							zoneId = 200,
							tooltip = L"Ancient History",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
55700, 13800

Click on "Empty Bookshelf".
]],
				},

				{   -- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Ancient History",
					mapPins =
					{
						{
							x = 5300,
							y = 31600,
							zoneId = 200,
							tooltip = L"Ancient History",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
5300, 31600

Click on "Ancient Lore".
]],
				},

				{
					name = L"The War of the Beard",
					mapPins =
					{
						{
							x = 37400,
							y = 37800,
							zoneId = 200,
							tooltip = L"The War of the Beard",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
37400, 37800

Click on "A Personal Letter".
]],
				},

				{   -- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"House Uthorin",
					mapPins =
					{
						{
							x = 54400,
							y = 31600,
							zoneId = 200,
							tooltip = L"House Uthorin",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
54400, 31600

Click on "House Uthorin Ensign".
]],
				},

				{   -- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"House Uthorin",
					mapPins =
					{
						{
							x = 12500,
							y = 32800,
							zoneId = 200,
							tooltip = L"House Uthorin",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
12500, 32800

Click on "House Uthorin Ensign".
]],
				},

				{   -- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"The Witch King",
					mapPins =
					{
						{
							x = 60000,
							y = 40000,
							zoneId = 200,
							tooltip = L"The Witch King",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
60000, 40000

Click on "Dark Elf Gonfalon".
]],
				},

				{   -- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"The Witch King",
					mapPins =
					{
						{
							x = 16800,
							y = 5500,
							zoneId = 200,
							tooltip = L"The Witch King",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
16800, 5500

Click on "Dark Elf Gonfalon".
]],
				},

				{
					name = L"Vile Perversions",
					mapPins =
					{
						{
							x = 33300,
							y = 27600,
							zoneId = 200,
							tooltip = L"Vile Perversions",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
33300, 27600

Click "Defiled Body".
]],
				},

				{
					name = L"Dark Elf Treachery",
					mapPins =
					{
						{
							x = 8500,
							y = 20400,
							zoneId = 200,
							tooltip = L"Dark Elf Treachery",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
8500, 20400

Click on "A Discarded Message".
]],
				},

				{   -- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"The Black Arks of Naggaroth",
					mapPins =
					{
						{
							x = 54500,
							y = 6900,
							zoneId = 200,
							tooltip = L"The Black Arks of Naggaroth",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
54500, 6900

Approach the Black Ark across the bridge.
]],
				},

				{   -- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"The Black Arks of Naggaroth",
					mapPins =
					{
						{
							x = 4600,
							y = 10500,
							zoneId = 200,
							tooltip = L"The Black Arks of Naggaroth",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
4600, 10500

Approach the Black Ark across the bridge.
]],
				},
			},
		},


		{
			name = L"Chrace",
			entries =
			{
				{
					name = L"The Shadow Warriors",
					mapPins =
					{
						{
							x = 3800,
							y = 51200,
							zoneId = 206,
							tooltip = L"The Shadow Warriors",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
3800, 51200

Click on "Tortured Dark Elf" at the end of the gully by the dead trees, there is a nearby camp of shadow warriors.
]],
				},

				{
					name = L"Manbane",
					mapPins =
					{
						{
							x = 31800,
							y = 41800,
							zoneId = 206,
							tooltip = L"Manbane",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
31800, 41800

Click on "Lathranoi Flowers" on the ridgeline just west of "Thanuil's Retreat" major landmark.
]],
				},

				{
					name = L"Thanuil's Retreat",
					mapPins =
					{
						{
							x = 37100,
							y = 41300,
							zoneId = 206,
							tooltip = L"Thanuil's Retreat",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
37100, 41300

Approach the door inside the tower at the top of "Thanuil's Retreat" major landmark.
]],
				},

				{
					name = L"The White Lions of Chrace",
					mapPins =
					{
						{
							x = 7000,
							y = 9200,
							zoneId = 206,
							tooltip = L"The White Lions of Chrace",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
7000, 9200

Talk to a "White Lion Guardian" in "Lionmarch Camp" major landmark.
]],
				},

				{
					name = L"Aenarion",
					mapPins =
					{
						{
							x = 55800,
							y = 19200,
							zoneId = 206,
							tooltip = L"Aenarion",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
55800, 19200

Click on "A Memorial to Aenarion", which is a small block of stone with some elvish script on it, on the cliff overlooking a high elf city below.
]],
				},

				{
					name = L"Khaine",
					mapPins =
					{
						{
							x = 63100,
							y = 42800,
							zoneId = 206,
							tooltip = L"Khaine",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
63100, 42800

Click on "Blade Sacrifice" a body, next to a blood cauldron at "Lyriana's Mansion" major landmark.
]],
				},

				{
					name = L"The Menhir Stones",
					mapPins =
					{
						{
							x = 60500,
							y = 52100,
							zoneId = 206,
							tooltip = L"The Menhir Stones",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
60500, 52100

Click on "Menhir-Infused Crystal" on the east side of the 'Stone of Imrathir' PQ, it is next to one of the outer medium sized stones.
]],
				},

				{
					name = L"The Vortex",
					mapPins =
					{
						{
							x = 8500,
							y = 32800,
							zoneId = 206,
							tooltip = L"The Vortex",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
8500, 32800

Click on "Broken Archmage Staff" at the base of the large menhir stone in the middle of "The Illboughs Stone" major landmark.
]],
				},
			},
		},

		{
			name = L"The Shadowlands",
			entries =
			{
				{
					name = L"Nagarythe",
					mapPins =
					{
						{
							x = 41800,
							y = 30800,
							zoneId = 201,
							tooltip = L"Nagarythe",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
41800, 30800

Click on "Nagarythe Ruin" a wall fragment on the floor next to the broken walls.
]],
				},

				{
					name = L"A People Divided",
					mapPins =
					{
						{
							x = 2700,
							y = 27500,
							zoneId = 201,
							tooltip = L"A People Divided",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
2700, 27500

Click on "Memorial Inscription" behind the large elf statue looking out to sea on the buff.
]],
				},

				{
					name = L"Dark Magic",
					mapPins =
					{
						{
							x = 54000,
							y = 3800,
							zoneId = 201,
							tooltip = L"Dark Magic",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
54000, 3800

Click on "Worn Cage", the empty one amounst the other cages.
]],
				},

				{
					name = L"The Noble Houses of Naggaroth",
					mapPins =
					{
						{
							x = 52500,
							y = 31800,
							zoneId = 201,
							tooltip = L"The Noble Houses of Naggaroth",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
52500, 31800

Click on "Weathered Scroll" on ground between two trees just south east of "Forgotten Future" PQ.
]],
				},

				{
					name = L"Rise to Power",
					mapPins =
					{
						{
							x = 62900,
							y = 40000,
							zoneId = 201,
							tooltip = L"Rise to Power",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
62900, 40000

Click on "Forgotten Tablet" on the east of the path behind some dead branches.
]],
				},

				{
					name = L"Land of Chill",
					mapPins =
					{
						{
							x = 11900,
							y = 45100,
							zoneId = 201,
							tooltip = L"Land of Chill",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
11900, 45100

Click on "General Issue Tent" one of several green tents in the shadow warrior camp.
]],
				},

				{
					name = L"Intrigues of the Dark Elves",
					mapPins =
					{
						{
							x = 25600,
							y = 13400,
							zoneId = 201,
							tooltip = L"Intrigues of the Dark Elves",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
25600, 13400

Click on "Emptied Coffer" on top of the hill.
]],
				},

				{
					name = L"The Shadow Warriors' Vigil",
					mapPins =
					{
						{
							x = 1300,
							y = 14500,
							zoneId = 201,
							tooltip = L"The Shadow Warriors' Vigil",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
1300, 14500

Click on "Recent Campfire" on the ridgeline over looking the sea, south of "Sundered Strand" Dark Elf Chapter 6.
]],
				},

				{
					name = L"The Price of Vengeance",
					mapPins =
					{
						{
							x = 29200,
							y = 14700,
							zoneId = 201,
							tooltip = L"The Price of Vengeance",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
29200, 14700

Click on "Emptied Weapon Rack" on the south side of an Elf tower.
]],
				},

				{
					name = L"The Outer Kingdoms",
					mapPins =
					{
						{
							x = 14600,
							y = 15300,
							zoneId = 201,
							tooltip = L"The Outer Kingdoms",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
14600, 15300

Click on "Outer Kingdoms Map" a scroll in the opening of a small purple dark elf tent.
]],
				},
			},
		},

		{
			name = L"Ellyrion",
			entries =
			{
				{
					name = L"The Steeds of Ellyrion",
					mapPins =
					{
						{
							x = 49100,
							y = 22300,
							zoneId = 207,
							tooltip = L"The Steeds of Ellyrion",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
49100, 22300

Click on "Dead Ellyrion Steed" beside the upright wagon.
]],
				},

				{
					name = L"High Magic",
					mapPins =
					{
						{
							x = 18600,
							y = 19800,
							zoneId = 207,
							tooltip = L"High Magic",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
18600, 19800

Click on "Mage Stone" on the ledge with lions nearby.
]],
				},

				{
					name = L"Ithilmar",
					mapPins =
					{
						{
							x = 39700,
							y = 41900,
							zoneId = 207,
							tooltip = L"Ithilmar",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
39700, 41900

Click on "Damaged Armor" west of "Reaverspring" High Elf Chapter 9, up against the mountain edge.
]],
				},

				{
					name = L"The Silver Helms",
					mapPins =
					{
						{
							x = 26500,
							y = 29600,
							zoneId = 207,
							tooltip = L"The Silver Helms",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
26500, 29600

Click on "Slain Invader" a body on the ground just next to the road.
]],
				},

				{
					name = L"The Seers of Ghrond",
					mapPins =
					{
						{
							x = 61000,
							y = 6500,
							zoneId = 207,
							tooltip = L"The Seers of Ghrond",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
61000, 6500

Kill "Seer of Ghrond" on the top of the cliff, overlooking the camp below.
]],
				},

				{
					name = L"A Dark Trade",
					mapPins =
					{
						{
							x = 51300,
							y = 59200,
							zoneId = 207,
							tooltip = L"A Dark Trade",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
51300, 59200

Click on "Prisoner Shackles" attached to "Ellyrian Reaver" NPC, with two Dark Elf guards next to him.
]],
				},

				{
					name = L"Corsair Raids",
					mapPins =
					{
						{
							x = 64000,
							y = 52000,
							zoneId = 207,
							tooltip = L"Corsair Raids",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
64000, 52000

Click on "Druchii Longboat" on the edge of the beach.
]],
				},

				{
					name = L"Har Ganeth Executioners",
					mapPins =
					{
						{
							x = 32000,
							y = 46100,
							zoneId = 207,
							tooltip = L"Har Ganeth Executioners",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
32000, 461000

Click on "Har Ganeth Halberd" a weapon rack on the right just before the first set of doors from the High Elf side.
]],
				},

				{
					name = L"Balance and Discipline",
					mapPins =
					{
						{
							x = 8800,
							y = 50800,
							zoneId = 207,
							tooltip = L"Balance and Discipline",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
8800, 50800

Click on "Broken High Elf Bust" tucked in the corner up against the High Elf building.
]],
				},

				{
					name = L"The Lessons of the Past",
					mapPins =
					{
						{
							x = 6600,
							y = 45300,
							zoneId = 207,
							tooltip = L"The Lessons of the Past",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
6600, 45300

Click on "Neglected Brazier" by the split in the main road, just north of "Conqueror's Watch" major landmark.
]],
				},
			},
		},

		{
			name = L"Avelorn",
			entries =
			{
				{
					name = L"Twilight of the High Elves",
					mapPins =
					{
						{
							x = 5600,
							y = 63100,
							zoneId = 202,
							tooltip = L"Twilight of the High Elves",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
5600, 63100

Click on "Neglected Altar" inside the "Shrine of Solace" minor landmark.
]],
				},

				{
					name = L"The Temple of Khaine",
					mapPins =
					{
						{
							x = 9200,
							y = 4400,
							zoneId = 202,
							tooltip = L"The Temple of Khaine",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
9200, 4400

Click on "Defiled Tree Trunk" on the ground.
]],
				},

				{
					name = L"Death Night",
					mapPins =
					{
						{
							x = 13100,
							y = 28100,
							zoneId = 202,
							tooltip = L"Death Night",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
13100, 28100

Click on "Denied Reveler" a corpse by a large rock near the bend in the main road.
]],
				},

				{
					name = L"Assassins",
					mapPins =
					{
						{
							x = 37800,
							y = 29300,
							zoneId = 202,
							tooltip = L"Assassins",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
37800, 29300

Click on "A Hung Warning" a corpse hung from a tree near the hill side.
]],
				},

				{
					name = L"The Cauldrons of Blood",
					mapPins =
					{
						{
							x = 27800,
							y = 16000,
							zoneId = 202,
							tooltip = L"The Cauldrons of Blood",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
27800, 16000

Click on "A Weathered Cauldron" near a large tree on the north east side of "Ritual of Corruption" PQ.
]],
				},

				{
					name = L"Bitter Rivals",
					mapPins =
					{
						{
							x = 33100,
							y = 20500,
							zoneId = 202,
							tooltip = L"Bitter Rivals",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
33100, 20500

Click on "A Tortured Rival" a slumped over corpse at the base of a large tree.
]],
				},

				{
					name = L"Witchbrew",
					mapPins =
					{
						{
							x = 13500,
							y = 47400,
							zoneId = 202,
							tooltip = L"Witchbrew",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
13500, 47400

Click on "Assorted Concoctions" three coloured bottles on a crate inside the tent.
]],
				},

				{
					name = L"Isha",
					mapPins =
					{
						{
							x = 15500,
							y = 61600,
							zoneId = 202,
							tooltip = L"Isha",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
15500, 61600

Click on "An Elder Root" near the base of a tree, close to the water.
]],
				},

				{
					name = L"Astarielle, the First Everqueen",
					mapPins =
					{
						{
							x = 4200,
							y = 51700,
							zoneId = 202,
							tooltip = L"Astarielle, the First Everqueen",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
4200, 51700

Click on "A History of Elves" a open book on a low wall corner near the water.
]],
				},

				{
					name = L"Land of Eternal Summer",
					mapPins =
					{
						{
							x = 7600,
							y = 22700,
							zoneId = 202,
							tooltip = L"Land of Eternal Summer",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
7600, 22700

Click on "A Bone-Dry Stein" on top of a crate, out the front of the Empire tent.
]],
				},

				{
					name = L"The Inner Kingdoms",
					mapPins =
					{
						{
							x = 20800,
							y = 1500,
							zoneId = 202,
							tooltip = L"The Inner Kingdoms",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
20800, 1500

Click on "Heart stricken warrior" slightly up the mountains on the north edge of the map.
]],
				},

				{
					name = L"The Maiden Guard",
					mapPins =
					{
						{
							x = 31500,
							y = 8900,
							zoneId = 202,
							tooltip = L"The Maiden Guard",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
31500, 8900

Click on "Maiden's Guard" a sheild on the ground behind the tower on the east side of "Grimwater" High Elf, Chapter 11.
]],
				},

				{
					name = L"Malekith and Morathi",
					mapPins =
					{
						{
							x = 41700,
							y = 23100,
							zoneId = 202,
							tooltip = L"Malekith and Morathi",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
41700, 23100

Click on "A Clear Message" a skull on the table inside the tent.
]],
				},

				{
					name = L"The Evercourt",
					mapPins =
					{
						{
							x = 54900,
							y = 7900,
							zoneId = 202,
							tooltip = L"The Evercourt",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
54900, 7900

Approach the door of the tower in the lake, west for "Grimwater" High Elf Chapter 11.
]],
				},

				{
					name = L"Seafaring Tradition",
					mapPins =
					{
						{
							x = 1500,
							y = 35100,
							zoneId = 202,
							tooltip = L"Seafaring Tradition",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
1500, 35100

Walk on to the middle ship.
]],
				},
			},
		},

		{
			name = L"Saphery",
			entries =
			{
				{
					name = L"The Crimson Shroud",
					mapPins =
					{
						{
							x = 57400,
							y = 16400,
							zoneId = 208,
							tooltip = L"The Crimson Shroud",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
57400, 16400

Click on "Basin of Skulls" near two Dark Elf tents.
]],
				},

				{
					name = L"The Cornerstone",
					mapPins =
					{
						{
							x = 19500,
							y = 51000,
							zoneId = 208,
							tooltip = L"The Cornerstone",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
19500, 51000

Click on "Dedication plaque" on the top edge of the wall, just behind three elf chariots.
]],
				},

				{
					name = L"Conclave of the Winds",
					mapPins =
					{
						{
							x = 10300,
							y = 57000,
							zoneId = 208,
							tooltip = L"Conclave of the Winds",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
10300, 57000

Click on "Broken Mage Staff" on the ground amongst the trees.
]],
				},

				{
					name = L"Dragon Mages",
					mapPins =
					{
						{
							x = 62100,
							y = 32800,
							zoneId = 208,
							tooltip = L"Dragon Mages",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
62100, 32800

Click on "Aqshy Brazier" broken just the the south of the Chaos tent.
]],
				},

				{
					name = L"The Siege of Silverglass Stand",
					mapPins =
					{
						{
							x = 38200,
							y = 42000,
							zoneId = 208,
							tooltip = L"The Siege of Silverglass Stand",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
38200, 42000

Click on "Broken Lobber" outside the orc Stronghold.
]],
				},

				{
					name = L"Untrustworthy Allies",
					mapPins =
					{
						{
							x = 40300,
							y = 30100,
							zoneId = 208,
							tooltip = L"Untrustworthy Allies",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
40300, 30100

Click on "Abandoned Chest" at the bottom of the ridgeline next to a corpse.
]],
				},

				{
					name = L"Noble Privilege",
					mapPins =
					{
						{
							x = 37500,
							y = 17200,
							zoneId = 208,
							tooltip = L"Noble Privilege",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
37500, 17200

Click on "Secluded Tent" on the top of the cliff.
]],
				},

				{
					name = L"The Glade of Reflection",
					mapPins =
					{
						{
							x = 32000,
							y = 19800,
							zoneId = 208,
							tooltip = L"The Glade of Reflection",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
32000, 19800

Click on "Isolated Well.
]],
				},

				{
					name = L"The Skyrage Griffons",
					mapPins =
					{
						{
							x = 37200,
							y = 25300,
							zoneId = 208,
							tooltip = L"The Skyrage Griffons",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
37200, 25300

Click on "Pristine Skyrage Egg" in the nest halfway up the hillside.
]],
				},

				{
					name = L"Dark Pact",
					mapPins =
					{
						{
							x = 49000,
							y = 28000,
							zoneId = 208,
							tooltip = L"Dark Pact",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
49000, 28000

Click on "Raven Banner" near the large fountain.
]],
				},

				{
					name = L"First Among Equals",
					mapPins =
					{
						{
							x = 24000,
							y = 48300,
							zoneId = 208,
							tooltip = L"First Among Equals",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
24000, 48300

Click on "Discarded Banner" right up against a small tree near the edge of the water.
]],
				},

				{
					name = L"Stoic Defenders",
					mapPins =
					{
						{
							x = 27000,
							y = 53200,
							zoneId = 208,
							tooltip = L"Stoic Defenders",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
27000, 53200

Click on "Sorceress's Kettle".
]],
				},

				{
					name = L"Highborn",
					mapPins =
					{
						{
							x = 45300,
							y = 53700,
							zoneId = 208,
							tooltip = L"Highborn",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
45300, 53700

Click on "Intricate Vase" on the ground between the large Dark Elf wagon and the low wall piece.
]],
				},

				{
					name = L"Cold One Knights",
					mapPins =
					{
						{
							x = 49200,
							y = 56500,
							zoneId = 208,
							tooltip = L"Cold One Knights",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
49200, 56500

Approach the tent camps in this area, unlocked while walking down one of the paths.
]],
				},

				{
					name = L"Lethal Poisons",
					mapPins =
					{
						{
							x = 30700,
							y = 63400,
							zoneId = 208,
							tooltip = L"Lethal Poisons",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
30700, 63400

Click on "Dispatched Warrior" down the cliff on a ledge close to the water.
]],
				},
			},
		},

		{
			name = L"The Lost Vale",
			entries =
			{
				{	
					name = L"Aein Yshain",
					mapPins =
					{
						{
							x = 42100,
							y = 38800,
							zoneId = 260,
							tooltip = L"Aein Yshain",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
42100, 38800 - Right Wing

Click on "Aein Yshain", a large golden shimerring tree. on the right side as you enter the area with the 4 stones to stand on.
]],
				},

				{	
					name = L"An Accord with the Beasts",
					mapPins =
					{
						{
							x = 18300,
							y = 41200,
							zoneId = 260,
							tooltip = L"An Accord with the Beasts",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
18300, 41200 - Left Wing

Click on "Hatched Egg", on the waters edge near Ahzranok.
]],
				},

				{	
					name = L"An Accord with Nature",
					mapPins =
					{
						{
							x = 44200,
							y = 45000,
							zoneId = 260,
							tooltip = L"An Accord with Nature",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
44200, 45000 - Right Wing

Click on "Reclaimed Stump", south of the path, behind the giant stone head.
]],
				},

				{	
					name = L"The Banner of Avelorn",
					mapPins =
					{
						{
							x = 35200,
							y = 10000,
							zoneId = 260,
							tooltip = L"The Banner of Avelorn",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
35200, 10000 - Middle Wing

Click on "The Banner of Avelorn", hanging on the wall in the first room, when heading inside to Zaar the Painseeker.
]],
				},

				{	
					name = L"Estrielle the Silver",
					mapPins =
					{
						{
							x = 36300,
							y = 31500,
							zoneId = 260,
							tooltip = L"Estrielle the Silver",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
36300, 31500 - Middle Wing

Click on "Memorial to Estrielle", at the base of a tree NW of the large statue in the first area.
]],
				},

				{	
					name = L"The Oracle of Isha",
					mapPins =
					{
						{
							x = 57100,
							y = 11500,
							zoneId = 260,
							tooltip = L"The Oracle of Isha",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
57100, 11500 - Middle Wing

Click on "Oracle's Pedestal", at the back of the room straight ahead as you enter Alarielle's palace.
]],
				},

				{	
					name = L"The Province of the Female",
					mapPins =
					{
						{
							x = 33600,
							y = 48000,
							zoneId = 260,
							tooltip = L"The Province of the Female",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
33600, 48000

Click on "Male Invader", one of the corpses on the starting beach.
]],
				},

				{	
					name = L"The Tears of Isha",
					mapPins =
					{
						{
							x = 55900,
							y = 5200,
							zoneId = 260,
							tooltip = L"The Tears of Isha",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
55900, 5200 - Middle Wing

Click on "Tear of Isha", a small crystal up the stairs on the left side of N'Kari chamber.
]],
				},

				{	
					name = L"The Whitefire Spiders",
					mapPins =
					{
						{
							x = 19000,
							y = 24700,
							zoneId = 260,
							tooltip = L"The Whitefire Spiders",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
19000, 24700 - Left Wing

Click on "Cocooned Druchii", on the left side of the tunnel as you head into Dralel the Whitefire Matron.
]],
				},

				{	
					name = L"Battle of the Gaean Vale",
					mapPins =
					{
						{
							x = 45800,
							y = 23200,
							zoneId = 260,
							tooltip = L"Battle of the Gaean Vale",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
45800, 23200 - Right Wing

Click on "Ode to Yvraine", a tablet up the stairs/ram on the left as you enter the area for Sarthain the Worldbearer.
]],
				},
			},
		},

		{
			name = L"Eataine",
			entries =
			{
				{
					name = L"Asuryan",
					mapPins =
					{
						{
							x = 21300,
							y = 62200,
							zoneId = 209,
							tooltip = L"Asuryan",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
21300, 62200

Click on "Shrine of Asuryan".
]],
				},

				{
					name = L"The Lothern Seaguard",
					mapPins =
					{
						{
							x = 62300,
							y = 6500,
							zoneId = 209,
							tooltip = L"The Lothern Seaguard",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
62300, 6500

Click on "Seaguard Banner" on the lower level of the dock. 
]],
				},

				{
					name = L"High Elf Colonies",
					mapPins =
					{
						{
							x = 400,
							y = 11000,
							zoneId = 209,
							tooltip = L"High Elf Colonies",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
400, 11000

Click on "Small Campfire Remains".
]],
				},

				{
					name = L"Eagle Claw Bolt Throwers",
					mapPins =
					{
						{
							x = 13500,
							y = 53300,
							zoneId = 209,
							tooltip = L"Eagle Claw Bolt Throwers",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
13500, 53300

Click on "The Eagle's Claw" one of two bolt throwers defending the tower.
]],
				},

				{
					name = L"The Straits of Lothern",
					mapPins =
					{
						{
							x = 53900,
							y = 21700,
							zoneId = 209,
							tooltip = L"The Straits of Lothern",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
53900, 21700

Click on "Cornerstone Plague", on the ground round the back of the tower.
]],
				},

				{
					name = L"The Third Gate",
					mapPins =
					{
						{
							x = 63700,
							y = 46600,
							zoneId = 209,
							tooltip = L"The Third Gate",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
63700, 46600

Click on "A Stored Dinghy" underneath the docks. 
]],
				},

				{
					name = L"Lileath",
					mapPins =
					{
						{
							x = 39900,
							y = 15100,
							zoneId = 209,
							tooltip = L"Lileath",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
39900, 15100

Click on "Gem Adorned Tome", behind one of two tents in the trees.
]],
				},

				{
					name = L"Orcification",
					mapPins =
					{
						{
							x = 6300,
							y = 5300,
							zoneId = 209,
							tooltip = L"Orcification",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
6300, 5300

Click on "Orc Landing Banner", infront of the orc barge.
]],
				},

				{
					name = L"The Underworld Sea",
					mapPins =
					{
						{
							x = 1200,
							y = 8800,
							zoneId = 209,
							tooltip = L"The Underworld Sea",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
1200, 8800

Click on "Locked Chest", washed up on the beach.
]],
				},

				{
					name = L"Repeater Crossbow",
					mapPins =
					{
						{
							x = 26000,
							y = 49600,
							zoneId = 209,
							tooltip = L"Repeater Crossbow",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
26000, 49600

Click on "Roadside Memorial".
]],
				},

				{
					name = L"Tiranoc Chariot",
					mapPins =
					{
						{
							x = 33100,
							y = 51700,
							zoneId = 209,
							tooltip = L"Tiranoc Chariot",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
33100, 51700

Click on "Elven Chariot".
]],
				},

				{
					name = L"Cold One Chariot",
					mapPins =
					{
						{
							x = 15800,
							y = 23700,
							zoneId = 209,
							tooltip = L"Cold One Chariot",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
15800, 23700

Walk near the Dark Elf charoit in the middle of the camp.
]],
				},

				{
					name = L"A Dark Day (Enemies in the Inner Sea)",
					mapPins =
					{
						{
							x = 31200,
							y = 2900,
							zoneId = 209,
							tooltip = L"A Dark Day (Enemies in the Inner Sea)",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
31200, 2900

Walk onto the Orc barge.
]],
				},

				{
					name = L"Stronger Bonds",
					mapPins =
					{
						{
							x = 29200,
							y = 15900,
							zoneId = 209,
							tooltip = L"Stronger Bonds",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
29200, 15900

Click on "Empty Jug" on the ground.
]],
				},

				{
					name = L"Cold One Knights",
					mapPins =
					{
						{
							x = 46900,
							y = 12600,
							zoneId = 209,
							tooltip = L"Cold One Knights",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
46900, 12600

Click on "Gnawed Bones", at the end of one of the outer wall sections.
]],
				},
			},
		},

		{
			name = L"Dragonwake",
			entries =
			{
				{
					name = L"Vaul",
					mapPins =
					{
						{
							x = 35800,
							y = 52000,
							zoneId = 205,
							tooltip = L"Vaul",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
35800, 52000

Click on "Caladain Anvil" up against the house with the golden roof.
]],
				},

				{
					name = L"The Blind Smiths",
					mapPins =
					{
						{
							x = 22400,
							y = 47600,
							zoneId = 205,
							tooltip = L"The Blind Smiths",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
22400, 47600

Click on "The Lay of the Blind Smiths", a book on the ground towards the cliff edge.
]],
				},

				{
					name = L"The Dragon Spine Mountains",
					mapPins =
					{
						{
							x = 19500,
							y = 63500,
							zoneId = 205,
							tooltip = L"The Dragon Spine Mountains",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
19500, 63500

Click on "Dragon Spine Scepter", high up the mountain side. 
]],
				},

				{
					name = L"The Taming of Bracchus",
					mapPins =
					{
						{
							x = 10200,
							y = 21400,
							zoneId = 205,
							tooltip = L"The Taming of Bracchus",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
10200, 21400

Click on "A Beastmaster's Tome" that sits on a small table by a campfire and three dark elf tents.
]],
				},

				{
					name = L"Beastmasters of Karond Kar",
					mapPins =
					{
						{
							x = 23300,
							y = 53600,
							zoneId = 205,
							tooltip = L"Beastmasters of Karond Kar",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
23300, 53600

Click on "Corral", the gate to open the beast pen.
]],
				},

				{
					name = L"The Sacred Flame",
					mapPins =
					{
						{
							x = 31700,
							y = 2400,
							zoneId = 205,
							tooltip = L"The Sacred Flame",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
31700, 2400

Click on "Elven Tent", in the small camp on the cliff edge.
]],
				},

				{
					name = L"The Phoenix Guard",
					mapPins =
					{
						{
							x = 12800,
							y = 30900,
							zoneId = 205,
							tooltip = L"The Phoenix Guard",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
12800, 30900

Click on "A Simple Headstone". 
]],
				},

				{
					name = L"The Pilgrimage",
					mapPins =
					{
						{
							x = 61600,
							y = 11700,
							zoneId = 205,
							tooltip = L"The Pilgrimage",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
61600, 11700

Click on "An Aged Wayshrine", just off the path.
]],
				},

				{
					name = L"The Black Heart Coven",
					mapPins =
					{
						{
							x = 38200,
							y = 39900,
							zoneId = 205,
							tooltip = L"The Black Heart Coven",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
38200, 39900 - In RvR Lake

Click on "Pile of Skulls", part way down the cliff side. 
]],
				},

				{
					name = L"The Dragonwake Sentinels",
					mapPins =
					{
						{
							x = 55200,
							y = 8300,
							zoneId = 205,
							tooltip = L"The Dragonwake Sentinels",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
55200, 8300

Click on "Tactical Map", next to a small dark elf tent on top of the cliff.
]],
				},

				{
					name = L"A Vessel of Khaine",
					mapPins =
					{
						{
							x = 55200,
							y = 58600,
							zoneId = 205,
							tooltip = L"A Vessel of Khaine",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
55200, 58600

Click on "Worn Sack", down near the bottom of the waterfall. 
]],
				},

				{
					name = L"Monument to the Ancient Fallen",
					mapPins =
					{
						{
							x = 20300,
							y = 53400,
							zoneId = 220,
							tooltip = L"Monument to the Ancient Fallen",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
20300, 53400 - In Isle of the Dead

Click on "Monument to the Ancient Fallen" at top of the peninsula. 
]],
				},

				{
					name = L"Downward Spiral",
					mapPins =
					{
						{
							x = 38700,
							y = 5300,
							zoneId = 220,
							tooltip = L"Downward Spiral",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
38700, 5300 - In Isle of the Dead

Kill "Insane Sorcerer" by the sea at the bottom of the cliff.
]],
				},

				{
					name = L"Timeless",
					mapPins =
					{
						{
							x = 42600,
							y = 30400,
							zoneId = 220,
							tooltip = L"Timeless",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
42600, 30400 - In Isle of the Dead

Talk to "Sarilion Avethan".
]],
				},

				{
					name = L"Aenarion and the Daemons",
					mapPins =
					{
						{
							x = 41300,
							y = 35900,
							zoneId = 220,
							tooltip = L"Aenarion and the Daemons",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
41300, 35900 - In Isle of the Dead

Approach the statue, just near the path to the vortex.
]],
				},
			},
		},

		{
			name = L"Caledor",
			entries =
			{
				{
					name = L"Beastmasters of Karond Kar",
					mapPins =
					{
						{
							x = 52600,
							y = 4400,
							zoneId = 203,
							tooltip = L"Beastmasters of Karond Kar",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
52600, 4400

Click on "Empty Goblet" on top of a rock.
]],
				},

				{
					name = L"Caledor Dragontamer",
					mapPins =
					{
						{
							x = 1100,
							y = 19100,
							zoneId = 203,
							tooltip = L"Caledor Dragontamer",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
1100, 19100

Click on "Dragontamer Monument" in the forest.
]],
				},

				{
					name = L"The Dragon Princes",
					mapPins =
					{
						{
							x = 64500,
							y = 39800,
							zoneId = 203,
							tooltip = L"The Dragon Princes",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
64500, 39800

Click on "Dragon Prince Horse" just east of the path. Their are two of them side by side, and either one works.
]],
				},

				{
					name = L"Truesteel",
					mapPins =
					{
						{
							x = 45500,
							y = 43300,
							zoneId = 203,
							tooltip = L"Truesteel ",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
45500, 43300

Click on "Crate of Truesteel".
]],
				},

				{
					name = L"A Memory of Fire",
					mapPins =
					{
						{
							x = 29900,
							y = 53000,
							zoneId = 203,
							tooltip = L"A Memory of Fire",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
29900, 53000

Click on "Volcanic Rock" in the middle of the river.
]],
				},

				{
					name = L"Reaper Bolt Thrower",
					mapPins =
					{
						{
							x = 64300,
							y = 13000,
							zoneId = 203,
							tooltip = L"Reaper Bolt Thrower",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
64300, 13000

Click on "Reaper Bolt Thrower" next to the path, just west of Dark Elf Chapter 17.
]],
				},

				{
					name = L"Lost Legacy",
					mapPins =
					{
						{
							x = 46700,
							y = 16500,
							zoneId = 203,
							tooltip = L"Lost Legacy",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
46700, 16500

Walk under the small stone arch just west of the road, unlock triggered walking up the small steps and through the archway.
]],
				},

				{
					name = L"A First Time for Everything",
					mapPins =
					{
						{
							x = 26900,
							y = 2800,
							zoneId = 203,
							tooltip = L"A First Time for Everything",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
26900, 2800

Board the Dwarf ship at Kelysian's Landing.
]],
				},

				{
					name = L"Caledor the Conqueror",
					mapPins =
					{
						{
							x = 41600,
							y = 40600,
							zoneId = 203,
							tooltip = L"Caledor the Conqueror",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
41600, 40600

Click on "Phoenix King Caledor I", a bust on the left side as you approach the tower behind the rubble pile.
]],
				},

				{
					name = L"The Price of Disloyalty",
					mapPins =
					{
						{
							x = 10800,
							y = 11300,
							zoneId = 203,
							tooltip = L"The Price of Disloyalty",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
10800, 11300

Click on "Cage" at the side of the road.
]],
				},

				{
					name = L"Prideful Arrogance",
					mapPins =
					{
						{
							x = 16800,
							y = 2500,
							zoneId = 203,
							tooltip = L"Prideful Arrogance",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
16800, 2500

Walk into the Elven gazebo, with the fancy chairs and harp.
]],
				},

				{
					name = L"The Drakefall Defenders",
					mapPins =
					{
						{
							x = 43600,
							y = 49000,
							zoneId = 203,
							tooltip = L"The Drakefall Defenders",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
43600, 49000

Click on "Sun Bleached Bone" near a giant ribcage close to the road.
]],
				},

				{
					name = L"Tethlis the Slayer",
					mapPins =
					{
						{
							x = 9000,
							y = 2500,
							zoneId = 203,
							tooltip = L"Tethlis the Slayer",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
9000, 2500

Click on "Chronicle of the Phoenix Kings" on some small stairs round the back of the tower.
]],
				},

				{
					name = L"The Trail of Darian Stormspear",
					mapPins =
					{
						{
							x = 64200,
							y = 57600,
							zoneId = 203,
							tooltip = L"The Trail of Darian Stormspear",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
64200, 57600

Click on "Notably Worn Bedroll" on top of the ledge, on the east side of the canyon. The bedroll is behind a tree at the south end of the ledge.
]],
				},

				{
					name = L"Fickle Favor",
					mapPins =
					{
						{
							x = 4400,
							y = 33800,
							zoneId = 203,
							tooltip = L"Fickle Favor",
							icon = "TTitan_Pin_History",
						},
					},
					text =
[[
4400, 38700 - In RvR Lake

Approach the alter inside "Hatred's Way" keep, you have to stand on the stone plinth to trigger the unlock. 
]],
				},
			},
		},
	},
}
