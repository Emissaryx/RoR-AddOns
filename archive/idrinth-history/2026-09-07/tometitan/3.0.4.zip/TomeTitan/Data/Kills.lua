TTitan.Data.Kills = {}

local function Kills_ToString(value)
    if value == nil then return "" end
    if type(value) == "wstring" and WStringToString then
        local ok, out = pcall(WStringToString, value)
        if ok and out then return out end
    end
    return tostring(value)
end

local function Kills_Clean(value)
    if TTitan.Data.CleanString then
        return TTitan.Data.CleanString(value)
    end

    return string.lower(Kills_ToString(value))
end

local function Kills_CleanNoCommas(value)
    return string.gsub(Kills_Clean(value), ",", "")
end

local function Kills_CleanCompact(value)
    return string.gsub(Kills_Clean(value), "[^%w]", "")
end

local function Kills_GetCompletedTasks()
    local completed = {}

    if not TomeGetBestiaryTOC or not TomeGetBestiarySubTypeData or not TomeGetBestiarySpeciesData then
        return completed
    end

    for _, typeData in ipairs(TomeGetBestiaryTOC() or {}) do
        for _, subtypeData in ipairs(typeData.subtypes or {}) do
            local subtype = TomeGetBestiarySubTypeData(subtypeData.id)
            for _, speciesData in ipairs((subtype and subtype.species) or {}) do
                local species = TomeGetBestiarySpeciesData(speciesData.id)
                for _, taskData in ipairs((species and species.tasks) or {}) do
                    if taskData.isComplete then
                        local taskName = Kills_ToString(taskData.text)
                        if taskName ~= "" then
                            completed[Kills_Clean(taskName)] = true
                            completed[Kills_CleanNoCommas(taskName)] = true
                            completed[Kills_CleanCompact(taskName)] = true
                        end
                    end
                end
            end
        end
    end

    return completed
end

local function Kills_SyncEntries(entries, completedTasks)
    local completed = true

    for _, entry in ipairs(entries or {}) do
        if entry.entries then
            entry.completed = Kills_SyncEntries(entry.entries, completedTasks)
        else
            local key = Kills_Clean(entry.name)
            local keyNoCommas = string.gsub(key, ",", "")
            local keyCompact = string.gsub(key, "[^%w]", "")
            entry.completed = completedTasks[key] == true
                or completedTasks[keyNoCommas] == true
                or completedTasks[keyCompact] == true
        end

        completed = completed and entry.completed
    end

    return completed
end

local function Kills_MoveCategoryBefore(categories, movingName, beforeName)
    local movingIndex = nil
    local beforeIndex = nil

    for index, category in ipairs(categories or {}) do
        local name = Kills_ToString(category.name)
        if name == movingName then movingIndex = index end
        if name == beforeName then beforeIndex = index end
    end

    if not movingIndex or not beforeIndex or movingIndex == beforeIndex - 1 then
        return
    end

    local category = table.remove(categories, movingIndex)
    if movingIndex < beforeIndex then
        beforeIndex = beforeIndex - 1
    end

    table.insert(categories, beforeIndex, category)
end

local function Kills_SingularizeTarget(target)
    if not target or target == "" then return nil end

    local base, suffix = string.match(target, "^(.-)(%s+of%s+.+)$")
    if base then
        local singularBase = Kills_SingularizeTarget(base)
        if singularBase and singularBase ~= "" then
            return singularBase .. suffix
        end
    end

    local irregular =
    {
        ["Rhinoxen"] = "Rhinox",
        ["Wolves"] = "Wolf",
        ["Dryads"] = "Dryad",
        ["Harpies"] = "Harpy",
        ["Zombies"] = "Zombie",
    }

    if irregular[target] then return irregular[target] end

    if string.match(target, "ies$") then
        return string.gsub(target, "ies$", "y")
    end

    if string.match(target, "xes$") then
        return string.gsub(target, "es$", "")
    end

    if string.match(target, "ches$") or string.match(target, "shes$") then
        return string.gsub(target, "es$", "")
    end

    if string.match(target, "s$") and not string.match(target, "ss$") then
        return string.gsub(target, "s$", "")
    end

    return target
end

local function Kills_GetEncounterTarget(groupName, firstTaskName)
    local group = Kills_ToString(groupName)
    local first = Kills_ToString(firstTaskName)

    if string.find(group, ",", 1, true) then
        local pluralTarget = string.match(first, "^Kill%s+[%d,]+%s+(.+)$")
        return Kills_SingularizeTarget(pluralTarget)
    end

    if group and group ~= "" then
        return group
    end

    return Kills_SingularizeTarget(string.match(first, "^Kill%s+[%d,]+%s+(.+)$"))
end

local function Kills_GetArticle(target)
    local firstLetter = string.sub(target or "", 1, 1)
    if string.find("AEIOUaeiou", firstLetter, 1, true) then
        return "an"
    end

    return "a"
end

local function Kills_GetEncounterTaskName(groupName, firstTaskName)
    local target = Kills_GetEncounterTarget(groupName, firstTaskName)

    if target and target ~= "" then
        return "Encounter " .. Kills_GetArticle(target) .. " " .. target
    end

    return nil
end

local function Kills_AddOneKillTasks(entries)
    for _, entry in ipairs(entries or {}) do
        if entry.entries then
            local children = entry.entries
            local first = children[1]

            if first and not first.entries then
                local firstName = Kills_ToString(first.name)

                if not first.generatedOneKillTask
                    and not string.match(firstName, "^Encounter%s+")
                    and not string.match(firstName, "^Kill%s+%D")
                then
                    local taskName = Kills_GetEncounterTaskName(entry.name, first.name)

                    if taskName then
                        table.insert(children, 1, {
                            id = 100000 + (tonumber(first.id) or 0),
                            name = towstring(taskName),
                            text = "XP\n\n" .. taskName,
                            generatedOneKillTask = true,
                        })
                    end
                end
            else
                Kills_AddOneKillTasks(children)
            end
        end
    end
end

local function Kills_NormalizeData()
    local categories = TTitan.Data.Kills.RawData.categories
    Kills_MoveCategoryBefore(categories, "Legendary Monsters", "Monsters")
    Kills_AddOneKillTasks(categories)
end

function TTitan.Data.Kills.GetData()
    TTitan.Data.Kills.FilterData()
    return TTitan.Data.Kills.RawData
end

function TTitan.Data.Kills.FilterData()
    Kills_NormalizeData()

    local completedTasks = Kills_GetCompletedTasks()

    for _, category in ipairs(TTitan.Data.Kills.RawData.categories or {}) do
        category.completed = Kills_SyncEntries(category.entries, completedTasks)
    end
end

local function Kills_LegendaryTask(id, name, reward)
    return {
        id = id,
        name = towstring(name),
        text = reward .. "\n\n" .. name,
    }
end

TTitan.Data.Kills.RawData =
{
    header = L"Bestiary Kill Progress",
    categories =
    {
        {
            name = L"Animals",
            entries =
            {
                {
                    name = L"Beasts",
                    entries =
                    {
                        {
                            name = L"Basilisk",
                            entries =
                            {
                                {
                                    id = 1,
                                    name = L"Kill 25 Basilisks",
                                    text =
[[
XP: 204

Kill 25 Basilisks
]],
                                },

                                {
                                    id = 2,
                                    name = L"Kill 100 Basilisks",
                                    text =
[[
XP: 500

Kill 100 Basilisks
]],
                                },

                                {
                                    id = 3,
                                    name = L"Kill 1,000 Basilisks",
                                    text =
[[
BESTIAL TOKEN

Kill 1,000 Basilisks
]],
                                },

                                {
                                    id = 4,
                                    name = L"Kill 10,000 Basilisks",
                                    text =
[[
"The Unyielding"

Kill 10,000 Basilisks
]],
                                },

                                {
                                    id = 5,
                                    name = L"Kill 100,000 Basilisks",
                                    text =
[[
"Deathgazer"

Kill 100,000 Basilisks
]],
                                },

                            },
                        },

                        {
                            name = L"Bat, Giant",
                            entries =
                            {
                                {
                                    id = 6,
                                    name = L"Kill 25 Giant Bats",
                                    text =
[[
XP: 204

Kill 25 Giant Bats
]],
                                },

                                {
                                    id = 7,
                                    name = L"Kill 100 Giant Bats",
                                    text =
[[
XP: 500

Kill 100 Giant Bats
]],
                                },

                                {
                                    id = 8,
                                    name = L"Kill 1,000 Giant Bats",
                                    text =
[[
BESTIAL TOKEN

Kill 1,000 Giant Bats
]],
                                },

                                {
                                    id = 9,
                                    name = L"Kill 10,000 Giant Bats",
                                    text =
[[
"Nightwing"

Kill 10,000 Giant Bats
]],
                                },

                                {
                                    id = 10,
                                    name = L"Kill 100,000 Giant Bats",
                                    text =
[[
"Bat Mangler"

Kill 100,000 Giant Bats
]],
                                },

                            },
                        },

                        {
                            name = L"Bear",
                            entries =
                            {
                                {
                                    id = 11,
                                    name = L"Kill 25 Bears",
                                    text =
[[
XP: 204

Kill 25 Bears
]],
                                },

                                {
                                    id = 12,
                                    name = L"Kill 100 Bears",
                                    text =
[[
XP: 500

Kill 100 Bears
]],
                                },

                                {
                                    id = 13,
                                    name = L"Kill 1,000 Bears",
                                    text =
[[
BESTIAL TOKEN

Kill 1,000 Bears
]],
                                },

                                {
                                    id = 14,
                                    name = L"Kill 10,000 Bears",
                                    text =
[[
"The Grizzled"

Kill 10,000 Bears
]],
                                },

                                {
                                    id = 15,
                                    name = L"Kill 100,000 Bears",
                                    text =
[[
"Ursine Champion"

Kill 100,000 Bears
]],
                                },

                            },
                        },

                        {
                            name = L"Boar",
                            entries =
                            {
                                {
                                    id = 16,
                                    name = L"Kill 25 Boars",
                                    text =
[[
XP: 204

Kill 25 Boars
]],
                                },

                                {
                                    id = 17,
                                    name = L"Kill 100 Boars",
                                    text =
[[
XP: 500

Kill 100 Boars
]],
                                },

                                {
                                    id = 18,
                                    name = L"Kill 1,000 Boars",
                                    text =
[[
BESTIAL TOKEN

Kill 1,000 Boars
]],
                                },

                                {
                                    id = 19,
                                    name = L"Kill 10,000 Boars",
                                    text =
[[
"Scout"

Kill 10,000 Boars
]],
                                },

                                {
                                    id = 20,
                                    name = L"Kill 100,000 Boars",
                                    text =
[[
"Predator"

Kill 100,000 Boars
]],
                                },

                            },
                        },

                        {
                            name = L"Great Cat",
                            entries =
                            {
                                {
                                    id = 21,
                                    name = L"Kill 25 Great Cats",
                                    text =
[[
XP: 204

Kill 25 Great Cats
]],
                                },

                                {
                                    id = 22,
                                    name = L"Kill 100 Great Cats",
                                    text =
[[
XP: 500

Kill 100 Great Cats
]],
                                },

                                {
                                    id = 23,
                                    name = L"Kill 1,000 Great Cats",
                                    text =
[[
BESTIAL TOKEN

Kill 1,000 Great Cats
]],
                                },

                                {
                                    id = 24,
                                    name = L"Kill 10,000 Great Cats",
                                    text =
[[
"The Stealthy"

Kill 10,000 Great Cats
]],
                                },

                                {
                                    id = 25,
                                    name = L"Kill 100,000 Great Cats",
                                    text =
[[
"The Ferocious"

Kill 100,000 Great Cats
]],
                                },

                            },
                        },

                        {
                            name = L"Hound",
                            entries =
                            {
                                {
                                    id = 26,
                                    name = L"Kill 25 Hounds",
                                    text =
[[
XP: 204

Kill 25 Hounds
]],
                                },

                                {
                                    id = 27,
                                    name = L"Kill 100 Hounds",
                                    text =
[[
XP: 500

Kill 100 Hounds
]],
                                },

                                {
                                    id = 28,
                                    name = L"Kill 1,000 Hounds",
                                    text =
[[
BESTIAL TOKEN

Kill 1,000 Hounds
]],
                                },

                                {
                                    id = 29,
                                    name = L"Kill 10,000 Hounds",
                                    text =
[[
"Foe of the Warhound"

Kill 10,000 Hounds
]],
                                },

                                {
                                    id = 30,
                                    name = L"Kill 100,000 Hounds",
                                    text =
[[
"The Packleader"

Kill 100,000 Hounds
]],
                                },

                            },
                        },

                        {
                            name = L"Rhinox",
                            entries =
                            {
                                {
                                    id = 31,
                                    name = L"Kill 25 Rhinoxen",
                                    text =
[[
XP: 336

Kill 25 Rhinoxen
]],
                                },

                                {
                                    id = 32,
                                    name = L"Kill 100 Rhinoxen",
                                    text =
[[
XP: 500

Kill 100 Rhinoxen
]],
                                },

                                {
                                    id = 33,
                                    name = L"Kill 1,000 Rhinoxen",
                                    text =
[[
BEASTIAL TACTIC FRAGMENT

Kill 1,000 Rhinoxen
]],
                                },

                                {
                                    id = 34,
                                    name = L"Kill 10,000 Rhinoxen",
                                    text =
[[
"Master Rhinox Slayer"

Kill 10,000 Rhinoxen
]],
                                },

                            },
                        },

                        {
                            name = L"Wolf",
                            entries =
                            {
                                {
                                    id = 35,
                                    name = L"Kill 25 Wolves",
                                    text =
[[
XP: 204

Kill 25 Wolves
]],
                                },

                                {
                                    id = 36,
                                    name = L"Kill 100 Wolves",
                                    text =
[[
XP: 500

Kill 100 Wolves
]],
                                },

                                {
                                    id = 37,
                                    name = L"Kill 1,000 Wolves",
                                    text =
[[
BESTIAL TOKEN

Kill 1,000 Wolves
]],
                                },

                                {
                                    id = 38,
                                    name = L"Kill 10,000 Wolves",
                                    text =
[[
"The Wolf Tracker"

Kill 10,000 Wolves
]],
                                },

                                {
                                    id = 39,
                                    name = L"Kill 100,000 Wolves",
                                    text =
[[
"Wolf's Bane"

Kill 100,000 Wolves
]],
                                },

                            },
                        },

                    },
                },

                {
                    name = L"Birds",
                    entries =
                    {
                        {
                            name = L"Great Eagle",
                            entries =
                            {
                                {
                                    id = 40,
                                    name = L"Kill 25 Great Eagles",
                                    text =
[[
XP: 204

Kill 25 Great Eagles
]],
                                },

                                {
                                    id = 41,
                                    name = L"Kill 100 Great Eagles",
                                    text =
[[
XP: 500

Kill 100 Great Eagles
]],
                                },

                                {
                                    id = 42,
                                    name = L"Kill 1,000 Great Eagles",
                                    text =
[[
BEASTIAL TACTIC FRAGMENT

Kill 1,000 Great Eagles
]],
                                },

                                {
                                    id = 43,
                                    name = L"Kill 10,000 Great Eagles",
                                    text =
[[
"Master Great Eagle Slayer"

Kill 10,000 Great Eagles
]],
                                },

                            },
                        },

                        {
                            name = L"Vulture",
                            entries =
                            {
                                {
                                    id = 44,
                                    name = L"Kill 25 Vultures",
                                    text =
[[
XP: 204

Kill 25 Vultures
]],
                                },

                                {
                                    id = 45,
                                    name = L"Kill 100 Vultures",
                                    text =
[[
XP: 500

Kill 100 Vultures
]],
                                },

                                {
                                    id = 46,
                                    name = L"Kill 1,000 Vultures",
                                    text =
[[
BESTIAL TOKEN

Kill 1,000 Vultures
]],
                                },

                                {
                                    id = 47,
                                    name = L"Kill 10,000 Vultures",
                                    text =
[[
"The Scavenger"

Kill 10,000 Vultures
]],
                                },

                                {
                                    id = 48,
                                    name = L"Kill 100,000 Vultures",
                                    text =
[[
"The Vulture"

Kill 100,000 Vultures
]],
                                },

                            },
                        },

                        {
                            name = L"Warhawk",
                            entries =
                            {
                                {
                                    id = 49,
                                    name = L"Kill 25 Warhawks",
                                    text =
[[
XP: 204

Kill 25 Warhawks
]],
                                },

                                {
                                    id = 50,
                                    name = L"Kill 100 Warhawks",
                                    text =
[[
XP: 500

Kill 100 Warhawks
]],
                                },

                                {
                                    id = 51,
                                    name = L"Kill 1,000 Warhawks",
                                    text =
[[
BESTIAL TOKEN

Kill 1,000 Warhawks
]],
                                },

                                {
                                    id = 52,
                                    name = L"Kill 10,000 Warhawks",
                                    text =
[[
"The Talon"

Kill 10,000 Warhawks
]],
                                },

                                {
                                    id = 53,
                                    name = L"Kill 100,000 Warhawks",
                                    text =
[[
"The Wing Clipper"

Kill 100,000 Warhawks
]],
                                },

                            },
                        },

                    },
                },

                {
                    name = L"Creatures",
                    entries =
                    {
                        {
                            name = L"Great Stag",
                            entries =
                            {
                                {
                                    id = 54,
                                    name = L"Kill 25 Great Stags",
                                    text =
[[
XP: 204

Kill 25 Great Stags
]],
                                },

                                {
                                    id = 55,
                                    name = L"Kill 100 Great Stags",
                                    text =
[[
XP: 500

Kill 100 Great Stags
]],
                                },

                                {
                                    id = 56,
                                    name = L"Kill 1,000 Great Stags",
                                    text =
[[
BEASTIAL TACTIC FRAGMENT

Kill 1,000 Great Stags
]],
                                },

                                {
                                    id = 57,
                                    name = L"Kill 10,000 Great Stags",
                                    text =
[[
"The Deer Hunter"

Kill 10,000 Great Stags
]],
                                },

                                {
                                    id = 58,
                                    name = L"Kill 100,000 Great Stags",
                                    text =
[[
"Master Deer Hunter"

Kill 100,000 Great Stags
]],
                                },

                            },
                        },

                    },
                },

                {
                    name = L"Insects & Arachnids",
                    entries =
                    {
                        {
                            name = L"Giant Scarab",
                            entries =
                            {
                                {
                                    id = 59,
                                    name = L"Kill 25 Giant Scarabs",
                                    text =
[[
XP: 1476

Kill 25 Giant Scarabs
]],
                                },

                                {
                                    id = 60,
                                    name = L"Kill 1,000 Giant Scarabs",
                                    text =
[[
UNDEAD TACTIC FRAGMENT

Kill 1,000 Giant Scarabs
]],
                                },

                                {
                                    id = 61,
                                    name = L"Kill 10,000 Giant Scarabs",
                                    text =
[[
"The Verminator"

Kill 10,000 Giant Scarabs
]],
                                },

                            },
                        },

                        {
                            name = L"Scorpion, Giant",
                            entries =
                            {
                                {
                                    id = 62,
                                    name = L"Kill 25 Giant Scorpions",
                                    text =
[[
XP: 204

Kill 25 Giant Scorpions
]],
                                },

                                {
                                    id = 63,
                                    name = L"Kill 100 Giant Scorpions",
                                    text =
[[
XP: 500

Kill 100 Giant Scorpions
]],
                                },

                                {
                                    id = 64,
                                    name = L"Kill 1,000 Giant Scorpions",
                                    text =
[[
BESTIAL TOKEN

Kill 1,000 Giant Scorpions
]],
                                },

                                {
                                    id = 65,
                                    name = L"Kill 10,000 Giant Scorpions",
                                    text =
[[
"Scorpion Smasher"

Kill 10,000 Giant Scorpions
]],
                                },

                                {
                                    id = 66,
                                    name = L"Kill 100,000 Giant Scorpions",
                                    text =
[[
"The Perforater"

Kill 100,000 Giant Scorpions
]],
                                },

                            },
                        },

                        {
                            name = L"Spider, Giant",
                            entries =
                            {
                                {
                                    id = 67,
                                    name = L"Kill 25 Giant Spiders",
                                    text =
[[
XP: 204

Kill 25 Giant Spiders
]],
                                },

                                {
                                    id = 68,
                                    name = L"Kill 100 Giant Spiders",
                                    text =
[[
XP: 500

Kill 100 Giant Spiders
]],
                                },

                                {
                                    id = 69,
                                    name = L"Kill 1,000 Giant Spiders",
                                    text =
[[
BESTIAL TOKEN

Kill 1,000 Giant Spiders
]],
                                },

                                {
                                    id = 70,
                                    name = L"Kill 10,000 Giant Spiders",
                                    text =
[[
"Scourge of the Arachnids"

Kill 10,000 Giant Spiders
]],
                                },

                                {
                                    id = 71,
                                    name = L"Kill 100,000 Giant Spiders",
                                    text =
[[
"The Websmiter"

Kill 100,000 Giant Spiders
]],
                                },

                            },
                        },

                        {
                            name = L"Tomb Swarm",
                            entries =
                            {
                                {
                                    id = 72,
                                    name = L"Kill 25 Tomb Swarm",
                                    text =
[[
XP: 1476

Kill 25 Tomb Swarm
]],
                                },

                                {
                                    id = 73,
                                    name = L"Kill 1,000 Tomb Swarm",
                                    text =
[[
UNDEAD TACTIC FRAGMENT

Kill 1,000 Tomb Swarm
]],
                                },

                                {
                                    id = 74,
                                    name = L"Kill 10,000 Tomb Swarm",
                                    text =
[[
"Bug Stomper"

Kill 10,000 Tomb Swarm
]],
                                },

                            },
                        },

                    },
                },

                {
                    name = L"Reptiles",
                    entries =
                    {
                        {
                            name = L"Cold One",
                            entries =
                            {
                                {
                                    id = 75,
                                    name = L"Kill 25 Cold Ones",
                                    text =
[[
XP: 204

Kill 25 Cold Ones
]],
                                },

                                {
                                    id = 76,
                                    name = L"Kill 100 Cold Ones",
                                    text =
[[
XP: 500

Kill 100 Cold Ones
]],
                                },

                                {
                                    id = 77,
                                    name = L"Kill 1,000 Cold Ones",
                                    text =
[[
BEASTIAL TACTIC FRAGMENT

Kill 1,000 Cold Ones
]],
                                },

                                {
                                    id = 78,
                                    name = L"Kill 10,000 Cold Ones",
                                    text =
[[
"Master Cold One Slayer"

Kill 10,000 Cold Ones
]],
                                },

                            },
                        },

                        {
                            name = L"Lizard, Giant",
                            entries =
                            {
                                {
                                    id = 79,
                                    name = L"Kill 25 Giant Lizards",
                                    text =
[[
XP: 204

Kill 25 Giant Lizards
]],
                                },

                                {
                                    id = 80,
                                    name = L"Kill 100 Giant Lizards",
                                    text =
[[
XP: 500

Kill 100 Giant Lizards
]],
                                },

                                {
                                    id = 81,
                                    name = L"Kill 1,000 Giant Lizards",
                                    text =
[[
BESTIAL TOKEN

Kill 1,000 Giant Lizards
]],
                                },

                                {
                                    id = 82,
                                    name = L"Kill 10,000 Giant Lizards",
                                    text =
[[
"The Reptile Wrangler"

Kill 10,000 Giant Lizards
]],
                                },

                                {
                                    id = 83,
                                    name = L"Kill 100,000 Giant Lizards",
                                    text =
[[
"Cold-Blooded"

Kill 100,000 Giant Lizards
]],
                                },

                            },
                        },

                    },
                },

            },
        },

        {
            name = L"Daemons",
            entries =
            {
                {
                    name = L"Daemons of Khorne",
                    entries =
                    {
                        {
                            name = L"Bloodbeast of Khorne",
                            entries =
                            {
                                {
                                    id = 84,
                                    name = L"Kill 25 Bloodbeasts of Khorne",
                                    text =
[[
XP: 336

Kill 25 Bloodbeasts of Khorne
]],
                                },

                                {
                                    id = 85,
                                    name = L"Kill 100 Bloodbeasts of Khorne",
                                    text =
[[
JEWEL ITEM : BROKE TOOF

Kill 100 Bloodbeasts of Khorne
]],
                                },

                                {
                                    id = 86,
                                    name = L"Kill 1,000 Bloodbeasts of Khorne",
                                    text =
[[
DAEMONIC TACTIC FRAGMENT

Kill 1,000 Bloodbeasts of Khorne
]],
                                },

                                {
                                    id = 87,
                                    name = L"Kill 10,000 Bloodbeasts of Khorne",
                                    text =
[[
"Master Bloodbeast Slayer"

Kill 10,000 Bloodbeasts of Khorne
]],
                                },

                            },
                        },

                        {
                            name = L"Bloodletter of Khorne",
                            entries =
                            {
                                {
                                    id = 88,
                                    name = L"Kill 25 Bloodletters of Khorne",
                                    text =
[[
XP: 204

Kill 25 Bloodletters of Khorne
]],
                                },

                                {
                                    id = 89,
                                    name = L"Kill 100 Bloodletters of Khorne",
                                    text =
[[
XP: 500

Kill 100 Bloodletters of Khorne
]],
                                },

                                {
                                    id = 90,
                                    name = L"Kill 1,000 Bloodletters of Khorne",
                                    text =
[[
DAEMONIC TACTIC FRAGMENT

Kill 1,000 Bloodletters of Khorne
]],
                                },

                                {
                                    id = 91,
                                    name = L"Kill 10,000 Bloodletters of Khorne",
                                    text =
[[
"Master Bloodletter Slayer"

Kill 10,000 Bloodletters of Khorne
]],
                                },

                            },
                        },

                        {
                            name = L"Bloodthirster of Khorne",
                            entries =
                            {
                                {
                                    id = 92,
                                    name = L"Kill 25 Bloodthirsters of Khorne",
                                    text =
[[
XP: 336

Kill 25 Bloodthirsters of Khorne
]],
                                },

                                {
                                    id = 93,
                                    name = L"Kill 100 Bloodthirsters of Khorne",
                                    text =
[[
XP: 500

Kill 100 Bloodthirsters of Khorne
]],
                                },

                                {
                                    id = 94,
                                    name = L"Kill 1,000 Bloodthirsters of Khorne",
                                    text =
[[
DAEMONIC TACTIC FRAGMENT

Kill 1,000 Bloodthirsters of Khorne
]],
                                },

                                {
                                    id = 95,
                                    name = L"Kill 10,000 Bloodthirsters of Khorne",
                                    text =
[[
"Master Bloodthirster Slayer"

Kill 10,000 Bloodthirsters of Khorne
]],
                                },

                            },
                        },

                        {
                            name = L"Flesh Hound of Khorne",
                            entries =
                            {
                                {
                                    id = 96,
                                    name = L"Kill 25 Fleshhounds of Khorne",
                                    text =
[[
XP: 336

Kill 25 Fleshhounds of Khorne
]],
                                },

                                {
                                    id = 97,
                                    name = L"Kill 100 Fleshhounds of Khorne",
                                    text =
[[
XP: 500

Kill 100 Fleshhounds of Khorne
]],
                                },

                                {
                                    id = 98,
                                    name = L"Kill 1,000 Fleshhounds of Khorne",
                                    text =
[[
DAEMONIC TACTIC FRAGMENT

Kill 1,000 Fleshhounds of Khorne
]],
                                },

                                {
                                    id = 99,
                                    name = L"Kill 10,000 Fleshhounds of Khorne",
                                    text =
[[
"Master Flesh Hound Slayer"

Kill 10,000 Fleshhounds of Khorne
]],
                                },

                            },
                        },

                        {
                            name = L"Ragebeast",
                            entries =
                            {
                                {
                                    id = 100,
                                    name = L"Kill 25 Ragebeasts",
                                    text =
[[
XP: 336

Kill 25 Ragebeasts
]],
                                },

                                {
                                    id = 101,
                                    name = L"Kill 100 Ragebeasts",
                                    text =
[[
XP: 500

Kill 100 Ragebeasts
]],
                                },

                                {
                                    id = 102,
                                    name = L"Kill 1,000 Ragebeasts",
                                    text =
[[
DAEMONIC TACTIC FRAGMENT

Kill 1,000 Ragebeasts
]],
                                },

                                {
                                    id = 103,
                                    name = L"Kill 10,000 Ragebeasts",
                                    text =
[[
"Master Juggernaut Slayer"

Kill 10,000 Ragebeasts
]],
                                },

                            },
                        },

                    },
                },

                {
                    name = L"Daemons of Nurgle",
                    entries =
                    {
                        {
                            name = L"Great Unclean One",
                            entries =
                            {
                                {
                                    id = 104,
                                    name = L"Kill 25 Great Unclean Ones",
                                    text =
[[
XP: 336

Kill 25 Great Unclean Ones
]],
                                },

                                {
                                    id = 105,
                                    name = L"Kill 100 Great Unclean Ones",
                                    text =
[[
XP: 500

Kill 100 Great Unclean Ones
]],
                                },

                                {
                                    id = 106,
                                    name = L"Kill 1,000 Great Unclean Ones",
                                    text =
[[
DAEMONIC TACTIC FRAGMENT

Kill 1,000 Great Unclean Ones
]],
                                },

                                {
                                    id = 107,
                                    name = L"Kill 10,000 Great Unclean Ones",
                                    text =
[[
"Master Great Unclean One Slayer"

Kill 10,000 Great Unclean Ones
]],
                                },

                            },
                        },

                        {
                            name = L"Nurgling",
                            entries =
                            {
                                {
                                    id = 108,
                                    name = L"Kill 25 Nurglings",
                                    text =
[[
XP: 204

Kill 25 Nurglings
]],
                                },

                                {
                                    id = 109,
                                    name = L"Kill 100 Nurglings",
                                    text =
[[
XP: 500

Kill 100 Nurglings
]],
                                },

                                {
                                    id = 110,
                                    name = L"Kill 1,000 Nurglings",
                                    text =
[[
BESTIAL TOKEN

Kill 1,000 Nurglings
]],
                                },

                                {
                                    id = 111,
                                    name = L"Kill 10,000 Nurglings",
                                    text =
[[
"Plaguepests' Foe"

Kill 10,000 Nurglings
]],
                                },

                                {
                                    id = 112,
                                    name = L"Kill 100,000 Nurglings",
                                    text =
[[
"Vileswarm Nemesis"

Kill 100,000 Nurglings
]],
                                },

                            },
                        },

                        {
                            name = L"Plaguebearer",
                            entries =
                            {
                                {
                                    id = 113,
                                    name = L"Kill 25 Plaguebearers of Nurgle",
                                    text =
[[
XP: 204

Kill 25 Plaguebearers of Nurgle
]],
                                },

                                {
                                    id = 114,
                                    name = L"Kill 100 Plaguebearers of Nurgle",
                                    text =
[[
XP: 500

Kill 100 Plaguebearers of Nurgle
]],
                                },

                                {
                                    id = 115,
                                    name = L"Kill 1,000 Plaguebearers of Nurgle",
                                    text =
[[
BESTIAL TOKEN

Kill 1,000 Plaguebearers of Nurgle
]],
                                },

                                {
                                    id = 116,
                                    name = L"Kill 10,000 Plaguebearers of Nurgle",
                                    text =
[[
"Blightseeker"

Kill 10,000 Plaguebearers of Nurgle
]],
                                },

                                {
                                    id = 117,
                                    name = L"Kill 100,000 Plaguebearers of Nurgle",
                                    text =
[[
"The Illwind Champion"

Kill 100,000 Plaguebearers of Nurgle
]],
                                },

                            },
                        },

                        {
                            name = L"Plaguebeast of Nurgle",
                            entries =
                            {
                                {
                                    id = 118,
                                    name = L"Kill 25 Plaguebeasts of Nurgle",
                                    text =
[[
XP: 336

Kill 25 Plaguebeasts of Nurgle
]],
                                },

                                {
                                    id = 119,
                                    name = L"Kill 100 Plaguebeasts of Nurgle",
                                    text =
[[
XP: 500

Kill 100 Plaguebeasts of Nurgle
]],
                                },

                                {
                                    id = 120,
                                    name = L"Kill 1,000 Plaguebeasts of Nurgle",
                                    text =
[[
DAEMONIC TACTIC FRAGMENT

Kill 1,000 Plaguebeasts of Nurgle
]],
                                },

                                {
                                    id = 121,
                                    name = L"Kill 10,000 Plaguebeasts of Nurgle",
                                    text =
[[
"Master Plaguebeast Slayer"

Kill 10,000 Plaguebeasts of Nurgle
]],
                                },

                            },
                        },

                        {
                            name = L"Slimehound",
                            entries =
                            {
                                {
                                    id = 122,
                                    name = L"Kill 25 Slimehounds",
                                    text =
[[
XP: 204

Kill 25 Slimehounds
]],
                                },

                                {
                                    id = 123,
                                    name = L"Kill 100 Slimehounds",
                                    text =
[[
XP: 500

Kill 100 Slimehounds
]],
                                },

                                {
                                    id = 124,
                                    name = L"Kill 1,000 Slimehounds",
                                    text =
[[
DAEMONIC TACTIC FRAGMENT

Kill 1,000 Slimehounds
]],
                                },

                                {
                                    id = 125,
                                    name = L"Kill 10,000 Slimehounds",
                                    text =
[[
"Master Slimehound Slayer"

Kill 10,000 Slimehounds
]],
                                },

                            },
                        },

                    },
                },

                {
                    name = L"Daemons of Slaanesh",
                    entries =
                    {
                        {
                            name = L"Daemonette of Slaanesh",
                            entries =
                            {
                                {
                                    id = 126,
                                    name = L"Kill 25 Daemonettes of Slaanesh",
                                    text =
[[
XP: 204

Kill 25 Daemonettes of Slaanesh
]],
                                },

                                {
                                    id = 127,
                                    name = L"Kill 100 Daemonettes of Slaanesh",
                                    text =
[[
XP: 500

Kill 100 Daemonettes of Slaanesh
]],
                                },

                                {
                                    id = 128,
                                    name = L"Kill 1,000 Daemonettes of Slaanesh",
                                    text =
[[
DAEMONIC TACTIC FRAGMENT

Kill 1,000 Daemonettes of Slaanesh
]],
                                },

                                {
                                    id = 129,
                                    name = L"Kill 10,000 Daemonettes of Slaanesh",
                                    text =
[[
"Master Daemonette Slayer"

Kill 10,000 Daemonettes of Slaanesh
]],
                                },

                            },
                        },

                        {
                            name = L"Fiend of Slaanesh",
                            entries =
                            {
                                {
                                    id = 130,
                                    name = L"Kill 25 Fiends of Slaanesh",
                                    text =
[[
XP: 336

Kill 25 Fiends of Slaanesh
]],
                                },

                                {
                                    id = 131,
                                    name = L"Kill 100 Fiends of Slaanesh",
                                    text =
[[
XP: 500

Kill 100 Fiends of Slaanesh
]],
                                },

                                {
                                    id = 132,
                                    name = L"Kill 1,000 Fiends of Slaanesh",
                                    text =
[[
POCKET : FIENDSHIP BRACELET

Kill 1,000 Fiends of Slaanesh
]],
                                },

                                {
                                    id = 133,
                                    name = L"Kill 10,000 Fiends of Slaanesh",
                                    text =
[[
"Master Fiend Slayer"

Kill 10,000 Fiends of Slaanesh
]],
                                },

                            },
                        },

                        {
                            name = L"Keeper of Secrets",
                            entries =
                            {
                                {
                                    id = 134,
                                    name = L"Kill 25 Keepers of Secrets",
                                    text =
[[
XP: 336

Kill 25 Keepers of Secrets
]],
                                },

                                {
                                    id = 135,
                                    name = L"Kill 100 Keepers of Secrets",
                                    text =
[[
XP: 500

Kill 100 Keepers of Secrets
]],
                                },

                                {
                                    id = 136,
                                    name = L"Kill 1,000 Keepers of Secrets",
                                    text =
[[
DAEMONIC TACTIC FRAGMENT

Kill 1,000 Keepers of Secrets
]],
                                },

                                {
                                    id = 137,
                                    name = L"Kill 10,000 Keepers of Secrets",
                                    text =
[[
"Master Keeper of Secrets Slayer"

Kill 10,000 Keepers of Secrets
]],
                                },

                            },
                        },

                        {
                            name = L"Pleasurebeast",
                            entries =
                            {
                                {
                                    id = 138,
                                    name = L"Kill 25 Pleasurebeasts",
                                    text =
[[
XP: 204

Kill 25 Pleasurebeasts
]],
                                },

                                {
                                    id = 139,
                                    name = L"Kill 100 Pleasurebeasts",
                                    text =
[[
XP: 500

Kill 100 Pleasurebeasts
]],
                                },

                            },
                        },

                    },
                },

                {
                    name = L"Daemons of Tzeentch",
                    entries =
                    {
                        {
                            name = L"Firewyrm of Tzeentch",
                            entries =
                            {
                                {
                                    id = 140,
                                    name = L"Kill 25 Firewyrms of Tzeentch",
                                    text =
[[
XP: 336

Kill 25 Firewyrms of Tzeentch
]],
                                },

                                {
                                    id = 141,
                                    name = L"Kill 100 Firewyrms of Tzeentch",
                                    text =
[[
XP: 500

Kill 100 Firewyrms of Tzeentch
]],
                                },

                                {
                                    id = 142,
                                    name = L"Kill 1,000 Firewyrms of Tzeentch",
                                    text =
[[
DAEMONIC TACTIC FRAGMENT

Kill 1,000 Firewyrms of Tzeentch
]],
                                },

                                {
                                    id = 143,
                                    name = L"Kill 10,000 Firewyrms of Tzeentch",
                                    text =
[[
"Master Firewyrm Slayer"

Kill 10,000 Firewyrms of Tzeentch
]],
                                },

                            },
                        },

                        {
                            name = L"Flamer of Tzeentch",
                            entries =
                            {
                                {
                                    id = 144,
                                    name = L"Kill 25 Flamers of Tzeentch",
                                    text =
[[
XP: 336

Kill 25 Flamers of Tzeentch
]],
                                },

                                {
                                    id = 145,
                                    name = L"Kill 100 Flamers of Tzeentch",
                                    text =
[[
XP: 500

Kill 100 Flamers of Tzeentch
]],
                                },

                                {
                                    id = 146,
                                    name = L"Kill 1,000 Flamers of Tzeentch",
                                    text =
[[
DAEMONIC TACTIC FRAGMENT

Kill 1,000 Flamers of Tzeentch
]],
                                },

                                {
                                    id = 147,
                                    name = L"Kill 10,000 Flamers of Tzeentch",
                                    text =
[[
"Master Flamer Slayer"

Kill 10,000 Flamers of Tzeentch
]],
                                },

                            },
                        },

                        {
                            name = L"Horror of Tzeentch",
                            entries =
                            {
                                {
                                    id = 148,
                                    name = L"Kill 25 Horrors of Tzeentch",
                                    text =
[[
XP: 204

Kill 25 Horrors of Tzeentch
]],
                                },

                                {
                                    id = 149,
                                    name = L"Kill 100 Horrors of Tzeentch",
                                    text =
[[
XP: 500

Kill 100 Horrors of Tzeentch
]],
                                },

                                {
                                    id = 150,
                                    name = L"Kill 1,000 Horrors of Tzeentch",
                                    text =
[[
BESTIAL TOKEN

Kill 1,000 Horrors of Tzeentch
]],
                                },

                                {
                                    id = 151,
                                    name = L"Kill 10,000 Horrors of Tzeentch",
                                    text =
[[
"Aethyr Custodian"

Kill 10,000 Horrors of Tzeentch
]],
                                },

                                {
                                    id = 152,
                                    name = L"Kill 100,000 Horrors of Tzeentch",
                                    text =
[[
"Aethyr Reaver"

Kill 100,000 Horrors of Tzeentch
]],
                                },

                            },
                        },

                        {
                            name = L"Lord of Change",
                            entries =
                            {
                                {
                                    id = 153,
                                    name = L"Kill 25 Lords of Change",
                                    text =
[[
XP: 336

Kill 25 Lords of Change
]],
                                },

                                {
                                    id = 154,
                                    name = L"Kill 100 Lords of Change",
                                    text =
[[
XP: 500

Kill 100 Lords of Change
]],
                                },

                                {
                                    id = 155,
                                    name = L"Kill 1,000 Lords of Change",
                                    text =
[[
DAEMONIC TACTIC FRAGMENT

Kill 1,000 Lords of Change
]],
                                },

                                {
                                    id = 156,
                                    name = L"Kill 10,000 Lords of Change",
                                    text =
[[
"Master Lord of Change Slayer"

Kill 10,000 Lords of Change
]],
                                },

                            },
                        },

                        {
                            name = L"Screamer of Tzeentch",
                            entries =
                            {
                                {
                                    id = 157,
                                    name = L"Kill 25 Screamers of Tzeentch",
                                    text =
[[
XP: 204

Kill 25 Screamers of Tzeentch
]],
                                },

                                {
                                    id = 158,
                                    name = L"Kill 100 Screamers of Tzeentch",
                                    text =
[[
XP: 500

Kill 100 Screamers of Tzeentch
]],
                                },

                                {
                                    id = 159,
                                    name = L"Kill 1,000 Screamers of Tzeentch",
                                    text =
[[
DAEMONIC TACTIC FRAGMENT

Kill 1,000 Screamers of Tzeentch
]],
                                },

                                {
                                    id = 160,
                                    name = L"Kill 10,000 Screamers of Tzeentch",
                                    text =
[[
"Master Screamer Slayer"

Kill 10,000 Screamers of Tzeentch
]],
                                },

                            },
                        },

                        {
                            name = L"Watcher",
                            entries =
                            {
                                {
                                    id = 161,
                                    name = L"Kill 25 Watchers",
                                    text =
[[
XP: 204

Kill 25 Watchers
]],
                                },

                                {
                                    id = 162,
                                    name = L"Kill 100 Watchers",
                                    text =
[[
XP: 500

Kill 100 Watchers
]],
                                },

                                {
                                    id = 163,
                                    name = L"Kill 1,000 Watchers",
                                    text =
[[
DAEMONIC TACTIC FRAGMENT

Kill 1,000 Watchers
]],
                                },

                                {
                                    id = 164,
                                    name = L"Kill 10,000 Watchers",
                                    text =
[[
"Master Watcher Slayer"

Kill 10,000 Watchers
]],
                                },

                            },
                        },

                    },
                },

                {
                    name = L"Unmarked Daemons",
                    entries =
                    {
                        {
                            name = L"Chaos Fury",
                            entries =
                            {
                                {
                                    id = 165,
                                    name = L"Kill 25 Chaos Furies",
                                    text =
[[
XP: 204

Kill 25 Chaos Furies
]],
                                },

                                {
                                    id = 166,
                                    name = L"Kill 100 Chaos Furies",
                                    text =
[[
XP: 500

Kill 100 Chaos Furies
]],
                                },

                                {
                                    id = 167,
                                    name = L"Kill 1,000 Chaos Furies",
                                    text =
[[
DAEMONIC TACTIC FRAGMENT

Kill 1,000 Chaos Furies
]],
                                },

                                {
                                    id = 168,
                                    name = L"Kill 10,000 Chaos Furies",
                                    text =
[[
"Master Chaos Fury Slayer"

Kill 10,000 Chaos Furies
]],
                                },

                            },
                        },

                        {
                            name = L"Chaos Hound",
                            entries =
                            {
                                {
                                    id = 169,
                                    name = L"Kill 25 Chaos Hounds",
                                    text =
[[
XP: 204

Kill 25 Chaos Hounds
]],
                                },

                                {
                                    id = 170,
                                    name = L"Kill 100 Chaos Hounds",
                                    text =
[[
XP: 500

Kill 100 Chaos Hounds
]],
                                },

                                {
                                    id = 171,
                                    name = L"Kill 1,000 Chaos Hounds",
                                    text =
[[
BEASTIAL TACTIC FRAGMENT

Kill 1,000 Chaos Hounds
]],
                                },

                                {
                                    id = 172,
                                    name = L"Kill 10,000 Chaos Hounds",
                                    text =
[[
"Master Chaos Hound Slayer"

Kill 10,000 Chaos Hounds
]],
                                },

                            },
                        },

                        {
                            name = L"Chaos Spawn",
                            entries =
                            {
                                {
                                    id = 173,
                                    name = L"Kill 25 Chaos Spawn",
                                    text =
[[
XP: 204

Kill 25 Chaos Spawn
]],
                                },

                                {
                                    id = 174,
                                    name = L"Kill 100 Chaos Spawn",
                                    text =
[[
XP: 500

Kill 100 Chaos Spawn
]],
                                },

                                {
                                    id = 175,
                                    name = L"Kill 1,000 Chaos Spawn",
                                    text =
[[
DAEMONIC TACTIC FRAGMENT

Kill 1,000 Chaos Spawn
]],
                                },

                                {
                                    id = 176,
                                    name = L"Kill 10,000 Chaos Spawn",
                                    text =
[[
"Master Chaos Spawn Slayer"

Kill 10,000 Chaos Spawn
]],
                                },

                            },
                        },

                        {
                            name = L"Chaos Spawn, Daemonvine",
                            entries =
                            {
                                {
                                    id = 177,
                                    name = L"Kill 25 Daemonvines",
                                    text =
[[
XP: 204

Kill 25 Daemonvines
]],
                                },

                                {
                                    id = 178,
                                    name = L"Kill 100 Daemonvines",
                                    text =
[[
XP: 500

Kill 100 Daemonvines
]],
                                },

                                {
                                    id = 179,
                                    name = L"Kill 1,000 Daemonvines",
                                    text =
[[
DAEMONIC TACTIC FRAGMENT

Kill 1,000 Daemonvines
]],
                                },

                                {
                                    id = 180,
                                    name = L"Kill 10,000 Daemonvines",
                                    text =
[[
"Daemonvine Despoiler"

Kill 10,000 Daemonvines
]],
                                },

                            },
                        },

                        {
                            name = L"Daemon Prince",
                            entries =
                            {
                                {
                                    id = 181,
                                    name = L"Kill 25 Daemon Princes",
                                    text =
[[
XP: 336

Kill 25 Daemon Princes
]],
                                },

                                {
                                    id = 182,
                                    name = L"Kill 100 Daemon Princes",
                                    text =
[[
XP: 500

Kill 100 Daemon Princes
]],
                                },

                                {
                                    id = 183,
                                    name = L"Kill 1,000 Daemon Princes",
                                    text =
[[
POCKET : DAEMON HORN

Kill 1,000 Daemon Princes
]],
                                },

                                {
                                    id = 184,
                                    name = L"Kill 10,000 Daemon Princes",
                                    text =
[[
"Master Daemon Prince Slayer"

Kill 10,000 Daemon Princes
]],
                                },

                            },
                        },

                        {
                            name = L"Walker",
                            entries =
                            {
                                {
                                    id = 185,
                                    name = L"Kill 25 Walkers",
                                    text =
[[
XP: 204

Kill 25 Walkers
]],
                                },

                                {
                                    id = 186,
                                    name = L"Kill 100 Walkers",
                                    text =
[[
XP: 500

Kill 100 Walkers
]],
                                },

                                {
                                    id = 187,
                                    name = L"Kill 1,000 Walkers",
                                    text =
[[
UNDEAD TACTIC FRAGMENT

Kill 1,000 Walkers
]],
                                },

                                {
                                    id = 188,
                                    name = L"Kill 10,000 Walkers",
                                    text =
[[
"Master Slayer of Walkers"

Kill 10,000 Walkers
]],
                                },

                            },
                        },

                    },
                },

            },
        },

        {
            name = L"Humanoids",
            entries =
            {
                {
                    name = L"Beastmen",
                    entries =
                    {
                        {
                            name = L"Beastman, Bestigor",
                            entries =
                            {
                                {
                                    id = 189,
                                    name = L"Kill 25 Bestigors",
                                    text =
[[
XP: 204

Kill 25 Bestigors
]],
                                },

                                {
                                    id = 190,
                                    name = L"Kill 100 Bestigors",
                                    text =
[[
XP: 500

Kill 100 Bestigors
]],
                                },

                                {
                                    id = 191,
                                    name = L"Kill 1,000 Bestigors",
                                    text =
[[
BESTIAL TOKEN

Kill 1,000 Bestigors
]],
                                },

                                {
                                    id = 192,
                                    name = L"Kill 10,000 Bestigors",
                                    text =
[[
"The Bestial"

Kill 10,000 Bestigors
]],
                                },

                                {
                                    id = 193,
                                    name = L"Kill 100,000 Bestigors",
                                    text =
[[
"Herd Breaker"

Kill 100,000 Bestigors
]],
                                },

                            },
                        },

                        {
                            name = L"Beastman, Bray Shaman",
                            entries =
                            {
                                {
                                    id = 194,
                                    name = L"Kill 25 Bray Shaman",
                                    text =
[[
XP: 204

Kill 25 Bray Shaman
]],
                                },

                                {
                                    id = 195,
                                    name = L"Kill 100 Bray Shaman",
                                    text =
[[
XP: 500

Kill 100 Bray Shaman
]],
                                },

                                {
                                    id = 196,
                                    name = L"Kill 1,000 Bray Shaman",
                                    text =
[[
CHAOS TACTIC FRAGMENT

Kill 1,000 Bray Shaman
]],
                                },

                                {
                                    id = 197,
                                    name = L"Kill 10,000 Bray Shaman",
                                    text =
[[
"Master Bray Shaman Slayer"

Kill 10,000 Bray Shaman
]],
                                },

                            },
                        },

                        {
                            name = L"Beastman, Gor",
                            entries =
                            {
                                {
                                    id = 198,
                                    name = L"Kill 25 Gors",
                                    text =
[[
XP: 204

Kill 25 Gors
]],
                                },

                                {
                                    id = 199,
                                    name = L"Kill 100 Gors",
                                    text =
[[
XP: 500

Kill 100 Gors
]],
                                },

                                {
                                    id = 200,
                                    name = L"Kill 1,000 Gors",
                                    text =
[[
BESTIAL TOKEN

Kill 1,000 Gors
]],
                                },

                                {
                                    id = 201,
                                    name = L"Kill 10,000 Gors",
                                    text =
[[
"Herd Stalker"

Kill 10,000 Gors
]],
                                },

                                {
                                    id = 202,
                                    name = L"Kill 100,000 Gors",
                                    text =
[[
"Champion of the Wild"

Kill 100,000 Gors
]],
                                },

                            },
                        },

                        {
                            name = L"Beastman, Ungor",
                            entries =
                            {
                                {
                                    id = 203,
                                    name = L"Kill 25 Ungors",
                                    text =
[[
XP: 204

Kill 25 Ungors
]],
                                },

                                {
                                    id = 204,
                                    name = L"Kill 100 Ungors",
                                    text =
[[
XP: 500

Kill 100 Ungors
]],
                                },

                                {
                                    id = 205,
                                    name = L"Kill 1,000 Ungors",
                                    text =
[[
BESTIAL TOKEN

Kill 1,000 Ungors
]],
                                },

                                {
                                    id = 206,
                                    name = L"Kill 10,000 Ungors",
                                    text =
[[
"The Raging"

Kill 10,000 Ungors
]],
                                },

                                {
                                    id = 207,
                                    name = L"Kill 100,000 Ungors",
                                    text =
[[
"The Feral"

Kill 100,000 Ungors
]],
                                },

                            },
                        },

                        {
                            name = L"Doombull",
                            entries =
                            {
                                {
                                    id = 208,
                                    name = L"Kill 25 Doombulls",
                                    text =
[[
XP: 336

Kill 25 Doombulls
]],
                                },

                                {
                                    id = 209,
                                    name = L"Kill 100 Doombulls",
                                    text =
[[
XP: 500

Kill 100 Doombulls
]],
                                },

                                {
                                    id = 210,
                                    name = L"Kill 1,000 Doombulls",
                                    text =
[[
CHAOS TACTIC FRAGMENT

Kill 1,000 Doombulls
]],
                                },

                                {
                                    id = 211,
                                    name = L"Kill 10,000 Doombulls",
                                    text =
[[
"Master Doombull Slayer"

Kill 10,000 Doombulls
]],
                                },

                            },
                        },

                    },
                },

                {
                    name = L"Dwarfs",
                    entries =
                    {
                        {
                            name = L"Dwarf",
                            entries =
                            {
                                {
                                    id = 212,
                                    name = L"Kill 25 Dwarfs",
                                    text =
[[
XP: 204

Kill 25 Dwarfs
]],
                                },

                                {
                                    id = 213,
                                    name = L"Kill 100 Dwarfs",
                                    text =
[[
XP: 500

Kill 100 Dwarfs
]],
                                },

                                {
                                    id = 214,
                                    name = L"Kill 1,000 Dwarfs",
                                    text =
[[
TROPHY : DWARVEN DESTROYER, ONE PIP

Kill 1,000 Dwarfs
]],
                                },

                                {
                                    id = 215,
                                    name = L"Kill 10,000 Dwarfs",
                                    text =
[[
TROPHY : DWARVEN DESTROYER, TWO PIPS

Kill 10,000 Dwarfs
]],
                                },

                                {
                                    id = 216,
                                    name = L"Kill 100,000 Dwarfs",
                                    text =
[[
TROPHY : DWARVEN DESTROYER, THREE PIPS

Kill 100,000 Dwarfs
]],
                                },

                                {
                                    id = 217,
                                    name = L"Kill 1,000,000 Dwarfs",
                                    text =
[[
TROPHY : GOLDEN DWARVEN DESTROYER, THREE PIPS

Kill 1,000,000 Dwarfs
]],
                                },

                            },
                        },

                        {
                            name = L"Dwarf, Engineer",
                            entries =
                            {
                                {
                                    id = 218,
                                    name = L"Kill 25 Dwarfen Engineers",
                                    text =
[[
XP: 204

Kill 25 Dwarfen Engineers
]],
                                },

                                {
                                    id = 219,
                                    name = L"Kill 100 Dwarfen Engineers",
                                    text =
[[
XP: 500

Kill 100 Dwarfen Engineers
]],
                                },

                                {
                                    id = 220,
                                    name = L"Kill 1,000 Dwarfen Engineers",
                                    text =
[[
"The Detonator"

Kill 1,000 Dwarfen Engineers
]],
                                },

                                {
                                    id = 221,
                                    name = L"Kill 10,000 Dwarfen Engineers",
                                    text =
[[
"The Demolisher"

Kill 10,000 Dwarfen Engineers
]],
                                },

                                {
                                    id = 222,
                                    name = L"Kill 100,000 Dwarfen Engineers",
                                    text =
[[
TROPHY : GOLDEN DWARVEN DESTROYER, TWO PIPS

Kill 100,000 Dwarfen Engineers
]],
                                },

                            },
                        },

                        {
                            name = L"Dwarf, Ironbreaker",
                            entries =
                            {
                                {
                                    id = 223,
                                    name = L"Kill 25 Ironbreakers",
                                    text =
[[
XP: 204

Kill 25 Ironbreakers
]],
                                },

                                {
                                    id = 224,
                                    name = L"Kill 100 Ironbreakers",
                                    text =
[[
XP: 500

Kill 100 Ironbreakers
]],
                                },

                                {
                                    id = 225,
                                    name = L"Kill 1,000 Ironbreakers",
                                    text =
[[
"The Deep Lurker"

Kill 1,000 Ironbreakers
]],
                                },

                                {
                                    id = 226,
                                    name = L"Kill 10,000 Ironbreakers",
                                    text =
[[
"Depth Haunter"

Kill 10,000 Ironbreakers
]],
                                },

                                {
                                    id = 227,
                                    name = L"Kill 100,000 Ironbreakers",
                                    text =
[[
TROPHY : GOLDEN DWARVEN DESTROYER, TWO PIPS

Kill 100,000 Ironbreakers
]],
                                },

                            },
                        },

                        {
                            name = L"Dwarf, Runepriest",
                            entries =
                            {
                                {
                                    id = 228,
                                    name = L"Kill 25 Runepriests",
                                    text =
[[
XP: 204

Kill 25 Runepriests
]],
                                },

                                {
                                    id = 229,
                                    name = L"Kill 100 Runepriests",
                                    text =
[[
XP: 500

Kill 100 Runepriests
]],
                                },

                                {
                                    id = 230,
                                    name = L"Kill 1,000 Runepriests",
                                    text =
[[
"Rune Breaker"

Kill 1,000 Runepriests
]],
                                },

                                {
                                    id = 231,
                                    name = L"Kill 10,000 Runepriests",
                                    text =
[[
"Grungni's Bane"

Kill 10,000 Runepriests
]],
                                },

                                {
                                    id = 232,
                                    name = L"Kill 100,000 Runepriests",
                                    text =
[[
TROPHY : GOLDEN DWARVEN DESTROYER, TWO PIPS

Kill 100,000 Runepriests
]],
                                },

                            },
                        },

                        {
                            name = L"Dwarf, Slayer",
                            entries =
                            {
                                {
                                    id = 233,
                                    name = L"Kill 25 Slayers",
                                    text =
[[
XP: 204

Kill 25 Slayers
]],
                                },

                                {
                                    id = 234,
                                    name = L"Kill 100 Slayers",
                                    text =
[[
XP: 500

Kill 100 Slayers
]],
                                },

                                {
                                    id = 235,
                                    name = L"Kill 1,000 Slayers",
                                    text =
[[
"An Axe to Grind"

Kill 1,000 Slayers
]],
                                },

                                {
                                    id = 236,
                                    name = L"Kill 10,000 Slayers",
                                    text =
[[
"Oath Breaker"

Kill 10,000 Slayers
]],
                                },

                                {
                                    id = 237,
                                    name = L"Kill 100,000 Slayers",
                                    text =
[[
TROPHY : GOLDEN DWARVEN DESTROYER, TWO PIPS

Kill 100,000 Slayers
]],
                                },

                            },
                        },

                        {
                            name = L"Dwarven, Slayer",
                            entries =
                            {
                                {
                                    id = 238,
                                    name = L"Kill 25 Slayers",
                                    text =
[[
XP: 204

Kill 25 Slayers
]],
                                },

                                {
                                    id = 239,
                                    name = L"Kill 100 Slayers",
                                    text =
[[
XP: 500

Kill 100 Slayers
]],
                                },

                                {
                                    id = 240,
                                    name = L"Kill 1,000 Slayers",
                                    text =
[[
BESTIAL TOKEN

Kill 1,000 Slayers
]],
                                },

                                {
                                    id = 241,
                                    name = L"Kill 10,000 Slayers",
                                    text =
[[
"Vow Breaker"

Kill 10,000 Slayers
]],
                                },

                                {
                                    id = 242,
                                    name = L"Kill 100,000 Slayers",
                                    text =
[[
"Dwarf Slayer"

Kill 100,000 Slayers
]],
                                },

                            },
                        },

                    },
                },

                {
                    name = L"Elves",
                    entries =
                    {
                        {
                            name = L"Dark Elf",
                            entries =
                            {
                                {
                                    id = 243,
                                    name = L"Kill 25 Dark Elves",
                                    text =
[[
XP: 204

Kill 25 Dark Elves
]],
                                },

                                {
                                    id = 244,
                                    name = L"Kill 100 Dark Elves",
                                    text =
[[
XP: 500

Kill 100 Dark Elves
]],
                                },

                                {
                                    id = 245,
                                    name = L"Kill 1,000 Dark Elves",
                                    text =
[[
TROPHY : DARK ELF DESTROYER, ONE PIP

Kill 1,000 Dark Elves
]],
                                },

                                {
                                    id = 246,
                                    name = L"Kill 10,000 Dark Elves",
                                    text =
[[
TROPHY : DARK ELF DESTROYER, TWO PIPS

Kill 10,000 Dark Elves
]],
                                },

                                {
                                    id = 247,
                                    name = L"Kill 100,000 Dark Elves",
                                    text =
[[
TROPHY : DARK ELF DESTROYER, THREE PIPS

Kill 100,000 Dark Elves
]],
                                },

                                {
                                    id = 248,
                                    name = L"Kill 1,000,000 Dark Elves",
                                    text =
[[
TROPHY : GOLDEN DARK ELF DESTROYER, THREE PIPS

Kill 1,000,000 Dark Elves
]],
                                },

                            },
                        },

                        {
                            name = L"Dark Elf, Blackguard",
                            entries =
                            {
                                {
                                    id = 249,
                                    name = L"Kill 25 Black Guards",
                                    text =
[[
XP: 204

Kill 25 Black Guards
]],
                                },

                                {
                                    id = 250,
                                    name = L"Kill 100 Black Guards",
                                    text =
[[
XP: 500

Kill 100 Black Guards
]],
                                },

                                {
                                    id = 251,
                                    name = L"Kill 1,000 Black Guards",
                                    text =
[[
"Halberd Splitter"

Kill 1,000 Black Guards
]],
                                },

                                {
                                    id = 252,
                                    name = L"Kill 10,000 Black Guards",
                                    text =
[[
"Witch King's Woe"

Kill 10,000 Black Guards
]],
                                },

                                {
                                    id = 253,
                                    name = L"Kill 100,000 Black Guards",
                                    text =
[[
TROPHY : GOLDEN DARK ELF DESTROYER, TWO PIPS

Kill 100,000 Black Guards
]],
                                },

                            },
                        },

                        {
                            name = L"Dark Elf, Disciple of Khaine",
                            entries =
                            {
                                {
                                    id = 254,
                                    name = L"Kill 25 Disciples of Khaine",
                                    text =
[[
XP: 204

Kill 25 Disciples of Khaine
]],
                                },

                                {
                                    id = 255,
                                    name = L"Kill 100 Disciples of Khaine",
                                    text =
[[
XP: 500

Kill 100 Disciples of Khaine
]],
                                },

                                {
                                    id = 256,
                                    name = L"Kill 1,000 Disciples of Khaine",
                                    text =
[[
"The Stalwart"

Kill 1,000 Disciples of Khaine
]],
                                },

                                {
                                    id = 257,
                                    name = L"Kill 10,000 Disciples of Khaine",
                                    text =
[[
"The Steadfast"

Kill 10,000 Disciples of Khaine
]],
                                },

                                {
                                    id = 258,
                                    name = L"Kill 100,000 Disciples of Khaine",
                                    text =
[[
TROPHY : GOLDEN DARK ELF DESTROYER, TWO PIPS

Kill 100,000 Disciples of Khaine
]],
                                },

                            },
                        },

                        {
                            name = L"Dark Elf, Sorceror",
                            entries =
                            {
                                {
                                    id = 259,
                                    name = L"Kill 25 Dark Elf Sorcerors",
                                    text =
[[
XP: 204

Kill 25 Dark Elf Sorcerors
]],
                                },

                                {
                                    id = 260,
                                    name = L"Kill 100 Dark Elf Sorcerors",
                                    text =
[[
XP: 500

Kill 100 Dark Elf Sorcerors
]],
                                },

                                {
                                    id = 261,
                                    name = L"Kill 1,000 Dark Elf Sorcerors",
                                    text =
[[
"Spellbinder"

Kill 1,000 Dark Elf Sorcerors
]],
                                },

                                {
                                    id = 262,
                                    name = L"Kill 10,000 Dark Elf Sorcerors",
                                    text =
[[
"Spellbreaker"

Kill 10,000 Dark Elf Sorcerors
]],
                                },

                                {
                                    id = 263,
                                    name = L"Kill 100,000 Dark Elf Sorcerors",
                                    text =
[[
TROPHY : GOLDEN DARK ELF DESTROYER, TWO PIPS

Kill 100,000 Dark Elf Sorcerors
]],
                                },

                            },
                        },

                        {
                            name = L"Dark Elf, Witch Elves",
                            entries =
                            {
                                {
                                    id = 264,
                                    name = L"Kill 25 Witch Elves",
                                    text =
[[
XP: 204

Kill 25 Witch Elves
]],
                                },

                                {
                                    id = 265,
                                    name = L"Kill 100 Witch Elves",
                                    text =
[[
XP: 500

Kill 100 Witch Elves
]],
                                },

                                {
                                    id = 266,
                                    name = L"Kill 1,000 Witch Elves",
                                    text =
[[
"The Deft"

Kill 1,000 Witch Elves
]],
                                },

                                {
                                    id = 267,
                                    name = L"Kill 10,000 Witch Elves",
                                    text =
[[
"The Lethal"

Kill 10,000 Witch Elves
]],
                                },

                                {
                                    id = 268,
                                    name = L"Kill 100,000 Witch Elves",
                                    text =
[[
TROPHY : GOLDEN DARK ELF DESTROYER, TWO PIPS

Kill 100,000 Witch Elves
]],
                                },

                            },
                        },

                        {
                            name = L"High Elf",
                            entries =
                            {
                                {
                                    id = 269,
                                    name = L"Kill 25 High Elves",
                                    text =
[[
XP: 204

Kill 25 High Elves
]],
                                },

                                {
                                    id = 270,
                                    name = L"Kill 100 High Elves",
                                    text =
[[
XP: 500

Kill 100 High Elves
]],
                                },

                                {
                                    id = 271,
                                    name = L"Kill 1,000 High Elves",
                                    text =
[[
TROPHY : HIGH ELF ELIMINATOR, ONE PIP

Kill 1,000 High Elves
]],
                                },

                                {
                                    id = 272,
                                    name = L"Kill 10,000 High Elves",
                                    text =
[[
TROPHY : HIGH ELF ELIMINATOR, TWO PIPS

Kill 10,000 High Elves
]],
                                },

                                {
                                    id = 273,
                                    name = L"Kill 100,000 High Elves",
                                    text =
[[
TROPHY : HIGH ELF ELIMINATOR, THREE PIPS

Kill 100,000 High Elves
]],
                                },

                                {
                                    id = 274,
                                    name = L"Kill 1,000,000 High Elves",
                                    text =
[[
TROPHY : GOLDEN HIGH ELF ELIMINATOR, THREE PIPS

Kill 1,000,000 High Elves
]],
                                },

                            },
                        },

                        {
                            name = L"High Elf, Archmage",
                            entries =
                            {
                                {
                                    id = 275,
                                    name = L"Kill 25 High Elf Archmagi",
                                    text =
[[
XP: 204

Kill 25 High Elf Archmagi
]],
                                },

                                {
                                    id = 276,
                                    name = L"Kill 100 High Elf Archmagi",
                                    text =
[[
XP: 500

Kill 100 High Elf Archmagi
]],
                                },

                                {
                                    id = 277,
                                    name = L"Kill 1,000 High Elf Archmagi",
                                    text =
[[
"Theurge Breaker"

Kill 1,000 High Elf Archmagi
]],
                                },

                                {
                                    id = 278,
                                    name = L"Kill 10,000 High Elf Archmagi",
                                    text =
[[
"The Spelleater"

Kill 10,000 High Elf Archmagi
]],
                                },

                                {
                                    id = 279,
                                    name = L"Kill 100,000 High Elf Archmagi",
                                    text =
[[
TROPHY : GOLDEN HIGH ELF ELIMINATOR, TWO PIPS

Kill 100,000 High Elf Archmagi
]],
                                },

                            },
                        },

                        {
                            name = L"High Elf, Shadow Warrior",
                            entries =
                            {
                                {
                                    id = 280,
                                    name = L"Kill 25 Shadow Warriors",
                                    text =
[[
XP: 204

Kill 25 Shadow Warriors
]],
                                },

                                {
                                    id = 281,
                                    name = L"Kill 100 Shadow Warriors",
                                    text =
[[
XP: 500

Kill 100 Shadow Warriors
]],
                                },

                                {
                                    id = 282,
                                    name = L"Kill 1,000 Shadow Warriors",
                                    text =
[[
"The Infiltrator"

Kill 1,000 Shadow Warriors
]],
                                },

                                {
                                    id = 283,
                                    name = L"Kill 10,000 Shadow Warriors",
                                    text =
[[
"Favored of Malekith"

Kill 10,000 Shadow Warriors
]],
                                },

                                {
                                    id = 284,
                                    name = L"Kill 100,000 Shadow Warriors",
                                    text =
[[
TROPHY : GOLDEN HIGH ELF ELIMINATOR, TWO PIPS

Kill 100,000 Shadow Warriors
]],
                                },

                            },
                        },

                        {
                            name = L"High Elf, Swordmaster",
                            entries =
                            {
                                {
                                    id = 285,
                                    name = L"Kill 25 High Elf Swordmasters",
                                    text =
[[
XP: 204

Kill 25 High Elf Swordmasters
]],
                                },

                                {
                                    id = 286,
                                    name = L"Kill 100 High Elf Swordmasters",
                                    text =
[[
XP: 500

Kill 100 High Elf Swordmasters
]],
                                },

                                {
                                    id = 287,
                                    name = L"Kill 1,000 High Elf Swordmasters",
                                    text =
[[
"Dirge Blade"

Kill 1,000 High Elf Swordmasters
]],
                                },

                                {
                                    id = 288,
                                    name = L"Kill 10,000 High Elf Swordmasters",
                                    text =
[[
"Edge Lord"

Kill 10,000 High Elf Swordmasters
]],
                                },

                                {
                                    id = 289,
                                    name = L"Kill 100,000 High Elf Swordmasters",
                                    text =
[[
TROPHY : GOLDEN HIGH ELF ELIMINATOR, TWO PIPS

Kill 100,000 High Elf Swordmasters
]],
                                },

                            },
                        },

                        {
                            name = L"High Elf, White Lion",
                            entries =
                            {
                                {
                                    id = 290,
                                    name = L"Kill 25 High Elf White Lions",
                                    text =
[[
XP: 204

Kill 25 High Elf White Lions
]],
                                },

                                {
                                    id = 291,
                                    name = L"Kill 100 High Elf White Lions",
                                    text =
[[
XP: 500

Kill 100 High Elf White Lions
]],
                                },

                                {
                                    id = 292,
                                    name = L"Kill 1,000 High Elf White Lions",
                                    text =
[[
"The Poacher"

Kill 1,000 High Elf White Lions
]],
                                },

                                {
                                    id = 293,
                                    name = L"Kill 10,000 High Elf White Lions",
                                    text =
[[
"Pride Taker"

Kill 10,000 High Elf White Lions
]],
                                },

                                {
                                    id = 294,
                                    name = L"Kill 100,000 High Elf White Lions",
                                    text =
[[
TROPHY : GOLDEN HIGH ELF ELIMINATOR, TWO PIPS

Kill 100,000 High Elf White Lions
]],
                                },

                            },
                        },

                    },
                },

                {
                    name = L"Greenskins",
                    entries =
                    {
                        {
                            name = L"Gnoblar",
                            entries =
                            {
                                {
                                    id = 295,
                                    name = L"Kill 25 Gnoblars",
                                    text =
[[
XP: 204

Kill 25 Gnoblars
]],
                                },

                                {
                                    id = 296,
                                    name = L"Kill 100 Gnoblars",
                                    text =
[[
XP: 500

Kill 100 Gnoblars
]],
                                },

                                {
                                    id = 297,
                                    name = L"Kill 1,000 Gnoblars",
                                    text =
[[
BESTIAL TOKEN

Kill 1,000 Gnoblars
]],
                                },

                                {
                                    id = 298,
                                    name = L"Kill 10,000 Gnoblars",
                                    text =
[[
"The Mighty"

Kill 10,000 Gnoblars
]],
                                },

                                {
                                    id = 299,
                                    name = L"Kill 100,000 Gnoblars",
                                    text =
[[
"The Invincible"

Kill 100,000 Gnoblars
]],
                                },

                            },
                        },

                        {
                            name = L"Goblin",
                            entries =
                            {
                                {
                                    id = 300,
                                    name = L"Kill 25 Goblins",
                                    text =
[[
XP: 204

Kill 25 Goblins
]],
                                },

                                {
                                    id = 301,
                                    name = L"Kill 100 Goblins",
                                    text =
[[
XP: 500

Kill 100 Goblins
]],
                                },

                                {
                                    id = 302,
                                    name = L"Kill 1,000 Goblins",
                                    text =
[[
TROPHY : GREENSKIN GRAPPLER, ONE PIP

Kill 1,000 Goblins
]],
                                },

                                {
                                    id = 303,
                                    name = L"Kill 10,000 Goblins",
                                    text =
[[
TROPHY : GREENSKIN GRAPPLER, TWO PIPS

Kill 10,000 Goblins
]],
                                },

                                {
                                    id = 304,
                                    name = L"Kill 100,000 Goblins",
                                    text =
[[
TROPHY : GREENSKIN GRAPPLER, THREE PIPS

Kill 100,000 Goblins
]],
                                },

                                {
                                    id = 305,
                                    name = L"Kill 1,000,000 Goblins",
                                    text =
[[
TROPHY : GOLDEN GREENSKIN GRAPPLER, THREE PIPS

Kill 1,000,000 Goblins
]],
                                },

                            },
                        },

                        {
                            name = L"Goblin, Night Goblin",
                            entries =
                            {
                                {
                                    id = 306,
                                    name = L"Kill 25 Night Goblins",
                                    text =
[[
XP: 204

Kill 25 Night Goblins
]],
                                },

                                {
                                    id = 307,
                                    name = L"Kill 100 Night Goblins",
                                    text =
[[
XP: 500

Kill 100 Night Goblins
]],
                                },

                                {
                                    id = 308,
                                    name = L"Kill 1,000 Night Goblins",
                                    text =
[[
MAN TACTIC FRAGMENT

Kill 1,000 Night Goblins
]],
                                },

                                {
                                    id = 309,
                                    name = L"Kill 10,000 Night Goblins",
                                    text =
[[
"Master Night Goblin Slayer"

Kill 10,000 Night Goblins
]],
                                },

                            },
                        },

                        {
                            name = L"Goblin, Shaman",
                            entries =
                            {
                                {
                                    id = 310,
                                    name = L"Kill 25 Goblin Shaman",
                                    text =
[[
XP: 204

Kill 25 Goblin Shaman
]],
                                },

                                {
                                    id = 311,
                                    name = L"Kill 100 Goblin Shaman",
                                    text =
[[
XP: 500

Kill 100 Goblin Shaman
]],
                                },

                                {
                                    id = 312,
                                    name = L"Kill 1,000 Goblin Shaman",
                                    text =
[[
"The Staff-Breaker"

Kill 1,000 Goblin Shaman
]],
                                },

                                {
                                    id = 313,
                                    name = L"Kill 10,000 Goblin Shaman",
                                    text =
[[
"Mork's Ruin"

Kill 10,000 Goblin Shaman
]],
                                },

                                {
                                    id = 314,
                                    name = L"Kill 100,000 Goblin Shaman",
                                    text =
[[
TROPHY : GOLDEN GREENSKIN GRAPPLER, TWO PIPS

Kill 100,000 Goblin Shaman
]],
                                },

                            },
                        },

                        {
                            name = L"Goblin, Squig Herder",
                            entries =
                            {
                                {
                                    id = 315,
                                    name = L"Kill 25 Goblin Squig Herders",
                                    text =
[[
XP: 204

Kill 25 Goblin Squig Herders
]],
                                },

                                {
                                    id = 316,
                                    name = L"Kill 100 Goblin Squig Herders",
                                    text =
[[
XP: 500

Kill 100 Goblin Squig Herders
]],
                                },

                                {
                                    id = 317,
                                    name = L"Kill 1,000 Goblin Squig Herders",
                                    text =
[[
"The Bond Breaker"

Kill 1,000 Goblin Squig Herders
]],
                                },

                                {
                                    id = 318,
                                    name = L"Kill 10,000 Goblin Squig Herders",
                                    text =
[[
"The Inedible"

Kill 10,000 Goblin Squig Herders
]],
                                },

                                {
                                    id = 319,
                                    name = L"Kill 100,000 Goblin Squig Herders",
                                    text =
[[
TROPHY : GOLDEN GREENSKIN GRAPPLER, TWO PIPS

Kill 100,000 Goblin Squig Herders
]],
                                },

                            },
                        },

                        {
                            name = L"Orc",
                            entries =
                            {
                                {
                                    id = 320,
                                    name = L"Kill 25 Orcs",
                                    text =
[[
XP: 204

Kill 25 Orcs
]],
                                },

                                {
                                    id = 321,
                                    name = L"Kill 100 Orcs",
                                    text =
[[
XP: 500

Kill 100 Orcs
]],
                                },

                                {
                                    id = 322,
                                    name = L"Kill 1,000 Orcs",
                                    text =
[[
TROPHY : GREENSKIN GRAPPLER, ONE PIP

Kill 1,000 Orcs
]],
                                },

                                {
                                    id = 323,
                                    name = L"Kill 10,000 Orcs",
                                    text =
[[
TROPHY : GREENSKIN GRAPPLER, TWO PIPS

Kill 10,000 Orcs
]],
                                },

                                {
                                    id = 324,
                                    name = L"Kill 100,000 Orcs",
                                    text =
[[
TROPHY : GREENSKIN GRAPPLER, THREE PIPS

Kill 100,000 Orcs
]],
                                },

                                {
                                    id = 325,
                                    name = L"Kill 1,000,000 Orcs",
                                    text =
[[
TROPHY : GOLDEN GREENSKIN GRAPPLER, THREE PIPS

Kill 1,000,000 Orcs
]],
                                },

                            },
                        },

                        {
                            name = L"Orc, Black Orc",
                            entries =
                            {
                                {
                                    id = 326,
                                    name = L"Kill 25 Black Orcs",
                                    text =
[[
XP: 204

Kill 25 Black Orcs
]],
                                },

                                {
                                    id = 327,
                                    name = L"Kill 100 Black Orcs",
                                    text =
[[
XP: 500

Kill 100 Black Orcs
]],
                                },

                                {
                                    id = 328,
                                    name = L"Kill 1,000 Black Orcs",
                                    text =
[[
"Dead 'Ard"

Kill 1,000 Black Orcs
]],
                                },

                                {
                                    id = 329,
                                    name = L"Kill 10,000 Black Orcs",
                                    text =
[[
"The Unstoppable"

Kill 10,000 Black Orcs
]],
                                },

                                {
                                    id = 330,
                                    name = L"Kill 100,000 Black Orcs",
                                    text =
[[
TROPHY : GOLDEN GREENSKIN GRAPPLER, TWO PIPS

Kill 100,000 Black Orcs
]],
                                },

                            },
                        },

                        {
                            name = L"Orc, Choppa",
                            entries =
                            {
                                {
                                    id = 331,
                                    name = L"Kill 25 Orc Choppas",
                                    text =
[[
XP: 204

Kill 25 Orc Choppas
]],
                                },

                                {
                                    id = 332,
                                    name = L"Kill 100 Orc Choppas",
                                    text =
[[
XP: 500

Kill 100 Orc Choppas
]],
                                },

                                {
                                    id = 333,
                                    name = L"Kill 1,000 Orc Choppas",
                                    text =
[[
"Chop Suey"

Kill 1,000 Orc Choppas
]],
                                },

                                {
                                    id = 334,
                                    name = L"Kill 10,000 Orc Choppas",
                                    text =
[[
"I Stopped the Chop"

Kill 10,000 Orc Choppas
]],
                                },

                                {
                                    id = 335,
                                    name = L"Kill 100,000 Orc Choppas",
                                    text =
[[
TROPHY : GOLDEN GREENSKIN GRAPPLER, TWO PIPS

Kill 100,000 Orc Choppas
]],
                                },

                            },
                        },

                        {
                            name = L"Orc, Savage Orc",
                            entries =
                            {
                                {
                                    id = 336,
                                    name = L"Kill 25 Savage Orcs",
                                    text =
[[
XP: 204

Kill 25 Savage Orcs
]],
                                },

                                {
                                    id = 337,
                                    name = L"Kill 100 Savage Orcs",
                                    text =
[[
XP: 500

Kill 100 Savage Orcs
]],
                                },

                                {
                                    id = 338,
                                    name = L"Kill 1,000 Savage Orcs",
                                    text =
[[
GREENSKIN TACTIC FRAGMENT

Kill 1,000 Savage Orcs
]],
                                },

                                {
                                    id = 339,
                                    name = L"Kill 10,000 Savage Orcs",
                                    text =
[[
"Master Savage Orc Slayer"

Kill 10,000 Savage Orcs
]],
                                },

                            },
                        },

                        {
                            name = L"Snotling",
                            entries =
                            {
                                {
                                    id = 340,
                                    name = L"Kill 25 Snotlings",
                                    text =
[[
XP: 204

Kill 25 Snotlings
]],
                                },

                                {
                                    id = 341,
                                    name = L"Kill 100 Snotlings",
                                    text =
[[
XP: 500

Kill 100 Snotlings
]],
                                },

                                {
                                    id = 342,
                                    name = L"Kill 1,000 Snotlings",
                                    text =
[[
BESTIAL TOKEN

Kill 1,000 Snotlings
]],
                                },

                                {
                                    id = 343,
                                    name = L"Kill 10,000 Snotlings",
                                    text =
[[
"The Weird"

Kill 10,000 Snotlings
]],
                                },

                                {
                                    id = 344,
                                    name = L"Kill 100,000 Snotlings",
                                    text =
[[
"Killer of a Thousand Snotlings"

Kill 100,000 Snotlings
]],
                                },

                            },
                        },

                        {
                            name = L"Squig",
                            entries =
                            {
                                {
                                    id = 345,
                                    name = L"Kill 25 Squigs",
                                    text =
[[
XP: 204

Kill 25 Squigs
]],
                                },

                                {
                                    id = 346,
                                    name = L"Kill 100 Squigs",
                                    text =
[[
XP: 500

Kill 100 Squigs
]],
                                },

                                {
                                    id = 347,
                                    name = L"Kill 1,000 Squigs",
                                    text =
[[
"The Squig Squisher"

Kill 1,000 Squigs
]],
                                },

                                {
                                    id = 348,
                                    name = L"Kill 10,000 Squigs",
                                    text =
[[
BESTIAL TACTIC FRAGMENT

Kill 10,000 Squigs
]],
                                },

                                {
                                    id = 349,
                                    name = L"Kill 100,000 Squigs",
                                    text =
[[
BACK ITEM : FANG HOPPER'S HIDE

Kill 100,000 Squigs
]],
                                },

                            },
                        },

                    },
                },

                {
                    name = L"Humans",
                    entries =
                    {
                        {
                            name = L"Bandit",
                            entries =
                            {
                                {
                                    id = 350,
                                    name = L"Kill 25 Bandits",
                                    text =
[[
XP: 204

Kill 25 Bandits
]],
                                },

                                {
                                    id = 351,
                                    name = L"Kill 100 Bandits",
                                    text =
[[
XP: 500

Kill 100 Bandits
]],
                                },

                                {
                                    id = 352,
                                    name = L"Kill 1,000 Bandits",
                                    text =
[[
BESTIAL TOKEN

Kill 1,000 Bandits
]],
                                },

                                {
                                    id = 353,
                                    name = L"Kill 10,000 Bandits",
                                    text =
[[
"The Man Hunter"

Kill 10,000 Bandits
]],
                                },

                                {
                                    id = 354,
                                    name = L"Kill 100,000 Bandits",
                                    text =
[[
"The Law"

Kill 100,000 Bandits
]],
                                },

                            },
                        },

                        {
                            name = L"Chaos",
                            entries =
                            {
                                {
                                    id = 355,
                                    name = L"Kill 25 servants of Chaos",
                                    text =
[[
XP: 204

Kill 25 servants of Chaos
]],
                                },

                                {
                                    id = 356,
                                    name = L"Kill 100 servants of Chaos",
                                    text =
[[
XP: 500

Kill 100 servants of Chaos
]],
                                },

                                {
                                    id = 357,
                                    name = L"Kill 1,000 servants of Chaos",
                                    text =
[[
TROPHY : CHAOS CLEANSER, ONE PIP

Kill 1,000 servants of Chaos
]],
                                },

                                {
                                    id = 358,
                                    name = L"Kill 10,000 servants of Chaos",
                                    text =
[[
TROPHY : CHAOS CLEANSER, TWO PIPS

Kill 10,000 servants of Chaos
]],
                                },

                                {
                                    id = 359,
                                    name = L"Kill 100,000 servants of Chaos",
                                    text =
[[
TROPHY : CHAOS CLEANSER, THREE PIPS

Kill 100,000 servants of Chaos
]],
                                },

                                {
                                    id = 360,
                                    name = L"Kill 1,000,000 servants of Chaos",
                                    text =
[[
TROPHY : GOLDEN CHAOS CLEANSER, THREE PIPS

Kill 1,000,000 servants of Chaos
]],
                                },

                            },
                        },

                        {
                            name = L"Chaos, Chosen",
                            entries =
                            {
                                {
                                    id = 361,
                                    name = L"Kill 25 Chaos Chosen",
                                    text =
[[
XP: 204

Kill 25 Chaos Chosen
]],
                                },

                                {
                                    id = 362,
                                    name = L"Kill 100 Chaos Chosen",
                                    text =
[[
XP: 500

Kill 100 Chaos Chosen
]],
                                },

                                {
                                    id = 363,
                                    name = L"Kill 1,000 Chaos Chosen",
                                    text =
[[
"The Decider"

Kill 1,000 Chaos Chosen
]],
                                },

                                {
                                    id = 364,
                                    name = L"Kill 10,000 Chaos Chosen",
                                    text =
[[
"The Arbitrator"

Kill 10,000 Chaos Chosen
]],
                                },

                                {
                                    id = 365,
                                    name = L"Kill 100,000 Chaos Chosen",
                                    text =
[[
TROPHY : GOLDEN CHAOS CLEANSER, TWO PIPS

Kill 100,000 Chaos Chosen
]],
                                },

                            },
                        },

                        {
                            name = L"Chaos, Magus",
                            entries =
                            {
                                {
                                    id = 366,
                                    name = L"Kill 25 Magi of Chaos",
                                    text =
[[
XP: 204

Kill 25 Magi of Chaos
]],
                                },

                                {
                                    id = 367,
                                    name = L"Kill 100 Magi of Chaos",
                                    text =
[[
XP: 500

Kill 100 Magi of Chaos
]],
                                },

                                {
                                    id = 368,
                                    name = L"Kill 1,000 Magi of Chaos",
                                    text =
[[
"The Toppler"

Kill 1,000 Magi of Chaos
]],
                                },

                                {
                                    id = 369,
                                    name = L"Kill 10,000 Magi of Chaos",
                                    text =
[[
"The Overthrower"

Kill 10,000 Magi of Chaos
]],
                                },

                                {
                                    id = 370,
                                    name = L"Kill 100,000 Magi of Chaos",
                                    text =
[[
TROPHY : GOLDEN CHAOS CLEANSER, TWO PIPS

Kill 100,000 Magi of Chaos
]],
                                },

                            },
                        },

                        {
                            name = L"Chaos, Marauder",
                            entries =
                            {
                                {
                                    id = 371,
                                    name = L"Kill 25 Marauders of Chaos",
                                    text =
[[
XP: 204

Kill 25 Marauders of Chaos
]],
                                },

                                {
                                    id = 372,
                                    name = L"Kill 100 Marauders of Chaos",
                                    text =
[[
XP: 500

Kill 100 Marauders of Chaos
]],
                                },

                                {
                                    id = 373,
                                    name = L"Kill 1,000 Marauders of Chaos",
                                    text =
[[
"The Limb Taker"

Kill 1,000 Marauders of Chaos
]],
                                },

                                {
                                    id = 374,
                                    name = L"Kill 10,000 Marauders of Chaos",
                                    text =
[[
"The Amputator"

Kill 10,000 Marauders of Chaos
]],
                                },

                                {
                                    id = 375,
                                    name = L"Kill 100,000 Marauders of Chaos",
                                    text =
[[
TROPHY : GOLDEN CHAOS CLEANSER, TWO PIPS

Kill 100,000 Marauders of Chaos
]],
                                },

                            },
                        },

                        {
                            name = L"Chaos, Zealot",
                            entries =
                            {
                                {
                                    id = 376,
                                    name = L"Kill 25 Zealots of Chaos",
                                    text =
[[
XP: 204

Kill 25 Zealots of Chaos
]],
                                },

                                {
                                    id = 377,
                                    name = L"Kill 100 Zealots of Chaos",
                                    text =
[[
XP: 500

Kill 100 Zealots of Chaos
]],
                                },

                                {
                                    id = 378,
                                    name = L"Kill 1,000 Zealots of Chaos",
                                    text =
[[
"The Blessed"

Kill 1,000 Zealots of Chaos
]],
                                },

                                {
                                    id = 379,
                                    name = L"Kill 10,000 Zealots of Chaos",
                                    text =
[[
"The Exhalted"

Kill 10,000 Zealots of Chaos
]],
                                },

                                {
                                    id = 380,
                                    name = L"Kill 100,000 Zealots of Chaos",
                                    text =
[[
TROPHY : GOLDEN CHAOS CLEANSER, TWO PIPS

Kill 100,000 Zealots of Chaos
]],
                                },

                            },
                        },

                        {
                            name = L"Drakk Cultist",
                            entries =
                            {
                                {
                                    id = 381,
                                    name = L"Kill 25 Cultists",
                                    text =
[[
XP: 204

Kill 25 Cultists
]],
                                },

                                {
                                    id = 382,
                                    name = L"Kill 100 Cultists",
                                    text =
[[
XP: 500

Kill 100 Cultists
]],
                                },

                                {
                                    id = 383,
                                    name = L"Kill 1,000 Cultists",
                                    text =
[[
BESTIAL TOKEN

Kill 1,000 Cultists
]],
                                },

                                {
                                    id = 384,
                                    name = L"Kill 10,000 Cultists",
                                    text =
[[
"Persecutor"

Kill 10,000 Cultists
]],
                                },

                                {
                                    id = 385,
                                    name = L"Kill 100,000 Cultists",
                                    text =
[[
"Drakk Demolisher"

Kill 100,000 Cultists
]],
                                },

                            },
                        },

                        {
                            name = L"Empire",
                            entries =
                            {
                                {
                                    id = 386,
                                    name = L"Kill 25 members of the Empire",
                                    text =
[[
XP: 204

Kill 25 members of the Empire
]],
                                },

                                {
                                    id = 387,
                                    name = L"Kill 100 members of the Empire",
                                    text =
[[
XP: 500

Kill 100 members of the Empire
]],
                                },

                                {
                                    id = 388,
                                    name = L"Kill 1,000 members of the Empire",
                                    text =
[[
TROPHY : EMPIRE ERADICATOR, ONE PIP

Kill 1,000 members of the Empire
]],
                                },

                                {
                                    id = 389,
                                    name = L"Kill 10,000 members of the Empire",
                                    text =
[[
TROPHY : EMPIRE ERADICATOR, TWO PIPS

Kill 10,000 members of the Empire
]],
                                },

                                {
                                    id = 390,
                                    name = L"Kill 100,000 members of the Empire",
                                    text =
[[
TROPHY : EMPIRE ERADICATOR, THREE PIPS

Kill 100,000 members of the Empire
]],
                                },

                                {
                                    id = 391,
                                    name = L"Kill 1,000,000 members of the Empire",
                                    text =
[[
TROPHY : GOLDEN EMPIRE ERADICATOR, THREE PIPS

Kill 1,000,000 members of the Empire
]],
                                },

                            },
                        },

                        {
                            name = L"Empire, Bright Wizard",
                            entries =
                            {
                                {
                                    id = 392,
                                    name = L"Kill 25 Bright Wizards",
                                    text =
[[
XP: 204

Kill 25 Bright Wizards
]],
                                },

                                {
                                    id = 393,
                                    name = L"Kill 100 Bright Wizards",
                                    text =
[[
XP: 500

Kill 100 Bright Wizards
]],
                                },

                                {
                                    id = 394,
                                    name = L"Kill 1,000 Bright Wizards",
                                    text =
[[
"The Wild"

Kill 1,000 Bright Wizards
]],
                                },

                                {
                                    id = 395,
                                    name = L"Kill 10,000 Bright Wizards",
                                    text =
[[
"The Feral"

Kill 10,000 Bright Wizards
]],
                                },

                                {
                                    id = 396,
                                    name = L"Kill 100,000 Bright Wizards",
                                    text =
[[
TROPHY : GOLDEN EMPIRE ERADICATOR, TWO PIPS

Kill 100,000 Bright Wizards
]],
                                },

                            },
                        },

                        {
                            name = L"Empire, Knight of the Blazing Sun",
                            entries =
                            {
                                {
                                    id = 397,
                                    name = L"Kill 25 Knights of the Blazing Sun",
                                    text =
[[
XP: 204

Kill 25 Knights of the Blazing Sun
]],
                                },

                                {
                                    id = 398,
                                    name = L"Kill 100 Knights of the Blazing Sun",
                                    text =
[[
XP: 500

Kill 100 Knights of the Blazing Sun
]],
                                },

                                {
                                    id = 399,
                                    name = L"Kill 1,000 Knights of the Blazing Sun",
                                    text =
[[
"Tank Buster"

Kill 1,000 Knights of the Blazing Sun
]],
                                },

                                {
                                    id = 400,
                                    name = L"Kill 10,000 Knights of the Blazing Sun",
                                    text =
[[
"Myrmidia's Bane"

Kill 10,000 Knights of the Blazing Sun
]],
                                },

                                {
                                    id = 401,
                                    name = L"Kill 100,000 Knights of the Blazing Sun",
                                    text =
[[
TROPHY : GOLDEN EMPIRE ERADICATOR, TWO PIPS

Kill 100,000 Knights of the Blazing Sun
]],
                                },

                            },
                        },

                        {
                            name = L"Empire, Warrior Priest",
                            entries =
                            {
                                {
                                    id = 402,
                                    name = L"Kill 25 Warrior Priests",
                                    text =
[[
XP: 204

Kill 25 Warrior Priests
]],
                                },

                                {
                                    id = 403,
                                    name = L"Kill 100 Warrior Priests",
                                    text =
[[
XP: 500

Kill 100 Warrior Priests
]],
                                },

                                {
                                    id = 404,
                                    name = L"Kill 1,000 Warrior Priests",
                                    text =
[[
"The Ruthless"

Kill 1,000 Warrior Priests
]],
                                },

                                {
                                    id = 405,
                                    name = L"Kill 10,000 Warrior Priests",
                                    text =
[[
"The Merciless"

Kill 10,000 Warrior Priests
]],
                                },

                                {
                                    id = 406,
                                    name = L"Kill 100,000 Warrior Priests",
                                    text =
[[
TROPHY : GOLDEN EMPIRE ERADICATOR, TWO PIPS

Kill 100,000 Warrior Priests
]],
                                },

                            },
                        },

                        {
                            name = L"Empire, Witch Hunter",
                            entries =
                            {
                                {
                                    id = 407,
                                    name = L"Kill 25 Witch Hunters",
                                    text =
[[
XP: 204

Kill 25 Witch Hunters
]],
                                },

                                {
                                    id = 408,
                                    name = L"Kill 100 Witch Hunters",
                                    text =
[[
XP: 500

Kill 100 Witch Hunters
]],
                                },

                                {
                                    id = 409,
                                    name = L"Kill 1,000 Witch Hunters",
                                    text =
[[
"The Cursed"

Kill 1,000 Witch Hunters
]],
                                },

                                {
                                    id = 410,
                                    name = L"Kill 10,000 Witch Hunters",
                                    text =
[[
"The Damned"

Kill 10,000 Witch Hunters
]],
                                },

                                {
                                    id = 411,
                                    name = L"Kill 100,000 Witch Hunters",
                                    text =
[[
TROPHY : GOLDEN EMPIRE ERADICATOR, TWO PIPS

Kill 100,000 Witch Hunters
]],
                                },

                            },
                        },

                        {
                            name = L"Ghoul",
                            entries =
                            {
                                {
                                    id = 412,
                                    name = L"Kill 25 Ghouls",
                                    text =
[[
XP: 204

Kill 25 Ghouls
]],
                                },

                                {
                                    id = 413,
                                    name = L"Kill 100 Ghouls",
                                    text =
[[
XP: 500

Kill 100 Ghouls
]],
                                },

                                {
                                    id = 414,
                                    name = L"Kill 1,000 Ghouls",
                                    text =
[[
BESTIAL TOKEN

Kill 1,000 Ghouls
]],
                                },

                                {
                                    id = 415,
                                    name = L"Kill 10,000 Ghouls",
                                    text =
[[
"Flesheater's Nemesis"

Kill 10,000 Ghouls
]],
                                },

                                {
                                    id = 416,
                                    name = L"Kill 100,000 Ghouls",
                                    text =
[[
XP: 1974

Kill 100,000 Ghouls
]],
                                },

                            },
                        },

                        {
                            name = L"Plague Victim",
                            entries =
                            {
                                {
                                    id = 417,
                                    name = L"Kill 25 Plague Victims",
                                    text =
[[
XP: 204

Kill 25 Plague Victims
]],
                                },

                                {
                                    id = 418,
                                    name = L"Kill 100 Plague Victims",
                                    text =
[[
XP: 500

Kill 100 Plague Victims
]],
                                },

                                {
                                    id = 419,
                                    name = L"Kill 1,000 Plague Victims",
                                    text =
[[
BESTIAL TOKEN

Kill 1,000 Plague Victims
]],
                                },

                                {
                                    id = 420,
                                    name = L"Kill 10,000 Plague Victims",
                                    text =
[[
"The Humane"

Kill 10,000 Plague Victims
]],
                                },

                                {
                                    id = 421,
                                    name = L"Kill 100,000 Plague Victims",
                                    text =
[[
"The Compassionate"

Kill 100,000 Plague Victims
]],
                                },

                            },
                        },

                    },
                },

                {
                    name = L"Ogres",
                    entries =
                    {
                        {
                            name = L"Gorger",
                            entries =
                            {
                                {
                                    id = 422,
                                    name = L"Kill 25 Gorgers",
                                    text =
[[
XP: 204

Kill 25 Gorgers
]],
                                },

                                {
                                    id = 423,
                                    name = L"Kill 100 Gorgers",
                                    text =
[[
XP: 500

Kill 100 Gorgers
]],
                                },

                                {
                                    id = 424,
                                    name = L"Kill 1,000 Gorgers",
                                    text =
[[
GIANT TACTIC FRAGMENT

Kill 1,000 Gorgers
]],
                                },

                                {
                                    id = 425,
                                    name = L"Kill 10,000 Gorgers",
                                    text =
[[
"Master Gorger Slayer"

Kill 10,000 Gorgers
]],
                                },

                            },
                        },

                        {
                            name = L"Ogre, Bull",
                            entries =
                            {
                                {
                                    id = 426,
                                    name = L"Kill 25 Ogre Bulls",
                                    text =
[[
XP: 204

Kill 25 Ogre Bulls
]],
                                },

                                {
                                    id = 427,
                                    name = L"Kill 100 Ogre Bulls",
                                    text =
[[
XP: 500

Kill 100 Ogre Bulls
]],
                                },

                                {
                                    id = 428,
                                    name = L"Kill 1,000 Ogre Bulls",
                                    text =
[[
BESTIAL TOKEN

Kill 1,000 Ogre Bulls
]],
                                },

                                {
                                    id = 429,
                                    name = L"Kill 10,000 Ogre Bulls",
                                    text =
[[
"The Big"

Kill 10,000 Ogre Bulls
]],
                                },

                                {
                                    id = 430,
                                    name = L"Kill 100,000 Ogre Bulls",
                                    text =
[[
"The Pulverizer"

Kill 100,000 Ogre Bulls
]],
                                },

                            },
                        },

                        {
                            name = L"Ogre, Butcher",
                            entries =
                            {
                                {
                                    id = 431,
                                    name = L"Kill 25 Ogre Butchers",
                                    text =
[[
XP: 204

Kill 25 Ogre Butchers
]],
                                },

                                {
                                    id = 432,
                                    name = L"Kill 100 Ogre Butchers",
                                    text =
[[
XP: 500

Kill 100 Ogre Butchers
]],
                                },

                            },
                        },

                        {
                            name = L"Ogre, Tyrant",
                            entries =
                            {
                                {
                                    id = 433,
                                    name = L"Kill 25 Ogre Tyrants",
                                    text =
[[
XP: 336

Kill 25 Ogre Tyrants
]],
                                },

                                {
                                    id = 434,
                                    name = L"Kill 100 Ogre Tyrants",
                                    text =
[[
XP: 500

Kill 100 Ogre Tyrants
]],
                                },

                                {
                                    id = 435,
                                    name = L"Kill 1,000 Ogre Tyrants",
                                    text =
[[
GIANT TACTIC FRAGMENT

Kill 1,000 Ogre Tyrants
]],
                                },

                                {
                                    id = 436,
                                    name = L"Kill 10,000 Ogre Tyrants",
                                    text =
[[
"Master Ogre Tyrant Slayer"

Kill 10,000 Ogre Tyrants
]],
                                },

                            },
                        },

                        {
                            name = L"Yhetee",
                            entries =
                            {
                                {
                                    id = 437,
                                    name = L"Kill 25 Yhetee",
                                    text =
[[
XP: 204

Kill 25 Yhetee
]],
                                },

                                {
                                    id = 438,
                                    name = L"Kill 100 Yhetee",
                                    text =
[[
XP: 500

Kill 100 Yhetee
]],
                                },

                                {
                                    id = 439,
                                    name = L"Kill 1,000 Yhetee",
                                    text =
[[
GIANT TACTIC FRAGMENT

Kill 1,000 Yhetee
]],
                                },

                                {
                                    id = 440,
                                    name = L"Kill 10,000 Yhetee",
                                    text =
[[
"Master Yhetee Slayer"

Kill 10,000 Yhetee
]],
                                },

                            },
                        },

                    },
                },

                {
                    name = L"Skaven",
                    entries =
                    {
                        {
                            name = L"Rat Ogre",
                            entries =
                            {
                                {
                                    id = 441,
                                    name = L"Kill 25 Rat Ogres",
                                    text =
[[
XP: 336

Kill 25 Rat Ogres
]],
                                },

                                {
                                    id = 442,
                                    name = L"Kill 100 Rat Ogres",
                                    text =
[[
XP: 500

Kill 100 Rat Ogres
]],
                                },

                                {
                                    id = 443,
                                    name = L"Kill 1,000 Rat Ogres",
                                    text =
[[
SKAVEN TACTIC FRAGMENT

Kill 1,000 Rat Ogres
]],
                                },

                                {
                                    id = 444,
                                    name = L"Kill 10,000 Rat Ogres",
                                    text =
[[
"Master Rat Ogre Slayer"

Kill 10,000 Rat Ogres
]],
                                },

                            },
                        },

                        {
                            name = L"Skaven",
                            entries =
                            {
                                {
                                    id = 445,
                                    name = L"Kill 25 Skaven",
                                    text =
[[
XP: 204

Kill 25 Skaven
]],
                                },

                                {
                                    id = 446,
                                    name = L"Kill 100 Skaven",
                                    text =
[[
XP: 500

Kill 100 Skaven
]],
                                },

                                {
                                    id = 447,
                                    name = L"Kill 1,000 Skaven",
                                    text =
[[
BESTIAL TOKEN

Kill 1,000 Skaven
]],
                                },

                                {
                                    id = 448,
                                    name = L"Kill 10,000 Skaven",
                                    text =
[[
"Tunnel Stalker"

Kill 10,000 Skaven
]],
                                },

                                {
                                    id = 449,
                                    name = L"Kill 100,000 Skaven",
                                    text =
[[
"Skavenbane"

Kill 100,000 Skaven
]],
                                },

                            },
                        },

                    },
                },

            },
        },

        {
            name = L"Monsters",
            entries =
            {
                {
                    name = L"Chaos Breeds",
                    entries =
                    {
                        {
                            name = L"Centigor",
                            entries =
                            {
                                {
                                    id = 450,
                                    name = L"Kill 25 Centigors",
                                    text =
[[
XP: 336

Kill 25 Centigors
]],
                                },

                                {
                                    id = 451,
                                    name = L"Kill 100 Centigors",
                                    text =
[[
XP: 500

Kill 100 Centigors
]],
                                },

                                {
                                    id = 452,
                                    name = L"Kill 1,000 Centigors",
                                    text =
[[
POCKET : ALE BARREL LID SHIELD

Kill 1,000 Centigors
]],
                                },

                                {
                                    id = 453,
                                    name = L"Kill 10,000 Centigors",
                                    text =
[[
"Master Centigor Slayer"

Kill 10,000 Centigors
]],
                                },

                            },
                        },

                        {
                            name = L"Chaos Mutant",
                            entries =
                            {
                                {
                                    id = 454,
                                    name = L"Kill 25 Chaos Mutants",
                                    text =
[[
XP: 204

Kill 25 Chaos Mutants
]],
                                },

                                {
                                    id = 455,
                                    name = L"Kill 100 Chaos Mutants",
                                    text =
[[
XP: 500

Kill 100 Chaos Mutants
]],
                                },

                                {
                                    id = 456,
                                    name = L"Kill 1,000 Chaos Mutants",
                                    text =
[[
CHAOS TACTIC FRAGMENT

Kill 1,000 Chaos Mutants
]],
                                },

                                {
                                    id = 457,
                                    name = L"Kill 10,000 Chaos Mutants",
                                    text =
[[
"Master Chaos Mutant Slayer"

Kill 10,000 Chaos Mutants
]],
                                },

                            },
                        },

                        {
                            name = L"Dark Pegasus",
                            entries =
                            {
                                {
                                    id = 458,
                                    name = L"Kill 25 Dark Pegasi",
                                    text =
[[
XP: 204

Kill 25 Dark Pegasi
]],
                                },

                                {
                                    id = 459,
                                    name = L"Kill 100 Dark Pegasi",
                                    text =
[[
XP: 500

Kill 100 Dark Pegasi
]],
                                },

                            },
                        },

                        {
                            name = L"Dragon Ogre",
                            entries =
                            {
                                {
                                    id = 460,
                                    name = L"Kill 25 Dragon Ogres",
                                    text =
[[
XP: 336

Kill 25 Dragon Ogres
]],
                                },

                                {
                                    id = 461,
                                    name = L"Kill 100 Dragon Ogres",
                                    text =
[[
XP: 500

Kill 100 Dragon Ogres
]],
                                },

                                {
                                    id = 462,
                                    name = L"Kill 1,000 Dragon Ogres",
                                    text =
[[
CHAOS TACTIC FRAGMENT

Kill 1,000 Dragon Ogres
]],
                                },

                                {
                                    id = 463,
                                    name = L"Kill 10,000 Dragon Ogres",
                                    text =
[[
"Master Dragon Ogre Slayer"

Kill 10,000 Dragon Ogres
]],
                                },

                            },
                        },

                        {
                            name = L"Flayerkin",
                            entries =
                            {
                                {
                                    id = 464,
                                    name = L"Kill 25 Flayerkin",
                                    text =
[[
XP: 336

Kill 25 Flayerkin
]],
                                },

                                {
                                    id = 465,
                                    name = L"Kill 100 Flayerkin",
                                    text =
[[
XP: 500

Kill 100 Flayerkin
]],
                                },

                                {
                                    id = 466,
                                    name = L"Kill 1,000 Flayerkin",
                                    text =
[[
CHAOS TACTIC FRAGMENT

Kill 1,000 Flayerkin
]],
                                },

                                {
                                    id = 467,
                                    name = L"Kill 10,000 Flayerkin",
                                    text =
[[
"Master Flayerkin Slayer"

Kill 10,000 Flayerkin
]],
                                },

                            },
                        },

                        {
                            name = L"Giant Leech",
                            entries =
                            {
                                {
                                    id = 468,
                                    name = L"Kill 25 Giant Leeches",
                                    text =
[[
XP: 204

Kill 25 Giant Leeches
]],
                                },

                                {
                                    id = 469,
                                    name = L"Kill 100 Giant Leeches",
                                    text =
[[
XP: 500

Kill 100 Giant Leeches
]],
                                },

                                {
                                    id = 470,
                                    name = L"Kill 1,000 Giant Leeches",
                                    text =
[[
???

Kill 1,000 Giant Leeches
]],
                                },

                            },
                        },

                        {
                            name = L"Harpy",
                            entries =
                            {
                                {
                                    id = 471,
                                    name = L"Kill 25 Harpies",
                                    text =
[[
XP: 204

Kill 25 Harpies
]],
                                },

                                {
                                    id = 472,
                                    name = L"Kill 100 Harpies",
                                    text =
[[
XP: 500

Kill 100 Harpies
]],
                                },

                                {
                                    id = 473,
                                    name = L"Kill 1,000 Harpies",
                                    text =
[[
BESTIAL TOKEN

Kill 1,000 Harpies
]],
                                },

                                {
                                    id = 474,
                                    name = L"Kill 10,000 Harpies",
                                    text =
[[
"Deathtalon Foe"

Kill 10,000 Harpies
]],
                                },

                                {
                                    id = 475,
                                    name = L"Kill 100,000 Harpies",
                                    text =
[[
"Clawtaker"

Kill 100,000 Harpies
]],
                                },

                            },
                        },

                        {
                            name = L"Maggot",
                            entries =
                            {
                                {
                                    id = 476,
                                    name = L"Kill 25 Maggots",
                                    text =
[[
XP: 204

Kill 25 Maggots
]],
                                },

                                {
                                    id = 477,
                                    name = L"Kill 100 Maggots",
                                    text =
[[
XP: 500

Kill 100 Maggots
]],
                                },

                                {
                                    id = 478,
                                    name = L"Kill 1,000 Maggots",
                                    text =
[[
CHAOS TACTIC FRAGMENT

Kill 1,000 Maggots
]],
                                },

                                {
                                    id = 479,
                                    name = L"Kill 10,000 Maggots",
                                    text =
[[
"Master of Maggots"

Kill 10,000 Maggots
]],
                                },

                            },
                        },

                        {
                            name = L"Tuskgor",
                            entries =
                            {
                                {
                                    id = 480,
                                    name = L"Kill 25 Tuskgors",
                                    text =
[[
XP: 204

Kill 25 Tuskgors
]],
                                },

                                {
                                    id = 481,
                                    name = L"Kill 100 Tuskgors",
                                    text =
[[
XP: 500

Kill 100 Tuskgors
]],
                                },

                                {
                                    id = 482,
                                    name = L"Kill 1,000 Tuskgors",
                                    text =
[[
POCKET : TUSKGOR SADDLE

Kill 1,000 Tuskgors
]],
                                },

                                {
                                    id = 483,
                                    name = L"Kill 10,000 Tuskgors",
                                    text =
[[
"The Wildtusk Foe"

Kill 10,000 Tuskgors
]],
                                },

                                {
                                    id = 484,
                                    name = L"Kill 100,000 Tuskgors",
                                    text =
[[
"Tuskbreaker"

Kill 100,000 Tuskgors
]],
                                },

                            },
                        },

                    },
                },

                {
                    name = L"Dragonoids",
                    entries =
                    {
                        {
                            name = L"Dragon",
                            entries =
                            {
                                {
                                    id = 485,
                                    name = L"Kill 25 Dragons",
                                    text =
[[
XP: 336

Kill 25 Dragons
]],
                                },

                                {
                                    id = 486,
                                    name = L"Kill 100 Dragons",
                                    text =
[[
XP: 500

Kill 100 Dragons
]],
                                },

                                {
                                    id = 487,
                                    name = L"Kill 1,000 Dragons",
                                    text =
[[
BACK ITEM : MANTLE OF THE FIREBORN

Kill 1,000 Dragons
]],
                                },

                                {
                                    id = 488,
                                    name = L"Kill 10,000 Dragons",
                                    text =
[[
"Master Dragon Slayer"

Kill 10,000 Dragons
]],
                                },

                            },
                        },

                        {
                            name = L"Hydra",
                            entries =
                            {
                                {
                                    id = 489,
                                    name = L"Kill 25 Hydras",
                                    text =
[[
XP: 336

Kill 25 Hydras
]],
                                },

                                {
                                    id = 490,
                                    name = L"Kill 100 Hydra",
                                    text =
[[
XP: 500

Kill 100 Hydra
]],
                                },

                                {
                                    id = 491,
                                    name = L"Kill 1,000 Hydra",
                                    text =
[[
MYTHICAL TACTIC FRAGMENT

Kill 1,000 Hydra
]],
                                },

                                {
                                    id = 492,
                                    name = L"Kill 10,000 Hydra",
                                    text =
[[
"Master Hydra Slayer"

Kill 10,000 Hydra
]],
                                },

                            },
                        },

                        {
                            name = L"Wyvern",
                            entries =
                            {
                                {
                                    id = 493,
                                    name = L"Kill 25 Wyvern",
                                    text =
[[
XP: 204

Kill 25 Wyvern
]],
                                },

                                {
                                    id = 494,
                                    name = L"Kill 100 Wyvern",
                                    text =
[[
XP: 500

Kill 100 Wyvern
]],
                                },

                                {
                                    id = 495,
                                    name = L"Kill 1,000 Wyvern",
                                    text =
[[
MYTHICAL TACTIC FRAGMENT

Kill 1,000 Wyvern
]],
                                },

                                {
                                    id = 496,
                                    name = L"Kill 10,000 Wyvern",
                                    text =
[[
"Master Wyvern Slayer"

Kill 10,000 Wyvern
]],
                                },

                            },
                        },

                    },
                },

                {
                    name = L"Giants",
                    entries =
                    {
                        {
                            name = L"Giant",
                            entries =
                            {
                                {
                                    id = 497,
                                    name = L"Kill 25 Giants",
                                    text =
[[
XP: 204

Kill 25 Giants
]],
                                },

                                {
                                    id = 498,
                                    name = L"Kill 100 Giants",
                                    text =
[[
XP: 500

Kill 100 Giants
]],
                                },

                                {
                                    id = 499,
                                    name = L"Kill 1,000 Giants",
                                    text =
[[
BESTIAL TOKEN

Kill 1,000 Giants
]],
                                },

                                {
                                    id = 500,
                                    name = L"Kill 10,000 Giants",
                                    text =
[[
"The Giant Slayer"

Kill 10,000 Giants
]],
                                },

                                {
                                    id = 501,
                                    name = L"Kill 100,000 Giants",
                                    text =
[[
"Bane of the Sky Titans"

Kill 100,000 Giants
]],
                                },

                            },
                        },

                        {
                            name = L"Giant, Chaos",
                            entries =
                            {
                                {
                                    id = 502,
                                    name = L"Kill 25 Chaos Giants",
                                    text =
[[
XP: 336

Kill 25 Chaos Giants
]],
                                },

                                {
                                    id = 503,
                                    name = L"Kill 100 Chaos Giants",
                                    text =
[[
XP: 500

Kill 100 Chaos Giants
]],
                                },

                                {
                                    id = 504,
                                    name = L"Kill 1,000 Chaos Giants",
                                    text =
[[
GIANT TACTIC FRAGMENT

Kill 1,000 Chaos Giants
]],
                                },

                                {
                                    id = 505,
                                    name = L"Kill 10,000 Chaos Giants",
                                    text =
[[
"Master Chaos Giant Slayer"

Kill 10,000 Chaos Giants
]],
                                },

                            },
                        },

                    },
                },

                {
                    name = L"Magical Beasts",
                    entries =
                    {
                        {
                            name = L"Cockatrice",
                            entries =
                            {
                                {
                                    id = 506,
                                    name = L"Kill 25 Cockatrice",
                                    text =
[[
XP: 204

Kill 25 Cockatrice
]],
                                },

                                {
                                    id = 507,
                                    name = L"Kill 100 Cockatrice",
                                    text =
[[
XP: 500

Kill 100 Cockatrice
]],
                                },

                                {
                                    id = 508,
                                    name = L"Kill 1,000 Cockatrice",
                                    text =
[[
MYTHICAL TACTIC FRAGMENT

Kill 1,000 Cockatrice
]],
                                },

                                {
                                    id = 509,
                                    name = L"Kill 10,000 Cockatrice",
                                    text =
[[
"Master Cockatrice Slayer"

Kill 10,000 Cockatrice
]],
                                },

                            },
                        },

                        {
                            name = L"Griffon",
                            entries =
                            {
                                {
                                    id = 510,
                                    name = L"Kill 25 Griffons",
                                    text =
[[
XP: 334

Kill 25 Griffons
]],
                                },

                                {
                                    id = 511,
                                    name = L"Kill 100 Griffons",
                                    text =
[[
XP: 500

Kill 100 Griffons
]],
                                },

                                {
                                    id = 512,
                                    name = L"Kill 1,000 Griffons",
                                    text =
[[
GIANT TACTIC FRAGMENT

Kill 1,000 Griffons
]],
                                },

                                {
                                    id = 513,
                                    name = L"Kill 10,000 Griffons",
                                    text =
[[
"Master Griffon Slayer"

Kill 10,000 Griffons
]],
                                },

                            },
                        },

                        {
                            name = L"Imp",
                            entries =
                            {
                                {
                                    id = 514,
                                    name = L"Kill 25 Imps",
                                    text =
[[
XP: 204

Kill 25 Imps
]],
                                },

                                {
                                    id = 515,
                                    name = L"Kill 100 Imps",
                                    text =
[[
XP: 500

Kill 100 Imps
]],
                                },

                                {
                                    id = 516,
                                    name = L"Kill 1,000 Imps",
                                    text =
[[
MYTHICAL TACTIC FRAGMENT

Kill 1,000 Imps
]],
                                },

                                {
                                    id = 517,
                                    name = L"Kill 10,000 Imps",
                                    text =
[[
"Master Imp Slayer"

Kill 10,000 Imps
]],
                                },

                            },
                        },

                        {
                            name = L"Manticore",
                            entries =
                            {
                                {
                                    id = 518,
                                    name = L"Kill 25 Manticores",
                                    text =
[[
XP: 204

Kill 25 Manticores
]],
                                },

                                {
                                    id = 519,
                                    name = L"Kill 100 Manticores",
                                    text =
[[
XP: 500

Kill 100 Manticores
]],
                                },

                                {
                                    id = 520,
                                    name = L"Kill 1,000 Manticores",
                                    text =
[[
MYTHICAL TACTIC FRAGMENT

Kill 1,000 Manticores
]],
                                },

                                {
                                    id = 521,
                                    name = L"Kill 10,000 Manticores",
                                    text =
[[
"Master Manticore Slayer"

Kill 10,000 Manticores
]],
                                },

                            },
                        },

                        {
                            name = L"Pegasus",
                            entries =
                            {
                                {
                                    id = 522,
                                    name = L"Kill 25 Pegasi",
                                    text =
[[
XP: 336

Kill 25 Pegasi
]],
                                },

                                {
                                    id = 523,
                                    name = L"Kill 100 Pegasi",
                                    text =
[[
XP: 500

Kill 100 Pegasi
]],
                                },

                                {
                                    id = 524,
                                    name = L"Kill 1,000 Pegasi",
                                    text =
[[
BACK ITEM : CLOAK OF THE PEGASUS

Kill 1,000 Pegasi
]],
                                },

                                {
                                    id = 525,
                                    name = L"Kill 10,000 Pegasi",
                                    text =
[[
"Master Pegasus Slayer"

Kill 10,000 Pegasi
]],
                                },

                            },
                        },

                        {
                            name = L"Unicorn",
                            entries =
                            {
                                {
                                    id = 526,
                                    name = L"Kill 25 Unicorns",
                                    text =
[[
XP: 336

Kill 25 Unicorns
]],
                                },

                                {
                                    id = 527,
                                    name = L"Kill 100 Unicorns",
                                    text =
[[
XP: 500

Kill 100 Unicorns
]],
                                },

                                {
                                    id = 528,
                                    name = L"Kill 1,000 Unicorns",
                                    text =
[[
MYTHICAL TACTIC FRAGMENT

Kill 1,000 Unicorns
]],
                                },

                                {
                                    id = 529,
                                    name = L"Kill 10,000 Unicorns",
                                    text =
[[
"Master Unicorn Slayer"

Kill 10,000 Unicorns
]],
                                },

                            },
                        },

                    },
                },

                {
                    name = L"Trolls",
                    entries =
                    {
                        {
                            name = L"Troll",
                            entries =
                            {
                                {
                                    id = 530,
                                    name = L"Kill 25 Trolls",
                                    text =
[[
XP: 204

Kill 25 Trolls
]],
                                },

                                {
                                    id = 531,
                                    name = L"Kill 100 Trolls",
                                    text =
[[
XP: 500

Kill 100 Trolls
]],
                                },

                                {
                                    id = 532,
                                    name = L"Kill 1,000 Trolls",
                                    text =
[[
BESTIAL TOKEN

Kill 1,000 Trolls
]],
                                },

                                {
                                    id = 533,
                                    name = L"Kill 10,000 Trolls",
                                    text =
[[
"Scourge of Trollkind"

Kill 10,000 Trolls
]],
                                },

                                {
                                    id = 534,
                                    name = L"Kill 100,000 Trolls",
                                    text =
[[
"The Fleshburner"

Kill 100,000 Trolls
]],
                                },

                            },
                        },

                        {
                            name = L"Troll, Chaos",
                            entries =
                            {
                                {
                                    id = 535,
                                    name = L"Kill 25 Chaos Trolls",
                                    text =
[[
XP: 204

Kill 25 Chaos Trolls
]],
                                },

                                {
                                    id = 536,
                                    name = L"Kill 100 Chaos Trolls",
                                    text =
[[
XP: 500

Kill 100 Chaos Trolls
]],
                                },

                                {
                                    id = 537,
                                    name = L"Kill 1,000 Chaos Trolls",
                                    text =
[[
GIANT TACTIC FRAGMENT

Kill 1,000 Chaos Trolls
]],
                                },

                                {
                                    id = 538,
                                    name = L"Kill 10,000 Chaos Trolls",
                                    text =
[[
"Master Chaos Troll Slayer"

Kill 10,000 Chaos Trolls
]],
                                },

                            },
                        },

                        {
                            name = L"Troll, River",
                            entries =
                            {
                                {
                                    id = 539,
                                    name = L"Kill 25 River Trolls",
                                    text =
[[
XP: 204

Kill 25 River Trolls
]],
                                },

                                {
                                    id = 540,
                                    name = L"Kill 100 River Trolls",
                                    text =
[[
XP: 500

Kill 100 River Trolls
]],
                                },

                                {
                                    id = 541,
                                    name = L"Kill 1,000 River Trolls",
                                    text =
[[
BESTIAL TOKEN

Kill 1,000 River Trolls
]],
                                },

                                {
                                    id = 542,
                                    name = L"Kill 10,000 River Trolls",
                                    text =
[[
"The Stench Stealer"

Kill 10,000 River Trolls
]],
                                },

                                {
                                    id = 543,
                                    name = L"Kill 100,000 River Trolls",
                                    text =
[[
"The Reeker"

Kill 100,000 River Trolls
]],
                                },

                            },
                        },

                        {
                            name = L"Troll, Stone",
                            entries =
                            {
                                {
                                    id = 544,
                                    name = L"Kill 25 Stone Trolls",
                                    text =
[[
XP: 204

Kill 25 Stone Trolls
]],
                                },

                                {
                                    id = 545,
                                    name = L"Kill 100 Stone Trolls",
                                    text =
[[
XP: 500

Kill 100 Stone Trolls
]],
                                },

                                {
                                    id = 546,
                                    name = L"Kill 1,000 Stone Trolls",
                                    text =
[[
BESTIAL TOKEN

Kill 1,000 Stone Trolls
]],
                                },

                                {
                                    id = 547,
                                    name = L"Kill 10,000 Stone Trolls",
                                    text =
[[
"The Rubble Wrecker"

Kill 10,000 Stone Trolls
]],
                                },

                                {
                                    id = 548,
                                    name = L"Kill 100,000 Stone Trolls",
                                    text =
[[
"The Stonecarver"

Kill 100,000 Stone Trolls
]],
                                },

                            },
                        },

                    },
                },

            },
        },

        {
            name = L"Nature Spirits",
            entries =
            {
                {
                    name = L"Forest Spirits",
                    entries =
                    {
                        {
                            name = L"Spite",
                            entries =
                            {
                                {
                                    id = 549,
                                    name = L"Kill 25 Spites",
                                    text =
[[
XP: 204

Kill 25 Spites
]],
                                },

                                {
                                    id = 550,
                                    name = L"Kill 100 Spites",
                                    text =
[[
XP: 500

Kill 100 Spites
]],
                                },

                                {
                                    id = 551,
                                    name = L"Kill 1,000 Spites",
                                    text =
[[
BESTIAL TOKEN

Kill 1,000 Spites
]],
                                },

                                {
                                    id = 552,
                                    name = L"Kill 10,000 Spites",
                                    text =
[[
"Wood Spirit's Scourge"

Kill 10,000 Spites
]],
                                },

                                {
                                    id = 553,
                                    name = L"Kill 100,000 Spites",
                                    text =
[[
"The Burnwood Champion"

Kill 100,000 Spites
]],
                                },

                            },
                        },

                    },
                },

                {
                    name = L"Plant Spirits",
                    entries =
                    {
                        {
                            name = L"Dryad",
                            entries =
                            {
                                {
                                    id = 554,
                                    name = L"Kill 25 Dryads",
                                    text =
[[
XP: 204

Kill 25 Dryads
]],
                                },

                                {
                                    id = 555,
                                    name = L"Kill 100 Dryads",
                                    text =
[[
XP: 500

Kill 100 Dryads
]],
                                },

                                {
                                    id = 556,
                                    name = L"Kill 1,000 Dryads",
                                    text =
[[
BESTIAL TOKEN

Kill 1,000 Dryads
]],
                                },

                                {
                                    id = 557,
                                    name = L"Kill 10,000 Dryads",
                                    text =
[[
"Despoiler"

Kill 10,000 Dryads
]],
                                },

                                {
                                    id = 558,
                                    name = L"Kill 100,000 Dryads",
                                    text =
[[
"Nymph Seeker"

Kill 100,000 Dryads
]],
                                },

                            },
                        },

                        {
                            name = L"Tree Kin",
                            entries =
                            {
                                {
                                    id = 559,
                                    name = L"Kill 25 Treekins",
                                    text =
[[
XP: 204

Kill 25 Treekins
]],
                                },

                                {
                                    id = 560,
                                    name = L"Kill 100 Treekins",
                                    text =
[[
XP: 500

Kill 100 Treekins
]],
                                },

                                {
                                    id = 561,
                                    name = L"Kill 1,000 Treekins",
                                    text =
[[
MYTHICAL TACTIC FRAGMENT

Kill 1,000 Treekins
]],
                                },

                                {
                                    id = 562,
                                    name = L"Kill 10,000 Treekins",
                                    text =
[[
"Master Treekin Slayer"

Kill 10,000 Treekins
]],
                                },

                            },
                        },

                        {
                            name = L"Treemen",
                            entries =
                            {
                                {
                                    id = 563,
                                    name = L"Kill 25 Treemen",
                                    text =
[[
XP: 204

Kill 25 Treemen
]],
                                },

                                {
                                    id = 564,
                                    name = L"Kill 100 Treemen",
                                    text =
[[
XP: 500

Kill 100 Treemen
]],
                                },

                                {
                                    id = 565,
                                    name = L"Kill 1,000 Treemen",
                                    text =
[[
MYTHICAL TACTIC FRAGMENT

Kill 1,000 Treemen
]],
                                },

                                {
                                    id = 566,
                                    name = L"Kill 10,000 Treemen",
                                    text =
[[
"The Worldbreaker"

Kill 10,000 Treemen
]],
                                },

                            },
                        },

                    },
                },

            },
        },

        {
            name = L"Undead",
            entries =
            {
                {
                    name = L"Constructs",
                    entries =
                    {
                        {
                            name = L"Asp Bone Construct",
                            entries =
                            {
                                {
                                    id = 567,
                                    name = L"Kill 25 Asp Bone Constructs",
                                    text =
[[
XP: 1476

Kill 25 Asp Bone Constructs
]],
                                },

                                {
                                    id = 568,
                                    name = L"Kill 1,000 Asp Bone Constructs",
                                    text =
[[
UNDEAD TACTIC FRAGMENT

Kill 1,000 Asp Bone Constructs
]],
                                },

                                {
                                    id = 569,
                                    name = L"Kill 10,000 Asp Bone Constructs",
                                    text =
[[
"Snake Charmer"

Kill 10,000 Asp Bone Constructs
]],
                                },

                            },
                        },

                        {
                            name = L"Bone Giant",
                            entries =
                            {
                                {
                                    id = 570,
                                    name = L"Kill 25 Bone Giants",
                                    text =
[[
XP: 336

Kill 25 Bone Giants
]],
                                },

                                {
                                    id = 571,
                                    name = L"Kill 100 Bone Giants",
                                    text =
[[
XP: 500

Kill 100 Bone Giants
]],
                                },

                                {
                                    id = 572,
                                    name = L"Kill 1,000 Bone Giants",
                                    text =
[[
UNDEAD TACTIC FRAGMENT

Kill 1,000 Bone Giants
]],
                                },

                                {
                                    id = 573,
                                    name = L"Kill 10,000 Bone Giants",
                                    text =
[[
"Master Bone Giant Slayer"

Kill 10,000 Bone Giants
]],
                                },

                            },
                        },

                        {
                            name = L"Living Armor",
                            entries =
                            {
                                {
                                    id = 574,
                                    name = L"Kill 25 Living Armors",
                                    text =
[[
XP: 204

Kill 25 Living Armors
]],
                                },

                                {
                                    id = 575,
                                    name = L"Kill 100 Living Armors",
                                    text =
[[
XP: 500

Kill 100 Living Armors
]],
                                },

                                {
                                    id = 576,
                                    name = L"Kill 1,000 Living Armors",
                                    text =
[[
MAN TACTIC FRAGMENT

Kill 1,000 Living Armors
]],
                                },

                                {
                                    id = 577,
                                    name = L"Kill 10,000 Living Armors",
                                    text =
[[
"Master Living Armor Slayer"

Kill 10,000 Living Armors
]],
                                },

                            },
                        },

                        {
                            name = L"Scarab Bone Construct",
                            entries =
                            {
                                {
                                    id = 578,
                                    name = L"Kill 25 Scarab Bone Constructs",
                                    text =
[[
XP: 1476

Kill 25 Scarab Bone Constructs
]],
                                },

                                {
                                    id = 579,
                                    name = L"Kill 1,000 Scarab Bone Constructs",
                                    text =
[[
UNDEAD TACTIC FRAGMENT

Kill 1,000 Scarab Bone Constructs
]],
                                },

                                {
                                    id = 580,
                                    name = L"Kill 10,000 Scarab Bone Constructs",
                                    text =
[[
"The De-Constructor"

Kill 10,000 Scarab Bone Constructs
]],
                                },

                            },
                        },

                        {
                            name = L"Tomb Scorpion",
                            entries =
                            {
                                {
                                    id = 581,
                                    name = L"Kill 25 Tomb Scorpions",
                                    text =
[[
XP: 1476

Kill 25 Tomb Scorpions
]],
                                },

                                {
                                    id = 582,
                                    name = L"Kill 100 Tomb Scorpions",
                                    text =
[[
UNDEAD TACTIC FRAGMENT

Kill 100 Tomb Scorpions
]],
                                },

                                {
                                    id = 583,
                                    name = L"Kill 1,000 Tomb Scorpions",
                                    text =
[[
"The Claw"

Kill 1,000 Tomb Scorpions
]],
                                },

                            },
                        },

                        {
                            name = L"Ushabti",
                            entries =
                            {
                                {
                                    id = 584,
                                    name = L"Kill 25 Ushabti",
                                    text =
[[
XP: 1476

Kill 25 Ushabti
]],
                                },

                                {
                                    id = 585,
                                    name = L"Kill 100 Ushabti",
                                    text =
[[
UNDEAD TACTIC FRAGMENT

Kill 100 Ushabti
]],
                                },

                                {
                                    id = 586,
                                    name = L"Kill 1,000 Ushabti",
                                    text =
[[
"Statue-Breaker"

Kill 1,000 Ushabti
]],
                                },

                            },
                        },

                        {
                            name = L"Winged Nightmare",
                            entries =
                            {
                                {
                                    id = 587,
                                    name = L"Kill 25 Winged Nightmares",
                                    text =
[[
XP: 336

Kill 25 Winged Nightmares
]],
                                },

                                {
                                    id = 588,
                                    name = L"Kill 100 Winged Nightmares",
                                    text =
[[
XP: 500

Kill 100 Winged Nightmares
]],
                                },

                                {
                                    id = 589,
                                    name = L"Kill 1,000 Winged Nightmares",
                                    text =
[[
UNDEAD TACTIC FRAGMENT

Kill 1,000 Winged Nightmares
]],
                                },

                                {
                                    id = 590,
                                    name = L"Kill 10,000 Winged Nightmares",
                                    text =
[[
"Master Winged Nightmare Slayer"

Kill 10,000 Winged Nightmares
]],
                                },

                            },
                        },

                    },
                },

                {
                    name = L"Greater Undead",
                    entries =
                    {
                        {
                            name = L"Liche",
                            entries =
                            {
                                {
                                    id = 591,
                                    name = L"Kill 25 Liches",
                                    text =
[[
XP: 204

Kill 25 Liches
]],
                                },

                                {
                                    id = 592,
                                    name = L"Kill 100 Liches",
                                    text =
[[
XP: 500

Kill 100 Liches
]],
                                },

                                {
                                    id = 593,
                                    name = L"Kill 1,000 Liches",
                                    text =
[[
UNDEAD TACTIC FRAGMENT

Kill 1,000 Liches
]],
                                },

                                {
                                    id = 594,
                                    name = L"Kill 10,000 Liches",
                                    text =
[[
"Master Liche Slayer"

Kill 10,000 Liches
]],
                                },

                            },
                        },

                        {
                            name = L"Preserved Dead",
                            entries =
                            {
                                {
                                    id = 595,
                                    name = L"Kill 25 Preserved Dead",
                                    text =
[[
XP: 1476

Kill 25 Preserved Dead
]],
                                },

                                {
                                    id = 596,
                                    name = L"Kill 100 Preserved Dead",
                                    text =
[[
UNDEAD TACTIC FRAGMENT

Kill 100 Preserved Dead
]],
                                },

                                {
                                    id = 597,
                                    name = L"Kill 1,000 Preserved Dead",
                                    text =
[[
"Tombstalker"

Kill 1,000 Preserved Dead
]],
                                },

                            },
                        },

                        {
                            name = L"Vampire",
                            entries =
                            {
                                {
                                    id = 598,
                                    name = L"Kill 25 Vampires",
                                    text =
[[
XP: 336

Kill 25 Vampires
]],
                                },

                                {
                                    id = 599,
                                    name = L"Kill 100 Vampires",
                                    text =
[[
XP: 500

Kill 100 Vampires
]],
                                },

                                {
                                    id = 600,
                                    name = L"Kill 1,000 Vampires",
                                    text =
[[
UNDEAD TACTIC FRAGMENT

Kill 1,000 Vampires
]],
                                },

                                {
                                    id = 601,
                                    name = L"Kill 10,000 Vampires",
                                    text =
[[
"Master Vampire Slayer"

Kill 10,000 Vampires
]],
                                },

                            },
                        },

                    },
                },

                {
                    name = L"Skeletons",
                    entries =
                    {
                        {
                            name = L"Carrion",
                            entries =
                            {
                                {
                                    id = 602,
                                    name = L"Kill 25 Carrion",
                                    text =
[[
XP: 1476

Kill 25 Carrion
]],
                                },

                                {
                                    id = 603,
                                    name = L"Kill 1,000 Carrion",
                                    text =
[[
UNDEAD TACTIC FRAGMENT

Kill 1,000 Carrion
]],
                                },

                                {
                                    id = 604,
                                    name = L"Kill 10,000 Carrion",
                                    text =
[[
"Buzzard Bait"

Kill 10,000 Carrion
]],
                                },

                            },
                        },

                        {
                            name = L"Skeleton",
                            entries =
                            {
                                {
                                    id = 605,
                                    name = L"Kill 25 Skeletons",
                                    text =
[[
XP: 204

Kill 25 Skeletons
]],
                                },

                                {
                                    id = 606,
                                    name = L"Kill 100 Skeletons",
                                    text =
[[
XP: 500

Kill 100 Skeletons
]],
                                },

                                {
                                    id = 607,
                                    name = L"Kill 1,000 Skeletons",
                                    text =
[[
BESTIAL TOKEN

Kill 1,000 Skeletons
]],
                                },

                                {
                                    id = 608,
                                    name = L"Kill 10,000 Skeletons",
                                    text =
[[
"The Bonecrusher"

Kill 10,000 Skeletons
]],
                                },

                                {
                                    id = 609,
                                    name = L"Kill 100,000 Skeletons",
                                    text =
[[
"The Fist of Morr"

Kill 100,000 Skeletons
]],
                                },

                            },
                        },

                    },
                },

                {
                    name = L"Spirits",
                    entries =
                    {
                        {
                            name = L"Banshee",
                            entries =
                            {
                                {
                                    id = 610,
                                    name = L"Kill 25 Banshee",
                                    text =
[[
XP: 336

Kill 25 Banshee
]],
                                },

                                {
                                    id = 611,
                                    name = L"Kill 100 Banshee",
                                    text =
[[
XP: 500

Kill 100 Banshee
]],
                                },

                                {
                                    id = 612,
                                    name = L"Kill 1,000 Banshee",
                                    text =
[[
UNDEAD TACTIC FRAGMENT

Kill 1,000 Banshee
]],
                                },

                                {
                                    id = 613,
                                    name = L"Kill 10,000 Banshee",
                                    text =
[[
"Master Banshee Slayer"

Kill 10,000 Banshee
]],
                                },

                            },
                        },

                        {
                            name = L"Spirit Host",
                            entries =
                            {
                                {
                                    id = 614,
                                    name = L"Kill 25 Spirit Hosts",
                                    text =
[[
XP: 204

Kill 25 Spirit Hosts
]],
                                },

                                {
                                    id = 615,
                                    name = L"Kill 100 Spirit Hosts",
                                    text =
[[
XP: 500

Kill 100 Spirit Hosts
]],
                                },

                                {
                                    id = 616,
                                    name = L"Kill 1,000 Spirit Hosts",
                                    text =
[[
BESTIAL TOKEN

Kill 1,000 Spirit Hosts
]],
                                },

                                {
                                    id = 617,
                                    name = L"Kill 10,000 Spirit Hosts",
                                    text =
[[
"The Iron Willed"

Kill 10,000 Spirit Hosts
]],
                                },

                                {
                                    id = 618,
                                    name = L"Kill 100,000 Spirit Hosts",
                                    text =
[[
"The Resolute"

Kill 100,000 Spirit Hosts
]],
                                },

                            },
                        },

                        {
                            name = L"Wraith",
                            entries =
                            {
                                {
                                    id = 619,
                                    name = L"Kill 25 Wraiths",
                                    text =
[[
XP: 204

Kill 25 Wraiths
]],
                                },

                                {
                                    id = 620,
                                    name = L"Kill 100 Wraiths",
                                    text =
[[
XP: 500

Kill 100 Wraiths
]],
                                },

                                {
                                    id = 621,
                                    name = L"Kill 1,000 Wraiths",
                                    text =
[[
UNDEAD TACTIC FRAGMENT

Kill 1,000 Wraiths
]],
                                },

                                {
                                    id = 622,
                                    name = L"Kill 10,000 Wraiths",
                                    text =
[[
"Master Wraith Slayer"

Kill 10,000 Wraiths
]],
                                },

                            },
                        },

                    },
                },

                {
                    name = L"Wights",
                    entries =
                    {
                        {
                            name = L"Wight",
                            entries =
                            {
                                {
                                    id = 623,
                                    name = L"Kill 25 Wights",
                                    text =
[[
XP: 204

Kill 25 Wights
]],
                                },

                                {
                                    id = 624,
                                    name = L"Kill 100 Wights",
                                    text =
[[
XP: 500

Kill 100 Wights
]],
                                },

                                {
                                    id = 625,
                                    name = L"Kill 1,000 Wights",
                                    text =
[[
UNDEAD TACTIC FRAGMENT

Kill 1,000 Wights
]],
                                },

                                {
                                    id = 626,
                                    name = L"Kill 10,000 Wights",
                                    text =
[[
"Master Wight Slayer"

Kill 10,000 Wights
]],
                                },

                            },
                        },

                    },
                },

                {
                    name = L"Zombies",
                    entries =
                    {
                        {
                            name = L"Zombie",
                            entries =
                            {
                                {
                                    id = 627,
                                    name = L"Kill 25 Zombies",
                                    text =
[[
XP: 204

Kill 25 Zombies
]],
                                },

                                {
                                    id = 628,
                                    name = L"Kill 100 Zombies",
                                    text =
[[
XP: 500

Kill 100 Zombies
]],
                                },

                                {
                                    id = 629,
                                    name = L"Kill 1,000 Zombies",
                                    text =
[[
BESTIAL TOKEN

Kill 1,000 Zombies
]],
                                },

                                {
                                    id = 630,
                                    name = L"Kill 10,000 Zombies",
                                    text =
[[
"of the Dead"

Kill 10,000 Zombies
]],
                                },

                                {
                                    id = 631,
                                    name = L"Kill 100,000 Zombies",
                                    text =
[[
"Knight of the Dead"

Kill 100,000 Zombies
]],
                                },

                            },
                        },

                    },
                },

            },
        },

        {
            name = L"Legendary Monsters",
            entries =
            {
                {
                    name = L"Bastion Stair",
                    entries =
                    {
                        {
                            name = L"Kaarn the Vanquisher",
                            entries =
                            {
                                Kills_LegendaryTask(632, "Encounter Kaarn the Vanquisher", "XP: 1216"),
                                Kills_LegendaryTask(633, "Defeat Kaarn the Vanquisher 5 Times", "COMPANION COIN"),
                                Kills_LegendaryTask(634, "Defeat Kaarn the Vanquisher 10 Times", "BESTIAL TOKEN"),
                                Kills_LegendaryTask(635, "Defeat Kaarn the Vanquisher 25 Times", "\"The Vanquisher's Vanquisher\""),
                                Kills_LegendaryTask(636, "Defeat Kaarn the Vanquisher 50 Times", "Trophy: TBD"),
                                Kills_LegendaryTask(637, "Defeat Kaarn the Vanquisher 75 Times", "\"Mmm, Kaarn Flakes\""),
                                Kills_LegendaryTask(638, "Defeat Kaarn the Vanquisher 100 Times", "Trophy: TBD"),
                            },
                        },

                        {
                            name = L"Lord Slaurith",
                            entries =
                            {
                                Kills_LegendaryTask(639, "Encounter Lord Slaurith", "XP: 1216"),
                                Kills_LegendaryTask(640, "Defeat Lord Slaurith 5 Times", "COMPANION COIN"),
                                Kills_LegendaryTask(641, "Defeat Lord Slaurith 10 Times", "BESTIAL TOKEN"),
                                Kills_LegendaryTask(642, "Defeat Lord Slaurith 25 Times", "\"The Warrior\""),
                                Kills_LegendaryTask(643, "Defeat Lord Slaurith 50 Times", "Trophy: TBD"),
                                Kills_LegendaryTask(644, "Defeat Lord Slaurith 75 Times", "\"Me! Pick me!\""),
                                Kills_LegendaryTask(645, "Defeat Lord Slaurith 100 Times", "Trophy: TBD"),
                            },
                        },

                        {
                            name = L"Skull Lord Var'Ithrok",
                            entries =
                            {
                                Kills_LegendaryTask(646, "Encounter Skull Lord Var'Ithrok", "XP: 1216"),
                                Kills_LegendaryTask(647, "Defeat Skull Lord Var'Ithrok 5 Times", "COMPANION COIN"),
                                Kills_LegendaryTask(648, "Defeat Skull Lord Var'Ithrok 10 Times", "BESTIAL TOKEN"),
                                Kills_LegendaryTask(649, "Defeat Skull Lord Var'Ithrok 25 Times", "\"Skull Lord Scrambler\""),
                                Kills_LegendaryTask(650, "Defeat Skull Lord Var'Ithrok 50 Times", "Trophy: TBD"),
                                Kills_LegendaryTask(651, "Defeat Skull Lord Var'Ithrok 75 Times", "\"Var'Ithrok Hates Me\""),
                                Kills_LegendaryTask(652, "Defeat Skull Lord Var'Ithrok 100 Times", "Trophy: TBD"),
                            },
                        },

                        {
                            name = L"Thar'Ignan",
                            entries =
                            {
                                Kills_LegendaryTask(653, "Encounter Thar'Ignan", "XP: 1216"),
                                Kills_LegendaryTask(654, "Defeat Thar'Ignan 5 Times", "COMPANION COIN"),
                                Kills_LegendaryTask(655, "Defeat Thar'Ignan 10 Times", "BESTIAL TOKEN"),
                                Kills_LegendaryTask(656, "Defeat Thar'Ignan 25 Times", "\"Doombull's Doom\""),
                                Kills_LegendaryTask(657, "Defeat Thar'Ignan 50 Times", "Trophy: TBD"),
                                Kills_LegendaryTask(658, "Defeat Thar'Ignan 75 Times", "\"Takes 'Em By the Horns\""),
                                Kills_LegendaryTask(659, "Defeat Thar'Ignan 100 Times", "Trophy: TBD"),
                            },
                        },
                    },
                },

                {
                    name = L"Mount Gunbad",
                    entries =
                    {
                        {
                            name = L"'Ard ta Feed",
                            entries =
                            {
                                Kills_LegendaryTask(660, "Encounter 'Ard ta Feed", "XP: 1216"),
                                Kills_LegendaryTask(661, "Defeat 'Ard ta Feed 5 Times", "COMPANION COIN"),
                                Kills_LegendaryTask(662, "Defeat 'Ard ta Feed 10 Times", "BESTIAL TOKEN"),
                                Kills_LegendaryTask(663, "Defeat 'Ard ta Feed 25 Times", "\"Hunger Striker\""),
                                Kills_LegendaryTask(664, "Defeat 'Ard ta Feed 50 Times", "Trophy: Bit o' Ard Ta Feed"),
                                Kills_LegendaryTask(665, "Defeat 'Ard ta Feed 75 Times", "\"Don't Eat Me!\""),
                                Kills_LegendaryTask(666, "Defeat 'Ard ta Feed 100 Times", "Trophy: TBD"),
                            },
                        },

                        {
                            name = L"Glomp da Squig Masta",
                            entries =
                            {
                                Kills_LegendaryTask(667, "Encounter Glomp da Squig Masta", "XP: 1216"),
                                Kills_LegendaryTask(668, "Defeat Glomp da Squig Masta 5 Times", "COMPANION COIN"),
                                Kills_LegendaryTask(669, "Defeat Glomp da Squig Masta 10 Times", "BESTIAL TOKEN"),
                                Kills_LegendaryTask(670, "Defeat Glomp da Squig Masta 25 Times", "\"Squig Stomper\""),
                                Kills_LegendaryTask(671, "Defeat Glomp da Squig Masta 50 Times", "Trophy: Glomp's Lucky Shrooms"),
                                Kills_LegendaryTask(672, "Defeat Glomp da Squig Masta 75 Times", "\"Squig Lover\""),
                                Kills_LegendaryTask(673, "Defeat Glomp da Squig Masta 100 Times", "Trophy: TBD"),
                            },
                        },

                        {
                            name = L"Masta Mixa",
                            entries =
                            {
                                Kills_LegendaryTask(674, "Encounter Masta Mixa", "XP: 1216"),
                                Kills_LegendaryTask(675, "Defeat Masta Mixa 5 Times", "COMPANION COIN"),
                                Kills_LegendaryTask(676, "Defeat Masta Mixa 10 Times", "BESTIAL TOKEN"),
                                Kills_LegendaryTask(677, "Defeat Masta Mixa 25 Times", "\"Brew Enthusiast\""),
                                Kills_LegendaryTask(678, "Defeat Masta Mixa 50 Times", "Trophy: Masta Mixa's Vial"),
                                Kills_LegendaryTask(679, "Defeat Masta Mixa 75 Times", "\"The Hammered\""),
                                Kills_LegendaryTask(680, "Defeat Masta Mixa 100 Times", "Trophy: TBD"),
                            },
                        },

                        {
                            name = L"Wight Lord Solithex",
                            entries =
                            {
                                Kills_LegendaryTask(681, "Encounter Wight Lord Solithex", "XP: 1216"),
                                Kills_LegendaryTask(682, "Defeat Wight Lord Solithex 5 Times", "COMPANION COIN"),
                                Kills_LegendaryTask(683, "Defeat Wight Lord Solithex 10 Times", "BESTIAL TOKEN"),
                                Kills_LegendaryTask(684, "Defeat Wight Lord Solithex 25 Times", "\"Skeleton Slicer\""),
                                Kills_LegendaryTask(685, "Defeat Wight Lord Solithex 50 Times", "Trophy: Mourkain Relic"),
                                Kills_LegendaryTask(686, "Defeat Wight Lord Solithex 75 Times", "\"Menace of Mourkain\""),
                                Kills_LegendaryTask(687, "Defeat Wight Lord Solithex 100 Times", "Trophy: TBD"),
                            },
                        },
                    },
                },

                {
                    name = L"The Lost Vale",
                    entries =
                    {
                        {
                            name = L"Dralel the Whitefire Matron",
                            entries =
                            {
                                Kills_LegendaryTask(688, "Encounter Dralel the Whitefire Matron", "COMPANION COIN"),
                                Kills_LegendaryTask(689, "Defeat Dralel the Whitefire Matron 5 Times", "BESTIAL TOKEN"),
                                Kills_LegendaryTask(690, "Defeat Dralel the Whitefire Matron 10 Times", "\"Whitefire Exterminator\""),
                                Kills_LegendaryTask(691, "Defeat Dralel the Whitefire Matron 25 Times", "Trophy: Whitefire Shard"),
                                Kills_LegendaryTask(692, "Defeat Dralel the Whitefire Matron 50 Times", "\"Master of Ghur\""),
                                Kills_LegendaryTask(693, "Defeat Dralel the Whitefire Matron 75 Times", "Trophy: TBD"),
                                Kills_LegendaryTask(694, "Defeat Dralel the Whitefire Matron 100 Times", "Cloak: Dralel"),
                            },
                        },

                        {
                            name = L"N'Kari the Soul-Flayer",
                            entries =
                            {
                                Kills_LegendaryTask(695, "Encounter N'Kari the Soul-Flayer", "COMPANION COIN"),
                                Kills_LegendaryTask(696, "Defeat N'Kari the Soul-Flayer 5 Times", "BESTIAL TOKEN"),
                                Kills_LegendaryTask(697, "Defeat N'Kari the Soul-Flayer 10 Times", "\"Lustfully Yours\""),
                                Kills_LegendaryTask(698, "Defeat N'Kari the Soul-Flayer 25 Times", "Trophy: N'Kari's Necklace"),
                                Kills_LegendaryTask(699, "Defeat N'Kari the Soul-Flayer 50 Times", "\"Hated by Slaanesh\""),
                                Kills_LegendaryTask(700, "Defeat N'Kari the Soul-Flayer 75 Times", "Trophy: TBD"),
                                Kills_LegendaryTask(701, "Defeat N'Kari the Soul-Flayer 100 Times", "Cloak: N'Kari"),
                            },
                        },

                        {
                            name = L"Sarthain the Worldbearer",
                            entries =
                            {
                                Kills_LegendaryTask(702, "Encounter Sarthain the Worldbearer", "COMPANION COIN"),
                                Kills_LegendaryTask(703, "Defeat Sarthain the Worldbearer 5 Times", "BESTIAL TOKEN"),
                                Kills_LegendaryTask(704, "Defeat Sarthain the Worldbearer 10 Times", "\"The Root Severer\""),
                                Kills_LegendaryTask(705, "Defeat Sarthain the Worldbearer 25 Times", "Trophy: Sarthain's Bark"),
                                Kills_LegendaryTask(706, "Defeat Sarthain the Worldbearer 50 Times", "\"Master of Ghyran\""),
                                Kills_LegendaryTask(707, "Defeat Sarthain the Worldbearer 75 Times", "Trophy: TBD"),
                                Kills_LegendaryTask(708, "Defeat Sarthain the Worldbearer 100 Times", "Cloak: Sarthain"),
                            },
                        },

                        {
                            name = L"Sechar the Darkpromise Chieftain",
                            entries =
                            {
                                Kills_LegendaryTask(709, "Encounter Sechar the Darkpromise Chieftain", "COMPANION COIN"),
                                Kills_LegendaryTask(710, "Defeat Sechar the Darkpromise Chieftain 5 Times", "BESTIAL TOKEN"),
                                Kills_LegendaryTask(711, "Defeat Sechar the Darkpromise Chieftain 10 Times", "\"Breaker of Promises\""),
                                Kills_LegendaryTask(712, "Defeat Sechar the Darkpromise Chieftain 25 Times", "Trophy: Sechar's Painlink"),
                                Kills_LegendaryTask(713, "Defeat Sechar the Darkpromise Chieftain 50 Times", "\"Enjoys Suffering\""),
                                Kills_LegendaryTask(714, "Defeat Sechar the Darkpromise Chieftain 75 Times", "Trophy: TBD"),
                                Kills_LegendaryTask(715, "Defeat Sechar the Darkpromise Chieftain 100 Times", "Cloak: Sechar"),
                            },
                        },
                    },
                },
            },
        },

    },
}

