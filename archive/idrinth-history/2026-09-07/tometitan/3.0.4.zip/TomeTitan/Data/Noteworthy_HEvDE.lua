TTitan.Data.NoteworthyHEvDE = {}

function TTitan.Data.NoteworthyHEvDE.GetData()
	return TTitan.Data.NoteworthyHEvDE.RawData
end

function TTitan.Data.NoteworthyHEvDE.FilterData()
	TTitan.Data.FilterByRealm(TTitan.Data.NoteworthyHEvDE.RawData)
end

TTitan.Data.NoteworthyHEvDE.RawData =
{
	header = L"Noteworthy Persons Unlocks - High Elves vs Dark Elves",
	categories =
	{
		{
			name = L"The Blighted Isle",
			entries =
			{
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Captain Talorith",
					mapPins =
					{
						{
							x = 48200,
							y = 14000,
							zoneId = 200,
							tooltip = L"Captain Talorith",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
48200, 14000

Talk to "Captain Talorith" the Rally Master at this location, for High Elf Chapter 1.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Kyrinn Silversea",
					mapPins =
					{
						{
							x = 42700,
							y = 25900,
							zoneId = 200,
							tooltip = L"Kyrinn Silversea",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
42700, 25900

Talk to "Kyrinn Silversea" the Rally Master at Adunei, High Elf Chapter 2.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Riandys Arrowlore",
					mapPins =
					{
						{
							x = 43000,
							y = 46500,
							zoneId = 200,
							tooltip = L"Riandys Arrowlore",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
43000, 46500

Talk to "Riandys Arrowlore" an NPC at Tor Aendris warcamp. They are in the higher area in front of the building, on the left by some chariots and barrels.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Aen Windsong",
					mapPins =
					{
						{
							x = 48200,
							y = 14000,
							zoneId = 200,
							tooltip = L"Aen Windsong",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
48200, 14000

Talk to "Aen Windsong" the Kill Collector at this location, for High Elf Chapter 1.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Caethsetir Silverstrand",
					mapPins =
					{
						{
							x = 44600,
							y = 26700,
							zoneId = 200,
							tooltip = L"Caethsetir Silverstrand",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
44600, 26700

Talk to "Caethsetir Silverstrand" the Kill Collector at Adunei, High Elf Chapter 2.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Master Kaltarn",
					mapPins =
					{
						{
							x = 10400,
							y = 19200,
							zoneId = 200,
							tooltip = L"Master Kaltarn",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
10400, 19200

Talk to "Master Kaltarn" the Rally Master at this location, for Dark Elf Chapter 1.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Akrana",
					mapPins =
					{
						{
							x = 13200,
							y = 31200,
							zoneId = 200,
							tooltip = L"Akrana",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
13200, 31200

Talk to "Akrana" the Rally Master at Akrana's Storm, Dark Elf Chapter 2.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Kulvorath Bloodhand",
					mapPins =
					{
						{
							x = 12900,
							y = 51600,
							zoneId = 200,
							tooltip = L"Kulvorath Bloodhand",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
12900, 51600

Talk to "Kulvorath Bloodhand" the Rally Master at Poisonblade Heath, Dark Elf Chapter 3.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Kolith Blackblade",
					mapPins =
					{
						{
							x = 24000,
							y = 58000,
							zoneId = 200,
							tooltip = L"Kolith Blackblade",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
24000, 58000

Talk to "Kolith Blackblade" an NPC at Cynathai Span warcamp. Near the PvE ramp, standing next to an orc tower.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Saril Zaen",
					mapPins =
					{
						{
							x = 8700,
							y = 14200,
							zoneId = 200,
							tooltip = L"Saril Zaen",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
8700, 14200

Talk to "Saril Zaen" the Kill Collector at this location, for Dark Elf Chapter 1.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Riakahd Flameblade",
					mapPins =
					{
						{
							x = 13300,
							y = 31500,
							zoneId = 200,
							tooltip = L"Riakahd Flameblade",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
13300, 31500

Talk to "Riakahd Flameblade" the Kill Collector at Akrana's Storm, Dark Elf Chapter 2.
]],
				},
			},
		},

		{
			name = L"Chrace",
			entries =
			{
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Morithwen Nightwhisper",
					mapPins =
					{
						{
							x = 53000,
							y = 1000,
							zoneId = 206,
							tooltip = L"Morithwen Nightwhisper",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
53000, 1000

Talk to "Morithwen Nightwhisper" the Rally Master at Blightsward, High Elf Chapter 3.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Caduin Goldbough",
					mapPins =
					{
						{
							x = 53700,
							y = 33100,
							zoneId = 206,
							tooltip = L"Caduin Goldbough",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
53700, 33100

Talk to "Caduin Goldbough" the Rally Master at Cliffs of Ushuru, High Elf Chapter 4.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Aeldith Tearsong",
					mapPins =
					{
						{
							x = 53300,
							y = 1500,
							zoneId = 206,
							tooltip = L"Aeldith Tearsong",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
53300, 1500

Talk to "Aeldith Tearsong" the Kill Collector at Blightsward, High Elf Chapter 3.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Elthossar Youngstar",
					mapPins =
					{
						{
							x = 53700,
							y = 33000,
							zoneId = 206,
							tooltip = L"Elthossar Youngstar",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
53700, 33000

Talk to "Elthossar Youngstar" the Kill Collector at Cliffs of Ushuru, High Elf Chapter 4.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"General Malagurn",
					mapPins =
					{
						{
							x = 18700,
							y = 25200,
							zoneId = 206,
							tooltip = L"General Malagurn",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
18700, 25200

Talk to "General Malagurn" the Rally Master at Malagurn's Charge, Dark Elf Chapter 4.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Krartil Deathsong",
					mapPins =
					{
						{
							x = 8700,
							y = 2400,
							zoneId = 206,
							tooltip = L"Krartil Deathsong",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
8700, 2400

Talk to "Krartil Deathsong" the Kill Collector at Poisonblade Heath, Dark Elf Chapter 3. He stands by the ramp onto the ship at "Shadowsong Landing" major landmark.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Hakazin Felwind",
					mapPins =
					{
						{
							x = 21100,
							y = 26100,
							zoneId = 206,
							tooltip = L"Hakazin Felwind",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
21100, 26100

Talk to "Hakazin Felwind" the Kill Collector at Malagurn's Charge, Dark Elf Chapter 4.
]],
				},
			},
		},

		{
			name = L"The Shadowlands",
			entries =
			{
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Mathrin Leafwind",
					mapPins =
					{
						{
							x = 59600,
							y = 11500,
							zoneId = 201,
							tooltip = L"Mathrin Leafwind",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
59600, 11500

Talk to "Mathrin Leafwind" the Rally Master at Mathrin's Watch, High Elf Chapter 5.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Captain Nenthuil",
					mapPins =
					{
						{
							x = 38500,
							y = 14100,
							zoneId = 201,
							tooltip = L"Captain Nenthuil",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
38500, 14100

Talk to "Captain Nenthuil" the Rally Master at Sorrowstrand, High Elf Chapter 6.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Liradean Swiftarm",
					mapPins =
					{
						{
							x = 52200,
							y = 38600,
							zoneId = 201,
							tooltip = L"Liradean Swiftarm",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
52200, 38600

Talk to "Liradean Swiftarm" the Rally Master at Skyblade's Hold, High Elf Chapter 7.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Lasira Swiftbow",
					mapPins =
					{
						{
							x = 47400,
							y = 42600,
							zoneId = 201,
							tooltip = L"Lasira Swiftbow",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
47400, 42600

Talk to "Lasira Swiftbow" at Bladewatch warcamp.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Celorn Slenderwand",
					mapPins =
					{
						{
							x = 60200,
							y = 11000,
							zoneId = 201,
							tooltip = L"Celorn Slenderwand",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
60200, 11000

Talk to "Celorn Slenderwand" the Kill Collector at Mathrin's Watch, High Elf Chapter 5.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Shenassa Blesswind",
					mapPins =
					{
						{
							x = 38300,
							y = 13700,
							zoneId = 201,
							tooltip = L"Shenassa Blesswind",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
38300, 13700

Talk to "Shenassa Blesswind" the Kill Collector at Sorrowstrand, High Elf Chapter 6.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Cirroniol Sureshot",
					mapPins =
					{
						{
							x = 52400,
							y = 40500,
							zoneId = 201,
							tooltip = L"Cirroniol Sureshot",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
52400, 40500

Talk to "Cirroniol Sureshot" the Kill Collector at Skyblade's Hold, High Elf Chapter 7.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Lady Elaryndra Stormblade",
					mapPins =
					{
						{
							x = 33000,
							y = 48700,
							zoneId = 201,
							tooltip = L"Lady Elaryndra Stormblade",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
33000, 48700 - In RvR Lake

Talk to "Lady Elaryndra Stormblade" the Keep Lord of Spite's Reach.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Lord Yldrian",
					mapPins =
					{
						{
							x = 36200,
							y = 9000,
							zoneId = 201,
							tooltip = L"Lord Yldrian",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
36200, 9000

Talk to "Lord Yldrian" the Rally Master at Ruins of Anlec, Dark Elf Chapter 5.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Harodir",
					mapPins =
					{
						{
							x = 5700,
							y = 10400,
							zoneId = 201,
							tooltip = L"Harodir",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
5700, 10400

Talk to "Harodir" the Rally Master at Sundered Strand, Dark Elf Chapter 6.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Ralkuth",
					mapPins =
					{
						{
							x = 18000,
							y = 37500,
							zoneId = 201,
							tooltip = L"Ralkuth",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
18000, 37500

Talk to "Ralkuth" the Rally Master at Ralkuth's Return, Dark Elf Chapter 7.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Kathandris Skysiege",
					mapPins =
					{
						{
							x = 24500,
							y = 50000,
							zoneId = 201,
							tooltip = L"Kathandris Skysiege",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
24500, 50000

Talk to "Kathandris Skysiege" at Oath's End warcamp. Standing near a rock on the western side of the camp.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Beastmaster Zakira",
					mapPins =
					{
						{
							x = 35400,
							y = 9800,
							zoneId = 201,
							tooltip = L"Beastmaster Zakira",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
35400, 9800

Talk to "Beastmaster Zakira" the Kill Collector at Ruins of Anlec, Dark Elf Chapter 5.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Maefyr Fellwhip",
					mapPins =
					{
						{
							x = 5600,
							y = 10500,
							zoneId = 201,
							tooltip = L"Maefyr Fellwhip",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
5600, 10500

Talk to "Maefyr Fellwhip" the Kill Collector at Sundered Strand, Dark Elf Chapter 6.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Torrath Ullen",
					mapPins =
					{
						{
							x = 17600,
							y = 37600,
							zoneId = 201,
							tooltip = L"Torrath Ullen",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
17600, 37600

Talk to "Torrath Ullen" the Kill Collector at Ralkuth's Return, Dark Elf Chapter 7.
]],
				},
				
				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Captain Maldrak Blacktide",
					mapPins =
					{
						{
							x = 33000,
							y = 48700,
							zoneId = 201,
							tooltip = L"Captain Maldrak Blacktide",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
33000, 48700 - In RvR Lake

Talk to "Captain Maldrak Blacktide" the Keep Lord of Spite's Reach.
]],
				},
			},
		},

		{
			name = L"Ellyrion",
			entries =
			{
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Andalian Windrider",
					mapPins =
					{
						{
							x = 51800,
							y = 10500,
							zoneId = 207,
							tooltip = L"Andalian Windrider",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
51800, 10500

Talk to "Andalian Windrider" the Rally Master at Windrider Plain, High Elf Chapter 8.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Ithiloen Truedale",
					mapPins =
					{
						{
							x = 42700,
							y = 42100,
							zoneId = 207,
							tooltip = L"Ithiloen Truedale",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
42700, 42100

Talk to "Ithiloen Truedale" the Rally Master at Reaverspring, High Elf Chapter 9.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Quartermaster Aenil",
					mapPins =
					{
						{
							x = 53000,
							y = 11000,
							zoneId = 207,
							tooltip = L"Quartermaster Aenil",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
53000, 11000

Talk to "Quartermaster Aenil" the Kill Collector at Windrider Plain, High Elf Chapter 8.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Seer Jhoril",
					mapPins =
					{
						{
							x = 42500,
							y = 42000,
							zoneId = 207,
							tooltip = L"Seer Jhoril",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
42500, 42000

Talk to "Seer Jhoril" the Kill Collector at Reaverspring, High Elf Chapter 9.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Elandros Windcharger",
					mapPins =
					{
						{
							x = 34200,
							y = 34000,
							zoneId = 207,
							tooltip = L"Elandros Windcharger",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
34200, 34000 - In RvR Lake

Talk to "Elandros Windcharger" the Keep Lord of Cascades of Thunder.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Baromad Drakanth",
					mapPins =
					{
						{
							x = 4900,
							y = 10000,
							zoneId = 207,
							tooltip = L"Baromad Drakanth",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
4900, 10000

Talk to "Baromad Drakanth" the Rally Master at Brokenblade, Dark Elf Chapter 8.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Kesida Garalond",
					mapPins =
					{
						{
							x = 14300,
							y = 37800,
							zoneId = 207,
							tooltip = L"Kesida Garalond",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
14300, 37800

Talk to "Kesida Garalond" the Rally Master at Goldmead, Dark Elf Chapter 9.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Tracker Drazek Kar",
					mapPins =
					{
						{
							x = 5600,
							y = 10300,
							zoneId = 207,
							tooltip = L"Tracker Drazek Kar",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
5600, 10300

Talk to "Tracker Drazek Kar" the Kill Collector at Brokenblade, Dark Elf Chapter 8.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Taraj Kirak",
					mapPins =
					{
						{
							x = 14400,
							y = 37000,
							zoneId = 207,
							tooltip = L"Taraj Kirak",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
14400, 37000

Talk to "Taraj Kirak" the Kill Collector at Goldmead, Dark Elf Chapter 9.
]],
				},
				
				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Beastmaster Chevalor",
					mapPins =
					{
						{
							x = 34200,
							y = 34000,
							zoneId = 207,
							tooltip = L"Beastmaster Chevalor",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
34200, 34000 - In RvR Lake

Talk to "Beastmaster Chevalor" the Keep Lord of Cascades of Thunder.
]],
				},				
			},
		},

		{
			name = L"Avelorn",
			entries =
			{
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Cirribhir Strongwing",
					mapPins =
					{
						{
							x = 26900,
							y = 9300,
							zoneId = 202,
							tooltip = L"Cirribhir Strongwing",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
26900, 9300

Talk to "Cirribhir Strongwing" the Rally Master at Fernwood, High Elf Chapter 10.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Aeddriel Swiftspear",
					mapPins =
					{
						{
							x = 59700,
							y = 9700,
							zoneId = 202,
							tooltip = L"Aeddriel Swiftspear",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
59700, 9700

Talk to "Aeddriel Swiftspear" the Rally Master at Grimwater, High Elf Chapter 11.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Sethril Stillwater",
					mapPins =
					{
						{
							x = 45700,
							y = 34300,
							zoneId = 202,
							tooltip = L"Sethril Stillwater",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
45700, 34300

Talk to "Sethril Stillwater" the Rally Master at Whisperwood, High Elf Chapter 12.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Eliren Stormshade",
					mapPins =
					{
						{
							x = 42600,
							y = 55800,
							zoneId = 202,
							tooltip = L"Eliren Stormshade",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
42600, 55800

Talk to "Eliren Stormshade" at Gaen Mere warcamp.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Mesilhin Darkeagle",
					mapPins =
					{
						{
							x = 27300,
							y = 10000,
							zoneId = 202,
							tooltip = L"Mesilhin Darkeagle",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
27300, 10000

Talk to "Mesilhin Darkeagle" the Kill Collector at Fernwood, High Elf Chapter 10.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Elithaen Leafwind",
					mapPins =
					{
						{
							x = 60500,
							y = 9000,
							zoneId = 202,
							tooltip = L"Elithaen Leafwind",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
60500, 9000

Talk to "Elithaen Leafwind" the Kill Collector at Grimwater, High Elf Chapter 11.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Nalrothel Forestshadow",
					mapPins =
					{
						{
							x = 46000,
							y = 34200,
							zoneId = 202,
							tooltip = L"Nalrothel Forestshadow",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
46000, 34200

Talk to "Nalrothel Forestshadow" the Kill Collector at Whisperwood, High Elf Chapter 12.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Calithria Starleaf",
					mapPins =
					{
						{
							x = 29200,
							y = 53900,
							zoneId = 202,
							tooltip = L"Calithria Starleaf",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
29200, 53900 - In RvR Lake

Talk to "Calithria Starleaf" the Keep Lord of Ghrond's Sacristy.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Ilries Stillfury",
					mapPins =
					{
						{
							x = 5500,
							y = 12100,
							zoneId = 202,
							tooltip = L"Ilries Stillfury",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
5500, 12100

Talk to "Ilries Stillfury" the Rally Master at Burnwood, Dark Elf Chapter 10.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Sarava Scornblade",
					mapPins =
					{
						{
							x = 23500,
							y = 24400,
							zoneId = 202,
							tooltip = L"Sarava Scornblade",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
23500, 24400

Talk to "Sarava Scornblade" the Rally Master at Scornblade's Siege, Dark Elf Chapter 11.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Devak Bloodbane",
					mapPins =
					{
						{
							x = 4700,
							y = 45600,
							zoneId = 202,
							tooltip = L"Devak Bloodbane",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
4700, 45600

Talk to "Devak Bloodbane" the Rally Master at Jade Coast, Dark Elf Chapter 12.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Lord Vilkareth",
					mapPins =
					{
						{
							x = 17700,
							y = 55000,
							zoneId = 202,
							tooltip = L"Lord Vilkareth",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
17700, 55000

Talk to "Lord Vilkareth" at Isha's Fall warcamp.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Uzoe Ra'an",
					mapPins =
					{
						{
							x = 5000,
							y = 12100,
							zoneId = 202,
							tooltip = L"Uzoe Ra'an",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
5000, 12100

Talk to "Uzoe Ra'an" the Kill Collector at Burnwood, Dark Elf Chapter 10.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Garak Zornil",
					mapPins =
					{
						{
							x = 22400,
							y = 23300,
							zoneId = 202,
							tooltip = L"Garak Zornil",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
22400, 23300

Talk to "Garak Zornil" the Kill Collector at Scornblade's Siege, Dark Elf Chapter 11.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Seleis Soronil",
					mapPins =
					{
						{
							x = 7800,
							y = 45300,
							zoneId = 202,
							tooltip = L"Seleis Soronil",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
7800, 45300

Talk to "Seleis Soronil" the Kill Collector at Jade Coast, Dark Elf Chapter 12.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Shadow-Matron Lyrandris",
					mapPins =
					{
						{
							x = 29200,
							y = 53900,
							zoneId = 202,
							tooltip = L"Shadow-Matron Lyrandris",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
29200, 53900 - In RvR Lake

Talk to "Shadow-Matron Lyrandris" the Keep Lord of Ghrond's Sacristy.
]],
				},
			},
		},

		{
			name = L"Saphery",
			entries =
			{
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Berliol Shadowseer",
					mapPins =
					{
						{
							x = 52300,
							y = 4400,
							zoneId = 208,
							tooltip = L"Berliol Shadowseer",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
52300, 4400

Talk to "Berliol Shadowseer" the Rally Master at Thornvale Manor, High Elf Chapter 13.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Menuthil Fargaze",
					mapPins =
					{
						{
							x = 55700,
							y = 45300,
							zoneId = 208,
							tooltip = L"Menuthil Fargaze",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
55700, 45300

Talk to "Menuthil Fargaze" the Rally Master at Menuthil's Burden, High Elf Chapter 14.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Dekindes Tovliryn",
					mapPins =
					{
						{
							x = 51500,
							y = 6200,
							zoneId = 208,
							tooltip = L"Dekindes Tovliryn",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
51500, 6200

Talk to "Dekindes Tovliryn" the Kill Collector at Thornvale Manor, High Elf Chapter 13.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Ilfuwyr Cetaine",
					mapPins =
					{
						{
							x = 54500,
							y = 43900,
							zoneId = 208,
							tooltip = L"Ilfuwyr Cetaine",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
54500, 43900

Talk to "Ilfuwyr Cetaine" the Kill Collector at Menuthil's Burden, High Elf Chapter 14.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Loremaster Litharia Moonblade",
					mapPins =
					{
						{
							x = 17400,
							y = 15900,
							zoneId = 208,
							tooltip = L"Loremaster Litharia Moonblade",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
17400, 15900 - In RvR Lake

Talk to "Loremaster Litharia Moonblade" the Keep Lord of Well of Qhaysh.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Morithia Shadowblight",
					mapPins =
					{
						{
							x = 11200,
							y = 6700,
							zoneId = 208,
							tooltip = L"Morithia Shadowblight",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
11200, 6700

Talk to "Morithia Shadowblight" the Rally Master at Knife's Edge, Dark Elf Chapter 13.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Kyaran Noth",
					mapPins =
					{
						{
							x = 8300,
							y = 34000,
							zoneId = 208,
							tooltip = L"Kyaran Noth",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
8300, 34000

Talk to "Kyaran Noth" the Rally Master at Kyaran's Advance, Dark Elf Chapter 14.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Nyethan Blackblade",
					mapPins =
					{
						{
							x = 9800,
							y = 5000,
							zoneId = 208,
							tooltip = L"Nyethan Blackblade",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
9800, 5000

Talk to "Nyethan Blackblade" the Kill Collector at Knife's Edge, Dark Elf Chapter 13.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Chorane",
					mapPins =
					{
						{
							x = 10000,
							y = 35000,
							zoneId = 208,
							tooltip = L"Chorane",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
10000, 35000

Talk to "Chorane" the Kill Collector at Kyaran's Advance, Dark Elf Chapter 14.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Velkaris Nightblade",
					mapPins =
					{
						{
							x = 17400,
							y = 15900,
							zoneId = 208,
							tooltip = L"Velkaris Nightblade",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
17400, 15900 - In RvR Lake

Talk to "Velkaris Nightblade" the Keep Lord of Well of Qhaysh.
]],
				},
			},
		},

		{
			name = L"The Lost Vale",
			entries =
			{
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Sonael Lyranon",
					mapPins =
					{
						{
							x = 33300,
							y = 47300,
							zoneId = 260,
							tooltip = L"Sonael Lyranon",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
33300, 47300

Talk to "Sonael Lyranon" the Rally Master on the starting beach.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Handmaiden Emrala",
					mapPins =
					{
						{
							x = 32700,
							y = 46300,
							zoneId = 260,
							tooltip = L"Handmaiden Emrala",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
32800, 46300

Talk to "Handmaiden Emrala" on the beach straight ahead.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Rolf",
					mapPins =
					{
						{
							x = 32900,
							y = 46300,
							zoneId = 260,
							tooltip = L"Rolf",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
32900, 46300

Talk to "Rolf" on the beach straight ahead, (the only human).
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Sammog the Smith",
					mapPins =
					{
						{
							x = 33300,
							y = 47100,
							zoneId = 260,
							tooltip = L"Sammog the Smith",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
33300, 47100

Talk to "Sammog the Smith", left of the caree trainer (the only Dwarf).
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Alarielle, the Everqueen",
					mapPins =
					{
						{
							x = 18600,
							y = 42900,
							zoneId = 260,
							tooltip = L"Alarielle, the Everqueen",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
18600, 42900

Talk to "Spirit of Alarielle", the spirit of the Everqueen that apppears after the first boss (and at several other time in the dungeon)
]],
				},
			},
		},

		{
			name = L"Eataine",
			entries =
			{
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Aelthyan Brightblade",
					mapPins =
					{
						{
							x = 61300,
							y = 13000,
							zoneId = 209,
							tooltip = L"Aelthyan Brightblade",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
61300, 13000

Talk to "Aelthyan Brightblade" the Rally Master at Goldenvale Manor, High Elf Chapter 15.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Saelir Haleril",
					mapPins =
					{
						{
							x = 20100,
							y = 18000,
							zoneId = 209,
							tooltip = L"Saelir Haleril",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
20100, 18000

Talk to "Saelir Haleril" the Rally Master at Haleril's Resolve, High Elf Chapter 16.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Arithan Stormbreaker",
					mapPins =
					{
						{
							x = 36400,
							y = 26700,
							zoneId = 209,
							tooltip = L"Arithan Stormbreaker",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
36400, 26700

Talk to "Arithan Stormbreaker" Eataine Mustering warcamp. Standing on a platform next to a bolt thrower, looking down over the bridge into the RvR lake.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Braen Tallofel",
					mapPins =
					{
						{
							x = 60900,
							y = 12100,
							zoneId = 209,
							tooltip = L"Braen Tallofel",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
60900, 12100

Talk to "Braen Tallofel" the Kill Collector at Goldenvale Manor, High Elf Chapter 15.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Dinen Lothreull",
					mapPins =
					{
						{
							x = 19000,
							y = 18400,
							zoneId = 209,
							tooltip = L"Dinen Lothreull",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
19000, 18400

Talk to "Dinen Lothreull" the Kill Collector at Haleril's Resolve, High Elf Chapter 16.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"???",
					mapPins =
					{
						{
							x = 17100,
							y = 38000,
							zoneId = 209,
							tooltip = L"???",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
17100, 38000 - In RvR Lake

Talk to "???" the Keep Lord of Pillars of Remembrence.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"???",
					mapPins =
					{
						{
							x = 54600,
							y = 34500,
							zoneId = 209,
							tooltip = L"???",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
54600, 34500 - In RvR Lake

Talk to "???" the Keep Lord of Arbor of Light.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Hellis Vileclaw",
					mapPins =
					{
						{
							x = 2300,
							y = 55700,
							zoneId = 209,
							tooltip = L"Hellis Vileclaw",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
2300, 55700

Talk to "Hellis Vileclaw" the Rally Master at Honor's Scourge, Dark Elf Chapter 20.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Hathdror Lightslayer",
					mapPins =
					{
						{
							x = 21800,
							y = 44800,
							zoneId = 209,
							tooltip = L"Hathdror Lightslayer",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
21800, 44800

Talk to "Hathdror Lightslayer" the Rally Master at Lightslayer's Umbrage, Dark Elf Chapter 21.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Morelan Darkslayer",
					mapPins =
					{
						{
							x = 43600,
							y = 43600,
							zoneId = 209,
							tooltip = L"Morelan Darkslayer",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
43600, 43600

Talk to "Morelan Darkslayer" the Rally Master at Asuryan's End, Dark Elf Chapter 22.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Koridrel Ebonshard",
					mapPins =
					{
						{
							x = 27500,
							y = 42000,
							zoneId = 209,
							tooltip = L"Koridrel Ebonshard",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
27500, 42000

Talk to "Koridrel Ebonshard" at Ebonhold Watch warcamp.

Currently not listed in the Tome, but still giving an unlock. Will NOT currently tick off.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Thandros Uthorin",
					mapPins =
					{
						{
							x = 1800,
							y = 55200,
							zoneId = 209,
							tooltip = L"Thandros Uthorin",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
1800, 55200

Talk to "Thandros Uthorin" the Kill Collector at Honor's Scourge, Dark Elf Chapter 20.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Telurna Darkveil",
					mapPins =
					{
						{
							x = 20000,
							y = 44000,
							zoneId = 209,
							tooltip = L"Telurna Darkveil",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
20000, 44000

Talk to "Telurna Darkveil" the Kill Collector at Lightslayer's Umbrage, Dark Elf Chapter 21.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Zural Bitterwind",
					mapPins =
					{
						{
							x = 44500,
							y = 44900,
							zoneId = 209,
							tooltip = L"Zural Bitterwind",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
44500, 44900

Talk to "Zural Bitterwind" the Kill Collector at Asuryan's End, Dark Elf Chapter 22.
]],
				},
			},
		},

		{
			name = L"Dragonwake",
			entries =
			{
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Aenarma Fellwater",
					mapPins =
					{
						{
							x = 61300,
							y = 21300,
							zoneId = 205,
							tooltip = L"Aenarma Fellwater",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
61300, 21300

Talk to "Aenarma Fellwater" the Rally Master at Caelanriol, High Elf Chapter 17.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Hithandror Oakbrow",
					mapPins =
					{
						{
							x = 45700,
							y = 22000,
							zoneId = 205,
							tooltip = L"Hithandror Oakbrow",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
45700, 22000

Talk to "Hithandror Oakbrow" the Rally Master at Oakbrow's Charge, High Elf Chapter 18.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Haelynar Silverstar",
					mapPins =
					{
						{
							x = 6800,
							y = 47300,
							zoneId = 205,
							tooltip = L"Haelynar Silverstar",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
6800, 47300

Talk to "Haelynar Silverstar" the Rally Master at Spires of Vaul, High Elf Chapter 19.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Prince Endhil",
					mapPins =
					{
						{
							x = 2100,
							y = 54500,
							zoneId = 205,
							tooltip = L"Prince Endhil",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
2100, 54500

Talk to "Prince Endhil" the Rally Master at Cinderblade, High Elf Chapter 20.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Irathir Fierceblade",
					mapPins =
					{
						{
							x = 2800,
							y = 26100,
							zoneId = 205,
							tooltip = L"Irathir Fierceblade",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
2800, 26100

Talk to "Irathir Fierceblade" at Drakewarden Keep warcamp. Standing next to the bolt thrower over the bridge towards PvE.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Firithas Lossaryn",
					mapPins =
					{
						{
							x = 61800,
							y = 21100,
							zoneId = 205,
							tooltip = L"Firithas Lossaryn",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
61800, 21100

Talk to "Firithas Lossaryn" the Kill Collector at Caelanriol, High Elf Chapter 17.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Celanar Orithwyn",
					mapPins =
					{
						{
							x = 46200,
							y = 22700,
							zoneId = 205,
							tooltip = L"Celanar Orithwyn",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
46200, 22700

Talk to "Celanar Orithwyn" the Kill Collector at Oakbrow's Charge, High Elf Chapter 18.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Virian Corresyn",
					mapPins =
					{
						{
							x = 6800,
							y = 47300,
							zoneId = 205,
							tooltip = L"Virian Corresyn",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
6800, 47300

Talk to "Virian Corresyn" the Kill Collector at Spires of Vaul, High Elf Chapter 19.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Lasinon Silverdawn",
					mapPins =
					{
						{
							x = 2700,
							y = 55300,
							zoneId = 205,
							tooltip = L"Lasinon Silverdawn",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
2700, 55300

Talk to "Lasinon Silverdawn" the Kill Collector at Cinderblade, High Elf Chapter 20.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"???",
					mapPins =
					{
						{
							x = 18500,
							y = 31300,
							zoneId = 205,
							tooltip = L"???",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
18500, 31300 - In RvR Lake

Talk to "???" the Keep Lord of Drakebreaker's Scourge.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"???",
					mapPins =
					{
						{
							x = 37600,
							y = 30300,
							zoneId = 205,
							tooltip = L"???",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
37600, 30300 - In RvR Lake

Talk to "???" the Keep Lord of Covenant of Flame.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Taenia Scarletmoon",
					mapPins =
					{
						{
							x = 1500,
							y = 11000,
							zoneId = 205,
							tooltip = L"Taenia Scarletmoon",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
1500, 11000

Talk to "Taenia Scarletmoon" the Rally Master at Saruthil's Wake, Dark Elf Chapter 17.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Taromir Sarath",
					mapPins =
					{
						{
							x = 27800,
							y = 17000,
							zoneId = 205,
							tooltip = L"Taromir Sarath",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
27800, 17000

Talk to "Taromir Sarath" the Rally Master at Taromir's Malice, Dark Elf Chapter 18.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Hyethan Baneblade",
					mapPins =
					{
						{
							x = 52300,
							y = 48400,
							zoneId = 205,
							tooltip = L"Hyethan Baneblade",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
52300, 48400

Talk to "Hyethan Baneblade" the Rally Master at Celrath Pass, Dark Elf Chapter 19.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Korana Bloodmoon",
					mapPins =
					{
						{
							x = 52600,
							y = 45300,
							zoneId = 205,
							tooltip = L"Korana Bloodmoon",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
52600, 45300

Talk to "Korana Bloodmoon" at Drakeslayer Hold warcamp.

Currently not listed in the Tome, but still giving an unlock. Will NOT currently tick off.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Krathar Dreyalan",
					mapPins =
					{
						{
							x = 1500,
							y = 11500,
							zoneId = 205,
							tooltip = L"Krathar Dreyalan",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
1500, 11500

Talk to "Krathar Dreyalan" the Kill Collector at Saruthil's Wake, Dark Elf Chapter 17.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Rindhor Swartshield",
					mapPins =
					{
						{
							x = 26100,
							y = 15200,
							zoneId = 205,
							tooltip = L"Rindhor Swartshield",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
26100, 15200

Talk to "Rindhor Swartshield" the Kill Collector at Taromir's Malice, Dark Elf Chapter 18.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Krellian Certhren",
					mapPins =
					{
						{
							x = 53000,
							y = 46800,
							zoneId = 205,
							tooltip = L"Krellian Certhren",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
53000, 46800

Talk to "Krellian Certhren" the Kill Collector at Celrath Pass, Dark Elf Chapter 19.
]],
				},
			},
		},

		{
			name = L"Caledor",
			entries =
			{
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Eralion Drakestar",
					mapPins =
					{
						{
							x = 49400,
							y = 51200,
							zoneId = 203,
							tooltip = L"Eralion Drakestar",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
49400, 51200

Talk to "Eralion Drakestar" the Rally Master at Drakestar's Lament, High Elf Chapter 21.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Aen Cinderblood",
					mapPins =
					{
						{
							x = 16400,
							y = 50200,
							zoneId = 203,
							tooltip = L"Aen Cinderblood",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
16400, 50200

Talk to "Aen Cinderblood" the Rally Master at Asuryan's Reach, High Elf Chapter 22.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Kaelys Firestar",
					mapPins =
					{
						{
							x = 28700,
							y = 39400,
							zoneId = 203,
							tooltip = L"Kaelys Firestar",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
28700, 39400

Talk to "Kaelys Firestar" at Conqueror's Descent warcamp. Standing in the middle next to the wagon.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Seladon Thistlewind",
					mapPins =
					{
						{
							x = 48900,
							y = 50400,
							zoneId = 203,
							tooltip = L"Seladon Thistlewind",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
48900, 50400

Talk to "Seladon Thistlewind" the Kill Collector at Drakestar's Lament, High Elf Chapter 21.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Arnien Brightwater",
					mapPins =
					{
						{
							x = 16700,
							y = 51000,
							zoneId = 203,
							tooltip = L"Arnien Brightwater",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
16700, 51000

Talk to "Arnien Brightwater" the Kill Collector at Asuryan's Reach, High Elf Chapter 22.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"???",
					mapPins =
					{
						{
							x = 2100,
							y = 31900,
							zoneId = 203,
							tooltip = L"???",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
2100, 31900 - In RvR Lake

Talk to "???" the Keep Lord of Hatred's Way.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"???",
					mapPins =
					{
						{
							x = 44900,
							y = 32300,
							zoneId = 203,
							tooltip = L"???",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
44900, 32300 - In RvR Lake

Talk to "???" the Keep Lord of Wrath's Resolve.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Thalyn Marr",
					mapPins =
					{
						{
							x = 1000,
							y = 24000,
							zoneId = 203,
							tooltip = L"Thalyn Marr",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
1000, 24000

Talk to "Thalyn Marr" the Rally Master at Crimson Scar, Dark Elf Chapter 15.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Velathor Lashstrider",
					mapPins =
					{
						{
							x = 45600,
							y = 7700,
							zoneId = 203,
							tooltip = L"Velathor Lashstrider",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
45600, 7700

Talk to "Velathor Lashstrider" the Rally Master at Drakeshadow, Dark Elf Chapter 16.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Valensyl Furysworn",
					mapPins =
					{
						{
							x = 27700,
							y = 23400,
							zoneId = 203,
							tooltip = L"Valensyl Furysworn",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
27700, 23400

Talk to "Valensyl Furysworn" at Conqueror's Watch warcamp.

Currently not listed in the Tome, but still giving an unlock. Will NOT currently tick off.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Karithan Aveth",
					mapPins =
					{
						{
							x = 700,
							y = 23200,
							zoneId = 203,
							tooltip = L"Karithan Aveth",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
700, 23200

Talk to "Karithan Aveth" the Kill Collector at Crimson Scar, Dark Elf Chapter 15.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Moridyth Cethlan",
					mapPins =
					{
						{
							x = 46100,
							y = 7700,
							zoneId = 203,
							tooltip = L"Moridyth Cethlan",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
46100, 7700

Talk to "Moridyth Cethlan" the Kill Collector at Drakeshadow, Dark Elf Chapter 16.
]],
				},
			},
		},
	},
}
