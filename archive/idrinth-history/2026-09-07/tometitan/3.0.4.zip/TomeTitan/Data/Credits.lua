TTitan.Data.Credits = {}

function TTitan.Data.Credits.GetData()
	return TTitan.Data.Credits.RawData
end

function TTitan.Data.Credits.FilterData()
end

TTitan.Data.Credits.RawData =
{
	header = L"FAQ & Credits",
	categories =
	{
		{
			name = L"FAQ",
			entries =
			{
				{
					name = L"About this Add-on",
					text =
[[
Welcome to Tome Titan! The purpose of this add-on is to bring information on unlocks posted in various locations here in-game in an easy to read and find format.

In short: To keep you from having to alt-tab!

We have information on Bestiary, History & Lore, and Noteworthy Persons unlocks as well for the Achievements; Dungeons, Explorations, and Pursuits. The add-on will also track if unlocks have been completed and can either hide them altogther, or mark them as completed, accordingly. With the update to version 3, also come map pin that will mark the unlock locations onto you ingame map.


To add a macro for easy access to Tome Titan, open the Main Menu, select Macros, and use this as your macro text:

/script TTitan.UI.ToggleShowing()

You can also make a macro for going to the current zone:

/script TTitan.UI.ExpandCurrentZone(); TTitan.UI.Show()

Please use "/ttitan help" for a full list of commands.
]],
				},

				{
					name = L"How often is it updated?",
					text =
[[
This is being updated for RoR, so things get added slowly and some existing unlocks get broken. We are trying to update all entries with clear and consistant locations and descriptions.

No set time line for updates exists.
]],
				},

				{
					name = L"Can you add...",
					text =
[[
If there is something you have found not included or you know of another way to unlock something.

Please send an in game mail to Ardora (Order) or Grizlet (Destro).

Include

 - Which faction it is for
 - A clear location
 - A clear description

We can then look to check it out and get it added if possible.
]],
				},
			},
		},

		{
			name = L"Credits",
			entries =
			{
				{
					name = L"The Tome Titan Team",
					text =
[[
Tome Titan was orignally created for WAR AOR with credit to "Aenathel, Oscarr and SquigyStardust"

This is currently being updated by Ardora, with the new data for ROR to give it a new lease of life for those that love running around for sweet unlock numbers!

Additional fixes and maintenance by "Zaru/Grimgog".
]],
				},
			},
		},

		{
			name = L"Changes",
			entries =
			{

				{
					name = L"Version 3.0.4 - Release Polish",
					text =
[[
Final data and UI checks before release.

- Added missing T2 and T3 Destruction Keep Lord entries.
- Added missing map pins for T3 Order Keep Lord entries.
- Corrected placeholder Keep Lord entries in The Badlands and Black Fire Pass.
- Added missing Land of the Dead Bestiary entries with map pins and realm filtering.
- Fixed the add-on description so History & Lore displays correctly.
]]
				},

				{
					name = L"Version 3.0.3 - UI and Map Pin Improvements",
					text =
[[
Improved the main UI, map pins, and utility tools.

- Completed entries are now easier to see in the list.
- Map pin tooltips now follow the mouse like normal in-game tooltips.
- Map pin tooltips hide repeated Bestiary title lines and map-only location notes.
- Added an icon browser for selecting better interface icons.
- Improved icon browser scrolling and filtered out blank icon results.
]]
				},

				{
					name = L"Version 3.0.2 - Bestiary Kill Progress",
					text =
[[
Reworked the Bestiary kill page into a useful progress tracker.

- Added a full Kills.lua data file for Bestiary kill unlocks.
- Grouped kills by Bestiary group, subgroup, and creature type.
- Added encounter, kill 25, kill 100, kill 1,000, kill 10,000, kill 100,000, and kill 1,000,000 entries where available.
- Added readable task and reward text for kill unlocks.
- Added Legendary Monsters to the Bestiary kill progress page.
]]
				},

				{
					name = L"Version 3.0.1 - Bestiary Data Fixes",
					text =
[[
Fixed Bestiary completion checks and cleaned up release data.

- Fixed shared task names such as "What do We Have Here?" so only the correct Bestiary entry completes.
- Cleaned entry notes and corrected Bestiary IDs.
- Removed unused plant data and references.
]]
				},

				{
					name = L"Version 3.0.0 - RoR Rebuild",
					text =
[[
Initial Tome Titan version 3 for Return of Reckoning.

- Added map pins for most unlocks.
- Added map pin tooltip support.
- Map pin refresh on map change resolved - Credit Zaru/Grimgog
- Added hide completed support for both the list and map pins.
- Updated Bestiary, History & Lore, and Noteworthy Persons data for many RoR zones.
- Added Karaz-a-Karak and Karak Eight Peaks sections.
- Updated Exploration and Pursuit achievement sections.
]]
				},				
			},
		},
	},
}
