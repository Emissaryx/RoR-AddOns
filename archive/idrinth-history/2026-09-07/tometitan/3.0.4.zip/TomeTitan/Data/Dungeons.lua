TTitan.Data.Dungeons = {}

function TTitan.Data.Dungeons.GetData()
	return TTitan.Data.Dungeons.RawData
end

function TTitan.Data.Dungeons.FilterData()
	TTitan.Data.FilterByRealm(TTitan.Data.Dungeons.RawData)
end

TTitan.Data.Dungeons.RawData =
{
	header = L"Dungeons Achievements",
	categories =
	{
		{
			name = L"Bastion Stair",
			entries =
			{
				{
					name = L"Defeated Hard Mode Thar'Ignan",
					text =
[[
Click on the skull pile to the left as you enter to activate hardmode before starting the fight.
]],
				},
				
				{
					name = L"Defeated Hard Mode Thar'Ignan 5 times",
					text =
[[
Click on the skull pile to the left as you enter to activate hardmode before starting the fight.
]],
				},
								
				{
					name = L"Defeated Hard Mode Thar'Ignan 10 times",
					text =
[[
Click on the skull pile to the left as you enter to activate hardmode before starting the fight.
]],
				},
				
				{
					name = L"Defeated Hard Mode Lord Slaurith",
					text =
[[
Click on the skull pile to the left as you enter to activate hardmode before starting the fight.
]],
				},
								
				{
					name = L"Defeated Hard Mode Lord Slaurith 5 times",
					text =
[[
Click on the skull pile to the left as you enter to activate hardmode before starting the fight.
]],
				},
								
				{
					name = L"Defeated Hard Mode Lord Slaurith 10 times",
					text =
[[
Click on the skull pile to the left as you enter to activate hardmode before starting the fight.
]],
				},
								
				{
					name = L"Defeated Hard Mode Kaarn",
					text =
[[
Click on the skull pile to the left against the stairs to activate hardmode before starting the fight.
]],
				},
								
				{
					name = L"Defeated Hard Mode Kaarn 5 times",
					text =
[[
Click on the skull pile to the left against the stairs to activate hardmode before starting the fight.
]],
				},
								
				{
					name = L"Defeated Hard Mode Kaarn 10 times",
					text =
[[
Click on the skull pile to the left against the stairs to activate hardmode before starting the fight.
]],
				},
				
				{
					name = L"Defeated Hard Mode Skull Lord Var'Ithrok",
					text =
[[
Click on the skull pile to the left as you reach the top platform to activate hardmode before starting the fight.
]],
				},
												
				{
					name = L"Defeated Hard Mode Skull Lord Var'Ithrok 5 times",
					text =
[[
Click on the skull pile to the left as you reach the top platform to activate hardmode before starting the fight.
]],
				},
												
				{
					name = L"Defeated Hard Mode Skull Lord Var'Ithrok 10 times",
					text =
[[
Click on the skull pile to the left as you reach the top platform to activate hardmode before starting the fight.
]],
				},
												
				{
					name = L"Conquered All Bastion Stair Hard Mode Fights",
					text =
[[
Defeat all Bastion Stair bosses once on hard modes.
]],
				},
																
				{
					name = towstring([["I want Murr Deyng!"]]),
					text =
[[
Defeated Murr Deyng two times
]],
				},
																
				{
					name = towstring([[Murr Deyng, my beloved"]]),
					text =
[[
Defeated Murr Deyng five times
]],
				},
																
				{
					name = L"Blood of my Blood",
					text =
[[
Defeated Murr Deyng ten times
]],
				},
																
				{
					name = L"Once more, with feeling",
					text =
[[
Defeated The Collector two times
]],
				},
																
				{
					name = L"High Five",
					text =
[[
Defeated The Collector five times
]],
				},
																
				{
					name = L"Champion of Champions",
					text =
[[
Defeated The Collector ten times
]],
				},
																
				{
					name = L"Murr Deyng, we choose you!",
					text =
[[
Defeated The Collector after sparing Murr Deyng.
]],
				},
			},
		},
	
		{
			name = L"Dragonback Pass",
			entries =
			{
				{
					name = L"Da Masta' Plan",
					mapPins =
					{
						{
							x = 37900,
							y = 33300,
							zoneId = 36,
							tooltip = L"Da Masta' Plan",
							icon = "TTitan_Pin_Dungeons",
						},
					},
					text =
[[
37900, 33300

Click on "Kordhal's Klad", behind a log, against the tower wall.
]],
				},
			
				{
					name = L"You can fly!",
					mapPins =
					{
						{
							x = 43100,
							y = 30800,
							zoneId = 36,
							tooltip = L"You can fly!",
							icon = "TTitan_Pin_Dungeons",
						},
					},
					text =
[[
43100, 30800
				
Click on "Pilot Heads", a pike with two impaled heads, on the right side of the large skull effigy up on the ledge.
]],
				},

				{
					name = L"Lessons for Beardlings",
					mapPins =
					{
						{
							x = 27500,
							y = 38300,
							zoneId = 36,
							tooltip = L"Lessons for Beardlings",
							icon = "TTitan_Pin_Dungeons",
						},
					},
					text =
[[
27500, 38300
				
Click on "Borradin's Axe" in the corner of the wall section.
]],
				},

				{
					name = L"How hard can it be?",
					mapPins =
					{
						{
							x = 23500,
							y = 37200,
							zoneId = 36,
							tooltip = L"How hard can it be?",
							icon = "TTitan_Pin_Dungeons",
						},
					},
					text =
[[
23500, 37200
				
Click on "Gyrocopter Repair Manual" on the edge of the gyrocopter pad, just left of the steps.
]],
				},

				{
					name = L"In Remembrance",
					mapPins =
					{
						{
							x = 32900,
							y = 34700,
							zoneId = 36,
							tooltip = L"In Remembrance",
							icon = "TTitan_Pin_Dungeons",
						},
					},
					text =
[[
32900, 34700
				
Click on "Gungnir's Own", some bottles on the bridge on the North side by the large head.
]],
				},

				{
					name = L"Da Masta' Plan",
					text =
[[
Complete the 5 unlocks above.
]],
				},
			},
		},
			
		{
			name = L"Hunter's Vale",
			entries =
			{
				{
					name = L"Entered the Hunter's Vale",
					text =
[[
Enter the Hunter's Vale dungeon.
]],
				},
			
				{
					name = L"Culling the Weak",
					mapPins =
					{
						{
							x = 26000,
							y = 36600,
							zoneId = 50,
							tooltip = L"Culling the Weak",
							icon = "TTitan_Pin_Dungeons",
						},
					},
					text =
[[
26000, 36600

Click on "Fallen Squig Herder" in the tree roots, near where the path bends South.
]],
				},

				{
					name = L"Sundered Bonds",
					mapPins =
					{
						{
							x = 25000,
							y = 40600,
							zoneId = 50,
							tooltip = L"Sundered Bonds",
							icon = "TTitan_Pin_Dungeons",
						},
					},
					text =
[[
25000, 40600

Click on "Fallen Sorceress", inside the fallen hollow log, just South of the road before the first boss.
]],
				},

				{
					name = L"Floater",
					mapPins =
					{
						{
							x = 31600,
							y = 34300,
							zoneId = 50,
							tooltip = L"Floater",
							icon = "TTitan_Pin_Dungeons",
						},
					},
					text =
[[

]],
				},

				{
					name = L"Get the Point?",
					mapPins =
					{
						{
							x = 33100,
							y = 29700,
							zoneId = 50,
							tooltip = L"Get the Point?",
							icon = "TTitan_Pin_Dungeons",
						},
					},
					text =
[[

]],
				},
				
				{
					name = L"Burn, Witch, Burn!",
					mapPins =
					{
						{
							x = 37200,
							y = 35600,
							zoneId = 50,
							tooltip = L"Burn, Witch, Burn!",
							icon = "TTitan_Pin_Dungeons",
						},
					},
					text =
[[

]],
				},
								
				{
					name = L"Starved for Attention",
					mapPins =
					{
						{
							x = 36200,
							y = 39200,
							zoneId = 50,
							tooltip = L"Starved for Attention",
							icon = "TTitan_Pin_Dungeons",
						},
					},
					text =
[[

]],
				},

				{
					name = L"Killed the Three Mothers in Under 5 Minutes",
					text =
[[
Kill "Peregra the Hound Mother", "Vorasyx the Wolf-Mother" and "?? the Lion Mother" within 5 minutes of each other.
]],
				},
				
				{
					name = L"Drank from the Hartsblood Draft",
					text =
[[
Take "Hartsblood Draft" from the bag given for completing the dungeon, and use it.
]],
				},
				
				{
					name = L"Cleared all of the Heroes of the Hunter's Vale",
					text =
[[
Kill all four extra heroes (Spite, Dryad, Great Stag and Great Eagle) and clear the dungeon.
]],
				},
				
				{
					name = L"Defeated Kurnous in under 35 Minutes",
					text =
[[
Clear the dungeon less than 35 minutes.
]],
				},
			},
		},
		
		{
			name = L"Lost Vale",
			entries =
			{
				{
					name = L"Rescued your ally from the Darkpromise Beast",
					mapPins =
					{
						{
							x = 33500,
							y = 43800,
							zoneId = 260,
							tooltip = L"Rescued your ally from the Darkpromise Beast",
							icon = "TTitan_Pin_Dungeons",
						},
					},
					text =
[[
Quickly "kill" the darkpromise beast at the start of the dungeon to rescue Rolf.
]],
				},

				{
					name = L"Defeated Ahzranok without popping more than 5 eggs",
					mapPins =
					{
						{
							x = 19100,
							y = 43000,
							zoneId = 260,
							tooltip = L"Defeated Ahzranok without popping more than 5 eggs",
							icon = "TTitan_Pin_Dungeons",
						},
					},
					text =
[[
Don't kill too many eggs!
]],
				},

				{
					name = L"Defeated Malghor after stepping in 40 Musks",
					mapPins =
					{
						{
							x = 24100,
							y = 42500,
							zoneId = 260,
							tooltip = L"Defeated Malghor after stepping in 40 Musks",
							icon = "TTitan_Pin_Dungeons",
						},
					},
					text =
[[
Just stack up those musks!
]],
				},

				{
					name = L"Beat the Darkpromise Beast after two or more allies died",
					mapPins =
					{
						{
							x = 19000,
							y = 29600,
							zoneId = 260,
							tooltip = L"Beat the Darkpromise Beast after two or more allies died",
							icon = "TTitan_Pin_Dungeons",
						},
					},
					text =
[[
Let two people die before you kill it.
]],
				},

				{
					name = L"Defeated Dralel without a Tank using their torch first",
					mapPins =
					{
						{
							x = 20500,
							y = 21100,
							zoneId = 260,
							tooltip = L"Defeated Dralel without a Tank using their torch first",
							icon = "TTitan_Pin_Dungeons",
						},
					},
					text =
[[
Any non-tank class breaks out first each time, at 80, 60, 40 and 20 percent.
]],
				},

				{
					name = L"Defeated Chul after stealing his meat",
					mapPins =
					{
						{
							x = 52500,
							y = 35100,
							zoneId = 260,
							tooltip = L"Defeated Chul after stealing his meat",
							icon = "TTitan_Pin_Dungeons",
						},
					},
					text =
[[
Grab the meat barrel in the cave in the water as the fight starts.
]],
				},

				{
					name = L"Defeated Butcher Gutbeater killing fewer than 4 Gnoblars",
					mapPins =
					{
						{
							x = 46200,
							y = 47100,
							zoneId = 260,
							tooltip = L"Defeated Butcher Gutbeater killing fewer than 4 Gnoblars",
							icon = "TTitan_Pin_Dungeons",
						},
					},
					text =
[[
Only kill the Gnoblars at around 75, 50 and 25 percent.
]],
				},

				{
					name = L"Defeated Gorak after killing Stormspite",
					mapPins =
					{
						{
							x = 41500,
							y = 32800,
							zoneId = 260,
							tooltip = L"Defeated Gorak after killing Stormspite",
							icon = "TTitan_Pin_Dungeons",
						},
					},
					text =
[[
Get the boss low, then kill the manticore, and then finish the boss fast.
]],
				},

				{
					name = L"Defeated Sarthain without killing any Corruptors",
					mapPins =
					{
						{
							x = 47600,
							y = 25200,
							zoneId = 260,
							tooltip = L"Defeated Sarthain without killing any Corruptors",
							icon = "TTitan_Pin_Dungeons",
						},
					},
					text =
[[
Just unga bunga the boss, heal debuff helps.
]],
				},

				{
					name = L"Defeated Zaar after leaving allies in cages for 2 minutes",
					mapPins =
					{
						{
							x = 31500,
							y = 9600,
							zoneId = 260,
							tooltip = L"Defeated Zaar after leaving allies in cages for 2 minutes",
							icon = "TTitan_Pin_Dungeons",
						},
					},
					text =
[[
As it says, be slow getting people out of cages, just watch the buff timers.
]],
				},

				{
					name = L"Defeated Horgulul without killing either Swellspawn",
					mapPins =
					{
						{
							x = 40900,
							y = 3500,
							zoneId = 260,
							tooltip = L"Defeated Horgulul without killing either Swellspawn",
							icon = "TTitan_Pin_Dungeons",
						},
					},
					text =
[[
Again just unga bunga with aoe.
]],
				},

				{
					name = L"Defeated Sechar while killing less than 20 trash mobs",
					mapPins =
					{
						{
							x = 48600,
							y = 9400,
							zoneId = 260,
							tooltip = L"Defeated Sechar while killing less than 20 trash mobs",
							icon = "TTitan_Pin_Dungeons",
						},
					},
					text =
[[
Leave the heal debuff pillar up, and you'll get this most times.
]],
				},

				{
					name = L"Defeated N'Kari with an ally getting one of each desire",
					mapPins =
					{
						{
							x = 56400,
							y = 6700,
							zoneId = 260,
							tooltip = L"Defeated N'Kari with an ally getting one of each desire",
							icon = "TTitan_Pin_Dungeons",
						},
					},
					text =
[[
Just rotate one person getting the yellow, blue and red on each channel phase.
]],
				},

				{
					name = L"Completed all the Lost Vale Hard-mode Tasks",
					text =
[[
Complete all of the above.
]],
				},

				{
					name = L"Clicked the Brazier a few times too many",
					mapPins =
					{
						{
							x = 19100,
							y = 22700,
							zoneId = 260,
							tooltip = L"Clicked the Brazier a few times too many",
							icon = "TTitan_Pin_Dungeons",
						},
					},
					text =
[[
Spam click the brazier (over 100 times), it will let you know when you are done.
]],
				},

				{
					name = L"Pick 20 Darkpromise Flowers",
					text =
[[
Just pick the pretty flowers.
]],
				},

				{
					name = L"Beat the Butcher without eating a Tiny Horse or Cow",
					mapPins =
					{
						{
							x = 47400,
							y = 46100,
							zoneId = 260,
							tooltip = L"Beat the Butcher without eating a Tiny Horse or Cow",
							icon = "TTitan_Pin_Dungeons",
						},
					},
					text =
[[
Throw in Wilbur for the meat.
]],
				},

				{
					name = L"Summoned and Defeated Syndestra",
					mapPins =
					{
						{
							x = 34700,
							y = 36500,
							zoneId = 260,
							tooltip = L"Summoned and Defeated Syndestra",
							icon = "TTitan_Pin_Dungeons",
						},
					},
					text =
[[
Kill all the mini bosses and then summon Syndestra by clicking the pillars and defeat her.
]],
				},

				{
					name = L"Completed all Secrets and Hard Mode Unlocks in Lost Vale",
					text =
[[
Complete all of the above.
]],
				},
			},
		},
		
		{
			name = L"Mount Gunbad",
			entries =
			{
				{
					name = L"Defeated Hard Mode Glomp",
					mapPins =
					{
						{
							x = 43700,
							y = 47600,
							zoneId = 60,
							tooltip = L"Defeated Hard Mode Glomp",
							icon = "TTitan_Pin_Dungeons",
						},
					},
					text =
[[
43700, 47600

Use the mushroom at the back right of the boss chamber to activate hardmode before starting the fight.
]],
				},
				
				{
					name = L"Defeated Hard Mode Masta Mixa",
					mapPins =
					{
						{
							x = 27700,
							y = 43000,
							zoneId = 60,
							tooltip = L"Defeated Hard Mode Masta Mixa",
							icon = "TTitan_Pin_Dungeons",
						},
					},
					text =
[[
27700, 43000

Use the item on the left side of the boss chamber to activate hardmode before starting the fight.
]],
				},
				
				{
					name = L"Defeated Hard Mode Solithex",
					mapPins =
					{
						{
							x = 0,
							y = 0,
							zoneId = 0,
							tooltip = L"Defeated Hard Mode Solithex",
							icon = "TTitan_Pin_Dungeons",
						},
					},
					text =
[[
???, ???

Use the skeleton on the ledge on the left side as you enter the boss chamber to activate hardmode before starting the fight.
]],
				},
				
				{
					name = L"Defeated Hard Mode Ard Ta Feed",
					mapPins =
					{
						{
							x = 0,
							y = 0,
							zoneId = 0,
							tooltip = L"Defeated Hard Mode Ard Ta Feed",
							icon = "TTitan_Pin_Dungeons",
						},
					},
					text =
[[
???, ???

Use the item on the left side of the boss chamber to activate hardmode before starting the fight.
]],
				},
				
				{
					name = L"Conquered All Gunbad Hard Mode Fights",
					text =
[[
Complete all four of the above boss hard modes.
]],
				},
			},
		},
	},
}
