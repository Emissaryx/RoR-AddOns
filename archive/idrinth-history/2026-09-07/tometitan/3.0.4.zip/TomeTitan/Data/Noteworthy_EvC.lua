TTitan.Data.NoteworthyEvC = {}

function TTitan.Data.NoteworthyEvC.GetData()
	return TTitan.Data.NoteworthyEvC.RawData
end

function TTitan.Data.NoteworthyEvC.FilterData()
	TTitan.Data.FilterByRealm(TTitan.Data.NoteworthyEvC.RawData)
end

TTitan.Data.NoteworthyEvC.RawData =
{
	header = L"Noteworthy Persons Unlocks - Empire vs Chaos",
	categories =
	{
		{
			name = L"Nordland",
			entries =
			{
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Eldred Krebs",
					mapPins =
					{
						{
							x = 26200,
							y = 54400,
							zoneId = 106,
							tooltip = L"Eldred Krebs",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
26200, 54400

Talk to "Eldred Krebs" the Rally Master at Grimmenhagen Village, Empire Chapter 1.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Werner Fassbinder",
					mapPins =
					{
						{
							x = 21700,
							y = 27600,
							zoneId = 106,
							tooltip = L"Werner Fassbinder",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
21700, 27600

Talk to "Werner Fassbinder" the Rally Master at Grey lady Coaching Inn, Empire Chapter 2.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"General Breuer",
					mapPins =
					{
						{
							x = 32000,
							y = 18600,
							zoneId = 106,
							tooltip = L"General Breuer",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
32000, 18600

Talk to "General Breuer" the Rally Master at Breuer's Regiment, Empire Chapter 3.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Captain Arnholdt",
					mapPins =
					{
						{
							x = 29200,
							y = 19200,
							zoneId = 106,
							tooltip = L"Captain Arnholdt",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
29200, 19200

Talk to "Captain Arnholdt" at Arnholdt's Company warcamp. They are in the middle standing next to the steamtank.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Caemris Sharpspear",
					mapPins =
					{
						{
							x = 23600,
							y = 40300,
							zoneId = 106,
							tooltip = L"Caemris Sharpspear",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
23600, 40300

Talk to "Caemris Sharpspear" the Kill Collector for Empire Chapter 1. They are at "Grimmenhagen Windmill" major landmark.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Edwin Hulsemann",
					mapPins =
					{
						{
							x = 20600,
							y = 26200,
							zoneId = 106,
							tooltip = L"Edwin Hulsemann",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
20600, 26200

Talk to "Edwin Hulsemann" the Kill Collector at Breuer's Regiment, Empire Chapter 2.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Lieutenant Boen Scharmdorf",
					mapPins =
					{
						{
							x = 31500,
							y = 20700,
							zoneId = 106,
							tooltip = L"Lieutenant Boen Scharmdorf",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
31500, 20700

Talk to "Lieutenant Boen Scharmdorf" the Kill Collector at Breuer's Regiment, Empire Chapter 3.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Volshehk",
					mapPins =
					{
						{
							x = 41800,
							y = 900,
							zoneId = 106,
							tooltip = L"Volshehk",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
41800, 900

Talk to "Volshehk" the Rally Master at Death's Brink, Chaos Chapter 3.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Authun Skandsen",
					mapPins =
					{
						{
							x = 57700,
							y = 19800,
							zoneId = 106,
							tooltip = L"Authun Skandsen",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
57700, 19800

Talk to "Authun Skandsen" the Rally Master at Authun's Host, Chaos Chapter 4.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Creve Avdvare",
					mapPins =
					{
						{
							x = 29200,
							y = 19200,
							zoneId = 106,
							tooltip = L"Creve Avdvare",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
29200, 19200

Talk to "Creve Avdvare" at Blessed Gathering warcamp. They are next to the Flight Master.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Orlyg Raud",
					mapPins =
					{
						{
							x = 41700,
							y = 1400,
							zoneId = 106,
							tooltip = L"Orlyg Raud",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
41700, 1400

Talk to "Orlyg Raud" the Kill Collector at Death's Brink, Chaos Chapter 3.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Golen",
					mapPins =
					{
						{
							x = 57900,
							y = 20800,
							zoneId = 106,
							tooltip = L"Golen",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
57900, 20800

Talk to "Golen" the Kill Collector at Authun's Host, Chaos Chapter 4.
]],
				},
			},
		},

		{
			name = L"Norsca",
			entries =
			{
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Captain Kleinke",
					mapPins =
					{
						{
							x = 55000,
							y = 57400,
							zoneId = 100,
							tooltip = L"Captain Kleinke",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
54700, 57400

Talk to "Captain Kleinke" the Rally Master at Gotland Advance, Empire Chapter 4.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Thomas Schmidt",
					mapPins =
					{
						{
							x = 54700,
							y = 57100,
							zoneId = 100,
							tooltip = L"Thomas Schmidt",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
54700, 57400

Talk to "Thomas Schmidt" the Kill Collector at Gotland Advance, Empire Chapter 4.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"The Eidolon",
					mapPins =
					{
						{
							x = 35000,
							y = 12200,
							zoneId = 100,
							tooltip = L"The Eidolon",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
35000, 12200

Talk to "The Eidolon" the Rally Master at Unshackled Host, Chaos Chapter 1.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Haldar",
					mapPins =
					{
						{
							x = 36800,
							y = 32500,
							zoneId = 100,
							tooltip = L"Haldar",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
36800, 32500

Talk to "Haldar" the Rally Master at Sorcerer's Axiom, Chaos Chapter 2.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Vaulkor",
					mapPins =
					{
						{
							x = 34000,
							y = 14000,
							zoneId = 100,
							tooltip = L"Vaulkor",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
34000, 14000

Talk to "Vaulkor" the Kill Collector at Unshackled Host, Chaos Chapter 1.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Vasili Tomarev",
					mapPins =
					{
						{
							x = 36300,
							y = 33500,
							zoneId = 100,
							tooltip = L"Vasili Tomarev",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
36300, 33500

Talk to "Vasili Tomarev" the Kill Collector at Sorcerer's Axiom, Chaos Chapter 2.
]],
				},
			},
		},

		{
			name = L"Troll Country",
			entries =
			{
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Siegmund Kraemer",
					mapPins =
					{
						{
							x = 6200,
							y = 23500,
							zoneId = 101,
							tooltip = L"Siegmund Kraemer",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
6200, 23500

Talk to "Siegmund Kraemer" the Rally Master at Suskarg, Empire Chapter 5.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Captain Oswin Breitenbach",
					mapPins =
					{
						{
							x = 17300,
							y = 53700,
							zoneId = 101,
							tooltip = L"Captain Oswin Breitenbach",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
17300, 53700

Talk to "Captain Oswin Breitenbach" the Rally Master at Felde Castle, Empire Chapter 6.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Presbyter Fromme",
					mapPins =
					{
						{
							x = 39500,
							y = 61800,
							zoneId = 101,
							tooltip = L"Presbyter Fromme",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
39500, 61800

Talk to "Presbyter Fromme" an NPC at Bramble Hollow warcamp. They are on the south side standing next to the large red & white tent.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Ruthgar",
					mapPins =
					{
						{
							x = 6200,
							y = 23500,
							zoneId = 101,
							tooltip = L"Ruthgar",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
6200, 23500

Talk to "Ruthgar" the Kill Collector at Suskarg, Empire Chapter 5.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Dieter Stroh",
					mapPins =
					{
						{
							x = 17300,
							y = 53700,
							zoneId = 101,
							tooltip = L"Dieter Stroh",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
17300, 53700

Talk to "Dieter Stroh" the Kill Collector at Felde Castle, Empire Chapter 6.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Soren Trolkarl",
					mapPins =
					{
						{
							x = 2400,
							y = 56500,
							zoneId = 101,
							tooltip = L"Soren Trolkarl",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
2400, 56500 - In RvR lake

Talk to "Soren Trolkarl" the Keep Lord at Stonetroll Keep.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Gunvor",
					mapPins =
					{
						{
							x = 12900,
							y = 62300,
							zoneId = 101,
							tooltip = L"Gunvor",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
12900, 62300

Talk to "Gunvor" the Rally Master at Felde, Chaos Chapter 6.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Halza",
					mapPins =
					{
						{
							x = 42100,
							y = 39300,
							zoneId = 101,
							tooltip = L"Halza",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
42100, 39300

Talk to "Halza" the Rally Master at Trovolek Advance, Chaos Chapter 8.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Yggdren",
					mapPins =
					{
						{
							x = 54200,
							y = 16400,
							zoneId = 101,
							tooltip = L"Yggdren",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
54200, 16400

Talk to "Yggdren" the Rally Master at Trollhaugen, Chaos Chapter 9.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Gottfried Holz",
					mapPins =
					{
						{
							x = 12200,
							y = 63000,
							zoneId = 101,
							tooltip = L"Gottfried Holz",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
12200, 63000

Talk to "Gottfried Holz" the Kill Collector at Felde, Chaos Chapter 6.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Nina",
					mapPins =
					{
						{
							x = 42800,
							y = 39500,
							zoneId = 101,
							tooltip = L"Nina",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
42800, 39500

Talk to "Nina" the Kill Collector at Trovolek Advance, Chaos Chapter 8.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Lilja Shadowdrinker",
					mapPins =
					{
						{
							x = 54900,
							y = 15600,
							zoneId = 101,
							tooltip = L"Lilja Shadowdrinker",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
54900, 15600

Talk to "Lilja Shadowdrinker" the Kill Collector at Trollhaugen, Chaos Chapter 9.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Thrain Trollhelm",
					mapPins =
					{
						{
							x = 2400,
							y = 56500,
							zoneId = 101,
							tooltip = L"Thrain Trollhelm",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
2400, 56500 - In RvR lake

Talk to "Thrain Trollhelm" the Keep Lord at Stonetroll Keep.
]],
				},
			},
		},

		{
			name = L"Ostland",
			entries =
			{
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Sergeant Kraussner",
					mapPins =
					{
						{
							x = 54000,
							y = 1900,
							zoneId = 107,
							tooltip = L"Sergeant Kraussner",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
54000, 1900

Talk to "Sergeant Kraussner" the Rally Master at Kraussner's Garrison, Empire Chapter 7.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Demona Gaertner",
					mapPins =
					{
						{
							x = 32400,
							y = 26200,
							zoneId = 107,
							tooltip = L"Demona Gaertner",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
32400, 26200

Talk to "Demona Gaertner" the Rally Master at Bohsenfels, Empire Chapter 8.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Liebert Naubhof",
					mapPins =
					{
						{
							x = 48800,
							y = 54000,
							zoneId = 107,
							tooltip = L"Liebert Naubhof",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
48800, 54000

Talk to "Liebert Naubhof" the Rally Master at Wolfenburg Inn, Empire Chapter 9.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Farmer Nadezhda",
					mapPins =
					{
						{
							x = 53300,
							y = 1900,
							zoneId = 107,
							tooltip = L"Farmer Nadezhda",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
53300, 1900

Talk to "Farmer Nadezhda" the Kill Collector at Kraussner's Garrison, Empire Chapter 7.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Droki Greybeard",
					mapPins =
					{
						{
							x = 30700,
							y = 26300,
							zoneId = 107,
							tooltip = L"Droki Greybeard",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
30700, 26300

Talk to "Droki Greybeard" the Kill Collector at Bohsenfels, Empire Chapter 8.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Dieter Totenhosen",
					mapPins =
					{
						{
							x = 49200,
							y = 51200,
							zoneId = 107,
							tooltip = L"Dieter Totenhosen",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
49200, 51200

Talk to "Dieter Totenhosen" the Kill Collector at Wolfenburg Inn, Empire Chapter 9.
]],
				},
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Helmut Eisenfaust",
					mapPins =
					{
						{
							x = 39500,
							y = 4000,
							zoneId = 107,
							tooltip = L"Helmut Eisenfaust",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
39500, 4000 - In RvR lake

Talk to "Helmut Eisenfaust" the Keep Lord at Mandred's Hold.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Turaanos",
					mapPins =
					{
						{
							x = 7800,
							y = 27200,
							zoneId = 107,
							tooltip = L"Turaanos",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
7800, 27200

Talk to "Turaanos" the Rally Master at Ferlangen, Chaos Chapter 5.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Kournar",
					mapPins =
					{
						{
							x = 53300,
							y = 12300,
							zoneId = 107,
							tooltip = L"Kournar",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
53300, 12300

Talk to "Kournar the Chosen" the Rally Master at Kournar's Encampment, Chaos Chapter 7.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Zaccur the Despised",
					mapPins =
					{
						{
							x = 28100,
							y = 5100,
							zoneId = 107,
							tooltip = L"Zaccur the Despised",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
28100, 5100

Talk to "Zaccur the Despised" at Ravens Edge Warcamp.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Rangrith",
					mapPins =
					{
						{
							x = 7400,
							y = 26900,
							zoneId = 107,
							tooltip = L"Rangrith",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
7400, 26900

Talk to "Rangrith" the Kill Collector at Ferlangen, Chaos Chapter 5.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Tosha Schreiber",
					mapPins =
					{
						{
							x = 52900,
							y = 11700,
							zoneId = 107,
							tooltip = L"Tosha Schreiber",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
52900, 11700

Talk to "Tosha Schreiber" the Kill Collector at Kournar's Encampment, Chaos Chapter 7.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Hrothgar Bludbjorn",
					mapPins =
					{
						{
							x = 39500,
							y = 4000,
							zoneId = 107,
							tooltip = L"Hrothgar Bludbjorn",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
39500, 4000 - In RvR lake

Talk to "Hrothgar Bludbjorn" the Keep Lord at Mandred's Hold.
]],
				},
			},
		},

		{
			name = L"High Pass",
			entries =
			{
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Captain Nuhr",
					mapPins =
					{
						{
							x = 4400,
							y = 28500,
							zoneId = 102,
							tooltip = L"Captain Nuhr",
							icon = "TTitan_Pin_Noteworthy",
						},
					},


					text =
[[
4400, 28500

Talk to "Captain Nuhr" the Rally Master at Nuhr's Crest, Empire Chapter 10.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Grizela Hirtzel",
					mapPins =
					{
						{
							x = 9300,
							y = 58200,
							zoneId = 102,
							tooltip = L"Grizela Hirtzel",
							icon = "TTitan_Pin_Noteworthy",
						},
					},


					text =
[[
9300, 58200

Talk to "Grizela Hirtzel" the Rally Master at Raven's End, Empire Chapter 11.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Konrad Riese",
					mapPins =
					{
						{
							x = 43000,
							y = 57100,
							zoneId = 102,
							tooltip = L"Konrad Riese",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
43000, 57100

Talk to "Konrad Riese" the Rally Master at Bitter Woods, Empire Chapter 12.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Teodor Hennschel",
					mapPins =
					{
						{
							x = 35600,
							y = 56800,
							zoneId = 102,
							tooltip = L"Teodor Hennschel",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
35600, 56800

Talk to "Teodor Hennschel" an NPC at Dogbite Ridge Warcamp. They are on the east side of the camp standing next to a rock.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Rolf Grimwold",
					mapPins =
					{
						{
							x = 4400,
							y = 28500,
							zoneId = 102,
							tooltip = L"Rolf Grimwold",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
4400, 28500

Talk to "Rolf Grimwold" the Kill Collector at Nuhr's Crest, Empire Chapter 10.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Vilmer DonHeisen",
					mapPins =
					{
						{
							x = 9300,
							y = 58200,
							zoneId = 102,
							tooltip = L"Vilmer DonHeisen",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
9300, 58200

Talk to "Vilmer DonHeisen" the Kill Collector at Raven's End, Empire Chapter 11.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Archibald Fleck",
					mapPins =
					{
						{
							x = 43800,
							y = 56000,
							zoneId = 102,
							tooltip = L"Archibald Fleck",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
43800, 56000

Talk to "Archibald Fleck" the Kill Collector at Bitter Woods, Empire Chapter 12.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Thalia Embersight",
					mapPins =
					{
						{
							x = 4600,
							y = 55800,
							zoneId = 102,
							tooltip = L"Thalia Embersight",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
4600, 55800 - In RvR lake

Talk to "Thalia Embersight" the Keep Lord at Stoneclaw Castle.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Urun",
					mapPins =
					{
						{
							x = 37300,
							y = 32300,
							zoneId = 102,
							tooltip = L"Urun",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
37300, 32300

Talk to "Urun" the Rally Master at Bloodmarr, Chaos Chapter 13.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Albodi the Scarred",
					mapPins =
					{
						{
							x = 49000,
							y = 20700,
							zoneId = 102,
							tooltip = L"Albodi the Scarred",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
49000, 20700

Talk to "Albodi the Scarred" the Rally Master at Jaggedspine Ridge, Chaos Chapter 14.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Kaltea Wyrmreaver",
					mapPins =
					{
						{
							x = 35500,
							y = 32800,
							zoneId = 102,
							tooltip = L"Kaltea Wyrmreaver",
							icon = "TTitan_Pin_Noteworthy",
						},
					},


					text =
[[
35500, 32800

Talk to "Kaltea Wyrmreaver" the Kill Collector at Bloodmarr, Chaos Chapter 13.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Norrmar Boneblade",
					mapPins =
					{
						{
							x = 49000,
							y = 22400,
							zoneId = 102,
							tooltip = L"Norrmar Boneblade",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
49000, 22400

Talk to "Norrmar Boneblade" the Kill Collector at Jaggedspine Ridge, Chaos Chapter 14.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Malakar Dreadspine",
					mapPins =
					{
						{
							x = 4600,
							y = 55800,
							zoneId = 102,
							tooltip = L"Malakar Dreadspine",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
4600, 55800 - In RvR lake

Talk to "Malakar Dreadspine" the Keep Lord at Stoneclaw Castle.
]],
				},
			},
		},

		{
			name = L"Talabecland",
			entries =
			{
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Captain Melicent Drauwulf",
					mapPins =
					{
						{
							x = 61600,
							y = 9700,
							zoneId = 108,
							tooltip = L"Captain Melicent Drauwulf",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
61600, 9700

Talk to "Captain Melicent Drauwulf" the Rally Master at Hergig Landing, Empire Chapter 13.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Emil Trachsel",
					mapPins =
					{
						{
							x = 44500,
							y = 43400,
							zoneId = 108,
							tooltip = L"Emil Trachsel",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
44500, 43400

Talk to "Emil Trachsel" the Rally Master at One Tree Hill, Empire Chapter 14.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Borak Brightaxe",
					mapPins =
					{
						{
							x = 61600,
							y = 9700,
							zoneId = 108,
							tooltip = L"Borak Brightaxe",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
61600, 9700

Talk to "Borak Brightaxe" the Kill Collector at Hergig Landing, Empire Chapter 13.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Mary Delarue",
					mapPins =
					{
						{
							x = 44500,
							y = 43400,
							zoneId = 108,
							tooltip = L"Mary Delarue",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
44500, 43400

Talk to "Mary Delarue" the Kill Collector at One Tree Hill, Empire Chapter 14.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Emissary of the Inner Circle",
					mapPins =
					{
						{
							x = 37800,
							y = 7500,
							zoneId = 108,
							tooltip = L"Emissary of the Inner Circle",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
37800, 7500 - In RvR lake

Talk to "Emissary of the Inner Circle" the Keep Lord at Passwatch Keep.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Vul'toren",
					mapPins =
					{
						{
							x = 3400,
							y = 30000,
							zoneId = 108,
							tooltip = L"Vul'toren",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
3400, 30000

Talk to "Vul'toren" the Rally Master at Goblin's Head Coaching Inn, Chaos Chapter 10.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Arinbjorn",
					mapPins =
					{
						{
							x = 16200,
							y = 3800,
							zoneId = 108,
							tooltip = L"Arinbjorn",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
16200, 3800

Talk to "Arinbjorn" the Rally Master at Witches' Hollow, Chaos Chapter 11.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Ulvarin",
					mapPins =
					{
						{
							x = 42700,
							y = 5000,
							zoneId = 108,
							tooltip = L"Ulvarin",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
42700, 5000

Talk to "Ulvarin" the Rally Master at Volgen, Chaos Chapter 12.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Telva Silverwheel",
					mapPins =
					{
						{
							x = 22000,
							y = 5600,
							zoneId = 108,
							tooltip = L"Telva Silverwheel",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
22000, 5600

Talk to "Telva Silverwheel" an NPC at Hellfang Ridge warcamp.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Harkon Steinkell",
					mapPins =
					{
						{
							x = 2000,
							y = 29700,
							zoneId = 108,
							tooltip = L"Harkon Steinkell",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
2000, 29700

Talk to "Harkon Steinkell" the Kill Collector at Goblin's Head Coaching Inn, Chaos Chapter 10.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Fnord Bulweis",
					mapPins =
					{
						{
							x = 16300,
							y = 3500,
							zoneId = 108,
							tooltip = L"Fnord Bulweis",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
16300, 3500

Talk to "Fnord Bulweis" the Kill Collector at Witches' Hollow, Chaos Chapter 11.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Reikl Bloodpike",
					mapPins =
					{
						{
							x = 42500,
							y = 5000,
							zoneId = 108,
							tooltip = L"Reikl Bloodpike",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
42500, 5000

Talk to "Reikl Bloodpike" the Kill Collector at Volgen, Chaos Chapter 12.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Valthor Heldenfaust",
					mapPins =
					{
						{
							x = 37800,
							y = 7500,
							zoneId = 108,
							tooltip = L"Valthor Heldenfaust",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
37800, 7500 - In RvR lake

Talk to "Valthor Heldenfaust" the Keep Lord at Passwatch Keep.
]],
				},
			},
		},

		{
			name = L"Reikland",
			entries =
			{
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Elmeric Oberholzer",
					mapPins =
					{
						{
							x = 7700,
							y = 33400,
							zoneId = 109,
							tooltip = L"Elmeric Oberholzer",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
7700, 33400

Talk to "Elmeric Oberholzer" the Rally Master at Kreuznach, Empire Chapter 15.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Greta Machholt",
					mapPins =
					{
						{
							x = 18600,
							y = 15000,
							zoneId = 109,
							tooltip = L"Greta Machholt",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
18600, 15000

Talk to "Greta Machholt" the Rally Master at Reik River Observatory, Empire Chapter 16.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"General Walther Gellert",
					mapPins =
					{
						{
							x = 24000,
							y = 12600,
							zoneId = 109,
							tooltip = L"General Walther Gellert",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
24000, 12600

Talk to "General Walther Gellert" an NPC at Deathwatch Landing Warcamp. They are on the north west side of the camp standing behind a small table next to a tent.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Barnabus Kuhn",
					mapPins =
					{
						{
							x = 7700,
							y = 33400,
							zoneId = 109,
							tooltip = L"Barnabus Kuhn",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
7700, 33400

Talk to "Barnabus Kuhn" the Kill Collector at Kreuznach, Empire Chapter 15.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Sigrid Widmann",
					mapPins =
					{
						{
							x = 18600,
							y = 15000,
							zoneId = 109,
							tooltip = L"Sigrid Widmann",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
18600, 15000

Talk to "Sigrid Widmann" the Kill Collector at Reik River Observatory, Empire Chapter 16.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Wilhelm IV",
					text =
[[
30400, 27400 - In RvR lake

Talk to "Wilhelm IV" the Keep Lord at Wilhelm's Fist.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Nathandar the Pale",
					text =
[[
23000, 59600 - In RvR lake

Talk to "Nathandar the Pale" the Keep Lord at Morr's Repose.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Astryth the Reaver",
					mapPins =
					{
						{
							x = 48400,
							y = 8300,
							zoneId = 109,
							tooltip = L"Astryth the Reaver",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
48400, 8300

Talk to "Astryth the Reaver" the Rally Master at Mark of the Reaver, Chaos Chapter 20.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Chieftain Vanik",
					mapPins =
					{
						{
							x = 45500,
							y = 34300,
							zoneId = 109,
							tooltip = L"Chieftain Vanik",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
45500, 34300

Talk to "Chieftain Vanik" the Rally Master at Vanik's Horde, Chaos Chapter 21.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Khyathor",
					mapPins =
					{
						{
							x = 35000,
							y = 53500,
							zoneId = 109,
							tooltip = L"Khyathor",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
35000, 53500

Talk to "Khyathor" the Rally Master at The Inevitable Fire, Chaos Chapter 22.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Lord Xyshrenth",
					mapPins =
					{
						{
							x = 40500,
							y = 30500,
							zoneId = 109,
							tooltip = L"Lord Xyshrenth",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
40500, 30500

Talk to "Lord Xyshrenth" an NPC at Darkstone Vantage warcamp.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Jarl Spearfist",
					mapPins =
					{
						{
							x = 48000,
							y = 8100,
							zoneId = 109,
							tooltip = L"Jarl Spearfist",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
48000, 8100

Talk to "Jarl Spearfist" the Kill Collector at Mark of the Reaver, Chaos Chapter 20.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Amundr the Despoiler",
					mapPins =
					{
						{
							x = 44800,
							y = 34900,
							zoneId = 109,
							tooltip = L"Amundr the Despoiler",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
44800, 34900

Talk to "Amundr the Despoiler" the Kill Collector at Vanik's Horde, Chaos Chapter 21.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Gorfaug Manhewer",
					mapPins =
					{
						{
							x = 33300,
							y = 55500,
							zoneId = 109,
							tooltip = L"Gorfaug Manhewer",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
33300, 55500

Talk to "Gorfaug Manhewer" the Kill Collector at The Inevitable Fire, Chaos Chapter 22.
]],
				},
			},
		},

		{
			name = L"Praag",
			entries =
			{
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Captain Lieberholz",
					mapPins =
					{
						{
							x = 12500,
							y = 57000,
							zoneId = 105,
							tooltip = L"Captain Lieberholz",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
12500, 57000

Talk to "Captain Lieberholz" the Rally Master at Lieberholz's Command, Empire Chapter 17.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Captain Becker",
					mapPins =
					{
						{
							x = 15000,
							y = 49500,
							zoneId = 105,
							tooltip = L"Captain Becker",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
15000, 49500

Talk to "Captain Becker" the Rally Master at Death's Cross, Empire Chapter 18.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Krasa Falkenheim",
					mapPins =
					{
						{
							x = 28800,
							y = 24200,
							zoneId = 105,
							tooltip = L"Krasa Falkenheim",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
28800, 24200

Talk to "Krasa Falkenheim" the Rally Master at Knight's Watch, Empire Chapter 19.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"General Ludwig Klunst",
					mapPins =
					{
						{
							x = 15800,
							y = 35800,
							zoneId = 105,
							tooltip = L"General Ludwig Klunst",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
15800, 35800

Talk to "General Ludwig Klunst" an NPC at Westmark Barricade Warcamp. They are on the north side of the camp standing behind a small table next to a tent.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Hartlieb Roth",
					mapPins =
					{
						{
							x = 12500,
							y = 57000,
							zoneId = 105,
							tooltip = L"Hartlieb Roth",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
12500, 57000

Talk to "Hartlieb Roth" the Kill Collector at Lieberholz's Command, Empire Chapter 17.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Danil Balk",
					mapPins =
					{
						{
							x = 15000,
							y = 49500,
							zoneId = 105,
							tooltip = L"Danil Balk",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
15000, 49500

Talk to "Danil Balk" the Kill Collector at Death's Cross, Empire Chapter 18.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Guildmaster Geoff",
					mapPins =
					{
						{
							x = 28800,
							y = 24200,
							zoneId = 105,
							tooltip = L"Guildmaster Geoff",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
28800, 24200

Talk to "Guildmaster Geoff" the Kill Collector at Knight's Watch, Empire Chapter 19.
]],
				},
																				
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"???",
					text =
[[
35400, 11800 - In RvR Lake

Talk to "???" the Keep Lord of Garrison of Skulls.
]],
				},
								
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"???",
					text =
[[
36900, 62500 - In RvR Lake

Talk to "???" the Keep Lord of Southern Garrison.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Korzah the Exalted",
					mapPins =
					{
						{
							x = 6800,
							y = 10100,
							zoneId = 105,
							tooltip = L"Korzah the Exalted",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
6800, 10100

Talk to "Korzah the Exalted" the Rally Master at Korzah's Assault, Chaos Chapter 17.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Exalted Magus Thurik",
					mapPins =
					{
						{
							x = 48000,
							y = 4600,
							zoneId = 105,
							tooltip = L"Exalted Magus Thurik",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
48000, 4600

Talk to "Exalted Magus Thurik" the Rally Master at Daemonfire, Chaos Chapter 18.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Lord Xyshrenth",
					mapPins =
					{
						{
							x = 44700,
							y = 48100,
							zoneId = 105,
							tooltip = L"Lord Xyshrenth",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
44700, 48100

Talk to "Lord Xyshrenth" the Rally Master at Southern Breach, Chaos Chapter 19.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Magedon the Omnicient",
					mapPins =
					{
						{
							x = 44500,
							y = 38000,
							zoneId = 105,
							tooltip = L"Magedon the Omnicient",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
44500, 38000

Talk to "Magedon the Omniscient" an NPC at Ravensworn warcamp.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Aesa Heidrdottir",
					mapPins =
					{
						{
							x = 6500,
							y = 8400,
							zoneId = 105,
							tooltip = L"Aesa Heidrdottir",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
6500, 8400

Talk to "Aesa Heidrdottir" the Kill Collector at Korzah's Assault, Chaos Chapter 17.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Zalir Shadowtalon",
					mapPins =
					{
						{
							x = 47800,
							y = 5500,
							zoneId = 105,
							tooltip = L"Zalir Shadowtalon",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
47800, 5500

Talk to "Zalir Shadowtalon" the Kill Collector at Daemonfire, Chaos Chapter 18.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Lahkis Curseblade",
					mapPins =
					{
						{
							x = 45000,
							y = 47400,
							zoneId = 105,
							tooltip = L"Lahkis Curseblade",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
45000, 47400

Talk to "Lahkis Curseblade" the Kill Collector at Southern Breach, Chaos Chapter 19.
]],
				},
			},
		},

		{
			name = L"Chaos Wastes",
			entries =
			{
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Valdred Kaltenbach",
					mapPins =
					{
						{
							x = 20100,
							y = 62800,
							zoneId = 103,
							tooltip = L"Valdred Kaltenbach",
							icon = "TTitan_Pin_Noteworthy",
						},
					},


					text =
[[
20100, 62800

Talk to "Valdred Kaltenbach" the Rally Master at Kaltenbach Expedition, Empire Chapter 20.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Sigric Drakenhof",
					mapPins =
					{
						{
							x = 53400,
							y = 45600,
							zoneId = 103,
							tooltip = L"Sigric Drakenhof",
							icon = "TTitan_Pin_Noteworthy",
						},
					},


					text =
[[
53400, 45600

Talk to "Sigric Drakenhof" the Rally Master at Camp of the Faithful, Empire Chapter 21.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"General Vogel",
					mapPins =
					{
						{
							x = 61000,
							y = 5200,
							zoneId = 103,
							tooltip = L"General Vogel",
							icon = "TTitan_Pin_Noteworthy",
						},
					},


					text =
[[
61000, 5200

Talk to "General Vogel" the Rally Master at Fire of Sigmar, Empire Chapter 22.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Captain Kalder Tannenbach",
					mapPins =
					{
						{
							x = 45500,
							y = 37000,
							zoneId = 103,
							tooltip = L"Captain Kalder Tannenbach",
							icon = "TTitan_Pin_Noteworthy",
						},
					},


					text =
[[
45500, 37000

Talk to "Captain Kalder Tannenbach" an NPC at Tannenbach's Doom warcamp. They are on the west side looking at the ramp into PvP, right in front of the red and white tent.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Constable Luidheim",
					mapPins =
					{
						{
							x = 18200,
							y = 62700,
							zoneId = 103,
							tooltip = L"Constable Luidheim",
							icon = "TTitan_Pin_Noteworthy",
						},
					},


					text =
[[
18200, 62700

Talk to "Constable Luidheim" the Kill Collector at Kaltenbach Expedition, Empire Chapter 20.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Quartermaster Randol",
					mapPins =
					{
						{
							x = 53800,
							y = 46100,
							zoneId = 103,
							tooltip = L"Quartermaster Randol",
							icon = "TTitan_Pin_Noteworthy",
						},
					},


					text =
[[
53800, 46100

Talk to "Quartermaster Randol" the Kill Collector at Camp of the Faithful, Empire Chapter 21.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Harald Nacht",
					mapPins =
					{
						{
							x = 60800,
							y = 3000,
							zoneId = 103,
							tooltip = L"Harald Nacht",
							icon = "TTitan_Pin_Noteworthy",
						},
					},


					text =
[[
60800, 3000

Talk to "Harald Nacht" the Kill Collector at Fire of Sigmar, Empire Chapter 22.
]],
				},
																									
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"???",
					text =
[[
31600, 9400 - In RvR Lake

Talk to "???" the Keep Lord of Zimmeron's Hold.
]],
				},
								
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"???",
					text =
[[
38300, 43000 - In RvR Lake

Talk to "???" the Keep Lord of Charon's Keep.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Larus",
					mapPins =
					{
						{
							x = 2900,
							y = 5100,
							zoneId = 103,
							tooltip = L"Larus",
							icon = "TTitan_Pin_Noteworthy",
						},
					},


					text =
[[
2900, 5100

Talk to "Larus" the Rally Master at Deathchill, Chaos Chapter 15.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Ydreda",
					mapPins =
					{
						{
							x = 13000,
							y = 47400,
							zoneId = 103,
							tooltip = L"Ydreda",
							icon = "TTitan_Pin_Noteworthy",
						},
					},


					text =
[[
13000, 47400

Talk to "Ydreda" the Rally Master at Awakened Tempest, Chaos Chapter 16.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Loefret the Hatebringer",
					mapPins =
					{
						{
							x = 23700,
							y = 30500,
							zoneId = 103,
							tooltip = L"Loefret the Hatebringer",
							icon = "TTitan_Pin_Noteworthy",
						},
					},


					text =
[[
23700, 30500

Talk to "Loefret the Hatebringer" an NPC at Seven Shades Creep warcamp.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Xahiriek",
					mapPins =
					{
						{
							x = 3100,
							y = 6500,
							zoneId = 103,
							tooltip = L"Xahiriek",
							icon = "TTitan_Pin_Noteworthy",
						},
					},


					text =
[[
3100, 6500

Talk to "Xahiriek" the Kill Collector at Deathchill, Chaos Chapter 15.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Gorfing Headsmasha",
					mapPins =
					{
						{
							x = 12200,
							y = 46000,
							zoneId = 103,
							tooltip = L"Gorfing Headsmasha",
							icon = "TTitan_Pin_Noteworthy",
						},
					},


					text =
[[
12200, 46000

Talk to "Gorfing Headsmasha" the Kill Collector at Awakened Tempest, Chaos Chapter 16.
]],
				},
			},
		},
		
		{
			name = L"Bastion Stair",
			entries =
			{
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Captain Dunstan",
					mapPins =
					{
						{
							x = 34000,
							y = 46600,
							zoneId = 160,
							tooltip = L"Captain Dunstan",
							icon = "TTitan_Pin_Noteworthy",
						},
					},


					text =
[[
34000, 46600

Talk to "Captain Dunstan" the Rally Master in the starting lobby.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Mysterious Knight",
					mapPins =
					{
						{
							x = 33000,
							y = 46300,
							zoneId = 160,
							tooltip = L"Mysterious Knight",
							icon = "TTitan_Pin_Noteworthy",
						},
					},


					text =
[[
33000, 46300

Talk to "Mysterious Knight" on the right side of the entrance way.
]],
				},
				
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Hannah Eberly",
					mapPins =
					{
						{
							x = 32500,
							y = 46300,
							zoneId = 160,
							tooltip = L"Hannah Eberly",
							icon = "TTitan_Pin_Noteworthy",
						},
					},


					text =
[[
32500, 46300

Talk to "Hannah Eberly" on the left side of the entrance way.
]],
				},
				
				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Rakkoth Doomfist",
					mapPins =
					{
						{
							x = 34000,
							y = 46600,
							zoneId = 160,
							tooltip = L"Rakkoth Doomfist",
							icon = "TTitan_Pin_Noteworthy",
						},
					},


					text =
[[
34000, 46600

Talk to "Rakkoth Doomfist" the Rally Master in the starting lobby.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Voice of the Schemer",
					mapPins =
					{
						{
							x = 33000,
							y = 46300,
							zoneId = 160,
							tooltip = L"Voice of the Schemer",
							icon = "TTitan_Pin_Noteworthy",
						},
					},


					text =
[[
33000, 46300

Talk to "Voice of the Schemer" on the right side of the entrance way.
]],
				},
				
				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Jodis Wolfscar",
					mapPins =
					{
						{
							x = 32500,
							y = 46300,
							zoneId = 160,
							tooltip = L"Jodis Wolfscar",
							icon = "TTitan_Pin_Noteworthy",
						},
					},


					text =
[[
32500, 46300

Talk to "Jodis Wolfscar" on the left side of the entrance way.
]],
				},
			},
		},

		{
			name = L"Altdorf",
			entries =
			{
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"High King Thorgrim Grudgebearer",
					mapPins =
					{
						{
							x = 23200,
							y = 17200,
							zoneId = 162,
							tooltip = L"High King Thorgrim Grudgebearer",
							icon = "TTitan_Pin_Noteworthy",
						},
					},


					text =
[[
23200, 17500

Talk to "High King Thorgrim Grudgebearer" in the room west of the throne room in the "Palace" (Green area).

This will tick off as done if you have already talk to him in Karaz-a-Karak.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Emperor Karl Franz",
					mapPins =
					{
						{
							x = 25500,
							y = 17200,
							zoneId = 162,
							tooltip = L"Emperor Karl Franz",
							icon = "TTitan_Pin_Noteworthy",
						},
					},


					text =
[[
25500, 17200

Talk to "Emperor Karl Franz" standing in front of the throne, in the throne room of the "Palace" (Green area).
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Supreme Patriarch Thyrus Gormann",
					mapPins =
					{
						{
							x = 32200,
							y = 34300,
							zoneId = 162,
							tooltip = L"Supreme Patriarch Thyrus Gormann",
							icon = "TTitan_Pin_Noteworthy",
						},
					},


					text =
[[
32200, 34300 - Inside the Bright Wizard College, enter at this location.

Talk to "Patriarch Thyrus Gormann", he is straight ahead floating in a pillar of fire.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Gotrek and Felix",
					mapPins =
					{
						{
							x = 36400,
							y = 40000,
							zoneId = 162,
							tooltip = L"Gotrek and Felix",
							icon = "TTitan_Pin_Noteworthy",
						},
					},


					text =
[[
36400, 40000

Talk to "Gotrek Gurnisson" or "Felix Jaeger" inside the 'The Screaming Cat' tavern, at the southern end of the docks.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Phoenix King Finubar",
					mapPins =
					{
						{
							x = 23200,
							y = 17500,
							zoneId = 162,
							tooltip = L"Phoenix King Finubar",
							icon = "TTitan_Pin_Noteworthy",
						},
					},


					text =
[[
23200, 17500

Talk to "Phoenix King Finubar" in the room west of the throne room in the "Palace" (Green area).
]],
				},
			},
		},

		{
			name = L"The Inevitable City",
			entries =
			{
				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Grumlok",
					mapPins =
					{
						{
							x = 27800,
							y = 16600,
							zoneId = 161,
							tooltip = L"Grumlok",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
27800, 16600

Talk to "Grumlok" in the room west of the throne room in the "Citadel" (Pink area).
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Gazbag",
					mapPins =
					{
						{
							x = 27600,
							y = 16800,
							zoneId = 161,
							tooltip = L"Gazbag",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
27600, 16800

Talk to "Gazbag" in the room west of the throne room in the "Citadel" (Pink area).
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Tchar'zanek",
					mapPins =
					{
						{
							x = 30900,
							y = 17100,
							zoneId = 161,
							tooltip = L"Tchar'zanek",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
30900, 17100

Talk to "Tchar'zanek" in the throne room in the "Citadel" (Pink area).
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Engra Deathsword",
					mapPins =
					{
						{
							x = 42000,
							y = 33700,
							zoneId = 161,
							tooltip = L"Engra Deathsword",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
42000, 33700

Talk to "Engra Deathsword" in the middle of the arena.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Lycithas the Harridan Seer",
					mapPins =
					{
						{
							x = 22400,
							y = 37300,
							zoneId = 161,
							tooltip = L"Lycithas the Harridan Seer",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
22400, 37300

Talk to "Lycithas the Harridan Seer" inside the "Monolith" (Orange area), use the teleport inside to reach them.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Malekith",
					mapPins =
					{
						{
							x = 27600,
							y = 16900,
							zoneId = 161,
							tooltip = L"Malekith",
							icon = "TTitan_Pin_Noteworthy",
						},
					},
					text =
[[
27600, 16900

Talk to "Malekith" in the room west of the throne room in the "Citadel" (Pink area).
]],
				},
			},
		},
	},
}
