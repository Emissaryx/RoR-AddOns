TTitan.Data.BestiaryHEvDE = {}

function TTitan.Data.BestiaryHEvDE.GetData()
	return TTitan.Data.BestiaryHEvDE.RawData
end

function TTitan.Data.BestiaryHEvDE.FilterData()
	TTitan.Data.FilterByRealm(TTitan.Data.BestiaryHEvDE.RawData)
end

TTitan.Data.BestiaryHEvDE.RawData =
{
	header = L"Beastiary Unlocks - High Elves vs Dark Elves",
	categories =
	{
		{
			name = L"Non Zone-Based",
			entries =
			{
				{
					name = L"Dark Elf (Title)",
					text =
[[
Dark Elf - Complete a Dark Elf Scenario
"Ulthuan's Avenger"

Win a Caledor Woods Scenario.
]],
				},

				{
					name = L"High Elf (Title)",
					text =
[[
High Elf - Complete a High Elf Scenario
"Scourge of the Asur"

Win any High Elf themed scenario.
]],
				},
			},
		},

		{
			name = L"The Blighted Isle",
			entries =
			{
				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Bandit (Title)",
					mapPins =
					{
						{
							x = 11400,
							y = 10000,
							zoneId = 200,
							tooltip = L"Bandit - Talk of the Town",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Bandit - Talk of the Town
"The Bounty Hunter"

11400, 10000

Talk to "Uthorin Sorceress" along the road up from the Dark Elf prologue area.
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Bandit (Title)",
					mapPins =
					{
						{
							x = 11400,
							y = 10000,
							zoneId = 200,
							tooltip = L"Bandit - Talk of the Town",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Bandit - Talk of the Town
"The Bounty Hunter"

11400, 10000

Kill "Uthorin Sorceress" along the road up from the Dark Elf prologue area.
]],
				},

				{
					name = L"Giant Lizard (Title)",
					mapPins =
					{
						{
							x = 36100,
							y = 20000,
							zoneId = 200,
							tooltip = L"Giant Lizard - A Matter of Scales",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Giant Lizard - A Matter of Scales
"The Lizard Hunter"

36100, 20000

Equip "Scaly Skin" pocket item droped by "Scorch Tail" lizards inside "Fire Crystal Caverns" minor landmark.
]],
				},

				{
					name = L"Horror (Pocket)",
					mapPins =
					{
						{
							x = 21300,
							y = 37800,
							zoneId = 200,
							tooltip = L"Horror - Where Did You All Go?",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Horror - Where Did You All Go?
POCKET ITEM

21300, 37800

Kill "Lost Horror" on the hills west of "Stone of Daroir Lacorith" major landmark.
]],
				},


				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Scorpion, Giant (Tactic)",
					mapPins =
					{
						{
							x = 8400,
							y = 62900,
							zoneId = 200,
							tooltip = L"Scorpion, Giant - A Pinch to Grow an Inch",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Scorpion, Giant - A Pinch to Grow an Inch
BESTIAL TOME TACTIC

8400, 62900

Kill "Poisonblight Scorpion" mobs, to complete the Kill Collector for "Poisonblade Heath", Dark Elf Chapter 3. The kill collector is south of the area in Chrace.
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Scorpion, Giant (Tactic)",
					mapPins =
					{
						{
							x = 49000,
							y = 36500,
							zoneId = 200,
							tooltip = L"Scorpion, Giant - A Pinch to Grow an Inch",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Scorpion, Giant - A Pinch to Grow an Inch
BESTIAL TOME TACTIC

49000, 36500

Kill "Blighted Scorpion" mobs, to complete the Kill Collector at "Adunei", High Elf Chapter 2.
]],
				},

				{
					name = L"Scorpion, Giant (Title)",
					mapPins =
					{
						{
							x = 2600,
							y = 62400,
							zoneId = 200,
							tooltip = L"Scorpion, Giant - Beach Bum",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Scorpion, Giant - Beach Bum
"The Scorpion Squisher"

2600, 62400

Kill "Bane Claw" wandering on the end of the sand islands in the far south west of the map.
]],
				},

				{
					name = L"Snotling (Title)",
					mapPins =
					{
						{
							x = 48780,
							y = 48300,
							zoneId = 200,
							tooltip = L"Snotling - And I Just Cleaned My Boots",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Snotling - And I Just Cleaned My Boots
"The Peculiar"

48780, 48300

Click on "Loose Rock" a boulder on the edge of a rock above a sleeping snotling.
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Spite (Title)",
					mapPins =
					{
						{
							x = 54000,
							y = 52500,
							zoneId = 200,
							tooltip = L"Spite - Looking for Shinnies",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Spite - Looking for Shinnies
"The Spite Splitter"

54000, 52500

Equip "Shining Ring" dropped by "Dark Spite" mobs around the waystone north west of "Ruins of Erraneth" PQ.
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Warhawk (Tactic)",
					mapPins =
					{
						{
							x = 51800,
							y = 22200,
							zoneId = 200,
							tooltip = L"Warhawk - Bird Watching ... Up Close, in Person",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Warhawk - Bird Watching ... Up Close, in Person
BESTIAL TOME TACTIC

51800, 22200

Kill "Crag Great Wing" a neutral mob, on the edge of the cliff behind the trees.
]],
				},

				{
					name = L"Witch Elf (Pocket)",
					mapPins =
					{
						{
							x = 26400,
							y = 61500,
							zoneId = 200,
							tooltip = L"Witch Elf - What Do We Have Here?",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					tomeBestiaryId = 31,
					tomeBestiaryName = L"Dark Elf, Witch Elves",
					text =
[[
Dark Elf, Witch Elves - What do We Have Here?
POCKET ITEM

26400, 61500 - In RvR Lake

Click on "Hidden Scroll" located in front of the north tower east of "Alter of Khaine" BO.

]],
				},

				{
					name = L"Wolf (Title)",
					mapPins =
					{
						{
							x = 4700,
							y = 49300,
							zoneId = 200,
							tooltip = L"Wolf - View With a Howl",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Wolf - View With a Howl
"The Howler"

4700, 49300

Click on "Wolves' Meal" a dead deer right on the edge of the cliff top.
]],
				},
			},
		},

		{
			name = L"Chrace",
			entries =
			{
				{
					name = L"Dryad (Title)",
					mapPins =
					{
						{
							x = 7100,
							y = 48800,
							zoneId = 206,
							tooltip = L"Dryad - Grove and Grave",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Dryad - Grove and Grave
"Forester"

7100, 48800

Approach a dead Elf body between two large broken looking rocks.
]],
				},

				{
					name = L"Harpy (Tactic)",
					mapPins =
					{
						{
							x = 44600,
							y = 23500,
							zoneId = 206,
							tooltip = L"Harpy - Get Down Here!",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Harpy - Get Down Here!
CHAOS TOME TACTIC

44600, 23500

Kill "Bloodtalon Matriarch" flying around the ruined tower.
]],
				},

				{
					name = L"Bandit (Pocket)",
					mapPins =
					{
						{
							x = 48100,
							y = 8500,
							zoneId = 206,
							tooltip = L"Human, Bandit - Treaty for Treasure",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Human, Bandit - Treaty for Treasure
POCKET ITEM

48100, 8500

Kill "Fay Val" standing on the ramp from the water right under the bridge connecting to the RvR lake.
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Spider, Giant (Tactic)",
					mapPins =
					{
						{
							x = 49000,
							y = 20800,
							zoneId = 206,
							tooltip = L"Spider, Giant - Fast Finds",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Spider, Giant - Fast Finds
BESTIAL TOME TACTIC

49000, 20800

Kill "Warpweb Spider" or "Warpweb Broodling" mobs around this area, to complete the Kill Collector at "Cliff of Ushuru", High Elf Chapter 4.
]],
				},

				{
					name = L"White Lion (Pocket)",
					mapPins =
					{
						{
							x = 27900,
							y = 11200,
							zoneId = 206,
							tooltip = L"High Elf, White Lion - What do We Have Here?",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					tomeBestiaryId = 76,
					tomeBestiaryName = L"High Elf, White Lion",
					text =
[[
High Elf, White Lion - What do We Have Here?
POCKET ITEM

27900, 11200 - In RvR Lake

Click on "Hidden Scroll" just to the west of the "Shard of Grief" BO.

]],
				},
			},
		},

		{
			name = L"The Shadowlands",
			entries =
			{
				{
					name = L"Bear (Title)",
					mapPins =
					{
						{
							x = 54900,
							y = 28500,
							zoneId = 201,
							tooltip = L"Bear - At Least They'll Stay Cool",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Bear - At Least They'll Stay Cool
"Pioneer"

54900, 28500

Equip "Bear Pelt" dropped by "Darkclaw Bear" mobs around this location.
]],
				},

				{
					name = L"Cockatrice (Title)",
					mapPins =
					{
						{
							x = 58100,
							y = 30000,
							zoneId = 201,
							tooltip = L"Cockatrice - If Looks Have Killed",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Cockatrice - If Looks Have Killed
"The Reckless"

58100, 30000

Click on "Petrified Corpse".
]],
				},

				{	-- Destruction version (no reliable coords)
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Cold One (Title)",
					mapPins =
					{
						{
							x = 37500,
							y = 8400,
							zoneId = 201,
							tooltip = L"Cold One - A Balancing of Scales",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Cold One - A Balancing of Scales
"The Scale Breaker"

37500, 8400

Talk to "Taelq Ragecrown", the healer at Ruins of Anlec, Dark Elf Chapter 5.

]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Cold One (Title)",
					mapPins =
					{
						{
							x = 42400,
							y = 21800,
							zoneId = 201,
							tooltip = L"Cold One - A Balancing of Scales",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Cold One - A Balancing of Scales
"The Scale Breaker"

42400, 21800

Kill "Snarling Cold One" mobs, to complete the Kill Collector at "Sorrowstrand", High Elf Chapter 6.
]],
				},

				{
					name = L"Harpy (Title)",
					mapPins =
					{
						{
							x = 53200,
							y = 45300,
							zoneId = 201,
							tooltip = L"Harpy - House on the Hill",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Harpy - House on the Hill
"The Bold"

53200, 45300

Click on "Harpy Roost", just on the west side of the road on a slab of rock. To reach it, jump on the slab from the top side against the cliff edge.
]],
				},

				{
					name = L"Imp (Title)",
					mapPins =
					{
						{
							x = 32700,
							y = 11500,
							zoneId = 201,
							tooltip = L"Imp - What Makes You Sparkle?",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Imp - What Makes You Sparkle?
"The Imp Squisher"

32700, 11500

Equip "Sparkling Sprite Remains" dropped by neutral "Sprite" mobs just south west of "Ruins of Anlec", Dark Elf Chapter 5.
]],
				},

				{
					name = L"Scorpion (Tactic)",
					mapPins =
					{
						{
							x = 2913,
							y = 41000,
							zoneId = 201,
							tooltip = L"Scorpion, Giant - Deadly When Dead",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Scorpion, Giant - Deadly When Dead
BESTIAL TOME TACTIC

2913, 41000

Equip "Poisontail Stinger" dropped by "Poisontail Stinger" mobs around this area.
]],
				},

				{
					name = L"Shadow Warrior (Pocket)",
					mapPins =
					{
						{
							x = 35500,
							y = 54500,
							zoneId = 201,
							tooltip = L"High Elf, Shadow Warrior - What do We Have Here?",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					tomeBestiaryId = 77,
					tomeBestiaryName = L"High Elf, Shadow Warrior",
					text =
[[
High Elf, Shadow Warrior - What do We Have Here?
POCKET ITEM

35500, 54500 - In RvR Lake

Click on "Hidden Scroll" located in the middle of some dead trees.

]],
				},

				{
					name = L"Tree Kin (Title)",
					mapPins =
					{
						{
							x = 12300,
							y = 58200,
							zoneId = 201,
							tooltip = L"Tree Kin - Rings of History",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Tree Kin - Rings of History
"The Lumberjack"

12300, 58200

Click on "Rootwalker Remains" up on the cliffs to the east of the road.
]],
				},

				{
					name = L"Unicorn (Title)",
					mapPins =
					{
						{
							x = 17600,
							y = 43200,
							zoneId = 201,
							tooltip = L"Unicorn - A Little Off the Top",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Unicorn - A Little Off the Top
"The Hornsnapper"

17600, 43200

Equip "Piece of a Unicorn's Horn" dropped by "Sylendores" standing amongst the other unicorns just west of the main road.
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Warhawk (Tactic)",
					mapPins =
					{
						{
							x = 24400,
							y = 22200,
							zoneId = 201,
							tooltip = L"Warhawk - Bird Watching ... Up Close, in Person",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Warhawk - Bird Watching ... Up Close, in Person
BESTIAL TOME TACTIC

24400, 22200

Kill the 'Skyherald Warhawk' perched on a rock next to 'Elder Meresene'.
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Warhawk (Title)",
					mapPins =
					{
						{
							x = 20200,
							y = 22900,
							zoneId = 201,
							tooltip = L"Warhawk - I Just Washed This Cloak",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Bird, Warhawk - I Just Washed This Cloak
"The Grounded"

27200, 22000 or 21500, 23400 or 20000, 28100 or 9300, 21300 or 10000, 18600 or 9300, 9500

Kill "Skyhunter Mauler" mobs at these location to collect 5 "Warhawk Feather" items.

Then trade them at Altdorf library for "Warhawk Cloak'" and equip it for the unlock.
]],
				},
			},
		},

		{
			name = L"Ellyrion",
			entries =
			{
				{
					name = L"Boar (Acc)",
					mapPins =
					{
						{
							x = 9500,
							y = 35500,
							zoneId = 207,
							tooltip = L"Boar - Pork Chop",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Boar - Pork Chop
SET ITEM

9500, 35500

Equip "Lean Boar Meat" dropped by "Stormtusk Boar" mobs around this area.
]],
				},

				{
					name = L"Disciple of Khaine (Pocket)",
					mapPins =
					{
						{
							x = 36400,
							y = 32500,
							zoneId = 207,
							tooltip = L"Dark Elf, Disciple of Khaine - What do We Have Here?",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					tomeBestiaryId = 32,
					tomeBestiaryName = L"Dark Elf, Disciple of Khaine",
					text =
[[
Dark Elf, Disciple of Khaine - What do We Have Here?
POCKET ITEM

36400, 32500 - In RvR Lake

Click on "Hidden Scroll" between some rocks near the waterfall east of "Cascades of Thunder" keep.

]],
				},

				{
					name = L"F. of Slaanesh (Title)",
					mapPins =
					{
						{
							x = 35200,
							y = 48200,
							zoneId = 207,
							tooltip = L"Fiend of Slaanesh - Things Best Left Unknown",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Fiend of Slaanesh - Things Best Left Unknown
"The Impure"

35200, 48200

Kill "Darklust Beast" which will spawn when you click on the "Book of Innocence" which is just to the south of the main road up to the gate.
]],
				},

				{
					name = L"Great Cat (Tactic)",
					mapPins =
					{
						{
							x = 61100,
							y = 57200,
							zoneId = 207,
							tooltip = L"Great Cat - Silencing Shadows",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Great Cat - Silencing Shadows
BESTIAL TOME TACTIC UNLOCK

61100, 57200

Kill "Shadowscream" just north of the main road in the trees.
]],
				},

				{
					name = L"Great Eagle (Title)",
					mapPins =
					{
						{
							x = 28300,
							y = 43200,
							zoneId = 207,
							tooltip = L"Great Eagle - Birds of a Feather",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Great Eagle - Birds of a Feather
"The Vigilant"

28300, 43200

Equip "Great Eagle Feather" dropped by "Ellyrian Eagle" mobs on the side of the mountains around the three nests.
]],
				},

				{
					name = L"Great Stag (Title)",
					mapPins =
					{
						{
							x = 43300,
							y = 32300,
							zoneId = 207,
							tooltip = L"Great Stag - Favored One",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Great Stag - Favored One
"The Nimble"

43300, 32300

Talk to "Blessed Stag".
]],
				},
			},
		},

		{
			name = L"Hunters Vale",
			entries =
			{
				{
					name = L"Great Eagle (Title)",
					mapPins =
					{
						{
							x = 35600,
							y = 36300,
							zoneId = 50,
							tooltip = L"Great Eagle - King of the Skies",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Great Eagle - King of the Skies
"The Majestic"

35600, 36300

Kill "Mynos, Warden of the Vale" on the right as you enter the area for the puzzle stones.
]],
				},

				{
					name = L"Great Stag (Title)",
					mapPins =
					{
						{
							x = 29400,
							y = 27500,
							zoneId = 50,
							tooltip = L"Great Stag - Heart of the Vale",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Great Stag - Heart of the Vale
"The Noble"

29400, 27500

Kill "Heart of the Vale" on the right of the path after the wolf mother.
]],
				},

				{
					name = L"Imp (Acc)",
					mapPins =
					{
						{
							x = 28300,
							y = 41000,
							zoneId = 50,
							tooltip = L"Imp - Natural Resistance",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Imp - Natural Resistance
JEWELRY ITEM

28300, 41000

Kill "Spellbiter" the 2nd boss.
]],
				},
			},
		},

		{
			name = L"Avelorn",
			entries =
			{
				{
					name = L"Archmage (Pocket)",
					mapPins =
					{
						{
							x = 28500,
							y = 61100,
							zoneId = 202,
							tooltip = L"High Elf, Archmage - What do We Have Here?",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					tomeBestiaryId = 75,
					tomeBestiaryName = L"High Elf, Archmage",
					text =
[[
High Elf, Archmage - What do We Have Here?
POCKET ITEM

28500, 61100 - In RvR Lake

Click on "Hidden Scroll" located in bushes south of "Ghrond's Sacristy" keep's main gates..

]],
				},

				{
					name = L"Beastman (Cloak)",
					mapPins =
					{
						{
							x = 44300,
							y = 37600,
							zoneId = 202,
							tooltip = L"Beastman, Bestigor - Bossy Beastie",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Beastman, Bestigor - Bossy Beastie
CLOAK ITEM

44300, 37600

Kill "Khurraak Might-Horns" standing off to the west of the road against the hills.
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Bone Giant (Title)",
					mapPins =
					{
						{
							x = 57800,
							y = 61400,
							zoneId = 202,
							tooltip = L"Bone Giant - Parts of Parts",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Bone Giant - Parts of Parts
"The Bone Breaker"

57800, 61400

Talk to "Brulgulrach the Unliving" standing outside the tent.
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Bone Giant (Title)",
					mapPins =
					{
						{
							x = 57800,
							y = 61400,
							zoneId = 202,
							tooltip = L"Bone Giant - Parts of Parts",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Bone Giant - Parts of Parts
"The Bone Breaker"

57800, 61400

Kill "Brulgulrach the Unliving" standing amoungst the other mobs outside the tent.
]],
				},

				{
					name = L"Dryad (Tactic)",
					mapPins =
					{
						{
							x = 32300,
							y = 36400,
							zoneId = 202,
							tooltip = L"Dryad - Chip Off the Old...",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Dryad - Chip Off the Old...
MYTHICAL TOME TACTIC

32300, 36400

Kill "Oldbark" amoungst the other Dryads and Sprites near a large rock.
]],
				},

				{
					name = L"H. of Tzeentch (Tactic)",
					mapPins =
					{
						{
							x = 62900,
							y = 15000,
							zoneId = 202,
							tooltip = L"Horror of Tzeentch - Pack of Three",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Horror of Tzeentch - Pack of Three
DAEMONIC TOME TACTIC

62900, 15000

Kill "Golmir" standing in a slight depression, just up the side of the mountain.
]],
				},

				{
					name = L"Liche (Title)",
					mapPins =
					{
						{
							x = 33200,
							y = 49700,
							zoneId = 202,
							tooltip = L"Liche - Final Rest... Again",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Liche - Final Rest... Again
"Champion of Morr"

33200, 49700

Kill "Tarnolious the Lost" south east "Tower of Aethwyn" PQ, by a rock looking into the RvR lake.
]],
				},

				{
					name = L"Nurgling (Pocket)",
					mapPins =
					{
						{
							x = 37100,
							y = 16400,
							zoneId = 202,
							tooltip = L"Nurgling - More Filth for Me!",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Nurgling - More Filth for Me!
POCKET ITEM

37100, 16400

Kill "Filthmiser" standing on top of a small rise, west of "Rotten Embrace" PQ.
]],
				},

				{
					name = L"Treeman (Title)",
					mapPins =
					{
						{
							x = 43500,
							y = 44800,
							zoneId = 202,
							tooltip = L"Treeman - Who Bears the Worldbearer?",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Treeman - Who Bears the Worldbearer?
"The Vale Walker"

43500, 44800

Talk to "Dregenis" standinf near the bend in the main road.
]],
				},

				{
					name = L"Troll (Bestial Token)",
					mapPins =
					{
						{
							x = 19300,
							y = 48400,
							zoneId = 202,
							tooltip = L"Troll, Chaos - Dispense Justice",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Troll, Chaos - Dispense Justice
BEAST TOKEN

19300, 48400

Kill "Goremaw" north of "Isha's Fall" warcamp.
]],
				},

				{
					name = L"Zombie (Pocket)",
					mapPins =
					{
						{
							x = 47700,
							y = 45800,
							zoneId = 202,
							tooltip = L"Zombie - Loop Back",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Zombie - Loop Back
POCKET ITEM

47700, 45800

Kill "Rupert" standing round the side of the tent
]],
				},
			},
		},

		{
			name = L"The Lost Vale",
			entries =
			{
				{
					name = L"Daemonette of Slaanesh (Acc)",
					mapPins =
					{
						{
							x = 33900,
							y = 36500,
							zoneId = 260,
							tooltip = L"Daemonette of Slaanesh - Great is the Temptation",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Daemonette of Slaanesh - Great is the Temptation
JEWELRY ITEM

33900, 36500

Kill "Syndestra" the final mega mini boss, unlocked by killing all the other mini bosses.
]],
				},

				{
					name = L"Daemonvine (Title)",
					mapPins =
					{
						{
							x = 19000,
							y = 29800,
							zoneId = 260,
							tooltip = L"Chaos Spawn, Daemonvine - Overgrown",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Chaos Spawn, Daemonvine - Overgrown
"The Unnatural Gardener"

19000, 29800

Kill "The Darkpromise Beast" the 3rd boss in the left wing.
]],
				},

				{
					name = L"Dark Pegasus (Title)",
					mapPins =
					{
						{
							x = 32300,
							y = 32900,
							zoneId = 260,
							tooltip = L"Dark Pegasus - Upon Dark Wings",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Dark Pegasus - Upon Dark Wings
"Dark Messenger"

32300, 32900

Kill "Erophex" the mini boss spawned by collecting and repairing the menhir.
]],
				},

				{
					name = L"Doombull (Title)",
					mapPins =
					{
						{
							x = 25400,
							y = 42600,
							zoneId = 260,
							tooltip = L"Doombull - Brave the Smell",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Doombull - Brave the Smell
"Bull-Headed"

25400, 42600

Click on "Jar of Perfume" on a small rock by the herdstone.
]],
				},

				{
					name = L"Dragon Ogre (Tactic)",
					mapPins =
					{
						{
							x = 40500,
							y = 34600,
							zoneId = 260,
							tooltip = L"Dragon Ogre - Demise of the Ancient",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Dragon Ogre - Demise of the Ancient
CHAOS TOME TACTIC

40500, 34600

Click on "Azyr Conduit" up on a ledge South of "Gorak the Ancient" the 4th boss in the right wing.  Climb up to the ledge using the fallen log as you head to the boss area.
]],
				},

				{
					name = L"Fiend of Slaanesh (Title)",
					mapPins =
					{
						{
							x = 39400,
							y = 3600,
							zoneId = 260,
							tooltip = L"Fiend of Slaanesh - Some Things I Cannot Unsee",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Fiend of Slaanesh - Some Things I Cannot Unsee
"Excessively Excessive"

39400, 3600

Kill "Horgulul" 2nd boss in the middle wing.
]],
				},

				{
					name = L"Flayerkin (Title)",
					mapPins =
					{
						{
							x = 31800,
							y = 10100,
							zoneId = 260,
							tooltip = L"Flayerkin - Chained",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Flayerkin - Chained
"Caged Soul"

31800, 10100

Kill "Zaar the Painseeker" 1st boss in the middle wing.
]],
				},

				{
					name = L"Giant Leech (Title)",
					mapPins =
					{
						{
							x = 37500,
							y = 15700,
							zoneId = 260,
							tooltip = L"Giant Leech - Mother Lode",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Giant Leech - Mother Lode
"The Leech"

37500, 15700

Kill "Giant Leech" champion at the end of the canyon.
]],
				},

				{
					name = L"Gorger (Token)",
					mapPins =
					{
						{
							x = 51500,
							y = 48200,
							zoneId = 260,
							tooltip = L"Gorger - A Bone to Pick",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Gorger - A Bone to Pick
BEASTIAL TOKEN

51500, 48200

Click on "Bonepile" just on the left as you enter the cave for "Larg the Devourer" in the right wing.
]],
				},

				{
					name = L"Imp (Acc)",
					mapPins =
					{
						{
							x = 37600,
							y = 32400,
							zoneId = 260,
							tooltip = L"Imp - Four Seasons",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Imp - Four Seasons
JEWELRY ITEM

37600, 32400

Kill "Traechyr" the mini boss spawned by killing all the imps in the cave, when coming back from the right wing.
]],
				},

				{
					name = L"Keeper of Secrets (Title)",
					mapPins =
					{
						{
							x = 54200,
							y = 10900,
							zoneId = 260,
							tooltip = L"Keeper of Secrets - Silky Smooth",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Keeper of Secrets - Silky Smooth
"Knows No Moderation"

54200, 10900

Click on "Cultist Cushions" up the stairs behind the pillars to the right, as you Alarielle's Palace.
]],
				},

				{
					name = L"Ogre, Butcher (Title)",
					mapPins =
					{
						{
							x = 45800,
							y = 47800,
							zoneId = 260,
							tooltip = L"Ogre, Butcher - Second Helpings",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Ogre, Butcher - Second Helpings
"Sous Chef"

45800, 47800

Click on "Vale Cardinal" a dead bird on the alter near the butcher's pot.
]],
				},

				{
					name = L"Pleasurebeast (Title)",
					mapPins =
					{
						{
							x = 47900,
							y = 7000,
							zoneId = 260,
							tooltip = L"Pleasurebeast - Impulsive Drive",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Pleasurebeast - Impulsive Drive
"Holds Nothing Back"

47900, 7000

Kill "Seraxes" the mini boss spawned from the corpse in the waterfall, near the final boss of the middle wing.
]],
				},

				{
					name = L"Treekin (Title)",
					mapPins =
					{
						{
							x = 48200,
							y = 27200,
							zoneId = 260,
							tooltip = L"Treekin - Organic Cycle",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Treekin - Organic Cycle
"The Composter"

48200, 27200

Kill "???" the mini boss spawned by from the branch at the waterfall, near the final boss of the right wing. (Flower from the dryad circle needed to spawn him).
]],
				},

				{
					name = L"Treemen (Title)",
					mapPins =
					{
						{
							x = 50300,
							y = 24000,
							zoneId = 260,
							tooltip = L"Treemen - From Little Acorns Grow",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Treemen - From Little Acorns Grow
"Grove Keeper"

50300, 24000

Click on "Acorn Basket" at the base of a tree.
]],
				},

				{
					name = L"Yhetee (Token)",
					mapPins =
					{
						{
							x = 52400,
							y = 35600,
							zoneId = 260,
							tooltip = L"Yhetee - Spring Coat",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Yhetee - Spring Coat
BEASTIAL TOKEN

52400, 35600

Click on "Vale Doe" in the cave from the water, below "Chul Earthkeeper" in the right wing.
]],
				},
			},
		},

		{
			name = L"Saphery",
			entries =
			{
				{
					name = L"Bray Shaman (Title)",
					mapPins =
					{
						{
							x = 48600,
							y = 10600,
							zoneId = 208,
							tooltip = L"Beastman, Bray Shaman - A Matching Set",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Beastman, Bray Shaman - A Matching Set
"Sentinel"

48600, 10600

Equip "Bray Shaman Horns" dropped by "Twisted Bray-Shaman" mobs around the camp.
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Chaos Hound (Acc)",
					mapPins =
					{
						{
							x = 47300,
							y = 10100,
							zoneId = 208,
							tooltip = L"Chaos Hound - From Mouth to Neck",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Chaos Hound - From Mouth to Neck
JEWELRY ITEM

47300, 10100

Kill "Twisted Hound" mobs in this area to collect 10 "Chaos Hound Fang" items.

Then trade them in to "Beastmaster Mezellain" at 31500, 15000, for "Amulet of Fangs" and equip it for the unlock.
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Chaos Hound (Acc)",
					mapPins =
					{
						{
							x = 47300,
							y = 10100,
							zoneId = 208,
							tooltip = L"Chaos Hound - From Mouth to Neck",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Chaos Hound - From Mouth to Neck
JEWELRY ITEM

47300, 10100

Kill "Twisted Hound" mobs in this area to collect 10 "Chaos Hound Fang" items. 

Then trade them in at Altdorf library for "Amulet of Fangs" and equip it for the unlock.
]],
				},

				{
					name = L"Cockatrice (Cloak)",
					mapPins =
					{
						{
							x = 58300,
							y = 27800,
							zoneId = 208,
							tooltip = L"Cockatrice - A Charmed Life",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Cockatrice - A Charmed Life
CLOAK ITEM

58300, 27800

Kill "Slashbeak" in amongst the other cockatrice in this area.
]],
				},

				{	
					name = L"Cold One (Token)",
					mapPins =
					{
						{
							x = 54400,
							y = 10500,
							zoneId = 208,
							tooltip = L"Cold One - Big Freeze",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Cold One - Big Freeze
BEAST TOKEN

54400, 10500

Kill "Coldlash" standing amoungst the other Cold Ones.
]],
				},

				{
					name = L"Manticore (Title)",
					mapPins =
					{
						{
							x = 59600,
							y = 45300,
							zoneId = 208,
							tooltip = L"Manticore - Won't Ask Where it Kept That",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Manticore - Won't Ask Where it Kept That
"The Manticore Masher"

59600, 45300

Equip "A Partially-digested Manual" dropped by "Deathmane" east of "Menuthil's Burden", High Elf Chapter 14.
]],
				},

				{
					name = L"Pegasus (Title)",
					mapPins =
					{
						{
							x = 14000,
							y = 1000,
							zoneId = 208,
							tooltip = L"Pegasus - Do You Know the Way",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Pegasus - Do You Know the Way
"The Hornblower"

14000, 1000 - In RvR Lake

Click on "Ancient Rider's Horn" hanging from a tree.
]],
				},

				{
					name = L"Squig (Pocket)",
					mapPins =
					{
						{
							x = 59900,
							y = 63400,
							zoneId = 208,
							tooltip = L"Squig - Take a Break",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Squig - Take a Break
POCKET ITEM

59900, 63400

Click on "Fleshy Mushrooms" a glowing blue mushroom in the final chamber of "Southern Stonewind Cavern" minor landmark, near the water between to green mushrooms.
]],
				},

				{
					name = L"Swordmaster (Pocket)",
					mapPins =
					{
						{
							x = 40000,
							y = 6200,
							zoneId = 208,
							tooltip = L"Empire, Swordmaster - What do We Have Here?",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					tomeBestiaryId = 78,
					tomeBestiaryName = L"High Elf, Swordmaster",
					text =
[[
Empire, Swordmaster - What do We Have Here?
POCKET ITEM

40000, 6200 - In RvR Lake

Click on "Hidden Scroll" located inside the dry fountain.

]],
				},
			},
		},

		{
			name = L"Fell Landing",
			entries =
			{
				{	-- Order version (no coords)
					realm = TTitan.Data.Realm.ORDER,
					name = L"Dark Elf (Title)",
					text = 
[[
Dark Elf - Vanquish the Dark Elf Fortress Lord
"Keeper of the Flame"
]],
				},
			},
		},

		{
			name = L"Caledor",
			entries =
			{
				{
					name = L"Blackguard (Pocket)",
					mapPins =
					{
						{
							x = 28000,
							y = 29000,
							zoneId = 203,
							tooltip = L"Dark Elf, Blackguard - What do We Have Here?",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					tomeBestiaryId = 33,
					tomeBestiaryName = L"Dark Elf, Blackguard",
					text =
[[
Dark Elf, Blackguard - What do We Have Here?
POCKET ITEM

28000, 29000 - In RvR Lake

Click on "Hidden Scroll" tucked under a bush.

]],
				},

				{
					name = L"Cold One (Cloak)",
					mapPins =
					{
						{
							x = 6100,
							y = 37100,
							zoneId = 203,
							tooltip = L"Cold One - No Hiding Here",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Cold One - No Hiding Here
CLOAK ITEM

6100, 37100

Kill "Frostscale".
]],
				},

				{
					name = L"High Elf (Title)",
					mapPins =
					{
						{
							x = 38000,
							y = 30000,
							zoneId = 203,
							tooltip = L"High Elf - The History of the High Elves",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
High Elf - The History of the High Elves
"Isha's Lament"

38000, 30000

Click on "Hidden Scroll" next to backbone of the dragon skeleton.
]],
				},

				{
					name = L"Hydra (Title)",
					mapPins =
					{
						{
							x = 10000,
							y = 37000,
							zoneId = 203,
							tooltip = L"Hydra - Who Let That Thing Out?",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Hydra - Who Let That Thing Out?
"Hydra Tamer"

10000, 37000

Kill "Deathclaw Hydra".
]],
				},

				{
					name = L"Liche (Token)",
					mapPins =
					{
						{
							x = 32100,
							y = 22000,
							zoneId = 203,
							tooltip = L"Liche - For the Promise of Power",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Liche - For the Promise of Power
BEASTIAL TOKEN

32100, 22000

Click on "Mound of Dirt", at the base of a larger tree. North East of the "Conqueror's Watch" Darak Elf War Camp, over the river.
]],
				},

				{
					name = L"Manticore (Token)",
					mapPins =
					{
						{
							x = 15400,
							y = 41300,
							zoneId = 203,
							tooltip = L"Manticore - Don't Look Up",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Manticore - Don't Look Up
BEASTIAL TOKEN

15400, 41300

Kill "Martikhoras".
]],
				},

				{	
					name = L"Scoprion (Acc)",
					mapPins =
					{
						{
							x = 50200,
							y = 44900,
							zoneId = 203,
							tooltip = L"Giant Scorpion - Stick the Sticker",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Giant Scorpion - Stick the Sticker
SET ITEM

50200, 44900

Equip "Giant Scorpion Stinger" dropped by "Crushclaw".
]],
				},
			},
		},

		{
			name = L"Dragonwake",
			entries =
			{
				{
					name = L"Doombull (Title)",
					mapPins =
					{
						{
							x = 64800,
							y = 29900,
							zoneId = 205,
							tooltip = L"Beastmen, Doombull - Grab the Bull By the Horn",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Beastmen, Doombull - Grab the Bull By the Horn
"Cairn Breaker"

64800, 29900

Kill "Crazed Bull", spawned by clicking on "Pile of Bones".
]],
				},

				{
					name = L"D. of Slaanesh (Acc)",
					mapPins =
					{
						{
							x = 14300,
							y = 8100,
							zoneId = 205,
							tooltip = L"Daemonette of Slaanesh - Sacrifice Over Excess",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Daemonette of Slaanesh - Sacrifice Over Excess
JEWELRY ITEM

14300, 8100

Get the "Icy Heart" from killing "Jezebeth" a mob that spawns when you click on "Second Journal of Lliean" a book on the ground by the trees.

Then travel to 54200, 16600 in Chaos Waste, and destroy the heart by clicking on "Alter of Broken Flesh".
]],
				},

				{
					name = L"Sorcerer (Pocket)",
					mapPins =
					{
						{
							x = 21400,
							y = 32500,
							zoneId = 205,
							tooltip = L"Dark Elf, Sorcerer - What do We Have Here?",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					tomeBestiaryId = 34,
					tomeBestiaryName = L"Dark Elf, Sorceror",
					text =
[[
Dark Elf, Sorcerer - What do We Have Here?
POCKET ITEM

21400, 32500 - In RvR Lake

Click on "Hidden Scroll" south of "Mournfire's Approach" BO, within some rocks against the cliff.

]],
				},
			},
		},

		{
			name = L"Isle of the Dead",
			entries =
			{
				{
					name = L"Chaos Fury (Token)",
					mapPins =
					{
						{
							x = 41900,
							y = 33200,
							zoneId = 220,
							tooltip = L"Chaos Fury - On Wings, but Not Quite Angels",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Chaos Fury - On Wings, but Not Quite Angels
BEASTIAL TOKEN

41900, 33200

Equip "Concentrated Evil" pocket item dropped by killing "Ylger'oz the Demented".
]],
				},

				{
					name = L"Construct (Title)",
					mapPins =
					{
						{
							x = 14200,
							y = 26000,
							zoneId = 220,
							tooltip = L"Construct - Anyone Have a Can Opener?",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Construct - Anyone Have a Can Opener?
"The Armor-Breaker"

14200, 26000

Equip "Fragment of Living Armor" pocket item dropped by killing "Living Armor" in the "Ritual of Metal" PQ.
]],
				},
			},
		},

		{
			name = L"Eataine",
			entries =
			{
				{
					name = L"Dark Elf (Title)",
					mapPins =
					{
						{
							x = 30000,
							y = 36000,
							zoneId = 209,
							tooltip = L"Dark Elf - The History of the Dark Elves",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Dark Elf - The History of the Dark Elves
"Lion Guard"

30000, 36000 - In RvR Lake

Click on "Hidden Scroll" located near a building, next to 3 barrels.
]],
				},	

				{
					name = L"Great Eagle (Acc)",
					mapPins =
					{
						{
							x = 46600,
							y = 60900,
							zoneId = 209,
							tooltip = L"Great Eagle - Eagle-Eye",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Great Eagle - Eagle-Eye
ITEM

46600, 60900

Kill "Ironfeather".
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Griffon (Title)",
					mapPins =
					{
						{
							x = 52600,
							y = 64000,
							zoneId = 209,
							tooltip = L"Griffon - The Mightiest",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Griffon - The Mightiest
"The Magestic"

52600, 64000

Kill "Grimwing".
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Griffon (Title)",
					mapPins =
					{
						{
							x = 52600,
							y = 64000,
							zoneId = 209,
							tooltip = L"Griffon - The Mightiest",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Griffon - The Mightiest
"The Magestic"

52600, 64000

Talk to "Grimwing".
]],
				},

				{
					name = L"Harpy (Tactic)",
					mapPins =
					{
						{
							x = 38700,
							y = 11900,
							zoneId = 209,
							tooltip = L"Harpy - Silent Star",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Harpy - Silent Star
CHAOS TOME TACTIC

38700, 11900

Kill "Khaligrar Bloodwing" flying above the vinyard field.
]],
				},

				{
					name = L"Harpy (Acc)",
					mapPins =
					{
						{
							x = 31100,
							y = 59600,
							zoneId = 209,
							tooltip = L"Harpy - Their Heart's Not in it, Yet.",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Harpy - Their Heart's Not in it, Yet.
JEWELRY ITEM

31100, 59600

Equip "Harpy Heart" dropped by "Tormented Harpy" mobs in this area.
]],
				},

				{
					name = L"Keeper of Secrets (Title)",
					mapPins =
					{
						{
							x = 47200,
							y = 2200,
							zoneId = 209,
							tooltip = L"Keeper of Secrets - Picked Clean",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Keeper of Secrets - Picked Clean
"Herald of Temperance"

47200, 2200

Click on "Discarded Bones", down near the water's edge.
]],
				},

				{
					name = L"Treekin (Token)",
					mapPins =
					{
						{
							x = 52800,
							y = 63000,
							zoneId = 209,
							tooltip = L"Treekin - Timber!",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Treekin - Timber!
BEAST TOKEN

52800, 63000

Kill "Irebough Mossroot" standing by the tree.
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Tuskgor (Tactic)",
					mapPins =
					{
						{
							x = 13800,
							y = 8400,
							zoneId = 209,
							tooltip = L"Tuskgor - Saving Face",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Tuskgor - Saving Face
Chaos Tome Tactic

13800, 8400

Kill "Ravaging Tuskgor" mobs, and collect 5 "Unchipped Tusk" items.

Then trade them in to "Karathae Leawalker" at "Haleril's Resolve", High Elf Chapter 16, for "Belt of Tusks" and equip it for the unlock.
]],
				},

				{
					name = L"Tuskgor (Tactic)",
					mapPins =
					{
						{
							x = 13800,
							y = 11500,
							zoneId = 209,
							tooltip = L"Tuskgor - Tusk for Tusk",
							icon = "TTitan_Pin_Bestiary",
						},
					},
					text =
[[
Tuskgor - Tusk for Tusk
CHAOS TOME TACTIC

13800, 11500

Kill "Riptusk".
]],
				},
			},
		},

		{
			name = L"Shining Way",
			entries =
			{

			},
		},
	},
}
