TTitan.Data.Credits = {}

function TTitan.Data.Credits.GetData()
	return TTitan.Data.Credits.RawData
end

function TTitan.Data.Credits.FilterData()
end

TTitan.Data.Credits.RawData =
{
	header = L"FAQ & Credits",
	categories =
	{
		{
			name = L"FAQ",
			entries =
			{
				{
					name = L"About this Add-on",
					text =
[[
Welcome to Tome Titan! The purpose of this add-on is to take information posted in various important Warhammer Alliance threads and list them here in-game in an easy to read and find format.

In short: To keep you from having to alt-tab.


We have information on Bestiary, History & Lore, and Noteworthy Persons unlocks as well as lists of Lairs, Explorations, and Pursuits. We also have Apothecary, Cultivating, and Talisman Making information. The add-on will also track if unlocks have been completed and can either hide them altogther, or mark them as completed, accordingly.


To add a macro for easy access to Tome Titan, open the Main Menu, select Macros, and use this as your macro text:

/script TTitan.UI.ToggleShowing()

You can also make a macro for going to the current zone:

/script TTitan.UI.ExpandCurrentZone(); TTitan.UI.Show()


Please use "/ttitan help" for a full list of commands. If you have any issues, don't hesitate to comment on the project's page on Curse.com or submit a ticket in our issue tracker at CurseForge.

http://war.curse.com/downloads/war-addons/details/ttitan.aspx
http://war.curseforge.com/projects/ttitan/tickets/
]],
				},

				{
					name = L"How often is it updated?",
					text =
[[
This add-on WILL need to be updated about once a week to keep the information, well, up to date. It is, however, possible that the add-on will be updated daily - and sometimes even several times a day!

You can do this by visiting this link:
http://war.curse.com/downloads/war-addons/details/ttitan.aspx

Or by using the Curse Client to automatically update this and all your other add-ons:
http://www.curse.com/client/

We will do our best to make sure the data files are updated at LEAST once a week, if not faster.

In the event that the add-on will malfunction or stop working altogether because of changes to the game, it will be updated as fast as possible.
]],
				},

				{
					name = L"Can you add...",
					text =
[[
Post a ticket with your feature request on curseforge here:
http://war.curseforge.com/projects/ttitan/tickets/

And we'll get back to you as soon as possible if it's possible or not. You can also see other feature requests that are pending or have been implemented.

If you think we should have a page for another type of information, please contact one of us or post a ticket to the CurseForge project!
]],
				},

				{
					name = L"Can I use the code?",
					text =
[[
Please contact us first as we haven't yet released the code publicly.
]],
				},
			},
		},

		{
			name = L"Credits",
			entries =
			{
				{
					name = L"The Tome Titan Team",
					text =
[[
That's a lot of T's! But seriously, Tome Titan is updated and mainted by a number of people. I will list them here along with their roles. I am also sad to say that most of the original team have left the game and no longer unpdate the addon. So it is up to me to update it myself.

Aenathel -- Ex - Project Manager, Main Coder, Data Updates (Inactive)
   Aenathel has really improved the add-on a lot since joining the Tome Titan Team - he is the main coder and the guy working the magic of the latest updates. Nearly the entire add-on has been rewritten to be easier to use, and provide much more functionality thanks to him. All major code changes go through him. He's also helped out on cleaning up a lot of the various data files.

Oscarr -- Bestiary and Lair Locations Updates, Minor Coding (Inactive)
   Oscarr originally started this project as Bestiary Helper. It was based off of the Killerguides add-on (with their permission) used for displaying data in a nice two-paned window - the same window used by the in-game Help. Oscarr and Squigy got together later on and decided to rename the project as Tome Titan and started including more data. Oscarr wrote the TTBar directory that handles modules for the popular Board/Bar add-ons. He also attempts to assist Aenathel with coding when and where possible.

Possibly (previously SquigyStardust) -- Project Manager, Main Content Updater, Minor Coding
   Previously only updating the History and Lore Sections, I will now update most of the information of this addon as the other authors are largely inactive now. 
   
]],
				},

				{
					name = L"The Community",
					text =
[[
Huge thanks to the community and posters at WarhammerAlliance.com and various other sites who have submitted all the information. Without them, this wouldn't be possible. Keep up the great work and team-spirit guys and gals.

If you think we should have a page for another type of information, please contact one of us or post a ticket on the CurseForge project here:
http://war.curseforge.com/projects/ttitan/tickets/
]],
				},

				{
					name = L"Thread Maintainers",
					text =
[[
Shrewd - Bestiary Unlocks Thread
    Shrewd is the man who maintains the WarhammerAlliance thread here: http://www.warhammeralliance.com/forums/showthread.php?t=121526
He's also assisted me a lot with the add-on early on, testing it, and providing feedback and suggestions on the data formats. Big thanks to him!

History and Lore Unlocks Thread // HammerWiki
    burfo is the man who maintains the Warhammer Alliance thread here: http://www.warhammeralliance.com/forums/showthread.php?t=149022
A lot of the information also comes from HammerWiki: http://warhammeronline.wikia.com/

Exploration and Pursuit Unlocks Thread

The Lair Locations Thread
    magos is the man who maintains the Warhammer Alliance thread here: http://www.warhammeralliance.com/forums/showthread.php?t=132580
]],
				},
			},
		},

		{
			name = L"Changes",
			entries =
			{

                {
					name = L"Most Recent Changes",
					text =
[[

DATA
(Kills - Choppa)
Updated Choppa 1000 Kills ( Thanks Grelin)

Fixed all Wormy1969's Spelling Mistakes, Hers the full list

Beastiary
Mount Bloodhorn: "Fiery Tales" should be "A Tale by the Fire"

History & Lore
Black Crag: "Shine Trinkets" should be "Shiny Trinkets"
Talabecland: "Talabecland Thunder Water" should be "Talabecland Thunder-Water"

Noteworthy Persons
Thunder Mountain: "Rofi Throstsson" should be "Rafi Throstsson"
Talabecland: "Captain Melicent" should be "Captain Melicent Drauwulf"
Altdorf: "Gotrek & Felix" should be "Gotrek and Felix"
Altdorf" "Phoenix King Finubar" should be "Pheonix King Finubar" (Need Verification)

Exploration Achievements
Gettin' Slopped: "Gettin' Slopped" should be "Getting' Slopped" (the header should not have a g the task should)
The Mysterious M.B.: Part 6 should be "M.B. Shipping Co."
The Mysterious M.B.: Part 7 should be "The Mysterious M.B."
Mourkain Treasure: Part 1 should be "Crystal Skull"
Mourkain Treasure: Part 2 should be "Cult of Ushoran"

Pursuit Achievements
Da Bigga 'Un: Part 2 should be "Bosses"
Da Bigga 'Un: Part 3 should be "Da Biggest Un'"
Subversion: Part 1 should be "Subversion" 

]]
				},							
				
				
			},
		},
	},
}
