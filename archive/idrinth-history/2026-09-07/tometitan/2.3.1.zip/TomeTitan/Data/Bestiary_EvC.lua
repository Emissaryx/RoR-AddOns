TTitan.Data.BestiaryEvC = {}

function TTitan.Data.BestiaryEvC.GetData()
	return TTitan.Data.BestiaryEvC.RawData
end

function TTitan.Data.BestiaryEvC.FilterData()
	TTitan.Data.FilterByRealm(TTitan.Data.BestiaryEvC.RawData)
end

TTitan.Data.BestiaryEvC.RawData =
{
	header = L"Beastiary Unlocks - Empire vs Chaos",
	categories =
	{
		{
			name = L"Hidden Scrolls (RVR LAKES)",
			entries =
			{
				{
					name = L"[Nordland]Bright Wizard (Pocket)",
					text =
[[
Empire, Bright Wizard - What do We Have Here ?
POCKET ITEM

NORDLAND @ 24, 11. Click on the Hidden Scroll behind a bush against the rocks. Unlocks: Flint Stone.

(NOTE: This will not mark as complete, as it currently marks as complete while incomplete if notated correctly.)

By Socran
20081217
]],
				},

				{
					name = L"[Norsca]Zealot (Pocket)",
					text =
[[
Chaos, Zealot - What do We Have Here ?
POCKET ITEM

NORSCA @ 42, 63. Click on the Hidden Scroll behind the burned house.

(NOTE: This will not mark as complete, as it currently marks as complete while incomplete if notated correctly.)

By Minusa
20081217
]],
				},

				{
					name = L"[Ostland]Marauder (Pocket)",
					text =
[[
Chaos, Marauder - What do We Have Here ?
POCKET ITEM

OSTLAND @ 34.8, 8.3. At the Crypt of Weapons, near the Tainted Earth for the quest, by one of the fallen pillars is a scroll. Unlocks: Mutated Claw.

(NOTE: This will not mark as complete, as it currently marks as complete while incomplete if notated correctly.)

By Ionass
20081217
]],
				},

				{
					name = L"[Troll Country]Witch Hunter (Pocket)",
					text =
[[
Empire, Witch Hunter - What do We Have Here ?
POCKET ITEM

TROLL COUNTRY @ 3.5, 54. The "Hidden Scroll" for this can be found slightly N of Stonetroll Keep in the ORvR lake. It is located in some bushes next to a tree N of the NE corner of Stonetroll Keep, near the stone "tunnel" that leads to the back door of the keep. This will unlock Fear in a bottle.

(NOTE: This will not mark as complete, as it currently marks as complete while incomplete if notated correctly.)

By wahooka
20081216
]],
				},

				{
					name = L"[High Pass]Magus (Pocket)",
					text =
[[
Chaos, Magus - What do We Have Here ?
POCKET ITEM

HIGH PASS @ 15, 63. Click on the 'Hidden Scroll' located beside a broken section of the wall, the scroll is semi buried in the snow...not that hard to see. Unlocks: Discus Tech.

(NOTE: This will not mark as complete, as it currently marks as complete while incomplete if notated correctly.)

By rouko
20081217
]],
				},

				{
					name = L"[Chaos Wastes]Empire (Title)",
					text =
[[
Empire - The History of the Empire
"The Anarchist"

CHAOS WASTES @ 23, 10. Click on the Hidden Scroll located behind the NE stone pillar right by the BO Flag.

By rouko
20081217
]],
				},

				{
					name = L"[Praag]Warrior Priest (Pocket)",
					text =
[[
Empire, Warrior Priest - What do We Have Here ?
POCKET ITEM

PRAAG @ 35, 58. Click on the 'Hidden Scroll' to unlock: Thumb Unguent.

(NOTE: This will not mark as complete, as it currently marks as complete while incomplete if notated correctly.)

By rouko
20081216
]],
				},

				{
					name = L"[Praag]Chosen (Pocket)",
					text =
[[
Chaos, Chosen - What do We Have Here ?
POCKET ITEM

PRAAG @ 30, 17. In a burning half building underneath a little ramp unlocks Mark of Tzeentch

By rouko
20081216
]],
				},
				{
					name = L"[Reikland]Chaos (Title)",
					text =
[[
Chaos - The History of the servants of Chaos
"Foe of the Dark Gods"

REIKLAND @ 17, 64. Click on the 'Hidden Scroll' located between 2 piles of wood.

By rouko
20081216
]],
				},
			},
		},

		{
			name = L"Nordland",
			entries =
			{
				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Beastman (Title)",
					text =
[[
Beastman, Gor - The Murder Wood
"Road Warden"

NORDLAND @ 40.5, 36.5. Click the Beastman Herdstone in the N part of the Murder Wood (it's in the secluded valley with the lake on the empire side).

By Maehan, Puddles404, LatukiJoe & Wykk
20081029
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Beastman (Title)",
					text =
[[
Beastman, Ungor (An Unfortunate Victim) - Who Wud Murder
"The Brute"

NORDLAND @ 37k, 35k. In Murder Wood target corpse of "An Unfortunate Victim" for the unlock.

By Kovacs, Nozaro& xepherys
20081007
]],
				},

				{
					name = L"Boar (Title)",
					text =
[[
Boar - Surrounded by Swine
"Huntsman"

NORDLAND @ 52.5k, 2k or 56k, 2k or 48k, 5k. Habitat reward @ an encampment between Ravenraid & Gotland. Just walk through the camp to activate it.

By LatukiJoe, Nazaro, burfo, NicWester, Puddles404 & Quiggles
20081007
]],
				},

				{
					name = L"Hound (Title)",
					text =
[[
Hound - Hungry, Hungry Hounds
"The Hound Hunter"

NORDLAND @ 57, 42k. Received from a bag of meat by the mt. ridge N of Salzenmund (on the N side). The bag called "Kibbles n Scraps" is in a camp consisting of one imperial and a few hounds, sitting by a camp fire.

By Shiwoen, Nozaro & Shawen
20081013
]],
				},

				{
					name = L"Plague Victim (Title)",
					text =
[[
Plague Victim - People Pop Up
"The Infected"

NORDLAND @ 59,12k. There is a Plagued Farmer mob lying behind a tree killing him will unlock People Pop Up and the title.

By Shadeviper, Puddles404 & Shawen
20081013
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Skeleton (Title)",
					text =
[[
Skeleton - What Lay Ahead
"Skeleton Hunter"

(O) NORDLAND @ 19k, 39k. Click on a grave found in Grimmenhagen just left of the entrance to the Grimmenhagen barrows.

By Mortiferous
20081007
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Spider (Tactic)",
					text =
[[
Spider, Giant (Grey/Scarlet Wolf Spider) - Fast Finds
BESTIAL TOME TACTIC

(D) NORDLAND. Kill spiders till you complete the kill collector quest in Authun's Host. By "complete" I mean till you do so many turn ins you can't do any more. NOTE: Requires 60 spider kills.

By FireOpal, Nerror & xentrix
20081029
]],
				},
			},
		},

		{
			name = L"Norsca",
			entries =
			{
				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Beastman (Title)",
					text =
[[
Beastman, Gor - The Murder Wood
"Road Warden"

NORSCA @ 29k, 17k. Click on the herdstone.

By Maehan, Puddles404, LatukiJoe & Wykk
20081007
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Beastman (Title)",
					text =
[[
Beastman, Ungor (An Unfortunate Victim) - Who Wud Murder
"The Brute"

NORSCA @ 24.5, 15.5k. Head toward the first Ungor camp from spawn area and check behind rocks for human corpse.

By Kovacs, Nozaro, Puddles404 & JodouTR
20081014
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Plage Victim (Tactic)",
					text =
[[
Plague Victim - Epic Epidemic
CHAOS TOME TACTIC

NORSCA @ 18.5, 48.5. Go to Mathis Rittenhouse sitting on a rock W of Suderholm PQ and near the Power Hungry Villager.

By Shadeviper, Riggswolfe & Sildroni
20081124
]],
				},
				
				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Plage Victim (Tactic)",
					text =
[[
Plague Victim - Epic Epidemic
CHAOS TOME TACTIC

NORSCA @ 51.5, 57. Look for Sister Raffaela in the plagued village. She's sitting in the back of the village on the ground near the hills next to a bush.

By FireOpal, Aoibhinn & Sereca
20081124
]],
				},
				
				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Skeleton (Title)",
					text =
[[
Skeleton - What Lay Ahead
"The Skeleton Hunter"

NORSCA @ 33, 7. Near the Chaos starting area there is a cemetery with a load of ghouls. In that cemetery is a gravestone, it's tall and there are a bunch of skulls stacked on top of each other on it. Simply click it to get the unlock.

By Kovacs, Impatiens & Elmarra
20081110
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Spider, Giant (Title)",
					text =
[[
Spider, Giant - Tacky Decor
"Spider-Slayer"

NORSCA. Also found in the Spider Cave (N of the bandit camp). NOTE: If you don't get the unlock here, see the entry in TROLL COUNTRY, below, and try that.

By NicWester, burfo, FireOpal & Wykk...whew.
20081007
]],
				},

				{
					name = L"Spirit Host (Title)",
					text =
[[
Spirit Host - Place of the Dead
"The Fearless"

NORSCA @ 48k, 45k. It's a habitat unlock on the (D) side. Go into the crypt "Amund's Barrow". I got it just a few steps into the crypt.

By Aoibhinn, Riggswolfe, papalauthority, notalltogether & raicarter
20081007
]],
				},
			},
		},

		{
			name = L"Troll Country",
			entries =
			{
				{	--  Destro version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Bat (Title)",
					text =
[[
Bat, Giant - For Once It Isn't Guano
"Echo Hunter"

TROLL COUNTRY: Kill any bat in Troll Country to net a Bat Wing.
Deliver to Voxanna the Transmuter in Felde @ 11, 60.

By NicWester & Elmarra
20081029
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Bat (Title)",
					text =
[[
Bat, Giant - For Once It Isn't Guano
"Echo Hunter"

TROLL COUNTRY: Kill any bat in Troll Country to net a Bat Wing.
Deliver to Brenard the Alchemist in Felde Castle @ 27, 82.

By Colloquial & Maehan
20081029
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Lizard (Tactic)",
					text =
[[
Giant Lizard - Hunger Pangs
BESTIAL TOME TACTIC UNLOCK

TROLL COUNTRY. Max out Dieter Stroh (Kill Collector for Ch6) by killing 50 Bluespine Salamanders: http://www.wardb.com/npc.aspx?id=5443 or Blueridge Salamander: http://www.wardb.com/npc.aspx?id=12836

By armorum
20081007
]],
				},

				{
					name = L"Gorger (Title)",
					text =
[[
Gorger - Questionable Fashion
"The Foolhardy"

TROLL COUNTRY. Kill any gorger in Troll Country to loot aGorger Bone Decoration. The Gorgers are mostly on the N and NW mt ranges. Once you have the item use it from your inventory for the unlock.

By Maehan, Wilken & Elmarra
20081021
]],
				},

				{
					name = L"Plaguebearer (Tactic)",
					text =
[[
Plaguebearer (Festering Corpse) - Finding Foul Flesh
DAEMONIC TOME TACTIC UNLOCK

TROLL COUNTRY @ 55, 27k. Hiding behind a tree NW of the Griffon Outpost PQ for (D). Corpse is half bent over between a rock and a tree; click on it for the unlock.

By Kargraz & aldrayk
20081016
]],
				},

				{
					name = L"Spider (Title)",
					text =
[[
Spider, Giant - Tacky Decor
"Spider-Slayer"

TROLL COUNTRY @ 2, 35k. Habitat unlock when you enter the Suskarg Caves.

By LatukiJoe
20081007
]],
				},

				{
					name = L"Spite (Tactic)",
					text =
[[
Spite (Elorian) - Lost and Found
MYTHICAL TOME TACTIC UNLOCK

TROLL COUNTRY @ 8.5, 46k. SW around the Wart Trolls there's a single Spite. Kill it.

By NicWester, Blodsalv, Royalflush & FireOpal
20081007
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Troll (Title)",
					text =
[[
Troll - Troll Tales
"Trollwise"

(D) TROLL COUNTRY @ 61.5, 29. Talk to Afvaldr.
(O) SAME @ 26, 41. Talk to Walbrecht Veit. Out of sight, behind the rocks just to the right of the entrance to the top camp at Griffon Outpost PQ. NOTE: Also confirmed near the deathzone quarry with all the furys/horrors/flamers.

By Insubstantial, Culland, dragonbait & Kriegzwerg
20081021
]],
				},

				{
					name = L"Troll (Tactic)",
					text =
[[
Troll, Stone (Coldsnap) - It's a Snap
GIANT TOME TACTIC

TROLL COUNTRY @ 9.5, 5. Kill the champ troll. NOTE: Need killing blow for the unlock.

By NicWester, Supaplex, Kellithe, Burgerderby & Shadyjane
20081027
]],
				},

				{
					name = L"Troll (Title)",
					text =
[[
Troll, Chaos - Gone But Not Forgotten
"The Undaunted"

TROLL COUNTRY. While killing Wart Trolls near The Troll Pit cave, one dropped a piece of loot titled Lost Locket. Examining it yields this unlock. NOTE: May take a long time for the drop. Scavenging seems to yield it faster.

By burfo, Wykk & Avale
20081021
]],
				},

				{	--Destro version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Troll (Tactic)",
					text =
[[
Troll, River - Gotta Go
GIANT TOME TACTIC

TROLL COUNTRY @ 50, 47 or 50.5, 50.5 or 55, 48. Pick up River Troll Droppings.
Deliver to Voxanna the Transmuter in Felde @ 11, 60.

By khelben, Sandkat, Mulesh, ThePedant & Xiani
20081106
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Troll (Tactic)",
					text =
[[
Troll, River - Gotta Go
GIANT TOME TACTIC

TROLL COUNTRY @ 50, 47 or 50.5, 50.5 or 55, 48. Pick up River Troll Droppings.
Deliver to Brenard the Alchemist in Felde Castle @ 27, 82.

By khelben, Sandkat, Mulesh, ThePedant & Xiani
20081106
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Troll (Title)",
					text =
[[
Troll, River  - Mass Exstinktion
"River Troll Ravager"

TROLL COUNTRY @ 57, 35.5. Walk into the entry of the Griffon Outpost PQ.

By NicWester, Squarkk, scootle & xarinth
20081110
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Troll (Title)",
					text =
[[
Troll, River  - Mass Exstinktion
"River Troll Ravager"

TROLL COUNTRY. Go N of the monster habitat to the Griffon Camp PQ. Wandering here should get it for you. If it doesn't, then near The Blighted Farm PQ (on a cliff above the Griffon Camp) I fell off the SE face of the cliff, into the camp. While falling I got the unlock.

By NicWester, Squarkk, scootle & xarinth
20081110
]],
				},

				{
					name = L"Troll (Pocket)",
					text =
[[
Troll, River (Bridge Troll) - Takes its Toll
POCKET ITEM

TROLL COUNTRY @ 54, 37 or 56, 23. The mob spawns under one of the two bridges. Kill it for the item: Revolting Crock.

By Nogglli, NicWester & Squarkk
20081103
]],
				},

				{
					name = L"Troll (Tactic)",
					text =
[[
Troll, River  (Brackmaw) - O'de Toilet
GIANT TOME TACTIC

TROLL COUNTRY @ 56, 47. First, near the Troll hunting goblin camp pick up a Barrel of Perfume. Then kill the mob @ 56, 44k.

By Kellithe, vahnkiljoy, Wykk, Squarkk & Spasmbot
20081103
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Troll (Title)",
					text =
[[
Troll, Stone  (Stormblight Dolt/Brute) - Uneasy Stomach
"The Boulderbane"

TROLL COUNTRY @ 12, 31. Kill this mob. Collect multiple Intact Troll Stomachs. Confirmed return at 5 stomachs, official number may be less.
Deliver to Voxanna the Transmuter in Felde @ 11, 60.

By NicWester, Nozaro, Spasmbot & Xiani
20081106
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Troll (Title)",
					text =
[[
Troll, Stone  (Stormblight Dolt/Brute) - Uneasy Stomach
"The Boulderbane"

TROLL COUNTRY @ 12, 31. Kill this mob. Collect multiple Intact Troll Stomachs. Confirmed return at 5 stomachs, official number may be less.
Deliver to Brenard the Alchemist in Felde Castle @ 27, 82.

By NicWester, Nozaro, Spasmbot & Xiani
20081106
]],
				},
			},
		},

		{
			name = L"Ostland",
			entries =
			{
				{
					name = L"Bandit (Tactic)",
					text =
[[
Bandit (Lodwig Falkenheim) - Wanted!
MAN TOME TACTIC

OSTLAND @ 56, 24. Kill this L17 champ. NOTE: Shadow Bandits may be placeholders.

By reggie & Dormammu & Kriegzwerg
20081022
]],
				},

				{
					name = L"Bat, Giant (Tactic)",
					text =
[[
Bat, Giant (Heartraker)- Things with Wings...
BESTIAL TOME TACTIC UNLOCK

OSTLAND @ 21.5, 29k or 31, 46k or 39, 40k. Kill this L17 Champ. In the Empire Ch8 town, follow the mts to a champ bat in the trees. It was sort of in the middle of the road between the town and the tower W of it. NOTE: Mob wanders, but will rest at the above locations.

By Xigence, Wykk, thezenny, Thanat0s, Avale, Getout & Emrus
20081013
]],
				},

				{
					name = L"Beastmen (Title)",
					text =
[[
Beastman, Bestigor - Meat for the Beast
"The Raw"

OSTLAND @ 21, 36k. By the Gor PQ for (O), towards the W of the Map. Downhill from the Gor PQ, towards the NW is another small group of Gors and a named NPC who you have to kill for an (O) quest. You'll be near when you see Gashthorn Beastmen instead of Blackmire Beastmen. Just S of them by a tree is a Witchhunter corpse lying between two trees just at the river. Right clicking on it gives you the title.

By Riggswolfe, Blodsalv, Wykk & scootle
20081007
]],
				},

				{   -- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Beastmen (Tactic)",
					text =
[[
Beastmen, Gor (Darkhorn Gors) - Thin the Herd
CHAOS TOME TACTIC UNLOCK

OSTLAND @ 17, 11k. Kill Darkhorn Gors. Then head to Felde and talk to the Kill Collector named Gottfried Holz. When you kill enough, you get the unlock.

By Blodsalv & GreenElite
20081007
]],
				},

				{   -- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Beastmen (Tactic)",
					text =
[[
Beastmen, Gor (Darkhorn Gors) - Thin the Herd
CHAOS TOME TACTIC UNLOCK

OSTLAND @ 20, 37.5k. Go to the Gasthorn Gor camp. Talk to the Kill Collector named Droki Greybeard in Bohsenfels (Ch8 camp). He talks about his friend killing 50 of them, daring you to beat that number, I killed 52 and received the unlock after going back to him.

By Kellithe
20081007
]],
				},

				{
					name = L"Dryad (Cloak)",
					text =
[[
Dryad (Sheen Gloomleaf)- Death in Green and Brown
CLOAK ITEM UNLOCK

OSTLAND @ 7, 18k. Everyone knows this one. Go to the lake, find the named Dryad, kill it. It's how you get the Shawl of Spring.

By NicWester, Nazaro & Nerror
20081007
]],
				},

				{
					name = L"Plague Feaster (Tactic)",
					text =
[[
Plague Feaster - Wash Your Hands
CHAOS TOME TACTIC UNLOCK

OSTLAND @ 48.5, 32k. Kill a champ named Plagued Feaster. There's a "Basket of Fish" that needs to be clicked to spawn the NPC if he isn't there. He's about straight up N of Wolfenburg past the bridge you see NW of Wolvenburg. He wanders along the water in an open area. Kill him for the third Plague Victim unlock.

By Blodsalv, reggie, scootle & Jschmuch2
20081007
]],
				},

				{
					name = L"H. of Tzeentch (Title)",
					text =
[[
Horror of Tzeentch (Purple Horror) - The Colors of Horror
"Aethyr Guard"

OSTLAND @ 43, 52. Kill the R20 mob near Wolfenburg in the court with all the horrors. The mobs name is Purple Horror, but the color was blue. NOTE: Frustratingly long spawn timer.
NOTE: Confirmed reports of Purple Horror spawning when pulling 1 pink and 1 blue horror and killing them at the exact same moment.

By Blodsalv, Sandkat, notalltogether, ThePedant, Mourngrym, Dguras & Sildroni
20081124
]],
				},

				{
					name = L"Skeleton (Tactic)",
					text =
[[
Skeleton (Boneshard Minion) - When There's a Will
UNDEAD TOME TACTIC

OSTLAND @ 30, 18. Go to Gerstman's Crypt and slaughter Boneshard Minions. One of them will drop a Faded Scroll. Right click it and you've got the unlock.

By NicWester & ThePedant
20081027
]],
				},

				{
					name = L"Skeleton (Tactic)",
					text =
[[
Skeleton - Bones Have Names Too
UNDEAD TOME TACTIC UNLOCK

OSTLAND @ 48, 18k. Kill Halman Meusmann. Best description I can give is follow the road S from Kaussner's Garrison till you see the first bridge. Cross it and close by should be a small camp with skeletons and 2 champ undead, near a camp with bandits which connects to the water. At the skeleton camp is a named normal mob. Kill it.

By reggie & scootle
20081007
]],
				},

				{   -- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Spirit Host (Pocket)",
					text =
[[
Spirit Host - Time is of the Essence
POCKET ITEM

(O) OSTLAND @ 48.5, 57.5. Start by getting a Jekil's Wedding Band off of the "Corpse of Jekil Behn" in Wolfenberg, behind a house near where the land slopes down to the river. The ring goes in your regular, not quest inventory. Then, travel QUICKLY SE to the graves near the catacombs. Go quickly to Hilde Behn's gravestone at 60k, 60k where she will spawn very briefly. Click on her as you would a quest mob to complete the task and unlock the item: Grave Dust.
NOTE: If you miss Hilde, she also spawns @ 12:00 p.m. (mid-day) SERVER TIME (type /time) NOTE: Confirmed complete @ 12:45pm GMT, so some wiggle room is given time-wise.
(D) WARNING: Currently broken.

By reggie, Riggswolfe, Sique, Avale, Bigskyn, cc2233bb & Xiani
20081117
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Spite (Title)",
					text =
[[
Spite - Looking for Shinnies
"The Spite Splitter"

OSTLAND @ 14,14. Kill Spites for the Shining Ring. Mostly can be found at the PQ Spirits of the Shadow.

By thezenny & xarinth
20081124
]],
				},

				{
					name = L"Troll (Pocket)",
					text =
[[
Troll (Heathgut Troll) - Who Is Up for Seconds
POCKET ITEM UNLOCK

OSTLAND @ 22.5, 3.5k or 32.5, 1.5k or 36.5, 3.5k. These trolls drop "Troll's Dinner". Examine the item to get an unlock for the pocket item: "A Troll's Pet Kitty." Drop rate has been nerfed, so get ready for a lot of farming. NOTE: Drop also found off Mudbelly Trolls in BADLANDS: http://www.wardb.com/npc.aspx?id=4693.

By Impatiens, Archaides & Nerror
20081009
]],
				},

				{   -- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Wolf (Cloak)",
					text =
[[
Wolf (Bloodfog Wolf) - Picking Up The Pieces
CLOAK ITEM

OSTLAND. Complete the Chaos Ch7 Kill Collector quest in Kournos' Encampment. NOTE: Most are located in Troll Country. Unlocks: Hunter Master's Pelt.

By Nerror
20081029
]],
				},
			},
		},

		{
			name = L"High Pass",
			entries =
			{
				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Tuskgor (Tactic)",
					text =
[[
Tuskgor - Saving Face
CHAOS TOME TACTIC

(D) HIGH PASS @ 41, 46. Gather Unchipped Tusks by killing Bloodsnout Tuskgors in HIGH PASS.

By Mourngrym, Socran, Karylet & Grishnar
20090107
]],
				},

				{
					name = L"Beastman (Tactic)",
					text =
[[
Beastman, Ungor (Gurrvek Shorthorns) - Thorn in My Side
CHAOS TOME TACTIC

HIGHPASS @ 46, 50. Kill this L25 champ. Confirmed to spawn due N of Lishka from the wolf entry. NOTE: May be on a long timer, or have multiple spawn points.

By Alesinde, Crucifix & Coriolis
20081030
]],
				},

				{
					name = L"B. of Khorne (Title)",
					text =
[[
Bloodthirster of Khorne (Empire Runner Corpse) - Dire News Indeed
"Heritor of War"

HIGH PASS @ 38, 41k. Near the bottom of the cliffs is a corpse. Interact with it to get the unlock.

By Wilken & Shawen
20081007
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Chaos Fury (Title)",
					text =
[[
Chaos Fury (Zchekil the Vile) - Nefarious Force
"The Warpbinder�

HIGH PASS: Simply talk to Zchekil the Vile by right-clicking him.

By Foggye & Sandkat
20081104
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Chaos Fury (Title)",
					text =
[[
Chaos Fury (Zchekil the Vile) - Nefarious Force
"The Warpbinder�

HIGH PASS @ 51, 50. Kill this L25 Hero Chaos Fury. Appears to be a slow or rare spawn. NOTE: May have multiple spawn locations.

By Foggye & Sandkat
20081104
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Chaos Hound (Title)",
					text =
[[
Chaos Hound (Bradiclaw the Seeker) - Seeker in the Snow
"The Gnawed"

HIGH PASS: Talk to Karl Oromson in Bloodmarr.

By Blodsalv & Mabuz
20081029
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Chaos Hound (Title)",
					text =
[[
Chaos Hound (Bradiclaw the Seeker) - Seeker in the Snow
"The Gnawed"

HIGH PASS @ 56, 50. Kill this L25 hero E of Vladesaul.

By Smilliam, Thanat0s & Akiu
20081029
]],
				},

				{
					name = L"Chaos Spawn (Title)",
					text =
[[
Chaos Spawn - Beyond Definition
"The Serene"

HIGH PASS @ 16, 30k or 28, 30k or 14.5, 42k. There is a red and black book on the mt titled "The 6th Journal of Llian". On pop spot is between a stand of 3 trees, and there's a horn hanging from a rope off one of the branches of the tree. NOTE: Book de-spawns on pickup and can respawn at any of the above locations.

By vassago1488, Medea, Xururuca, Toodlepips & Greggar
20081007
]],
				},

				{
					name = L"Spite (Tactic)",
					text =
[[
Spite (Elorian) - Lost and Found
MYTHICAL TOME TACTIC

HIGH PASS @ 58, 16. Kill this L16 mob.

By Drunklight, Sandkat, vasil & Josemite
20081023
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Flayerkin (Title)",
					text =
[[
Flayerkin - One Part Agony, Three Parts Cold Wought Iron
"The Flayer"

HIGH PASS.
PART 1: 3, 38 is where the entrance to the Tomb for the chain is. Find the item on a corpse called "Dead Flayerkin" inside the Tomb of the Traitor PQ. The loot was Flayer-Kin's Scaling Chains.
PART 2: 10, 49 is where to find Flayer-Kin's Scaling Hooks. Go around the mt and swoop back when coming from the S. Inside a cave is a Flayerkin corpse has the hooks.
PART 3: 47, 33 in WEST PRAAG. Find the Flayer-Kin's Iron Helm on a flayerkin corpse.
Turn in to Kreelik of Clan Moulder @ 6, 10 in PRAAG, Chaos Ch17 camp. (Blodsalv)

By Kellithe, Blodsalv, Wilken & Thovargh
20081022
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Flayerkin (Title)",
					text =
[[
Flayerkin - One Part Agony, Three Parts Cold Wought Iron
"The Flayer"

HIGH PASS.
PART 1: 3, 38 is where the entrance to the Tomb for the chain is. Find the item on a corpse called "Dead Flayerkin" inside the Tomb of the Traitor PQ. The loot was Flayer-Kin's Scaling Chains.
PART 2: 10, 49 is where to find Flayer-Kin's Scaling Hooks. Go around the mt and swoop back when coming from the S. Inside a cave is a Flayerkin corpse has the hooks.
PART 3: 47, 33 in WEST PRAAG. Find the Flayer-Kin's Iron Helm on a flayerkin corpse.
Turn this chain in to Breitenhoff the Faithful in Ch17 Empire, in Praag @ 17, 45. NOTE: The coords are 13, 57 for the turn in. (Mabuz)
NOTE: Confirmed Unlock with only having the chain from Part1 and then talking to the healer. (by Thunderblaze)


By Kellithe, Blodsalv, Wilken & Thovargh
20081022
]],
				},

				{
					-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Gnoblar (Title)",
					text =
[[
Gnoblar - Mixed Company
"The Bully"

HIGH PASS @ 18, 3.8 to 23, 3. Habitat unlock by running through several tents with Ogres and Gnoblars.

By Blodsalv, Avale & Yvarma
20081029
]],
				},

				{
					name = L"Gorger (Token)",
					text =
[[
Gorger (Bloodscent) - Engage the Gorger
BESTIAL TOKEN UNLOCK

HIGH PASS @ 18, 7.5k. Kill this lvl29 Champ.

By Sandkat, Thanat0s & Medea
20081007
]],
				},

				{	-- Order entry
					realm = TTitan.Data.Realm.ORDER,
					name = L"Great Cat (Title)",
					text =
[[
Great Cat (Snarling Razortooth) - A Run for Rolf
"The Clawed"

HIGH PASS. Complete Rolf Grimwold's Kill Quest quota for the unlock. Mobs can be found along the pass between Nuhr's Crest and Raven's End.

By Kutzum & TorqueVolkmar
20081023
]],
				},

				{
					name = L"Great Unclean (Title)",
					text =
[[
Great Unclean One (Old Hienrich) - The Unclean
"Herald of the Vital"

HIGH PASS @ 26, 41. Near a small frozen lake SW of the Chaos Ch13 camp "Bloodmarr" an NPC directs you to his "Hienrich's Stew pot" which grants the unlock when used. NOTE: NPC is not always there, so this may be time or circumstance dependent, but once he's up he is confirmed to stay up for quite a while.
SIGHTINGS:
Saturday @ 4:34 EST, in-game: 20:10
Saturday @ Noon CST, in-game: 20:34
3:20 PM GMT, in-game: 16:20
8:30 PM CST; in-game 7:00

By Houyoko, Zarlemagne, Lorem Ipsum, koan, JodouTR & Avale
20081028
]],
				},

				{
					name = L"Ogre, Bull (Tactic)",
					text =
[[
Ogre, Bull - It's Safer Outside
GIANT TOME TACTIC UNLOCK

HIGH PASS @ 5, 34.5k. Habitat unlock N of the PQ "Tomb of the Traitor" near a camp full of Ogre Bulls.

By carbonara & xentrix
20081013
]],
				},

				{
					name = L"Ogre, Bull (Tactic)",
					text =
[[
Ogre, Bull (Marl the Maneater) - Bigger They Are...
GIANT TOME TACTIC

HIGH PASS @ 9, 44 or @ 5k, 45. Kill this L23 champ. He patrols the road.

By Kellithe, Xigence & Pingping
20081124
]],
				},

				{
					name = L"Plaguebearer (Acc)",
					text =
[[
Plaguebearer - Organ Grinder
SET ITEM

Kill Grotesque Plaguebearers in the CHAOS WASTES around 48000,53000 until one drops a Pestilent Organ. Click the Pestilent Organ for the unlock.

By Ahi (Bala)
20081031
]],
				},

				{
					name = L"Warhawk (Pocket)",
					text =
[[
Warhawk - Poached, Scrambled, or Fried
POCKET ITEM

HIGH PASS @ 9, 44 or 4.5, 42 or 6, 53.5. Gather 5 Warhawk eggs near the trolls, and select the items in your inventory after. Unlocks item: Bird Seed. NOTE: Only 1 egg will spawn at a time and always will spawn near a moltclaw eagle. All the warhawks are on a range of mts accessible at the mt that you get up via a ledge @ 6.5, 44.5 and jumping across to near the Yhetee. NOTE: There are more spawn points than listed just look for the hawks to find the eggs.

By Amisted, Pingping, Wilken & Dracool
20081022
]],
				},

				{
					name = L"Wight (Cloak)",
					text =
[[
Wight (Kulian Bonewarriors/Bonearchers) - Broken Men, Broken Blades
CLOAK ITEM

HIGH PASS @ 34, 25. Collect 5 Broken Wight Blade from these skeletons in the Keep of Asavar Kul to unlock the Death Shroud Cape.

By Blodsalv & Wykk
20081022
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Wolf (Tactic)",
					text =
[[
Wolf (Lishka)- Alpha in Bits
BESTIAL TOME TACTIC

HIGH PASS @ 46, 51. Kill this grey named that roams the cliffs overlooking the PQ grisley herd.

By Nilenya, Wilken, Crucifix & Kellithe
20081029
]],
				},

				{
					name = L"Yhetee (Cloak)",
					text =
[[
Yhetee (Killing Frost) - Appropriately Named
CLOAK ITEM

HIGH PASS @ 8, 44 . Near T3 (O) Ch10, kill a yeti champ on a mt along the road S of the (O) Ch10 town. It's on top of the first snowy mountain when the ground starts to change. It'll be on your left, if you're heading S and eagles are visible on the ledges. It unlocks Hide of Killing Frost.
NOTE: The mts are accessible via a ledge at 6.5, 44.5 and jumping across left near the Yhetee.

By Colloquial, Impatiens, Nilenya & Wilken
20081029
]],
				},
			},
		},

		{
			name = L"Talabecland",
			entries =
			{
				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Beastman (Tactic)",
					text =
[[
Beastman, Bestigor - Appalling Fashion
CHAOS TOME TACTIC

TALABECLAND @ 55, 35 or 48, 42. Confirmed at 1st coords by right clicking Casimir Por in the Beastman area E of the Herdstone. At 2nd coords, killing blow the L9 champ Witch Hunter Adept and he will give you the necklace that you click on for the unlock.

By Blodsalv, armorum, Archaides, Kellithe & Shaz
20081124
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Beastman (Tactic)",
					text =
[[
Beastman, Bestigor - Appalling Fashion
CHAOS TOME TACTIC

TALABECLAND @ 48.5, 39. Head to the Blackhorn Heardstone. Kill them to receive a Grisly Necklace. Beastman Bestigors have the best droprate. Right click it for the unlock.

By Blodsalv, armorum, Archaides, Kellithe & Shaz
20081124
]],
				},

				{
					name = L"Beastman (Tactic)",
					text =
[[
Beastman, Ungor - Trinkets for Treasure
CHAOS TOME TACTIC

TALABECLAND @ 48.5, 39. Kill L27 Blackhorn Ungors near the Blackhorn Herdstone. Gives an Ungor Talisman. Sell it to a merchant. Works for both.

By Blodsalv & armorum
20081021
]],
				},

				{
					name = L"Chaos Mutant (Title)",
					text =
[[
Chaos Mutant - Handy Dandy
"The Unsullied"

TALABECLAND @ 23k, 32k. Kill 10 Deathbed or Grave Mutants for 10 of their Mutant Hands. ADDENDUM: The drop rate for hands is not 100%, but my friend and I still got them soon enough.

By Blodsalv, ThePedant & TorqueVolkmar
20081023
]],
				},

				{
					name = L"Plaguebearer (Tactic)",
					text =
[[
Plaguebearer (Blight Spew) - Let It Fly or Let It Die
DAEMONIC TOME TACTIC UNLOCK

TALABECLAND @ 36, 51k. Where the river curves into a "U" shape kill this L29 champ.

By Kellithe, armorum & Crucifix
20081014
]],
				},

				{
					name = L"Plague Victim (Pocket)",
					text =
[[
Plague Victim - Side Effects Include Mutation and Death
POCKET ITEM

TALABECLAND @ 5, 43. A Chest is guarded by 2 L29 champ guards. Opening the chest unlocks item: Barrel of Ale. NOTE: Acquiring item from a librarian may be bugged. You receive the item Filthy Hanky instead.

By Thovargh, armorum, JodouTR & Vaginitus
20081022
]],
				},

				{
					name = L"Skaven (Tactic)",
					text =
[[
Skaven - What a Rat's Nest
SKAVEN TOME TACTIC

TALABECLAND @ 30, 16. In the Horned Tower are mostly L23-34 Skaven. Go all the way to the very top and circle around the balcony. There is a flag/banner, click it and bam, you have the unlock: "Queek Reek"

By Kellithe, Ningiliath & Sandkat
20081029
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Vulture (Pocket)",
					text =
[[
Vulture (Blightbeak Vultures/Blightbeak Carrion) - Diseased Pecking Order
POCKET ITEM

TALABECLAND @ 4, 44. Near the S side of the river these L29 mobs drop a "Blightbeak Beak". Unlocks: Carrion Tickler.
Turn in to the healer NPC in chaos Ch11. Requires "More Than Just a Foul Feather"

By Thovargh, Mabuz, Shattered, Caliber & Almaram
20081021
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Vulture (Pocket)",
					text =
[[
Vulture (Blightbeak Vultures/Blightbeak Carrion) - Diseased Pecking Order
POCKET ITEM

TALABECLAND @ 4, 44. Near the S side of the river these L29 mobs drop a "Blightbeak Beak". Unlocks: Carrion Tickler.
Turn in to the healer in (O) Ch14.

By Thovargh, Mabuz, Shattered, Caliber & Almaram
20081021
]],
				},

				{
					name = L"Vulture (Tactic)",
					text =
[[
Vulture (Plaguefeather) - More Than Just a Foul Feather
BESTIAL TOME TACTIC

TALABECLAND @ 4, 44. Near the W map border, near the S side of the river. Killing blow this Lvl29 champ.

By Thovargh & Cahyr
20081105
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Wolf (Tactic)",
					text =
[[
Wolf (Sorenna) (Lishka) - Alpha in Bits
BEASTIAL TOME TACTIC UNLOCK

TALABECLAND. Kill this L26 wolf just SE of Volgen, the Chaos Ch12 camp.

By Supaplex & Kellithe
20081013
]],
				},

				{
					name = L"Zombie (Title)",
					text =
[[
Zombie - Dare to Tread With the Undead
"The Gory"

TALABECLAND @ 38.5, 38k. Explore the graveyard.

By Blodsalv
20081007
]],
				},
			},
		},

		{
			name = L"Praag",
			entries =
			{
				{
					name = L"Bear (Pocket)",
					text =
[[
Bear (Deadmaul) - Getting Ahead
POCKET ITEM

PRAAG @ 58, 18. Kill this L36 champ bear inside a cave. Unlocks Deathmaw Paw.

By Thanat0s & furnaps
20081106
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Bear (Tactic)",
					text =
[[
Bear (Ursun Bear/Deadmaul) - Heading for Profit
BESTIAL TOME TACTIC

PRAAG. Kill these mobs at the Ursun's Den (middle of E map border) to get a Deadmaul's Paw. Sell this to a merchant for unlock.

By Supaplex, Josemite & skyrunner620
20081124
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Bear (Tactic)",
					text =
[[
Bear (Ursun Bear/Deadmaul) - Heading for Profit
BESTIAL TOME TACTIC

PRAAG @ 59, 19. Ursun Bears are friendly to (O). Loot the paw from the source: Deadmaul, inside his cave. He doesn't drop it very frequently (WarDB lists 8% to the Ursun Bear's 33%).

By Supaplex, Josemite & skyrunner620
20081124
]],
				},

				{
					name = L"Beastman (Tactic)",
					text =
[[
Beastman, Gor (Drahamesh) - For the Greater Gor
CHAOS TOME TACTIC

PRAAG @ 7, 18. Kill this L40 Hero. NOTE: Mob does not hit hard.

By Alesinde
20081021
]],
				},

				{
					name = L"Beastman (Acc)",
					text =
[[
Beastman, Ungor (Grentic the Thick-Headed) - Thick-Headed
JEWELRY ITEM

PRAAG @ 0.7, 28. Kill this named mob @ the W border of Praag. Exact loc might vary a bit in that area. Grants the Writhing Shackles accessory, part of The Divided Jewelry set.

By Supaplex & Benji
20081117
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Big Cat (Title)",
					text =
[[
Big Cat - A Run for Rolf
"The Clawed"

PRAAG. Southern Breach, Ch19, max the Kill Collector.

By Sandkat
20081021
]],
				},

				{
					name = L"Bird (Tactic)",
					text =
[[
Bird, Warhawk (Snowperch Matriarch) - Well Watched Weaklings
BESTIAL TOME TACTIC

PRAAG @ 58, 50. Kill this L37 Hero. There are 4 L36 Snowperch Fledglings at this spot. Kill 1 of them and the Hero will spawn.

By Brail & JCBN
20081106
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Chaos Giant (Title)",
					text =
[[
Chaos Giant (Geral the Dim) - What's Inside is What Counts
"The Unflinching"

PRAAG @ 50, 10. Kill the giant and take the item to Kraglorn the Maker @ 46.5, 44 in WEST PRAAG.

By Drunklight & Tyrilian
20081030
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Chaos Giant (Title)",
					text =
[[
Chaos Giant (Geral the Dim) - What's Inside is What Counts
"The Unflinching"

PRAAG @ 58, 10. Kill this giant to receive Mote of Zzangal'Nes Nalanel, and then talk to Aialye Lynsellia in Eataine.

By Drunklight & Tyrilian
20081030
]],
				},

				{
					name = L"Chaos Mutant (Token)",
					text =
[[
Chaos Mutant (Calvin Lankdorf) - Leader of the Lost
BEAST TOKEN

PRAAG @ 16, 13 or 15, 9 or 18,15. Kill this L38 mob. The Mutated Peasant is a place holder for him if he is not up on that spot.

By Thovargh, Teran, Josemite, skyrunner620, Benji & Drollgar
20081124
]],
				},

				{
					name = L"Chaos Spawn (Acc)",
					text =
[[
Chaos Spawn - Empirical Proof
JEWELRY ITEM

PRAAG @ 13, 1 or 12.5, 3 or 11, 5.3. A book called "Third Journal of Lilean" spawns near the first (D) PQ "Gates of Praag". Find it E of town where Sasha Michailov is. Grants the unlock: One Tusk. NOTE: The Third Journal might also spawn on the opposite side of Sasha (near his most E spawn point, near the Griffon couriers) behind a building.

By Supaplex, Blodsalv, Flawed, Dirg & omega1
20081110
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Hound (Tactic)",
					text =
[[
Hound - Picky Eater
BESTIAL TOME TACTIC

PRAAG. Talk to the to the guard with a hound near him at chaos Ch19 to receive an empty bag. Kill horses until you obtain a Fresh Meat, then return to the guard to receive the reward.


By Fura
20081021
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Hound (Tactic)",
					text =
[[
Hound - Picky Eater
BESTIAL TOME TACTIC

PRAAG. Talk to the Hungry Hound behind the tent with the rally master in Ch17. He gives you an empty bag. Kill Warpwind Night Runners near the tunnel @ 8.5, 64 to get fresh meat. Return to the hound afterward to give them their 'lovely' meal.

By India
20081021
]],
				},

				{
					name = L"Skaven (Pocket)",
					text =
[[
Skaven (Thashtak Bloodeye) - Dead Eye
POCKET ITEM UNLOCK

PRAAG @ 8, 62k. This L35 champ is found inside the Skaven tunnels and gives the item: "Barbed Whip".

By rollen, Eridanos & JodouTR
20081016
]],
				},

				{
					name = L"Tuskgor (Pocket)",
					text =
[[
Tuskgor (Bloodcharge) (Scythetusk) - Tough Meat
POCKET ITEM

PRAAG @ 5, 20. Kill L37 champ Bloodcharge.
-OR-
PRAAG @ 18, 15. Kill L38 Scythetusk.

By Ness, Blodsalv, Teran & omega1
20081110
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Wolf (Cloak)",
					text =
[[
Wolf (Winter Wolf) - Picking Up The Pieces
CLOAK ITEM

PRAAG. Kill these mobs and max out the Kill Collector in the Ch20 (O) camp in Chaos Waste. Best place to kill wolves is actually on the road on the border between Praag/Chaos along the (O) road. Unlocks: Hunter Master's Pelt

By fjir
20081031
]],
				},

				{
					name = L"Wraith (Acc)",
					text =
[[
Wraith (Gloomveil) - Soul Catcher
JEWELRY ITEM

PRAAG @ 22, 53. There is a mob under the waterfall. Kill it to unlock the ring: Foserain.

By rollen
20081021
]],
				},
			},
		},

		{
			name = L"West Praag",
			entries =
			{
				{
					name = L"Centigor (Title)",
					text =
[[
Centigor - Good to the Last Drop
"The Unruly"

WEST PRAAG @ 43.5, 45. Click the Noxious Ale and use it in your inventory to get the title. NOTE: May have a long respawn time. Show up around 22:00 in-game time, in case that turns out to be relevant. It's by the big rock across the river, on the ground. Tip: Make sure you have inventory space for it as it will disappear if you do not. I learned this the hard way by Ulgwar.

By Drunklight, Flawed & TorqueVolkmar
20081110
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Chaos Spawn (Pocket)",
					text =
[[
Chaos Spawn, Daemonvine (Xavian's Pride) - Cutting Bonds
POCKET ITEM UNLOCK

WEST PRAAG @ 46k, 6k. Go N of the Chasing Shadows PQ (N border of map). The mob is near a house. Killing it gave the unlock, although the tome unlock says you need a certain weapon. If I'm not mistaken this is also what the NPC in Chaos Wastes talks about for the Hide and Seek unlocks. Gives item: "Putrid Flower." NOTE: You find a "Sacrifical Kris" in a mound of dirt in Chaos Wastes. It says "Gerrad Farmstead, West Praag" on it. That must be the weapon, but I guess you don't need it. And yeah, it is related to the Hide and Seek NPCs (Anya Gerrad for D and Xavian Gerrad for O).

By Supaplex, Thanat0s & Xilanle
20081007
]],
				},

				{
					name = L"Hound (Tactic)",
					text =
[[
Hound (Lost Hound) - Dog Gone Crazy
BESTIAL TOME TACTIC

WEST PRAGG @ 31, 21. There are three 'Lost Hounds' wandering here. Killing one gives the unlock.

By Mapples & Iranium
20081020
]],
				},
			},
		},

		{
			name = L"Chaos Wastes",
			entries =
			{
				{
					name = L"Chaos (Title)",
					text = 
[[
Chaos - Complete a Chaos Scenario
"The Sentinel of Sanity"

CHAOS WASTES. Win a Maw of Madness Scenario.
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Beastmen (Tactic)",
					text =
[[
Beastman, Bestigor (Dreadhorn Bestigors) - Nacht to Dread
CHAOS TOME TACTIC UNLOCK

CHAOS WASTES @ 56, 20k. Max out Kill Collector Harald Nacht at (O) Chp 22 Camp by killng the mob at the Fall of Night PQ.

By Foggye
20081017
]],
				},

				{
					name = L"Beastmen (Token)",
					text =
[[
Beastmen, Bray Shaman (Kratkar/Dreadhorn Shaman) - Bigger Bray to Make Your Day
BEASTIAL TOKEN

CHAOS WASTES @ 56, 25 or 61, 25 or 54, 15. Kill this L40-41 non-champ. He's a few feet off the W side of the road. If he's not up, there may be a Dreadhorn Shaman L40 non-champ there instead. I got the unlock for killing Kratkor, a friend got the unlock for killing the shaman later that day. NOTE: Five minute respawn. FURTHER: Mob also pops up on the side of the cliff E of the road, so look all around the Gor areas, not just the W side of the road.

By Valekrin, Sandkat, JodouTR, Magdain & Dissent
20081021
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"B. of Khorne (Token)",
					text =
[[
Bloodletter of Khorne (Cithym) - The Key to Success
BEAST TOKEN

CHAOS WASTES
1: @ 38.5, 12.5. Hail Mihkail for the Talisman Key.
2: @ 60, 33 there is a "Battered Strongbox" at the Reaping Field PQ E of the Empire Warcamp. It may be hard to see initially, somewhat hidden behind a bush at the back end of the PQ near the hills. Clicking on the Strongbox will spawn a L39 Champ. Kill it.

By fjir, Iranium & Benji
20081124
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"B. of Khorne (Token)",
					text =
[[
Bloodletter of Khorne (Cithym) - The Key to Success
BEAST TOKEN

CHAOS WASTES
1: @ 38.5, 12.5 kill Mikhail the Profane from the Battered but not Forgotten unlock. When you kill him you will receive a Talisman Key. It will automatically go to your inventory when you kill him.
2: @ 60, 33 there is a "Battered Strongbox" at the Reaping Field PQ E of the Empire Warcamp. It may be hard to see initially, somewhat hidden behind a bush at the back end of the PQ near the hills. Clicking on the Strongbox will spawn a L39 Champ. Kill it.

By fjir, Iranium & Benji
20081124
]],
				},

				{
					name = L"B. of Khorne (Title)",
					text =
[[
Bloodletter of Khorne (Mikhail The Profane) - Battered But Not Forgotten
"The Sanguinary"

CHAOS WASTES @ 38.5, 12.5. Speak to(D) or kill(O) Mikhail the Profane, depending on your side.

By Iranium, Sandkat, Socran & Benji
20081112
]],
				},

				{
					name = L"Chaos Spawn (Pocket)",
					text =
[[
Chaos Spawn, Daemonvine - Cutting Bonds
POCKET ITEM

This unlock has two parts.
1. CHAOS WASTES @ 11, 14 to 22, 20 or 14, 17. Along the road, W side, there is a pile of dirt that's interactable, and gives you an item called Sacrificial Kris.
2. WEST PRAAG @ 46, 8. Near the farm shack there is a single Demonvine spawn. Kill it with the Kris in your inventory and you receive the unlock for: Putrid Flower.
NOTE: Confirmed to work by skipping step one and just killing the damned flower.

By WNxInviso, JodouTR & poll12
20081029
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Chaos Spawn (Title)",
					text =
[[
Chaos Spawn, Daemonvine - Hide and Seek
"The Weed Whacker"

CHAOS WASTES @ 5.5, 10. Listen to the sad story of Anya Gerrad. Head down the road, past the Wight area till the road curves and you see some Daemonettes, Chaosfuries and Plaguebearers to your left. She's hiding beside the road in the bushes. Stay close and listen for the unlock.

By Blodsalv, Thanat0s, Nukeitall, Houyoko & India
20081104
]],
				},

				{	-- Orderversion
					realm = TTitan.Data.Realm.ORDER,
					name = L"Chaos Spawn (Title)",
					text =
[[
Chaos Spawn, Daemonvine - Hide and Seek
"The Weed Whacker"

CHAOS WASTES @ 50, 61 Find Xavian Gerrad. Listen to his chatter and you get the unlock. NOTE: Confirmed to work for some and not for others. May be bugged, or need an initial first trigger.

By Blodsalv, Thanat0s, Nukeitall, Houyoko & India
20081104
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"D. of Slaanesh (Title)",
					text =
[[
Daemonette of Slaanesh (Eidih the Helator) (Bloodsong) - Song and Dance
"The Chaste"

CHAOS WASTES @ 15.6, 31 or 15.5, 40. Kill it and achieve the killing blow.

By Sandkat, Nukeitall, Bass, TorqueVolkmar & Kriegzwerg
20081105
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"D. of Slaanesh (Title)",
					text =
[[
Daemonette of Slaanesh (Eidih the Helator) (Bloodsong) - Song and Dance
"The Chaste"

CHAOS WASTES @ 54.5, 46. Accept the Breaking Point quest from Hewitt. Turn this quest in to Karl the Chaste @ 61, 53 and accept the next part. After killing 15 Daemonettes of Slaanesh turn this part in and receive a quest to kill Bloodsong. The mob spawns near the bottom of the hill and runs up to you. Kill it.

By Sandkat, Nukeitall, Bass, TorqueVolkmar & Kriegzwerg
20081105
]],
				},

				{
					name = L"F. of Tzeentch (Title)",
					text =
[[
Firewyrm of Tzeentch (Corrupt Spawn) - Insane in the Membrane
"The Insane"

CHAOS WASTES @ 22, 52k. Kill the L39 champ. You have to go down into a ravine just E of the Tower of Awakening PQ. After killing it you get a message that you pull a scale out of the beast. Look in your regular inventory for the scale, has the icon of a talisman. Right-click it a few times, after the first time a new one popped up and after the 2nd click a 3rd scale popped up so just keep clicking till you get the unlock.

By Supaplex
20081007
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"F. of Tzeentch (Title)",
					text =
[[
Flamer of Tzeentch (Soulflame) - Hot Deal
"The Banisher"

CHAOS WASTES @ 48, 6.5. Talk to the L41 named mob.

By Dissent, rally & JCBN
20081103
]],
				},

				{
					name = L"Giant Bat (Acc)",
					text =
[[
Giant Bat (Deathwing) - Not Available in Any Stores
SET ITEM

CHAOS WASTES @ 45, 3. Kill this L40 champ. It flies up near the ceiling at the back of the Caverns of Terror. 15min repop. Drops Deathwing's Fangs, rt click for: Hapless Ha'penny. NOTE: Drop rate is not 100%.

By Rathenau & Barandox
20081021
]],
				},

				{
					name = L"J. of Khorne (Title)",
					text =
[[
Juggernaut of Khorne - Between a Rock and a...
"The Immoveable Object"

CHAOS WASTES @ 40, 15 or 42, 16. Face the friendly Rhinox: Unbound Mastodon. Stand on the mob and face west. Their is a pile of rubble in the corner behind the wall. Click on it.

By Sandkat, Thanat0s, Socran & Yvarma
20081112
]],
				},

				{
					name = L"L. of Change (Title)",
					text =
[[
Lord of Change (Eye of Change) - I Spy With My Eye
"Scion of Anarchy"

CHAOS WASTES @ 64, 29. Up on the side of the mt is the Eye of Change (looks like a blue gem on the ground). Click it for the unlock. To get to it, go around the S of the mt range @ 62, 36.5 and then up the backside to drop down on it.

By Dissent. TorqueVolkmar & Crucifix
20081022
]],
				},

				{
					name = L"Nurgling (Tactic)",
					text =
[[
Nurgling (Corpulent Nurglings) - No End to the Oozing
DAEMONIC TOME TACTIC

CHAOS WASTES @ 17.5, 46.5 or 18.5, 38 or 18.5, 40. Kill Nurglings to loot Nurgling Ooze Sample. Collect 20 and you'll get the unlock. NOTE: Look for green bile on the floor, it show up on your mini-map.

By Supaplex, Thanat0s, Houyoko & Kriegzwerg
20081104
]],
				},

				{
					name = L"Plaguebearer (Acc)",
					text =
[[
Plaguebearer (Grotesque Plaguebearer/Plaguebringer) - Organ Grinder
SET ITEM

CHAOS WASTES @ 43, 55. Kill the mob and there is a chance you will receive an item called Pestilent Organ. Inspect this to get the unlock for the set item: Cytheril. NOTE: Mob is slightly to the SE of given coords.

By Zoe9906, JodouTR, Benji & Jette Black
20081117
]],
				},

				{
					name = L"S. of Tzeentch (Title)",
					text =
[[
Screamer - Puddles of Points
"The Screamer Seeker"

CHAOS WASTES @ 12, 55.5k. Unlocked it after stepping into an area filled with Screamers.

By Blodsalv
20081007
]],
				},

				{
					name = L"S. of Tzeentch (Cloak)",
					text =
[[
Screamer of Tzeentch (Vilemaw) - Poke'm If You Got'em
CLOAK ITEM

CHAOS WASTES @ 5, 25. Kill this L33 champ who roams the water just SE of the Lonely Tower PQ. Unlocks the cloak: Cape of the Screamer.

By Supaplex
20081104
]],
				},

				{
					name = L"Spirit Host (Tactic)",
					text =
[[
Spirit Host (Vilesoul) - Higher Caliber of Soul
UNDEAD TOME TACTIC UNLOCK

CHAOS WASTES @ 41, 57.5k Kill this L38 champ spirit host.

Bi Itsari & Iranium
20081008
]],
				},

				{
					name = L"Wight (Title)",
					text =
[[
Wight (Brimdall Yggdreidar) - Dead Weight
"King Slayer"

CHAOS WASTES @ 8, 2 or 6.5, 1.5. NE of Deathchill, Chaos Ch15. Kill this L1 mob.
ALTERNATE METHOD: See entry in DEATH PEAK below.

By Bastion & Phrost
20081104
]],
				},

				{
					name = L"Zombie (Tactic)",
					text =
[[
Zombie - The Family That Dies Together
UNDEAD TOME TACTIC

CHAOS WASTES: SW of the Tower of Awakening PQ, you'll reach a broken down house with named creatures inside: Tomas Spolfinkr, Croetch Spolfinkr, Papa Spolfinkr and Annabelle Spolfinkr. Killing them all gave the unlock.

By Supaplex & Thanat0s
20081029
]],
				},
			},
		},

		{
			name = L"Reikland",
			entries =
			{
				{
					name = L"Spirit Host (Tactic)",
					text = 
[[
Spirit Host - Worth the Waiting For
Undead Tactic Fragment

REIKLAND @ 12, 44. An NPC named Mabel Riess spawns at this loc. Attack her, she turns into a Spirit Host. Kill it for the unlock.

Probably only spawns at night in-game, IE 9pm-9am or so. - Mob Roams: Docks, to point shown, to 10k, 46k. Sits down at each point to whine about Alexi Gaertner standing her up, and then moves along.

By Wabbajack + Benji
]],
				},

				{
					name = L"Empire (Title)",
					text =
[[
Empire - Complete an Empire Scenario
"Man Hunter"

REIKLAND. Win a Reikland Hills Scenario. Scenario unlocks when the zone becomes contested.

By Ulgwar
20081110
]],
				},

				{
					name = L"Giant (Tactic)",
					text =
[[
Giant (Uglik) - Brutal Nose Ring
GIANT TOME TACTIC

REIKLAND @ 45, 27. Just NE of the Chaos Warcamp there is a short path leading below the bridge to Chaos Ch. 20. Take the path under the bridge and you'll see this L39 Champ. Examine the Giant Nosering for the unlock.
Alternate method in KADRIN VALLEY.

By Schwarzwald
20081110
]],
				},

				{
					name = L"Great Cat (Tactic)",
					text =
[[
Great Cat (Grinya) (Bloodmane) - Not So Great Any More
BESTIAL TOME TACTIC

REIKLAND @ 2, 18. Kill L38 Grinya W of the road on the mt.
-OR-
REIKLAND @ 59, 19. Kill L38 Bloodmane.

By logoth, JodouTR & Phrost
20081110
]],
				},

				{
					name = L"Hound (Pocket)",
					text =
[[
Hound - Dog Catcher
POCKET ITEM

REIKLAND @ 46, 37. There is a Pet Trap just S of Chaos Ch21 camp. Use it for the unlock. Gives Dog Whistle. TIP: Look a bit to the W when standing at the pet trap and you'll see a chest that you can use to get a little hidden quest.

By Supaplex
20081110
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Wolf (Tactic)",
					text =
[[
Wolf (Reik Wolf/Lynsk Wolf) - Fall Fur Fashions
BESTIAL TOME TACTIC

REIKLAND. Collect five Fine Wolf Pelts to finish the kill request from Multan the Huntsman in the (O) Ch15 town. NOTE: Reik Wolf drop rates are INCREDIBLY RARE at about .65% (1 in 150). Lynsk drops are near .11% (1 in 900).

By Socran & Kellithe
20081110
]],
				},
			},
		},

		{
			name = L"Bastion Stair",
			entries =
			{
				{
					name = L"Beastman, Gor (Acc.)",
					text =
[[
Beastman, Gor (Bloodherd Gor) - Lair of the Brute
SET ITEM

BASTION STAIR. In the first wing kill the Gor to get the Skull of a Bray-shaman. This item is used to unlock The Seeping Larva for The Divided set.

By Naukan & Risingashes
20081104
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"F.Hound of Khorne (Token)",
					text =
[[
Flesh Hound of Khorne - Hunters of Blood
BEAST TOKEN

BASTION STAIR
1. Get a Razor Sharp Fang from the Ruin (middle) wing of Bastion Stair.
2. WEST PRAAG @ 46.5, 44. Deliver to Kraglorn the Maker. NOTE: Confirmed delivery of a stack of 20 Razor Sharp Fang. 20 may not be necessary though. 1 fang does not work.

By Chewen, Nukeitall & Ryfar
20081106
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"F.Hound of Khorne (Token)",
					text =
[[
Flesh Hound of Khorne - Hunters of Blood
BEAST TOKEN

1. Get a Razor Sharp Fang from the Ruin (middle) wing of Bastion Stair.
2. Deliver 20 fangs to... (???)
UNCONFIRMED. Negative on the turn in to: Aialye Lynsellia in EATAINE.

By Chewen, Nukeitall & Ryfar
20081106
]],
				},

				{
					name = L"Tuskgor (Title)",
					text =
[[
Tuskgor (Bloodherd Tuskgor) - Not Trying To Hide
"The Tuskgor Hunter"

BASTION STAIR. Loot and inspect the drop Thick Tuskgor Hide.

By Rhuobhe
20081029
]],
				},
			},
		},

		{
			name = L"Reikwald",
			entries =
			{
				{
					name = L"Empire (Title)",
					text =
[[
Empire - Vanquish the Empire Fortress Lord
"The Hand of Chaos"

(D) REIKWALD. Be in the vicinity of a Fortress Lord kill.

By Risingashes
20081216
]],
				},


			},
		},

		{
			name = L"Altdorf",
			entries =
			{
				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Skaven (Tactic)",
					text =
[[
Skaven (Master Moulder Vitchek) - Septic Sanitation
SKAVEN TOME TACTIC

(O) ALTDORF @ 24, 27. Kill 3 L15 Skaven in a house. There is a woman outside the house who cries about 'beasties' in her house. This will spawn a L19 Hero Skaven. Kill this Skaven for the unlock. NOTE: Must achieve killing blow.
NOTE: (O) only. The same mob appears in the sewers and may also give the unlock.

By Bethryn, JodouTR & Frantic
20081027
]],
				},
			},
		},

		{
			name = L"The Maw",
			entries =
			{

			},
		},

		{
			name = L"The Inevitable City",
			entries =
			{

			},
		},

},		
}
