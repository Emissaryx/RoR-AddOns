TTitan.Data.Lairs = {}

function TTitan.Data.Lairs.GetData()
	return TTitan.Data.Lairs.RawData
end

function TTitan.Data.Lairs.FilterData()
	TTitan.Data.FilterByRealm(TTitan.Data.Lairs.RawData)
end

TTitan.Data.Lairs.RawData =
{
	header = L"Lair Locations",
	categories =
	{
		{
			name = L"About This Page",
			entries =
			{
				{
					name = L"Credit",
					text =
[[
The information found here is directly from the Warhammer Alliance Forums "The Lair Thread". You can find it here:
http://www.warhammeralliance.com/forums/showthread.php?t=132580

The thread is maintained by Maglight of the guild Curbstomp on the Volkmar server.
]],
				},

				{
					name = L"Format",
					text =
[[
I've followed the same layout/format that thread follows MOSTLY.
- Lair Heroes that are under Level 40
- Lair Heroes that are Level 40
- Lairs that require special ways to gain acess.

Under each of those categories though I have the lairs listed by Alphabetical by Zone, instead of Alphabetical by Lair Name
Suggestions for format improvement are always welcome!
~Oscarr
]],
				},
			},
		},

		{	-- Divider, won't expand when clicked
			name = L"---------",
			divider = true,
			entries = {},
		},

		{
			name = L"Pre-Lvl 40 Heroes",
			entries =
			{
				{
					name = L"Badlands (31)",
					text =
[[
Lair of Krela Darkshroud (31)
Badlands 23k, 62k
Thanks Kerian
]],
				},

				{
					name = L"Black Fire Pass (31)",
					text =
[[
Lair of the Shambler (31)
Black Fire Pass 5k, 24k
Thanks Freezooi
					]],
				},

				{
					name = L"Blighted Isle (11)",
					text =
[[
Lair of Lady Alisha (11)
RVR: Blighted Isle 35k, 51k - Three runes must be activated north of the lair.
]],
				},

				{
					name = L"Ekrund (11)",
					text =
[[
Lair of the Bandit Queen (11)
RVR: Ekrund 58k, 3k - Kill a player with the dark energy buff.
]],
				},

				{
					name = L"Norsca (11)",
					text =
[[
Traitor's Rest (11)
RVR: Norsca 26k, 62k - Each race must stand on a specific pedestal.
]],
				},
			},
		},

		{
			name = L"Level 40 Heroes",
			entries =
			{
				{
					name = L"Avelorn",
					text =
[[
Lair of Elrin Helfried
Avelorn 5.8k, 46k
]],
				},

				{
					name = L"Barak Varr",
					text =
[[
Lair of the Reaver
Barak Varr 2k, 20k
]],
				},

				{
					name = L"Black Fire Pass",
					text =
[[
Lair of Ravack
Black Fire Pass 62k, 8k
]],
				},

				{
					name = L"Blighted Isle",
					text =
[[
Lair of Gorthlak
Blighted Isle 36k, 18k
]],
				},

				{
					name = L"Caledor",
					text =
[[
Lair of Fesitt
Caledor 34k, 36k
Thanks Odawnus
]],
				},

				{
					name = L"Chaos Wastes",
					text =
[[
Lair of Tezakk Gnawbone
Chaos Wastes 36k, 6k
	]],
				},

				{
					name = L"Chrace",
					text =
[[
Lair of Kelbrax
Chrace 19k, 63k Thanks Final
]],
				},

				{
					name = L"Ellyrion",
					text =
[[
Lair of Stinkfang
Ellyrion 5.5k, 42k
]],
				},

				{
					name = L"Kadrin Valley",
					text =
[[
Lair of the Fleshrender
Kadrin Valley 3k, 32k
Thanks Sorcerer
]],
				},

				{
					name = L"Marshes of Madness",
					text =
[[
Lair of Old Oozeback
Marshes of Madness 25k, 60k
]],
				},

				{
					name = L"Mount Bloodhorn",
					text =
[[
Lair of Gutslime
Mount Bloodhorn 53k, 45k
]],
				},

				{
					name = L"Nordland",
					text =
[[
Lair of Morra
Nordland 32k, 60k
]],
				},

				{
					name = L"Norsca",
					text =
[[
Lair of Silveroak
Norsca 20k, 25k
]],
				},

				{
					name = L"The Maw",
					text =
[[
Migliod's Menagerie
The Maw 40k, 54k
Thanks Kerian
]],
				},

				{
					name = L"Troll Country",
					text =
[[
Lair of Metoh
Troll Country 9k, 4k
]],
				},

				{
					name = L"West Praag",
					text =
[[
Frostshard Prison
West Praag 23k, 44k
]],
				},
			},
		},

		{
			name = L"Special Access Lairs",
			entries =
			{
				{
					name = L"Caledor",
					text =
[[
Xaphan the Pyre Lair
Caledor 54k, 27k
(requires clicking on six candles around the world) - Thanks Nuzaak

    Candle Locations: - Thanks Torach

       1. Nordland 39k, 46k
       2. Marshes of Madness 13k, 47k
       3. Avelorn 24k, 13k
       4. Reikland 38k, 11k
       5. Black Crag 40k, 15k
       6. Praag 20k, 18k
]],
				},

				{
					name = L"Dragonwake",
					text =
[[
Lair of Gholnaros the Deathless
Dragonwake 23k, 42k

   To open this lair you must find all three dragoneyes. Each one is found in a random location in the tier 4 High Elf/Dark Elf RvR Lakes.

       1. Red - Caledor
       2. Blue - Dragonwake
       3. Pink - Eataine
]],
				},

				{
					name = L"Ostland (Incomplete)",
					text =
[[
Lair of the Defiler
Ostland 7k, 62k (I don't know how to open this lair)

    Seven Lords with Seven Sons
    Faith corrupted, life undone.
    For young pilgrims, four to come.

    Thanks Karmann for the grave theory:

    The grave of Kazagund Alnirson - Kadrin Valley - 12k, 31k Thanks Treeko
    The grave of Bomit Bumbleshoot - Reikland - 2k, 6k Thanks Apacolypse
    The grave of Skordin Kazagundson - Badlands - 58k, 54k
    The grave of Bilton Bumbleshoot - Talabecland - 18k, 28k
    The grave of Ronal Grumman - Ostland 60k, 60k
    The grave of Hanse Grumman - Chaos Wastes 62k, 15k
    The grave of Mororthel Hawkwood - The Blighted Isle 39.5k, 34.5k
    The grave of Galdulrel Hawkwood - Dragonwake 31k, 37k
    The grave of Barnabas Hirtzel - Praag 25k, 58k
    The grave of Konrad Hirtzel - Altdorf Sewers - South wing
    The grave of Faustus Kummel - Nordland 61k, 20k
    The grave of Fabian Kummel - Inevitable City Sacellum Dungeon - South wing
    The grave of Xavier Nuhr - Talabecland 24k, 27k
    The grave of Nicodemus Nuhr - Reikland 36k,11k

There is an ongoing discussion about how to unlock this lair at:
http://www.warhammeralliance.com/forums/showthread.php?t=105762
]],
				},
			},
		},
	},
}
