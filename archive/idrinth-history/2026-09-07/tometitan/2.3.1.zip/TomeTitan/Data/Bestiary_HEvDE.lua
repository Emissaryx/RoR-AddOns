TTitan.Data.BestiaryHEvDE = {}

function TTitan.Data.BestiaryHEvDE.GetData()
	return TTitan.Data.BestiaryHEvDE.RawData
end

function TTitan.Data.BestiaryHEvDE.FilterData()
	TTitan.Data.FilterByRealm(TTitan.Data.BestiaryHEvDE.RawData)
end

TTitan.Data.BestiaryHEvDE.RawData =
{
	header = L"Beastiary Unlocks - High Elves vs Dark Elves",
	categories =
	{
		{
			name = L"Hidden Scrolls (RVR LAKES)",
			entries =
			{
				{
					name = L"[Blighted Isle]Witch Elf (Pocket)",
					text =
[[
Dark Elves, Witch Elves - What do We Have Here ?
POCKET ITEM

THE BLIGHTED ISLE @ 26.5, 62. Click on the Hidden Scroll located in front of the N tower by the W BO, in the rubble. Unlocks: Witch Armor.

(NOTE: This will not mark as complete, as it currently marks as complete while incomplete if notated correctly.)

By rouko
20081217
]],
				},

				{
					name = L"[Chrace]White Lion (Pocket)",
					text =
[[
High Elf, White Lion - What do We Have Here ?
POCKET ITEM

CHRACE @ 27.9, 11.2. To the W of the Shard of Grief RvR objective is a Hidden Scroll on the ground. It can be found between some rocks at the W ruined doorway of the Shard of Grief. Unlocks: Captured Lion Essence.

(NOTE: This will not mark as complete, as it currently marks as complete while incomplete if notated correctly.)

By wahooka, Dagaric & Sidac
20081217
]],
				},

				{
					name = L"[Shadowlands]Shadow Warrior (Pocket)",
					text =
[[
High Elf, Shadow Warrior - What do We Have Here ?
POCKET ITEM

SHADOWLANDS @ 35.5, 54.5. Click on the 'Hidden Scroll' located in the middle of a some trees. Unlocks: Broken Bowstring.

(NOTE: This will not mark as complete, as it currently marks as complete while incomplete if notated correctly.)

By rouko
20081217
]],
				},

				{
					name = L"[Ellyrion]Disciple of Khaine (Pocket)",
					text =
[[
DARKELF, DISCIPLE OF KHAINE - What do We Have Here ?
POCKET ITEM

ELLYRION@ 36,32. Click on the 'Hidden Scroll' -- Near the waterfall, between the stones.

(NOTE: This will not mark as complete, as it currently marks as complete while incomplete if notated correctly.)

By Fadira
]],
				},

				{
					name = L"[Saphery]Archmage (Pocket)",
					text =
[[
High Elf, Archmage - What do We Have Here ?
POCKET ITEM

SAPHERY @ 15.6k, 10.4k. Click on the Hidden Scroll located behind a rock just to the W of the Well of Qhaysh, very near the (D) side road, barely inside the lake, in fact. Unlocks: Ruined Book.

(NOTE: This will not mark as complete, as it currently marks as complete while incomplete if notated correctly.)

By Dagaric, Sidac & LeviathanXIII
20081217
]],
				},


				{
					name = L"[Saphery]Swordmaster (Pocket)",
					text =
[[
Empire, Swordmaster - What do We Have Here ?
POCKET ITEM

SAPHERY @ 40, 6.2. Click on the Hidden Scroll located inside the fountain. Unlocks: Broken Sword.

(NOTE: This will not mark as complete, as it currently marks as complete while incomplete if notated correctly.)

By greggus
20081217
]],
				},

				{
					name = L"[Caledor]High Elf (Title)",
					text =
[[
High Elf - The History of the High Elves
"Isha's Lament"

CALEDOR @ 38,30 . Click on the Hidden Scroll located next to backbone of the dragon skeleton.

By Scilla
20081217
]],
				},

				{
					name = L"[Dragonwake]Sorcerer (Pocket)",
					text =
[[
Dark Elf, Sorcerer - What do We Have Here ?
POCKET ITEM

DRAGONWAKE @ 21.4, 32.5. Click on the 'Hidden Scroll' S of the Mournfire's Approach BO, within some rocks. Unlocks: Foul Scroll.

(NOTE: This will not mark as complete, as it currently marks as complete while incomplete if notated correctly.)

By Risingashes
20081216
]],
				},

				{
					name = L"[Eataine]Dark Elf (Title)",
					text =
[[
Dark Elf - The History of the Dark Elves
"Lion Guard"

EATAINE @ 30, 36. Click on the 'Hidden Scroll' located near a building, next to 3 barrels.

By rouko
20081216
]],
				},
			},
		},

		{
			name = L"The Blighted Isle",
			entries =
			{
				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Bandit (Title)",
					text =
[[
Bandit (Uthorin Sorceress) - Talk of the Town
"The Bounty Hunter"

BLIGHTED ISLE @ 13, 8. In the DE prologue area there are multiple Uthorin Sorceress mobs surrounded by groups of neutral sprites. Simply talk to any of them.

**As of the 12/16 patch, this unlock is broken**

By Shadeviper & Road
20081104
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Bird (Title)",
					text =
[[
Bird, Warhawk (Crag Great Wing) - I Just Washed This Cloak
"The Grounded"

BLIGHTED ISLE @ 7, 37 or 8, 47. Kill the warhawk by Volruc Kinslayer to collect Warhawk Feathers. WARNING: This entry is specifically buggy. Confirmed unlocks by killing the bird ONLY.

By khelben, Demonspawn, FireOpal, Sereca, raicarter, Yvarma, ThePedant & h0tr0d
20081027
]],
				},

				{
					name = L"Giant Lizard (Title)",
					text =
[[
Giant Lizard - A Matter of Scales
"The Lizard Hunter"

BLIGHTED ISLE @ Fire Crystal Caverns. Loot Scaly Skin drop off of a Fire Tail (it took me over 130 kills).
BLIGHTED ISLE. Ch2 High Elves @ the lizard cave near the forest burning PQ. Enter cave for title. EDIT: You have to keep killing giant lizards until they drop a specific item. NOTE: This site is more (O) friendly.

By Kovacs, Puddles404, FireOpal, Dormammu & JodouTR
20081029
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Horror (Pocket)",
					text =
[[
Horror (Lost Horror) - Where Did You All Go?
POCKET ITEM

BLIGHTED ISLES climb the mt @ 24, 43. Jump on the rocks near the DE PQ "Golden Tor" to get onto the mt cliffs. Then run along the top and you should see the Pink Horror after about 10-15 seconds. Kill it.

By Puddles404, burfo, Doyle, Nozaro, Pinith & Mimer
20081119
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Horror (Pocket)",
					text =
[[
Horror (Lost Horror) - Where Did You All Go?
POCKET ITEM

BLIGHTED ISLES @ 20.5, 38. In the hills W of Lacorith, there is a lone L4 champ Pink Horror. Kill him.

By Puddles404, burfo, Doyle, Nozaro, Pinith & Mimer
20081119
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Scorpion, Giant (Tactic)",
					text =
[[
Scorpion, Giant - A Pinch to Grow an Inch
BESTIAL TOME TACTIC

BLIGHTED ISLE. Unlocked this in the quest camp near the first PQ near the starting DE area. It was from one of the quest givers in that camp. EDIT: The quest is called Lucrative Intrigue, turn in NPC is Tiritha Venomfire. 2nd EDIT: This quest requires you complete both quests given by Nehmora the Hag before you can get the "Lucrative Intrigue" quest. Kill the scorpions just outside of Sternbrow's Lament.

By Rhianni, Arienh, Squarkk & Sereca
20081124
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Scorpion, Giant (Tactic)",
					text =
[[
Scorpion, Giant - A Pinch to Grow an Inch
BESTIAL TOME TACTIC

BLIGHTED ISLE @ 49, 36. Kill Blighted Scorpions for the Kill Collector Caethsetir Silverstrand @ 44, 26. 60 kills are required.

By Spasmbot, Akiu & WarWoman
20081124
]],
				},

				{
					name = L"Scorpion, Giant (Title)",
					text =
[[
Scorpion, Giant (Bane Claw) - Beach Bum
"The Scorpion Squisher"

BLIGHTED ISLE @ 3, 63. Far SW before you leave the zone for Chrace. There's a champ on the sandbox shores. Kill him.

By NicWester, reggie, thezenny & Jarathorn
20081021
]],
				},

				{
					name = L"Snotling (Title)",
					text =
[[
Snotling - And I Just Cleaned My Boots
"The Peculiar"

BLIGHTED ISLE @ 48.5, 48. A snotling sleeps by a rock. Target the boulder above him and push it onto him for the unlock. The rock is buggy, I literally had to jump on top of it before I was able to activate it. NOTE: Snotling area is NOT in the RvR area.

By Amagorr, OdaNova & Meloc
20081020
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Spite (Title)",
					text =
[[
Spite - Looking for Shinnies
"The Spite Splitter"

BLIGHTED ISLE. Near the ruins of Erraneth, there is a waystone with 'anomalies' around it, and Dark Spites. This has been the best place I've found to kill them for the item: Shining Ring. Don't know what you are meant to do with the ring, haven't found anyone interested in it yet.

By Puddle404
20081021
]],
				},

				{
					name = L"Wolf (Title)",
					text =
[[
Wolf - View With a Howl
"The Howler"

BLIGHTED ISLE @ 5, 49. NW of Dreamshade. While hunting wolf matrons, approach the edge of the cliff to hear "wolves howling down below". This unlocked after killing him. NOTE: Between the PQ's 'Dreamshade' & 'The Watchtower', walk along the cliffside until you get a message "Looking out over the cliffs to the dark waters below, you hear the echo of the wolfs calL"and you will get the unlock.

By Ater, NicWester, thezenny & angral
20081028
]],
				},
			},
		},

		{
			name = L"Chrace",
			entries =
			{
				{
					name = L"Dryad (Title)",
					text =
[[
Dryad - Grove and Grave
"Forester"

CHRACE @ 8, 34k or 6, 47k or 7.3k, 49.8k .. Run to the SW as if going to Shadowlands on foot. Once you're there the sky should change sort of and you should be surrounded by Spites and Bats and other weaksauce punks. Just keep running N until you get the unlock.

By NicWester, Nogglli, Rakaija & Meep
20081007
]],
				},

				{
					name = L"Harpy (Tactic)",
					text =
[[
Harpy - Get Down Here!
CHAOS TOME TACTIC

CHRACE @ 44.7, 22.5. Between Yenlui and Blackwood Hill Garrison there is a ruined tower with swarming Harpies. Keep killing the Harpies to get the unlock. NOTE: From the name of the unlock, one may have to kill the airborne harpies, not the ones on the ground.

By Puddles404, notalltogether, Shadeviper & TBBle
20081020
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Human (Pocket)",
					text =
[[
Human, Bandit (Fay Val) - Treaty for Treasure
POCKET ITEM

CHRACE @ 48, 8. The 3 NPCs are up a ramp from the water right under the bridge connecting to the RvR area, W of Yenlui. The other mobs are L10 Amalyn Weber with her dog L20 Canine. Unlocks: Semi-lucky Charm. NOTE: Confirmed unlock by killing Weber.

By gaberiel07, Thanat0s, , Kjermzs, Puddles404, ThePedant, Feclump, ultraczar, Sildroni & ThePedant
20081027
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Spider, Giant (Tactic)",
					text =
[[
Spider, Giant (Warpweb Spiders) - Fast Finds
BESTIAL TOME TACTIC

CHRACE @ 49, 21.7k Max out the Kill Collector Elthossar YoungStarat found by the Cliffs of Ushuru @ 53, 32. 60 kills is generally enough for KC's.

By FireOpal, Meep & TBBle
20081021
]],
				},
			},
		},

		{
			name = L"The Shadowlands",
			entries =
			{
				{
					name = L"Bear (Title)",
					text =
[[
Bear (Darkclaw Bear/Mauler) - At Least They'll Stay Cool
"Pioneer"

SHADOWLANDS 55, 25 or NE of Elbisar. Kill for 5 Bear Pelts, then inspect them.

By Arcton, Dormammu, Blodsalv, CastleBravo & Kadregon
20081029
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Bird (Title)",
					text =
[[
Bird, Warhawk (Warhawk Mauler) - I Just Washed This Cloak
"The Grounded"

SHADOWLANDS @ 20, 23 or 19, 26 or 11.5, 22.5 or 24, 22. Kill the mob for Warhawk Feathers. Get five for the unlock. Drops are not 100%.
WARNING: This entry is specifically buggy. There is a mob (D) players can kill in Blighted Isle, but that entry is buggy also. You may need to try several different things. Try clicking on the feathers after getting 5. Try visiting and kill the warhawk in the Blighted Isle. Also try deleting your feathers and recollecting them.
NOTE: Confirmed that killing the Bird with no feathers also gave the unlock.
FURTHER: Confirmed unlock by killing Skyherald Warhawk @ 24,22 (both once and multiple times).

By Wolfed, notalltogether, Ulgwar, Yvarma, Torgan & Ryfar
20081103
]],
				},

				{
					name = L"Cockatrice (???)",
					text =
[[
Cockatrice (Petrified Corpse) - If Looks Have Killed

SHADOWLANDS @ 58, 29. NE of Elbisar examine the corpse.

By khelben
20081027
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Cold One (Title)",
					text =
[[
Cold One - A Balancing of Scales
"The Scale Breaker"

SHADOWLANDS. Talk to Taelq Ragecrown.
This healer is in the DE camp in Ruins of Anlec (the first camp when entering from Chrace).

By Shiwoen & Nozaro
20081124
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Cold One (Title)",
					text =
[[
Cold One - A Balancing of Scales
"The Scale Breaker"

SHADOWLANDS. Max out the Cold One Kill Collector for the unlock.

By Shiwoen & Nozaro
20081124
]],
				},

				{
					name = L"Harpy (Title)",
					text =
[[
Harpy - House on the Hill
"The Bold"

SHADOWLANDS @ 53, 45. Climb up and use the harpy roost on top of a slab of rock on the side of the road. Best access is running to the E side of the slab and jumping up, I couldn't get onto the slab from the road.

By khelben, Blodsalv, Nymph of Tor & Puddles404
20081020
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Imp (Title)",
					text =
[[
Imp (Bradas Coldtouch) - What Makes You Sparkle?
"The Imp Squisher"

SHADOWLANDS @ 35.5, 10. Talk to this merchant.

By NicWester, notalltogether, shadracht, Elli0t & Lessing
20081124
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Imp (Title)",
					text =
[[
Imp (Bradas Coldtouch) - What Makes You Sparkle?
"The Imp Squisher"

SHADOWLANDS. Directly SW of Ruins of Anlec (DE Ch5) there are a few sprites with a random Dark Elf sorceress. Kill these to loot Sparkling Sprite Remains and right click them to get the unlock. NOTE: Drops chances are about .31% and mobs respawn slowly--so get ready to bust out that Thank-You card for Mythic.

By NicWester, notalltogether, shadracht, Elli0t & Lessing
20081124
]],
				},

				{
					name = L"Scorpion (Tactic)",
					text =
[[
Scorpion, Giant (Poisontail Stinger) - Deadly When Dead
BESTIAL TOME TACTIC

SHADOWLANDS @ 5.6, 45 or 2, 41.5. Kill the scorpions in the area along the coast for the loot. The drop may take a while, but it has been confirmed to drop off both normal and champ mobs.

By Mabuz, NicWester, Icebird, Emrus, Crucifix & Sildroni
20081027
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Tree Kin (Title)",
					text =
[[
Tree Kin - Rings of History
"The Lumberjack"

SHADOWLANDS @ 9, 60 or 12, 58.5. On the cliff overlooking the final DE Ch7 PQ "The Griffon Gate" select Rootwalker Remains for the unlock.

By Malfious
20081027
]],
				},

				{
					name = L"Unicorn (Title)",
					text =
[[
Unicorn (Sylendoras) - A Little Off the Top
"The Hornsnapper"

SHADOWLANDS @ 16, 44. Kill this L15 champ who hides among the other unicorns. Inspect a piece of a Unicorn's Horn.

By Blodsalv, Crucifix, Thanat0s, Ulgwar & meth8609
20081103
]],
				},
			},
		},

		{
			name = L"Ellyrion",
			entries =
			{
				{
					name = L"Great Cat (Tactic)",
					text =
[[
Great Cat (Shadowscream) - Silencing Shadows
BESTIAL TOME TACTIC UNLOCK

ELLYRION @ 61k, 57.5k. Kill the named champ panther for the unlock. NOTE: The original coords posted (60k, 40k) lead to a hero mob named Bloodpaw. Bloodpaw drops an item that gives a quest. However, even tho' the quest is acceptable by Destro', the person you need to talk to is Order.

By expansionsss, notalltogether, Elmarra & Bastion
20081007
]],
				},

				{
					name = L"F. of Slaanesh (Title)",
					text =
[[
Fiend of Slaanesh (Book of Innocence) - Things Best Left Unknown
"The Impure"

ELLYRION @ 35k ,48k. On the HE side of the mt near the double gates in the middle of the map is a book called "The Book of Innocence." A non aggro mob called Kelthera Darklust sits beside it. Click on the book and the mob turns into the lvl 20 Fiend of Slaanesh and attacks you. NOTE: Receiving the unlocks without killing the mob has been confirmed.

By Nozaro, Ulgwar, CastleBravo & Colloquial
20081007
]],
				},

				{
					name = L"Great Eagle (Title)",
					text =
[[
Great Eagle (Ellyrian Eagle) - Birds of a Feather
"The Vigilant"

ELLYRION @ 27, 44. Kill the Ellyrian Eagles until the Great Eagle Feather drops and examine it. The eagles are found in the middle Ellryion to the N of the two gates with Dark Elves inside. They're in the mt ranges in the vicinity of three large nests.
NOTE: (For Order players) unlock seems bugged. Confirmed unlock, but the entry does not log into the ToK.

By Shaia, scootle, Tayshrenn & ThePedant
20081027
]],
				},
			},
		},

		{
			name = L"Avelorn",
			entries =
			{
				{
					name = L"Beastman (Cloak)",
					text =
[[
Beastman, Bestigor (Khurraak Might-Horns) - Bossy Beastie
CLOAK ITEM UNLOCK

AVELORN. Spawns on the road, on the S side of the (O) camp. He is with another non-named bestigor and attacks @ the Ch12 town. Kill him and you will get the unlock and the ability to buy the Pelt of the Dark Young cloak.

By Abriel, Kellithe & notalltogether
20081007
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Bone Giant (Title)",
					text =
[[
Bone Giant (Brulgulrach the Unliving) - Parts of Parts
"The Bone Breaker"

AVELORN @ 58.5, 62 or 47, 45. He is friendly and talking to him completes the unlock. 

By Kellithe, notalltogether, Tyrlian & halsfield
20081124
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Bone Giant (Title)",
					text =
[[
Bone Giant (Brulgulrach the Unliving) - Parts of Parts
"The Bone Breaker"

AVELORN @ 58.5, 62 or 47, 45. Kill this L25 skeleton champ. NOTE: May require a trigger to populate, have a placeholder, or be on a long timer. TIP: The ToK places the mob in the Bone Giant category, but it looks like a normal sized skeleton.

By Kellithe, notalltogether, Tyrlian & halsfield
20081124
]],
				},

				{
					name = L"Dryad (Tactic)",
					text =
[[
Dryad (Oldbark) - Chip Off the Old...
MYTHICAL TOME TACTIC

AVELORN @ 31, 39 or 40, 40.: Kill it.

By Supaplex, notalltogether & OGGleep
20081029
]],
				},

				{
					name = L"H. of Tzeentch (Tactic)",
					text =
[[
Horror of Tzeentch (Golmir) - Pack of Three
DAEMONIC TOME TACTIC UNLOCK

AVELORN @ 62, 14k. He's in a slight depression in the far E wall of the mt and is a l23 champ, also two non-champ L23 spiders come along for the fun.

By Kellithe & JodouTR
20081013
]],
				},

				{
					name = L"Liche (Title)",
					text =
[[
Liche (Tarnolious the Lost) - Final Rest... Again
"Champion of Morr"

AVELORN @ 33, 49. Kill this L1 Hero SE of the Tower of Aethwyn PQ on a cliff at the river.

By Blodsalv & Ulgwar
20081124
]],
				},

				{
					name = L"Nurgling (Pocket)",
					text =
[[
Nurgling (Filthmiser) - More Filth for Me!
POCKET ITEM

AVELORN @ 37, 16. A L21 champ gives the unlock. Killing this mob yields the item: Regurgitated Trinket

By Thovargh, beetfield, notalltogether & Flea
20081029
]],
				},

				{
					name = L"Treeman (Title)",
					text =
[[
Treeman (Dregenis) - Who Bears the Worldbearer?
"The Vale Walker"

AVELORN @ 44, 44.5. Approach Dregenis. Talk to him.

By Blodsalv, Muninn & Nozaro
20081021
]],
				},

				{
					name = L"Troll (Bestial Token)",
					text =
[[
Troll, Chaos (Goremaw) - Dispense Justice
BEAST TOKEN

AVELORN @ 19, 49. Kill a L25 Chaos Troll Champ. He's just a little ways N of the DE camp in the zone. EDIT Mob has also been confirmed to pop E of the DE camp, between it and the PQ The Watchtower, amongst the trolls there.

By Draekon, Pinafore, notalltogether & TorqueVolkmar
20081029
]],
				},

				{
					name = L"Zombie (Pocket)",
					text =
[[
Zombie (Rupert) - Loop Back
POCKET ITEM

AVELORN @ 40, 40. Kill this named zombie to unlock Moldy Coin Purse.

By Kellithe & Amagorr
20081029
]],
				},
			},
		},

		{
			name = L"Saphery",
			entries =
			{
				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Chaos Hound (Acc)",
					text =
[[
Chaos Hound - From Mouth to Neck
JEWELRY ITEM

SAPHERY. Talk to Beastmaster Mezellian @ 31.5, 15 to get the Amulet. Then kill Twisted Hounds and return to Beastmaster Mezellian.

By Sandkat
20081023
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Chaos Hound (Acc)",
					text =
[[
Chaos Hound - From Mouth to Neck
JEWELRY ITEM

SAPHERY @ 59.5, 20.5. First speak to Golgrund Stonefist @ the Ch13 camp to get Amulet of Fangs. Then kill Chaos Hounds near 49.5, 13 until you have 10 Chaos Hound Fangs. Speak to Golgrund again for: Black Toof.

By Risingashes, Ulgwar & TorqueVolkmar
20081023
]],
				},

				{
					name = L"Cockatrice (Cloak)",
					text =
[[
Cockatrice (Petrified Corpse) (Slashbeak)- A Charmed Life
CLOAK ITEM

SAPHERY @ 59, 27.5. Head E and cross the road from the Ithilmar Tower PQ. You should see a small camp of cockatrice type mobs and toward the wall there will be a corpse that's clickable. Click it to receive an item and then kill the L27 champ to receive the unlock for: Plumes of the Eye Killer.

By Gabriel Stern, hamsterz, Buzzbomb & benji
20081021
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Cold One (Token)",
					text =
[[
Cold One (Coldlash) - Big Freeze
BEAST TOKEN

SAPHERY @ 9, 35. Talk to Maedlaine Bloodwine.. Don't have to kill anything.

By Nozaro
20081124
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Cold One (Token)",
					text =
[[
Cold One (Coldlash) - Big Freeze
BEAST TOKEN

SAPHERY @ 54, 10. Kill this L27 named champ.

O by Risingashes & dremmor
20081124
]],
				},

				{
					name = L"Manticore (???)",
					text =
[[
Manticore (Unmounted Manticore) - Won't Ask Where it Kept That

SAPHERY @ 53.5, 20. Mob drops A Partially-digested Manual. Use it for unlock. NOTE: Killing the Manticore mobs at the lake near 53.5, 15.5 DO NOT drop the Manual.

By Dissent, cintra & Foggye
20081103
]],
				},

				{
					name = L"Pegasus (???)",
					text =
[[
Pegasus - Do You Know the Way
"???"

SAPHERY @ 14, 1 There is an "Ancient Rider's Horn" hanging from a tree that unlocks this. BUG: The title it gives seems to be bugged and doesn't show up.

By Dissent, Expance & skyrunner620
2008110
]],
				},

				{
					name = L"Squig (Pocket)",
					text =
[[
Squig - Take a Break
POCKET ITEM UNLOCK

SAPHERY @ 58k, 61k. In the dungeon where you take 2 mushroom and a Shard, in the furthest S part of dungeon there is a mushroom on the ground. It has the same graphic as your quest mushroom so don't mix it up. NOTE: It is in the furthest W part of the dungeon before you head S, there is a split where you either go up or go down; it is down just after the split. The tooltip says "Fleshy Mushroom".

By Xururuca & Wilken
20081007
]],
				},
			},
		},

		{
			name = L"Dragonwake",
			entries =
			{
				{
					name = L"Beastmen (Title)",
					text =
[[
Beastmen, Doombull - Grab the Bull By the Horn
"Cairn Breaker"

DRAGONWAKE @ 65, 30. Near the border to Eataine there's a small waterfall about 20 yards from 3 rocks, on big one and 2 small ones on the one side. Next to the small rocks are a pile of bones. Looting it to spawn a L34 Doombull. NOTE: Must kill the bull quickly. The unlock relies on a timer--take too long and he despawns.

By Tyrlian, poll12 & Draegnar
20081027
]],
				},

				{
					name = L"D. of Slaanesh (Acc)",
					text =
[[
Daemonette of Slaanesh - Sacrifice Over Excess
JEWELRY ITEM

DRAGONWAKE @ 15, 9. Find a book to the W of the road along the mtside, near a group of trees. Click it and a daemonette will spawn. After I clicked the book 10 times and killed her 10 times she dropped an Icy Heart. Take the item to the Altar of Broken Flesh in CHAOS WASTES @ 54, 16.5. Unlocks Moon Fang.
NOTE: Summoning horse on top of her book seems to trigger her arrival.

By Ravnir, Nukeitall, Zoe9906, Crucifix & sakkath
20081027
]],
				},

				{
					name = L"Savage Charger (Acc)",
					text =
[[
Savage Charger - Pork Chop
SET ITEM

DRAGONWAKE @ 60, 18. N of the HE Ch16 camp kill this neutral mob which gives the unlock "Pork Chop" via the item Lean Boar Meat. Unlocks jewelry item The Deep Oaths which is part of a 2-set called "The Broken Covenant". NOTE: Drop rate is low, confirmed past 14 kills.
NOTE: See entry for Boar in CALEDOR for alternate approach.

By wrajjt & lasmrah
20081021
]],
				},
			},
		},

		{
			name = L"Isle of the Dead",
			entries =
			{
				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Chaos Fury (Token)",
					text =
[[
Chaos Fury (Ylger'oz the Demented) - On Wings, but Not Quite Angels
BEASTIAL TOKEN

ISLE OF THE DEAD @ 36, 5. Kill this L35 champ that spawns @ 36, 5 and can pat all the way down to 48, 55. He is on a 5 min respawn. The item you are looking for is called Concentrated Evil. Kill him until it drops and go sell it to a merchant for the unlock.

By Sandkat & JodouTR
20081021
]],
				},

				{
					name = L"Construct (Title)",
					text =
[[
Construct (Living Armor) - Anyone Have a Can Opener?
"The Armor-Breaker"

ISLE OF THE DEAD. Kill this L36mob @ the Ritual of Metal till you get the unlock. NOTE: Some people have done it in 10 kills, others 36. Keep trying.

By Supaplex, Sandkat, Iranium & Societal
20081028
]],
				},
			},
		},

		{
			name = L"Caledor",
			entries =
			{
{
					name = L"Dark Elf (Title)",
					text =
[[
Dark Elf - Complete a Dark Elf Scenario
"Ulthuan's Avenger"

CALEDOR. Win a Caledor Woods Scenario. Scenario unlocks when the zone becomes contested.
]],
				},

				{
					name = L"Boar (Acc)",
					text =
[[
Boar (Wyrmstone Charger) - Pork Chop
SET ITEM

CALEDOR. Kill Wyrmstone Chargers outside the DE camp in the SW, and loot the item Lean Boar Meat. Inspect this to get the unlock for the set item:The Deep Oaths.
NOTE: See entry for Savage Charger in DRAGONWAKE for alternate approach.

By Blodsalv, Sandkat, Thanat0s & Zerk
20081021
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Scoprion (Acc)",
					text =
[[
Giant Scorpion (Crushclaw) (Firestrike) - Stick the Sticker
SET ITEM

CALEDOR @ 44, 5. Kill Firestrike to get Giant Scorpion Stinger. Then go to (O) side of Caledor @ 50, 45 (via Dragonwake @ 15, 45 and jump to ally side zone. Then go to Dragonwake 2, 60 to take the little secret stage) and kill the champ scorpion mob you find there.

By Sandkat, JodouTR, Boldag, Kellithe, TorqueVolkmar & prx
20081027
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Scoprion (Acc)",
					text =
[[
Giant Scorpion (Crushclaw) (Firestrike) - Stick the Sticker
SET ITEM

CALEDOR @ 51, 46. Brightmoon Forest N of (O) ch21. First kill Crushclaw to get: Giant Scorpion Stinger. Then go to 44, 6 and kill Firestrike. The scorpion stinger will disappear and you will get the The Obdurate Seal.
NOTE: If this doesn't work, try reversing the process. Kill Firestrike first, then Crushclaw.

By Sandkat, JodouTR, Boldag, Kellithe, TorqueVolkmar & prx
20081027
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Hydra (Title)",
					text =
[[
Hydra (Deathclaw) - Who Let That Thing Out?
"Hydra Tamer"

DIRECTIONS: Mob patrols with 2 DE guards that are neutral to (D). Start in Dragonwake warcamp and go W to enter Caledor through a small pass in the SW area of Dragonwake. Then, go W following the road until you come to a tunnel. Go through the tunnel and head down the hill/road until you come to the (O) camp. Hug the outside wall of the (O) Ch22 camp and go to the back and jump down to the road. Now mount up and head N to 10k, 37k. If the hydra isn't there, just wait. It will be.

By Mippo & Sandkat
20081009
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Hydra (Title)",
					text =
[[
Hydra (Deathclaw) - Who Let That Thing Out?
"Hydra Tamer"

CALEDOR @ 10k, 37k. Lvl 40 Champ. Kill it.

By Mippo & Sandkat
20081009
]],
				},

				{
					name = L"Liche (Token)",
					text =
[[
Liche (Mound of Dirt/Scepter of Maggots) - For the Promise of Power
BEAST TOKEN

CALEDOR @ 32, 22. E of the (D) Warcamp against a hill between two waterfalls is a Mound of Dirt. Click on it to get the Scepter of Maggots, then click on the scepter in your inventory. Finally, click the mound again for the unlock. NOTE: For (O) you'll need to come from the RvR lake, hug the hill to avoid the hero packs and drop down.

By Foggye
20081103
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Manticore (Token)",
					text =
[[
Manticore (Martikhoras) - Don't Look Up
BEASTIAL TOKEN UNLOCK

CALEDOR. Kill this Lvl40 Champ and it's flying so DO look up!
DIRECTIONS: See above entry for Hydra (Deathclaw). The Manticore is flying, but occasionally he will land on the side of the mt and you can then pull him.

By Mippo & Itsari & Sandkat
20081009
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Manticore (Token)",
					text =
[[
Manticore (Martikhoras) - Don't Look Up
BEASTIAL TOKEN UNLOCK

CALEDOR @ 17k, 37k. Kill this Lvl40 Champ and it's flying so DO look up!

By Mippo & Itsari & Sandkat
20081009
]],
				},
			},
		},

		{
			name = L"Eataine",
			entries =
			{
				{
					name = L"High Elf (Title)",
					text =
[[
High Elf - Complete a High Elf Scenario
"Scourge of the Asur"

EATAINE. Win a Blood of the Black Cairn Scenario. Scenario unlocks when the zone becomes contested.

By Gharik_Gallant & Risingashes
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Tuskgor (Tactic)",
					text =
[[
Tuskgor - Saving Face
Chaos Tome Tactic

(O) EATAINE. Gather Unchipped Tusks by killing Ravaging Tuskgors.

By Mourngrym, Socran, Karylet & Grishnar
20090107
]],
				},

				{
					name = L"Great Eagle (Acc)",
					text =
[[
Great Eagle (Ironfeather) - Eagle-Eye
ITEM UNLOCK

EATAINE @ 46, 60k. Kill a champ eagle called located in the SE, S of Shrine of Lileath, on a little rock. Gives an accessory called Gorkamork from the Fortune's Baubles set. NOTE: Slow spawn.

By Supaplex
20081007
]],
				},


				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"F. of Tzeentch (Title)",
					text =
[[
Flamer of Tzeentch (Aialye Lynsellia) - Hot Deal
"The Banisher"

EATAINE. Return the "Mote of Change" to Aialye Lynsellia @ the HE Ch16 Hub. The Mote of Change has to chance to drop from any Flamer, but I received it from an Unbound Flamer in the Chaos Wastes.

By Foggye
20081013
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Griffon (Title)",
					text =
[[
Griffon (Grimwing) - The Mightiest
"The Magestic"

EATAINE @ 52, 63 or 53.5, 63.5. Kill this champ in the SE, S of Shrine of Lileath.

By Supaplex, JodouTR & TorqueVolkmar
20081027
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Griffon (Title)",
					text =
[[
Griffon (Grimwing) - The Mightiest
"The Magestic"

EATAINE @ 52, 63 or 53.5, 63.5. Just talk to the NPC.

By Supaplex, JodouTR & TorqueVolkmar
20081027
]],
				},

				{
					name = L"Harpy (Tactic)",
					text =
[[
Harpy (Khaligrar Bloodwing) - Silent Star
CHAOS TOME TACTIC

EATAINE @ 37, 13 or 32, 13. Kill it.
Must pull while the mob is airborne for the reward.
NOTE: Twice confirmed report that killing the flying harpies ONLY cause the named mob to pop. Further, the named may pop in flight even as the other named remains sitting on the ground.

By Scubasteve79, Dissent, Hoof, Daht, JCBN, Vauhs, Vandiego & Oxdottir
20081124
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Harpy (Acc)",
					text =
[[
Harpy (Tormented Harpy) - Their Heart's Not in it, Yet.
JEWELRY ITEM

EATAINE @ 22, 63 or 30.5, 59. Kill these mobs until they drop a Harpy Heart. Deliver this to the Healer NPC in the DE Ch21 camp. Grants the unlock: Wind of Change. NOTE: The drop might take a while, I killed about 50 of them before the drop. BONUS: Click the Shrine of Asuryan NW of these mobs for an unlock!

By Supaplex, JodouTR & Benji
20081124
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Harpy (Acc)",
					text =
[[
Harpy (Tormented Harpy) - Their Heart's Not in it, Yet.
JEWELRY ITEM

EATAINE @ 22, 63 or 30.5, 59. Kill these mobs until they drop a Harpy Heart. Deliver heart to the healer located in Caledor Ch21--49, 21. Grants the unlock: Wind of Change. NOTE: The drop might take a while, I killed about 50 of them before the drop. BONUS: Click the Shrine of Asuryan NW of these mobs for an unlock!

By Supaplex, JodouTR & Benji
20081124
]],
				},

				{
					name = L"Treekin (Token)",
					text =
[[
Treekin (Irebough Mossroot) - Timber!
BEAST TOKEN

EATAINE @ 49, 63 to 50, 48. Vanquish this L40 Hero that patrols S of Lilithorn Estate.

By Vert, Supaplex & poll12
20081023
]],
				},

				{
					name = L"Tuskgor (Tactic)",
					text =
[[
Tuskgor (Riptusk) - Tusk for Tusk
CHAOS TOME TACTIC

EATAINE @ 14, 10.5. Kill the champ.

By Risingashes & Drunklight
20081124
]],
				},
			},
		},

		{
			name = L"Fell Landing",
			entries =
			{
				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Dark Elf (Title)",
					text = 
[[
Dark Elf - Vanquish the Dark Elf Fortress Lord
"Keeper of the Flame"

By Socran
]],
				},
			},
		},

		{
			name = L"Shining Way",
			entries =
			{

			},
		},

},		
}
