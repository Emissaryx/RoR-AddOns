TTitan.Data.BestiaryDvG = {}

function TTitan.Data.BestiaryDvG.GetData()
	return TTitan.Data.BestiaryDvG.RawData
end

function TTitan.Data.BestiaryDvG.FilterData()
	TTitan.Data.FilterByRealm(TTitan.Data.BestiaryDvG.RawData)
end

TTitan.Data.BestiaryDvG.RawData =
{
	header = L"Beastiary Unlocks - Dwarfs vs Greenskins",
	categories =
	{
		{
			name = L"Hidden Scrolls (RVR LAKES)",
			entries =
			{
				{
					name = L"[Ekrund]Ironbreaker (Pocket)",
					text =
[[
Dwarf, Ironbreaker - What do We Have Here ?

EKRUND @ 50, 8.5. Use the 'Hidden Scroll' just outside a dwarf tower due S of the Stonemine Tower BO. Unlocks: Endless List of Grudges.

(NOTE: This will not mark as complete, as it currently marks as complete while incomplete if notated correctly.)

By Gorfist, Benji & Fadira
20081216
]],
				},

				{
					name = L"[Mount Bloodhorn]Squig Herder (Pocket)",
					text =
[[
Goblin, Squig Herder - What do We Have Here ?
POCKET ITEM

MOUNT BLOODHORN @ 25.2k, 4.3k. In the very back of the cave SE of the Ironmane outpost in the RvR lake there is a Hidden Scroll on the ground (between the orc bodies at the cave-in and the large stone column).

(NOTE: This will not mark as complete, as it currently marks as complete while incomplete if notated correctly.)

]],
				},

				{
					name = L"[Marshes of Madness]Shaman (Pocket)",
					text =
[[
Goblin, Shaman - What do We Have Here ?
POCKET ITEM

MARSHES OF MADNESS @ 29, 29.5. NW of the keep there is a Hidden Scroll sitting on top of a pile.

(NOTE: This will not mark as complete, as it currently marks as complete while incomplete if notated correctly.)

By Fredegar
20081217
]],
				},

				{
					name = L"[Barak Varr]Rune Priest (Pocket)",
					text =
[[
Dwarf, Rune Priest - What do We Have Here ?
POCKET ITEM

BARAK VARR @ 31.5, 36. Click on the 'Hidden Scroll' -- 'Hidden Scroll' is located against the keep and near the postern door.

(NOTE: This will not mark as complete, as it currently marks as complete while incomplete if notated correctly.)

Be Sane Malk
]],
				},

				{
					name = L"[Badlands]Black Orc (Pocket)",
					text =
[[
Orc, Black Orc - What do We Have Here ?
POCKET ITEM

THE BADLANDS @ 22, 55. Click on the 'Hidden Scroll' located within the giant bone area, right beside a barrel that's on a pile of rubble. Unlocks: Lucky Humie's Hand.

(NOTE: This will not mark as complete, as it currently marks as complete while incomplete if notated correctly.)

By rouko
20081217
]],
				},

				{
					name = L"[BlackFire Pass]Engineer (Pocket)",
					text =
[[
Dwarf, Engineer - What do We Have Here ?
POCKET ITEM

Black fire pass @ 13,6k, 14,5k. Click on the 'Hidden Scroll' -- Scroll is located east of Gnol baraz keep between a broken siege weapon and a bush

(NOTE: This will not mark as complete, as it currently marks as complete while incomplete if notated correctly.)

By Urgiz
]],
				},

				{
					name = L"[Kadrin Valley]Dwarf (Title)",
					text =
[[
Dwarf - The History of the Dwarfs
"Forgebreaker"

KADRIN VALLEY @ 34.5, 7. Click on the 'Hidden Scroll' NE of the northernmost BO, behind some rocks.
By Loupgaroo, Socran & Risingashes
20081216
]],
				},

				{	name = L"[Black Crag]Goblin (Title)",
					text =
[[
Goblin - The History of the Goblins
"Grot's Doom"

BLACK CRAG @ 36, 60. Click on the 'Hidden Scroll' located in a cave. Enter the cave and follow the path to 39.5, 61. Go to the base of the big rock column coming down from the ceiling and find the scroll between 2 mushroom stocks.
By rouko
20081216
]],
				},
			},
		},
		{
			name = L"Ekrund",
			entries =
			{
				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Squig (Title)",
					text =
[[
Squig - The Other, Other Red Meat
"The Gourmand"

EKRUND. Head into Pick and Goggles tavern in the dwarf starting area and talk to waitress for Roasted squig then eat it.

By Kovacs, OdaNova, & burfo
20081007
]],
				},

{	-- Both version
					name = L"Plaguebearer (Title)",
					text =
[[
Plaguebearer - A Tale by the Fire
"The Plaguebearer Hunter"

EKRUND

1. 44.5k,52.5k - Hiding in bush, click on bush, start a quest.
2. Then get a branch, and go to the 60k, 39.5. And talk with a fanatic, he stands after a cabin which at a gate.

]],
				},

			},
		},

		{
			name = L"Mount Bloodhorn",
			entries =
			{
				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Boar (Tactic)",
					text =
[[
Boar (Dog Soldier/Waylayer/Firecaller) - Avoid a Gory End
BESTIAL TOME TACTIC

MOUNT BLOODHORN. Kill enough "Dog" mobs to max out the kill collector @ Da War Maker.

By notalltogether, Demonspawn & Cahyr
20081103
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Goblin, Night (Title)",
					text =
[[
Goblin, Night Goblin (Bloody Sun War Blasta) - Good Night Goblin
"The Frightful"

MOUNT BLOODHORN @ 35, 47. Talking to this NPC gets the unlock.

By Tananthalas
20081021
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Spite (Pocket)",
					text =
[[
Spite (Maegda) (Tarestil) - De-spite
POCKET ITEM

MOUNT BLOODHORN @ 3.5, 61. Run SW to HERE. Near the PQ Sacred Grove, so if you see that you know you're in the right area. Kill this L5-8 mob to unlock Spite Ale.

By NicWester, Wykk, Finalheaven & ThePedant
20081118
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Spite (Pocket)",
					text =
[[
Spite (Maegda) (Tarestil) - De-spite
POCKET ITEM

MOUNT BLOODHORN @ 3.5, 61. Run SW to HERE. Near the PQ Sacred Grove, so if you see that you know you're in the right area. Kill this L5-8 mob to unlock Spite Ale.
Also @ 54.5, 28. Killing the named spite Tarestil gives the unlock as well.

By NicWester, Wykk, Finalheaven & ThePedant
and by India & kazetenzan
20081118
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Spite (Tactic)",
					text =
[[
Spite (Tainted Grove Spite) - A Defiled Life-Force
MYTHICAL TOME TACTIC

MOUNT BLOODHORN @ 9, 61. Kill this L7 Hero and loot Tainted Spite Essence. Take it to the Bloody Sun Burner in a hut at the Ch3 camp. NOTE: Mob does NOT drop the loot every time, 10m repop.

By raicarter & Tananthalas
20081124
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Spite (Tactic)",
					text =
[[
Spite (Tainted Grove Spite) - A Defiled Life-Force
MYTHICAL TOME TACTIC

MOUNT BLOODHORN @ 9, 61. Kill this L7 Hero and loot Tainted Spite Essence. Speaking to Hammerstriker Hasher beside the Krom Komar merchant gives the unlock.  NOTE: Mob does NOT drop the loot every time, 10m repop.

By Torgan
20081124
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Squig (Title)",
					text =
[[
Squig - The Other, Other Red Meat
"The Gourmand"

MOUNT BLOODHORN. Talk to Tochez da Slop Slinger by Da War Maker. Get the Squig-on-a Stick & enjoy your meal.

By Ulgwar
20081103
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Vulture (Tactic)",
					text =
[[
Vulture - Slop-of-the-Day
BESTIAL TOME TACTIC

MOUNT BLOODHORN @ 2.5, 26 THEN ---> 22.5, 24 or 24.5, 25. Talk to Bloody Sun Burner in Komar at the first coords to get a Sack of Rotting Fruit. Travel E to second coords. Among the camp of vultures are slop baskets. Right-click on each one to dispose of the fruit (weak aggressive vultures will spawn).
Return to the Bloody Sun Burner inside the hut @ 2.5, 26.

By Tananthalas & Elmarra
20081103
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Vulture (Tactic)",
					text =
[[
Vulture - Slop-of-the-Day
BESTIAL TOME TACTIC

MOUNT BLOODHORN @ 2.5, 26 THEN ---> 22.5, 24 or 24.5, 25. Talk to Bloody Sun Burner in Komar at the first coords to get a Sack of Rotting Fruit. Travel E to second coords. Among the camp of vultures are slop baskets. Right-click on each one to dispose of the fruit (weak aggressive vultures will spawn).
Return the Empty Burlap Sack to the NPC to receive the unlock.

By Aoibhinn
20081103
]],
				},
								
			},
		},

		{
			name = L"Barak Varr",
			entries =
			{
				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Boar (Tactic)",
					text =
[[
Boar - Avoid a Gory End
BEASTIAL TOME TACTIC UNLOCK

BARAK VARR. Max out the kill collector named Elagroth Karginson in Thane's Defense.

By Lobo6717
20081007
]],
				},

				{
					name = L"Boar (Tactic)",
					text =
[[
Boar (Jowler) - Great Tusk
BESTIAL TOME TACTIC

BARAK VARR @ 56.5, 30.5 or 20, 64 or 40.5, 52 -OR- the location described below:
Vanquish this L16 named mob near the (O) warcamp. There's a trench that runs S, get in and follow the trench till you get to a bridge. The boar lives under the bridge.

By Deedee, Avale, notalltogether, Ulgwar & Icebird
20081103
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Dwarf Slayer (Tactic)",
					text =
[[
Dwarf Slayer (Sea Anvil Slayer) - Off With His ...
MAN TOME TACTIC

BARAK VARR @ 11, 49. Kill the mob and collect 20 Slayer Scalps. Then go talk to Kill Collector Reezel in Rottoof's Mugz 33.5, 60.

By NicWester, Rhah & Wykk
20081124
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Dwarf Slayer (Tactic)",
					text =
[[
Dwarf Slayer (Sea Anvil Slayer) - Off With His ...
MAN TOME TACTIC

BARAK VARR @ 10.5, 45. Go inside "The Sea Anvil" in Hammerhead Lagoon and talk to the Captain for the unlock.

By Kellithe, War Woman & Xiani
20081124
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Dwarf Slayer (Title)",
					text =
[[
Dwarf Slayer (First Mate Kjaelsson) - First of Many
"Doom Bringer"

BARAK VARR @ 10.5, 47. Board The Sea's Anvil ship. Kill the mob.

By NicWester, Wilken & Wykk
20081124
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Dwarf Slayer (Title)",
					text =
[[
Dwarf Slayer (First Mate Kjaelsson) - First of Many
"Doom Bringer"

BARAK VARR @ 10.5, 47. Just speak with the NPC for the unlock.


By armorum
20081124
]],
				},

				{
					name = L"Giant Lizard (Tactic)",
					text =
[[
Giant Lizard- Poached
BESTIAL TOME TACTIC

BARAK VARR @ 8, 29 or 5, 23. Habitat unlock, just walk along the beach where the salamanders are.

By LatukiJoe, burfo, NicWester, Dormammu, Wykk & Puddles404
20081103
]],
				},

				{
					name = L"Giant Lizard (Title)",
					text =
[[
Giant Lizard - A Matter of Scales
"The Lizard Hunter"

BARAK VARR @ 8, 25.5. Go to the beach and collect the item Scaly Skin from the lizards you see there. NOTE: This site is more (D) friendly.
Alternate method: See entry in BLIGHTED ISLE below.

By notalltogether & JodouTR
20081021
]],
				},

				{
					name = L"Giant Lizard (Exp)",
					text =
[[
Giant Lizard (Stonescale) - Blood from a Stone

BARAK VARR @ 19, 17. Kill this L20 mob.

By Sandkat, Thanat0s & Sildroni
20081103
]],
				},

				{
					name = L"Nurgling (Title)",
					text =
[[
Nurgling (Festering Corpse) - Getting it off Your Chest
"The Denier of Disease"

BARAK VARR @ 53, 49. Go where a patch of road is littered with dead dwarf bodies and vultures eating them. If you are on the N side of the vultures on the road, head just NE and fall down the cliff. Search the body and a couple nurglings pop out along with getting the unlock. NOTE: The corpse is on the ground next to a tree.

By Muninn, Wilken & Sandkat
20081103
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Ogre, Bull (Title)",
					text =
[[
Ogre, Bull - Loose-Lipped
"The Crusher"

BARAK VARR @ 21, 47. Find an ogre named Ragakk, a little bit S from the (O) warcamp along with some gobbos.

By Ursus, Thovargh & Blodsalv
20081124
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Ogre, Bull (Title)",
					text =
[[
Ogre, Bull - Loose-Lipped
"The Crusher"

BARAK VARR @ 49, 57. In the SE dwarf camp (Just head a little N of the squiggly path that heads S into the Marsh of Madness) talk to a Lead Belcher Ogre.

By Ursus, Thovargh & Blodsalv
20081124
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Spider, Giant (Title)",
					text =
[[
Spider, Giant - Tacky Decor
"Spider-Slayer"

BARAK VARR @ 5, 28. Go to the cave N of the zone entrance. BONUS: Lore unlock by examining the statue nearby.

By NicWester, burfo & FireOpal
20081103
]],
				},
			},
		},

		{
			name = L"Marshes of Madness",
			entries =
			{
				{
					name = L"Banshee (Title)",
					text =
[[
Banshee - A Sound to Silence
"The Silencer"

MARSHES OF MADNESS @ 56, 30. On the shore, behind a tree is a shallow grave hidden between the roots. Examine it to gain unlock.

By Enli, skyrunner620, Thanat0s & Jorus
20081104
]],
				},

				{
					name = L"Bat, Giant (Title)",
					text =
[[
Bat, Giant (Neborhest Bat) - For Once It Isn't Guano
"Echo Hunter"

MARSHES OF MADNESS @ 41, 48. Perform killing blow on this regular L19 mob just S of Dwarf Ch9.

By Squarkk, burfo& Pinafore
20081020
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Ghoul (Title)",
					text =
[[
Ghoul - Ghoul to be Gone
"Foe of the Cannibal"

MARSHES OF MADNESS @ 31, 10.5. First kill a ghoul. Second, talk to the goblin Noglik.

By Nerror, Wykk & Deymus
20081117
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Ghoul (Title)",
					text =
[[
Ghoul - Ghoul to be Gone
"Foe of the Cannibal"

MARSHES OF MADNESS @ 7.5, 61 OR 49.5, 40.5 by the entrance to the Fellowing Cave. Talk to Acolyte Scherer. Inspecting him grants you the title.
NOTE: You may need to kill ghouls before the unlock will trigger.


By Ursus, Dormammu, Wilken, Puddles404 & Zmiinyi
20081117
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Gnoblar (Tactic)",
					text =
[[
Gnoblar - Cull the Weak
GREENSKIN TOME TACTIC

MARSHES OF MADNESS @ 56, 7. Fight Boglars and loot their Boglar Ears.
Collect 5, once you have 5 then it auto-completes and you receive the unlock.

By OneWingedAngelo1, Dormammu, Risingashes, Ibeefus, Rhumble & Icebird
20081022
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Gnoblar (Tactic)",
					text =
[[
Gnoblar - Cull the Weak
GREENSKIN TOME TACTIC

MARSHES OF MADNESS @ 56, 7. Fight Boglars and loot their Boglar Ears.
Collect 5, once you have 5 then talk to the Kill Collector. NOTE: Bug of this works by turning in 1 ear (may be fixed).

By OneWingedAngelo1, Dormammu, Risingashes, Ibeefus, Rhumble & Icebird
20081022
]],
				},

				{
					name = L"Gnoblar (Tactic)",
					text =
[[
Gnoblar (Honcho Bogwash) - Tiny Tyrant
GREENSKIN TOME

MARSHES OF MADNESS @ 35, 60. Kill the L20 mob. Doing this unlock plus "Cull the Weak" will completely unlock the first Greenskin Tactic called "Fungal Fetish".

By Unpeftable, Kellithe & Wilken
20081022
]],
				},

				{
					name = L"Giant (Title)",
					text =
[[
Giant (Thrags) - Bare the Brunt
"The Earth Shaker"

MARSHES OF MADNESS @ 55, 60. Engage and battle AND get critically hit by this L15 Hero (you don't have to defeat him to get the unlock). TIP: Scrap your initiative gear before you engage him.
NOTE: Repop time may be lengthy.
BONUS: Hidden quest for a golden nugget when traveling up the mt toward the coords.

By Unpeftable, Thanat0s, Dormammu, notalltogether, Pinafore, India& Puddles404
20081021
]],
				},

				{
					name = L"Vampire (Title)",
					text =
[[
Vampire - Hail to the Horror
"The Dawnbringer"

MARSHES OF MADNESS @ 50, 53. Near where all the plague priests are look for a clickable object called a "Vampire Effigy." Right click it to get the title.

By Thrid, Jschmuck2 & BlackNova169
20081022
]],
				},
			},
		},

		{
			name = L"The Badlands",
			entries =
			{
				{
					name = L"Ghoul (Tactic)",
					text =
[[
Ghoul (Rauklus) - Foul Amongst the Fowl
BESTIAL TOME TACTIC

BADLANDS @ 19, 10. Kill the mob in the valley with the other zombies and birds.

By Blodsalv, Ghenghiz & Teran
20081124
]],
				},
				
				{
					name = L"Night Goblin (Title)",
					text =
[[
Goblin, Night Goblin (Uzfang) - Good Night Goblin
"The Frightful"

BADLANDS @ 5.5, 8 or 4, 8. Kill it. He's inside one of the huts. BONUS: There's a lore unlock by the bonfire, too.

By Kellithe & Teran
20081030
]],
				},

				{
					name = L"Ogre Tyrant (Title)",
					text =
[[
Ogre Tyrant (Graw Leadgut) - Not What it Appears
"The Liberator"

BADLANDS @ 63, 36k or 60, 27k. Enter the cave. Kill this L29 Champ and inspect the medal he drops. NOTE: If you kill him in a group, he only drops 1 medal, so you'll have to kill him several times.

By Thovargh, notalltogether & Teran
20081013
]],
				},

				{
					name = L"Savage Orc (Token)",
					text =
[[
Savage Orc (Skaar Vidash) - Scar'd for Life
BEASTIAL TOKEN UNLOCK

BADLANDS @ 5, 55k or 4, 35k. Kill this L21 Hero. He stands next to a tree in the mts above the Geyser Den. NOTE: Respawn timer is lengthy.

By cintra, JodouTR, Blodsalv & poll12
20081016
]],
				},

				{
					name = L"Savage Orc (Title)",
					text =
[[
Savage Orc (Tribal Blue Face) - Fungus Amoung Us
"The Civil"

BADLANDS @ 14.5, 20.5 THEN ---> 6, 17 or 15, 18. First, loot the Strange Mushroom from a "Thornberry Bush" on a small island at the first set of coords. Then, have it in your inventory when you kill the mobs at next coords. NOTE: Make sure to kill the orcs that are hanging around the piles of rubbish and not the ones on the cliff itself.

By Arienh, Thovargh, Houyoko, Gabriel Stern, notalltogether & Pinafore
20081103
]],
				},

				{
					name = L"Skaven (Title)",
					text =
[[
Skaven (Man Trap) - Sign of the Times
"Skaven Splitter"

BADLANDS. S of the first T3 Dwarf town there is a cave called Warpclaw Hideout. It's full of Skavens amidst a bunch of Geiser Squigs. Head into the cave, and click on a corpse in a "Man Trap" (Obviously a Skaven take on the rat trap) to get the unlock.

By Ursus, Dormammu & notalltogether
20081029
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Snotling (Pocket)",
					text =
[[
Snotling (Foigak) - Miscreant Memories
POCKET ITEM

BADLANDS @ 24, 26.5. Talk to this snotling on a tiny island in the river, close to a waterfall and surrounded by trolls. Unlocks Steamtrain Token.

By Amagorr, Banehowl, nny76 & Pinafore
20081030
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Vulture (Title)",
					text =
[[
Vulture (Vulture Feeder Parts) - Feeding Time...
"The Main Course"

BADLANDS @ 35, 27.5. Destroy the "Vulture Feeder" for the unlock.

By FnClassy, Gabriel Stern, Houyoko, Kriegzwerg & Kutzum
20081124
]],
				},
			},
		},

		{
			name = L"Mount Gunbad",
			entries =
			{
				{
					name = L"Night Goblin (Pocket)",
					text =
[[
Night Goblin (Morgit da Waaagher) - Night-Time is the Right Time
POCKET ITEM

MOUNT GUNBAD (Middle Wing). Kill the champ Night Goblin in the first PQ area in the middle wing of Mt Gunbad (Straight down the ramp from the entrance, the PQ with the giants). The mob is hiding in a little alcove on the left near the start of the long hallway leading to the next area. Unlocks: Darklight.
NOTE: May or may not be a killing blow unlock. Confirmed reports of both instances.

By Houyoko, JodouTR & Kellithe
20081110
]],
				},

				{
					name = L"Snotling (Tactic)",
					text =
[[
Snotling (Kezzen) - Green Lightning
GREENSKIN TOME TACTIC

MOUNT GUNBAD. The mob spawns in a hidey hole in the right wing before the first PQ. Kezzen immediately paths from the right wing, through the NPC area (he passes by the crock pot there) and on to the left wing. The mob will continue on, following the wall to the right and enter the hidey hole near a bunch of wyvern eggs. There he despawns. Best advice is to wait for him in the NPC area, he'll pass right on by. NOTE: Sometimes he can take up to 3 hours to spawn. Also he can be bugged and ghost through walls.

By Kellithe
20081110
]],
				},

				{
					name = L"Squig (Title)",
					text =
[[
Squig ('Ard ta Feed) - Feeding Time...
"'Ard ta Eat"

MOUNT GUNBAD (Middle Wing). Killing blow the last boss, the giant 2-headed squig. NOTE: Killing blow is confirmed, but needs more evidence to support.

By Dissent
20081110
]],
				},
			},
		},

		{
			name = L"Black Fire Pass",
			entries =
			{
				{
					name = L"Squig (Tactic)",
					text =
[[
Squig (Famished Squig) - Forgotten and Famished
BESTIAL TOME TACTIC

BLACK FIRE PASS @ 37.5, 59.5. Kill this champ hiding in the mts, eating goats, yum!

By Ulgwar, Sandkat & JodouTR
20081103
]],
				},
			},
		},

		{
			name = L"Thunder Mountain",
			entries =
			{
				{
					name = L"Bull Ogre (Acc)",
					text =
[[
Bull Ogre (Cauldron) - You Going to Eat That?
JEWELRY ITEM

THUNDER MOUNTAIN @ 48, 54. Clicking on the Cauldron will give you Fresh Meat. Right-click it to get the unlock: Fated Veil.

By Sandkat & Teran
20081027
]],
				},

				{
					name = L"Dragon (Title)",
					text =
[[
Dragon - All That Remains
"Fireborn"

THUNDER MOUNTAIN @ 1.5, 21. Top of the mt between the two roads crossing into Cinderfall, probably easiest to climb up to this point from the S road. The Broken Axe Cindri Cragborn is a clickable item on ground.

By fjir, Dissent & m3atwad
20081103
]],
				},

				{
					name = L"Drakk Cultist (Tactic)",
					text =
[[
Drakk Cultist - Hard To Be a Leader
MAN TOME TACTIC

THUNDER MOUNTAIN @ 17, 5. Click the "Drakk Altar" inside the cultist cave for the unlock. NOTE: Also accomplished by killing a Drakk Cultist. Any Cultist up there should do. FURTHER: May take multiple kills for the unlock to trigger (confirmed at 5 kills).

By Sandkat, Teran, JodouTR & xarinth
20081124
]],
				},

				{
					name = L"Drakk Cultist (Title)",
					text =
[[
Drakk Cultist (Cultist Altar) - Where the Blood Flows
"The Harrier"

THUNDER MOUNTAIN @ 20, 7.5. Click the altar at the very end of the Dragon Breath Cave.

By Sandkat, JodouTR & Quiggles
20081020
]],
				},

				{
					name = L"Giant (Pocket)",
					text =
[[
Giant (Bugman's XXXXXX) - X Marks the Spot
POCKET ITEM

THUNDER MOUNTAIN. Left of the merchant in the Dwarf Ch18 town, click the barrel for the unlock: Barrel of Ale.

By skyrunner620 & JodouTR
20081021
]],
				},

				{
					name = L"Spider (Tactic)",
					text =
[[
Giant Spider (Graelba) - Big Identity Crisis
BESTIAL TOME TACTIC

THUNDER MOUNTAIN @ 24, 49 or 22, 47 or 62, 22. Kill this L35 named mob next to the road between Greenskin Ch18 and the Greenskin WC.

By Supaplex, TorqueVolkmar & Lirion
20081104
]],
				},

				{
					name = L"Spider (Acc)",
					text =
[[
Giant Spider (Magma Crawler) - Sacking for Sacs
JEWELRY ITEM

THUNDER MOUNTAIN @ 43, 7.5. Kill the mobs until you get an 5 Arachnid Poison Sac. Unlocks Crow Caller Chain. NOTE: Less than 10% drop rate.

By Krazed, Kaijin, Draskuul& Venar
20081103
]],
				},

				{
					name = L"H. of Tzeentch (Tactic)",
					text =
[[
Horror of Tzeentch - What Horrifies Horrors?
DAEMONIC TOME TACTIC

THUNDER MOUNTAIN @ 16, 17 or 18, 13. Kill horrors on top of that mt and they drop An Odd Doll. Location is up the mt on the S side, right across the Dwarf Ch18 town. Rt click it in inventory for the unlock. NOTE: Drop rates are very low.

By armorum, India, JodouTR, poll12 & Quiggles
20081021
]],
				},

				{
					name = L"Rhinox (Title)",
					text =
[[
Rhinox (Rhinox Bonepile) - Dense and Denser
"The Rhinox Rocker"

THUNDER MOUNTAIN @ 50, 55. Click on the bonepile in the lava. This is very close to the cauldron for the Bull Ogre unlock. NOTE: The bone pile can spawn random at every lava lake in the SE part of the map.

By cintra, TorqueVolkmar & Thovargh
20081027
]],
				},
			},
		},

		{
			name = L"Cinderfall",
			entries =
			{
				{
					name = L"Basilisk (Acc)",
					text =
[[
Basilisk (Bale Gaze) - No Reflection of Your Skill
SET ITEM

CINDERFALL @ 35, 34. Across the lava there is a skeleton "Komnor Bronzemug". Click it and read, "The statue before you is incredible life-like, and highly detailed. The oddest feature is the cracked mirror that you pry from the statues fingers." Rt clicking on the mirror to make this L37 mob appear. Kill it for: Wordbreaker Band part of "The Winds Impervious" set.
TIP: You can climb up the mt @ 46.5, 41 and then work your way through it.

By JCBN, Almaram & India
20081021
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Ghoul (Tactic)",
					text =
[[
Ghoul (Flamepicked/Deathflame Ghoul) - Finger Lickign Good
BESTIAL TOME TACTIC

CINDERFALL @ 54, 43. Ghouls are in Cinderfall. Max the Kill Collector @ Da Scrapin Camp for the unlock. NOTE: I killed 80 ghouls and got the unlock. You can probably kill less. As you kill them the ghouls are being counted as zombies but unlock a ghoul tome entry. NOTE: There appears to be a lvl requirement for the kill collector.

By Sandkat, Grevan, India & victor0219
20081124
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Ghoul (Tactic)",
					text =
[[
Ghoul (Flamepicked/Deathflame Ghoul) - Finger Lickign Good
BESTIAL TOME TACTIC

CINDERFALL @ 54, 43. Ghouls are in Cinderfall. Max the Kill Collector @ ch18 Camp for the unlock. NOTE: I killed 80 ghouls and got the unlock. You can probably kill less. As you kill them the ghouls are being counted as zombies but unlock a ghoul tome entry. NOTE: There appears to be a lvl requirement for the kill collector.
NOTE: Kill Collector says you need to kill Flamepicked Ghouls, but the Deathflame Ghouls on (D) side work.

By Sandkat, Grevan, India & victor0219
20081103
]],
				},

				{
					name = L"Skeleton (Acc)",
					text =
[[
Skeleton (De-Animated Skeleton) - Coin of the Trade
JEWELRY ITEM

CINDERFALL @ coords below. Examining a Skeleton will give you a skull. Right clicking on the skull unlocks item: Torment. NOTE: You need all three skulls to get the unlock.
1. @ 59.5, 11k --->Undead Dwarf Skull. In the cave, up the ramp to the left, close to a goblin and some piping.
2. @ 57, 57k --->Undead Elven Skull @ entrance to cave with 4 vultures in (D) zone.
3. @ 64, 50k--->Undead Human Skull in first room with ogre and bright wizards inside.
BUG: vendor refuses to sell the ring despite it's unlock in ToK.

By Foggye, SmithyPasha, Sandkat, JodouTR, Xiani & Risingashes
20081110
]],
				},

				{
					name = L"Zombie (Tactic)",
					text =
[[
Zombie (Wulgrig) - Wulgrig
UNDEAD TOME TACTIC UNLOCK

CINDERFALL @ 44, 2.5k. This L36 mob spawns in the N cave, that you trigger by interacting with a "Pile of Rocks" found one lvl below the main lvl of this cave. After killing it I got the unlock "Wulgrig", 9th in the list under zombie. Also acquired the first undead tactic after 4 undead tome tactic unlocks called: Undead Chill. NOTE: (D) players cannot interact with the rocks, but after approaching them a few times he spawns.

By Nilenya, Grevan & JodouTR
20081017
]],
				},
			},
		},

		{
			name = L"Death Peak",
			entries =
			{
				{
					name = L"Ghoul (Acc)",
					text =
[[
Ghoul (Pisacha the Rank) - Demoted
JEWLERY ITEM

DEATH PEAK @ 9.6, 36. Kill it. Unlocks Strife.

By Zoe9906
20081021
]],
				},

				{
					name = L"Wight (Title)",
					text =
[[
Wight (Seno Cirrus) - Dead Weight
"The King Slayer"

DEATH PEAK @ 3, 10k. Kill the named mob at the end of the tunnel.

By Zoe9906
20081013
]],
				},

				{
					name = L"Winged N. (Title)",
					text =
[[
Winged Nightmare (Terrorwing) - Clip Its Wings
"The Dreamstealer"

DEATH PEAK @ 11, 12. Kill it.

By Sandkat
20081124
]],
				},

				{
					name = L"Wyvern (Title)",
					text =
[[
Wyvern (Damaged Wyvern Egg) - In the Wild
"The Wyvern Watcher"

DEATH PEAK @ 3k, 45k. Find Damaged Wyvern Egg in the back of the cave, in a small room.

By Sandkat
20081007
]],
				},
			},
		},

		{
			name = L"Kadrin Valley",
			entries =
			{
				{
					name = L"Dwarf Slayer (Tactic)",
					text =
[[
Dwarf, Slayer - Look Out Below!
MAN TOME TACTIC

KADRIN VALLEY @ 29, 40. Up on the bridge there's a barrel of tools, right click for unlock.

By Itsari & KramerTheWeird
20090106
]],
				},

				{
					name = L"Bear (Tactic)",
					text =
[[
Bear (Thag Bolgar) - Sharpen Your Knives
BEASTIAL TOME TACTIC

KADRIN VALLEY @ 5, 14.6. Kill the mob. He's at the back of a place in between the mts, behind a camp filled with zealots.

By Supaplex
20081021
]],
				},

				{
					name = L"Beastman, Gor (Tactic)",
					text =
[[
Beastman, Gor (Yarrgan The Fiendish) - For the Greater Gor
CHAOS TOME TACTIC

KADRIN VALLEY @ 27, 20 just W of the PVP Objective. Kill it.

By Iranium & Kraxis
20081124
]],
				},
				
				{
					name = L"Dwarf (Title)",
					text =
[[
Dwarf - Complete a Dwarf Scenario
"Foe of the Dawi"

KADRIN VALLEY. Win a Gromril Crossing Scenario. Scenario unlocks when the zone becomes contested.

By Socran
20081124
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Dwarf Slayer (Acc)",
					text =
[[
Dwarf Slayer (Argnus Rockskull) - Looking for Trouble
JEWELRY ITEM

 KADRIN VALLEY @ 58, 50. Kill the NPC to receive the unlock.

By cintra & Zerk
20081021
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Dwarf Slayer (Acc)",
					text =
[[
Dwarf Slayer (Argnus Rockskull) - Looking for Trouble
JEWELRY ITEM

KADRIN VALLEY @ 58, 50. Talk to this NPC to unlock: Oathstone of Karaz-a-Karak.

By cintra & Zerk
20081021
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Giant Lizard (Tactic)",
					text =
[[
Giant Lizard - Hunger Pangs
BESTIAL TOME TACTIC

KADRIN VALLEY. Max the Kill Collector in Greenskin Ch21 for the tactic. Requires the standard 60 kills.

By armorum, Houyoko, JodouTR, JCBN & Benji
20081117
]],
				},

				{
					name = L"Giant (Tactic)",
					text =
[[
Giant (Vragi the Brute) - Brutal Nose Ring
GIANT TOME TACTIC

KADRIN VALLEY @ 34, 28. Drops Giant Nosering. Rt clicking object gives the unlock. NOTE: May take multiple kills.
Alternate method: See REIKLAND.

By JCBN, JodouTR, skyrunner620 & TorqueVolkmar
20081031
]],
				},

				{
					name = L"Greenskin (Title)",
					text =
[[
Dwarf - Complete a Dwarf Scenario
"Foe of the Dawi"

KADRIN VALLEY. Win a Gromril Crossing Scenario. Scenario unlocks when the zone becomes contested.

By Socran
20081112
]],
				},

				{
					name = L"Nurgling (Tactic)",
					text =
[[
Nurgling (Vlasi Ipatiev) - Say Hello to My Little Friends
DAEMONIC TOME TACTIC

KADRIN VALLEY @ 40.5, 25. Kill this L40 Hero human N of Greenskins Ch22 sitting at the edge of the cliff.

By MasterM & skyrunner620
20081103
]],
				},

				{
					name = L"Rat Ogre (Title)",
					text =
[[
Rat Ogre (Burrow Champion) - To the Death
"The Scarred"

KADRIN VALLEY @ 57, 39k. Kill this L38 champ mob, up a ramp inside the cave. NOTE: He summons 3 skaven at 20% health and is on a 10 minute repop.

By Sandkat & poll12
20081017
]],
				},

				{
					name = L"Troll, Stone (Acc)",
					text =
[[
Stone Troll (Boulder Chukka) - Diamond in the Rough
JEWELRY ITEM

KADRIN VALLEY @ 31, 25. Kill these mobs to get the drop Consumed Rough Diamond. Rt click it to unlock: Bloodied Fracture.

By JCBN
20081021
]],
				},
			},
		},

		{
			name = L"Black Crag",
			entries =
			{
				{
					name = L"Basilisk (Title)",
					text =
[[
Basilisk - Cave of Stone
"The Rock"

BLACK CRAG. Enter the Sulfur Caves @ NW corner of the map.

By Supaplex
20081007
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Basilisk (Tactic)",
					text =
[[
Basilisk - It's in the Bag
BESTIAL TOME TACTIC

BLACK CRAG. Kill 6 young basilisks N of the Ch16 quest hub. Then go back to the hub and talk to the goblin "Gubs". He is hiding by the fence in the N part of the hub.

By Ravnir, Apophisthecursed, cintra, Yvarma & flushed
20081124
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Basilisk (Tactic)",
					text =
[[
Basilisk - It's in the Bag
BESTIAL TOME TACTIC

BLACK CRAG @ 40, 38. Pick-up Duregar's pack located in or around the burnt down huts. Return the bag to Duregar Bronzemug at the Dwarf CH21 camp. NOTE: Bag despawns on pickup and instantly respawns elsewhere. Just keep looking--it's a small bag on the ground.

By Ravnir, Apophisthecursed, cintra, Yvarma & flushed
20081124
]],
				},

				{
					name = L"Basilisk (Tactic)",
					text =
[[
Basilisk (Stinky) - Scales of Mourning
BEASTIAL TOME TACTIC UNLOCK

BLACK CRAG. Find this mob in the back of the Sulfur Caves (NW Corner of the map). Also needed for a Destruction quest.

By Supaplex
20081007
]],
				},

				{
					name = L"Bat, Giant (Tactic)",
					text =
[[
Bat, Giant (Pit Bat) - In the Dark of Day
BEASTIAL TOME TACTIC UNLOCK

BLACK CRAG. Kill a Pit Bat @ the Bat Hollow, W of Greenskin Ch15 (D) camp.

By Supaplex
20081007
]],
				},

				{
					name = L"Giant (Tactic)",
					text =
[[
Giant (Ufgor) - Giant Amongst Giants
GIANT TOME TACTIC

BLACK CRAG @ 36, 53. There are 3 named giants, one is a L40+ champ. Kill it.

By Gorbasch & Doombeard
20081020
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Gnoblar (Title)",
					text =
[[
Gnoblar - Mixed Company
"The Bully"

BLACK CRAG @ 40, 12k. Burnmaw Tower. Run through the camp with Ogres and Gnoblars.

By India
20081016
]],
				},

				{
					name = L"Goblin (Title)",
					text =
[[
Goblin - Complete a Greenskin Scenario
"The Avenging Brewmaster"

BLACK CRAG. Win a Howling Forge scenario. This scenario unlocks when the zone becomes contested.

By Risingashes
20081110
]],
				},

				{
					name = L"Orc (Title)",
					text =
[[
Orc - Complete a Greenskin Scenario
"The Mangler"

BLACK CRAG. Win a Howling Forge scenario. This scenario unlocks when the zone becomes contested.

By Risingashes
20081110
]],
				},

				{
					name = L"Slimehound (Title)",
					text =
[[
Slimehound (Slimehound Remains) - An Easy Trail to Follow
"The Slime-Trodder"

BLACK CRAG @ 29, 29k. The slimehound remains are just to the left of the cave entrance behind some bushes. Examine the slime to get the unlock.

By Thovargh, Archaides& JodouTR
20081016
]],
				},

				{
					name = L"Snotling (Tactic)",
					text =
[[
Snotling (Hoarding Burrower) - Relish the Relics
GREENSKIN TOME TACTIC

BLACK CRAG @ 63, 56. In the cave Cliffrunners Den, enter the last big room before the orc champ spawn. There is the L41 named snotling in the corner to your right. Snotling will drop Relic Sword of Verena which must be right clicked for the unlock. NOTE: Drop rate is not %100, 10min repop.

By Gorbasch, Dissent& Foggye
20081020 - 3
]],
				},

				{	-- Order version
					realm = TTitan.Data.Realm.ORDER,
					name = L"Wyvern (Acc)",
					text =
[[
Wyvern (Rustspatter Squig) - Let's See What This Does
JEWELRY ITEM

BLACK CRAG @ 19, 9.5. First you kill the L32 mob and get the item Fresh Meat. Then go E to 21k, 9.5k and place the meat in the Wyvern Trap. You will get the unlock. NOTE: a L37 Wyvern will spawn but you don't have to kill it. Unlocks Fullbelly's Lucky Foot.

By Xerexerex
20081027
]],
				},

				{
					name = L"Troll (Tactic)",
					text =
[[
Troll (Rockmaw) - Rock in the Maw of Darkness
GIANT TOME TACTIC

BLACK CRAG @ 6.5, 24 THEN ---> 1.3, 24.5. L31 mob found outside and later inside the Despair Pits. First, kill it outside the cave and then venture into the cave where he spawns in the back. Kill him there for the unlock. It appears that these two killings are connected. NOTE: Spawn repop between the two mobs is short, if not instant.

By Lilion, Itsari, JodouTR & Doombeard
20081020
]],
				},

				{
					name = L"Troll (Tactic)",
					text =
[[
Troll (Stonegullet Troll) - Prescribed Flesh
GIANT TOME TACTIC

BLACK CRAG. Kill this mob in the Despair Pits (middle of W border) to receive Troll Flesh. Automatically gave me unlock. NOTE: 5% drop rate.

By Supaplex & Xerexerex
20081103
]],
				},

				{
					name = L"Troll (Tactic)",
					text =
[[
Troll, Stone - Indigestion
GIANT TOME TACTIC

BLACK CRAG. Enter the Despair Pits (middle of W border). In the N end of the cave, there's something on the ground that you can interact with called Drul's Lunch. Interacting with it gives you a text saying you could poison. Go to the S end of the cave & kill Skittering Spiders to get a Poison Gland. Then interact with Drul's Lunch to get the unlock.

By Supaplex
20081021
]],
				},

				{	-- Destruction version
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Wyvern (Acc)",
					text =
[[
Wyvern - Let's See What This Does
JEWELRY ITEM

BLACK CRAG @ 20, 9. Kill a Squig in this area to acquire Fresh Meat, then use it on the Wyvern trap to receive: Fullbelly's Lucky Foot. NOTE: When you use the trap, a L37 Wyvern will appear but it has been confirmed that killing it is not required for the unlock. NOTE: Wyvern trap also spotted @ 44, 13.5. Here, the unlock is unconfirmed.

By Thovargh, MrPing1000 & Amaranth
20081027
]],
				},
			},
		},
    },
}
