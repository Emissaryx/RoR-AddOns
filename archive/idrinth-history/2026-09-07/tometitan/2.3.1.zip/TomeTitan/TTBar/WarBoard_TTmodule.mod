<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
    <UiMod name="WarBoard_TTmodule" version="1.0" date="11/17/2008" >
        <Author name="Oscarr" email="oscarr_d24@yahoo.com" />
        <Description text="Tome Titan for WarBoard" />

        <Dependencies>
	    	<Dependency name="WarBoard" />
			<Dependency name="Tome Titan" />
        </Dependencies>

		<Files>
			<File name="WarBoard_TTmodule.lua" />
			<File name="WarBoard_TTmodule.xml" />
		</Files>

		<OnInitialize>
			<CallFunction name="WarBoard_TTitan.Initialize" />
        </OnInitialize>
	</UiMod>
</ModuleFile>