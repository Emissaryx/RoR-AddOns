TTitan.Data.HistoryEvC = {}

function TTitan.Data.HistoryEvC.GetData()
	return TTitan.Data.HistoryEvC.RawData
end

function TTitan.Data.HistoryEvC.FilterData()
	TTitan.Data.FilterByRealm(TTitan.Data.HistoryEvC.RawData)
end

TTitan.Data.HistoryEvC.RawData =
{
	header = L"History & Lore Unlocks - Empire vs Chaos",
	categories =
	{
		{
			name = L"Nordland",
			entries =
			{
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"The Order of the Griffon",
					text =
[[
28.4k, 19k
Talk to any 'Griffon Striker' in Arnholdt’s Warcamp.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"The Order of the Griffon",
					text =
[[
53k, 5k
Kill any 'Griffon Striker' along the main road near the Ravenraid Mill, Major Landmark.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Sigmar",
					text =
[[
24.2k, 55.5k 
Interact with the book 'Life of Sigmar' on the second floor of the Grimmenhagen Inn.
]],
				},
				
				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Sigmar",
					text =
[[
57.5k, 60.6k 
Interact with the book 'Life of Sigmar' on an outdoor table at the Salzemund Book Vendor.
]],
				},				

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Militia",
					text =
[[
27.5k, 51.2k
Talk to the farmer 'Jakob Hebel' in Grimmenhagen Village - Empire Chapter 1.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Militia",
					text =
[[
46.2k, 5.1k
Kill 'Citizen Militia' east of Blessed Gathering Warcamp.
]],
				},

				{
					name = L"Ill Omens",
					text =
[[
42k, 25.4k
Interact with the 'Dead Sparrow' south of the Hangman’s Woods, Major Landmark.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Superstition",
					text =
[[
25k, 55.6k
Interact with the 'Empire Bar Door' and enter the Grimmenhagen Inn.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Superstition",
					text =
[[
49.5k, 57.1k
Interact with the 'Tavern Door' and enter the Fishes Flask in the Salzenmund PQ.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"The Plague",
					text =
[[
27.4k, 54.2k 
Interact with 'Plague Corpse' near the center of Grimmenhagen Village.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"The Plague",
					text =
[[
62.9k, 22.8k 
Interact with 'Plague Corpse' next to unearthed grave in the Beeckerhoven Graveyard.
]],
				},

				{
					name = L"The Colleges of Magic",
					text =
[[
11.2k, 24.3k
Interact with 'A Dusty Tome' near the Ruins of Schloss von Rubendorf, it's hidden up on the ledge near some Spites next to a bush.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Isolated Settlements",
					text =
[[
14.5k, 50.5k
Interact with a dead man, identified as the 'Midnight Rider' behind the tent near where order spawn at game start.
]],
				},
				
				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Isolated Settlements",
					text =
[[
40.8k, 1.5k
Interact with a dead man, identified as the 'Midnight Rider' behind a house in Death’s Brink - Chaos Chapter 3.
]],
				},				

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Elector Counts",
					text =
[[
31k, 46.2k
Interact with the 'Dedication Plaque' north of Grimmenhagen Village.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Elector Counts",
					text =
[[
62k, 45.6k
Kill Steward Lord Geinhardt at Salzenmund Keep.
]],
				},
				
				{
					name = L"Corruption from Within",
					text =
[[
38.5k, 25k
Interact with the 'Runic Tablet' under the large stones in the middle of the Faewulf's Rest PQ.
]],
				},				
				
			},
		},

		{
			name = L"Norsca",
			entries =
			{
				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Chaos Portal",
					text =
[[
27k, 9.4k
Interact with the 'Changer’s Eye' north of spawn point in The Unshackled Host - Chaos Prologue camp.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Chaos Portal",
					text =
[[
58.8k, 23k
Interact with the 'Changer’s Eye' east of the Pit of the Forsaken PQ.
]],
				},

				{
					name = L"The Raven Host",
					text =
[[
18.5k, 39.8k
Interact with the 'Dead magus' in the Tomb of the Ravenboune, Major Landmark.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Hellcannons",
					text =
[[
38.5k, 10k
Interact with the 'Ammunition' pile next to hellcannon.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Hellcannons",
					text =
[[
42.5k, 62k
Kill the Hellcannon.
]],
				},				

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"The Raven God",
					text =
[[
31k, 12.4k
Interact with a pile of books called 'Tomes of the Raven' at The Unshackled Host- Chaos Prologue camp, next to 'Skurlorg Blackhorn'.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"The Raven God",
					text =
[[
48.8k, 44.4k
Interact with a pile of books called 'Tomes of the Raven' in Amund’s Barrow, Major Landmark.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Daemons",
					text =
[[
30.1k, 9.2k
Talk to the 'Screamer' in the The Unshackled Host- Chaos Prologue camp, next to the portal.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Daemons",
					text =
[[
50.8k, 31.5k 
Kill a 'Foul Nurgling' in the Ulfenwyr PQ.
]],
				},

				{
					name = L"Norse Tribes",
					text =
[[
31.2k, 41,4k
Interact with the 'Sarl Banner' in Skaldbjorn, Major Landmark.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Raiding and Pillaging",
					text =
[[
36.7k, 22.2k
Interact with the 'Broken Wheelbarrow' among a collection of wheelbarrows and crates to the south of the Ruinous Powers PQ, just before you cross the bridge towards Sorcerer's Axion - Chaos Chapter 2.
]],
				},
				
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Raiding and Pillaging",
					text =
[[
49.2k, 64k
Interact with the 'Caravan Crate' by the overturned wagon, on the road transitioning into Nordland.
]],
				},

				{
					name = L"Nomads",
					text =
[[
57.6k, 39.3k
Interact with the 'Hide Stretcher' by the horses in the Norse Invader camp.
]],
				},

				{
					name = L"Sorcery",
					text =
[[
59.8k, 49k
Interact with a large open book called 'Another Dusty Tome' laying on the ground in the center of the standing stones next to the altar in the 'Altar of Bloodbane PQ.
]],
				},

				{
					name = L"Marauders",
					text =
[[
31k, 47.4k
Interact with a dead horse 'Logi' on top of a small cliff, east of the Suderholm PQ.
]],
				},
			},
		},

		{
			name = L"Troll Country",
			entries =
			{
				{
					name = L"Cult of the Plaguesworn",
					text =
[[
30.5k, 52.8k 
Kill the 'Blighted Prophet' (Champion lvl 13) by the Blighted Farm PQ.
]],
				},

				{
					name = L"Scarce Resources",
					text =
[[
23.15k, 52.7k
Interact with the 'Destroyed Supplies' between the burning house and cart on the west side of The Blighted Farm PQ.
]],
				},

				{
					name = L"Sacred Totems",
					text =
[[
39k, 46k
Proximity Area Unlock: - Walk near 3 wooden eagle-like totems in the beach near In the southern part of Trovolek - Destruction Chapter 8.
]],
				},
				
				{
					name = L"The End Times",
					text =
[[
34.8k, 32.2k 
Interact with the book titled 'This Will Be Your Doom', it is mostly obscured by the nest. It is located among the Great Eagle Nests, Major Landmark, there is a nest near the ledge to the right while going up the long hill.
]],
				},		

				{
					name = L"The Cult of Sigmar",
					text =
[[
10.8k, 53.3k
Interact with the 'Statue of Sigmar' in RvR lake, northwest of Felde Castle - Chaos Chapter 6.
]],
				},		

				{
					name = L"Nobility",
					text =
[[
8.3k, 23.2k
Interact with the 'Fine Tools' lying on the ground off the cliff of Suskarg - Empire Chapter 5.
]],
				},

				{
					name = L"Nurgle",
					text =
[[
51.7k, 30k
Kill 'Corvak the Maimed' in the middle of Lursa's Blight PQ, on top of the hill.
]],
				},

				{
					name = L"Soulblight Stone",
					text =
[[
50k, 54.5k
Interact with 'Dead Marauder' among a group of marauder corpses. This unlock is in-between Slayer's Demise PQ and Plague Trolls PQ, but it's closest to the latter. On the map is a medium sized lake (the only one), there are some little plots of land scattered around, it's in the right-most side of the lake. (looks like a circle on the map).
]],
				},

				{
					name = L"Taal",
					text =
[[
7.6k, 52.7k
Interact with the little 'Wine in a Casket' on the ground near a copse of trees, in the RvR lakes, east from the Ruins of Greystone Keep BO. It's to the right of the fork in the road on the map.
]],
				},

				{
					name = L"Mannslieb and Morrslieb",
					text =
[[
16.3k, 55.8k
Interact with the 'Very Large Telescope' directly south of the Felde Castle - Empire Chapter 6, up on a partially crumbled section of wall. Hug the west side of the wall and stand partially on the rock to just slightly come within range of the telescope to use it.
]],
				},
				
			
			},
		},

		{
			name = L"Ostland",
			entries =
			{
				{
					name = L"Twin-tailed comets and other Omens",
					text =
[[
32.2k, 13.3k
Interact with the statue Sigmar 'Sigmar Wayshrine' at Wayshrine of Sigmar PQ.
]],
				},

				{
					name = L"Magnus the Pious",
					text =
[[
12.4k, 32.5k
Interact with a pile of books titled 'The Canonization of Magnus the Pious' . It's at the northeast of the Black Mire Bell Tower, Major Landmark. The pile of books is hidden behind a bush, oriented to the north. The bush is between one Shadow Cut-Throat and one Shadow Cutpurse.
]],
				},

				{
					name = L"Loathsome Rat Men",
					text =
[[
51.8k, 51.8k
Interact with the 'Dead Skaven' located under the bridge behind the grate just east of Wolfenburg Inn - Empire Chapter 9.
]],
				},

				{
					name = L"Favored of the Gods",
					text =
[[
31.6k, 11.4k 
Interact with the corpse of 'Dagny Betz' in the RvR lakes east of the Crypt of Weapons BO in the hills behind a tree with a another corpse hanging from it and a couple of other bodies surrounding it.
]],
				},

				{
					name = L"Dark Rites",
					text =
[[
17.8k, 21.1k
Interact with the 'Altar of the Scepter' in the Krul'Gor Herd PQ.
]],
				},

				{
					name = L"Wilderness",
					text =
[[
35.7k, 25.6k
Interact with an 'Empire Signpost' along the road east of Bohsenfels - Empire Chapter 8.
]],
				},

				{
					name = L"Khorne",
					text =
[[
6.7k, 58.9k
Interact with a 'Powder Barrel' near the ruined tent where Dieden Bloodmane spawns near the Gore Woods PQ.
]],
				},

				{
					name = L"Blood for the Blood God",
					text =
[[
10.5k, 55k
Interact with an 'Altar' near a big symbol of Khorne at the Gore Wood PQ. There is a gathering of cultists around the altar.
]],
				},

				{
					name = L"The Howling Vale",
					text =
[[
32.4k, 52.9k
Interact with the 'Dead Caravan Horse' by The Forest of Shadows, Major Landmark. In the middle of the Howling Vale PQ is a wrecked wagon surrounded by some Gor Raiders.
]],
				},

				{
					name = L"Forest Vipers",
					text =
[[
22.5k, 21k
Interact with the 'Butchered Livestock' easr of the Krul’Gor Herdstone, Major Landmark, in front of a house on a hill.
]],
				},
			},
		},

		{
			name = L"High Pass",
			entries =
			{
				{
					name = L"Doctor Zumwald",
					text =
[[
31.5k, 41.5k
Interact with a chest of 'Zumwald's Supplies' in the Shrine of Tzeentch PQ.
]],
				},

				{
					name = L"Temple of Change",
					text =
[[
26k, 48.6k
Interact with the 'Changer's All-Seeing Eye' inside the Temple of Change PQ.
]],
				},

				{
					name = L"Ranald",
					text =
[[
27k, 18.4k
Interact with a 'Bag of Dice' between two marauder corpses.
]],
				},

				{
					name = L"The Luminous Veil",
					text =
[[
62.4k, 37.7k
Interact with 'Blast Victim' near the Luminous Vale, Major Landmark.
]],
				},

				{
					name = L"Empire Steam Tank",
					text =
[[
9k, 56k
Proximity Area Unlock: Go near the steam tank in Raven's End - Empire Chapter 11, to achieve the unlock.
It is possible for Destruction to get this, but you need to enter the chapter camp from the RVR lake, hugging as far right as you can, and run directly to the tank. You will be killed by guards.
]],
				},

				{
					name = L"The Sigil of Malice",
					text =
[[
10.5k, 11.6k
Interact with the 'Bloody Sigil' on the ceiling at the center of the Temple of Heimkel PQ
]],
				},

				{
					name = L"Shallya",
					text =
[[
49.6k, 55.5k
Interact with a 'Plague Victim' inside the RvR lakes inside the fort of Hallenfurt Manor BO in the RvR lakes. 
]],
				},

				{
					name = L"Ogrund's Tavern",
					text =
[[
27.6k, 60.5k
Interact with the 'Tavern Door' of Ogrund's Tavern BO in the RvR Lakes.
]],
				},

				{
					name = L"Feiten's Lock",
					text =
[[
40k, 64k
Interact with the 'Milegate Door' of Feiten’s Lock BO in the RvR lakes.
]],
				},

				{
					name = L"Fort Marvik",
					text =
[[
4.6k, 56k
Interact with the 'Massive Bloodwrought Chain' inside Stoneclaw Castle.
]],
				},

				{
					name = L"Black Powder",
					text =
[[
 28k, 59k 
 Interact with a 'Black Powder Keg' behind Ogrund's Tavern BO in the RvR lakes.
]],
				},

				{
					name = L"Myrmidia",
					text =
[[
46.8k, 61.8k
Interact with a pile of books called 'On Warfare' against the outer wall of Hallenfurt Manor BO in the RvR lakes.
]],
				},

				{
					name = L"The Grand Conclave",
					text =
[[
51.7k, 63.7k
Interact with a scroll 'Letter to the Order of Luck' on the southeast side of Hallenfurt Manor BO. A dead horse and rider are nearby. The horse's head points to the scroll.
]],
				},

				{
					name = L"Verena",
					text =
[[
30.5k, 44.5k
Interact with the scroll 'Dietrich's Letter'. It's located to the southwest of the Shrine of Tzeentch PQ in a gully in the side of the hill.
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Exorcism",
					text =
[[
42.2k 56k
Interact with the chest 'Blair's Raiments' inside Bitter Woods - Empire Chapter 12.
]],
				},
				
				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Exorcism",
					text =
[[
 37.7k, 31.2k
 Interact with the 'Torture Stake' in Bloodmarr - Chaos Chapter 13.
]],
				},				
			},
		},

		{
			name = L"Talabecland",
			entries =
			{
				{
					name = L"Serpent Fang Bandits",
					text =
[[
3.8k, 19k
Interact with 'Far-Too-Lavish Pillows' in the large tent in the Serpent’s Fang Bandits PQ.
]],
				},

				{
					name = L"Slaanesh",
					text =
[[
14k 49.5k
Interact with the corpse 'Albert Calvert Sr.' at The Schuler Estate, Major Landmark.
]],
				},

				{
					name = L"Corruptor's Crown",
					text =
[[
39.6, 900
Interact with the 'Frozen Corpse' Enter the cave tunnel in RvR lake near Passwatch Castle.
]],
				},

				{
					name = L"Lady Kreuger",
					text =
[[
40.6k, 17.4k
Interact with 'Implement of Vanity' in the Kruegerhaus PQ at the very top of the building.
]],
				},

				{
					name = L"Verentane's Keep",
					text =
[[
28.9k, 7.9k
Interact with the 'Verentane's Tower Door' of the Verentane's Tower BO o the RvR lakes.
]],
				},

				{
					name = L"Dragonships",
					text =
[[
51k, 17.4k
Interact with 'Raider's Kindling' at Blackshore Landing, Major Landmark.
]],
				},

				{
					name = L"Necromancy",
					text =
[[
46k, 48.8k 
Interact with the coffin of 'Gosbert Troutman' underneath the Haunted Windmill.
]],
				},

				{
					name = L"Witch Hunts",
					text =
[[
24k, 28.4k
Interact with gravestone 'Here Lies Hester Prynne' in Suderheim cemetery.
]],
				},

				{
					name = L"Talabec River",
					text =
[[
18.2, 41.9k
Interact with 'Basket of Fish' on a boat at Unterbaum Docks, Major Landmark.
]],
				},

				{
					name = L"Woodsmen",
					text =
[[
13.2k, 8k
Interact with 'Basket of Apples' on the wagon in the Knightly Riders PQ.
]],
				},

				{
					name = L"Talabecland Thunder-Water",
					text =
[[
54.2k, 30k
Interact with the 'Tasty Beverage' (a bottle and wine glass) on the ground at next to two trees.
]],
				},

				{
					name = L"Longshanks",
					text =
[[
8k, 21.5k
Interact with 'Longshanks' corpse , south of Army of Faith PQ and Serpent's Fang Bandits PQ.
]],
				},

				{
					name = L"Rhya",
					text =
[[
41.8k, 39.8k
Interact with the 'Rest in Peace' tombstone at the Unterbaum Cemetery PQ.
]],
				},

				{
					name = L"Eye of the Beholder",
					text =
[[
32k, 23k
Interact with the barrel of 'Stirland Red', west of the Village Vermin PQ.
]],
				},

				{
					name = L"Moral Oppression",
					text =
[[
33k, 45.7k 
Interact with the 'Torture Stake' just west, outside of Unterbaum, Major Landmark.
]],
				},
			},
		},

		{
			name = L"Praag",
			entries =
			{
				{
					name = L"Kislev",
					text =
[[
38k, 25.9k
Click on 'Sergey Babyuk' hung from the side of the building.
]],
				},

				{
					name = L"The Steppes",
					text =
[[
25.9k, 3.9k 
Click on 'Broken Plow' half hidden in the bush.
]],
				},

				{
					name = L"Ungol Horsemen",
					text =
[[
8.9k, 19.1k
Click on 'Archery Target'.
]],
				},

				{
					name = L"Tor",
					text =
[[
10.8k, 3.1k
Click on 'A Treatise on the Gods', a book on the ground next to a brazier.
]],
				},

				{
					name = L"Warpwind Clan",
					text =
[[
4.2k, 64.5k
Click on 'Warpwind Clan Banner' inside the Skaven Tunnels (major landmark).
]],
				},

				{
					name = L"Vodka",
					text =
[[
17.3k, 42.8k
Click on 'Cup' on the steps of a small building.
]],
				},

				{
					name = L"Dazh",
					text =
[[
63.1k, 20.6k 
Click on 'Breath of Dazh', a brazier on the ground floor of Cinderash Tower (major landmark).
]],
				},

				{
					name = L"Gospodars",
					text =
[[
8.8k, 39.4k
Click on 'Sascha Makiev', a corpse up on a platform.
]],
				},

				{
					name = L"Winged Lancers",
					text =
[[
WEST PRAAG
52.2k, 51.5k
Click on 'Lancer's Horse'.
]],
				},

				{
					name = L"Ursun",
					text =
[[
63.5k, 31.9k
Click on 'Sacred Pelts' on the right as you enter Ursun's Den (major landmark).
]],
				},

				{
					name = L"Gryphon Legion",
					text =
[[
29.3k, 27.6k
Click on 'Banner of Praag' flying on the city wall.
]],
				},

				{
					name = L"The Ice Queen of Kislev",
					text =
[[
50.8k, 62.1k
Click on 'Kislevite Aid', a pile of sacks up against the large cart.
]],
				},

				{
					name = L"The Great War Against Chaos",
					text =
[[
WEST PRAAG
50.8k, 24.4k
Click on 'Sundered Memorial' on the ground, left of the steps to the small building.
]],
				},

				{
					name = L"Ice Magic",
					text =
[[
WEST PRAAG
28.3k, 37.9k
Click on 'Ice Conduit' on the right just as you enter Frostshard Prison.
]],
				},

				{
					name = L"The Cursed City",
					text =
[[
46.5k, 19.1k
Click on 'Daemon's Finger', a small rock spike at the base of the larger one.
]],
				},
			},
		},

		{
			name = L"Chaos Wastes",
			entries =
			{
				{
					name = L"Mutation",
					text =
[[
33.4k, 16.2k 
Click on 'Journal of Teppo Benzinger' under a couple of bushes, near 'Zimmeron's Hold' east postern.
]],
				},

				{
					name = L"Change Storms",
					text =
[[
55.9k, 3k 
Click on 'Forlorn Skull' on the ground at the base of the crucified Empire soldier.
]],
				},

				{
					name = L"Changing Terrain",
					text =
[[
33.8k, 35.3k 
Click on 'Ragnar Danneskjold', a corpse at the bottom of the ridgeline.
]],
				},

				{
					name = L"Tribal Rivalries",
					text =
[[
49.1k, 18.4k
Click on 'Tong Curr', a corpse around the back of the "Altar of Madness" PQ
]],
				},

				{
					name = L"The Lonely Tower",
					text =
[[
2.3k, 22.1k
Approach the steps leading to the tower door in 'Lonely Tower' PQ.
]],
				},

				{
					name = L"Monoliths",
					text =
[[
46.9k, 46.5k 
Click on 'Chaotic Writings' just east of "The Shrine of Time" BO, behind the broken wall.
]],
				},

				{
					name = L"Grimclan",
					text =
[[
12.4k, 53.8k 
Click on 'Grimclan Banner' just on the outside of the outer ring of teeth/spikes.
]],
				},

				{
					name = L"Grimnir's Journey",
					text =
[[
31.1k, 2.4k
Click on 'Grimnir's Axe' on the hill north of 'Chokethorn Bramble' BO. You must go into The Maw to climb up to it.
Note: I was not able to find where this axe was.
]],
				},

				{
					name = L"Soul Gem",
					text =
[[
15.7k, 56.3k
Click on 'Altera's Scribbles', a book a short distance from the front of the ruined house on the edge of the ridge.
]],
				},

				{
					name = L"Corruption",
					text =
[[
10.9k, 16.7k
Click on 'Local Flora', a large mutant plant south of the road.
]],
				},

				{
					name = L"Teef",
					text =
[[
46.9k, 4.1k 
Click on 'Grobbag's Teef' on the north side of the road, next to a dead bush.
]],
				},

				{
					name = L"Gifts of the Gods",
					text =
[[
48k, 43.3k 
Click on 'Destroyed Desk' inside the south tent in the camp.
]],
				},

				{
					name = L"Rise of a Champion",
					text =
[[
29.2k, 46.5k
Click on 'Champion's Tribute', a brazier next to the huge statue head southeast of 'The Statue of the Everchosen' BO.
]],
				},

				{
					name = L"The Hill of the Dead",
					text =
[[
25.5k, 39.5k
Walk up to the monument
]],
				},

				{
					name = L"Daemon Weapon",
					text =
[[
???
]],
				},
			},
		},

		{
			name = L"Reikland",
			entries =
			{
				{
					name = L"The Reiksguard",
					text =
[[
25.9k, 52k 
Click on 'Reiksguard Guide' next to the fenced tomb.
]],
				},

				{
					name = L"The River Reik",
					text =
[[
29k, 48k
Ride over the bridge.
]],
				},

				{
					name = L"Slaves to Fashion",
					text =
[[
49.7k, 63.9k 
Click on 'Empire Couture', a rock with a couple of ragged clothes lying on it.
]],
				},

				{
					name = L"Shallya",
					text =
[[
57.7k, 10.3k
Click on 'Pilgrim's Bedroll' behind the tent.
]],
				},

				{
					name = L"Reikflies",
					text =
[[
53k, 51.5k
Click on 'Barrel of Ale', on the outside of the walls.
]],
				},

        {
          name = L"Agitators",
          text =
[[
6.2k, 9.1k
Click on 'Soap Box', on the steps up to a house in the Castle Grauenburg PQ area.
]],
        },

				{
					name = L"Abject Poverty",
					text =
[[
11k, 16.3k
Click on 'Raven Ward' between two of the houses.
]],
				},

				{
					name = L"Celestial College",
					text =
[[
28.7k, 26.9k 
Click on 'Dwarven Refractory Contraption' just west of Wilhelm's Fist main keep.
]],
				},

				{
					name = L"Reik River Bandits",
					text =
[[
6.7k, 27.9k 
Click on 'Bag of Gold' on the east side of the tent.
]],
				},

				{
					name = L"Reikland Blackswords",
					text =
[[
40.6k, 20.7k
Click on 'Company Ledger' on the table inside the tent.
]],
				},

				{
					name = L"Morr's Maze",
					text =
[[
63.1k, 36.2k 
Click on 'Crypt Gate', the entrance gates to "Morr's Maze" major landmark.
]],
				},

				{
					name = L"Hedge Wizards",
					text =
[[
33.2k, 23k
Click on 'Stolen Wizard's Notes', a pile of burning scrolls on the ledge east of Wilhelm's Fist main gate.
]],
				},

				{
					name = L"Detachments",
					text =
[[
47.9k, 60.3k 
Click on 'Nuln Cannonballs' next to the three cannons looking down the hill.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"The Jade Order",
					text =
[[
11.6k, 35.9k
Kill 'Conrad Groenfeld' sitting by a large tree just east of "Kreuznach" (Empire Chapter 15).
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"The Jade Order",
					text =
[[
11.6k, 35.9k
Talk to 'Conrad Groenfeld' sitting by a large tree just east of "Kreuznach" (Empire Chapter 15).
]],
				},
				
				{
					name = L"Tilea",
					text =
[[
46.6k, 28.6k
Click on 'Man O'War', a dead horse just at the south end of the bridge.
]],
				},
			},
		},

		{
			name = L"Altdorf",
			entries =
			{
				{
					name = L"The Altdorf Docks",
					text =
[[
33.8k 31.5k
Enter the Docks.
]],
				},

				{
					name = L"Ol' Knuckles' Ring",
					text =
[[
31.7k 28.1k
Approach the two men fighting on the docks, north of the Blowhole Tavern.
]],
				},

				{
					name = L"Pale-Eye Hideout",
					text =
[[
34.6k 32.1k
Talk to 'Gahela Coppermane' (female dwarf) just outside the Port Authority in the Docks.
]],
				},

				{
					name = L"The Sewers of Altdorf",
					text =
[[
34.5k 40.6k
Right click on the Slain City Guard as you first enter the South Sewer.
]],
				},

				{
					name = L"The Blowhole Tavern",
					text =
[[
30.9k 28.6k
Enter The Blowhole, located on far north side of the docks.
]],
				},

				{
					name = L"The Cult of the Feathered Coin",
					text =
[[
19.4k 34k
To the north of the Temple of Sigmar, keep going north until you see a fence gate in front of you and a beggar to the left, turn right and go into the small alley.
]],
				},

				{
					name = L"The City Guard",
					text =
[[
Talk to any City Guard NPC (Found at any Sewers Entrance)
]],
				},

				{
					name = L"The First Bank of Altdorf",
					text =
[[
21k 38.5k
Approach the First Bank of Altdorf entrance.
]],
				},

				{
					name = L"The Emperor's Palace",
					text =
[[
Unlocks when you first fly into Altdorf.
]],
				},

				{
					name = L"The Temple of Sigmar",
					text =
[[
16.5k 38.3k
Enter the Temple of Sigmar.
]],
				},

				{
					name = L"The Reikland Arms",
					text =
[[
20k 38.4k
Enter the Reikland Arms, across from the First Bank of Altdorf.
]],
				},

				{
					name = L"The Clank",
					text =
[[
23.4k 41.8k
Enter The Clank.
]],
				},

				{
					name = L"Aqshy Fountain",
					text =
[[
32k 34.4k
Click on the Aqshy conduit located within the Bright Wizard College, at the very top.
]],
				},

				{	
					name = L"The Slums",
					text =
[[
28.5k 34.5k
Enter the Slums.
]],
				},

				{
					name = L"Lord's Row",
					text =
[[
20.6k 37.2k
Enter the Lord's Row.
]],
				},

				{
					name = L"War Quarters",
					text =
[[
Enter the War Quarters
]],
				},

				{
					name = L"Legacy of the Emperors",
					text =
[[
25.7k 30.5k
Click on the 'Old Empire Standard' in front of the Emperor's Palace. It looks like a red standard pinned to the wall on the right side of the 2nd doorway to the Palace from the Marketplace.
]],
				},

				{
					name = L"The Bright College",
					text =
[[
32k 34.4k 
Enter the Bright College.
]],
				},

				{
					name = L"Market Square",
					text =
[[
25.6k 33.6k 
Enter the Market Square.
]],
				},

				{
					name = L"Goradian's Fall",
					text =
[[
31k 36k
Enter the Sewers. Find the room with Goradian The Creator, he's a level 20 Hero. There is a 'Well worn book' on the floor, at the corner on the right before the entrance to his room. Click on it to get the unlock.
]],
				},
			},
		},

		{
			name = L"The Inevitable City",
			entries =
			{
				{
					name = L"The Sacellum",
					text =
[[
41.7k 34.4k 
Approach The Sacellum.
]],
				},

				{
					name = L"The Holding Pits",
					text =
[[
Kill the Hero 'Malghar Ragehorn' in the Sacellum Dungeon East Wing. He can be found behind the first set of gates on the right as you go into the East Wing.
]],
				},

				{
					name = L"The Cult of the Plaguesworn",
					text =
[[
50.2k 35.7k
Talk to 'Shargra Glutmire' in Fleshrot Alley standing inside. There is a 'Plague Cauldron' with 2 'Plague Disciples' next to the entrance.
]],
				},

				{
					name = L"The Bloodfiends",
					text =
[[
40.4k 40.7k
Interact with the 'Mark of Khorne' above the door south of the Sacellum. It is in the archway.
]],
				},

				{
					name = L"The Battle for the Herdstone",
					text =
[[
35.6k 36k
Stand next to the Herdstone.
]],
				},

				{
					name = L"The Temple of the Damned",
					text =
[[
37k 38.8k
Kill Sovek the Merciless inside the temple.
Note: It should be provided during the Public Quest in The Lost Narrows.
]],
				},

				{
					name = L"The Lost Narrows",
					text =
[[
34.5k 40.5k
Enter The Lost Narrows.
]],
				},

				{
					name = L"The Apex",
					text =
[[
30.4k 37.3k
Approach The Apex.
]],
				},

				{
					name = L"Soul Vaults",
					text =
[[
27.8k 43.3k
Stand near the banker.
]],
				},

				{
					name = L"The Eternal Citadel",
					text =
[[
30.8k 24.4k
Approach The Eternal Citadel.
]],
				},

				{
					name = L"The Scrying Vats",
					text =
[[
28.6k 36.7k
Right click the Image of the Emperor.
]],
				},

				{
					name = L"Journey's End",
					text =
[[
22k 44.3k
Interact with the skeleton of 'Agder Rotwing' at the end of Dread Way.
]],
				},

				{
					name = L"The Price of Knowledge",
					text =
[[
18.2k 34.6k
Interact with the pile of books 'Treatise of Dire Caution' in The Lyceum.
]],
				},

				{
					name = L"The Foreboding Lyceum",
					text =
[[
14.7k 37.1k
Talk to 'Disciple Everdamned', located in the upper left wing of the Lyceum.
]],
				},

				{
					name = L"The Monolith",
					text =
[[
22.6k 37.1k
Approach the Monolith, as you near it you'll receive this unlock.
]],
				},

				{
					name = L"The Sentries",
					text =
[[
Talk to a Dread Sentry.
]],
				},

				{
					name = L"Fate's Edge",
					text =
[[
28k 32k
Approach Fate's Edge, the zone around flight master.
]],
				},

				{
					name = L"Dhar'ek Cores",
					text =
[[
36k, 33k
Right click the Dhar'ek Core
]],
				},

				{
					name = L"Imbalance of Power",
					text =
[[
32.5k 27.8k
Kill the bird 'Blue Speckled Crow' outside of The Viper Pit.
]],
				},

				{
					name = L"The Watchers",
					text =
[[
30.4k 42.3k
Unlocked by walking towards The Journey's End.
]],
				},
			},
		},
	},
}

