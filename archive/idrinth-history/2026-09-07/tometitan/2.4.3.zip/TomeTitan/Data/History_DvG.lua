TTitan.Data.HistoryDvG = {}

function TTitan.Data.HistoryDvG.GetData()
	return TTitan.Data.HistoryDvG.RawData
end

function TTitan.Data.HistoryDvG.FilterData()
	TTitan.Data.FilterByRealm(TTitan.Data.HistoryDvG.RawData)
end

TTitan.Data.HistoryDvG.RawData =
{
	header = L"History & Lore Unlocks - Dwarfs vs Greenskins",
	categories =
	{
		{
			name = L"Ekrund",
			entries =
			{
				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Gold",
					text =
[[
15.3k, 45.1k
Interact with the ‘Gold Nugget’ at the mouth of the middle tunnel in the "Stonemane's Junction" major landmark. Right next to the tipped mine cart.
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Gold",
					text =
[[
64k, 57.6k
Interact with ‘Goldfist's Gold’ at south end of Goldfist's Tomb.
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Reclaiming Ekrund",
					text =
[[
19.6k, 46.9k
Interact with the ‘Commemorative Plaque’ in the middle of the wall with the 4 golden gates, directly behind the Mordrin’s Anvil - Dwarf Chapter 1 Kill Collector.
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Reclaiming Ekrund",
					text =
[[
52k, 39.4k
Interact with the ‘Royal Mining Corps’ banner in Goldfist's Hole Recovery PQ.
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Helga",
					text =
[[
24.8k, 38.5k
Interact with ‘Helga’ the giant cannon at the top of the dwarven starting area, which looks out to the NE.
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Helga",
					text =
[[
54k, 37k
Interact with the ‘Railgun Ammo Mold’.
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Oathbearers",
					text =
[[
21.5k, 40k
Talk to any ‘Oathbearer Keeper’ in Mordrin’s Anvil, Dwarf Chapter 1.
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Oathbearers",
					text =
[[
48k, 34k
Kill an ‘Oathbearer Ranger’ by Redhammer Brewery.
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Grudges",
					text =
[[
20.8k, 41.2k
Interact with the ‘Grudge Book’ on a bench round a large stone column, the bench faces to the archway leaving Mordrin’s Anvil, Dwarf Chapter 1.
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Grudges",
					text =
[[
60k, 38.9k
Interact with the ‘Slain Irontoe’ inside Gorgor’s Smash - Greenskin Chapter 4, behind a hut
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"The Pick & Goggles",
					text =
[[
21.9k, 39.6k
Area Proximity Unlock: Enter the ‘Picks & Goggles’ tavern, a major landmark in the dwarven starting area.
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"The Pick & Goggles",
					text =
[[
42.5k, 40.9k
Interact with the ‘Looted Stein’ in Raider's Haven PQ
]],
				},

				{
					name = L"Rune Magic",
					text =
[[
53.1k, 49.7k 
Interact with the ‘Book of Runes’ next to a dead dwarf skeleton up the first part of the ramp, inside the tower.
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Cannons",
					text =
[[
23.2k, 41.5k - Quest start location
Talk to "Tharik Redaxe" and take the quest "Oathbearers". Complete this first stage and then return to "Tharik Reaxe" for the follow up quest "Filth in the Rough", once you have this you can then click on ‘Crate of Cannonballs’ a short distance away just up the stairs for the unlock.
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Cannons",
					text =
[[
54.5k, 4.4k
Interact with the ‘Cannonballs in RvR lake among some cannons and crates.
]],
				},

				{
					name = L"Ancestor Worship",
					text =
[[
64.1k, 19.5k
Interact with the ‘Ancestral Statue’ a large dwarven statue covered in orc mess, just off to the left-hand side of the road as you head towards Mount Bloodhorn.
]],
				},

				{
					name = L"Durak Bitterstone",
					text =
[[
44.5k, 21.1k
Area Proximity Unlock: Approach the dwarven structure at the top of Durak's Gate PQ. The trigger area is very tight, so hug the walls around the structure to get it to unlock.
]],
				},
			},
		},

		{
			name = L"Mount Bloodhorn",
			entries =
			{
				{
					name = L"Waaagh!",
					text =
[[
33.7k 27.7k
Interact with the ‘Orc Corpse’ under bridge at Komar - Dwarf - Chapter 3 Camp.
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Simple Minds",
					text =
[[
46.9k 57.1k
Interact with the 'Observation Point', a telescope. This is accessible by climbing mountains (there is a way starting at 46k 53k, then climb). Note: It is possible to reach it using lobbers of Lobber Hill (36k 51k), which make you fly to the Stunty Mountain.
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Simple Minds",
					text =
[[
45.8k, 34,8k
Interact with the 'Observation Point', a telescope, near Gran Thewn Watch, Major Landmark.
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Bloody Sun Boyz",
					text =
[[
41.7k 52.3k
Interact with the 'Bloody Sun Banner' next to 'Skarzag', the Orc on the Wyvern, at Skarzag’s Stompin’ Grounds - Greenskin Chapter 1. If you can not interact with it, take the quest 'Two Can Play at Dat' from 'Scribbiz' goblin in front of the banner.
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Bloody Sun Boyz",
					text =
[[
45.4, 44.1k
Interact with the 'Bloody Sun Banner' in the Bloody Sun Camp, Major Landmark.
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Choppas",
					text =
[[
32k, 47.5k
Interact with a dead dwarf corpse 'Stunty Chopped Gud' in the woods north of 'Snout's Pens' Major Landmark.
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Choppas",
					text =
[[
Kill an ‘Invada Boy’ at Forgehand's Workshop, Major Landmark.
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Ironmane's Lock",
					text =
[[
40.8k, 61k
Interact with the 'Memorial Plaque' in the Stunty Mountain area. It is possible to access there through mountains, then reach the road where the 'Observation Point' for H&L 'Simple Minds' is (see above). The plaque can be found on a lower right-hand side of the northern wall with the marooned ship's brow facing toward it.
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Ironmane's Lock",
					text =
[[
30.4k, 41.4k
Interact with the 'Ironclad Oil'.
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Greenskin Technology",
					text =
[[
12.3k, 51.5k
Talk to the ‘Siege Git’ between the Siege Towers near the Da War Maker - Greenskin Chapter 2 Camp.
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Greenskin Technology",
					text =
[[
12.3k, 51.5k
Kill to the ‘Siege Git’ between the Siege Towers near the Da War Maker - Greenskin Chapter 2 Camp.
]],
				},

				{
					name = L"Da War Maka",
					text =
[[
18.2k, 54.1k - 
Interact with the 'Orc Corpse' below the north-facing blade of 'Da War Maka' in Da War Maker - Greenskin Chapter 2 Camp.
Note for Order: Be really prudent with the Destruction Champion Guards. It is possible to reach and interact with 'Orc Corpse' but you will most likely die in the process.
]],
				},

				{
					name = L"Rock Lobbers",
					text =
[[
16.6k, 39.2k
Interact with the ‘Rock Lobber’ inside Ironclaw Camp PQ.
]],
				},

				{
					name = L"Greenskin Food",
					text =
[[
38.9k 38.9k
Interact with a 'Dinner Scraps' at the Marghaz Bloodtoof Ritual PQ, inside in a hut, on the top of a small hill just after you cross the bridge.
]],
				},

				{
					name = L"Dragonbone Pass",
					text =
[[
42.6,23.5k
Interact with ‘Drakk Bone’.
]],
				},
			},
		},

		{
			name = L"Barak Varr",
			entries =
			{
				{
					name = L"Long Drong and his Slayer Pirates",
					text =
[[
6k, 45.6k
Interact with a barrel of ale, labeled 'Rarest Ale', washed up on the beaches by The Seas Anvil, Major Landmark.
]],
				},

				{
					name = L"Sacred Oaths",
					text =
[[
37.3k, 46k
Area Proximity Unlock: Enter the destroyed dwarf tower surrounded by greenskins, just southwest of Foultooth’s Warcamp.
]],
				},

				{
					name = L"Waaagh! Magic",
					text =
[[
41k, 51k 
Interact with the 'Orc Remains' among the trees and Bloodtusk Warsnouts in Barak Weald.
]],
				},

				{
					name = L"Size Matters",
					text =
[[
6.3k, 26.6k
Area Proximity unlock: Walk on the broken Dwarf statue near the entrance of Wetfang Cave.
]],
				},

				{
					name = L"Greenskin Battle Barges",
					text =
[[
16.2k, 27k
Area Proximity unlock: Approach the docked Greenskin barge filled with River Rat Champions.
]],
				},

				{
					name = L"One Tusk Tribe",
					text =
[[
4.7k, 30k
Interact with the ‘Bloody Sun Goblin’, a goblin head on a spear, by the sign post west of Nogaz’s Boyz - Greenskin Chapter 5.
]],
				},

				{
					name = L"Overlook Bridge",
					text =
[[
46.4k, 25k
Interact with the ‘Harbor master’s Spyglass’ by the great bridge in the underground Port of Barak Varr (inside the mountain) through Longbeard's Strand, Major Landmark, in the RvR Lakes.
]],
				},

				{
					name = L"Tribal Assimilation",
					text =
[[
33.3k, 19k
Interact with the 'Fallen Banner' on the Black Strand beach. Be sure to be in the target circle of the banner when you click on it.
]],
				},

				{
					name = L"Ironclads",
					text =
[[
27.8k, 29k
Area Proximity unlock: Reach the sunken Ironclad.
]],
				},

				{
					name = L"Leviathan",
					text =
[[
35.6k, 34.5k
Interact with the ‘Sunbaked Vertebrae’ on the beach in the RvR zone between Dok Karaz and The Ironclad BO.
]],
				},
			},
		},

		{
			name = L"Marshes of Madness",
			entries =
			{
				{
					name = L"Oathgold",
					text =
[[
50.5k 8.3k 
Interact with the chest 'Oathgold', northwest of Reekmarsh Camp - Dwarf Chapter 8 camp.
]],
				},

				{
					name = L"The Mourkain",
					text =
[[
9.7k 28.8k 
Area Proximity Unlock: Walk up to an arch near Foul Ruins PQ.
]],
				},

				{
					name = L"Who's Da Boss?",
					text =
[[
14k, 21k 
Interact with ‘Trophy Teef’.
]],
				},

				{
					name = L"The World's Best Miners",
					text =
[[
61.8k, 52.6k
Interact with the 'Mining Tools', a little hidden just on the other side of a pile of logs outside the entrance to Falcon's Tomb. The tomb is at the southeastern explorable corner of the map.
]],
				},

				{
					name = L"Nebhorest, the Vampire Lord",
					text =
[[
29k, 21k 
Interact with a ‘Grim Warning’, one of four crucified Dwarf skeletons near the fork in the road North of Morth’s Mire - Greenskin Warcamp.
]],
				},

				{
					name = L"The Marsh Road",
					text =
[[
12.5k, 7k 
Interact with the ‘Marsh Skeleton’ near Murdogh’s Hold - Dwarf Chapter 6 Camp.
]],
				},

				{
					name = L"The Black Skulls",
					text =
[[
27k, 11k
Talk to Hargruk in 'Hargruk's Camp', Major Landmark.
]],
				},

				{
					name = L"Vital Supplies",
					text =
[[
32k, 57.3k
Interact with crate 'Stolen Supplies'Interact with crate 'Stolen Supplies' on the island of the large swamp in the Fetid Bog.
]],
				},

				{
					name = L"The Price of Knowledge",
					text =
[[
3.1k, 31.5k 
Interact with ‘Leopold Schaeffer’, inside 'Dawr Galaz Grung' cave.
]],
				},

				{
					name = L"Greenskin Stupidity",
					text =
[[
56.7k, 52.7k
Interact with the 'Really Empty Barrel' near some ghouls and pieces of a broken bridge.
]],
				},
			},
		},

		{
			name = L"The Badlands",
			entries =
			{
				{
					name = L"Animosity",
					text =
[[
52.5k, 39.1k
Area Proximity Unlock: Ride across the bridge northeast of Muggar's Choppaz - Greenskin Warcamp.
Note: Must be ON the bridge, will not unlock under
]],
				},

				{
					name = L"The Cauldron",
					text =
[[
4k, 28k 
Area Proximity Unlock: Walk near the cauldron up in the hills in the The Cauldron PQ area.
This one took me a while to unlock. I had to run around it and through it. 
]],
				},

				{
					name = L"Likwid Courage",
					text =
[[
MOUNT GUNBAD
25.3k, 42.3k
Area Proximity Unlock: Walk on the Giant Cauldron in the Goblin Alchemy boss area in the West Wing.
]],
				},

				{
					name = L"Gork and Mork",
					text =
[[
43.7k, 25.3k 
Interact with ‘Gork’nMork’s Fings’ at the base of the totem overlooking Skullbreak Ridge PQ.
]],
				},

				{
					name = L"Blue Face Orcs",
					text =
[[
9k, 33k
Interact with the ‘Savage Corpse’ in the pit of the Savage Assault PQ.
]],
				},

				{
					name = L"Tribal Culture",
					text =
[[
47.2k, 8.8k
Area Proximity Unlock: Walk near the Ork camp in Bloodgash Ravine, Major Landmark, to get the unlock.
]],
				},

				{
					name = L"Moonfang Tribe",
					text =
[[
12k, 9k
Interact with the ‘Moonfang Banner’ in the Revoltin' Gobbos PQ.
]],
				},

				{
					name = L"Red Eye Tribe",
					text =
[[
MOUNT GUNBAD
31.7k, 30k 
Interact with the crate of ‘Goblin Supplies’ in the lobby next to the portal.
]],
				},

				{
					name = L"Da Little Waaagh!",
					text =
[[
10.5k, 4.4k 
Interact with a 'Goblin Map' that can be found on a table next to a hut on the hill in the Night Goblin village outside Mount Gunbad at the Revoltin' Gobbos PQ.
]],
				},

				{
					name = L"Brightstone",
					text =
[[
26k, 32.2k
Interact with the ‘Brightstone Deposit’ at the entrance to the west wing.
]],
				},

				{
					name = L"Dragon's Gut",
					text =
[[
22.4k, 54.9k
Interact with the Dwarf corpse 'Gruber's Remains' in RvR zone, northwest of the Goblin Artillery Range BO, under the skeleton of the dragon.
]],
				},

				{
					name = L"Warpstone",
					text =
[[
4.7k, 31k
Interact with the 'Skaven Corpse' on the ground among the 'Fallen Ranger' (dwarf corpses) and Caldera Bonegnawer rats, under a broken arch.
]],
				},

				{
					name = L"Phineas Fireforge",
					text =
[[
4k, 28.8k 
Interact with a 'Rusty Scrollcase' on the ground behind a wall. The scrollcase is very small and half hidden in the ground. If you jump down from the higher plateau of The Cauldron PQ, it's the first wall on the right hand side.
]],
				},

				{
					name = L"Warpaint",
					text =
[[
3.5k, 37k 
Interact with the 'Table of Supplies' inside a hut in the west of Norrikson’s Excavation - Dwarf Chapter 10 camp.
]],
				},

				{
					name = L"Bloodspike Mesa",
					text =
[[
7.3k, 16.2k
Interact with ‘Slain Oathbearer’ on the steps of the Greenskin lookout tower.
]],
				},
			},
		},

		{
			name = L"Black Fire Pass",
			entries =
			{
				{
					name = L"Beer",
					text =
[[
48k, 58.9k
Interact with the 'Keg of Beer' at the corner of a ruined tower inside Proudrock - Dwarf Chapter 12.
Note For Destruction: It is obtainable. Start climbing around 51.5k, 57k, head to the ruined tower following the northwest side of the hill. Follow the north wall of the tower, then turn left and you will see the keg.
]],
				},

				{
					name = L"Battle of Black Fire Pass",
					text =
[[
44k, 20k 
Area Proximity Unlock: Enter the tower at Ancient's Reach, Major Landmark.
]],
				},

				{
					name = L"The Oath between Men and Dwarfs",
					text =
[[
5.9k, 22.2k 
Interact with the 'Plunger' at the end of the cave 'Orehound's Lament', Major Landmark. in RvR lake.
]],
				},

				{
					name = L"Bugman's Brewery",
					text =
[[
25k, 19k
Interact with the 'Long Forgotten Tools' behind the Bugman's Brewery BO in the RvR lake next to the ramp.
]],
				},

				{
					name = L"Dwarf Craftsmanship",
					text =
[[
5.5k, 57k
Interact with the 'Dwarf Anvil' the Tharadrik Smashin' PQ behind one of the buildings.
]],
				},

				{
					name = L"Sisters of Shallya",
					text =
[[
55k, 57k 
Interact with the crate of 'Medicine' to the right of the Hindelburg PQ entrance gate.
]],
				},

				{
					name = L"Dwarf Trains",
					text =
[[
23k, 42k 
Interact with the book 'Manual for New Engineers' on top of the tower at the Grimbeard Station PQ.
]],
				},

				{
					name = L"Ghal Maraz",
					text =
[[
40k, 5.7k 
Area Proximity Unlock: Approach the giant statue that is part of the mountainside at.
]],
				},

				{
					name = L"Worlds Edge Mountains",
					text =
[[
1.2k, 4.6k 
Area Proximity Unlock: Approach the gate in the upper northwest area of the RvR lake.
]],
				},

				{
					name = L"The Time of Woes",
					text =
[[
46.4k, 13.5k 
Area Proximity Unlock: Approach the dwarven statue guarded by a small company of Kazdor Dwarfs.
]],
				},

				{
					name = L"The Path of Sigmar - Part One",
					text =
[[
14k, 44k
Interact with 'Roadside Plaque' up the road behind the Snow Peak Temple, Major Landmark.
Note: The road begins behind the temple at 14.7k, 40.8k
]],
				},

				{
					name = L"The Path of Sigmar - Part Two",
					text =
[[
10.3k, 41.7k
Continue the road from Part 1. A few corners later in front of an angel statue, interact with another 'Roadside Plaque'.
]],
				},

				{
					name = L"The Path of Sigmar - Part Three",
					text =
[[
4.5k, 47k 
Keep following the road from Part 2. On your right side slightly upwards near another Statue of Sigmar, this one is not in a wooden shrine. Interact with another 'Roadside Plaque'.
]],
				},

				{
					name = L"The Path of Sigmar - Part Four",
					text =
[[
2k, 34.5k 
Follow the road from Part 3. you'll come to an open spot. You'll see a wooden fence on the left. The new 'Roadside Plaque' is on the right side near some stones.
]],
				},

				{
					name = L"The Path of Sigmar - Conclusion",
					text =
[[
1.5k, 29k
Continue following the road from Part 4 up through the mist all the way up the mountain. At the top right in front of the big Statue of Sigmar and 2 angel statues, you'll find the last 'Roadside Plaque'. Interact with it to gain the unlock.
]],
				},
			},
		},

		{
			name = L"Thunder Mountain",
			entries =
			{
				{
					name = L"Hurgan's Vent",
					text =
[[
10.2k, 18.3k
Cross the bridge over the lava.

]],
				},

				{
					name = L"The Final Grudge of Drangin Ironboots",
					text =
[[
40.3k, 55.1k
Click on "Drangin Ironboots" on the stone spike jutting out south over the lava lake, just east from "Mudja's Warcamp".

]],
				},

				{
					name = L"The Long Defeat",
					text =
[[
12.3k, 36.8k 
Click on "Destroyed Wagon" under the bridge.

]],
				},

				{
					name = L"Last Stand at Karak Palik",
					text =
[[
23.4k, 43.3k 
Click on "Slain Defender" behind the wall, on the southwest side of "Karak Palik" BO.

]],
				},

				{
					name = L"Und-a-Runki Book of Grudges",
					text =
[[
3k, 62.8k 
Click on "Book of Grudges" inside "Und-a-Runki" PQ. Straight ahead as you enter, on some crates by the right statue.

]],
				},

				{
					name = L"Ash Crawler Victims",
					text =
[[
15.3k, 55k
Click on "Pile of Skulls" to the side of the path.

]],
				},

				{
					name = L"Sons of Valaya",
					text =
[[
62k, 6.2k
Enter the building at the far east of the "Sons Of Valaya" PQ.

]],
				},

				{
					name = L"The Golden Lumps",
					text =
[[
17.6k, 49.3k
Click on "Golden Lumps" on the edge of the lava.

]],
				},

				{
					name = L"Reichert's Red Raiders",
					text =
[[
5.2k, 12.8k 
Click on "Ill-Gotten Goods", a chest inside the southwest tent.

]],
				},

				{
					name = L"The Throng of Karaz-a-Karak",
					text =
[[
47.8k, 14.7k 
Click on "Remnant of Battle" on top of the broken piece of wall, just north of the main road.

]],
				},

				{
					name = L"View from the Top",
					text =
[[
25.7k, 1k
Click on "Congratulatory Plaque" on top of the mountain. Can start the climb from the road at 10k, 1k.

]],
				},

				{
					name = L"The Bone Field",
					text =
[[
50k, 8.5k
Click on "Fertilizer", a skeletal arm on the ground, close to the obelisk.

]],
				},
			},
		},

		{
			name = L"Cinderfall",
			entries =
			{
				{
					name = L"Built to Last",
					text =
[[
CINDERFALL
38.9k, 48.8k
Click on "Pressurized Steam Vat", inside an unmarked cave that opens out into a dwarf hall, just at the top of the big ramp on the left side.
]],
				},
			},
		},

		{
			name = L"Death Peak",
			entries =
			{
				{
					name = L"Not Much Grows Here",
					text =
[[
DEATH PEAK
15k, 59.2k
Click on "Ashen Bramble" just south of the path.
]],
				},

				{
					name = L"Runelords",
					text =
[[
DEATH PEAK
6.3k, 10.1k
Click on "Ancient Anvil" at "Sinar Orcstom" major landmark.
]],
				},
			},
		},

		{
			name = L"Kadrin Valley",
			entries =
			{
				{
					name = L"Karak Ankor",
					text =
[[
58.1k, 11.9k 
Click on "Gold Chest" in the back right corner of the second hut as you enter on the south side (right).

]],
				},

				{
					name = L"Grimnir",
					text =
[[
26.1k, 10.6k
Click on "Shrine" the door into the "Shrine of Grimnir" major landmark.

]],
				},

				{
					name = L"Valaya",
					text =
[[
4.9k, 43.6k
Click on "Prayer Book" inside the west side house, inside "Gates of Grung Grimaz" PQ.

]],
				},

				{
					name = L"Grungni",
					text =
[[
43.4k, 59.4k
Click on "Mine Barrow" just at the front of "Kloingar Mine" major landmark, next to a pile of beams.

]],
				},

				{
					name = L"The King's Flying Corps",
					text =
[[
52.7k, 31.4k
Approach the Gyrocopter on the pad, south of the "Slayer Keep" major landmark.

]],
				},

				{
					name = L"Dwarf Engineers",
					text =
[[
7.6k, 44.1k 
Click on "Dwarf Corpse" on the platform next to the broken gyrocopter, inside "Gates of Grung Grimaz" PQ.

]],
				},

				{
					name = L"The Slayer Oath",
					text =
[[
42.3k, 4.3k
Click on "Bottles", on the first left-hand side outside the table.

]],
				},

				{
					name = L"Ghavrin's Brace",
					text =
[[
58.9k, 11.3k 
Approach the statue in the middle of the walled area.

]],
				},

				{
					name = L"Karak Kadrin",
					text =
[[
54.4k, 25.7k 
Click on "Slayer Keep" door at the entrance to "Slayer Keep" major landmark.

]],
				},

				{
					name = L"Flame Cannons",
					text =
[[
34.5k, 32.0k 
Click on "Flame Cannon" in the corner of the wall.

]],
				},

				{
					name = L"Peak Pass",
					text =
[[
57.4k, 2.6k 
Enter "Everpeak Mine" major landmark.

]],
				},

				{
					name = L"Gyrocopters",
					text =
[[
58.7k, 43.0k 
Approach the Gyrocopter on the pad.

]],
				},

				{
					name = L"The Slayer Heirarchy",
					text =
[[
46.6k, 36.0k 
Click on "Brugi" a corpse on a rock.

]],
				},

				{
					name = L"Dogs of War",
					text =
[[
60.7k, 59.3k
Click on "Chest" in the middle one of the five smaller buildings at the back, on the right-hand side as you go in.

]],
				},

				{
					name = L"Organ Guns",
					text =
[[
34.4k, 40.7k 
Click on "Deceased Gunner" next to the destroyed organ gun.

]],
				},
			},
		},

		{
			name = L"Black Crag",
			entries =
			{
				{
					name = L"Morkfang and Grimgork",
					text =
[[
11.7k, 28.8k
Walk on the platform with the three barrels and the crane. The trigger is very small on or around the patch of dirt.
]],
				},

				{
					name = L"Squigger",
					text =
[[
17.9k, 36.4k
Click on "Orc Banner" west of Greenskin chapter 15 camp.
]],
				},

				{
					name = L"Frenzy",
					text =
[[
50.7k, 12.8k
Click on "Orc Corpse" on the south side of the road under a bush, south of Dwarf Chapter 20.
]],
				},

				{
					name = L"Vandalism",
					text =
[[
46.1k, 44.5k
Click on "Vandalized Statue" up against the rock.
]],
				},

				{
					name = L"Effigies and Totems",
					text =
[[
16.0k, 10.2k 
Click on "Gork'n'Mork Totem" on the North edge of the canyons.
]],
				},

				{
					name = L"The Throngmortar of Sturlin Thunderhelm",
					text =
[[
20.1k, 19.3k 
Click on "Charred skull" amongst a small group of rocks, west of Ironskin Skar keep, near the bottom of the cliff.
]],
				},

				{
					name = L"The Greenskin Muck Pen",
					text =
[[
32.7k, 26.8k 
Click on "Slimy Muck Bubble" a white blob in the water.
]],
				},

				{
					name = L"Ur'kar's Lair",
					text =
[[
10.4k, 38.9k
Click on "Jarl Themsbold" a corpse caught on top of the rocks, you can walk up them from the NE corner.
]],
				},

				{
					name = L"The Brothers Damgrundsson",
					text =
[[
19.1k, 56.8k
Click on "Ammo Crate" behind all the boulders to the north "Gudmud's Strong-Huts" warcamp.
]],
				},

				{
					name = L"Keebsta's Dead Giant-Killin' Gits",
					text =
[[
12.3k, 41.4k 
Click on "Goblin Weapons" near the edge of the cliff, at the top.
]],
				},

				{
					name = L"Morkfang Treasure Chest",
					text =
[[
8.8k, 27.8k 
Click on "Morkfang Treasure", a chest inside the hut up on the platform.
]],
				},

				{
					name = L"Echo Bluff Watchpoint",
					text =
[[
23.3k, 26.5k 
Click on "Oathbearer Tent" on top of the plateau.
]],
				},

				{
					name = L"King's Bluff",
					text =
[[
34.7k, 38.6k
Click on "Historian's Kit" on the ramp into the RvR lake.
]],
				},

				{
					name = L"Redfang Camp",
					text =
[[
50.6k, 58.1k 
Click on "Kazador's Kin", a crucified dwarf skeleton next to the path.
]],
				},

				{
					name = L"Shiny Trinkets",
					text =
[[
56.8k, 27.6k 
Click on "Crate of Shinies" on the left as you enter "Da Great Smashin' Pit" PQ.
]],
				},
			},
		},
		
		{
			name = L"Karaz-a-Karak",
			entries =
			{
				{
					name = L"Warrior's Stand",
					text =
[[
28.6k, 44.7k
Go up onto the raised platform area in the Warrior's Stand area on the map (Red area).
]],
				},

				{
					name = L"The Forge",
					text =
[[
20.5k, 33k
Approach "The Forge" major landmark on the map at this location.
]],
				},

				{
					name = L"The Great Vault",
					text =
[[
25.7k, 31.5k 
Approach the bankers inside "The Vault" major landmark, in the Merchant District. (Blue area)
]],
				},

				{
					name = L"The Feast Hall",
					text =
[[
38.6k, 36.5k
Enter the area around the "Feast Hall" major landmark.
]],
				},

				{
					name = L"The Brewery",
					text =
[[
41.6k, 36.5k
Enter the area east of the "Feast Hall" major landmark, unlocked just up the stairs between the two Brewery Warden NPCs.
]],
				},

				{
					name = L"The Steadfast Inn",
					text =
[[
39.8k, 26.3k
Approach the back of the tavern to trigger the unlock.
]],
				},

				{
					name = L"The High King's Hold",
					text =
[[
28.5k, 26.5k
Enter the area "High King's Hold" on the map (Green area).
]],
				},

				{
					name = L"The Great Gate",
					text =
[[
28.5k, 49.2k
Talk to "The Gatekeeper" NPC, in the middle right in front of the huge door, at the very south of the map.
]],
				},

				{
					name = L"Stonebread",
					text =
[[
39.8k, 31.3k
Click on "Durazbrog" some bread on a wooden table inside the pub, the table is just behind Josef Bugman.
]],
				},

				{
					name = L"Anvil of Doom",
					text =
[[
11.7k, 33k
Approach the Anvil of Doom at this location.
]],
				},

				{
					name = L"Thungni",
					text =
[[
21.5k, 31.9k
Click on "Gromril Ore" at the base of the alter on the east side of the "The Forge" major landmark, alter is on the left side of the archway through to the Merchant Distrist (Blue area).
]],
				},

				{
					name = L"Thunderbarges",
					text =
[[
7.5k, 21k
Enter the guild area on the west side of the "Flight Master" major landmark. Unlocked straight away outside the portal up.
]],
				},

				{
					name = L"Royal Hammerers",
					text =
[[
28.7k, 23.7k 
Talk to "Hammerer Bodyguard" NPCs around the "Throne Room" major landmark.
]],
				},

				{
					name = L"Dammaz Kron",
					text =
[[
28.7k, 22.6k
Click on "Book of Grudges" right in front of the High King at the "Throne Room" major landmark.
]],
				},

				{
					name = L"High King Alriksson",
					text =
[[
30.1k, 32.9k
Click on "Battle a the Gates of Kislev" a huge red and gold tapstery hanging in the hallway. You need to look up and click on the ranging rail.
]],
				},

				{
					name = L"Age of Heroes",
					text =
[[
26.9k, 47.9k
Click on "Memorial Plaque" low on the west side of the south wall of Warrior's Stand area on the map (Red area).
]],
				},

				{
					name = L"Royal Clans",
					text =
[[
28.7k, 26.7k
Click on "Clan Registry", the closed book on the table infront of the "Royal Reception" (Name Registrar) NPC.
]],
				},

				{
					name = L"The Grand Alliance",
					text =
[[
31.9k, 30.1k 
Click on "Book of Days" on a table just in front of "Teclis" NPC, inside the Elf Order Headquarters (West most yellow area).
]],
				},

				{
					name = L"The Long Migration",
					text =
[[
24.3k, 37.4k
Click on "The Long Migration" a large gold tapestry hanging in the archway into the west "Ancestor Temples" (Orange area).
]],
				},

				{
					name = L"Alaric the Mad",
					text =
[[
19.9k, 23k
Click on "On Runic Properties of Metals" a book on a small bench near the back of the room, behind Grimm Buloksson.
]],
				},

				{
					name = L"Doomstrikers",
					text =
[[
10.5k, 33k
Talk to the Doomstriker Tester behind the Anvil of Doom.
]],
				},

				{
					name = L"Smednir, Shaper of Ores",
					text =
[[
In the Middle Deeps
20.5k, 44.3k
Click on "Small Find" at the base of the alter. The alter is on the level with the pub that is half way down the stairs.
]],
				},

				{
					name = L"Ungdrin Ankor",
					text =
[[
16.3k, 49.3k
In the Middle Deeps
Approach the giant doorway on the west side of "Grungni's Citadel" major landmark, unlock triggered after going up the stairs.
]],
				},

				{
					name = L"Engineer's Guild",
					text =
[[
39.2k, 29.9k 
In the Middle Deeps 
Click on the scroll casing called "Turret Designs", on a bench in the upper workshop area.
]],
				},

				{
					name = L"Goblin-Hewer",
					text =
[[
24.7k, 29k 
In the Middle Deeps
Talk to "Goblin Hewer", these are the 3 warmachine contraptions in this area.
]],
				},

				{
					name = L"Morgrim",
					text =
[[
35.7k, 37.4k 
In the Middle Deeps
Click on "Knublsprube" at the base of the alter on the west side of the "Cannon Foundry" major landmark.
]],
				},

				{
					name = L"Crypt of the High Kings",
					text =
[[
14.8k, 31.3k 
In the Middle Deeps
Approach the gold door at the end of the room, where the major landmark "The Crypt" is on the map. Unlocks after basically hugging the door.
]],
				},

				{
					name = L"Gazul, Lord of Underearth",
					text =
[[
18.7k, 33.3k 
In the Middle Deeps 
Click on "Dharkhangron Flame" at the base of the alter at the back of the room.
]],
				},

				{
					name = L"Order of Guardians",
					text =
[[
18.8k, 29.7k 
In the Middle Deeps
Talk to one of the "Guardian" NPCs in the library room.
]],
				},

				{
					name = L"Irondrakes",
					text =
[[
28.8k, 36.8k 
In the Middle Deeps
Talk to one of the "Norgrimling Irondrake" NPCs in this area.
]],
				},
			},
		},
		
		{
			name = L"Karak Eight Peaks",
			entries =
			{
				{
					name = L"Da Biggest, Da Toughest, Da Bestest",
					text =
[[
30.7k, 32.4kk
Enter the Hall of Da Bestest.

]],
				},

				{
					name = L"Waaaagh Boss",
					text =
[[
32.6k, 35.5k 
Enter Hall of Da Gorkiest and Morkiest
]],
				},

				{
					name = L"Da Waaagh Machine",
					text =
[[
27.9k, 34.1k
Enter the Stunty Diggin’ Pit

]],
				},

				{
					name = L"Dem Shinies",
					text =
[[
40.6k, 28.6k
Enter "Shineyz Keepin' Place" major landmark (Blue area).

]],
				},

				{
					name = L"The Kataklysm",
					text =
[[
DA DEEPS
27.5k, 7.3k  
In Karak Eight Peaks Da Deeps. Approach the back of the room inside the Rat Ridge centre area.
]],
				},

				{
					name = L"The Goblin Wars",
					text =
[[
DA DEEPS
25.3k, 19.8k 
In Karak Eight Peaks Da Deeps. Click on "Memorial Plaque" inside the tower before crossing the west bridge at Kataclysm Chasm.
]],
				},

				{
					name = L"Warlord Urgluk Bloodfang",
					text =
[[
41.2k, 41.1k 
Click on "Bloodfang", a banner to the right of a pooh statue.

]],
				},

				{
					name = L"Greenskin Anatomy",
					text =
[[
27.1k, 29.1k 
Click on "Sigwald's Journal" on a small wooden table in the south Hedkwaterz (Yellow) area.

]],
				},

				{
					name = L"Moving Ecosystem",
					text =
[[
DA DEEPS
17.7k, 45.7k 
Click on the “Squirming Goo” in the squig pit. 
]],
				},

				{
					name = L"Da Big Waaagh!",
					text =
[[
37.7k, 34.3k 
Approach the ramp down to the "Temple of Gork" major landmark.

]],
				},

				{
					name = L"Black Orcs",
					text =
[[
???
]],
				},

				{
					name = L"Night Gobboz",
					text =
[[
DA DEEPS
40.9k, 34.5k 
Click on the “Lil Pot” behind Nubz Brainsporez.
]],
				},

				{
					name = L"Fungal Brew",
					text =
[[
???
]],
				},

				{
					name = L"Art of the Squig",
					text =
[[
DA DEEPS
29k, 45.3k
Either talk to Butcha Gleek in Da ‘Ungry Troll area. 
]],
				},

				{
					name = L"Goblin Cunning",
					text =
[[
???
]],
				},

				{
					name = L"Big 'Uns",
					text =
[[
32.6k, 39k 
Talk to "Bloody Sun Brute" NPCs.
]],
				},

				{
					name = L"Ironclaw Tribe",
					text =
[[
18.7k, 28.6k 
Click on the Ironclaw spektator sitting on the ground.

]],
				},

				{
					name = L"Pit Fightin'",
					text =
[[
20.5k, 29k
Walk into the fighting pit.
]],
				},

				{
					name = L"Spear Chukkas",
					text =
[[
19.2k, 34.1k 
Click on "Spearchukka" at the end of the wooden platform.
]],
				},

				{
					name = L"Doom Diver Catapults",
					text =
[[
21.6k, 24.6k 
Click on "Doomflyer", a flying contraption to the right of the giant catapult.
]],
				},

				{
					name = L"Wyvern Taming",
					text =
[[
???
]],
				},

				{
					name = L"Nasty Skulers",
					text =
[[
DA DEEPS
17.7k, 28.7k
Talk to the Nasty Skulkers in the Hammerin’ Hall. They are behind the large wooden orc face 
]],
				},

				{
					name = L"Know Yer Place",
					text =
[[
???
]],
				},

				{
					name = L"Frenzy Power",
					text =
[[
???
]],
				},

				{
					name = L"Yer Full o' Hot Air!",
					text =
[[
21k, 26.3k 
Walk up the ramp and into the area.

]],
				},

				{
					name = L"Dis Iz Our Place",
					text =
[[
Da Deeps
29.9k, 11.5k
Click on "Border Banner", a large fallen banner on the floor, just inside the broken arches.
]],
				},

				{
					name = L"Stunty Trophies",
					text =
[[
???
]],
				},

				{
					name = L"Spida Worshippers",
					text =
[[
DA DEEPS
32.3k, 44.7k
Click on "Gork o' Eight Eyes Offerin'", a cocooned body in front of the pooh spider totem.
]],
				},

				{
					name = L"Gork Sez Huh?",
					text =
[[
???
]],
				},
				
				{
					name = L"Mork Sez Wut?",
					text =
[[
???
]],
				},				
			},
		},		
	},
}
