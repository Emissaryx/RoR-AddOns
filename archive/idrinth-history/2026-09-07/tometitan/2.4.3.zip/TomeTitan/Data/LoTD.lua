TTitan.Data.LoTD = {}

function TTitan.Data.LoTD.GetData()
	return TTitan.Data.LoTD.RawData
end

function TTitan.Data.LoTD.FilterData()
end

TTitan.Data.LoTD.RawData =
{
	header = L"Land of The Dead Unlocks - Unlocks",
	categories =
	{
	{
			name = L"Land Of The Dead",
			entries =
			{
	{
					name = L"Swarm (Trophy)",
					text =
[[
Swarm - A Voracious Tomb Swarm Leaves Nothing to Waste

1. Go to the Land of the Dead
2. Fall into the tomb located at 14.6, 24
3. go into eastern tunnel and go to the first turn.
4. Click on the Pile of Bones
5. Kill the level 40 Tomb Swarm

You will recieve the ToK bestiary achievement (A Voracious tomb swarm leaves nothing to waste) and can now buy a Tomb swarm trophy.

by: Elrosre on Ironfist server
]],
				},
				
					{
					name = L"Carrion (Trophy)",
					text =
[[
Carrion - You Can't Make an Omelet Without Breaking Some Eggs

1. Go to your respective PQ in Land of the Dead where you recieve the Vulture Glyph.
2. Get picked up so that you are in their nests.
3. Search their nests for Shiny Trinkets.
4. Collect 5 total from multiple nests.
5. Look at the items and they will tell you who to deliver them to. (O) Vanden Lightwind, (D) Xolyn Eboneye at 56.4/10.3 in Da Dusty Dry (Schwarznhammer lvl 40 Chosen on Gorfang)

You recieve the Carrion trophy unlock and the You cant make an omelet without breaking some eggs Bestiary unlock for carrions

by: Elrosre on Ironfist server
]],
				},
				
									{
					name = L"Scorpion (Trophy)",
					text =
[[
Scorpions - The Dead Can(And Do) Speak

Use the head dropped by the Amen Sher PQ. You have to kill the boss to obtain this. (Needs Confirmation and possibly a name check)
Unlocks a trophy Tomb Scorpion.

by: Cloudscraper of Karak Azgal
]],
				},
				
				{
					name = L"Scarab Bone Construct (EXP)",
					text =
[[
(Scarab Bone Construct) - The Eyes Have It

Collect 10 'Scarab construct eye's and take them to Dregg Stinkeye in Da dusty dry for (D) or Cavlan Teurin in Goldbarrow for (O)
Item has a low drop chance from any skeletons which spawn during the 'The assault on Nekh Akhet' PQ, possibly from the eqivalent PQ on the order side of Lotd.

by: Thason
]],
				},
                
    		
    },
    }, 
    },
    }