TTitan.Data.BestiaryEvC = {}

function TTitan.Data.BestiaryEvC.GetData()
	return TTitan.Data.BestiaryEvC.RawData
end

function TTitan.Data.BestiaryEvC.FilterData()
	TTitan.Data.FilterByRealm(TTitan.Data.BestiaryEvC.RawData)
end

TTitan.Data.BestiaryEvC.RawData =
{
	header = L"Beastiary Unlocks - Empire vs Chaos",
	categories =
	{
		{
			name = L"Nordland",
			entries =
			{
				{
					name = L"Bright Wizard (Pocket)",
					text =
[[
Empire, Bright Wizard - What do We Have here?

24k, 11k
Click on the Hidden Scroll behind a bush against the rocks. Unlocks: Flint Stone.

Reward
Pocket Item: Flint Stone
]],
				},

				{
					name = L"Beastman (Title)",
					text =
[[
Beastman, Gor - The Murder Wood
40.5k, 36.4k
Interact with the beastman 'Herdstone'

Reward: 
Title: Road Warden
]],
				},

				{
					name = L"Beastman (Title)",
					text =
[[
Beastman, Ungor - Who Wud Murder
37k, 35k
Interact with a corpse labelled 'Unfortunate Victim' that can be found behind a tree in The Murder Wood.

Reward: 
Title: The Brute
]],
				},

				{
					name = L"Boar (Title)",
					text =
[[
Boar - Surrounded by Swine
55k, 500
Talk to "Hanke the Boar Tackler" standing on a small hill with two other hunters.

Rewards
Title: Huntsman
]],
				},

				{
					name = L"Hound (Title)",
					text =
[[
Hound - Hungry, Hungry Hounds
56.6k 43.8k
Interact with the bag "Kibbles 'n Scraps", next to a tree .

Rewards
Title: The Hound Hunter
]],
				},

				{
					name = L"Plague Victim (Title)",
					text =
[[
Plague Victim - People Pop Up
59k, 11.8k
Kill the "Plagued Farmer", laying underneath a tree will unlock this entry.

Reward: 
Title: The Infected
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Flamer of Tzeentch (Title)",
					text =
[[
Flamer of Tzeentch - Hot Deal
18.9k 41.4k
Kill 'Kruk'tar the Drunken' until he drops a Pocket Item 'Mote of Change'. Equip it for the associated title.

Rewards
Title: The Banisher
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Skeleton (Title)",
					text =
[[
Skeleton - What Lay Ahead
19.4k 39.6k
Interact with a 'Gravestone' in the Grimmenhagen Barrows graveyard, left of the crypt entrance. (Easier for Order)

Rewards
Title: The Skeleton Hunter
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Spider (Tactic)",
					text =
[[
Spider, Giant - Fast Finds
48k, 40k
Kill 60 'Scarlet Wolf Spiders' and 'Grey Wolf Spiders', to complete the quest for the Kill Collector, Golen, in Authun's Host (Chaos Chapter 4).

Rewards
Beastial Tactic Fragment
]],
				},
			},
		},

		{
			name = L"Norsca",
			entries =
			{

				{
					name = L"Zealot (Pocket)",
					text =
[[
Chaos, Zealot - What do We Have Here?

42k, 63k
Click on the Hidden Scroll behind the burned house.

Rewards
Pocket Item: Smoking Skull
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Plague Victim (Tactic)",
					text =
[[
Plague Victim - Epic Epidemic
18.4k, 48.7k
Speak to "Mathis Rittenhouse", sitting on a rock down the cliff.

Rewards
Chaos Tactic Fragment
]],
				},
				
				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Plage Victim (Tactic)",
					text =
[[

51.7k 57k
Speak to "Sister Raffaela", on the opposite side of hill as Gotland Advance (Empire Chapter 4), near the "Courageous Villagers".

Rewards
Chaos Tactic Fragment
]],
				},
				
				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Skeleton (Title)",
					text =
[[
Skeleton - What Lay Ahead
33k, 7.1k
Interact with a 'Gravestone' in the graveyard in front of 'Thorshafn Crypt', near the starting area. (Easier for Destruction)

Rewards
Title: The Skeleton Hunter
]],
				},

				{
					name = L"Spirit Host (Title)",
					text =
[[
Spirit Host - Place of the Dead
48.3k 44.5k
Interact with the 'Crypt Gate' of 'Amund's Barrow'.

Rewards
Title: The Fearless
]],
				},
			},
		},

		{
			name = L"Troll Country",
			entries =
			{

				{
					name = L"Witch Hunter (Pocket)",
					text =
[[
Empire, Witch Hunter - What do We Have Here?
3.5k, 54k
The "Hidden Scroll" for this can be found slightly N of Stonetroll Keep in the ORvR lake. It is located in some bushes next to a tree N of the NE corner of Stonetroll Keep, near the stone "tunnel" that leads to the back door of the keep. This will unlock Fear in a bottle.

Reward
Pocket: Fear in a Bottle
]],
				},
				
				{
					name = L"Bat (Title)",
					text =
[[
Bat, Giant - For Once It Isn't Guano
15k, 48k or 11k, 38k
Kill 'Leatherwing Bat' or 'Blighted Leatherwing' until they drop a Pocket Item 'Bat Wing'. Equip it for the associated title.

Reward: 
Title: Echo Hunter
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Lizard (Tactic)",
					text =
[[
Giant Lizard - Hunger Pangs
Kill 60 'Blueridge Salamanders' and 'Bluespine Salamanders' in the areas around Felde Castle (Empire Chapter 6) in Troll Country then speak to kill collector Dieter Stroh in Felde Castle.

Rewards
Beastial Tactic Fragment
]],
				},

				{
					name = L"Gorger (Title)",
					text =
[[
Gorger - Questionable Fashion
7.8k, 7.8k
Kill "Bonegash Gorgers" inside "Iceflow Maw" until one drops a Pocket Item "Gorger Bone Decoration". Equip it for the associated title.
Note: The drop rate is a bit low (10%).

Reward: 
Title: The Foolhardy
]],
				},

				{
					name = L"Plaguebearer (Tactic)",
					text =
[[
Plaguebearer- Finding Foul Flesh
55k, 26.7k
Interact with an empire corpse 'Festering Corpse'. The corpse is hidden between a tree and a rock, on the east of the path.

Rewards
Daemonic Tactic Fragment
]],
				},

				{
					name = L"Spider (Title)",
					text =
[[
Spider, Giant - Tacky Decor
2k, 35k - in Troll Country
Enter the Suskarg Caves to trigger this unlock.

Rewards
Title: The Spider Slayer
]],
				},

				{
					name = L"Spite (Tactic)",
					text =
[[
Spite - Lost and Found
8.6k 47.2k - in Troll Country
Or
60.3k 16.4k - in High Pass
Kill a Spite level 16-17 named 'Elorian'.

Rewards
Mythical Tactic Fragment
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Troll (Title)",
					text =
[[
Troll, Stone  - It's a Snap
61.6k 29.4k
Talk to "Afvaldr". He is well hidden in the rocks southeast of Destruction PQ "Griffon Outpost". There's a fallen tree beside him.

Rewards
Title: The Trollwise
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Troll (Title)",
					text =
[[
Troll, Stone  - It's a Snap
26.4k 41.5k
Talk to "Walbrecht Veit", who is standing in front of a tree. Easier to reach him if you approach him from the frozen way.

Rewards
Title: The Trollwise
]],
				},

				{
					name = L"Troll (Tactic)",
					text =
[[
Troll, Stone  - It's a Snap
9.8k 5.7k
Kill "Coldsnap", a level 20 Stone Troll Champion. He is in front of the Lair of Metoh.

Rewards
Giant Tactic Fragment
]],
				},

				{
					name = L"Troll (Title)",
					text =
[[
Troll, Chaos - Gone But Not Forgotten
7.7k 46.4k
Kill "Wart Trolls" until one drops a Pocket Item "Lost Locket". Equip it for the associated title.

Rewards
Title: The Undaunted
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Troll (Tactic)",
					text =
[[
Troll, River - Gotta Go
49.2k 44k
OR
50k 49.3k
OR
51.8k 46.4k

Interact with "Troll Droppings" on the ground to receive a "River Troll Dropping". Then take this item to "Voxanna the Transmuter" in Chaos Chapter 6.

Rewards
Giant Tactic Fragment
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Troll (Tactic)",
					text =
[[
Troll, River - Gotta Go
49.2k 44k
OR
50k 49.3k
OR
51.8k 46.4k
Interact with "Troll Droppings" on the ground to receive a "River Troll Dropping". Then take this item to "Brenard the Alchemist" in Empire Chapter 6.

Rewards
Giant Tactic Fragment
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Troll (Title)",
					text =
[[
Troll, River  - Mass Exstinktion
Not Implemented
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Troll (Title)",
					text =
[[
Troll, River  - Mass Exstinktion
Not Implemented
]],
				},

				{
					name = L"Troll (Pocket)",
					text =
[[
Troll, River - Takes its Toll
53.4k 37.9k
OR
47.5k 39.5k
Kill 'Bridge Troll' under a bridge.

Rewards
Pocket: Revolting Crock
]],
				},

				{
					name = L"Troll (Tactic)",
					text =
[[
Troll, River - O'de Toilet
55.8k, 47.6k
Interact with the "Barrel of Perfume" to receive one in your inventory, at the Goblin Hunter Camp.
Kill "Brackmaw", a level 15 Champion River Troll, in Troll Country at 56.7k, 43.8k, with the "Barrel of Perfume" in your inventory. Brackmaw is surrounded by some "Rank Trolls".
Use the “Barrel of Perfume” to complete the quest and achievements

Rewards
Giant Tactic Fragment
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Troll (Title)",
					text =
[[
Troll, Stone - Uneasy Stomach
14k, 30k
Kill 'Stormblight Brute' and 'Stormblight Dolt' to collect 5 'Intact Troll Stomachs' on them.
Trade these to Disciple's Assistant in the Lyceum in The Inevitable City for a Pocket Item 'Acidic Troll Bile' and equip for the unlock.

Rewards
Title: The Boulderbane
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Troll (Title)",
					text =
[[
Troll, Stone - Uneasy Stomach
14k, 30k
Kill 'Stormblight Brute' and 'Stormblight Dolt' to collect 5 'Intact Troll Stomachs' on them.
Trade these to the Library Assistant in the Library in Altdorf for a Pocket Item 'Acidic Troll Bile' and equip for the unlock.

Rewards
Title: The Boulderbane
]],
				},
			},
		},

		{
			name = L"Ostland",
			entries =
			{

				{
					name = L"Marauder (Pocket)",
					text =
[[
Chaos, Marauder - What do We Have Here?
34k, 8k 
At the Crypt of Weapons, near the Tainted Earth for the quest, by one of the fallen pillars is a scroll.

Reward
Pocket: Mutated Claw
]],
				},

				{
					name = L"Bandit (Tactic)",
					text =
[[
Bandit - Wanted!
56k, 25k
Kill "Lodwig Falkenheim" level 17 Champion Bandit.

Rewards
Man Tactic Fragment
]],
				},

				{
					name = L"Bat, Giant (Tactic)",
					text =
[[
Bat, Giant - Things with Wings...
20.8k 28.6k
Kill the giant bat 'Heartraker', a lvl 17 Champion.

Rewards
Beastial Tactic Fragment
]],
				},

				{
					name = L"Beastmen (Title)",
					text =
[[
Beastman, Bestigor - Meat for the Beast
20.9k 36.4k
Interact with a 'Witch Hunter Corpse'. The corpse is hidden amongst a few trees, just south the river, at the north side of a Bestigor camp.

Rewards
Title: The Raw
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Beastmen (Tactic)",
					text =
[[
Beastmen, Gor - Thin the Herd
16k, 10k
Kill 50 'Darkhorn Gors' then speak to kill collector Gottfried Holz in Felde Chaos Chapter 6.

Rewards
Chaos Tactic Fragment
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Beastmen (Tactic)",
					text =
[[
Beastmen, Gor - Thin the Herd
20k, 37k
Kill 50 'Gashthorn Gors' then speak to the kill collector Droki Greybeard in Bohsenfels Empire Chapter 8 to complete the kill quest 'Outslay the Slayer'.

Rewards
Chaos Tactic Fragment
]],
				},

				{
					name = L"Dryad (Cloak)",
					text =
[[
Dryad - Death in Green and Brown
8k 16.3k
Kill "Sheen Gloomleaf", a level 12 Champion Dryad, near abandoned house northeast of a small lake.

Rewards
Back Item: Shawl of Spring
]],
				},

				{
					name = L"Plague Feaster (Tactic)",
					text =
[[
Plague Feaster - Wash Your Hands
48.7k 32.3k
Interact with 'Basket of Fish' to make spawn 'Plague Feaster', a rank 19 Champion Plague Victim.Kill him for the unlock.

Rewards
Chaos Tactic Fragment
]],
				},

				{
					name = L"H. of Tzeentch (Title)",
					text =
[[
Horror of Tzeentch (Purple Horror) - The Colors of Horror
Not Implemented
]],
				},

				{
					name = L"Skeleton (Tactic)",
					text =
[[
Skeleton - When There's a Will
30.5k 18.5k - inside the 'Gerstmann Crypt'
Or
11.2k 29.5k - inside 'Ferlangen Cementary'

Kill 'Boneshard Minions' or 'Skeletal Gebauers' until one drops a Pocket Item 'Faded Scroll'. Equip it for the unlock.

Rewards
Undead Tactic Fragment
]],
				},

				{
					name = L"Skeleton (Tactic)",
					text =
[[
Skeleton - Bones Have Names Too
49.4k 18.3k
Kill 'Halman Meusmann', a level 16 skeleton. He is located in front of a standalone gate arch of a graveyard.

Rewards
Undead Tactic Fragment
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Spirit Host (Pocket)",
					text =
[[
Spirit Host - Time is of the Essence
48.8k 57.4k
Collect 'Jekil's Wedding Band' from the 'Corpse of Jekil Behn'. This corpse is behind a building right at the cliff at the edge of the river.
Take the item to 'Hilda Behn's Grave' to the graveyard at 60.6k 60k in Ostland. Examine the grave, and speak to the spirit that appears 'Hilde Behn'.

Rewards
Pocket: Grave Dust
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Spirit Host (Pocket)",
					text =
[[
Spirit Host - Time is of the Essence
Not Implemented

48.8k 57.4k
Collect 'Jekil's Wedding Band' from the 'Corpse of Jekil Behn'. This corpse is behind a building right at the cliff at the edge of the river.
Take the item to 'Hilda Behn's Grave' to the graveyard at 60.6k 60k in Ostland. Examine the grave, and speak to the spirit that appears 'Hilde Behn'.

Rewards
Pocket: Grave Dust
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Spite (Title)",
					text =
[[
Spite - Looking for Shinnies
13.5k 14k
Kill "Shadow Spites" until one drops a Pocket Item "Shining Ring". Equip it for the associated title.

Rewards
Title: The Spite Splitter
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Wolf (Cloak)",
					text =
[[
Wolf - Picking Up The Pieces
54k, 34
Kill 65 Bloodfog Wolves found in both Troll Country & Ostland then turn in to kill collector Tosha Schreiber at Kournos' Encampment (Chapter 7).

Rewards
Back Item: Hunter Master's Pelt
]],
				},
				
			  {
					name = L"Plaguebeast of Nurgle (Title)",
					text =
[[
Plaguebeast of Nurgle - A Trail of Pure Vile Evil
20.5k, 13.8k
Kill ‘Plaguesworn Pariah’ which will spawn a 'Noxious Plaguebeast' (Champion).
Kill the 'Noxious Plaguebeast' for the unlock.

Rewards
Title: The Rank
]],
				},
			},
		},

		{
			name = L"High Pass",
			entries =
			{

				{
					name = L"Magus (Pocket)",
					text =
[[
Chaos, Magus - What do We Have Here?
15k, 63k
Click on the 'Hidden Scroll' located beside a broken section of the wall, the scroll is semi buried in the snow...not that hard to see.

Reward
Pocket: Discus Tech
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Tuskgor (Tactic)",
					text =
[[
Tuskgor - Saving Face
43k 48.7k
Kill 'Bloodsnout Tuskgors' (not Chargers) and collect 5 'Unchipped Tusks'.
Trade them for a Pocket Item 'Belt of Tusks' to Disciple's Assistant into the Lyceum in The Inevitable City. Equip it for the unlock.

Rewards
Chaos Tactic Fragment
]],
				},

				{
					name = L"Beastman (Tactic)",
					text =
[[
Beastman, Ungor - Thorn in My Side
47.6k, 50.3k
Kill the champion ungor 'Gurrvek Shorthorns', standing in front of a campfire.

Rewards
Chaos Tactic Fragment
]],
				},

				{
					name = L"B. of Khorne (Title)",
					text =
[[
Bloodthirster of Khorne - Dire News Indeed
38.3k 40.7k
Interact with the 'Empire Runner Corpse'. The corpse is in a slight indent on a bit of a hill located with giant spiders just below it, in front of the 'Shrine of Tzeentch' Order PQ.

Rewards
Title: Heritor of War
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Chaos Fury (Title)",
					text =
[[
Chaos Fury - Nefarious Force
51.7k, 50.2k - In High Pass
Talk to 'Zchekil the Vile', 25 hero, northwest outside of the ruinous castle.

Rewards
Title: Warp Binder
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Chaos Fury (Title)",
					text =
[[
Chaos Fury - Nefarious Force
51.7k, 50.2k - In High Pass
Kill 'Zchekil the Vile', 25 hero, northwest outside of the ruinous castle.

Rewards
Title: Warp Binder
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Chaos Hound (Title)",
					text =
[[
Chaos Hound - Seeker in the Snow
57.5k, 50.5k
Talk to 'Bradiclaw the Seeker', 25 hero. He is up on a little cliff.

Rewards
Title: The Gnawed
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Chaos Hound (Title)",
					text =
[[
Chaos Hound - Seeker in the Snow
57.5k, 50.5k
Kill'Bradiclaw the Seeker', 25 hero. He is up on a little cliff.

Rewards
Title: The Gnawed
]],
				},

				{
					name = L"Chaos Spawn (Title)",
					text =
[[
Chaos Spawn - Beyond Definition
28.2k, 30.2k
Interact with a book called 'Sixth Journal of Lliean' among 3 trees.

Rewards
Title: The Serene
]],
				},

				{
					name = L"Spite (Tactic)",
					text =
[[
Spite - Lost and Found
8.6k 47.2k - in Troll Country
Or
60.3k 16.4k - in High Pass
Kill a Spite level 16-17 named 'Elorian'.

Rewards
Mythical Tactic Fragment
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Flayerkin (Title)",
					text =
[[
Flayerkin - One Part Agony, Three Parts Cold Wrought Iron
1.7k 41.5k - in High Pass
Loot "Flayer-Kin's Scaling Chains" from a corpse "Dead Flayerkin", inside the Tomb of the Traitor (5.2k 39.3k).

9.7k 49.1k - in High Pass
Loot "Flayerkin Hooks" from another corpse "Dead Flayerkin" inside a cave.

47.6k 33.2k - in West Praag
Loot a "Flayer-Kin's Iron Helm" from another corpse "Dead Flayerkin" inside the calls. He is near a bush, a well and an empire home.

Then turn the items in to "Kreelik of Clan Moulder" a skaven by the central campfire in Chaos Chapter 17 in Praag at 6.5k 9.7k. 

Rewards
Title: The Flayer
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Flayerkin (Title)",
					text =
[[
Flayerkin - One Part Agony, Three Parts Cold Wrought Iron
1.7k 41.5k - in High Pass
Loot "Flayer-Kin's Scaling Chains" from a corpse "Dead Flayerkin", inside the Tomb of the Traitor (5.2k 39.3k).

9.7k 49.1k - in High Pass
Loot "Flayerkin Hooks" from another corpse "Dead Flayerkin" inside a cave.

47.6k 33.2k - in West Praag
Loot a "Flayer-Kin's Iron Helm" from another corpse "Dead Flayerkin" inside the calls. He is near a bush, a well and an empire home.

Then turn the items in to "Breitenhoff the Faithful" by a campfire at Empire Chapter 17 in Praag at 12.7k 57.4k.

Rewards
Title: The Flayer
]],
				},

				{
					name = L"Gnoblar (Title)",
					text =
[[
Gnoblar - Mixed Company
Not implemented yet - I wonder if this is actually in Black Crag
16k, 4k
Walk near the location in High Pass (even if the text description advises to explore in Black Crag).

Rewards
Title: The Bully
]],
				},

				{
					name = L"Gorger (Token)",
					text =
[[
Gorger - Engage the Gorger
18.7k, 7.1k - in High Pass

Kill "Bloodscent", the level 29 champion Gorger.

Rewards
Bestial Token
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Great Cat (Title)",
					text =
[[
Great Cat - A Run for Rolf
9.4k, 38.7k
Kill "Snarling Razortooth" mobs around this area ("Rabid" ones do not count) to complete the Kill Collector at "Nuhr's Crest", Empire Chapter 10 camp.

Rewards
Title: The Clawed
]],
				},

				{
					name = L"Great Unclean (Title)",
					text =
[[
Great Unclean One - The Unclean
26.3k, 40.9k
Interact with 'Heinrich's Stew Pot'. It's right next to 'Old Hienrich', on Destruction side of the map (north of the mountains).

Rewards
Title: Herald of the Vital
]],
				},

				{
					name = L"Ogre, Bull (Tactic)",
					text =
[[
Ogre, Bull - It's Safer Outside
5k, 34.5k
Explore the area around the Ogre Bull camp.

Rewards
Giant Tactic Fragment
]],
				},

				{
					name = L"Ogre, Bull (Tactic)",
					text =
[[
Ogre, Bull - Bigger They Are...
5.5k, 46.8k
Kill "Marl the Maneater", a level 23 Champion Ogre on the road.

Rewards
Giant Tactic Fragment
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Warhawk (Pocket)",
					text =
[[
Warhawk - Poached, Scrambled, or Fried
4.5k, 53.2k
Click on "Cracked Warhawk Egg" to start the quest "Winter Rations". Then collect 5 "Warhawk Egg" quest items by clicking on "Warhawk Egg" around the area.
Return to "Eustace Cloudedsight" in "Raven's End" Empire Chapter 11 camp to complete the quest.

Rewards
Pocket: Bird Seed
]],
				},
				
				{
				 realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Warhawk (Pocket)",
					text =
[[
Warhawk - Poached, Scrambled, or Fried
4.5k, 53.2k
Click on "Cracked Warhawk Egg" to start the quest "Winter Rations". Then collect 5 "Warhawk Egg" quest items by clicking on "Warhawk Egg" around the area.
Return to Granr Volvrik at the CH13 camp to complete the quest. 


Rewards
Pocket: Bird Seed
]],
				},				

				{
				 realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Wight (Cloak)",
					text =
[[
Wight - Broken Men, Broken Blades
33.6k, 24k
Kill 'Kulian Bonewarriors' and 'Kulian Bonearchers', in the 'Keep of Asavar Kul' Destruction PQ, until you get 5 'Broken Wight Blades'.
Then trade them for a Pocket Item 'Restored Wight Blade' to Disciple's Assistant in the Lyceum at The Inevitable City. Equip it for the unlock.

Rewards
Back Item: Death Shroud Cape
]],
				},
				
				{
				 realm = TTitan.Data.Realm.ORDER,
					name = L"Wight (Cloak)",
					text =
[[
Wight - Broken Men, Broken Blades
33.6k, 24k
Kill 'Kulian Bonewarriors' and 'Kulian Bonearchers', in the 'Keep of Asavar Kul' Destruction PQ, until you get 5 'Broken Wight Blades'.
Then trade them for a Pocket Item 'Restored Wight Blade' to Library Assistant in the Library at Altdorf. Equip it for the unlock.

Rewards
Back Item: Death Shroud Cape
]],
				},				

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Wolf (Tactic)",
					text =
[[
Wolf - Alpha in Bits
46.8k, 51.5k
Kill 'Lishka', the level 26 wolf, on the edge of the main road, northeast of the Empire Chapter 12.

Rewards
Beastial Tactic Fragment
]],
				},

				{
					name = L"Yhetee (Cloak)",
					text =
[[
Yhetee - Appropriately Named
10.5k, 44.8k
Kill "Killing Frost", 21 Champion Yhetee on a peak. You can start climbing the mountains around 10.8k 42.5k to reach him.

Rewards
Back Item: Hide of Killing Frost
]],
				},
			},
		},

		{
			name = L"Talabecland",
			entries =
			{
				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Beastman (Tactic)",
					text =
[[
Beastman, Bestigor - Appalling Fashion
I'm not sure this is implemented, I killed the NPC over 30 times along with the Bestigors in the order instructions. 
49.5k, 42.8k
Kill 'Witch Hunter Adept', a level 9 Champion,on the mountains. He drops a Pocket Item 'Grisly Necklace'. Equip it for the unlock.

OR 

47.8k, 39.4k
Kill 'Blackhorn Bestigors' around the 'Blackhorn Herdstone' Major Landmark, until one drops a Pocket Item called 'Grisly Necklace'. Equip it for the unlock.

Another guide said to talk to 'Casimir Por'at 55k, 35k but this did not work for me either. 

Rewards
Chaos Tactic Fragment
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Beastman (Tactic)",
					text =
[[
Beastman, Bestigor - Appalling Fashion
47.8k, 39.4k
Kill 'Blackhorn Bestigors' around the 'Blackhorn Herdstone' Major Landmark, until one drops a Pocket Item called 'Grisly Necklace'. Equip it for the unlock.

Rewards
Chaos Tactic Fragment
]],
				},

				{
					name = L"Beastman (Tactic)",
					text =
[[
Beastman, Ungor - Trinkets for Treasure
47.8k, 39.4k
Kill 'Blackhorn Ungor' at the 'Blackhorn Herdstone' Major Landmark, until one drops a Pocket Item called 'Ungor Talisman'. Equip it for the unlock.

Rewards
Chaos Tactic Fragment
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Chaos Mutant (Title)",
					text =
[[
Chaos Mutant - Handy Dandy
21.1k, 31.6k OR 5k, 33.7k
Collect 10 "Mutant Hands" on "Grave Mutants". Trade them for 2 Pocket Items "Right Hand" and "Left Hand" to the Library Assistant in the Library at Altdorf. Equip the "Right Hand" for the unlock, and the "Left Hand" for the associated title.

Rewards
Title: The Unsullied
]],
				},
				
				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Chaos Mutant (Title)",
					text =
[[
Chaos Mutant - Handy Dandy
21.1k, 31.6k OR 5k, 33.7k
Collect 10 "Mutant Hands" on "Grave Mutants". Trade them for 2 Pocket Items "Right Hand" and "Left Hand" to the Disciple's Assistant in the Lyceum at Inevitable City. Equip the "Right Hand" for the unlock, and the "Left Hand" for the associated title.

Rewards
Title: The Unsullied
]],
				},				

				{
					name = L"Plaguebearer (Tactic)",
					text =
[[
Plaguebearer - Let It Fly or Let It Die
36k, 50.4k
Kill 'Blight Spew' (level 29 champion). He is just south the river on the opposite side of the little town.

Rewards
Daemonic Tactic Fragment
]],
				},

				{
					name = L"Plague Victim (Pocket)",
					text =
[[
Plague Victim - Side Effects Include Mutation and Death
5.1k, 42.2k
Interact with a "Chest of Plagues" by the river. It is guarded by a pair of level 29 Champion Plague Guards.

Rewards
Pocket: Filthy Hanky
]],
				},

				{
					name = L"Skaven (Tactic)",
					text =
[[
Skaven - What a Rat's Nest
26k, 19.4k
Interact with a banner "Verminkin Banner", at the top of the "Horned Tower". To reach it, you must go through portal at the waterfall. It will teleport you inside the tower at 30k, 18.2k, just go to the top.
You will eventually have to leave the tower going through the portal next to the banner. Walk a little then you'll find another portal, which will teleport you back in Talabecland.

Rewards
Skaven Tactic Fragment
]],
				},

				{
					name = L"Vulture (Pocket)",
					text =
[[
Vulture - Diseased Pecking Order
Kill 'Blightbeak Carrions' in Talabecland on the south side of the Talabec River, until they drop a Pocket Item 'Blightbeak Beak'. Equip it to trigger the unlock.

Rewards
Pocket: Carrion Tickler
]],
				},

				{
					name = L"Vulture (Tactic)",
					text =
[[
Vulture - More Than Just a Foul Feather
5.4k, 43k
Kill a champion monster named Plaguefeather, on a rock.

Rewards
Beastial Tactic Fragment
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Wolf (Tactic)",
					text =
[[
Wolf - Alpha in Bits
45.3k, 7.8k
Kill 'Sorenna' the level 27 wolf, just south the road among several trees.

Rewards
Beastial Tactic Fragment
]],
				},

				{
					name = L"Zombie (Title)",
					text =
[[
Zombie - Dare to Tread With the Undead
39.8k, 46.0k
Enter 'Unterbaum Cemetery' Order PQ and then click the Game Object.

Rewards
Title: The Gory
]],
				},
			},
		},

		{
			name = L"Praag",
			entries =
			{

				{
					name = L"Warrior Priest (Pocket)",
					text =
[[
Empire, Warrior Priest - What do We Have Here?
35k, 58k
Click on the 'Hidden Scroll'.

Reward
Pocket: Thumb Unguent
]],
				},

				{
					name = L"Chosen (Pocket)",
					text =
[[
Chaos, Chosen - What do We Have Here?
30k, 17k
Click on the 'Hidden Scroll.

Reward
Pocket: Mark of Tzeentch
]],
				},

				{
					name = L"Bear (Pocket)",
					text =
[[
Bear - Getting Ahead
64.4k, 33k
Talk to "Boris the Mauler" inside "Ursan's Den" major landmark.

Rewards
Pocket: Deathmaw Paw
]],
				},

				{
					name = L"Bear (Tactic)",
					text =
[[
Bear - Heading for Profit
59.5k, 19.9k 
Equip "Deadmaul's Paw" dropped by "Deadmaul" at the end of the cave.

Rewards
Beastial Tactic Fragment
]],
				},

				{
					name = L"Beastman (Tactic)",
					text =
[[
Beastman, Gor - For the Greater Gor
6.9k, 18.1k
Kill 'Drahamesh', a level 40 hero. 

Rewards
Chaos Tactic Fragment
]],
				},

				{
					name = L"Beastman (Acc)",
					text =
[[
Beastman, Ungor - Thick-Headed
1k, 28.6k
Kill an ungor by the name of 'Grentic the Thick-Headed' a level 37 mob, (not a champ). He is alone among tuskgors and wolves.

Rewards
Jewel Item : Writhing Shackles
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Big Cat (Title)",
					text =
[[
Big Cat - A Run for Rolf
55k, 64k
Kill 60 'Winter Lynx' and 'Winter Great Lynx' for Kill Collector Lahkis Curseblade, Southern Breach (Chaos Chapter 19).

Rewards
Title: The Clawed
]],
				},

				{
					name = L"Bird (Tactic)",
					text =
[[
Bird, Warhawk - Well Watched Weaklings
60k, 49k
Kill 'Snowperch Matriarch', a level 37 Hero Warhawk, above the mountains.

Rewards
Beastial Tactic Fragment
]],
				},

				{
					name = L"Chaos Giant (Title)",
					text =
[[
Chaos Giant - What's Inside is What Counts
58.8k, 10.7k
Kill "Geral the Dim", a Chaos Giant. Loot a Pocket Item "Mote of Zzangal'Nes Nalanel" on him and equip it for the associated title. 

Rewards
Title: The Unflinching
]],
				},

				{
					name = L"Chaos Mutant (Token)",
					text =
[[
Chaos Mutant - Leader of the Lost
15.5k, 12.7k
Kill "Calvin Lankdorf" at the edge of the road.

Rewards
Bestial Token
]],
				},

				{
					name = L"Chaos Spawn (Acc)",
					text =
[[
Chaos Spawn - Empirical Proof
13.4k, 2.6k
Interact with the book 'Third Journal of Lliean', at Destruction PQ 'Gates of Praag'. It is hidden behind some buildings: coming from northeast entrance, enter and take directly to your left behind a building, continue a little and you'll find the book.

Rewards
Jewel Item : One Tusk
]],
				},

				{
					name = L"Hound (Tactic)",
					text =
[[
Hound - Picky Eater
8.5k, 64k and 2k, 60k
Kill 'Warpwind Night Runner' around Skaven Tunnels until one drops a Pocket Item 'Fresh Meat'. Equip it will trigger the unlock.

Or

42k, 54k
Kill 'Ungol Stallion' south of Chaos Chapter 19, until one drops a Pocket Item 'Fresh Meat'. Equip it will trigger the unlock.

Rewards
Beastial Tactic Fragment
]],
				},

				{
					name = L"Skaven (Pocket)",
					text =
[[
Skaven - Dead Eye
1.9k, 65.2k
Kill "Thashrak Bloodeye", a level 35 Champion Skaven in the "Skaven Tunnels".

Rewards
Pocket: Barbed Whip
]],
				},

				{
					name = L"Tuskgor (Pocket)",
					text =
[[
Tuskgor - Tough Meat
19k, 14.3k
Kill "Scythetusk" the Tuskgor.

Rewards
Pocket: Gorducken
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Wolf (Cloak)",
					text =
[[
Wolf - Picking Up The Pieces
20.2k, 1.5k
Kill "Winter Wolf" or "Winter Howler" mobs around this area for the Kill Collector at "Kaltenbach Expedition", Empire Chapter 20 camp.

Rewards
Back Item: Hunter Master's Pelt
]],
				},

				{
					name = L"Wraith (Acc)",
					text =
[[
Wraith - Soul Catcher
22.7k, 54k
Kill 'Gloomveil', a level 39 Wraith that is hiding under a waterfall.

Rewards
Jewel Item : Foserain
]],
				},
			},
		},

		{
			name = L"West Praag",
			entries =
			{

				{
					name = L"Chaos Spawn (Pocket)",
					text =
[[
Chaos Spawn, Daemonvine - Cutting Bonds
47.2k, 6k
Kill the Daemonvine 'Xavian's Pride' in front of a house.

Rewards
Pocket: Putrid Flower
]],
				},

				{
					name = L"Centigor (Title)",
					text =
[[
Centigor - Good to the Last Drop
44k, 45.2k
Interact with barrel "Noxious Ale" next to the herdstone.

Rewards
Title: The Unruly
]],
				},

				{
					name = L"Hound (Tactic)",
					text =
[[
Hound - Dog Gone Crazy
31.3k, 20.5k
Kill a Lost Hound.

Rewards
Beastial Tactic Fragment
]],
				},
				
				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Flayerkin (Title)",
					text =
[[
Flayerkin - One Part Agony, Three Parts Cold Wrought Iron
1.7k 41.5k - in High Pass
Loot "Flayer-Kin's Scaling Chains" from a corpse "Dead Flayerkin", inside the Tomb of the Traitor (5.2k 39.3k).

9.7k 49.1k - in High Pass
Loot "Flayerkin Hooks" from another corpse "Dead Flayerkin" inside a cave.

47.6k 33.2k - in West Praag
Loot a "Flayer-Kin's Iron Helm" from another corpse "Dead Flayerkin" inside the calls. He is near a bush, a well and an empire home.

Then turn the items in to "Kreelik of Clan Moulder" a skaven by the central campfire in Chaos Chapter 17 in Praag at 6.5k 9.7k. 

Rewards
Title: The Flayer
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Flayerkin (Title)",
					text =
[[
Flayerkin - One Part Agony, Three Parts Cold Wrought Iron
1.7k 41.5k - in High Pass
Loot "Flayer-Kin's Scaling Chains" from a corpse "Dead Flayerkin", inside the Tomb of the Traitor (5.2k 39.3k).

9.7k 49.1k - in High Pass
Loot "Flayerkin Hooks" from another corpse "Dead Flayerkin" inside a cave.

47.6k 33.2k - in West Praag
Loot a "Flayer-Kin's Iron Helm" from another corpse "Dead Flayerkin" inside the calls. He is near a bush, a well and an empire home.

Then turn the items in to "Breitenhoff the Faithful" by a campfire at Empire Chapter 17 in Praag at 12.7k 57.4k.

Rewards
Title: The Flayer
]],
				},

				{
					name = L"Big Cat (Acc)",
					text =
[[
Big Cat - Refined Tastes
58k, 42.5k - in West Praag 
TO 
300, 31k - in Praag
Kill 'Frost Growler' and 'Frost Sabretusk', just at the edge of both zones until one drops a Pocket Item 'Fine Fur Pelt'. Equip it to trigger the unlock.

Rewards
Jewel Item: The Ascendant Verses
]],
				},				
			},
		},

		{
			name = L"Chaos Wastes",
			entries =
			{

				{
					name = L"Empire (Title)",
					text =
[[
Empire - The History of the Empire
22.5k, 9k 
Click on the hidden scroll.

Reward
Title: The anarchist
]],
				},

				{
					name = L"Plaguebearer (Acc)",
					text =
[[
Plaguebearer - Organ Grinder
48k, 53k
Kill 'Grotesque Plaguebearers' until one drops a Pocket Item 'Pestilent Organ'. Equip it for the unlock.

Rewards
Jewel Item: Cytheril
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Beastmen (Tactic)",
					text =
[[
Beastman, Bestigor - Nacht to Dread
57k, 19k
Kill 60 Dreadhorn Beastmen and then talk to Harald Nacht, the Kill Collector for quest 'Dreadhorn', at Empire Chapter 22.

Rewards
Chaos Tactic Fragment
]],
				},
				
				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Beastmen (Tactic)",
					text =
[[
Beastman, Bestigor - Nacht to Dread
3.3k, 6.7k - in the Chaos Wastes

Talk to Gudlaug Nacht, the healer NPC in Ch15.

Rewards
Chaos Tactic Fragment
]],
				},				

				{
					name = L"Beastmen (Token)",
					text =
[[
Beastmen, Bray Shaman - Bigger Bray to Make Your Day
61.5k, 25.4k OR 56.6k, 27.8k
Kill 'Kratkar', Bray Shaman level 41, who stands on a hill (you can reach him following big stones just north of him) or west the road.

Rewards
Bestial Token
]],
				},

				{
					name = L"B. of Khorne (Title)",
					text =
[[
Bloodletter of Khorne - Battered But Not Forgotten
39.4k, 12.3k
Kill or talk to 'Mikhail the Profane'.
He will provide you with a 'Talisman Key' to be used in The Key to Success. 

Rewards
Title: The Sanguinary
]],
				},

				{
					name = L"B. of Khorne (Token)",
					text =
[[
Bloodletter of Khorne - The Key to Success
59.6k, 33.2k
Once you have completed the other Bestiary unlock for Bloodletter of Khorne, Battered But Not Forgotten, you should have received a 'Talisman Key'.
Use this 'Talisman Key' on a 'Battered Strongbox'. The box is in the northeast corner of the 'Reaping Fields' Order PQ, behind a bush. The chest will spawn Cihtym, a level 39 Champion Bloodletter of Khorne. 
Kill Cihtym to receive the unlock.

Rewards
Bestial Token
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Chaos Spawn (Title)",
					text =
[[
Chaos Spawn, Daemonvine - Hide and Seek
5.8k, 10k
Talk to 'Anya Gerrad' and listen to her tale. She is hidden among 3 bushes.

Rewards
Title: The Weed Whacker
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Chaos Spawn (Title)",
					text =
[[
Chaos Spawn, Daemonvine - Hide and Seek
50.8k, 60.9k
Talk to 'Xavian Gerrad' and listen to his threats. He is up on a cliff south of the road, with an unicorn next to him called 'Exhausted Unicorn'.

Rewards
Title: The Weed Whacker
]],
				},

				{
					name = L"D. of Slaanesh (Title)",
					text =
[[
Daemonette of Slaanesh - Song and Dance
15.7k, 39.7k - in the Chaos Wastes
Kill 'Eidih the Helator' (33 Champion).

Or

24.1k, 55.6k - in the Chaos Wastes
Talk to/kill 'Bladedancer' (38 Champion).

Or
62k, 53.5k - in Chaos Wastes
Kill 'Bloodsong' (level 38).

Rewards
Title: The Chaste
]],
				},

				{
					name = L"F. of Tzeentch (Title)",
					text =
[[
Firewyrm of Tzeentch - Insane in the Membrane
22.7k, 52.4k
Kill 'Corrupt Spawn', a level 39 Champion Firewyrm of Tzeentch. You can easily reach him from RvR lake. He drops a Pocket Item 'Scintillating Scale'. Equip it to trigger the associated title. 

Rewards
Title: The Insane
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"F. of Tzeentch (Title)",
					text =
[[
Flamer of Tzeentch - Hot Deal
48k, 6.5k
Kill 'Soulflame', a level 41 Flamer of Tzeentch.

Rewards
Title: The Banisher
]],
				},

				{
					name = L"Giant Bat (Acc)",
					text =
[[
Giant Bat - Not Available in Any Stores
44.6k, 3.5k
Kill 'Deathwing', a level 40 Champion Giant Bat in the Caverns of Terror. He can be found in the room furthest back. He will drop a Pocket Item 'Deathwing's Fangs'. Equip it will trigger the unlock.

Rewards
Jewel Item : Hapless Ha'penny
]],
				},

				{
					name = L"J. of Khorne (Title)",
					text =
[[
Juggernaut of Khorne - Between a Rock and a...
39.9k, 15.5k
Interact with a 'Pile of Rubble' behind some bushes for this unlock. This is a pile of rocks at the corner of some ruins. A Juggernaut of Khorne 'Unbound Mastodon' is standing close to this object.

Rewards
Title: The Immovable Object
]],
				},

				{
					name = L"L. of Change (Title)",
					text =
[[
Lord of Change - I Spy With My Eye
64.1k, 28.7k
Interact with the blue "Eye of Change", in the mountains.
Tip: To reach it, I advice you to start climbing at 60.5k 36k, to go the highest you can, then go down a little to the mountainous just south. At this moment you'll be able to go at the top of the mountain. You will eventually have to reach the "Eye of Change" at the coordinates given, walking northeast then down the mountain.

Rewards
Title: Scion of Anarchy
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Nurgling (Tactic)",
					text =
[[
Nurgling - No End to the Oozing
15.5k, 45.5k
Kill 'Corpulent Nurglings' until you collect 20 'Nurgling Ooze Samples'. Trade the 20 'Nurgling Ooze Samples' for a Pocket Item 'Ooze Booze' to Disciple's Assistant in the Lyceum at Inevitable City. Equip it to trigger the unlock.

Rewards
Daemonic Tactic Fragment
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Nurgling (Tactic)",
					text =
[[
Nurgling - No End to the Oozing
15.5k, 45.5k
Kill 'Corpulent Nurglings' until you collect 20 'Nurgling Ooze Samples'. Trade the 20 'Nurgling Ooze Samples' for a Pocket Item 'Ooze Booze' to Library Assistant in the Library at Altdorf. Equip it to trigger the unlock.

Rewards
Daemonic Tactic Fragment
]],
				},

				{
					name = L"S. of Tzeentch (Title)",
					text =
[[
Screamer - Puddles of Points
12.5k, 60k
Interact with the ‘Sunken altar’ in the pool near the cave full of screamers.

Rewards
Title: The Screamer Seeker
]],
				},

				{
					name = L"S. of Tzeentch (Cloak)",
					text =
[[
Screamer of Tzeentch - Poke'm If You Got'em
3.8k, 24.4k
Kill Vilemaw, a level 33 Champion Screamer. He can be found at the southern edge of the island where the Destruction PQ 'Lonely Tower' is.

Rewards
Back Item: Cape of the Screamer
]],
				},

				{
					name = L"Spirit Host (Tactic)",
					text =
[[
Spirit Host - Higher Caliber of Soul
40.5k, 56.5k
Kill 'Vilesoul', the level 38 champion Spirit Host, above the edge of the cliff.

Rewards
Undead Tactic Fragment
]],
				},

				{
					name = L"Wight (Title)",
					text =
[[
Wight - Dead Weight
5.8k, 2.4k
Kill 'Brimdall Yggdreidar', a level 1 Wight.

Rewards
Title: King Slayer
]],
				},

				{
					name = L"Zombie (Tactic)",
					text =
[[
Zombie - The Family That Dies Together
14.7k, 58.4k
Interact with a broken table 'Family Dining Table', inside the ruined house of the Spolfinkr Family.

Rewards
Undead Tactic Fragment
]],
				},
			},
		},

		{
			name = L"Reikland",
			entries =
			{
				{
					name = L"Chaos (Title)",
					text =
[[
Chaos - The History of the servants of Chaos
17k, 64k 
Click on the 'Hidden Scroll' located between 2 piles of wood.

Reward
Title: Foe of the Dark Gods
]],
				},

				{
					name = L"Empire (Pocket)",
					text =
[[
Empire, Knight of the Blazing Sun - What do We Have Here?
31k, 4k
Click on the 'Hidden Scroll'.

Reward
Pocket: Myrmidian Icon
]],
				},
				
				{
					name = L"Spirit Host (Tactic)",
					text = 
[[
Spirit Host - Worth the Waiting For
12.8k, 43.5k
Kill 'Mabel Reiss', a level 32 Champion.

Rewards
Undead Tactic Fragment
]],
				},

				{
					name = L"Great Cat (Tactic)",
					text =
[[
Great Cat - Not So Great Any More
58.8k, 20k
Kill the great cat Bloodmane, on the cliff's edge.

OR 

2k, 19.4k
Kill the great cat Grinya. Approach from 4k, 17k.

Rewards
Beastial Tactic Fragment
]],
				},

				{
					name = L"Hound (Pocket)",
					text =
[[
Hound - Dog Catcher
46.6k, 38k 
Interact with a 'Pet Trap' just south of Chaos Chapter 21.

Rewards
Pocket: Dog Whistle
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Wolf (Tactic)",
					text =
[[
Wolf - Fall Fur Fashions
5.5k, 51.7k - in Reikland
Kill 'Reik Wolf', black wolves, (not Reik Howlers) and collect 5 'Fine Wolf Pelt' on them.

Or

5k,12.2k - in Praag
33k, 21.5k - in West Praag
Kill 'Lynsk Wolf', black wolves, (not Lynsk Howlers) and collect 5 'Fine Wolf Pelt' on them.

Trade these items for a Pocket Item 'Wolf Pelt Cloak' to Library Assistant inside the Library in Altdorf. Equip it for the unlock. 

Rewards
Beastial Tactic Fragment
]],
				},
				
				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Wolf (Tactic)",
					text =
[[
Wolf - Fall Fur Fashions
5.5k, 51.7k - in Reikland
Kill 'Reik Wolf', black wolves, (not Reik Howlers) and collect 5 'Fine Wolf Pelt' on them.

Or

5k,12.2k - in Praag
33k, 21.5k - in West Praag
Kill 'Lynsk Wolf', black wolves, (not Lynsk Howlers) and collect 5 'Fine Wolf Pelt' on them.

Trade these items for a Pocket Item Wolf Pelt Cloak to Disciple's Assistant inside the Lyceum in The Inevitable City. Equip it for the unlock. 

Rewards
Beastial Tactic Fragment
]],
				},				
				
			},
		},

		{
			name = L"Bastion Stair",
			entries =
			{
				{
					name = L"Beastman, Gor (Acc.)",
					text =
[[
Beastman, Gor - Lair of the Brute
Kill Gor creatures in 'The Bastion Stair' Dungeon until one drops a 'Skull of the Bray-Shaman'. Click on it for the unlock.

Rewards
Jewel Item : The Seeping Larva
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"F.Hound of Khorne (Token)",
					text =
[[
Flesh Hound of Khorne - Hunters of Blood
Collect 20 'Razor Sharp Fangs' from Flesh Hound of Khorne in the middle wing of Bastion Stair Dungeon.
Talk to Kraglorn the Maker in West Praag (46.5k, 44.4k) with the 20 'Razor Sharp Fangs' in your backpack.

Rewards
Bestial Token
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"F.Hound of Khorne (Token)",
					text =
[[
Flesh Hound of Khorne - Hunters of Blood
Collect 20 'Razor Sharp Fangs' from Flesh Hound of Khorne in the middle wing of Bastion Stair Dungeon.
Talk to Griffon First Knight in West Praag (50.8k 59.5k) with the 20 'Razor Sharp Fangs' in your backpack.

Rewards
Bestial Token
]],
				},

				{
					name = L"Tuskgor (Title)",
					text =
[[
Tuskgor - Not Trying To Hide
Kill Tuskgor creatures in The Bastion Stair until one drops a "Thick Tuskgor Hide". Click on the hide for the unlock.

Rewards
Title: The Tuskgor Hunter
]],
				},
				
				{
					name = L"F.Hound of Khorne (Title)",
					text =
[[
Flesh Hound of Khorne - Sins of the Flesh
Left Wing of Bastion Stair Dungeon, 2nd PQ 'Bloodhorn Labryinth' in the last room where the boss spawns, is a Champion named Beastrip. Kill him until he drops the bind on pickup 'Rage Forged Collar', examine the collar in your inventory for the unlock.

Rewards
Title: The Bloodhound
]],
				},				
			},
		},

		{
			name = L"Altdorf",
			entries =
			{
				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Skaven (Tactic)",
					text =
[[
Skaven - Septic Sanitation
29.9k, 39.7k
Kill "Master Moulder Vitchek", a level 19 Hero Skaven inside a house.
 
Or

31k, 36k - in The Sewers of Altdorf
Kill "Master Moulder Vitchek", a level 19 Hero Skaven.

Rewards
Skaven Tactic Fragment
]],
				},
			},
		},
},		
}
