TTitan.Data.IBF = {}

function TTitan.Data.IBF.GetData()
	return TTitan.Data.IBF.RawData
end

function TTitan.Data.IBF.FilterData()
end

TTitan.Data.IBF.RawData =
{
	header = L"Instanced Boss Fights",
	categories =
	{
		{
			name = L"About This Page",
			entries =
			{
				{
					name = L"Information",
					text =
[[
The information in this page was made to aid you in boss fights, it is NOT a definitive way of killing a boss as the circumstances in each fight will vary. The information here was obtained using my own experinces and some previous knowledge of instances and how boss fights are designed.

Squigy
]],
				},

				{
					name = L"Format",
					text =
[[
Each Boss fight will have certain rules and attacks that you will have to defeat. I will cover the main objective and the skills of the boss and then rolling through the minor changes you have to make depending on what type of class make-up you have.

- 2DPS, 2Tanks, 2 Healers
- 3DPS, 1Tank, 2 Healers
- 3DPS, 2Tanks, 1 Healer
- 5DPS, 1Tank, 1 Healer

These are the main groups that a party might be constructed from. As a general rule, the most balanced and effective party will be the 2DPS, 2 Tanks and 2 Healers group, each group moving downwards will have a lower chance on sucess.
]],
				},
			},
		},

		{	-- Divider, won't expand when clicked
			name = L"---------",
			divider = true,
		},

		 {
         name=L"Bastion Stair",
			entries =
			{
				{
				name = L"Thar'lgnan",
				text =
[[
Thar'lgnan is the first instance in Bastion Stair, this particular boss requires any of the 2 healer parties, unless you healer happens to have an obscenely high amount of willpower (800+). It is recommended that one of your DPS classes can do a decent amount of AoE damage, this is however not required to complete the instance, but it is recommended.

OBJECTIVES:

The objective of this fight is to first, lure the dogs in the middle of the stadium. Make sure all the dogs around are all lured into one spot. With this done, the DPS assigned to AoE will quickly kill the dogs off the tank. The healers aim in this whole instance is to keep EVERYBODY up. When someone dies in this boss, he regenerates around 30 - 50% of his health back. This could mean a huge tide turning in this bosses favor, as this boss, as with any other instanced boss has a hidden rage ticker that will pop when you take too long to kill him. Besides the abilities mentioned below, this fight is a plain tank and spank. Melee DPS can focus on smashing the boss from behind while the tank keeps aggro off of them, the same applies to Ranges DPS, which should try and stay as far away as possible while still in range of the healers and the boss.

ABILITIES:

- He has a root ability, that will root you on the groud for a set peroid of time, this should not really effect the party at all as this targets all around him and the heals in this game are all ranged. Melee DPS in this root can just throw axes to wait it out.

- He throws people randomly to the corpses on the ground. When you first enter it is good to know that there are attackable corpses on the ground. These are the targets of where he will throw you.

- He has an AoE dot that hits anyone near him. Healers should try and stay at max range to prevent interruptions to heals and excessive damage.

- He will randomly charge and attack someone for around 900 damage to a light armour DPS. This should be quickly healed as he may do this 2 - 3 times in a row and sometimes even sneak off a normal hit which does around 2k.

- The Regenration Passive allows him to heal instantly 30 - 50% of his health when any of your party members or their pets die from his attacks.

NOTES:

- Corpses make good morale growers, if you really want, make your whole party farm a corpse until everyone has max morale. (The corpses can't die so you all can attack )

- As this boss regenertates HP upon killing anything, all pet based classes should have their pets de-summoned and their tactics changed to one supporting their damage without a pet (If applicable)

]],
				},

								{
				name = L"Lord Slaurith",
				text =
[[
Lord Slaurith is the second instance in Bastion Stair, this boss requires better co-ordination between the 6 people in the party and you MUST have a 2/2/2 group. 1 tank might suffice if they have a high amount of wounds and a blanace of toughness.

OBJECTIVES:

For this instance, you have to spread out as much as possible so that the ability he uses will only affect1 party member at a time. This avoids certain complications that might occur in the process of more then 1 member taking excessive damage.

ABILITIES:

- Lord Salurith has a skill that targets the ground. It then ticks on the target it was cast on 3 ticks of around 1k each give or take. Be sure to have more then 5.8k health for every member of your party.

- Another ability he has is a full party dot. This does around 600 damage to each member of the party and you have to live through it.

NOTES:

- The AoE has two options to survive it. One option is to take the damage. This will unfortunately make Lord Slaurith target the person who took it. This can be used to your advantage to move the tank into the dot so that he can get the aggro. The other option is to move when he casts it on you to avoid the damage. This will get him to cast the whole party dot so if you have good healers you can probably heal through the damage. 

- A AoE specced healers will help alot if you so choose to run out of the point based AoE ability.
]],
				},

				},
        },

}
}
