TTitan.Data.Lairs = {}

function TTitan.Data.Lairs.GetData()
	return TTitan.Data.Lairs.RawData
end

function TTitan.Data.Lairs.FilterData()
	TTitan.Data.FilterByRealm(TTitan.Data.Lairs.RawData)
end

TTitan.Data.Lairs.RawData =
{
	header = L"Lair Locations",
	categories =
	{
		{
			name = L"About This Page",
			entries =
			{
				{
					name = L"Credit",
					text =
[[
Return of Reckong brought many changes to lairs including disabling some of the original puzzles to access them. 
All lair information can be find on the RoR wiki page: https://wiki.returnofreckoning.com/
]],
				},

				{
					name = L"Format",
					text =
[[
I have updated this section to match how lairs are laid out in the Tome of Knowledge. 
Each lair will note what zone they are in along with what level the lair boss is. 
-Tallinah
]],
				},
			},
		},

		{	-- Divider, won't expand when clicked
			name = L"---------",
			divider = true,
			entries = {},
		},
 		{
			name = L"Lairs in Dwarf & Greenskin Lands",
			entries =
			{
				{
					name = L"Lair of Goretusk",
					text =
[[
Lair of Goretusk
Ekrund 26.6k, 29.3k
]],
				}, 
				{
					name = L"Lair of the Bandit Queen",
					text =
[[
Lair of the Bandit Queen (11)
RVR: Ekrund 58k, 3k
]],
				},
				{
					name = L"Lair of the Fleshrender",
					text =
[[
Lair of the Fleshrender
Kadrin Valley 3k, 32k
]],
				},	
				{
					name = L"Lair of Gutslime",
					text =
[[
Lair of Gutslime
Mount Bloodhorn 53k, 45k
]],
				},	
			  {
					name = L"Lair of the Shambler",
					text =
[[
Lair of the Shambler
Black Fire Pass 3.6k, 25.2k
					]],
				},	
			  {
					name = L"Lair of Ravack",
					text =
[[
Lair of Ravack
Black Fire Pass 62.1k, 7.6k
					]],
				},		
				{
					name = L"Lair of Reaver",
					text =
[[
Lair of the Reaver
Barak Varr 2k, 20k
]],
				},	
				{
					name = L"Lair of Old Oozeback",
					text =
[[
Lair of Old Oozeback
Marshes of Madness 25k, 60k
]],
				},				
				{
					name = L"Lair of Krela Darkshroud",
					text =
[[
Lair of Krela Darkshroud
Badlands 23.3k, 63.3k
]],
				},
				{
					name = L"Lair of the Fallen Slayer",
					text =
[[
Not Implemented
Tomb of the Fallen Slayer
Kadrin Valley 62.7k, 54.6k
]],
				},		
				{
					name = L"Malachia's Lair",
					text =
[[
Malachia's Lair
Black Crag 63k, 13k
]],
				},	
		},
	},

		{
			name = L"Lairs in Empire & Chaos Lands",
			entries =
			{
				{
					name = L"Migliod's Menagerie",
					text =
[[
Migliod's Menagerie
The Maw 40k, 54k
]],
				},
				{
					name = L"Lair of the Defiler",
					text =
[[
Lair of the Defiler
Ostland 9.6k, 63k
]],
				},	
        {
					name = L"Frostshard Prison",
					text =
[[
Frostshard Prison
West Praag 23k, 44k
]],
				},			
				{
					name = L"Lair of Metoh",
					text =
[[
Lair of Metoh
Troll Country 9k, 3k
]],
				},	
			  {
					name = L"Lair of Morra",
					text =
[[
Lair of Morra
Nordland 31k, 61k
]],
				},	
			  {
					name = L"Lair of Silveroak",
					text =
[[
Lair of Silveroak
Norsca 18k, 27k
]],
				},			
				{
					name = L"Lair of Gnawbone",
					text =
[[
Lair of Tezakk Gnawbone
Chaos Wastes 37.5k, 6k
	]],
				},	
			  {
					name = L"Traitor's Rest",
					text =
[[
Kamilla the Decayed (11)
RVR: Norsca 28k, 62k
]],
				},			
				{
					name = L"Lair of the Bleakwing Matriarch",
					text =
[[
Lair of the Bleakwing Matriarch
Talabecland 45k, 63k
					]],
				},
			},
		},

		{
			name = L"Lairs in  High & Dark Elven Lands",
			entries =
			{
				{
					name = L"Lair of Stinkfang the Vomitous",
					text =
[[
Lair of Stinkfang the Vomitous
Ellyrion 54.3k, 42.6k
]],
				},
				{
					name = L"Lair of Kelbrax",
					text =
[[
Lair of Kelbrax
Chrace 19k, 63k
]],
				},			
			 	{
					name = L"Lair of Gorthlak",
					text =
[[
Lair of Gorthlak
Blighted Isle 36k, 18k
]],
				},
				{
					name = L"Lair of Lady Alisha",
					text =
[[
Lair of Lady Alisha (11)
RVR: Blighted Isle 35k, 51k
]],
				},				
				{
					name = L"Lair of  Elrin Helfried",
					text =
[[
Lair of Elrin Helfried
Avelorn 61.4k, 48.2k
]],
				},
				{
					name = L"Lair of Gholnaros the Deathless",
					text =
[[
Lair of Gholnaros the Deathless
Dragonwake 23k, 42k
]],
				},
				{
					name = L"Lair of Festitt",
					text =
[[
Lair of Festitt
Caledor 34k, 36k
]],
				},
				{
					name = L"Lair of Xaphan of the Pyre",
					text =
[[
Xaphan the Pyre Lair
Caledor 54k, 27k
]],
				},				
				{
					name = L"Lair of Lady Grimgyre",
					text =
[[
Lair of Lady Grimgyre
Saphery 46.1k, 59.8k
]],
				},
			},
		},
	},
}
