TTitan.Data.Pursuits = {}

function TTitan.Data.Pursuits.GetData()
	return TTitan.Data.Pursuits.RawData
end

function TTitan.Data.Pursuits.FilterData()
	TTitan.Data.FilterByRealm(TTitan.Data.Pursuits.RawData)
end

TTitan.Data.Pursuits.RawData =
{
	header = L"Pursuit Achievements",
	categories =
	{
		{
			name = L"About This Page",
			entries =
			{
				{
					name = L"Pursuits",
					text =
[[
These are Pursuit Unlocks found in the Achievements section of your ToK.
Use "/ttitan explorations" to open the Explorations page.
]],
				},

				{
					name = L"Credit",
					text =
[[
This section has been updated by Tallinah. All unlocks are verified on Destro as of May 22, 2026.
]],
				},
			},
		},

		{	-- Divider, won't expand when clicked
			name = L"---------",
			divider = true,
			entries = {},
		},

		{
			name = L"A Delicate Art",
			entries =
			{
				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Delicate Negotiations",
					text =
[[
Unverified
BARAK VARR
56.2k, 27.8k
Kill "Roarin' Choppa" a level 2 mob. There are two of them in a group with cheering Bloody Sun Stompas, they are just inside the Greenskin camp. They can be hit with ranged attacks if entering from the south "Khaz Kol Bar" major landmark entrance, hug the left wall to avoid line of sight from the 55 guard.
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Delicate Negotiations",
					text =
[[
BARAK VARR 
56.2k, 27.8k
Talk to "Roarin' Choppa" an NPC in Greenskin chapter 8 camp, there are two of them in a group with cheering Bloody Sun Stompas.
]],
				},
			},
		},

		{
			name = L"Ale Run",
			entries =
			{
				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Ale: The Thirst Quencher",
					text =
[[
Unverified
MARSHES OF MADNESS
10.8k, 270
In the back of the Dwarf Chapter 6 camp is a small cave. Speak to Durgan Grimminsson inside the cave for this unlock.
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Alebearer",
					text =
[[
MARSHES OF MADNESS
54.8k 18k
Just south of the Dwarf Chapter 8 camp, a group of dwarfs are seen guarding and working on a machine of some sort, grumbling about lack of ale. Talking to one of them gives you this achievement.
]],
				},
				
				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Alebearer",
					text =
[[
MARSHES OF MADNESS
54.8k 18k
Just south of the Dwarf Chapter 8 camp, a group of dwarfs are seen guarding and working on a machine of some sort, grumbling about lack of ale. Killing one of them gives you this achievement.
]],
				},
			},
		},

		{
			name = L"Beauty of Pain",
			entries =
			{
				{
					name = L"Beauty of Pain",
					text =
[[
THE SHADOWLANDS
63k, 47.6k
Click on "Blood Cauldron" near the two cages and three witch elfs in the lower section of "Preemptive Strike" PQ.
]],
				},
			},
		},
		
		{
			name = L"Cannonball!",
			entries =
			{
				{
					name = L"Cannonball!",
					text =
[[
BARAK VARR
10.8k, 45.8
Click on the "Crate of Cannonballs" next to one of the cannons in The Sea's Anvil major landmark.
The crate is inside on the Northwest side of the upper deck. 
]],
				},
			},
		},

		{
			name = L"Come One, Come All",
			entries =
			{
				{
					name = L"Wandering Rock",
					text =
[[
TROLL COUNTRY
6.2k, 25.4k
Talk to "Raving Waldo" he is sitting down against some rocks, facing the "Welcome to Troll Country" PQ on the edge of Empire Chapter 5 camp.
]],
				},

				{
					name = L"Lesson Learned",
					text =
[[
TROLL COUNTRY
19.1k, 55.5k
Talk to "Raving Waldo" he is sitting down against a tree looking down over the road, just east of "Felde Castle" Empire chapter 6 camp.
]],
				},

				{
					name = L"Burdens and Bunions",
					text =
[[
TROLL COUNTRY
38.8k, 58.9k
Talk to"Raving Waldo" he is sitting down against a huge tree by the road on the left side of the ramp up to Order warcamp.
]],
				},

				{
					name = L"Mucking Green",
					text =
[[
TROLL COUNTRY
39.9k, 40.7k
Talk to"Raving Waldo" he is sitting down against a carved totem between to bushes, on the bend in the road just SW of "Trovolek Advance" Chaos chapter 8 camp.
]],
				},

				{
					name = L"Making Space",
					text =
[[
TROLL COUNTRY
54.1k, 18.9k
Talk to "Raving Waldo" he is sitting down against a large tree, on the SW side of "Trollhaugen" Chaos chapter 9 camp.
]],
				},

				{
					name = L"One For All",
					text =
[[
TROLL COUNTRY
22.6k, 22.1k
Talk to/Kill "Raving Waldo" he is sitting down against a large rock, on the mound.
]],
				},
			},
		},

		{
			name = L"Da Bigga 'Un",
			entries =
			{
				{
					name = L"Da Bigga 'Un",
					text =
[[
MARSHES OF MADNESS
26.3k, 12k
Kill a level 1 Champion Orc named "a Bigga 'U" patrolling the road outside of Hargruk's Camp.
]],
				},

				{
					name = L"Bosses",
					text =
[[
MARSHES OF MADNESS
29.9k, 11k
Kill "Black Skull Boss", there are two (either work) standing near the large ork totem.
]],
				},

				{
					name = L"Da Biggest Un'",
					text =
[[
MARSHES OF MADNESS
24.6k, 30.4k
Kill "Da Biggest 'Un", inside the hut at the end of the path.
]],
				},
			},
		},

		{
			name = L"Dirty Dealings",
			entries =
			{
				{
					name = L"Enemy of my Enemy",
					text =
[[
MOUNT BLOODHORN
41.8k, 18.9k
Approach the ruined tower inside the Dwarf Chapter 4 camp.
Note for Destruction: Hug the left cliff face along the rib bones to avoid the guards and make it up to the tower.
]],
				},

				{
					name = L"Profiteering",
					text =
[[
MOUNT BLOODHORN
42.2k, 10.8k
Kill "Dog Paymaster" during the second stage of "Traitor's Watch" PQ.
]],
				},

				{
					name = L"Supply & Demand",
					text =
[[
MOUNT BLOODHORN
35.7k, 14.8k
Click on "Merchant's Traveling Gear" a backpack on the floor behind the blue tent.
]],
				},
				
				{
					name = L"Dirty Dealin'",
					text =
[[
MOUNT BLOODHORN
52k, 8.5k
Kill "Ranulf Baumann" a level 8 hero. Standing just in front of a patchwork tent.
]],
				},
			},
		},

		{
			name = L"Durak's Journal",
			entries =
			{
				{
					name = L"Durak's Journal",
					text =
[[
MOUNT BLOODHORN 
26.4k, 32k
Click on "Durak's Journal" inside "Forgotten Hold" major landmark, you'll find a sarcophagus with the journal sitting next to it.
]],
				},
				
				{
					name = L"Durak's Last Days",
					text =
[[
MOUNT BLOODHORN
53.1k, 13.7k
Click on "Durak's Tome" on the floor on the lowest level of "Gnol Barak" major landmark, between a pillar and a cannon.
]],
				},
			},
		},

		{
			name = L"Grebo's Pile",
			entries =
			{
				{
					name = L"Grebo's Pile",
					text =
[[
BARAKK VARR
5.8k, 34.4k
Click on "Grebo's Pile" inside the ruined tower, SW of "Nogaz's Boyz" Greenskin chapter 5 camp.
]],
				},

				{
					name = L"Oltrak Steelbarrel",
					text =
[[
BARAK VARR
5.2k, 34k
Talk to/Kill "Oltrak Steelbarrel" standing in front of the ruined tower.
]],
				},
			},
		},

		{
			name = L"Greenskin Games",
			entries =
			{
				{
					name = L"Greenskin Games",
					text =
[[
BLACK CRAG
62k, 31.5k
Click on "Smashed Orc" in the cave at the back of the fighting pit, in "Da Great Smashin' Pit" PQ.
]],
				},
			},
		},

		{
			name = L"Greenskin Humor",
			entries =
			{
				{
					name = L"Greenskin Humor",
					text =
[[
BLACK CRAG
23.1k, 43.2k
Click on "Git-in-a-Barrel" next to the end of the bridge.
]],
				},
			},
		},

		{
			name = L"Harsh Punishment",
			entries =
			{
				{
					name = L"Harsh Punishment",
					text =
[[
OSTLAND
27.5k, 17k. 
Interact with 'Signpost', among skeletons. The good signpost is the first you see on the south of the road, when you come from east of the road.
]],
				},
			},
		},		

		{
			name = L"Illiteracy",
			entries =
			{
				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Illiteracy",
					text =
[[
NORDLAND. 
26.8k 55.5k
Interact with 'Sheet of Paper' in the Empire Chapter 1. It is a white paper above the central table, among 2 other tables. 'Scrivener Elwin' is standing in front of the paper.
]],
				},
				
				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Illiteracy",
					text =
[[
Not Implemented
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Wolfram's Letter",
					text =
[[
Not verified
1. Take the quest 'Alive and Well' from 'Wolfram Becker' in Altdorf at 24.3k 34.9k.
2. He asks you to take his letter 'Wolfram's Letter' which is inside the building behind him; interact with it.
3. Then fly to Nordland and head to Empire Chapter 1, and find his wife 'Agatha Becker' at 26.5k 53.2k to complete the quest.
4. Once finished, take the other part of the quest from Agatha 'Alive and Well'.
5. Talk once again to Agatha to complete the quest.
6. Once finished you will receive a trophy reward 'Agatha's Thanks'. Equip it for the unlock.
]],
				},
			},
		},

		{
			name = L"Loyal Companion",
			entries =
			{
				{
					name = L"Loyal Mastiff",
					text =
[[
OSTLAND
48.7k, 52.2k
Talk to "Randulf Ackermann" an NPC in "Wolfenburg Inn" Empire chapter 9 camp. He is standing to the side of a tent in the middle.
]],
				},

				{
					name = L"Better Off Dead",
					text =
[[
OSTLAND
47.3k, 62.3k
Kill "Zombified Hound" on the far southside of "Wolfenburg" major landmark. It is between the mill and the large house, towards the back.
]],
				},

				{
					name = L"Bruno's Safe Return",
					text =
[[
OSTLAND
47.3k, 62.3k
Kill "Zombified Hound" to get the quest item "Bruno's Collar". Click it to start the quest "Bruno's Fate", and return it to "Randulf Ackermann" at 48.7k, 55.2k. Complete the quest for the unlock.
]],
				},

				{
					name = L"Who's A Good Boy?",
					text =
[[
Not Implemented
OSTLAND
48.7k, 52.2k
Talk to "Bruno", he appears once you complete the above achivements.
]],
				},
			},
		},

		{
			name = L"Medicinal Purposes",
			entries =
			{
				{
					name = L"Shameful Ailments",
					text =
[[
KADRIN VALLEY
20.1k, 62.6k
Click on "Elgi Wine" on the left side of the entrance to the tower, in "The Sealed Tower" PQ.
]],
				},

				{
					name = L"Bleed It Out",
					text =
[[
CINDERFALL
59.1k, 35.8k
Click on "Cultist Blades" on a couple of crates, to the side of the cart.
]],
				},

				{
					name = L"Sweat It Out",
					text =
[[
DEATH PEAK
10.9k, 29.2k
Click on "Sauna Water" next to the lake of lava.
]],
				},

				{
					name = L"Grease For The Gut",
					text =
[[
CINDERFALL
46.3k, 9.8k
Click on "Rhinox Lard", a small barrel on the mortar platform.
]],
				},
				
				{
					name = L"Shock It Up",
					text =
[[
THUNDER MOUNTAIN
62.5k, 41.5k
Click on "Azorgari Lightning Rod", west of the road, next to the dragon skull.
]],
				},

				{
					name = L"Chills For The Chills",
					text =
[[
KADRIN VALLEY
48.6k, 11.2k
Click on "Box of Ice", round the North West side of "Peak Tower" Major Landmark.
]],
				},

				{
					name = L"The Cure For What Ales You",
					text =
[[
DEATH PEAK
2.1k, 60k
Click on "Aged Bugman's" a barrel inside the building, just left of the fireplace.
]],
				},
			},
		},	

		{
			name = L"Ostland Corruption",
			entries =
			{
				{
					name = L"Ostland Corruption",
					text =
[[
OSTLAND
45k, 15.3k
Click on "Magistrate's Warrant" a piece of paper at the top of the stairs, round the back of the large building.
]],
				},

				{
					name = L"A Cry In The Night",
					text =
[[
OSTLAND
36.8k, 35.6k
Kill "Rupert Millson" a level 15 mob, standing outside by the tower, just to the right of the stairs.
]],
				},

				{
					name = L"Purchased Silence",
					text =
[[
OSTLAND
36.8k, 35.6k
Equip "Pouch full of Karls" pocket items, dropped by "Rupert Millson".
]],
				},
			},
		},

		{
			name = L"Random Sacrifice",
			entries =
			{
				{
					name = L"Ritual of Tzeentch",
					text =
[[
NORSCA
32.6k 26.9k
Interact with the 'Altar of the Raven'. A 'Tzeentch Cultist' is doing a ritual in front of it, and a 'Warped Peasant' is flying above the altar. (Destruction side of the map)

Or

54.6k 37k
Interact with the 'Altar of the Raven' A 'Tzeentch Cultist' is doing a ritual in front of it, and a 'Warped Peasant' is flying above the altar. (Order side of the map)

Or

59.7k 59.6k
Interact with the 'Altar of the Raven'.
]],
				},

				{
					name = L"Ritual of Khorne",
					text =
[[
NORSCA
32k 45.4k
Interact with the 'Altar of Bloodshed'. A 'Khorne Cultist' is doing a ritual in front of it, and a 'Bloodied Peasant' is flying above the altar.

Or

48.5k 60.6k
Interact with the 'Altar of Bloodshed'.

Or

20.2k 46k
Interact with the 'Altar of Bloodshed'.
]],
				},

				{
					name = L"Ritual of Nurgle",
					text =
[[
NORSCA
42.3k 33.3k
Interact with the 'Altar of Decay'. A 'Nurgle Cultist' is doing a ritual in front of it, and a 'Rotting Peasant' is laying on the altar.

Or

45.6k 53.8k
Interact with the 'Altar of Decay'.
]],
				},

				{
					name = L"Ritual of Slaanesh",
					text =
[[
NORSCA
34.3k 41.5k
Interact with the 'Altar of the Shameless'. A 'Slaanesh Cultist' is doing a ritual in front of it, and an 'Enslaved Peasant' is laying on the altar.
]],
				},
			},
		},

		{
			name = L"Shameful Behavior",
			entries =
			{
				{
					name = L"Out of Sorts",
					text =
[[
OSTLAND
31.6k, 28.1k
Click on "Bohsenfels Ale" a stein on the bar counter inside the tavern.
Note for Destruction: This is reachable, however, you need to be careful and go wide around the chapter camp to enter the tavern. 
]],
				},
			},
		},

		{
			name = L"Sign of Change",
			entries =
			{
				{
					name = L"Sign of Change",
					text =
[[
NORSCA
39.1k, 20k
Click on "Eye of Change" at the centre of the chaos crater, the first Chaos PQ Ruinous Powers.
]],
				},
			},
		},

		{
			name = L"Special Character",
			entries =
			{
				{
					name = L"Special Character",
					text =
[[
CHAOS WASTES
41k, 59k
Kill/talk to "Grunthar Deathwielder", and loot the item "Vandalized Imperial Cross".
]],
				},
				
				{
					name = L"Challenge of Champions",
					text =
[[
CHAOS WASTES
56.5k, 48.4k
Kill/talk to "Vy'tak Tz'kul", and loot the item "Looted Twin-tailed Comet Icon".
]],
				},
				
				{
					name = L"Ultimate Destiny",
					text =
[[
CHAOS WASTES
49.4k, 2.2k
Kill/talk to "Bellande Soultaker", and loot the item "Stolen Imperial Amulet".
]],
				},
				
				{
					name = L"Championhood",
					text =
[[
Not Implemented for Destruction
CHAOS WASTES
61.1k, 4.2k
Trade the 3 items from the above unlocks, for "Imperial Chapion's Mark" at the merchant "Theofil Karstgard" in Empire Chapter 22 camp. Then equip it for the unlock.
]],
				},			
			},
		},

		{
			name = L"Squig'uns!",
			entries =
			{
				{
					name = L"Getting Et",
					text =
[[
Not verified
GUNBAD
38.9k, 31k
Click on "Dead Squig Trainer" behind the wooden stake barrier.
]],
				},
				
				{
					name = L"Not Getting Et",
					text =
[[
Not verified
GUNBAD
38.9k, 42.9k
Kill "Squig Bait" a snotling, standing on the little island.
]],
				},
			},
		},

		{
			name = L"Squig Taming",
			entries =
			{
				{
					name = L"Squig Training",
					text =
[[
Not Implemented Yet
]],
				},
			},
		},

		{
			name = L"Stirring up Trouble",
			entries =
			{
				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Stirring up Trouble",
					text =
[[
Not Implemented Yet
]],
				},
				
				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Stirring up Trouble",
					text =
[[
NORDLAND
26.7k 52.9k
Talk to the 'Frightened Peasant' at the Empire Chapter 1 camp.
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Stirring up More Trouble",
					text =
[[
NORDLAND
20k 28.4k
Talk to 'Frightened Peasant' in Empire Chapter 2, inside Grey Lady Inn. He is at the second floor.
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Troubling Indeed",
					text =
[[
NORDLAND
32.5k 19.1k
Talk to 'Frightened Peasant' at the Empire Chapter 3 camp. There are 2 other NPC "attacking" him, and a 'Pious Hunter' in front of him.
]],
				},
			},
		},

		{
			name = L"Subversion",
			entries =
			{
				{
					name = L"Subversion",
					text =
[[
Verified for Destruction Only
NORDLAND
52.1k, 53.7k
Inside the tent you will find two NPCs 'Dirk Eisenhauer' and 'Luthor Vogt'. Kill Dirk to obtain a quest starter. Once you’ve examined the item and completed the quest you will get the achievement along with a 'Wizard's Key' that teleports you inside the Wizard Tower.
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Brotherhood of Nuln",
					text =
[[
NORDLAND 
Use the 'Wizard's Key' that teleports you inside the Wizard Tower obtained by completing the Subversion achievement.
Once you are inside Wizard Tower, search 'Heironymous of Nuln', a level 9 Bright Wizard Hero. Kill him for this second unlock. You eventually have to take the portal behind him to escape from this tower.
]],
				},
			},
		},

		{
			name = L"The Creator",
			entries =
			{
				{
					name = L"The Creator",
					text =
[[
Not Implemented Yet
]],
				},
				
				{
					name = L"Of Beggings",
					text =
[[
Not Implemented Yet
]],
				},
				
				{
					name = L"Of Endings",
					text =
[[
Not Implemented Yet
]],
				},
			},
		},

		{
			name = L"The Forgekeepers",
			entries =
			{
				{
					name = L"The Forgekeepers",
					text =
[[
Not Implemented Yet
]],
				},
				
				{
					name = L"Fire Under the Mountain",
					text =
[[
THUNDER MOUNTAIN
47.5k, 34.6k
Click on "Ancient Skeleton" at the back of "Gromril Kruk" BO.
]],
				},
				
				{
					name = L"World Ember",
					text =
[[
THUNDER MOUNTAIN
58.2k, 31.5k
Equip "Spark of Karag Dron", obtained by clicking on "Rune-Sealed Container" behind the forge.
]],
				},
				
				{
					name = L"???",
					text =
[[
Not Implemented Yet
]],
				},
			},
		},

		{
			name = L"The Gateway to Ultimate Knowledge",
			entries =
			{
				{
					name = L"Mysterious Gateway",
					text =
[[
THE BLIGHTED ISLE
35.5k 16.2k
Interact with 'Tainted Crystal', near the entrance of the Lair of Gorthlak.
]],
				},

				{
					name = L"Chasing Wisdom",
					text =
[[
THE BLIGHTED ISLE
35.7k 16.3k
Interact with one of the 'Stone of Wisdom'. Each Stone of Wisdom triggers a different unlock of this pursuit.
]],
				},

				{
					name = L"Pursuit of Knowledge",
					text =
[[
THE BLIGHTED ISLE
35.7k 16.3k
Interact with one of the 'Stone of Wisdom'. Each Stone of Wisdom triggers a different unlock of this pursuit.
]],
				},

				{
					name = L"Deep in Study",
					text =
[[
THE BLIGHTED ISLE
35.7k 16.3k
Interact with one of the 'Stone of Wisdom'. Each Stone of Wisdom triggers a different unlock of this pursuit.
]],
				},

				{
					name = L"Teach Them Well",
					text =
[[
THE BLIGHTED ISLE
35.7k 16.3k
Interact with one of the 'Stone of Wisdom'. Each Stone of Wisdom triggers a different unlock of this pursuit.
]],
				},

				{
					name = L"The Gateway to Ultimate Knowledge",
					text =
[[
THE BLIGHTED ISLE
35.7k 16.3k
Interact with 'Cleansed Crystal'.
]],
				},
			},
		},

		{
			name = L"The Herald",
			entries =
			{
				{
					name = L"The Herald",
					text =
[[
TROLL COUNTRY
22.7k 11.5k
Kill 'The Herald', a Zealot Champion level 18.
]],
				},

				{
					name = L"Wandering Alone",
					text =
[[
TROLL COUNTRY
22.7k 11.6k
Kill one of the 'Minion of Flame' behind The Herald.
]],
				},

				{
					name = L"Carrying His Word",
					text =
[[
TROLL COUNTRY
22.7k 11.6k
'The Herald' will drop a Pocket Item 'Profane Writ'. Equip it for this last unlock.
]],
				},
			},
		},

		{
			name = L"The Last Upholder",
			entries =
			{
				{
					name = L"The Last Upholder",
					text =
[[
BLACK FIRE PASS
13.4k, 36.2k
Talk to "The Last Upholder" a NPC praying at an alter on the west side of "Snow Peak Temple" major landmark.
]],
				},

				{
					name = L"Standing Against the Tide",
					text =
[[
BLACK FIRE PASS
13.5k, 35.9k
Click on "The Last Upholder's Pack" to start the quest "One Man's Struggle". Click on the pack again to complete the quest and get the unlock.
]],
				},

				{
					name = L"Borrowed Time",
					text =
[[
BLACK FIRE PASS
13.5k, 35.9k
Equip "The Last Upholder's Watch" pocket item, rewarded when completing the quest "One Man's Struggle" for the above unlock.
]],
				},
			},
		},

		{
			name = L"The Littlest Beastmaster",
			entries =
			{
				{
					name = L"???",
					text =
[[
Not Implemented Yet
]],
				},
			},
		},	
		
		{
			name = L"The Teacher",
			entries =
			{
				{
					name = L"The Teacher",
					text =
[[
ELLYRION
1.3k, 45.7k
Kill "The Teacher" a level 20 Hero. Click on "Asur Tablet" to spawn him if he is not there.
]],
				},

				{
					name = L"Lesson to be Learned",
					text =
[[
ELLYRION
1.3k, 45.7k
Kill "The Teacher" a level 20 Hero, again. Click on "Asur Tablet" to spawn him.
]],
				},

				{
					name = L"The Master",
					text =
[[
ELLYRION
1.3k, 45.7k
Equip "Teacher's Chain" pocket item, dropped by "The Teacher".
]],
				},
			},
		},
		
		{
			name = L"",
			entries =
			{
				{
					name = L"",
					text =
[[

]],
				},
			},
		},
	},
}
