TTitan.Data.NoteworthyEvC = {}

function TTitan.Data.NoteworthyEvC.GetData()
	return TTitan.Data.NoteworthyEvC.RawData
end

function TTitan.Data.NoteworthyEvC.FilterData()
	TTitan.Data.FilterByRealm(TTitan.Data.NoteworthyEvC.RawData)
end

TTitan.Data.NoteworthyEvC.RawData =
{
	header = L"Noteworthy Persons Unlocks - Empire vs Chaos",
	categories =
	{
		{
			name = L"Nordland",
			entries =
			{
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Eldred Krebs",
					text =
[[
26k, 54.3k
Rally Master, Chapter 1 'Grimmerhagen'.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Werner Fassbinder",
					text =
[[
21.6k, 27.3k
Rally Master, Chapter 2 'Grey Lady Coaching Inn'.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"General Breuer",
					text =
[[
32k, 18.3k
Rally Master, Chapter 3 'Breur's Regiment'.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Captain Arnholdt",
					text =
[[
29k, 19.2k
'Arnholdt's Company' Warcamp.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Caemris Sharpspear",
					text =
[[
23.5k, 40.3k 
Kill Collector, Chapter 1 'Grimmerhagen Windmill'.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Edwin Hulsemann",
					text =
[[
20.5k, 26k
Kill Collector, Chapter 2 'Grey Lady Coaching Inn'.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Lieutenant Boen Scharmdorf",
					text =
[[
31.6k, 20.7k
Kill Collector, Chapter 3 'Breur's Regiment'.

Stands by the road.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Volshehk",
					text =
[[
41.8k, 1k
Rally Master, Chapter 3 'Death's Brink'.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Authun Skandsen",
					text =
[[
57.7k, 19.8k
Rally Master, Chapter 4 'Authun's Host'.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Orlyg Raud",
					text =
[[
41.7k, 1.4k
Kill Collector, Chapter 3 'Death's Brink'.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Golen",
					text =
[[
57.9k, 20.8k
Kill Collector, Chapter 4 'Authun's Host'.
]],
				},
				
				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Creve Avdvare",
					text =
[[
40.3k, 3.2k
Blessed Gathering War Camp
]],
				},				
			},
		},

		{
			name = L"Norsca",
			entries =
			{
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Captain Kleinke",
					text =
[[
55.3k, 57.5k
Rally Master, Chapter 4 'Gotland Advance'.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Thomas Schmidt ",
					text =
[[
54k, 57.5k
Kill Collector, Chapter 4 'Gotland Advance'.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"The Eidolon",
					text =
[[
34k, 13.4k
Rally Master, Chapter 1 'Unshackled Host.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Haldar",
					text =
[[
36.8k, 32.5k
Rally Master, Chapter 2 'Sorcerer's Axiom'.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Creve Avdvare",
					text =
[[

'Blessed Gathering' Warcamp. (40.5,4.1k)
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Vaulkor",
					text =
[[
34k, 14k
Kill Collector, Chapter 1 'Unshackled Host'.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Vasili Tomarev",
					text =
[[
36.3k, 33.5k
Kill Collector, Chapter 2 'Sorcerer's Axiom'.
]],
				},
			},
		},

		{
			name = L"Troll Country",
			entries =
			{
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Siegmund Kraemer",
					text =
[[
6.4k, 23k
Rally Master-Empire Chapter 5.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Captain Oswin Breitenbach",
					text =
[[
17.3k, 53.6k
Rally Master-Empire Chapter 6-Felde Castle.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Presbyter Gillian",
					text =
[[
38.5k, 62.2k
Bramble Hollow Warcamp. NOTE: Unlock received by clicking Presbyter Fromme
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Ruthgar",
					text =
[[
6.4k, 23.5k
Kill Collector-Empire Chapter 5-Suskarg.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Dieter Stroh",
					text =
[[
16.5k, 53.6k
Kill Collector-Empire Chapter 6-Felde Castle.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Gunvor",
					text =
[[
12.8k, 62.5k
Rally Master, Chapter 6 'Felde'.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Halza",
					text =
[[
42.2k, 39.3k
Rally Master, Chapter 8 'Trovolek'.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Yggdren",
					text =
[[
54.2k, 16.4k
Rally Master, Chapter 9 'Trollhaugen'.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Gottfried Holz",
					text =
[[
11.8k, 63k
Kill Collector, Chapter 6 'Felde'.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Nina",
					text =
[[
42.8k, 39.5k
Kill Collector, Chapter 8 'Trovolek'.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Lilja Shadowdrinker",
					text =
[[
54.8k, 15.7k
Kill Collector, Chapter 9 'Trollhaugen'.
]],
				},
				
				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Thrain Troldhelm",
					text =
[[
2.4k, 56.4k
Keep Lord 'Stonetroll Keep'.
]],
				},				
			},
		},

		{
			name = L"Ostland",
			entries =
			{
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Sergeant Kraussner",
					text =
[[
54k, 1.9k
Rally Master - Empire Chapter 7 - Kraussner's Charge.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Demona Gaertner",
					text =
[[
32k, 26k
Rally Master - Empire Chapter 8 - Bohsenfels.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Liebert Naubhof",
					text =
[[
49k, 54k
Rally Master - Empire Chapter 9 - Wolfenburg.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Farmer Nadezhda",
					text =
[[
53.5k, 1.7k
Kill Collector - Empire Chapter 7 - Kraussner's Charge.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Droki Greybeard",
					text =
[[
30.4k, 26k
Kill Collector - Empire Chapter 8 - Bohsenfels.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Dieter Totenhosen",
					text =
[[
48.5k, 50.7k
Kill Collector - Empire Chapter 9 - Wolfenburg.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Turaanos",
					text =
[[
7.6k, 27k
Rally Master, Chapter 5 'Ferlangen'.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Kournar",
					text =
[[
53.2k, 12.4k
Rally Master, Chapter 7 'Kournos' Encampment'.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Zaccur the Despised",
					text =
[[
28k, 4k
'Ravens Edge' Warcamp.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Rangrith",
					text =
[[
7.4k, 26.7k
Kill Collector, Chapter 5 'Ferlangen'.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Tosha Schreiber",
					text =
[[
53k, 11.7k
Kill Collector, Chapter 7 'Kournos' Encampment'.
]],
				},
			},
		},

		{
			name = L"High Pass",
			entries =
			{
				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Captain Nuhr",
					text =
[[
4.6k, 29.2k
Rally Master-Empire Chapter 10-Nuhr's Crest.
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Grizela Hirtzel",
					text =
[[
9k, 58.4k
Rally Master-Empire Chapter 11-Raven's End.
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Konrad Riese",
					text =
[[
43k, 57.3k
Rally Master-Empire Chapter 12-Bitter Woods.
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Teodor Hennschel",
					text =
[[
35.7k, 56.9k
Dogbite Ridge Warcamp.
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Rolf Grimwold",
					text =
[[
4.6k, 27.5k
Kill Collector-Empire Chapter 10-Nuhr's Crest.
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Vilmer DonHeisen",
					text =
[[
10.8k, 59.5k
Kill Collector-Empire Chapter 11-Raven's End.
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Archibald Fleck",
					text =
[[
43.8k, 55.8k
Kill Collector-Empire Chapter 12-Bitter Woods.
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Urun",
					text =
[[
37.3k, 32.3k
Rally Master, Chapter 13 'Bloodmarr'.
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Albodi the Scarred",
					text =
[[
49k, 20.7k
Rally Master, Chapter 14 'Jaggedspine Ridge'.
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Kaltea Wyrmreaver",
					text =
[[
35.5k, 32.8k
Kill Collector, Chapter 13 'Bloodmarr'.
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Norrmar Boneblade",
					text =
[[
49k, 22.4k
Kill Collector, Chapter 14 'Jaggedspine Ridge'.
]],
				},
			},
		},

		{
			name = L"Talabecland",
			entries =
			{
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Captain Melicent Drauwulf",
					text =
[[
61.6k, 9.3k
Rally Master-Empire Chapter 13-Hergig Landing.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Emil Trachsel",
					text =
[[
45k, 43.8k
Rally Master-Empire Chapter 14-Unterbaum Cemetary.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Borak Brightaxe",
					text =
[[
61.6k, 11k
Kill Collector-Empire Chapter 13-Hergig Landing.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Mary Delarue",
					text =
[[
44.7k, 42.8k
Kill Collector-Empire Chapter 14-Unterbaum Cemetary.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Vul'toren",
					text =
[[
3.4k, 30k
Rally Master, Chapter 10 'Goblin's Head Coaching Inn'.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Arinbjorn",
					text =
[[
16.2k, 3.8k
Rally Master, Chapter 11 'Witches' Hollow'.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Ulvarin",
					text =
[[
42.7k, 5k
Rally Master, Chapter 12 'Volgen'. 
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Telva Silverwheel",
					text =
[[
22k, 5.6k
'Hellfang Ridge' Warcamp. 
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Harkon Steinkell",
					text =
[[
2k, 29.7k
Kill Collector, Chapter 10 'Goblin's Head Coaching Inn'.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Fnord Bulweis",
					text =
[[
16.3k, 3.5k
Kill Collector, Chapter 11 'Witches' Hollow'.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Reikl Bloodpike",
					text =
[[
42.5k, 5k
Kill Collector, Chapter 12 'Volgen'.
]],
				},
			},
		},

		{
			name = L"Praag",
			entries =
			{
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Captain Lieberholz",
					text =
[[
13.9k, 56k
Rally Master-Empire Chapter 17-Lieberholz's Command.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Captain Becker",
					text =
[[
14.1k, 49.5k
Rally Master-Empire Chapter 18-Death's Cross.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Krasa Falkenheim",
					text =
[[
27.7k, 24.7k
Rally Master-Empire Chapter 19-Knight's Watch.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"General Ludwig Kunst",
					text =
[[
16.2k, 35.6k
Westmark Barricade Warcamp.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Hartlieb Roth",
					text =
[[
13.2k, 58.3k
Kill Collector-Empire Chapter 17-Lieberholz's Command.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Danil Balk",
					text =
[[
15.5k, 50k
Kill Collector-Empire Chapter 18-Death's Cross.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Guildmaster Geoff",
					text =
[[
29k, 25.2k
Kill Collector-Empire Chapter 19-Knight's Watch.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Korzah the Exalted",
					text =
[[
7k, 10.5k
Rally Master, Chapter 17 'Korzah's Assault'.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Exalted Magus Thurik",
					text =
[[
48.1k, 4.5k
Rally Master, Chapter 18 'Daemonfire'.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Lord Xyshrenth",
					text =
[[
45k, 48k
Rally Master, Chapter 19 'Southern Breach'.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Magedon the Omnicient",
					text =
[[
45k, 38.7k
'Ravensworn' Warcamp.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Aesa Heidrdottir",
					text =
[[
6.3k, 8k
Kill Collector, Chapter 17 'Korzah's Assault'.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Zalir Shadowtalon",
					text =
[[
47.8k, 5.6k
Kill Collector, Chapter 18 'Daemonfire'.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Lahkis Curseblade",
					text =
[[
45k, 47.3k
Kill Collector, Chapter 19 'Southern Breach'.
]],
				},
			},
		},

		{
			name = L"Chaos Wastes",
			entries =
			{
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Valdred Kaltenbach",
					text =
[[
19.8k, 62.5k
Rally Master-Empire Chapter 20-Kaltenbach Expedition. 
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Sigric Drakenhof",
					text =
[[
53.2k, 44.8k
Rally Master-Empire Chapter 21-Camp of the Faithful. 
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"General Vogel",
					text =
[[
61.2k, 5.5k
Rally Master-Empire Chapter 22-Fires of Sigmar.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Captain Kalder Tannenbach",
					text =
[[
45k, 37.3k
Tannenbach's Doom Warcamp.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Constable Luidheim",
					text =
[[
18k, 62.8k
Kill Collector-Empire Chapter 20-Kaltenbach Expedition.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Quartermaster Randol",
					text =
[[
53.7k, 45.8k
Kill Collector-Empire Chapter 21-Camp of the Faithful.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Harald Nacht",
					text =
[[
60.9k, 2.7k
Kill Collector-Empire Chapter 22-Fires of Sigmar.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Larus",
					text =
[[
2.9k, 5.1k
Rally Master, Chapter 15 'Deathchill'. 
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Ydreda",
					text =
[[
13k, 47.4k
Rally Master, Chapter 16 'Awakened Tempest'. 
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Loefret the Hatebringer",
					text =
[[
23.7k, 30.5k
'Seven Shades Creep' Warcamp.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Xahiriek",
					text =
[[
3.1k, 6.5k
Kill Collector, Chapter 15 'Deathchill'.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Gorfing Headsmasha",
					text =
[[
12.2k, 46k
Kill Collector, Chapter 16 'Awakened Tempest'.
]],
				},
			},
		},

		{
			name = L"Reikland",
			entries =
			{
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Elmeric Oberholzer",
					text =
[[
7.5k, 34k
Rally Master-Empire Chapter 15-Kreuznach.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Greta Machholt",
					text =
[[
18.7k, 14.9k
Rally Master-Empire Chapter 16-Reik River Observatory.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"General Gellert",
					text =
[[
23.9k, 12.4k
Deathwatch Landing Warcamp.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Barnabus Kuhn",
					text =
[[
7.3k, 32.4k
Kill Collector-Empire Chapter 15-Kreuznach.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Sigrid Widmann",
					text =
[[
21k, 16.8k
Kill Collector-Empire Chapter 16-Reik River Observatory.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Astryth the Reaver",
					text =
[[
48.4k, 8.3k
Rally Master, Chapter 20 'Mark of the Reaver'.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Chieftain Vanik",
					text =
[[
45.6k, 34.7k
Rally Master, Chapter 21 'Vanik's Horde'.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Khyathor",
					text =
[[
35k, 53.5k
Rally Master, Chapter 22 'The Inevitable Fire'.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Lord Xyshrenth",
					text =
[[
40.4k, 30.5k
Drkstone Vantage War Camp,
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Jarl Spearfist",
					text =
[[
48k, 8.1k
Kill Collector, Chapter 20 'Mark of the Reaver'.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Amundr the Despoiler",
					text =
[[
44.5k, 34.7k
Kill Collector, Chapter 21 'Vanik's Horde'.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Gorfaug Manhewer",
					text =
[[
33.3k, 55.5k
Kill Collector, Chapter 22 'The Inevitable Fire'. 
]],
				},
			},
		},

		{
			name = L"Altdorf",
			entries =
			{
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"High King Thorgrim Grudgebearer",
					text =
[[
23.2k, 17.2k
Just west of the throne room in the Emperor's Palace, in a discussion with Phoenix King Finubar.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Emperor Karl Franz",
					text =
[[
25.6k, 17.1k
In the throne room of the Emperor's Palace
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Supreme Patriarch Thyrus Gormann",
					text =
[[
32k, 34.3k - Entrance
Inside the Bright College, floating in the huge pillar of fire.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Gotrek and Felix",
					text =
[[
36.3k, 40.3k
In the Screaming Cat inn, at the southern end of the docks.
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Phoenix King Finubar",
					text =
[[
23.2k, 17.6k
Just west of the throne room in the Emperor's Palace, in a discussion with High King Thorgrim (19000,3500)
]],
				},
			},
		},

		{
			name = L"The Inevitable City",
			entries =
			{
				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Grumlok",
					text =
[[
27.7k, 16.7k
'The Eternal Citadel'.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Gazbag",
					text =
[[
27.7k, 16.7k
'The Eternal Citadel'.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Tchar'zanek",
					text =
[[
30.9k, 17.1k
'The Eternal Citadel'.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Engra Deathsword",
					text =
[[
41.8k, 34k
'The Arena'.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Lycithas the Harridan Seer",
					text =
[[
22.5k, 37k
Use the teleport inside 'The Apex'.
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Malekith",
					text =
[[
27.8k, 16.8k
'The Eternal Citadel'. 
]],
				},
			},
		},
	},
}
