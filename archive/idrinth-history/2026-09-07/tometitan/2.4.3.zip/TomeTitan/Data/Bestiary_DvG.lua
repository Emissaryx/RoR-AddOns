TTitan.Data.BestiaryDvG = {}

function TTitan.Data.BestiaryDvG.GetData()
	return TTitan.Data.BestiaryDvG.RawData
end

function TTitan.Data.BestiaryDvG.FilterData()
	TTitan.Data.FilterByRealm(TTitan.Data.BestiaryDvG.RawData)
end

TTitan.Data.BestiaryDvG.RawData =
{
	header = L"Beastiary Unlocks - Dwarfs vs Greenskins",
	categories =
	{
		{
			name = L"Ekrund",
			entries =
			{
				{
					name = L"Ironbreaker (Pocket)",
					text =
[[
Dwarf, Ironbreaker - What do We Have Here?
50k, 9k
Use the 'Hidden Scroll' just outside a dwarf tower due S of the Stonemine Tower BO.

Reward
Pocket: Endless List of Grudges
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Squig (Title)",
					text =
[[
21.2k, 38.9k
Talk to "Lormina Falinsdotr" on the left inside "Pick & Google" major landmark, then purchase and use "Squig-On-A-Stick".

Rewards
Title: The Gourmand
]],
				},

        {
					realm = TTitan.Data.Realm.ORDER,
					name = L"Plaguebearer (Title)",
					text =
[[
Plaguebearer - A Tale by the Fire
45.4k, 29.7k
Talk to 'Witch Hunter Adept' in Dwarf Chapter 2. He is standing by the fireplace inside the Redhammer Pub.

Rewards
Title: The Plaguebearer Hunter
]],
				},
				
        {
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Plaguebearer (Title)",
					text =
[[
Plaguebearer - A Tale by the Fire
60k, 38.9k
Talk to the 'Forsaken Acolyte' in Gorgor's Smash Greenskin Chapter 4 for this unlock.

Rewards
Title: The Plaguebearer Hunter
]],
				},
			},
		},

		{
			name = L"Mount Bloodhorn",
			entries =
			{
				{
					name = L"Squig Herder (Pocket)",
					text =
[[
Goblin, Squig Herder - What do We Have Here?
25.5k, 4.5k
In the very back of the cave SE of the Ironmane outpost (22k, 10k) in the RvR lake there is a Hidden Scroll on the ground (between the orc bodies at the cave-in and the large stone column).

Reward
Pocket: Sumfink Wot Looks Tasty
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Boar (Tactic)",
					text =
[[
Boar - Avoid a Gory End
Kill Sharpthorn Boars around Greenskin Chapter 2, until you no longer get credit with the Kill Collector Sneakfang in Da War Maker.
This takes 60 kills and will count for the tallyman achievements as well. There are 8 boars just north of the camp that can be killed in a constant circle.

Reward
Beastial Tactic Fragment
]],
				},

				{
					name = L"Spite (Pocket)",
					text =
[[
Spite - De-spite
3.5k, 61.2k or 54.9k, 27.7k
Kill "Maegda" a lvl 8 champion Spite at first location or Kill "Tarestil" a lvl 10 champion Spite at second location.

Rewards
Pocket: Spite Ale
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Spite (Tactic)",
					text =
[[
Spite - A Defiled Life-Force
8.2k, 63k
Kill "Tainted Grove Spite", a level 7 Hero Spite, to loot a "Tainted Spite Essence".
Trade it for a Pocket Item "Burnt Spite Remains" to "Bloody Sun Burner" in Greenskin Chapter 3, inside one of the hut next to the merchant. Equip it for the unlock.

Rewards
Mythical Tactic Fragment
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Spite (Tactic)",
					text =
[[
Spite - A Defiled Life-Force
8.2k, 63k
Kill "Tainted Grove Spite", a level 7 Hero Spite, to loot a "Tainted Spite Essence".
Trade it for a Pocket Item "Burnt Spite Remains" to "Hammerstriker Hasher" in Dwarf Chapter 3, inside the building. Equip it for the unlock.

Rewards
Mythical Tactic Fragment
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Squig (Title)",
					text =
[[
Squig - The Other, Other Red Meat
16.2k, 53.5k
Talk to "Tochez da Slop Slinger" at Greenskin Chapter 2, then purchase and use "A Squig-On-A-Stick".

Rewards
Title: The Gourmand
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Vulture (Tactic)",
					text =
[[
Vulture - Slop-of-the-Day
3k, 25.7k

Talk to Bloody Sun Burner in Greenskin Chapter 3. He is inside a small hut and purchase three(?) 'Sacks of Rotting Fruit'. (I purchased 3 but only 1 was used from my inventory.
Open your quest items and right click on the sack of rotting fruit to start the quest.
Put 'Sacks of Rotting Fruit' in the three 'Slop Baskets', and kill the attacking Carrion Seeker Vultures (level 4 Vultures) that appears after using each basket. You can find 'Slop Baskets' at each of the following locations within the Mount Bloodhorn zone:
 - 20.8k 26.3k next to a banner and a tree
 - 22.4k 24.2k between a dwarf statue 'Mud Covered Statue' and a tree
 - 24.3k 25.6k surrounded by some bushes
If all went right, you'll have an 'Empty Burlap Sack', that smells of rotten fruit, instead of the 'Sack of Rotting Fruit' in your backpack.
Talk to the Bloody Sun Burner again.

Rewards
Beastial Tactic Fragment
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Vulture (Tactic)",
					text =
[[
Vulture - Slop-of-the-Day
7.6k, 24.6k - Quest Start Location
Talk to "Hammerstriker Hasher" a merchant inside the building at "Komar", Dwarf chapter 3. Purchase and use "Sack of Rotting Fruit" in your quest items. This will start the quest "Rotten Business", head to around 22400, 25700 where you will find three "Slop Basket" to click on. Complete this stage and then return to "Hammerstriker Hasher" to complete the 2nd quest and receive the unlock.

Rewards
Beastial Tactic Fragment
]],
				},
								
			},
		},

		{
			name = L"Barak Varr",
			entries =
			{
				{
					name = L"Rune Priest (Pocket)",
					text =
[[
Dwarf, Rune Priest - What do We Have Here?
31.3k, 35k

Click on the 'Hidden Scroll' located against the keep and near the postern door.

Rewards
Pocket: Simpleton's Guides to Runes
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Boar (Tactic)",
					text =
[[
Boar - Avoid a Gory End
20.3k, 55.8k
Kill "Great Warsnout" or "Bloodtusk Warsnout" mobs around this area, to complete the Kill Collector at "Thane's Defense", Dwarf Chapter 7 camp.

Rewards
Beastial Tactic Fragment
]],
				},

				{
					name = L"Boar (Tactic)",
					text =
[[
Boar - Great Tusk
20.6k, 51.6k
Kill the boar Jowler under the bridge. Jowler is a non champion level 16.

Rewards
Beastial Tactic Fragment
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Dwarf Slayer (Tactic)",
					text =
[[
Dwarf Slayer - Off With His ...
11.3k, 49k
Collect 20 'Slayer Scalps' on 'Sea Anvil Slayers'.
Then trade them for a Pocket Item 'Snotling's Head' to the Disciple's Assistant in the Lyceum at the Inevitable City. Equip it for the unlock. 

Rewards
Man Tactic Fragment
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Dwarf Slayer (Tactic)",
					text =
[[
Dwarf Slayer - Off With His ...
20.7k, 44.6k
Talk to "Captain Brinebeard" standing in front of the tent, over the small bridge in the south west of "Goldpeak's Warcamp".

Rewards
Man Tactic Fragment
]],
				},

				{
					name = L"Dwarf Slayer (Title)",
					text =
[[
Dwarf Slayer - First of Many
10.7k, 47.2k
Kill/talk to 'First Mate Kjaelsson' aboard 'The Sea's Anvil' Major Landmark. He is just at the left when you go aboard the ship.

Rewards
Title: Doom Bringer
]],
				},

				{
					name = L"Giant Lizard (Tactic)",
					text =
[[
Giant Lizard- Poached
4.4k, 19.2k
Click on "Broken Salamander Egg" towards the north end of the beach.

Rewards
Beastial Tactic Fragment
]],
				},

				{
					name = L"Giant Lizard (Title)",
					text =
[[
Giant Lizard - A Matter of Scales
4.4k, 20.8k
Equip "Scaly Skin" pocket item dropped by "Beach Salamander" mobs in this area.

Rewards
Title: The Lizard Hunter
]],
				},

				{
					name = L"Giant Lizard (Exp)",
					text =
[[
Giant Lizard - Blood from a Stone
18.7k, 16k
Kill Stonescale along the beach.
]],
				},

				{
					name = L"Nurgling (Title)",
					text =
[[
Nurgling - Getting it off Your Chest
54.2k, 49.6k
Interact with a dwarf corpse 'Festering Corpse' at the base of a steep slope. Few 'Festering Nurglings' will pop out when you examine the corpse.

Rewards
Title: The Denier of Disease
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Ogre, Bull (Title)",
					text =
[[
Ogre, Bull - Loose-Lipped
21k, 47.6k
Speak to the ogre "Ragakk", inside a greenskin camp.

Rewards
Title: The Crusher
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Ogre, Bull (Title)",
					text =
[[
Ogre, Bull - Loose-Lipped
49.3k, 58k
Speak to the ogre "Lead Belcher" just next to a cannon.

Rewards
Title: The Crusher
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Spider, Giant (Title)",
					text =
[[
Spider, Giant - Tacky Decor
5.4k, 28.2k
Enter the Wetfang Cave near Noggaz Camp and it will unlock.

Rewards
Title: The Spider Slayer
]],
				},
			},
		},

		{
			name = L"Marshes of Madness",
			entries =
			{
				{
					name = L"Shaman (Pocket)",
					text =
[[
Goblin, Shaman - What do We Have Here?
29k, 29.5k
NW of the keep there is a Hidden Scroll sitting on top of a pile.

Rewards
Pocket: Emergency Mushroom
]],
				},

				{
					name = L"Banshee (Title)",
					text =
[[
Banshee - A Sound to Silence
56.7k, 30.8k
Interact with a 'Shallow Grave'. It is hidden behind a tree at the bottom of a ravine.

Rewards
Title: The Silencer
]],
				},

				{
					name = L"Bat, Giant (Title)",
					text =
[[
Bat, Giant - For Once It Isn't Guano
43.5k, 54k OR 35k, 51k
Kill a 'Neborhest Bat' at the Order PQ 'The Tower of Neborhest' area.

Rewards
Title: Echo Hunter
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Ghoul (Title)",
					text =
[[
Ghoul - Ghoul to be Gone
31.3k, 10.6k
Speak to goblin "Noglik", inside "Hargruk's Camp" Major Landmark. He is hidden under a tree, near some rocks, northeast of the big greenskin totem.

Rewards
Title: Foe of the Cannibal
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Ghoul (Title)",
					text =
[[
Ghoul - Ghoul to be Gone
50.4k, 40.5k
Speak to "Acolyte Scherer", at the right of the entrance cave, other side of the ruins.

Rewards
Title: Foe of the Cannibal
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Gnoblar (Tactic)",
					text =
[[
Gnoblar - Cull the Weak
56k, 8k
Kill 'Boglars' until they drop 5 'Boglar Ears'. Trade them for a Pocket Item 'Collection of Ears' to the Disciple's Assistant in the Lyceum at Inevitable City. Equip it for the unlock.

Rewards
Greenskin Tactic Fragment
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Gnoblar (Tactic)",
					text =
[[
Gnoblar - Cull the Weak
56k, 8k
Kill 'Boglars' until they drop 5 'Boglar Ears'. Trade them for a Pocket Item 'Collection of Ears' to the Library Assistant in the Library at Altdorf. Equip it for the unlock. 

Rewards
Greenskin Tactic Fragment
]],
				},

				{
					name = L"Gnoblar (Tactic)",
					text =
[[
Gnoblar - Tiny Tyrant
36k, 60.3k
Kill the gnoblar 'Honcho Bogwash'. Two 'Sludgesucker Boglars' are next to him.

Rewards
Greenskin Tactic Fragment
]],
				},

				{
					name = L"Giant (Title)",
					text =
[[
Giant - Bare the Brunt
54.9k, 60.4k
Kill "Thrags", level 15 Hero Giant. He is located on top of a mountain cliff, which you can start climbing at 58k 55.3k.

Rewards
Title: The Earth Shaker
]],
				},

				{
					name = L"Vampire (Title)",
					text =
[[
Vampire - Hail to the Horror
50.3k, 53.5k
Interact with a tombstone labeled 'Vampire Effigy'.

Rewards
Title: The Dawnbringer
]],
				},
			},
		},

		{
			name = L"The Badlands",
			entries =
			{
				{
					name = L"Black Orc (Pocket)",
					text =
[[
Orc, Black Orc - What do We Have Here?
22k, 55k
Click on the 'Hidden Scroll' located within the giant bone area, right beside a barrel that's on a pile of rubble. Unlocks: Lucky Humie's Hand.

Rewards
Pocket: Lucky Humie's Hand
]],
				},

				{
					name = L"Ghoul (Tactic)",
					text =
[[
Ghoul - Foul Amongst the Fowl
18.2k, 9.1k
Kill the ghoul "Rauklus" in a narrow canyon, next to "Skeleton Bones".

Rewards
Beastial Tactic Fragment
]],
				},
				
				{
					name = L"Night Goblin (Title)",
					text =
[[
Goblin, Night Goblin - Good Night Goblin
5.5k, 7.9k
Kill 'Uzfang' the Night Goblin, in the hut nearest Dreglug's Gits.

Rewards
Title: The Frightful
]],
				},

				{
					name = L"Ogre Tyrant (Title)",
					text =
[[
Ogre Tyrant - Not What it Appears
59.7k, 27k
Kill "Graw Leadgut", Lv 29 Hero Ogre Tyrant, in the south part of "Bloodmaw Cave". A Pocket Item "Tarnished Medal" will drop from his body. Equip it for the associated title.

Rewards
Title: The Liberator
]],
				},

				{
					name = L"Savage Orc (Token)",
					text =
[[
Savage Orc - Scar'd for Life
2.8k, 53k 
Kill the 21 Hero Savage Orc 'Skaar Vidash' just up the hill. He is found standing next to a tree in the mountains.
Note: You can reach him starting climbing at 3k 49.7k.

Rewards
Bestial Token
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Savage Orc (Title)",
					text =
[[
Savage Orc - Fungus Amoung Us
14.3k, 19.8k - Quest start location
Click on "Thornberry Bush" on a small island to start the quest "Fungal Warfare".
Head to 5.9k, 17k and use "Strange Mushroom" in your quest inventory on "Gruk'trok", then kill him.
Talk to "Damnir Lostore" in "Copperstone's River Crossing" Dwarf Chapter 11 camp to complete the quest for the unlock.

Rewards
Title: The Civil
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Savage Orc (Title)",
					text =
[[
Savage Orc - Fungus Amoung Us
14.3k, 19.8k - Quest start location
Click on "Thornberry Bush" on a small island to start the quest "Fungal Warfare". 
Head to 5.9k, 17k and use "Strange Mushroom" in your quest inventory on "Gruk'trok", then kill him. 
Talk to "Chagas" in "Trug’s Hut" Greenskin Chapter 11 camp to complete the quest for the unlock.

Rewards
Title: The Civil
]],
				},

				{
					name = L"Skaven (Title)",
					text =
[[
Skaven - Sign of the Times
7.5k, 53.9k
Interact with a 'Man Trap', inside the 'Warpclaw Hideout' tunnels (entrance at 8.8k, 50.8k). It looks like a skeleton in a trap, just next to a skaven 'Warpclaw Clanrat'.

Rewards
Title: Skaven Splitter
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Snotling (Pocket)",
					text =
[[
Snotling - Miscreant Memories
23.7k, 26.6k
Talk to the goblin 'Foigak', on a small island in the river.

Rewards
Pocket: Steamtrain Token
]],
				},
				
				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Snotling (Pocket)",
					text =
[[
Snotling - Miscreant Memories
37.9k, 19k
Talk to 'Elke Raub'. She is hidden behind a big stone.

Rewards
Pocket: Steamtrain Token
]],
				},				

				{
					name = L"Vulture (Title)",
					text =
[[
Vulture - Feeding Time...
34.4k, 27k
Interact with planks 'Vulture Feeder Parts' between a tree and a big rock.

Rewards
Title: The Main Course
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Gnoblar (Acc)",
					text =
[[
Gnoblar - Sum of the Whole
First you need to take the quest'Gnoblar Hunt' from the quest giver 'Zigmoot da Curious' (Orc) at The Inevitable City in the Lyceum south wing.
Then you have to kill several mobs for some drops:

40k, 37k in Badlands - Kill 'Bloodmaw Gnoblars' until one drops a 'Bloodmaw Gnoblar's Nose'.
54k, 54k in Cinderfall - Kill 'Gutbash Trappers' until one drops a 'Gnoblar Trapper's Trap Parts'.
54k, 54k in Cinderfall - Kill 'Gutbash Tooth Gnoblars' until one drops a 'Tooth Gnoblar's Tooth'.
41.7k, 10.5k in Black Crag - Kill 'Burnmaw Gnoblars' until one drops a 'Burnmaw Gnoblar's Shiny Bits'.

Return in the city to the quest giver to finish it. It will give you a 'Limited Edition Gnoblar Collectables!' Pocket Item.Equip it for the unlock.

Rewards 
Jewel: Oathstone of Karak Eight Peaks
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Gnoblar (Acc)",
					text =
[[
Gnoblar - Sum of the Whole
First you need to take the quest 'Gnoblar Huntin' from the quest giver 'Rogni Ironsight' (Dwarf) at Altdorf in the Library.
Then you have to kill several mobs for some drops:

40k, 37k in Badlands - Kill 'Bloodmaw Gnoblars' until one drops a 'Bloodmaw Gnoblar's Nose'.
54k, 54k in Cinderfall - Kill 'Gutbash Trappers' until one drops a 'Gnoblar Trapper's Trap Parts'.
54k, 54k in Cinderfall - Kill 'Gutbash Tooth Gnoblars' until one drops a 'Tooth Gnoblar's Tooth'.
41.7k, 10.5k in Black Crag - Kill 'Burnmaw Gnoblars' until one drops a 'Burnmaw Gnoblar's Shiny Bits'.

Return in the city to the quest giver to finish it. It will give you a 'Limited Edition Gnoblar Collectables!' Pocket Item.Equip it for the unlock.

Rewards 
Jewel: Oathstone of Karak Eight Peaks
]],
				},
			},
		},

		{
			name = L"Mount Gunbad",
			entries =
			{
				{
					name = L"Night Goblin (Pocket)",
					text =
[[
Night Goblin - Night-Time is the Right Time
MIDDLE WING
Follow the central path down. At the first Public Quest area with Giants and Goblins, you will find 'Morgit da Waaagher' standing beside a Hut on the left. Kill him for the unlock.

Rewards
Pocket: Darklight
]],
				},

				{
					name = L"Snotling (Tactic)",
					text =
[[
Snotling - Green Lightning
RIGHT WING
Kill the snotling 'Kezzen' inside Mount Gunbad. He is on the east wing, at the first PQ. He is a bit isolated.

Rewards
Greenskin Tactic Fragment
]],
				},

				{
					name = L"Squig (Title)",
					text =
[[
Squig - Feeding Time...
MIDDLE WING
Kill the main boss of Mount Gunbad "Ard Ta Feed", which is an enormous Squig.

Rewards
Title: 'Ard ta Eat
]],
				},
			},
		},

		{
			name = L"Black Fire Pass",
			entries =
			{
				{
					name = L"Engineer (Pocket)",
					text =
[[
Dwarf, Engineer - What do We Have Here?
13.6k, 14.5k
Click on the 'Hidden Scroll' located east of Gnol baraz keep between a broken siege weapon and a bush

Rewards
Pocket: Shiny Metal Thing
]],
				},

				{
					name = L"Squig (Tactic)",
					text =
[[
Squig - Forgotten and Famished
37.5k, 59.8k
Kill the champion "Famished Squig".

Rewards
Beastial Tactic Fragment
]],
				},

				{
					name = L"Bandit (Tactic)",
					text =
[[
Bandit - Robbery
57.4k, 44.2k - In Black Fire Pass
Kill "Haaloth Bloodreaver".

Rewards
Man Tactic Fragment
]],
				},
			},
		},

		{
			name = L"Thunder Mountain",
			entries =
			{
				{
					name = L"Bull Ogre (Acc)",
					text =
[[
Bull Ogre - You Going to Eat That?
48.1k, 55.3k
Interact with the "Ogre Cauldron".

Rewards
Jewel Item : Fated Veil
]],
				},

				{
					name = L"Dragon (Title)",
					text =
[[
Dragon - All That Remains
1.4k, 21.4k
Interact with "The Broken Axe Sindri Cragborn" on the top of a hill. You can easily reach this point by climbing up from the road to the south.

Rewards
Title: Fireborn
]],
				},

				{
					name = L"Drakk Cultist (Tactic)",
					text =
[[
Drakk Cultist - Hard To Be a Leader
18.7k, 3.5k
Kill a "Lehnera" mainly outside and inside the "Dragon's Breath Cave".

Rewards
Man Tactic Fragment
]],
				},

				{
					name = L"Drakk Cultist (Title)",
					text =
[[
Drakk Cultist - Where the Blood Flows
20.3k, 7.2k
Interact with a "Drakk Altar", at the south of the "Dragon's Breath Cave" (entrance at 18.7k 3.5k).

Rewards
Title: The Harrier
]],
				},

				{
					name = L"Giant (Pocket)",
					text =
[[
Giant - X Marks the Spot
11.9k, 24.7k
Interact with the barrel "Bugman's XXXXXX" near the merchant of Dwarf Chapter 18. There are tents and crates next to the barrel.
For Destruction: To reach the barrel, follow the road north of the chapter then stop around 12.8k 22.5k. There you will see dwarf banners and a piece of broken wall. Head southwest following closely this broken wall, to reach the barrel.

Rewards
Pocket: Barrel of Ale
]],
				},

				{
					name = L"Spider (Tactic)",
					text =
[[
Giant Spider - Big Identity Crisis
63k, 23k
Kill the giant spider 'Graelba', located among other giant spiders.

Rewards
Beastial Tactic Fragment
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Spider (Acc)",
					text =
[[
Giant Spider - Sacking for Sacs
43k, 6.6k
Kill 'Magma Crawlers' until you gather 5 'Arachnid Poison Sacs' from them.
Trade the 5 'Arachnid Poison Sacs' for a Pocket Item 'Vial of Concentrated Venom' to Library Assistant in the Library at Altdorf. Equip it to trigger the unlock.

Rewards
Jewel Item : Crow Caller Chain
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Spider (Acc)",
					text =
[[
Giant Spider - Sacking for Sacs
43k, 6.6k
Kill 'Magma Crawlers' until you gather 5 'Arachnid Poison Sacs' from them.
Trade the 5 'Arachnid Poison Sacs' for a Pocket Item 'Vial of Concentrated Venom' to Disciple's Assistant in the Lyceum at Inevitable City. Equip it to trigger the unlock.

Rewards
Jewel Item : Crow Caller Chain
]],
				},

				{
					name = L"H. of Tzeentch (Tactic)",
					text =
[[
Horror of Tzeentch - What Horrifies Horrors?
16k, 17k
Kill 'Mysterious Horrors' until you get a Pocket Item 'An Odd Doll'. Equip it for the unlock.
Note: You can reach 'Mysterious Horros' area by a way at 13.7k 20.4k.

Rewards
Daemonic Tactic Fragment
]],
				},

				{
					name = L"Rhinox (Title)",
					text =
[[
Rhinox - Dense and Denser
45.6k, 59k or 49.2k, 55.7k
Interact with a 'Rhinox Bonepile' at the edge of a Lava Lake to the southeast of Mudja's Warcamp.

Rewards
Title: The Rhinox Rocker
]],
				},
			},
		},

		{
			name = L"Cinderfall",
			entries =
			{
				{
					name = L"Basilisk (Acc)",
					text =
[[
Basilisk - No Reflection of Your Skill
38.3k, 35.5k
Interact with skeleton 'Komnor Bronzemug' at the cliff's edge.

Rewards
Jewel Item: Wordbreaker Band
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Ghoul (Tactic)",
					text =
[[
Ghoul - Finger Licking Good
56k, 24k 
OR 
54.5k, 43.5k
Kill 60 "Flamepicked Ghouls" or "Deathflame Ghouls" and then speak to the Kill Collector at Da Scrappin' Camp (Greenskin chapter 18) in Thunder Mountain.

Rewards
Beastial Tactic Fragment
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Ghoul (Tactic)",
					text =
[[
Ghoul - Finger Licking Good
56k, 24k 
OR 
54.5k, 43.5k
Kill 60 "Flamepicked Ghouls" or "Deathflame Ghouls" and then speak to Rori Mailcutter, the Kill Collector at Palik Watch (Dwarf chapter 18) in Thunder Mountain.

Rewards
Beastial Tactic Fragment
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Skeleton (Acc)",
					text =
[[
Skeleton - Coin of the Trade
NOT IMPLEMENTED
First you need to take the quest 'Remembering the Fallen' from Irkul Grudgebearer inside the Library in Altdorf.
Then you need to interact with different 'Deanimated Skeletons' in different Caves across Cinderfall:
62k, 49.6k - You will find the 'Deanimated Human Skeleton' in the Cave. The Skeleton is against a pillar of an arch in the first room of the cave. You will receive an 'Undead Human Skull'.
57.5k, 58.6k - You will find the 'Deanimated Elven Skeleton' just outside another Cave. You will receive an 'Undead Elven Skull'.
61.8k, 3.4k - You will find the 'Deanimated Dwarf Skeleton' in the another Cave (entrance at 59.8k 11k). You will receive an 'Undead Dwarf Skull'.
Return to the quest giver in the city to finish the quest. It will give you a Pocket Item 'Skulls of the Fallen'. Equip it for the unlock.

Rewards
Jewel Item : Torment
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Skeleton (Acc)",
					text =
[[
Skeleton - Coin of the Trade
NOT IMPLEMENTED
First you need to take the quest: 'The Essence of the Fallen' from Disciple Rageborn inside the Lyceum in The Inevitable City.
Then you need to interact with different 'Deanimated Skeletons' in different Caves across Cinderfall:
62k, 49.6k in Cinderfall - You will find the 'Deanimated Human Skeleton' in the Cave. The Skeleton is against a pillar of an arch in the first room of the cave. You will receive an 'Undead Human Skull'.
57.5k, 58.6k in Cinderfall - You will find the 'Deanimated Elven Skeleton' just outside another Cave. You will receive an 'Undead Elven Skull'.
61.8k, 3.4k in Cinderfall - You will find the 'Deanimated Dwarf Skeleton' in the another Cave (entrance at 59.8k 11k). You will receive an 'Undead Dwarf Skull'.
Return to the quest giver in the city to finish the quest. It will give you a Pocket Item 'Skulls of the Fallen'. Equip it for the unlock.

Rewards
Jewel Item : Torment
]],
				},

				{
					name = L"Zombie (Tactic)",
					text =
[[
Zombie - Wulgrig
44k, 2.5k - in Cinderfall
Interact with 'Pile of Rocks' at inside 'Palik Tunnels' (entrance at 47.7k 7k). To reach it, go north at the first junction inside Palik Tunnels, descend the ramp, and go left. You will find it in the first room behind a column on the left.
Interacting with this 'Pile of Rocks' will make spawn 'Wulgrig', a level 36 zombie. Kill him for the unlock.

Rewards
Undead Tactic Fragment
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Gnoblar (Acc)",
					text =
[[
Gnoblar - Sum of the Whole
First you need to take the quest'Gnoblar Hunt' from the quest giver 'Zigmoot da Curious' (Orc) at The Inevitable City in the Lyceum south wing.
Then you have to kill several mobs for some drops:

40k, 37k in Badlands - Kill 'Bloodmaw Gnoblars' until one drops a 'Bloodmaw Gnoblar's Nose'.
54k, 54k in Cinderfall - Kill 'Gutbash Trappers' until one drops a 'Gnoblar Trapper's Trap Parts'.
54k, 54k in Cinderfall - Kill 'Gutbash Tooth Gnoblars' until one drops a 'Tooth Gnoblar's Tooth'.
41.7k, 10.5k in Black Crag - Kill 'Burnmaw Gnoblars' until one drops a 'Burnmaw Gnoblar's Shiny Bits'.

Return in the city to the quest giver to finish it. It will give you a 'Limited Edition Gnoblar Collectables!' Pocket Item.Equip it for the unlock.

Rewards 
Jewel: Oathstone of Karak Eight Peaks
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Gnoblar (Acc)",
					text =
[[
Gnoblar - Sum of the Whole
First you need to take the quest 'Gnoblar Huntin' from the quest giver 'Rogni Ironsight' (Dwarf) at Altdorf in the Library.
Then you have to kill several mobs for some drops:

40k, 37k in Badlands - Kill 'Bloodmaw Gnoblars' until one drops a 'Bloodmaw Gnoblar's Nose'.
54k, 54k in Cinderfall - Kill 'Gutbash Trappers' until one drops a 'Gnoblar Trapper's Trap Parts'.
54k, 54k in Cinderfall - Kill 'Gutbash Tooth Gnoblars' until one drops a 'Tooth Gnoblar's Tooth'.
41.7k, 10.5k in Black Crag - Kill 'Burnmaw Gnoblars' until one drops a 'Burnmaw Gnoblar's Shiny Bits'.

Return in the city to the quest giver to finish it. It will give you a 'Limited Edition Gnoblar Collectables!' Pocket Item.Equip it for the unlock.

Rewards 
Jewel: Oathstone of Karak Eight Peaks
]],
				},
			},
		},

		{
			name = L"Death Peak",
			entries =
			{
				{
					name = L"Ghoul (Acc)",
					text =
[[
Ghoul - Demoted
11k, 36.3k
Kill "Pisacha the Rank". He is a bit hidden in some bushes north of the road.

Rewards
Jewel Item : Strife
]],
				},

				{
					name = L"Wight (Title)",
					text =
[[
Wight- Dead Weight
3.2k, 11.7k
Kill 'Seno Cirrus', a level 37 Wight, in 'Acidburn Cave' (entrance at 5k 15.7k). He is at the end of the first right way of the cave.

Rewards
Title: King Slayer
]],
				},

				{
					name = L"Winged N. (Title)",
					text =
[[
Winged Nightmare - Clip Its Wings
12k, 11.3k
Kill 'Terrorwing', a level 37 Champion Winged Nightmare.

Rewards
Title: The Dreamstealer
]],
				},

				{
					name = L"Wyvern (Title)",
					text =
[[
Wyvern - In the Wild
10.3k, 45.6k
Interact with a "Damaged Wyvern Egg". This is at the end of a cave which is not marked on the map. The entrance is at 3.6k 45.3k.

Rewards
Title: The Wyvern Watcher
]],
				},
			},
		},

		{
			name = L"Kadrin Valley",
			entries =
			{
				{
					name = L"Dwarf (Title)",
					text =
[[
Dwarf - The History of the Dwarfs
34.5k, 7k
Click on the 'Hidden Scroll' NE of the northernmost BO, behind some rocks.

Rewards
Title: Forgebreaker
]],
				},

				{
					name = L"Dwarf, Slayer (Pocket)",
					text =
[[
Dwarf, Slayer - What do We Have Here?
34k, 4k
Click on the 'Hidden Scroll'.

Rewards
Pocket: Slayer Haircomb
]],
				},

				{
					name = L"Dwarf Slayer (Tactic)",
					text =
[[
Dwarf, Slayer - Looking for Trouble
58k, 49.5k
Kill/talk to 'Argnus Rockskull' (level 38 Champion Slayer).

Rewards
Jewel Item : Oathstone of Karaz-a-Karak
]],
				},

				{
					name = L"Dwarf Slayer (Tactic)",
					text =
[[
Dwarf, Slayer - Look Out Below!
28.6k, 40.3k
Interact with the barrel 'Stonesmith Supplies' at the end of the broken bridge.

Rewards
Man Tactic Fragment
]],
				},
				
				{
					name = L"Bear (Tactic)",
					text =
[[
Bear - Sharpen Your Knives
5.5k, 14k
Kill 'Thag Bolgar', a level 32 Bear.

Rewards
Beastial Tactic Fragment
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Giant Lizard (Tactic)",
					text =
[[
Giant Lizard - Hunger Pangs
Kill 60 'Snowfury Fork-tongues' just to the west of Gashfang's Warband (Orc Chapter 21) in Kadrin Valley, until the Kill Collector quest from Dragna in that town is completed.

Rewards
Beastial Tactic Fragment
]],
				},

				{
					name = L"Giant (Tactic)",
					text =
[[
Giant - Brutal Nose Ring
33.5k, 28.1k
Kill "Vragi the Brute", a level 39 Chaos Troll, at the top of the cliff edge, to collect a Pocket Item "Giant Nosering". Equip it for the unlock.

Rewards
Giant Tactic Fragment
]],
				},

				{
					name = L"Nurgling (Tactic)",
					text =
[[
Nurgling - Say Hello to My Little Friends
40.5k, 25k
Kill Vlasi Ipatiev, a level 40 Hero, north of Orc Chapter 22, at the cliff's edge. 3 'Nurglings' are standing next to him.

Rewards
Daemonic Tactic Fragment
]],
				},

				{
					name = L"Rat Ogre (Title)",
					text =
[[
Rat Ogre - To the Death
57.7k, 39.2k
Kill "Burrow Champion" (Level 38 Champion Rat Ogre), inside "Tunnel of Baradum". You can reach it via a ramp that leads up past a Gyrocopter.

Rewards
Title: The Scarred
]],
				},

				{
					name = L"Troll, Stone (Acc)",
					text =
[[
Stone Troll - Diamond in the Rough
31.8k, 27k
Kill "Boulder Chukkas" on the hill above Duraz Dok, until you get a Pocket Item "Consumed Rough Diamond". Equip it for the unlock.

Rewards
Jewel Item: Bloodied Fracture
]],
				},
			},
		},

		{
			name = L"Black Crag",
			entries =
			{
				{	
				  name = L"Goblin (Title)",
					text =
[[
Goblin - The History of the Goblins
39.5k, 61k
Click on the 'Hidden Scroll' located in a cave. Enter the cave and follow the path to 39.5, 61. Go to the base of the big rock column coming down from the ceiling and find the scroll between 2 mushroom stocks.

Rewards
Title: Grot's Doom
]],
				},

				{	
				  name = L"Orc, Choppa (Pocket)",
					text =
[[
Orc, Choppa - What do we Have Here?
29k, 49.5k
Click on the 'Hidden Scroll'.

Rewards
Pocket: Toof Pick
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Gnoblar (Acc)",
					text =
[[
Gnoblar - Sum of the Whole
First you need to take the quest'Gnoblar Hunt' from the quest giver 'Zigmoot da Curious' (Orc) at The Inevitable City in the Lyceum south wing.
Then you have to kill several mobs for some drops:

40k, 37k in Badlands - Kill 'Bloodmaw Gnoblars' until one drops a 'Bloodmaw Gnoblar's Nose'.
54k, 54k in Cinderfall - Kill 'Gutbash Trappers' until one drops a 'Gnoblar Trapper's Trap Parts'.
54k, 54k in Cinderfall - Kill 'Gutbash Tooth Gnoblars' until one drops a 'Tooth Gnoblar's Tooth'.
41.7k, 10.5k in Black Crag - Kill 'Burnmaw Gnoblars' until one drops a 'Burnmaw Gnoblar's Shiny Bits'.

Return in the city to the quest giver to finish it. It will give you a 'Limited Edition Gnoblar Collectables!' Pocket Item.Equip it for the unlock.

Rewards 
Jewel: Oathstone of Karak Eight Peaks
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Gnoblar (Acc)",
					text =
[[
Gnoblar - Sum of the Whole
First you need to take the quest 'Gnoblar Huntin' from the quest giver 'Rogni Ironsight' (Dwarf) at Altdorf in the Library.
Then you have to kill several mobs for some drops:

40k, 37k in Badlands - Kill 'Bloodmaw Gnoblars' until one drops a 'Bloodmaw Gnoblar's Nose'.
54k, 54k in Cinderfall - Kill 'Gutbash Trappers' until one drops a 'Gnoblar Trapper's Trap Parts'.
54k, 54k in Cinderfall - Kill 'Gutbash Tooth Gnoblars' until one drops a 'Tooth Gnoblar's Tooth'.
41.7k, 10.5k in Black Crag - Kill 'Burnmaw Gnoblars' until one drops a 'Burnmaw Gnoblar's Shiny Bits'.

Return in the city to the quest giver to finish it. It will give you a 'Limited Edition Gnoblar Collectables!' Pocket Item.Equip it for the unlock.

Rewards 
Jewel: Oathstone of Karak Eight Peaks
]],
				},

				{
					name = L"Basilisk (Title)",
					text =
[[
Basilisk - Cave of Stone
6k, 9k
Enter 'Sulfur Caves', found in the northwestern corner of Black Crag.

Reward
Title: The Rock
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Basilisk (Tactic)",
					text =
[[
Basilisk - It's in the Bag
9k, 10k
Collect six 'Lisk Meat from the Young Basilisks (Level 13 Basilisks) just north of Da Great Big Food Pot (Orc Chapter 16). 
Once you have collected the 'Lisk Meats, trade them for a Pocket Item 'Bag of 'Lisk Meat' to Disciple's Assistant in the Lyceum at Inevitable City. Equip it for the unlock.

Rewards
Beastial Tactic Fragment
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Basilisk (Tactic)",
					text =
[[
Basilisk - It's in the Bag
9k, 10k
Collect six 'Lisk Meat from the Young Basilisks (Level 13 Basilisks) just north of Da Great Big Food Pot (Orc Chapter 16). 
Once you have collected the 'Lisk Meats, trade them for a Pocket Item 'Bag of 'Lisk Meat' to Library Assistant in the Library at Altdorf. Equip it for the unlock.

Rewards
Beastial Tactic Fragment
]],
				},

				{
					name = L"Basilisk (Tactic)",
					text =
[[
Basilisk - Scales of Mourning
5k, 8k
Kill the Basilisk 'Stinky' in 'Sulfur Caves'.

Or

40.7k, 38.7k
Kill the level 39 Champion Basilisk 'Black Scale'.

Rewards
Beastial Tactic Fragment
]],
				},

				{
					name = L"Bat, Giant (Tactic)",
					text =
[[
Bat, Giant - In the Dark of Day
14.4k, 33.8k
Kill a 'Deep Pit Bat' or a 'Pit Bat' inside the cave 'Bat Hollow'.

Rewards
Beastial Tactic Fragment
]],
				},

				{
					name = L"Giant (Tactic)",
					text =
[[
Giant - Giant Amongst Giants
35.6k, 52.6k
Kill "Ufgor", the level 40 Champion Giant. There are two other giants nearby.

Rewards
Giant Tactic Fragment
]],
				},

				{
					name = L"Slimehound (Title)",
					text =
[[
Slimehound - An Easy Trail to Follow
29.3k, 28.8k
Interact with 'Slimehound Remains' hidden among bushes, on the left of the entrance to 'Stonemane Mine'.

Rewards
Title: The Slime-Trodder
]],
				},

				{
					name = L"Snotling (Tactic)",
					text =
[[
Snotling - Relish the Relics
63k, 56k
Enter the 'Cliffrunner Den' cave. In the room before 'Gorfang Rotgut' (level 40 champion orc), at the right when you enter, is a snotling 'Hoarding Burrower' (level 41 snotling at 62.5k 61.5k).
Kill him to get a Pocket Item "Relic Sword of Verena". Equip it for the unlock.

Rewards
Greenskin Tactic Fragment
]],
				},

				{
					name = L"Wyvern (Acc)",
					text =
[[
Wyvern - Let's See What This Does
21.2k, 9.1k
Kill "Rustblot Squigs" or "Rustspatter Squigs" a short distance west, east, or south of the "Wyvern Trap" until one drops a "Fresh Meat". Right click the Wyvern Trap to place the Fresh Meat.
Once the unlock triggered, you can claim the jewel buying it from the correct merchant in Library (Order) / Lyceum (Destruction).

Rewards
Jewel: Fullbelly's Lucky Foot
]],
				},

				{
					name = L"Troll (Tactic)",
					text =
[[
Troll - Rock in the Maw of Darkness
6.3k, 25k
Kill "Rockmaw", a level 31 champion Troll.

Rewards
Giant Tactic Fragment
]],
				},

				{
					name = L"Troll (Tactic)",
					text =
[[
Troll - Prescribed Flesh
2.3k, 28k
Kill "Stonegullet Trolls" in "The Despair Pits" cave until one drops a Pocket Item "Troll Flesh". Equip it for the unlock.

Rewards
Giant Tactic Fragment
]],
				},

				{
					name = L"Troll (Tactic)",
					text =
[[
Troll, Stone - Indigestion
???
]],
				},
				
				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Dryad (Tactic)",
					text =
[[
Dryad - Fire Seldom Dies Alone
Interact with "Crate of Torches" in Black Crag at 21.5k 36.2k in Greenskin Chapter 15, to receive a "Torch".
Use "Torch", just once, on "Ashridden Nymphs" or "Ashridden Dryads" in the RvR area and kill it normally after. You can find some at 28k 58k or 25k 48k.
Each kill gives you "Dryad Ash" in your inventory, collect 10 of them. There are 10 shots in a Torch, so you can complete it with just 1 Torch.
Eventually return to NPC "Snotgul" at Greenskin Chapter 15, just next where you got the Torch.

Rewards
Mythical Tactic Fragment
]],
				},				

				{
					realm = TTitan.Data.Realm.Order,
					name = L"Dryad (Tactic)",
					text =
[[
Dryad - Fire Seldom Dies Alone
Interact with "Crate of Torches" in Black Crag at 38.5k 45.2k in Dwarf Chapter 22, to receive a "Torch".
Use "Torch", just once, on "Ashridden Nymphs" or "Ashridden Dryads" in the RvR area and kill it normally after. You can find some at 28k 58k or 25k 48k.
Each kill gives you "Dryad Ash" in your inventory, collect 10 of them. There are 10 shots in a Torch, so you can complete it with just 1 Torch.
Eventually return to NPC "Godor Bronzemug" at Dwarf Chapter 22, just next where you got the Torch.

Rewards
Mythical Tactic Fragment
]],
				},
			},
		},
  },
}
