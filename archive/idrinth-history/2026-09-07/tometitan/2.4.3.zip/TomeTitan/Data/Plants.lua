TTitan.Data.Plants = {}

function TTitan.Data.Plants.GetData()
	return TTitan.Data.Plants.RawData
end

function TTitan.Data.Plants.FilterData()
end

TTitan.Data.Plants.RawData =
{
	header = L"Plants",
	categories =
	{
		{
			name = L"Level 1 Seeds/Spores",
			entries =
			{
				{
					name = L"BeardWeeds (STR)",
					text =
[[
Common - Wispy BeardWeed
Common Special Gooey Arboreal Resin

Rare - Crimson Bearweed
Rare Special - None
]],
				},

				{
					name = L"Grumpleafs (WILL)",
					text =
[[
Common - Petulant Grumpleaf
Common Special Gooey Arboreal Resin

Rare - Pock-Marked Grumpleaf
Rare Special - None
]],
				},

				{
					name = L"Smedleycaps (INT)",
					text =
[[
Common - Motley Smedleycap
Common Special Gooey Arboreal Resin

Rare - Spore-Laden Smedleycap
Rare Special - Honeycomb Extract (pigment)
]],
				},

				{
					name = L"Thief's Nettle (ACC)",
					text =
[[
Common - Woolly Thief's Nettle
Common Special Gooey Arboreal Resin

Rare - Short-Haired Thiefs Nettle
Rare Special - None
]],
				},

				{
					name = L"Gravel/Shore nuts (TOUGH/CORP)",
					text =
[[
Common - Pebbled Gravelnuts
Common Special Gooey Arboreal Resin

Rare - Green Shorenuts
Rare Special - None
]],
				},

				{
					name = L"MorrWeeds (ARMOUR)",
					text =
[[
Common - Wispy Morrweed
Common Special Gooey Arboreal Resin

Rare - Steepled Morrweed
Rare Special - None
]],
				},

				{
					name = L"Dandedragons (AP)",
					text =
[[
Common - Swaying Dandedragon
Common Special Gooey Arboreal Resin

Rare - Willowy Dandedragon
Rare Special - None
]],
				},

				{
					name = L"Elvish Parsley (Healing)",
					text =
[[
Common - Musty Elvish Parsley
Common Special Gooey Arboreal Resin

Rare - Trenchant Elvish Parsley
Rare Special - None
]],
				},

				{
					name = L"Ashberries (Flaming Breath)",
					text =
[[
Common - Smoking Ashberry
Common Special Gooey Arboreal Resin

Rare - Sallow Ashberry
Rare Special - None
]],
				},

				{
					name = L"Pyre Ivys (Fiery Concoction)",
					text =
[[
Common - Smoking Pyre Ivy
Common Special Gooey Arboreal Resin

Rare - Blistering Pyre Ivy
Rare Special - None
]],
				},

				{
					name = L"Fusks (Increase #)",
					text =
[[
Common - Dusty Fusk
Common Special Gooey Arboreal Resin

Rare - Mottled Fusk
Rare Special - None
]],
				},

				{
					name = L"Gobsworts (Increase Duration)",
					text =
[[
Common - Callous Gobswort
Common Special Gooey Arboreal Resin

Rare - Blue Speckled Gobswort
Rare Special - None
]],
				},
			},
		},

		{
			name = L"Level 25 Seeds/Spores",
			entries =
			{
				{
					name = L"BeardWeeds (STR)",
					text =
[[
Common - Brittle BeardWeed
Common Special - Slimy Arboreal Resin

Rare - Rosy Bearweed
Rare Special - None
]],
				},

				{
					name = L"Grumpleafs (WILL)",
					text =
[[
Common - Frowning Grumpleaf
Common Special - Slimy Arboreal Resin

Rare - Scarred Grumpleaf
Rare Special - None
]],
				},

				{
					name = L"Smedleycaps (INT)",
					text =
[[
Common - Blotchy Smedleycap
Common Special - Slimy Arboreal Resin

Rare - Spore-Covered Smedleycap
Rare Special - None
]],
				},

				{
					name = L"Thief's Nettle (ACC)",
					text =
[[
Common - Wiry Thief's Nettle
Common Special - Slimy Arboreal Resin

Rare - Long-Haired Thiefs Nettle
Rare Special - None
]],
				},

				{
					name = L"Gravel/Shore nuts (TOUGH/CORP)",
					text =
[[
Common - Jagged Gravelnuts
Common Special - Slimy Arboreal Resin

Rare - Brown Shorenuts
Rare Special - Honeycomb Extract (Pigment)
]],
				},

				{
					name = L"MorrWeeds (ARMOUR)",
					text =
[[
Common - Brittle Morrweed
Common Special - Slimy Arboreal Resin

Rare - Domed Morrweed
Rare Special - None
]],
				},

				{
					name = L"Dandedragons (AP)",
					text =
[[
Common - Capering Dandedragon
Common Special - Slimy Arboreal Resin

Rare - Gossamer Dandedragon
Rare Special - None
]],
				},

				{
					name = L"Elvish Parsley (Healing)",
					text =
[[
Common - Bitter Elvish Parsley
Common Special - Slimy Arboreal Resin

Rare - Probing Elvish Parsley
Rare Special - None
]],
				},

				{
					name = L"Ashberries (Flaming Breath)",
					text =
[[
Common - Charred Ashberry
Common Special - Slimy Arboreal Resin

Rare - Waxen Ashberry
Rare Special - None
]],
				},

				{
					name = L"Pyre Ivys (Fiery Concoction)",
					text =
[[
Common - Charred Pyre Ivy
Common Special - Slimy Arboreal Resin

Rare - Searing Pyre Ivy
Rare Special - None
]],
				},

				{
					name = L"Boletes (Increase #)",
					text =
[[
Common - Sandy Fusk
Common Special - Slimy Arboreal Resin

Rare - Dappled Fusk
Rare Special - Honeycomb Extract (Pigment)
]],
				},

				{
					name = L"Gobsworts (Increase Duration)",
					text =
[[
Common - Scabrous Gobswort
Common Special - Slimy Arboreal Resin

Rare - Grey Speckled Gobswort
Rare Special - None
]],
				},
			},
		},

		{
			name = L"Level 50 Seeds/Spores",
			entries =
			{
				{
					name = L"Blackstipes (STR)",
					text =
[[
Common - Arching Blackstipe
Common Special - Seeping Arboreal Resin

Rare - Long-Petaled Blackstipe
Rare Special - None
]],
				},

				{
					name = L"Elfcups/Dwarfcups (WILL)",
					text =
[[
Common - Wiry Elfcup
Common Special - Seeping Arboreal Resin

Rare - Pock-Marked Dwarfcup
Rare Special - Resinous Brown Extract
]],
				},

				{
					name = L"Twigfesters (INT)",
					text =
[[
Common - Rotting Twigfester
Common Special - Seeping Arboreal Resin

Rare - Moldering Twigfester
Rare Special - Resinous Brown Extract
]],
				},

				{
					name = L"Twigbloats (ACC)",
					text =
[[
Common - Scattered Twigbloat
Common Special - Seeping Arboreal Resin

Rare - Standing Twigbloat
Rare Special - None
]],
				},

				{
					name = L"Trotweeds (TOUGH/CORP)",
					text =
[[
Common - Striding Trotweed
Common Special - Seeping Arboreal Resin

Rare - Green Trotweed
Rare Special - None
]],
				},

				{
					name = L"Skunkthistles (ARMOUR)",
					text =
[[
Common - Vile Skunkthistle
Common Special - Seeping Arboreal Resin

Rare - Open-Sac Skunkthistle
Rare Special - None
]],
				},

				{
					name = L"Peckgrass' (AP)",
					text =
[[
Common - Tufted Peckgrass
Common Special - Seeping Arboreal Resin

Rare - Willowy Peckgrass
Rare Special - None
]],
				},

				{
					name = L"Grottuk Weeds (Healing)",
					text =
[[
Common - Grasping Grottuk Weed
Common Special - Seeping Arboreal Resin

Rare - Trenchant Grottuk Weed
Rare Special - Resinous Brown Extract
]],
				},

				{
					name = L"Redvines (Flaming Breath)",
					text =
[[
Common - Grasping Redvine
Common Special - Seeping Arboreal Resin

Rare - Sallow Redvine
Rare Special - Resinous Brown Extract
]],
				},

				{
					name = L"Scruntleydowns (Fiery Concoction)",
					text =
[[
Common - Fuzzy Scruntleydown
Common Special - Seeping Arboreal Resin

Rare - Blistering Scruntleydown
Rare Special - None
]],
				},

				{
					name = L"[FIX PLEASE]",
					text =
[[
Common - Burgandy Bolete
Common Special - Seeping Arboreal Resin

Rare - Mottled Bolete
Rare Special - None
]],
				},

				{
					name = L"Merulius' (Increase Duration)",
					text =
[[
Common - Coarse Merulius
Common Special - Seeping Arboreal Resin

Rare - porous Merulius
Rare Special - None
]],
				},
			},
		},

		{
			name = L"Level 75 Seeds/Spores",
			entries =
			{
				{
					name = L"Blackstipes (STR)",
					text =
[[
Common - Curling Blackstipe
Common Special - Oozing Arboreal Resin

Rare - Round-Petaled Blackstipe
Rare Special - Resinous Broun Extract
]],
				},

				{
					name = L"Elfcups/Dwarfcups (WILL)",
					text =
[[
Common - Hairy Elfcup
Common Special - Oozing Arboreal Resin

Rare - Scarred Dwarfcup
Rare Special - None
]],
				},

				{
					name = L"Twigfesters (INT)",
					text =
[[
Common - Blighted Twigfester
Common Special - Oozing Arboreal Resin

Rare - Mortified Twigfester
Rare Special - Resinous Brown Extract
]],
				},

				{
					name = L"Twigbloats (ACC)",
					text =
[[
Common - Scurfy Twigbloat
Common Special - Oozing Arboreal Resin

Rare - Leaning Twigbloat
Rare Special - None
]],
				},

				{
					name = L"Trotweeds (TOUGH/CORP)",
					text =
[[
Common - Cantering Trotweed
Common Special - Oozing Arboreal Resin

Rare - Brown Trotweed
Rare Special - None
]],
				},

				{
					name = L"Skunkthistles (ARMOUR)",
					text =
[[
Common - Noxious Skunkthistle
Common Special - Oozing Arboreal Resin

Rare - Crowned-Sac Skunkthistle
Rare Special - Resinous Brown Extract
]],
				},

				{
					name = L"Peckgrass' (AP)",
					text =
[[
Common - Wispy Peckgrass
Common Special - Oozing Arboreal Resin

Rare - Gossamer Peckgrass
Rare Special - None
]],
				},

				{
					name = L"Grottuk Weeds (Healing)",
					text =
[[
Common - Drooping Grottuk Weed
Common Special - Oozing Arboreal Resin

Rare - Probing Grottuk Weed
Rare Special - Resinous Brown Extract
]],
				},

				{
					name = L"Redvines (Flaming Breath)",
					text =
[[
Common - Clawing Redvine
Common Special - Oozing Arboreal Resin

Rare - Waxen Redvine
Rare Special - Resinous Brown Extract
]],
				},

				{
					name = L"Scruntleydowns (Fiery Concoction)",
					text =
[[
Common - Patchy Scruntleydown
Common Special - Oozing Arboreal Resin

Rare - Searing Scruntleydown
Rare Special - None
]],
				},

				{
					name = L"Boletes (Increase #)",
					text =
[[
Common - Scarlet Bolete
Common Special - Oozing Arboreal Resin

Rare - Dappled Bolete
Rare Special - None
]],
				},

				{
					name = L"Merulius' (Increase Duration)",
					text =
[[
Common - Wiry Merulius
Common Special - Oozing Arboreal Resin

Rare - Porous Wiry Merulius
Rare Special - Resinous Brown Extract
]],
				},
			},
		},

		{
			name = L"Level 100 Seeds/Spores",
			entries =
			{
				{
					name = L"Phlegmberrys (STR)",
					text =
[[
Common - Pasty Phlegmberry
Common Special - Thick Arboreal Resin

Rare - Jade Phlegmberry
Rare Special - Verdant Leaf Extract
]],
				},

				{
					name = L"Ulric's Tashs (WILL)",
					text =
[[
Common - Ropy Ulric's Tash
Common Special - Thick Arboreal Resin

Rare - Pock-Marked Ulric's Tash
Rare Special - Verdant Leaf Extract
]],
				},

				{
					name = L"Toody's Hats (INT)",
					text =
[[
Common - Crusted Toody's Hat
Common Special - Thick Arboreal Resin

Rare - High-Cap Toody's Hat
Rare Special - None
]],
				},

				{
					name = L"Flea Agarics (ACC)",
					text =
[[
Common - Whiskered Flea Agaric
Common Special - Thick Arboreal Resin

Rare - Stippled Flea Agaric
Rare Special - None
]],
				},

				{
					name = L"Old Man Mane (TOUGH/CORP)",
					text =
[[
Common - Old Man's Mane
Common Special - Thick Arboreal Resin

Rare - Green Old Man's Mane
Rare Special - None
]],
				},

				{
					name = L"Chev's Needles (ARMOUR)",
					text =
[[
Common - Wispy Chev's Needle
Common Special - Thick Arboreal Resin

Rare - Smooth Shelled Chev's Needle
Rare Special - Verdant Leaf Extract
]],
				},

				{
					name = L"Sorrels (AP)",
					text =
[[
Common - Wiry Sorrel
Common Special - Thick Arboreal Resin

Rare - WIllowy Red Sorrel
Rare Special - Verdant Leaf Extract
]],
				},

				{
					name = L"Black Peas (Healing)",
					text =
[[
Common - Pygmy Black Pea
Common Special - Thick Arboreal Resin

Rare - Trenchant Black Pea
Rare Special - None
]],
				},

				{
					name = L"Cannys (Flaming Breath)",
					text =
[[
Common - Curling Yellow Canny
Common Special - Thick Arboreal Resin

Rare - Sallow Violet Canny
Rare Special - None
]],
				},

				{
					name = L"Spikeworts (Fiery Concoction)",
					text =
[[
Common - Wavering Spikewort
Common Special - Thick Arboreal Resin

Rare - Blistering Spikewort
Rare Special - Verdant Leaf Extract
]],
				},

				{
					name = L"Shadow Fungus\t(Increase #)",
					text =
[[
Common - Dusky Shadow Fungus
Common Special - Thick Arboreal Resin

Rare - Mottled Shadow Fungus
Rare Special - One Seed Juniper Extract
]],
				},

				{
					name = L"Rose Blushers (Increase Duration)",
					text =
[[
Common - Rose Blusher Spore
Common Special - Thick Arboreal Resin

Rare - Yellow Stemmed Rose Blusher
Rare Special - None
]],
				},
			},
		},

		{
			name = L"Level 125 Seeds/Spores",
			entries =
			{
				{
					name = L"Phlegmberrys (STR)",
					text =
[[
Common - Slimy Phlegmberry
Common Special - Viscous Arboreal Resin

Rare - Willow Root Phlegmberry
Rare Special - Blue Bottle Fly Extract
]],
				},

				{
					name = L"Ulric's Tashs (WILL)",
					text =
[[
Common - Wiry Ulric's Tash
Common Special - Viscous Arboreal Resin

Rare - Scarred Ulric's Tash
Rare Special - Blue Bottle Fly Extract
]],
				},

				{
					name = L"Toody's Hats (INT)",
					text =
[[
Common - Caked Toody's Hat
Common Special - Viscous Arboreal Resin

Rare - Low-Cap Toody's Hat
Rare Special - Blue Bottle Fly Extract
]],
				},

				{
					name = L"Flea Agarics (ACC)",
					text =
[[
Common - Shaggy Flea Agaric
Common Special - Viscous Arboreal Resin

Rare - Mottled Flea Agaric
Rare Special - None
]],
				},

				{
					name = L"Old Man's Bristles (TOUGH/CORP)",
					text =
[[
Common - Old Man's Bristles
Common Special - Viscous Arboreal Resin

Rare - Brown Old Man's Bristles
Rare Special - Shining Clubmoss Extract
]],
				},

				{
					name = L"Chev's Needles (ARMOUR)",
					text =
[[
Common - Swollen Chev's Needle
Common Special - Viscous Arboreal Resin

Rare - Rough Shelled Chev's Needle
Rare Special - Blue Bottle Fly Extract
]],
				},

				{
					name = L"Sorrels (AP)",
					text =
[[
Common - Tufted Sorrel
Common Special - Viscous Arboreal Resin

Rare - Gossamer Red Sorrel
Rare Special - Blue Bottle Fly Extract
]],
				},

				{
					name = L"Black Peas (Healing)",
					text =
[[
Common - Dwarf Black Pea
Common Special - Viscous Arboreal Resin

Rare - Probing Black Pea
Rare Special - Blue Bottle Fly Extract
]],
				},

				{
					name = L"Cannys (Flaming Breath)",
					text =
[[
Common - Coiled Yellow Canny
Common Special - Viscous Arboreal Resin

Rare - Waxen Violet Canny
Rare Special - Blue Bottle Fly Extract
]],
				},

				{
					name = L"Spikeworts (Fiery Concoction)",
					text =
[[
Common - Whispering Spikewort
Common Special - Viscous Arboreal Resin

Rare - Searing Spikewort
Rare Special - Blue Bottle Fly Extract
]],
				},

				{
					name = L"Shadow Fungus\t(Increase #)",
					text =
[[
Common - Shaded Shadow Fungus
Common Special - Viscous Arboreal Resin

Rare - Dappled Shadow Fungus
Rare Special - Blue Bottle Fly Extract
]],
				},

				{
					name = L"Rose Blushers (Increase Duration)",
					text =
[[
Common - Carmine Blusher
Common Special - Viscous Arboreal Resin

Rare - Yellow Stemmed Carmine Blusher
Rare Special - Blue Bottle Fly Extract
]],
				},
			},
		},

		{
			name = L"Level 150 Seeds/Spores",
			entries =
			{
				{
					name = L"Spurges (STR)",
					text =
[[
Common - Blossoming Spurge
Common Special - Resilient Arboreal Resin

Rare - Broadleaf Spurge
Rare Special - Fiery Red Ant Extract
]],
				},

				{
					name = L"Spumepetals (WILL)",
					text =
[[
Common - Foaming Spumepetal
Common Special - Resilient Arboreal Resin

Rare - Pock-Marked Spumepetal
Rare Special - Fiery Red Ant Extract
]],
				},

				{
					name = L"Jack O'Lanterns (INT)",
					text =
[[
Common - Laughing Jack O'Lantern
Common Special - Resilient Arboreal Resin

Rare - Cyclopean Jack O'Lantern
Rare Special - None
]],
				},

				{
					name = L"Cheese Slippers (ACC)",
					text =
[[
Common - Lady's Cheese Slipper
Common Special - Resilient Arboreal Resin

Rare - Dwarf cheese Slipper
Rare Special - Fiery Red Ant Extract
]],
				},

				{
					name = L"Hook/Buck Berries (TOUGH/CORP)",
					text =
[[
Common - Serrated HookBerry
Common Special - Resilient Arboreal Resin

Rare - Green BuckBerry
Rare Special - Fiery Red Ant Extract
]],
				},

				{
					name = L"Spider Fronds (ARMOUR)",
					text =
[[
Common - Webbed Spider Frond
Common Special - Resilient Arboreal Resin

Rare - Gossamer Spider Frond
Rare Special - Shining Clubmoss Extract
]],
				},

				{
					name = L"Foolsberries (AP)",
					text =
[[
Common - Drunken Foolsberry
Common Special - Resilient Arboreal Resin

Rare - Willowy Foolsberry
Rare Special - Fiery Red Ant Extract
]],
				},

				{
					name = L"Grundles (Healing)",
					text =
[[
Common - Vibrant Green Grundle
Common Special - Resilient Arboreal Resin

Rare - Trenchant Yellow Grundle
Rare Special - Fiery Red Ant Extract
]],
				},

				{
					name = L"Argost Creeps (Flaming Breath)",
					text =
[[
Common - Crying Argost Creep
Common Special - Resilient Arboreal Resin

Rare - Sallow Argost Creep
Rare Special - None
]],
				},

				{
					name = L"Dragoncaps (Fiery Concoction)",
					text =
[[
Common - Crimson-Tipped Dragoncap
Common Special - Resilient Arboreal Resin

Rare - Blistering Dragoncap
Rare Special - None
]],
				},

				{
					name = L"Clubmosses\t(Increase #)",
					text =
[[
Common - Wolfpaw Clubmoss
Common Special - Resilient Arboreal Resin

Rare - Mottled Clubmoss
Rare Special - Fiery Red Ant Extract
]],
				},

				{
					name = L"Stalkballs (Increase Duration)",
					text =
[[
Common - Wiggly Stalkball
Common Special - Resilient Arboreal Resin

Rare - Paired Wiggly Stalkball
Rare Special - Fiery Red Ant Extract
]],
				},
			},
		},

		{
			name = L"Level 175 Seeds/Spores",
			entries =
			{
				{
					name = L"Spurges (STR)",
					text =
[[
Common - Milksap Spurge
Common Special - Hale Arboreal Resin

Rare - Weeping Spurge
Rare Special - None
]],
				},

				{
					name = L"Spumepetals (WILL)",
					text =
[[
Common - Frothing Spumepetal
Common Special - Hale Arboreal Resin

Rare - Scarred Spumepetal
Rare Special - None
]],
				},

				{
					name = L"Jack O'Lanterns (INT)",
					text =
[[
Common - Mocking Jack O'Lantern
Common Special - Hale Arboreal Resin

Rare - Hollow-Eyed Jack O'Lantern
Rare Special - Fiery Red Ant Extract
]],
				},

				{
					name = L"Cheese Slippers (ACC)",
					text =
[[
Common - Six-Toed Lady's Cheese Slipper
Common Special - Hale Arboreal Resin

Rare - Six-Toed Dwarf cheese Slipper
Rare Special - Fiery Red Ant Extract
]],
				},

				{
					name = L"Hook/Buck Berries (TOUGH/CORP)",
					text =
[[
Common - Piked HookBerry
Common Special - Hale Arboreal Resin

Rare - Brown BuckBerry
Rare Special - None
]],
				},

				{
					name = L"Spider Fronds (ARMOUR)",
					text =
[[
Common - Black Spider Frond
Common Special - Hale Arboreal Resin

Rare - Albino Spider Frond
Rare Special - Fiery Red Ant Extract
]],
				},

				{
					name = L"Foolsberries (AP)",
					text =
[[
Common - Blissful Foolsberry
Common Special - Hale Arboreal Resin

Rare - Gossamer Foolsberry
Rare Special - None
]],
				},

				{
					name = L"Grundles (Healing)",
					text =
[[
Common - Aromatic Green Grundle
Common Special - Hale Arboreal Resin

Rare - Probing Aromatic Yellow Grundle
Rare Special - Sugar Bush Extract
]],
				},

				{
					name = L"Argost Creeps (Flaming Breath)",
					text =
[[
Common - Coiled Argost Creep
Common Special - Hale Arboreal Resin

Rare - Waxen Argost Creep
Rare Special - None
]],
				},

				{
					name = L"Dragoncaps (Fiery Concoction)",
					text =
[[
Common - Yellow-Tipped Dragoncap
Common Special - Hale Arboreal Resin

Rare - Searing Dragoncap
Rare Special - None
]],
				},

				{
					name = L"Clubmosses\t(Increase #)",
					text =
[[
Common - Staghorn Clubmoss
Common Special - Hale Arboreal Resin

Rare - Dappled Clubmoss
Rare Special - Sugar Bush Extract
]],
				},

				{
					name = L"Stalkballs (Increase Duration)",
					text =
[[
Common - Gauzy Stalkball
Common Special - Hale Arboreal Resin

Rare - Paired Gauzy Stalkball
Rare Special - Fiery Red Ant Extract
]],
				},
			},
		},

		{
			name = L"Goldweeds",
			entries =
			{
				{
					name = L"Level 1",
					text =
[[
Common - Prickly Goldweed
Rare - Glinting Spurge
]],
				},

				{
					name = L"Level 25",
					text =
[[
Common - Glinting Goldweed
Rare - Spiny Goldweed
]],
				},

				{
					name = L"Level 50",
					text =
[[
Common - Spiny Goldweed
Rare - Glimmering Goldweed
]],
				},

				{
					name = L"Level 75",
					text =
[[
Common - Glimmering Goldweed
Rare - Thorny Goldweed
]],
				},

				{
					name = L"Level 100",
					text =
[[
Common - Thorny Goldweed
Rare - Gleaming Goldweed
]],
				},

				{
					name = L"Level 125",
					text =
[[
Common - Gleaming Goldweed
Rare - Barbed Goldweed
]],
				},

				{
					name = L"Level 150",
					text =
[[
Common - Barbed Goldweed
Rare - Vibrant Goldweed
]],
				},

				{
					name = L"Level 175",
					text =
[[
Common - Vibrant Goldweed
Rare - None
]],
				},
			},
		},
	},
}
