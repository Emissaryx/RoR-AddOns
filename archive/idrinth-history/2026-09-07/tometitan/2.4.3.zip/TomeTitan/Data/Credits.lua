TTitan.Data.Credits = {}

function TTitan.Data.Credits.GetData()
	return TTitan.Data.Credits.RawData
end

function TTitan.Data.Credits.FilterData()
end

TTitan.Data.Credits.RawData =
{
	header = L"FAQ & Credits",
	categories =
	{
		{
			name = L"FAQ",
			entries =
			{
				{
					name = L"About this Add-on",
					text =
[[
Welcome to Tome Titan! The purpose of this add-on is to take information posted on the RoR Wiki and list them here in-game in an easy to read and find format.

In short: To keep you from having to alt-tab.


We have information on Bestiary, History & Lore, and Noteworthy Persons unlocks as well as lists of Lairs, Explorations, and Pursuits. We also have Apothecary, Cultivating, and Talisman Making information. 
The add-on will also track if unlocks have been completed and can either hide them altogther, or mark them as completed, accordingly.


To add a macro for easy access to Tome Titan, open the Main Menu, select Macros, and use this as your macro text:

/script TTitan.UI.ToggleShowing()

You can also make a macro for going to the current zone:

/script TTitan.UI.ExpandCurrentZone(); TTitan.UI.Show()


Please use "/ttitan help" for a full list of commands.
]],
				},

				{
					name = L"How often is it updated?",
					text =
[[
The original creators of this addon have long sinced moved on from the game and the RoR project. With that, I have aimed to keep the addon as up to date as possible. 
My goal is to update all entries to accurately reflect the game as it currently is. Once that is complete I will do my best to update it as unlocks become available or change. 
]],
				},

				{
					name = L"Can you add...",
					text =
[[
Your best option to contact me is on the GWU discord: https://discord.gg/da-union
]],
				},
			},
		},

		{
			name = L"Credits",
			entries =
			{
				{
					name = L"The Tome Titan Team",
					text =
[[
That's a lot of T's! But seriously, Tome Titan is updated and mainted by a number of people. I will list them here along with their roles. I am also sad to say that most of the original team have left the game and no longer unpdate the addon. So it is up to me to update it myself.

Aenathel -- Ex - Project Manager, Main Coder, Data Updates (Inactive)
   Aenathel has really improved the add-on a lot since joining the Tome Titan Team - he is the main coder and the guy working the magic of the latest updates. Nearly the entire add-on has been rewritten to be easier to use, and provide much more functionality thanks to him. All major code changes go through him. He's also helped out on cleaning up a lot of the various data files.

Oscarr -- Ex - Bestiary and Lair Locations Updates, Minor Coding (Inactive)
   Oscarr originally started this project as Bestiary Helper. It was based off of the Killerguides add-on (with their permission) used for displaying data in a nice two-paned window - the same window used by the in-game Help. Oscarr and Squigy got together later on and decided to rename the project as Tome Titan and started including more data. Oscarr wrote the TTBar directory that handles modules for the popular Board/Bar add-ons. He also attempts to assist Aenathel with coding when and where possible.

Possibly (previously SquigyStardust) -- Ex - Project Manager, Main Content Updater, Minor Coding (Inactive)
   Previously only updating the History and Lore Sections, I will now update most of the information of this addon as the other authors are largely inactive now. 
   
Tallinah -- All of the above? 
I am hoping to maintain and update this project as must as possible including any unlock updates and possible additions to many of the other tome unlocks that are currently not in the addon. 
I want to express my deepest gratitude to the original authors and coders of this project for creating such an amazing addon for Warhammer Online. 
]],
				},
			},
		},

		{
			name = L"Changes",
			entries =
			{

                {
					name = L"Most Recent Changes",
					text =
[[

DATA
All information in the Empire vs. Chaos pairing unlocks has been updated to reflect a new layout and updated instructions where applicable. 
All Destro unlocks have been personally verified in game. Some order unlocks have been verified, however, at this time they may not all be implemented. 

]]
				},							
			},
		},
	},
}
