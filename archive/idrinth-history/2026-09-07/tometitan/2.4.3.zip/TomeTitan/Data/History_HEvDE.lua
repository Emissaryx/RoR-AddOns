TTitan.Data.HistoryHEvDE = {}

function TTitan.Data.HistoryHEvDE.GetData()
	return TTitan.Data.HistoryHEvDE.RawData
end

function TTitan.Data.HistoryHEvDE.FilterData()
	TTitan.Data.FilterByRealm(TTitan.Data.HistoryHEvDE.RawData)
end

TTitan.Data.HistoryHEvDE.RawData =
{
	header = L"History & Lore Unlocks - High Elves vs Dark Elves",
	categories =
	{
		{
			name = L"The Blighted Isle",
			entries =
			{
				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"The Shining Guard",
					text =
[[
43.1k, 8.8k
Talk to Eliryel Sorrowblade, the career trainer, in Moonrise Tower - High Elf Chapter 1.

]],
				},

				{	
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"The Shining Guard",
					text =
[[
20.4k, 54.5k 
Kill a ‘Shining Commander just outside Cyanthai - Dark Elf War Camp.
]],
				},

				{	
					realm = TTitan.Data.Realm.ORDER,
					name = L"Eltharin, Language of the High Elves",
					text =
[[
39.9k, 1.8k
Interact with the 'A Dusty Old Tome' on a bench in Moonrise Tower - High Elf Chapter 1, north of the tower.
]],
				},

				{	
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Eltharin, Language of the High Elves",
					text =
[[
Entrance 17.4k, 16.4k 
Interact with the 'A Dusty Old Tome' in Halls of Aenarion, in the last room in the end of underground tunnel system, by the Spires of Narthain PQ.
]],
				},

				{	
					name = L"The Beasts of Karond Kar",
					text =
[[
14.8k, 47.8k
Interact with the 'Manacles of Wrought Iron' in the ruins north of Posionblade Heath - Dark Elf - Chapter 3 camp. The chains are located on the right-hand of the ruins obscured by a twisted tree, it's well hidden.
]],
				},

				{
					name = L"Benevolent Protectors",
					text =
[[
39k, 37k 
Talk to the ‘Wounded Swale Mare’ in The Swale of Miralei PQ.
]],
				},

				{	
					realm = TTitan.Data.Realm.ORDER,
					name = L"Masters of Sword, Bow and Spear",
					text =
[[
52.2k, 8.3k 
Interact with the ‘Plundered Weapon Rack’ at the House Arkaneth PQ. As you face the large building, there is a wardrobe tucked away on the left. A House Arkaneth Shade stands in front of it.
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Masters of Sword, Bow and Spear",
					text =
[[
9.3k, 38k
Interact with the ‘Weapon Rack’ in the Nimosar PQ.
]],
				},

				{	
					realm = TTitan.Data.Realm.ORDER,
					name = L"Ancient History",
					text =
[[
54.5k, 14.2k
Interact with the 'Empty Bookshelf' located deep inside the Halls of Lileath. Make your way into the same room where the scrolls and tears are gathered, upon entering the doorway, turn immediately to your right.
]],
				},

				{	
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Ancient History",
					text =
[[
5.3k, 31.6k
Interact with the scroll of “Ancient Lore’ at Shrine of Lore, Major Landmark.
]],
				},

				{
					name = L"The War of the Beard",
					text =
[[
37.6k, 37.7k 
Interact with the scroll 'A Personal Letter' on a table in Lacorith Village.
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"House Uthorin",
					text =
[[
54.4k, 31.6k 
Interact with a banner 'House Uthorin Ensign' next to the gangplank of the Dark Elf ship docked at the water's edge.
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"House Uthorin",
					text =
[[
12.2k, 33.1k 
Interact with a banner 'House Uthorin Ensign' outside the south side (facing the lake) of the tent containing Kerryn Darkwater, in the Mistwood camp - Dark Elf Chapter 2.
]],
				},

				{	
					name = L"The Witch King",
					text =
[[
60k, 40k 
Interact with a banner 'Dark Elf Gonfalon' on the east side of a big tent by the sea in Eranneth.
]],
				},

				{
					name = L"Vile Perversions",
					text =
[[
33.3k, 27.6k 
Interact with an elf corpse 'Defiled Body' in the Northeast corner of Mistwood Grove Destruction PQ.
]],
				},

				{
					name = L"Dark Elf Treachery",
					text =
[[
8.5k, 20.6k 
Interact with 'A Discarded Message' on the ground between two High Elf ballistas.
]],
				},

				{	
					name = L"The Black Arks of Naggaroth",
					text =
[[
4.8k, 9.5k 
Proximity Area Unlock: Black Ark Bridge at the Black Ark Landing.
]],
				},
			},
		},

		{
			name = L"Chrace",
			entries =
			{
				{
					name = L"The Shadow Warriors",
					text =
[[
3.7k, 51k 
Interact with the body of a 'Tortured Dark Elf' near the Destruction entrance to the Shadowlands, at a camp of shadow warriors. They surround a large blighted tree to the North of the Shadowlands entrance.
]],
				},

				{
					name = L"Manbane",
					text =
[[
31.5k, 41.5k
Interact with the ‘Lathranoi Flower' among some trees there are some flowers on a hill near Thanuil's Retreat, Major Landmark.
]],
				},

				{
					name = L"Thanuil's Retreat",
					text =
[[
37k, 40k
Proximity Area Unlock: Thanuil's Retreat, Major Landmark . Go to the top of the hill Thanuil Hawksong is and climb the stairs.
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"The White Lions of Chrace",
					text =
[[
8.2k, 9.9k 
Talk to the ‘White Lion Guardian’ in front of a tent in the Lionmarch, Major Landmark.
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"The White Lions of Chrace",
					text =
[[
8.2k, 9.9k 
Kill the ‘White Lion Guardian’ in front of a tent in the Lionmarch, Major Landmark.
]],
				},

				{
					name = L"Aenarion",
					text =
[[
56k, 19k 
Interact with 'A Memorial to Aenarion' which is a small block of stone with some elvish script on it, on a bluff overlooking a High Elf city below.
]],
				},

				{
					name = L"Khaine",
					text =
[[
63k, 42.8k
Interact with the elf body of a 'Blade Sacrifice' next to a blood cauldron in Lyrianna's Mansion, Major Landmark.
]],
				},

				{
					name = L"The Menhir Stones",
					text =
[[
60.9k, 51k 
Interact with the ‘Menhir-Infused Shard’ near the Stone of Imrathir PQ.
]],
				},

				{
					name = L"The Vortex",
					text =
[[
8.7k, 32.8k 
Interact with the ‘Broken Archmage Staff’ next to the center stone of The Illboughs Stones, Major Landmark.
]],
				},
			},
		},

		{
			name = L"The Shadowlands",
			entries =
			{
				{
					name = L"Nagarythe",
					text =
[[
42k, 31k 
Interact with the ‘Nagarythe Ruin’ east of the Broken Spirits PQ.
]],
				},

				{
					name = L"A People Divided",
					text =
[[
3k, 28k 
Interact with the ‘Memorial Inscription’ marker in front of the statue on the western coast near look on a hilltop for a statue overlooking the sea.
]],
				},

				{
					name = L"Dark Magic",
					text =
[[
54.2k, 3.6k 
Interact with a 'Worn Cage' Broken Dunes PQ.
]],
				},

				{
					name = L"The Noble Houses of Naggaroth",
					text =
[[
52.8k, 31.7k 
Interact with a 'Weathered Scroll' on ground between two trees that are really close from each other, southeast Forgotten Future PQ.
]],
				},

				{
					name = L"Rise to Power",
					text =
[[
63.2k, 40.4k 
Interact with a 'Forgotten Tablet' found south of the Lair of the Dead PQ.
]],
				},

				{
					name = L"Land of Chill",
					text =
[[
12.3k, 44.5k 
Interact with the 'General Issue Tent' east of the Shrine of Remembrance, Major Landmark.
]],
				},

				{
					name = L"Intrigues of the Dark Elves",
					text =
[[
25.7k, 13.6k 
Interact with an 'Emptied Coffer' on top of a hill located at the base of a tree.
]],
				},

				{
					name = L"The Shadow Warriors' Vigil",
					text =
[[
1.4k, 14.5k 
Interact with a 'Recent Campfire' southwest of Sundered Strand - Dark Elf Chapter 6.
]],
				},

				{
					name = L"The Price of Vengeance",
					text =
[[
29.1k, 14.5k
Interact with an 'Emptied Weapon Rack' on the south side of a large spire, south of the Ruins of Anlec PQ in the Arkaneth Camp.
]],
				},

				{
					name = L"The Outer Kingdoms",
					text =
[[
14.7k, 15.3k 
Interact with a scroll 'Outer Kingdoms Map' at the entrance to the north small tent among the Bloodcharge Coldbloods, dead Dark Elves and Ardelon Nisothar (Champion lvl 13) in the Shattered Basin.
]],
				},
			},
		},

		{
			name = L"Ellyrion",
			entries =
			{
				{
					name = L"The Steeds of Ellyrion",
					text =
[[
49.4k, 22.8k 
Interact with the 'Dead Ellyrion Steed' beside the upright wagon just off the road south of the Ellyrion Stables PQ where the convoy was ambushed.
]],
				},

				{
					name = L"High Magic",
					text =
[[
18.3k, 19.3k 
Interact with a small tablet 'Mage Stone' on a ledge with lions east of Shining Encampment, Major Landmark.
]],
				},

				{
					name = L"Ithilmar",
					text =
[[
39.7k, 41.5k 
Interact with 'Damaged Armor' behind the tower of the Reaverspring - High Elf Chapter 9 camp, right up against the mountain range.
]],
				},

				{
					name = L"The Silver Helms",
					text =
[[
26k, 30k 
Interact with the ‘Slain Invader’ at the crossroads north of Destruction’s entrance to Hunter’s Vale, Major Landmark and Dungeon.
]],
				},

				{
					name = L"The Seers of Ghrond",
					text =
[[
61k, 6.5k 
Kill the 'Seer of Ghrond' on the ridge overlooking Irongob’s Camp, Major Landmark, south of the Dragon Gate.
]],
				},

				{
					name = L"Vile Perversions",
					text =
[[
51.2k, 58.7k 
Interact with 'Prisoner Shackles', east of the Gates of Elthrai PQ, next to one Ellyrian Reaver and two Uthorin Dreadblades.
]],
				},

				{
					name = L"Corsair Raids",
					text =
[[
63k 51k 
Interact with the ‘Druchii Longboat’ along the shore of the eastern beach, north of Order’s entrance to Hunter’s Vale, Major Landmark and Dungeon.
]],
				},

				{
					name = L"Har Ganeth Executioners",
					text =
[[
32k, 46k 
Interact with the weapon rack 'Har Ganeth Halberd', on the High Elf side of the Elyr Gate, near the walls
]],
				},

				{
					name = L"Balance and Discipline",
					text =
[[
8.4k, 50.6k 
Interact with 'Broken High Elf Bust' southeast of Conqueror’s Watch, Major Landmark.
]],
				},

				{
					name = L"The Lessons of the Past",
					text =
[[
6.6k, 45.4k
Interact with the 'Neglected Brazier' at the crossroads north of Conqueror’s Watch, Major Landmark.
]],
				},
			},
		},

		{
			name = L"Avelorn",
			entries =
			{
				{
					name = L"Twilight of the High Elves",
					text =
[[
6.1k, 63.4k
Interact with broken 'Neglected Altar' in the Shrine of Solace, Major Landmark.
]],
				},

				{
					name = L"The Temple of Khaine",
					text =
[[
9.6k, 4.2k 
Interact with a 'Defiled Tree Trunk' up on one of the hills east of Spirited Resistance PQ.
]],
				},

				{
					name = L"Death Night",
					text =
[[
13k, 28.7k
Interact with a dark elf corpse the 'Denied Reveler' hidden under a huge rock to the west side of Ghyran's Path, Major Landmark.
]],
				},
				
				{
					name = L"Assassins",
					text =
[[
37.5k, 29.3k
Interact with a hanging corpse of 'A Hung Peasant' on one of the trees near a small Druchii camp northwest of Whisperwoods - High Elf Chapter 12.
]],
				},

				{
					name = L"The Cauldrons of Blood",
					text =
[[
27.9k, 16.5k
Interact with 'A Weathered Cauldron' in the Ritual of Corruption PQ.
]],
				},

				{
					name = L"Bitter Rivals",
					text =
[[
33.1k, 20.9k 
Interact with 'A Tortured Rival' leaning against a tree, southeast of the Ritual of Corruption PQ.
]],
				},

				{
					name = L"Witchbrew",
					text =
[[
13.8k, 47.5k
Interact with the bottles of 'Assorted Concoctions' at inside one of the tents in one of the Arkaneth camps northeast of Isha’s Fall - Dark Elf Warcamp.
]],
				},

				{
					name = L"Isha",
					text =
[[
15k, 61.6k 
Interact with 'An Elder Root' nearby the water's edge on the southern part of the map at. It is a little off south from Isha's Fall - Dark Elf Warcamp and Jade Strand PQ.
]],
				},

				{
					name = L"Astarielle, the First Everqueen",
					text =
[[
4.7k, 51.7k
Interact with the book, 'A History of Elves' in the Evercourt camp down south Jade Coast - Dark Elf Chapter 12. It's lying open on a white stone wall planter on the right-hand side of the camp nearby a tent that is closest to the water's edge.
]],
				},

				{
					name = L"Land of Eternal Summer",
					text =
[[
7.6k, 22.5k
Interact with a 'Bone-Dry Stein' on a table in front of a tent west of Handmaiden’s Enclave, Major Landmark.
]],
				},

				{
					name = L"The Inner Kingdoms",
					text =
[[
21k, 2k
Interact with the high elf corpse 'Heart Stricken Warrior' at. He's lying on top of the hills east of the Spirited Resistance PQ.
]],
				},

				{
					name = L"The Maiden Guard",
					text =
[[
61.7k, 9.3k
Interact with a 'Maiden's Guard' shield, on the ground behind one of the elf towers, on the east side of Grimwater - High Elf Chapter 11 camp.
]],
				},

				{
					name = L"Malekith and Morathi",
					text =
[[
40k, 24.1k
Interact with a skull that leaves 'A Clear Message' on the table inside one of the tents in the Arkaneth camp.
]],
				},

				{
					name = L"The Evercourt",
					text =
[[
55k, 8.3k
Proximity Area Unlock: Approach the door of the tower in the small lake east of Grimwater - High Elf Chapter 11.
]],
				},

				{
					name = L"Seafaring Tradition",
					text =
[[
1.8k, 35.2k 
Proximity Area Unlock: Board the middle ship in the Sea Guard Beachhead PQ.
]],
				},
			},
		},

		{
			name = L"Saphery",
			entries =
			{
				{
					name = L"The Crimson Shroud",
					text =
[[
57.2k, 17k 
Interact with the 'Basin of Skulls', near two small tents, just west of the bridge leading to the Thanon Hall PQ.
]],
				},

				{
					name = L"The Cornerstone",
					text =
[[
19.4k, 50.4k
Interact with the 'Dedication Plaque' on the ground, just below a winged elf statue at The White Tower of Hoeth PQ.
]],
				},

				{
					name = L"Conclave of the Winds",
					text =
[[
9.8k 57k
Interact with 'Broken Mage Staff' among the tree clusters along the river.
]],
				},

				{
					name = L"Dragon Mages",
					text =
[[
62k 32.4k
Interact with the toppled 'Aqshy Brazier' next to a tent in the Raven camp.
]],
				},

				{
					name = L"The Siege of Silverglass Stand",
					text =
[[
38.7k, 42.4k
Interact with the 'Broken Rock Lobber' outside the orc stronghold in The Siege of Silverglass Stand PQ.
]],
				},

				{
					name = L"Untrustworthy Allies",
					text =
[[
40.8k, 30.4k
Interact with the 'Abandoned Chest' next to a Deceased Chaos Warrior down the cliff northwest of Sinelian Hall, Major Landmark.
]],
				},

				{
					name = L"Noble Privilege",
					text =
[[
37.6k, 17k
Interact with the 'Secluded Tent' at, up on the cliff, above the Skyrage Griffon nests northwest of The Circle of the Winds PQ.
]],
				},

				{
					name = L"The Glade of Reflection",
					text =
[[
32k, 19.5k 
Interact with the ‘Isolated Well‘ west of the Skyrage Griffon nests.
]],
				},

				{
					name = L"The Skyrage Griffons",
					text =
[[
37.2k, 25.3k 
Interact with the ‘PristineSkyrage Egg’ in a nest halfway up the hillside.
]],
				},

				{
					name = L"Dark Pact",
					text =
[[
49k, 28k
Interact with ‘Raven Banner" at The Platinum Tower PQ.
]],
				},

				{
					name = L"First Among Equals",
					text =
[[
23.9k, 48.7k
Interact with 'Discarded Banner' at river's edge next to tree at.
]],
				},

				{
					name = L"Stoic Defenders",
					text =
[[
27.2k, 53.4k
Interact with cauldron 'Sorceress' Kettle' at the House of Cards PQ.
]],
				},

				{
					name = L"Highborn",
					text =
[[
45.6k 54.3k
Interact with the small 'Intricate Vase' between a large Dark Elf wagon by a small wall.
]],
				},

				{
					name = L"Cold One Knights",
					text =
[[
49.4, 56.2k
Proximity Area Unlock: Walk near the Cold Ones pen.
]],
				},

				{
					name = L"Lethal Poisons",
					text =
[[
31.3k, 62.2k
Interact with the High Elf corpse of a 'Dispatched Warrior' down the hill near the water's edge.
]],
				},
			},
		},

		{
			name = L"Dragonwake",
			entries =
			{
				{
					name = L"Vaul",
					text =
[[
35.8k, 52.0k
Click on "Caladain Anvil" up against the house with the golden roof.
]],
				},

				{
					name = L"The Blind Smiths",
					text =
[[
22.4k, 47.6k
Click on "The Lay of the Blind Smiths", a book on the ground towards the cliff edge.
]],
				},

				{
					name = L"The Dragon Spine Mountians",
					text =
[[
19.5k, 63.5k
Click on "Dragon Spine Scepter", high up the mountain side.
]],
				},

				{
					name = L"The Taming of Bracchus",
					text =
[[
10.2k, 21.4k
Click on "A Beastmaster's Tome" that sits on a small table by a campfire and three dark elf tents.
]],
				},

				{
					name = L"Beastmasters of Karond Kar",
					text =
[[
23.3k, 53.6k 
Click on "Corral", the gate to open the beast pen.
]],
				},

				{
					name = L"The Sacred Flame",
					text =
[[
31.7k, 2.4k
Click on "Elven Tent", in the small camp on the cliff edge.
]],
				},

				{
					name = L"The Phoenix Guard",
					text =
[[
12.8k, 30.9k
Click on "A Simple Headstone".
]],
				},

				{
					name = L"The Pilgrimage",
					text =
[[
Either incorrect or not implemented
61.6k, 11.7k
Click on "An Aged Wayshrine", just off the path.
]],
				},

				{
					name = L"The Black Heart Coven",
					text =
[[
38.2k, 39.9k
In RvR Lake – Click on "Pile of Skulls", part way down the cliff side.
]],
				},

				{
					name = L"The Dragonwake Sentinels",
					text =
[[
55.2k, 8.3k 
Click on "Tactical Map", next to a small dark elf tent on top of the cliff.
]],
				},

				{
					name = L"A Vessel of Khaine",
					text =
[[
55.2k, 58.6k 
Click on "Worn Sack", down near the bottom of the waterfall.
]],
				},
			},
		},

		{
			name = L"Isle of the Dead",
			entries =
			{

				{
					name = L"Monument to the Ancient Fallen",
					text =
[[
20.3k, 53.4k 
In Isle of the Dead – Click on "Monument to the Ancient Fallen" at top of the peninsula.
]],
				},

				{
					name = L"Downward Spiral",
					text =
[[
38.7k, 5.3k 
In Isle of the Dead – Kill "Insane Sorcerer" by the sea at the bottom of the cliff.
]],
				},

				{
					name = L"Timeless",
					text =
[[
42.6k, 30.4k 
In Isle of the Dead – Talk to "Sarilion Avethan".
]],
				},

				{
					name = L"Aenarion and the Daemons",
					text =
[[
41.3k, 35.9k 
In Isle of the Dead – Approach the statue, just near the path to the vortex.
]],
				},
			},
		},
		
		{
			name = L"Caledor",
			entries =
			{
				{
					name = L"Beastmasters of Karond Kar",
					text =
[[
52.6k, 4.4k 
Click on "Empty Goblet" on top of a rock.
]],
				},

				{
					name = L"Caledor Dragontamer",
					text =
[[
1.1k, 19.1k 
Click on "Dragontamer Monument" in the forest.
]],
				},

				{
					name = L"The Dragon Princes",
					text =
[[
64.5k, 39.8k 
Click on "Dragon Prince Horse" just east of the path. Their are two of them side by side, and either one works.
]],
				},

				{
					name = L"Truesteel ",
					text =
[[
45.5k, 43.3k
Click on "Crate of Truesteel".

IMPORTANT NOTE
For Destruction to go on Order side of Caledor's map:
From Dragonwake war camp, walk in RvR area then join PvE area at 29k 45k.
Reach 2k 59k to take the secret passage, avoiding Order Chapters, and you'll arrive in Caledor.
]],
				},

				{
					name = L"A Memory of Fire",
					text =
[[
29.9k, 53.0k
Click on "Volcanic Rock" in the middle of the river.

IMPORTANT NOTE
For Destruction to go on Order side of Caledor's map:
From Dragonwake war camp, walk in RvR area then join PvE area at 29k 45k.
Reach 2k 59k to take the secret passage, avoiding Order Chapters, and you'll arrive in Caledor.
]],
				},

				{
					name = L"Reaper Bolt Thrower",
					text =
[[
Either incorrect or not implemented
64.3k, 13.0k 
Click on "Reaper Bolt Thrower" next to the path, just west of Dark Elf Chapter 17.
]],
				},

				{
					name = L"Lost Legacy",
					text =
[[
46.7k, 16.5k 
Walk under the small stone arch just west of the road, unlock triggered walking up the small steps and through the archway.
]],
				},

				{
					name = L"A First Time for Everything",
					text =
[[
26.9k, 2.8k 
Board the Dwarf ship at Kelysian's Landing.
]],
				},

				{
					name = L"Caledor the Conqueror",
					text =
[[
41.6k, 40.6k
Click on "Phoenix King Caledor I", a bust on the left side as you approach the tower behind the rubble pile.

IMPORTANT NOTE
For Destruction to go on Order side of Caledor's map:
From Dragonwake war camp, walk in RvR area then join PvE area at 29k 45k.
Reach 2k 59k to take the secret passage, avoiding Order Chapters, and you'll arrive in Caledor.
]],
				},

				{
					name = L"The Price of Disloyalty",
					text =
[[
10.8k, 11.3k 
Click on "Cage" at the side of the road.
]],
				},

				{
					name = L"Prideful Arrogance",
					text =
[[
16.8k, 2.5k
Walk into the Elven gazebo, with the fancy chairs and harp.
]],
				},

				{
					name = L"The Drakefall Defenders",
					text =
[[
43.6k, 49.0k 
Click on "Sun Bleached Bone" near a giant ribcage close to the road.

IMPORTANT NOTE
For Destruction to go on Order side of Caledor's map:
From Dragonwake war camp, walk in RvR area then join PvE area at 29k 45k.
Reach 2k 59k to take the secret passage, avoiding Order Chapters, and you'll arrive in Caledor.
]],
				},

				{
					name = L"Tethlis the Slayer",
					text =
[[
9.0k, 2.5k 
Click on "Chronicle of the Phoenix Kings" on some small stairs round the back of the tower.
]],
				},

				{
					name = L"The Trail of Darian Stormspear",
					text =
[[
64.2k, 57.6k
Click on "Notably Worn Bedroll" on top of the ledge, on the east side of the canyon. The bedroll is behind a tree at the south end of the ledge.
]],
				},

				{
					name = L"Fickle Favor",
					text =
[[
4.4k, 38.7k
In RvR Lake – Approach the alter inside "Hatred's Way" keep, you have to stand on the stone plinth to trigger the unlock.
]],
				},
			},
		},

		{
			name = L"Eataine",
			entries =
			{
				{
					name = L"Asuryan",
					text =
[[
21.3k, 62.2k 
Click on "Shrine of Asuryan".
]],
				},

				{
					name = L"The Lothern Seaguard",
					text =
[[
62.3k, 6.5k
Click on "Seaguard Banner" on the lower level of the dock.
]],
				},

				{
					name = L"High Elf Colonies",
					text =
[[
0.4k, 11.0k 
Click on "Small Campfire Remains".
]],
				},

				{
					name = L"Eagle Claw Bolt Throwers",
					text =
[[
13.5k, 53.3k 
Click on "The Eagle's Claw" one of two bolt throwers defending the tower.
]],
				},

				{
					name = L"The Straits of Lothern",
					text =
[[
53.9k, 21.7k 
Click on "Cornerstone Plague", on the ground round the back of the tower.
]],
				},

				{
					name = L"The Third Gate",
					text =
[[
63.7k, 46.6k 
Click on "A Stored Dinghy" underneath the docks.
]],
				},

				{
					name = L"Lileath",
					text =
[[
39.9k, 15.1k 
Click on "Gem Adorned Tome", behind one of two tents in the trees.
]],
				},

				{
					name = L"Orcification",
					text =
[[
6.3k, 5.3k 
Click on "Orc Landing Banner", infront of the orc barge.
]],
				},

				{
					name = L"The Underworld Sea",
					text =
[[
1.2k, 8.8k 
Click on "Locked Chest", washed up on the beach.
]],
				},

				{
					name = L"Repeater Crossbow",
					text =
[[
26.0k, 49.6k
Click on "Roadside Memorial".
]],
				},

				{
					name = L"Tiranoc Chariot",
					text =
[[
33.1k, 51.7k
Click on "Elven Chariot".
]],
				},

				{
					name = L"Cold One Chariot",
					text =
[[
15.8k, 23.7k 
Walk near the Dark Elf charoit in the middle of the camp.
]],
				},

				{
					name = L"A Dark Day (Enemies in the Inner Sea)",
					text =
[[
31.2k, 2.9k 
Walk onto the Orc barge.
]],
				},

				{
					name = L"Stronger Bonds",
					text =
[[
29.2k, 15.9k 
Click on "Empty Jug" on the ground.
]],
				},

				{
					name = L"Cold One Knights",
					text =
[[
46.9k, 12.6k 
Click on "Gnawed Bones", at the end of one of the outer wall sections.
]],
				},
			},
		},
	},
}
