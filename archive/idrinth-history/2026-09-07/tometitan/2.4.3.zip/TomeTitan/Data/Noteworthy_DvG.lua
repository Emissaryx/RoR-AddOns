TTitan.Data.NoteworthyDvG = {}

function TTitan.Data.NoteworthyDvG.GetData()
	return TTitan.Data.NoteworthyDvG.RawData
end

function TTitan.Data.NoteworthyDvG.FilterData()
	TTitan.Data.FilterByRealm(TTitan.Data.NoteworthyDvG.RawData)
end

TTitan.Data.NoteworthyDvG.RawData =
{
	header = L"Noteworthy Persons Unlocks - Dwarfs vs Greenskins",
	categories =
	{
		{
			name = L"Ekrund",
			entries =
			{
				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Grimilda Mughammer",
					text =
[[
19.2k, 46.1k 
Dwarven Kill Collector in Goldbrow's Lament.
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Rordin Ironmane",
					text =
[[
35k, 36.5k
Rally Master in the Battle of Bitterstone, Dwarf Chapter 1.
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Skolm Goldskaar",
					text =
[[
46k, 30k
Kill Collector in Redhammer Station, Dwarf Chapter 2.
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Krogan Redhammer",
					text =
[[
46.3k, 31.5k
Rally Master at Redhammer Station, Dwarf Chapter 2.
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Moranir Grudgekeg",
					text =
[[
54.5k, 18k
NPC at Grudgekeg's Guard Warcamp.
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Gorgor",
					text =
[[
58k, 38k
Rally Master - Greenskins Chapter 4 - Gorgor's Smash.
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Gorsh Smashmouf",
					text =
[[
57.6k, 36k
Gorgor's Smash Camp.
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Xobz Madgut",
					text =
[[
59k, 39k
Kill Collector - Greenskins Chapter 4 - Gorgor's Smash.
]],
				},
			},
		},

		{
			name = L"Mount Bloodhorn",
			entries =
			{
				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Odarik Rorkisson",
					text =
[[
7k, 25.5k
Rally Master of Komar.
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Captain Skalfson",
					text =
[[
45k, 16k
Rally Master of Skalfson's Watch.
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Zamgund Roarhammer",
					text =
[[
17k,25k

]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Dodrum Ironsplitter",
					text =
[[
8k, 24.5k
Kill Collector of Komar.
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Barin Grimbeard",
					text =
[[
45k, 17k
Kill Collector of Skalfson's Watch.
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Maggut",
					text =
[[
33.5k, 54k
Rally Master of Snouts' Pens.
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Grokk",
					text =
[[
17.5k, 54k
Rally Master of Da War Maker.
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Splinta",
					text =
[[
4k, 28k
Rally Master of Kron Komar.
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Screeb",
					text =
[[
9.6k, 21k 
Screeb's Warcamp
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Wobna Slipsquig",
					text =
[[
40k, 54.5k
Kill Collector of Lobber Hill.
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Sneakfang",
					text =
[[
16k, 52.4k
Kill Collector of Da War Maker.
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Virrik",
					text =
[[
1.7k, 27k
Kill Collector of Kron Komar.
]],
				},
			},
		},

		{
			name = L"Barak Varr",
			entries =
			{
				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Thane Karrasteel",
					text =
[[
31k, 51k
Rally Master - Dwarf Chapter 7
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Farnir Goldpeak",
					text =
[[
22k, 44k
Goldpeak's Warcamp
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Elgaroth Karginson",
					text =
[[
31.5k, 51k
Kill Collector - Dwarf Chapter 7
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Nogaz",
					text =
[[
8.8k, 31k
Rally Master - Greenskins Chapter 5 - Nogaz's Boyz.
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Rottoof",
					text =
[[
32.3k, 59.3k
Rally Master - Greenskins Chapter 7 - Rottoof's Mugz.
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Malgrog",
					text =
[[
56k, 27k
Rally Master - Greenskins Chapter 8 - Port of Barak Varr.
]],
				},

				{	
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Mobash",
					text =
[[
28.3k, 18.5k
Rally Master - Greenskins Chapter 9 - Mobash's Place.
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Faduk Foultooth",
					text =
[[
38k, 43k
Foultooth's Warcamp.
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Runtskull",
					text =
[[
9.1k, 31k
Kill Collector - Greenskins Chapter 5 - Nogaz's Boyz.
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Reezel",
					text =
[[
33.3k, 60.3k
Kill Collector - Greenskins Chapter 7 - Rottoof's Mugz. 
]],
				},

				{	
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Sneaks",
					text =
[[
56.4k, 27k
Kill Collector - Greenskins Chapter 8 - Port of Barak Varr. (43,24.2k)
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Moozle",
					text =
[[
28.7k, 18k
Kill Collector - Greenkins Chapter 9 - Mobash's Place.
]],
				},
			}
		},

		{
			name = L"Marshes of Madness",
			entries =
			{
				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Durrig Olfrinson",
					text =
[[
3.3k, 22.6k
Rally Master - Dwarf Chapter 5
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Murdogh Kadrikson",
					text =
[[
13k, 5.7k
Rally Master - Dwarf Chapter 6
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Barin Oathsmiter",
					text =
[[
55.5k, 14.7k
Rally Master - Chapter 8
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Droki Redbeard",
					text =
[[
56k, 42k
Rally Master - Chapter 9
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Balabin Thurarikson",
					text =
[[
41k, 42.7k
Questgiver - in Thurarikson's Warcamp
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Kurgan Ironfist",
					text =
[[
2.5k, 23.5k
Kill Collector - Chapter 5
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Estelle Meyer",
					text =
[[
11.3k, 5k
Kill Collector - Chapter 6
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Grunlok Steelspade",
					text =
[[
55.4k, 14.3k
Kill Collector - Chapter 8
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Lokki Redbeard",
					text =
[[
55.7k, 42k
Kill Collector - Chapter 9
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Bonerender",
					text =
[[
20.7k, 7.5k
Rally Master - Greenskins Chapter 6-Bonerender's Bash
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Morth",
					text =
[[
26.7k, 26.8k
Morth's Mire Warcamp
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Thudfist",
					text =
[[
20k, 7k
Kill Collector - Greenskins Chapter 6-Bonerender's Bash
]],
				},
			}
		},

		{
			name = L"The Badlands",
			entries =
			{
				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Alethewn Stoutgut",
					text =
[[
10.8k, 39.2k
Rally Master - Dwarf Chapter 10
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Skaf Copperstone",
					text =
[[
13k, 17k
Rally Master - Dwarf Chapter 11
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Dunhilda Grodrikson",
					text =
[[
33k, 12.3k
Rally Master - Dwarf Chapter 13
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Athran Ironbeard",
					text =
[[
48k, 14.6k
Rally Master - Dwarf Chapter 14
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Lungni the Dour",
					text =
[[
16k, 33.2k
Questgiver - Dour Guard Warcamp
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Bragni Tunnelcut",
					text =
[[
10k, 38.2k
Kill Collector - Dwarf Chapter 10
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Doragrum Stouthammer",
					text =
[[
12.4k, 15.7k
Kill Collector - Dwarf Chapter 11
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Hlom Hrnghamson",
					text =
[[
33.3k, 13k
Kill Collector - Dwarf Chapter 13
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Mak Kleintrek",
					text =
[[
47.4k, 16.3k
Kill Collector - Dwarf Chapter 14
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Trug",
					text =
[[
16.5k, 5.6k
Rally Master - Greenskins Chapter 11
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Muggar",
					text =
[[
47k, 46.3k
Muggar's Choppaz Warcamp
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Shaman Greyfrobba",
					text =
[[
16.6k, 5.9k
Kill Collector - Greenskins Chapter 11
]],
				},
			}
		},

		{
			name = L"Black Fire Pass",
			entries =
			{
				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Varmir Proudrock",
					text =
[[
47.5k, 60k
Rally Master - Dwarf Chapter 12
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Gamira Odinadotr",
					text =
[[
35.8k, 21.8k
Questgiver - Odinadotr's Watch Warcamp  
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Thurn Goldbrewer",
					text =
[[
46k, 58.6k
Kill Collector - Dwarf Chapter 12
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Moogz",
					text =
[[
4.5k, 52k
Rally Master - Greenskins Chapter 10 - Moogz's Brawl
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Drok Gunash",
					text =
[[
31.1k, 58.8k
Rally Master - Greenskins Chapter 12 - Drok's Fist
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Gorthug",
					text =
[[
32.2k, 36.4k
Rally Master - Greenskins Chapter 13 - Gorthug's Chew
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Skargor",
					text =
[[
47.3k, 27.2k 
Rally Master - Greenskins Chapter 14 - Da Big Burn
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Torka",
					text =
[[
34.3k, 7k
Torka's Boyz War Camp
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Gremgob",
					text =
[[
3.5k, 53k
Kill Collector - Greenskins Chapter 10 - Moogz' Brawl
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Smashmur",
					text =
[[
31k, 58.5k
Kill Collector - Greenskins Chapter 12 - Drok's Fist
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Grik",
					text =
[[
31.6k, 35.5k
Kill Collector - Greenskins Chapter 13 - Gorthug's Chew
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Tog Nailclub",
					text =
[[
46.8k, 26.5k
Kill Collector - Greenskins Chapter 14 - Da Big Burn
]],
				},
			}
		},

		{
			name = L"Thunder Mountain",
			entries =
			{
				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Zamgrund Lorkison",
					text =
[[
5.2k, 8.2k
Rally Master - Dwarf Chapter 17
]],
				},

				{	
					realm = TTitan.Data.Realm.ORDER,
					name = L"Bari Hlavengr",
					text =
[[
12.8k, 26k
Rally Master - Dwarf Chapter 18
]],
				},

				{	
					realm = TTitan.Data.Realm.ORDER,
					name = L"Dolgr Grinarson",
					text =
[[
55k, 25.2k
Rally Master - Dwarf Chapter 19
]],
				},

				{	
					realm = TTitan.Data.Realm.ORDER,
					name = L"Bodor Greymere",
					text =
[[
36.1k, 10.7k
Greymere Point War Camp
]],
				},

				{	
					realm = TTitan.Data.Realm.ORDER,
					name = L"Leo Heller",
					text =
[[
4.6k, 8.9k
Kill Collector - Dwarf Chapter 17
]],
				},

				{	
					realm = TTitan.Data.Realm.ORDER,
					name = L"Rori Mailcutter",
					text =
[[
11.9k, 27.3k
Kill Collector - Dwarf Chapter 18
]],
				},

				{	
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Slagrot",
					text =
[[
12.3k, 60.3k
Rally Master Chapter 17
]],
				},

				{	
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Brugg One-Eye",
					text =
[[
13.8k, 42k
Rally Master Chapter 18
]],
				},				

				{	
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Fudja Mudnose",
					text =
[[
56.4k, 45.2k
Rally Master Chapter 19
]],
				},

				{	
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Saggrutz Bonechukka",
					text =
[[
37.7k, 59k
Mudja's Warcamp
]],
				},

				{	
					realm = TTitan.Data.Realm.ORDER,
					name = L"Grimor",
					text =
[[
12k, 61k
Kill Collector Chapter 17
]],
				},

				{	
					realm = TTitan.Data.Realm.ORDER,
					name = L"Gorlub",
					text =
[[
10.6k, 39.5k
Kill Collector Chapter 18
]],
				},

				{	
					realm = TTitan.Data.Realm.ORDER,
					name = L"Gurglesmear",
					text =
[[
58.3k, 42.3k
Kill Collector Chapter 19
]],
				},
			}
		},

		{
			name = L"Kadrin Valley",
			entries =
			{
				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Skoragrin Drokison",
					text =
[[
14.4k, 11k
Rally Master - Dwarf Chapter 15
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Furen Brazenbrow",
					text =
[[
17k, 42k
Rally Master - Dwarf Chapter 16
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Grumir Orcslayer",
					text =
[[
27k, 7.1k
Gharvin's Brace Warcamp
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Karon Vigridson",
					text =
[[
11.6k, 14.2k
Kill Collector - Dwarf Chapter 15
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Olfgrond Hammerson",
					text =
[[
15.4k, 43.4k
Kill Collector - Dwarf Chapter 16
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Naguk",
					text =
[[
51.8k, 58.1k
Rally Master - Greenskin Chapter 20
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Gashfang",
					text =
[[
40.5k, 41.5k
Rally Master - Greenskin Chapter 21
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Badrot",
					text =
[[
43k, 33.7k
Rally Master - Greenskin Chapter 22
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Odug Hut-Burna",
					text =
[[
36.5k, 51.4k
Krung's Scrappin' Spot Warcamp
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Ripgut",
					text =
[[
52.5k, 56.8k
Kill Collector - Greenskin Chapter 20
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Dragna",
					text =
[[
40.8k, 39.5k
Kill Collector - Greenskin Chapter 21
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Snogrot",
					text =
[[
40.2k, 32.1k
Kill Collector - Greenskin Chapter 22
]],
				},
			},
		},

		{
			name = L"Black Crag",
			entries =
			{
				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Ellamina Craghelm",
					text =
[[
51.3k, 9.8k
Rally Master - Dwarf Chapter 20
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Gargrim Oathgrund",
					text =
[[
33.9k, 19.1k
Rally Master - Dwarf Chapter 21
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Gav Hallmundr",
					text =
[[
36.8k, 47.7k
Rally Master - Dwarf Chapter 22
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Rogrin Weatheredmane",
					text =
[[
45.6k, 7.2k
Kargrund's Stand Warcamp
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Slayer Bolgun",
					text =
[[
52k, 9k
Kill Collector - Dwarf Chapter 20
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Bogni Goblingrinder",
					text =
[[
33.3k, 19.2k
Kill Collector - Dwarf Chapter 21
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Hanri Raudson",
					text =
[[
36.3k, 46k
Kill Collector - Dwarf Chapter 22
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Grimgork",
					text =
[[
23.3k, 35.7k
Rally Master - Greenskins Chapter 15
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Mugash",
					text =
[[
9.9k, 14.5k
Rally Master - Greenskins Chapter 16
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Shaz da Bleeda",
					text =
[[
20.2k, 61.6k
Gudmud's Strong-huts Warcamp
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Kark",
					text =
[[
20.8k, 35.5k
Kill Collector - Greenskins Chapter 15
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Bloodtoof",
					text =
[[
9.7k, 14.8k
Kill Collector - Greenskins Chapter 16
]],
				},
			}
		},

		{
			name = L"Karaz-a-Karak",
			entries =
			{
				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"High King Thorgrim Grudgebearer",
					text =
[[
28.7k, 22.6k
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Prince Ulther Stonehammer",
					text =
[[
29.5k, 27.4k
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"King Belegar Ironhammer",
					text =
[[
28.4k, 26.6k
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Teclis",
					text =
[[
31.8k, 30k
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Josef Bugman",
					text =
[[
39.7k, 31.4k
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Snorri Nosebite",
					text =
[[
36.6k, 36.6k
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Queen Karga",
					text =
[[
3.2k, 37.7k
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Malakai Makaisson",
					text =
[[
7k, 22.4k
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Kragg The Grim",
					text =
[[
11.7k, 33k
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Burlok Damminsson",
					text =
[[
In the Middle Deeps
38.2k, 31.2k
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Garagrim Ironfist",
					text =
[[
In the Middle Deeps
31.5k, 31.2k
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Gotrek Athranborson",
					text =
[[
In the Middle Deeps
20.7k, 48.9k
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Dawi-Wyr",
					text =
[[
In the Middle Deeps
26.3k, 16.4k
]],
				},
			}
		},

		{
			name = L"Karak Eight Peaks",
			entries =
			{
				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Grumlok & Gazbag",
					text =
[[
???
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Borgut Facebeater",
					text =
[[
???
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Morglum Necksnapper",
					text =
[[
In Da Depps
27.6k, 23.3k
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Wurrzag Ud Ura Zahubu",
					text =
[[
???
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Kazgi",
					text =
[[
In Da Deeps
23k, 36.8k
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Grottnik",
					text =
[[
23.3k, 40k
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Gitilla da Hunter",
					text =
[[
???
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Urk da Stuntystomper",
					text =
[[
???
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Asperon Khitain",
					text =
[[
26.2k, 24.2k
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Aekold Helbrass",
					text =
[[
26.2k, 29.7k
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Skargaz Gutrippa",
					text =
[[
23.8k, 27k
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Vargit Slimefoot",
					text =
[[
In Da Deeps
15.1k, 47.9k
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Gitslit Spleenspit",
					text =
[[
In Da Deeps
37.6k, 43.4k
]],
				},
			}
		},
	},
}
