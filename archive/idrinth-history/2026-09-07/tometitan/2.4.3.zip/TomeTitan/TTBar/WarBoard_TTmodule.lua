WarBoard_TTitan = {}

function WarBoard_TTitan.Initialize()
	if (WarBoard.AddMod("WarBoard_TTitan")) then
		LabelSetTextColor("WarBoard_TTitanButton", 255, 55, 55)
		LabelSetText("WarBoard_TTitanButton", L"TT")
		-- Hide the TomeTitan button by default
		WindowSetShowing("TTitanTTButtonWindow", false)
		TTitan.ShowButton = false
	end
end

function WarBoard_TTitan.OnLButtonDown()
	TTitan.UI.ToggleShowing()
end

function WarBoard_TTitan.OnRButtonDown()
	TTitan.UI.ExpandCurrentZone()
	TTitan.UI.Show()
end

function WarBoard_TTitan.OnMButtonDown()
	TTitan.UI.ToggleButton()
end

function WarBoard_TTitan.OnMouseOver()
    Tooltips.CreateTextOnlyTooltip( SystemData.ActiveWindow.name, nil )
    Tooltips.AnchorTooltip( Tooltips.ANCHOR_WINDOW_BOTTOM )
	Tooltips.SetTooltipColor( 1, 1, 255, 0, 0 )
    Tooltips.SetTooltipText( 1, 1, L"Tome Titan WarBoard Module" )
	Tooltips.SetTooltipText( 2, 1, L"Left click to toggle Tome Titan" )
	Tooltips.SetTooltipText( 3, 1, L"Right click to open to current zone" )
	Tooltips.SetTooltipText( 4, 1, L"Middle click to toggle TT button" )
	Tooltips.Finalize()
end

