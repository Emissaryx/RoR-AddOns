---------------------------------------------------------------------------------------------------------------------
-- Tome Titan plugin by Oscarr  <oscarr_d24@yahoo.com> for SNT_BAR
-- SNT_BAR can be found at http://war.curse.com/downloads/war-addons/details/snt-bar.aspx
---------------------------------------------------------------------------------------------------------------------

snt_bar.titan_module = {}

--------------- Mouse over Tooltip ---------------------------------------------------------------------------------

function snt_bar.titan_module.tt_tooltip()
    Tooltips.CreateTextOnlyTooltip( i_titan.wname, nil)
    Tooltips.AnchorTooltip( Tooltips.ANCHOR_WINDOW_BOTTOM )
	Tooltips.SetTooltipColor( 1, 1, 255, 0, 0 )
    Tooltips.SetTooltipText( 1, 1, L"Tome Titan SNT Bar Module" )
	Tooltips.SetTooltipText( 2, 1, L"Left click to toggle Tome Titan" )
	Tooltips.SetTooltipText( 3, 1, L"Right click to open to current zone" )
	Tooltips.SetTooltipText( 4, 1, L"Middle click to toggle TT button" )
	Tooltips.Finalize()

	if WindowGetShowing("TTitanUI") == true then
		i_titan:set_icon(108)
	else
		i_titan:set_icon(100)
	end
end

----------------- Left and Right click functions -----------------------------------------------------------------

function snt_bar.titan_module.tt_Lclick()
	TTitan.UI.ToggleShowing()
	if WindowGetShowing("TTitanUI") == true then
		i_titan:set_icon(108)
	else
		i_titan:set_icon(100)
	end
end

function snt_bar.titan_module.tt_Rclick()
	TTitan.UI.ExpandCurrentZone()
	TTitan.UI.Show()
	if WindowGetShowing("TTitanUI") == true then
		i_titan:set_icon(108)
	else
		i_titan:set_icon(100)
	end
end

function snt_bar.titan_module.tt_Mclick()
	TTitan.UI.ToggleButton()

	if WindowGetShowing("TTitanUI") == true then
		i_titan:set_icon(108)
	else
		i_titan:set_icon(100)
	end
end

---------------  Initialize ------------------------------------------------------------------------------------------

function snt_bar.titan_module.initialize()
	EA_ChatWindow.Print(L"SNT Bar Tome Titan Module Loaded.")

	i_titan = snt_bar.informer:new("i_titan",nil,75,{255,55,55},100,
									"snt_bar.titan_module.tt_tooltip", -- the mouseover function
									"snt_bar.titan_module.tt_Lclick","snt_bar.titan_module.tt_Rclick") -- left and right mouse click function
	i_titan:set_label("TT")
	WindowRegisterCoreEventHandler("i_titan","OnMButtonDown","snt_bar.titan_module.tt_Mclick") -- register a middle mouse click (not built into SNT_BAR)
end
