<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
	<UiMod name="SNT_BAR_TTmodule" version="1.0" date="11/17/2008">
		<Author name="Oscarr" email="oscarr_d24@yahoo.com" />
		<Description text="Tome Titan module for SNT_BAR" />
		<VersionSettings gameVersion="1.4.8" windowsVersion="2.0" savedVariablesVersion="2.0" />

		<Dependencies>
			<Dependency name="SNT_BAR" />
			<Dependency name="Tome Titan" />
		</Dependencies>

		<Files>
			<File name="SNT_BAR_TTmodule.lua" />
		</Files>

		<OnInitialize>
			<CallFunction name="snt_bar.titan_module.initialize" />
		</OnInitialize>
	</UiMod>
</ModuleFile>
