TTitan.Data.Kills = {}

function TTitan.Data.Kills.GetData()
	return TTitan.Data.Kills.RawData
end

function TTitan.Data.Kills.FilterData()
end

TTitan.Data.Kills.RawData =
{
	header = L"Bestiary Kill Achievements",
	categories =
	{
  	{
			name = L"Beasts",
			entries =
			{
				{
					name = L"Basilisk",
					text =
[[
Location: 

Rewards:
1,000: Bestial Token
10,000: Title: The Unyielding
100,000: Title: Deathgazer
]]
				},

				{
					name = L"Bat, Giant",
					text =
[[
Location: 

Rewards:
1,000: Bestial Token
10,000: Title: Nightwing
100,000: Title: Bat Mangler
]]
				},

				{
					name = L"Bear",
					text =
[[
Location: 

Rewards:
1,000: Bestial Token
10,000: Title: The Grizzled
100,000: Title: Ursine Champion
]]
				},

				{
					name = L"Boar",
					text =
[[
Location: 

Rewards:
1,000: Bestial Token
10,000: Title: Scout
100,000: Title: Predator
]]
				},

				{
					name = L"Great Cat",
					text =
[[
Location: 

Rewards:
1,000: Bestial Token
10,000: Title: The Stealthy
100,000: Title: The Ferocious
]]
				},

				{
					name = L"Hound",
					text =
[[
Location: 

Rewards:
1,000: Bestial Token
10,000: Title: Foe of the Warhound
100,000: Title: The Packleader
]]
				},

				{
					name = L"Rhinox",
					text =
[[
Location: 

Rewards:
1,000: Bestial Tactic Fragment
10,000: Title: Master Rhinox Slayer
]]
				},

				{
					name = L"Wolf",
					text =
[[
Location: 

Rewards:
1,000: Bestial Token
10,000: Title: The Wolf Tracker
100,000: Title: Wolf's Bane
]]
				},
			},
		},

  	{
			name = L"Birds",
			entries =
			{
				{
					name = L"Great Eagle",
					text =
[[
Location: 

Rewards:
1,000: Bestial Tactic Fragment
10,000: Title: Master Great Eagle Slayer
]]
				},
				
				{
					name = L"Vulture",
					text =
[[
Location: 

Rewards:
1,000: Bestial Token
10,000: Title: The Scavenger
100,000: Title: The Vulture
]]
				},
				
				{
					name = L"Warhawk",
					text =
[[
Location: 

Rewards:
1,000: Bestial Token
10,000: Title: The Talon
100,000: Title: The Wing Clipper
]]
				},

			},
		},
		
		{
			name = L"Creatures",
			entries =
			{
				{
					name = L"Great Stag",
					text =
[[
Location: 

Rewards:
1,000: Bestial Tactic Fragment
10,000: Title: The Deer Hunter
100,000: Title: Master Deer Hunter
]],
				},
			},
		},
		
    {
			name = L"Insects & Arachnids",
			entries =
			{
				{
					name = L"Giant Scarab",
					text =
[[
Location: 

Rewards:
1,000: Undead Tactic Fragment
10,000: Title: The Verminator
]],
				},

				{
					name = L"Scorpian, Giant",
					text =
[[
Location: 

Rewards:
1,000: Bestial Token
10,000: Title: Scorpian Smasher
100,000: Title: The Perforater
]],
				},
				
				{
					name = L"Spider, Giant",
					text =
[[
Location: 

Rewards:
1,000: Bestial Token
10,000: Title: Scourge of the Arachnids
100,000: Title: The Websmiter
]],
				},
				
				{
					name = L"Tomb Swarm",
					text =
[[
Location: 

Rewards:
1,000: Undead Tactic Fragment
10,000: Title: Bug Stomper
]],
				},				
			},
		},
		
  	{
			name = L"Reptiles",
			entries =
			{
				{
					name = L"Cold One",
					text =
[[
Location: 

Rewards:
1,000: Bestial Tactic Fragment
10,000: Title: Master Cold One Slayer
]],
				},

				{
					name = L"Lizard, Giant",
					text =
[[
Location: 

Rewards:
1,000: Bestial Token
10,000: Title: The Reptile Wrangler
100,000: Title: Cold-Blooded
]],
				},				
			},
		},
		
  	{
			name = L"Daemons of Khorne",
			entries =
			{
				{
					name = L"Bloodbeast of Khorne",
					text =
[[
Location: 

Rewards:
1,000: Daemonic Tactic Fragment
10,000: Title: Master Bloodbeast Slayer
]]
				},

				{
					name = L"Bloodletter of Khorne",
					text =
[[
Location: 

Rewards:
1,000: Daemonic Tactic Fragment
10,000: Title: Master Bloodletter Slayer
]]
				},

				{
					name = L"Bloodthirster of Khorne",
					text =
[[
Location: 

Rewards:
1,000: Daemonic Tactic Fragment
10,000: Title: Master Bloodthirster Slayer
]]
				},

				{
					name = L"Flesh Hound of Khorne",
					text =
[[
Location: 

Rewards:
1,000: Daemonic Tactic Fragment
10,000: Title: Master Flesh Hound Slayer
]]
				},

				{
					name = L"Ragebeast",
					text =
[[
Location: 

Rewards:
1,000: Daemonic Tactic Fragment
10,000: Title: Master Juggernaut Slayer
]]
				},
			},
		},

  	{
			name = L"Daemons of Nurgle",
			entries =
			{
				{
					name = L"Great Unclean One",
					text =
[[
Location: 

Rewards:
1,000: Daemonic Tactic Fragment
10,000: Title: Master Great Unclean One Slayer
]]
				},
				
				{
					name = L"Nurgling",
					text =
[[
Location: 

Rewards:
1,000: Bestial Token
10,000: Title: Plaguepests' Foe 
100,000: Title: Vileswarm Nemesis
]]
				},
				
				{
					name = L"Plaguebearer",
					text =
[[
Location: 

Rewards:
1,000: Bestial Token
10,000: Title: Blightseeker
100,000: Title:The Illwind Champion
]]
				},

				{
					name = L"Plaguebeast of Nurgle",
					text =
[[
Location: 

Rewards:
1,000: Daemonic Tactic Fragment
10,000: Title: Master Plaguebeast Slayer
]]
				},
				
				{
					name = L"Slimehound",
					text =
[[
Location: 

Rewards:
1,000: Daemonic Tactic Fragment
10,000: Title: Master Slimehound Slayer
]]
				},
			},
		},
		
		{
			name = L"Daemons of Slaanesh",
			entries =
			{
				{
					name = L"Daemonette of Slaanesh",
					text =
[[
Location: 

Rewards:
1,000: Daemonic Tactic Fragment
10,000: Title: Master Daemonette Slayer
]]
				},
				
				{
					name = L"Fiend of Slaanesh",
					text =
[[
Location: 

Rewards:
1,000: Pocket: Friendship Bracelet
10,000: Title: Master Fiend Slayer
]]
				},

				{
					name = L"Keeper of Secrets",
					text =
[[
Location: 

Rewards:
1,000: Daemonic Tactic Fragment
10,000: Title: Master Keeper of Secrets Slayer
]]
				},
				
				{
					name = L"Pleasurebeast",
					text =
[[
Location: The Lost Vale

Rewards:
No kill unlocks for this monster type
]]
				},
			},
		},
		
    {
			name = L"Daemons of Tzeentch",
			entries =
			{
				{
					name = L"Firewyrm of Tzeentch",
					text =
[[
Location: 

Rewards:
1,000: Daemonic Tactic Fragment
10,000: Title: Master Firewyrm Slayer
]]
				},
				
				{
					name = L"Flamer of Tzeentch",
					text =
[[
Location: 

Rewards:
1,000: Daemonic Tactic Fragment
10,000: Title: Master Flamer Slayer
]]
				},

				{
					name = L"Horror of Tzeentch",
					text =
[[
Location: 

Rewards:
1,000: Bestial Token
10,000: Title: Aethyr Custodian
100,000: Title: Aethyr Reaver

]]
				},
				
				{
					name = L"Lord of Change",
					text =
[[
Location: 

Rewards:
1,000: Daemonic Tactic Fragment
10,000: Title: Master Lord of Change Slayer
]]
				},
				
				{
					name = L"Screamer of Tzeentch",
					text =
[[
Location: 

Rewards:
1,000: Daemonic Tactic Fragment
10,000: Title: Master Screamer Slayer
]]
				},
				
				{
					name = L"Watcher",
					text =
[[
Location: 

Rewards:
1,000: Daemonic Tactic Fragment
10,000: Title: Master Watcher Slayer
]]
				},				
			},
		},
		
  	{
			name = L"Unmarked Daemons",
			entries =
			{
				{
					name = L"Chaos Fury",
					text =
[[
Location: 

Rewards:
1,000: Daemonic Tactic Fragment
10,000: Title: Master Chaos Fury Slayer
]]
				},

				{
					name = L"Chaos Hound",
					text =
[[
Location: 

Rewards:
1,000: Bestial Tactic Fragment
10,000: Title: Master Chaos Hound Slayer
]]
				},

				{
					name = L"Chaos Spawn",
					text =
[[
Location: 

Rewards:
1,000: Daemonic Tactic Fragment
10,000: Title: Master Chaos Spawn Slayer
]]
				},

				{
					name = L"Chaos Spawn, Daemonvine",
					text =
[[
Location: 

Rewards:
1,000: Daemonic Tactic Fragment
10,000: Title: Daemonvine Despoiler
]]
				},

				{
					name = L"Daemon Prince",
					text =
[[
Location: 

Rewards:
1,000: Pocket: Daemon Horn 
10,000: Title: Master Daemon Prince Slayer
]]
				},

				{
					name = L"Walker",
					text =
[[
Location: 

Rewards:
1,000: Undead tactic Fragment
10,000: Title: Master Slayer of Walkers
]]
				},
			},
		},		

  	{
			name = L"Beastmen",
			entries =
			{
				{
					name = L"Bestigor",
					text =
[[
Location: 

Rewards:
1,000: Bestial Token
10,000: Title: The Bestial
100,000: Title: Herd Breaker
]]
				},

				{
					name = L"Bray Shaman",
					text =
[[
Location: 

Rewards:
1,000: Chaos Tactic Fragment
10,000: Title: Master Bray Shaman Slayer
]]
				},

				{
					name = L"Gor",
					text =
[[
Location: 

Rewards:
1,000: Bestial Token
10,000: Title: Herd Stalker
100,000: Title: Champion of the Wild
]]
				},

				{
					name = L"Ungor",
					text =
[[
Location: 

Rewards:
1,000: Bestial Token
10,000: Title: The Raging
100,000: Title: The Feral
]]
				},

				{
					name = L"Doombull",
					text =
[[
Location: 

Rewards:
1,000: Chaos Tactic Fragment
10,000: Title: Master Doombull Slayer
]]
				},
			},
		},

  	{
			name = L"Dwarfs",
			entries =
			{
				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Dwarf",
					text =
[[
Location: 

Rewards:
1,000: Trophy: Dwarven Destroyer, One Pip
10,000: Trophy: Dwarven Destroyer, Two Pips
100,000: Trophy: Dwarven Destroyer, Three Pips
1,000,000: Trophy: Golden Dwarven Destroyer, Three Pips
]]
				},
				
				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Engineer",
					text =
[[
Location: 

Rewards:
1,000: Title: The Detonator
10,000: Title: The Demolisher
100,000: Trophy: Golden Dwarven Destroyer, Two Pips
]]
				},
				
				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Ironbreaker",
					text =
[[
Location: 

Rewards:
1,000: Title: The Deep Lurker
10,000: Title: Depth Haunter
100,000: Trophy: Golden Dwarven Destroyer, Two Pips
]]
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Runepriest",
					text =
[[
Location: 

Rewards:
1,000: Title: Rune Breaker
10,000: Title: Grungni's Bane
100,000: Trophy: Golden Dwarven Destroyer, Two Pips
]]
				},
				
				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Slayer",
					text =
[[
Location: 

Rewards:
1,000: Title: An Axe to Grind
10,000: Title: Oath Breaker
100,000: Trophy: Golden Dwarven Destroyer, Two Pips
]]
				},
				
				{
					name = L"Dwarven, Slayer",
					text =
[[
Location: 

Rewards:
1,000: Bestial Token
10,000: Title: Vow Breaker
100,000: Title: Dwarf Slayer
]]
				},
			},
		},
		
		{
			name = L"Elves",
			entries =
			{
				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Dark Elf",
					text =
[[
Location: 

Rewards:
1,000: Trophy: Dark Elf Destroyer, One Pip
10,000: Trophy: Dark Elf Destroyer, Two Pips
100,000: Trophy: Dark Elf Destroyer, Three Pips
1,000,000: Not Implemented Yet
]]
				},
				
				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Blackguard",
					text =
[[
Location: 

Rewards:
1,000: Title: Halberd Splitter
10,000: Title: Witch King's Woe
100,000: Trophy: Golden Dark Elf Destroyer, Two Pips
]]
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Disciple of Khaine",
					text =
[[
Location: 

Rewards:
1,000: Title: The Stalwart
10,000: Title: The Steadfast
100,000: Trophy: Golden Dark Elf Destroyer, Two Pips
]]
				},
				
				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Sorceror",
					text =
[[
Location: 

Rewards:
1,000: Title: Spellbinder
10,000: Title: Spellbreaker
100,000: Trophy: Golden Dark Elf Destroyer, Two Pips
]]
				},
				
				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Witch Elves",
					text =
[[
Location: 

Rewards:
1,000: Title: The Deft
10,000: Title: The Lethal
100,000: Trophy: Golden Dark Elf Destroyer, Two Pips
]]
				},
				
				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"High Elf",
					text =
[[
Location: 

Rewards:
1,000: Trophy: High Elf Eliminator, One Pip
10,000: Trophy: High Elf Eliminator, Two Pips
100,000: Trophy: High Elf Eliminator, Three Pips
1,000,000: Not Implemented Yet
]]
				},
				
				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Archmage",
					text =
[[
Location: 

Rewards:
1,000: Title: Theurge Breaker
10,000: Title: The Spelleater
100,000: Trophy: Golden High Elf Eliminator, Two Pips
]]
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Shadow Warrior",
					text =
[[
Location: 

Rewards:
1,000: Title: The Infiltrator
10,000: Title: Favored of Malekith
100,000: Trophy: Golden High Elf Eliminator, Two Pips
]]
				},
				
				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Swordmaster",
					text =
[[
Location: 

Rewards:
1,000: Title: Dirge Blade
10,000: Title: Edge Lord
100,000: Trophy: Golden High Elf Eliminator, Two Pips
]]
				},
				
				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"White Lion",
					text =
[[
Location: 

Rewards:
1,000: Title: The Poacher
10,000: Title: Pride Taker
100,000: Trophy: Golden High Elf Eliminator, Two Pips
]]
				},				
			},
		},
		
    {
			name = L"Greenskins",
			entries =
			{
				{
					name = L"Gnoblar",
					text =
[[
Location: 

Rewards:
1,000: Bestial Token
10,000: Title: The Mighty
100,000: Title: The Invincible
]]
				},
				
				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Goblin",
					text =
[[
Location: 

Rewards:
1,000: Trophy: Greenskin Grappler, One Pip
10,000: Trophy: Greenskin Grappler, Two Pips
100,000: Trophy: Greenskin Grappler, Three Pips
1,000,000: Not Implemented Yet
]]
				},

				{
					name = L"Night Goblin",
					text =
[[
Location: 

Rewards:
1,000: Man Tactic Fragment
10,000: Title: Master Night Goblin Slayer
]]
				},
				
				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Shaman",
					text =
[[
Location: 

Rewards:
1,000: Title: The Staff-Breaker
10,000: Title: Mork's Ruin
100,000: Trophy: Golden Greenskin Grappler, Two Pips
]]
				},
				
				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Squig Herder",
					text =
[[
Location: 

Rewards:
1,000: Title: The Bond Breaker
10,000: Title: The Inedible
100,000: Trophy: Golden Greenskin Grappler, Two Pips
]]
				},
				
				{
					name = L"Orc",
					text =
[[
Location:

Rewards:
1,000: Trophy: Greenskin Grappler, One Pip
10,000: Trophy: Greenskin Grappler, Two Pips
100,000: Trophy: Greenskin Grappler, Three Pips
1,000,000: Not Implemented Yet
]]
				},
				
				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Black Orc",
					text =
[[
Location: 

Rewards:
1,000: Title: Dead 'Ard
10,000: Title: The Unstoppable
100,000: Trophy: Golden Greenskin Grappler, Two Pips
]]
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Choppa",
					text =
[[
Location: 

Rewards:
1,000: Title: Chop Suey
10,000: Title: I Stopped the Chop
100,000: Trophy: Golden Greenskin Grappler, Two Pips
]]
				},
				
				{
					name = L"Savage Orc",
					text =
[[
Location: 

Rewards:
1,000: Greenskin Tactic Fragment
10,000: Title: Master Savage Orc Slayer
]]
				},
				
				{
					name = L"Snotling",
					text =
[[
Location: 

Rewards:
1,000: Bestial Token
10,000: Title: The Weird
100,000: Title: Killer of a Thousand Snotlings
]]
				},
				
				{
					name = L"Squig",
					text =
[[
Location: 

Rewards:
1,000: Title: The Squig Squisher
10,000: Bestial Tactic Fragment
100,000: Back Item: Fang Hopper's Hide
]]
				},				
			},
		},
		
  	{
			name = L"Humans",
			entries =
			{
				{
					name = L"Bandit",
					text =
[[
Location: 

Rewards:
1,000: Bestial Token
10,000: Title: The Man Hunter
100,000: Title: The Law
]]
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Chaos",
					text =
[[
Location: 

Rewards:
1,000: Trophy: Chaos Cleanser, One Pip
10,000: Trophy: Chaos Cleanser, Two Pips
100,000: Trophy: Chaos Cleanser, Three Pips
1,000,000: Not Implemented Yet
]]
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Chosen",
					text =
[[
Location: 

Rewards:
1,000: Title: The Decider
10,000: Title: The Arbitrator
100,000: Trophy: Golden Chaos Cleanser, Two Pips
]]
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Magus",
					text =
[[
Location: 

Rewards:
1,000: Title: The Toppler
10,000: Title: The Overthrower
100,000: Trophy: Golden Chaos Cleanser, Two Pips
]]
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Marauder",
					text =
[[
Location: 

Rewards:
1,000: Title: The Limb Taker
10,000: Title: The Amputator
100,000: Trophy: Golden Chaos Cleanser, Two Pips
]]
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Zealot",
					text =
[[
Location: 

Rewards:
1,000: Title: The Blessed
10,000: Title: The Exhalted
100,000: Trophy: Golden Chaos Cleanser, Two Pips
]]
				},

				{
					name = L"Drakk Cultist",
					text =
[[
Location: 

Rewards:
1,000: Bestial Token
10,000: Title: Persecutor
100,000: Title: Drakk Demolisher
]]
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Empire",
					text =
[[
Location: 

Rewards:
1,000: Trophy: Empire Eradicator, One Pip
10,000: Trophy: Empire Eradicator, Two Pips
100,000: Trophy: Empire Eradicator, Three Pips
1,000,000: Not Implemented Yet
]]
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Bright Wizard",
					text =
[[
Location: 

Rewards:
1,000: Title: The Wild
10,000: Title: The Feral
100,000: Trophy: Golden Empire Eradicator, Two Pips
]]
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Knight of the Blazing Sun",
					text =
[[
Location: 

Rewards:
1,000: Title: Tank Buster
10,000: Title: Myrmidia's Bane
100,000: Trophy: Golden Empire Eradicator, Two Pips
]]
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Warrior Priest",
					text =
[[
Location: 

Rewards:
1,000: Title: The Ruthless
10,000: Title: The Merciless
100,000: Trophy: Golden Empire Eradicator, Two Pips
]]
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Witch Hunter",
					text =
[[
Location: 

Rewards:
1,000: Title: The Cursed
10,000: Title: The Damned
100,000: Trophy: Golden Empire Eradicator, Two Pips
]]
				},

				{
					name = L"Ghoul",
					text =
[[
Location: 

Rewards:
1,000: Bestial Token
10,000: Title: Flesheater's Nemesis
100,000: XP
]]
				},

				{
					name = L"Plague Victim",
					text =
[[
Location: 

Rewards:
1,000: Bestial Token
10,000: Title: The Humane
100,000: Title: The Compassionate
]]
				},
			},
		},
		
  	{
			name = L"Ogres",
			entries =
			{
				{
					name = L"Gorger",
					text =
[[
Location: 

Rewards:
1,000: Giant Tactic Fragment
10,000: Title: Master Gorger Slayer
]]
				},

				{
					name = L"Ogre, Bull",
					text =
[[
Location: 

Rewards:
1,000: Bestial Token
10,000: Title: The Big
100,000: Title: The Pulverizer
]]
				},

				{
					name = L"Ogre, Butcher",
					text =
[[
Location: Lost Vale

Rewards:
100:XP
]]
				},

				{
					name = L"Ogre, Tyran",
					text =
[[
Location: 

Rewards:
1,000: Giant Tactic Fragment
10,000: Title: Master Ogre Tyrant Slayer
]]
				},

				{
					name = L"Yhetee",
					text =
[[
Location: 

Rewards:
1,000: Giant Tactic Fragment
10,000: Title: Master Yhetee Slayer
]]
				},
			},
		},

  	{
			name = L"Skaven",
			entries =
			{
				{
					name = L"Rat Ogre",
					text =
[[
Location: 

Rewards:
1,000: Skaven Tactic Fragment
10,000: Title: Master Rat Ogre Slayer
]]
				},
				
				{
					name = L"Skaven",
					text =
[[
Location: 

Rewards:
1,000: Bestial Token
10,000: Title: Tunnel Stalker
100,000: Title: Skavenbane
]]
				},
			},
		},
		
		{
			name = L"Bastion Stair",
			entries =
			{
				{
					name = L"Kaarn the Vanquisher",
					text =
[[
Rewards:
5: Companion Coin
10: Bestial Token
25: Title: The Vanquisher's Vanquisher
50:
75: Title: Mmm, Kaarn Flakes
100: 
]]
				},
				
				{
					name = L"Lord Slaurith",
					text =
[[
Rewards:
5: Companion Coin
10: Bestial Token
25: Title: The Warrior
50:
75: Title: Me! Pick me!
100: 
]]
				},

				{
					name = L"Skull Lord Var'lthrok",
					text =
[[
Rewards:
5: Companion Coin
10: Bestial Token
25: Title: Skull Lord Scrambler
50:
75: Title: Var'Ithrok Hates Me
100: 
]]
				},
				
				{
					name = L"Thar'lgnan",
					text =
[[
Rewards:
5: Companion Coin
10: Bestial Token
25: Title: Doombull's Doom
50:
75: Title: Takes 'Em By the Horns
100: 
]]
				},
			},
		},
		
    {
			name = L"Mount Gunbad",
			entries =
			{
				{
					name = L"'Ard ta Feed'",
					text =
[[
Rewards:
5: Companion Coin
10: Bestial Token
25: Title: Hunger Striker
50: Trophy: Bit o' Ard Ta Feed
75: Title: Don't Eat Me!
100: 
]]
				},
				
				{
					name = L"Glomp da Squig Masta",
					text =
[[
Rewards:
5: Companion Coin
10: Bestial Token
25: Title: Squig Stomper
50: Trophy: Glomp's Lucky Shrooms
75: Title: Squig Lover
100: 
]]
				},

				{
					name = L"Masta Mixa",
					text =
[[
Rewards:
5: Companion Coin
10: Bestial Token
25: Title: Brew Enthusiast
50: Trophy: Masta Mixa's Vial
75: Title: The Hammered
100:
]]
				},
				
				{
					name = L"Wight Lord Solithex",
					text =
[[
Rewards:
5: Companion Coin
10: Bestial Token
25: Title: Skeleton Slicer
50: Trophy: Mourkain Relic
75: Title: Menace of Mourkain
100:
]]
				},
			},
		},
		
  	{
			name = L"Lost Vale",
			entries =
			{
				{
					name = L"Dralel, the Whitefire Matron",
					text =
[[
Rewards:
Encounter: Companion Coin
5: Bestial Token
10: Title: Whitefire Exterminator
25: Trophy: Whitefire Shard
50: Title: Master of Ghur
75: 
100:Cloak: Dralel, Title: The Webmaster
]]
				},

				{
					name = L"N'Kari, the Soul-Flayer",
					text =
[[
Rewards:
Encounter: Companion Coin
5: Bestial Token
10: Title: Lustfully Yours
25: Trophy: N'Kari's Necklace
50: Title: Hated by Slaanesh
75: 
100: Cloak: N'Kari, Title: Likes it Rough
]]
				},

				{
					name = L"Sarthain the Worldbearer",
					text =
[[
Rewards:
Encounter: Companion Coin
5: Bestial Token
10: Title: The Root Severer
25: Trophy: Sarthain's Bark
50: Title: Master of Ghyran
75: 
100: Cloak: Sarthain, Title: The Worldbearer
]]
				},

				{
					name = L"Sechar, the Darkpromise Chieftain",
					text =
[[
Rewards:
Encounter: Companion Coin
5: Bestial Token
10: Title: Breaker of Promises
25: Trophy: Sechar's Painlink
50: Title: Enjoys Suffering
75: 
100: Cloak: Sechar, Title: One Who Knows Pain
]]
				},
			},
		},		

		{
			name = L"Chaos Breeds",
			entries =
			{
				{
					name = L"Centigor",
					text =
[[
Location: 

Rewards:
1,000: Pocket: Ale Barrel Lid Shield
10,000: Title: Master Centigor Slayer
]]
				},

				{
					name = L"Chaos Mutant",
					text =
[[
Location: 

Rewards:
1,000: Chaos Tactic Fragment
10,000: Title: Master Chaos Mutant Slayer
]]
				},

				{
					name = L"Dark Pegasus",
					text =
[[
Location: Lost Vale

Rewards:
No additional rewards at this time
]]
				},

				{
					name = L"Dragon Ogre",
					text =
[[
Location: 

Rewards:
1,000: Chaos Tactic Fragment
10,000: Title: Master Dragon Ogre Slayer
]]
				},

				{
					name = L"Flayerkin",
					text =
[[
Location: 

Rewards:
1,000: Chaos Tactic Fragment
10,000: Title: Master Flayerkin Slayer
]]
				},

				{
					name = L"Giant Leech",
					text =
[[
Location: Lost Vale

Rewards:
No additional rewards at this time
]]
				},

				{
					name = L"Harpy",
					text =
[[
Location: 

Rewards:
1,000: Bestial Token
10,000: Title: Deathtalon Foe
100,000: Title: Clawtaker
]]
				},

				{
					name = L"Maggot",
					text =
[[
Location: 

Rewards:
1,000: Chaos Tactic Fragment
10,000: Title: Master of Maggots
]]
				},

				{
					name = L"Tuskgor",
					text =
[[
Location: 

Rewards:
1,000: Pocket: Tuskgor Saddle
10,000: Title: The Wildtusk Foe
100,000: Title: Tuskbreaker
]]
				},
			},
		},
		
    {
			name = L"Dragonoids",
			entries =
			{
				{
					name = L"Dragon",
					text =
[[
Location: 

Rewards:
1,000: Back Item: Mantle of the Fireborn
10,000: Title: Master Dragon Slayer
]]
				},

				{
					name = L"Hydra",
					text =
[[
Location: 

Rewards:
1,000: Mythical Tactic Fragment
10,000: Title: Master Hydra Slayer
]]
				},

				{
					name = L"Wyvern",
					text =
[[
Location: 

Rewards:
1,000: Mythical Tactic Fragment
10,000: Title: Master Wyvern Slayer
]]
				},
			},
		},

  	{
			name = L"Giants",
			entries =
			{
				{
					name = L"Giant",
					text =
[[
Location: 

Rewards:
1,000: Giants	Bestial Token
10,000: Title: The Giant Slayer
100,000: Title: Bane of the Sky Titans
]]
				},

				{
					name = L"Giant, Chaos",
					text =
[[
Location: 

Rewards:
1,000: Giant Tactic Fragment
10,000: Title: Master Chaos Giant Slayer
]]
				},
			},
		},
		
  	{
			name = L"Magical Beasts",
			entries =
			{
				{
					name = L"Cockatrice",
					text =
[[
Location: 

Rewards:
1,000: Mythical Tactic Fragment
10,000: Title: Master Cockatrice Slayer
]]
				},

				{
					name = L"Griffon",
					text =
[[
Location: 

Rewards:
1,000: Giant Tactic Fragment
10,000: Title: Master Griffon Slayer
]]
				},

				{
					name = L"Imp",
					text =
[[
Location: 

Rewards:
1,000: Mythical Tactic Fragment
10,000: Title: Master Imp Slayer
]]
				},

				{
					name = L"Manticore",
					text =
[[
Location: 

Rewards:
1,000: Mythical Tactic Fragment
10,000: Title: Master Manticore Slayer
]]
				},

				{
					name = L"Pegasus",
					text =
[[
Location: 

Rewards:
1,000: Back Item: Cloak of the Pegasus
10,000: Title: Master Pegasus Slayer
]]
				},

				{
					name = L"Unicorn",
					text =
[[
Location: 

Rewards:
1,000: Mythical Tactic Fragment
10,000: Title: Master Unicorn Slayer
]]
				},
			},
		},	
		
  	{
			name = L"Trolls",
			entries =
			{
				{
					name = L"Troll",
					text =
[[
Location: 

Rewards:
1,000: Bestial Token
10,000: Title: Scourge of Trollkind
100,000: Title: The Fleshburner
]]
				},

				{
					name = L"Troll, Chaos",
					text =
[[
Location: 

Rewards:
1,000: Giant Tactic Fragment
10,000: Title: Master Chaos Troll Slayer
]]
				},

				{
					name = L"Troll, River",
					text =
[[
Location: 

Rewards:
1,000: Bestial Token
10,000: Title: The Stench Stealer
100,000: Title: The Reeker
]]
				},

				{
					name = L"Troll, Stone",
					text =
[[
Location: 

Rewards:
1,000: Bestial Token
10,000: Title: The Rubble Wrecker
100,000: Title: The Stonecarver
]]
				},
			},
		},		

  	{
			name = L"Forest Spirits",
			entries =
			{
				{
					name = L"Spite",
					text =
[[
Location: 

Rewards:
1,000: Bestial Token
10,000: Title: Wood Spirit's Scourge
100,000: Title: The Burnwood Champion
]]
				},

				{
					name = L"The Spirit of Kurnous",
					text =
[[
Location: Hunter's Vale

Rewards:
5: Title: Blessed of Kurnous
10: Title: Wild Wanderer
25: Title: Forested Fiend
50: 
75: 
100: 
]]
				},
			},
		},
		
  	{
			name = L"Plant Spirits",
			entries =
			{
				{
					name = L"Dryad",
					text =
[[
Location: 

Rewards:
1,000: Bestial Token
10,000: Title: Despoiler
100,000: Title: Nymph Seeker
]]
				},

				{
					name = L"Tree Kin",
					text =
[[
Location: 

Rewards:
1,000: Mythical Tactic Fragment
10,000: Title: Master Treekin Slayer
]]
				},

				{
					name = L"Treemen",
					text =
[[
Location: 

Rewards:
1,000: Mythical Tactic Fragment
10,000: Title: The Worldbreaker
]]
				},
			},
		},
		
  	{
			name = L"Constructs",
			entries =
			{
				{
					name = L"Asp Bone Construct",
					text =
[[
Location: 

Rewards:
1,000: Undead Tactic Fragment
10,000: Title: Snake Charmer
]]
				},

				{
					name = L"Bone Giant",
					text =
[[
Location: 

Rewards:
1,000: Undead Tactic Fragment
10,000: Title: Master Bone Giant Slayer
]]
				},

				{
					name = L"Living Armor",
					text =
[[
Location: 

Rewards:
1,000: Man Tactic Fragment
10,000: Title: Master Living Armor Slayer
]]
				},

				{
					name = L"Scarab Bone Construct",
					text =
[[
Location: 

Rewards:
1,000: Undead Tactic Fragment
10,000: Title: The De-Constructor
]]
				},

				{
					name = L"Ushabti",
					text =
[[
Location: 

Rewards:
1,000: Undead Tactic Fragment
10,000: Title: The Claw
]]
				},

				{
					name = L"Winged Nightmare",
					text =
[[
Location: 

Rewards:
1,000: Undead Tactic Fragment
10,000: Title: Master Winged Nightmare Slayer
]]
				},

				{
					name = L"???",
					text =
[[
Location: 

Rewards:
1,000:
10,000:
100,000:
]]
				},
			},
		},
		
  	{
			name = L"Greater Undead",
			entries =
			{
				{
					name = L"Liche",
					text =
[[
Location: 

Rewards:
1,000: Undead Tactic Fragment
10,000: Title: Master Liche Slayer
]]
				},

				{
					name = L"Preserved Dead",
					text =
[[
Location: 

Rewards:
100: Undead Tactic Fragment
1,000: Title: Tombstalker
]]
				},

				{
					name = L"Vampire",
					text =
[[
Location: 

Rewards:
1,000: Undead Tactic Fragment
10,000: Title: Master Vampire Slayer
]]
				},
			},
		},
		
  	{
			name = L"Skeletons",
			entries =
			{
				{
					name = L"Carrion",
					text =
[[
Location: 

Rewards:
1,000: Undead Tactic Fragment
10,000: Title: Buzzard Bait
]]
				},

				{
					name = L"Skeleton",
					text =
[[
Location: 

Rewards:
1,000: Bestial Token
10,000: Title: The Bonecrusher
100,000: Title: The Fist of Morr
]]
				},
			},
		},
		
  	{
			name = L"Spirits",
			entries =
			{
				{
					name = L"Banshee",
					text =
[[
Location: 

Rewards:
1,000: Undead Tactic Fragment
10,000: Title: Master Banshee Slayer
]]
				},

				{
					name = L"Spirit Host",
					text =
[[
Location: 

Rewards:
1,000: Bestial Token
10,000: Title: The Iron Willed
100,000: Title: The Resolute
]]
				},

				{
					name = L"Wraith",
					text =
[[
Location: 

Rewards:
1,000: Undead Tactic Fragment
10,000: Title: Master Wraith Slayer
]]
				},
			},
		},
		
  	{
			name = L"Wrights",
			entries =
			{
				{
					name = L"Wright",
					text =
[[
Location: 

Rewards:
1,000: Undead Tactic Fragment
10,000: Title: Master Wight Slayer
]]
				},
			},
		},
		
  	{
			name = L"Zombies",
			entries =
			{
				{
					name = L"Zombie",
					text =
[[
Location: 

Rewards:
1,000: Bestial Token
10,000: Title: of the Dead
100,000: Title: Knight of the Dead
]]
				},
			},
		},		
	},
 }
	