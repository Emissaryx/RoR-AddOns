TTitan.Data.NoteworthyHEvDE = {}

function TTitan.Data.NoteworthyHEvDE.GetData()
	return TTitan.Data.NoteworthyHEvDE.RawData
end

function TTitan.Data.NoteworthyHEvDE.FilterData()
	TTitan.Data.FilterByRealm(TTitan.Data.NoteworthyHEvDE.RawData)
end

TTitan.Data.NoteworthyHEvDE.RawData =
{
	header = L"Noteworthy Persons Unlocks - High Elves vs Dark Elves",
	categories =
	{
		{
			name = L"The Blighted Isle",
			entries =
			{
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Captain Talorith",
					text =
[[
48.4k, 13.9k
Rally Master - High Elf Chapter 1
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Kyrinn Silversea",
					text =
[[
47.2k, 25.8k
Rally Master - High Elf Chapter 2
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Riandys Arrowlore",
					text =
[[
43k, 46.7k
Tor Aendris War Camp
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Aen Windsong",
					text =
[[
48.3k, 14.2k
Kill Collector - High Elf Chapter 1
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Caethsetir Silverstrand ",
					text =
[[
44.5k, 26.5k
Kill Collector - High Elf Chapter 2
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Master Kaltarn",
					text =
[[
10.4k, 19.2k
Dark Elf Rally Master - Dark Elf Chapter 1
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Akrana",
					text =
[[
13.2k, 31.2k
Dark Elf Rally Master - Dark Elf Chapter 2
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Kulvorath Bloodhand",
					text =
[[
12.9k, 51.6k 
Dark Elf Rally Master - Dark Elf Chapter 3
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Kolith Blackblade",
					text =
[[
24k, 58k
Cynathai Span Warcamp
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Saril Zaen",
					text =
[[
8.7k, 14.2k 
Kill Collector - Dark Elf Chapter 1
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Riakahd Flameblade",
					text =
[[
13.3k, 31.5k
Dark Elf Kill - Dark Elf Chapter 2
]],
				},
			},
		},

		{
			name = L"Chrace",
			entries =
			{
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Morithwen Nightwhisper",
					text =
[[
52.4k, 1.6k
Rally Master - High Elf Chapter 3
]],
				},
				
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Caduin Goldbough ",
					text =
[[
Rally Master - High Elf Chapter 4
]],
				},
				
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Aeldith Tearsong",
					text =
[[
53.7k, 1.8k
Kill Collector - High Elf Chapter 3
]],
				},
				
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Elthossar Youngstar",
					text =
[[
53.1k, 32.7k
Kill Collector - High Elf Chapter 4
]],
				},
				
				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"General Malagurn",
					text =
[[
18.7k, 25.2k
Rally Master - Dark Elf Chapter 4
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Krartil Deathsong",
					text =
[[
8.7k, 2.4k 
Kill Collector - Dark Elf Chapter 3
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Hakazin Felwind",
					text =
[[
21.1k, 26.1k
Kill Collector - Dark Elf Chapter 4
]],
				},
			},
		},

		{
			name = L"The Shadowlands",
			entries =
			{
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Mathrin Leafwind",
					text =
[[
59.6k, 11.5k
Rally Master - High Elf Chapter 5	
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Captain Nenthuil",
					text =
[[
38.5k, 14.1k
Rally Master - High Elf Chapter 6	
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Liradean Swiftarm",
					text =
[[
52.2k, 38.6k
Rally Master - High Elf Chapter 7	
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Lasira Swiftbow",
					text =
[[
47.4k, 42.6k
Bladewatch Warcamp
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Celorn Slenderwand",
					text =
[[
60.2k, 11k
Kill Collector - High Elf Chapter 5	
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Shenassa Blesswind",
					text =
[[
38.3k, 13.7k
Kill Collector - High Elf Chapter 6	
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Cirroniol Sureshot",
					text =
[[
52.4k, 40.5k
Kill Collector - High Elf Chapter 7	
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Lord Yldrian",
					text =
[[
36.2k, 9k
Rally Master - Dark Elf Chapter 5	
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Harodir",
					text =
[[
5.7k, 10.4k
Rally Master - Dark Elf Chapter 6	
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Ralkuth",
					text =
[[
18k, 37.5k
Rally Master - Dark Elf Chapter 7	
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Kathandris Skysiege",
					text =
[[
24.5k, 50k
Oath's End Warcamp
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Beastmaster Zakira",
					text =
[[
Kill Collector, Chapter 5 'Ruins of Anlec'. (35.4, 9.3k).
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Maefyr Fellwhip",
					text =
[[
35.4k, 9.8k
Kill Collector - Dark Elf Chapter 5	
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Captain Maldrak Blacktide",
					text =
[[
5.6k, 10.5k
Kill Collector - Dark Elf Chapter 6
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Torrath Ullen",
					text =
[[
17.6k, 37.6k
Kill Collector - Dark Elf Chapter 7	
]],
				},
			},
		},

		{
			name = L"Ellyrion",
			entries =
			{
				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Andalian Windrider",
					text =
[[
51.8k, 10.5k
Rally Master - High Elf Chapter 8	
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Ithiloen Truedale",
					text =
[[
42.7k, 42.1k
Rally Master - High Elf Chapter 9	
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Quartermaster Aenil",
					text =
[[
53k, 11k
Kill Collector - High Elf Chapter 8	
]],
				},

				{	-- Order only
					realm = TTitan.Data.Realm.ORDER,
					name = L"Seer Jhoril",
					text =
[[
42.5k, 42k
Kill Collector - High Elf Chapter 9	
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Baromad Drakanth",
					text =
[[
4.9k, 10k
Rally Master - Dark Elf Chapter 8	
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Kesida Garalond",
					text =
[[
14.3k, 37.8k
Rally Master - Dark Elf Chapter 9	
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Tracker Drazek Kar",
					text =
[[
5.6k, 10.3k
Kill Collector - Dark Elf Chapter 8	
]],
				},

				{	-- Destruction only
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Taraj Kirak",
					text =
[[
14.4k, 37k
Kill Collector - Dark Elf Chapter 9	
]],
				},
			},
		},

		{
			name = L"Avelorn",
			entries =
			{
				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Cirribhir Strongwing ",
					text =
[[
26.9k, 9.3k
Rally Master - High Elf Chapter 10	
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Aeddriel Swiftspear",
					text =
[[
59.7k, 9.7k
Rally Master - High Elf Chapter 11	
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Sethril Stillwater",
					text =
[[
45.7k, 34.3k
Rally Master - High Elf Chapter 12	
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Eliren Stormshade",
					text =
[[
42.6k, 55.8k
Gaen Mere War camp
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Mesilhin Darkeagle",
					text =
[[
27.3k, 10k
Kill Collector - High Elf Chapter 10	
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Elithaen Leafwind",
					text =
[[
60.5k, 9k
Kill Collector - High Elf Chapter 11	
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Nalrothel Forestshadow",
					text =
[[
46k, 34.2k
Kill Collector - High Elf Chapter 12	
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Ilries Stillfury",
					text =
[[
5.5k, 12.1k 
Rally Master - Dark Elves Chapter 10
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Sarava Scornblade",
					text =
[[
23.5k, 24.4k 
Rally Master - Dark Elves Chapter 11
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Devak Bloodbane",
					text =
[[
4.7k, 45.6k
Rally Master - Dark Elves Chapter 12
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Lord Vilkareth",
					text =
[[
17.7k, 55k
Isha's Fall Warcamp
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Uzoe Ra'an",
					text =
[[
5k, 12.1k 
Kill Collector - Dark Elves Chapter 10
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Garak Zornil",
					text =
[[
22.4k, 23.3k 
Kill Collector - Dark Elves Chapter 11
]],
				},

				{	
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Seleis Soronil",
					text =
[[
7.8k, 45.3k
Kill Collector - Dark Elves Chapter 12
]],
				},
			},
		},

		{
			name = L"Saphery",
			entries =
			{
				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Berliol Shadowseer",
					text =
[[
52.3k, 4.4k
Rally Master - High Elf Chapter 13	
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Menuthil Fargaze",
					text =
[[
55.7k, 45.3k
Rally Master - High Elf Chapter 14
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Dekindes Tovliryn",
					text =
[[
51.5k, 6.2k
Kill Collector - High Elf Chapter 13	
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Ilfuwyr Cetaine",
					text =
[[
54.5k, 43.9k
Kill Collector - High Elf Chapter 14	
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Morithia Shadowblight",
					text =
[[
11.2k, 6.7k
Rally Master - Dark Elves Chapter 13
]],
				},

				{	
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Kyaran Noth",
					text =
[[
8.3k, 34k
Rally Master - Dark Elves Chapter 14
]],
				},

				{	
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Nyethan Blackblade",
					text =
[[
9.8k, 5k
Kill Collector - Dark Elves Chapter 13
]],
				},

				{	
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Chorane",
					text =
[[
10k, 35k 
Kill Collector - Dark Elves Chapter 14
]],
				},
			},
		},

		{
			name = L"Dragonwake",
			entries =
			{
				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Aenarma Fellwater",
					text =
[[
61.3k, 21.3k
Rally Master - High Elf Chapter 17
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Hithandror Oakbrow",
					text =
[[
45.7k, 22.2k
Rally Master - High Elf Chapter 18	
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Haelynar Silverstar",
					text =
[[
6.6k, 47.3k
Rally Master - High Elf Chapter 19	
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Prince Endhil",
					text =
[[
2.3k, 54.8k
Rally Master - High Elf Chapter 20	
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Arithan Stormbreaker",
					text =
[[
2.9k, 26.1k
Drakewarden Keep Warcamp 
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Firithas Lossaryn",
					text =
[[
61.6k, 21.2k
Kill Collector - High Elf Chapter 17	
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Celanar Orithwyn",
					text =
[[
46k, 22.6k
Kill Collector - High Elf Chapter 18	
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Virian Corresyn",
					text =
[[
7k, 47.3k
Kill Collector - High Elf Chapter 19	
]],
				},
				
				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Lasinon Silverdawn",
					text =
[[
2.6k, 55.5k
Kill Collector - High Elf Chapter 20	
]],
				},
				
				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Taenia Scarletmoon",
					text =
[[
1.5k, 11k
Rally Master - Dark Elf Chapter 17	
]],
				},

				{	
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Taromir Sarath",
					text =
[[
27.8k, 17k
Rally Master - Dark Elf Chapter 18	
]],
				},

				{	
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Hyethan Baneblade",
					text =
[[
52.3k, 48.4k
Rally Master - Dark Elf Chapter 19	
]],
				},

				{	
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Korana Bloodmoon",
					text =
[[
52.6k, 45.3k
Drakeslayer Hold (War Camp) 
]],
				},

				{	
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Krathar Dreyalan",
					text =
[[
1.5k, 11.5k
Kill Collector - Dark Elf Chapter 17	
]],
				},

				{	
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Rindhor Swartshield",
					text =
[[
26.1k, 15.2k
Kill Collector - Dark Elf Chapter 18	
]],
				},

				{	
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Krellian Certhren",
					text =
[[
53k, 46.8k
Kill Collector Chapter 19	
]],
				},
			},
		},

		{
			name = L"Caledor",
			entries =
			{
				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Aenarma Fellwater",
					text =
[[
See Eataine Unlocks
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Elralion Drakestar",
					text =
[[
49.3k, 51.5k
Rally Master - High Elf Chapter 21	
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Aen Cinderblood",
					text =
[[
16.3k, 50k
Rally Master - High Elf Chapter 22	
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Kaelys Firestar",
					text =
[[
28.9k, 39.2k
Conqueror's Descent Warcamp
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Braen Tallofel",
					text =
[[
See Eataine Unlocks
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Seladon Thistlewind",
					text =
[[
48.9k, 50.3k
Kill Collector - High Elf Chapter 21	
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Arnien Brightwater",
					text =
[[
16.8k, 50.6k
Kill Collector - High Elf Chapter 22	
]],
				},
				
				{	
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Thalyn Marr",
					text =
[[
1k, 24k
Rally Master - Dark Elf Chapter 15	
]],
				},

				{	
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Velathor Lashstrider",
					text =
[[
45.6k, 7.7k
Rally Master - Dark Elf Chapter 16	
]],
				},

				{	
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Valensyl Furysworn",
					text =
[[
27.7k, 23.4k
Conqueror's Watch Warcamp 
]],
				},

				{	
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Karithan Aveth",
					text =
[[
700, 23.2k
Kill Collector - Dark Elf Chapter 15	
]],
				},

				{	
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Moridyth Cethlan",
					text =
[[
46.1k, 7.7k
Kill Collector Chapter 16
]],
				},				
			},
		},

		{
			name = L"Eataine",
			entries =
			{
				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Aelthyan Brightblade",
					text =
[[
61.5k, 13.6k
Rally Master - High Elf Chapter 15	
Found on the Caledor ToK page
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Saelir Haleril",
					text =
[[
20.2k, 18.2k
Rally Master - High Elf Chapter 16	
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Irathir Fierceblade",
					text =
[[
36.6k, 26.7k
Eataine Mustering (War Camp) 
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Braen Tallofel",
					text =
[[
60.9k, 12.2k
Kill Collector - High Elf Chapter 15	
Found on the Caledor ToK page
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Dinen Lothreull",
					text =
[[
20k, 18.2k
Kill Collector - High Elf Chapter 16	
]],
				},
				
				{	
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Hellis Vileclaw",
					text =
[[
2.3k, 55.7k
Rally Master - Dark Elf Chapter 20
]],
				},

				{	
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Hathdror Lightslayer",
					text =
[[
21.8k, 44.8k
Rally Master Chapter 21	
]],
				},

				{	
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Morelan Darkslayer",
					text =
[[
43.6k, 43.6k	
Rally Master Chapter 22	
]],
				},

				{	
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Koridrel Ebonshard",
					text =
[[
27.5k, 42k
Ebonhold Watch (War Camp) 
]],
				},

				{	
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Thandros Uthorin",
					text =
[[
1.8k, 55.2k
Kill Collector Chapter 20	
]],
				},				

				{	
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Telurna Darkveil",
					text =
[[
20k, 44k
Kill Collector Chapter 21	
]],
				},

				{	
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Zural Bitterwind",
					text =
[[
44.5k, 44.9k
Kill Collector Chapter 22	
]],
				},				
			},
		},
	},
}
