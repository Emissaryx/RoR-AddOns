TTitan.Data.BestiaryHEvDE = {}

function TTitan.Data.BestiaryHEvDE.GetData()
	return TTitan.Data.BestiaryHEvDE.RawData
end

function TTitan.Data.BestiaryHEvDE.FilterData()
	TTitan.Data.FilterByRealm(TTitan.Data.BestiaryHEvDE.RawData)
end

TTitan.Data.BestiaryHEvDE.RawData =
{
	header = L"Beastiary Unlocks - High Elves vs Dark Elves",
	categories =
	{
		{
			name = L"The Blighted Isle",
			entries =
			{
				{
					name = L"Witch Elf (Pocket)",
					text =
[[
Dark Elves, Witch Elves - What do We Have Here?
26.5k, 62k
Click on the Hidden Scroll located in front of the N tower by the W BO, in the rubble. 

Rewards
Pocket: Witch Armor
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Bandit (Title)",
					text =
[[
Bandit - Talk of the Town
13k, 8k
Talk to one of the "Uthorin Sorceresses" along the path between Narthain Beach and Black Ark, near Dark Elf Chapter 1. They are surrounded by neutral "Dark Sprites".

Rewards
Title: The Bounty Hunter
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Warhack (Tactic)",
					text =
[[
Warhawk - Bird Watching ... Up Close, in Person
51.8k, 22.2k
Kill "Crag Great Wing" a neutral mob, on the edge of the cliff behind the trees.

Rewards
Beastial Tactic Fragment
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Bandit (Title)",
					text =
[[
Bandit - Talk of the Town
13k, 8k
Kill one of the "Uthorin Sorceresses" along the path between Narthain Beach and Black Ark, near Dark Elf Chapter 1. They are surrounded by neutral "Dark Sprites".
Note: Order can easily reach them swimming from 31k 3k to 23k 12k, then avoid 55 Champions.

Rewards
Title: The Bounty Hunter
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Horror (Pocket)",
					text =
[[
Horror - Where Did You All Go?
21.6k, 37.4k
Kill the lone level 4 'Lost Horror' Champion, in the hills west of Lacorith. It is found on a high mountain ridge that is a little difficult to reach:
If you are coming from the Destruction side (west side), climb to 18.6k 40.2k then follow the slope of the mountain to reach the Horror.

Rewards
Pocket Item: Morphing Ooze
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Horror (Pocket)",
					text =
[[
Horror - Where Did You All Go?
21.6k, 37.4k
Kill the lone level 4 'Lost Horror' Champion, in the hills west of Lacorith. It is found on a high mountain ridge that is a little difficult to reach:
If you are coming from the Order side (east side), run south at 27.5k 46.7k, then climb to reach 18.6k 40.2k. Eventually follow the slope of the mountain to reach the Horror.

Rewards
Pocket Item: Morphing Ooze
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Scorpion, Giant (Tactic)",
					text =
[[
Scorpion, Giant - A Pinch to Grow an Inch
6k, 63k
Kill 60 'Poisonblight Scorpions', 'Poisonblight Burnclaws' and 'Poisonblight Ironclaws' in a large zone around in thesouthwestern part of the map, for the kill collector Krartil Deathsong in Chrace (8.7k 2.2k).

Rewards
Beastial Tactic Fragment
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Scorpion, Giant (Tactic)",
					text =
[[
Scorpion, Giant - A Pinch to Grow an Inch
Unverified
Kill 60 'Blighted Scorpions' and 'Blighted Poisontails' in The Blighted Isle around 48k 39k for the kill collector Caethsetir Silverstrand located in Adunei (High Elf Chapter 2).

Rewards
Beastial Tactic Fragment
]],
				},

				{
					name = L"Scorpion, Giant (Title)",
					text =
[[
Scorpion, Giant - Beach Bum
3.3k, 62.7k
Kill 'Bane Claw', the champion scorpion.

Rewards
Title: The Scorpion Squisher
]],
				},

				{
					name = L"Snotling (Title)",
					text =
[[
Snotling - And I Just Cleaned My Boots
Incorrect or not implemented
49k, 48.4k
Interact with a white rock "Loose Rock", on top of a stone, with a Snotling lying at its base.

Rewards
Title: The Peculiar
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Spite (Title)",
					text =
[[
Spite - Looking for Shinnies
54.5k 52.4k
Kill "Dark Spites" until one drops a Pocket Item "Shining Ring". Equip it for the associated title.

Rewards
Title: The Spite Splitter
]],
				},

				{
					name = L"Wolf (Title)",
					text =
[[
Wolf - View With a Howl
4.7k, 49.3k
Click on "Wolves' Meal" a dead deer right on the edge of the cliff top.

Rewards
Title: The Howler
]],
				},
			},
		},

		{
			name = L"Chrace",
			entries =
			{
				{
					name = L"White Lion (Pocket)",
					text =
[[
High Elf, White Lion - What do We Have Here?
28k, 11.5k
Click on the hidden scroll. 

Reward
Pocket: Captured Lion Essence
]],
				},

				{
					name = L"Dryad (Title)",
					text =
[[
Dryad - Grove and Grave
Not implemented yet
4.5k, 47k
Explore the monster's habitat.

Rewards
Title: Forester
]],
				},

				{
					name = L"Harpy (Tactic)",
					text =
[[
Harpy - Get Down Here!
45k, 23k
Kill a "Bloodtalon Harpy" near the ruined tower, on the north shore of the lake.

Rewards
Chaos Tactic Fragment
]],
				},

				{	
					name = L"Bandit (Pocket)",
					text =
[[
Bandit - Treaty for Treasure
48k, 8.6k
Kill the two bandits named "Amalyn Weber" and "Faye Val". They are on a narrow ramp leading down to the ocean underneath the land bridge connecting the Plain of Bone with the mainland.
Note: As Destruction char, you will have to swim from 21k 14.5k following cliffs to reach this location. Be prudent as you there are 55 Champions at the start of the bridge (47.4k 10.3k).

Rewards
Pocket: Semi-Lucky Charm
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Spider, Giant (Tactic)",
					text =
[[
Spider, Giant - Fast Finds
45.5k 42.7k
Kill 60 'Warpweb Spiders' and 'Warpweb Broodlings' . Then return to the Kill Collector, Elthossar Youngstar, in the Cliffs of Ushuru to complete the Kill Quest 'Toxic Shock'.

Rewards
Beastial Tactic Fragment
]],
				},
			},
		},

		{
			name = L"The Shadowlands",
			entries =
			{
				{
					name = L"Shadow Warrior (Pocket)",
					text =
[[
High Elf, Shadow Warrior - What do We Have Here?
35.5k, 54.5k
Click on the 'Hidden Scroll' located in the middle of a some trees. Unlocks: Broken Bowstring.

Reward
Pocket: Broken Bowstring
]],
				},

				{	
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Bird (Title)",
					text =
[[
Bird, Warhawk - Bird Watching ... Up Close, In Person
24.4k, 22.2k
Kill the 'Skyherald Warhawk' perched on a rock next to 'Elder Meresene'.

Rewards
Beastial Tactic Fragment
]],
				},

				{
					name = L"Bear (Title)",
					text =
[[
Bear - At Least They'll Stay Cool
58.6k, 28.9k
Kill 'Darkclaw Bear' and 'Darkclaw Mauler' in a large zone until they drop a Pocket Item 'Bear Pelt', then equip it to unlock the associated title.
Note: Drop rate is 10%.

Rewards
Title: Pioneer
]],
				},

				{	
					realm = TTitan.Data.Realm.ORDER,
					name = L"Bird (Title)",
					text =
[[
Bird, Warhawk - I Just Washed This Cloak
27.2k, 22k or 21.5k, 23.4k or 20k, 28.1k or 9.3k, 21.3k or 10k, 18.6k or 9.3k, 9.5k
Kill "Skyhunter Mauler" mobs at these location to collect 5 "Warhawk Feather" items, then trade them to Library Assistant inside the Library in Altdorf for "Warhawk Cloak" and equip it for the unlock.

Rewards
Title: The Grounded
]],
				},

				{	
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Bird (Title)",
					text =
[[
Bird, Warhawk - I Just Washed This Cloak
27.2k, 22k or 21.5k, 23.4k or 20k, 28.1k or 9.3k, 21.3k or 10k, 18.6k or 9.3k, 9.5k
Kill "Skyhunter Mauler" mobs at these location to collect 5 "Warhawk Feather" items, then trade them to Disciple's Assistant inside the Lyceum in The Inevitable City for "Warhawk Cloak" and equip it for the unlock.

Rewards
Title: The Grounded
]],
				},

				{
					name = L"Cockatrice (EXP)",
					text =
[[
Cockatrice- If Looks Have Killed
58k, 29.9k
Interact with the 'Petrified Corpse' between some trees.
]],
				},

				{	
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Cold One (Title)",
					text =
[[
Cold One - A Balancing of Scales
37.7k, 8.3k
Talk to the Healer, Taelq Ragecrown, in the Dark Elf Chapter 5 (Ruins of Anlec).

Rewards
Title: Scale Breaker
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Cold One (Title)",
					text =
[[
Cold One - A Balancing of Scales
44k, 29k 
Max out the Kill Collector, Shenassa Blesswind, at Sorrowstrand (High Elf Chapter 6), killing 60 'Snarling Cold Ones' and 'Snarling Scalebacks'.
Note: 'Frostsnaps' (Champions) around the lake at 50k 20k do NOT count for this unlock.

Rewards
Title: Scale Breaker
]],
				},

				{
					name = L"Harpy (Title)",
					text =
[[
Harpy - House on the Hill
53.3k, 45.2k
Interact with the "Harpy Roost", on the outcrop by the roadside. You can jump on the outcrop by its southwest side, but you have to pass through the north of the outcrop to be able to reach its southwest side.

Rewards
Title: The Bold
]],
				},

				{
					name = L"Imp (Title)",
					text =
[[
Imp - What Makes You Sparkle?
33.6k, 11.3k
Kill the "Sprites" until they drop a Pocket Item "Sparkling Sprite Remains". Equip it for the associated title.

Rewards
Title: The Imp Squisher
]],
				},

				{
					name = L"Scorpion (Tactic)",
					text =
[[
Scorpion, Giant - Deadly When Dead
3k, 42k
Kill the scorpions in the area along the coast until the 'Poisontail stinger' drops. Equip it for the unlock.

Rewards
Beastial Tactic Fragment
]],
				},

				{
					name = L"Tree Kin (Title)",
					text =
[[
Tree Kin - Rings of History
12.4k, 58k
Interact with a "Rootwalker Remains", up on the cliff that you can climb from 14.5k 56k.

Rewards
Title: The Lumberjack
]],
				},

				{
					name = L"Unicorn (Title)",
					text =
[[
Unicorn - A Little Off the Top
17.8k, 43.6k
Kill the level 16 champion Unicorn "Sylendoras". This unicorn drops a Pocket Item "Piece of a Unicorn's Horn". Equip it for the associated title.

Rewards
Title: The Hornsnapper
]],
				},
			},
		},

		{
			name = L"Ellyrion",
			entries =
			{
				{
					name = L"Disciple of Khaine (Pocket)",
					text =
[[
Dark Elf, Disciple of Khaine - What do We Have Here?
36k, 32k
Click on the 'Hidden Scroll' -- Near the waterfall, between the stones.

Reward:
Pocket: Dark Polish
]],
				},

				{
					name = L"Great Cat (Tactic)",
					text =
[[
Great Cat - Silencing Shadows
61.1k, 57.2k
Kill "Shadowscream" just north of the main road in the trees.

Rewards
Beastial Tactic Fragment
]],
				},

				{
					name = L"F. of Slaanesh (Title)",
					text =
[[
Fiend of Slaanesh - Things Best Left Unknown
35.7k, 48.2k
Interact with 'Book of Innocence'. It's behind a NPC sitting down named 'Kelthera Darklust' lvl 20.

Rewards
Title: The Impure
]],
				},

				{
					name = L"Great Eagle (Title)",
					text =
[[
Great Eagle - Birds of a Feather
28k, 43k
Kill 'Ellyrian Eagle' until one drops a Pocket Item 'Great Eagle Feather'. Equip it for the associated title.

Rewards
Title: The Vigilant
]],
				},
			},
		},

		{
			name = L"Avelorn",
			entries =
			{
				{
					name = L"Archmage (Pocket)",
					text =
[[
High Elf, Archmage - What do We Have Here?
28.5k, 61.1k
Click on the Hidden Scroll located behind a rock just to the W of the Well of Qhaysh, very near the (D) side road, barely inside the lake, in fact. Unlocks: Ruined Book.

Rewards
Pocket: Ruined Book
]],
				},

				{
					name = L"Beastman (Cloak)",
					text =
[[
Beastman, Bestigor - Bossy Beastie
46.1k, 39.3k
Kill the rank 26 bestigor 'Khurraak Might-Horns' on the road.

Rewards
Back Item: Pelt of the Dark Young
]],
				},

				{
					name = L"Bone Giant (Title)",
					text =
[[
Bone Giant - Parts of Parts
58k, 61.4k
Kill/talk to "Brulgulrach the Unliving", 25 Champion Giant Bone.

Rewards
Title: The Bone Breaker
]],
				},

				{
					name = L"Dryad (Tactic)",
					text =
[[
Dryad - Chip Off the Old...
32.5k, 36.5k
Kill "Oldbark", a rank 24 Dryad.

Rewards
Mythical Tactic Fragment
]],
				},

				{
					name = L"H. of Tzeentch (Tactic)",
					text =
[[
Horror of Tzeentch - Pack of Three
62.9k, 15.1k
Kill 'Golmir' (level 23 champion Horror). He is up on a little cliff.

Rewards
Daemonic Tactic Fragment
]],
				},

				{
					name = L"Liche (Title)",
					text =
[[
Liche - Final Rest... Again
33.3k, 49.6k
Kill 'Tarnolious the Lost', the Liche rank 1 Hero, above the cliff at the edge of water.

Rewards
Title: Champion of Morr
]],
				},

				{
					name = L"Nurgling (Pocket)",
					text =
[[
Nurgling - More Filth for Me!
37.2k, 16.6k
Kill 'Filthmiser', the Champion Nurgling.

Rewards
Pocket: Regurgitated Trinket
]],
				},

				{
					name = L"Treeman (Title)",
					text =
[[
Treeman - Who Bears the Worldbearer?
43.8k, 44.8k 
Speak to 'Dregenis' the Tree Kin.

Rewards
Title: The Vale-Walker
]],
				},

				{
					name = L"Troll (Bestial Token)",
					text =
[[
Troll, Chaos - Dispense Justice
19.5k, 48.5k
Kill "Goremaw", a rank 25 champion Chaos Troll, northeast of Destruction War Camp.

Rewards
Bestial Token
]],
				},

				{
					name = L"Zombie (Pocket)",
					text =
[[
Zombie - Loop Back
Incorrect or not implemented
40.5k, 41.3k
Kill 'Rupert', the rank 27 zombie.

Rewards
Pocket: Moldy Coin Purse
]],
				},
			},
		},

		{
			name = L"Saphery",
			entries =
			{
				{
					name = L"Swordmaster (Pocket)",
					text =
[[
Empire, Swordmaster - What do We Have Here?
40k, 6.2k
Click on the Hidden Scroll located inside the fountain. Unlocks: Broken Sword.

Rewards
Pocket: Broken Sword
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Chaos Hound (Acc)",
					text =
[[
Chaos Hound - From Mouth to Neck
47.8k, 9.5k
Kill 'Twisted Hounds' until you collect 10 'Chaos Hound Fang'. 
Trade these 'Chaos Hound Fang(s)' for a Pocket Item 'Amulet of Fangs' to Disciple's Assistant in the Lyceum at The Inevitable City. Equip it for the unlock.

Rewards
Jewel Item : Black Toof
]],
				},

				{	
					realm = TTitan.Data.Realm.ORDER,
					name = L"Chaos Hound (Acc)",
					text =
[[
Chaos Hound - From Mouth to Neck
47.8k, 9.5k 
Kill 'Twisted Hounds' until you collect 10 'Chaos Hound Fang'. 
Trade these 'Chaos Hound Fang(s)' for a Pocket Item 'Amulet of Fangs' for to Library Assistant in the Library at Altdorf. Equip it for the unlock.

Rewards
Jewel Item : Black Toof
]],
				},

				{
					name = L"Cockatrice (Cloak)",
					text =
[[
Cockatrice - A Charmed Life
58.2k, 27.4k
Kill 'Slashbeak', a level 27 Champion Cockatrice, among other Cockatrices.

Rewards
Back Item: Plumes of the Eye Killer
]],
				},

				{
					name = L"Cold One (Token)",
					text =
[[
Cold One - Big Freeze
51k, 10k
Kill the 27 champion cold one named 'Coldlash'. He is centered in a pack of loose cold ones just off the road.

Rewards
Bestial Token
]],
				},

				{
					name = L"Manticore (EXP)",
					text =
[[
Manticore - Won't Ask Where it Kept That
53.9k, 19.6k
Kill the "Unmounted Manticore", above the waterfall. It will drop a Pocket Item "Partially Digested Manual", equip it for the unlock.

Note: You can also find other "Unmounted Manticores" near, around 54.5k 15.7k.
]],
				},

				{
					name = L"Pegasus (Title)",
					text =
[[
Pegasus - Do You Know the Way
14.7k, 900
Interact with an 'Ancient Rider's Horn', hanging from an elf tree with blue leaves northeast of Dark Elf Chapter 13, over a hill. You will be flagged RvR.

Rewards
Title: The Hornblower
]],
				},

				{
					name = L"Squig (Pocket)",
					text =
[[
Squig - Take a Break
60.4k, 61.6k
Interact with "Fleshy Mushrooms" in the cave "Southern Stonewind Cavern" (Entrance 57k, 60k). It's a set of 3 blue mushrooms that look exactly the same as the "Bluespore Nightcap" quest items throughout the rest of the cave. They are in the split level area just before the deepest part of the cave.

Rewards
Pocket: Squig Teeth Necklace
]],
				},
			},
		},

		{
			name = L"Dragonwake",
			entries =
			{
				{
					name = L"Sorcerer (Pocket)",
					text =
[[
Dark Elf, Sorcerer - What do We Have Here?
21.5k, 32.5k
Click on the 'Hidden Scroll' South of the Mournfire's Approach BO, within some rocks. 

Rewards
Pocket: Foul Scroll
]],
				},

				{
					name = L"Beastmen (Title)",
					text =
[[
Beastmen, Doombull - Grab the Bull By the Horn
65k, 30k
Interact with 'Pile of Bones' just next to the river, to make spawn 'Crazed Bull', a level 34 Doombull. Kill him for the unlock and the associated title.

Rewards
Title: Cairn Breaker
]],
				},

				{
					name = L"D. of Slaanesh (Acc)",
					text =
[[
Daemonette of Slaanesh - Sacrifice Over Excess
14.6k, 8.2k
Interact with the 'Second Journal of Lliean' to spawn 'Jezebeth', a level 39 Daemonette of Slaanesh. Kill her for a pocket item 'Icy Heart'.
Take the 'Icy Heart' to the 'Altar of Broken Flesh' in the Chaos Wastes at 54k 16.2k. Interacting with the altar will trigger the unlock. 

Rewards
Jewel Item : Moon Fang
]],
				},
			},
		},

		{
			name = L"Isle of the Dead",
			entries =
			{
				{
					name = L"Chaos Fury (Token)",
					text =
[[
Chaos Fury - On Wings, but Not Quite Angels
42.7k, 33.3k
Kill 'Ylger'oz the Demented', a level 35 Champion Chaos Fury, until he drops a Pocket Item 'Concentrated Evil'. Equip it for the unlock.
 
Rewards
Bestial Token
]],
				},

				{
					name = L"Construct (Title)",
					text =
[[
Construct - Anyone Have a Can Opener?
Either incorrect or not implemented
13.8k, 26.8k 
Kill 30 'Living Armors' at the Destruction PQ 'Ritual of Metal'.
 
Rewards
Title: The Armor-Breaker
]],
				},
			},
		},

		{
			name = L"Caledor",
			entries =
			{
				{
					name = L"High Elf (Title)",
					text =
[[
High Elf - The History of the High Elves
38k, 30k
Click on the Hidden Scroll located next to backbone of the dragon skeleton.

Rewards
Title: Isha's Lament
]],
				},

				{
					name = L"Dark Elf (Pocket)",
					text =
[[
Dark Elf - What do We Have Here?
28k, 29k
Click on the Hidden Scroll located next to backbone of the dragon skeleton.

Rewards
Pocket: Kouran's Orders
]],
				},

				{
					name = L"Boar (Acc)",
					text =
[[
Boar - Pork Chop
???
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Scoprion (Acc)",
					text =
[[
Giant Scorpion - Stick the Sticker
50k, 45.4k
Kill 'Crushclaw', a rank 38 champion. He will drop a Pocket Item 'Giant Scorpion Stinger', equip it to have the unlock.

IMPORTANT NOTE: 
For Destruction to go on Order side of Caledor's map:
From Dragonwake war camp, walk in RvR area then join PvE area at 29k 45k.
Reach 2k 59k to take the secret passage, avoiding Order Chapters, and you'll arrive in Caledor.

Rewards
Jewel Item: The Obdurate Seal
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Scoprion (Acc)",
					text =
[[
Giant Scorpion - Stick the Sticker
50k, 45.4k
Kill 'Crushclaw', a rank 38 champion. He will drop a Pocket Item 'Giant Scorpion Stinger', equip it to have the unlock.

Rewards
Jewel Item: The Obdurate Seal
]],
				},

				{
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Hydra (Title)",
					text =
[[
Hydra - Who Let That Thing Out?
13.3k, 36.9k
Kill "Deathclaw Hydra" (lvl 40 champ).

IMPORTANT NOTE: 
For Destruction to go on Order side of Caledor's map:
From Dragonwake war camp, walk in RvR area then join PvE area at 29k 45k.
Reach 2k 59k to take the secret passage, avoiding Order Chapters, and you'll arrive in Caledor.

Rewards
Title: Hydra Tamer
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Hydra (Title)",
					text =
[[
Hydra - Who Let That Thing Out?
13.3k, 36.9k
Kill "Deathclaw Hydra" (lvl 40 champ).

Rewards
Title: Hydra Tamer
]],
				},

				{
					name = L"Liche (Token)",
					text =
[[
Liche - For the Promise of Power
32.2k, 22.2k
Interact with 'Mound of Dirt'.

Note: When you accomplish the unlock, it tells 'You have completed: Stunting Their Power', but the unlock in ToK is 'For the Promise of Power'.
For Order: To reach the Mound of Dirt, come from the RvR lake and head to Destruction Warcamp, hug the hill to avoid 55 Guards, then drop down.

Rewards
Bestial Token
]],
				},

				{	
					realm = TTitan.Data.Realm.DESTRUCTION,
					name = L"Manticore (Token)",
					text =
[[
Manticore - Don't Look Up
15.8k, 41k
Kill "Martikhoras", a level 39 Champion Manticore.

IMPORTANT NOTE: 
For Destruction to go on Order side of Caledor's map:
From Dragonwake war camp, walk in RvR area then join PvE area at 29k 45k.
Reach 2k 59k to take the secret passage, avoiding Order Chapters, and you'll arrive in Caledor.

Rewards
Bestial Token
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Manticore (Token)",
					text =
[[
Manticore - Don't Look Up
15.8k, 41k
Kill "Martikhoras", a level 39 Champion Manticore.

Rewards
Bestial Token
]],
				},
			},
		},

		{
			name = L"Eataine",
			entries =
			{
				{
					name = L"Dark Elf (Title)",
					text =
[[
Dark Elf - The History of the Dark Elves
30k, 36k
Click on the 'Hidden Scroll' located near a building, next to 3 barrels.

Rewards
Title: Lion Guard
]],
				},

				{
					realm = TTitan.Data.Realm.ORDER,
					name = L"Tuskgor (Tactic)",
					text =
[[
Tuskgor - Saving Face
12.8k, 8.2k to 27.8k, 5.5k
Kill 'Ravaging Tuskgors' (not Rampaging) and collect 5 'Unchipped Tusks'.
Trade them for a Pocket Item 'Belt of Tusks' to Library Assistant into the Library at Altdorf. Equip it for the unlock.

Rewards
Chaos Tactic Fragment
]],
				},

				{
					name = L"Great Eagle (Acc)",
					text =
[[
Great Eagle - Eagle-Eye
46.4k, 61k
Kill a champion eagle named Ironfeather that is located west of the Shrine of Lileath, on a little rock.

Rewards
Jewel Item : Gorkamork
]],
				},

				{	
					name = L"Griffon (Title)",
					text =
[[
Griffon - The Mightiest
53k, 64.2k
Kill/talk to the Champion Griffon "Grimwing".

Rewards
Title: The Majestic
]],
				},

				{
					name = L"Harpy (Tactic)",
					text =
[[
Harpy - Silent Star
39k, 12.2k
Kill the level 31 harpy champion "Khaligrar Bloodwing". She is near some "Vineyard Boars".

Rewards
Chaos Tactic Fragment
]],
				},

				{	
					name = L"Harpy (Acc)",
					text =
[[
Harpy - Their Heart's Not in it, Yet.
32k, 60k
Kill "Tormented Harpy" until you receive the Pocket Item "Harpy Heart". Equip it for the unlock.

Rewards
Jewel Item: Wind of Change
]],
				},

				{
					name = L"Treekin (Token)",
					text =
[[
Treekin - Timber!
53k, 63.2k
Kill "Irebough Mossroot", a level 40 Hero Treekin.

Rewards
Bestial Token
]],
				},

				{
					name = L"Tuskgor (Tactic)",
					text =
[[
Tuskgor - Tusk for Tusk
13.9k, 11.6k 
Kill 'Riptusk', a level 33 Champion.

Rewards
Chaos Tactic Fragment
]],
				},
				
				{
					name = L"Keeper of Secrets (Title)",
					text =
[[
Keeper of Secrets - Picked Clean
47.2k, 2.1k
Interact with the skeleton labeled 'Discarded Bones'. It is down the cliff, at the water's edge.

Rewards
Title: Herald of Temperance
]],
				},				
			},
		},
  },		
}
