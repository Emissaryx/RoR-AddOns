TTitan.Data.Explorations = {}

function TTitan.Data.Explorations.GetData()
	return TTitan.Data.Explorations.RawData
end

function TTitan.Data.Explorations.FilterData()
	TTitan.Data.FilterByRealm(TTitan.Data.Explorations.RawData)
end

TTitan.Data.Explorations.RawData =
{
	header = L"Exploration Achievements",
	categories =
	{
		{
			name = L"About This Page",
			entries =
			{
				{
					name = L"Explorations",
					text =
[[
These are Exploration Unlocks found in the Achievements section of your ToK.
Use "/ttitan pursuits" to open the Pursuits page.
]],
				},

				{
					name = L"Credit",
					text =
[[
The information found here is directly from the Warhammer Alliance Forums "The Unofficial Exploration/Pursuit Achievement Unlock Thread". You can find it here:
http://www.warhammeralliance.com/forums/showthread.php?t=180277

The thread is maintained by Socran of the Red Eye Mountain server.
]],
				},
			},
		},

		{	-- Divider, won't expand when clicked
			name = L"---------",
			divider = true,
			entries = {},
		},

		{
			name = L"Ancient Lament",
			entries =
			{
				{
					name = L"Ancient Lament",
					text =
[[
THE BLIGHTED ISLE
45k, 24k
Interact with 'Ancient Scroll' on a bench, northeast of High Elf Chapter 2.

Tip: As Destruction player, to reach order side of the map, I advice you to head 34k 28k, then jump down. You will have to walk on the western side of the ground to avoid 55 Champions of High Elf Chapter, to head to 40k 22k. Avoid the chapter by the north, then jump from the hill around 45.3k 21.3k (without dying).
]],
				},
			},
		},

		{
			name = L"Cold One Hunters",
			entries =
			{
				{
					name = L"Cold One Hunters",
					text =
[[
THE BLIGHTED ISLE
58k, 41.2k
Click on "Corral" the gate into the Coldone pen.
]],
				},
			},
		},

		{
			name = L"Dangers of Deadwater",
			entries =
			{
				{
					name = L"Dangers of Deadwater",
					text =
[[
MARSHES OF MADNESS
15.2k, 31.2k
Click on "Rotting Ratman" on the edge of the green water.
]],
				},

				{
				realm = TTitan.Data.Realm.ORDER,
				name = L"Marsh Fever",
					text =
[[
MARSHES OF MADNESS
15.2k, 31.2k
Click on "Rotting Ratman" on the edge of the green water to start the quest "Rotten Luck". Then head to "Olfrinson's Outpost" Dwarf Chapter 5 camp and talk to "Hegakin Behrson" to complete the quest, which gives the unlock.
]],
				},

				{
				realm = TTitan.Data.Realm.DESTRUCTION,
				name = L"Marsh Fever",
					text =
[[
MARSHES OF MADNESS
15.2k, 31.2k
Click on "Rotting Ratman" on the edge of the green water to start the quest "Rotten Luck". Then head to "Morth's Mire" Greenskin War Camp and talk to "Odgit Shineymaka" to complete the quest, which gives the unlock.
]],
				},
			},
		},

		{
			name = L"Darkhelm Resistance",
			entries =
			{
				{
					name = L"Darkhelm Residence",
					text =
[[
BARAK VARR
47.5k 15.3k
Interact with 'Dwarf Post' in the Khaz Kol Bar tunnels, in front of a dwarf door.

Tip: To reach it, from Destruction PQ 'Fall of Firebrew' (55.4k 19.5k) head west than north at 51k 18.2k. You will naturally have to turn left where an enormous pillar is, continue a little and the door will be on your right.
]],
				},
			},
		},

		{
			name = L"Dead in the Water",
			entries =
			{
				{
					name = L"Dead in the Water",
					text =
[[
BARAK VARR
31.3k, 26.9k
Click on "Deteriorating Sea Mine" out in the middle of the water directly north from the back of "Dok Karaz" keep.
]],
				},

				{
				realm = TTitan.Data.Realm.ORDER,
				name = L"Settin' Things Straight",
					text =
[[
Not Verified
BARAK VARR
31.1k, 49.1k
Talk to "Siege Engineer", a dwarf with a large metal helmet, on the north side of "Thane's Defense" Dwarf Chapter 7 camp.
]],
				},

				{
				realm = TTitan.Data.Realm.ORDER,
				name = L"Wot's Dis Den?",
					text =
[[
Not Verified
BARAK VARR
29.2k, 18.6k
Kill "Bloody Sun Metal 'Ead", a goblin with a large metal helmet, on the north east edge of "Mobash's Place" Greenskin Chapter 9 camp.
]],
				},
				
				{
				realm = TTitan.Data.Realm.DESTRUCTION,
				name = L"Settin' Things Straight",
					text =
[[
BARAK VARR
31.1k, 49.1k
Kill "Siege Engineer", a dwarf with a large metal helmet, on the north side of "Thane's Defense" Dwarf Chapter 7 camp.
]],
				},

				{
				realm = TTitan.Data.Realm.DESTRUCTION,
				name = L"Wot's Dis Den?",
					text =
[[
BARAK VARR
29.2k, 18.6k
Talk to "Bloody Sun Metal 'Ead", a goblin with a large metal helmet, on the north east edge of "Mobash's Place" Greenskin Chapter 9 camp.
]],
				},
			},
		},

		{
			name = L"Everlastink Nob Toppa",
			entries =
			{
				{
					name = L"Everlastink Nob Toppa",
					text =
[[
MOUNT BLOODHORN
17.8k 36.8k
Interact with 'Ranklot's Pile', inside Major Landmark 'Da Gobbo Camp'. It is a cuirass next to a large greenskin pile, some red mushrooms are just next to the Ranklot's Pile.
]],
				},
			},
		},

		{
			name = L"Exploration",
			entries =
			{
				{
					name = L"Leap of Faith",
					text =
[[
KARAZ-A-KARAK MIDDLE DEEPS
29.7k, 28.4k
Click on "Misplaced Rope" on top of the rock pillar. To reach it, you have to jump down to the first rock ledge and then onto the pillar. It is a one way trip!

NOTE: This is currently Order only, as no way for Destruction to get to the city.

Rewards
Title: Curious Creature
]],
				},

				{
					name = L"Follow the Bones",
					text =
[[
KARAK EIGHT PEAKS
20.9k, 33.2k
Head towards the Arena area but jump off the walkway around 23.4k, 35k near the "Hole Datm Goes Down".
Start slowly jumping down the cliff face slightly north. Be sure to catch legdges on the way down not to die from falling! You will see a destroyed dwarf camp at the bottom of the chasm.
Click on "Stunty Skribbles" beside the Dwarf skeleton and banner.
You can use the "Hole Dat Goes Up" to be teleported out of the chasm.

NOTE: This is currently Destruction only, as no way for Order to get to the city.

Rewards
Title: Little Explorer
]],
				},
			},
		},

		{
			name = L"Firebrew",
			entries =
			{
				{
					name = L"Firebrew",
					text =
[[
BARAK VARR
53.5k 24.7k
Interact with 'Floating Barrel' in the water next to a grille.
]],
				},
			},
		},

		{
			name = L"Gettin' Slopped",
			entries =
			{
				{
					name = L"Getting' Sloped",
					text =
[[
MOUNT BLOODHORN
15k 37.2k
Interact with one of the 'Slop Bucket' inside Ranklot's hut at the Major Landmark 'Da Gobbo Camp'. The hut is on a hill.

There are 3 Slop Buckets:
- 15.2k 37.1k just on the left when you enter the hut, between 2 crates
- 15.2k 37.4k on the left of the hut, between crates and a small table
- 14.6k 37.2k on the right of the hut behind the greenskin pile
]],
				},
			},
		},

		{
			name = L"Ghoulish Gourmet",
			entries =
			{
				{
					name = L"Ghoulish Gormet",
					text =
[[
OSTLAND
56.5k, 39k
Talk to "Nathore Gristlechewer" a neutal mob, standing beside and cooking pot, with a dead horse on a rock in front of him.
Click on "Pungent Cooking Pot" next to "Nathore Gristlechewer" and take all of the quests.
]],
				},
				
				{
					name = L"Cadaverous Casseroles",
					text =
[[
NORSCA
40.9k, 33.6k
Kill "Seared Ghoul" mobs for "Portion of Ghoul Meat". Return to "Nathore Gristlechewer" in Ostland to complete the quest and get the unlock.
]],
				},
				
  			{
					name = L"Stitchy Fingers",
					text =
[[
BARAK VARR
22k, 20.7k
Click on "Washed-Up Corpse" for "Portion of Dwarf Meat". Return to "Nathore Gristlechewer" in Ostland to complete the quest and get the unlock.
]],
				},
				
				{
					name = L"Fried Green Waaagh",
					text =
[[
MOUNT BLOODHORN
9k, 54.1k
Kill "Scartusk Bruisa" mobs for "Orc Skull". Return to "Nathore Gristlechewer" in Ostland to complete the quest and get the unlock.
]],
				},
				
				{
					name = L"Baked Tzeentch",
					text =
[[
HIGH PASS
16.7k, 27.3k
Kill "Flameborn" a flamer champion for "Flamer Flesh". Return to "Nathore Gristlechewer" in Ostland to complete the quest and get the unlock.
]],
				},
				
				{
					name = L"Fired Cracklins",
					text =
[[
NORSCA
50.2k, 26k
Click on "Gotland's Pyromancer" a body burnt at the stake in the middle of the town, for "Chunk of Human Flesh". Return to "Nathore Gristlechewer" in Ostland to complete the quest and get the unlock.
]],
				},
			},
		},

		{
			name = L"Grave of the Unknown Acolyte",
			entries =
			{
				{
					name = L"Grave of the Unknown Acolyte",
					text =
[[
OSTLAND
62.5k 45.7k
Interact with 'Tombstone' in the cemetery in front of north 'The Catacombs' entrance. The tombstone is near some bushes, and is clearer than the other graves
]],
				},
			},
		},

		{
			name = L"Iceshard Blade",
			entries =
			{
				{
					name = L"Iceshard Blade",
					text =
[[
TROLL COUNTRY
39.8k, 3.6k
Interact with 'Shard of Ice'at 37.5k 570 inside the cave 'Shiver Hollow'. The 'Shard of Ice' is behind the Yhetee level 19 Champion 'Icemaw', hidden between 2 black/grey big rocks.
]],
				},
			},
		},

		{
			name = L"Litany of Death",
			entries =
			{
				{
					name = L"Song of the Rose",
					text =
[[
OSTLAND
2.8k, 20k
Click on "Song of the Rose" a book inside "Lost Cavern" minor landmark at the very back of the cave.
]],
				},
				
				{
					name = L"Boneweave Cypher",
					text =
[[
OSTLAND
2.8k, 20k
Click on "Song of the Rose" a book inside "Lost Cavern" minor landmark at the very back of the cave. Then complete the quest given called "Song of the Rose", by using the item in your quest items.
]],
				},
		
				{
					name = L"Markus Gebauer",
					text =
[[
OSTLAND
9.2k, 30.3k
Talk to "Markus Gebauer" a cowering man, next to the 4 outhouses, just south of "Ferlangen" Chaos chapter 5.
]],
				},
			
				{
					name = L"Litany of Death",
					text =
[[
OSTLAND
15.1k, 28.8k
Click on "Mildewy Page", inside "Ferlangen Crypt" major landmark, in the eastern large chamber, on the ground to the right of the side altar thing.
]],
				},

				{
					name = L"Song of the Rose",
					text =
[[
OSTLAND
2.8k, 20k
Click on "Song of the Rose" a book inside "Lost Cavern" minor landmark at the very back of the cave.
]],
				},

				{
					name = L"Blackthorn Key",
					text =
[[
OSTLAND
11.2k, 23.1k
Click on "Crypt Keys" on the side of the crypt, which will teleport you inside.
]],
				},
				
				{
					name = L"Blackthorn Crypt",
					text =
[[
OSTLAND
12k, 24k
Click on "Memorial Plaque" in the middle of the crypt room.
]],
				},
				
				{
					name = L"Blackthorn Rite",
					text =
[[
OSTLAND
12.7k, 24.7k
Click on "Apothecary's Vials" on the floor, to the left of the archway, going to the left set of stairs inside the crypt.
]],
				},
			},
		},

		{
			name = L"Marsh Choppa",
			entries =
			{
				{
					name = L"Marsh Choppa",
					text =
[[
MARSHES OF MADNESS
32.8k 5.1k
Interact with 'Marsh Axe', an axe in a helm, inside 'Marshfang Spider Cave' (entrance at 28k 7k).
]],
				},
			},
		},

		{
			name = L"Missions of Mercy",
			entries =
			{
				{
					name = L"Lady in Distress",
					text =
[[
Not Implemented
NORDLAND
19.4k, 28.5k
Kill "Pub Rat" round the back of the tavern at Grey Lady Coaching Inn, Empire chapter 2 camp.
]],
				},

				{
				realm = TTitan.Data.Realm.ORDER,
				name = L"Waterbearer",
					text =
[[
Not Verified
NORDLAND
20.1k, 26.5k
Click on "Water Bucket" next to the well in the middle of Grey Lady Coaching Inn, Empire chapter 2 camp.
]],
				},

				{
				realm = TTitan.Data.Realm.ORDER,
				name = L"Tending the Sick",
					text =
[[
Not Verified
NORDLAND
33.1k, 18.5k
Click on "Supply Chest" a crate by one of the wagons, accept the quest and head west along the road to the tent outside the camp. Target the "Sick Peasant" NPC in the tent, and use the item "Food" in your quest items. Talk to "Doctor Heino" an NPC walking around the tent area, to complete the quest and get the unlock.
]],
				},

				{
				realm = TTitan.Data.Realm.ORDER,
				name = L"Missions of Mercy",
					text =
[[
Not Verified
Complete "Lady in Distress", "Waterbearer" and "Tending the Sick" and this will unlock.
]],
				},
			},
		},

		{
			name = L"Mourkain Treasure",
			entries =
			{
				{
					name = L"Crystal Skull",
					text =
[[
MARSHES OF MADNESS
55.6k, 57k
Click on "Crystal Skull", it is a very small white skull, between the pillar and the rock.
]],
				},
				
		  	{
					name = L"Cult of Ushoran",
					text =
[[
Not Implemented for DESTRUCTION, Not Verified for ORDER
MARSHES OF MADNESS
55.6k, 57k
Click on "Crystal Skull" to start the quest "Legend of the Crystal Skull". Then head to "The Tower of Neborhest" major landmark, enter the tower and go down 2 level to the bottom floor and click on the "Mourkain Reliquary" in the centre of the room. Complete the quest for the unlock.
]],
				},
				
				{
					name = L"A Useful Pawn",
					text =
[[
Not Implemented for DESTRUCTION, Not Verified for ORDER
MARSHES OF MADNESS
Kill "Raxsus Fleshfeeder" a mob that spawns at the back of the room, when clicking on the "Mourkain Reliquary" in the above unlock.
]],
				},
			},
		},

		{
			name = L"Raiders ",
			entries =
			{
				{
					name = L"Northern Raiding Route",
					text =
[[
CHRACE
9k, 23.1k
Approach the back of the cave in the final room of "Emlyria Caverns" minor landmark.
]],
				},
			},
		},

		{
			name = L"Ranks of the Damned",
			entries =
			{
				{
					name = L"Ranks of the Damned, Kalarthay the Mad",
					text =
[[
THE INEVITABLE CITY
14.3k 37.3k
Interact with the pile of books 'Ranks of the Damned' within the Lyceum south wing.
]],
				},

				{
					name = L"Ranks of the Damned, Ileon Blackwing",
					text =
[[
THE INEVITABLE CITY
48k 40k
Interact with the 'Fount of Souls'.
]],
				},

				{
					name = L"Ranks of the Damned, Maesius Blackwing",
					text =
[[
Not Implemented
]],
				},

				{
					name = L"Ranks of the Damned, Darul Kingslayer",
					text =
[[
Not Implemented
]],
				},
			},
		},

		{
			name = L"Riphorn Challenge",
			entries =
			{
				{
					name = L"Riphorn Challenge",
					text =
[[
TROLL COUNTRY
63.8k 48.5k
Interact with the pike with skulls 'Urghu Foes'.
]],
				},

				{
					name = L"Blood Rite",
					text =
[[
TROLL COUNTRY
63.8k 48k
Kill 'Urghu Redhorn', right next to the Urghu Foes. He drops a Pocket Item 'Redhorn's Skull', equip it for the unlock.
]],
				},
			},
		},

		{
			name = L"Seven Lords and Seven Sons",
			entries =
			{
				{
					name = L"The Grave of Ronal Grumman",
					text =
[[
OSTLAND
60k 59.9k
Interact with the 'Grave' among other graves of the graveyard in front of The Catacombs south entrance.
]],
				},

				{
					name = L"The grave of Bomit Bumbleshoot",
					text =
[[
REIKLAND
1.6k, 5.9k
Interact with the 'Grave' above the cliff behind the crypt entrance.
]],
				},

				{
					name = L"The grave of Barnabas Hirtzel",
					text =
[[
PRAAG
27.4k, 59.2k
Interact with the 'Grave' among other graves of Russenscheller Graveyard Battlefield Objective.
]],
				},

				{
					name = L"The grave of Faustus Kummel",
					text =
[[
NORDLAND
61.5k 20.2k
Interact with the 'Grave', among other graves.
]],
				},

				{
					name = L"The grave of Xavier Nuhr",
					text =
[[
TALABECLAND
24.4k 27.3k
Interact with the 'Grave'.
]],
				},

				{
					name = L"The grave of Kazagund Alnirson",
					text =
[[
KADRIN VALLEY
12.1k 31.6k
Interact with the 'Grave' behind a dwarf house.
]],
				},

				{
					name = L"The grave of Mororthel Hawkwood",
					text =
[[
THE BLIGHTED ISLE
39.5k 34.6k
Interact with the 'Grave'.
]],
				},
				
				{
					name = L"The grave of Hanse Grumman",
					text =
[[
CHAOS WASTES
61.8k 14.5k
Interact with the 'Grave' on the top of the mountains.
]],
				},

				{
					name = L"The grave of Bilton Bumbleshoot",
					text =
[[
TALABECLAND
18k 27.6k
Interact with the 'Grave'.
]],
				},

				{
					name = L"The grave of Konrad Hirtzel",
					text =
[[
ALTDORF
33.2k 34.4k
Interact with the 'Grave'.
]],
				},

				{
					name = L"The grave of Fabian Kummel",
					text =
[[
THE INEVITABLE CITY
47.2k 39.2k
Interact with the 'Grave'.
]],
				},

				{
					name = L"The grave of Nicodemus Nuhr",
					text =
[[
REIKLAND
35.7k 11.6k
Interact with the 'Grave' above the cliff.
]],
				},

				{
					name = L"The grave of Skordin Kazagundson",
					text =
[[
THE BADLANDS
57.4k 54.1k
Interact with the 'Grave' on the left of the cave entrance, behind a bush and next to a tree.
]],
				},

				{
					name = L"The grave of Galdulrel Hawkwood",
					text =
[[
DRAGONWAKE
31.1k 37.3k
Interact with the 'Grave'.
]],
				},
			},
		},

		{
			name = L"The Mysterious M.B.",
			entries =
			{
		  	{
				realm = TTitan.Data.Realm.ORDER,
				name = L"Precious Flask",
					text =
[[
Not Verified
THE BLIGHTED ISLE
39.5k 1.9k
Interact with the bottles 'Precious Flask' in High Elf Chapter 1. Interacting with it will trigger the unlock. If you have the quest, it will drop a Pocket Item 'Precious Flask'. Equip it for the unlock 'The Mysterious M.B.'.
]],
				},

		  	{
				realm = TTitan.Data.Realm.ORDER,
				name = L"Rare Flask",
					text =
[[
Not Verified
EKRUND
45.4k 29.8k
Interact with the bottles 'Rare Flask' inside Redhammer Pub of Dwarf Chapter 2. It is on the right side when you enter, on some barrels on the left of the fireplace. Interacting with it will trigger the unlock. If you have the quest, it will drop a Pocket Item 'Rare Flask'. Equip it for the unlock 'The Mysterious M.B.'.
]],
				},
				
		  	{
				realm = TTitan.Data.Realm.ORDER,
				name = L"Unique Flask",
					text =
[[
Not Verified
NORDLAND
33k 18.5k
Interact with the bottles 'Unique Flask'Empire Chapter 3. It is on some crates, next to carts. Interacting with it will trigger the unlock. If you have the quest, it will drop a Pocket Item 'Rare Flask'. Equip it for the unlock 'The Mysterious M.B.'.
]],
				},
				
		  	{
				realm = TTitan.Data.Realm.ORDER,
				name = L"The Mysterious M.B.",
					text =
[[
Not Verified
With the quest, interact with 'Precious Flask' in The Blighted Isle, 'Rare Flask' in Ekrund or 'Unique Flask' in Nordland. It will drop Pocket Items with respective flasks names, equip one of them to trigger the unlock.
]],
				},
				
		  	{
				realm = TTitan.Data.Realm.ORDER,
				name = L"Less Than Meets the Eye",
					text =
[[
Not Verified
MARSHES OF MADNESS
57k 36.2k
Interact with the bottles 'Dust Covered Flasks', inside the 'Cave' north of Dwarf Chapter 9. It is at the end of the right wing when you enter, behind a pillar.
]],
				},
				
			 	{
				realm = TTitan.Data.Realm.ORDER,
				name = L"M.B. Shipping Co.",
					text =
[[
Not Verified
BARAK VARR
25.4k 22.1k
Interact with the bottles 'Sand Covered Flasks' between big rocks.
]],
				},
				
		  	{
				realm = TTitan.Data.Realm.ORDER,
				name = L"The Mysterious M.B. (continued)",
					text =
[[
Not Verified
Equip the Trophy reward 'Bitterstone Mug' of the quest 'The Mysterious M.B.'.
]],
				},
				
		  	{
				realm = TTitan.Data.Realm.DESTRUCTION,
				name = L"Precious Flask",
					text =
[[
THE BLIGHTED ISLE
14k 52.6k
Interact with the bottles 'Precious Flask' in Dark Elf Chapter 3. It is at the southeast of the camp, behind a small tent, hidden under a small tree at the entrance of the tower. Interacting with it will trigger the unlock. If you have the quest, it will drop a Pocket Item 'Precious Flask'. Equip it for the unlock 'The Mysterious M.B.'.
]],
				},

		  	{
				realm = TTitan.Data.Realm.DESTRUCTION,
				name = L"Rare Flask",
					text =
[[
EKRUND
49.2k 27.2k
Interact with the bottles 'Rare Flask' on a crate above a small hill. Interacting with it will trigger the unlock. If you have the quest, it will drop a Pocket Item 'Rare Flask'. Equip it for the unlock 'The Mysterious M.B.'.
]],
				},
				
		  	{
				realm = TTitan.Data.Realm.DESTRUCTION,
				name = L"Unique Flask",
					text =
[[
NORDLAND
36.2k 18.8k
Interact with the bottles 'Unique Flask'. It is next to a tree, a 'Dead Dwarf' and a broken cart with crates. Interacting with it will trigger the unlock. If you have the quest, it will drop a Pocket Item 'Rare Flask'. Equip it for the unlock 'The Mysterious M.B.'.
]],
				},
				
		  	{
				realm = TTitan.Data.Realm.DESTRUCTION,
				name = L"The Mysterious M.B.",
					text =
[[
With the quest, interact with 'Precious Flask' in The Blighted Isle, 'Rare Flask' in Ekrund or 'Unique Flask' in Nordland. It will drop Pocket Items with respective flasks names, equip one of them to trigger the unlock.
]],
				},
				
		  	{
				realm = TTitan.Data.Realm.DESTRUCTION,
				name = L"Less Than Meets the Eye",
					text =
[[
MARSHES OF MADNESS
57k 36.2k
Interact with the bottles 'Dust Covered Flasks', inside the 'Cave' north of Dwarf Chapter 9. It is at the end of the right wing when you enter, behind a pillar.
]],
				},
				
			 	{
				realm = TTitan.Data.Realm.DESTRUCTION,
				name = L"M.B. Shipping Co.",
					text =
[[
BARAK VARR
25.4k 22.1k
Interact with the bottles 'Sand Covered Flasks' between big rocks.
]],
				},
				
		  	{
				realm = TTitan.Data.Realm.DESTRUCTION,
				name = L"The Mysterious M.B. (continued)",
					text =
[[
Not Verified
Equip the Trophy reward 'Stunty Mug' of the quest 'Da Stunty Mystery'.
]],
				},
			},
		},

		{
			name = L"Visions",
			entries =
			{
				{
					name = L"Visions of Danger",
					text =
[[
CHRACE
47.7k, 49.7k
Approach the centre of the pool just south of "Lyriana's Repose" major landmark.
]],
				},

				{
					name = L"Importance of Life",
					text =
[[
CHRACE
48.3k, 54.8k
Click on "Slain Chracian" slumped against the broken altar/fountain thing.
]],
				},
			},
		},

		{
			name = L"Wanderers Among the Lost",
			entries =
			{
				{
					name = L"???",
					text =
[[
THE LOST VALE
???
]],
				},

				{
					name = L"To See the Views",
					text =
[[
THE LOST VALE
41.8k, 40.8k
Click on "Elven Poetry" near the 4 pads to unlock the barrier, on the cliff edge looking down on the route up.
]],
				},
				
				{
					name = L"???",
					text =
[[
THE LOST VALE
???
]],
				},
				
				{
					name = L"To Hear the Waters",
					text =
[[
THE LOST VALE
36.8k, 7.6k - In The Lost Vale
Click on "Elven Poetry" at the base of the tree, overlooking the waterfall.
]],
				},	
				
				{
					name = L"???",
					text =
[[
THE LOST VALE
???
]],
				},				
			},
		},

		{
			name = L"Will of the Assured",
			entries =
			{
				{
				realm = TTitan.Data.Realm.ORDER,
				name = L"The Rune of Cython",
					text =
[[
Not Verified
THE BLIGHTED ISLE
59k, 12k
Click on "Rune of Cython" a white runestone near the cliff edge. Head round the back of one of the towers in "House Arkaneth" PQ to reach it.
]],
				},

				{
				realm = TTitan.Data.Realm.ORDER,
				name = L"The Asking",
					text =
[[
Not Verified
THE BLIGHTED ISLE
59k, 12k
Talk to "Sprite of Cython" one of the NPC Spites that spawns with you click on "Rune of Cython".
]],
				},
	
				{
				realm = TTitan.Data.Realm.ORDER,
				name = L"The Testing",
					text =
[[
Not Verified
THE BLIGHTED ISLE
59k, 12k
Click on "Rune of Cython" a white runestone near the cliff edge. Head round the back of one of the towers in "House Arkaneth" PQ to reach it.
]],
				},
				
				{
				realm = TTitan.Data.Realm.ORDER,
				name = L"The Rune of Cython",
					text =
[[
CHRACE
13k 27.4k
Interact with 'Rune of Cython', a white stone with a rune. It is located between some trees above the hill.
]],
				},

				{
				realm = TTitan.Data.Realm.DESTRUCTION,
				name = L"The Asking",
					text =
[[
CHRACE
13k 27.4k
Interact with 'Rune of Cython', a white stone with a rune. It is located between some trees above the hill.
]],
				},
	
				{
				realm = TTitan.Data.Realm.DESTRUCTION,
				name = L"The Testing",
					text =
[[
CHRACE
10.9k 47.5k
Interact with 'Rune of Cython', another white stone with a rune. It is located between some trees above a hill east of the road.
]],
				},
			},
		},

		{
			name = L"Wolfenburg",
			entries =
			{
				{
					name = L"Wolfenburg",
					text =
[[
OSTLAND
45.3k, 57.8k
Click on "Wolfenburg Noticeboard" in the middle "Wolfenburg" major landmark.
]],
				},
			},
		},
	},
}
