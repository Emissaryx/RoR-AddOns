<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
    <UiMod name="Tome Titan" version="v2.4.4" date="28/06/2026">
        <Author name="Oscarr / Squigy / Aenathel" email="oscarr_d24@yahoo.com / ngkaijie@hotmail.com / aenathel@dogsofwarguild.eu" />
        <Description text="Tome Titan is the compiled information of Bestiary, History & Lore, and Noteworthy Persons sections of your Tome of Knowledge." />
		<VersionSettings gameVersion="1.4.8" windowsVersion="2.0" savedVariablesVersion="2.0" />

		<Dependencies>
			<Dependency name="LibSlash" />
        </Dependencies>

		<Files>
			<File name="TTitan.lua" />

			<File name="TTitan_UI.lua" />
			<File name="TTitan_UI.xml" />
			<File name="TTitan_TTButton.lua" />
			<File name="TTitan_TTButton.xml" />
			<File name="TTitan_Data.lua" />
			
			<File name="TTBar\TTmodules.lua" />

			<File name="Data\Credits.lua" />

			<File name="Data\Bestiary_DvG.lua" />
			<File name="Data\Bestiary_EvC.lua" />
			<File name="Data\Bestiary_HEvDE.lua" />

			<File name="Data\History_DvG.lua" />
			<File name="Data\History_EvC.lua" />
			<File name="Data\History_HEvDE.lua" />

			<File name="Data\Noteworthy_DvG.lua" />
			<File name="Data\Noteworthy_EvC.lua" />
			<File name="Data\Noteworthy_HEvDE.lua" />

			<File name="Data\Lairs.lua" />
			<File name="Data\Explorations.lua" />
			<File name="Data\Pursuits.lua" />
			<File name="Data\LoTD.lua" />
			<File name="Data\Kills.lua" />
		</Files>

        <OnInitialize>
			<CreateWindow name="TTitanUI" show="false" />
			<CreateWindow name="TTitanTTButtonWindow" show="true" />

			<CallFunction name="TTitan.Init" />
			<CallFunction name="TTitan.UI.Init" />
			
        </OnInitialize>

		<OnUpdate>
			<CallFunction name="TTitan.UI.OnUpdate" />
		</OnUpdate>
		
		<SavedVariables>
			<SavedVariable name="TTitan.Settings" />
		</SavedVariables>
    </UiMod>
</ModuleFile>
