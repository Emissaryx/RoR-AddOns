Ding = {} --Ding 1.3 , Now with 90% less code
function Ding.Initialize()
	LibSlash.RegisterSlashCmd("Ding",Ding.LevelUp)
	RegisterEventHandler(SystemData.Events.ENTER_WORLD, "ding.unload" )
	RegisterEventHandler(SystemData.Events.INTERFACE_RELOADED, "ding.unload" )	
	RegisterEventHandler(SystemData.Events.PLAYER_ZONE_CHANGED, "ding.unload")
	RegisterEventHandler(SystemData.Events.LOADING_BEGIN, "ding.unload")
	RegisterEventHandler(SystemData.Events.LOADING_END, "ding.unload")	
	TextLogAddEntry("Chat", 0, L"<icon57> Ding v1.3 Loaded")
end
function ding.unload()
	UnregisterEventHandler(SystemData.Events.PLAYER_CAREER_RANK_UPDATED, "Ding.LevelUp")
	UnregisterEventHandler(SystemData.Events.PLAYER_RENOWN_RANK_UPDATED, "Ding.LevelUp")
	RegisterEventHandler(SystemData.Events.PLAYER_POSITION_UPDATED,"Ding.load" )
end
function Ding.load()
	RegisterEventHandler(SystemData.Events.PLAYER_CAREER_RANK_UPDATED, "Ding.LevelUp")
	RegisterEventHandler(SystemData.Events.PLAYER_RENOWN_RANK_UPDATED, "Ding.LevelUp")
	UnregisterEventHandler(SystemData.Events.PLAYER_POSITION_UPDATED,"Ding.load" )
end
function Ding.LevelUp()
	SendChatText(L"/shout !Ding   <br>"..L"<icon"..towstring(Icons.GetCareerIconIDFromCareerLine(tonumber(GameData.Player.career.line)))..L">"..towstring(CreateHyperLink(L"PLAYER:"..GameData.Player.name,towstring(GameData.Player.name), {0,255,0},{}))..L" ("..towstring(GameData.Player.Renown.curTitle)..L") <icon52>"..towstring(CreateHyperLink(L"0",L"Level: "..towstring(GameData.Player.level), {125,255,125},{}))..L" <icon45>"..towstring(CreateHyperLink(L"0",L"Rank: "..towstring(GameData.Player.Renown.curRank), {255,125,255},{})), L"")
end