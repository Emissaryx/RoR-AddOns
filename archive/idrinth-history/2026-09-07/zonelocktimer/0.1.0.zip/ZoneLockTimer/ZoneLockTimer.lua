ZoneLockTimer = ZoneLockTimer or {}

local Timer = ZoneLockTimer

Timer.TEMPLATE = "ZoneLockTimer_Template"
Timer.WINDOW_PREFIX = "ZoneLockTimer_"
Timer.REFRESH_INTERVAL = 0.25
Timer.SLASH_RETRY_LIMIT = 10
Timer.LOST_SECONDS = 2
Timer.TEST_SECONDS = 300
Timer.MAX_VISIBLE_SECONDS = 50
Timer.POST_LOCK_DETECTION_PAUSE_SECONDS = 30
Timer.WIDTH = 50
Timer.HEIGHT = 18
Timer.REAL_ANNOUNCE_CHANNEL = "/1"
Timer.TEST_ANNOUNCE_CHANNEL = "/o"
Timer.ANNOUNCE_TEXT = "ZONE LOCK"
Timer.CHAT_TAG_TEXT = "ZoneLockTimer"
Timer.CHAT_TAG_COLOR = "255,204,102"
Timer.ORDER_COLOR = { r = 107, g = 191, b = 255 }
Timer.DESTRO_COLOR = { r = 255, g = 105, b = 105 }

Timer._elapsed = Timer._elapsed or 0
Timer._slashRegistered = Timer._slashRegistered or false
Timer._slashTries = 0
Timer._states = Timer._states or {}
Timer._lockPauseRemaining = Timer._lockPauseRemaining or 0
Timer._lockedObjectiveZones = Timer._lockedObjectiveZones or {}

local LOCKED_BO_STATES = {
    [6] = true,
    [8] = true,
    [9] = true,
    [10] = true,
}

local function toString(value)
    if value == nil then
        return ""
    end

    if type(value) == "string" then
        return value
    end

    if type(value) == "number" or type(value) == "boolean" then
        return tostring(value)
    end

    if type(WStringToString) == "function" then
        local ok, text = pcall(WStringToString, value)
        if ok and type(text) == "string" then
            return text
        end
    end

    local ok, text = pcall(tostring, value)
    if ok and type(text) == "string" then
        return text
    end

    return ""
end

local function toWString(value)
    if type(towstring) == "function" then
        local ok, text = pcall(towstring, toString(value))
        if ok and text ~= nil then
            return text
        end
    end

    return toString(value)
end

local function getTag()
    return toWString(
        "[<LINK data=\"\" text=\""
            .. Timer.CHAT_TAG_TEXT
            .. "\" color=\""
            .. Timer.CHAT_TAG_COLOR
            .. "\">]: "
    )
end

local function chatPrint(message)
    local line = getTag() .. toWString(message)
    local printed = false

    if type(TextLogAddEntry) == "function" then
        local ok = pcall(TextLogAddEntry, "Chat", 0, line)
        printed = ok
    end

    if not printed and type(EA_ChatWindow) == "table" and type(EA_ChatWindow.Print) == "function" then
        pcall(EA_ChatWindow.Print, line)
    end
end

local function windowExists(windowName)
    if windowName == nil or windowName == "" then
        return false
    end

    if type(DoesWindowExist) ~= "function" then
        return true
    end

    local ok, exists = pcall(DoesWindowExist, windowName)
    return ok and exists == true
end

local function isNormalZone(zoneId)
    local zoneNumber = tonumber(zoneId)
    if zoneNumber == nil then
        return false
    end

    if type(RoR_SoR) == "table" then
        if type(RoR_SoR.Forts) == "table" and RoR_SoR.Forts[zoneNumber] ~= nil then
            return false
        end
        if type(RoR_SoR.City) == "table" and RoR_SoR.City[zoneNumber] ~= nil then
            return false
        end
    end

    return true
end

local function getZoneWindow(zoneId)
    local zoneNumber = tonumber(zoneId)
    if zoneNumber == nil then
        return nil
    end

    return "SoR_" .. tostring(zoneNumber)
end

local function isOpenZone(zoneId)
    if type(RoR_SoR) ~= "table" or type(RoR_SoR.OpenZones) ~= "table" then
        return false
    end

    return RoR_SoR.OpenZones[tostring(zoneId)] ~= nil or RoR_SoR.OpenZones[tonumber(zoneId)] ~= nil
end

local function getZonePairingTier(zoneId)
    local zoneNumber = tonumber(zoneId)
    if zoneNumber == nil or type(GetCampaignZoneData) ~= "function" then
        return nil, nil
    end

    local ok, data = pcall(GetCampaignZoneData, zoneNumber)
    if ok and type(data) == "table" then
        return tonumber(data.pairingId), tonumber(data.tierId)
    end

    return nil, nil
end

local function isPlayerInSamePairingTier(zoneId)
    local zoneNumber = tonumber(zoneId)
    if zoneNumber == nil or type(GameData) ~= "table" or type(GameData.Player) ~= "table" then
        return false
    end

    local playerZone = tonumber(GameData.Player.zone)
    if playerZone == nil or playerZone == 0 then
        return false
    end

    if playerZone == zoneNumber then
        return true
    end

    local playerPairing, playerTier = getZonePairingTier(playerZone)
    local zonePairing, zoneTier = getZonePairingTier(zoneNumber)
    return playerPairing ~= nil
        and zonePairing ~= nil
        and playerTier ~= nil
        and zoneTier ~= nil
        and playerPairing == zonePairing
        and playerTier == zoneTier
end

local function getOverlayName(zoneId)
    local zoneNumber = tonumber(zoneId)
    if zoneNumber == nil then
        return nil
    end

    return Timer.WINDOW_PREFIX .. tostring(zoneNumber)
end

local function getState(zoneId)
    local zoneNumber = tonumber(zoneId)
    if zoneNumber == nil then
        return nil
    end

    if type(Timer._states[zoneNumber]) ~= "table" then
        Timer._states[zoneNumber] = {}
    end

    return Timer._states[zoneNumber]
end

local function ensureOverlay(zoneId)
    local zoneWindow = getZoneWindow(zoneId)
    local overlayName = getOverlayName(zoneId)
    if zoneWindow == nil or overlayName == nil or not windowExists(zoneWindow) then
        return nil
    end

    local created = false
    if not windowExists(overlayName) then
        if type(CreateWindowFromTemplate) ~= "function" then
            return nil
        end

        local ok = pcall(CreateWindowFromTemplate, overlayName, Timer.TEMPLATE, zoneWindow)
        if not ok or not windowExists(overlayName) then
            return nil
        end
        created = true
    end

    if created then
        if type(WindowClearAnchors) == "function" then
            pcall(WindowClearAnchors, overlayName)
        end
        if type(WindowAddAnchor) == "function" then
            pcall(WindowAddAnchor, overlayName, "topright", zoneWindow, "topright", -8, 22)
        end
        if type(WindowSetDimensions) == "function" then
            pcall(WindowSetDimensions, overlayName, Timer.WIDTH, Timer.HEIGHT)
        end
        if type(LabelSetTextColor) == "function" then
            pcall(LabelSetTextColor, overlayName .. "Text", 255, 255, 255)
            pcall(LabelSetTextColor, overlayName .. "TextBG", 0, 0, 0)
        end
    end

    return overlayName
end

local function setOverlayText(overlayName, state, text)
    if state.lastText == text then
        return
    end

    local labelText = toWString(text)
    if type(LabelSetText) == "function" then
        pcall(LabelSetText, overlayName .. "Text", labelText)
        pcall(LabelSetText, overlayName .. "TextBG", labelText)
    end
    state.lastText = text
end

local function showOverlay(zoneId, text, mode)
    local overlayName = ensureOverlay(zoneId)
    if overlayName == nil then
        return false
    end

    local state = getState(zoneId)
    if state == nil then
        return false
    end

    setOverlayText(overlayName, state, text)
    if type(WindowSetShowing) == "function" and state.showing ~= true then
        pcall(WindowSetShowing, overlayName, true)
    end
    state.showing = true
    state.mode = mode
    return true
end

local function hideOverlay(zoneId)
    local state = getState(zoneId)
    local overlayName = getOverlayName(zoneId)
    if state == nil or overlayName == nil then
        return
    end

    if type(WindowSetShowing) == "function" and state.showing ~= false and windowExists(overlayName) then
        pcall(WindowSetShowing, overlayName, false)
    end

    state.showing = false
    state.mode = nil
    state.lastText = nil
    state.lostRemaining = nil
end

local function startLost(zoneId)
    local state = getState(zoneId)
    if state == nil or state.mode ~= "real" then
        return
    end

    if windowExists(getZoneWindow(zoneId)) and showOverlay(zoneId, "lost", "lost") then
        state.lostRemaining = Timer.LOST_SECONDS
    else
        hideOverlay(zoneId)
    end
end

local function formatSeconds(seconds)
    local value = math.ceil(tonumber(seconds) or 0)
    if value < 0 then
        value = 0
    end

    return tostring(value) .. "s"
end

local function getOpenZoneIds()
    local zones = {}
    if type(RoR_SoR) ~= "table" or type(RoR_SoR.OpenZones) ~= "table" then
        return zones
    end

    if type(RoR_SoR.StackSort) == "table" then
        for _, entry in ipairs(RoR_SoR.StackSort) do
            local zoneId = tonumber(type(entry) == "table" and entry.Zone)
            if zoneId ~= nil and isOpenZone(zoneId) and isNormalZone(zoneId) and windowExists(getZoneWindow(zoneId)) then
                zones[#zones + 1] = zoneId
            end
        end
    end

    if #zones == 0 then
        for zoneKey, _ in pairs(RoR_SoR.OpenZones) do
            local zoneId = tonumber(zoneKey)
            if zoneId ~= nil and isNormalZone(zoneId) and windowExists(getZoneWindow(zoneId)) then
                zones[#zones + 1] = zoneId
            end
        end

        table.sort(zones)
    end

    return zones
end

local function getFirstOpenZoneId()
    local zones = getOpenZoneIds()
    return zones[1]
end

local function getKeepOwner(zoneId)
    if type(RoR_SoR) ~= "table" or type(RoR_SoR.KEEP_IDs) ~= "table" then
        return nil
    end

    local keeps = RoR_SoR.KEEP_IDs[tostring(zoneId)] or RoR_SoR.KEEP_IDs[tonumber(zoneId)]
    if type(keeps) ~= "table" then
        return nil
    end

    local keep1 = type(keeps[1]) == "table" and tonumber(keeps[1].Owner) or nil
    local keep2 = type(keeps[2]) == "table" and tonumber(keeps[2].Owner) or nil
    if keep1 ~= nil and keep1 == keep2 and (keep1 == 1 or keep1 == 2) then
        return keep1
    end

    return nil
end

local function isLockedBoState(state)
    return LOCKED_BO_STATES[tonumber(state)] == true
end

local function countOwnedObjectives(zoneId, realm)
    if type(RoR_SoR) ~= "table" or type(RoR_SoR.BO_IDs) ~= "table" then
        return 0
    end

    local zoneKey = tostring(zoneId)
    local objectives = RoR_SoR.BO_IDs[zoneKey] or RoR_SoR.BO_IDs[tonumber(zoneId)]
    if type(objectives) ~= "table" then
        return 0
    end

    local states = type(RoR_SoR.BO_States) == "table" and (RoR_SoR.BO_States[zoneKey] or RoR_SoR.BO_States[tonumber(zoneId)]) or nil
    local timers = type(RoR_SoR.Timers) == "table" and (RoR_SoR.Timers[zoneKey] or RoR_SoR.Timers[tonumber(zoneId)]) or nil
    local count = 0
    for index, objective in pairs(objectives) do
        if type(objective) == "table" and tonumber(objective.Owner) == realm then
            local state = type(states) == "table" and tonumber(states[index]) or nil
            local timer = type(timers) == "table" and tonumber(timers[index]) or nil
            if state ~= 4 and not isLockedBoState(state) and (timer == nil or timer <= 0) then
                count = count + 1
            end
        end
    end

    return count
end

local function hasLockedObjectives(zoneId)
    if type(RoR_SoR) ~= "table" or type(RoR_SoR.BO_IDs) ~= "table" or type(RoR_SoR.BO_States) ~= "table" then
        return false
    end

    local zoneKey = tostring(zoneId)
    local objectives = RoR_SoR.BO_IDs[zoneKey] or RoR_SoR.BO_IDs[tonumber(zoneId)]
    local states = RoR_SoR.BO_States[zoneKey] or RoR_SoR.BO_States[tonumber(zoneId)]
    if type(objectives) ~= "table" or type(states) ~= "table" then
        return false
    end

    for index, objective in pairs(objectives) do
        if type(objective) == "table" and tonumber(objective.Owner) ~= 0 and isLockedBoState(states[index]) then
            return true
        end
    end

    return false
end

local function isRealTimerActive(zoneId)
    local state = Timer._states[tonumber(zoneId)]
    return type(state) == "table" and state.mode == "real"
end

local function isDetectionPaused()
    return (tonumber(Timer._lockPauseRemaining) or 0) > 0
end

local function updateDetectionPause(delta)
    local remaining = tonumber(Timer._lockPauseRemaining) or 0
    if remaining <= 0 then
        Timer._lockPauseRemaining = 0
        return
    end

    remaining = remaining - (tonumber(delta) or 0)
    if remaining < 0 then
        remaining = 0
    end
    Timer._lockPauseRemaining = remaining
end

local function pauseDetectionAfterLock()
    Timer._lockPauseRemaining = Timer.POST_LOCK_DETECTION_PAUSE_SECONDS
end

local function hideIfLocked(zoneId)
    if hasLockedObjectives(zoneId) then
        hideOverlay(zoneId)
        pauseDetectionAfterLock()
        return true
    end

    return false
end

local function updateLockedZoneTransitions()
    local foundLock = false
    local seenZones = {}

    for _, zoneId in ipairs(getOpenZoneIds()) do
        local locked = hasLockedObjectives(zoneId)
        local previous = Timer._lockedObjectiveZones[zoneId]
        if previous == false and locked then
            foundLock = true
        end

        Timer._lockedObjectiveZones[zoneId] = locked and true or false
        seenZones[zoneId] = true
    end

    for zoneId, _ in pairs(Timer._lockedObjectiveZones) do
        if seenZones[zoneId] ~= true then
            Timer._lockedObjectiveZones[zoneId] = nil
        end
    end

    if foundLock then
        pauseDetectionAfterLock()
    end
end

local function hideLockedTimerZones(testZoneId)
    for zoneId, state in pairs(Timer._states) do
        local zoneNumber = tonumber(zoneId)
        if zoneNumber ~= nil
            and zoneNumber ~= testZoneId
            and (state.mode == "real" or state.mode == "lost") then
            hideIfLocked(zoneNumber)
        end
    end
end

local function getEligibleZones(activeRealOnly)
    local zones = {}
    for _, zoneId in ipairs(getOpenZoneIds()) do
        local owner = getKeepOwner(zoneId)
        if owner ~= nil
            and isPlayerInSamePairingTier(zoneId)
            and countOwnedObjectives(zoneId, owner) >= 3
            and (activeRealOnly ~= true or isRealTimerActive(zoneId)) then
            zones[#zones + 1] = zoneId
        end
    end

    return zones
end

local function readPoolShift()
    return select(3, GetRewardPools())
end

local function getPoolShiftSeconds()
    if type(GetRewardPools) ~= "function" then
        return nil
    end

    local ok, shifting, seconds = pcall(readPoolShift)
    if ok ~= true or shifting ~= true then
        return nil
    end

    seconds = tonumber(seconds)
    if seconds == nil or seconds <= 0 then
        return nil
    end

    return seconds
end

local function updateTest(delta)
    if type(Timer._test) ~= "table" then
        return nil
    end

    local zoneId = tonumber(Timer._test.zoneId)
    if zoneId == nil or not windowExists(getZoneWindow(zoneId)) then
        Timer._test = nil
        hideOverlay(zoneId)
        return nil
    end

    Timer._test.remaining = math.max(0, (tonumber(Timer._test.remaining) or 0) - delta)
    if Timer._test.remaining <= 0 then
        Timer._test = nil
        hideOverlay(zoneId)
        return nil
    end

    showOverlay(zoneId, formatSeconds(Timer._test.remaining), "test")
    return zoneId
end

local function updateLostStates(delta, activeRealZones, testZoneId)
    for zoneId, state in pairs(Timer._states) do
        local zoneNumber = tonumber(zoneId)
        if state.mode == "lost" and activeRealZones[zoneNumber] ~= true and testZoneId ~= zoneNumber then
            if not isPlayerInSamePairingTier(zoneNumber) then
                hideOverlay(zoneNumber)
            elseif not hideIfLocked(zoneNumber) then
                state.lostRemaining = (tonumber(state.lostRemaining) or 0) - delta
                if state.lostRemaining <= 0 then
                    hideOverlay(zoneNumber)
                end
            end
        end
    end
end

function Timer.Refresh(delta)
    local elapsed = tonumber(delta) or Timer.REFRESH_INTERVAL
    local activeRealZones = {}
    local testZoneId = updateTest(elapsed)
    updateDetectionPause(elapsed)
    updateLockedZoneTransitions()
    hideLockedTimerZones(testZoneId)

    local eligibleZones = getEligibleZones(isDetectionPaused())
    local poolSeconds = nil

    if #eligibleZones > 0 then
        poolSeconds = getPoolShiftSeconds()
    end

    if poolSeconds ~= nil and poolSeconds <= Timer.MAX_VISIBLE_SECONDS then
        local text = formatSeconds(poolSeconds)
        for _, zoneId in ipairs(eligibleZones) do
            if zoneId ~= testZoneId then
                if showOverlay(zoneId, text, "real") then
                    activeRealZones[zoneId] = true
                end
            end
        end
    elseif poolSeconds ~= nil then
        for _, zoneId in ipairs(eligibleZones) do
            if zoneId ~= testZoneId then
                activeRealZones[zoneId] = true
                local state = Timer._states[zoneId]
                if type(state) == "table" and (state.mode == "real" or state.mode == "lost") then
                    hideOverlay(zoneId)
                end
            end
        end
    end

    updateLostStates(elapsed, activeRealZones, testZoneId)

    for zoneId, state in pairs(Timer._states) do
        local zoneNumber = tonumber(zoneId)
        if state.mode == "real" and activeRealZones[zoneNumber] ~= true and testZoneId ~= zoneNumber then
            if not isPlayerInSamePairingTier(zoneNumber) then
                hideOverlay(zoneNumber)
            elseif not hideIfLocked(zoneNumber) then
                startLost(zoneNumber)
            end
        end
    end
end

local function getActiveWindowName()
    if type(SystemData) == "table" then
        if type(SystemData.ActiveWindow) == "table" and type(SystemData.ActiveWindow.name) == "string" then
            return SystemData.ActiveWindow.name
        end
        if type(SystemData.MouseOverWindow) == "table" and type(SystemData.MouseOverWindow.name) == "string" then
            return SystemData.MouseOverWindow.name
        end
    end

    return ""
end

local function getZoneIdFromOverlayWindow(windowName)
    if type(windowName) ~= "string" then
        return nil
    end

    return tonumber(string.match(windowName, "^" .. Timer.WINDOW_PREFIX .. "(%d+)"))
end

local function getClickedZoneId()
    local zoneId = getZoneIdFromOverlayWindow(getActiveWindowName())
    if zoneId ~= nil then
        return zoneId
    end

    if type(SystemData) == "table" and type(SystemData.MouseOverWindow) == "table" then
        return getZoneIdFromOverlayWindow(SystemData.MouseOverWindow.name)
    end

    return nil
end

local function getRealmColor(realm)
    local realmNumber = tonumber(realm)
    if type(RoR_SoR) == "table" and type(RoR_SoR.RealmColors) == "table" then
        local color = RoR_SoR.RealmColors[(realmNumber or 0) + 1]
        if type(color) == "table" then
            local r = tonumber(color.r)
            local g = tonumber(color.g)
            local b = tonumber(color.b)
            if r ~= nil and g ~= nil and b ~= nil then
                return r, g, b
            end
        end
    end

    local color = Timer.ORDER_COLOR
    if realmNumber == 2 then
        color = Timer.DESTRO_COLOR
    end

    return color.r, color.g, color.b
end

local function getRandomTestRealm()
    if type(math) == "table" and type(math.random) == "function" then
        local realm = tonumber(math.random(1, 2))
        if realm == 1 or realm == 2 then
            return realm
        end
    end

    local previous = tonumber(Timer._testRealmFallback) or 0
    Timer._testRealmFallback = previous == 1 and 2 or 1
    return Timer._testRealmFallback
end

local function getColoredAnnouncementText(realm)
    local r, g, b = getRealmColor(realm)
    return "<LINK data=\"0\" color=\""
        .. tostring(r)
        .. ","
        .. tostring(g)
        .. ","
        .. tostring(b)
        .. "\" text=\""
        .. Timer.ANNOUNCE_TEXT
        .. "\">"
end

local function formatAnnouncementSeconds(seconds)
    local value = math.ceil(tonumber(seconds) or 0)
    if value < 0 then
        value = 0
    end

    return tostring(value) .. " seconds"
end

local function buildAnnouncementMessage(seconds, realm)
    return getColoredAnnouncementText(realm) .. " in " .. formatAnnouncementSeconds(seconds) .. "!"
end

local function getVisibleTimerState(zoneId)
    local state = getState(zoneId)
    if type(state) ~= "table" or state.showing ~= true then
        return nil
    end

    if state.mode ~= "real" and state.mode ~= "test" then
        return nil
    end

    return state
end

function Timer.GetAnnouncement(zoneId)
    local zoneNumber = tonumber(zoneId)
    if zoneNumber == nil then
        return nil
    end

    local state = getVisibleTimerState(zoneNumber)
    if state == nil then
        return nil
    end

    if state.mode == "test" then
        if type(Timer._test) ~= "table" or tonumber(Timer._test.zoneId) ~= zoneNumber then
            return nil
        end

        local seconds = tonumber(Timer._test.remaining)
        if seconds == nil or seconds <= 0 then
            return nil
        end

        return buildAnnouncementMessage(seconds, getRandomTestRealm()), Timer.TEST_ANNOUNCE_CHANNEL
    end

    local owner = getKeepOwner(zoneNumber)
    if owner ~= 1 and owner ~= 2 then
        return nil
    end

    if not isPlayerInSamePairingTier(zoneNumber) then
        return nil
    end

    local seconds = getPoolShiftSeconds()
    if seconds == nil or seconds <= 0 then
        return nil
    end

    return buildAnnouncementMessage(seconds, owner), Timer.REAL_ANNOUNCE_CHANNEL
end

function Timer.EmitAnnouncement(zoneId)
    local message, channel = Timer.GetAnnouncement(zoneId)
    if message == nil or channel == nil then
        chatPrint("Timer is no longer available to announce.")
        return false
    end

    if type(SendChatText) ~= "function" then
        chatPrint("SendChatText is unavailable; cannot announce timer.")
        return false
    end

    local ok = pcall(SendChatText, toWString(message), toWString(channel))
    if not ok then
        chatPrint("Unable to announce timer.")
        return false
    end

    return true
end

function Timer.OpenAnnouncementMenu(zoneId)
    local zoneNumber = tonumber(zoneId)
    if zoneNumber == nil or getVisibleTimerState(zoneNumber) == nil then
        return false
    end

    if type(EA_Window_ContextMenu) ~= "table"
        or type(EA_Window_ContextMenu.CreateContextMenu) ~= "function"
        or type(EA_Window_ContextMenu.AddMenuItem) ~= "function"
        or type(EA_Window_ContextMenu.Finalize) ~= "function" then
        return false
    end

    local overlayName = getOverlayName(zoneNumber) or getActiveWindowName()

    EA_Window_ContextMenu.CreateContextMenu(overlayName)
    EA_Window_ContextMenu.AddMenuItem(
        toWString("Announce ZONE LOCK countdown"),
        function() Timer.EmitAnnouncement(zoneNumber) end,
        false,
        true
    )
    EA_Window_ContextMenu.Finalize()
    return true
end

function Timer.OpenAnnouncementMenuFromClick()
    local zoneId = getClickedZoneId()
    if zoneId == nil then
        return false
    end

    return Timer.OpenAnnouncementMenu(zoneId)
end

local function printHelp()
    chatPrint("Commands: /zlock test [seconds] [zoneId], /zlock off, /zlock status, /zlock help.")
end

local function startTest(seconds, zoneId)
    local targetZone = tonumber(zoneId) or getFirstOpenZoneId()
    if targetZone == nil then
        chatPrint("No open RoR_SoR zone window is available for the test timer.")
        return
    end

    if not windowExists(getZoneWindow(targetZone)) then
        chatPrint("RoR_SoR zone window not found: " .. tostring(targetZone))
        return
    end

    local previousZone = type(Timer._test) == "table" and tonumber(Timer._test.zoneId) or nil
    if previousZone ~= nil and previousZone ~= targetZone then
        hideOverlay(previousZone)
    end

    Timer._test = {
        zoneId = targetZone,
        remaining = math.max(1, tonumber(seconds) or Timer.TEST_SECONDS),
    }
    showOverlay(targetZone, formatSeconds(Timer._test.remaining), "test")
    chatPrint("Test timer shown on zone " .. tostring(targetZone) .. ".")
end

local function stopTest()
    local zoneId = type(Timer._test) == "table" and tonumber(Timer._test.zoneId) or nil
    Timer._test = nil
    if zoneId ~= nil then
        hideOverlay(zoneId)
    end
    chatPrint("Test timer stopped.")
end

function Timer.HandleSlash(input)
    local args = {}
    for word in string.gmatch(toString(input), "%S+") do
        args[#args + 1] = string.lower(word)
    end

    local command = args[1] or ""
    if command == "" or command == "help" then
        printHelp()
    elseif command == "status" then
        local test = Timer._test
        if type(test) == "table" then
            chatPrint("Test timer: zone " .. tostring(test.zoneId) .. ", " .. formatSeconds(test.remaining) .. " remaining.")
        else
            chatPrint("No test timer active.")
        end
    elseif command == "off" then
        stopTest()
    elseif command == "test" then
        startTest(tonumber(args[2]) or Timer.TEST_SECONDS, tonumber(args[3]))
    else
        chatPrint("Unknown command: " .. command)
        printHelp()
    end
end

function Timer.TryRegisterSlash()
    if Timer._slashRegistered then
        return true
    end

    if Timer._slashTries >= Timer.SLASH_RETRY_LIMIT then
        return false
    end

    Timer._slashTries = Timer._slashTries + 1

    if type(LibSlash) ~= "table" then
        return false
    end

    local register = LibSlash.RegisterWSlashCmd
    if type(register) ~= "function" then
        register = LibSlash.RegisterSlashCmd
    end

    if type(register) ~= "function" then
        return false
    end

    register("zlock", function(input) Timer.HandleSlash(input) end)
    Timer._slashRegistered = true
    return true
end

function ZoneLockTimer.OnInitialize()
    Timer.TryRegisterSlash()
end

function ZoneLockTimer.OnTimerLButtonUp()
    return Timer.OpenAnnouncementMenuFromClick()
end

function ZoneLockTimer.OnTimerRButtonUp()
    return Timer.OpenAnnouncementMenuFromClick()
end

function ZoneLockTimer.OnUpdate(elapsed)
    local delta = tonumber(elapsed) or 0
    if delta <= 0 then
        return
    end

    Timer._elapsed = Timer._elapsed + delta
    if Timer._elapsed < Timer.REFRESH_INTERVAL then
        return
    end

    local refreshDelta = Timer._elapsed
    Timer._elapsed = 0

    if not Timer._slashRegistered and Timer._slashTries < Timer.SLASH_RETRY_LIMIT then
        Timer.TryRegisterSlash()
    end

    Timer.Refresh(refreshDelta)
end
