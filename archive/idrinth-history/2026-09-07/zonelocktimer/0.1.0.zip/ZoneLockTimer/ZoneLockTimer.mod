<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
    <UiMod name="ZoneLockTimer" version="0.1.0" date="2026-05-23">
        <Author name="Wholdar" />
        <Description text="Clickable zone-lock countdown." />
        <VersionSettings gameVersion="1.4.8" windowsVersion="0.1" />
        <Dependencies>
            <Dependency name="RoR_SoR" />
            <Dependency name="LibSlash" optional="true" forceEnable="true" />
        </Dependencies>
        <Files>
            <File name="ZoneLockTimer.xml" />
            <File name="ZoneLockTimer.lua" />
        </Files>
        <OnInitialize>
            <CallFunction name="ZoneLockTimer.OnInitialize" />
        </OnInitialize>
        <OnUpdate>
            <CallFunction name="ZoneLockTimer.OnUpdate" />
        </OnUpdate>
    </UiMod>
</ModuleFile>
