# ZoneLockTimer

ZoneLockTimer adds a clickable zone-lock countdown for your current pairing/tier.

## Usage

- Shows a timer when a zone in your current pairing/tier appears close to locking.
- Left-click or right-click the timer to announce `ZONE LOCK in xx seconds!` to `/1`.

## Requirements

`RoR_SoR` is required. `LibSlash` is optional.

## Notes

ZoneLockTimer reads `RoR_SoR` keep, BO, BO-state, and BO-timer caches, plus campaign zone data for the player pairing/tier check. It creates no overlay windows until a real timer is visible, and briefly delays new-zone detection after a lock.

## Changelog

### 0.1.0 - 2026-05-23 - Wholdar

- Initial release.
