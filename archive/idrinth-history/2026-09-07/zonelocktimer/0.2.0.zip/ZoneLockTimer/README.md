# ZoneLockTimer

ZoneLockTimer adds a small timer to SoR's open RvR zone rows during ZoneLock attempts.

## How It Works

- Grey timer: one realm holds both keeps in an open zone.
- White timer: that realm also holds at least three BOs, and the pool-shift timer is 45 seconds or less.
- Countdown seconds come from the game's pool-shift timer.
- `lost`: a white countdown stopped; returns to grey if the attempt continues.
- Timers only show for your current pairing and tier.
- Left-click or right-click a white timer to announce `ZONE LOCK in xx seconds!` to `/1`.

## Requirements

Requires `RoR_SoR`. `LibSlash` is optional.

## Changelog

### 0.2.0 - 2026-06-27

- Added a grey timer for ZoneLock attempts, shown when one realm holds both keeps.
- Changed the white countdown threshold from 50 seconds to 45 seconds.
- Returned stopped countdowns to the active attempt after `lost`.

### 0.1.0 - 2026-05-23

- Initial release.
