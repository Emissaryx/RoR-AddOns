--[[
IHYTM
Warhammer Online: Age of Reckoning UI modification that adds a simple
aggro meter.
    
Copyright (C) 2008-2010  Dillon "Rhekua" DeLoss
rhekua@msn.com		    www.rhekua.com

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
]]--

-- Special thanks to:
-- Pinkie
-- Khodan
-- Skatt
-- Naomh
-- Lux
-- Shover
-- Lokioden

IHYTM = {}

IHYTM.enabled = true
IHYTM.joinChannelName = L""
IHYTM.syncChannelName = L""
IHYTM.syncChannelNumber = 0

IHYTM.AggroTable = {}
IHYTM.PurgeAggroStack = {}
IHYTM.SyncMessageStack = {}
local deleteAggroTable = false -- called on end of combat

local leaveChannels = false -- forces the client to leave all IHYTM channels
local sendSyncMessage = false -- queues up the message to sync clients to the IHYTM channel for the group
local sendJoinMessage = false -- queues up the message requesting to join the IHYTM channel for the group
local sendResetMessage = false -- queues up the message requesting to reset the IHYTM aggro tables for the group

IHYTM.GuardAggroModifier = 0.35+0.35 -- doubled to make up for the 35% reduced aggro already applied from guard
						 -- used after a sync to funnel the aggro difference into you (if you are guarding)
IHYTM.GuardedAggroModifier = 0.65 -- aggro by 35% reduced when guarded
IHYTM.HealAggroModifier = 0.80
IHYTM.TauntAggroModifier = 6*375
IHYTM.DetauntAggroModifier = 0 -- testing shows detaunts don't permanently change your aggro at all... LAME!
IHYTM.DamageAggroModifier = 2

IHYTM.AggroModifiers = { -- TAUNTS
				 ["Taunt"] = { ["amount"] = IHYTM.TauntAggroModifier, ["AOE"] = false },
				 ["Challenge"] = { ["amount"] = IHYTM.TauntAggroModifier, ["AOE"] = true }, -- AOE

				 -- DETAUNTS, why oh why couldn't they all be named "Detaunt"
				 ["Look Over There!"] = { ["amount"] = IHYTM.DetauntAggroModifier, ["AOE"] = false },
				 ["Stop hittin' me!"] = { ["amount"] = IHYTM.DetauntAggroModifier, ["AOE"] = true }, -- AOE
				 ["Dissipating Hatred"] = { ["amount"] = IHYTM.DetauntAggroModifier, ["AOE"] = false },
				 ["Walk Between Worlds"] = { ["amount"] = IHYTM.DetauntAggroModifier, ["AOE"] = false },
				 ["Smoke Screen"] = { ["amount"] = IHYTM.DetauntAggroModifier, ["AOE"] = false },
				 ["Terrifying Vision"] = { ["amount"] = IHYTM.DetauntAggroModifier, ["AOE"] = false },
				 ["Addling Shot"] = { ["amount"] = IHYTM.DetauntAggroModifier, ["AOE"] = false },
				 ["Horrifying Visions"] = { ["amount"] = IHYTM.DetauntAggroModifier, ["AOE"] = false },
				 ["Wave Of Horror"] = { ["amount"] = IHYTM.DetauntAggroModifier, ["AOE"] = true }, -- AOE
				 ["Rune Of Preservation"] = { ["amount"] = IHYTM.DetauntAggroModifier, ["AOE"] = false },
				 ["Grimnir's Shield"] = { ["amount"] = IHYTM.DetauntAggroModifier, ["AOE"] = true }, -- AOE? weird, treat as a detaunt
				 ["Distracting Shot"] = { ["amount"] = IHYTM.DetauntAggroModifier, ["AOE"] = false },
				 ["Dread Aspect"] = { ["amount"] = IHYTM.DetauntAggroModifier, ["AOE"] = false },
				 ["Don't Eat Me"] = { ["amount"] = IHYTM.DetauntAggroModifier, ["AOE"] = false },
				 ["Repent"] = { ["amount"] = IHYTM.DetauntAggroModifier, ["AOE"] = false },

				 -- Submission: 10s cooldown? hate reduction AND 25% less hate for 5s?
				 -- White Lions must be detaunt kings, fuck being accurate.
				 -- TO FIX: Accuracy problems ignoring Baiting Strike on groupmates.
				 ["Submission"] = { ["amount"] = IHYTM.DetauntAggroModifier*0.75, ["AOE"] = true }, -- AOE? weird, treat as detaunt

				 ["Chaotic Blur"] = { ["amount"] = IHYTM.DetauntAggroModifier, ["AOE"] = false },
				 ["Embrace the Warp"] = { ["amount"] = IHYTM.DetauntAggroModifier, ["AOE"] = true }, -- AOE? weird, treat as detaunt
				 ["Enchanting Beauty"] = { ["amount"] = IHYTM.DetauntAggroModifier, ["AOE"] = true }, -- AOE
				 ["Get Thee Behind Me!"] = { ["amount"] = IHYTM.DetauntAggroModifier, ["AOE"] = true } -- AOE
				}

IHYTM.DamageAggroModifiers = { ["Clobber"] = IHYTM.DamageAggroModifier,
					 ["Enraged Blow"] = IHYTM.DamageAggroModifier,
					 ["Grudging Blow"] = IHYTM.DamageAggroModifier,
					 ["Graceful Strike"] = IHYTM.DamageAggroModifier,
					 ["Sunder"] = IHYTM.DamageAggroModifier,
					 ["Hateful Strike"] = IHYTM.DamageAggroModifier
					}

IHYTM.TacticAggroModifiers = { ["Menace"] = 2,
					 ["Focused Offense"] = 0.85,
					 ["Sleight Of Hand"] = 0.5,
					 ["Subtlety"] = 0.25
					}

IHYTM.BuffAggroModifiers = { ["Save Da Runts"] = IHYTM.GuardedAggroModifier,
				     ["Guard"] = IHYTM.GuardedAggroModifier,
				     ["Submission"] = 0.75,
				     ["Baiting Strike"] = 0.75 -- not sure if this is the right name for the buff Baiting Strike puts on pets/players
				    }

IHYTM.currHostileTarget = L""
IHYTM.currFriendlyTarget = L""
IHYTM.currGuardTarget = L"" -- used in the sync command to funnel the aggro difference from this group member to the local player
IHYTM.savedGuardTarget = L"" -- used to set the guard target after a reloadui

local TIME_DELAY = 1
local timeLeft = TIME_DELAY
local SYNC_TIME_DELAY = 3 -- send updates to the sync channel every x seconds (if the channel exists, and we aren't leaving or joining)
local syncTimeLeft = SYNC_TIME_DELAY

local lastAbilityCast = L""
local lastAbilityCastTarget = L""

local MAX_MSG_LENGTH = 200

local playerName = L"" -- set in init

function IHYTM.OnInitialize()

	RegisterEventHandler(SystemData.Events.PLAYER_TARGET_UPDATED, "IHYTM.OnTargetUpdated")
	RegisterEventHandler(SystemData.Events.PLAYER_BEGIN_CAST, "IHYTM.OnBeginCast")
	RegisterEventHandler(SystemData.Events.PLAYER_END_CAST, "IHYTM.OnEndCast")
	RegisterEventHandler(SystemData.Events.PLAYER_ABILITY_TOGGLED, "IHYTM.OnAbilityToggled")
	RegisterEventHandler(SystemData.Events.PLAYER_COMBAT_FLAG_UPDATED, "IHYTM.OnCombat")
	RegisterEventHandler(SystemData.Events.PLAYER_DEATH, "IHYTM.OnDeath")

	-- GROUP_PLAYER_ADDED - currently useless: the event is called when a player zones, when a pet dies or is spawned, etc.
	--RegisterEventHandler(SystemData.Events.GROUP_PLAYER_ADDED, "IHYTM.OnGroupPlayerAdded")
	--RegisterEventHandler(SystemData.Events.PLAYER_GROUP_LEADER_STATUS_UPDATED, "IHYTM.OnPlayerGroupLeaderStatusUpdated")
	RegisterEventHandler(SystemData.Events.GROUP_LEAVE, "IHYTM.OnGroupLeave")
	RegisterEventHandler(SystemData.Events.GROUP_ACCEPT_INVITATION, "IHYTM.OnGroupJoin")
	RegisterEventHandler(SystemData.Events.GROUP_ACCEPT_REFERRAL, "IHYTM.OnGroupJoin")

	RegisterEventHandler(SystemData.Events.INTERFACE_RELOADED, "IHYTM.OnInterfaceReloaded")

	RegisterEventHandler(SystemData.Events.CHAT_TEXT_ARRIVED, "IHYTM.OnChat")

	RegisterEventHandler(TextLogGetUpdateEventId("Chat"), "IHYTM.OnChatLogUpdated")
	RegisterEventHandler(TextLogGetUpdateEventId("Combat"), "IHYTM.OnCombatLogUpdated")

	playerName = IHYTM.FixName( GameData.Player.name ) -- currently there are two extra characters at the end of GameData.Player.name

	if ( LibSlash ~= nil ) then
		LibSlash.RegisterSlashCmd("IHYTM", function(input) IHYTM.HandleSlashCmd(input) end)
	end

	EA_ChatWindow.Print(L"IHYTM enabled, use '/IHYTM' for more information.")

end

function IHYTM.OnShutdown()

	UnregisterEventHandler(SystemData.Events.PLAYER_TARGET_UPDATED, "IHYTM.OnTargetUpdated")
	UnregisterEventHandler(SystemData.Events.PLAYER_BEGIN_CAST, "IHYTM.OnBeginCast")
	UnregisterEventHandler(SystemData.Events.PLAYER_END_CAST, "IHYTM.OnEndCast")
	UnregisterEventHandler(SystemData.Events.PLAYER_ABILITY_TOGGLED, "IHYTM.OnAbilityToggled")
	UnregisterEventHandler(SystemData.Events.PLAYER_COMBAT_FLAG_UPDATED, "IHYTM.OnCombat")
	UnregisterEventHandler(SystemData.Events.PLAYER_DEATH, "IHYTM.OnDeath")

	--UnregisterEventHandler(SystemData.Events.GROUP_PLAYER_ADDED, "IHYTM.OnGroupPlayerAdded")
	--UnregisterEventHandler(SystemData.Events.PLAYER_GROUP_LEADER_STATUS_UPDATED, "IHYTM.OnPlayerGroupLeaderStatusUpdated")
	UnregisterEventHandler(SystemData.Events.GROUP_LEAVE, "IHYTM.OnGroupLeave")
	UnregisterEventHandler(SystemData.Events.GROUP_ACCEPT_INVITATION, "IHYTM.OnGroupJoin")
	UnregisterEventHandler(SystemData.Events.GROUP_ACCEPT_REFERRAL, "IHYTM.OnGroupJoin")

	UnregisterEventHandler(SystemData.Events.INTERFACE_RELOADED, "IHYTM.OnInterfaceReloaded")

	UnregisterEventHandler(SystemData.Events.CHAT_TEXT_ARRIVED, "IHYTM.OnChat")

	UnregisterEventHandler(TextLogGetUpdateEventId("Chat"), "IHYTM.OnChatLogUpdated")
	UnregisterEventHandler(TextLogGetUpdateEventId("Combat"), "IHYTM.OnCombatLogUpdated")

	IHYTM.savedGuardTarget = IHYTM.currGuardTarget -- set the saved guard target for later (after /reloadui)

end

function IHYTM.HandleSlashCmd(arg)

	if (arg == "enable" or arg == "enabled" or arg == "on" or arg == "1") then

		-- set these so we don't parse all logs since the mod was last enabled,
		-- it'd be very bad if that happened.
		--lastChatLogEntry = TextLogGetNumEntries("Chat")
		--lastCombatLogEntry = TextLogGetNumEntries("Combat")

		IHYTM.enabled = true
		EA_ChatWindow.Print(L"IHYTM: Enabled!")
		return
	end

	if (arg == "disable" or arg == "disabled" or arg == "off" or arg == "0") then

		-- leave channels if we are in any
		IHYTM.LeaveChannels()

		-- reset variables
		IHYTM.joinChannelName = L""
		IHYTM.syncChannelName = L""
		IHYTM.syncChannelNumber = 0

		IHYTM.AggroTable = {}
		IHYTM.PurgeAggroStack = {}
		IHYTM.SyncMessageStack = {}
		deleteAggroTable = false -- called on end of combat

		leaveChannels = false -- forces the client to leave all IHYTM channels
		sendSyncMessage = false -- queues up the message to sync clients to the IHYTM channel for the group
		sendJoinMessage = false -- queues up the message requesting to join the IHYTM channel for the group
		sendResetMessage = false -- queues up the message requesting to reset the IHYTM aggro tables for the group

		lastAbilityCast = L""
		lastAbilityCastTarget = L""

		IHYTM.currHostileTarget = L""
		IHYTM.currFriendlyTarget = L""
		IHYTM.currGuardTarget = L"" -- used in the sync command to funnel the aggro difference from this group member to the local player
		IHYTM.savedGuardTarget = L"" -- used to set the guard target after a reloadui

		timeLeft = TIME_DELAY
		syncTimeLeft = SYNC_TIME_DELAY

		WindowSetShowing("IHYTM_GUI", false)

		IHYTM.enabled = false
		EA_ChatWindow.Print(L"IHYTM: Disabled.")
		return
	end

	if (arg == "sync") then
		sendSyncMessage = true

		timeLeft = 1 -- make sure this fires after 1 second

		return
	end

	if (arg == "join") then
		sendJoinMessage = true

		timeLeft = 1 -- make sure this fires after 1 second

		return
	end

	if (arg == "leave") then
		leaveChannels = true

		timeLeft = 1 -- make sure this fires after 1 second

		return
	end

	if (arg == "test") then
		if ( IHYTM_GUI.test ) then
			IHYTM_GUI.test = false
			WindowSetShowing("IHYTM_GUI", false)
			EA_ChatWindow.Print(L"IHYTM: Test mode deactivated.")
		else
			IHYTM_GUI.test = true
			WindowSetShowing("IHYTM_GUITitle", true)
			for i = 1, 6 do 
				WindowSetShowing("IHYTM_GUI_AggroBar" .. i, true)
			end
			WindowSetShowing("IHYTM_GUI", true)
			EA_ChatWindow.Print(L"IHYTM: Test mode activated.")
		end

		return
	end

	if (arg == "reset") then
		sendResetMessage = true

		timeLeft = 1 -- make sure this fires after 1 second
		syncTimeLeft = syncTimeLeft + 1 -- adjust sync time to compensate

		EA_ChatWindow.Print(L"IHYTM: Preparing to send group aggro reset message...")
		return
	end

	EA_ChatWindow.Print(L"Invalid argument, try: 'enable' 'disable' 'sync' 'join' 'leave' 'reset' 'test'")
end

function IHYTM.SendChatText( text, chan )
	if( SystemData.ClientVersion >= L"Version 1.3.6 Build 0" ) then
		-- THANKS, MYTHIC
		SendChatText( text, chan )
	else
		SystemData.UserInput.ChatText = text
		BroadcastEvent( SystemData.Events.SEND_CHAT_TEXT )
	end
end

function IHYTM.inGroup()
	if ( GroupWindow ~= nil and GroupWindow.groupData ~= nil ) then
		local inGroup = GroupWindow.groupData[1].name ~= L"" and GroupWindow.groupData[1].name ~= nil
		return inGroup
	else
		return false
	end
end

function IHYTM.IsTableEmpty( table )
	if ( table ~= nil ) then
		for key, value in pairs(table) do
			return false
		end
	end
	
	return true
end

function IHYTM.OnInterfaceReloaded()
	if ( IHYTM.enabled == false ) then
		return
	end
	IHYTM.currGuardTarget = IHYTM.savedGuardTarget
	if ( IHYTM.currGuardTarget ~= L"" ) then
		DEBUG(L"Guard target reloaded to " .. IHYTM.currGuardTarget .. L".")
	end
end

function IHYTM.OnDeath()
	if ( IHYTM.enabled == false ) then
		return
	end
	-- when you die, if you were guarding someone, guard is broken and the target should be reset
	if ( IHYTM.currGuardTarget ~= L"" ) then
		IHYTM.currGuardTarget = L""
		DEBUG(L"Guard target reset.")
	end
end

function IHYTM.OnAbilityToggled( abilityId, toggle )
	if ( IHYTM.enabled == false ) then
		return
	end
	if ( toggle == false 
		and ( IHYTM.CompareWStrings(GetAbilityName(abilityId), L"Save Da Runts" ) 
			or IHYTM.CompareWStrings(GetAbilityName(abilityId), L"Guard" ) ) ) then
		
		if ( IHYTM.currGuardTarget ~= L"" ) then
			IHYTM.currGuardTarget = L"" -- reset the guard target
			DEBUG(L"Guard target reset.")
		end
	end
end

function IHYTM.OnBeginCast( abilityId, something, castTime, somethingElse )
	if ( IHYTM.enabled == false ) then
		return
	end
	if ( GameData.Player.isInScenario == true ) then
		return
	end

	lastAbilityCast = GetAbilityName(abilityId)
	lastAbilityCastTarget = IHYTM.currHostileTarget

	if ( castTime == 0 ) then
		IHYTM.OnEndCast( false )
	end
end

function IHYTM.OnEndCast( failed )
	if ( IHYTM.enabled == false ) then
		return
	end
	if ( GameData.Player.isInScenario == true ) then
		return
	end
	if ( failed ) then
		lastAbilityCast = L""
		lastAbilityCastTarget = L""
		return
	end

	if ( lastAbilityCast ~= L"" and IHYTM.currFriendlyTarget ~= L"" 
		and ( IHYTM.CompareWStrings(lastAbilityCast, L"Save Da Runts" ) or IHYTM.CompareWStrings(lastAbilityCast, L"Guard" ) ) ) then

		-- we are a tank casting a guarding skill; set our guard target
		IHYTM.currGuardTarget = IHYTM.currFriendlyTarget
		DEBUG(L"Setting guard target to " .. IHYTM.currGuardTarget .. L" with " .. lastAbilityCast .. L".")

	elseif ( lastAbilityCast ~= L"" and lastAbilityCastTarget ~= L"" ) then
		for key, value in pairs(IHYTM.AggroModifiers) do
			if ( IHYTM.CompareWStrings(lastAbilityCast, towstring(key)) ) then
				if ( IHYTM.AggroModifiers[key].AOE == false ) then
					IHYTM.UpdateAggroTable( playerName, lastAbilityCast, lastAbilityCastTarget, 
									IHYTM.AggroModifiers[key].amount, false, false, false )
					break
				else
					-- apply the AOE to every enemy in the table, not accurate but the best we can do currently
					for akey, avalue in pairs(IHYTM.AggroTable) do
						IHYTM.UpdateAggroTable( playerName, lastAbilityCast, akey, 
										IHYTM.AggroModifiers[key].amount, false, false, false )
					end

					-- does this enemy exist in our table?
					local foundCastTarget = false
					for akey, avalue in pairs(IHYTM.AggroTable) do
						if( IHYTM.CompareWStrings(akey, lastAbilityCastTarget) ) then
							foundCastTarget = true
						end
					end
					if ( not foundCastTarget ) then
						-- this enemy did not exist in the table, add it now
						IHYTM.UpdateAggroTable( playerName, lastAbilityCast, lastAbilityCastTarget, 
										IHYTM.AggroModifiers[key].amount, false, false, false )
					end

					break
				end
			end
		end
	end
	lastAbilityCast = L""
	lastAbilityCastTarget = L""
end

function IHYTM.OnTargetUpdated( unitId, targetId, targetType )
	if ( IHYTM.enabled == false ) then
		return
	end
	if ( unitId == "selfhostiletarget" ) then
		IHYTM.currHostileTarget = IHYTM.FixName( TargetInfo:UnitName(unitId) )

		-- handle the gui showing from here
		if ( IHYTM.currHostileTarget == L"" and not IHYTM_GUI.test ) then
			WindowSetShowing("IHYTM_GUI", false)
		else
			WindowSetShowing("IHYTM_GUI", true)
			IHYTM_GUI.SetTimeLeft(0) -- update the info instantly
		end
	elseif ( unitId == "selffriendlytarget" ) then
		IHYTM.currFriendlyTarget = IHYTM.FixName( TargetInfo:UnitName(unitId) )
	end
end

function IHYTM.OnGroupPlayerAdded()
	if ( IHYTM.enabled == false ) then
		return
	end
	if ( GameData.Player.isInScenario == true ) then
		return
	end

	if ( GameData.Player.isGroupLeader == true ) then
		sendSyncMessage = true -- send the sync channel message
		timeLeft = 1 -- make sure this fires after 1 second
		syncTimeLeft = syncTimeLeft + 1 -- adjust sync time to compensate
	end
end

function IHYTM.OnGroupJoin()
	if ( IHYTM.enabled == false ) then
		return
	end
	if ( GameData.Player.isInScenario == true ) then
		return
	end

	-- don't send the message if you are the leader accepting a referral join message
	if ( GameData.Player.isGroupLeader ~= true ) then
		sendJoinMessage = true -- send the join channel message
		timeLeft = 1 -- make sure this fires after 1 second
		syncTimeLeft = syncTimeLeft + 1 -- adjust sync time to compensate
	end
end

function IHYTM.OnGroupLeave()
	if ( IHYTM.enabled == false ) then
		return
	end

	-- leave the sync channels
	leaveChannels = true
end

function IHYTM.OnPlayerGroupLeaderStatusUpdated()
	if ( IHYTM.enabled == false ) then
		return
	end
	--IHYTM.OnGroupPlayerAdded() -- same implementation
end

function IHYTM.OnChat()
	if ( IHYTM.enabled == false ) then
		return
	end
	if ( GameData.Player.isInScenario == true ) then
		return
	end

	local type = GameData.ChatData.type

	local syncType = IHYTM.GetSyncFilter( IHYTM.syncChannelNumber )

	-- disable incomming sync chat from showing in the default chat window
	if ( syncType ~= nil and LogDisplayGetFilterState( "EA_ChatTab1TextLog", "Chat", syncType ) == true ) then
		LogDisplaySetFilterState( "EA_ChatTab1TextLog", "Chat", syncType, false )
	end

	if ( type == SystemData.ChatLogFilters.GROUP or type == syncType ) then
		IHYTM.ChatHandler( type )
	end	
end

function IHYTM.GetSyncFilter( channelNumber )
	local syncType = nil
	-- ignoring channels 1 and 2 because they are reserved for Region and Region-RVR
	if ( channelNumber == 3 ) then
		syncType = SystemData.ChatLogFilters.CHANNEL_3

	elseif ( channelNumber == 4 ) then
		syncType = SystemData.ChatLogFilters.CHANNEL_4

	elseif ( channelNumber == 5 ) then
		syncType = SystemData.ChatLogFilters.CHANNEL_5

	elseif ( channelNumber == 6 ) then
		syncType = SystemData.ChatLogFilters.CHANNEL_6

	elseif ( channelNumber == 7 ) then
		syncType = SystemData.ChatLogFilters.CHANNEL_7

	elseif ( channelNumber == 8 ) then
		syncType = SystemData.ChatLogFilters.CHANNEL_8

	elseif ( channelNumber == 9 ) then
		syncType = SystemData.ChatLogFilters.CHANNEL_9
	end

	return syncType
end

function IHYTM.ChatHandler( type )
	if ( IHYTM.enabled == false ) then
		return
	end

	local msg = GameData.ChatData.text
	local author = IHYTM.FixName( GameData.ChatData.name )
	local player = playerName

	if ( type == nil ) then
		-- this shouldn't ever happen
		DEBUG(L"IHYTM.ChatHandler: type is nil")
		return
	end

	if ( type == SystemData.ChatLogFilters.GROUP ) then
		if (wstring.sub(msg, 1, 13) == L"[IHYTM: SYNC]") then
			IHYTM.joinChannelName =  L"IHYTM_" .. author 
			timeLeft = TIME_DELAY -- make sure we wait at least a second
		elseif (wstring.sub(msg, 1, 13) == L"[IHYTM: JOIN]") then
			-- super lazy way to do this
			IHYTM.OnGroupPlayerAdded()
			timeLeft = TIME_DELAY -- make sure we wait at least a second
		elseif (wstring.sub(msg, 1, 14) == L"[IHYTM: RESET]") then
			deleteAggroTable = true
		end

	else -- sync channel message
		if ( wstring.find(player, author, 1, true) == nil ) then
			if (wstring.sub(msg, 1, 1) == L"�") then
				table.insert( IHYTM.SyncMessageStack, { ["msg"] = wstring.sub(msg, 2, -1), ["author"] = author } )
			end
		end
	end
end

function IHYTM.CheckChannels()
	local channelNames = GetChatChannelNames()
	for key, value in pairs(channelNames) do
		if ( wstring.find(channelNames[key].name, L"IHYTM", 1, true) == 1 ) then
			return channelNames[key].name, channelNames[key].number
		end
	end
	return L"", 0
end

function IHYTM.JoinChannel( channelName )
	IHYTM.syncChannelName, IHYTM.syncChannelNumber = IHYTM.CheckChannels()

	if ( IHYTM.syncChannelName ~= L"" and IHYTM.syncChannelNumber ~= 0 and channelName ~= IHYTM.syncChannelName ) then
		IHYTM.joinChannelName = channelName  -- set the channel name to join after we leave the channels
		leaveChannels = true -- leave the channels
		return
	end

	if ( channelName ~= nil ) then
		IHYTM.SendChatText( L"/channeljoin " .. channelName, L"" )
	end
	IHYTM.joinChannelName = L""
end

function IHYTM.SendSyncMessage()

	-- keep looking for the IHYTM channel and set it
	-- probably a "better" way for me to do this, like checking OnChat for when you join channels, but whatever
	-- this works better at preventing players from breaking stuff by leaving the IHYTM channel
	IHYTM.syncChannelName, IHYTM.syncChannelNumber = IHYTM.CheckChannels()

	if ( IHYTM.syncChannelName == L"" or IHYTM.syncChannelNumber == 0 ) then
		return
	elseif ( IHYTM.inGroup() == false ) then
		leaveChannels = true -- leave the channels
		return
	end

	local msg = L"/" .. towstring(IHYTM.syncChannelNumber) .. L" �"
	local name = playerName

	local numSent = 0
	for key, value in pairs(IHYTM.AggroTable) do
		numSent = numSent + 1
		if ( numSent > 20 ) then
			break
		end

		if( IHYTM.AggroTable[key][name] ~= nil and IHYTM.AggroTable[key][name] > 0 ) then
			msg = msg .. key .. L":" .. towstring(IHYTM.AggroTable[key][name]) .. L";"
		end
	end

	local initialMessage = msg
	
	local iteration = 0
	while ( wstring.len(msg) > MAX_MSG_LENGTH ) do
		-- if the message is too long we are probably cutting some text off when we send it
		-- remove the excess and hope for the best

		iteration = iteration + 1
		if ( iteration > 100 ) then
			DEBUG( L"IHYTM.SendSyncMessage() - LONG LOOP: " .. initialMessage )
			return
		end

		local lastSemicolon = wstring.find(wstring.reverse(msg), L";", 2, true)
		if ( lastSemicolon == nil ) then
			return
		end
		lastSemicolon = lastSemicolon * -1

		msg = wstring.sub(msg, 1, lastSemicolon)
	end

	if ( msg ~= L"/" .. towstring(IHYTM.syncChannelNumber) .. L" �" ) then
		-- don't send a empty sync message
		IHYTM.SendChatText( msg, L"" )
	end
end

function IHYTM.ParseSyncMessage( msg, author )
	if ( msg == nil or msg == L"" or author == nil or author == L"" ) then

		return
	end

	local initialMessage = msg

	local iteration = 0
	local done = false
	while ( not done ) do
		
		iteration = iteration + 1
		if ( iteration > 100 ) then
			DEBUG( L"IHYTM.ParseSyncMessage() - LONG LOOP: " .. author .. L": " .. initialMessage )
			return
		end

		local semicolonPos = wstring.find(msg, L";", 1, true)
		if ( semicolonPos ~= nil ) then

			local colonPos = wstring.find(msg, L":", 1, true)
			if ( colonPos ~= nil ) then

				local enemyName = wstring.sub(msg, 1, colonPos-1)
				local enemyAggro = wstring.sub(msg, colonPos+1, semicolonPos-1)
				if ( enemyName ~= nil and enemyName ~= L"" and enemyAggro ~= nil and enemyAggro ~= L"" ) then
					enemyAggro = tonumber(enemyAggro)

					local foundEnemy = false
					for key, value in pairs(IHYTM.AggroTable) do

						-- only check if we haven't found the enemy since we can't break while in nested loops
						if ( foundEnemy == false and IHYTM.CompareWStrings(key, enemyName) ) then

							if ( IHYTM.currGuardTarget ~= L"" and IHYTM.CompareWStrings( author, IHYTM.currGuardTarget ) ) then

								local fAggro = 0
								-- if we are guarding this target then funnel in the aggro difference to us
								if ( IHYTM.AggroTable[key][author] == nil ) then
									fAggro = enemyAggro
									fAggro = math.ceil(fAggro * IHYTM.GuardAggroModifier)
								elseif ( IHYTM.AggroTable[key][author] < enemyAggro ) then
									fAggro = enemyAggro - IHYTM.AggroTable[key][author]
									fAggro = math.ceil(fAggro * IHYTM.GuardAggroModifier)
								end
								if ( fAggro > 0 ) then
									if ( IHYTM.AggroTable[key][playerName] ~= nil ) then
										IHYTM.AggroTable[key][playerName] = IHYTM.AggroTable[key][playerName] + fAggro 
									else
										IHYTM.AggroTable[key][playerName] = fAggro -- create the entry
									end
								end

								IHYTM.AggroTable[key][author] = enemyAggro		
							else
								IHYTM.AggroTable[key][author] = enemyAggro
							end
							foundEnemy = true
							--can't break, lua fucks up and breaks all loops not just this one
						end
					end

					if ( foundEnemy == false ) then
						-- this enemy does not exist in our table, add it in
						IHYTM.AggroTable[enemyName] = { [author] = enemyAggro }
					end
				end
			end

			msg = wstring.sub(msg, semicolonPos+1, -1)
		else
			done = true
		end
	end
end

function IHYTM.PopSyncMessageStack()
	local iteration = 0
	while ( IHYTM.SyncMessageStack[1] ~= nil ) do
		iteration = iteration + 1
		if ( iteration > 100 ) then
			DEBUG( L"IHYTM.PopSyncMessageStack() - LONG LOOP: ABORTED" )
			IHYTM.SyncMessageStack = {}
			return
		end

		IHYTM.ParseSyncMessage( IHYTM.SyncMessageStack[1].msg, IHYTM.SyncMessageStack[1].author )
		table.remove(IHYTM.SyncMessageStack, 1)
	end
end

function IHYTM.FixName( name )
	-- currently the game adds a ^M or ^F at the end of names for what I 
	-- assume is to determine sex in combat or other messages
	-- it's terrible and it makes comparing names difficult

	if ( type(name) ~= "wstring" ) then
		name = towstring(name)
	end

	-- this is to prevent unnecessary checks and because wstring.reverse(L"") returns a STRING, and that breaks stuff
	if ( name == L"" ) then
		return name
	end

	if ( wstring.find(name, L"^", 1, true) ~= nil ) then
		name = wstring.sub(name, 1, wstring.find(name, L"^", 1, true)-1)
	end

	-- remove spaces at the start and end of names. IE: I encounted a L"Rock-Biter Gnoblar " that compared incorrectly.
	-- OR TAB CHARACTERS (WHAT THE FUCK, MYTHIC?) "Battle for Praag" in other languages has a TAB CHARACTER in it.
	-- AHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH!
	local done = false
	while ( not done ) do
		if ( wstring.find(name, L" ", 1, true) == 1 or wstring.find(name, L"	", 1, true) == 1) then
			name = wstring.sub(name, 2, -1)
		elseif ( wstring.find(wstring.reverse(name), L" ", 1, true) == 1 or wstring.find(wstring.reverse(name), L"	", 1, true) == 1 ) then
			name = wstring.sub(name, 1, -2)
		else
			done = true
		end
	end

	return name
end

function IHYTM.CompareWStrings( first, second )
	-- for some fucked up reason, the game or lua likes to put random hidden characters in wstrings
	-- this messes up their length and makes wstring.find return nil even though they appear to be the same
	-- IE: the wstring name of enemy L"Burning Spear" will sometimes not equal wstring L"Burning Spear"

	-- this implementation has been removed in favor of IHYTM.FixName() to fix names
	--[[if ( wstring.len(first) > wstring.len(second) ) then
		first = wstring.sub(first, 1, wstring.len(second))
	elseif ( wstring.len(first) < wstring.len(second) ) then
		second = wstring.sub(second , 1, wstring.len(first))
	end]]--

	-- this is only a precaution for ability names, etc.
	first = IHYTM.FixName( first )
	second = IHYTM.FixName( second )

	-- check lengths as IHYTM.CompareWStrings(L"Doggles", L"Dog") will return true otherwise
	if ( wstring.len(first) ~= wstring.len(second) ) then
		return false
	end

	if ( wstring.find(first, second, 1, true) == 1 ) then
		return true
	else
		return false
	end
end

function IHYTM.UpdateAggroTable( name, abilityName, targetName, amount, isHeal, isCrit, ignoreTactics )
	if ( IHYTM.AggroTable == nil ) then
		return
	end

	if ( name == playerName ) then
		-- apply tactic aggro bonuses
		if ( not ignoreTactics ) then
			for i = 1, 4 do
				for key, value in pairs(IHYTM.TacticAggroModifiers) do
					if ( GetActiveTactics()[i] ~= nil and IHYTM.CompareWStrings(GetAbilityName(GetActiveTactics()[i]), towstring(key)) ) then
						amount = amount * value
						break
					end
				end
			end
		end		

		-- apply buff aggro bonuses
		local currBuffs = GetBuffs(GameData.BuffTargetType.SELF)
		local numGuards = 0
		for key, value in pairs(currBuffs) do
			for bkey, bvalue in pairs(IHYTM.BuffAggroModifiers) do
				if ( IHYTM.CompareWStrings(currBuffs[key].name, towstring(bkey)) ) then
					if ( ( bkey == "Save Da Runts" or bkey == "Guard" ) and IHYTM.currGuardTarget ~= L"" ) then
						-- do not apply if we are the one guarding someone
						numGuards = numGuards + 1
						--DEBUG(L"Currently guarding, ignoring aggro reduction from guard buff.")
					else
						amount = amount * bvalue
					end
				end
			end
		end

		if ( numGuards > 1 ) then
			-- we are a tank being guarded by another tank
			--DEBUG(L"Currently guarding AND being guarded, applying aggro reduction from guard buff.")
			amount = amount * IHYTM.GuardedAggroModifier
		end

	end

	-- HEAL?

	if ( isHeal ) then
		if ( name ~= playerName ) then
			-- for now we cannot track other players well without syncing in a channel
			-- so we will ignore heals unless they are ours, thus making it so we only
			-- update our own aggro and leave other groupmember's to be synced.

			-- currently the combat log doesn't track other player's damage, just 
			-- incomming hits (damage) to them from something else (enemy)
			return
		end

		-- apply healing aggro modifier
		amount = amount * IHYTM.HealAggroModifier

		for key, value in pairs(IHYTM.AggroTable) do
			if( IHYTM.AggroTable[key][name] ~= nil ) then
				IHYTM.AggroTable[key][name] = IHYTM.AggroTable[key][name] + math.ceil(amount)
			else
				IHYTM.AggroTable[key][name] = math.ceil(amount)
			end
		end
		return
	end

	-- DAMAGE!

	-- apply ability aggro bonuses based on damage
	for key, value in pairs(IHYTM.DamageAggroModifiers) do
		if ( IHYTM.CompareWStrings(abilityName, towstring(key)) ) then
			amount = amount * value
			break
		end
	end

	local nameFound = false
	if ( name == playerName ) then
		nameFound = true
	elseif ( GetNumGroupmates() > 0 ) then
		for i = 1, GetNumGroupmates() do
			if ( name == GetGroupData()[i].name ) then
				nameFound = true
				break
			end
		end
	end

	if ( targetName == L"your pet" ) then
		return
	end

	-- ignore incomming damage, it seems to not affect your aggro at all.
	if ( targetName == playerName ) then
		amount = 0
	end

	-- we assume everyone outside our group is THE ENEMY
	local keyFound = false
	if ( nameFound == false ) then
		for key, value in pairs(IHYTM.AggroTable) do
			if ( IHYTM.CompareWStrings(key, name) ) then
				if( IHYTM.AggroTable[key][targetName] ~= nil ) then
					IHYTM.AggroTable[key][targetName] = IHYTM.AggroTable[key][targetName] + math.ceil(amount)
				else
					IHYTM.AggroTable[key][targetName] = math.ceil(amount)
				end
				keyFound = true
			end
		end

		-- doesn't exist, make it
		if ( keyFound == false ) then
			IHYTM.AggroTable[name] = { [targetName] = amount }
		end
	else
		for key, value in pairs(IHYTM.AggroTable) do
			if ( IHYTM.CompareWStrings(key, targetName) ) then
				if( IHYTM.AggroTable[key][name] ~= nil ) then
					IHYTM.AggroTable[key][name] = IHYTM.AggroTable[key][name] + math.ceil(amount)
				else
					IHYTM.AggroTable[key][name] = math.ceil(amount)
				end
				keyFound = true
			end
		end

		-- doesn't exist, make it
		if ( keyFound == false ) then
			IHYTM.AggroTable[targetName] = { [name] = math.ceil(amount) }
		end
			
	end
end

function IHYTM.PopPurgeAggroStack()
	local iteration = 0
	while ( IHYTM.PurgeAggroStack[1] ~= nil ) do
		iteration = iteration + 1
		if ( iteration > 100 ) then
			DEBUG( L"IHYTM.PopPurgeAggroStack() - LONG LOOP: ABORTED" )
			IHYTM.PurgeAggroStack = {}
			return
		end

		if ( IHYTM.AggroTable[IHYTM.PurgeAggroStack[1]] ~= nil ) then
			IHYTM.AggroTable[IHYTM.PurgeAggroStack[1]] = nil
		end
		table.remove(IHYTM.PurgeAggroStack, 1)
	end
end

function IHYTM.ParseChatLog( textLog, textLogType )
	-- this crap can't be tracked otherwise
	if ( GameData.Player.isInScenario == true ) then
		return
	end

	-- only count deaths
	if ( textLogType ~= SystemData.ChatLogFilters.KILLS_DEATH_YOURS
		and textLogType ~= SystemData.ChatLogFilters.KILLS_DEATH_OTHER ) then 

		return
	end

	local killedName = L""
	
	if ( wstring.find(textLog, L"You have slain ", 1, true) ~= nil ) then
		killedName = IHYTM.FixName( wstring.sub(textLog, 16, wstring.find(textLog, L"!", 1, true)-1 ) )
	elseif ( wstring.find(textLog, L" has been slain by ", 1, true) ~= nil ) then
		killedName = IHYTM.FixName( wstring.sub(textLog, 1, wstring.find(textLog, L" has been slain by ", 1, true)-1 ) )
	end

	if ( killedName ~= L"" ) then
		--DEBUG( L"Enemy killed: \"" .. killedName .. L"\"" )
		table.insert(IHYTM.PurgeAggroStack, killedName)
	end
end

function IHYTM.ParseCombatLog( textLog, textLogType  )
	if ( GameData.Player.isInScenario == true ) then
		return
	end

	local subLocation = 1

	local name = L""
	local abilityName = L""
	local targetName = L""
	local amount = 0
	local isHeal = false
	local isCrit = false

	-- name
	if ( wstring.sub(textLog, 1, 4) == L"Your" ) then
		name = playerName
		subLocation = 6
	elseif ( wstring.find(textLog, L"'s", 1, true) ~= nil and wstring.sub(textLog, 1, 4) ~= L"You " ) then
		name = wstring.sub(textLog, 1, wstring.find(textLog, L"'s", 1, true)-1)
		subLocation = wstring.find(textLog, L"'s", 1, true)+3
	end
	textLog = wstring.sub(textLog, subLocation)

	if ( wstring.find(textLog, L"critically ", 1, true) ) then
		-- remove the crit from the message
		textLog = wstring.gsub( textLog, L"critically ", L"" )
		isCrit = true
	end

	-- abilityName
	if ( wstring.find(textLog, L" hits", 1, true) ~= nil ) then
		abilityName = wstring.sub(textLog, 1, wstring.find(textLog, L" hits", 1, true)-1)
		subLocation = wstring.find(textLog, L"hits", 1, true)+5
	elseif ( wstring.find(textLog, L" heals", 1, true) ~= nil ) then
		abilityName = wstring.sub(textLog, 1, wstring.find(textLog, L" heals", 1, true)-1)
		subLocation = wstring.find(textLog, L"heals", 1, true)+6
		isHeal = true
	else
		--DEBUG(textLog) -- something horrible happened
		return
	end
	textLog = wstring.sub(textLog, subLocation)

	-- fix for 1.2 combat log changes
	if ( wstring.find(abilityName, L"[", 1, true) and wstring.find(abilityName, L"]", 1, true) ) then
		abilityName = wstring.sub(abilityName, 2, -2)
	end
	
	-- targetName
	if ( wstring.sub(textLog, 1, 4) == L"you " ) then
		targetName = playerName
		subLocation = wstring.find(textLog, L"for", 1, true)+4
	elseif ( wstring.find(textLog, L" for", 1, true) ~= nil ) then
		targetName = wstring.sub(textLog, 1, wstring.find(textLog, L" for", 1, true)-1)
		subLocation = wstring.find(textLog, L"for", 1, true)+4
	else
		--DEBUG(textLog) -- something horrible happened
		return
	end
	textLog = wstring.sub(textLog, subLocation)

	if ( wstring.find(textLog, L" damage", 1, true) ~= nil ) then
		amount = wstring.sub(textLog, 1, wstring.find(textLog, L" damage", 1, true)-1)
		subLocation = wstring.find(textLog, L"damage", 1, true)+7
	elseif ( wstring.find(textLog, L" points", 1, true) ~= nil ) then
		amount = wstring.sub(textLog, 1, wstring.find(textLog, L" points", 1, true)-1)
		subLocation = wstring.find(textLog, L"points", 1, true)+7
	else
		--DEBUG(textLog) -- something horrible happened
		return
	end
	textLog = wstring.sub(textLog, subLocation)

	--[[if ( name == L"" ) then
		DEBUG(L"(IHYTM): NO NAME: " .. textLog)
	else
		local heal, crit = L""
		if ( isHeal == true ) then
			heal = L"true"
		else
			heal = L"false"
		end
		if ( isCrit == true ) then
			crit = L"true"
		else
			crit = L"false"
		end

		DEBUG(L"(IHYTM): " .. name .. L", " .. abilityName .. L", isHeal=" .. heal .. L", isCrit=" .. crit .. L", " .. targetName .. L", " .. amount)
		DEBUG(L"(IHYTM): " .. textLog)
	end]]--

	if ( name ~= L"" and abilityName ~= L"" and targetName ~= L"" and amount ~= 0 ) then
		IHYTM.UpdateAggroTable( IHYTM.FixName( name ), abilityName, IHYTM.FixName( targetName ), tonumber(amount), isHeal, isCrit, false )
	else
		--DEBUG(L"(IHYTM): Ignoring: " .. textLog)
	end
end

function IHYTM.LeaveChannels()
	local channelNames = GetChatChannelNames()
	for key, value in pairs(channelNames) do
		if ( wstring.find(channelNames[key].name, L"IHYTM", 1, true) == 1 ) then
			local syncType = IHYTM.GetSyncFilter( channelNames[key].number )

			-- re-enable the sync channel as we aren't using it anymore
			if ( syncType ~= nil ) then
				LogDisplaySetFilterState( "EA_ChatTab1TextLog", "Chat", syncType, true )
			end

			IHYTM.SendChatText( L"/channelleave " .. channelNames[key].name, L"" )

			IHYTM.syncChannelName = L""
			IHYTM.syncChannelNumber = 0

			return true
		end
	end

	return false
end

function IHYTM.OnChatLogUpdated( updateType, filterType )
	local chatLog = L""
	local chatLogType = 0

	-- check to prevent double parsing when TextLog entries are capped at around 2048
	if ( updateType == 0 ) then
		_,chatLogType,chatLog = TextLogGetEntry("Chat", TextLogGetNumEntries("Chat")-1)
		IHYTM.ParseChatLog(chatLog, chatLogType)
	end
end

function IHYTM.OnCombatLogUpdated( updateType, filterType )
	local combatLog = L""
	local combatLogType = 0

	-- check to prevent double parsing when TextLog entries are capped at around 2048
	if ( updateType == 0 ) then
		_,combatLogType,combatLog = TextLogGetEntry("Combat", TextLogGetNumEntries("Combat")-1)
		IHYTM.ParseCombatLog(combatLog, combatLogType)
	end
end

--local lastChatLogEntry = TextLogGetNumEntries("Chat")
--local lastCombatLogEntry = TextLogGetNumEntries("Combat")
function IHYTM.OnUpdate( elapsed )

	if ( IHYTM.enabled == false ) then
		return
	end

	timeLeft = timeLeft - elapsed
	if timeLeft > 0 then
		return -- cut out early
	end
	timeLeft = TIME_DELAY -- reset to TIME_DELAY seconds
	-- this will run roughly every second. If TIME_DELAY were 2, it'd run every 2 seconds.

	syncTimeLeft = syncTimeLeft - TIME_DELAY

	-- this method no longer works as of 1.1
	--[[local chatLog = L""
	local chatLogType = 0
	if ( lastChatLogEntry < TextLogGetNumEntries("Chat") ) then
		for i = lastChatLogEntry, TextLogGetNumEntries("Chat")-1 do
			_,chatLogType,chatLog = TextLogGetEntry("Chat", i)
			IHYTM.ParseChatLog(chatLog, chatLogType)
		end
		lastChatLogEntry = TextLogGetNumEntries("Chat")
	end

	local combatLog = L""
	local combatLogType = 0
	if ( lastCombatLogEntry < TextLogGetNumEntries("Combat") ) then
		for i = lastCombatLogEntry, TextLogGetNumEntries("Combat")-1 do
			_,combatLogType,combatLog = TextLogGetEntry("Combat", i)
			IHYTM.ParseCombatLog(combatLog, combatLogType)
		end
		lastCombatLogEntry = TextLogGetNumEntries("Combat")
	end]]--

	-- pop the stacks
	-- sync message stack first to prevent aggro that should have been deleted from being
	-- put back in from a delayed sync message
	IHYTM.PopSyncMessageStack()
	IHYTM.PopPurgeAggroStack()

	if ( deleteAggroTable == true ) then
		-- print it out before we say goodbye
		--[[EA_ChatWindow.Print(L"IHYTM.AggroTable:")
		for key, value in pairs(IHYTM.AggroTable) do
			EA_ChatWindow.Print(L"- " .. towstring(key) .. L":")
			for jkey, jvalue in pairs(IHYTM.AggroTable[key]) do
				EA_ChatWindow.Print(L"-- " .. towstring(jkey) .. L": " .. towstring(jvalue))
			end
		end]]--

		IHYTM.AggroTable = {}
		deleteAggroTable = false
	end

	-- print out
	--[[if ( GameData.Player.inCombat ) then
		EA_ChatWindow.Print(L"IHYTM.AggroTable:")
		for key, value in pairs(IHYTM.AggroTable) do
			EA_ChatWindow.Print(L"- " .. towstring(key) .. L":")
			for jkey, jvalue in pairs(IHYTM.AggroTable[key]) do
				EA_ChatWindow.Print(L"-- " .. towstring(jkey) .. L": " .. towstring(jvalue))
			end
		end
	end]]--

	if ( leaveChannels == true ) then
		leaveChannels = IHYTM.LeaveChannels() -- leave channels will return true whenever there is a IHYTM channel to leave
								  -- so it will automatically set leaveChannels to false when done
	else
		if ( sendSyncMessage == true ) then
			IHYTM.SendChatText( L"/p [IHYTM: SYNC]", L"" )
			sendSyncMessage = false
		elseif ( sendJoinMessage == true ) then
			IHYTM.SendChatText( L"/p [IHYTM: JOIN]", L"" )
			sendJoinMessage = false
		elseif ( sendResetMessage == true ) then
			IHYTM.SendChatText( L"/p [IHYTM: RESET]", L"" )
			sendResetMessage = false
		elseif ( IHYTM.joinChannelName ~= L"" ) then
			-- set when a player requests to sync channels
			-- or in IHYTM.JoinChannel() if a IHYTM channel already exists
			IHYTM.JoinChannel( IHYTM.joinChannelName )
--[[
		elseif ( IHYTM.CheckChannels() ~= L"" and ( IHYTM.syncChannelName == L"" or IHYTM.syncChannelNumber == 0 ) ) then
			-- keep looking for the IHYTM channel if it's not set
			-- probably a "better" way for me to do this, like checking OnChat for when you join channels, but whatever
			IHYTM.syncChannelName, IHYTM.syncChannelNumber = IHYTM.CheckChannels()
]]--
		elseif ( syncTimeLeft < 0 and GameData.Player.inCombat ) then
			-- send sync message
			IHYTM.SendSyncMessage()
			syncTimeLeft = SYNC_TIME_DELAY
		end
	end
end

function IHYTM.OnCombat()
	if ( not GameData.Player.inCombat ) then
		-- this triggers twice. why?
		deleteAggroTable = true
	else
		--IHYTM.AggroTable = {} 
	end
end