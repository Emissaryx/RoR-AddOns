<?xml version="1.0" encoding="UTF-8"?>
<!--
IHYTM
Warhammer Online: Age of Reckoning UI modification that adds a simple
aggro meter.
    
Copyright (C) 2008-2010  Dillon "Rhekua" DeLoss
rhekua@msn.com		    www.rhekua.com

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
-->
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
	<UiMod name="I HATE YOU THIS MUCH" version="1.2" date="8/4/2010" >
		<VersionSettings gameVersion="1.3.6" windowsVersion="1.0" savedVariablesVersion="1.0" />
		<Author name="Rhekua" email="rhekua@msn.com" />
		<Description text="Adds a simple aggro meter."/>
		<Dependencies>
			<Dependency name="LibSlash" />
 			<Dependency name="EA_ChatWindow"/> 
			<Dependency name="EA_ChatSystem"/>
      		<Dependency name="EATemplate_DefaultWindowSkin" />
		</Dependencies>
		<Files>
			<File name="IHYTM.lua" />
			<File name="IHYTM_GUI.xml" />
		</Files>
		<SavedVariables>
			<SavedVariable name="IHYTM.enabled" />
			<SavedVariable name="IHYTM.savedGuardTarget" />
		</SavedVariables>
		<OnInitialize>
			<CallFunction name="IHYTM.OnInitialize" />
			<CreateWindow name="IHYTM_GUI" show="false" />
		</OnInitialize>
		<OnUpdate>
			<CallFunction name="IHYTM.OnUpdate" />
		</OnUpdate>
		<OnShutdown>
			<CallFunction name="IHYTM.OnShutdown" />
    		</OnShutdown>
	</UiMod>
</ModuleFile>
