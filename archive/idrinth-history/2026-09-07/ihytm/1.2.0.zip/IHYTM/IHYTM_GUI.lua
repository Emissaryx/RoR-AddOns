--[[
IHYTM
Warhammer Online: Age of Reckoning UI modification that adds a simple
aggro meter.
    
Copyright (C) 2008-2010  Dillon "Rhekua" DeLoss
rhekua@msn.com		    www.rhekua.com

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
]]--

IHYTM_GUI = {}

-- for testing purposes only, I do not want to have people rely on exact numbers as the number is just an approximation
IHYTM_GUI.showNumberValue = true

IHYTM_GUI.BAR_HIGH_TINT = { r=255, g=0, b=0 }
IHYTM_GUI.BAR_MED_TINT = { r=255, g=255, b=0 }
IHYTM_GUI.BAR_LOW_TINT = { r=0, g=255, b=0 }

IHYTM_GUI.BAR_HIGH_THRESHOLD = 100
IHYTM_GUI.BAR_MED_THRESHOLD = 50
IHYTM_GUI.BAR_LOW_THRESHOLD = 50

IHYTM_GUI.test = false

local TIME_DELAY = 0.5
local timeLeft = 0 -- start at 0 to hide the window instantly on a reloadui (see OnUpdate)

function IHYTM_GUI.OnInitialize()

	LabelSetText("IHYTM_GUITitle", L"IHYTM")

	--LayoutEditor.RegisterWindow( windowName, windowDisplayName, windowDesc, allowSizeWidth, allowSizeHeight, allowHiding, setHiddenCallback )
	LayoutEditor.RegisterWindow( "IHYTM_GUI", L"IHYTM Window", L"IHYTM Aggro Meter Window", false, false, true, nil )

	IHYTM_GUI.SetTestBarInfo()
end

function IHYTM_GUI.OnShutdown()

	LayoutEditor.UnregisterWindow( "IHYTM_GUI" )
end

function IHYTM_GUI.SetTimeLeft( num )
	timeLeft = num
end

function IHYTM_GUI.SetBarInfo()
	if ( IHYTM.currHostileTarget ~= L"" ) then
		local tempAggroTable = {}

		for key, value in pairs(IHYTM.AggroTable) do
			if ( IHYTM.CompareWStrings(key, IHYTM.currHostileTarget) ) then
				for akey, avalue in pairs(IHYTM.AggroTable[key]) do
					tempAggroTable[akey] = avalue
				end
				break
			end
		end
		
		-- make a test table
		--[[for i = 1, math.random(0, 6) do
			tempAggroTable[L"fart " .. towstring(i)] = math.random(-1,1)
		end]]--

		local tableSize = 0
		local highestAggro = -math.huge -- make it the smallest value ever so if we start the fight at a negative (detaunted) it doesn't mess up
		local highestAggroName = L""
		for key, value in pairs(tempAggroTable) do
			tableSize = tableSize + 1
			if ( value > highestAggro ) then
				highestAggro = value
				highestAggroName = key
			end
		end

		local lowestAggro = highestAggro
		for key, value in pairs(tempAggroTable) do
			if ( value < lowestAggro ) then
				lowestAggro = value
			end
		end

		-- i'm sure there is an easier way to sort this but it was fun figuring it out for myself
		local aggroStep = highestAggro
		local aggroName = highestAggroName
		local namesChecked = {}
		table.insert(namesChecked, highestAggroName)
		for i = 1, tableSize do
			if ( i > 1 ) then
				local tempAggroStep = -math.huge
				for key, value in pairs(tempAggroTable) do
					local nameFound = false
					for nkey, nvalue in ipairs(namesChecked) do
						if ( key == nvalue ) then
							nameFound = true
							break
						end
					end

					if ( value == aggroStep and aggroName ~= key and not nameFound ) then
						tempAggroStep = value
						aggroName = key
						table.insert(namesChecked, key)
						break
					elseif ( value < aggroStep ) then
						if ( value > tempAggroStep ) then
							tempAggroStep = value
							aggroName = key
							if ( not nameFound ) then
								table.insert(namesChecked, key)
							end
						end
					end
				end
				aggroStep = tempAggroStep 
			end

			if ( i > 6 ) then
				-- we're done here, break...
				break
			end

			StatusBarSetCurrentValue( "IHYTM_GUI_AggroBar" .. i .. "StatusBar", math.ceil((aggroStep/highestAggro) * 100) )
			color = IHYTM_GUI.GetBarColor( StatusBarGetCurrentValue("IHYTM_GUI_AggroBar" .. i .. "StatusBar") )
			StatusBarSetForegroundTint( "IHYTM_GUI_AggroBar" .. i .. "StatusBar", color.r, color.g, color.b)
			StatusBarSetBackgroundTint( "IHYTM_GUI_AggroBar" .. i .. "StatusBar", 0, 0, 0 )
			if ( IHYTM_GUI.showNumberValue ) then
				LabelSetText( "IHYTM_GUI_AggroBar" .. i .. "Percent", towstring(math.ceil(aggroStep)) )
			else
				LabelSetText( "IHYTM_GUI_AggroBar" .. i .. "Percent", towstring(StatusBarGetCurrentValue("IHYTM_GUI_AggroBar" .. i .. "StatusBar")) .. L"%" )
			end
			LabelSetText( "IHYTM_GUI_AggroBar" .. i .. "Name", aggroName )
			WindowSetShowing("IHYTM_GUI_AggroBar" .. i, true)
		end

		-- hide unused bars
			for i = tableSize + 1, 6 do
				WindowSetShowing("IHYTM_GUI_AggroBar" .. i, false)
			end

		-- hide or show the title text
		if ( WindowGetShowing("IHYTM_GUI_AggroBar1") == true ) then
			WindowSetShowing("IHYTM_GUITitle", true)
		else
			WindowSetShowing("IHYTM_GUITitle", false)
		end
	end
end

function IHYTM_GUI.SetTestBarInfo()
	local color = { r=0, g=0, b=0 }
	local num = 100
	for i = 1, 6 do
		StatusBarSetMaximumValue( "IHYTM_GUI_AggroBar" .. i .. "StatusBar", 100 )
		StatusBarSetCurrentValue( "IHYTM_GUI_AggroBar" .. i .. "StatusBar", num )
		color = IHYTM_GUI.GetBarColor( StatusBarGetCurrentValue("IHYTM_GUI_AggroBar" .. i .. "StatusBar") )
		StatusBarSetForegroundTint( "IHYTM_GUI_AggroBar" .. i .. "StatusBar", color.r, color.g, color.b)
		StatusBarSetBackgroundTint( "IHYTM_GUI_AggroBar" .. i .. "StatusBar", 0, 0, 0 )
		LabelSetText( "IHYTM_GUI_AggroBar" .. i .. "Percent", towstring(StatusBarGetCurrentValue("IHYTM_GUI_AggroBar" .. i .. "StatusBar")) .. L"%" )
		LabelSetText( "IHYTM_GUI_AggroBar" .. i .. "Name", L"hurf durf #" .. towstring(i) )

		num = num - math.random(20)
	end
end

function IHYTM_GUI.GetBarColor( percent )
	local color = { r=0, g=0, b=0 }

	local weight = 0

	weight = ( percent - IHYTM_GUI.BAR_MED_THRESHOLD ) / IHYTM_GUI.BAR_MED_THRESHOLD
	if ( weight > 0 ) then
		color.r = color.r + ( IHYTM_GUI.BAR_HIGH_TINT.r * weight )
		color.g = color.g + ( IHYTM_GUI.BAR_HIGH_TINT.g * weight )
		color.b = color.b + ( IHYTM_GUI.BAR_HIGH_TINT.b * weight )
	end

	weight = ( percent ) / IHYTM_GUI.BAR_MED_THRESHOLD
	if ( weight > 1 ) then
		weight = 2 - weight
	end
	color.r = color.r + ( IHYTM_GUI.BAR_MED_TINT.r * weight )
	color.g = color.g + ( IHYTM_GUI.BAR_MED_TINT.g * weight )
	color.b = color.b + ( IHYTM_GUI.BAR_MED_TINT.b * weight )

	weight = ( IHYTM_GUI.BAR_LOW_THRESHOLD - percent ) / IHYTM_GUI.BAR_LOW_THRESHOLD
	if ( weight <= 1 and weight > 0 ) then
		color.r = color.r + ( IHYTM_GUI.BAR_LOW_TINT.r * weight )
		color.g = color.g + ( IHYTM_GUI.BAR_LOW_TINT.g * weight )
		color.b = color.b + ( IHYTM_GUI.BAR_LOW_TINT.b * weight )
	end

	return color
end

function IHYTM_GUI.OnUpdate( elapsed )

	timeLeft = timeLeft - elapsed
	if timeLeft > 0 then
		return -- cut out early
	end
	timeLeft = TIME_DELAY -- reset to TIME_DELAY seconds
	-- this will run roughly every second. If TIME_DELAY were 2, it'd run every 2 seconds.

	-- when reloading UI with a target, the game will show the initial test window
	-- until the user clicks, this prevents it.
	if ( IHYTM.currHostileTarget == L"" and not IHYTM_GUI.test ) then
		WindowSetShowing("IHYTM_GUI", false)
	end

	--[[if ( IHYTM.currHostileTarget ~= L"" ) then
		for key, value in pairs(IHYTM.AggroTable) do
			local findStr = false
			findStr = IHYTM.CompareWStrings(key, IHYTM.currHostileTarget)]]--
			--[[if ( findStr == false ) then
				DEBUG(L"nil: " .. key .. L" ~= " .. IHYTM.currHostileTarget)
			else
				DEBUG(key .. L" == " .. IHYTM.currHostileTarget)
			end]]--
		--[[end
	end]]--

	if ( not IHYTM_GUI.test ) then
		IHYTM_GUI.SetBarInfo()
	else
		IHYTM_GUI.SetTestBarInfo()
	end

	--[[local color = { r=0, g=0, b=0 }
	color = IHYTM_GUI.GetBarColor( fakeAggro )
	StatusBarSetForegroundTint("IHYTM_GUI_AggroBar1StatusBar", color.r, color.g, color.b)
	StatusBarSetCurrentValue( "IHYTM_GUI_AggroBar1StatusBar", fakeAggro )
	LabelSetText("IHYTM_GUI_AggroBar1Name", L"Clompastompa")
	LabelSetText("IHYTM_GUI_AggroBar1Percent", towstring(fakeAggro) .. L"%")]]--
end