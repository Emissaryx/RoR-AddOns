# CanvasByEgyptianKozi

Warband tactical map canvas for Return of Reckoning. The warband leader draws
lines and arrows directly on the world map; every member running the addon sees
the drawing appear on their own map in real time.

## Usage

1. `/canvas draw` — arm draw mode (leader only by default).
2. Open the world map, **hold SHIFT and drag** the left mouse button to draw.
   Release to finish the stroke — an arrowhead is added automatically and the
   stroke is broadcast to the warband/party.
3. **SHIFT + click** (no drag) on a line erases it — for you and for everyone.
4. Right-click while drawing cancels the stroke without sending it.
5. Drawings never expire: they stay on their map until erased or `/canvas clear`.
6. Each drawing belongs to the map it was drawn on and only shows there.

## Slash commands

| Command | Effect |
|---|---|
| `/canvas` | help |
| `/canvas draw` | toggle draw mode (map input capture) |
| `/canvas clear` | erase all drawings; broadcasts the wipe if you lead |
| `/canvas color R\|G\|B\|Y\|W\|P` | brush color |
| `/canvas on` / `off` | master switch |

## How it works

- A transparent overlay window (`WarbandCanvasOverlay`) is anchored over the
  stock world map every frame. It captures mouse input **only** while draw mode
  is armed and the local player is allowed to draw — for everyone else the map
  behaves completely normally.
- The client has no `DrawLine()` API, so strokes are rendered by *texture
  stitching*: pooled 5×5 tinted dot windows spaced a few pixels apart along the
  path (max 900 dots; oldest strokes are evicted first).
- Coordinates are normalized to a 0–999 grid relative to the map window, so all
  resolutions and UI scales see the drawing in the same map location.
- Strokes are simplified with Ramer–Douglas–Peucker, serialized as
  `WBC:1:<id>:<seq>/<total>:<color>:x,y|x,y|...`, chunked under the chat length
  limit (max 6 messages, throttled to 1 per 0.6 s) and sent via `/wb` (or `/p`
  in a 6-man). Receivers reassemble, render, and suppress the raw packets from
  the visible chat log by pre-hooking `EA_ChatWindow.OnChatTextArrived`.

## Requirements

- Members must have the addon installed to see drawings.
- LibSlash (optional) for the `/canvas` command.

## Known limitations

- While draw mode is armed for the leader, non-SHIFT clicks on the map are
  swallowed by the overlay. Toggle `/canvas draw` off to interact with the map
  normally.
- Drawings are cleared on zone change (coordinates are per-map).

## License

Copyright © 2026 EgyptianKozi. All rights reserved. Redistribution or reuse of
this code without permission is not allowed.

## Changelog

### 1.0.0 — 2026-07-16

- Release build: `/canvas debug` removed, diagnostic file logging disabled
  (the addon writes nothing to disk beyond its own saved settings), release
  packages ship with comments stripped and a copyright notice.

### 0.9.0 — 2026-07-16

- Silent chat, achieved client-side ("chat mirror"): the channel-9 probe
  proved the server does not relay player sends there, so instead the addon
  disables the real party/warband chat filters on every tab and re-emits each
  human line **verbatim** (the engine's own formatting) under a mirror filter,
  colored like the original channel — while packet lines are simply never
  re-emitted. Human chat looks identical; WBC lines are gone. Original filter
  states are snapshotted per tab and restored by `/canvas off` and at logout.
- Note: warband members NOT running the addon still see the packet lines;
  everyone who should read the map must install it anyway.

### 0.8.0 — 2026-07-16

- Transport moved to chat channel 9 (the server's data channel, hidden by
  default on every client): custom player channels turned out not to exist on
  RoR, so 0.7.0's channel join always fell back to visible group chat. A
  startup handshake verifies the server relays player sends on /9 (packets are
  held, never leaked to visible chat, until the probe resolves); only if the
  probe fails does the addon fall back to group chat. Foreign lines are safe
  for the server's SoR addon (its parser hard-gates on "SoR_").

### 0.7.0 — 2026-07-16

- Chat is now completely silent while drawing. Sync packets moved off the
  warband/party channel onto a dedicated hidden chat channel (`canvasek`),
  whose filter is disabled on every chat tab — the same mechanism RoR's own
  State-of-the-Realm module uses. No visible lines, no chat bubbles.
  Incoming packets are trusted only from current warband/party members.
  If the channel join ever fails, the addon falls back to group chat.
- HUD header now reads "Canvas / By EgyptianKozi".

### 0.6.1 — 2026-07-16

- The HUD panel is draggable: hold left mouse on its background and drop it
  anywhere on the map screen. The position is saved per character and restored
  every session.
- Drawing is now strictly leader-only: the `/canvas anyone` override and its
  HUD button are removed (solo players can still practice).

### 0.6.0 — 2026-07-16

- New HUD: opening the world map shows a "Canvas" panel docked to the right of
  the map picture with everything clickable — Draw ON/OFF, Clear all, Test
  arrow, Leader-only/Anyone toggle, and the six brush colors as swatches (the
  selected color is highlighted). It appears and disappears with the map.
  Slash commands still work and stay in sync with the panel.

### 0.5.0 — 2026-07-16

- Drawings are now permanent until removed: no fade timer, `/canvas time`
  removed. (Previously lifetime ran on each receiver's own clock/settings,
  which is why drawings vanished early on other players' maps.)
- New eraser: **SHIFT + click** on a line deletes it, synced to the whole
  group (strokes carry a shared `<owner>/<id>` identity; new `E` packet).
- Removed the "«name» is drawing" chat notice — drawing is fully silent now.

### 0.4.1 — 2026-07-16

- Members now get a small local chat line — "«name» is drawing on the map
  now." — when a drawing arrives (printed on their own client only, so it adds
  no chat traffic; throttled to once per 20 s per sender).
- Faster sync pacing (0.35 s between packets, first packet sends instantly).
- Clear packets now carry a unique id so chat servers that drop repeated
  identical messages can never eat a second `/canvas clear`; clears are also
  logged on the receiving side.

**Everyone in the group must run the same version** — the sync protocol
(v2) is ignored by older builds.

### 0.4.0 — 2026-07-16

- Per-map drawings: every stroke is tagged with the zone the map screen was
  displaying when it was drawn (`EA_Window_WorldMap.currentMap`) and is only
  shown while that same map is on screen — switch zones on the map and each
  map keeps its own drawings. The zone travels in the sync packets
  (wire protocol v2; older addon versions ignore v2 packets).
- Fixed the live line suddenly cutting off mid-draw: the dot pool could be
  exhausted by recent strokes (each lives 15s) and eviction never ran during
  live drawing. The pool is bigger (1500) and headroom is reclaimed from the
  oldest finished strokes at stroke start and while sampling.
- Traveling between zones no longer wipes drawings (the per-map gate handles
  them); a half-drawn gesture is still cancelled.

### 0.3.3 — 2026-07-16

- Fixed strokes never ending (line followed the cursor after release): logs
  proved `WindowRegisterCoreEventHandler` cannot displace an XML-declared
  handler, so the MapDisplay's OnLButtonUp never reached the addon. Release is
  now detected by pre-hooking `EA_Window_WorldMap.OnClickMap` (XML dispatches
  by function name, so the hook receives the release); drag-end swallows the
  zone-click, ordinary clicks forward to it unchanged.
- A new press while a stroke is somehow still live now finishes that stroke
  (guaranteed termination, no leaked dots).

### 0.3.2 — 2026-07-16

- Input rework: live-client logging proved a reparented addon window never
  receives mouse events over the map (MapDisplay wins all hit-testing, even
  against input-enabled siblings). Mouse handlers are now registered directly
  on `EA_Window_WorldMapZoneViewMapDisplay` via `WindowRegisterCoreEventHandler`
  (the same mechanism stock RoR code uses on that exact window). The stock
  zone-click is forwarded on every mouse-up that isn't a drag-end, so normal
  map navigation is unaffected. The overlay is now a pure rendering surface.

### 0.3.1 — 2026-07-16

- Diagnostic build: writes a step-by-step trace of the input/draw/broadcast
  chain to `<game>/logs/CanvasByEgyptianKozi.log` (attachment, input-capture
  transitions, mouse enter/leave, every click with its modifier flags, gate
  decisions, stroke lifecycle, packets sent/received).
- Mouse handlers are additionally registered at runtime via
  `WindowRegisterCoreEventHandler`, in case XML-declared handlers do not
  survive `WindowSetParent` on the live client.

### 0.3.0 — 2026-07-16

- Fixed strokes being force-finished the frame they started: the map root's
  `WindowGetShowing` flag reports false on the live RoR client even when the
  map is usable, and the mid-drag safety check trusted it. Visibility now
  relies purely on child-parenting; a 30s timer covers lost mouse-ups instead.
- Added `/canvas test`: draws a sample arrow through the full render pipeline
  without needing mouse input or leadership (and broadcasts when grouped+allowed).

### 0.2.1 — 2026-07-16

- `/canvas draw` now auto-enables the addon if it was `/canvas off`, so draw
  mode can never be silently dead.
- `/canvas debug` now prints the addon version.

### 0.2.0 — 2026-07-16

- Fixed shift-drag doing nothing: the full-screen map window was swallowing all
  mouse input before the Root-level overlay could see it. The overlay is now
  re-parented INTO the map's zone view (`WindowSetParent`) and anchored exactly
  over the real map picture (`EA_Window_WorldMapZoneViewMapDisplay` — window
  names verified against the client's own UI source extracted from
  interface.myp). Drawings now also align to the map image, not the parchment
  frame, and auto-hide with the map.
- Added `/canvas debug` state dump for troubleshooting.

### 0.1.1 — 2026-07-16

- Fixed "Failed" load state: removed invalid `MAP` WARInfo category, removed the
  hard `EA_Window_WorldMap` dependency (map window is now discovered purely at
  runtime), and replaced the dot texture with a client-proven TGA format
  (1×1 RLE 24-bit, byte-identical to LibSlash's tint_square).

### 0.1.0 — 2026-07-16

- Initial release.
