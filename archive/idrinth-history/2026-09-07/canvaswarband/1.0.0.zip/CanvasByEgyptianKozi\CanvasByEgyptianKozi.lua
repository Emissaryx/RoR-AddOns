--------------------------------------------------------------------------------
-- CanvasByEgyptianKozi v1.0.0
-- Copyright (c) 2026 EgyptianKozi. All rights reserved.
-- Redistribution or reuse of this code without permission is not allowed.
--------------------------------------------------------------------------------
CanvasByEgyptianKozi = CanvasByEgyptianKozi or {}
local Canvas = CanvasByEgyptianKozi
Canvas.VERSION = "1.0.0"
Canvas.DEBUG = false
Canvas.Settings = Canvas.Settings or {}
local MSG_PREFIX          = "WBC:"   -- unique packet marker on the chat channel
local PROTOCOL            = "2"      -- v2 added the zone field (per-map drawings)
local GRID                = 1000     -- normalized coordinate space is 0..GRID-1
local SAMPLE_INTERVAL     = 0.06     -- seconds between cursor samples while dragging (~16 Hz)
local MIN_SAMPLE_DIST     = 6        -- grid units the cursor must move before a new point is kept
local MAX_POINTS_SAMPLED  = 400      -- hard cap on raw samples per stroke (runaway guard)
local DOT_SPACING         = 5        -- pixels between stitched dots along a stroke
local DOT_SIZE            = 5        -- edge length of one dot window, pixels
local MAX_DOTS            = 1500     -- global dot-window budget across all strokes
local ARROW_WING_LEN      = 14       -- pixels; length of the two arrowhead wings
local ARROW_WING_ANGLE    = 2.62     -- radians (~150 deg) between path direction and each wing
local SIMPLIFY_EPSILON    = 4        -- RDP tolerance in grid units (raised if stroke won't fit)
local MAX_CHUNKS          = 6        -- refuse to spam more than this many chat messages per stroke
local CHUNK_PAYLOAD_LEN   = 180      -- max payload characters per chunk (keeps total < chat limit)
local SEND_INTERVAL       = 0.35     -- seconds between queued chat sends (avoids "Slow down!")
local REASSEMBLY_TIMEOUT  = 12       -- seconds before an incomplete incoming stroke is dropped
local MIRROR_INTERVAL     = 10       -- seconds between re-applying tab filter states
local ERASE_RADIUS        = 25       -- grid units: how close a shift-click must be to erase a stroke
local LEADER_POLL         = 2.0      -- seconds between cached leadership re-checks
local COLORS = {
    R = { 255,  40,  40 },  -- red (default)
    G = {  40, 220,  70 },  -- green
    B = {  70, 140, 255 },  -- blue
    Y = { 255, 220,  40 },  -- yellow
    W = { 255, 255, 255 },  -- white
    P = { 255,  80, 255 },  -- pink/magenta
}
local MAP_ROOT = "EA_Window_WorldMap"
local MAP_VIEW = "EA_Window_WorldMapZoneView"
local MAP_AREA = "EA_Window_WorldMapZoneViewMapDisplay"
local OVERLAY = "WarbandCanvasOverlay"  -- must match the XML / .mod window name
local HUD     = "CanvasHUD"             -- side panel docked right of the map
Canvas.time            = 0        -- accumulated addon-relative clock, seconds
Canvas.attachedMap     = nil      -- window the overlay is anchored over (nil until first attach)
Canvas.overlayW        = 0        -- cached overlay dimensions, used to detect resizes
Canvas.overlayH        = 0
Canvas.isDrawing       = false    -- true between LButtonDown(shift) and LButtonUp
Canvas.currentStroke   = nil      -- the live (still being drawn) stroke object
Canvas.sampleTimer     = 0        -- throttle accumulator for cursor sampling
Canvas.drawStartTime   = 0        -- when the current drag began (30s failsafe)
Canvas.strokes         = {}       -- array of stroke objects currently on screen
Canvas.dotPool         = {}       -- recycled hidden dot window names
Canvas.dotCounter      = 0        -- total dot windows ever created (for unique names)
Canvas.dotsInUse       = 0        -- dots currently placed on screen
Canvas.sendQueue       = {}       -- outgoing chat strings, drained on a timer
Canvas.sendTimer       = 0
Canvas.strokeCounter   = 0        -- feeds the 2-char base36 stroke id
Canvas.inbox           = {}       -- key "sender/strokeId" -> partial reassembly entry
Canvas.playerName      = ""       -- our own cleaned character name
Canvas.canDrawCached   = false    -- leadership check result, refreshed on a timer/events
Canvas.leaderTimer     = 0
Canvas.chatHooked      = false    -- whether the EA_ChatWindow suppression hook is installed
Canvas.logReady        = false    -- file logger initialized (logs/CanvasByEgyptianKozi.log)
Canvas.clickMapHooked  = false    -- EA_Window_WorldMap.OnClickMap release hook installed
Canvas.mirrorSnapshot  = {}       -- tabLog -> original group-filter states (for restore)
Canvas.mirrorTimer     = 0        -- periodic filter re-apply accumulator
Canvas.mirrorActive    = false    -- chat mirror currently applied
Canvas.lastMapShown    = -1       -- displayed zone id last frame (per-map visibility)
Canvas.hudCreated      = false    -- HUD buttons/swatches instantiated
Canvas.hudActions      = {}       -- button window name -> slash-command action
Canvas.hudSwatches     = {}       -- swatch window name -> color letter
local function Print(text)
    if EA_ChatWindow and EA_ChatWindow.Print then
        pcall(EA_ChatWindow.Print, towstring("[Canvas] " .. text))
    end
end
local LOG_NAME = "CanvasByEgyptianKozi"
function Canvas.InitLog()
    if not Canvas.DEBUG then return end -- release builds write no log file
    if type(TextLogCreate) ~= "function" then return end
    TextLogCreate(LOG_NAME, 2000)
    TextLogSetEnabled(LOG_NAME, true)
    TextLogSetIncrementalSaving(LOG_NAME, true, StringToWString("logs/" .. LOG_NAME .. ".log"))
    Canvas.logReady = true
end
local function Log(msg)
    if Canvas.logReady and type(TextLogAddEntry) == "function" then
        pcall(TextLogAddEntry, LOG_NAME, 0,
            towstring("[" .. string.format("%.2f", Canvas.time) .. "] " .. msg))
    end
end
local function clamp(v, lo, hi)
    if v < lo then return lo end
    if v > hi then return hi end
    return v
end
local function HasFlag(flags, flag)
    if type(flags) ~= "number" or type(flag) ~= "number" or flag <= 0 then
        return false
    end
    local q = math.floor(flags / flag)
    return (q - 2 * math.floor(q / 2)) == 1
end
local function ShiftFlag()
    if SystemData and SystemData.ButtonFlags and SystemData.ButtonFlags.SHIFT then
        return SystemData.ButtonFlags.SHIFT
    end
    return 1 -- stock client value
end
function Canvas.FixName(name)
    if name == nil then return "" end
    local s = name
    if type(s) ~= "string" then
        s = WStringToString(towstring(s))
    end
    local caret = string.find(s, "^", 1, true)
    if caret then
        s = string.sub(s, 1, caret - 1)
    end
    return s
end
local BASE36 = "0123456789abcdefghijklmnopqrstuvwxyz"
local function ToBase36Pair(n)
    n = math.floor(n) - math.floor(math.floor(n) / 1296) * 1296 -- n % 1296
    local hi = math.floor(n / 36)
    local lo = n - hi * 36
    return string.sub(BASE36, hi + 1, hi + 1) .. string.sub(BASE36, lo + 1, lo + 1)
end
local function ApplyDefaultSettings()
    local s = Canvas.Settings
    if s.enabled       == nil then s.enabled       = true  end -- master switch (render + broadcast)
    if s.drawMode      == nil then s.drawMode      = false end -- overlay input capture on/off
    if s.colorKey      == nil then s.colorKey      = "R"   end -- brush color letter
    if COLORS[s.colorKey] == nil then s.colorKey = "R" end      -- heal corrupt saves
    s.fadeDuration  = nil -- retired in 0.5.0: strokes persist until erased/cleared
    s.anyoneCanDraw = nil -- retired in 0.6.1: drawing is strictly leader-only
end
function Canvas.Initialize()
    ApplyDefaultSettings()
    Canvas.InitLog()
    Canvas.playerName = Canvas.FixName(GameData.Player.name)
    Log("Initialize v" .. Canvas.VERSION .. " player=" .. Canvas.playerName
        .. " enabled=" .. tostring(Canvas.Settings.enabled)
        .. " drawMode=" .. tostring(Canvas.Settings.drawMode))
    RegisterEventHandler(SystemData.Events.CHAT_TEXT_ARRIVED, "CanvasByEgyptianKozi.OnChatTextArrived")
    if type(TextLogGetUpdateEventId) == "function" then
        RegisterEventHandler(TextLogGetUpdateEventId("Chat"), "CanvasByEgyptianKozi.OnChatLogUpdated")
    end
    if SystemData.Events.GROUP_STATUS_UPDATED then
        RegisterEventHandler(SystemData.Events.GROUP_STATUS_UPDATED, "CanvasByEgyptianKozi.RefreshLeadership")
    end
    if SystemData.Events.BATTLEGROUP_UPDATED then
        RegisterEventHandler(SystemData.Events.BATTLEGROUP_UPDATED, "CanvasByEgyptianKozi.RefreshLeadership")
    end
    if SystemData.Events.LOADING_END then
        RegisterEventHandler(SystemData.Events.LOADING_END, "CanvasByEgyptianKozi.OnZoneChanged")
    end
    Canvas.RegisterSlashCommands()
    Canvas.RefreshLeadership()
    Print("v" .. Canvas.VERSION .. " loaded. /canvas for options, /canvas draw to start painting.")
end
function Canvas.RegisterSlashCommands()
    if LibSlash and type(LibSlash.RegisterSlashCmd) == "function" then
        pcall(LibSlash.RegisterSlashCmd, "canvas", Canvas.OnSlashCommand)
    else
        Print("LibSlash not found - the /canvas command is unavailable (addon still works).")
    end
end
Canvas.mirrorMap = nil
local function BuildMirrorMap()
    local f = SystemData.ChatLogFilters
    if f == nil or f.GROUP == nil then return nil end
    local map = {}
    map[f.GROUP]           = { mirror = f.CHANNEL_7, r = 120, g = 180, b = 255 }
    map[f.BATTLEGROUP]     = { mirror = f.CHANNEL_8, r = 178, g = 255, b = 116 }
    if f.SCENARIO_GROUPS then
        map[f.SCENARIO_GROUPS] = { mirror = f.CHANNEL_8, r = 178, g = 255, b = 116 }
    end
    if f.SCENARIO then
        map[f.SCENARIO]        = { mirror = f.CHANNEL_8, r = 178, g = 255, b = 116 }
    end
    return map
end
local function ForEachChatTab(fn)
    if type(EA_ChatWindowGroups) ~= "table" or type(EA_ChatTabManager) ~= "table"
       or type(EA_ChatTabManager.GetTabName) ~= "function" then
        return
    end
    for _, wndGroup in ipairs(EA_ChatWindowGroups) do
        if wndGroup.used == true and type(wndGroup.Tabs) == "table" then
            for _, tab in ipairs(wndGroup.Tabs) do
                local tabName = EA_ChatTabManager.GetTabName(tab.tabManagerId)
                if tabName then
                    fn(tabName .. "TextLog")
                end
            end
        end
    end
end
function Canvas.ApplyChatMirror()
    if Canvas.mirrorMap == nil then
        Canvas.mirrorMap = BuildMirrorMap()
        if Canvas.mirrorMap == nil then return end
    end
    if type(LogDisplaySetFilterState) ~= "function" then return end
    ForEachChatTab(function(tabLog)
        local snap = Canvas.mirrorSnapshot[tabLog]
        if snap == nil then
            snap = {}
            for realId, m in pairs(Canvas.mirrorMap) do
                local wasOn = true
                if type(LogDisplayGetFilterState) == "function" then
                    local ok, state = pcall(LogDisplayGetFilterState, tabLog, "Chat", realId)
                    if ok and state ~= nil then wasOn = state and true or false end
                end
                snap[realId] = wasOn
                LogDisplaySetFilterState(tabLog, "Chat", m.mirror, wasOn)
                if type(LogDisplaySetFilterColor) == "function" then
                    pcall(LogDisplaySetFilterColor, tabLog, "Chat", m.mirror, m.r, m.g, m.b)
                end
            end
            Canvas.mirrorSnapshot[tabLog] = snap
            Log("chat mirror applied to " .. tabLog)
        end
        for realId in pairs(Canvas.mirrorMap) do
            LogDisplaySetFilterState(tabLog, "Chat", realId, false)
        end
    end)
    Canvas.mirrorActive = true
end
function Canvas.RestoreChatMirror()
    if not Canvas.mirrorActive or Canvas.mirrorMap == nil then return end
    if type(LogDisplaySetFilterState) ~= "function" then return end
    for tabLog, snap in pairs(Canvas.mirrorSnapshot) do
        for realId, wasOn in pairs(snap) do
            LogDisplaySetFilterState(tabLog, "Chat", realId, wasOn)
            local m = Canvas.mirrorMap[realId]
            if m then
                LogDisplaySetFilterState(tabLog, "Chat", m.mirror, false)
            end
        end
    end
    Canvas.mirrorSnapshot = {}
    Canvas.mirrorActive = false
    Log("chat mirror restored")
end
function Canvas.OnChatLogUpdated(updateType, filterType)
    if updateType ~= SystemData.TextLogUpdate.ADDED then return end
    if not Canvas.Settings.enabled or not Canvas.mirrorActive then return end
    if Canvas.mirrorMap == nil then return end
    local m = Canvas.mirrorMap[filterType]
    if m == nil then return end
    local _, _, text = TextLogGetEntry("Chat", TextLogGetNumEntries("Chat") - 1)
    if text == nil then return end
    local plain = WStringToString(towstring(text))
    if string.find(plain, MSG_PREFIX, 1, true) then
        return -- packet line: silenced for good
    end
    TextLogAddEntry("Chat", m.mirror, text)
end
function Canvas.UpdateChatMirror(elapsed)
    if Canvas.time < 3 then return end
    Canvas.mirrorTimer = Canvas.mirrorTimer + elapsed
    if not Canvas.mirrorActive or Canvas.mirrorTimer >= MIRROR_INTERVAL then
        Canvas.mirrorTimer = 0
        Canvas.ApplyChatMirror()
    end
end
function Canvas.ComputeIsLeader()
    local inParty   = type(GetNumGroupmates) == "function" and (GetNumGroupmates() or 0) > 0
    local inWarband = type(IsWarBandActive) == "function" and IsWarBandActive()
    if not inParty and not inWarband then
        return true -- solo: free practice
    end
    if inWarband and type(GetBattlegroupMemberData) == "function" then
        local ok, data = pcall(GetBattlegroupMemberData)
        if ok and type(data) == "table" then
            for _, group in pairs(data) do
                if type(group) == "table" and type(group.players) == "table" then
                    for _, p in pairs(group.players) do
                        if type(p) == "table" and p.name ~= nil
                           and Canvas.FixName(p.name) == Canvas.playerName then
                            return p.isGroupLeader == true
                        end
                    end
                end
            end
        end
        return false -- in a warband but couldn't find/verify ourselves: deny
    end
    if PartyUtils and type(PartyUtils.GetPartyData) == "function" then
        local ok, gdata = pcall(PartyUtils.GetPartyData)
        if ok and type(gdata) == "table" then
            for _, m in pairs(gdata) do
                if type(m) == "table" and m.isGroupLeader == true
                   and m.name ~= nil and Canvas.FixName(m.name) ~= Canvas.playerName then
                    return false -- somebody else is the leader
                end
            end
        end
    end
    return true
end
function Canvas.CanDraw()
    return Canvas.canDrawCached -- strictly the warband/party leader (or solo)
end
function Canvas.RefreshLeadership()
    Canvas.canDrawCached = Canvas.ComputeIsLeader()
end
function Canvas.OnZoneChanged()
    Canvas.CancelCurrentStroke()
    Canvas.inbox = {}
end
function Canvas.MapIsOpen()
    return DoesWindowExist(MAP_ROOT) and WindowGetShowing(MAP_ROOT)
end
function Canvas.UpdateAttachment()
    if Canvas.attachedMap == nil then
        if not DoesWindowExist(MAP_VIEW) then
            return -- stock map module not up yet; try again next frame
        end
        local area = DoesWindowExist(MAP_AREA) and MAP_AREA or MAP_VIEW
        WindowSetParent(OVERLAY, MAP_VIEW)
        WindowClearAnchors(OVERLAY)
        WindowAddAnchor(OVERLAY, "topleft",     area, "topleft",     0, 0)
        WindowAddAnchor(OVERLAY, "bottomright", area, "bottomright", 0, 0)
        WindowSetScale(OVERLAY, WindowGetScale(area))
        WindowSetShowing(OVERLAY, true)
        WindowSetHandleInput(OVERLAY, false)
        if area == MAP_AREA then
            WindowRegisterCoreEventHandler(MAP_AREA, "OnLButtonDown", "CanvasByEgyptianKozi.OnOverlayLButtonDown")
            WindowRegisterCoreEventHandler(MAP_AREA, "OnRButtonUp",   "CanvasByEgyptianKozi.OnOverlayRButtonUp")
            Log("mouse handlers registered on " .. MAP_AREA)
        end
        if not Canvas.clickMapHooked and EA_Window_WorldMap
           and type(EA_Window_WorldMap.OnClickMap) == "function" then
            local original = EA_Window_WorldMap.OnClickMap
            EA_Window_WorldMap.OnClickMap = function()
                if Canvas.isDrawing then
                    Log("OnClickMap: drag release - finishing stroke")
                    Canvas.FinishCurrentStroke()
                    return -- swallow: drag-end must not also zone-click
                end
                return original()
            end
            Canvas.clickMapHooked = true
            Log("EA_Window_WorldMap.OnClickMap hooked for release detection")
        end
        Canvas.attachedMap = area
        local w, h = WindowGetDimensions(OVERLAY)
        Log("attached: parent=" .. MAP_VIEW .. " area=" .. area
            .. " dims=" .. tostring(w) .. "x" .. tostring(h)
            .. " scale=" .. tostring(WindowGetScale(OVERLAY)))
        Canvas.CreateHUD()
    end
    local w, h = WindowGetDimensions(OVERLAY)
    if w and h and w > 0 and h > 0 then
        if math.abs(w - Canvas.overlayW) > 1 or math.abs(h - Canvas.overlayH) > 1 then
            Canvas.overlayW = w
            Canvas.overlayH = h
            Canvas.RelayoutAllStrokes()
        end
    end
end
function Canvas.MouseToGrid()
    if Canvas.attachedMap == nil then return nil end
    if not (SystemData and SystemData.MousePosition) then return nil end
    local mx = tonumber(SystemData.MousePosition.x)
    local my = tonumber(SystemData.MousePosition.y)
    if mx == nil or my == nil then return nil end
    local wx, wy = WindowGetScreenPosition(OVERLAY)
    local w, h   = WindowGetDimensions(OVERLAY)
    local scale  = WindowGetScale(OVERLAY)
    if not (wx and wy and w and h) or w <= 0 or h <= 0 then return nil end
    if scale == nil or scale <= 0 then scale = 1 end
    local localX = (mx - wx) / scale
    local localY = (my - wy) / scale
    local gx = math.floor(clamp(localX / w, 0, 1) * (GRID - 1) + 0.5)
    local gy = math.floor(clamp(localY / h, 0, 1) * (GRID - 1) + 0.5)
    return gx, gy
end
function Canvas.GetDisplayedMap()
    if EA_Window_WorldMap and type(EA_Window_WorldMap.currentMap) == "number" then
        return EA_Window_WorldMap.currentMap
    end
    return 0
end
function Canvas.GridToLocal(gx, gy)
    local w, h = WindowGetDimensions(OVERLAY)
    if not (w and h) or w <= 0 or h <= 0 then return 0, 0 end
    return (gx / (GRID - 1)) * w, (gy / (GRID - 1)) * h
end
local SWATCH_ORDER = { "R", "G", "B", "Y", "W", "P" }
local HUD_BUTTONS = {
    { id = "Draw",  action = "draw"  },
    { id = "Clear", action = "clear" },
    { id = "Test",  action = "test"  },
}
function Canvas.CreateHUD()
    if Canvas.hudCreated then return end
    Canvas.hudCreated = true
    WindowSetParent(HUD, MAP_VIEW)
    WindowClearAnchors(HUD)
    if Canvas.Settings.hudX ~= nil and Canvas.Settings.hudY ~= nil then
        WindowAddAnchor(HUD, "topleft", MAP_VIEW, "topleft", Canvas.Settings.hudX, Canvas.Settings.hudY)
    else
        WindowAddAnchor(HUD, "topright", Canvas.attachedMap, "topleft", 18, 40)
    end
    WindowSetShowing(HUD, true) -- child of the zone view: visible only with the map
    WindowSetTintColor(HUD .. "Bg", 12, 12, 12)
    WindowSetAlpha(HUD .. "Bg", 0.80)
    LabelSetText(HUD .. "Title", L"Canvas")
    LabelSetTextColor(HUD .. "Title", 255, 200, 80)
    LabelSetText(HUD .. "Sub", L"By EgyptianKozi")
    LabelSetTextColor(HUD .. "Sub", 230, 180, 90)
    LabelSetText(HUD .. "Hint1", L"Shift+drag: draw")
    LabelSetText(HUD .. "Hint2", L"Shift+click line: erase")
    LabelSetTextColor(HUD .. "Hint1", 200, 200, 200)
    LabelSetTextColor(HUD .. "Hint2", 200, 200, 200)
    local y = 56
    for _, def in ipairs(HUD_BUTTONS) do
        local name = HUD .. "Btn" .. def.id
        CreateWindowFromTemplate(name, "CanvasHUDButtonTemplate", HUD)
        WindowClearAnchors(name)
        WindowAddAnchor(name, "topleft", HUD, "topleft", 12, y)
        WindowSetShowing(name, true)
        Canvas.hudActions[name] = def.action
        y = y + 32
    end
    local baseY = y + 8
    for i, colorKey in ipairs(SWATCH_ORDER) do
        local name = HUD .. "Swatch" .. colorKey
        CreateWindowFromTemplate(name, "CanvasHUDSwatchTemplate", HUD)
        WindowClearAnchors(name)
        local col = i - 1 - 3 * math.floor((i - 1) / 3) -- (i-1) % 3
        local row = math.floor((i - 1) / 3)
        WindowAddAnchor(name, "topleft", HUD, "topleft", 22 + col * 46, baseY + row * 34)
        WindowSetShowing(name, true)
        local c = COLORS[colorKey]
        WindowSetTintColor(name .. "Bg", c[1], c[2], c[3])
        Canvas.hudSwatches[name] = colorKey
    end
    Canvas.UpdateHUD()
    Log("HUD created, docked right of " .. tostring(Canvas.attachedMap))
end
function Canvas.UpdateHUD()
    if not Canvas.hudCreated then return end
    local btn = HUD .. "BtnDraw"
    if Canvas.Settings.drawMode then
        LabelSetText(btn .. "Label", L"Draw: ON")
        WindowSetTintColor(btn .. "Bg", 40, 110, 40)
    else
        LabelSetText(btn .. "Label", L"Draw: OFF")
        WindowSetTintColor(btn .. "Bg", 70, 70, 70)
    end
    WindowSetAlpha(btn .. "Bg", 0.9)
    btn = HUD .. "BtnClear"
    LabelSetText(btn .. "Label", L"Clear all")
    WindowSetTintColor(btn .. "Bg", 120, 45, 45)
    WindowSetAlpha(btn .. "Bg", 0.9)
    btn = HUD .. "BtnTest"
    LabelSetText(btn .. "Label", L"Test arrow")
    WindowSetTintColor(btn .. "Bg", 70, 70, 70)
    WindowSetAlpha(btn .. "Bg", 0.9)
    for name, colorKey in pairs(Canvas.hudSwatches) do
        local c = COLORS[colorKey]
        WindowSetTintColor(name .. "Bg", c[1], c[2], c[3])
        WindowSetAlpha(name .. "Bg", (colorKey == Canvas.Settings.colorKey) and 1.0 or 0.35)
    end
end
function Canvas.OnHUDButtonClick()
    local name = SystemData.ActiveWindow.name
    local action = Canvas.hudActions[name]
    if action then
        Canvas.OnSlashCommand(action)
    end
    Canvas.UpdateHUD()
end
function Canvas.OnHUDSwatchClick()
    local name = SystemData.ActiveWindow.name
    local colorKey = Canvas.hudSwatches[name]
    if colorKey then
        Canvas.Settings.colorKey = colorKey
    end
    Canvas.UpdateHUD()
end
function Canvas.OnHUDButtonHover()
    local name = SystemData.ActiveWindow.name
    if Canvas.hudActions[name] or Canvas.hudSwatches[name] then
        WindowSetTintColor(name .. "Bg", 150, 150, 150)
        WindowSetAlpha(name .. "Bg", 1.0)
    end
end
function Canvas.OnHUDButtonHoverEnd()
    Canvas.UpdateHUD() -- restores every tint/alpha from state
end
function Canvas.OnHUDPanelMouseUp()
    local hx, hy = WindowGetScreenPosition(HUD)
    local px, py = WindowGetScreenPosition(MAP_VIEW)
    local scale = WindowGetScale(HUD)
    if hx == nil or px == nil then return end
    if scale == nil or scale <= 0 then scale = 1 end
    local x = (hx - px) / scale
    local y = (hy - py) / scale
    Canvas.Settings.hudX = x
    Canvas.Settings.hudY = y
    WindowClearAnchors(HUD)
    WindowAddAnchor(HUD, "topleft", MAP_VIEW, "topleft", x, y)
    Log("HUD moved to " .. math.floor(x) .. "," .. math.floor(y))
end
function Canvas.AcquireDot()
    local name = table.remove(Canvas.dotPool)
    if name == nil then
        Canvas.dotCounter = Canvas.dotCounter + 1
        name = "CanvasDot" .. Canvas.dotCounter
        CreateWindowFromTemplate(name, "CanvasDotTemplate", OVERLAY)
        pcall(DynamicImageSetTexture, name .. "Image", "CanvasByEgyptianKoziDot", 0, 0)
        pcall(DynamicImageSetTextureDimensions, name .. "Image", 1, 1)
    end
    Canvas.dotsInUse = Canvas.dotsInUse + 1
    return name
end
function Canvas.ReleaseDot(name)
    WindowSetShowing(name, false)
    Canvas.dotsInUse = Canvas.dotsInUse - 1
    table.insert(Canvas.dotPool, name)
end
function Canvas.PlaceDot(name, x, y, color, alpha)
    WindowSetDimensions(name, DOT_SIZE, DOT_SIZE)
    WindowSetDimensions(name .. "Image", DOT_SIZE, DOT_SIZE)
    WindowClearAnchors(name)
    WindowAddAnchor(name, "topleft", OVERLAY, "center", x, y)
    WindowSetTintColor(name .. "Image", color[1], color[2], color[3])
    WindowSetAlpha(name, alpha or 1.0)
    WindowSetShowing(name, true)
end
local function NewStroke(colorKey, live, zone)
    return {
        points   = {},
        colorKey = COLORS[colorKey] and colorKey or "R",
        live     = live or false,
        zone     = zone or 0,
        key      = nil,
        dots     = {},
    }
end
function Canvas.ReleaseStrokeDots(stroke)
    for i = 1, #stroke.dots do
        Canvas.ReleaseDot(stroke.dots[i])
    end
    stroke.dots = {}
end
function Canvas.EnsureDotBudget(needed)
    while Canvas.dotsInUse + needed > MAX_DOTS do
        local victimIndex = nil
        for i = 1, #Canvas.strokes do
            if not Canvas.strokes[i].live then victimIndex = i break end
        end
        if victimIndex == nil then return end -- only live strokes left; degrade below
        local victim = table.remove(Canvas.strokes, victimIndex)
        Canvas.ReleaseStrokeDots(victim)
    end
end
function Canvas.StitchSegment(stroke, x1, y1, x2, y2, skipFirst)
    local dx, dy = x2 - x1, y2 - y1
    local dist = math.sqrt(dx * dx + dy * dy)
    local steps = math.floor(dist / DOT_SPACING)
    local color = COLORS[stroke.colorKey]
    local from = skipFirst and 1 or 0
    for s = from, steps do
        local t
        if steps == 0 then t = 1 else t = s / steps end
        if Canvas.dotsInUse >= MAX_DOTS then return end -- hard budget guard
        local dot = Canvas.AcquireDot()
        Canvas.PlaceDot(dot, x1 + dx * t, y1 + dy * t, color, 1.0)
        table.insert(stroke.dots, dot)
    end
end
function Canvas.StitchArrowHead(stroke)
    local n = #stroke.points
    if n < 2 then return end
    local tipG = stroke.points[n]
    local prevG = nil
    for i = n - 1, 1, -1 do
        local p = stroke.points[i]
        if p[1] ~= tipG[1] or p[2] ~= tipG[2] then prevG = p break end
    end
    if prevG == nil then return end
    local tx, ty = Canvas.GridToLocal(tipG[1], tipG[2])
    local px, py = Canvas.GridToLocal(prevG[1], prevG[2])
    local angle = math.atan2(ty - py, tx - px) -- direction of travel at the tip
    for _, side in pairs({ -1, 1 }) do
        local wingAngle = angle + side * ARROW_WING_ANGLE
        local wx = tx + math.cos(wingAngle) * ARROW_WING_LEN
        local wy = ty + math.sin(wingAngle) * ARROW_WING_LEN
        Canvas.StitchSegment(stroke, tx, ty, wx, wy, true)
    end
end
function Canvas.LayoutStroke(stroke)
    Canvas.ReleaseStrokeDots(stroke)
    if stroke.zone ~= Canvas.GetDisplayedMap() then
        return -- belongs to another map; dots return when that map is shown
    end
    local n = #stroke.points
    if n == 0 then return end
    local x1, y1 = Canvas.GridToLocal(stroke.points[1][1], stroke.points[1][2])
    if n == 1 then
        local dot = Canvas.AcquireDot()
        Canvas.PlaceDot(dot, x1, y1, COLORS[stroke.colorKey], 1.0)
        table.insert(stroke.dots, dot)
        return
    end
    for i = 2, n do
        local x2, y2 = Canvas.GridToLocal(stroke.points[i][1], stroke.points[i][2])
        Canvas.StitchSegment(stroke, x1, y1, x2, y2, i > 2)
        x1, y1 = x2, y2
    end
    if not stroke.live then
        Canvas.StitchArrowHead(stroke)
    end
end
function Canvas.RefreshMapVisibility()
    local shown = Canvas.GetDisplayedMap()
    if shown == Canvas.lastMapShown then return end
    Canvas.lastMapShown = shown
    Log("displayed map -> " .. tostring(shown))
    if Canvas.isDrawing and Canvas.currentStroke and Canvas.currentStroke.zone ~= shown then
        Canvas.FinishCurrentStroke()
    end
    for i = 1, #Canvas.strokes do
        Canvas.LayoutStroke(Canvas.strokes[i])
    end
end
function Canvas.RelayoutAllStrokes()
    for i = 1, #Canvas.strokes do
        Canvas.LayoutStroke(Canvas.strokes[i])
    end
    if Canvas.currentStroke then
        Canvas.LayoutStroke(Canvas.currentStroke)
    end
end
function Canvas.ClearAllStrokes()
    for i = 1, #Canvas.strokes do
        Canvas.ReleaseStrokeDots(Canvas.strokes[i])
    end
    Canvas.strokes = {}
end
function Canvas.OnOverlayLButtonDown(flags, x, y)
    Log("LButtonDown flags=" .. tostring(flags)
        .. " shiftConst=" .. tostring(ShiftFlag())
        .. " x=" .. tostring(x) .. " y=" .. tostring(y))
    if Canvas.isDrawing then
        Log("  finishing previous stroke (new press while drawing)")
        Canvas.FinishCurrentStroke()
        return
    end
    if not (Canvas.Settings.enabled and Canvas.Settings.drawMode) then
        Log("  gate: enabled/drawMode failed")
        return
    end
    if not Canvas.CanDraw() then
        Log("  gate: not leader")
        Print("Only the warband/party leader may draw.")
        return
    end
    if not HasFlag(flags, ShiftFlag()) then
        Log("  gate: SHIFT not held")
        return -- plain click: intentionally inert so misclicks never paint
    end
    local gx, gy = Canvas.MouseToGrid()
    if gx == nil then
        Log("  gate: MouseToGrid returned nil (no attach/geometry)")
        return
    end
    Log("  stroke started at grid " .. gx .. "," .. gy)
    Canvas.EnsureDotBudget(150)
    Canvas.isDrawing = true
    Canvas.sampleTimer = 0
    Canvas.drawStartTime = Canvas.time
    Canvas.currentStroke = NewStroke(Canvas.Settings.colorKey, true, Canvas.GetDisplayedMap())
    table.insert(Canvas.currentStroke.points, { gx, gy })
end
function Canvas.SampleDrag(elapsed)
    if not Canvas.isDrawing or Canvas.currentStroke == nil then return end
    if Canvas.time - (Canvas.drawStartTime or 0) > 30 then
        Canvas.FinishCurrentStroke()
        return
    end
    Canvas.sampleTimer = Canvas.sampleTimer + elapsed
    if Canvas.sampleTimer < SAMPLE_INTERVAL then return end
    Canvas.sampleTimer = 0
    local gx, gy = Canvas.MouseToGrid()
    if gx == nil then return end
    local pts = Canvas.currentStroke.points
    local last = pts[#pts]
    local dx, dy = gx - last[1], gy - last[2]
    if (dx * dx + dy * dy) < (MIN_SAMPLE_DIST * MIN_SAMPLE_DIST) then
        return -- didn't move far enough to be a new path vertex
    end
    if #pts >= MAX_POINTS_SAMPLED then
        Canvas.FinishCurrentStroke() -- pathological drag; close it out safely
        return
    end
    table.insert(pts, { gx, gy })
    if Canvas.dotsInUse > MAX_DOTS - 40 then
        Canvas.EnsureDotBudget(60)
    end
    local x1, y1 = Canvas.GridToLocal(last[1], last[2])
    local x2, y2 = Canvas.GridToLocal(gx, gy)
    Canvas.StitchSegment(Canvas.currentStroke, x1, y1, x2, y2, true)
end
function Canvas.OnOverlayLButtonUp(flags, x, y)
    Log("LButtonUp isDrawing=" .. tostring(Canvas.isDrawing))
    if Canvas.isDrawing then
        Canvas.FinishCurrentStroke()
    end
end
function Canvas.OnOverlayRButtonUp(flags, x, y)
    if Canvas.isDrawing then
        Log("RButtonUp: stroke cancelled")
        Canvas.CancelCurrentStroke()
    end
end
function Canvas.CancelCurrentStroke()
    if Canvas.currentStroke then
        Canvas.ReleaseStrokeDots(Canvas.currentStroke)
    end
    Canvas.currentStroke = nil
    Canvas.isDrawing = false
end
function Canvas.FinishCurrentStroke()
    local stroke = Canvas.currentStroke
    Canvas.currentStroke = nil
    Canvas.isDrawing = false
    if stroke == nil then return end
    if #stroke.points < 2 then
        Canvas.ReleaseStrokeDots(stroke)
        local p = stroke.points[1]
        if p then Canvas.EraseAt(p[1], p[2]) end
        return
    end
    stroke.live = false
    Canvas.strokeCounter = Canvas.strokeCounter + 1
    stroke.wireId = ToBase36Pair(Canvas.strokeCounter + math.floor(Canvas.time * 7))
    stroke.key = Canvas.playerName .. "/" .. stroke.wireId
    table.insert(Canvas.strokes, stroke)
    Canvas.LayoutStroke(stroke)
    Log("stroke finished: " .. #stroke.points .. " points, " .. #stroke.dots
        .. " dots, zone=" .. tostring(stroke.zone))
    Canvas.BroadcastStroke(stroke)
end
local function PerpendicularDistance(px, py, ax, ay, bx, by)
    local dx, dy = bx - ax, by - ay
    local len2 = dx * dx + dy * dy
    if len2 == 0 then
        local ex, ey = px - ax, py - ay
        return math.sqrt(ex * ex + ey * ey)
    end
    local t = clamp(((px - ax) * dx + (py - ay) * dy) / len2, 0, 1)
    local cx, cy = ax + t * dx, ay + t * dy
    local ex, ey = px - cx, py - cy
    return math.sqrt(ex * ex + ey * ey)
end
function Canvas.SimplifyPath(points, epsilon)
    local n = #points
    if n < 3 then return points end
    local keep = {}
    keep[1], keep[n] = true, true
    local stack = { { 1, n } }
    while #stack > 0 do
        local seg = table.remove(stack)
        local a, b = seg[1], seg[2]
        local maxDist, maxIdx = -1, nil
        for i = a + 1, b - 1 do
            local d = PerpendicularDistance(
                points[i][1], points[i][2],
                points[a][1], points[a][2],
                points[b][1], points[b][2])
            if d > maxDist then maxDist, maxIdx = d, i end
        end
        if maxIdx ~= nil and maxDist > epsilon then
            keep[maxIdx] = true
            table.insert(stack, { a, maxIdx })
            table.insert(stack, { maxIdx, b })
        end
    end
    local out = {}
    for i = 1, n do
        if keep[i] then table.insert(out, points[i]) end
    end
    return out
end
function Canvas.EraseAt(gx, gy)
    local shown = Canvas.GetDisplayedMap()
    local bestIdx, bestDist = nil, ERASE_RADIUS
    for i = 1, #Canvas.strokes do
        local s = Canvas.strokes[i]
        if s.zone == shown then
            local pts = s.points
            local segs = #pts - 1
            if segs < 1 then segs = 1 end -- single-point "ping": degenerate segment
            for j = 1, segs do
                local a = pts[j]
                local b = pts[j + 1] or a
                local d = PerpendicularDistance(gx, gy, a[1], a[2], b[1], b[2])
                if d <= bestDist then
                    bestDist = d
                    bestIdx = i
                end
            end
        end
    end
    if bestIdx == nil then
        Log("erase: nothing within " .. ERASE_RADIUS .. " of " .. gx .. "," .. gy)
        return
    end
    local victim = table.remove(Canvas.strokes, bestIdx)
    Canvas.ReleaseStrokeDots(victim)
    Log("erased stroke key=" .. tostring(victim.key))
    if victim.key and Canvas.HasGroupChannel() then
        Canvas.strokeCounter = Canvas.strokeCounter + 1
        local id = ToBase36Pair(Canvas.strokeCounter + math.floor(Canvas.time * 7))
        table.insert(Canvas.sendQueue,
            MSG_PREFIX .. PROTOCOL .. ":" .. id .. ":1/1:E:0:" .. victim.key)
    end
end
function Canvas.EraseByKey(key, sender)
    for i = 1, #Canvas.strokes do
        if Canvas.strokes[i].key == key then
            local victim = table.remove(Canvas.strokes, i)
            Canvas.ReleaseStrokeDots(victim)
            Log("erase received from " .. sender .. " key=" .. key)
            return
        end
    end
    Log("erase from " .. sender .. " ignored: no stroke with key=" .. tostring(key))
end
local function EncodeTokens(points)
    local tokens = {}
    for i = 1, #points do
        tokens[i] = points[i][1] .. "," .. points[i][2]
    end
    return tokens
end
local function PackChunks(tokens)
    local chunks, current = {}, ""
    for i = 1, #tokens do
        local tok = tokens[i]
        if current == "" then
            current = tok
        elseif string.len(current) + 1 + string.len(tok) <= CHUNK_PAYLOAD_LEN then
            current = current .. "|" .. tok
        else
            table.insert(chunks, current)
            current = tok
        end
    end
    if current ~= "" then table.insert(chunks, current) end
    return chunks
end
function Canvas.BroadcastStroke(stroke)
    if not Canvas.HasGroupChannel() then
        return -- solo practice: local render only, nothing to broadcast
    end
    local epsilon = SIMPLIFY_EPSILON
    local simplified = Canvas.SimplifyPath(stroke.points, epsilon)
    local chunks = PackChunks(EncodeTokens(simplified))
    while #chunks > MAX_CHUNKS and epsilon < GRID do
        epsilon = epsilon * 2
        simplified = Canvas.SimplifyPath(stroke.points, epsilon)
        chunks = PackChunks(EncodeTokens(simplified))
    end
    if #chunks > MAX_CHUNKS then
        Print("Stroke too complex to sync - drawn locally only.")
        return
    end
    local id = stroke.wireId
    local total = #chunks
    for seq = 1, total do
        local msg = MSG_PREFIX .. PROTOCOL .. ":" .. id .. ":" .. seq .. "/" .. total
            .. ":" .. stroke.colorKey .. ":" .. tostring(stroke.zone) .. ":" .. chunks[seq]
        table.insert(Canvas.sendQueue, msg)
    end
    Log("broadcast queued: id=" .. id .. " " .. total .. " chunk(s), "
        .. #simplified .. " simplified points (epsilon " .. epsilon .. ")")
end
function Canvas.BroadcastClear()
    if Canvas.HasGroupChannel() then
        Canvas.strokeCounter = Canvas.strokeCounter + 1
        local id = ToBase36Pair(Canvas.strokeCounter + math.floor(Canvas.time * 7))
        table.insert(Canvas.sendQueue,
            MSG_PREFIX .. PROTOCOL .. ":" .. id .. ":1/1:X:0:0")
        Log("clear broadcast queued (id=" .. id .. ")")
    end
end
function Canvas.HasGroupChannel()
    local inParty   = type(GetNumGroupmates) == "function" and (GetNumGroupmates() or 0) > 0
    local inWarband = type(IsWarBandActive) == "function" and IsWarBandActive()
    return inParty or inWarband
end
function Canvas.UpdateSendQueue(elapsed)
    Canvas.sendTimer = Canvas.sendTimer + elapsed
    if Canvas.sendTimer < SEND_INTERVAL then return end
    if #Canvas.sendQueue == 0 then return end
    Canvas.sendTimer = 0
    local msg = table.remove(Canvas.sendQueue, 1)
    local prefix
    if type(IsWarBandActive) == "function" and IsWarBandActive() then
        prefix = "/wb "
    else
        prefix = "/p "
    end
    Log("send " .. prefix .. "(" .. string.len(msg) .. " chars)")
    SendChatText(towstring(prefix .. msg), L"")
end
function Canvas.OnChatTextArrived()
    if not Canvas.Settings.enabled then return end
    local data = GameData.ChatData
    if data == nil or data.text == nil then return end
    local filters = SystemData.ChatLogFilters
    local t = data.type
    if t ~= filters.GROUP and t ~= filters.BATTLEGROUP
       and t ~= filters.SCENARIO and t ~= filters.SCENARIO_GROUPS then
        return
    end
    local text = WStringToString(towstring(data.text))
    if string.sub(text, 1, string.len(MSG_PREFIX)) ~= MSG_PREFIX then return end
    local sender = Canvas.FixName(data.name)
    Log("WBC packet from " .. sender .. " (" .. string.len(text) .. " chars)")
    if sender == Canvas.playerName then
        return -- our own broadcast echoing back; already rendered locally
    end
    Canvas.ParsePacket(sender, text)
end
function Canvas.DecodePoints(payload)
    local points = {}
    local pos = 1
    local len = string.len(payload)
    while pos <= len do
        local bar = string.find(payload, "|", pos, true)
        local token
        if bar then
            token = string.sub(payload, pos, bar - 1)
            pos = bar + 1
        else
            token = string.sub(payload, pos)
            pos = len + 1
        end
        local _, _, sx, sy = string.find(token, "^(%d+),(%d+)$")
        if sx == nil then return nil end
        local gx = clamp(tonumber(sx), 0, GRID - 1)
        local gy = clamp(tonumber(sy), 0, GRID - 1)
        table.insert(points, { gx, gy })
    end
    if #points == 0 then return nil end
    return points
end
function Canvas.ParsePacket(sender, text)
    local _, _, proto, id, seq, total, kind, zone, payload =
        string.find(text, "^WBC:(%w+):(%w+):(%d+)/(%d+):(%w):(%d+):(.*)$")
    if proto ~= PROTOCOL then return end -- older/newer builds: silently ignore
    seq, total = tonumber(seq), tonumber(total)
    if seq == nil or total == nil or total < 1 or total > MAX_CHUNKS
       or seq < 1 or seq > total then
        return
    end
    if kind == "H" then return end
    if kind == "X" then
        Log("clear received from " .. sender)
        Canvas.ClearAllStrokes()
        Print(sender .. " cleared the canvas.")
        return
    end
    if kind == "E" then
        Canvas.EraseByKey(payload, sender)
        return
    end
    if COLORS[kind] == nil then return end -- unknown brush color / future kind
    zone = tonumber(zone) or 0
    local key = sender .. "/" .. id
    local entry = Canvas.inbox[key]
    if entry == nil then
        entry = { total = total, count = 0, parts = {}, colorKey = kind, zone = zone, born = Canvas.time }
        Canvas.inbox[key] = entry
    end
    if entry.total ~= total or entry.parts[seq] ~= nil then
        entry = { total = total, count = 0, parts = {}, colorKey = kind, zone = zone, born = Canvas.time }
        Canvas.inbox[key] = entry
    end
    entry.parts[seq] = payload
    entry.count = entry.count + 1
    if entry.count < entry.total then return end -- still waiting for chunks
    Canvas.inbox[key] = nil
    local full = entry.parts[1]
    for i = 2, entry.total do
        full = full .. "|" .. entry.parts[i]
    end
    local points = Canvas.DecodePoints(full)
    if points == nil then return end
    local stroke = NewStroke(entry.colorKey, false, entry.zone)
    stroke.points = points
    stroke.key = key -- same "<owner>/<id>" identity as on the sender's client
    Canvas.EnsureDotBudget(200) -- safe here: not inside a strokes-list iteration
    table.insert(Canvas.strokes, stroke)
    Canvas.LayoutStroke(stroke)
    Log("incoming stroke rendered: " .. #points .. " points from " .. sender
        .. ", zone=" .. tostring(entry.zone) .. ", key=" .. key)
end
function Canvas.UpdateInbox()
    for key, entry in pairs(Canvas.inbox) do
        if Canvas.time - entry.born > REASSEMBLY_TIMEOUT then
            Canvas.inbox[key] = nil
        end
    end
end
function Canvas.OnUpdate(elapsed)
    if type(elapsed) ~= "number" or elapsed <= 0 then elapsed = 0.033 end
    Canvas.time = Canvas.time + elapsed
    if not Canvas.Settings.enabled then return end
    Canvas.UpdateChatMirror(elapsed) -- keep packet lines silenced on all tabs
    Canvas.UpdateAttachment()        -- keep overlay glued to the live map window
    Canvas.RefreshMapVisibility()    -- per-map stroke visibility on zone switch
    Canvas.SampleDrag(elapsed)       -- cursor sampling while the leader draws
    Canvas.UpdateSendQueue(elapsed)  -- throttled outgoing chat
    Canvas.UpdateInbox()             -- reassembly timeouts
    Canvas.leaderTimer = Canvas.leaderTimer + elapsed
    if Canvas.leaderTimer >= LEADER_POLL then
        Canvas.leaderTimer = 0
        Canvas.RefreshLeadership()
    end
end
function Canvas.OnSlashCommand(args)
    local input = ""
    if args ~= nil then
        input = string.lower(WStringToString(towstring(args)))
    end
    local _, _, cmd, rest = string.find(input, "^%s*(%S*)%s*(.*)$")
    cmd = cmd or ""
    if cmd == "draw" then
        Canvas.Settings.drawMode = not Canvas.Settings.drawMode
        if Canvas.Settings.drawMode then
            if not Canvas.Settings.enabled then
                Canvas.Settings.enabled = true
                Print("(Addon was disabled - enabling it.)")
            end
            Print("Draw mode ON - SHIFT-drag draws, SHIFT-click erases a line, right-click cancels a stroke.")
            if not Canvas.CanDraw() then
                Print("Note: you are not the leader, so drawing stays locked until you are.")
            end
        else
            Print("Draw mode OFF - the map behaves normally again.")
        end
    elseif cmd == "clear" then
        Canvas.ClearAllStrokes()
        if Canvas.CanDraw() then
            Canvas.BroadcastClear()
            Print("Canvas cleared for the whole group.")
        else
            Print("Canvas cleared locally.")
        end
    elseif cmd == "color" then
        local letter = string.upper(string.sub(rest or "", 1, 1))
        if COLORS[letter] then
            Canvas.Settings.colorKey = letter
            Print("Brush color set to " .. letter .. ".")
        else
            Print("Colors: R(ed) G(reen) B(lue) Y(ellow) W(hite) P(ink). Example: /canvas color g")
        end
    elseif cmd == "test" then
        if Canvas.attachedMap == nil then
            Print("Test failed: overlay not attached yet - open the world map once, then retry.")
        else
            if not Canvas.Settings.enabled then Canvas.Settings.enabled = true end
            local stroke = NewStroke(Canvas.Settings.colorKey, false, Canvas.GetDisplayedMap())
            stroke.points = {
                { 150, 850 }, { 350, 550 }, { 500, 650 }, { 700, 350 }, { 850, 200 },
            }
            Canvas.strokeCounter = Canvas.strokeCounter + 1
            stroke.wireId = ToBase36Pair(Canvas.strokeCounter + math.floor(Canvas.time * 7))
            stroke.key = Canvas.playerName .. "/" .. stroke.wireId
            Canvas.EnsureDotBudget(200)
            table.insert(Canvas.strokes, stroke)
            Canvas.LayoutStroke(stroke)
            Print("Test stroke drawn (" .. #stroke.dots
                .. " dots) - it stays until erased (shift-click it) or /canvas clear.")
            if Canvas.CanDraw() and Canvas.HasGroupChannel() then
                Canvas.BroadcastStroke(stroke)
                Print("Test stroke also broadcast to the group.")
            end
        end
    elseif cmd == "on" then
        Canvas.Settings.enabled = true
        Print("Addon enabled.")
    elseif cmd == "off" then
        Canvas.Settings.enabled = false
        Canvas.CancelCurrentStroke()
        Canvas.ClearAllStrokes()
        WindowSetHandleInput(OVERLAY, false)
        Canvas.RestoreChatMirror() -- give the player their vanilla chat filters back
        Print("Addon disabled (drawings cleared, chat filters restored).")
    else
        Print("CanvasByEgyptianKozi v" .. Canvas.VERSION .. " - warband map drawing:")
        Print("  SHIFT-drag on the map draws; SHIFT-click on a line erases it.")
        Print("  Drawings stay until erased or cleared.")
        Print("  /canvas draw    - toggle draw mode")
        Print("  /canvas clear   - erase all drawings (broadcasts if you lead)")
        Print("  /canvas color X - brush color: R G B Y W P")
        Print("  /canvas on|off  - master switch")
        Print("  /canvas test    - draw a sample arrow on the map (no leader needed)")
    end
    Canvas.UpdateHUD()
end
function Canvas.Shutdown()
    Canvas.RestoreChatMirror()
end
