<?xml version="1.0" encoding="UTF-8"?>
<!--	Project: DuffTimer.	Project Author:  Thurwell	Project Date: 2009-02-23T01:54:29Z
	Project Revision: 102	Project Version: v2.0.15 
	File Author: Thurwell	File Revision: 102	File Date:	2009-02-23T01:54:29Z	-->
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">

<!--@non-debug@-->
<UiMod name="DuffTimer" version="v2.0.15" date="2009-02-23T01:54:29Z">
<Author name="Thurwell" email="" />
<!--@end-non-debug@-->
 
<!--@debug@
 <UiMod name="DuffTimer" version="2.0" date="01/2009">
<Author name="Thurwell" email="" />
 @end-debug@-->

	<Description text="Buff/debuff timers for player, offensive and defensive targets" />

	<Dependencies>
		<Dependency name="DuffTimerSettings" />
		<Dependency name="EASystem_LayoutEditor" />
		<Dependency name="EA_SettingsWindow" />
	</Dependencies>

	<Files>
		<File name="LibSharedAssets/LibStub.lua" />
		<File name="LibSharedAssets/LibSharedAssets.lua" />
		<File name="LibSharedAssets/textures/textures.lua" />
		<File name="LibSharedAssets/textures/textures.xml" />
		<File name="DuffTimerLanguage.lua" />
		<File name="DuffTimer.xml" />
		<File name="DuffTimerOptionsDefn.xml" />
		<File name="DuffTimerOptions.xml" />
		<File name="DuffTimerDefaultOptions.lua" />
		<File name="DuffTimerOptions.lua" />
		<File name="DuffTimer.lua" />
	</Files>
	
	<SavedVariables>
		<SavedVariable name="DuffTimer.SavedSettings" />
	</SavedVariables>
	
	<OnInitialize>
		<CallFunction name="DuffTimer.OnInitialize" />
	</OnInitialize>
</UiMod>
</ModuleFile>
