-- yakui.lua build20100524

yakui = {}

local yperftoggle = 1
local ymenutoggle = 1
local ytextureset
local logon = true
yinstallmsg = ""
panelxscale = 1
panelyscale = 1
mwmxanch = 1
mwmyanch = 1
mwmxscale = 1
mwmyscale = 1




MacroIcons = {}
Scrollminder = {}
local DelayTime = 0
local REFRESH_DELAY = 0.5
local broadcaststate = false
local oldOnPlayerLinkLButtonUp
local oldOnPlayerLinkRButtonUp

local macroId = EA_Window_Macro.MACRO_ICONS_ID_BASE
local oldFlightPointLButtonUp = nil
local selectedFlightButton = nil
local BASE_ICON         = 0
local BUTTON_TEXT       = 1
local COOLDOWN          = 2
local COOLDOWN_TIMER    = 3
local FLASH_ANIM        = 4
local ACTIVE_ANIM       = 5
local GLOW_ANIM         = 6
local STACK_COUNT_TEXT  = 7

local PO_STATUS_NONE = 0
local PO_STATUS_LOGOUT = 1
local PO_STATUS_EXITGAME = 2
local PO_TIMEDELAY = 0.1
local PO_Status = PO_STATUS_NONE
local PO_Val = 0
local PO_ValRange = 0
local PO_Time = PO_TIMEDELAY
local PO_Msg, PO_MsgCnt
local oldEA_ChatWindow_OnKeyEnter = nil
local oldMainMenuWindow_ToggleShowing = nil
local moraleInitScale
local moraleScaleFactor = 1.7
local moraleEventhandler = false


booltowstring={[false]=L"Off",[true]=L"On"} 

--------------------------------------------------------------------------------------------------------

function yakui.initialize()
	
	yakuiUpdate.load()
		
------------------------------------------------------ Event Handlers

	RegisterEventHandler(SystemData.Events.INTERACT_SHOW_HEALER , "yakui.healall")
	--RegisterEventHandler( SystemData.Events.SCENARIO_BEGIN, "yakui.scbegin" )	
	RegisterEventHandler(SystemData.Events.RELOAD_INTERFACE, "yakui.onreload")
	RegisterEventHandler(SystemData.Events.PLAYER_ZONE_CHANGED, "yakui.zonechange")
	RegisterEventHandler(SystemData.Events.LOADING_END, "yakui.onload")
	--WindowRegisterEventHandler(window, SystemData.Events.OnRButtonUp, handler)

	yakui.ychatrenameEA=EA_ChatWindow.OnRename 
	EA_ChatWindow.OnRename=yakui.ychatrename
	
	oldFlightPointLButtonUp = EA_InteractionFlightMasterWindow.FlightPointLButtonUp
    EA_InteractionFlightMasterWindow.FlightPointLButtonUp = yakui.guildscrollhook

	CreateWindow("yakuiMWM", true)
	WindowRegisterEventHandler("yakuiMWM", SystemData.Events.LOADING_END, "yakui.MWMUpdateMap")
	WindowRegisterEventHandler("yakuiMWM", SystemData.Events.PLAYER_ZONE_CHANGED, "yakui.MWMUpdateMap")
	WindowRegisterEventHandler("yakuiMWM", SystemData.Events.INTERFACE_RELOADED, "yakui.MWMInterfaceReloaded")
	CreateMapInstance("yakuiMWM", SystemData.MapTypes.NORMAL)
	LayoutEditor.RegisterWindow("yakuiMWM", L"Mini World Map" , L"A simple map.", false, false, true)
	WindowSetLayer("yakuiMWM", 1)
	yakui.MWMUpdateFilters()	

    RegisterEventHandler("TargetLast", SystemData.Events.PLAYER_TARGET_UPDATED, "yakui.TargetLUpdateTargets")
    RegisterEventHandler("TargetLast", SystemData.Events.ESCAPE_KEY_PROCESSED, "yakui.TargetLSetEscapeFlag")
    
    yakui.TargetLoldHostileTarget = nil
    yakui.TargetLlastKnownFriendlyTarget = nil
    yakui.TargetLlastKnownHostileTarget = nil
    yakui.TargetLlockedFriendlyTarget = nil
    yakui.TargetLisFriendlyTargetLocked = false
    yakui.TargetLoldFriendlyTarget = GameData.Player.name
	

	
------------------------------------------------------ building yakui
	
		-- Border
			CreateWindowFromTemplate("YBorder","EA_DynamicImage_DefaultSeparatorRight","Root")
			WindowSetShowing("YBorder",true)
			WindowSetAlpha("YBorder", yakuiVar.Panel.Panelalpha)
		 	WindowSetHandleInput("YBorder",false)
			WindowSetLayer("YBorder",0)
			WindowClearAnchors("YBorder")
			WindowAddAnchor("YBorder","bottomleft","Root","bottomleft",0,0)
			
		-- Panel
			CreateWindowFromTemplate("YPanel","EA_DynamicImage_DefaultSeparatorRight","Root")
			WindowSetShowing("YPanel",true)
			if yakuiVar.Panel.alphatoggle == true then 
				WindowSetAlpha("YPanel",yakuiVar.Panel.alpha)
			else				
				WindowSetAlpha("YPanel",1)
			end
			WindowSetHandleInput("YPanel",false)
    		WindowSetLayer("YPanel",0)
    		WindowClearAnchors("YPanel")
    		WindowAddAnchor("YPanel","bottomleft","Root","bottomleft",0,0)
		
		-- FX
			CreateWindowFromTemplate("YFX","EA_DynamicImage_DefaultSeparatorRight","Root")
			WindowSetShowing("YFX",true)
			WindowSetAlpha("YFX",yakuiVar.Panel.fxalpha)
			WindowSetHandleInput("YFX",false)
    		WindowSetLayer("YFX",0)
    		WindowClearAnchors("YFX")
    		WindowAddAnchor("YFX","bottomleft","Root","bottomleft",0,0)
			
		-- Miniworldmap Background
			CreateWindowFromTemplate("YMPanel","EA_DynamicImage_DefaultSeparatorRight","Root")
			WindowSetShowing("YMPanel", false)
			if yakuiVar.Panel.alphatoggle == true then 
				WindowSetAlpha("YMPanel",yakuiVar.Panel.alpha)
			else			
				WindowSetAlpha("YMPanel",1)
			end
			WindowSetHandleInput("YMPanel",false)
    		WindowSetLayer("YMPanel",0)
    		WindowClearAnchors("YMPanel")
			CreateWindowFromTemplate("YMBorder","EA_DynamicImage_DefaultSeparatorRight","Root")
			WindowSetShowing("YMBorder", false)
    		WindowSetAlpha("YMBorder",yakuiVar.Panel.Panelalpha)
			WindowSetHandleInput("YMBorder",false)
    		WindowSetLayer("YMBorder",0)
    		WindowClearAnchors("YMBorder")
			CreateWindowFromTemplate("YMFX","EA_DynamicImage_DefaultSeparatorRight","Root")
			WindowSetShowing("YMFX", false)
    		WindowSetAlpha("YMFX",yakuiVar.Panel.fxalpha)
			WindowSetHandleInput("YMFX",false)
    		WindowSetLayer("YMFX",0)
    		WindowClearAnchors("YMFX")


		-- Chatdisplay
			for k,v in pairs(ChatSettings.Channels) do
        				if v.serverCmd == L"/t" then
            				ChatSettings.Channels[k].remember = true
        			end
    			end

    			oldOnPlayerLinkLButtonUp = EA_ChatWindow.OnPlayerLinkLButtonUp
    			oldOnPlayerLinkRButtonUp = EA_ChatWindow.OnPlayerLinkRButtonUp
    
    			EA_ChatWindow.OnPlayerLinkLButtonUp = function(playerName, flags, x, y)
        			if flags == 8 then
            			-- ctrl left click : invite to group
            				playerName = wstring.gsub( playerName, L"(^.)", L"" )
            				SystemData.UserInput.ChatText = L"/invite "..playerName
            				BroadcastEvent(SystemData.Events.SEND_CHAT_TEXT)
        			elseif flags == 4 then
            			-- shift left click : who
            				playerName = wstring.gsub( playerName, L"(^.)", L"" )
            				SystemData.UserInput.ChatText = L"/who "..playerName
            				BroadcastEvent(SystemData.Events.SEND_CHAT_TEXT)
        			else
            				oldOnPlayerLinkLButtonUp(playerName, flags, x, y)
        			end
    			end
    
    			EA_ChatWindow.OnPlayerLinkRButtonUp = function(playerName, flags, x, y)
        			if flags == 4 then
            			-- shift right click : target
            				playerName = wstring.gsub( playerName, L"(^.)", L"" )
            				SystemData.UserInput.ChatText = L"/target "..playerName
            				BroadcastEvent(SystemData.Events.SEND_CHAT_TEXT)
        			elseif flags == 8 then
            			-- ctrl right click: join
            				playerName = wstring.gsub( playerName, L"(^.)", L"" )
            				SystemData.UserInput.ChatText = L"/join "..playerName
            				BroadcastEvent(SystemData.Events.SEND_CHAT_TEXT)
        			else
            				oldOnPlayerLinkRButtonUp(playerName, flags, x, y)
        			end
    			end


			CreateWindow("YakChatdisplay", true)
   			LayoutEditor.RegisterWindow("YakChatdisplay", L"Y Chatframe Display", L"Options.",false,false,true,nil )
			WindowSetFontAlpha ("YakChatdisplay", 0.5)
			WindowSetFontAlpha ("YakChatdisplayText", 0.3)
			LabelSetTextColor("YakChatdisplayText", 200, 200 , 200 )
			WindowSetMovable( "YakChatdisplay", false)
			yakui.ychattoggle(yakuiVar.Panel.chat,1)
			
		-- enable more macro symbols
			
			yakui.macroshookselect = EA_Window_Macro.SelectionIconLButtonDown
			EA_Window_Macro.SelectionIconLButtonDown = yakui.macrosselect
			WindowSetShowing("IconsScrollbar", false)
			CreateWindow("MacroIconsUpArrowButton", true)
			CreateWindow("MacroIconsDownArrowButton", true)
			WindowSetParent("MacroIconsUpArrowButton", "MacroIconSelectionWindow")
			WindowSetParent("MacroIconsDownArrowButton", "MacroIconSelectionWindow")
			WindowClearAnchors("MacroIconsUpArrowButton")
			WindowClearAnchors("MacroIconsDownArrowButton")
			WindowAddAnchor("MacroIconsUpArrowButton", "topright", "MacroIconSelectionWindow", "topright", -5,35)
			WindowAddAnchor("MacroIconsDownArrowButton", "bottomright", "MacroIconSelectionWindow", "bottomright", -5,-5)			
	
------------------------------------------------------ building yakui: resolution dependencies

	

	if yakuiVar.Panel.res == "1920x1200" then
		panelxscale = 1920
		panelyscale = 225
		mwmxanch = 52
		mwmyanch = -222
		mwmxscale = 400
		mwmyscale =	392
		ytextureset = "1920x1200"
		DynamicImageSetTextureDimensions("YBorder", 1920, 225)
		DynamicImageSetTextureDimensions("YPanel", 1920, 225)
		DynamicImageSetTextureDimensions("YFX", 1920, 225)
		DynamicImageSetTextureDimensions("YMPanel", 400, 400)
		DynamicImageSetTextureDimensions("YMBorder", 400, 400)
		DynamicImageSetTextureDimensions("YMFX", 400, 400)
	end



	if yakuiVar.Panel.res == "1680x1050" then
		panelxscale = 1680
		panelyscale = 200
		mwmxanch = 45
		mwmyanch = -196
		mwmxscale = 346
		mwmyscale =	346 
		ytextureset = "1680x1050"
		DynamicImageSetTextureDimensions("YBorder", 1680, 200)
		DynamicImageSetTextureDimensions("YPanel", 1680, 200)
		DynamicImageSetTextureDimensions("YFX", 1680, 200)
		DynamicImageSetTextureDimensions("YMPanel", 300, 300)		
		DynamicImageSetTextureDimensions("YMBorder", 300, 300)
		DynamicImageSetTextureDimensions("YMFX", 300, 300)
	end

	if yakuiVar.Panel.res == "1600x1200" then
		panelxscale = 1640
		panelyscale = 200
		mwmxanch = 45
		mwmyanch = -200
		mwmxscale = 336
		mwmyscale =	336 
		ytextureset = "1680x1050"
		DynamicImageSetTextureDimensions("YBorder", 1680, 200)
		DynamicImageSetTextureDimensions("YPanel", 1680, 200)
		DynamicImageSetTextureDimensions("YFX", 1680, 200)
		DynamicImageSetTextureDimensions("YMPanel", 300, 300)		
		DynamicImageSetTextureDimensions("YMBorder", 300, 300)
		DynamicImageSetTextureDimensions("YMFX", 300, 300)
	end
			
		
	if yakuiVar.Panel.res == "1440x900" then
		panelxscale = 1440
		panelyscale = 171
		mwmxanch = 39
		mwmyanch = -166
		mwmxscale = 296
		mwmyscale =	296 
		ytextureset = "1680x1050"
		DynamicImageSetTextureDimensions("YBorder", 1680, 200)
		DynamicImageSetTextureDimensions("YPanel", 1680, 200)
		DynamicImageSetTextureDimensions("YFX", 1680, 200)
		DynamicImageSetTextureDimensions("YMPanel", 300, 300)		
		DynamicImageSetTextureDimensions("YMBorder", 300, 300)
		DynamicImageSetTextureDimensions("YMFX", 300, 300)
	end	

	
	if yakuiVar.Panel.res == "1280x1024" then
		panelxscale = 1280
		panelyscale = 1024
		mwmxanch = 42
		mwmyanch = -182
		mwmxscale = 334
		mwmyscale =	334 
		ytextureset = "1280x1024"
		DynamicImageSetTextureDimensions("YBorder", 1280, 1024)
		DynamicImageSetTextureDimensions("YPanel", 1280, 1024)
		DynamicImageSetTextureDimensions("YFX", 1280, 1024)
		DynamicImageSetTextureDimensions("YMPanel", 333, 333)		
		DynamicImageSetTextureDimensions("YMBorder", 333, 333)
		DynamicImageSetTextureDimensions("YMFX", 333, 333)
	end			
				


	if yakuiVar.Panel.res == "1920x1080" then
		panelxscale = 1920
		panelyscale = 225
		mwmxanch = 52
		mwmyanch = -222
		mwmxscale = 397
		mwmyscale =	392 
		ytextureset = "1920x1200"
		DynamicImageSetTextureDimensions("YBorder", 1920, 225)
		DynamicImageSetTextureDimensions("YPanel", 1920, 225)
		DynamicImageSetTextureDimensions("YFX", 1920, 225)
		DynamicImageSetTextureDimensions("YMPanel", 400, 400)		
		DynamicImageSetTextureDimensions("YMBorder", 400, 400)
		DynamicImageSetTextureDimensions("YMFX", 400, 400)
	end
	
	
	if yakuiVar.Panel.res == "1360x768" then
		panelxscale = 1440
		panelyscale = 171
		mwmxanch = 39
		mwmyanch = -166
		mwmxscale = 296
		mwmyscale =	296 
		ytextureset = "1680x1050"
		DynamicImageSetTextureDimensions("YBorder", 1680, 200)
		DynamicImageSetTextureDimensions("YPanel", 1680, 200)
		DynamicImageSetTextureDimensions("YFX", 1680, 200)
		DynamicImageSetTextureDimensions("YMPanel", 300, 300)		
		DynamicImageSetTextureDimensions("YMBorder", 300, 300)
		DynamicImageSetTextureDimensions("YMFX", 300, 300)
	end

------------------------------------------------------ building yakui: post resolution 

	WindowSetDimensions("YBorder",math.ceil((panelxscale*(1/InterfaceCore.GetScale()))*(1/yakuiVar.Panel.scale)),math.ceil((panelyscale*(1/InterfaceCore.GetScale()))*(1/yakuiVar.Panel.scale)))
	WindowSetDimensions("YPanel",math.ceil((panelxscale*(1/InterfaceCore.GetScale()))*(1/yakuiVar.Panel.scale)),math.ceil((panelyscale*(1/InterfaceCore.GetScale()))*(1/yakuiVar.Panel.scale)))
	WindowSetDimensions("YFX",math.ceil((panelxscale*(1/InterfaceCore.GetScale()))*(1/yakuiVar.Panel.scale)),math.ceil((panelyscale*(1/InterfaceCore.GetScale()))*(1/yakuiVar.Panel.scale)))
	WindowSetDimensions("YMPanel",math.ceil((mwmxscale*(1/InterfaceCore.GetScale()))*(1/yakuiVar.Panel.scale)),math.ceil((mwmyscale*(1/InterfaceCore.GetScale()))*(1/yakuiVar.Panel.scale)))
	WindowSetDimensions("YMBorder",math.ceil((mwmxscale*(1/InterfaceCore.GetScale()))*(1/yakuiVar.Panel.scale)),math.ceil((mwmyscale*(1/InterfaceCore.GetScale()))*(1/yakuiVar.Panel.scale)))
	WindowSetDimensions("YMFX",math.ceil((mwmxscale*(1/InterfaceCore.GetScale()))*(1/yakuiVar.Panel.scale)),math.ceil((mwmyscale*(1/InterfaceCore.GetScale()))*(1/yakuiVar.Panel.scale)))
	WindowAddAnchor("YMPanel","bottomleft","Root","bottomleft",math.ceil((mwmxanch*(1/InterfaceCore.GetScale()))*(1/yakuiVar.Panel.scale)),math.ceil((mwmyanch*(1/InterfaceCore.GetScale()))*(1/yakuiVar.Panel.scale)))
	WindowAddAnchor("YMBorder","bottomleft","Root","bottomleft",math.ceil((mwmxanch*(1/InterfaceCore.GetScale()))*(1/yakuiVar.Panel.scale)),math.ceil((mwmyanch*(1/InterfaceCore.GetScale()))*(1/yakuiVar.Panel.scale)))
	WindowAddAnchor("YMFX","bottomleft","Root","bottomleft",math.ceil((mwmxanch*(1/InterfaceCore.GetScale()))*(1/yakuiVar.Panel.scale)),math.ceil((mwmyanch*(1/InterfaceCore.GetScale()))*(1/yakuiVar.Panel.scale)))
	DynamicImageSetTexture("YBorder", "Yak"..yakuiVar.Panel.tex..ytextureset.."B", 0, 0)
	DynamicImageSetTexture("YPanel", "Yak"..yakuiVar.Panel.tex..ytextureset.."P", 0, 0)
	DynamicImageSetTexture("YFX", "Yak"..yakuiVar.Panel.tex..ytextureset.."FX", 0, 0)
	DynamicImageSetTexture("YMBorder", "Yak"..yakuiVar.Panel.tex..ytextureset.."MB", 0, 0)
	DynamicImageSetTexture("YMPanel", "Yak"..yakuiVar.Panel.tex..ytextureset.."MP", 0, 0)
	DynamicImageSetTexture("YMFX", "Yak"..yakuiVar.Panel.tex..ytextureset.."MFX", 0, 0)
	
---------------------------------------------------------------------------------------------------------------------------------------	
	
			
		--Buttons (YuiButton, War Commander Button, Alpha Toggle Button)
			CreateWindow("YakuiButton", true)
   			LayoutEditor.RegisterWindow( "YakuiButton", L"YakUI Button", L"YakUI Functions", false, false, true, nil )
			CreateWindow("YakuiWCButton", true)
   			LayoutEditor.RegisterWindow( "YakuiWCButton", L"YakUIWC Button", L"Warcommander Functions", false, false, true, nil )
			CreateWindow("YakuiFWButton", true)
   			LayoutEditor.RegisterWindow( "YakuiFWButton", L"YakUIFW Button", L"FW Button", false, false, true, nil )
			CreateWindow("YakuiBWButton", true)
   			LayoutEditor.RegisterWindow( "YakuiBWButton", L"YakUIBW Button", L"BW Button", false, false, true, nil )
			CreateWindow("YakuiSORButton", true)
			LayoutEditor.RegisterWindow( "YakuiSORButton", L"YakUISOR Button", L"SOR Functions", false, false, true, nil )
			CreateWindow("YakuiATButton", true)
   			LayoutEditor.RegisterWindow( "YakuiATButton", L"YakUIAT Button", L"Alpha Toggle", false, false, true, nil )
			CreateWindow("YakuiTTButton", true)
   			LayoutEditor.RegisterWindow( "YakuiTTButton", L"YakUITT Button", L"Targets Functions", false, false, true, nil )

-- appearance custom: panel r64,g64,b80 background r16,0,0 

		--colors  			
	WindowSetTintColor("YBorder", yakuiVar.Colors.colprintr, yakuiVar.Colors.colprintg, yakuiVar.Colors.colprintb)
	WindowSetTintColor("YMBorder", yakuiVar.Colors.colprintr, yakuiVar.Colors.colprintg, yakuiVar.Colors.colprintb)
   	WindowSetTintColor("YPanel", yakuiVar.Colors.background.r, yakuiVar.Colors.background.g, yakuiVar.Colors.background.b)
	WindowSetTintColor("YFX", yakuiVar.Colors.fx.r, yakuiVar.Colors.fx.g, yakuiVar.Colors.fx.b)
	WindowSetTintColor("YMFX", yakuiVar.Colors.fx.r, yakuiVar.Colors.fx.g, yakuiVar.Colors.fx.b)
   	WindowSetTintColor("YMPanel", yakuiVar.Colors.background.r, yakuiVar.Colors.background.g, yakuiVar.Colors.background.b)
	WindowSetTintColor("YakuiATButton", yakuiVar.Colors.colprintr, yakuiVar.Colors.colprintg, yakuiVar.Colors.colprintb)
	WindowSetTintColor("YakuiTTButton", 255, 255, 255)

	yakuislash.init()
	yakuiTactic.init()
	yakuiActionBars_Initialize()
	yakuiconfig.initialize()
	yakui.POInit()
	yakuiInfo.entry_point()
	yakui.alertlimitInit()
	CreateWindow("MoraleEditor", true)
	yakuiWHL.initialize()
	yakui.minefilter()
	-- startup checks
	RegisterEventHandler(SystemData.Events.LOADING_END, "yakui.handle_loading_end_function")

		
	if yakuiVar.counter == 1 then
		yakui.relogafterprofileselection()
	else
		yakui.delay(30, yakui.postloading)
	end
end


--------------------------------------------------------------------------------------------------------


function yakui.ybuttonr()
	if yakuiVar.Panel.config == "on" then yakuiconfig.hide() end
	yakui.MWMToggleMap()
end

function yakui.ybuttonl()
	if yakuiVar.Huduf.ignore == false then 
	yakuiVar.Huduf.grpico = not yakuiVar.Huduf.grpico
		for i = 1,5 do
			if Effigy.Bars["WorldGroupMember"..i] then
				bar =  Effigy.Bars["WorldGroupMember"..i]
				bar.show = yakuiVar.Huduf.grpico
				bar:setup()
				bar:render()
			end
		end
	if yakuiVar.Huduf.grpico == true then print("Group Icons: On") else print ("Group Icons: Off") end
	end
end

function yakui.infopanel()
	if yakuiVar.Huduf.ignore == false then
		if Effigy.Bars["InfoPanel"] then
			bar =  Effigy.Bars["InfoPanel"]
			bar.show = yakuiVar.Huduf.infopanel
			bar:setup()
			bar:render()
		end
	end
end

function yakui.friendlyrange()
	if yakuiVar.Huduf.ignore == false then
		if Effigy.Bars["FriendlyTarget"] then
			bar =  Effigy.Bars["FriendlyTarget"]
			bar.labels["Range"].show = yakuiVar.Huduf.friendlyrange
			bar:setup()
			bar:render()
		end
	end
end

function yakui.hostilerange()
	if yakuiVar.Huduf.ignore == false then
		if Effigy.Bars["HostileTarget"] then
			bar =  Effigy.Bars["HostileTarget"]
			bar.labels["Range"].show = yakuiVar.Huduf.hostilerange
			bar:setup()
			bar:render()
		end
	end
end

function yakui.ybuttonmo()
    local windowName	= SystemData.ActiveWindow.name

    Tooltips.CreateTextOnlyTooltip (windowName, nil)
    Tooltips.SetTooltipText (1, 1, L"YakUI rocks!")
    Tooltips.SetTooltipColorDef (1, 1, Tooltips.COLOR_BODY)
    Tooltips.Finalize()
    
    local anchor = { Point="left", RelativeTo=windowName, RelativePoint="right", XOffset=0, YOffset=0 }
    Tooltips.AnchorTooltip (anchor)
    Tooltips.SetTooltipAlpha (1)
end



function yakui.ytargetsbtl()
	if yakuiVar.DEVmode == true then print("YakUI: ytargetsbtl") end
	if Targets.enemies.visible == true then
		print("Targets: enemy list off")
	else
		print("Targets: enemy list on")
	end
	TargetsSlashCmd.parse_cmd("toggle enemies")
end

function yakui.ytargetsbtr()
	if Targets.allies.visible == true then 
		print("Targets: ally list off")
	else 
		print("Targets: ally list on")
	end
	TargetsSlashCmd.parse_cmd("toggle allies")
end

function yakui.ytargetsbtmo()
    local windowName	= SystemData.ActiveWindow.name
    Tooltips.CreateTextOnlyTooltip (windowName, nil)
    Tooltips.SetTooltipText (1, 1, L"Toggle Targets")
    Tooltips.SetTooltipColorDef (1, 1, Tooltips.COLOR_BODY)
    Tooltips.Finalize()
    
    local anchor = { Point="left", RelativeTo=windowName, RelativePoint="right", XOffset=0, YOffset=0 }
    Tooltips.AnchorTooltip (anchor)
    Tooltips.SetTooltipAlpha (1)
end



function yakui.ywarcmdbtmo()
    local windowName	= SystemData.ActiveWindow.name

    Tooltips.CreateTextOnlyTooltip (windowName, nil)
    Tooltips.SetTooltipText (1, 1, L"Toggle WarCommander")
    Tooltips.SetTooltipColorDef (1, 1, Tooltips.COLOR_BODY)
    Tooltips.Finalize()
    
    local anchor = { Point="left", RelativeTo=windowName, RelativePoint="right", XOffset=0, YOffset=0 }
    Tooltips.AnchorTooltip (anchor)
    Tooltips.SetTooltipAlpha (1)
end



function yakui.alphatoggle()
	if yakuiVar.Panel.alphatoggle == true then
		WindowSetAlpha("YPanel",1)
		WindowSetAlpha("YMPanel",1)
		WindowSetTintColor("yCustomcolorsliders_BGSliderA", 120, 120, 120 )
		yakuiVar.Panel.alphatoggle = false
	else
		WindowSetAlpha("YPanel",yakuiVar.Panel.alpha)
		WindowSetAlpha("YMPanel",yakuiVar.Panel.alpha)
		WindowSetTintColor("yCustomcolorsliders_BGSliderA", 255, 255, 255 )
		yakuiVar.Panel.alphatoggle = true
	end
	ButtonSetPressedFlag("yCustomcolorsliders_AlphaToggle", yakuiVar.Panel.alphatoggle)
	SliderBarSetDisabledFlag("yCustomcolorsliders_BGSliderA", not yakuiVar.Panel.alphatoggle )
	yakuiSkin.newbackground()
end



function yakui.ychatfwbt()
	yakui.ychattoggle(yakuiVar.Panel.chat+1,#EA_ChatTabManager.Tabs)
end

function yakui.ychatbwbt()
	yakui.ychattoggle(yakuiVar.Panel.chat-1,1)
end

function yakui.ychattoggle(start,stop)
    local x=1
    local t
    local tabs=EA_ChatTabManager.Tabs
    if(start>stop)then x=-1 end
    for i=start,stop,x
    do
        if(tabs[i].used)
        then
            t=i
            break
        end
    end
    if(t~=nil)
    then
        yakuiVar.Panel.chat=t
        EA_ChatWindow.SetToTab(t)
        LabelSetText("YakChatdisplayText",towstring(EA_ChatWindowGroups[tabs[t].wndGroupId].Tabs[t].tabText))
    end
end 

function yakui.ychatmenu()
	EA_ChatTabManager.activeTabId = yakuiVar.Panel.chat 
	EA_Window_ContextMenu.CreateContextMenu("YakChatdisplaytext", EA_Window_ContextMenu.CONTEXT_MENU_1) 
	EA_Window_ContextMenu.AddMenuItem(GetChatString(StringTables.Chat.LABEL_CHAT_FILTERS), EA_ChatWindow.OnViewChatFilters, false, true, EA_Window_ContextMenu.CONTEXT_MENU_1) 
	EA_Window_ContextMenu.AddMenuItem(GetChatString(StringTables.Chat.LABEL_CHAT_TAB_TEXTCOLORS), EA_ChatWindow.OnViewChatOptions, false, true, EA_Window_ContextMenu.CONTEXT_MENU_1) 
	EA_Window_ContextMenu.AddCascadingMenuItem(GetChatString(StringTables.Chat.LABEL_CHAT_TAB_TABOPTIONS), EA_ChatWindow.SpawnTabOptionsMenu, false, EA_Window_ContextMenu.CONTEXT_MENU_1) 
	EA_Window_ContextMenu.AddCascadingMenuItem(GetChatString(StringTables.Chat.LABEL_CHAT_TAB_COMMANDLISTS), EA_ChatWindow.SpawnCommandListsMenu, false, EA_Window_ContextMenu.CONTEXT_MENU_1) 
	EA_Window_ContextMenu.Finalize(EA_Window_ContextMenu.CONTEXT_MENU_1) 
end

function yakui.ychatrename()
		yakui.ychatrenameEA()
		yakui.ychattoggle(yakuiVar.Panel.chat,1)
end


---------------------------------------------------------------------------------------------

function yakui.perftoggle()
		if yperftoggle == 1 then
				SystemData.Settings.Performance.perfLevel = SystemData.Settings.Performance.PERF_LEVEL_CUSTOM2
				BroadcastEvent(SystemData.Events.USER_SETTINGS_CHANGED)
				TextLogAddEntry("Chat", SystemData.ChatLogFilters.SHOUT, L"Performance settings changed to CUSTOM2...")	
				yperftoggle = 2
		else
				SystemData.Settings.Performance.perfLevel = SystemData.Settings.Performance.PERF_LEVEL_CUSTOM1
				BroadcastEvent(SystemData.Events.USER_SETTINGS_CHANGED)
				TextLogAddEntry("Chat", SystemData.ChatLogFilters.SHOUT, L"Performance settings changed to CUSTOM1...")
				yperftoggle = 1
		end
end



function yakui.color()
	if yakuiVar.Huduf.ignore == false then
	if yakuiVar.Warnings.Huduf == 1 then
		local hudufframes = { "PlayerHP", "FriendlyTarget", "HostileTarget", "Pet", "Castbar", "GroupMember1", "GroupMember2", "GroupMember3", "GroupMember4", "GroupMember5"}
		for _, v in ipairs (hudufframes) do
			if Effigy.Bars[v] then 
				bar = Effigy.Bars[v]
				bar.images["Background"].colorsettings.color.r = yakuiVar.Colors.colprintr
				bar.images["Background"].colorsettings.color.g = yakuiVar.Colors.colprintg
				bar.images["Background"].colorsettings.color.b = yakuiVar.Colors.colprintb
				bar.images["Background"].alpha = yakuiVar.Panel.Panelalpha
				bar.images["Foreground"].colorsettings.color.r = yakuiVar.Colors.fx.r
				bar.images["Foreground"].colorsettings.color.g = yakuiVar.Colors.fx.g
				bar.images["Foreground"].colorsettings.color.b = yakuiVar.Colors.fx.b
				bar.images["Foreground"].alpha = yakuiVar.Panel.fxalpha
				if v == "PlayerHP" or v == "GroupMember1" or v == "GroupMember2" or v == "GroupMember3" or v == "GroupMember4" or v == "GroupMember5" or v == "Pet" then 
					bar.fg.colorsettings.color.r = yakuiVar.Colors.unitframes.player.r
					bar.fg.colorsettings.color.g = yakuiVar.Colors.unitframes.player.g
					bar.fg.colorsettings.color.b = yakuiVar.Colors.unitframes.player.b
				elseif v == "FriendlyTarget" then
					bar.fg.colorsettings.color.r = yakuiVar.Colors.unitframes.friendly.r
					bar.fg.colorsettings.color.g = yakuiVar.Colors.unitframes.friendly.g
					bar.fg.colorsettings.color.b = yakuiVar.Colors.unitframes.friendly.b
				elseif v == "HostileTarget" then
					bar.fg.colorsettings.color.r = yakuiVar.Colors.unitframes.hostile.r
					bar.fg.colorsettings.color.g = yakuiVar.Colors.unitframes.hostile.g
					bar.fg.colorsettings.color.b = yakuiVar.Colors.unitframes.hostile.b
				end
				bar:setup()
				bar:render()
			end
		end
		if Effigy.Bars["Castbar"] then
			bar = Effigy.Bars["Castbar"]
			bar.fg.colorsettings.color.r = yakuiVar.Colors.unitframes.castbar.r
			bar.fg.colorsettings.color.g = yakuiVar.Colors.unitframes.castbar.g
			bar.fg.colorsettings.color.b = yakuiVar.Colors.unitframes.castbar.b
			bar:setup()
			bar:render()
		end
		if Effigy.Bars["PlayerAP"] then
			bar =  Effigy.Bars["PlayerAP"]
			bar.fg.colorsettings.color.r = yakuiVar.Colors.unitframes.apbar.r
			bar.fg.colorsettings.color.g = yakuiVar.Colors.unitframes.apbar.g
			bar.fg.colorsettings.color.b = yakuiVar.Colors.unitframes.apbar.b
			bar:setup()
			bar:render()
		end
		if Effigy.Bars["PlayerCareer"] then
			bar =  Effigy.Bars["PlayerCareer"]
			bar.fg.colorsettings.color.r = yakuiVar.Colors.unitframes.careerbar.r
			bar.fg.colorsettings.color.g = yakuiVar.Colors.unitframes.careerbar.g
			bar.fg.colorsettings.color.b = yakuiVar.Colors.unitframes.careerbar.b
			bar:setup()
			bar:render()
		end
		if Effigy.Bars["InfoPanel"] then
			bar = Effigy.Bars["InfoPanel"]
			bar.images["Background"].colorsettings.color.r = yakuiVar.Colors.colprintr
			bar.images["Background"].colorsettings.color.g = yakuiVar.Colors.colprintg
			bar.images["Background"].colorsettings.color.b = yakuiVar.Colors.colprintb
			bar.images["Background"].alpha = yakuiVar.Panel.Panelalpha
			bar.images["Foreground"].colorsettings.color.r = yakuiVar.Colors.fx.r
			bar.images["Foreground"].colorsettings.color.g = yakuiVar.Colors.fx.g
			bar.images["Foreground"].colorsettings.color.b = yakuiVar.Colors.fx.b
			bar.images["Foreground"].alpha = yakuiVar.Panel.fxalpha
			bar:setup()
			bar:render()
		end
	end
	end
	WindowSetTintColor("YBorder", yakuiVar.Colors.colprintr, yakuiVar.Colors.colprintg, yakuiVar.Colors.colprintb)
	WindowSetTintColor("YMBorder", yakuiVar.Colors.colprintr, yakuiVar.Colors.colprintg, yakuiVar.Colors.colprintb)
	WindowSetTintColor("YFX", yakuiVar.Colors.fx.r, yakuiVar.Colors.fx.g, yakuiVar.Colors.fx.b)
	WindowSetTintColor("YMFX", yakuiVar.Colors.fx.r, yakuiVar.Colors.fx.g, yakuiVar.Colors.fx.b)
   	WindowSetTintColor("YPanel", yakuiVar.Colors.background.r, yakuiVar.Colors.background.g, yakuiVar.Colors.background.b)
   	WindowSetTintColor("YMPanel", yakuiVar.Colors.background.r, yakuiVar.Colors.background.g, yakuiVar.Colors.background.b)
	WindowSetTintColor("YakuiATButton", yakuiVar.Colors.colprintr, yakuiVar.Colors.colprintg, yakuiVar.Colors.colprintb)
	WindowSetTintColor("YakuiTTButton", 255, 255, 255)
	WindowSetAlpha("YBorder", yakuiVar.Panel.Panelalpha)
	if yakuiVar.Panel.alphatoggle == true then 
		WindowSetAlpha("YPanel", yakuiVar.Panel.alpha)
		WindowSetAlpha("YMPanel", yakuiVar.Panel.alpha)
	else
		WindowSetAlpha("YPanel", 1)
		WindowSetAlpha("YMPanel", 1)
	end
	WindowSetAlpha("YMBorder", yakuiVar.Panel.Panelalpha)
	WindowSetAlpha("YMFX", yakuiVar.Panel.fxalpha)
	WindowSetAlpha("YFX", yakuiVar.Panel.fxalpha)
	if yakuiVar.Skin.active == true then
		yakuiSkin.UpdateAllBorders()
		if yakuiVar.Skin.newbackgrounds.linkwpanel == true then	yakuiSkin.newbackground() end
	end
end


function yakui.texture()
	if yakuiVar.Huduf.ignore == false then
	if yakuiVar.Warnings.Huduf == 1 then
		--unitframes
		local unitframes = { "PlayerHP", "FriendlyTarget", "HostileTarget", "Pet", "GroupMember1", "GroupMember2", "GroupMember3", "GroupMember4", "GroupMember5"}
		for _, v in ipairs (unitframes) do
			bar =  Effigy.Bars[v]
			bar.images["Background"].texture.name = "SharedMediaY"..yakuiVar.Panel.tex.."UFBG"
			bar.images["Foreground"].texture.name = "SharedMediaY"..yakuiVar.Panel.tex.."UFFX"
			bar:setup()
			bar:render()
		end
		--bars
		local unitframesbars = { "PlayerHP", "PlayerAP", "PlayerCareer", "FriendlyTarget", "HostileTarget", "Pet", "GroupMember1", "GroupMember2", "GroupMember3", "GroupMember4", "GroupMember5"}
		for _, v in ipairs (unitframesbars) do
			bar =  Effigy.Bars[v]
			bar.fg.texture.name = "SharedMediaY"..yakuiVar.Panel.tex.."UFBar"
			bar:setup()
			bar:render()
		end
		--castbar
		Effigy.Bars["Castbar"].images["Background"].texture.name = "SharedMediaY"..yakuiVar.Panel.tex.."CBBG"
		Effigy.Bars["Castbar"].images["Foreground"].texture.name = "SharedMediaY"..yakuiVar.Panel.tex.."CBFX"
		Effigy.Bars["Castbar"].images["CBEnd"].texture.name = "SharedMediaY"..yakuiVar.Panel.tex.."CBBarEnd"
		Effigy.Bars["Castbar"].fg.texture.name = "SharedMediaY"..yakuiVar.Panel.tex.."CBBar"
		Effigy.Bars["Castbar"]:setup()
		Effigy.Bars["Castbar"]:render()
		--infopanel
		Effigy.Bars["InfoPanel"].images["Background"].texture.name = "SharedMediaY"..yakuiVar.Panel.tex.."IPBG"
		Effigy.Bars["InfoPanel"].images["Foreground"].texture.name = "SharedMediaY"..yakuiVar.Panel.tex.."IPFX"
		Effigy.Bars["InfoPanel"]:setup()
		Effigy.Bars["InfoPanel"]:render()
	end
	end
	DynamicImageSetTexture("YBorder", "Yak"..yakuiVar.Panel.tex..ytextureset.."B", 0, 0)
	DynamicImageSetTexture("YPanel", "Yak"..yakuiVar.Panel.tex..ytextureset.."P", 0, 0)
	DynamicImageSetTexture("YFX", "Yak"..yakuiVar.Panel.tex..ytextureset.."FX", 0, 0)
	DynamicImageSetTexture("YMBorder", "Yak"..yakuiVar.Panel.tex..ytextureset.."MB", 0, 0)
	DynamicImageSetTexture("YMPanel", "Yak"..yakuiVar.Panel.tex..ytextureset.."MP", 0, 0)
	DynamicImageSetTexture("YMFX", "Yak"..yakuiVar.Panel.tex..ytextureset.."MFX", 0, 0)
	if yakuiVar.Skin.active == true then yakuiSkin.UpdateAllBorders() end
end



function yakui.mwmtex()
	if WindowGetShowing("yakuiMWM") == true then 
				WindowSetShowing("YMPanel", true)
				WindowSetShowing("YMBorder", true)
				WindowSetShowing("YMFX", true)
			else
				WindowSetShowing("YMPanel", false)
				WindowSetShowing("YMBorder", false)
				WindowSetShowing("YMFX", false)
		end					
end




function yakui.healall()
d(".Heal")
	cost = MoneyFrame.FormatMoneyString(EA_Window_InteractionHealer.costToRemoveSinglePenalty * EA_Window_InteractionHealer.penaltyCount)
	EA_ChatWindow.Print(towstring(L"You have cleansed yourself of "..EA_Window_InteractionHealer.penaltyCount.. L" penalties" ))
	EA_ChatWindow.Print(towstring(L"This cost you "..cost ))
	EA_Window_InteractionHealer.HealAllPenalties()
end


-- function yakui.scbegin()
  -- broadcaststate = false
  -- DelayTime = REFRESH_DELAY
  -- RegisterEventHandler( SystemData.Events.UPDATE_PROCESSED, "yakui.scupdate")
-- end

-- function yakui.scupdate(elapsed)
	-- DelayTime = DelayTime - elapsed
    -- if DelayTime > 0 then
        -- return
    -- end
    -- DelayTime = REFRESH_DELAY
    
    -- if ( not GameData.Player.isInScenario ) then
        -- UnregisterEventHandler( SystemData.Events.UPDATE_PROCESSED, "yakui.scupdate" )
    -- else
        -- if not WindowGetShowing("ScenarioSummaryWindow") then
            -- BroadcastEvent( SystemData.Events.SCENARIO_STOP_UPDATING_PLAYERS_STATS)        
        -- else
            -- broadcaststate = not broadcaststate
            -- if (broadcaststate) then
                -- BroadcastEvent( SystemData.Events.SCENARIO_START_UPDATING_PLAYERS_STATS)
            -- else
                -- BroadcastEvent( SystemData.Events.SCENARIO_STOP_UPDATING_PLAYERS_STATS)
            -- end
        -- end
    -- end
-- end

function yakui.macrosdw()
	yakui.macrosnewtex(18)
end

function yakui.macrosup()
	yakui.macrosnewtex(-18)
end

function yakui.macrosnewtex(startId)
	if macroId+startId+EA_Window_Macro.NUM_MACRO_ICONS > 1688 or macroId+startId < 1 then return end
	macroId = macroId + startId
	for  slot = 1, EA_Window_Macro.NUM_MACRO_ICONS do
		local texture, x, y = GetIconData( macroId + slot )
		DynamicImageSetTexture( "MacroIconSelectionWindowIconSlot"..slot.."IconBase", texture, x, y )
	end
end

function yakui.macrosselect(...)
	yakui.macroshookselect(...)
	pcall(yakui.macrosnewicon)
end

function yakui.macrosnewicon()
	local slot = WindowGetId(SystemData.ActiveWindow.name)
	EA_Window_Macro.iconNum = macroId + slot
	local texture, x, y = GetIconData( EA_Window_Macro.iconNum )
	DynamicImageSetTexture( "EA_Window_MacroDetailsIconIconBase", texture, x, y )
end



function yakui.guildscroll()
    if not (GuildWindow and GuildWindow.IsPlayerInAGuild()) then
        return false
    end
    if (not GameData.Guild.m_GuildRank) or GameData.Guild.m_GuildRank < 17 then
        return false
    end
    -- 178 = The Viper Pit, 198 = Sigmar's Hammer
    if GameData.Player.zone == 178 or GameData.Player.zone == 198 then
        local itemData = DataUtils.GetItems()
        for k,v in pairs(itemData) do
            -- 65824 = order GRS, 65825 = destro GRS
            if v.uniqueID == 65824 or v.uniqueID == 65825 then
                -- Found a scroll, don't need to buy one.
                return false
            end
        end
        -- We didn't find any scrolls in inventory, so yes, we should probably buy some.
        return true
    else
        -- We're not in a guild tavern, so we don't care about buying scrolls.
        return false
    end
end

function yakui.guildscrollfly()
    SystemData.ActiveWindow.name = selectedFlightButton
    oldFlightPointLButtonUp()
end

function yakui.guildscrollhook()
    if not yakui.guildscroll() then
        oldFlightPointLButtonUp()
    else
        selectedFlightButton = SystemData.ActiveWindow.name
        DialogManager.MakeTwoButtonDialog(
            L"You're out of Guild Recall Scrolls!",
            L"Continue", yakui.guildscrollfly,
            L"Cancel", nil)
    end
end

local checkbreak = false

local function yakuiPO_UpdateLabel()
	if yakuiVar.DEVmode == true then print("YakUI: PO_UpdateLabel") end
	if yakuiVar.smoothout == true then
		if ((20 - math.floor(PO_Val)) == 5) and (checkbreak == false) then
			checkbreak = true
			yakuiPO_SmoothOut() 
		end
	end
	if PO_Status == PO_STATUS_LOGOUT then
		LabelSetText("YakuiPOInfo", towstring(20 - math.floor(PO_Val))..L"s")
		LabelSetText("YakuiPOInfoShadow", towstring(20 - math.floor(PO_Val))..L"s")
	elseif PO_Status == PO_STATUS_EXITGAME then
		if towstring("You will finish logging out in " .. 20 - math.floor(PO_Val) .. " seconds.") == GetFormatStringFromTable("Hardcoded", 457, {20 - math.floor(PO_Val)}) then
			LabelSetText("YakuiPOInfo", towstring(20 - math.floor(PO_Val))..L"s")
			LabelSetText("YakuiPOInfoShadow", towstring(20 - math.floor(PO_Val))..L"s")
		else
			LabelSetText("YakuiPOInfo", towstring(20 - math.floor(PO_Val))..L"s")
			LabelSetText("YakuiPOInfoShadow", towstring(20 - math.floor(PO_Val))..L"s")
		end
	end
end

function yakuiPO_SmoothOut()
	if yakuiVar.DEVmode == true then print("YakUI: PO_SmoothOut") end
	if DoesWindowExist("ySmoothOut") == true then DestroyWindow("ySmoothOut") end	
	CreateWindowFromTemplate("ySmoothOut","EA_FullResizeImage_TintableSolidBackground","Root")
	WindowSetShowing("ySmoothOut",true)
	WindowSetAlpha("ySmoothOut", 0)
	WindowSetLayer("ySmoothOut",3)
	WindowAddAnchor("ySmoothOut","topleft","Root","topleft",0,0)
	WindowAddAnchor("ySmoothOut","bottomright","Root","bottomright",0,0)
	WindowSetTintColor("ySmoothOut",0,0,0)
	WindowStartAlphaAnimation("ySmoothOut",Window.AnimationType.SINGLE_NO_RESET,0,1,4.5,true, 0,0)
end

function yakuiPO_SmoothOutCancel()
	if yakuiVar.DEVmode == true then print("YakUI: PO_SmoothOutCancel") end
	if DoesWindowExist("ySmoothOut") == true then DestroyWindow("ySmoothOut") end
	checkbreak = false
end

local function yakuiPO_Tick()
	if yakuiVar.DEVmode == true then print("YakUI: PO_Tick") end
	local msgcount = TextLogGetNumEntries("System")
	if msgcount == 0 then
		return
	end
	local msg = select(3, TextLogGetEntry("System", TextLogGetNumEntries("System") - 1))
	if msg ~= PO_Msg then
		PO_Msg = msg
		if msg == GetFormatStringFromTable("Hardcoded", 457, {20}) then
			PO_Val = 0.5
			PO_ValRange = 0
			yakuiPO_UpdateLabel()
			WindowSetShowing("YakuiPO", true)
		elseif msg == GetFormatStringFromTable("Hardcoded", 457, {15}) then
			PO_Val = 5
			PO_ValRange = 5
			yakuiPO_UpdateLabel()
			WindowSetShowing("YakuiPO", true)
		elseif msg == GetFormatStringFromTable("Hardcoded", 457, {10}) then
			PO_Val = 10
			PO_ValRange = 10
			yakuiPO_UpdateLabel()
			WindowSetShowing("YakuiPO", true)
		elseif msg == GetFormatStringFromTable("Hardcoded", 457, {5}) then
			PO_Val = 15
			PO_ValRange = 15
			yakuiPO_UpdateLabel()
			WindowSetShowing("YakuiPO", true)
		elseif msg == GetStringFromTable("Hardcoded", 458) then
			UnregisterEventHandler(SystemData.Events.UPDATE_PROCESSED, "yakui.POTickCheck")
			PO_Status = PO_STATUS_NONE
			if yakuiVar.smoothout == true then yakuiPO_SmoothOutCancel() end
			WindowSetShowing("YakuiPO", false)
			return
		end
	end
	if math.floor(PO_Val) ~= PO_ValRange and math.floor(PO_Val) < PO_ValRange + 5 then
		yakuiPO_UpdateLabel()
	end
end

local function yakuiPO_SetupAction(state)
	if yakuiVar.DEVmode == true then print("YakUI: PO_SetupAction") end
	if PO_Status > PO_STATUS_NONE then
	    return
	end
	WindowSetShowing("MainMenuWindow", false)
	RegisterEventHandler(SystemData.Events.UPDATE_PROCESSED, "yakui.POTickCheck")
	PO_Status = state
	yakuiPO_Tick()
end

local function EA_ChatWindow_OnKeyEnter(...)
	local input = WStringToString(EA_TextEntryGroupEntryBoxTextInput.Text)
	input = string.lower(input)
	local cmd = string.match(input, "^/%l+")
	if  cmd == "/logout" or cmd == "/camp" then
		yakui.POLogOut()
	elseif cmd == "/quit" or cmd == "/exit" or cmd == "/q" then
		yakui.POExitGame()
	end
	oldEA_ChatWindow_OnKeyEnter(...)
end

function yakui.POInit()
	if yakuiVar.DEVmode == true then print("YakUI: POInit") end
	CreateWindow("YakuiPO", false)
	WindowSetLayer("YakuiPO", 4)
	RegisterEventHandler(SystemData.Events.LOG_OUT, "yakui.POLogOut")
	RegisterEventHandler(SystemData.Events.EXIT_GAME, "yakui.POExitGame")
	oldEA_ChatWindow_OnKeyEnter = EA_ChatWindow.OnKeyEnter
	EA_ChatWindow.OnKeyEnter = EA_ChatWindow_OnKeyEnter
	WindowSetTintColor("YakuiPOBg", 255, 255, 255)
	DynamicImageSetTexture("YakuiPOBg", "SmoothOutBG", 0, 0)
	DynamicImageSetTextureDimensions("YakuiPOBg", 300, 300)
	LabelSetText("YakuiPOInfo", L"")
	LabelSetText("YakuiPOInfoShadow", L"")
	WindowSetAlpha("YakuiPO", 1)
	WindowSetShowing("YakuiPO", false)
end

function yakui.POTickCheck(elapsed)
	if yakuiVar.DEVmode == true then print("YakUI: POTickCheck") end
	PO_Time = PO_Time - elapsed
	PO_Val = PO_Val + elapsed
	if PO_Time > 0 then
		return
	end
	PO_Time = PO_TIMEDELAY
	yakuiPO_Tick()
end

function yakui.POLogOut()
	WindowSetAlpha("YakuiPO", 1)
	WindowSetShowing("YakuiPO", true)
	yakuiPO_SetupAction(PO_STATUS_LOGOUT)
end

function yakui.POExitGame()
	WindowSetAlpha("YakuiPO", 1)
	WindowSetShowing("YakuiPO", true)
	yakuiPO_SetupAction(PO_STATUS_EXITGAME)
end 

function yakui.POCancel()
	BroadcastEvent( SystemData.Events.LOG_OUT )
	if yakuiVar.smoothout == true then yakuiPO_SmoothOutCancel() end
	LabelSetText("YakuiPOInfo", L"")
	LabelSetText("YakuiPOInfoShadow", L"")	
	WindowSetShowing("YakuiPO", false)
end

function yakui.POOnShown()
	WindowUtils.OnShown( yakui.POCancel, WindowUtils.Cascade.MODE_NONE )
end

function yakui.POOnHidden()
	if yakuiVar.DEVmode == true then print("YakUI: POOnHidden") end
	if PO_Status > PO_STATUS_NONE then
		BroadcastEvent( SystemData.Events.LOG_OUT )
	end
	WindowUtils.OnHidden()
end



function yakui.MWMShutdown()
	LayoutEditor.UnregisterWindow("yakuiMWM")
	WindowUnregisterEventHandler("yakuiMWM", SystemData.Events.LOADING_END)
	WindowUnregisterEventHandler("yakuiMWM", SystemData.Events.PLAYER_ZONE_CHANGED)
	RemoveMapInstance("yakuiMWM")
end

function yakui.MWMUpdateMap()
	MapSetMapView( "yakuiMWM", GameDefs.MapLevel.ZONE_MAP, GameData.Player.zone)

end

function yakui.MWMInterfaceReloaded()
	yakui.MWMUpdateMap()
	WindowSetShowing("yakuiMWM", false)
end

function yakui.MWMOnMButtonUp()
	EA_Window_ContextMenu.CreateDefaultContextMenu("yakuiMWM")
end

function yakui.MWMToggleMap(show)
	if show ~= true and show ~= false then
		show = not WindowGetShowing("yakuiMWM")
	end
	WindowSetShowing("yakuiMWM", show)
	yakui.mwmtex()
end

function yakui.MWMOnButtonMouseOver()
	DynamicImageSetTextureSlice("MiniWorldMapButtonOpen", "Quest-Tracker-Open-ROLLOVER")
	DynamicImageSetTextureSlice("MiniWorldMapButtonClosed", "Quest-Tracker-Closed-ROLLOVER")
end

function yakui.MWMOnButtonMouseOverEnd()
	DynamicImageSetTextureSlice("MiniWorldMapButtonOpen", "Quest-Tracker-Open")
	DynamicImageSetTextureSlice("MiniWorldMapButtonClosed", "Quest-Tracker-Closed")
end


function yakui.MWMUpdateFilters()
	local show
	for index, filterType in pairs( SystemData.MapPips ) do
		show = EA_Window_WorldMap.Settings.mapPinFilters[filterType] 
		MapSetPinFilter("yakuiMWM", filterType, show )
	end
end

TargetLastSettings = {}

yakui.TargetLoldFriendlyTarget = nil
TargetLastSettings.isFriendlyTargetSticky = false
TargetLastSettings.isHostileTargetSticky = false

local escapeFlag = false

local function GetTargetName(target)
    if not TargetInfo:UnitIsNPC(target) then
        return TargetInfo:UnitName(target)
    else
        return nil
    end
end

local function TargetPlayer(playerName)
    local trimName = playerName:match(L"([^^]+)^?([^^]*)")
    SystemData.UserInput.ChatText = L"/target "..trimName
    BroadcastEvent(SystemData.Events.SEND_CHAT_TEXT)
end

function yakui.TargetLSetEscapeFlag()
    escapeFlag = true
end

function yakui.TargetLUpdateTargets(targetClass, targetId, targetType)
    
    TargetInfo:UpdateFromClient()
    
    if targetClass == "selffriendlytarget" then
        local escaped = escapeFlag
        escapeFlag = false
        
        if yakui.TargetLisFriendlyTargetLocked then
            targetname = GetTargetName(targetClass)
            if targetname ~= yakui.TargetLlockedFriendlyTarget then
                TargetPlayer(yakui.TargetLlockedFriendlyTarget)
            end
        else
            targetname = GetTargetName(targetClass)
            if targetname == nil then return end
            if targetname == L"" then
                if TargetLastSettings.isFriendlyTargetSticky and yakui.TargetLlastKnownFriendlyTarget and (not escaped) then
                    TargetPlayer(yakui.TargetLlastKnownFriendlyTarget)
                    return
                else
                    targetname = GameData.Player.name
                end
            end
            if targetname ~= yakui.TargetLlastKnownFriendlyTarget then
                  yakui.TargetLoldFriendlyTarget = yakui.TargetLlastKnownFriendlyTarget
                  yakui.TargetLlastKnownFriendlyTarget = targetname
            end
        end
    end
    
    if targetClass == "selfhostiletarget" then
        targetname = GetTargetName(targetClass)
        if targetname == nil then return end
        if targetname == L"" then
            if TargetLastSettings.isHostileTargetSticky and yakui.TargetLlastKnownHostileTarget then
                TargetPlayer(yakui.TargetLlastKnownHostileTarget)
            end
            return
        end
        if targetname ~= yakui.TargetLlastKnownHostileTarget then
            if yakui.TargetLlastKnownHostileTarget ~= L"" then
                yakui.TargetLoldHostileTarget = yakui.TargetLlastKnownHostileTarget
            end
            yakui.TargetLlastKnownHostileTarget = targetname
        end
    end
    
end

function TargetLastFriendlyTarget()
    if yakui.TargetLoldFriendlyTarget then
        TargetPlayer(yakui.TargetLoldFriendlyTarget)
    end
end

function TargetLastHostileTarget()
    if yakui.TargetLoldHostileTarget then
        TargetPlayer(yakui.TargetLoldHostileTarget)
    end
end

function ToggleFriendlyTargetLock()
    if yakui.TargetLisFriendlyTargetLocked then
        yakui.TargetLisFriendlyTargetLocked = false
        EA_ChatWindow.Print(L"Friendly target unlocked.")
    else
        targetname = GetTargetName("selffriendlytarget")
        if targetname == nil then
            EA_ChatWindow.Print(L"Can't lock an NPC friendly target.")
            return
        end
        if targetname == L"" then targetname = GameData.Player.name end
        yakui.TargetLlockedFriendlyTarget = targetname
        yakui.TargetLisFriendlyTargetLocked = true
        EA_ChatWindow.Print(L"Friendly target locked to "..targetname..L".")
    end
end

function ToggleFriendlyTargetSticky()
    TargetLastSettings.isFriendlyTargetSticky = not TargetLastSettings.isFriendlyTargetSticky
    if TargetLastSettings.isFriendlyTargetSticky then
        EA_ChatWindow.Print(L"Friendly target is now sticky.")
    else
        EA_ChatWindow.Print(L"Friendly target is now nonsticky.")
    end
end

function ToggleHostileTargetSticky()
    TargetLastSettings.isHostileTargetSticky = not TargetLastSettings.isHostileTargetSticky
    if TargetLastSettings.isHostileTargetSticky then
        EA_ChatWindow.Print(L"Hostile target is now sticky.")
    else
        EA_ChatWindow.Print(L"Hostile target is now nonsticky.")
    end
end



function yakui.handle_loading_end_function()
		yakui.mwmtex()
end

local TIME_OUT = 5
ALRTLMT = {}

function yakui.alertlimitInit()
	RegisterEventHandler(SystemData.Events.UPDATE_PROCESSED, "yakui.alertlimitOnUpdate")
	yakui.alertlimitlastMessage = L""
	yakui.alertlimitsinceMessage = 0

	-- Hooks
	yakui.alertlimitSetAlertDataHook = AlertTextWindow.SetAlertData
	AlertTextWindow.SetAlertData = yakui.alertlimitSetAlertData
end


function yakui.alertlimitOnUpdate(elapsed)
	-- Only if we have a message
	if (yakui.alertlimitlastMessage ~= L"") then
		-- How long has it been?
		yakui.alertlimitsinceMessage = yakui.alertlimitsinceMessage + elapsed
		if (yakui.alertlimitsinceMessage > TIME_OUT) then
			-- Time to reset
			yakui.alertlimitlastMessage = L""
			yakui.alertlimitsinceMessage = 0
		end
	end
end

function yakui.alertlimitSetAlertData(type, text)
	local displayMessage = false
	for _, message in pairs(text) do
		if (message ~= yakui.alertlimitlastMessage) then
			displayMessage = true
			yakui.alertlimitlastMessage = message
			yakui.alertlimitsinceMessage = 0
		end
	end
	if yakuiVar.limitalert == false then displayMessage = true end
	if (displayMessage) then
		yakui.alertlimitSetAlertDataHook(type, text)
	end
end

function yakui.relogafterprofileselection()
	-- KwestorTracker.NubLButtonUp()
	TextLogAddEntry("Chat", SystemData.ChatLogFilters.SAY, L"YakUI will now log off to complete the installation.")
	CreateWindow("YOnScreenMessage",true)
	LabelSetText("YOnScreenMessage_Label", L"YakUI will now log off to complete the installation.")
	BroadcastEvent( SystemData.Events.LOG_OUT )
end

function yakui.postloading()
	if yakuiVar.Skin.active == true then yakuiSkin.initialize() end
	TextLogAddEntry("Chat", SystemData.ChatLogFilters.SHOUT, towstring(yakuiVar.ver)..L" initialized...")
	--core addon check
	if Effigy and Effigy.Initialize then 
		yakuiVar.Warnings.Huduf = 1
	else 
		if yakuiVar.Warnings.Huduf < 4 then 
			yakuiVar.Warnings.Huduf = yakuiVar.Warnings.Huduf+1
			TextLogAddEntry("Chat", SystemData.ChatLogFilters.SAY, L"WARNING: HudUF not found! (This warning will be shown "..towstring(4-yakuiVar.Warnings.Huduf)..L" more times)")
		end
	end

	-- Enemy hook
	if Enemy then
		DynamicImageSetTexture ("EnemyIcon", "YakuiEnemyRed", 0, 0)
		yakui.enemyiconhook()
	end

	if TidyChat then 
		yakuiVar.Warnings.TChat = 1
		WindowSetShowing("YakuiFWButton", true)
		WindowSetShowing("YakuiBWButton", true)
		WindowSetShowing("YakChatdisplay", true)
		yakui.tidychathook()
	else 
		if yakuiVar.Warnings.TChat < 4 then 
			yakuiVar.Warnings.TChat = yakuiVar.Warnings.TChat+1
			TextLogAddEntry("Chat", SystemData.ChatLogFilters.SAY, L"WARNING: TidyChat not found! (This warning will be shown "..towstring(4-yakuiVar.Warnings.TChat)..L" more times)")
		end
		WindowSetShowing("YakuiFWButton", false)
		WindowSetShowing("YakuiBWButton", false)
		WindowSetShowing("YakChatdisplay", false)
	end

	if TidyRoll then 
		yakuiVar.Warnings.TRoll = 1 
	else 
		if yakuiVar.Warnings.TRoll < 4 then 
			yakuiVar.Warnings.TRoll = yakuiVar.Warnings.TRoll+1
			TextLogAddEntry("Chat", SystemData.ChatLogFilters.SAY, L"WARNING: TidyRoll not found! (This warning will be shown "..towstring(4-yakuiVar.Warnings.TRoll)..L" more times)")
		end
	end

	if ScenarioStats then 
		yakuiVar.Warnings.ScenarioStats = 1 
	else 
		if yakuiVar.Warnings.ScenarioStats < 4 then 
			yakuiVar.Warnings.ScenarioStats = yakuiVar.Warnings.ScenarioStats+1
			TextLogAddEntry("Chat", SystemData.ChatLogFilters.SAY, L"WARNING: ScenarioStats not found! (This warning will be shown "..towstring(4-yakuiVar.Warnings.ScenarioStats)..L" more times)")
		end
	end

	if Phantom then 
		yakuiVar.Warnings.Phantom = 1 
	else 
		if yakuiVar.Warnings.Phantom < 4 then 
			yakuiVar.Warnings.Phantom = yakuiVar.Warnings.Phantom+1
			TextLogAddEntry("Chat", SystemData.ChatLogFilters.SAY, L"WARNING: Phantom not found! (This warning will be shown "..towstring(4-yakuiVar.Warnings.Phantom)..L" more times)")
		end
	end

	if Dascore then 
		yakuiVar.Warnings.DaScore = 1 
	else 
		if yakuiVar.Warnings.DaScore < 4 then 
			yakuiVar.Warnings.DaScore = yakuiVar.Warnings.DaScore+1
			TextLogAddEntry("Chat", SystemData.ChatLogFilters.SAY, L"WARNING: DaScore not found! (This warning will be shown "..towstring(4-yakuiVar.Warnings.DaScore)..L" more times)")
		end
	end

	if Targets then 
		yakuiVar.Warnings.Targets = 1
		WindowSetShowing("YakuiTTButton", true)
	else 
		if yakuiVar.Warnings.Targets < 4 then 
			yakuiVar.Warnings.Targets = yakuiVar.Warnings.Targets+1
			TextLogAddEntry("Chat", SystemData.ChatLogFilters.SAY, L"WARNING: Targets not found! (This warning will be shown "..towstring(4-yakuiVar.Warnings.Targets)..L" more times)")
		end
		WindowSetShowing("YakuiTTButton", false)
	end

	if SOR then 
		yakuiVar.Warnings.SOR = 1
		WindowSetShowing("YakuiSORButton", true)
	else 
		if yakuiVar.Warnings.SOR < 4 then 
			yakuiVar.Warnings.SOR = yakuiVar.Warnings.SOR+1
			TextLogAddEntry("Chat", SystemData.ChatLogFilters.SAY, L"WARNING: State Of Realm not found! (This warning will be shown "..towstring(4-yakuiVar.Warnings.SOR)..L" more times)")
		end
		WindowSetShowing("YakuiSORButton", false)
	end

	if Squared then 
		yakuiVar.Warnings.Squared = 1 
	else 
		if yakuiVar.Warnings.Squared < 4 then 
			yakuiVar.Warnings.Squared = yakuiVar.Warnings.Squared+1
			TextLogAddEntry("Chat", SystemData.ChatLogFilters.SAY, L"WARNING: Squared not found! (This warning will be shown "..towstring(4-yakuiVar.Warnings.Squared)..L" more times)")
		end
	end

	if DAoCBuff then 
		yakuiVar.Warnings.DaocBuff = 1
	else 
		if yakuiVar.Warnings.DaocBuff < 4 then 
			yakuiVar.Warnings.DaocBuff = yakuiVar.Warnings.DaocBuff+1
			TextLogAddEntry("Chat", SystemData.ChatLogFilters.SAY, L"WARNING: DaoCBuff not found! (This warning will be shown "..towstring(4-yakuiVar.Warnings.DaocBuff)..L" more times)")
		end
	end

	if WARCommander then 
		yakuiVar.Warnings.Warcommander = 1
		WindowSetShowing("YakuiWCButton", true)
	else 
		if yakuiVar.Warnings.Warcommander < 4 then 
			yakuiVar.Warnings.Warcommander = yakuiVar.Warnings.Warcommander+1
			TextLogAddEntry("Chat", SystemData.ChatLogFilters.SAY, L"WARNING: WarCommander not found! (This warning will be shown "..towstring(4-yakuiVar.Warnings.Warcommander)..L" more times)")
		end
		WindowSetShowing("YakuiWCButton", false)
	end

	if Minmap then 
		yakuiVar.Warnings.Minmap = 1
		yakui.minmapmwmtogglehook()
		--RegisterEventHandler(SystemData.Events.UPDATE_PROCESSED, "yakui.minmaphookdel")
	else 
		if yakuiVar.Warnings.Minmap < 4 then 
			yakuiVar.Warnings.Minmap = yakuiVar.Warnings.Minmap+1
			TextLogAddEntry("Chat", SystemData.ChatLogFilters.SAY, L"WARNING: Minmap not found! (This warning will be shown "..towstring(4-yakuiVar.Warnings.Minmap)..L" more times)")
		end
		
	end
	local screenWidth, screenHeight = GetScreenResolution()
	local resocheck = towstring(screenWidth)..L"x"..towstring(screenHeight)
	if resocheck == not towstring(yakuiVar.Panel.res) then
		TextLogAddEntry("Chat", SystemData.ChatLogFilters.SAY, L"WARNING: Game resolution and YakUI profile don't match!")
	end

	-- dammaz kron stuff
	if DK_Config and DK_Config.OnUpdateSettingButton and Moth and Moth.Initialize then
			DK_Config.ToggleSetting( "MiscMoth" , 0 )
	end

	
	-- 2nd Start only
	if yakuiVar.counter == 2 then
		yakuiUpdate.afterloading()
	end

	-- was firststeps open before reloading ui?
	if yakuiVar.firststepsopen == true then yakuifirststeps.show() end

	-- infobar loc module needs delay or libsurveyor won't be available at start
	yakuiInfo.loc_moduleentry_point()
	if yakuiVar.loc == true then
		WindowSetShowing("i_loc", true)
		RegisterEventHandler(SystemData.Events.PLAYER_POSITION_UPDATED,"yakuiInfo.loc_moduleupdate")
	else
		WindowSetShowing("i_loc", false)
	end
	if DoesWindowExist("DammazKronHTS") == true then WindowSetShowing("DammazKronHTS", false) end
	if DoesWindowExist("DammazKronHTS") == true and DoesWindowExist("HostileTarget") == true then
		WindowClearAnchors("DammazKronHTS")
		WindowAddAnchor("DammazKronHTS", "bottomright", "HostileTarget", "bottomleft" , 20 , -20 )
		LayoutEditor.UnregisterWindow("DammazKronHTS")
	end
	
	RegisterEventHandler(SystemData.Events.UPDATE_PROCESSED, "yakui.getinitmoralscale")
end

function yakui.getinitmoralscale()
	if DoesWindowExist("EA_MoraleBarContentsButton1CooldownTimer") then
		UnregisterEventHandler(SystemData.Events.UPDATE_PROCESSED, "yakui.getinitmoralscale")
		moraleInitScale = WindowGetScale("EA_MoraleBarContentsButton1CooldownTimer")
		if moraleEventhandler == false then
			RegisterEventHandler(SystemData.Events.PLAYER_MORALE_UPDATED, "yakui.setmoraleCDsize")
			moraleEventhandler = true
		end
	end
end


function yakui.setmoraleCDsize()
		if moraleEventhandler == true then 
			UnregisterEventHandler(SystemData.Events.PLAYER_MORALE_UPDATED, "yakui.setmoraleCDsize")
			moraleEventhandler = false
		end
		if yakuiVar.moraleCDsize == true then 
			WindowSetScale("EA_MoraleBarContentsButton1CooldownTimer", 1.7*moraleInitScale)
			WindowSetScale("EA_MoraleBarContentsButton2CooldownTimer", 1.7*moraleInitScale)
			WindowSetScale("EA_MoraleBarContentsButton3CooldownTimer", 1.7*moraleInitScale)
			WindowSetScale("EA_MoraleBarContentsButton4CooldownTimer", 1.7*moraleInitScale)
		end
end

function yakui.tidychathook()
	oldTidyChatOptionsOnApply = TidyChat.Options.OnApply
	TidyChat.Options.OnApply =
		function(...)
			oldTidyChatOptionsOnApply(...)
			if TidyChat.Settings[1].chatwindow_tabs_showing == false then
				WindowSetShowing("YakuiFWButton", true)
				WindowSetShowing("YakuiBWButton", true)
				WindowSetShowing("YakChatdisplay", true)
			else
				WindowSetShowing("YakuiFWButton", false)
				WindowSetShowing("YakuiBWButton", false)
				WindowSetShowing("YakChatdisplay", false)
			end
		end
end

function yakui.minmaphookdel()
	if Minmap.OnClickMap then
		UnregisterEventHandler(SystemData.Events.UPDATE_PROCESSED, "yakui.minmaphookdel")
		yakui.minmapmwmtogglehook()
	end
end

function yakui.minmapmwmtogglehook()
	oldMinmapOnClickMap = Minmap.OnClickMap
	Minmap.OnClickMap =
		function(...)
			oldMinmapOnClickMap(...)
			if yakuiVar.minmaphook == true then yakui.ybuttonr() end
		end
end

local delaycounter
local targetfunc

function yakui.delay(del, func) --del = #of updates, func = functionname without ""!!!
	delaycounter = del
	targetfunc = func
	RegisterEventHandler(SystemData.Events.UPDATE_PROCESSED, "yakui.delay2")
end

function yakui.delay2()
	delaycounter = delaycounter - 1
	if delaycounter == 0 then
		UnregisterEventHandler(SystemData.Events.UPDATE_PROCESSED, "yakui.delay2")
		targetfunc()
	end
end

--------------------------------------------------------------------------------------------------------------------------------------------------------------------


function yakui.zonechange()
	if logon == false then
	if yakuiVar.Huduf.ignore == false then
	--huduf: groupframes
		bar =  Effigy.Bars["GroupMember1"]
		bar.show = yakuiVar.Huduf.groupframes
		bar:setup()
		bar:render()
		bar =  Effigy.Bars["GroupMember2"]
		bar.show = yakuiVar.Huduf.groupframes
		bar:setup()
		bar:render()
		bar =  Effigy.Bars["GroupMember3"]
		bar.show = yakuiVar.Huduf.groupframes
		bar:setup()
		bar:render()
		bar =  Effigy.Bars["GroupMember4"]
		bar.show = yakuiVar.Huduf.groupframes
		bar:setup()
		bar:render()
		bar =  Effigy.Bars["GroupMember5"]
		bar.show = yakuiVar.Huduf.groupframes
		bar:setup()
		bar:render()
		
	--huduf: groupicons
		bar =  Effigy.Bars["WorldGroupMember1"]
		bar.show = yakuiVar.Huduf.grpico
		bar:setup()
		bar:render()
		bar =  Effigy.Bars["WorldGroupMember2"]
		bar.show = yakuiVar.Huduf.grpico
		bar:setup()
		bar:render()
		bar =  Effigy.Bars["WorldGroupMember3"]
		bar.show = yakuiVar.Huduf.grpico
		bar:setup()
		bar:render()
		bar =  Effigy.Bars["WorldGroupMember4"]
		bar.show = yakuiVar.Huduf.grpico
		bar:setup()
		bar:render()
		bar =  Effigy.Bars["WorldGroupMember5"]
		bar.show = yakuiVar.Huduf.grpico
		bar:setup()
		bar:render()
	end
	end
	if moraleEventhandler == false then 
		RegisterEventHandler(SystemData.Events.PLAYER_MORALE_UPDATED, "yakui.setmoraleCDsize") 
		moraleEventhandler = true
	end
	logon = false
end

function yakui.onload()
	WindowSetShowing("EA_MoraleBarContentsBackground", false)
	WindowSetShowing("EA_MoraleBarContentsOverlay", false)
	WindowClearAnchors("EA_MoraleBarContentsButton3")
	WindowAddAnchor( "EA_MoraleBarContentsButton3", "bottomleft", "EA_MoraleBar", "bottomleft", 181, -10 )
	WindowClearAnchors("EA_MoraleBarContentsButton4")
	WindowAddAnchor( "EA_MoraleBarContentsButton4", "bottomleft", "EA_MoraleBar", "bottomleft", 249, -10 )
	if moraleEventhandler == false then 
		RegisterEventHandler(SystemData.Events.PLAYER_MORALE_UPDATED, "yakui.setmoraleCDsize") 
		moraleEventhandler = true
	end
end

function yakui.onreload()
	WindowSetShowing("EA_MoraleBarContentsBackground", false)
	WindowSetShowing("EA_MoraleBarContentsOverlay", false)
	WindowClearAnchors("EA_MoraleBarContentsButton3")
	WindowAddAnchor( "EA_MoraleBarContentsButton3", "bottomleft", "EA_MoraleBar", "bottomleft", 181, -10 )
	WindowClearAnchors("EA_MoraleBarContentsButton4")
	WindowAddAnchor( "EA_MoraleBarContentsButton4", "bottomleft", "EA_MoraleBar", "bottomleft", 249, -10 )
	if DoesWindowExist("DammazKronHTS") == true then WindowSetShowing("DammazKronHTS", false) end
	if DoesWindowExist("DammazKronHTS") == true and DoesWindowExist("HostileTarget") == true then
		WindowClearAnchors("DammazKronHTS")
		WindowAddAnchor("DammazKronHTS", "bottomright", "HostileTarget", "bottomleft" , 20 , 0 )
		LayoutEditor.UnregisterWindow("DammazKronHTS")
	end
end

function yakui.enemyiconhook()
	if yakuiVar.DEVmode == true then print("YakUI: enemyiconhook") end
	local oldEnemyUI_Icon_Switch = Enemy.UI_Icon_Switch
	Enemy.UI_Icon_Switch =
		function(on,...)
			oldEnemyUI_Icon_Switch(on,...)
			if (on) then
				DynamicImageSetTexture ("EnemyIcon", "YakuiEnemyGreen", 0, 0)
			else
				DynamicImageSetTexture ("EnemyIcon", "YakuiEnemyRed", 0, 0)
			end
		end
end


function yakui.reloadui()
	InterfaceCore.ReloadUI()
end

function yakui.minefilter()
    oldCFL = EA_Window_InteractionStore.CreateFilteredList

    CreateWindowFromTemplate("yMineFilterCheckbox",
        "EA_Window_InteractionStoreFilterTemplate", "EA_Window_InteractionStoreFilter")
    WindowClearAnchors("yMineFilterCheckbox")
    WindowAddAnchor("yMineFilterCheckbox", "right", "EA_Window_InteractionStoreFilterByUsable", "left", 0, 0)
    LabelSetText("yMineFilterCheckboxLabel", L"For Me")
    
    ButtonSetPressedFlag("yMineFilterCheckboxButton", true)
    
    EA_Window_InteractionStore.CreateFilteredList =
        function(...)
            local result = oldCFL(...)
            
            if not ButtonGetPressedFlag("yMineFilterCheckboxButton") then return result end
            
            local i = 1
            while i <= #result do
                local itemData = EA_Window_InteractionStore.displayData[result[i]]
                if DataUtils.CareerIsAllowedForItem(GameData.Player.career.line, itemData) and
                    DataUtils.SkillIsEnoughForItem( GameData.Player.Skills, itemData ) and
                    DataUtils.RaceIsAllowedForItem( GameData.Player.race.id, itemData) then
                    i = i + 1
                else
                    tremove(result,i)
                end
            end
            
            return result
        end
end
		
--------------------------------------------------------------------------------------------------------------------------------------------------------------------

