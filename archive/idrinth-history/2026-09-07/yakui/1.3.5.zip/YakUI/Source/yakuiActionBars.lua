-- yakuiActionBars.lua build20100524

local oldActionButtonUpdateBurning = nil
local oldActionButtonUpdateCooldownAnimation = nil
local oldActionButtonCreate = nil
local oldActionButtonUpdateKeyBindingText = nil
local oldMoraleButtonUpdate = nil
local oldActionButtonUpdateEnabledState = nil
local oldActionButtonOnMouseOver=ActionButton.OnMouseOver
local oldSettingsWindowTabbedOnCancelButton = SettingsWindowTabbed.OnCancelButton

local BASE_ICON         = 0
local BUTTON_TEXT       = 1
local COOLDOWN          = 2
local COOLDOWN_TIMER    = 3
local FLASH_ANIM        = 4
local ACTIVE_ANIM       = 5
local GLOW_ANIM         = 6
local STACK_COUNT_TEXT  = 7

local USE_ENABLED_ICON  = 42

local function ButtonTextures(btn)
	if yakuiVar.Actionbar.usetexture == true then
		if yakuiVar.Actionbar.texture == 1 then
			ButtonSetTexture(btn, Button.ButtonState.NORMAL, "ActionbarButton1", 0, 0)
			ButtonSetTexture(btn, Button.ButtonState.HIGHLIGHTED, "ActionbarButton1", 0, 0)
			ButtonSetTexture(btn, Button.ButtonState.PRESSED, "ActionbarButtonDown1", 0, 0)
			ButtonSetTexture(btn, Button.ButtonState.PRESSED_HIGHLIGHTED, "ActionbarButtonDown1", 0, 0)
		elseif yakuiVar.Actionbar.texture == 2 then
			ButtonSetTexture(btn, Button.ButtonState.NORMAL, "ActionbarButton2", 0, 0)
			ButtonSetTexture(btn, Button.ButtonState.HIGHLIGHTED, "ActionbarButton2", 0, 0)
			ButtonSetTexture(btn, Button.ButtonState.PRESSED, "ActionbarButtonDown2", 0, 0)
			ButtonSetTexture(btn, Button.ButtonState.PRESSED_HIGHLIGHTED, "ActionbarButtonDown2", 0, 0)
		elseif yakuiVar.Actionbar.texture == 3 then
			ButtonSetTexture(btn, Button.ButtonState.NORMAL, "ActionbarButton3", 0, 0)
			ButtonSetTexture(btn, Button.ButtonState.HIGHLIGHTED, "ActionbarButton3", 0, 0)
			ButtonSetTexture(btn, Button.ButtonState.PRESSED, "ActionbarButtonDown3", 0, 0)
			ButtonSetTexture(btn, Button.ButtonState.PRESSED_HIGHLIGHTED, "ActionbarButtonDown3", 0, 0)		
		end
	end
end

function TextureGo(btn)
	for barNum,barData in pairs(ActionBars.m_Bars) do
		for btnNum,btnData in ipairs(barData.m_Buttons) do
			ButtonTextures(btnData.m_Name.."Action")
		end
	end
end

function ActionButton:OnMouseOver(...)
  if yakuiVar.Actionbar.Tooltips == true then 
    oldActionButtonOnMouseOver(self,...) 
  end 
end


function yakuiActionBars_Initialize()
	if yakuiVar.Actionbar.usetexture == true then
		RegisterEventHandler(SystemData.Events.PLAYER_HOT_BAR_UPDATED, "TextureOverlayUpdate")
    end

	SettingsWindowTabbed.OnCancelButton =
		function(...)
			oldSettingsWindowTabbedOnCancelButton(...)
			if yakuiVar.Actionbar.Pagers == false then ChangePagers() end
		end
    
    oldActionButtonUpdateBurning = ActionButton.UpdateBurning
    ActionButton.UpdateBurning =
        function(...)
            oldActionButtonUpdateBurning(...)
            if yakuiVar.Actionbar.Glow == false then  --Y
				local self = ...
				local glowFrame = self.m_Windows[GLOW_ANIM]
				if glowFrame:IsShowing() then
					glowFrame:StopAnimation(true)
					glowFrame:Show(false)
				end
			end
        end
        
    oldActionButtonUpdateCooldownAnimation = ActionButton.UpdateCooldownAnimation
    ActionButton.UpdateCooldownAnimation =
        function(...)
            oldActionButtonUpdateCooldownAnimation(...)
            local self = ...
            local cooldownFrame = self.m_Windows[COOLDOWN]
            local cooldownTimer = self.m_Windows[COOLDOWN_TIMER]
            local flashFrame = self.m_Windows[FLASH_ANIM]
            local iconFrame = self.m_Windows[BASE_ICON]

			if yakuiVar.Actionbar.Flash == false then  --Y
				flashFrame:SetAlpha(0.0)
			else
				flashFrame:SetAlpha(1.0)
			end

            if ((self.m_Cooldown > 0) and (self.m_MaxCooldown > 0)) then
				if yakuiVar.Actionbar.CDAnimation == false then  --Y
					cooldownFrame:SetAlpha(0.0)
				else
					cooldownFrame:SetAlpha(0.8)
				end
                cooldownFrame:SetTintColor(0, 0, 0)
                iconFrame:SetTintColor(255, 255, 255)

                if self.m_Cooldown > 3 then
					if self.m_Cooldown >= 60 then
						cooldownTimer:SetText(wstring.format(L"%dm", math.ceil(self.m_Cooldown / 60)))
                    else
						cooldownTimer:SetText(wstring.format(L"%d", self.m_Cooldown))
					end
                else
                    cooldownTimer:SetText(wstring.format(L"%0.1f", self.m_Cooldown))
                end

                if self.m_MaxCooldown >= 1.6 then
                    cooldownTimer:Show(true)

                else
                    cooldownTimer:Show(false)
					self.m_Windows[COOLDOWN]:Show(yakuiVar.Actionbar.GCDAnimation) --Y
                end
				

			else
                cooldownTimer:Show(false)
        
                if (self.m_IsEnabled == true) and (self.m_IsTargetValid == true) then
                    iconFrame:SetTintColor(255, 255, 255)
                elseif (self.m_IsEnabled == true) then
                    iconFrame:SetTintColor(200, 0, 0)
                elseif (self.m_IsTargetValid == false) then
                    iconFrame:SetTintColor(100, 0, 0)
                elseif self.m_IsEnabled == false then
                    texture, x, y, disabledTexture = GetIconData(self.m_IconNum)
					if disabledTexture == "" then
						iconFrame:SetTintColor(150, 150, 150)
					end
                else
                    iconFrame:SetTintColor(255, 255, 255)
                end
            end
        end
        
    oldActionButtonCreate = ActionButton.Create
    ActionButton.Create =
        function(...)
            local newButton = oldActionButtonCreate(...)
            if not newButton then return nil end
            local timerLabel = newButton.m_Windows[COOLDOWN_TIMER].m_Name
            local buttonLabel = newButton.m_Windows[BUTTON_TEXT].m_Name
            LabelSetFont(timerLabel, "font_clear_large_bold", 22)
            LabelSetFont(buttonLabel, "font_clear_medium_bold", 22)
            
            WindowSetDimensions(timerLabel, WindowGetDimensions(WindowGetParent(timerLabel)))
            
            return newButton
        end
        
    oldActionButtonUpdateKeyBindingText = ActionButton.UpdateKeyBindingText
    ActionButton.UpdateKeyBindingText =
        function(...)
            oldActionButtonUpdateKeyBindingText(...)
            local self = ...
            local buttonLabel = self.m_Windows[BUTTON_TEXT].m_Name
            
            WindowSetShowing(buttonLabel, yakuiVar.Actionbar.Keybindings) --Y
            
            local btnName = self.m_Name
            if btnName:sub(1,12) == "EA_ActionBar" then
                ButtonTextures(btnName.."Action")
            end
            
        end
        
    oldActionButtonUpdateEnabledState = ActionButton.UpdateEnabledState
    ActionButton.UpdateEnabledState = function(self, ...)
        oldActionButtonUpdateEnabledState(self, ...)
        
        local iconFrame = self.m_Windows[BASE_ICON]
        
        if (self.m_IsEnabled == true) and (self.m_IsTargetValid == true) then
            iconFrame:SetTintColor(255, 255, 255)
        elseif (self.m_IsEnabled == true) then
            iconFrame:SetTintColor(255, 0, 0)
        elseif (self.m_IsTargetValid == false) then
            iconFrame:SetTintColor(255, 0, 0)
        elseif self.m_IsEnabled == false then
			texture, x, y, disabledTexture = GetIconData(self.m_IconNum)
			if disabledTexture == "" then
				iconFrame:SetTintColor(150, 150, 150)
			end
        else
            iconFrame:SetTintColor(255, 255, 255)
        end
        
    end
    oldMoraleButtonUpdate = MoraleButton.Update
    MoraleButton.Update = function(self, ...)
        oldMoraleButtonUpdate(self, ...)
        
        local BASE_ICON         = 2
    
        if self.m_AbilityId > 0 then
            if self.m_IsTargetValid then
                self.m_Windows[BASE_ICON]:SetTintColor (255, 255, 255)
            else
                self.m_Windows[BASE_ICON]:SetTintColor (255, 0, 0)
            end
        end
        
    end
end

local actionbarupdate

function TextureOverlayUpdate()
	actionbarupdate = yakuiVar.Actionbar.updatedelay
	UnregisterEventHandler(SystemData.Events.PLAYER_HOT_BAR_UPDATED, "TextureOverlayUpdate")
	RegisterEventHandler(SystemData.Events.UPDATE_PROCESSED, "TextureOverlayUpdate2")
end
	
function TextureOverlayUpdate2()
	actionbarupdate = actionbarupdate-1
	if actionbarupdate == 0 then
		UnregisterEventHandler(SystemData.Events.UPDATE_PROCESSED, "TextureOverlayUpdate2")
		TextureGo()
		RegisterEventHandler(SystemData.Events.PLAYER_HOT_BAR_UPDATED, "TextureOverlayUpdate")
	end
end

function ChangePagers()
	local i = 1
	repeat
				ActionBarClusterManager:UnregisterClusterWithLayoutEditor ()
				if yakuiVar.Actionbar.Pagers == false then
					ActionBarClusterManager.m_Settings:SetActionBarSetting(i, "selector", ActionBarConstants.HIDE_PAGE_SELECTOR)
					ActionBars.m_Bars[i].m_PageSelectorMode = ActionBarConstants.HIDE_PAGE_SELECTOR
					if ActionBars.m_Bars[i].m_PageSelectorWindow then
						ActionBars.m_Bars[i].m_PageSelectorWindow:Show(false)
					end
				elseif yakuiVar.Actionbar.Pagers == true then
					ActionBarClusterManager.m_Settings:SetActionBarSetting(i, "selector", ActionBarConstants.SHOW_PAGE_SELECTOR_RIGHT)
					ActionBars.m_Bars[i].m_PageSelectorMode = ActionBarConstants.SHOW_PAGE_SELECTOR_RIGHT
					if ActionBars.m_Bars[i].m_PageSelectorWindow then
						ActionBars.m_Bars[i].m_PageSelectorWindow:Show(true)
					end
				end
				ActionBars.m_Bars[i]:AnchorButtons()
				ActionBarClusterManager:ReanchorCluster()
				ActionBarClusterManager:RegisterClusterWithLayoutEditor()
				i = i + 1
				if not ActionBars.m_Bars[i] then break end
	until i > 9
end

function BarBackgrounds()
	local i = 1
	repeat
            if yakuiVar.Actionbar.Background == false then
                ActionBarClusterManager.m_Settings:SetActionBarSetting(i, "background", ActionBarConstants.HIDE_BACKGROUND)
                ActionBars.m_Bars[i].m_ShowBackground = ActionBarConstants.HIDE_BACKGROUND
                ActionBars.m_Bars[i].m_Background:Show(false)
            elseif yakuiVar.Actionbar.Background == true then
                ActionBarClusterManager.m_Settings:SetActionBarSetting(i, "background", ActionBarConstants.SHOW_BACKGROUND)
                ActionBars.m_Bars[i].m_ShowBackground = ActionBarConstants.SHOW_BACKGROUND
                ActionBars.m_Bars[i].m_Background:Show(true)
			end
			i = i + 1
			if not ActionBars.m_Bars[i] then break end
	until i > 9
end

function BarEmptySlots()
	local i = 1
	repeat
            if yakuiVar.Actionbar.Empty == false then
                ActionBarClusterManager.m_Settings:SetActionBarSetting(i, "showEmptySlots", ActionBarConstants.HIDE_EMPTY_SLOTS)
                ActionBars.m_Bars[i].m_ShowEmptySlots = ActionBarConstants.HIDE_EMPTY_SLOTS
                ActionBars.m_Bars[i]:UpdateShownSlots()
            elseif yakuiVar.Actionbar.Empty == true then
                ActionBarClusterManager.m_Settings:SetActionBarSetting(i, "showEmptySlots", ActionBarConstants.SHOW_EMPTY_SLOTS)
                ActionBars.m_Bars[i].m_ShowEmptySlots = ActionBarConstants.SHOW_EMPTY_SLOTS
                ActionBars.m_Bars[i]:UpdateShownSlots()
            end
			i = i + 1
			if not ActionBars.m_Bars[i] then break end
	until i > 9
	if yakuiVar.Actionbar.usetexture == true then TextureOverlayUpdate() end
end

function yakuiActionBars_zonechanged()
	if yakuiVar.Actionbar.usetexture == true then
		RegisterEventHandler(SystemData.Events.PLAYER_HOT_BAR_UPDATED, "TextureOverlayUpdate")
	else
		UnregisterEventHandler(SystemData.Events.PLAYER_HOT_BAR_UPDATED, "TextureOverlayUpdate")
    end
end