-- yakuiconfig.lua build20100524

yakuiconfig = {}
local configside = 1
booltowstring={[false]=L"Off",[true]=L"On"} 


function yakuiconfig.initialize()
    -- Init Contextmenu Checkboxes
	CreateWindowFromTemplate ("yconfigcontextmenutooltips", "ChatContextMenuItemCheckBox", "Root")
    LabelSetText( "yconfigcontextmenutooltipsCheckBoxLabel", L"Tooltips" )
    WindowRegisterCoreEventHandler("yconfigcontextmenutooltips", "OnLButtonUp", "yakuiconfig.actionbartoggletooltips")
    WindowRegisterCoreEventHandler("yconfigcontextmenutooltips", "OnMouseOver", "EA_Window_ContextMenu.OnMouseOverDefaultMenuItem")
    WindowSetShowing("yconfigcontextmenutooltips", false)
	CreateWindowFromTemplate ("yconfigcontextmenucdanim", "ChatContextMenuItemCheckBox", "Root")
    LabelSetText( "yconfigcontextmenucdanimCheckBoxLabel", L"CD-Animation" )
    WindowRegisterCoreEventHandler("yconfigcontextmenucdanim", "OnLButtonUp", "yakuiconfig.actionbartogglecdanim")
    WindowRegisterCoreEventHandler("yconfigcontextmenucdanim", "OnMouseOver", "EA_Window_ContextMenu.OnMouseOverDefaultMenuItem")
    WindowSetShowing("yconfigcontextmenucdanim", false)
	CreateWindowFromTemplate ("yconfigcontextmenugcdanim", "ChatContextMenuItemCheckBox", "Root")
    LabelSetText( "yconfigcontextmenugcdanimCheckBoxLabel", L"GCD-Animation" )
    WindowRegisterCoreEventHandler("yconfigcontextmenugcdanim", "OnLButtonUp", "yakuiconfig.actionbartogglegcdanim")
    WindowRegisterCoreEventHandler("yconfigcontextmenugcdanim", "OnMouseOver", "EA_Window_ContextMenu.OnMouseOverDefaultMenuItem")
    WindowSetShowing("yconfigcontextmenugcdanim", false)
	CreateWindowFromTemplate ("yconfigcontextmenukeyb", "ChatContextMenuItemCheckBox", "Root")
    LabelSetText( "yconfigcontextmenukeybCheckBoxLabel", L"Keybindings (reloads UI)" )
    WindowRegisterCoreEventHandler("yconfigcontextmenukeyb", "OnLButtonUp", "yakuiconfig.actionbartogglekeyb")
    WindowRegisterCoreEventHandler("yconfigcontextmenukeyb", "OnMouseOver", "EA_Window_ContextMenu.OnMouseOverDefaultMenuItem")
    WindowSetShowing("yconfigcontextmenukeyb", false)
	-- CreateWindowFromTemplate ("yconfigcontextmenutexture", "ChatContextMenuItemCheckBox", "Root")
    -- LabelSetText( "yconfigcontextmenutextureCheckBoxLabel", L"Use Texture (reloads UI)" )
    -- WindowRegisterCoreEventHandler("yconfigcontextmenutexture", "OnLButtonUp", "yakuiconfig.actionbartoggletexture")
    -- WindowRegisterCoreEventHandler("yconfigcontextmenutexture", "OnMouseOver", "EA_Window_ContextMenu.OnMouseOverDefaultMenuItem")
    -- WindowSetShowing("yconfigcontextmenutexture", false)
	CreateWindowFromTemplate ("yconfigcontextmenupagers", "ChatContextMenuItemCheckBox", "Root")
    LabelSetText( "yconfigcontextmenupagersCheckBoxLabel", L"Pagers (reloads UI)" )
    WindowRegisterCoreEventHandler("yconfigcontextmenupagers", "OnLButtonUp", "yakuiconfig.actionbartogglepagers")
    WindowRegisterCoreEventHandler("yconfigcontextmenupagers", "OnMouseOver", "EA_Window_ContextMenu.OnMouseOverDefaultMenuItem")
    WindowSetShowing("yconfigcontextmenupagers", false)
	CreateWindowFromTemplate ("yconfigcontextmenuempty", "ChatContextMenuItemCheckBox", "Root")
    LabelSetText( "yconfigcontextmenuemptyCheckBoxLabel", L"Show Empty Buttons" )
    WindowRegisterCoreEventHandler("yconfigcontextmenuempty", "OnLButtonUp", "yakuiconfig.actionbartoggleempty")
    WindowRegisterCoreEventHandler("yconfigcontextmenuempty", "OnMouseOver", "EA_Window_ContextMenu.OnMouseOverDefaultMenuItem")
    WindowSetShowing("yconfigcontextmenuempty", false)
	CreateWindowFromTemplate ("yconfigcontextmenubackground", "ChatContextMenuItemCheckBox", "Root")
    LabelSetText( "yconfigcontextmenubackgroundCheckBoxLabel", L"Bar Backgrounds" )
    WindowRegisterCoreEventHandler("yconfigcontextmenubackground", "OnLButtonUp", "yakuiconfig.actionbartogglebackground")
    WindowRegisterCoreEventHandler("yconfigcontextmenubackground", "OnMouseOver", "EA_Window_ContextMenu.OnMouseOverDefaultMenuItem")
    WindowSetShowing("yconfigcontextmenubackground", false)
	CreateWindowFromTemplate ("yconfigcontextmenuglow", "ChatContextMenuItemCheckBox", "Root")
    LabelSetText( "yconfigcontextmenuglowCheckBoxLabel", L"Glow Effect" )
    WindowRegisterCoreEventHandler("yconfigcontextmenuglow", "OnLButtonUp", "yakuiconfig.actionbartoggleglow")
    WindowRegisterCoreEventHandler("yconfigcontextmenuglow", "OnMouseOver", "EA_Window_ContextMenu.OnMouseOverDefaultMenuItem")
    WindowSetShowing("yconfigcontextmenuglow", false)
	-- CreateWindowFromTemplate ("yconfigcontextmenuflash", "ChatContextMenuItemCheckBox", "Root")
    -- LabelSetText( "yconfigcontextmenuflashCheckBoxLabel", L"Flash After CD" )
    -- WindowRegisterCoreEventHandler("yconfigcontextmenuflash", "OnLButtonUp", "yakuiconfig.actionbartoggleflash")
    -- WindowRegisterCoreEventHandler("yconfigcontextmenuflash", "OnMouseOver", "EA_Window_ContextMenu.OnMouseOverDefaultMenuItem")
    -- WindowSetShowing("yconfigcontextmenuflash", false)

	-- Init Color Selection
	CreateWindowFromTemplate ("yconfigcontextmenucolorselect1", "ChatContextMenuItemFontSelection", "Root")
    LabelSetText( "yconfigcontextmenucolorselect1Label", L"Transparenz (light)" )
    WindowRegisterCoreEventHandler("yconfigcontextmenucolorselect1", "OnLButtonUp", "yakuiconfig.colorselect1")
    WindowSetShowing("yconfigcontextmenucolorselect1", false)
	CreateWindowFromTemplate ("yconfigcontextmenucolorselect2", "ChatContextMenuItemFontSelection", "Root")
    LabelSetText( "yconfigcontextmenucolorselect2Label", L"Transparenz (dark)" )
    WindowRegisterCoreEventHandler("yconfigcontextmenucolorselect2", "OnLButtonUp", "yakuiconfig.colorselect2")
    WindowSetShowing("yconfigcontextmenucolorselect2", false)
	CreateWindowFromTemplate ("yconfigcontextmenucolorselect3", "ChatContextMenuItemFontSelection", "Root")
    LabelSetText( "yconfigcontextmenucolorselect3Label", L"Vintage" )
    WindowRegisterCoreEventHandler("yconfigcontextmenucolorselect3", "OnLButtonUp", "yakuiconfig.colorselect3")
    WindowSetShowing("yconfigcontextmenucolorselect3", false)
	CreateWindowFromTemplate ("yconfigcontextmenucolorselect4", "ChatContextMenuItemFontSelection", "Root")
    LabelSetText( "yconfigcontextmenucolorselect4Label", L"Eeeeks!" )
    WindowRegisterCoreEventHandler("yconfigcontextmenucolorselect4", "OnLButtonUp", "yakuiconfig.colorselect4")
    WindowSetShowing("yconfigcontextmenucolorselect4", false)
	CreateWindowFromTemplate ("yconfigcontextmenucolorselect5", "ChatContextMenuItemFontSelection", "Root")
    LabelSetText( "yconfigcontextmenucolorselect5Label", L"Mariner" )
    WindowRegisterCoreEventHandler("yconfigcontextmenucolorselect5", "OnLButtonUp", "yakuiconfig.colorselect5")
    WindowSetShowing("yconfigcontextmenucolorselect5", false)
	CreateWindowFromTemplate ("yconfigcontextmenucolorselect6", "ChatContextMenuItemFontSelection", "Root")
    LabelSetText( "yconfigcontextmenucolorselect6Label", L"Dem Bones" )
    WindowRegisterCoreEventHandler("yconfigcontextmenucolorselect6", "OnLButtonUp", "yakuiconfig.colorselect6")
    WindowSetShowing("yconfigcontextmenucolorselect6", false)

	-- Init Unitframe Options
	CreateWindowFromTemplate ("yconfigcontextmenugroupicons", "ChatContextMenuItemCheckBox", "Root")
    LabelSetText( "yconfigcontextmenugroupiconsCheckBoxLabel", L"Grp Icons" )
    WindowRegisterCoreEventHandler("yconfigcontextmenugroupicons", "OnLButtonUp", "yakuiconfig.actionbartogglegroupicons")
    WindowRegisterCoreEventHandler("yconfigcontextmenugroupicons", "OnMouseOver", "EA_Window_ContextMenu.OnMouseOverDefaultMenuItem")
    WindowSetShowing("yconfigcontextmenugroupicons", false)
	CreateWindowFromTemplate ("yconfigcontextmenugroupframes", "ChatContextMenuItemCheckBox", "Root")
    LabelSetText( "yconfigcontextmenugroupframesCheckBoxLabel", L"Group Frames" )
    WindowRegisterCoreEventHandler("yconfigcontextmenugroupframes", "OnLButtonUp", "yakuiconfig.actionbartogglegroupframes")
    WindowRegisterCoreEventHandler("yconfigcontextmenugroupframes", "OnMouseOver", "EA_Window_ContextMenu.OnMouseOverDefaultMenuItem")
    WindowSetShowing("yconfigcontextmenugroupframes", false)
	CreateWindowFromTemplate ("yconfigcontextmenuinfopanel", "ChatContextMenuItemCheckBox", "Root")
    LabelSetText( "yconfigcontextmenuinfopanelCheckBoxLabel", L"InfoPanel" )
    WindowRegisterCoreEventHandler("yconfigcontextmenuinfopanel", "OnLButtonUp", "yakuiconfig.infopaneltoggle")
    WindowRegisterCoreEventHandler("yconfigcontextmenuinfopanel", "OnMouseOver", "EA_Window_ContextMenu.OnMouseOverDefaultMenuItem")
    WindowSetShowing("yconfigcontextmenuinfopanel", false)
	CreateWindowFromTemplate ("yconfigcontextmenufriendlyrange", "ChatContextMenuItemCheckBox", "Root")
    LabelSetText( "yconfigcontextmenufriendlyrangeCheckBoxLabel", L"FT Range" )
    WindowRegisterCoreEventHandler("yconfigcontextmenufriendlyrange", "OnLButtonUp", "yakuiconfig.friendlyrangetoggle")
    WindowRegisterCoreEventHandler("yconfigcontextmenufriendlyrange", "OnMouseOver", "EA_Window_ContextMenu.OnMouseOverDefaultMenuItem")
    WindowSetShowing("yconfigcontextmenufriendlyrange", false)
	CreateWindowFromTemplate ("yconfigcontextmenuhostilerange", "ChatContextMenuItemCheckBox", "Root")
    LabelSetText( "yconfigcontextmenuhostilerangeCheckBoxLabel", L"HT Range" )
    WindowRegisterCoreEventHandler("yconfigcontextmenuhostilerange", "OnLButtonUp", "yakuiconfig.hostilerangetoggle")
    WindowRegisterCoreEventHandler("yconfigcontextmenuhostilerange", "OnMouseOver", "EA_Window_ContextMenu.OnMouseOverDefaultMenuItem")
    WindowSetShowing("yconfigcontextmenuhostilerange", false)
	CreateWindowFromTemplate ("yconfigcontextmenucastbargcd", "ChatContextMenuItemCheckBox", "Root")
    LabelSetText( "yconfigcontextmenucastbargcdCheckBoxLabel", L"Castbar GCD" )
    WindowRegisterCoreEventHandler("yconfigcontextmenucastbargcd", "OnLButtonUp", "yakuiconfig.castbargcdtoggle")
    WindowRegisterCoreEventHandler("yconfigcontextmenucastbargcd", "OnMouseOver", "EA_Window_ContextMenu.OnMouseOverDefaultMenuItem")
    WindowSetShowing("yconfigcontextmenucastbargcd", false)
	CreateWindowFromTemplate ("yconfigcontextmenuignoreeffigy", "ChatContextMenuItemCheckBox", "Root")
    LabelSetText( "yconfigcontextmenuignoreeffigyCheckBoxLabel", L"Ignore Effigy" )
	LabelSetTextColor( "yconfigcontextmenuignoreeffigyCheckBoxLabel", 255,0,0)
    WindowRegisterCoreEventHandler("yconfigcontextmenuignoreeffigy", "OnLButtonUp", "yakuiconfig.ignoreeffigytoggle")
    WindowRegisterCoreEventHandler("yconfigcontextmenuignoreeffigy", "OnMouseOver", "EA_Window_ContextMenu.OnMouseOverDefaultMenuItem")
    WindowSetShowing("yconfigcontextmenuignoreeffigy", false)

	-- Misc Options
	CreateWindowFromTemplate ("yconfigcontextmenulimitalert", "ChatContextMenuItemCheckBox", "Root")
    LabelSetText( "yconfigcontextmenulimitalertCheckBoxLabel", L"Limit On Screen Alerts" )
    WindowRegisterCoreEventHandler("yconfigcontextmenulimitalert", "OnLButtonUp", "yakuiconfig.actionbartogglelimitalert")
    WindowRegisterCoreEventHandler("yconfigcontextmenulimitalert", "OnMouseOver", "EA_Window_ContextMenu.OnMouseOverDefaultMenuItem")
    WindowSetShowing("yconfigcontextmenulimitalert", false)
	CreateWindowFromTemplate ("yconfigcontextmenufps", "ChatContextMenuItemCheckBox", "Root")
    LabelSetText( "yconfigcontextmenufpsCheckBoxLabel", L"Show FPS" )
    WindowRegisterCoreEventHandler("yconfigcontextmenufps", "OnLButtonUp", "yakuiconfig.actionbartogglefps")
    WindowRegisterCoreEventHandler("yconfigcontextmenufps", "OnMouseOver", "EA_Window_ContextMenu.OnMouseOverDefaultMenuItem")
    WindowSetShowing("yconfigcontextmenufps", false)
	CreateWindowFromTemplate ("yconfigcontextmenuloc", "ChatContextMenuItemCheckBox", "Root")
    LabelSetText( "yconfigcontextmenulocCheckBoxLabel", L"Show Coordinates" )
    WindowRegisterCoreEventHandler("yconfigcontextmenuloc", "OnLButtonUp", "yakuiconfig.actionbartoggleloc")
    WindowRegisterCoreEventHandler("yconfigcontextmenuloc", "OnMouseOver", "EA_Window_ContextMenu.OnMouseOverDefaultMenuItem")
    WindowSetShowing("yconfigcontextmenuloc", false)
	CreateWindowFromTemplate ("yconfigcontextmenubag", "ChatContextMenuItemCheckBox", "Root")
    LabelSetText( "yconfigcontextmenubagCheckBoxLabel", L"Show Bag-Info" )
    WindowRegisterCoreEventHandler("yconfigcontextmenubag", "OnLButtonUp", "yakuiconfig.actionbartogglebag")
    WindowRegisterCoreEventHandler("yconfigcontextmenubag", "OnMouseOver", "EA_Window_ContextMenu.OnMouseOverDefaultMenuItem")
    WindowSetShowing("yconfigcontextmenubag", false)
	CreateWindowFromTemplate ("yconfigcontextmenuminmaphook", "ChatContextMenuItemCheckBox", "Root")
    LabelSetText( "yconfigcontextmenuminmaphookCheckBoxLabel", L"Minmap-Leftclick" )
    WindowRegisterCoreEventHandler("yconfigcontextmenuminmaphook", "OnLButtonUp", "yakuiconfig.minmaphook")
    WindowRegisterCoreEventHandler("yconfigcontextmenuminmaphook", "OnMouseOver", "EA_Window_ContextMenu.OnMouseOverDefaultMenuItem")
    WindowSetShowing("yconfigcontextmenuminmaphook", false)	
	CreateWindowFromTemplate ("yconfigcontextmenumoraleCDsize", "ChatContextMenuItemCheckBox", "Root")
    LabelSetText( "yconfigcontextmenumoraleCDsizeCheckBoxLabel", L"Larger Morale-CD" )
    WindowRegisterCoreEventHandler("yconfigcontextmenumoraleCDsize", "OnLButtonUp", "yakuiconfig.moralecd")
    WindowRegisterCoreEventHandler("yconfigcontextmenumoraleCDsize", "OnMouseOver", "EA_Window_ContextMenu.OnMouseOverDefaultMenuItem")
    WindowSetShowing("yconfigcontextmenumoraleCDsize", false)
	CreateWindowFromTemplate ("yconfigcontextmenusmoothout", "ChatContextMenuItemCheckBox", "Root")
    LabelSetText( "yconfigcontextmenusmoothoutCheckBoxLabel", L"Smooth Out" )
    WindowRegisterCoreEventHandler("yconfigcontextmenusmoothout", "OnLButtonUp", "yakuiconfig.togglesmoothout")
    WindowRegisterCoreEventHandler("yconfigcontextmenusmoothout", "OnMouseOver", "EA_Window_ContextMenu.OnMouseOverDefaultMenuItem")
    WindowSetShowing("yconfigcontextmenusmoothout", false)

	-- Custom Color Sliders
	CreateWindow("yCustomcolorsliders",false)
	WindowSetShowing("yCustomcolorsliders",false)
	WindowSetHandleInput("yCustomcolorsliders",true)
	LabelSetText("yCustomcolorsliders_Headline1", L"Panel:")
	LabelSetText("yCustomcolorsliders_Headline2", L"Background:")
	LabelSetText("yCustomcolorsliders_Headline3", L"FX:")
	LabelSetText("yCustomcolorslidersTitleBarText", L"Appearance:")
	LabelSetText("yCustomcolorsliders_Red", L"Red: "..yakuiVar.Colors.colprintr)
	LabelSetText("yCustomcolorsliders_Green", L"Green: "..yakuiVar.Colors.colprintg)
	LabelSetText("yCustomcolorsliders_Blue", L"Blue: "..yakuiVar.Colors.colprintb)
	LabelSetText("yCustomcolorsliders_Alpha", L"Alpha: "..yakuiVar.Panel.Panelalpha)
	SliderBarSetCurrentPosition( "yCustomcolorsliders_SliderR" , yakuiVar.Colors.colprintr/256)
	SliderBarSetCurrentPosition( "yCustomcolorsliders_SliderG" , yakuiVar.Colors.colprintg/256)
	SliderBarSetCurrentPosition( "yCustomcolorsliders_SliderB" , yakuiVar.Colors.colprintb/256)
	SliderBarSetCurrentPosition( "yCustomcolorsliders_SliderA" , yakuiVar.Panel.Panelalpha)
	LabelSetText("yCustomcolorsliders_BGRed", L"Red: "..yakuiVar.Colors.background.r)
	LabelSetText("yCustomcolorsliders_BGGreen", L"Green: "..yakuiVar.Colors.background.g)
	LabelSetText("yCustomcolorsliders_BGBlue", L"Blue: "..yakuiVar.Colors.background.b)
	LabelSetText("yCustomcolorsliders_BGAlpha", L"Alpha: "..yakuiVar.Panel.alpha)
	SliderBarSetCurrentPosition( "yCustomcolorsliders_BGSliderR" , yakuiVar.Colors.background.r/256)
	SliderBarSetCurrentPosition( "yCustomcolorsliders_BGSliderG" , yakuiVar.Colors.background.g/256)
	SliderBarSetCurrentPosition( "yCustomcolorsliders_BGSliderB" , yakuiVar.Colors.background.b/256)
	SliderBarSetCurrentPosition( "yCustomcolorsliders_BGSliderA" , yakuiVar.Panel.alpha)
	LabelSetText("yCustomcolorsliders_FXRed", L"Red: "..yakuiVar.Colors.fx.r)
	LabelSetText("yCustomcolorsliders_FXGreen", L"Green: "..yakuiVar.Colors.fx.g)
	LabelSetText("yCustomcolorsliders_FXBlue", L"Blue: "..yakuiVar.Colors.fx.b)
	LabelSetText("yCustomcolorsliders_FXAlpha", L"Alpha: "..yakuiVar.Panel.fxalpha)
	SliderBarSetCurrentPosition( "yCustomcolorsliders_FXSliderR" , yakuiVar.Colors.fx.r/256)
	SliderBarSetCurrentPosition( "yCustomcolorsliders_FXSliderG" , yakuiVar.Colors.fx.g/256)
	SliderBarSetCurrentPosition( "yCustomcolorsliders_FXSliderB" , yakuiVar.Colors.fx.b/256)
	SliderBarSetCurrentPosition( "yCustomcolorsliders_FXSliderA" , yakuiVar.Panel.fxalpha)
	LabelSetText("yCustomcolorsliders_AlphaToggleLabel", L"Enable Alpha")
	ButtonSetPressedFlag("yCustomcolorsliders_AlphaToggle", yakuiVar.Panel.alphatoggle)
	SliderBarSetDisabledFlag("yCustomcolorsliders_BGSliderA", not yakuiVar.Panel.alphatoggle )
	if yakuiVar.Panel.alphatoggle == false then 
		WindowSetTintColor("yCustomcolorsliders_BGSliderA", 120, 120, 120 )
		--LabelSetTextColor("yCustomcolorsliders_BGAlpha", 120, 120, 120 )
	else
		WindowSetTintColor("yCustomcolorsliders_BGSliderA", 255, 255, 255 )
		--LabelSetTextColor("yCustomcolorsliders_BGAlpha", 255, 255, 255 )
	end
	ComboBoxAddMenuItem ("yCustomcolorsliders_TextureCombo", L"Classic")
	ComboBoxAddMenuItem ("yCustomcolorsliders_TextureCombo", L"Snake Shake")
	ComboBoxAddMenuItem ("yCustomcolorsliders_TextureCombo", L"YakUI 1.3")
	ComboBoxAddMenuItem ("yCustomcolorsliders_TextureCombo", L"Skull&Bones")
	ComboBoxAddMenuItem ("yCustomcolorsliders_TextureCombo", L"Tranzparenz")
	if yakuiVar.Panel.tex == "Set1" then ComboBoxSetSelectedMenuItem ("yCustomcolorsliders_TextureCombo", 1)
	elseif yakuiVar.Panel.tex == "Set2" then ComboBoxSetSelectedMenuItem ("yCustomcolorsliders_TextureCombo", 2)
	elseif yakuiVar.Panel.tex == "Set3" then ComboBoxSetSelectedMenuItem ("yCustomcolorsliders_TextureCombo", 3)
	elseif yakuiVar.Panel.tex == "Set4" then ComboBoxSetSelectedMenuItem ("yCustomcolorsliders_TextureCombo", 4)
	elseif yakuiVar.Panel.tex == "Set5" then ComboBoxSetSelectedMenuItem ("yCustomcolorsliders_TextureCombo", 5)
	end
	ComboBoxAddMenuItem ("yCustomcolorsliders_Side", L"Panel Color Settings")
	if yakuiVar.Warnings.Huduf == 1 then
		ComboBoxAddMenuItem ("yCustomcolorsliders_Side", L"Unitframe Settings 1")
		ComboBoxAddMenuItem ("yCustomcolorsliders_Side", L"Unitframe Settings 2")
	end
	ComboBoxSetSelectedMenuItem ("yCustomcolorsliders_Side", configside)
	ComboBoxAddMenuItem ("yCustomcolorsliders_Preset", L"Transparenz (light)")
	ComboBoxAddMenuItem ("yCustomcolorsliders_Preset", L"Transparenz (dark)")
	ComboBoxAddMenuItem ("yCustomcolorsliders_Preset", L"Vintage")
	ComboBoxAddMenuItem ("yCustomcolorsliders_Preset", L"Eeeeks!")
	ComboBoxAddMenuItem ("yCustomcolorsliders_Preset", L"Mariner")
	ComboBoxAddMenuItem ("yCustomcolorsliders_Preset", L"Dem Bones")
	ComboBoxAddMenuItem ("yCustomcolorsliders_Preset", L"Custom")
	if yakuiVar.Colors.col == "Preset1" then ComboBoxSetSelectedMenuItem ("yCustomcolorsliders_Preset", 1)
	elseif yakuiVar.Colors.col == "Preset2" then ComboBoxSetSelectedMenuItem ("yCustomcolorsliders_Preset", 2)
	elseif yakuiVar.Colors.col == "Preset3" then ComboBoxSetSelectedMenuItem ("yCustomcolorsliders_Preset", 3)
	elseif yakuiVar.Colors.col == "Preset4" then ComboBoxSetSelectedMenuItem ("yCustomcolorsliders_Preset", 4)
	elseif yakuiVar.Colors.col == "Preset5" then ComboBoxSetSelectedMenuItem ("yCustomcolorsliders_Preset", 5)
	elseif yakuiVar.Colors.col == "Preset6" then ComboBoxSetSelectedMenuItem ("yCustomcolorsliders_Preset", 6)
	else ComboBoxSetSelectedMenuItem ("yCustomcolorsliders_Preset", 7) end
	
	-- init actionbar texture selection
	CreateWindowFromTemplate ("yconfigcontextmenuactionbartextureselect1", "ChatContextMenuItemFontSelection", "Root")
    LabelSetText( "yconfigcontextmenuactionbartextureselect1Label", L"Plain" )
    WindowRegisterCoreEventHandler("yconfigcontextmenuactionbartextureselect1", "OnLButtonUp", "yakuiconfig.actionbartextureselect1")
    WindowSetShowing("yconfigcontextmenuactionbartextureselect1", false)
	CreateWindowFromTemplate ("yconfigcontextmenuactionbartextureselect2", "ChatContextMenuItemFontSelection", "Root")
    LabelSetText( "yconfigcontextmenuactionbartextureselect2Label", L"Gloss" )
    WindowRegisterCoreEventHandler("yconfigcontextmenuactionbartextureselect2", "OnLButtonUp", "yakuiconfig.actionbartextureselect2")
    WindowSetShowing("yconfigcontextmenuactionbartextureselect2", false)
	CreateWindowFromTemplate ("yconfigcontextmenuactionbartextureselect3", "ChatContextMenuItemFontSelection", "Root")
    LabelSetText( "yconfigcontextmenuactionbartextureselect3Label", L"Analog" )
    WindowRegisterCoreEventHandler("yconfigcontextmenuactionbartextureselect3", "OnLButtonUp", "yakuiconfig.actionbartextureselect3")
    WindowSetShowing("yconfigcontextmenuactionbartextureselect3", false)
	CreateWindowFromTemplate ("yconfigcontextmenuactionbartextureselect4", "ChatContextMenuItemFontSelection", "Root")
    LabelSetText( "yconfigcontextmenuactionbartextureselect4Label", L"no texture" )
    WindowRegisterCoreEventHandler("yconfigcontextmenuactionbartextureselect4", "OnLButtonUp", "yakuiconfig.actionbartextureselect4")
    WindowSetShowing("yconfigcontextmenuactionbartextureselect4", false)
	
	-- Skin Settings
	CreateWindow("ySkinBackgroundColor",false)
	WindowSetShowing("ySkinBackgroundColor",false)
	WindowSetHandleInput("ySkinBackgroundColor",true)
	ButtonSetPressedFlag("ySkinBackgroundColor_LinkwpanelCheckbox", yakuiVar.Skin.newbackgrounds.linkwpanel)
	ButtonSetPressedFlag("ySkinBackgroundColor_ActivateSkin", yakuiVar.Skin.active)
	if yakuiVar.Skin.newbackgrounds.linkwpanel == true then
		WindowSetTintColor("ySkinBackgroundColor_SliderR", 120, 120, 120 )
		WindowSetTintColor("ySkinBackgroundColor_SliderG", 120, 120, 120 )
		WindowSetTintColor("ySkinBackgroundColor_SliderB", 120, 120, 120 )
		WindowSetTintColor("ySkinBackgroundColor_SliderA", 120, 120, 120 )
		LabelSetTextColor("ySkinBackgroundColor_Red", 160, 160, 160)
		LabelSetTextColor("ySkinBackgroundColor_Green", 160, 160, 160)
		LabelSetTextColor("ySkinBackgroundColor_Blue", 160, 160, 160)
		LabelSetTextColor("ySkinBackgroundColor_Alpha", 160, 160, 160)
	else
		WindowSetTintColor("ySkinBackgroundColor_SliderR", 255, 255, 255 )
		WindowSetTintColor("ySkinBackgroundColor_SliderG", 255, 255, 255 )
		WindowSetTintColor("ySkinBackgroundColor_SliderB", 255, 255, 255 )
		WindowSetTintColor("ySkinBackgroundColor_SliderA", 255, 255, 255 )
		LabelSetTextColor("ySkinBackgroundColor_Red", 255, 255, 255)
		LabelSetTextColor("ySkinBackgroundColor_Green", 255, 255, 255)
		LabelSetTextColor("ySkinBackgroundColor_Blue", 255, 255, 255)
		LabelSetTextColor("ySkinBackgroundColor_Alpha", 255, 255, 255)
	end
	LabelSetText("ySkinBackgroundColor_Headline1", L"Link BG with panel")
	LabelSetText("ySkinBackgroundColor_Headline2", L"Activate Skin Mod")
	LabelSetText("ySkinBackgroundColorTitleBarText", L"ySkin:")
	LabelSetText("ySkinBackgroundColor_Red", L"Red: "..yakuiVar.Skin.newbackgrounds.r)
	LabelSetText("ySkinBackgroundColor_Green", L"Green: "..yakuiVar.Skin.newbackgrounds.g)
	LabelSetText("ySkinBackgroundColor_Blue", L"Blue: "..yakuiVar.Skin.newbackgrounds.b)
	LabelSetText("ySkinBackgroundColor_Alpha", L"Alpha: "..yakuiVar.Skin.newbackgrounds.alpha)
	SliderBarSetCurrentPosition( "ySkinBackgroundColor_SliderR" , yakuiVar.Skin.newbackgrounds.r/256)
	SliderBarSetCurrentPosition( "ySkinBackgroundColor_SliderG" , yakuiVar.Skin.newbackgrounds.g/256)
	SliderBarSetCurrentPosition( "ySkinBackgroundColor_SliderB" , yakuiVar.Skin.newbackgrounds.b/256)
	SliderBarSetCurrentPosition( "ySkinBackgroundColor_SliderA" , yakuiVar.Skin.newbackgrounds.alpha)
	SliderBarSetDisabledFlag("ySkinBackgroundColor_SliderR", yakuiVar.Skin.newbackgrounds.linkwpanel )
	SliderBarSetDisabledFlag("ySkinBackgroundColor_SliderG", yakuiVar.Skin.newbackgrounds.linkwpanel )
	SliderBarSetDisabledFlag("ySkinBackgroundColor_SliderB", yakuiVar.Skin.newbackgrounds.linkwpanel )
	SliderBarSetDisabledFlag("ySkinBackgroundColor_SliderA", yakuiVar.Skin.newbackgrounds.linkwpanel )
end

-- building context menu

function yakuiconfig.toggle()
	EA_Window_ContextMenu.CreateContextMenu( "YakuiButton" )
	EA_Window_ContextMenu.AddCascadingMenuItem(L"ActionBars Settings", yakuiconfig.showactionbaroptions, false, EA_Window_ContextMenu.CONTEXT_MENU_1)
	EA_Window_ContextMenu.AddCascadingMenuItem(L"Appearance Settings", yakuiconfig.showcoloroptions, false, EA_Window_ContextMenu.CONTEXT_MENU_1)
	if yakuiVar.Warnings.Huduf == 1 then
		EA_Window_ContextMenu.AddCascadingMenuItem(L"Unitframe Settings", yakuiconfig.showunitframeoptions, false, EA_Window_ContextMenu.CONTEXT_MENU_1)
	end
	EA_Window_ContextMenu.AddCascadingMenuItem(L"Misc. Settings", yakuiconfig.showmiscellaneousoptions, false, EA_Window_ContextMenu.CONTEXT_MENU_1)
	EA_Window_ContextMenu.AddCascadingMenuItem(L"Core Addons", yakuiconfig.showunitframesextoptions, false, EA_Window_ContextMenu.CONTEXT_MENU_1)
	if yakuifirststeps then
		EA_Window_ContextMenu.AddMenuItem( L"YakUI First Steps" , yakuifirststeps.show , false, true, EA_Window_ContextMenu.CONTEXT_MENU_1 )
	end
	EA_Window_ContextMenu.AddMenuItem( L"Reload Interface" , yakuiconfig.reloadui, false, true, EA_Window_ContextMenu.CONTEXT_MENU_1 )
	EA_Window_ContextMenu.Finalize(EA_Window_ContextMenu.CONTEXT_MENU_1)

end

function yakuiconfig.showactionbaroptions()
	EA_Window_ContextMenu.Hide(EA_Window_ContextMenu.CONTEXT_MENU_3)
	EA_Window_ContextMenu.CreateContextMenu("", EA_Window_ContextMenu.CONTEXT_MENU_2)
	--button Texture
	EA_Window_ContextMenu.AddCascadingMenuItem(L"Actionbutton Texture", yakuiconfig.showactionbartextureoptions, false, EA_Window_ContextMenu.CONTEXT_MENU_2)
	--Tooltips
	ButtonSetPressedFlag("yconfigcontextmenutooltipsCheckBox", yakuiVar.Actionbar.Tooltips)
	EA_Window_ContextMenu.AddUserDefinedMenuItem("yconfigcontextmenutooltips", EA_Window_ContextMenu.CONTEXT_MENU_2)
	--CD Animation
	ButtonSetPressedFlag("yconfigcontextmenucdanimCheckBox", yakuiVar.Actionbar.CDAnimation)
	EA_Window_ContextMenu.AddUserDefinedMenuItem("yconfigcontextmenucdanim", EA_Window_ContextMenu.CONTEXT_MENU_2)
	--GCD Animation
	ButtonSetPressedFlag("yconfigcontextmenugcdanimCheckBox", yakuiVar.Actionbar.GCDAnimation)
	EA_Window_ContextMenu.AddUserDefinedMenuItem("yconfigcontextmenugcdanim", EA_Window_ContextMenu.CONTEXT_MENU_2)
	--Glow
	ButtonSetPressedFlag("yconfigcontextmenuglowCheckBox", yakuiVar.Actionbar.Glow)
	EA_Window_ContextMenu.AddUserDefinedMenuItem("yconfigcontextmenuglow", EA_Window_ContextMenu.CONTEXT_MENU_2)
	--Flash
	-- ButtonSetPressedFlag("yconfigcontextmenuflashCheckBox", yakuiVar.Actionbar.Flash)
	-- EA_Window_ContextMenu.AddUserDefinedMenuItem("yconfigcontextmenuflash", EA_Window_ContextMenu.CONTEXT_MENU_2)
	--Empty buttons
	ButtonSetPressedFlag("yconfigcontextmenuemptyCheckBox", yakuiVar.Actionbar.Empty)
	EA_Window_ContextMenu.AddUserDefinedMenuItem("yconfigcontextmenuempty", EA_Window_ContextMenu.CONTEXT_MENU_2)
	--Button Background
	ButtonSetPressedFlag("yconfigcontextmenubackgroundCheckBox", yakuiVar.Actionbar.Empty)
	EA_Window_ContextMenu.AddUserDefinedMenuItem("yconfigcontextmenubackground", EA_Window_ContextMenu.CONTEXT_MENU_2)
	--Keybindings
	ButtonSetPressedFlag("yconfigcontextmenukeybCheckBox", yakuiVar.Actionbar.Keybindings)
	EA_Window_ContextMenu.AddUserDefinedMenuItem("yconfigcontextmenukeyb", EA_Window_ContextMenu.CONTEXT_MENU_2)
	--Pagers
	ButtonSetPressedFlag("yconfigcontextmenupagersCheckBox", yakuiVar.Actionbar.Pagers)
	EA_Window_ContextMenu.AddUserDefinedMenuItem("yconfigcontextmenupagers", EA_Window_ContextMenu.CONTEXT_MENU_2)
	
	EA_Window_ContextMenu.Finalize(EA_Window_ContextMenu.CONTEXT_MENU_2)
end

function yakuiconfig.showactionbartextureoptions()
	EA_Window_ContextMenu.CreateContextMenu("", EA_Window_ContextMenu.CONTEXT_MENU_3)
	EA_Window_ContextMenu.AddUserDefinedMenuItem("yconfigcontextmenuactionbartextureselect1", EA_Window_ContextMenu.CONTEXT_MENU_3)
		if (yakuiVar.Actionbar.texture == 1) and (yakuiVar.Actionbar.usetexture == true) then WindowSetShowing("yconfigcontextmenuactionbartextureselect1Check", true)
		else WindowSetShowing("yconfigcontextmenuactionbartextureselect1Check", false) end
	EA_Window_ContextMenu.AddUserDefinedMenuItem("yconfigcontextmenuactionbartextureselect2", EA_Window_ContextMenu.CONTEXT_MENU_3)
		if (yakuiVar.Actionbar.texture == 2) and (yakuiVar.Actionbar.usetexture == true) then WindowSetShowing("yconfigcontextmenuactionbartextureselect2Check", true)
		else WindowSetShowing("yconfigcontextmenuactionbartextureselect2Check", false) end
	EA_Window_ContextMenu.AddUserDefinedMenuItem("yconfigcontextmenuactionbartextureselect3", EA_Window_ContextMenu.CONTEXT_MENU_3)
		if (yakuiVar.Actionbar.texture == 3) and (yakuiVar.Actionbar.usetexture == true) then WindowSetShowing("yconfigcontextmenuactionbartextureselect3Check", true)
		else WindowSetShowing("yconfigcontextmenuactionbartextureselect3Check", false) end
	EA_Window_ContextMenu.AddUserDefinedMenuItem("yconfigcontextmenuactionbartextureselect4", EA_Window_ContextMenu.CONTEXT_MENU_3)
		if yakuiVar.Actionbar.usetexture == false then WindowSetShowing("yconfigcontextmenuactionbartextureselect4Check", true)
		else WindowSetShowing("yconfigcontextmenuactionbartextureselect4Check", false) end
	EA_Window_ContextMenu.Finalize(EA_Window_ContextMenu.CONTEXT_MENU_3)
	
end

function yakuiconfig.showcoloroptions()
	EA_Window_ContextMenu.Hide(EA_Window_ContextMenu.CONTEXT_MENU_3)
	EA_Window_ContextMenu.CreateContextMenu("", EA_Window_ContextMenu.CONTEXT_MENU_2)
	EA_Window_ContextMenu.AddMenuItem( L"Edit Skin Settings" , yakuiconfig.editwindowbackgrounds, false, true, EA_Window_ContextMenu.CONTEXT_MENU_2 )
	EA_Window_ContextMenu.AddMenuItem( L"Edit Custom Settings" , yakuiconfig.editcustomcolor, false, true, EA_Window_ContextMenu.CONTEXT_MENU_2 )

	EA_Window_ContextMenu.AddUserDefinedMenuItem("yconfigcontextmenucolorselect1", EA_Window_ContextMenu.CONTEXT_MENU_2)
		if yakuiVar.Colors.col == "Preset1" then WindowSetShowing("yconfigcontextmenucolorselect1Check", true)
		else WindowSetShowing("yconfigcontextmenucolorselect1Check", false) end
	EA_Window_ContextMenu.AddUserDefinedMenuItem("yconfigcontextmenucolorselect2", EA_Window_ContextMenu.CONTEXT_MENU_2)
		if yakuiVar.Colors.col == "Preset2" then WindowSetShowing("yconfigcontextmenucolorselect2Check", true)
		else WindowSetShowing("yconfigcontextmenucolorselect2Check", false) end
	EA_Window_ContextMenu.AddUserDefinedMenuItem("yconfigcontextmenucolorselect3", EA_Window_ContextMenu.CONTEXT_MENU_2)
		if yakuiVar.Colors.col == "Preset3" then WindowSetShowing("yconfigcontextmenucolorselect3Check", true)
		else WindowSetShowing("yconfigcontextmenucolorselect3Check", false) end
	EA_Window_ContextMenu.AddUserDefinedMenuItem("yconfigcontextmenucolorselect4", EA_Window_ContextMenu.CONTEXT_MENU_2)
		if yakuiVar.Colors.col == "Preset4" then WindowSetShowing("yconfigcontextmenucolorselect4Check", true)
		else WindowSetShowing("yconfigcontextmenucolorselect4Check", false) end
	EA_Window_ContextMenu.AddUserDefinedMenuItem("yconfigcontextmenucolorselect5", EA_Window_ContextMenu.CONTEXT_MENU_2)
		if yakuiVar.Colors.col == "Preset5" then WindowSetShowing("yconfigcontextmenucolorselect5Check", true)
		else WindowSetShowing("yconfigcontextmenucolorselect5Check", false) end
	EA_Window_ContextMenu.AddUserDefinedMenuItem("yconfigcontextmenucolorselect6", EA_Window_ContextMenu.CONTEXT_MENU_2)
		if yakuiVar.Colors.col == "Preset6" then WindowSetShowing("yconfigcontextmenucolorselect6Check", true)
		else WindowSetShowing("yconfigcontextmenucolorselect6Check", false) end
	EA_Window_ContextMenu.Finalize(EA_Window_ContextMenu.CONTEXT_MENU_2)
end

function yakuiconfig.showmiscellaneousoptions()
	EA_Window_ContextMenu.Hide(EA_Window_ContextMenu.CONTEXT_MENU_3)
	EA_Window_ContextMenu.CreateContextMenu("", EA_Window_ContextMenu.CONTEXT_MENU_2)
	ButtonSetPressedFlag("yconfigcontextmenulimitalertCheckBox", yakuiVar.limitalert)
	EA_Window_ContextMenu.AddUserDefinedMenuItem("yconfigcontextmenulimitalert", EA_Window_ContextMenu.CONTEXT_MENU_2)
	if alertMod then
		EA_Window_ContextMenu.AddMenuItem( L"ext. AlertMod" , yakuiconfig.alertmod, false, true, EA_Window_ContextMenu.CONTEXT_MENU_2 )
	end
	ButtonSetPressedFlag("yconfigcontextmenufpsCheckBox", yakuiVar.fps)
	EA_Window_ContextMenu.AddUserDefinedMenuItem("yconfigcontextmenufps", EA_Window_ContextMenu.CONTEXT_MENU_2)
	ButtonSetPressedFlag("yconfigcontextmenulocCheckBox", yakuiVar.loc)
	EA_Window_ContextMenu.AddUserDefinedMenuItem("yconfigcontextmenuloc", EA_Window_ContextMenu.CONTEXT_MENU_2)
	ButtonSetPressedFlag("yconfigcontextmenuminmaphookCheckBox", yakuiVar.minmaphook)
	ButtonSetPressedFlag("yconfigcontextmenubagCheckBox", yakuiVar.bag)
	EA_Window_ContextMenu.AddUserDefinedMenuItem("yconfigcontextmenubag", EA_Window_ContextMenu.CONTEXT_MENU_2)
	EA_Window_ContextMenu.AddUserDefinedMenuItem("yconfigcontextmenuminmaphook", EA_Window_ContextMenu.CONTEXT_MENU_2)
	ButtonSetPressedFlag("yconfigcontextmenumoraleCDsizeCheckBox", yakuiVar.moraleCDsize)
	EA_Window_ContextMenu.AddUserDefinedMenuItem("yconfigcontextmenumoraleCDsize", EA_Window_ContextMenu.CONTEXT_MENU_2)
	ButtonSetPressedFlag("yconfigcontextmenusmoothoutCheckBox", yakuiVar.smoothout)
	EA_Window_ContextMenu.AddUserDefinedMenuItem("yconfigcontextmenusmoothout", EA_Window_ContextMenu.CONTEXT_MENU_2)
	--EA_Window_ContextMenu.AddMenuItem( L"Edit MoraleCD Size" , yakuiconfig.moralecd, false, true, EA_Window_ContextMenu.CONTEXT_MENU_2 )	
	EA_Window_ContextMenu.Finalize(EA_Window_ContextMenu.CONTEXT_MENU_2)
end

function yakuiconfig.showunitframeoptions()
	EA_Window_ContextMenu.Hide(EA_Window_ContextMenu.CONTEXT_MENU_3)
	EA_Window_ContextMenu.CreateContextMenu("", EA_Window_ContextMenu.CONTEXT_MENU_2)
	ButtonSetPressedFlag("yconfigcontextmenugroupiconsCheckBox", yakuiVar.Huduf.grpico)
	EA_Window_ContextMenu.AddUserDefinedMenuItem("yconfigcontextmenugroupicons", EA_Window_ContextMenu.CONTEXT_MENU_2)
	ButtonSetPressedFlag("yconfigcontextmenugroupframesCheckBox", yakuiVar.Huduf.groupframes)
	EA_Window_ContextMenu.AddUserDefinedMenuItem("yconfigcontextmenugroupframes", EA_Window_ContextMenu.CONTEXT_MENU_2)
	ButtonSetPressedFlag("yconfigcontextmenuinfopanelCheckBox", yakuiVar.Huduf.infopanel)
	EA_Window_ContextMenu.AddUserDefinedMenuItem("yconfigcontextmenuinfopanel", EA_Window_ContextMenu.CONTEXT_MENU_2)
	ButtonSetPressedFlag("yconfigcontextmenuhostilerangeCheckBox", yakuiVar.Huduf.hostilerange)
	EA_Window_ContextMenu.AddUserDefinedMenuItem("yconfigcontextmenuhostilerange", EA_Window_ContextMenu.CONTEXT_MENU_2)
	ButtonSetPressedFlag("yconfigcontextmenufriendlyrangeCheckBox", yakuiVar.Huduf.friendlyrange)
	EA_Window_ContextMenu.AddUserDefinedMenuItem("yconfigcontextmenufriendlyrange", EA_Window_ContextMenu.CONTEXT_MENU_2)
	ButtonSetPressedFlag("yconfigcontextmenucastbargcdCheckBox", yakuiVar.Huduf.castbargcd)
	EA_Window_ContextMenu.AddUserDefinedMenuItem("yconfigcontextmenucastbargcd", EA_Window_ContextMenu.CONTEXT_MENU_2)
	ButtonSetPressedFlag("yconfigcontextmenuignoreeffigyCheckBox", yakuiVar.Huduf.ignore)
	EA_Window_ContextMenu.AddUserDefinedMenuItem("yconfigcontextmenuignoreeffigy", EA_Window_ContextMenu.CONTEXT_MENU_2)	
	EA_Window_ContextMenu.Finalize(EA_Window_ContextMenu.CONTEXT_MENU_2)
end
	
function yakuiconfig.showunitframesextoptions()
	EA_Window_ContextMenu.CreateContextMenu("", EA_Window_ContextMenu.CONTEXT_MENU_2)
	if yakuiVar.Warnings.DaocBuff == 1 then 
		EA_Window_ContextMenu.AddMenuItem( L"DaoCBuff Options" , DAoCBuffSettings.OpenOptionswindow, false, true, EA_Window_ContextMenu.CONTEXT_MENU_2 )
	end
	if yakuiVar.Warnings.Huduf == 1 then
		EA_Window_ContextMenu.AddMenuItem( L"Effigy Options" , yakuiconfig.openeffigyoptions , false, true, EA_Window_ContextMenu.CONTEXT_MENU_2 )
	end
	if yakuiVar.Warnings.Phantom == 1 then
		EA_Window_ContextMenu.AddMenuItem( L"Phantom Options" , Phantom.Show, false, true, EA_Window_ContextMenu.CONTEXT_MENU_2 )
	end
	if yakuiVar.Warnings.Squared == 1 then
		EA_Window_ContextMenu.AddMenuItem( L"Squared Options" , SquaredConfigurator.Show, false, true, EA_Window_ContextMenu.CONTEXT_MENU_2 )
	end
	if yakuiVar.Warnings.TChat == 1 then
		EA_Window_ContextMenu.AddMenuItem( L"TidyChat Options" , TidyChat.ToggleOptions, false, true, EA_Window_ContextMenu.CONTEXT_MENU_2 )
	end
	if WSCT then
		EA_Window_ContextMenu.AddMenuItem( L"WSCT Options" , yakuiconfig.showwsctoptions, false, true, EA_Window_ContextMenu.CONTEXT_MENU_2 )
	end
	EA_Window_ContextMenu.Finalize(EA_Window_ContextMenu.CONTEXT_MENU_2)
end




-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------

-- Config core functions


function yakuiconfig.openeffigyoptions()
	if Effigy then RVMOD_Manager.API_ToggleAddon("EffigyConfigGui", 2) end
end

function yakuiconfig.ignoreeffigytoggle()
	yakuiVar.Huduf.ignore = not yakuiVar.Huduf.ignore
	ButtonSetPressedFlag("yconfigcontextmenuignoreeffigyCheckBox", yakuiVar.Huduf.ignore)
	if yakuiVar.Huduf.ignore == true then print("YakUI will no longer change Effigy settings...")
	else print("YakUI will change Effigy settings again. Caution! If you changed settings manually, this may result in errors or mixed up frames. Consider reloading the YakUI_135 layout in Effigy before proceeding.")
	end
end

function yakuiconfig.texturecombo()
	if ComboBoxGetSelectedMenuItem("yCustomcolorsliders_TextureCombo") == 1 then
		yakuiVar.Panel.tex = "Set1"
		yakui.texture()
		yakuiVar.Colors.col = "Custom"
		yakuiconfig.colorsliderUpdate()
	elseif ComboBoxGetSelectedMenuItem("yCustomcolorsliders_TextureCombo") == 2 then
		yakuiVar.Panel.tex = "Set2"
		yakui.texture()
		yakuiVar.Colors.col = "Custom"
		yakuiconfig.colorsliderUpdate()
	elseif ComboBoxGetSelectedMenuItem("yCustomcolorsliders_TextureCombo") == 3 then
		yakuiVar.Panel.tex = "Set3"
		yakui.texture()
		yakuiVar.Colors.col = "Custom"
		yakuiconfig.colorsliderUpdate()
	elseif ComboBoxGetSelectedMenuItem("yCustomcolorsliders_TextureCombo") == 4 then
		yakuiVar.Panel.tex = "Set4"
		yakui.texture()
		yakuiVar.Colors.col = "Custom"
		yakuiconfig.colorsliderUpdate()
	elseif ComboBoxGetSelectedMenuItem("yCustomcolorsliders_TextureCombo") == 5 then
		yakuiVar.Panel.tex = "Set5"
		yakui.texture()
		yakuiVar.Colors.col = "Custom"
		yakuiconfig.colorsliderUpdate()
	end
end

function yakuiconfig.presetcombo()
	if ComboBoxGetSelectedMenuItem("yCustomcolorsliders_Preset") == 1 then
		yakuiconfig.colorselect1()
	elseif ComboBoxGetSelectedMenuItem("yCustomcolorsliders_Preset") == 2 then
		yakuiconfig.colorselect2()
	elseif ComboBoxGetSelectedMenuItem("yCustomcolorsliders_Preset") == 3 then
		yakuiconfig.colorselect3()
	elseif ComboBoxGetSelectedMenuItem("yCustomcolorsliders_Preset") == 4 then
		yakuiconfig.colorselect4()
	elseif ComboBoxGetSelectedMenuItem("yCustomcolorsliders_Preset") == 5 then
		yakuiconfig.colorselect5()
	elseif ComboBoxGetSelectedMenuItem("yCustomcolorsliders_Preset") == 6 then
		yakuiconfig.colorselect6()
	elseif ComboBoxGetSelectedMenuItem("yCustomcolorsliders_Preset") == 7 then
		yakuiVar.Colors.col = "Custom"
		yakuiconfig.colorsliderUpdate()
	end
end

function yakuiconfig.configsidecombo()
	if ComboBoxGetSelectedMenuItem("yCustomcolorsliders_Side") == 1 then
		configside = 1
		yakuiconfig.colorsliderUpdate()
	elseif ComboBoxGetSelectedMenuItem("yCustomcolorsliders_Side") == 2 then
		configside = 2
		yakuiconfig.colorsliderUpdate()
	elseif ComboBoxGetSelectedMenuItem("yCustomcolorsliders_Side") == 3 then
		configside = 3
		yakuiconfig.colorsliderUpdate()
	end
end

function yakuiconfig.hostilerangetoggle()
	yakuiVar.Huduf.hostilerange = not yakuiVar.Huduf.hostilerange
	yakui.hostilerange()
	ButtonSetPressedFlag("yconfigcontextmenuhostilerangeCheckBox", yakuiVar.Huduf.hostilerange)
end

function yakuiconfig.friendlyrangetoggle()
	yakuiVar.Huduf.friendlyrange = not yakuiVar.Huduf.friendlyrange
	yakui.friendlyrange()
	ButtonSetPressedFlag("yconfigcontextmenufriendlyrangeCheckBox", yakuiVar.Huduf.friendlyrange)
end

function yakuiconfig.castbargcdtoggle()
	if yakuiVar.Huduf.ignore == false then
		yakuiVar.Huduf.castbargcd = not yakuiVar.Huduf.castbargcd
		Effigy.WindowSettings.castbar_show_gcd = yakuiVar.Huduf.castbargcd
		ButtonSetPressedFlag("yconfigcontextmenucastbargcdCheckBox", yakuiVar.Huduf.castbargcd)
	end
end

function yakuiconfig.alphatoggle()
	yakui.alphatoggle()
end

function yakuiconfig.activateskin()
	yakuiVar.Skin.active = not yakuiVar.Skin.active
	InterfaceCore.ReloadUI()
end

function yakuiconfig.infopaneltoggle()
	yakuiVar.Huduf.infopanel = not yakuiVar.Huduf.infopanel
	yakui.infopanel()
	ButtonSetPressedFlag("yconfigcontextmenuinfopanelCheckBox", yakuiVar.Huduf.infopanel)
end

function yakuiconfig.editwindowbackgrounds()
	WindowSetShowing("ySkinBackgroundColor", not WindowGetShowing("ySkinBackgroundColor"))
end

function yakuiconfig.linkwpanel()
	yakuiVar.Skin.newbackgrounds.linkwpanel = not yakuiVar.Skin.newbackgrounds.linkwpanel
	ButtonSetPressedFlag("ySkinBackgroundColor_LinkwpanelCheckbox", yakuiVar.Skin.newbackgrounds.linkwpanel)
	SliderBarSetDisabledFlag("ySkinBackgroundColor_SliderR", yakuiVar.Skin.newbackgrounds.linkwpanel )
	SliderBarSetDisabledFlag("ySkinBackgroundColor_SliderG", yakuiVar.Skin.newbackgrounds.linkwpanel )
	SliderBarSetDisabledFlag("ySkinBackgroundColor_SliderB", yakuiVar.Skin.newbackgrounds.linkwpanel )
	SliderBarSetDisabledFlag("ySkinBackgroundColor_SliderA", yakuiVar.Skin.newbackgrounds.linkwpanel )
	if yakuiVar.Skin.newbackgrounds.linkwpanel == true then
		WindowSetTintColor("ySkinBackgroundColor_SliderR", 120, 120, 120 )
		WindowSetTintColor("ySkinBackgroundColor_SliderG", 120, 120, 120 )
		WindowSetTintColor("ySkinBackgroundColor_SliderB", 120, 120, 120 )
		WindowSetTintColor("ySkinBackgroundColor_SliderA", 120, 120, 120 )
		LabelSetTextColor("ySkinBackgroundColor_Red", 160, 160, 160)
		LabelSetTextColor("ySkinBackgroundColor_Green", 160, 160, 160)
		LabelSetTextColor("ySkinBackgroundColor_Blue", 160, 160, 160)
		LabelSetTextColor("ySkinBackgroundColor_Alpha", 160, 160, 160)
	else
		WindowSetTintColor("ySkinBackgroundColor_SliderR", 255, 255, 255 )
		WindowSetTintColor("ySkinBackgroundColor_SliderG", 255, 255, 255 )
		WindowSetTintColor("ySkinBackgroundColor_SliderB", 255, 255, 255 )
		WindowSetTintColor("ySkinBackgroundColor_SliderA", 255, 255, 255 )
		LabelSetTextColor("ySkinBackgroundColor_Red", 255, 255, 255)
		LabelSetTextColor("ySkinBackgroundColor_Green", 255, 255, 255)
		LabelSetTextColor("ySkinBackgroundColor_Blue", 255, 255, 255)
		LabelSetTextColor("ySkinBackgroundColor_Alpha", 255, 255, 255)
	end
	yakuiSkin.newbackground()
end

function yakuiconfig.closewindowbackgrounds()
	WindowSetShowing("ySkinBackgroundColor", false)
end

function yakuiconfig.actionbartogglebag()
	yakuiVar.bag = not yakuiVar.bag
	if yakuiVar.bag == true then
		WindowSetShowing("yInfo_bag", true)
	else
		WindowSetShowing("yInfo_bag", false)
	end
	ButtonSetPressedFlag("yconfigcontextmenubagCheckBox", yakuiVar.bag)
end

function yakuiconfig.togglesmoothout()
	yakuiVar.smoothout = not yakuiVar.smoothout
	ButtonSetPressedFlag("yconfigcontextmenusmoothoutCheckBox", yakuiVar.smoothout)
end

function yakuiconfig.minmaphook()
	yakuiVar.minmaphook = not yakuiVar.minmaphook
	ButtonSetPressedFlag("yconfigcontextmenuminmaphookCheckBox", yakuiVar.minmaphook)
end

function yakuiconfig.actionbartoggletooltips()
	yakuiVar.Actionbar.Tooltips = not yakuiVar.Actionbar.Tooltips
	ButtonSetPressedFlag("yconfigcontextmenutooltipsCheckBox", yakuiVar.Actionbar.Tooltips)
end

function yakuiconfig.actionbartogglekeyb()
	yakuiVar.Actionbar.Keybindings = not yakuiVar.Actionbar.Keybindings
	InterfaceCore.ReloadUI()
end 

function yakuiconfig.actionbartogglecdanim()
	yakuiVar.Actionbar.CDAnimation = not yakuiVar.Actionbar.CDAnimation
	ButtonSetPressedFlag("yconfigcontextmenucdanimCheckBox", yakuiVar.Actionbar.CDAnimation)
end

function yakuiconfig.actionbartogglegcdanim()
	yakuiVar.Actionbar.GCDAnimation = not yakuiVar.Actionbar.GCDAnimation
	ButtonSetPressedFlag("yconfigcontextmenugcdanimCheckBox", yakuiVar.Actionbar.GCDAnimation)
end

function yakuiconfig.actionbartogglepagers()
	yakuiVar.Actionbar.Pagers = not yakuiVar.Actionbar.Pagers
	ChangePagers()
	InterfaceCore.ReloadUI()
end

function yakuiconfig.actionbartoggleempty()
	yakuiVar.Actionbar.Empty = not yakuiVar.Actionbar.Empty
	BarEmptySlots()
	ButtonSetPressedFlag("yconfigcontextmenuemptyCheckBox", yakuiVar.Actionbar.Empty)
end

function yakuiconfig.actionbartogglebackground()
	yakuiVar.Actionbar.Background = not yakuiVar.Actionbar.Background
	BarBackgrounds()
	ButtonSetPressedFlag("yconfigcontextmenubackgroundCheckBox", yakuiVar.Actionbar.Background)
end

function yakuiconfig.actionbartoggleglow()
	yakuiVar.Actionbar.Glow = not yakuiVar.Actionbar.Glow
	ButtonSetPressedFlag("yconfigcontextmenuglowCheckBox", yakuiVar.Actionbar.Glow)
end

function yakuiconfig.actionbartoggleflash()
	yakuiVar.Actionbar.Flash = not yakuiVar.Actionbar.Flash
	ButtonSetPressedFlag("yconfigcontextmenuflashCheckBox", yakuiVar.Actionbar.Flash)
end

function yakuiconfig.editcustomcolor()
	WindowSetShowing("yCustomcolorsliders", not WindowGetShowing("yCustomcolorsliders"))
end

function yakuiconfig.setlinkwpanel()
	ButtonSetPressedFlag("ySkinBackgroundColor_LinkwpanelCheckbox", yakuiVar.Skin.newbackgrounds.linkwpanel)
	SliderBarSetDisabledFlag("ySkinBackgroundColor_SliderR", yakuiVar.Skin.newbackgrounds.linkwpanel )
	SliderBarSetDisabledFlag("ySkinBackgroundColor_SliderG", yakuiVar.Skin.newbackgrounds.linkwpanel )
	SliderBarSetDisabledFlag("ySkinBackgroundColor_SliderB", yakuiVar.Skin.newbackgrounds.linkwpanel )
	SliderBarSetDisabledFlag("ySkinBackgroundColor_SliderA", yakuiVar.Skin.newbackgrounds.linkwpanel )
	if yakuiVar.Skin.newbackgrounds.linkwpanel == true then
		WindowSetTintColor("ySkinBackgroundColor_SliderR", 120, 120, 120 )
		WindowSetTintColor("ySkinBackgroundColor_SliderG", 120, 120, 120 )
		WindowSetTintColor("ySkinBackgroundColor_SliderB", 120, 120, 120 )
		WindowSetTintColor("ySkinBackgroundColor_SliderA", 120, 120, 120 )
		LabelSetTextColor("ySkinBackgroundColor_Red", 160, 160, 160)
		LabelSetTextColor("ySkinBackgroundColor_Green", 160, 160, 160)
		LabelSetTextColor("ySkinBackgroundColor_Blue", 160, 160, 160)
		LabelSetTextColor("ySkinBackgroundColor_Alpha", 160, 160, 160)
	else
		WindowSetTintColor("ySkinBackgroundColor_SliderR", 255, 255, 255 )
		WindowSetTintColor("ySkinBackgroundColor_SliderG", 255, 255, 255 )
		WindowSetTintColor("ySkinBackgroundColor_SliderB", 255, 255, 255 )
		WindowSetTintColor("ySkinBackgroundColor_SliderA", 255, 255, 255 )
		LabelSetTextColor("ySkinBackgroundColor_Red", 255, 255, 255)
		LabelSetTextColor("ySkinBackgroundColor_Green", 255, 255, 255)
		LabelSetTextColor("ySkinBackgroundColor_Blue", 255, 255, 255)
		LabelSetTextColor("ySkinBackgroundColor_Alpha", 255, 255, 255)
	end
	yakuiSkin.newbackground()
end

function yakuiconfig.colorselect1()
	WindowSetShowing("yconfigcontextmenucolorselect1Check", true)
	WindowSetShowing("yconfigcontextmenucolorselect2Check", false)
	WindowSetShowing("yconfigcontextmenucolorselect3Check", false)
	WindowSetShowing("yconfigcontextmenucolorselect4Check", false)
	WindowSetShowing("yconfigcontextmenucolorselect5Check", false)
	WindowSetShowing("yconfigcontextmenucolorselect6Check", false)
	yakuiVar.Colors.colprintr = 64
	yakuiVar.Colors.colprintg = 64
	yakuiVar.Colors.colprintb = 80
	yakuiVar.Panel.Panelalpha = 0.5
	yakuiVar.Colors.background.r = 16
	yakuiVar.Colors.background.g = 16
	yakuiVar.Colors.background.b = 20
	yakuiVar.Panel.alpha = 0.7
	yakuiVar.Colors.fx.r = 255
	yakuiVar.Colors.fx.g = 255
	yakuiVar.Colors.fx.b = 255
	yakuiVar.Panel.fxalpha = 0.7
	yakuiVar.Colors.unitframes.player.r = 220
	yakuiVar.Colors.unitframes.player.g = 220
	yakuiVar.Colors.unitframes.player.b = 220
	yakuiVar.Colors.unitframes.hostile.r = 220
	yakuiVar.Colors.unitframes.hostile.g = 220
	yakuiVar.Colors.unitframes.hostile.b = 220
	yakuiVar.Colors.unitframes.castbar.r = 220
	yakuiVar.Colors.unitframes.castbar.g = 220
	yakuiVar.Colors.unitframes.castbar.b = 220
	yakuiVar.Colors.unitframes.apbar.r = 220
	yakuiVar.Colors.unitframes.apbar.g = 220
	yakuiVar.Colors.unitframes.apbar.b = 220
	yakuiVar.Colors.unitframes.friendly.r = 220
	yakuiVar.Colors.unitframes.friendly.g = 220
	yakuiVar.Colors.unitframes.friendly.b = 220
	yakuiVar.Colors.unitframes.careerbar.r = 220
	yakuiVar.Colors.unitframes.careerbar.g = 220
	yakuiVar.Colors.unitframes.careerbar.b = 220
	yakuiVar.Colors.col = "Preset1"
	yakuiVar.Panel.tex = "Set5"
	if yakuiVar.Skin.active == true then
		yakuiVar.Skin.newbackgrounds.r = 16
		yakuiVar.Skin.newbackgrounds.g = 16
		yakuiVar.Skin.newbackgrounds.b = 16
		yakuiVar.Skin.newbackgrounds.alpha = 0.9
		yakuiVar.Skin.newbackgrounds.linkwpanel = false
		yakuiconfig.setlinkwpanel()
	end
	yakuiconfig.colorsliderUpdate()
	yakui.color()
	yakui.texture()
end

function yakuiconfig.colorselect2()
	WindowSetShowing("yconfigcontextmenucolorselect1Check", false)
	WindowSetShowing("yconfigcontextmenucolorselect2Check", true)
	WindowSetShowing("yconfigcontextmenucolorselect3Check", false)
	WindowSetShowing("yconfigcontextmenucolorselect4Check", false)
	WindowSetShowing("yconfigcontextmenucolorselect5Check", false)
	WindowSetShowing("yconfigcontextmenucolorselect6Check", false)
	yakuiVar.Colors.colprintr = 24
	yakuiVar.Colors.colprintg = 24
	yakuiVar.Colors.colprintb = 24
	yakuiVar.Panel.Panelalpha = 0.8
	yakuiVar.Colors.background.r = 16
	yakuiVar.Colors.background.g = 16
	yakuiVar.Colors.background.b = 16
	yakuiVar.Panel.alpha = 0.7
	yakuiVar.Colors.fx.r = 180
	yakuiVar.Colors.fx.g = 220
	yakuiVar.Colors.fx.b = 255
	yakuiVar.Panel.fxalpha = 0.6
	yakuiVar.Colors.unitframes.player.r = 220
	yakuiVar.Colors.unitframes.player.g = 220
	yakuiVar.Colors.unitframes.player.b = 220
	yakuiVar.Colors.unitframes.hostile.r = 192
	yakuiVar.Colors.unitframes.hostile.g = 48
	yakuiVar.Colors.unitframes.hostile.b = 160
	yakuiVar.Colors.unitframes.castbar.r = 220
	yakuiVar.Colors.unitframes.castbar.g = 220
	yakuiVar.Colors.unitframes.castbar.b = 220
	yakuiVar.Colors.unitframes.apbar.r = 220
	yakuiVar.Colors.unitframes.apbar.g = 220
	yakuiVar.Colors.unitframes.apbar.b = 220
	yakuiVar.Colors.unitframes.friendly.r = 0
	yakuiVar.Colors.unitframes.friendly.g = 192
	yakuiVar.Colors.unitframes.friendly.b = 160
	yakuiVar.Colors.unitframes.careerbar.r = 220
	yakuiVar.Colors.unitframes.careerbar.g = 220
	yakuiVar.Colors.unitframes.careerbar.b = 220
	yakuiVar.Colors.col = "Preset2"
	yakuiVar.Panel.tex = "Set5"
	if yakuiVar.Skin.active == true then
		yakuiVar.Skin.newbackgrounds.r = 16
		yakuiVar.Skin.newbackgrounds.g = 16
		yakuiVar.Skin.newbackgrounds.b = 20
		yakuiVar.Skin.newbackgrounds.alpha = 0.9
		yakuiVar.Skin.newbackgrounds.linkwpanel = false
		yakuiconfig.setlinkwpanel()
	end
	yakuiconfig.colorsliderUpdate()
	yakui.color()
	yakui.texture()
end

function yakuiconfig.colorselect3()
	WindowSetShowing("yconfigcontextmenucolorselect1Check", false)
	WindowSetShowing("yconfigcontextmenucolorselect2Check", false)
	WindowSetShowing("yconfigcontextmenucolorselect3Check", true)
	WindowSetShowing("yconfigcontextmenucolorselect4Check", false)
	WindowSetShowing("yconfigcontextmenucolorselect5Check", false)
	WindowSetShowing("yconfigcontextmenucolorselect6Check", false)
	yakuiVar.Colors.colprintr = 64
	yakuiVar.Colors.colprintg = 64
	yakuiVar.Colors.colprintb = 80
	yakuiVar.Panel.Panelalpha = 1
	yakuiVar.Colors.background.r = 12
	yakuiVar.Colors.background.g = 3
	yakuiVar.Colors.background.b = 9
	yakuiVar.Panel.alpha = 0.8
	yakuiVar.Colors.fx.r = 92
	yakuiVar.Colors.fx.g = 92
	yakuiVar.Colors.fx.b = 92
	yakuiVar.Panel.fxalpha = 0.8
	yakuiVar.Colors.unitframes.player.r = 180
	yakuiVar.Colors.unitframes.player.g = 190
	yakuiVar.Colors.unitframes.player.b = 200
	yakuiVar.Colors.unitframes.hostile.r = 168
	yakuiVar.Colors.unitframes.hostile.g = 40
	yakuiVar.Colors.unitframes.hostile.b = 120
	yakuiVar.Colors.unitframes.castbar.r = 180
	yakuiVar.Colors.unitframes.castbar.g = 190
	yakuiVar.Colors.unitframes.castbar.b = 200
	yakuiVar.Colors.unitframes.apbar.r = 180
	yakuiVar.Colors.unitframes.apbar.g = 190
	yakuiVar.Colors.unitframes.apbar.b = 200
	yakuiVar.Colors.unitframes.friendly.r = 120
	yakuiVar.Colors.unitframes.friendly.g = 140
	yakuiVar.Colors.unitframes.friendly.b = 220
	yakuiVar.Colors.unitframes.careerbar.r = 180
	yakuiVar.Colors.unitframes.careerbar.g = 190
	yakuiVar.Colors.unitframes.careerbar.b = 200
	yakuiVar.Colors.col = "Preset3"
	yakuiVar.Panel.tex = "Set3"
	if yakuiVar.Skin.active == true then
		yakuiVar.Skin.newbackgrounds.r = 16
		yakuiVar.Skin.newbackgrounds.g = 0
		yakuiVar.Skin.newbackgrounds.b = 6
		yakuiVar.Skin.newbackgrounds.alpha = 0.8
		yakuiVar.Skin.newbackgrounds.linkwpanel = true
		yakuiconfig.setlinkwpanel()
	end
	yakuiconfig.colorsliderUpdate()
	yakui.color()
	yakui.texture()
end

function yakuiconfig.colorselect4()
	WindowSetShowing("yconfigcontextmenucolorselect1Check", false)
	WindowSetShowing("yconfigcontextmenucolorselect2Check", false)
	WindowSetShowing("yconfigcontextmenucolorselect3Check", false)
	WindowSetShowing("yconfigcontextmenucolorselect4Check", true)
	WindowSetShowing("yconfigcontextmenucolorselect5Check", false)
	WindowSetShowing("yconfigcontextmenucolorselect6Check", false)
	yakuiVar.Colors.colprintr = 24
	yakuiVar.Colors.colprintg = 24
	yakuiVar.Colors.colprintb = 24
	yakuiVar.Panel.Panelalpha = 1
	yakuiVar.Colors.background.r = 0
	yakuiVar.Colors.background.g = 12
	yakuiVar.Colors.background.b = 6
	yakuiVar.Panel.alpha = 0.8
	yakuiVar.Colors.fx.r = 200
	yakuiVar.Colors.fx.g = 200
	yakuiVar.Colors.fx.b = 0
	yakuiVar.Panel.fxalpha = 0.7
	yakuiVar.Colors.unitframes.player.r = 180
	yakuiVar.Colors.unitframes.player.g = 190
	yakuiVar.Colors.unitframes.player.b = 200
	yakuiVar.Colors.unitframes.hostile.r = 180
	yakuiVar.Colors.unitframes.hostile.g = 190
	yakuiVar.Colors.unitframes.hostile.b = 200
	yakuiVar.Colors.unitframes.castbar.r = 180
	yakuiVar.Colors.unitframes.castbar.g = 190
	yakuiVar.Colors.unitframes.castbar.b = 200
	yakuiVar.Colors.unitframes.apbar.r = 180
	yakuiVar.Colors.unitframes.apbar.g = 190
	yakuiVar.Colors.unitframes.apbar.b = 200
	yakuiVar.Colors.unitframes.friendly.r = 180
	yakuiVar.Colors.unitframes.friendly.g = 190
	yakuiVar.Colors.unitframes.friendly.b = 200
	yakuiVar.Colors.unitframes.careerbar.r = 180
	yakuiVar.Colors.unitframes.careerbar.g = 190
	yakuiVar.Colors.unitframes.careerbar.b = 200
	yakuiVar.Colors.col = "Preset4"
	yakuiVar.Panel.tex = "Set2"
	if yakuiVar.Skin.active == true then
		yakuiVar.Skin.newbackgrounds.r = 0
		yakuiVar.Skin.newbackgrounds.g = 12
		yakuiVar.Skin.newbackgrounds.b = 6
		yakuiVar.Skin.newbackgrounds.alpha = 0.8
		yakuiVar.Skin.newbackgrounds.linkwpanel = true
		yakuiconfig.setlinkwpanel()
	end
	yakuiconfig.colorsliderUpdate()
	yakui.color()
	yakui.texture()
end

function yakuiconfig.colorselect5()
	WindowSetShowing("yconfigcontextmenucolorselect1Check", false)
	WindowSetShowing("yconfigcontextmenucolorselect2Check", false)
	WindowSetShowing("yconfigcontextmenucolorselect3Check", false)
	WindowSetShowing("yconfigcontextmenucolorselect4Check", false)
	WindowSetShowing("yconfigcontextmenucolorselect5Check", true)
	WindowSetShowing("yconfigcontextmenucolorselect6Check", false)
	yakuiVar.Colors.colprintr = 20
	yakuiVar.Colors.colprintg = 30
	yakuiVar.Colors.colprintb = 60
	yakuiVar.Panel.Panelalpha = 1
	yakuiVar.Colors.background.r = 10
	yakuiVar.Colors.background.g = 15
	yakuiVar.Colors.background.b = 30
	yakuiVar.Panel.alpha = 0.7
	yakuiVar.Colors.fx.r = 255
	yakuiVar.Colors.fx.g = 255
	yakuiVar.Colors.fx.b = 255
	yakuiVar.Panel.fxalpha = 0.8
	yakuiVar.Colors.unitframes.player.r = 220
	yakuiVar.Colors.unitframes.player.g = 220
	yakuiVar.Colors.unitframes.player.b = 220
	yakuiVar.Colors.unitframes.hostile.r = 220
	yakuiVar.Colors.unitframes.hostile.g = 220
	yakuiVar.Colors.unitframes.hostile.b = 220
	yakuiVar.Colors.unitframes.castbar.r = 220
	yakuiVar.Colors.unitframes.castbar.g = 220
	yakuiVar.Colors.unitframes.castbar.b = 220
	yakuiVar.Colors.unitframes.apbar.r = 220
	yakuiVar.Colors.unitframes.apbar.g = 220
	yakuiVar.Colors.unitframes.apbar.b = 220
	yakuiVar.Colors.unitframes.friendly.r = 220
	yakuiVar.Colors.unitframes.friendly.g = 220
	yakuiVar.Colors.unitframes.friendly.b = 220
	yakuiVar.Colors.unitframes.careerbar.r = 220
	yakuiVar.Colors.unitframes.careerbar.g = 220
	yakuiVar.Colors.unitframes.careerbar.b = 220
	yakuiVar.Colors.col = "Preset5"
	yakuiVar.Panel.tex = "Set1"
	if yakuiVar.Skin.active == true then
		yakuiVar.Skin.newbackgrounds.r = 10
		yakuiVar.Skin.newbackgrounds.g = 15
		yakuiVar.Skin.newbackgrounds.b = 30
		yakuiVar.Skin.newbackgrounds.alpha = 0.7
		yakuiVar.Skin.newbackgrounds.linkwpanel = true
		yakuiconfig.setlinkwpanel()
	end
	yakuiconfig.colorsliderUpdate()
	yakui.color()
	yakui.texture()
end

function yakuiconfig.colorselect6()
	WindowSetShowing("yconfigcontextmenucolorselect1Check", false)
	WindowSetShowing("yconfigcontextmenucolorselect2Check", false)
	WindowSetShowing("yconfigcontextmenucolorselect3Check", false)
	WindowSetShowing("yconfigcontextmenucolorselect4Check", false)
	WindowSetShowing("yconfigcontextmenucolorselect5Check", false)
	WindowSetShowing("yconfigcontextmenucolorselect6Check", true)
	yakuiVar.Colors.colprintr = 24
	yakuiVar.Colors.colprintg = 0
	yakuiVar.Colors.colprintb = 24
	yakuiVar.Panel.Panelalpha = 1
	yakuiVar.Colors.background.r = 8
	yakuiVar.Colors.background.g = 0
	yakuiVar.Colors.background.b = 4
	yakuiVar.Panel.alpha = 0.9
	yakuiVar.Colors.fx.r = 142
	yakuiVar.Colors.fx.g = 160
	yakuiVar.Colors.fx.b = 142
	yakuiVar.Panel.fxalpha = 0.8
	yakuiVar.Colors.unitframes.player.r = 220
	yakuiVar.Colors.unitframes.player.g = 220
	yakuiVar.Colors.unitframes.player.b = 220
	yakuiVar.Colors.unitframes.hostile.r = 220
	yakuiVar.Colors.unitframes.hostile.g = 220
	yakuiVar.Colors.unitframes.hostile.b = 220
	yakuiVar.Colors.unitframes.castbar.r = 220
	yakuiVar.Colors.unitframes.castbar.g = 220
	yakuiVar.Colors.unitframes.castbar.b = 220
	yakuiVar.Colors.unitframes.apbar.r = 220
	yakuiVar.Colors.unitframes.apbar.g = 220
	yakuiVar.Colors.unitframes.apbar.b = 220
	yakuiVar.Colors.unitframes.friendly.r = 220
	yakuiVar.Colors.unitframes.friendly.g = 220
	yakuiVar.Colors.unitframes.friendly.b = 220
	yakuiVar.Colors.unitframes.careerbar.r = 220
	yakuiVar.Colors.unitframes.careerbar.g = 220
	yakuiVar.Colors.unitframes.careerbar.b = 220
	yakuiVar.Colors.col = "Preset6"
	yakuiVar.Panel.tex = "Set4"
	if yakuiVar.Skin.active == true then
		yakuiVar.Skin.newbackgrounds.r = 8
		yakuiVar.Skin.newbackgrounds.g = 0
		yakuiVar.Skin.newbackgrounds.b = 4
		yakuiVar.Skin.newbackgrounds.alpha = 0.7
		yakuiVar.Skin.newbackgrounds.linkwpanel = true
		yakuiconfig.setlinkwpanel()
	end
	yakuiconfig.colorsliderUpdate()
	yakui.color()
	yakui.texture()
end


function yakuiconfig.actionbartogglegroupicons()
	if yakuiVar.Huduf.ignore == false then
		yakuiVar.Huduf.grpico = not yakuiVar.Huduf.grpico
		for i = 1,5 do
			if Effigy.Bars["WorldGroupMember"..i] then
				bar =  Effigy.Bars["WorldGroupMember"..i]
				bar.show = yakuiVar.Huduf.grpico
				bar:setup()
				bar:render()
			end
		end
		if yakuiVar.Huduf.grpico == true then print("Group Icons: On") else print ("Group Icons: Off") end
		ButtonSetPressedFlag("yconfigcontextmenugroupiconsCheckBox", yakuiVar.Huduf.grpico)
	end
end

function yakuiconfig.actionbartogglelimitalert()
	yakuiVar.limitalert = not yakuiVar.limitalert
	ButtonSetPressedFlag("yconfigcontextmenulimitalertCheckBox", yakuiVar.limitalert)
end

function yakuiconfig.moralecd()
	yakuiVar.moraleCDsize = not yakuiVar.moraleCDsize
	yakui.setmoraleCDsize()
	ButtonSetPressedFlag("yconfigcontextmenumoraleCDsizeCheckBox", yakuiVar.moraleCDsize)
end

function yakuiconfig.actionbartogglefps()
	yakuiVar.fps = not yakuiVar.fps
	if yakuiVar.fps == true then
		RegisterEventHandler(SystemData.Events.UPDATE_PROCESSED, "yakuiInfo.fps_moduleupdate")
		WindowSetShowing("snt_info_fps", true)
	else
		WindowSetShowing("snt_info_fps", false)
		UnregisterEventHandler(SystemData.Events.UPDATE_PROCESSED, "yakuiInfo.fps_moduleupdate")
	end
	ButtonSetPressedFlag("yconfigcontextmenufpsCheckBox", yakuiVar.fps)
end

function yakuiconfig.actionbartoggleloc()
	yakuiVar.loc = not yakuiVar.loc
	if yakuiVar.loc == true then
		RegisterEventHandler(SystemData.Events.PLAYER_POSITION_UPDATED,"yakuiInfo.loc_moduleupdate")
		WindowSetShowing("i_loc", true)
	else
		WindowSetShowing("i_loc", false)
		UnregisterEventHandler(SystemData.Events.PLAYER_POSITION_UPDATED,"yakuiInfo.loc_moduleupdate")
	end
	ButtonSetPressedFlag("yconfigcontextmenulocCheckBox", yakuiVar.loc)
end

function yakuiconfig.actionbartogglegroupframes()
	yakuiVar.Huduf.groupframes = not yakuiVar.Huduf.groupframes
	ButtonSetPressedFlag("yconfigcontextmenugroupframesCheckBox", yakuiVar.Huduf.groupframes)
	bar =  Effigy.Bars["GroupMember1"]
	bar.show = yakuiVar.Huduf.groupframes
	bar:setup()
	bar:render()
	bar =  Effigy.Bars["GroupMember2"]
	bar.show = yakuiVar.Huduf.groupframes
	bar:setup()
	bar:render()
	bar =  Effigy.Bars["GroupMember3"]
	bar.show = yakuiVar.Huduf.groupframes
	bar:setup()
	bar:render()
	bar =  Effigy.Bars["GroupMember4"]
	bar.show = yakuiVar.Huduf.groupframes
	bar:setup()
	bar:render()
	bar =  Effigy.Bars["GroupMember5"]
	bar.show = yakuiVar.Huduf.groupframes
	bar:setup()
	bar:render()
	if yakuiVar.Warnings.DaocBuff == 1 then
		for i,k in ipairs(DAoCBuffVar.Frames) do  
			if(k.buffTargetType==100) then k.active= yakuiVar.Huduf.groupframes end 
		end 
		DAoCBuff.U()
	end
	-- InterfaceCore.ReloadUI()
end

function yakuiconfig.showwsctoptions()
	WSCT:OpenMenu()
end

function yakuiconfig.reloadui()
	InterfaceCore.ReloadUI()
end

function yakuiconfig.alertmod()
	alertMod.SlashCommand()
end

function yakuiconfig.alphasliderpanel(pos)
	local tmp = towstring(pos)
	tmp = wstring.format( L"%0.1f", tmp )
	tmp = tonumber(tmp)
	yakuiVar.Panel.Panelalpha = tmp
	yakuiVar.Panel.alphatoggle = true
	WindowSetShowing("yconfigcontextmenucolorselect1Check", false)
	WindowSetShowing("yconfigcontextmenucolorselect2Check", false)
	WindowSetShowing("yconfigcontextmenucolorselect3Check", false)
	WindowSetShowing("yconfigcontextmenucolorselect4Check", false)
	WindowSetShowing("yconfigcontextmenucolorselect5Check", false)
	WindowSetShowing("yconfigcontextmenucolorselect6Check", false)
	yakuiVar.Colors.col = "Custom"
	yakui.color()
	yakuiconfig.colorsliderUpdate()
end

function yakuiconfig.alphasliderbackground(pos)
	local tmp = towstring(pos)
	tmp = wstring.format( L"%0.1f", tmp )
	tmp = tonumber(tmp)
	yakuiVar.Panel.alpha = tmp
	WindowSetShowing("yconfigcontextmenucolorselect1Check", false)
	WindowSetShowing("yconfigcontextmenucolorselect2Check", false)
	WindowSetShowing("yconfigcontextmenucolorselect3Check", false)
	WindowSetShowing("yconfigcontextmenucolorselect4Check", false)
	WindowSetShowing("yconfigcontextmenucolorselect5Check", false)
	WindowSetShowing("yconfigcontextmenucolorselect6Check", false)
	yakuiVar.Colors.col = "Custom"
	yakui.color()
	yakuiconfig.colorsliderUpdate()
end

function yakuiconfig.alphasliderfx(pos)
	local tmp = towstring(pos)
	tmp = wstring.format( L"%0.1f", tmp )
	tmp = tonumber(tmp)
	yakuiVar.Panel.fxalpha = tmp
	WindowSetShowing("yconfigcontextmenucolorselect1Check", false)
	WindowSetShowing("yconfigcontextmenucolorselect2Check", false)
	WindowSetShowing("yconfigcontextmenucolorselect3Check", false)
	WindowSetShowing("yconfigcontextmenucolorselect4Check", false)
	WindowSetShowing("yconfigcontextmenucolorselect5Check", false)
	WindowSetShowing("yconfigcontextmenucolorselect6Check", false)
	yakuiVar.Colors.col = "Custom"
	yakui.color()
	yakuiconfig.colorsliderUpdate()
end

function yakuiconfig.windowsbackgroundsalphaslider(pos)
	local tmp = towstring(pos)
	tmp = wstring.format( L"%0.1f", tmp )
	tmp = tonumber(tmp)
	yakuiVar.Skin.newbackgrounds.alpha = tmp
	yakuiSkin.newbackground()
	yakuiconfig.windowsbackgroundssliderUpdate()
end

function yakuiconfig.windowsbackgroundssliderR(pos)
	yakuiVar.Skin.newbackgrounds.r = math.floor(255 * pos + 0.5)
	yakuiSkin.newbackground()
	yakuiconfig.windowsbackgroundssliderUpdate()
end

function yakuiconfig.windowsbackgroundssliderG(pos)
	yakuiVar.Skin.newbackgrounds.g = math.floor(255 * pos + 0.5)
	yakuiSkin.newbackground()
	yakuiconfig.windowsbackgroundssliderUpdate()
end

function yakuiconfig.windowsbackgroundssliderB(pos)
	yakuiVar.Skin.newbackgrounds.b = math.floor(255 * pos + 0.5)
	yakuiSkin.newbackground()
	yakuiconfig.windowsbackgroundssliderUpdate()
end

function yakuiconfig.windowsbackgroundssliderUpdate()
	LabelSetText("ySkinBackgroundColor_Red", L"Red: "..yakuiVar.Skin.newbackgrounds.r)
	LabelSetText("ySkinBackgroundColor_Green", L"Green: "..yakuiVar.Skin.newbackgrounds.g)
	LabelSetText("ySkinBackgroundColor_Blue", L"Blue: "..yakuiVar.Skin.newbackgrounds.b)
	LabelSetText("ySkinBackgroundColor_Alpha", L"Alpha: "..yakuiVar.Skin.newbackgrounds.alpha)
	SliderBarSetCurrentPosition( "ySkinBackgroundColor_SliderR" , yakuiVar.Skin.newbackgrounds.r/256)
	SliderBarSetCurrentPosition( "ySkinBackgroundColor_SliderG" , yakuiVar.Skin.newbackgrounds.g/256)
	SliderBarSetCurrentPosition( "ySkinBackgroundColor_SliderB" , yakuiVar.Skin.newbackgrounds.b/256)
	SliderBarSetCurrentPosition( "ySkinBackgroundColor_SliderA" , yakuiVar.Skin.newbackgrounds.alpha)
end

function yakuiconfig.colorsliderClose()
	WindowSetShowing("yCustomcolorsliders", false)
end

function yakuiconfig.colorsliderUpdate()
	if configside == 1 then
		LabelSetText("yCustomcolorsliders_Headline1", L"Panel:")
		LabelSetText("yCustomcolorsliders_Headline2", L"Background:")
		LabelSetText("yCustomcolorsliders_Headline3", L"FX:")
		LabelSetText("yCustomcolorsliders_Red", L"Red: "..yakuiVar.Colors.colprintr)
		LabelSetText("yCustomcolorsliders_Green", L"Green: "..yakuiVar.Colors.colprintg)
		LabelSetText("yCustomcolorsliders_Blue", L"Blue: "..yakuiVar.Colors.colprintb)
		WindowSetShowing("yCustomcolorsliders_Alpha", true)
		LabelSetText("yCustomcolorsliders_Alpha", L"Alpha: "..yakuiVar.Panel.Panelalpha)
		SliderBarSetCurrentPosition( "yCustomcolorsliders_SliderR" , yakuiVar.Colors.colprintr/256)
		SliderBarSetCurrentPosition( "yCustomcolorsliders_SliderG" , yakuiVar.Colors.colprintg/256)
		SliderBarSetCurrentPosition( "yCustomcolorsliders_SliderB" , yakuiVar.Colors.colprintb/256)
		WindowSetShowing("yCustomcolorsliders_SliderA" , true)
		SliderBarSetCurrentPosition( "yCustomcolorsliders_SliderA" , yakuiVar.Panel.Panelalpha)
		LabelSetText("yCustomcolorsliders_BGRed", L"Red: "..yakuiVar.Colors.background.r)
		LabelSetText("yCustomcolorsliders_BGGreen", L"Green: "..yakuiVar.Colors.background.g)
		LabelSetText("yCustomcolorsliders_BGBlue", L"Blue: "..yakuiVar.Colors.background.b)
		WindowSetShowing("yCustomcolorsliders_BGAlpha", true)
		LabelSetText("yCustomcolorsliders_BGAlpha", L"Alpha: "..yakuiVar.Panel.alpha)
		SliderBarSetCurrentPosition( "yCustomcolorsliders_BGSliderR" , yakuiVar.Colors.background.r/256)
		SliderBarSetCurrentPosition( "yCustomcolorsliders_BGSliderG" , yakuiVar.Colors.background.g/256)
		SliderBarSetCurrentPosition( "yCustomcolorsliders_BGSliderB" , yakuiVar.Colors.background.b/256)
		WindowSetShowing("yCustomcolorsliders_BGSliderA" , true)
		SliderBarSetCurrentPosition( "yCustomcolorsliders_BGSliderA" , yakuiVar.Panel.alpha)
		LabelSetText("yCustomcolorsliders_FXRed", L"Red: "..yakuiVar.Colors.fx.r)
		LabelSetText("yCustomcolorsliders_FXGreen", L"Green: "..yakuiVar.Colors.fx.g)
		LabelSetText("yCustomcolorsliders_FXBlue", L"Blue: "..yakuiVar.Colors.fx.b)
		WindowSetShowing("yCustomcolorsliders_FXAlpha", true)
		LabelSetText("yCustomcolorsliders_FXAlpha", L"Alpha: "..yakuiVar.Panel.fxalpha)
		SliderBarSetCurrentPosition( "yCustomcolorsliders_FXSliderR" , yakuiVar.Colors.fx.r/256)
		SliderBarSetCurrentPosition( "yCustomcolorsliders_FXSliderG" , yakuiVar.Colors.fx.g/256)
		SliderBarSetCurrentPosition( "yCustomcolorsliders_FXSliderB" , yakuiVar.Colors.fx.b/256)
		WindowSetShowing( "yCustomcolorsliders_FXSliderA" , true)
		SliderBarSetCurrentPosition( "yCustomcolorsliders_FXSliderA" , yakuiVar.Panel.fxalpha)
		WindowSetShowing("yCustomcolorsliders_AlphaToggleLabel", true)
		WindowSetShowing("yCustomcolorsliders_AlphaToggle", true)
		ButtonSetPressedFlag("yCustomcolorsliders_AlphaToggle", yakuiVar.Panel.alphatoggle)
		SliderBarSetDisabledFlag("yCustomcolorsliders_BGSliderA", not yakuiVar.Panel.alphatoggle )
		if yakuiVar.Panel.alphatoggle == false then 
			WindowSetTintColor("yCustomcolorsliders_BGSliderA", 120, 120, 120 )
		else
			WindowSetTintColor("yCustomcolorsliders_BGSliderA", 255, 255, 255 )
		end
	elseif configside == 2 then
		LabelSetText("yCustomcolorsliders_Headline1", L"Player:")
		LabelSetText("yCustomcolorsliders_Headline2", L"Hostile:")
		LabelSetText("yCustomcolorsliders_Headline3", L"Friendly:")
		LabelSetText("yCustomcolorsliders_Red", L"Red: "..yakuiVar.Colors.unitframes.player.r)
		LabelSetText("yCustomcolorsliders_Green", L"Green: "..yakuiVar.Colors.unitframes.player.g)
		LabelSetText("yCustomcolorsliders_Blue", L"Blue: "..yakuiVar.Colors.unitframes.player.b)
		WindowSetShowing("yCustomcolorsliders_Alpha", false)
		SliderBarSetCurrentPosition( "yCustomcolorsliders_SliderR" , yakuiVar.Colors.unitframes.player.r/256)
		SliderBarSetCurrentPosition( "yCustomcolorsliders_SliderG" , yakuiVar.Colors.unitframes.player.g/256)
		SliderBarSetCurrentPosition( "yCustomcolorsliders_SliderB" , yakuiVar.Colors.unitframes.player.b/256)
		WindowSetShowing("yCustomcolorsliders_SliderA" , false)
		LabelSetText("yCustomcolorsliders_BGRed", L"Red: "..yakuiVar.Colors.unitframes.hostile.r)
		LabelSetText("yCustomcolorsliders_BGGreen", L"Green: "..yakuiVar.Colors.unitframes.hostile.g)
		LabelSetText("yCustomcolorsliders_BGBlue", L"Blue: "..yakuiVar.Colors.unitframes.hostile.b)
		WindowSetShowing("yCustomcolorsliders_BGAlpha", false)
		SliderBarSetCurrentPosition( "yCustomcolorsliders_BGSliderR" , yakuiVar.Colors.unitframes.hostile.r/256)
		SliderBarSetCurrentPosition( "yCustomcolorsliders_BGSliderG" , yakuiVar.Colors.unitframes.hostile.g/256)
		SliderBarSetCurrentPosition( "yCustomcolorsliders_BGSliderB" , yakuiVar.Colors.unitframes.hostile.b/256)
		WindowSetShowing("yCustomcolorsliders_BGSliderA" , false)
		LabelSetText("yCustomcolorsliders_FXRed", L"Red: "..yakuiVar.Colors.unitframes.friendly.r)
		LabelSetText("yCustomcolorsliders_FXGreen", L"Green: "..yakuiVar.Colors.unitframes.friendly.g)
		LabelSetText("yCustomcolorsliders_FXBlue", L"Blue: "..yakuiVar.Colors.unitframes.friendly.b)
		WindowSetShowing("yCustomcolorsliders_FXAlpha", false)
		SliderBarSetCurrentPosition( "yCustomcolorsliders_FXSliderR" , yakuiVar.Colors.unitframes.friendly.r/256)
		SliderBarSetCurrentPosition( "yCustomcolorsliders_FXSliderG" , yakuiVar.Colors.unitframes.friendly.g/256)
		SliderBarSetCurrentPosition( "yCustomcolorsliders_FXSliderB" , yakuiVar.Colors.unitframes.friendly.b/256)
		WindowSetShowing( "yCustomcolorsliders_FXSliderA" , false)
		WindowSetShowing("yCustomcolorsliders_AlphaToggleLabel", false)
		WindowSetShowing("yCustomcolorsliders_AlphaToggle", false)
	elseif configside == 3 then
		LabelSetText("yCustomcolorsliders_Headline1", L"AP Bar:")
		LabelSetText("yCustomcolorsliders_Headline2", L"Career Bar:")
		LabelSetText("yCustomcolorsliders_Headline3", L"Castbar:")
		LabelSetText("yCustomcolorsliders_Red", L"Red: "..yakuiVar.Colors.unitframes.apbar.r)
		LabelSetText("yCustomcolorsliders_Green", L"Green: "..yakuiVar.Colors.unitframes.apbar.g)
		LabelSetText("yCustomcolorsliders_Blue", L"Blue: "..yakuiVar.Colors.unitframes.apbar.b)
		WindowSetShowing("yCustomcolorsliders_Alpha", false)
		SliderBarSetCurrentPosition( "yCustomcolorsliders_SliderR" , yakuiVar.Colors.unitframes.apbar.r/256)
		SliderBarSetCurrentPosition( "yCustomcolorsliders_SliderG" , yakuiVar.Colors.unitframes.apbar.g/256)
		SliderBarSetCurrentPosition( "yCustomcolorsliders_SliderB" , yakuiVar.Colors.unitframes.apbar.b/256)
		WindowSetShowing("yCustomcolorsliders_SliderA" , false)
		LabelSetText("yCustomcolorsliders_BGRed", L"Red: "..yakuiVar.Colors.unitframes.careerbar.r)
		LabelSetText("yCustomcolorsliders_BGGreen", L"Green: "..yakuiVar.Colors.unitframes.careerbar.g)
		LabelSetText("yCustomcolorsliders_BGBlue", L"Blue: "..yakuiVar.Colors.unitframes.careerbar.b)
		WindowSetShowing("yCustomcolorsliders_BGAlpha", false)
		SliderBarSetCurrentPosition( "yCustomcolorsliders_BGSliderR" , yakuiVar.Colors.unitframes.careerbar.r/256)
		SliderBarSetCurrentPosition( "yCustomcolorsliders_BGSliderG" , yakuiVar.Colors.unitframes.careerbar.g/256)
		SliderBarSetCurrentPosition( "yCustomcolorsliders_BGSliderB" , yakuiVar.Colors.unitframes.careerbar.b/256)
		WindowSetShowing("yCustomcolorsliders_BGSliderA" , false)
		LabelSetText("yCustomcolorsliders_FXRed", L"Red: "..yakuiVar.Colors.unitframes.castbar.r)
		LabelSetText("yCustomcolorsliders_FXGreen", L"Green: "..yakuiVar.Colors.unitframes.castbar.g)
		LabelSetText("yCustomcolorsliders_FXBlue", L"Blue: "..yakuiVar.Colors.unitframes.castbar.b)
		WindowSetShowing("yCustomcolorsliders_FXAlpha", false)
		SliderBarSetCurrentPosition( "yCustomcolorsliders_FXSliderR" , yakuiVar.Colors.unitframes.castbar.r/256)
		SliderBarSetCurrentPosition( "yCustomcolorsliders_FXSliderG" , yakuiVar.Colors.unitframes.castbar.g/256)
		SliderBarSetCurrentPosition( "yCustomcolorsliders_FXSliderB" , yakuiVar.Colors.unitframes.castbar.b/256)
		WindowSetShowing( "yCustomcolorsliders_FXSliderA" , false)
		WindowSetShowing("yCustomcolorsliders_AlphaToggleLabel", false)
		WindowSetShowing("yCustomcolorsliders_AlphaToggle", false)	
	end
	if yakuiVar.Colors.col == "Preset1" then ComboBoxSetSelectedMenuItem ("yCustomcolorsliders_Preset", 1)
	elseif yakuiVar.Colors.col == "Preset2" then ComboBoxSetSelectedMenuItem ("yCustomcolorsliders_Preset", 2)
	elseif yakuiVar.Colors.col == "Preset3" then ComboBoxSetSelectedMenuItem ("yCustomcolorsliders_Preset", 3)
	elseif yakuiVar.Colors.col == "Preset4" then ComboBoxSetSelectedMenuItem ("yCustomcolorsliders_Preset", 4)
	elseif yakuiVar.Colors.col == "Preset5" then ComboBoxSetSelectedMenuItem ("yCustomcolorsliders_Preset", 5)
	elseif yakuiVar.Colors.col == "Preset6" then ComboBoxSetSelectedMenuItem ("yCustomcolorsliders_Preset", 6)
	else ComboBoxSetSelectedMenuItem ("yCustomcolorsliders_Preset", 7) end
	if yakuiVar.Panel.tex == "Set1" then ComboBoxSetSelectedMenuItem ("yCustomcolorsliders_TextureCombo", 1)
	elseif yakuiVar.Panel.tex == "Set2" then ComboBoxSetSelectedMenuItem ("yCustomcolorsliders_TextureCombo", 2)
	elseif yakuiVar.Panel.tex == "Set3" then ComboBoxSetSelectedMenuItem ("yCustomcolorsliders_TextureCombo", 3)
	elseif yakuiVar.Panel.tex == "Set4" then ComboBoxSetSelectedMenuItem ("yCustomcolorsliders_TextureCombo", 4)
	elseif yakuiVar.Panel.tex == "Set5" then ComboBoxSetSelectedMenuItem ("yCustomcolorsliders_TextureCombo", 5)
	end
end

function yakuiconfig.colorsliderR(pos)
	if configside == 1 then
		yakuiVar.Colors.colprintr = math.floor(255 * pos + 0.5)
	elseif configside == 2 then
		yakuiVar.Colors.unitframes.player.r  = math.floor(255 * pos + 0.5)
	elseif configside == 3 then
		yakuiVar.Colors.unitframes.apbar.r  = math.floor(255 * pos + 0.5)
	end
	WindowSetShowing("yconfigcontextmenucolorselect1Check", false)
	WindowSetShowing("yconfigcontextmenucolorselect2Check", false)
	WindowSetShowing("yconfigcontextmenucolorselect3Check", false)
	WindowSetShowing("yconfigcontextmenucolorselect4Check", false)
	WindowSetShowing("yconfigcontextmenucolorselect5Check", false)
	WindowSetShowing("yconfigcontextmenucolorselect6Check", false)
	yakuiVar.Colors.col = "Custom"
	yakui.color()
	yakuiconfig.colorsliderUpdate()
end

function yakuiconfig.colorsliderG(pos)
	if configside == 1 then
		yakuiVar.Colors.colprintg = math.floor(255 * pos + 0.5)
	elseif configside == 2 then
		yakuiVar.Colors.unitframes.player.g  = math.floor(255 * pos + 0.5)
	elseif configside == 3 then
		yakuiVar.Colors.unitframes.apbar.g  = math.floor(255 * pos + 0.5)
	end
	WindowSetShowing("yconfigcontextmenucolorselect1Check", false)
	WindowSetShowing("yconfigcontextmenucolorselect2Check", false)
	WindowSetShowing("yconfigcontextmenucolorselect3Check", false)
	WindowSetShowing("yconfigcontextmenucolorselect4Check", false)
	WindowSetShowing("yconfigcontextmenucolorselect5Check", false)
	WindowSetShowing("yconfigcontextmenucolorselect6Check", false)
	yakuiVar.Colors.col = "Custom"
	yakui.color() 
	yakuiconfig.colorsliderUpdate()
end

function yakuiconfig.colorsliderB(pos)
	if configside == 1 then
		yakuiVar.Colors.colprintb = math.floor(255 * pos + 0.5)
	elseif configside == 2 then
		yakuiVar.Colors.unitframes.player.b  = math.floor(255 * pos + 0.5)
	elseif configside == 3 then
		yakuiVar.Colors.unitframes.apbar.b  = math.floor(255 * pos + 0.5)
	end
	WindowSetShowing("yconfigcontextmenucolorselect1Check", false)
	WindowSetShowing("yconfigcontextmenucolorselect2Check", false)
	WindowSetShowing("yconfigcontextmenucolorselect3Check", false)
	WindowSetShowing("yconfigcontextmenucolorselect4Check", false)
	WindowSetShowing("yconfigcontextmenucolorselect5Check", false)
	WindowSetShowing("yconfigcontextmenucolorselect6Check", false)
	yakuiVar.Colors.col = "Custom"
	yakui.color() 
	yakuiconfig.colorsliderUpdate()
end

function yakuiconfig.bgcolorsliderR(pos)
	if configside == 1 then
		yakuiVar.Colors.background.r = math.floor(255 * pos + 0.5)
	elseif configside == 2 then
		yakuiVar.Colors.unitframes.hostile.r = math.floor(255 * pos + 0.5)
	elseif configside == 3 then
		yakuiVar.Colors.unitframes.careerbar.r = math.floor(255 * pos + 0.5)
	end
	WindowSetShowing("yconfigcontextmenucolorselect1Check", false)
	WindowSetShowing("yconfigcontextmenucolorselect2Check", false)
	WindowSetShowing("yconfigcontextmenucolorselect3Check", false)
	WindowSetShowing("yconfigcontextmenucolorselect4Check", false)
	WindowSetShowing("yconfigcontextmenucolorselect5Check", false)
	WindowSetShowing("yconfigcontextmenucolorselect6Check", false)
	yakuiVar.Colors.col = "Custom"
	yakuiconfig.colorsliderUpdate()
	yakui.color()
end

function yakuiconfig.bgcolorsliderG(pos)
	if configside == 1 then
		yakuiVar.Colors.background.g = math.floor(255 * pos + 0.5)
	elseif configside == 2 then
		yakuiVar.Colors.unitframes.hostile.g = math.floor(255 * pos + 0.5)
	elseif configside == 3 then
		yakuiVar.Colors.unitframes.careerbar.g = math.floor(255 * pos + 0.5)
	end
	WindowSetShowing("yconfigcontextmenucolorselect1Check", false)
	WindowSetShowing("yconfigcontextmenucolorselect2Check", false)
	WindowSetShowing("yconfigcontextmenucolorselect3Check", false)
	WindowSetShowing("yconfigcontextmenucolorselect4Check", false)
	WindowSetShowing("yconfigcontextmenucolorselect5Check", false)
	WindowSetShowing("yconfigcontextmenucolorselect6Check", false)
	yakuiVar.Colors.col = "Custom"
	yakuiconfig.colorsliderUpdate()
	yakui.color() 
end

function yakuiconfig.bgcolorsliderB(pos)
	if configside == 1 then
		yakuiVar.Colors.background.b = math.floor(255 * pos + 0.5)
	elseif configside == 2 then
		yakuiVar.Colors.unitframes.hostile.b = math.floor(255 * pos + 0.5)
	elseif configside == 3 then
		yakuiVar.Colors.unitframes.careerbar.b = math.floor(255 * pos + 0.5)
	end
	WindowSetShowing("yconfigcontextmenucolorselect1Check", false)
	WindowSetShowing("yconfigcontextmenucolorselect2Check", false)
	WindowSetShowing("yconfigcontextmenucolorselect3Check", false)
	WindowSetShowing("yconfigcontextmenucolorselect4Check", false)
	WindowSetShowing("yconfigcontextmenucolorselect5Check", false)
	WindowSetShowing("yconfigcontextmenucolorselect6Check", false)
	yakuiVar.Colors.col = "Custom"
	yakuiconfig.colorsliderUpdate()
	yakui.color()
end

function yakuiconfig.fxcolorsliderR(pos)
	if configside == 1 then
		yakuiVar.Colors.fx.r = math.floor(255 * pos + 0.5)
	elseif configside == 2 then
		yakuiVar.Colors.unitframes.friendly.r = math.floor(255 * pos + 0.5)
	elseif configside == 3 then
		yakuiVar.Colors.unitframes.castbar.r = math.floor(255 * pos + 0.5)
	end
	WindowSetShowing("yconfigcontextmenucolorselect1Check", false)
	WindowSetShowing("yconfigcontextmenucolorselect2Check", false)
	WindowSetShowing("yconfigcontextmenucolorselect3Check", false)
	WindowSetShowing("yconfigcontextmenucolorselect4Check", false)
	WindowSetShowing("yconfigcontextmenucolorselect5Check", false)
	WindowSetShowing("yconfigcontextmenucolorselect6Check", false)
	yakuiVar.Colors.col = "Custom"
	yakuiconfig.colorsliderUpdate()
	yakui.color()
end

function yakuiconfig.fxcolorsliderG(pos)
	if configside == 1 then
		yakuiVar.Colors.fx.g = math.floor(255 * pos + 0.5)
	elseif configside == 2 then
		yakuiVar.Colors.unitframes.friendly.g = math.floor(255 * pos + 0.5)
	elseif configside == 3 then
		yakuiVar.Colors.unitframes.castbar.g = math.floor(255 * pos + 0.5)
	end
	WindowSetShowing("yconfigcontextmenucolorselect1Check", false)
	WindowSetShowing("yconfigcontextmenucolorselect2Check", false)
	WindowSetShowing("yconfigcontextmenucolorselect3Check", false)
	WindowSetShowing("yconfigcontextmenucolorselect4Check", false)
	WindowSetShowing("yconfigcontextmenucolorselect5Check", false)
	WindowSetShowing("yconfigcontextmenucolorselect6Check", false)
	yakuiVar.Colors.col = "Custom"
	yakuiconfig.colorsliderUpdate()
	yakui.color() 
end

function yakuiconfig.fxcolorsliderB(pos)
	if configside == 1 then
		yakuiVar.Colors.fx.b = math.floor(255 * pos + 0.5)
	elseif configside == 2 then
		yakuiVar.Colors.unitframes.friendly.b = math.floor(255 * pos + 0.5)
	elseif configside == 3 then
		yakuiVar.Colors.unitframes.castbar.b = math.floor(255 * pos + 0.5)
	end
	WindowSetShowing("yconfigcontextmenucolorselect1Check", false)
	WindowSetShowing("yconfigcontextmenucolorselect2Check", false)
	WindowSetShowing("yconfigcontextmenucolorselect3Check", false)
	WindowSetShowing("yconfigcontextmenucolorselect4Check", false)
	WindowSetShowing("yconfigcontextmenucolorselect5Check", false)
	WindowSetShowing("yconfigcontextmenucolorselect6Check", false)
	yakuiVar.Colors.col = "Custom"
	yakuiconfig.colorsliderUpdate()
	yakui.color()
end


function yakuiconfig.actionbartextureselect1()
	WindowSetShowing("yconfigcontextmenuactionbartextureselect1Check", true)
	WindowSetShowing("yconfigcontextmenuactionbartextureselect2Check", false)
	WindowSetShowing("yconfigcontextmenuactionbartextureselect3Check", false)
	WindowSetShowing("yconfigcontextmenuactionbartextureselect4Check", false)
	yakuiVar.Actionbar.usetexture = true
	yakuiVar.Actionbar.texture = 1
	InterfaceCore.ReloadUI()
end

function yakuiconfig.actionbartextureselect2()
	WindowSetShowing("yconfigcontextmenuactionbartextureselect1Check", false)
	WindowSetShowing("yconfigcontextmenuactionbartextureselect2Check", true)
	WindowSetShowing("yconfigcontextmenuactionbartextureselect3Check", false)
	WindowSetShowing("yconfigcontextmenuactionbartextureselect4Check", false)
	yakuiVar.Actionbar.usetexture = true
	yakuiVar.Actionbar.texture = 2
	InterfaceCore.ReloadUI()
end

function yakuiconfig.actionbartextureselect3()
	WindowSetShowing("yconfigcontextmenuactionbartextureselect1Check", false)
	WindowSetShowing("yconfigcontextmenuactionbartextureselect2Check", false)
	WindowSetShowing("yconfigcontextmenuactionbartextureselect3Check", true)
	WindowSetShowing("yconfigcontextmenuactionbartextureselect4Check", false)
	yakuiVar.Actionbar.usetexture = true
	yakuiVar.Actionbar.texture = 3
	InterfaceCore.ReloadUI()
end

function yakuiconfig.actionbartextureselect4()
	WindowSetShowing("yconfigcontextmenuactionbartextureselect1Check", false)
	WindowSetShowing("yconfigcontextmenuactionbartextureselect2Check", false)
	WindowSetShowing("yconfigcontextmenuactionbartextureselect3Check", false)
	WindowSetShowing("yconfigcontextmenuactionbartextureselect4Check", true)
	yakuiVar.Actionbar.usetexture = false
	InterfaceCore.ReloadUI()
end
