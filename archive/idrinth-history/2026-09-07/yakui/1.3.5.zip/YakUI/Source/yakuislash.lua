-- yakuislash.lua build20100524

yakuislash = {}

booltowstring={[false]=L"Off",[true]=L"On"}

function yakuislash.init()
	LibSlash.RegisterWSlashCmd("yui", function(args) yakuislash.yui(args) end)
	LibSlash.RegisterWSlashCmd("rl", function(args) yakui.reloadui(args) end)
end

function yakuislash.yui(args)
	local opt, val = args:match(L"([a-z0-9]+)[ ]?(.*)")

--version
	if opt == nil then
			print("")
			TextLogAddEntry("Chat", SystemData.ChatLogFilters.SHOUT, towstring(yakuiVar.ver))
			print("For usage of the chat commands enter /yui help .")
	end
	
	if opt == L"ver" then
			print("")
			local screenWidth, screenHeight = GetScreenResolution()
			TextLogAddEntry("Chat", SystemData.ChatLogFilters.SHOUT, towstring(yakuiVar.ver))
			print("UI Scale: "..InterfaceCore.GetScale().." | Resolution: "..screenWidth.."x"..screenHeight)
	end

	if opt == L"igeffigy" then
		yakuiVar.Huduf.ignore = not yakuiVar.Huduf.ignore
		if yakuiVar.Huduf.ignore == true then print("YakUI will no longer change Effigy settings...")
		else print("YakUI will change Effigy settings again. Caution! If you changed settings manually, this may result in errors or mixed up frames. Consider reloading the YakUI_135 layout in Effigy before proceeding.")
		end
	end

	if opt == L"counter" then
		print(L"The Interface has been loaded "..yakuiVar.counter..L" times after the installation.")
	end
	
--help
	if opt == L"help" then
		print("")
		TextLogAddEntry("Chat", SystemData.ChatLogFilters.SHOUT, towstring(yakuiVar.ver))
		print("syntax: /yui <command> <value>")
		print("")
		print("usable commands:")
		print("help   - shows help")
		print("config   - opens the configuration")
		print("ver   - shows YakUI version and settings")
		print("scale   - scales the panel textures")
		print("igeffigy    - YakUI will no longer change Effify settings")
		print("")
	end		

-- open menu
	if opt ==L"config" then yakuiconfig.toggle() end

-- Scaling
	if opt == L"scale" then
		if val == L"" then
				print("")
				TextLogAddEntry("Chat", SystemData.ChatLogFilters.SHOUT, towstring(yakuiVar.ver))
				print("This function toggles the panel scaling.")
				print("Syntax: /yui scale <value>")
				print("usable values: adjust, 0.5 - 1.5")
		else
		if val == L"adjust" then
		WindowSetDimensions("YBorder",math.ceil((panelxscale*(1/InterfaceCore.GetScale()))*(1/yakuiVar.Panel.scale)),math.ceil((panelyscale*(1/InterfaceCore.GetScale()))*(1/yakuiVar.Panel.scale)))
		WindowSetDimensions("YFX",math.ceil((panelxscale*(1/InterfaceCore.GetScale()))*(1/yakuiVar.Panel.scale)),math.ceil((panelyscale*(1/InterfaceCore.GetScale()))*(1/yakuiVar.Panel.scale)))
		WindowSetDimensions("YPanel",math.ceil((panelxscale*(1/InterfaceCore.GetScale()))*(1/yakuiVar.Panel.scale)),math.ceil((panelyscale*(1/InterfaceCore.GetScale()))*(1/yakuiVar.Panel.scale)))
		else
			yakuiVar.Panel.scale = val
			yakuiVar.Panel.scale = tonumber(yakuiVar.Panel.scale)
			if yakuiVar.Panel.scale > 1.5 then yakuiVar.Panel.scale = 1.5 end
			if yakuiVar.Panel.scale < 0.5 then yakuiVar.Panel.scale = 0.5 end
			WindowSetDimensions("YBorder",math.ceil((panelxscale*(1/InterfaceCore.GetScale()))*(1/yakuiVar.Panel.scale)),math.ceil((panelyscale*(1/InterfaceCore.GetScale()))*(1/yakuiVar.Panel.scale)))
			WindowSetDimensions("YPanel",math.ceil((panelxscale*(1/InterfaceCore.GetScale()))*(1/yakuiVar.Panel.scale)),math.ceil((panelyscale*(1/InterfaceCore.GetScale()))*(1/yakuiVar.Panel.scale)))
			WindowSetDimensions("YFX",math.ceil((panelxscale*(1/InterfaceCore.GetScale()))*(1/yakuiVar.Panel.scale)),math.ceil((panelyscale*(1/InterfaceCore.GetScale()))*(1/yakuiVar.Panel.scale)))
			WindowSetDimensions("YMPanel",math.ceil((mwmxscale*(1/InterfaceCore.GetScale()))*(1/yakuiVar.Panel.scale)),math.ceil((mwmyscale*(1/InterfaceCore.GetScale()))*(1/yakuiVar.Panel.scale)))
			WindowSetDimensions("YMBorder",math.ceil((mwmxscale*(1/InterfaceCore.GetScale()))*(1/yakuiVar.Panel.scale)),math.ceil((mwmyscale*(1/InterfaceCore.GetScale()))*(1/yakuiVar.Panel.scale)))
			WindowSetDimensions("YMFX",math.ceil((mwmxscale*(1/InterfaceCore.GetScale()))*(1/yakuiVar.Panel.scale)),math.ceil((mwmyscale*(1/InterfaceCore.GetScale()))*(1/yakuiVar.Panel.scale)))
			WindowClearAnchors("YMPanel")
			WindowClearAnchors("YMBorder")
			WindowClearAnchors("YMFX")
			WindowAddAnchor("YMPanel","bottomleft","Root","bottomleft",math.ceil((mwmxanch*(1/InterfaceCore.GetScale()))*(1/yakuiVar.Panel.scale)),math.ceil((mwmyanch*(1/InterfaceCore.GetScale()))*(1/yakuiVar.Panel.scale)))
			WindowAddAnchor("YMBorder","bottomleft","Root","bottomleft",math.ceil((mwmxanch*(1/InterfaceCore.GetScale()))*(1/yakuiVar.Panel.scale)),math.ceil((mwmyanch*(1/InterfaceCore.GetScale()))*(1/yakuiVar.Panel.scale)))
			WindowAddAnchor("YMFX","bottomleft","Root","bottomleft",math.ceil((mwmxanch*(1/InterfaceCore.GetScale()))*(1/yakuiVar.Panel.scale)),math.ceil((mwmyanch*(1/InterfaceCore.GetScale()))*(1/yakuiVar.Panel.scale)))
		end
		if yakuiVar.Panel.config == "on" then
			yuiconfighide()
			yuiconfigshow()
		end
		print(L"Scale: "..yakuiVar.Panel.scale)
		print(L"X: "..math.ceil(panelxscale*(1/yakuiVar.Panel.scale)))
		print(L"Y: "..math.ceil(panelyscale*(1/yakuiVar.Panel.scale)))
		end
	end
end
