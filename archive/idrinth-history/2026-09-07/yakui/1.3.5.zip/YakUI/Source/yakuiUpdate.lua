-- yakuiUpdate.lua build20100524

yakuiUpdate = {}

function yakuiUpdate.load()
	-- variables
	if yakuiVar == nil then 
		TextLogAddEntry("Chat", SystemData.ChatLogFilters.SAY, L"Warning!!! No YakUI variables found!")	
	else
		if yakuiVar.counter == nil then yakuiVar.counter = 0 end
		yakuiVar.counter = yakuiVar.counter + 1
	end
end


function yakuiUpdate.afterloading()
		WindowUnregisterEventHandler("EA_Window_CurrentEvents", SystemData.Events.LOADING_END, "EA_Window_CurrentEvents.OnLoadingEnd" )
		KwestorTracker.NubLButtonUp()
		if yakuifirststeps then 
			if yakuiVar.firststepsopen == nil then yakuiVar.firststepsopen = false end
			yakuifirststeps.show() 
		end
		if DK_Config and DK_Config.OnUpdateSettingButton then
			DK_Config.ToggleSetting( "MiscHTScore" , 0 )
		end
		RegisterEventHandler(SystemData.Events.UPDATE_PROCESSED, "yakuiUpdate.afterloading2")
end

function yakuiUpdate.afterloading2()
		UnregisterEventHandler(SystemData.Events.UPDATE_PROCESSED, "yakuiUpdate.afterloading2")
end