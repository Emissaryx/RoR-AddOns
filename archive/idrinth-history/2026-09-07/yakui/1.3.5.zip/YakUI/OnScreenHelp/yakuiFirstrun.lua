-- yakuiFirstrun.lua build20100524

function yakuiFirstrunInit()
	yakuiFirstunDelay()
end

local WINDOWNAME = "EA_Window_UiProfileIntroDialog"
local firstrundelay
local scale
local scalemath
local resolution
local initialresolution = (InterfaceCore.GetScale()/InterfaceCore.GetResolutionScale())


function yakuiFirstunDelay()
	firstrundelay = 1
	RegisterEventHandler(SystemData.Events.UPDATE_PROCESSED, "yakuiFirstrunDelay2")
end

function yakuiFirstrunDelay2()
	firstrundelay = firstrundelay + 1
	if firstrundelay == 50 then
		if not yakuiVar then
		UnregisterEventHandler(SystemData.Events.UPDATE_PROCESSED, "yakuiFirstrunDelay2")
			RegisterEventHandler(SystemData.Events.USER_SETTINGS_CHANGED , "yakuiFirstrunUpdatelabels")
			EA_Window_UiProfileIntroDialog.Initialize =
			function(...)
				LabelSetText( WINDOWNAME.."TitleBarText", L"YakUI Installation:" )           
				LabelSetText( WINDOWNAME.."Instructions", L"Welcome to the YakUI Installation. In the left / right corner of this window your current resolution / UI-scale is displayed. The color indicates if settings are compatible with YakUI. Click on the labels to open the settings menu / toggle usable UI-scales. Change settings if needed, then use the Import-button and select the profile according to those settings." ) 
				ButtonSetText( WINDOWNAME.."OkayButton", L"Import" )   
				ButtonSetText( WINDOWNAME.."CancelButton", L"Cancel")
			end
			oldEA_Window_UiProfileIntroDialogOnOkayButton = EA_Window_UiProfileIntroDialog.OnOkayButton
			EA_Window_UiProfileIntroDialog.OnOkayButton =
			function(...)
				oldEA_Window_UiProfileIntroDialogOnOkayButton()
				WindowClearAnchors("yakuiFirstrunLabels")
				WindowAddAnchor("yakuiFirstrunLabels", "bottomleft", "EA_Window_UiProfileImport", "bottomleft", 233, -24)
				WindowSetParent("yakuiFirstrunLabels","EA_Window_UiProfileImport")
				WindowClearAnchors("yakuiFirstrunInstall")
				WindowAddAnchor("yakuiFirstrunInstall", "bottomleft", "EA_Window_UiProfileImport", "bottomleft", 3, -24)
				WindowSetParent("yakuiFirstrunInstall","EA_Window_UiProfileImport")
			end
			WindowSetShowing("UiModVersionMismatchWindow", false)
			DestroyWindow( WINDOWNAME )
			CreateWindow( WINDOWNAME, true )

			CreateWindow("yakuiFirstrunLabels", true)
			CreateWindow("yakuiFirstrunInstall", true)

			WindowClearAnchors("yakuiFirstrunLabels")
			WindowAddAnchor("yakuiFirstrunLabels", "bottomleft", "EA_Window_UiProfileIntroDialog", "bottomleft", 458, -24)
			WindowSetParent("yakuiFirstrunLabels","EA_Window_UiProfileIntroDialog")
			WindowClearAnchors("yakuiFirstrunInstall")
			WindowAddAnchor("yakuiFirstrunInstall", "bottomleft", "EA_Window_UiProfileIntroDialog", "bottomleft", 26, -24)
			WindowSetParent("yakuiFirstrunInstall","EA_Window_UiProfileIntroDialog")
			yakuiFirstrunUpdatelabels()
		end
	end
end

function yakuiFirstrunUpdatelabels()
			local scalecheck
			local resocheck
			scalemath = (InterfaceCore.GetScale()/InterfaceCore.GetResolutionScale())
			resolution = towstring(SystemData.screenResolution.x)..L"x"..towstring(SystemData.screenResolution.y)
			if scalemath == 0.75 then scale = L"0.75"
			elseif scalemath == 1 then scale = L"1.00"
			else
				scale = towstring(scalemath)
				scale = wstring.format( L"%0.2f", scale )
			end
			LabelSetText("yakuiFirstrunLabels_Scale", scale)
			if		(resolution == L"1920x1200")
				or	(resolution == L"1920x1080")
				or	(resolution == L"1680x1050")
				or	(resolution == L"1600x1200")
				or	(resolution == L"1440x900")
				or	(resolution == L"1360x768")
				or	(resolution == L"1280x1024")
				or	(resolution == L"1600x900")
			then 
				LabelSetTextColor("yakuiFirstrunInstall_Install", 64, 192, 64)
				resocheck = true
			else
				LabelSetTextColor("yakuiFirstrunInstall_Install", 192, 32, 0)
				resocheck = false
			end
			LabelSetText("yakuiFirstrunInstall_Install", resolution)
			if (scale == L"0.75") and (resolution == L"1920x1200") then scalecheck = true 
			elseif (scale == L"0.75") and (resolution == L"1920x1080") then scalecheck = true
			elseif (scale == L"0.75") and (resolution == L"1680x1050") then scalecheck = true
			elseif (scale == L"0.75") and (resolution == L"1440x900") then scalecheck = true
			elseif (scale == L"1.00") and (resolution == L"1440x900") then scalecheck = true
			elseif (scale == L"0.75") and (resolution == L"1600x1200") then scalecheck = true
			elseif (scale == L"1.00") and (resolution == L"1360x768") then scalecheck = true
			elseif (scale == L"0.75") and (resolution == L"1280x1024") then scalecheck = true
			elseif (scale == L"0.75") and (resolution == L"1600x900") then scalecheck = true
			else scalecheck = false end
			if (scalecheck == true) then LabelSetTextColor("yakuiFirstrunLabels_Scale", 64, 192, 64) else LabelSetTextColor("yakuiFirstrunLabels_Scale", 192, 32, 0) end
			
			if (scalecheck == true) and (resocheck == true) then
				LabelSetText( WINDOWNAME.."Instructions2", L"Note: The UI scaling and resolution are global settings, so using different scalings or resolutions on different characters will mess the layouts!") 
			else
				LabelSetText( WINDOWNAME.."Instructions2", L"Note: There is no YakUI profile available for your current resolution and/or UI-scale!") 
			end
end

function yakuiFirstrunScaleBtn()
				if scale == L"0.75" then 
					scale = L"1.00"
					ScaleInterface(1)
					SystemData.Settings.Interface.globalUiScale = 1
				elseif scale == L"1.00" then
					if initialresolution == 1 then 
						scale = L"0.75"
						ScaleInterface(0.75)
						SystemData.Settings.Interface.globalUiScale = 0.75
					else
						scale = towstring(initialresolution)
						scale = wstring.format( L"%0.2f", scale )
						ScaleInterface(initialresolution)
						SystemData.Settings.Interface.globalUiScale = initialresolution
					end
				else
					scale = L"0.75"
					ScaleInterface(0.75)
					SystemData.Settings.Interface.globalUiScale = 0.75
				end
				if (scale==L"1.00") or (scale==L"0.75") then LabelSetTextColor("yakuiFirstrunLabels_Scale", 64, 192, 64) else LabelSetTextColor("yakuiFirstrunLabels_Scale", 192, 32, 0) end
				LabelSetText("yakuiFirstrunLabels_Scale", scale)
				if (scale == L"1.00") or (scale == L"0.75") then 
					LabelSetText( WINDOWNAME.."Instructions2", L"Note: The UI scaling is a global setting, so using different scaling settings on different characters will mix up the layouts!") 
				else
					LabelSetText( WINDOWNAME.."Instructions2", L"Note: There is no YakUI profile available for your current scaling. Use the Scale button to toggle scaling!") 
				end
				SettingsWindowTabbed.UpdateSettings()
				BroadcastEvent( SystemData.Events.USER_SETTINGS_CHANGED )
end


function yakuiFirstrunInstallBtn()
	WindowUtils.ToggleShowing( "SettingsWindowTabbed" )
	SettingsWindowTabbed.SelectTab(2)
end
