local Enemy = Enemy
local g = {}

local CHECK_INTERVAL_SECONDS = 5
local PARTY_WINDOW_NAME = "GroupWindow"
local WARBAND_WINDOW_NAMES =
{
	"BattlegroupHUDGroup1LayoutWindow",
	"BattlegroupHUDGroup2LayoutWindow",
	"BattlegroupHUDGroup3LayoutWindow",
	"BattlegroupHUDGroup4LayoutWindow"
}

local PARTY_HANDLERS =
{
	{ SystemData.Events.GROUP_UPDATED, "GroupWindow.OnGroupUpdated" },
	{ SystemData.Events.BATTLEGROUP_UPDATED, "GroupWindow.OnGroupUpdated" },
	{ SystemData.Events.GROUP_STATUS_UPDATED, "GroupWindow.OnStatusUpdated" },
	{ SystemData.Events.GROUP_EFFECTS_UPDATED, "GroupWindow.OnEffectsUpdated" },
	{ SystemData.Events.GROUP_PLAYER_ADDED, "GroupWindow.OnGroupPlayerAdded" },
	{ SystemData.Events.SCENARIO_BEGIN, "GroupWindow.OnScenarioBegin" },
	{ SystemData.Events.CITY_SCENARIO_BEGIN, "GroupWindow.OnScenarioBegin" },
	{ SystemData.Events.SCENARIO_END, "GroupWindow.OnScenarioEnd" },
	{ SystemData.Events.CITY_SCENARIO_END, "GroupWindow.OnScenarioEnd" },
	{ SystemData.Events.SCENARIO_GROUP_JOIN, "GroupWindow.OnScenarioGroupJoin" },
	{ SystemData.Events.SCENARIO_GROUP_LEAVE, "GroupWindow.OnScenarioGroupLeave" }
}

local WARBAND_HANDLERS =
{
	{ SystemData.Events.SCENARIO_BEGIN, "BattlegroupHUD.OnScenarioBegin" },
	{ SystemData.Events.CITY_SCENARIO_BEGIN, "BattlegroupHUD.OnScenarioBegin" },
	{ SystemData.Events.SCENARIO_END, "BattlegroupHUD.OnScenarioEnd" },
	{ SystemData.Events.CITY_SCENARIO_END, "BattlegroupHUD.OnScenarioEnd" },
	{ SystemData.Events.BATTLEGROUP_UPDATED, "BattlegroupHUD.Update" },
	{ SystemData.Events.BATTLEGROUP_MEMBER_UPDATED, "BattlegroupHUD.SingleMemberUpdate" }
}

local function WindowExists (windowName)
	if (DoesWindowExist) then return DoesWindowExist (windowName) end
	return true
end

local function IsLayoutWindowRegistered (windowName)
	if (not LayoutEditor or not LayoutEditor.windowsList) then return false end
	return LayoutEditor.windowsList[windowName] ~= nil
end

local function IsLayoutWindowUserHidden (windowName)
	if (not WindowExists (windowName)) then return false end

	if (LayoutEditor and LayoutEditor.windowsList)
	then
		local window_data = LayoutEditor.windowsList[windowName]
		return window_data ~= nil and window_data.isUserHidden == true
	end

	if (LayoutEditor and LayoutEditor.IsWindowUserHidden)
	then
		return LayoutEditor.IsWindowUserHidden (windowName) == true
	end

	return false
end

local function AreWarbandFramesUserHidden ()
	local registered_count = 0

	for _, window_name in ipairs (WARBAND_WINDOW_NAMES)
	do
		if (IsLayoutWindowRegistered (window_name))
		then
			registered_count = registered_count + 1
			if (not IsLayoutWindowUserHidden (window_name)) then return false end
		end
	end

	return registered_count == #WARBAND_WINDOW_NAMES
end

local function EnemyUnitFramesEnabled ()
	if (Enemy.unitFrames and Enemy.unitFrames.isPluginEnabled ~= nil) then
		return Enemy.unitFrames.isPluginEnabled == true
	end

	return Enemy.Settings and Enemy.Settings.unitFramesEnabled == true
end

local function CleanupEnabled ()
	return Enemy.Settings and Enemy.Settings.unitFramesReduceHiddenDefaultFrameUpdates == true
end

local function FeatureActive ()
	return CleanupEnabled () and EnemyUnitFramesEnabled ()
end

local function GetHiddenFramesText (party_status, warband_status)
	if (party_status and warband_status) then return "Default party/warband frames are hidden" end
	if (party_status) then return "Default party frames are hidden" end
	return "Default warband frames are hidden"
end

local function GetEventStatusText ()
	return "Enemy has disabled their default event handlers"
end

local function SetHandlersEnabled (handlers, enabled)
	for _, handler in ipairs (handlers)
	do
		if (enabled)
		then
			RegisterEventHandler (handler[1], handler[2])
		else
			UnregisterEventHandler (handler[1], handler[2])
		end
	end
end

local function RestoreDisabledHandlers ()
	if (g.partyHandlersEnabled == false)
	then
		SetHandlersEnabled (PARTY_HANDLERS, true)
		g.partyHandlersEnabled = true
	end

	if (g.warbandHandlersEnabled == false)
	then
		SetHandlersEnabled (WARBAND_HANDLERS, true)
		g.warbandHandlersEnabled = true
	end
end

local function StopRefreshTimer ()
	if (not g.refreshTimer) then return end

	g.refreshTimer:Remove ()
	g.refreshTimer = nil
end

local function StartRefreshTimer ()
	if (g.refreshTimer) then return end

	g.refreshTimer = EnemyTimer.New ("default frame event refresh", CHECK_INTERVAL_SECONDS, function ()
		Enemy.DefaultFrameEventsRefresh ()
		return false
	end)
end

local function RefreshPartyHandlers ()
	if (type (GroupWindow) ~= "table" or not IsLayoutWindowRegistered (PARTY_WINDOW_NAME)) then return end

	if (g.partyHandlersEnabled == nil) then g.partyHandlersEnabled = true end

	local user_hidden = IsLayoutWindowUserHidden (PARTY_WINDOW_NAME)
	local should_enable = not user_hidden

	if (should_enable ~= g.partyHandlersEnabled)
	then
		SetHandlersEnabled (PARTY_HANDLERS, should_enable)
		g.partyHandlersEnabled = should_enable
	end

	if (user_hidden and not should_enable)
	then
		return true
	end
end

local function RefreshWarbandHandlers ()
	if (type (BattlegroupHUD) ~= "table") then return end

	if (g.warbandHandlersEnabled == nil) then g.warbandHandlersEnabled = true end

	local user_hidden = AreWarbandFramesUserHidden ()
	local should_enable = not user_hidden

	if (should_enable ~= g.warbandHandlersEnabled)
	then
		SetHandlersEnabled (WARBAND_HANDLERS, should_enable)
		g.warbandHandlersEnabled = should_enable

		if (not should_enable) then rawset (BattlegroupHUD, "needsRefresh", false) end
	end

	if (user_hidden and not should_enable)
	then
		return true
	end
end

local function PrintStartupNotice (party_status, warband_status)
	if (not Enemy.Print or (not party_status and not warband_status)) then return end

	Enemy.Print ("Enemy unit frames are enabled. "..GetHiddenFramesText (party_status, warband_status).." in Layout Editor; "..GetEventStatusText ()..".")
end

function Enemy.DefaultFrameEventsRefresh ()
	if (not FeatureActive ())
	then
		RestoreDisabledHandlers ()
		StopRefreshTimer ()
		return nil, nil
	end

	StartRefreshTimer ()

	local party_status = RefreshPartyHandlers ()
	local warband_status = RefreshWarbandHandlers ()

	return party_status, warband_status
end

function Enemy.DefaultFrameEventsInitialize ()
	Enemy.AddEventHandler ("DefaultFrameEvents", "SettingsChanged", Enemy.DefaultFrameEventsRefresh)

	local party_status, warband_status = Enemy.DefaultFrameEventsRefresh ()
	PrintStartupNotice (party_status, warband_status)
end
