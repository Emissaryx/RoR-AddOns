local Enemy = Enemy
local pairs = pairs
local ipairs = ipairs
local min = math.min
local max = math.max
local floor = math.floor
local next = next
local GameData = GameData

local DISTANT_DISTANCE = 250
local EnemyPlayerEffectDurationThresholdSettings = nil
local EnemyPlayerEffectDurationThresholdIndicators = nil
local EnemyPlayerEffectInitialDurationThresholds = nil
local EnemyPlayerEffectCurrentDurationThresholds = nil
local EnemyPlayerEffectChecksInitialDurationPositive = false
local EnemyPlayerEffectChecksCurrentDurationPositive = false

local EnemyPlayerEffectIndexedTypeKeys =
{
	-- Keep this narrow: indexing every boolean effect flag costs more during
	-- heavy effect storms than it saves. These are the broad hot-path defaults.
	"isHealing",
	"isBuff",
	"isBlessing"
}

local CareersWithPet =
{
	[GameData.CareerLine.WHITE_LION] = true,
	[GameData.CareerLine.MAGUS] = true,
	[GameData.CareerLine.ENGINEER] = true,
	[GameData.CareerLine.SQUIG_HERDER] = true
}

--------------------------------------------------------------- EnemyPlayer class
EnemyPlayer = {}
EnemyPlayer.__index = EnemyPlayer

function EnemyPlayer.New (name)
	local obj = {}
	setmetatable (obj, EnemyPlayer)

	-- defaults
	obj.name = name
	obj.career = 0
	obj.level = 0
	obj.hp = 0
	obj.ap = 0
	obj.morale = 0
	obj.isOnline = true
	obj.isDistant = false
	obj.isGroupLeader = false
	obj.worldObjectId = 0
	obj.zoneId = 0
	obj.distance = 0

	obj.isSelected = false
	obj.isLOS = false

	obj.isInPlayerGroup = false
	obj.isSelf = false

	obj.pet = nil

	obj.effects = {}
	obj.effectsByAbilityId = {}
	obj.effectsByType = {}

	return obj
end


local function RemoveIndexedEffect (player, index)
	local oldEffect = player.effects[index]
	local abilityId = oldEffect and oldEffect.abilityId
	local effects = abilityId and player.effectsByAbilityId and player.effectsByAbilityId[abilityId]
	if (effects)
	then
		effects[index] = nil
		if (next (effects) == nil)
		then
			player.effectsByAbilityId[abilityId] = nil
		end
	end

	for _, typeKey in ipairs (EnemyPlayerEffectIndexedTypeKeys)
	do
		if (oldEffect and oldEffect[typeKey])
		then
			effects = player.effectsByType and player.effectsByType[typeKey]
			if (effects)
			then
				effects[index] = nil
				if (next (effects) == nil)
				then
					player.effectsByType[typeKey] = nil
				end
			end
		end
	end
end


local function AddIndexedEffect (player, index, effect)
	local abilityId = effect and effect.abilityId

	if (abilityId)
	then
		player.effectsByAbilityId = player.effectsByAbilityId or {}
		player.effectsByAbilityId[abilityId] = player.effectsByAbilityId[abilityId] or {}
		player.effectsByAbilityId[abilityId][index] = effect
	end

	player.effectsByType = player.effectsByType or {}
	for _, typeKey in ipairs (EnemyPlayerEffectIndexedTypeKeys)
	do
		if (effect[typeKey])
		then
			player.effectsByType[typeKey] = player.effectsByType[typeKey] or {}
			player.effectsByType[typeKey][index] = effect
		end
	end
end

local function EnemyPlayerEffectAddDurationThreshold (thresholds, thresholdType, value)
	if (value == nil) then return end

	thresholds[#thresholds + 1] =
	{
		type = thresholdType,
		value = value
	}
end


local function EnemyPlayerEffectRefreshDurationThresholds ()
	local effectsIndicators = Enemy.Settings and Enemy.Settings.effectsIndicators
	if (EnemyPlayerEffectDurationThresholdSettings == Enemy.Settings and EnemyPlayerEffectDurationThresholdIndicators == effectsIndicators) then return end

	EnemyPlayerEffectDurationThresholdSettings = Enemy.Settings
	EnemyPlayerEffectDurationThresholdIndicators = effectsIndicators
	EnemyPlayerEffectInitialDurationThresholds = {}
	EnemyPlayerEffectCurrentDurationThresholds = {}
	EnemyPlayerEffectChecksInitialDurationPositive = false
	EnemyPlayerEffectChecksCurrentDurationPositive = false

	for _, indicator in pairs (effectsIndicators or {})
	do
		for _, filter in pairs (indicator.effectFilters or {})
		do
			if (filter.durationType == 2)
			then
				EnemyPlayerEffectChecksInitialDurationPositive = true
				EnemyPlayerEffectAddDurationThreshold (EnemyPlayerEffectInitialDurationThresholds, "min", filter.durationMin)
				EnemyPlayerEffectAddDurationThreshold (EnemyPlayerEffectInitialDurationThresholds, "max", filter.durationMax)

			elseif (filter.durationType == 4)
			then
				EnemyPlayerEffectChecksCurrentDurationPositive = true
				EnemyPlayerEffectAddDurationThreshold (EnemyPlayerEffectCurrentDurationThresholds, "min", filter.durationMin)
				EnemyPlayerEffectAddDurationThreshold (EnemyPlayerEffectCurrentDurationThresholds, "max", filter.durationMax)
			end
		end
	end
end


local function EnemyPlayerEffectCrossedDurationThreshold (oldValue, newValue, thresholds, checksPositive)
	oldValue = oldValue or 0
	newValue = newValue or 0

	if (checksPositive and ((oldValue > 0) ~= (newValue > 0))) then return true end

	for _, threshold in ipairs (thresholds or {})
	do
		if (threshold.type == "min")
		then
			if ((oldValue < threshold.value) ~= (newValue < threshold.value)) then return true end
		else
			if ((oldValue > threshold.value) ~= (newValue > threshold.value)) then return true end
		end
	end

	return false
end


local function EnemyPlayerEffectPrepareText (effect, oldEffect)
	if (effect._enemy) then return end

	if (oldEffect and oldEffect.name == effect.name and oldEffect._enemyName)
	then
		effect._enemyName = oldEffect._enemyName
	else
		effect._enemyName = Enemy.FixString (effect.name):lower ()
	end

	if (oldEffect and oldEffect.effectText == effect.effectText and oldEffect._enemyEffectText)
	then
		effect._enemyEffectText = oldEffect._enemyEffectText
	else
		effect._enemyEffectText = Enemy.FixString (effect.effectText):lower ()
	end

	effect._enemy = true
end


local function EnemyPlayerEffectPrepareTiming (effect, oldEffect)
	local oldDuration = nil
	if (
			oldEffect
			and oldEffect.abilityId == effect.abilityId
			and oldEffect.name == effect.name
			and oldEffect.effectText == effect.effectText
		)
	then
		oldDuration = oldEffect._enemyDuration
	end

	if (effect._enemyDuration)
	then
		if (not effect._enemyTimeout) then effect._enemyTimeout = Enemy.time + effect._enemyDuration end
		return
	end

	-- Preserve the first-seen duration for durationType=initial filters, but
	-- treat same-effect duration increases as refreshes so timer icons extend.
	if (oldDuration and oldEffect and effect.duration <= (oldEffect.duration or effect.duration))
	then
		effect._enemyDuration = oldDuration
		effect._enemyTimeout = oldEffect._enemyTimeout
	else
		effect._enemyDuration = max (0, effect.duration)
		effect._enemyTimeout = Enemy.time + effect._enemyDuration
		effect._enemyDurationRefreshed = oldDuration ~= nil
	end
end


local function EnemyPlayerEffectMaterialChanged (oldEffect, effect)
	-- Partial effect updates often repeat the same visible row many times per
	-- second. Only wake unit-frame indicator scans when a filter-relevant value
	-- changed or a configured duration threshold was crossed.
	if (not oldEffect) then return true end

	if (
			oldEffect.abilityId ~= effect.abilityId
			or oldEffect.iconNum ~= effect.iconNum
			or oldEffect.name ~= effect.name
			or oldEffect.effectText ~= effect.effectText
			or oldEffect.isBuff ~= effect.isBuff
			or oldEffect.isBlessing ~= effect.isBlessing
			or oldEffect.isHealing ~= effect.isHealing
			or oldEffect.isDefensive ~= effect.isDefensive
			or oldEffect.isDebuff ~= effect.isDebuff
			or oldEffect.isOffensive ~= effect.isOffensive
			or oldEffect.isDamaging ~= effect.isDamaging
			or oldEffect.isAilment ~= effect.isAilment
			or oldEffect.isHex ~= effect.isHex
			or oldEffect.isCurse ~= effect.isCurse
			or oldEffect.isStatsBuff ~= effect.isStatsBuff
			or oldEffect.isGranted ~= effect.isGranted
			or oldEffect.isPassive ~= effect.isPassive
			or oldEffect.permanentUntilDispelled ~= effect.permanentUntilDispelled
			or oldEffect.castByPlayer ~= effect.castByPlayer
			or oldEffect.stackCount ~= effect.stackCount
		)
	then
		return true
	end

	EnemyPlayerEffectRefreshDurationThresholds ()
	if (effect._enemyDurationRefreshed) then return true end

	return EnemyPlayerEffectCrossedDurationThreshold (oldEffect._enemyDuration, effect._enemyDuration, EnemyPlayerEffectInitialDurationThresholds, EnemyPlayerEffectChecksInitialDurationPositive)
		or EnemyPlayerEffectCrossedDurationThreshold (oldEffect.duration, effect.duration, EnemyPlayerEffectCurrentDurationThresholds, EnemyPlayerEffectChecksCurrentDurationPositive)
end


local function EnemyPlayerEffectUpdateStoredTiming (oldEffect, effect)
	oldEffect.duration = effect.duration
	oldEffect._enemyDuration = effect._enemyDuration
	oldEffect._enemyTimeout = effect._enemyTimeout
end


function EnemyPlayer:IsMainAssist ()

	local main_assist_member = PartyUtils.GetWarbandMainAssist ()
    local main_assist_name = nil

    if (main_assist_member)
    then
			main_assist_name = Enemy.FixString (main_assist_member.name)
    end

	return self.name == main_assist_name
end


function EnemyPlayer:IsValid ()
	return self.name ~= nil and self.name ~= L"" and self.career ~= 0
end


function EnemyPlayer:IsInGroup ()
	return self.group ~= nil
end


function EnemyPlayer:IsSelected ()
	return self.isSelected == true
end


function EnemyPlayer:IsLOS ()
	return self.isLOS == true
end

function EnemyPlayer:SetLOS (value, silent)

	if (self.isLOS == value or self.isSelf) then return end

	self.isLOS = value

	if (not silent) then Enemy.TriggerEvent ("GroupsPlayerUpdated", self) end
end

function EnemyPlayer:SetSelected (value)

	self.isSelected = value

	if (not self.isSelected and not self.isDistant)
	then
		self:SetLOS (false)
	end
end


function EnemyPlayer:SetDistant (value)

	if (self.isDistant == value or self.isSelf) then return end

	self.isDistant = value

	if (not self.isSelected and not self.isDistant)
	then
		self:SetLOS (false, true)
	end

	Enemy.TriggerEvent ("GroupsPlayerUpdated", self)
end


function EnemyPlayer:SetDistance (value)

	if (self.distance == value or self.isSelf) then return end

	self.distance = floor (0.5 + value)
	Enemy.TriggerEvent ("GroupsPlayerDistanceUpdated", self)

	self:SetDistant (value >= DISTANT_DISTANCE)
end


function EnemyPlayer:SetObjectWorldId (id)

	local old_id = self.worldObjectId
	self.worldObjectId = id

	if (old_id ~= id)
	then
		Enemy.TriggerEvent ("GroupsPlayerWorldObjectIdUpdated", self)
	end
end


function EnemyPlayer:LoadFromScenarioData (data)

	self.career = Enemy.ScenarioCareerIdToLine[data.careerId]
	self.level = data.rank
	self.hp = data.health
	self.ap = min (data.ap, 100)

	if (data.moraleLevel ~= nil)
	then
		self.morale = data.moraleLevel
	end

	self.zoneId = GameData.Player.zone or 0
	self.isGroupLeader = false
end


function EnemyPlayer:LoadFromWarbandData (data)
	self:LoadFromGroupData (data)
end


function EnemyPlayer:LoadFromGroupData (data)

	self.career = data.careerLine
	self.level = data.level
	self.hp = data.healthPercent
	self.ap = min (data.actionPointPercent, 100)

	-- Some group/warband member packets can omit moraleLevel; preserve the last
	-- known value so morale number/bar parts do not blank or error on partial updates.
	if (data.moraleLevel ~= nil)
	then
		self.morale = data.moraleLevel
	end

	self.zoneId = data.zoneNum or 0
	self:SetObjectWorldId (data.worldObjNum or 0)

	self.isOnline = data.online
	self.isGroupLeader = data.isGroupLeader

	if (CareersWithPet[self.career] and data.Pet and data.Pet.healthPercent)
	then
		self.pet =
		{
			owner = self,
			career = self.career,
			hp = data.Pet.healthPercent
		}
	else
		self.pet = nil
	end
end


function EnemyPlayer:LoadFromCurrentPlayer ()

	self.career = GameData.Player.career.line
	self.level = GameData.Player.level
	self.hp = floor (100.0 * GameData.Player.hitPoints.current / GameData.Player.hitPoints.maximum)
	self.ap = min (floor (100.0 * GameData.Player.actionPoints.current / GameData.Player.actionPoints.maximum), 100)
	self.morale = GetPlayerMoraleLevel ()

	self.zoneId = GameData.Player.zone or 0
	self.worldObjectId = GameData.Player.worldObjNum or 0

	self.isOnline = true
	self.isGroupLeader = GameData.Player.isGroupLeader
	self:SetDistant (false)

	self.isRVRFlagged = (GameData.Player.rvrZoneFlagged or GameData.Player.rvrPermaFlagged)
	self.isInCombat = GameData.Player.inCombat

	self:LoadPetFromCurrentPlayer ()
end


function EnemyPlayer:LoadPetFromCurrentPlayer ()

	if (CareersWithPet[self.career] and GameData.Player.Pet and GameData.Player.Pet.healthPercent)
	then
		self.pet =
		{
			owner = self,
			name = Enemy.FixString (GameData.Player.Pet.name),
			career = self.career,
			level = GameData.Player.Pet.level,
			hp = GameData.Player.Pet.healthPercent,
			worldObjectId = GameData.Player.Pet.objNum
		}
	else
		self.pet = nil
	end
end


function EnemyPlayer:LoadFromTarget (targetClassification, _targetId)

	self.name = Enemy.FixString (TargetInfo:UnitName (targetClassification))
	self.career = TargetInfo:UnitCareer (targetClassification)
	self.level = TargetInfo:UnitLevel (targetClassification)
	self.hp = TargetInfo:UnitHealth (targetClassification)

	self.zoneId = GameData.Player.zone or 0
	self:SetObjectWorldId (TargetInfo:UnitEntityId (targetClassification) or 0)

	self.isOnline = true
end


function EnemyPlayer:LoadEffects (data, isFullList)

	local loadEffectsChanged = isFullList == true
	local oldEffects = self.effects

	if (isFullList)
	then
		self.effects = {}
		self.effectsByAbilityId = {}
		self.effectsByType = {}
	end

	self.effectsByAbilityId = self.effectsByAbilityId or {}
	self.effectsByType = self.effectsByType or {}

	for index, effect in pairs (data)
	do
		local oldEffect = oldEffects and oldEffects[index]

		if (effect.effectIndex == nil or effect.iconNum == nil or effect.iconNum < 1)
		then
			if (oldEffect)
			then
				loadEffectsChanged = true
				if (not isFullList) then RemoveIndexedEffect (self, index) end
				self.effects[index] = nil
			end
		else
			EnemyPlayerEffectPrepareText (effect, oldEffect)
			EnemyPlayerEffectPrepareTiming (effect, oldEffect)

			if (not isFullList and oldEffect and not EnemyPlayerEffectMaterialChanged (oldEffect, effect))
			then
				EnemyPlayerEffectUpdateStoredTiming (oldEffect, effect)
			else
				loadEffectsChanged = true
				if (not isFullList) then RemoveIndexedEffect (self, index) end
				self.effects[index] = effect
				AddIndexedEffect (self, index, effect)
			end
		end
	end

	if (self.checkEffectsTimer)
	then
		self.checkEffectsTimer:Remove ()
		self.checkEffectsTimer = nil
	end

	if (self:IsInGroup () and not self.isInPlayerGroup)
	then
		-- calculate minimal duration effect
		-- also calculate timeout for effect

		local min_timeout = nil
		for _, effect in pairs (self.effects)
		do
			if (min_timeout == nil or (effect._enemyTimeout and min_timeout > effect._enemyTimeout))
			then
				min_timeout = effect._enemyTimeout
			end
		end

		if (min_timeout)
		then
			self.checkEffectsTimer = EnemyTimer.New (nil, min_timeout - Enemy.time, function (_timer, player)

				local expiredEffectsChanged = false

				for index, effect in pairs (player.effects)
				do
					if (effect._enemyTimeout and Enemy.time >= effect._enemyTimeout)
					then
						RemoveIndexedEffect (player, index)
						player.effects[index] = nil
						expiredEffectsChanged = true
					end
				end

				if (expiredEffectsChanged)
				then
					player:LoadEffects ({}, false)
					Enemy.TriggerEvent ("GroupsPlayerEffectsUpdated", player)
				end

				return true

			end, self)
		end
	end

	return loadEffectsChanged
end


function EnemyPlayer.GetExample ()

	local obj = EnemyPlayer.New (Enemy.groups.player.name)

	for k, v in pairs (Enemy.groups.player)
	do
		obj[k] = v
	end

	obj.distance = 123
	obj.isGroupLeader = true
	obj.morale = 4
	obj.isSelected = true

	return obj
end


function EnemyPlayer.GetRandomExample (group_index, index)

	local prefix = ""
	if group_index then prefix = prefix.."G:"..group_index end
	if index then prefix = prefix.."P:"..index end

	local obj = EnemyPlayer.New (towstring (Enemy.capitalize (prefix..(Enemy.GetRandomString2 (math.random (4, 15)))  )  ))

	obj.career = math.random (24)
	obj.level = math.random (40)
	obj.hp = math.random (0, 100)
	obj.ap = math.random (0, 100)
	obj.morale = math.random (0, 4)
	obj.distance = math.random (DISTANT_DISTANCE + 50)

	obj.isOnline = math.random (0, 10) ~= 5
	obj.isDistant = obj.distance >= DISTANT_DISTANCE
	obj.isGroupLeader = math.random (0, 1) == 0
	obj.isInPlayerGroup = math.random (0, 1) == 0
	obj.isSelected = math.random (0, 3) == 2
	obj.isLOS = math.random (0, 10) == 5
	obj.isSelf = obj.isInPlayerGroup and (math.random (0, 1) == 0)

	return obj
end
