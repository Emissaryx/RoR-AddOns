WBStutterLess = {}

function WBStutterLess.Initialize()
	RegisterEventHandler(	SystemData.Events.ALL_MODULES_INITIALIZED, 		"WBStutterLess.OnInitialize")
	
	-- ror_rankedleaderboard
	RegisterEventHandler(	SystemData.Events.ALL_MODULES_INITIALIZED, 		"WBStutterLess.RankedLeaderboardHook")
	
	-- friendsuggester
	UnregisterEventHandler( SystemData.Events.GROUP_UPDATED, 				"FriendSuggester.OnPartyUpdated" )
    UnregisterEventHandler( SystemData.Events.BATTLEGROUP_UPDATED, 			"FriendSuggester.OnWarbandUpdated" )
	UnregisterEventHandler( SystemData.Events.SCENARIO_POST_MODE, 			"FriendSuggester.ScenarioFinish" )
	UnregisterEventHandler( SystemData.Events.CHAT_TEXT_ARRIVED, 			"FriendSuggester.OnChatText" )
	
	-- ea_battlegrouphud
	UnregisterEventHandler( SystemData.Events.BATTLEGROUP_UPDATED, 			"BattlegroupHUD.Update" )
    UnregisterEventHandler( SystemData.Events.BATTLEGROUP_MEMBER_UPDATED, 	"BattlegroupHUD.SingleMemberUpdate" )
	
	-- ea_groupwindow
	UnregisterEventHandler( SystemData.Events.BATTLEGROUP_UPDATED, 			"GroupWindow.OnGroupUpdated")
	UnregisterEventHandler( SystemData.Events.GROUP_PLAYER_ADDED, 			"GroupWindow.OnGroupPlayerAdded") -- Buffs
	UnregisterEventHandler( SystemData.Events.GROUP_EFFECTS_UPDATED, 		"GroupWindow.OnEffectsUpdated") -- Buffs
	UnregisterEventHandler( SystemData.Events.GROUP_STATUS_UPDATED, 		"GroupWindow.OnStatusUpdated") -- HP/AP/Lvl/RvR
	
	--ea_playerassist
	UnregisterEventHandler( SystemData.Events.GROUP_UPDATED, 				"EA_Button_PlayerAssist.UpdateButtonVisibility")
    UnregisterEventHandler( SystemData.Events.BATTLEGROUP_UPDATED, 			"EA_Button_PlayerAssist.UpdateButtonVisibility")
end

function WBStutterLess.OnInitialize()
	-- friendsuggester
	WBStutterLess.FriendSuggesterHook()

	-- ea_groupwindow
	WBStutterLess.GroupWindowHook()
	
	-- ea_battlegrouphud
	WBStutterLess.BattleGroupHudHook()

	-- ea_summoningprompt
	WBStutterLess.SummoningPromptHook()
	
	-- ea_openpartywindow
	WBStutterLess.OpenPartyHook()
	
	-- ea_scenariolobbywindow
	WBStutterLess.ScenarioLobbyHook()
end

function WBStutterLess.FriendSuggesterHook()
	FriendSuggester.Data 					= {}
    FriendSuggester.Update 					= function ( dt ) end
end

function WBStutterLess.GroupWindowHook()
	if ( not PartyUtils.IsPartyActive() ) then
		GroupWindow.Buffs = {}
	end

	GroupWindow.ConditionalShow 			= function () end
	GroupWindow.OnScenarioBegin				= function () end
	GroupWindow.OnGroupPlayerAdded			= function () end
	
	GroupWindow.OnScenarioEnd				= function ()
		GroupWindow.inScenarioGroup = false
		GroupWindow.UpdateGroupMembers()
	end
	
	GroupWindow.UpdateGroupMembers			= function ()
		if ( GroupWindow.groupData == nil ) then return end
		
		GroupWindow.inWorldGroup = GroupWindow.IsMemberValid( 1 )
		
		if( GameData.Player.isInScenario or GameData.Player.isInSiege ) then
			if( GroupWindow.inScenarioGroup == false ) then
				GroupWindow.inWorldGroup = false
			end
		end
	end
end

function WBStutterLess.BattleGroupHudHook()
	BattlegroupHUD.Update 					= function () end
	BattlegroupHUD.OnUpdate 				= function ( elapsedTime ) end
	BattlegroupHUD.SingleMemberUpdate		= function ( partyIndex, memberIndex ) end
	BattlegroupHUD.AdjustStatusSettings		= function ( memberWindow, color, alpha, showBar ) end
end

function WBStutterLess.SummoningPromptHook()
	WindowUnregisterEventHandler( "EA_SummoningAcceptPrompt", 	SystemData.Events.PLAYER_COMBAT_FLAG_UPDATED )    
    WindowUnregisterEventHandler( "EA_SummoningAcceptPrompt", 	SystemData.Events.GROUP_UPDATED )
    WindowUnregisterEventHandler( "EA_SummoningAcceptPrompt", 	SystemData.Events.SUMMON_SHOW_PROMPT )
    WindowUnregisterEventHandler( "EA_SummoningAcceptPrompt", 	SystemData.Events.L_BUTTON_DOWN_PROCESSED )	
    WindowUnregisterEventHandler( "EA_SummoningAcceptPrompt", 	SystemData.Events.PLAYER_IS_BEING_THROWN ) 
end

function WBStutterLess.OpenPartyHook()
	EA_Window_OpenParty.EnableTab( 4 )
	EA_Window_OpenParty.UpdateManageTabDisable 	= function () end
	
	WindowUnregisterEventHandler( "EA_Window_OpenPartyFlyOut", 	SystemData.Events.SOCIAL_OPENPARTY_NOTIFY )
	WindowUnregisterEventHandler( "EA_Window_OpenPartyNearby", 	SystemData.Events.GROUP_UPDATED )
	WindowUnregisterEventHandler( "EA_Window_OpenPartyNearby", 	SystemData.Events.BATTLEGROUP_UPDATED )
	WindowUnregisterEventHandler( "EA_Window_OpenPartyWorld", 	SystemData.Events.GROUP_UPDATED )
	WindowUnregisterEventHandler( "EA_Window_OpenPartyWorld", 	SystemData.Events.BATTLEGROUP_UPDATED )
	WindowUnregisterEventHandler( "EA_Window_OpenPartyManage", 	SystemData.Events.GROUP_UPDATED )
	-- UpdateManageTabDisable
    WindowUnregisterEventHandler( "EA_Window_OpenParty", 		SystemData.Events.GROUP_UPDATED ) 			
	WindowUnregisterEventHandler( "EA_Window_OpenParty", 		SystemData.Events.BATTLEGROUP_UPDATED )
end

function WBStutterLess.ScenarioLobbyHook()
    WindowUnregisterEventHandler( "EA_Window_ScenarioLobby", SystemData.Events.BATTLEGROUP_UPDATED )
end

function WBStutterLess.RankedLeaderboardHook()
	UnregisterEventHandler( SystemData.Events.BATTLEGROUP_UPDATED, 	"RoR_RankedLeaderboard.UpdateQue")
end
