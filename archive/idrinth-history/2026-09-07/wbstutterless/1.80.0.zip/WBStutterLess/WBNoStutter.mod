<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
	<UiMod name="WBStutterLess" version="1.8" date="09/12/2021" >
		<VersionSettings gameVersion="1.4.8" windowsVersion="1.0" savedVariablesVersion="1.0" />
		
		<Author name="Zapz"/>
		<Description text="Reduces stutters that happen in warband during keeps and forts" />
		
		<Files>
			<File name="WBStutterLess.lua" />
		</Files>
		
		<OnInitialize>
			<CallFunction name="WBStutterLess.Initialize" /> 
		</OnInitialize>	
		
		<Dependencies>
			<Dependency name="Enemy" />
		</Dependencies>
		
	</UiMod>
</ModuleFile>