WBStutterLess = {}

function WBStutterLess.Initialize()
	RegisterEventHandler(	SystemData.Events.ALL_MODULES_INITIALIZED, 		"WBStutterLess.init")
	RegisterEventHandler(	SystemData.Events.RELOAD_INTERFACE,				"WBStutterLess.init")
	
	-- friendsuggester
	UnregisterEventHandler( SystemData.Events.GROUP_UPDATED, 				"FriendSuggester.OnPartyUpdated" )
    UnregisterEventHandler( SystemData.Events.BATTLEGROUP_UPDATED, 			"FriendSuggester.OnWarbandUpdated" )
	UnregisterEventHandler( SystemData.Events.SCENARIO_POST_MODE, 			"FriendSuggester.ScenarioFinish" )
	UnregisterEventHandler( SystemData.Events.CHAT_TEXT_ARRIVED, 			"FriendSuggester.OnChatText" )
	
	-- ea_battlegrouphud
	UnregisterEventHandler( SystemData.Events.BATTLEGROUP_UPDATED, 			"BattlegroupHUD.Update" )
    UnregisterEventHandler( SystemData.Events.BATTLEGROUP_MEMBER_UPDATED, 	"BattlegroupHUD.SingleMemberUpdate" )
	
	-- ea_groupwindow
	UnregisterEventHandler( SystemData.Events.GROUP_UPDATED, 				"GroupWindow.OnGroupUpdated")
    UnregisterEventHandler( SystemData.Events.BATTLEGROUP_UPDATED, 			"GroupWindow.OnGroupUpdated")
	UnregisterEventHandler( SystemData.Events.GROUP_PLAYER_ADDED, 			"GroupWindow.OnGroupPlayerAdded")
	UnregisterEventHandler( SystemData.Events.GROUP_STATUS_UPDATED, 		"GroupWindow.OnStatusUpdated")
	UnregisterEventHandler( SystemData.Events.GROUP_EFFECTS_UPDATED, 		"GroupWindow.OnEffectsUpdated")

	--ror_rankedleaderboard
	RegisterEventHandler(	SystemData.Events.ALL_MODULES_INITIALIZED, 		"WBStutterLess.RankedLeaderboardHook")
end

function WBStutterLess.init()
	-- friendsuggester
	WBStutterLess.FriendSuggesterHook()
	
	-- ea_battlegrouphud
	WBStutterLess.BattleGroupHudHook()
	
	-- ea_groupwindow
	WBStutterLess.GroupWindowHook()
	
	-- ea_playerstatuswindow
    WBStutterLess.PlayerWindowHook()

	-- ea_summoningprompt
	WBStutterLess.SummoningPromptHook()
	
	-- ea_openpartywindow
	-- "Manage Tab" Re-select tab to show updates ( click OpenParty tab > ManageTab ) 
	WBStutterLess.OpenPartyHook()
	
	-- ea_scenariolobbywindow
	WBStutterLess.ScenarioLobbyHook()
end

function WBStutterLess.FriendSuggesterHook()
	FriendSuggester.Data 				= {}
    FriendSuggester.Update 				= function ( dt ) end
	
	FriendSuggester.OnPartyUpdated 		= function () d("FriendSuggester.OnPartyUpdated") end
	FriendSuggester.OnWarbandUpdated 	= function () d("FriendSuggester.OnWarbandUpdated") end
	
end

function WBStutterLess.BattleGroupHudHook()
	BattlegroupHUD.Update 				= function () end
	
	BattlegroupHUD.OnUpdate 			= function ( elapsedTime ) end
	BattlegroupHUD.SingleMemberUpdate 	= function ( partyIndex, memberIndex ) d("BattlegroupHUD.SingleMemberUpdate") end
end

function WBStutterLess.GroupWindowHook()
	GroupWindow.ConditionalShow 		= function () end
	
	GroupWindow.OnGroupUpdated 			= function () d("GroupWindow.OnGroupUpdated") end
	GroupWindow.OnGroupPlayerAdded 		= function () d("GroupWindow.OnGroupPlayerAdded") end
	GroupWindow.OnGroupPlayerAdded 		= function () d("GroupWindow.OnGroupPlayerAdded") end
	GroupWindow.OnStatusUpdated 		= function ( groupMemberIndex ) d("GroupWindow.OnStatusUpdated") end
	GroupWindow.UpdateMemberStatus 		= function ( groupMemberIndex ) d("GroupWindow.UpdateMemberStatus") end
	GroupWindow.OnEffectsUpdated 		= function ( updateType, updatedEffects, isFullList ) d("GroupWindow.OnEffectsUpdated") end
end

function WBStutterLess.RankedLeaderboardHook()
	UnregisterEventHandler( SystemData.Events.GROUP_UPDATED, 		"RoR_RankedLeaderboard.UpdateQue")
	UnregisterEventHandler( SystemData.Events.BATTLEGROUP_UPDATED, 	"RoR_RankedLeaderboard.UpdateQue")
	UnregisterEventHandler( SystemData.Events.GROUP_PLAYER_ADDED,	"RoR_RankedLeaderboard.UpdateQue" )
end

function WBStutterLess.PlayerWindowHook()
	WindowUnregisterEventHandler( "PlayerWindow",				SystemData.Events.PLAYER_GROUP_LEADER_STATUS_UPDATED )
	WindowUnregisterEventHandler( "PlayerWindow", 				SystemData.Events.GROUP_UPDATED )
	WindowUnregisterEventHandler( "PlayerWindow", 				SystemData.Events.PLAYER_MAIN_ASSIST_UPDATED )
	
	PlayerWindow.UpdateMainAssist 	= function () d("PlayerWindow.UpdateMainAssist") end
end

function WBStutterLess.SummoningPromptHook()
	WindowUnregisterEventHandler( "EA_SummoningAcceptPrompt", 	SystemData.Events.PLAYER_COMBAT_FLAG_UPDATED )    
    WindowUnregisterEventHandler( "EA_SummoningAcceptPrompt", 	SystemData.Events.GROUP_UPDATED )
    WindowUnregisterEventHandler( "EA_SummoningAcceptPrompt", 	SystemData.Events.SUMMON_SHOW_PROMPT )
    WindowUnregisterEventHandler( "EA_SummoningAcceptPrompt", 	SystemData.Events.L_BUTTON_DOWN_PROCESSED )
    WindowUnregisterEventHandler( "EA_SummoningAcceptPrompt", 	SystemData.Events.PLAYER_IS_BEING_THROWN ) 
	
	EA_SummoningAcceptPrompt.OnPlayerCombatFlagUpdated 	= function () d("EA_SummoningAcceptPrompt.OnPlayerCombatFlagUpdated") end
	EA_SummoningAcceptPrompt.OnGroupUpdated 			= function () d("EA_SummoningAcceptPrompt.OnGroupUpdated") end
	EA_SummoningAcceptPrompt.ShowPrompt 				= function () d("EA_SummoningAcceptPrompt.ShowPrompt") end
	UseItemTargeting.OnLButtonProcessed 				= function () d("UseItemTargeting.OnLButtonProcessed") end
end

function WBStutterLess.OpenPartyHook()
	EA_Window_OpenParty.EnableTab( 4 )

	WindowUnregisterEventHandler( "EA_Window_OpenPartyFlyOut", 	SystemData.Events.SOCIAL_OPENPARTY_NOTIFY )
    WindowUnregisterEventHandler( "EA_Window_OpenParty", 		SystemData.Events.BATTLEGROUP_UPDATED )
    WindowUnregisterEventHandler( "EA_Window_OpenParty", 		SystemData.Events.GROUP_UPDATED )
	
	WindowUnregisterEventHandler( "EA_Window_OpenPartyManage", 	SystemData.Events.BATTLEGROUP_UPDATED )
    WindowUnregisterEventHandler( "EA_Window_OpenPartyManage", 	SystemData.Events.GROUP_UPDATED )
	
	WindowUnregisterEventHandler( "EA_Window_OpenPartyNearby", 	SystemData.Events.SOCIAL_OPENPARTYINTEREST_UPDATED )
    WindowUnregisterEventHandler( "EA_Window_OpenPartyNearby", 	SystemData.Events.GROUP_SETTINGS_PRIVACY_UPDATED )
    WindowUnregisterEventHandler( "EA_Window_OpenPartyNearby", 	SystemData.Events.BATTLEGROUP_UPDATED )
    WindowUnregisterEventHandler( "EA_Window_OpenPartyNearby", 	SystemData.Events.GROUP_UPDATED )
	
	WindowUnregisterEventHandler( "EA_Window_OpenPartyWorld", 	SystemData.Events.BATTLEGROUP_UPDATED )
    WindowUnregisterEventHandler( "EA_Window_OpenPartyWorld", 	SystemData.Events.GROUP_UPDATED )
	
	EA_Window_OpenParty.UpdateManageTabDisable 	= function () end
	
	EA_Window_OpenPartyWorld.OnGroupUpdated 	= function () d("EA_Window_OpenPartyWorld.OnGroupUpdated") end
	EA_Window_OpenParty.OnOpenPartyNotification = function () d("EA_Window_OpenParty.OnOpenPartyNotification") end
end

function WBStutterLess.ScenarioLobbyHook()
	WindowUnregisterEventHandler( "EA_Window_ScenarioLobby", SystemData.Events.GROUP_UPDATED )
    WindowUnregisterEventHandler( "EA_Window_ScenarioLobby", SystemData.Events.BATTLEGROUP_UPDATED )
		
	EA_Window_ScenarioLobby.OnJoinAllQueues = function ()
		if( ButtonGetDisabledFlag( SystemData.ActiveWindow.name ) ) then return	end
																	   
		local joinAllEvent = EA_Window_ScenarioLobby.joinModes[ EA_Window_ScenarioLobby.joinMode ].joinAllEvent
		
		BroadcastEvent( joinAllEvent )   
		WindowSetShowing("EA_Window_ScenarioLobby", false)
	end
end