ActionBarHide = {}

ActionBarHide.bar =
{
	[1] = { inc_alpha = 1, ooc_alpha = 0, mod_bar = true },
	[2] = { inc_alpha = 1, ooc_alpha = 0, mod_bar = true },
	[3] = { inc_alpha = 1, ooc_alpha = 0, mod_bar = true },
	[4] = { inc_alpha = 1, ooc_alpha = 0, mod_bar = true }
}
ActionBarHide.Throttle = true

ActionBarHide.hidden = false
ActionBarHide.MouseIn = false

local systemTime = 0.0
local lastUpdate = 0.0

function ActionBarHide.Initialize()
	RegisterEventHandler(SystemData.Events.LOADING_END, "ActionBarHide.OnLoad")
	RegisterEventHandler(SystemData.Events.RELOAD_INTERFACE, "ActionBarHide.OnLoad")
	RegisterEventHandler(SystemData.Events.PLAYER_COMBAT_FLAG_UPDATED, "ActionBarHide.Combat")

	--[[ Grab the old mouse handler and add our alpha
	--change function ]]
	old_mouse_over = ActionButton.OnMouseOver
	ActionButton.OnMouseOver = function(...)
		old_mouse_over(...)
		ActionBarHide.MouseIn = true
		ActionBarHide.ChangeAlpha()
	end

	--[[ Grab the old mouse handler and add our alpha
	--change function ]]
	old_mouse_over_end = ActionButton.OnMouseOverEnd
	ActionButton.OnMouseOverEnd = function(...)
		old_mouse_over_end(...)
		ActionBarHide.MouseIn = false
		ActionBarHide.ChangeAlpha()
	end


	--[[ Grab the Update function.  This is called
	--each frame for each button on each action bar. ]]
	old_button_update = ActionButton.Update
	ActionButton.Update = function(self, timeElapsed, updateCooldown, ui, pr, cr)
		if (nil == self.time) then
			self.time = 0.0
			self.text_shown = true
			self.pr = 0
		end
		self.time = self.time + timeElapsed
		if (false == ActionBarHide.Throttle) then
			old_button_update(self, timeElapsed, updateCooldown, ui, pr, cr)
		end
		if (self.time >= 0.25) then
			if (true == ActionBarHide.Throttle) then
				old_button_update(self, self.time, true, ui, self.pr, cr)
				self.pr = cr
			end

			if (true == self.text_shown)and(true == ActionBarHide.hidden) then
				LabelSetText(self:GetName().."ActionText", L"")
				self.text_shown = false
			elseif (false == self.text_shown)and(false == ActionBarHide.hidden) then
				self:UpdateKeyBindingText()
				self.text_shown = true
			end

			self.time = 0.0
		end
	end

end

--[[ On Load Event handler ]]
local registered = false
function ActionBarHide.OnLoad()
	EA_ChatWindow.Print(L"ActionBarHide Loaded")

	if ((nil ~= LibSlash)and(false == registered)) then
		LibSlash.RegisterSlashCmd("abh", function() ActionBarHide.OptionsWindow() end)
		registered = true
	end

	WindowSetShowing("ActionBarLockToggler", false)

	ActionBarHide.ChangeAlpha()
end

--[[
--	Called when Combat State Changes
--]]
ActionBarHide.last_state = false
function ActionBarHide.Combat()
	if ((true == GameData.Player.inCombat)and(false == ActionBarHide.last_state)) then
		ActionBarHide.ChangeAlpha()
	elseif (true == ActionBarHide.last_state) then
		ActionBarHide.ChangeAlpha()
	end
end



--[[ 
--	Change the alpha depending on current combat state
--	and the state the current bar is in
--]]
function ActionBarHide.ChangeAlpha()
	for k=1,4 do
		if (true == ActionBarHide.bar[k].mod_bar) then
			if (true == ActionBarHide.MouseIn)or
				 (true == GameData.Player.inCombat) 
			then
				WindowSetAlpha("EA_ActionBar"..k, ActionBarHide.bar[k].inc_alpha)
				ActionBarHide.hidden = false
			else
				WindowSetAlpha("EA_ActionBar"..k, ActionBarHide.bar[k].ooc_alpha)
				ActionBarHide.hidden = true
			end
		end
	end
	ActionBarHide.last_state = GameData.Player.inCombat
end


--[[ 
--	GUI Config 
--]]
local LibGUI = LibStub("LibGUI")
function ActionBarHide.OptionsWindow()
	local w = {}

	w = LibGUI("Blackframe")
	w:MakeMovable()
	w:Resize(550, 150)
	w:AnchorTo("Root", "topright", "topright", 0, 0)

		-- Add a close button
	w.CloseButton = w("Closebutton")
	w.CloseButton.OnLButtonUp =
	function()
		w:Destroy()
	end


	w.Title = w("Label")
	w.Title:Resize(250)
	w.Title:AnchorTo(w, "top", "top", 0, 10)
	w.Title:Font("font_clear_large_bold")
	w.Title:SetText(L"ABH Config")
	w.Title:Align("center")
	w.Title:IgnoreInput()

	w.l1 = w("Label")
	w.l1:Resize(200)
	w.l1:Position(25,35)
	w.l1:Font("font_clear_medium")
	w.l1:SetText(L"In Combat Alpha:")
	w.l1:Align("left")

	w.s1 = w("Slider")
	w.s1:AnchorTo(w.l1, "bottomleft", "topleft", 0, 0)
	w.s1:SetRange(0.0, 1.0)
	w.s1:SetValue(ActionBarHide.bar[1].inc_alpha)
	w.s1.OnLButtonUp =
		function()
			local val = w.s1:GetValue()
			ActionBarHide.bar[1].inc_alpha = val
			ActionBarHide.bar[2].inc_alpha = val
			ActionBarHide.bar[3].inc_alpha = val
			ActionBarHide.bar[4].inc_alpha = val
			ActionBarHide.ChangeAlpha()
		end
	w.s1.OnMouseOverEnd =
		function()
			local val = w.s1:GetValue()
			ActionBarHide.bar[1].inc_alpha = val
			ActionBarHide.bar[2].inc_alpha = val
			ActionBarHide.bar[3].inc_alpha = val
			ActionBarHide.bar[4].inc_alpha = val
			ActionBarHide.ChangeAlpha()
		end

	w.l2 = w("Label")
	w.l2:Resize(200)
	w.l2:Position(250,35)
	w.l2:Font("font_clear_medium")
	w.l2:SetText(L"Out Of Combat Alpha:")
	w.l2:Align("left")

	w.s2 = w("Slider")
	w.s2:AnchorTo(w.l2, "bottomleft", "topleft", 0, 0)
	w.s2:SetRange(0.0, 1.0)
	w.s2:SetValue(ActionBarHide.bar[1].ooc_alpha)
	w.s2.OnLButtonUp =
		function()
			local val = w.s2:GetValue()
			ActionBarHide.bar[1].ooc_alpha = val
			ActionBarHide.bar[2].ooc_alpha = val
			ActionBarHide.bar[3].ooc_alpha = val
			ActionBarHide.bar[4].ooc_alpha = val
			ActionBarHide.ChangeAlpha()
		end
	w.s2.OnMouseOverEnd =
		function()
			local val = w.s2:GetValue()
			ActionBarHide.bar[1].ooc_alpha = val
			ActionBarHide.bar[2].ooc_alpha = val
			ActionBarHide.bar[3].ooc_alpha = val
			ActionBarHide.bar[4].ooc_alpha = val
			ActionBarHide.ChangeAlpha()
		end

	w.l3 = w("Label")
	w.l3:Resize(200)
	w.l3:Position(25,100)
	w.l3:Font("font_clear_medium")
	w.l3:SetText(L"Throttle:")
	w.l3:Align("left")

	w.k1 = w("Checkbox")
	w.k1:AnchorTo(w.l3, "right", "left", 0, 0)
	w.k1.OnLButtonUp =
		function()
			ActionBarHide.Throttle = w.k1:GetValue()
		end
	if (true == ActionBarHide.Throttle) then
		w.k1:Check()
	end

	w:Show() 
end
