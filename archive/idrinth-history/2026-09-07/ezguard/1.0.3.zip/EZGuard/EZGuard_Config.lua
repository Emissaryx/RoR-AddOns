LibConfig = LibStub("LibConfig")

EZGuard_Config = {}

local GUI

function EZGuard_Config.Slash(input)
	if (not GUI) then
		-- parameters: title text, settings table, callback-function
		-- note that you need to have a settings table!
		GUI = LibConfig("EZGuard v" .. tostring(EZGuard.Settings.version), EZGuard.Settings, true, EZGuard_Config.SettingsChanged)

		GUI:AddTab("Settings")
		local checkbox
		checkbox = GUI("checkbox", "Enabled", "enabled")
		checkbox.label:Font("font_default_text_small")
		
		checkbox = GUI("checkbox", "Glow effects", "glowEffects")
		checkbox.label:Font("font_default_text_small")

		local textbox
		textbox = GUI("textbox", "Guard Distance:", "guardDistance")
		textbox.label:Font("font_default_text_small")
		textbox.label:AnchorTo(textbox, "left", "left", 48, -5)
		textbox.label:Align("left")
		textbox.edit:AnchorTo(textbox.label, "right", "right", -48)
		textbox.edit:Resize(50)

		GUI:AddTab("Priorities")
		textbox = GUI("textbox", "Healers Hit Points factor:", "healerWeight")
		textbox.label:Font("font_default_text_small")
		textbox.label:AnchorTo(textbox, "left", "left", 48, -5)
		textbox.label:Align("left")
		textbox.edit:AnchorTo(textbox.label, "right", "right", -48)
		textbox.edit:Resize(50)

		textbox = GUI("textbox", "DPS Hit Points factor:", "dpsWeight")
		textbox.label:Font("font_default_text_small")
		textbox.label:AnchorTo(textbox, "left", "left", 48, -5)
		textbox.label:Align("left")
		textbox.edit:AnchorTo(textbox.label, "right", "right", -48)
		textbox.edit:Resize(50)
		
		textbox = GUI("textbox", "Tanks Hit Points factor:", "tankWeight")
		textbox.label:Font("font_default_text_small")
		textbox.label:AnchorTo(textbox, "left", "left", 48, -5)
		textbox.label:Align("left")
		textbox.edit:AnchorTo(textbox.label, "right", "right", -48)
		textbox.edit:Resize(50)
	end
	GUI:Show()
end

function EZGuard_Config.SettingsChanged()
	GUI:Hide()
	EZGuard.PrintSettings()
end