local version 		= 1.0
local AlertHook
Info_Alert = {}


local Default_AlertIcon = {name="info",width=34,height=34,x=-3,y=-4,scale=0.7}
local AlertIcon = {	[0]={name="info",width=34,height=34,x=-3,y=-4,scale=0.7}, --info "target too far"
					[1]={name="info",width=34,height=34,x=-3,y=-4,scale=0.7},	
					[2]={name="map_markers01",slice="QuestActive",width=32,height=32,x=-5,y=-5,scale=0.85},	--quest stuff
					[4]={name="icon000049",width=64,height=64,x=-5,y=-5,scale=0.4}, --Server announce
					[16]={name="map_markers01",slice="QuestEpic",width=30,height=28,x=-10,y=-8,scale=1},	--Flagged for rvr
					[17]={name="map_markers01",slice="NPC-Travel",width=30,height=28,x=-10,y=-10,scale=1},	--zoning, area change
					[18]={name="map_markers01",slice="Influence-Teal-ROLLOVER",width=30,height=30,x=-6,y=-5,scale=0.87},--PQ
					[19]={name="map_markers01",slice="Influence-Teal",width=30,height=30,x=-6,y=-5,scale=0.87},--PQ end
					[21]={name="info",width=34,height=34,x=-3,y=-4,scale=0.7,tint={DefaultColor.AlertTextColors[AlertTextWindow.TypeInfo[21].color].r,DefaultColor.AlertTextColors[AlertTextWindow.TypeInfo[21].color].g,DefaultColor.AlertTextColors[AlertTextWindow.TypeInfo[21].color].b}},--21 rvr info (keep door n stuff) blue
					[22]={name="info",width=34,height=34,x=-3,y=-4,scale=0.7,tint={DefaultColor.AlertTextColors[AlertTextWindow.TypeInfo[22].color].r,DefaultColor.AlertTextColors[AlertTextWindow.TypeInfo[22].color].g,DefaultColor.AlertTextColors[AlertTextWindow.TypeInfo[22].color].b}},--22 rvr info (keep door n stuff) Red
--					[22]={name="map_markers01",slice="QuestRVR",width=30,height=30,x=-6,y=-5,scale=0.87},--22 rvr combat info, supplies? red
					[23]={name="info",width=34,height=34,x=-3,y=-4,scale=0.7,tint={DefaultColor.AlertTextColors[AlertTextWindow.TypeInfo[23].color].r,DefaultColor.AlertTextColors[AlertTextWindow.TypeInfo[23].color].g,DefaultColor.AlertTextColors[AlertTextWindow.TypeInfo[23].color].b}},--yellow info, "the war continues in other areas"
					[25]={name="map_markers01",slice="GuildStandard",width=32,height=32,x=-4,y=-5,scale=0.72}, --Objectives
					[28]={name="map_markers01",slice="NPC-Travel",width=30,height=28,x=-10,y=-10,scale=1}	--zoning, area change
					}	

function Info_Alert.OnInitialize()
if not InfoScroller.Settings.Alerts then InfoScroller.Settings.Alerts = true end
if not InfoScroller.Settings.Alert_Supress then InfoScroller.Settings.Alert_Supress = false end
if not InfoScroller.Settings.Alert_Color then InfoScroller.Settings.Alert_Color = {65,0,255} end


	--Alert option config
	local Alerts = {name="+Alerts",[1]={name="checkbox",title="Show Alerts on InfoScroller",save="Alerts"},
									[2]={name="checkbox",title="Supress Text Alerts",save="Alert_Supress"},
									[3]={name="color",title="Ticket BG Color",save="Alert_Color"},
	}
	table.insert(InfoScroller.Register,Alerts)	
	
	AlertHook = AlertTextWindow.SetAlertData
	AlertTextWindow.SetAlertData = Info_Alert.AlertHook	
	
end

function Info_Alert.OnShutdown()	
	--UnregisterEventHandler(SystemData.Events.SHOW_ALERT_TEXT, "Info_Alert.AlertHook")
	--WindowSetShowing("AlertTextContainerWindow",true)
end

function Info_Alert.AlertHook(vecType, vecText)
	if InfoScroller.Settings.Alert_Supress == false then AlertHook(vecType, vecText) end
	if InfoScroller.Settings.Alerts == false then return end

	--WindowSetShowing("AlertTextContainerWindow",not InfoScroller.Settings.Alert_Supress)

	if vecType[1] == SystemData.AlertText.Types.STATUS_ERRORS or vecType[1] == SystemData.AlertText.Types.COMBAT then
		return
	end


	local AlertColorBgColor = InfoScroller.Settings.Alert_Color
	local AlertColor = {r=AlertColorBgColor[1],g=AlertColorBgColor[2],b=AlertColorBgColor[3]}

	--,font=AlertTextWindow.TypeInfo[v].halfFont
	local Index = #vecType
	local Tic_tab = {}
		for k,v in pairs (vecType) do
			local Texture_Swap
			if k == 1 then 
				if AlertIcon[v] == nil then Texture_Swap = Default_AlertIcon else Texture_Swap = AlertIcon[v] end			
					Tic_tab[k] = {texture=Texture_Swap,text=L"     "..vecText[k],color=DefaultColor.AlertTextColors[AlertTextWindow.TypeInfo[v].color],font="font_clear_medium_bold"}
		
			else				
					Tic_tab[k] = {text=vecText[k],color=DefaultColor.AlertTextColors[AlertTextWindow.TypeInfo[v].color],font="font_clear_medium_bold"}				
			end
		end
	--Enter a BO objective
	if vecType[1] == SystemData.AlertText.Types.BO_ENTER then
		Index = Index +1
		Tic_tab[Index] = {text=towstring(GetString(StringTables.Default.LABEL_BATTLE_FIELD_OBJECTIVE)),color=DefaultColor.AlertTextColors[AlertTextWindow.TypeInfo[SystemData.AlertText.Types.BO_DESCRIPTION].color]}
	end
	
	--Enter a PQ 
	if vecType[1] == SystemData.AlertText.Types.PQ_ENTER then
		Index = Index +1
		Tic_tab[Index] = Info_Alert.PQEnterExtraText()	
	end
	

	if Index == 1 then
		InfoScroller.TicketOnQue({BGColor={r=AlertColor.r,g=AlertColor.g,b=AlertColor.b},Tic_tab[1]})
	elseif Index == 2 then
		InfoScroller.TicketOnQue({BGColor={r=AlertColor.r,g=AlertColor.g,b=AlertColor.b},Tic_tab[1],Tic_tab[2]})
	elseif Index == 3 then
		InfoScroller.TicketOnQue({BGColor={r=AlertColor.r,g=AlertColor.g,b=AlertColor.b},Tic_tab[1],Tic_tab[2],Tic_tab[3]})
	elseif Index == 4 then
		InfoScroller.TicketOnQue({BGColor={r=AlertColor.r,g=AlertColor.g,b=AlertColor.b},Tic_tab[1],Tic_tab[2],Tic_tab[3],Tic_tab[4]})
	elseif Index == 5 then
		InfoScroller.TicketOnQue({BGColor={r=AlertColor.r,g=AlertColor.g,b=AlertColor.b},Tic_tab[1],Tic_tab[2],Tic_tab[3],Tic_tab[4],Tic_tab[5]})
	end
end


function Info_Alert.PQEnterExtraText()

    if (GameData.Player.isInScenario) then
	
		local extra_text = towstring( GetString( StringTables.Default.LABEL_BATTLE_FIELD_OBJECTIVE ))
		return {text=extra_text,color=DefaultColor.AlertTextColors[AlertTextWindow.TypeInfo[SystemData.AlertText.Types.BO_DESCRIPTION].color]}
      
    end
						   local areaData = GetAreaData()
							local infID = 0
							local hasPQButNoInfluence = false
							if( areaData ~= nil ) then
								for k, v in ipairs( areaData ) do
									if( v.influenceID ~= 0 )
									then
										infID = v.influenceID
										hasPQButNoInfluence = v.hasPQButNoInfluence
										break
									elseif( v.hasPQButNoInfluence )
									then
										hasPQButNoInfluence = true
									end
								end
							end									
	if (GameData.Player.City.id ~= 0) then
        hasPQButNoInfluence = true
    end
    
	
--[[	
    if( infID == 0 and not hasPQButNoInfluence)
    then
        for index = 1, #SystemData.AlertText.VecType
        do
            if( SystemData.AlertText.VecType[index] == SystemData.AlertText.Types.PQ_NAME )
            then
                SystemData.AlertText.VecType[index] = SystemData.AlertText.Types.BO_NAME
                break
            end
        end
        table.insert( vecType, nextIndex, SystemData.AlertText.Types.BO_DESCRIPTION )
        table.insert( vecText, nextIndex, wstring.upper( GetString( StringTables.Default.LABEL_KEEP ) ) )
        return
    end
--]]				
				
					local zonePairing = GetZonePairing()

				local raceName
				if( not hasPQButNoInfluence )
				then
					raceName = StringUtils.GetFriendlyRaceForCurrentPairing( zonePairing, true )
				end

				local chapterName
				if (infID > 0 and not hasPQButNoInfluence)
				then
					chapterName = GetChapterName( infID )
				end
				
				local pqDesc
				if( raceName or chapterName )
				then
					pqDesc = towstring( GetStringFormat( StringTables.Default.LABEL_PQ_RACE_CHAPTER_FORMAT, {racename or L"", chaptername or L""} ) )
				else
					pqDesc = towstring( GetString( StringTables.Default.LABEL_PUBLIC_QUEST ) )
				end
				
				if( infID > 0 or hasPQButNoInfluence )
				then
				
					return {text=pqDesc,color=DefaultColor.AlertTextColors[AlertTextWindow.TypeInfo[SystemData.AlertText.Types.PQ_DESCRIPTION].color]}
				end

end