<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
    <UiMod name="Info_Alert" version="1.0" date="11/12/2020">
        <Author name="Sullemunk" />
        <Description text="Info_Alert, Shows Alert text tickers on InfoScroller" />
         <Dependencies>
            <Dependency name="InfoScroller" optional="false" />
			<Dependency name="EA_AlertTextWindow" />	
		</Dependencies>
        <Files>
				<File name="Info_Alert.lua" />
        </Files>
        <OnInitialize>
            <CallFunction name="Info_Alert.OnInitialize" />
        </OnInitialize>
		
		<SavedVariables>		
		</SavedVariables>
        <OnUpdate>
    	 </OnUpdate>	
        <OnShutdown>
			<CallFunction name="Info_Alert.OnShutdown" />
		</OnShutdown>
    </UiMod>
</ModuleFile>