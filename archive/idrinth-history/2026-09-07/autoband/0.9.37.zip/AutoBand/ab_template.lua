-- AB_template.lua

AB_template = {}

-- Helper function to pick a player for a slot
function AB_template.pick_player_for_slot(bin, target_gid, current_target_group_players_list, wb_dist_so_far)
    if not bin or #bin == 0 then
        if AutoBand.debugon then AB_util.debug("pick_player_for_slot: Bin is empty for G" .. target_gid) end
        return nil
    end

    local role_of_this_bin = bin[1].role

    local function count_career_globally(career)
        local count = 0
        if wb_dist_so_far then
            for _, grp in ipairs(wb_dist_so_far) do
                if grp then
                    for _, placed in ipairs(grp) do
                        if placed.role == role_of_this_bin and placed.career == career then
                            count = count + 1
                        end
                    end
                end
            end
        end
        return count
    end

    local function count_career_in_group(career)
        local count = 0
        if current_target_group_players_list then
            for _, p in ipairs(current_target_group_players_list) do
                if p.role == role_of_this_bin and p.career == career then
                    count = count + 1
                end
            end
        end
        return count
    end

    local candidates = {}
    for i = #bin, 1, -1 do
        local p_entry = bin[i]
        table.insert(candidates, {
            player_data = p_entry,
            bin_index_original = i,
            global_diversity_score = count_career_globally(p_entry.career),
            intra_diversity_score = count_career_in_group(p_entry.career),
            is_sticky_flag = (p_entry.original_gid == target_gid),
            level_raw = p_entry.level or 0,
            level_range_score = AB_util.get_level_range_score(p_entry.level or 0)
        })
    end

    if #candidates == 0 then
        if AutoBand.debugon then AB_util.debug("pick_player_for_slot: No candidates found for G" .. target_gid .. ", Role: " .. role_of_this_bin) end
        return nil
    end

    table.sort(candidates, function(a, b)
        if a.global_diversity_score ~= b.global_diversity_score then
            return a.global_diversity_score < b.global_diversity_score
        end

        if a.intra_diversity_score ~= b.intra_diversity_score then
            return a.intra_diversity_score < b.intra_diversity_score
        end

        -- Higher-level ranges take precedence (40 > 36-39 > ...)
        if a.level_range_score ~= b.level_range_score then
            return a.level_range_score > b.level_range_score
        end

        if a.is_sticky_flag ~= b.is_sticky_flag then
            return a.is_sticky_flag
        end

        if a.level_raw ~= b.level_raw then
            return a.level_raw > b.level_raw
        end

        return a.bin_index_original > b.bin_index_original
    end)

    local best = candidates[1]
    local picked_player = table.remove(bin, best.bin_index_original)

    if (AutoBand.debugon or AutoBand.live_org_verbose) and picked_player then
        local name_str = picked_player.name and tostring(picked_player.name) or "UnknownName"
        local role_str = picked_player.role or "UnknownRole"
        local career_str = picked_player.career and (AutoBand.GetCareerName and AutoBand.GetCareerName(picked_player.career) or picked_player.career) or "UnkCareer"
        local lvl_str = picked_player.level or "??"
        local orig_g_str = picked_player.original_gid or "?"
        local sticky_tag_log = best.is_sticky_flag and " [STICKY]" or ""
        AB_util.print(string.format("Picked for G%d: %s (Role:%s, Career:%s, Lvl:%s, OrigG:%s) DivG:%d DivL:%d%s",
            target_gid, name_str, role_str, career_str, lvl_str, orig_g_str,
            best.global_diversity_score, best.intra_diversity_score, sticky_tag_log))
    end

    return picked_player
end

function AB_template.from_wb(wb_obj, valid_groups)
  if (valid_groups == nil) then
    valid_groups = {}
    for i = 1, wb_obj.MAX_GROUPS do
      valid_groups[i] = true
    end
  end
  local newwb = {}
  for i = 1, wb_obj.MAX_GROUPS do newwb[i] = {} end
  wb_obj:foreach_player(
    function(gid, player)
      if (valid_groups[gid] ~= nil) then
        table.insert(newwb[gid], {["role"] = player.role})
      end
    end
  )
  return newwb
end

function AB_template.find_min_groupid_strict(role_id_to_place, num_groups_to_consider, sorted_group_list, current_wb_dist, role_counts_per_group)
    local opt_role_ratio = AB_const.GROUP_SIZE + 1
    local opt_overall_size = AB_const.GROUP_SIZE + 1
    local opt_gid = -1

    -- Only consider the top 'num_groups_to_consider' from the sorted list (sorted by overall emptiness)
    for i = 1, math.min(num_groups_to_consider, #sorted_group_list) do
        local current_gid_struct = sorted_group_list[i]
        local gid = current_gid_struct.id
        if not current_wb_dist[gid] then current_wb_dist[gid] = {} end -- Ensure group exists for size check

        if #current_wb_dist[gid] < AB_const.GROUP_SIZE then -- Only consider groups with space
            local current_role_count_in_group = role_counts_per_group[role_id_to_place][gid]
            local current_total_players_in_group = #current_wb_dist[gid]

            if (current_role_count_in_group < opt_role_ratio) then
                opt_role_ratio = current_role_count_in_group
                opt_gid = gid
                opt_overall_size = current_total_players_in_group
            elseif (current_role_count_in_group == opt_role_ratio) then
                -- Tie on role count, prefer group with fewer total players
                if (current_total_players_in_group < opt_overall_size) then
                    opt_gid = gid
                    opt_overall_size = current_total_players_in_group
                elseif (current_total_players_in_group == opt_overall_size and gid < opt_gid) then
                    -- Tie on role count and total size, prefer lower group ID
                    opt_gid = gid
                end
            end
        end
    end

    if opt_gid == -1 and AutoBand.debugon then
        AB_util.debug("find_min_groupid_strict: Could not find suitable group for role " .. role_id_to_place .. " within the " .. num_groups_to_consider .. " target groups that have space.")
    end
    return opt_gid
end

function AB_template.find_max_groupid_strict(role_id_to_place, num_groups_to_consider, sorted_group_list, current_wb_dist, role_counts_per_group)
    local opt_role_ratio = -1
    local opt_overall_size = -1
    local opt_gid = -1

    for i = 1, math.min(num_groups_to_consider, #sorted_group_list) do
        local current_gid_struct = sorted_group_list[i]
        local gid = current_gid_struct.id
        if not current_wb_dist[gid] then current_wb_dist[gid] = {} end

        if #current_wb_dist[gid] < AB_const.GROUP_SIZE then -- Only consider groups with space
            local current_role_count_in_group = role_counts_per_group[role_id_to_place][gid]
            local current_total_players_in_group = #current_wb_dist[gid]

            if (current_role_count_in_group > opt_role_ratio) then
                opt_role_ratio = current_role_count_in_group
                opt_gid = gid
                opt_overall_size = current_total_players_in_group
            elseif (current_role_count_in_group == opt_role_ratio) then
                -- Tie on role count
                if (opt_role_ratio == 0 and current_total_players_in_group < opt_overall_size) then
                    -- If no group has this role yet, prefer emptier group overall
                    opt_gid = gid
                    opt_overall_size = current_total_players_in_group
                elseif (opt_role_ratio > 0 and current_total_players_in_group > opt_overall_size) then
                    -- If groups already have this role, prefer fuller group overall (to stack more)
                     opt_gid = gid
                     opt_overall_size = current_total_players_in_group
                elseif (current_total_players_in_group == opt_overall_size and gid > opt_gid) then
                    -- Tie on role count and effective total size consideration, prefer higher group ID
                    opt_gid = gid
                end
            end
        end
    end
    if opt_gid == -1 and AutoBand.debugon then
         AB_util.debug("find_max_groupid_strict: Could not find suitable group for role " .. role_id_to_place .. " within the " .. num_groups_to_consider .. " target groups that have space.")
    end
    return opt_gid
end

function AB_template.match(wb_obj, wb_dist, roles_not_taken, bins, temp_definition, max_target_groups_override)
  AB_util.debug("AB_template.match: init. WB player count: " .. wb_obj.player_count .. ", max_target_groups_override=" .. tostring(max_target_groups_override))

  local effective_max_groups = max_target_groups_override or AB_const.MAX_WB_GROUPS

  local role_per_group = {}
  for r_key, rid in pairs(AB_const.ROLE_CATEGORIES) do
    role_per_group[rid] = {}
    for i = 1, effective_max_groups do role_per_group[rid][i] = 0 end
  end

  local group_ids_sorted_by_fullness = {}
  for i = 1, effective_max_groups do
        if not wb_dist[i] then wb_dist[i] = {} end
    table.insert(group_ids_sorted_by_fullness, {id = i, current_size_in_wb_dist = #wb_dist[i]})
  end
  table.sort(group_ids_sorted_by_fullness, function(a,b)
    return a.current_size_in_wb_dist < b.current_size_in_wb_dist or
       (a.current_size_in_wb_dist == b.current_size_in_wb_dist and a.id < b.id)
  end)

  local template_size = AB_util.size_wb(temp_definition)
  local players_placed_by_template = 0
  local watchdog_triggered_in_template = false

  if (template_size > 0 and temp_definition) then
    AB_util.debug("AB_template.match: Applying template. Template total slots: " .. template_size)
    local loop_watchdog = 0

    for tgid = 1, #temp_definition do
      if watchdog_triggered_in_template then break end
            if not wb_dist[tgid] then wb_dist[tgid] = {} end

      local template_group_roles = temp_definition[tgid]
      if template_group_roles then
        for _, role_entry_in_template in ipairs(template_group_roles) do
          loop_watchdog = loop_watchdog + 1
          if (loop_watchdog > template_size + AB_const.LOOP_MAX + AB_const.GROUP_SIZE * effective_max_groups) then
            AB_util.debug("****[ERROR] AB_template.match (template loop): Watchdog. Placed by template: " .. players_placed_by_template)
            watchdog_triggered_in_template = true
            break
          end

          local role_to_fill = role_entry_in_template.role
          local role_id_for_bin = AB_const.ROLE_CATEGORIES[role_to_fill]

          if role_id_for_bin and bins[role_id_for_bin] and #bins[role_id_for_bin] > 0 then
            if #wb_dist[tgid] < AB_const.GROUP_SIZE then
              -- Pass current state of wb_dist[tgid] (list of player objects)
              local picked_player_obj = AB_template.pick_player_for_slot(bins[role_id_for_bin], tgid, wb_dist[tgid], wb_dist)
              if picked_player_obj then
                table.insert(wb_dist[tgid], picked_player_obj) -- Store the full player object
                table.insert(roles_not_taken[picked_player_obj.role], tgid) -- This stores the GID where the role is now filled
                role_per_group[role_id_for_bin][tgid] = role_per_group[role_id_for_bin][tgid] + 1
                players_placed_by_template = players_placed_by_template + 1
                for _, g_entry in ipairs(group_ids_sorted_by_fullness) do
                  if g_entry.id == tgid then
                    g_entry.current_size_in_wb_dist = #wb_dist[tgid]
                    break
                  end
                end
              else
                AB_util.debug("AB_template.match (template): Could not pick player for role " .. role_to_fill .. " in G" .. tgid)
              end
            else
              AB_util.debug("AB_template.match (template): Wants role " .. role_to_fill .. " in G" .. tgid .. " but group is full in wb_dist.")
            end
          else
            AB_util.debug("AB_template.match (template): No players in bin for role " .. role_to_fill .. " (ID: " .. tostring(role_id_for_bin) .. ") or invalid role_id for G" .. tgid)
          end
        end
      end
    end
    for i=1, #group_ids_sorted_by_fullness do
      group_ids_sorted_by_fullness[i].current_size_in_wb_dist = #wb_dist[group_ids_sorted_by_fullness[i].id]
    end
    table.sort(group_ids_sorted_by_fullness, function (a, b)
      return (a.current_size_in_wb_dist < b.current_size_in_wb_dist or
         (a.current_size_in_wb_dist == b.current_size_in_wb_dist and a.id < b.id))
    end)
    AB_util.debug("AB_template.match: After template fill, " .. players_placed_by_template .. " players placed. wb_dist total: " .. AB_util.size_wb(wb_dist))
  end

    local total_players = wb_obj.player_count
    local num_groups_that_can_be_full = math.floor(total_players / AB_const.GROUP_SIZE)
    local has_partial_group_val = (total_players % AB_const.GROUP_SIZE) > 0

    local primary_target_group_count = num_groups_that_can_be_full
    if total_players > 0 and num_groups_that_can_be_full == 0 then
        primary_target_group_count = 1
    end
    if total_players == 0 then
        primary_target_group_count = 0
    end

    AB_util.debug("AB_template.match: Total players: " .. total_players ..
                  ", Num groups that can be full: " .. num_groups_that_can_be_full ..
                  ", Has partial group: " .. tostring(has_partial_group_val) ..
                  ", Primary target group count for role dist: " .. primary_target_group_count)

    local ngrp_for_main_distribution = 0
    if primary_target_group_count > 0 then
        for i = 1, math.min(primary_target_group_count, #group_ids_sorted_by_fullness) do
            local gid_to_check = group_ids_sorted_by_fullness[i].id
            if not wb_dist[gid_to_check] then wb_dist[gid_to_check] = {} end
            if #wb_dist[gid_to_check] < AB_const.GROUP_SIZE then
                ngrp_for_main_distribution = ngrp_for_main_distribution + 1
            end
        end
    end
    AB_util.debug("AB_template.match: ngrp_for_main_distribution (num primary target groups with space): " .. ngrp_for_main_distribution)

    if ngrp_for_main_distribution == 0 and primary_target_group_count > 0 and AB_util.size_wb(bins) > 0 then
         AB_util.debug("AB_template.match: Primary " .. primary_target_group_count .. " groups for role distribution are already full or have no space. Main distribution might be skipped.")
    end

    local slots_in_primary_groups = 0
    if ngrp_for_main_distribution > 0 then
        for i = 1, ngrp_for_main_distribution do
            local gid_struct_idx = group_ids_sorted_by_fullness[i]
            if gid_struct_idx then -- Ensure the entry exists in the sorted list
                local gid_to_check = gid_struct_idx.id
                if wb_dist[gid_to_check] then
                     slots_in_primary_groups = slots_in_primary_groups + (AB_const.GROUP_SIZE - #wb_dist[gid_to_check])
                end
            else
                AB_util.debug("AB_template.match: Warning - group_ids_sorted_by_fullness["..i.."] is nil when calculating slots_in_primary_groups.")
            end
        end
    end

    local max_players_for_main_dist = math.min(AB_util.size_wb(bins), slots_in_primary_groups)
    AB_util.debug("AB_template.match: Max players for main distribution phase: " .. max_players_for_main_dist)


  if (AB_util.size_wb(bins) > 0 and ngrp_for_main_distribution > 0 and max_players_for_main_dist > 0) then
    AB_util.debug("AB_template.match: Proceeding to main distribution. Algorithm: " .. AutoBand.saved.org_algo_mode .. ". Targeting " .. ngrp_for_main_distribution .. " groups, for up to " .. max_players_for_main_dist .. " players.")
    if (AutoBand.saved.org_algo_mode == AB_const.MODE_SPREAD) then
      AB_template.from_bins_spread(wb_obj, wb_dist, roles_not_taken, bins, role_per_group, ngrp_for_main_distribution, group_ids_sorted_by_fullness, max_players_for_main_dist)
    else
      AB_template.from_bins_aggregate(wb_obj, wb_dist, roles_not_taken, bins, role_per_group, ngrp_for_main_distribution, group_ids_sorted_by_fullness, max_players_for_main_dist)
    end
  end

  local left_over_count = AB_util.size_wb(bins)
  if (left_over_count > 0) then
    AB_util.debug("AB_template.match: " .. left_over_count .. " players leftover. Attempting to place.")
    local initial_target_gid_for_leftover = -1
        local max_total_groups_to_use_for_leftovers = num_groups_that_can_be_full + (has_partial_group_val and 1 or 0)
        if total_players > 0 and num_groups_that_can_be_full == 0 and has_partial_group_val then
            max_total_groups_to_use_for_leftovers = 1
        elseif total_players == 0 then
            max_total_groups_to_use_for_leftovers = 0
        end
        max_total_groups_to_use_for_leftovers = math.min(max_total_groups_to_use_for_leftovers, effective_max_groups)


    for i=1, #group_ids_sorted_by_fullness do
            local gid_ref = group_ids_sorted_by_fullness[i].id
            if not wb_dist[gid_ref] then wb_dist[gid_ref] = {} end
            group_ids_sorted_by_fullness[i].current_size_in_wb_dist = #wb_dist[gid_ref]
    end
    table.sort(group_ids_sorted_by_fullness, function(a,b) return a.current_size_in_wb_dist < b.current_size_in_wb_dist or (a.current_size_in_wb_dist == b.current_size_in_wb_dist and a.id < b.id) end)

        if has_partial_group_val and num_groups_that_can_be_full < effective_max_groups then
            local partial_gid_candidate = num_groups_that_can_be_full + 1
            if partial_gid_candidate <= max_total_groups_to_use_for_leftovers then -- Ensure candidate is within allowed range
                if not wb_dist[partial_gid_candidate] then wb_dist[partial_gid_candidate] = {} end
                if #wb_dist[partial_gid_candidate] < AB_const.GROUP_SIZE then
                    initial_target_gid_for_leftover = partial_gid_candidate
                end
            end
        end

        if initial_target_gid_for_leftover == -1 then
            for i = 1, max_total_groups_to_use_for_leftovers do
                local gid_struct = group_ids_sorted_by_fullness[i]
                if gid_struct then
                    local gid_to_check = gid_struct.id
                    if not wb_dist[gid_to_check] then wb_dist[gid_to_check] = {} end
                    if #wb_dist[gid_to_check] < AB_const.GROUP_SIZE then
                        initial_target_gid_for_leftover = gid_to_check
                        break
                    end
                end
            end
            AB_util.debug("AB_template.match: Leftovers fallback initial_target_gid: " .. tostring(initial_target_gid_for_leftover))
        else
             AB_util.debug("AB_template.match: Leftovers initial_target_gid (partial): " .. initial_target_gid_for_leftover)
        end

    if initial_target_gid_for_leftover ~= -1 and max_total_groups_to_use_for_leftovers > 0 then
      AB_template.left_over(wb_obj, wb_dist, roles_not_taken, bins, initial_target_gid_for_leftover, max_total_groups_to_use_for_leftovers)
    else
      AB_util.debug("AB_template.match: No group found for leftovers or max_total_groups_to_use is 0. " .. left_over_count .. " players remain unplaced.")
    end
  end
  AB_util.debug("AB_template.match: Final wb_dist total players: " .. AB_util.size_wb(wb_dist))
  if AutoBand.debugon then AB_util.print_wb(wb_dist) end
end

function AB_template.find_min_groupid(role_id_to_place, num_primary_groups_to_check, all_group_ids_struct_list, current_wb_dist, role_counts_per_group)
  local opt_role_ratio = AB_const.GROUP_SIZE + 1
  local opt_overall_size = AB_const.GROUP_SIZE + 1
  local opt_gid = -1

  -- Phase 1: Consider primary 'num_primary_groups_to_check' groups (which are sorted by current_size_in_wb_dist)
  local groups_to_evaluate_phase1 = {}
  for i = 1, num_primary_groups_to_check do
    if all_group_ids_struct_list[i] then table.insert(groups_to_evaluate_phase1, all_group_ids_struct_list[i]) end
  end
  if #groups_to_evaluate_phase1 == 0 and #all_group_ids_struct_list > 0 then
        -- If num_primary_groups_to_check was 0 but there are groups, consider all
        if AutoBand.debugon then AB_util.debug("find_min_groupid: num_primary_groups_to_check was 0, evaluating all groups.") end
        groups_to_evaluate_phase1 = all_group_ids_struct_list
    elseif #groups_to_evaluate_phase1 == 0 then
         if AutoBand.debugon then AB_util.debug("find_min_groupid: No groups to evaluate in phase 1.") end
    end


  for _, current_gid_struct in ipairs(groups_to_evaluate_phase1) do
    local gid = current_gid_struct.id
        if not current_wb_dist[gid] then current_wb_dist[gid] = {} end -- Ensure group table exists

    if #current_wb_dist[gid] < AB_const.GROUP_SIZE then
      local current_role_count_in_group = role_counts_per_group[role_id_to_place][gid]
      local current_total_players_in_group = #current_wb_dist[gid]

      if (current_role_count_in_group < opt_role_ratio) then
        opt_role_ratio = current_role_count_in_group; opt_gid = gid; opt_overall_size = current_total_players_in_group
      elseif (current_role_count_in_group == opt_role_ratio) then
        if (current_total_players_in_group < opt_overall_size) then
          opt_gid = gid; opt_overall_size = current_total_players_in_group
        elseif (current_total_players_in_group == opt_overall_size and gid < opt_gid) then
          opt_gid = gid
        end
      end
    end
  end

  if opt_gid == -1 and num_primary_groups_to_check < #all_group_ids_struct_list then
    if AutoBand.debugon then AB_util.debug("find_min_groupid: Fallback - primary " .. num_primary_groups_to_check .. " groups unsuitable/full for role " .. role_id_to_place .. ". Checking all groups.") end
    for _, gid_struct in ipairs(all_group_ids_struct_list) do
      local gid_fallback = gid_struct.id
            if not current_wb_dist[gid_fallback] then current_wb_dist[gid_fallback] = {} end
      if #current_wb_dist[gid_fallback] < AB_const.GROUP_SIZE then
        local current_role_count_in_group = role_counts_per_group[role_id_to_place][gid_fallback]
        local current_total_players_in_group = #current_wb_dist[gid_fallback]
        if opt_gid == -1 or (current_role_count_in_group < opt_role_ratio) or
          (current_role_count_in_group == opt_role_ratio and current_total_players_in_group < opt_overall_size) or
          (current_role_count_in_group == opt_role_ratio and current_total_players_in_group == opt_overall_size and gid_fallback < opt_gid) then
          opt_role_ratio = current_role_count_in_group; opt_gid = gid_fallback; opt_overall_size = current_total_players_in_group
        end
      end
    end
  end

  if opt_gid == -1 and #all_group_ids_struct_list > 0 then
    for _, gid_struct_final_fallback in ipairs(all_group_ids_struct_list) do
            if not current_wb_dist[gid_struct_final_fallback.id] then current_wb_dist[gid_struct_final_fallback.id] = {} end
      if #current_wb_dist[gid_struct_final_fallback.id] < AB_const.GROUP_SIZE then
        opt_gid = gid_struct_final_fallback.id
        if AutoBand.debugon then AB_util.debug("find_min_groupid: Ultimate fallback to G" .. opt_gid .. " as it has space.") end
        break
      end
    end
  end

  if opt_gid == -1 then
    if AutoBand.debugon then AB_util.debug("****[WARN] find_min_groupid: Could not find ANY suitable group for role " .. role_id_to_place .. ". All groups may be full.") end
  end
  return opt_gid
end

function AB_template.find_max_groupid(role_id_to_place, num_primary_groups_to_check, all_group_ids_struct_list, current_wb_dist, role_counts_per_group)
  local opt_role_ratio = -1
  local opt_overall_size = -1
  local opt_gid = -1

  local groups_to_evaluate_phase1 = {}
  for i = 1, num_primary_groups_to_check do
    if all_group_ids_struct_list[i] then table.insert(groups_to_evaluate_phase1, all_group_ids_struct_list[i]) end
  end
    if #groups_to_evaluate_phase1 == 0 and #all_group_ids_struct_list > 0 then
        if AutoBand.debugon then AB_util.debug("find_max_groupid: num_primary_groups_to_check was 0, evaluating all groups.") end
        groups_to_evaluate_phase1 = all_group_ids_struct_list
    elseif #groups_to_evaluate_phase1 == 0 then
         if AutoBand.debugon then AB_util.debug("find_max_groupid: No groups to evaluate in phase 1.") end
    end


  for _, current_gid_struct in ipairs(groups_to_evaluate_phase1) do
    local gid = current_gid_struct.id
        if not current_wb_dist[gid] then current_wb_dist[gid] = {} end
    if #current_wb_dist[gid] < AB_const.GROUP_SIZE then
      local current_role_count_in_group = role_counts_per_group[role_id_to_place][gid]
      local current_total_players_in_group = #current_wb_dist[gid]

      if (current_role_count_in_group > opt_role_ratio) then
        opt_role_ratio = current_role_count_in_group; opt_gid = gid; opt_overall_size = current_total_players_in_group
      elseif (current_role_count_in_group == opt_role_ratio) then
        if (opt_role_ratio == 0 and current_total_players_in_group < opt_overall_size) then
          opt_gid = gid; opt_overall_size = current_total_players_in_group
        elseif (opt_role_ratio > 0 and current_total_players_in_group > opt_overall_size) then
          opt_gid = gid; opt_overall_size = current_total_players_in_group
        elseif (current_total_players_in_group == opt_overall_size and gid > opt_gid) then -- Prefer higher GID to spread aggregation
          opt_gid = gid
        end
      end
    end
  end

  if opt_gid == -1 and num_primary_groups_to_check < #all_group_ids_struct_list then
    if AutoBand.debugon then AB_util.debug("find_max_groupid: Fallback - primary " .. num_primary_groups_to_check .. " groups unsuitable/full for role " .. role_id_to_place .. ". Checking all groups.") end
    for _, gid_struct in ipairs(all_group_ids_struct_list) do
      local gid_fallback = gid_struct.id
            if not current_wb_dist[gid_fallback] then current_wb_dist[gid_fallback] = {} end
      if #current_wb_dist[gid_fallback] < AB_const.GROUP_SIZE then
        local current_role_count_in_group = role_counts_per_group[role_id_to_place][gid_fallback]
        local current_total_players_in_group = #current_wb_dist[gid_fallback]
        if opt_gid == -1 or (current_role_count_in_group > opt_role_ratio) or
         (current_role_count_in_group == opt_role_ratio and ((opt_role_ratio == 0 and current_total_players_in_group < opt_overall_size) or (opt_role_ratio > 0 and current_total_players_in_group > opt_overall_size))) or
         (current_role_count_in_group == opt_role_ratio and current_total_players_in_group == opt_overall_size and gid_fallback > opt_gid) then
          opt_role_ratio = current_role_count_in_group; opt_gid = gid_fallback; opt_overall_size = current_total_players_in_group
        end
      end
    end
  end

  if opt_gid == -1 and #all_group_ids_struct_list > 0 then
    for i = #all_group_ids_struct_list, 1, -1 do -- Check from the "end" of sorted list (often fuller, for aggregation)
      local gid_struct_final_fallback = all_group_ids_struct_list[i]
            if not current_wb_dist[gid_struct_final_fallback.id] then current_wb_dist[gid_struct_final_fallback.id] = {} end
      if #current_wb_dist[gid_struct_final_fallback.id] < AB_const.GROUP_SIZE then
        opt_gid = gid_struct_final_fallback.id
        if AutoBand.debugon then AB_util.debug("find_max_groupid: Ultimate fallback to G" .. opt_gid .. " as it has space.") end
        break
      end
    end
  elseif opt_gid == -1 then
    if AutoBand.debugon then AB_util.debug("****[WARN] find_max_groupid: Could not find ANY suitable group for role " .. role_id_to_place) end
  end
  return opt_gid
end

function AB_template.from_bins_spread(wb_obj, wb_dist, roles_not_taken, bins, role_per_group, ngrp, group_ids_sorted_by_initial_fullness, max_players_to_place_in_this_phase)
  AB_util.debug("from_bins_spread: ngrp=" .. ngrp .. ", max_players_to_place_in_this_phase=" .. tostring(max_players_to_place_in_this_phase))
  local players_placed_in_this_func = 0

  if not max_players_to_place_in_this_phase or max_players_to_place_in_this_phase <= 0 then
        AB_util.debug("from_bins_spread: No players to place in this phase or no slots in target groups.")
        return
    end

  local bid = 1
  local loop_watchdog = 0
  local effective_ngrp_for_find = ngrp

  while players_placed_in_this_func < max_players_to_place_in_this_phase do
    loop_watchdog = loop_watchdog + 1
    if loop_watchdog > max_players_to_place_in_this_phase * 4 * 2 + AB_const.LOOP_MAX then
      AB_util.debug("****[ERROR] from_bins_spread: Watchdog. Placed: " .. players_placed_in_this_func .. "/" .. max_players_to_place_in_this_phase .. ". Bins left: " .. AB_util.size_wb(bins))
      break
    end

        if AB_util.size_wb(bins) == 0 then
            AB_util.debug("from_bins_spread: All bins empty. Placed: " .. players_placed_in_this_func)
            break
        end

    local current_role_bin = bins[bid]
    if current_role_bin and #current_role_bin > 0 then
      local opt_gid = AB_template.find_min_groupid_strict(bid, effective_ngrp_for_find, group_ids_sorted_by_initial_fullness, wb_dist, role_per_group)

      if opt_gid and opt_gid ~= -1 and wb_dist[opt_gid] and #wb_dist[opt_gid] < AB_const.GROUP_SIZE then
        local picked_player = AB_template.pick_player_for_slot(current_role_bin, opt_gid, wb_dist[opt_gid], wb_dist) -- Pass current state of wb_dist[opt_gid]
        if picked_player then
          table.insert(wb_dist[opt_gid], picked_player) -- Store the full player object
          table.insert(roles_not_taken[picked_player.role], opt_gid)
          role_per_group[bid][opt_gid] = role_per_group[bid][opt_gid] + 1
          for _, g_entry in ipairs(group_ids_sorted_by_initial_fullness) do if g_entry.id == opt_gid then g_entry.current_size_in_wb_dist = #wb_dist[opt_gid]; break; end end
          players_placed_in_this_func = players_placed_in_this_func + 1
        else
                    if AutoBand.debugon then AB_util.debug("from_bins_spread: pick_player_for_slot returned nil for role " .. bid .. " in G" .. opt_gid) end
                end
      else
        if AutoBand.debugon then
                    if opt_gid and opt_gid ~= -1 and wb_dist[opt_gid] then
                        AB_util.debug("from_bins_spread: Opt GID " .. opt_gid .. " is full (#" .. #wb_dist[opt_gid] .. ") or find_min_groupid_strict returned no valid group for role " .. bid .. " within the " .. effective_ngrp_for_find .. " target groups.")
                    elseif opt_gid == -1 then
                        AB_util.debug("from_bins_spread: find_min_groupid_strict returned -1 for role " .. bid .. " within " .. effective_ngrp_for_find .. " groups. Bin size " .. #current_role_bin)
                    else
                         AB_util.debug("from_bins_spread: Opt GID " .. tostring(opt_gid) .. " issue for role " .. bid .. "; bin size: " .. #current_role_bin)
                    end
                end
      end
    end

    bid = bid + 1
    if bid > 4 then bid = 1; end
  end
  AB_util.debug("from_bins_spread: Finished. Players placed in this phase: " .. players_placed_in_this_func .. " (target: " .. max_players_to_place_in_this_phase .. ")")
end

function AB_template.from_bins_aggregate(wb_obj, wb_dist, roles_not_taken, bins, role_per_group, ngrp, group_ids_sorted_by_initial_fullness, max_players_to_place_in_this_phase)
  AB_util.debug("from_bins_aggregate: ngrp=" .. ngrp .. ", max_players_to_place_in_this_phase=" .. tostring(max_players_to_place_in_this_phase))
  local players_placed_in_this_func = 0

  if not max_players_to_place_in_this_phase or max_players_to_place_in_this_phase <= 0 then
        AB_util.debug("from_bins_aggregate: No players to place in this phase.")
        return
    end

  local bid = 1
  local loop_watchdog = 0
  local effective_ngrp_for_find = ngrp

  while players_placed_in_this_func < max_players_to_place_in_this_phase do
    loop_watchdog = loop_watchdog + 1
    if loop_watchdog > max_players_to_place_in_this_phase * 4 * 2 + AB_const.LOOP_MAX then
      AB_util.debug("****[ERROR] from_bins_aggregate: Watchdog. Placed: " .. players_placed_in_this_func .. "/" .. max_players_to_place_in_this_phase)
      break
    end

        if AB_util.size_wb(bins) == 0 then
            AB_util.debug("from_bins_aggregate: All bins empty. Placed: " .. players_placed_in_this_func)
            break
        end

    local current_role_bin = bins[bid]
    if current_role_bin and #current_role_bin > 0 then
      local opt_gid
      if (bid == AB_const.ROLE_CATEGORIES[AutoBand.saved.org_algo_role]) then
        opt_gid = AB_template.find_min_groupid_strict(bid, effective_ngrp_for_find, group_ids_sorted_by_initial_fullness, wb_dist, role_per_group)
      else
        opt_gid = AB_template.find_max_groupid_strict(bid, effective_ngrp_for_find, group_ids_sorted_by_initial_fullness, wb_dist, role_per_group)
      end

      if opt_gid and opt_gid ~= -1 and wb_dist[opt_gid] and #wb_dist[opt_gid] < AB_const.GROUP_SIZE then
        local picked_player = AB_template.pick_player_for_slot(current_role_bin, opt_gid, wb_dist[opt_gid], wb_dist) -- Pass current state of wb_dist[opt_gid]
        if picked_player then
          table.insert(wb_dist[opt_gid], picked_player) -- Store the full player object
          table.insert(roles_not_taken[picked_player.role], opt_gid)
          role_per_group[bid][opt_gid] = role_per_group[bid][opt_gid] + 1
          for _, g_entry in ipairs(group_ids_sorted_by_initial_fullness) do if g_entry.id == opt_gid then g_entry.current_size_in_wb_dist = #wb_dist[opt_gid]; break; end end
          players_placed_in_this_func = players_placed_in_this_func + 1
        else
                     if AutoBand.debugon then AB_util.debug("from_bins_aggregate: pick_player_for_slot returned nil for role " .. bid .. " in G" .. opt_gid) end
                end
      else
                 if AutoBand.debugon then
                    if opt_gid and opt_gid ~= -1 and wb_dist[opt_gid] then
                        AB_util.debug("from_bins_aggregate: Opt GID " .. opt_gid .. " is full (#" .. #wb_dist[opt_gid] .. ") or find_max/min_groupid_strict returned no valid group for role " .. bid .. " within the " .. effective_ngrp_for_find .. " target groups.")
                    elseif opt_gid == -1 then
                         AB_util.debug("from_bins_aggregate: find_max/min_groupid_strict returned -1 for role " .. bid .. " within " .. effective_ngrp_for_find .. " groups. Bin size " .. #current_role_bin)
                    else
                         AB_util.debug("from_bins_aggregate: Opt GID " .. tostring(opt_gid) .. " issue for role " .. bid .. "; bin size: " .. #current_role_bin)
                    end
                end
      end
    end

    bid = bid + 1
    if bid > 4 then bid = 1; end
  end
  AB_util.debug("from_bins_aggregate: Finished. Players placed in this phase: " .. players_placed_in_this_func .. " (target: " .. max_players_to_place_in_this_phase .. ")")
end

function AB_template.left_over(wb_obj, wb_dist, roles_not_taken, bins, initial_target_gid, max_groups_to_fill_with_leftovers)
    if not initial_target_gid or initial_target_gid == -1 or not max_groups_to_fill_with_leftovers or max_groups_to_fill_with_leftovers <= 0 then
        AB_util.debug("left_over: No valid initial_target_gid ("..tostring(initial_target_gid)..") or max_groups_to_fill_with_leftovers ("..tostring(max_groups_to_fill_with_leftovers)..") is invalid.")
        if AB_util.size_wb(bins) > 0 then
            AB_util.debug("left_over: Cannot place " .. AB_util.size_wb(bins) .. " players under these constraints.")
        end
        return
    end

    local current_target_gid = initial_target_gid
    AB_util.debug("left_over: Initial target G" .. current_target_gid .. ". Max group to fill up to is G" .. max_groups_to_fill_with_leftovers)

    local role_iteration_order = {1, 2, 3, 4} -- Example: Healer, Tank, MDPS, RDPS (can be adjusted)

    for _, role_id in ipairs(role_iteration_order) do
        local bin_content = bins[role_id]
        if bin_content then
            local watchdog_bin = 0
            while #bin_content > 0 do
                watchdog_bin = watchdog_bin + 1
                if watchdog_bin > (AB_const.GROUP_SIZE * max_groups_to_fill_with_leftovers) + 5 then
                    AB_util.debug("left_over: Inner watchdog for role_id " .. role_id .. " on G" .. current_target_gid)
                    break
                end

                if not wb_dist[current_target_gid] then wb_dist[current_target_gid] = {} end

                if #wb_dist[current_target_gid] < AB_const.GROUP_SIZE then
                    local player_entry = AB_template.pick_player_for_slot(bin_content, current_target_gid, wb_dist[current_target_gid], wb_dist) -- Pass current state
                    if player_entry then
                        table.insert(wb_dist[current_target_gid], player_entry) -- Store the full player object
                        table.insert(roles_not_taken[player_entry.role], current_target_gid)
                        if AutoBand.debugon then
                            local name_str = player_entry.name and tostring(player_entry.name) or "UnknownName"
                            AB_util.print("Leftover placed: " .. name_str .. " (Role: " .. player_entry.role .. ") in G" .. current_target_gid)
                        end
                    else
                        AB_util.debug("left_over: pick_player_for_slot returned nil for role_id " .. role_id .. " targeting G" .. current_target_gid .. ". Bin size: " .. #bin_content .. ". Trying next role or group.")
                        break
                    end
                else
                    local next_gid_found_within_limit = false
                    if current_target_gid < max_groups_to_fill_with_leftovers then
                        for next_g = current_target_gid + 1, max_groups_to_fill_with_leftovers do
                            if not wb_dist[next_g] then wb_dist[next_g] = {} end
                            if #wb_dist[next_g] < AB_const.GROUP_SIZE then
                                current_target_gid = next_g
                                next_gid_found_within_limit = true
                                AB_util.debug("left_over: Switched to next allowed group G" .. current_target_gid)
                                break
                            end
                        end
                    end

                    if not next_gid_found_within_limit then
                        AB_util.debug("left_over: All allowed groups (G" .. initial_target_gid .. " to G" .. max_groups_to_fill_with_leftovers .. ") are full or cannot place current role. Players in this bin ("..role_id.."): " .. #bin_content)
                        break
                    end
                end
            end
        end
    end
    AB_util.debug("left_over: Finished processing leftovers.")
end
