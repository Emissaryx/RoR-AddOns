-- ab_wb.lua

AB_wb = {
    group = {},
    player_count = 0,
    group_count = 0,
    fullgroup_count = 0,
    remainder = 0,
    MAX_GROUPS = 0			-- max number of groups (wb=4, sc=6)
}

-- Mapping of healer careers to the career line used when the player
-- is detected as playing a damage spec via RoRGroupScoreboard.
local ALT_SPEC_TRANSFORMS = {
    [GameData.CareerLine.ZEALOT]        = GameData.CareerLine.MAGUS,
    [GameData.CareerLine.WARRIOR_PRIEST] = GameData.CareerLine.SLAYER,
    [GameData.CareerLine.RUNE_PRIEST]    = GameData.CareerLine.ENGINEER,
    [GameData.CareerLine.ARCHMAGE]       = GameData.CareerLine.ENGINEER,
    [GameData.CareerLine.SHAMAN]         = GameData.CareerLine.MAGUS,
    [GameData.CareerLine.DISCIPLE]       = GameData.CareerLine.CHOPPA,
    [GameData.CareerLine.SQUIG_HERDER]   = GameData.CareerLine.CHOPPA,
    [GameData.CareerLine.SHADOW_WARRIOR] = GameData.CareerLine.SLAYER,
}

-- Build a lookup table of players running alt specs based on
-- RoRGroupScoreboard data. Keys are string player names, values are true.
local function build_alt_spec_lookup()
    local lookup = {}
    if RoRGroupScoreboard and RoRGroupScoreboard.playersDataRaw then
        for _, pdata in pairs(RoRGroupScoreboard.playersDataRaw) do
            if pdata.archtype and pdata.archtype > 0 and pdata.name then
                lookup[tostring(pdata.name)] = true
            end
        end
    end
    return lookup
end

-- default ctor
function AB_wb:new(t)
    t = t or {}
    setmetatable(t, self)
    self.__index = self
    return t
end

function AB_wb:set_groups()
    self.group = {}
    self.player_count = 0
    self.MAX_GROUPS = AB_const.MAX_WB_GROUPS
    for i= 1, AB_const.MAX_WB_GROUPS do
        self.group[i] = {}
    end
end

function AB_wb:add_to_gid(role, pid, gid)
    local player = {["name"]= "Fake_" .. gid .. "_" .. pid }
    for key, fake in pairs(AB_const.FAKE_PLAYERS[role]) do
        player[key] = fake
    end
    player.role = role
    player.online = false
    player.zid = 0
--	self.group[gid] = self.group[gid] or {}
    table.insert(self.group[gid], player)
    self.player_count = self.player_count + 1
end

-- loads group data from scenario party
function AB_wb:load_from_scdata()
    self.group = {}
    self.player_count = 0
    local current_players = {}
    local alt_lookup = nil
    if AutoBand.saved.alt_speccheck_enabled then
        alt_lookup = build_alt_spec_lookup()
    end

    local scdata = GameData.GetScenarioPlayerGroups() -- get scenario wb
    for _, player in ipairs(scdata) do
        if (self.group[player.sgroupindex] == nil) then
            self.group[player.sgroupindex] = {}
        end
        local name_lower = tostring(player.name):lower()
        local override = AutoBand.saved.custom_roles and AutoBand.saved.custom_roles[name_lower]
        local base_career = player.careerLine
        local role = nil
        local role_source = "archetype" -- Default source

        -- Determine effective career from alt-spec
        local effective_career = base_career
        if AutoBand.saved.alt_speccheck_enabled then
            local career_after_alt_check = AB_wb:getArcheType(player, alt_lookup)
            if career_after_alt_check ~= base_career then
                role_source = "spec check"
                effective_career = career_after_alt_check
            end
        end

        role = AB_util.career_category(effective_career)

        -- Check for BW/Sorc as MDPS toggle
        if AutoBand.saved.bw_sorc_as_mdps then
            if base_career == GameData.CareerLine.BRIGHT_WIZARD or base_career == GameData.CareerLine.SORCERER then
                if role ~= AB_const.MDPS then
                    role = AB_const.MDPS
                    if AutoBand.faction == AB_const.ORDER then
                        role_source = "BW as mDPS"
                    elseif AutoBand.faction == AB_const.DESTRUCTION then
                        role_source = "Sorc as mDPS"
                    else
                        role_source = "BW/Sorc as mDPS"
                    end
                end
            end
        end

        -- Check for custom role override (highest priority)
        if override and (override == AB_const.TANK or override == AB_const.HEALER or override == AB_const.MDPS or override == AB_const.RDPS) then
            role = override
            role_source = "role override"
        end

        player.role = role
        player.role_source = role_source
        self.group[player.sgroupindex][player.sgroupslotnum] = player
        self.player_count = self.player_count + 1
        AB_wb:track_role(player, current_players)
    end
    AB_wb:remove_missing_players(current_players)
    AutoBand.need_role_update = false
    self.MAX_GROUPS = 6
    self:recalc_counters()
end

-- loads group data from warband party
function AB_wb:load_from_wbdata()
    self.group = {}
    self.player_count = 0
    local current_players = {}
    local alt_lookup = nil
    if AutoBand.saved.alt_speccheck_enabled then
        alt_lookup = build_alt_spec_lookup()
    end
    local wbdata = GetBattlegroupMemberData()
    for i in ipairs(wbdata) do
        self.group[i] = {}
    end
    for gid, grp in ipairs(wbdata) do
        for pid, player in ipairs(grp.players) do
            local name_lower = tostring(player.name):lower()
            local override = AutoBand.saved.custom_roles and AutoBand.saved.custom_roles[name_lower]
            local base_career = player.careerLine
            local role = nil
            local role_source = "archetype"

            -- Determine effective career from alt-spec
            local effective_career = base_career
            if AutoBand.saved.alt_speccheck_enabled then
                local career_after_alt_check = AB_wb:getArcheType(player, alt_lookup)
                if career_after_alt_check ~= base_career then
                    role_source = "spec check"
                    effective_career = career_after_alt_check
                end
            end

            role = AB_util.career_category(effective_career)

            -- Check for BW/Sorc as MDPS toggle
            if AutoBand.saved.bw_sorc_as_mdps then
                if base_career == GameData.CareerLine.BRIGHT_WIZARD or base_career == GameData.CareerLine.SORCERER then
                    if role ~= AB_const.MDPS then
                        role = AB_const.MDPS
                        if AutoBand.faction == AB_const.ORDER then
                            role_source = "BW as mDPS"
                        elseif AutoBand.faction == AB_const.DESTRUCTION then
                            role_source = "Sorc as mDPS"
                        else
                            role_source = "BW/Sorc as mDPS"
                        end
                    end
                end
            end

            -- Check for custom role override (highest priority)
            if override and (override == AB_const.TANK or override == AB_const.HEALER or override == AB_const.MDPS or override == AB_const.RDPS) then
                role = override
                role_source = "role override"
            end

            player.role = role
            player.role_source = role_source
            table.insert(self.group[gid], player)
            self.player_count = self.player_count + 1
            AB_wb:track_role(player, current_players)
        end
    end
    AB_wb:remove_missing_players(current_players)
    AutoBand.need_role_update = false
    self.MAX_GROUPS = AB_const.MAX_WB_GROUPS
    self:recalc_counters()
end

-- Function that checks if player is using alt-spec and returns careerLine value accordingly
function AB_wb:getArcheType(player, alt_lookup)
    local name_str = tostring(player.name)
    if alt_lookup and alt_lookup[name_str] then
        return ALT_SPEC_TRANSFORMS[player.careerLine] or player.careerLine
    end

    if alt_lookup == nil then
        if not RoRGroupScoreboard or not RoRGroupScoreboard.playersDataRaw then
            return player.careerLine
        end
        for _, p in pairs(RoRGroupScoreboard.playersDataRaw) do
            if p.name == towstring(player.name) and p.archtype > 0 then
                return ALT_SPEC_TRANSFORMS[player.careerLine] or player.careerLine
            end
        end
    end

    return player.careerLine
end

function AB_wb:track_role(player, current_players)
    local name = tostring(player.name)
    local new_role = tostring(player.role)
    local role_source = player.role_source or "archetype" -- Fallback just in case
    current_players[name] = true

    local prev_role = roles_last[name]
    local icon = AB_const.ICONS[new_role] or ""

    if AutoBand.saved.printrole_enabled and not AutoBand.suppressRoleNotifs then
        local source_text = " (via " .. role_source .. ")"

        if not prev_role then
            AB_util.print(name .. " assigned role " .. icon .. " " .. new_role .. source_text .. ".")
        elseif prev_role ~= new_role then
            local prev_icon = AB_const.ICONS[prev_role] or ""
            AB_util.print(name .. " reassigned role from " .. prev_icon .. " " .. prev_role .. " to " .. icon .. " " .. new_role .. source_text .. ".")
        end
    end

    roles_last[name] = new_role
end

function AB_wb:remove_missing_players(current_players)
    local MAX_DETAILED_LEAVERS = 4
    local leavers = {}

    for name in pairs(roles_last) do
        if not current_players[name] then
            table.insert(leavers, name)
        end
    end

    if AutoBand.saved.printrole_enabled and #leavers > 0 then
        if #leavers <= MAX_DETAILED_LEAVERS then
            for _, name in ipairs(leavers) do
                local role = roles_last[name]
                local icon = AB_const.ICONS[role] or ""
                AB_util.print(name .. " (" .. icon .. " " .. role .. ") left.")
            end
        else
            AB_util.print(#leavers .. " assigned roles cleared from the warband roster.")
        end
    end

    for _, name in ipairs(leavers) do
        roles_last[name] = nil
    end
end

-- iterates over every player in data calling "f(group id, player object, player position)"
function AB_wb:foreach_player(func)
    for i, grp in ipairs(self.group) do
        for j, player in ipairs(grp) do
            func(i, player, j)
        end
    end
end

--
function AB_wb:recalc_counters()
    self.group_count = math.ceil(self.player_count / AB_const.GROUP_SIZE)		-- total number of groups
    self.fullgroup_count = math.floor(self.player_count / AB_const.GROUP_SIZE)	-- full groups
    self.remainder = self.player_count % AB_const.GROUP_SIZE			-- last group size
    if (self.remainder > math.floor(AB_const.GROUP_SIZE / 2)) then
        self.fullgroup_count = self.fullgroup_count + 1
        self.remainder = 0
    end
end

--
function AB_wb:print()
    AB_util.print("groups: " .. self.group_count)
    AB_util.print("full groups: " .. self.fullgroup_count)
    AB_util.print("remainder group size: " .. self.remainder)
    self:foreach_player(
        function (gid, player, pid)
            AB_util.print("gid " .. gid .. " " .. tostring(player.name) .. " " .. player.role)
        end
    )
end
