-- AutoBand.lua

AutoBand = {}
tanks_t_old = {}
healers_t_old = {}
dps_t_old = {}
mdps_t_old = {}
rdps_t_old = {}
roles_last = {}
toofar = {}
toofar_old = {}
toofar_not_changed = {}
warned = {}
number = 0
number2 = 12
g_m = {}
ign = {}
guild_members = {}

local AVAILABLE_COLORS = AB_const.AVAILABLE_COLORS
local MAX_MAP_POINTS = 511
local DISTANCE_FIX_COEFFICIENT = 1 / 1.06
local MapPointTypeFilter = {
    [SystemData.MapPips.PLAYER] = true,
    [SystemData.MapPips.GROUP_MEMBER] = true,
    [SystemData.MapPips.WARBAND_MEMBER] = true,
    [SystemData.MapPips.DESTRUCTION_ARMY] = true,
    [SystemData.MapPips.ORDER_ARMY] = true
}

function AutoBand.init()
    --------------------------------------------------------------------------
    -- 1) MODULE VARIABLES
    --------------------------------------------------------------------------
    AutoBand.cmd_queue          = {}
    AutoBand.cmd_current        = nil
    AutoBand.debugon            = false
    AutoBand.gizilon            = false
    AutoBand.offliners_countdown = {}
    AutoBand.has_shortslash     = false
    AutoBand.elapsed            = 0
    AutoBand.faction            = nil
    AutoBand.factionDetermined  = false
    AutoBand.race               = nil
    AutoBand.raceDetermined     = false
    AutoBand.playername         = nil
    AutoBand.nameDetermined     = false
    AutoBand.current_purpose    = nil
    AutoBand.cached_wb          = nil
    AutoBand.cache_dirty        = true

    --------------------------------------------------------------------------
    -- 2) PERSISTENT SETTINGS
    --------------------------------------------------------------------------
    -- A) CORE "SAVED" TABLE & CUSTOM ROLES
    AutoBand.saved               = AutoBand.saved or {}
    AutoBand.saved.custom_roles  = AutoBand.saved.custom_roles or {}

    -- A.1) ROLE COMPOSITION LIMITS
    AutoBand.saved.max_tanks   = AutoBand.saved.max_tanks   or AB_const.DEFAULT_MAX_TANKS
    AutoBand.saved.max_healers = AutoBand.saved.max_healers or AB_const.DEFAULT_MAX_HEALERS
    AutoBand.saved.max_dps     = AutoBand.saved.max_dps     or AB_const.DEFAULT_MAX_DPS

    -- Validate that loaded/default roles add up to 24
    if AutoBand.saved.max_tanks + AutoBand.saved.max_healers + AutoBand.saved.max_dps ~= 24 then
        AB_util.print("[Warning] Saved role counts did not sum to 24. Resetting to defaults (" .. AB_const.DEFAULT_MAX_TANKS .. "-" .. AB_const.DEFAULT_MAX_HEALERS .. "-" .. AB_const.DEFAULT_MAX_DPS .. ").")
        AutoBand.saved.max_tanks   = AB_const.DEFAULT_MAX_TANKS
        AutoBand.saved.max_healers = AB_const.DEFAULT_MAX_HEALERS
        AutoBand.saved.max_dps     = AB_const.DEFAULT_MAX_DPS
    end

    -- B) CORE TOGGLES
    if AutoBand.saved.autokick_enabled        == nil then AutoBand.saved.autokick_enabled        = AB_const.AUTOKICK          end
    if AutoBand.saved.autokick_toofar_enabled == nil then AutoBand.saved.autokick_toofar_enabled = AB_const.AUTOKICKTOOFAR    end
    if AutoBand.saved.autokick_lowrnk_enabled == nil then AutoBand.saved.autokick_lowrnk_enabled = AB_const.KICKLOWRNK        end
    if AutoBand.saved.autonote_enabled        == nil then AutoBand.saved.autonote_enabled        = AB_const.AUTONOTE          end
    if AutoBand.saved.notify_buffs_enabled    == nil then AutoBand.saved.notify_buffs_enabled    = true                       end
    if AutoBand.saved.autokick_we_wh_enabled  == nil then AutoBand.saved.autokick_we_wh_enabled  = AB_const.AUTOKICK_WE_WH    end
    if AutoBand.saved.autokick_rvrzone_enabled== nil then AutoBand.saved.autokick_rvrzone_enabled= AB_const.AUTOKICKRVRZONE   end
    if AutoBand.saved.bw_sorc_as_mdps         == nil then AutoBand.saved.bw_sorc_as_mdps         = AB_const.BW_SORC_AS_MDPS   end
    if AutoBand.saved.restrict_same_race      == nil then AutoBand.saved.restrict_same_race      = AB_const.RESTRICT_RACE     end

    -- C) KICK TIMERS & RANK RULES
    AutoBand.saved.autokick_period   = AutoBand.saved.autokick_period   or AB_const.KICK_PERIOD
    AutoBand.saved.min_rank          = AutoBand.saved.min_rank          or AB_const.MINIMUM_RANK
    AutoBand.saved.min_rank_healer   = AutoBand.saved.min_rank_healer   or AB_const.MINIMUM_RANK_HEALER

    if AutoBand.saved.min_rank_healer > AutoBand.saved.min_rank then
        local old_healer_rank         = AutoBand.saved.min_rank_healer
        AutoBand.saved.min_rank_healer = AutoBand.saved.min_rank
    end

    -- D) TEMPLATES & ORGANIZATION ALGORITHM
    AutoBand.saved.default_template = AutoBand.saved.default_template or AB_const.EMPTY_TEMPLATE
    AutoBand.saved.templates        = AutoBand.saved.templates        or {}
    AutoBand.saved.org_algo_mode    = AutoBand.saved.org_algo_mode    or AB_const.DEFAULT_ORG_ALGO
    AutoBand.saved.org_algo_role    = AutoBand.saved.org_algo_role    or AB_const.DEFAULT_ORG_ROLE

    -- E) ICON & GUILD PRIORITY
    if AutoBand.saved.displayicon            == nil then AutoBand.saved.displayicon            = true                          end
    if AutoBand.saved.right_click_organize   == nil then AutoBand.saved.right_click_organize   = AB_const.RIGHTCLICKORGANIZE    end
    if AutoBand.saved.guild_priority_enabled == nil then AutoBand.saved.guild_priority_enabled = AB_const.GUILDPRIORITY         end

    -- F) KICK FUNCTION SPECIFICS
    if AutoBand.saved.kick_func_enabled == nil then
        AutoBand.saved.kick_func_enabled = {}
        for k, v in pairs(AB_const.KICK_FUNC_DEFAULT) do
            AutoBand.saved.kick_func_enabled[k] = v
        end
    end

    -- G) ALT SPEC CHECK & ROLE PRINTING
    if AutoBand.saved.alt_speccheck_enabled == nil then AutoBand.saved.alt_speccheck_enabled = AB_const.ALTCHECK  end
    if AutoBand.saved.printrole_enabled     == nil then AutoBand.saved.printrole_enabled     = AB_const.PRINTROLE end

    -- H) DPS WEIGHTING SETTINGS
    if AutoBand.saved.dps_weighting_enabled == nil then AutoBand.saved.dps_weighting_enabled = AB_const.DPS_WEIGHTING_ENABLED end
    AutoBand.saved.max_mdps = AutoBand.saved.max_mdps or AB_const.DEFAULT_MAX_MDPS
    AutoBand.saved.max_rdps = AutoBand.saved.max_rdps or AB_const.DEFAULT_MAX_RDPS

    -- Ensure consistency on load: mdps + rdps must sum to the *current* max_dps
    if AutoBand.saved.max_mdps + AutoBand.saved.max_rdps ~= AutoBand.saved.max_dps then
        AB_util.print("[Warning] Saved mDPS/rDPS counts did not sum to max DPS (" .. AutoBand.saved.max_dps .. "). Resetting mDPS/rDPS based on current max DPS.")
        AutoBand.saved.max_rdps = math.floor(AutoBand.saved.max_dps / 2)
        AutoBand.saved.max_mdps = AutoBand.saved.max_dps - AutoBand.saved.max_rdps
    end

    -- I) PREFIX & COLOR SETTINGS
    if AutoBand.saved.prefix_text        == nil then AutoBand.saved.prefix_text        = AB_const.DEFAULT_PREFIX_TEXT       end
    if AutoBand.saved.prefix_color_name  == nil then AutoBand.saved.prefix_color_name  = AB_const.DEFAULT_PREFIX_COLOR_NAME end
    if AutoBand.saved.lead_color_name    == nil then AutoBand.saved.lead_color_name    = AB_const.DEFAULT_LEAD_COLOR_NAME   end
	if AutoBand.saved.prefix_use_guild   == nil then AutoBand.saved.prefix_use_guild   = AB_const.DEFAULT_PREFIX_USE_GUILD  end

    -- Validate loaded prefix on init, fallback to default if invalid
    if #AutoBand.saved.prefix_text > AB_const.MAX_PREFIX_LENGTH then
        AB_util.print("[Warning] Saved prefix text was too long (>" .. AB_const.MAX_PREFIX_LENGTH .. " characters). Resetting to default.")
        AutoBand.saved.prefix_text = AB_const.DEFAULT_PREFIX_TEXT
    end
    if AutoBand.saved.prefix_text == "" then
        AB_util.print("[Warning] Saved prefix text was empty. Resetting to default.")
        AutoBand.saved.prefix_text = AB_const.DEFAULT_PREFIX_TEXT
    end

    -- Validate loaded colors on init, fallback to default if invalid
    if not AVAILABLE_COLORS[AutoBand.saved.prefix_color_name:lower()] then
        AB_util.print("[Warning] Saved prefix color '" .. AutoBand.saved.prefix_color_name .. "' is invalid. Resetting to default.")
        AutoBand.saved.prefix_color_name = AB_const.DEFAULT_PREFIX_COLOR_NAME
    else
        AutoBand.saved.prefix_color_name = AutoBand.saved.prefix_color_name:lower()
    end

    if not AVAILABLE_COLORS[AutoBand.saved.lead_color_name:lower()] then
        AB_util.print("[Warning] Saved lead color '" .. AutoBand.saved.lead_color_name .. "' is invalid. Resetting to default.")
        AutoBand.saved.lead_color_name = AB_const.DEFAULT_LEAD_COLOR_NAME
    else
        AutoBand.saved.lead_color_name = AutoBand.saved.lead_color_name:lower()
    end

    -- J) DEBUG SETTINGS
    AutoBand.saved.dumps        = AutoBand.saved.dumps or {}
    AutoBand.saved.dumped_wb    = AutoBand.saved.dumped_wb or nil
    AutoBand.saved.default_dump = AutoBand.saved.default_dump or nil

    --------------------------------------------------------------------------
    -- 3) CREATE ZONE ID SET & REGISTER SLASH COMMANDS
    --------------------------------------------------------------------------
    AutoBand.allowed_rvr_zones_set = {}
    for _, zone_id in ipairs(AB_const.ZONEIDS) do
        AutoBand.allowed_rvr_zones_set[zone_id] = true
    end

    LibSlash.RegisterSlashCmd("autoband", function(msg) AutoBand.parse_cmd(msg) end)
    if not LibSlash.IsSlashCmdRegistered("ab") then
        LibSlash.RegisterSlashCmd("ab", function(msg) AutoBand.parse_cmd(msg) end)
        AutoBand.has_shortslash = true
    end

    --------------------------------------------------------------------------
    -- 4) COMMAND LIST INITIALIZATION
    --    (help/info/UI, templates, kicking, zone, ranks, warband org, debug)
    --------------------------------------------------------------------------
    AutoBand.cmd = {
        -- Help/Info & UI
        [""]      = { f = AutoBand.cmd_usage,         help = "",                            print_id = 10 },
        ["help"]  = { f = AutoBand.cmd_usage,         help = "show command list",           print_id = 11 },
        ["info"]  = { f = AutoBand.cmd_show,          help = "show current settings",       print_id = 12 },
        ["show"]  = { f = AutoBand.cmd_toggle_gui,    help = "open/close GUI",              print_id = 13 },
        ["icon"]  = { f = AutoBand.cmd_toggle_icon,   help = "show/hide minimap icon",      print_id = 14 },
        ["rco"]   = { f = AutoBand.cmd_toggle_rco,    help = "toggle right-click organize on icon", print_id = 15 },

        -- Config Commands
        ["setprefix"]        = { f = AutoBand.cmd_set_prefix,          help = "<string> set the chat prefix text",               print_id = 16 },
        ["prefix"]           = { f = AutoBand.cmd_set_prefix,          help = "" },
        ["resetprefix"]      = { f = AutoBand.cmd_reset_prefix,        help = "reset chat prefix text to default",               print_id = 17 },
        ["prefixreset"]      = { f = AutoBand.cmd_reset_prefix,        help = "" },
        ["listcolors"]       = { f = AutoBand.cmd_list_colors,         help = "list available color names",                      print_id = 18 },
        ["listcolor"]        = { f = AutoBand.cmd_list_colors,         help = "" },
        ["prefixcolor"]      = { f = AutoBand.cmd_set_prefix_color,    help = "<color_name> set prefix color",                   print_id = 19 },
        ["colorprefix"]      = { f = AutoBand.cmd_set_prefix_color,    help = "" },
        ["setprefixcolor"]   = { f = AutoBand.cmd_set_prefix_color,    help = "" },
        ["resetprefixcolor"] = { f = AutoBand.cmd_reset_prefix_color,  help = "reset prefix color to default",                   print_id = 20 },
        ["prefixcolorreset"] = { f = AutoBand.cmd_reset_prefix_color,  help = "" },
	    ["prefixguild"]      = { f = AutoBand.cmd_toggle_prefix_guild, help = "toggle using guild name as prefix",               print_id = 21 },
        ["leadcolor"]        = { f = AutoBand.cmd_set_lead_color,      help = "<color_name> set WB lead mention color",          print_id = 22 },
        ["colorlead"]        = { f = AutoBand.cmd_set_lead_color,      help = "" },
        ["setleadcolor"]     = { f = AutoBand.cmd_set_lead_color,      help = "" },
        ["resetleadcolor"]   = { f = AutoBand.cmd_reset_lead_color,    help = "reset WB lead mention color to default",          print_id = 23 },
        ["leadcolorreset"]   = { f = AutoBand.cmd_reset_lead_color,    help = "" },

        -- Templates
        ["list"]    = { f = AutoBand.cmd_list_template,   help = "list all templates",                       print_id = 23 },
        ["save"]    = { f = AutoBand.cmd_save_template,   help = "<name> save current WB template",          print_id = 24 },
        ["apply"]   = { f = AutoBand.cmd_apply_template,  help = "<name> apply template",                    print_id = 25 },
        ["default"] = { f = AutoBand.cmd_default_template,help = "set/clear default template",               print_id = 26 },
        ["mode"]    = { f = AutoBand.cmd_mode,            help = "<num> distribution algorithm mode",        print_id = 27 },

        -- Kick / Auto-Kick
        ["kf"]          = { f = AutoBand.cmd_kick_toofar,            help = "kick all far players",                           print_id = 30 },
        ["ak"]          = { f = AutoBand.cmd_flag_autokick,          help = "toggle autokick low rank/excess roles",          print_id = 31 },
        ["akf"]         = { f = AutoBand.cmd_flag_autokick_toofar,   help = "toggle autokick toofar",                         print_id = 32 },
        ["akl"]         = { f = AutoBand.cmd_flag_autokick_lowrnk,   help = "toggle autokick low rank players",               print_id = 33 },
        ["kicktimeout"] = { f = AutoBand.cmd_autokick_timeout,       help = "<mins> autokick toofar timeout",                 print_id = 34 },
        ["wewhk"]       = { f = AutoBand.cmd_toggle_autokick_we_wh,  help = "toggle autokick WE/WH",                          print_id = 35 },
        ["wek"]         = { f = AutoBand.cmd_toggle_autokick_we_wh,  help = "" },
        ["whk"]         = { f = AutoBand.cmd_toggle_autokick_we_wh,  help = "" },
        ["akz"]         = { f = AutoBand.cmd_flag_autokick_rvrzone,  help = "toggle autokick players in scenarios",           print_id = 36 },
        ["an"]          = { f = AutoBand.cmd_flag_autonote,          help = "toggle autosearch in /1 for roles",              print_id = 37 },
        ["searchroles"] = { f = AutoBand.cmd_search_roles,           help = "<1|t4|5> search in chans",                       print_id = 38 },
        ["searchrole"]  = { f = AutoBand.cmd_search_roles,           help = "" },
        ["sr"]          = { f = AutoBand.cmd_search_roles,           help = "" },
        ["gp"]          = { f = AutoBand.cmd_flag_guildpriority,     help = "toggle guild priority",                          print_id = 39 },
        ["dpsweight"]   = {
            f    = AutoBand.cmd_toggle_dps_weighting,
            help = function()
                return "<on|off> toggle mDPS/rDPS weighting for " ..
                       AutoBand.saved.max_tanks .. "-" ..
                       AutoBand.saved.max_healers .. "-" ..
                       AutoBand.saved.max_dps
            end,
            print_id = 40
        },
        ["dw"]       = { f = AutoBand.cmd_toggle_dps_weighting, help = "" },
        ["setdps"]   = {
            f    = AutoBand.cmd_set_dps_weights,
            help = function()
                return "<mdps> <rdps> set desired counts (sum must be " .. AutoBand.saved.max_dps .. ")"
            end,
            print_id = 41
        },
        ["setroles"]   		= { f = AutoBand.cmd_setroles,   help = "<tanks> <healers> <dps> set role limits (sum must be 24)",  print_id = 42 },
        ["resetroles"] 		= { f = AutoBand.cmd_resetroles, help = "reset role limits to default (" .. AB_const.DEFAULT_MAX_TANKS .. "-" .. AB_const.DEFAULT_MAX_HEALERS .. "-" .. AB_const.DEFAULT_MAX_DPS .. ")", print_id = 43 },
        ["bwsmdps"]    		= { f = AutoBand.cmd_toggle_bw_sorc_mdps, help = "treat BW/Sorc as mDPS", print_id = 44 },
        ["bwm"]        		= { f = AutoBand.cmd_toggle_bw_sorc_mdps, help = "" },
        ["sorcm"]      		= { f = AutoBand.cmd_toggle_bw_sorc_mdps, help = "" },
        ["restrictrace"]	= { f = AutoBand.cmd_toggle_restrict_race, help = "restricting WB to leader's race", print_id = 45 },
        ["rr"]         		= { f = AutoBand.cmd_toggle_restrict_race, help = "" },
        ["raceonly"]   		= { f = AutoBand.cmd_toggle_restrict_race, help = "" },

        -- Zone
        ["zone"]     = { f = AutoBand.cmd_list_zone,     help = "list players not in leader's zone", print_id = 50 },
        ["zones"]    = { f = AutoBand.cmd_list_zone,     help = "" },
        ["zonekick"] = { f = AutoBand.cmd_kick_notinzone,help = "kick players not in leader's zone", print_id = 51 },
        ["zk"]       = { f = AutoBand.cmd_kick_notinzone,help = "" },

        -- Ranks
        ["rank"]           = { f = AutoBand.cmd_list_rank,     help = "list players below required rank",    print_id = 60 },
        ["minrank"]        = { f = AutoBand.cmd_rank,          help = "<num> set min rank requirement",      print_id = 61 },
        ["minrankhealer"]  = { f = AutoBand.cmd_rank_healer,   help = "<num> min rank for healers",          print_id = 62 },
        ["minrankheal"]    = { f = AutoBand.cmd_rank_healer,   help = "" },
        ["minrankh"]       = { f = AutoBand.cmd_rank_healer,   help = "" },
        ["rankkick"]       = { f = AutoBand.cmd_kick_rank,     help = "kick players below required rank",    print_id = 63 },

        -- Warband Organization
        ["org"]        = { f = AutoBand.cmd_organize,          help = "organize the warband",                    print_id = 70 },
        ["buffnotify"] = { f = AutoBand.cmd_toggle_buffnotify, help = "toggle notifying wb after org",           print_id = 71 },
        ["bn"]         = { f = AutoBand.cmd_toggle_buffnotify, help = "" },
        ["alt"]        = { f = AutoBand.cmd_alt_speccheck,     help = "toggle alt-spec check",                   print_id = 72 },
        ["wb"]         = { f = AutoBand.wb,                    help = "information about the warband",           print_id = 73 },
        ["roles"]      = { f = AutoBand.cmd_list_roles,        help = "<role> list players and their roles",     print_id = 74 },
        ["role"]       = { f = AutoBand.cmd_list_roles,        help = "" },
        ["pr"]         = { f = AutoBand.cmd_flag_printrole,    help = "toggle printing of role assignments",     print_id = 75 },
        ["customrole"] = { f = AutoBand.cmd_custom_role,       help = "<add|remove|list> manage role overrides", print_id = 76 },
        ["customroles"]= { f = AutoBand.cmd_custom_role,       help = "" },
        ["cr"]         = { f = AutoBand.cmd_custom_role,       help = "" },
        ["purpose"]    = { f = AutoBand.cmd_set_purpose,       help = "<"..AB_const.GetPurposeNames().."|clear> set wb purpose", print_id = 77 },
        ["purposelist"]= { f = AutoBand.cmd_list_purposes,     help = "list available warband purposes",         print_id = 78 },
        ["end"]        = { f = AutoBand.cmd_end,               help = "end warband, kick all",                   print_id = 79 },
		["printguild"] = { f = AutoBand.cmd_print_guild, help = "prints your current guild name as a clickable link", print_id = 80 },

        -- Debug
        ["debug"]    	= { f = AutoBand.cmd_debug,        			help = "", print_id = 100 },
        ["dump"]     	= { f = AutoBand.cmd_dump,         			help = "", print_id = 101 },
        ["cleardump"]	= { f = AutoBand.cmd_cleardumps,   			help = "", print_id = 102 },
        ["listdump"] 	= { f = AutoBand.cmd_list_dump,    			help = "", print_id = 103 },
        ["loaddump"] 	= { f = AutoBand.cmd_load_dump,    			help = "", print_id = 104 },
        ["tempdump"] 	= { f = AutoBand.cmd_dump_from_template, 	help = "", print_id = 105 },
		["dumpguild"] 	= { f = AutoBand.cmd_dump_guild_data, 		help = "", print_id = 106 },
		["dumpplayer"] 	= { f = AutoBand.cmd_dump_player_data, 		help = "", print_id = 107 },
    }

    --------------------------------------------------------------------------
    -- 5) SORT COMMANDS & DEBUG
    --------------------------------------------------------------------------
    AB_const.AVAILABLE_COLOR_NAMES_SORTED = {}
    for name, _ in pairs(AB_const.AVAILABLE_COLORS) do
        table.insert(AB_const.AVAILABLE_COLOR_NAMES_SORTED, name)
    end
    table.sort(AB_const.AVAILABLE_COLOR_NAMES_SORTED)

    AutoBand.cmd_ordered = {}
    for key, cmd in pairs(AutoBand.cmd) do
        -- Handle help text potentially being a function
        local help_text = ""
        if type(cmd.help) == "function" then
            help_text = cmd.help()
        elseif type(cmd.help) == "string" then
            help_text = cmd.help
        end
        if cmd.print_id ~= nil then
            cmd.key            = key
            cmd.resolved_help  = help_text -- Store resolved help text for sorting/display
            table.insert(AutoBand.cmd_ordered, cmd)
        end
    end
    table.sort(AutoBand.cmd_ordered, function(a, b)
        return a.print_id < b.print_id
    end)
    -- AB_util.debug(AutoBand.cmd_ordered)

    --------------------------------------------------------------------------
    -- 6) REGISTER LAYOUT WINDOW
    --------------------------------------------------------------------------
    LayoutEditor.RegisterWindow("AutoBandMapIcon", L"AutoBand", L"AutoBand Button", false, false, true, nil)

    --------------------------------------------------------------------------
    -- 7) REGISTERING EVENTS
    --------------------------------------------------------------------------
    RegisterEventHandler(SystemData.Events.ENTER_WORLD,          "AutoBand.OnPlayerEnteringWorldOrReload")
    RegisterEventHandler(SystemData.Events.INTERFACE_RELOADED,   "AutoBand.OnPlayerEnteringWorldOrReload")
    RegisterEventHandler(SystemData.Events.GROUP_LEAVE,          "AutoBand.OnGroupLeave")
    RegisterEventHandler(SystemData.Events.GROUP_UPDATED,        "AutoBand.OnBattleGroupDataChanged")
    RegisterEventHandler(SystemData.Events.BATTLEGROUP_UPDATED,  "AutoBand.OnBattleGroupDataChanged")

    --------------------------------------------------------------------------
    -- 8) PRINT LOADED MESSAGE
    --------------------------------------------------------------------------
    local slash = AutoBand.has_shortslash and " or /ab" or ""
    AB_util.print("AutoBand v" .. AB_const.VERSION .. " loaded. Type /autoband" .. slash .. " for instructions")
end

function AutoBand.cmd_print_guild(args)
    if not GameData or not GameData.Guild or not GameData.Guild.m_GuildID or GameData.Guild.m_GuildID == 0 or not GameData.Guild.m_GuildName then
        AB_util.print("[Error] Could not retrieve guild information. Are you in a guild?")
        return
    end
    local guild_id = tostring(GameData.Guild.m_GuildID)         -- Get Guild ID as string
    local guild_name_str = tostring(GameData.Guild.m_GuildName) -- Get Guild Name (convert wstring to string for LINK)
    local prefix_color_name = AutoBand.saved.prefix_color_name or AB_const.DEFAULT_PREFIX_COLOR_NAME
    local color_rgb = AB_const.AVAILABLE_COLORS[prefix_color_name] or AB_const.AVAILABLE_COLORS[AB_const.DEFAULT_PREFIX_COLOR_NAME]
    local r, g, b = color_rgb[1], color_rgb[2], color_rgb[3]
    local link_color_str = string.format("%d,%d,%d", r, g, b)
    local link_raw = string.format("<LINK data=\"GUILD:%s\" text=\"%s\" color=\"%s\">",
                                   guild_id,
                                   guild_name_str, -- Use the regular string version for the text attribute
                                   link_color_str) -- Use the formatted RGB string

    local link_wstring = towstring(link_raw)
    AB_util.print(link_wstring)
end

function AutoBand.OnBattleGroupDataChanged()
    AutoBand.cache_dirty = true
    need_role_update = true	
end

function AutoBand.OnPlayerEnteringWorldOrReload()
    AutoBand.DetermineRaceAndFaction()
end

function AutoBand.DetermineRaceAndFaction()
    AutoBand.faction = nil
    AutoBand.factionDetermined = false
    AutoBand.race = nil
    AutoBand.raceDetermined = false

    if GameData and GameData.Player and GameData.Player.career and GameData.Player.career.line then
         local faction = AB_const.CAREERLINE_FACTIONMAP[GameData.Player.career.line]
         local race = AB_const.CAREERLINE_RACEMAP[GameData.Player.career.line]

         if faction then
             AutoBand.faction = faction
             AutoBand.factionDetermined = true
             -- AB_util.print("Determined Faction as " .. AutoBand.faction .. ".")
         else
             AB_util.print("Could not determine faction.")
         end

         if race then
             AutoBand.race = race
             AutoBand.raceDetermined = true
             -- AB_util.print("Determined Race as " .. AutoBand.race .. ".")
         else
             AB_util.print("Could not determine race.")
         end

    else
         AB_util.print("Player data not ready for race/faction determination on ENTER_WORLD/INTERFACE_RELOADED.")
    end
end

function AutoBand.cmd_set_prefix(raw_prefix_string)
    local new_prefix = raw_prefix_string
    local MAX_PREFIX_LENGTH = 20

    new_prefix = string.gsub(new_prefix, "^%s+", "")
    new_prefix = string.gsub(new_prefix, "%s+$", "")

    if new_prefix == "" then
        AB_util.print("[Error] Prefix cannot be empty or only spaces. Use /ab resetprefix to restore default.")
        return
    end

    if #new_prefix > MAX_PREFIX_LENGTH then
        AB_util.print("[Error] Prefix is too long (max " .. MAX_PREFIX_LENGTH .. " characters). Prefix not set.")
        return
    end

    AutoBand.saved.prefix_text = new_prefix
    -- Add quotes in feedback to make spaces visible
    AB_util.print("Chat prefix set to: \"" .. new_prefix .. "\"")
end

function AutoBand.cmd_toggle_prefix_guild(args)
    AutoBand.saved.prefix_use_guild = not AutoBand.saved.prefix_use_guild
    local guildInfo = AutoBand.GetCurrentGuildInfo()

    if AutoBand.saved.prefix_use_guild then
        if guildInfo then
            -- Use GenerateGuildLinkRaw and convert to wstring for printing the example
            local example_link_raw = AutoBand.GenerateGuildLinkRaw(guildInfo.id, guildInfo.name)
            AB_util.print(L"Prefix set to use guild link: " .. towstring(example_link_raw))
        else
            -- Get normal prefix example (wstring)
            local normal_prefix_example = AutoBand.GetFormattedPrefixWString(false)
            AB_util.print(L"Prefix guild link enabled, but you are not in a guild. Will use normal prefix: " .. normal_prefix_example)
        end
    else
         -- Get normal prefix example (wstring)
        local normal_prefix_example = AutoBand.GetFormattedPrefixWString(false)
        AB_util.print(L"Prefix guild link disabled. Using normal prefix: " .. normal_prefix_example)
    end

    -- Optional: Refresh GUI if relevant controls are added later
    -- if AutoBandWindow.showing() and AutoBandWindow.SelectedTab == AB_const.TABS_CONFIG then
    --     AutoBandWindowConfig.Show()
    -- end
end

function AutoBand.cmd_reset_prefix(args)
    AutoBand.saved.prefix_text = AB_const.DEFAULT_PREFIX_TEXT
    AB_util.print("Chat prefix reset to default: " .. AutoBand.saved.prefix_text)
end

function AutoBand.cmd_list_colors(args)
    AB_util.print("Available color names:")
    local color_list_str = table.concat(AB_const.AVAILABLE_COLOR_NAMES_SORTED, ", ")
    AB_util.print(color_list_str)
end

function AutoBand.cmd_set_prefix_color(args)
    local color_name = args[1]
    if not color_name then
        AB_util.print("[Error] Missing color name. Usage: /ab setprefixcolor <color_name>")
        AutoBand.cmd_list_colors({}) -- Show available colors
        return
    end
    color_name = color_name:lower() -- Ensure lowercase for comparison

    if AVAILABLE_COLORS[color_name] then
        AutoBand.saved.prefix_color_name = color_name
        -- Get the formatted prefix with the NEW color for feedback (as wstring)
        local example_prefix = AutoBand.GetFormattedPrefixWString(false) -- Get prefix without space
        local feedback_message = L"Prefix color set to " .. example_prefix

        -- Pass the complete wstring message to AB_util.print
        AB_util.print(feedback_message)
    else
        AB_util.print("[Error] Invalid color name: '" .. color_name .. "'.")
        AutoBand.cmd_list_colors({}) -- Show available colors
    end
end

function AutoBand.cmd_reset_prefix_color(args)
    AutoBand.saved.prefix_color_name = AB_const.DEFAULT_PREFIX_COLOR_NAME
    -- Get the formatted prefix using the NEWLY reset default color for feedback
    local example_prefix = AutoBand.GetFormattedPrefixWString(false) -- Get prefix without space
    -- Construct the full feedback message as a wstring
    local feedback_message = L"Prefix color reset to default (" .. example_prefix .. L")"
    AB_util.print(feedback_message)
end

function AutoBand.cmd_set_lead_color(args)
    local color_name = args[1]
    if not color_name then
        AB_util.print("[Error] Missing color name. Usage: /ab setleadcolor <color_name>")
        AutoBand.cmd_list_colors({}) -- Show available colors
        return
    end
    color_name = color_name:lower() -- Ensure lowercase for comparison

    if AVAILABLE_COLORS[color_name] then
        AutoBand.saved.lead_color_name = color_name
        -- Generate example colored text for feedback
        local color_rgb = AVAILABLE_COLORS[color_name]
        local r, g, b = color_rgb[1], color_rgb[2], color_rgb[3]
        -- Keep the raw string for formatting, then convert
        local example_text_raw = string.format("<LINK data=\"0\" color=\"%d,%d,%d\" text=\"%s\">", r, g, b, color_name)
        local example_text_wstring = towstring(example_text_raw) -- Convert the link to wstring
        local feedback_message = L"WB Lead mention color set to " .. example_text_wstring

        -- Pass the complete wstring message to AB_util.print
        AB_util.print(feedback_message)
    else
        AB_util.print("[Error] Invalid color name: '" .. color_name .. "'.")
        AutoBand.cmd_list_colors({}) -- Show available colors
    end
end

function AutoBand.cmd_reset_lead_color(args)
    AutoBand.saved.lead_color_name = AB_const.DEFAULT_LEAD_COLOR_NAME
    -- Generate example colored text for feedback using the default color
    local default_color_name = AB_const.DEFAULT_LEAD_COLOR_NAME
    -- Ensure default color exists (should always be true if defaults are in AVAILABLE_COLORS)
    local color_rgb = AB_const.AVAILABLE_COLORS[default_color_name] or {255, 255, 255} -- Fallback just in case
    local r, g, b = color_rgb[1], color_rgb[2], color_rgb[3]
    local example_text_raw = string.format("<LINK data=\"0\" color=\"%d,%d,%d\" text=\"%s\">", r, g, b, default_color_name)
    local example_text_wstring = towstring(example_text_raw) -- Convert the link to wstring
    -- Construct the full feedback message as a wstring
    local feedback_message = L"WB Lead mention color reset to default (" .. example_text_wstring .. L")"
    AB_util.print(feedback_message)
end

function AutoBand.cmd_flag_autokick_lowrnk(args)
    AutoBand.saved.autokick_lowrnk_enabled = not AutoBand.saved.autokick_lowrnk_enabled
    AB_util.print("Auto kick low rank players: " .. tostring(AutoBand.saved.autokick_lowrnk_enabled))
    if AutoBandWindow.showing() and AutoBandWindow.SelectedTab == AB_const.TABS_CONFIG then
        AutoBandWindowConfig.Show()
    end		
end

function AutoBand.cmd_flag_autokick_rvrzone(args)
    AutoBand.saved.autokick_rvrzone_enabled = not AutoBand.saved.autokick_rvrzone_enabled
    AB_util.print("Auto kick players in scenarios: " .. tostring(AutoBand.saved.autokick_rvrzone_enabled))
    if AutoBandWindow.showing() and AutoBandWindow.SelectedTab == AB_const.TABS_CONFIG then
        AutoBandWindowConfig.Show()
    end
end

function AutoBand.cmd_toggle_buffnotify(args)
    AutoBand.saved.notify_buffs_enabled = not AutoBand.saved.notify_buffs_enabled
    AB_util.print("Notify warband after organize: " .. tostring(AutoBand.saved.notify_buffs_enabled))
    if AutoBandWindow.showing() and AutoBandWindow.SelectedTab == AB_const.TABS_TOOLS then
        AutoBandWindowTools.Show()
    end	
end

function AutoBand.cmd_alt_speccheck(args)
	AutoBand.saved.alt_speccheck_enabled = not AutoBand.saved.alt_speccheck_enabled
	AB_util.print("Use alt spec check: " .. tostring(AutoBand.saved.alt_speccheck_enabled))
    if AutoBandWindow.showing() and AutoBandWindow.SelectedTab == AB_const.TABS_CONFIG then
        AutoBandWindowConfig.Show()
    end	
end

function AutoBand.cmd_flag_printrole(args)
    AutoBand.saved.printrole_enabled = not AutoBand.saved.printrole_enabled
    AB_util.print("Print role assignments: " .. tostring(AutoBand.saved.printrole_enabled))
end


function AutoBand.cmd_list_roles(args)
    local role_filter = nil
    if args[1] then
        local role_param = args[1]:lower()
        if role_param == "tanks" then
            role_param = AB_const.TANK -- Convert to singular constant
        elseif role_param == "healers" then
            role_param = AB_const.HEALER -- Convert to singular constant
        elseif role_param == "heals" then
            role_param = AB_const.HEALER -- Convert to singular constant
        elseif role_param == "heal" then
            role_param = AB_const.HEALER -- Convert to singular constant
        end		
        if role_param ~= AB_const.TANK and role_param ~= AB_const.HEALER and
           role_param ~= AB_const.MDPS and role_param ~= AB_const.RDPS then
            AB_util.print("[error] Invalid role: " .. role_param .. ". Valid roles are " ..
                          AB_const.TANK .. ", " .. AB_const.HEALER .. ", " ..
                          AB_const.MDPS .. ", " .. AB_const.RDPS .. ".")
            return
        end
        role_filter = role_param
    end

    AB_util.print("Currently known player roles" ..
                  (role_filter and (" (" .. role_filter .. ")") or "") .. ":")
    local entries = {}
    for name, role in pairs(roles_last) do
        if not role_filter or role == role_filter then
            table.insert(entries, { name = name, role = role })
        end
    end

    table.sort(entries, function(a, b)
        if a.role == b.role then
            return a.name < b.name
        else
            return a.role < b.role
        end
    end)

    local count = 0
    for _, entry in ipairs(entries) do
        local msg = towstring("- [") .. towstring(entry.role) .. towstring("] - ") .. towstring(entry.name)
        AB_util.print(msg)
        count = count + 1
    end

    if count == 0 then
        AB_util.print("(no role data available)")
    end
end


function AutoBand.update(elapsed)
    AutoBand.elapsed = AutoBand.elapsed + elapsed
    if (AutoBand.elapsed > AB_const.HEARTBEAT) then
        local e = AutoBand.elapsed
        AutoBand.elapsed = 0
		AutoBand.cache_dirty = true
		need_role_update = true
        AutoBand.auto_kick()
        AutoBand.auto_kick_toofar()
        AutoBand.auto_note()
		if need_role_update then
			AutoBand.update_roles()
			need_role_update = false
		end
    end

    if (AutoBand.cmd_current == nil) then
        if (#AutoBand.cmd_queue > 0) then
            AutoBand.cmd_current = table.remove(AutoBand.cmd_queue, 1)
        else
            return
        end
    end

    AutoBand.cmd_current.ticks = AutoBand.cmd_current.ticks - 1
    if (AutoBand.cmd_current.ticks <= 0) then
        if (AutoBand.debugon or AutoBand.gizilon) then
            AB_util.debug(tostring(AutoBand.cmd_current.cmd))
        end
        SendChatText(towstring(AutoBand.cmd_current.cmd), L"")
        local cmd_tmp = AutoBand.cmd_current
        AutoBand.cmd_current = nil
        if (cmd_tmp.callback) then
            cmd_tmp.callback(cmd_tmp)
        end
    end
end

function AutoBand.update_roles()
	local wb_obj = AutoBand.get_wb()
	if not wb_obj then
		AB_util.print("wb_obj is nil!")
		return
	end

	local current_players = {}

	local success, err = pcall(function()
		wb_obj:foreach_player(function(gid, player)
			AB_wb:track_role(player, current_players)
		end)
	end)

	if not success then
		AB_util.print("Error in foreach_player: " .. tostring(err))
	end

	AB_wb:remove_missing_players(current_players)
end

function AutoBand.cmd_custom_role(args)
    local subcmd = args[1]
    if subcmd == "add" and args[2] and args[3] then
        local name = args[2]
        local role = args[3]
        if role ~= "tank" and role ~= "healer" and role ~= "mdps" and role ~= "rdps" then
            AB_util.print("[error] Invalid role: " .. role .. " - valid choices are tank, healer, mdps or rdps.")
            return
        end
        AutoBand.saved.custom_roles[name] = role
        AB_util.print("Added role override: " .. name .. " -> " .. role)
		need_role_update = true
    elseif subcmd == "remove" and args[2] then
        AutoBand.saved.custom_roles[args[2]] = nil
        AB_util.print("Removed role override for: " .. args[2])
		need_role_update = true
    elseif subcmd == "list" then
        AB_util.print("Custom role overrides:")
        for k, v in pairs(AutoBand.saved.custom_roles) do
            AB_util.print("- " .. k .. ": " .. v)
        end
    else
        AB_util.print("Usage: /ab customrole add <name> <role>")
        AB_util.print("       /ab customrole remove <name>")
        AB_util.print("       /ab customrole list")
    end
end

-- enqueues a string to be processed by "AutoBand.update()"
function AutoBand.enqueue_command(cmd, ticks, callback)
    ticks = ticks or AB_const.DEFAULT_CMD_TICKS
    table.insert(AutoBand.cmd_queue, {
        ["cmd"] = cmd,
        ["ticks"] = ticks,
        ["callback"] = callback
    })
end

function AutoBand.enqueue_kick(player_name, msg_reason)
    if (msg_reason) then
        -- Use the helper function to get the current prefix format for the tell message
        local prefix_raw_wspace = AutoBand.GetFormattedPrefixRaw(true)
        AutoBand.enqueue_command("/tell " .. tostring(player_name) ..
            " " .. prefix_raw_wspace .. "You were kicked from the warband since " .. msg_reason)
    end
    AutoBand.enqueue_command(L"/kick " .. player_name)
    AB_util.print(L"Kicking " .. player_name)
end

function AutoBand.has_permission()
    local wb_obj = AutoBand.get_wb()
    local i = 0
    wb_obj:foreach_player(
        function(gid, player)
            i = i + 1
        end
    )
    if i == 0 then
        return false
    end
    return GameData.Player.isGroupLeader
end

function AutoBand.is_assistant()
    local wb_obj = AutoBand.get_wb() -- Get current group/wb data
    local i = 0
    -- Check if we are actually in a group recognised by the addon
    wb_obj:foreach_player(
        function(gid, player)
            i = i + 1
        end
    )
    if i == 0 then
        return false -- Can't be assistant if not in a group
    end
    return GameData.Player.isWarbandAssistant
end

-- returns a AB_wb object either from a warband, scenario or dumped_wb
function AutoBand.get_wb()
    if (AutoBand.debugon and AutoBand.saved.dumped_wb ~= nil) then
        AB_util.debug("Getting dump " .. AutoBand.saved.default_dump .. " size " ..
            AB_util.size_wb(AutoBand.saved.dumped_wb.group) .. " (Debug mode, bypasses cache)")
        return AB_wb:new(AutoBand.saved.dumped_wb)
    end
    if not AutoBand.cache_dirty and AutoBand.cached_wb then
        return AutoBand.cached_wb
    end
    local wb = AB_wb:new()
    local success, err = pcall(function() wb:load_from_wbdata() end)
    if not success then
        AB_util.print("[Error] Failed to load warband data during cache refresh: " .. tostring(err))
    end
    AutoBand.cached_wb = wb
    AutoBand.cache_dirty = false
    return AutoBand.cached_wb
end

-- ####### / Commands ####### 
function AutoBand.parse_cmd(original_msg)
    local cmd_key = nil
    local args_str = "" -- Raw argument string (including spaces, original case)
    local args_tbl = {} -- Split arguments table (for most commands)

    -- Trim leading/trailing whitespace from the whole input
    original_msg = string.gsub(original_msg, "^%s+", "")
    original_msg = string.gsub(original_msg, "%s+$", "")

    -- Find the first space to separate command from arguments
    local first_space = string.find(original_msg, " ", 1, true)

    if first_space then
        -- Extract command part and convert ONLY the command to lowercase for lookup
        cmd_key = string.sub(original_msg, 1, first_space - 1):lower()
        -- Extract the rest of the string (arguments) with original case
        args_str = string.sub(original_msg, first_space + 1)
        -- Only split into a table IF NOT the setprefix command (or others needing raw string)
        if cmd_key ~= "setprefix" and args_str ~= "" then
             args_tbl = StringSplit(args_str)
        end
    else
        -- No space found, the whole message is the command
        cmd_key = original_msg:lower()
        -- args_str remains ""
        -- args_tbl remains {}
    end

    -- Find and execute the command handler
    if cmd_key and AutoBand.cmd[cmd_key] ~= nil then
        local handler_func = AutoBand.cmd[cmd_key].f
        -- Decide what to pass based on the command
        if cmd_key == "setprefix" or cmd_key == "prefix" then
            -- Pass the raw argument string directly for setprefix
            handler_func(args_str)
        else
            -- Pass the split arguments table for other commands
            handler_func(args_tbl)
        end
    else
        AB_util.print("AutoBand unknown command: " .. original_msg)
    end
end

function AutoBand.cmd_setroles(args)
       local num_tanks = tonumber(args[1])
       local num_healers = tonumber(args[2])
       local num_dps = tonumber(args[3])

       if not num_tanks or not num_healers or not num_dps then
               AB_util.print("[Error] Invalid input. Usage: /ab setroles <tanks> <healers> <dps>")
               return
       end

       num_tanks = math.floor(num_tanks)
       num_healers = math.floor(num_healers)
       num_dps = math.floor(num_dps)

       if num_tanks < 0 or num_healers < 0 or num_dps < 0 then
               AB_util.print("[Error] Role counts cannot be negative.")
               return
       end

       if num_tanks + num_healers + num_dps ~= 24 then
               AB_util.print("[Error] Role counts must sum to 24. Provided: " .. num_tanks .. "+" .. num_healers .. "+" .. num_dps .. " = " .. (num_tanks + num_healers + num_dps))
               return
       end

       AutoBand.saved.max_tanks = num_tanks
       AutoBand.saved.max_healers = num_healers
       AutoBand.saved.max_dps = num_dps

       AB_util.print("Role limits set to: Tanks=" .. num_tanks .. ", Healers=" .. num_healers .. ", DPS=" .. num_dps)

       -- Check and potentially adjust mDPS/rDPS weights if DPS limit changed
       if AutoBand.saved.max_mdps + AutoBand.saved.max_rdps ~= AutoBand.saved.max_dps then
               AB_util.print("[Warning] Max DPS changed. Resetting mDPS/rDPS weights proportionally.")
               AutoBand.saved.max_mdps = math.floor(AutoBand.saved.max_dps / 2)
               AutoBand.saved.max_rdps = AutoBand.saved.max_dps - AutoBand.saved.max_mdps -- Guarantees sum
               AB_util.print(" -> New mDPS/rDPS weights: mDPS=" .. AutoBand.saved.max_mdps .. ", rDPS=" .. AutoBand.saved.max_rdps)
       end

       AutoBandWindowConfig.refresh_autokick_label()
       AutoBandWindowConfig.refresh_dps_weights()
end

function AutoBand.cmd_resetroles(args)
       AutoBand.saved.max_tanks = AB_const.DEFAULT_MAX_TANKS
       AutoBand.saved.max_healers = AB_const.DEFAULT_MAX_HEALERS
       AutoBand.saved.max_dps = AB_const.DEFAULT_MAX_DPS
       AutoBand.saved.max_mdps = AB_const.DEFAULT_MAX_MDPS
       AutoBand.saved.max_rdps = AB_const.DEFAULT_MAX_RDPS
       AB_util.print("Role limits reset to default: Tanks=" .. AutoBand.saved.max_tanks .. ", Healers=" .. AutoBand.saved.max_healers .. ", DPS=" .. AutoBand.saved.max_dps)
       AutoBand.cmd_setroles({AutoBand.saved.max_tanks, AutoBand.saved.max_healers, AutoBand.saved.max_dps})
end

function AutoBand.cmd_usage(args)
    local ab = "/autoband "
    if (AutoBand.has_shortslash) then
        ab = "/ab "
    end
    AB_util.print("[Autoband v" .. AB_const.VERSION .. " commands]")
    for _, cmd in ipairs(AutoBand.cmd_ordered) do
       if (cmd.help ~= "" or AutoBand.debugon) then
            -- Use resolved_help which handles functions
            local help_text = cmd.resolved_help or ""
            if type(cmd.help) == "function" then -- Resolve again just in case order changes things (unlikely here)
                 help_text = cmd.help()
            end
      AB_util.print(ab .. cmd.key .. " - " .. help_text)
      end
    end
end

function AutoBand.cmd_show(args)
    AB_util.print("[Autoband v" .. AB_const.VERSION .. " settings]")
    local current_prefix_example = AutoBand.GetFormattedPrefixRaw(false) -- Get raw string example
    AB_util.print("Chat Prefix: " .. current_prefix_example .. " (Guild Link: " .. tostring(AutoBand.saved.prefix_use_guild) .. ") (Color: " .. AutoBand.saved.prefix_color_name .. ")")
    -- AB_util.print("Chat Prefix: '" .. AutoBand.saved.prefix_text .. "' (Color: " .. AutoBand.saved.prefix_color_name .. ")")
    AB_util.print("WB Lead Mention Color: " .. AutoBand.saved.lead_color_name .. ".")
    AB_util.print("Faction detected as " .. (AutoBand.faction or "Unknown") .. ".")
    AB_util.print("Race detected as " .. (AutoBand.race or "Unknown") .. ".")
    AB_util.print("Default template: " .. AutoBand.saved.default_template)
    AB_util.print("Right-click icon to organize: " .. tostring(AutoBand.saved.right_click_organize))
    AB_util.print("Auto kick too far players: " .. tostring(AutoBand.saved.autokick_toofar_enabled))
    AB_util.print("Auto kick too far players timeout: " .. tostring(AutoBand.saved.autokick_period))
    AB_util.print("Minimum rank requirement: " .. tostring(AutoBand.saved.min_rank))
    AB_util.print("Minimum rank requirement (healer): " .. tostring(AutoBand.saved.min_rank_healer))
	AB_util.print("Auto enforcing " .. AutoBand.saved.max_tanks .. "-" .. AutoBand.saved.max_healers .. "-" .. AutoBand.saved.max_dps .." WB (autokick): " .. tostring(AutoBand.saved.autokick_enabled))
    AB_util.print(" -> DPS Weighting Enabled: " .. tostring(AutoBand.saved.dps_weighting_enabled))
    if AutoBand.saved.dps_weighting_enabled then
        AB_util.print("    -> Max Melee DPS: " .. tostring(AutoBand.saved.max_mdps))
        AB_util.print("    -> Max Ranged DPS: " .. tostring(AutoBand.saved.max_rdps))
    end
    AB_util.print("Auto kick low rank players: " .. tostring(AutoBand.saved.autokick_lowrnk_enabled))
    AB_util.print("Auto kick stealhers: " .. tostring(AutoBand.saved.autokick_we_wh_enabled))
    AB_util.print("Auto kick players outside RvR zones: " .. tostring(AutoBand.saved.autokick_rvrzone_enabled))
    AB_util.print("Guild priority when auto-kick: " .. tostring(AutoBand.saved.guild_priority_enabled))
    AB_util.print("Notify warband after organize: " .. tostring(AutoBand.saved.notify_buffs_enabled))
    AB_util.print("Use alt spec check: " .. tostring(AutoBand.saved.alt_speccheck_enabled))
    AB_util.print("Auto note in /1: " .. tostring(AutoBand.saved.autonote_enabled))
    AB_util.print("Print role assignments: " .. tostring(AutoBand.saved.printrole_enabled))
    local bw_sorc_label = AB_const.GetBWSorcAsMDPSLabel() -- Get faction-aware label
    AB_util.print(bw_sorc_label .. ": " .. tostring(AutoBand.saved.bw_sorc_as_mdps))
    local restrict_race_label = AB_const.GetRestrictRaceLabel() -- Get race-aware label
    AB_util.print(restrict_race_label .. ": " .. tostring(AutoBand.saved.restrict_same_race))
    if AutoBand.current_purpose then
        local purpose_display = AB_const.WARBAND_PURPOSES[AutoBand.current_purpose].display or AutoBand.current_purpose
        AB_util.print("Current warband purpose: " .. purpose_display)
    else
        AB_util.print("Current warband purpose: none set")
    end
	if (AutoBand.debugon) then
        AB_util.print("Data dumped: " .. tostring(AutoBand.saved.dumped_wb ~= nil))
        AB_util.print("Debug mode: true")
    end
end

function AutoBand.cmd_debug(args)
    AutoBand.debugon = not AutoBand.debugon
    AB_util.print("Debug mode: " .. tostring(AutoBand.debugon))
end

function AutoBand.cmd_flag_autokick(args)
    AutoBand.saved.autokick_enabled = not AutoBand.saved.autokick_enabled
	AB_util.print("Auto enforcing " .. AutoBand.saved.max_tanks .. "-" .. AutoBand.saved.max_healers .. "-" .. AutoBand.saved.max_dps .." WB (autokick): " .. tostring(AutoBand.saved.autokick_enabled))
    if AutoBandWindow.showing() and AutoBandWindow.SelectedTab == AB_const.TABS_CONFIG then
        AutoBandWindowConfig.Show()
    end	
end

function AutoBand.cmd_flag_autokick_toofar(args)
    AutoBand.saved.autokick_toofar_enabled = not AutoBand.saved.autokick_toofar_enabled
    if AutoBand.has_permission() then
        -- Use the helper function to get the current prefix format
        local prefix_raw_wspace = AutoBand.GetFormattedPrefixRaw(true)
        if AutoBand.saved.autokick_toofar_enabled then
            AutoBand.enqueue_command("/wb " .. prefix_raw_wspace .. "Autokick players who are far away from leader ENABLED! Follow the leader PLEASE!")
        else
            AutoBand.enqueue_command("/wb " .. prefix_raw_wspace .. "Autokick players who are far away from leader DISABLED! Free move!")
            warned = {}
            toofar = {}
            toofar_old = {}
            toofar_not_changed = {}
        end
    end
    AB_util.print("Auto kick too far players: " .. tostring(AutoBand.saved.autokick_toofar_enabled))
    if AutoBandWindow.showing() and AutoBandWindow.SelectedTab == AB_const.TABS_CONFIG then
        AutoBandWindowConfig.Show()
    end
end

function AutoBand.cmd_flag_autonote(args)
    AutoBand.saved.autonote_enabled = not AutoBand.saved.autonote_enabled
    AB_util.print("Auto note in /1: " .. tostring(AutoBand.saved.autonote_enabled))
    if AutoBandWindow.showing() and AutoBandWindow.SelectedTab == AB_const.TABS_TOOLS then
        AutoBandWindowTools.Show()
    end	
end

function AutoBand.cmd_dump(args)
    if (args[1] == nil) then
        AB_util.print("[error] Missing argument")
        return
    end
    local wb = AB_wb:new()
    wb:load_from_wbdata()
    AutoBand.saved.dumped_wb = wb
    AutoBand.saved.default_dump = args[1]
    AutoBand.saved.dumps[args[1]] = wb
    AB_util.print("Dump complete")
end

function AutoBand.cmd_cleardumps(args)
    AutoBand.saved.dumped_wb = nil
    AutoBand.saved.dumps = {}
    AutoBand.saved.default_dump = nil
end

function AutoBand.cmd_kick_toofar(args)
    if (not AutoBand.has_permission()) then
        AB_util.print("[error] You need to be a wb leader")
        return
    end
    local wb_obj = AutoBand.get_wb()
    wb_obj:foreach_player(
        function(gid, player)
            for i = 1, MAX_MAP_POINTS do
                local mpd = GetMapPointData("EA_Window_OverheadMapMapDisplay", i)
                if (not mpd or not MapPointTypeFilter[mpd.pointType] or not mpd.name) then
                    continue
                end
                local name = AutoBand.FixString((mpd.name))
                if name == player.name then
                    player.distance = mpd.distance * DISTANCE_FIX_COEFFICIENT
                    if player.distance > 150 then
                        AutoBand.enqueue_kick(player.name, "not follow leader")
                    end
                    break
                end
            end
        end
    )
end

function AutoBand.cmd_list_offline(args)
    local wb_obj = AutoBand.get_wb()
    wb_obj:foreach_player(
        function(gid, player)
            for i = 1, MAX_MAP_POINTS do
                local mpd = GetMapPointData("EA_Window_OverheadMapMapDisplay", i)
                if (not mpd or not MapPointTypeFilter[mpd.pointType] or not mpd.name) then
                    continue
                end
                local name = AutoBand.FixString((mpd.name))
                if name == player.name then
                    player.distance = mpd.distance * DISTANCE_FIX_COEFFICIENT
                    if player.distance > 150 then
                        AB_util.print(player.name)
                    end
                end
            end
        end
    )
end

function AutoBand.cmd_list_rank(args)
    local str = ""
    local players = AutoBand.get_low_rank()
    if (#players > 0) then
        table.sort(players, function(p1, p2) return p1.level > p2.level end)
        for _, player in ipairs(players) do
            str = str .. tostring(player.name) .. "(r" .. player.level .. ") "
        end
        AB_util.print(AB_const.HEADER_MARGIN ..
            " Players with rank < (configured) " ..
            AB_const.HEADER_MARGIN ..
            " (#" .. #players .. ")")
        AB_util.print(str)
    end
end

function AutoBand.cmd_list_zone(args)
    local wb_obj = AutoBand.get_wb()
    if (wb_obj.player_count == 0) then
        AB_util.debug("No wb data found")
        return
    end

    local players_by_zid = AutoBand.get_players_zone(wb_obj)
    local num_valid_zones = AB_util.size_table(players_by_zid["valid_as"])
    if (players_by_zid["valid_as"] and num_valid_zones > 0) then
        AB_util.print(AB_const.HEADER_MARGIN ..
            " Leader's and assistants' zones " ..
            AB_const.HEADER_MARGIN)
        for zid, as_zone in pairs(players_by_zid["valid_as"]) do
            local num_assistants = AB_util.size_table(as_zone)
            local str = ""
            local num_players = AB_util.size_table(players_by_zid["valid_p"][zid])
            local zone_name = GetZoneName(zid)
            if (zid == 0) then
                zone_name = "Offline"
            end
            str = str .. tostring(zone_name) .. " (#" .. num_players .. ") "
            for _, player in ipairs(as_zone) do
                if (player.isGroupLeader) then
                    str = str .. tostring(player.name) ..
                    "(" .. AB_const.ABBREVATIONS["LEADER"] .. ") "
                else
                    str = str .. tostring(player.name) ..
                    "(" .. AB_const.ABBREVATIONS["ASSISTANT"] .. ") "
                end
            end
            AB_util.print(str)
        end
    end

    local num_invalid_zones = AB_util.size_table(players_by_zid["other"])
    if (players_by_zid["other"] and num_invalid_zones > 0) then
        AB_util.print(AB_const.HEADER_MARGIN ..
            " " ..
            AB_const.LABEL_NOTSAMEZONE ..
            " " ..
            AB_const.HEADER_MARGIN)
        for zid, other_zone in pairs(players_by_zid["other"]) do
            local str = ""
            local num_players = AB_util.size_table(other_zone)
            str = str ..
                tostring(GetZoneName(zid)) ..
                " (#" .. #other_zone .. ") "
            for _, player in ipairs(other_zone) do
                str = str .. tostring(player.name) .. " "
            end
            AB_util.print(str)
        end
    end
end

function AutoBand.cmd_kick_notinzone(args)
    if (not AutoBand.has_permission()) then
        AB_util.print("[error] You need to be a wb leader")
        return
    end

    local wb_obj = AutoBand.get_wb()
    if (wb_obj.player_count == 0) then
        AB_util.debug("No wb data found")
        return
    end

    local zone_name = GetZoneName
    local players_by_zid = AutoBand.get_players_zone(wb_obj)
    local num_valid_zones = AB_util.size_table(players_by_zid["valid_as"])

    if (players_by_zid["valid_as"] and num_valid_zones > 0) then
        local valid_zone_str = ""
        for zid, as_zone in pairs(players_by_zid["valid_as"]) do
            if (zid ~= 0) then
                valid_zone_str = valid_zone_str ..
                    tostring(zone_name(zid)) ..
                    " "
            end
        end

        local num_invalid_zones = AB_util.size_table(players_by_zid["other"])
        if (players_by_zid["other"] and num_invalid_zones > 0) then
            AB_util.print("Kicking " .. AB_const.LABEL_NOTSAMEZONE)
            for zid, other_zone in pairs(players_by_zid["other"]) do
                if (zid ~= 0) then
                    for _, player in ipairs(other_zone) do
                        AutoBand.enqueue_kick(player.name,
                            "you are not in one of the required zones {" ..
                            valid_zone_str .. "}")
                    end
                end
            end
        end
    end
    AB_util.print("Zone kick complete")
end

function AutoBand.cmd_toggle_autokick_we_wh(args)
    AutoBand.saved.autokick_we_wh_enabled = not AutoBand.saved.autokick_we_wh_enabled
    AB_util.print("Auto kick stealthers: " .. tostring(AutoBand.saved.autokick_we_wh_enabled))
    if AutoBandWindow.showing() and AutoBandWindow.SelectedTab == AB_const.TABS_CONFIG then
        AutoBandWindowConfig.Show()
    end
end

function AutoBand.cmd_rank(args)
    if (args[1] == nil) then
        AB_util.print("[error] Missing argument")
        return
    end
    local n = tonumber(args[1])
    if (n < 0 or n > 40) then
        AB_util.print("[error] Invalid rank value: " .. tostring(n))
        return
    end
    AutoBand.saved.min_rank = math.floor(n)

    -- Ensure the separate healer rank doesn't exceed the new min_rank
    if (AutoBand.saved.min_rank_healer > AutoBand.saved.min_rank) then
        AutoBand.saved.min_rank_healer = AutoBand.saved.min_rank
    end

    AB_util.print("Minimum rank requirement: " .. tostring(AutoBand.saved.min_rank))
    if AutoBandWindow.showing() and AutoBandWindow.SelectedTab == AB_const.TABS_CONFIG then
        AutoBandWindowConfig.Show()
    end		
end

function AutoBand.cmd_rank_healer(args)
    if (args[1] == nil) then
        AB_util.print("[error] Missing argument")
        return
    end
    local n = tonumber(args[1])
    if (n < 0 or n > 40) then
        AB_util.print("[error] Invalid healer rank value: " .. tostring(n))
        return
    end
    -- Make sure it cannot exceed the general min_rank
    if (n > AutoBand.saved.min_rank) then
        AB_util.print("[error] Healer min rank cannot exceed overall min rank (" ..
            AutoBand.saved.min_rank .. ")")
        return
    end
    AutoBand.saved.min_rank_healer = math.floor(n)
    AB_util.print("Minimum rank requirement (healer): " .. tostring(AutoBand.saved.min_rank_healer))
    if AutoBandWindow.showing() and AutoBandWindow.SelectedTab == AB_const.TABS_CONFIG then
        AutoBandWindowConfig.Show()
    end		
end

function AutoBand.cmd_kick_rank(args)
    if (not AutoBand.has_permission()) then
        AB_util.print("[error] You need to be a wb leader")
        return
    end
    local players = AutoBand.get_low_rank()
    if (#players > 0) then
        AB_util.print("Kicking players below rank requirements")
        for _, player in ipairs(players) do
            local needed = player.role == "healer" and AutoBand.saved.min_rank_healer or AutoBand.saved.min_rank
            AutoBand.enqueue_kick(player.name,
                "you don't meet the rank requirement (" .. needed .. ")")
        end
    end
    AB_util.print("Rank kick complete")
end

function AutoBand.cmd_organize(args)
    local is_leader = AutoBand.has_permission()
    local is_assist = AutoBand.is_assistant()
    local debug     = AutoBand.debugon

    if not (is_leader or is_assist or debug) then
        AB_util.print("[error] You need to be a wb leader or assistant")
        return
    end

    -- save current kick/notify flags
    local a = AutoBand.saved.autokick_enabled
    local b = AutoBand.saved.autokick_toofar_enabled
    local c = AutoBand.saved.autokick_lowrnk_enabled
    local d = AutoBand.saved.autokick_we_wh_enabled
    local e
    if is_assist or debug then
        e = AutoBand.saved.notify_buffs_enabled
    end

    -- disable them all
    AutoBand.saved.autokick_enabled      = false
    AutoBand.saved.autokick_toofar_enabled = false
    AutoBand.saved.autokick_lowrnk_enabled = false
    AutoBand.saved.autokick_we_wh_enabled  = false
    if is_assist or debug then
        AutoBand.saved.notify_buffs_enabled = false
    end

    -- pick the right template
    local tpl_key = args[1] or AutoBand.saved.default_template
    local tpl     = AutoBand.saved.templates[tpl_key]
    AB_org.auto_organize(tpl)

    -- restore original flags
    AutoBand.saved.autokick_enabled      = a
    AutoBand.saved.autokick_toofar_enabled = b
    AutoBand.saved.autokick_lowrnk_enabled = c
    AutoBand.saved.autokick_we_wh_enabled  = d
    if is_assist or debug then
        AutoBand.saved.notify_buffs_enabled = e
    end
end

function AutoBand.cmd_autokick_timeout(args)
    if (args[1] == nil) then
        AB_util.print("[error] Missing argument")
        return
    end
    local n = tonumber(args[1])
    if (n < 0) then
        AB_util.print("[error] Invalid timeout value: " .. tostring(n))
        return
    end
    AutoBand.saved.autokick_period = math.floor(n)
    AB_util.print("Auto kick timeout: " .. tostring(AutoBand.saved.autokick_period))
    if AutoBandWindow.showing() and AutoBandWindow.SelectedTab == AB_const.TABS_CONFIG then
        AutoBandWindowConfig.Show()
    end	
end

function AutoBand.cmd_mode(args)
    if (args[1] == nil) then
        AB_util.print("[error] Missing argument")
        return
    end
    local n = tonumber(args[1])
    if (n < 0 or n > 2) then
        AB_util.print("[error] Invalid distribution algorithm: " .. tostring(n))
        return
    end
    AutoBand.saved.org_algo_mode = math.floor(n)
    AB_util.print("Distribution algorithm mode: " ..
        tostring(AutoBand.saved.org_algo_mode) ..
        AB_const.ALGO_MODE[AutoBand.saved.org_algo_mode])
    if AutoBandWindow.showing() and AutoBandWindow.SelectedTab == AB_const.TABS_CONFIG then
        AutoBandWindowConfig.Show()
    end			
end

function AutoBand.cmd_set_purpose(args)
    if not AutoBand.has_permission() then
        AB_util.print("[Error] Only the warband leader can set the purpose.")
        return
    end
    local purpose_arg = args[1]
    if not purpose_arg then
        AB_util.print("[Error] Missing purpose type. Usage: /ab purpose <" .. AB_const.GetPurposeNames() .. "|clear>")
        return
    end

    purpose_arg = purpose_arg:lower() -- Convert input to lowercase

    if purpose_arg == "clear" or purpose_arg == "none" then
        if AutoBand.current_purpose then
            AutoBand.current_purpose = nil
            AB_util.print("Warband purpose cleared.")
        else
            AB_util.print("Warband purpose was not set.")
        end
        return
    end

    local canonical_purpose = AB_const.PURPOSE_ALIASES[purpose_arg]

    if canonical_purpose then
        if AB_const.WARBAND_PURPOSES[canonical_purpose] then
            AutoBand.current_purpose = canonical_purpose -- Store the canonical key
            local purpose_display = AB_const.WARBAND_PURPOSES[canonical_purpose].display or canonical_purpose
            AB_util.print("Warband purpose set to: " .. purpose_display)
        else
            AB_util.print("[Internal Error] Alias '" .. purpose_arg .. "' maps to invalid purpose '" .. canonical_purpose .. "'.")
            AutoBand.current_purpose = nil -- Ensure purpose is not set incorrectly
        end
    else
        AB_util.print("[Error] Invalid purpose type '" .. purpose_arg .. "'. Valid types: " .. AB_const.GetPurposeNames() .. ", clear")
    end
end

function AutoBand.cmd_list_purposes(args)
    AB_util.print("Available warband purposes:")
    local purpose_keys = {}
    for key, _ in pairs(AB_const.WARBAND_PURPOSES) do
        table.insert(purpose_keys, key)
    end

    if #purpose_keys == 0 then
        AB_util.print("- None defined.")
        return
    end

    table.sort(purpose_keys)

    for _, key in ipairs(purpose_keys) do
        local purpose_data = AB_const.WARBAND_PURPOSES[key]
        if purpose_data then
            local display_name = purpose_data.display or key -- Fallback to key if display name is missing
            local description = purpose_data.description or "No description available." -- Fallback description
            local output_line = L"- " .. towstring(key) .. L" - " .. towstring(display_name) .. L": " .. towstring(description)
            AB_util.print(output_line)
        end
    end
    AB_util.print(L"Set the current purpose using: /ab purpose <name>")
end

function AutoBand.OnGroupLeave()
    if AutoBand.current_purpose then
        -- AB_util.print("GROUP_LEAVE event fired, clearing warband purpose.")
        AutoBand.current_purpose = nil
    end
end

function AutoBand.cmd_flag_guildpriority(args)
    AutoBand.saved.guild_priority_enabled = not AutoBand.saved.guild_priority_enabled
    AB_util.print("Guild priority for auto-kick: " .. tostring(AutoBand.saved.guild_priority_enabled))
    if AutoBandWindow.showing() and AutoBandWindow.SelectedTab == AB_const.TABS_CONFIG then
        AutoBandWindowConfig.Show()
    end	
end

function AutoBand.cmd_list_template(args)
    AB_util.print("Default template " .. AutoBand.saved.default_template)
    for tname in pairs(AutoBand.saved.templates) do
        AB_util.print(tname)
    end
end

function AutoBand.cmd_save_template(args)
    if (args[1] == nil) then
        AB_util.print("[error] Missing argument")
        return
    end
    AutoBand.saved.templates[args[1]] = AB_template.from_wb(AutoBand.get_wb())
    AB_util.print("Template " .. args[1] .. " saved")
end

function AutoBand.cmd_apply_template(args)
    if (args[1] == nil) then
        AB_util.print("[error] Missing argument")
        return
    end
    if (AutoBand.saved.templates[args[1]] == nil) then
        AB_util.print("[error] Template " .. args[1] .. " does not exist")
        return
    end
    AB_org.auto_organize(AutoBand.saved.templates[args[1]])
    AB_util.print("Template " .. args[1] .. " loaded")
end

function AutoBand.cmd_default_template(args)
    if (#args > 0) then
        if (AutoBand.saved.templates[args[1]] == nil) then
            AB_util.print("[error] Template " .. args[1] .. " does not exist")
            return
        end
        AutoBand.saved.default_template = args[1]
    else
        AutoBand.saved.default_template = AB_const.EMPTY_TEMPLATE
    end
    AB_util.print("Default template set: " .. AutoBand.saved.default_template)
    if AutoBandWindow.showing() and AutoBandWindow.SelectedTab == AB_const.TABS_CONFIG then
        AutoBandWindowConfig.Show()
    end		
end

function AutoBand.cmd_toggle_gui(args)
    if (AutoBandWindow.showing()) then
        AutoBandWindow.Hide()
    else
        AutoBandWindow.Show()
    end
end

function AutoBand.cmd_toggle_icon(args)
    AutoBandWindow.toggle_mapicon()
	AB_util.print("Show map-icon: " .. tostring(AutoBand.saved.displayicon))
    if AutoBandWindow.showing() and AutoBandWindow.SelectedTab == AB_const.TABS_CONFIG then
        AutoBandWindowConfig.Show()
    end	
end

function AutoBand.cmd_toggle_rco(args)
    AutoBand.saved.right_click_organize = not AutoBand.saved.right_click_organize
    AB_util.print("Right-click icon to organize: " .. tostring(AutoBand.saved.right_click_organize))
    if AutoBandWindow.showing() and AutoBandWindow.SelectedTab == AB_const.TABS_TOOLS then
        AutoBandWindowTools.Show() 
    end
end

function AutoBand.HandleIconRightClick()
    if AutoBand.saved.right_click_organize then
        AB_util.print("Icon right-clicked: Organizing warband...")
        AutoBand.cmd_organize({})
    else
         -- AB_util.print("Icon right-clicked, but organize function is disabled in settings.")
    end
end

function AutoBand.cmd_list_dump(args)
    if (AutoBand.saved.dumped_wb ~= nil) then
        AB_util.print("[AutoBand] default dump " .. AutoBand.saved.default_dump)
    end
    for tname in pairs(AutoBand.saved.dumps) do
        AB_util.print(tname)
    end
end

function AutoBand.cmd_load_dump(args)
    if (#args > 0) then
        if (AutoBand.saved.dumps[args[1]] == nil) then
            AB_util.print("[error] Dump " .. args[1] .. " does not exist")
            return
        end
        AutoBand.saved.default_dump = args[1]
        AutoBand.saved.dumped_wb = AutoBand.saved.dumps[AutoBand.saved.default_dump]
    end
    AB_util.print("[AutoBand] Default dump set: " .. AutoBand.saved.default_dump)
end

function AutoBand.cmd_dump_from_template(args)
    if (AutoBand.debugon) then
        if (#args > 1) then
            local template_name = args[1]
            local dump_name = args[2]
            if (AutoBand.saved.templates[template_name] == nil) then
                AB_util.print("[error] Template " .. template_name .. " does not exist")
                return
            end
            AutoBand.saved.dumped_wb = AutoBand.get_fakewb(AutoBand.saved.templates[template_name])
            AutoBand.saved.dumps[dump_name] = AutoBand.saved.dumped_wb
            AutoBand.saved.default_dump = dump_name
        end
    end
end

function AutoBand.auto_kick_toofar()
    if (not AutoBand.saved.autokick_toofar_enabled or not AutoBand.has_permission() or AutoBand.debugon) then
        return
    end
    local wb_obj = AutoBand.get_wb()
	local prefix_raw_wspace = AutoBand.GetFormattedPrefixRaw(true)
    wb_obj:foreach_player(
        function(gid, player)
            for i = 1, MAX_MAP_POINTS do
                local mpd = GetMapPointData("EA_Window_OverheadMapMapDisplay", i)
                if (not mpd or not MapPointTypeFilter[mpd.pointType] or not mpd.name) then
                    continue
                end
                local name = AutoBand.FixString((mpd.name))
                if name == player.name then
                    player.distance = mpd.distance * DISTANCE_FIX_COEFFICIENT
                    if player.distance > 150 then
                        if toofar[player.name] then
                            toofar[player.name] = toofar[player.name] + 1
                        else
                            toofar[player.name] = 1
                        end
                        if (toofar[player.name] == 6) then
                            local found = 0
                            for i, v in pairs(warned) do
                                if v == player.name then
                                    found = 1
                                    break
                                end
                            end
                            if found == 0 then
                                AutoBand.enqueue_command("/tell " .. tostring(player.name) ..
                                     " " .. prefix_raw_wspace .. "You are too far from leader, you will be autokicked in " ..
                                     AutoBand.saved.autokick_period * 60 - 30 ..
                                     "sec! Follow the leader PLEASE!")
                                table.insert(warned, player.name)
                            end
                        end
                        if (toofar[player.name] > AutoBand.saved.autokick_period * 12) then
                            AutoBand.enqueue_kick(player.name,
                                "was too far from warband leader for a long time")
                        end
                    else
                        toofar[player.name] = nil
                    end
                    break
                end
            end
        end
    )

    for i, v in pairs(toofar) do
        for ii, vv in pairs(toofar_old) do
            if i == ii then
                if v == vv then
                    if toofar_not_changed[i] then
                        toofar_not_changed[i] = toofar_not_changed[i] + 1
                    else
                        toofar_not_changed[i] = 1
                    end
                    if toofar_not_changed[i] > 60 then
                        toofar[i] = nil
                        toofar_not_changed[i] = nil
                    end
                end
                break
            end
        end
    end

    toofar_old = {}
    for key, value in pairs(toofar) do
        toofar_old[key] = value
    end
end

function AutoBand.cmd_toggle_dps_weighting(args)
    if not AutoBand.saved.autokick_enabled then
		AB_util.print("[Warning] DPS weighting only applies when 'Auto enforcing " .. AutoBand.saved.max_tanks .. "-" .. AutoBand.saved.max_healers .. "-" .. AutoBand.saved.max_dps .." WB' (/ab ak) is enabled.")
    end

    local composition_str = AutoBand.saved.max_tanks .. "-" .. AutoBand.saved.max_healers .. "-" .. AutoBand.saved.max_dps
    local state = args[1]
    if state == "on" then
        AutoBand.saved.dps_weighting_enabled = true
	    AB_util.print("DPS weighting for " .. composition_str .." enabled. Max MDPS: " .. AutoBand.saved.max_mdps .. ", Max RDPS: " .. AutoBand.saved.max_rdps)
    elseif state == "off" then
        AutoBand.saved.dps_weighting_enabled = false
		AB_util.print("DPS weighting for " .. composition_str .." disabled.")		
    else
        AutoBand.saved.dps_weighting_enabled = not AutoBand.saved.dps_weighting_enabled
        AB_util.print("DPS weighting for " .. composition_str .." toggled to: " .. tostring(AutoBand.saved.dps_weighting_enabled))
        if AutoBand.saved.dps_weighting_enabled then
            AB_util.print(" -> Max MDPS: " .. AutoBand.saved.max_mdps .. ", Max RDPS: " .. AutoBand.saved.max_rdps)
        end
    end
     -- Refresh GUI if open
    if AutoBandWindow.showing() and AutoBandWindow.SelectedTab == AB_const.TABS_CONFIG then
        AutoBandWindowConfig.Show()
    end
end

function AutoBand.cmd_set_dps_weights(args)
    local mdps_count = tonumber(args[1])
    local rdps_count = tonumber(args[2])

    if not mdps_count or not rdps_count or mdps_count < 0 or rdps_count < 0 then
        AB_util.print("[Error] Invalid counts. Usage: /ab setdps <mdps_count> <rdps_count>")
        return
    end

    mdps_count = math.floor(mdps_count)
    rdps_count = math.floor(rdps_count)

	if mdps_count + rdps_count ~= AutoBand.saved.max_dps then
		AB_util.print("[Error] Counts must sum to the current max DPS setting (" .. AutoBand.saved.max_dps .. "). Provided: " .. mdps_count .. " MDPS + " .. rdps_count .. " RDPS.")
        return
    end

    AutoBand.saved.max_mdps = mdps_count
    AutoBand.saved.max_rdps = rdps_count
    AB_util.print("DPS weights set. Max MDPS: " .. AutoBand.saved.max_mdps .. ", Max RDPS: " .. AutoBand.saved.max_rdps)

    if not AutoBand.saved.dps_weighting_enabled then
        AB_util.print("[Warning] DPS weighting is currently disabled (/ab dpsweight on).")
    end
    if not AutoBand.saved.autokick_enabled then
	    AB_util.print("[Warning] DPS weighting only applies when 'Auto enforcing " .. AutoBand.saved.max_tanks .. "-" .. AutoBand.saved.max_healers .. "-" .. AutoBand.saved.max_dps .." WB' (/ab ak) is enabled.")
    end
     -- Refresh GUI if open
    if AutoBandWindow.showing() and AutoBandWindow.SelectedTab == AB_const.TABS_CONFIG then
		 AutoBandWindowConfig.refresh_dps_weights()
    end
end

function AutoBand.cmd_toggle_bw_sorc_mdps(args)
    AutoBand.saved.bw_sorc_as_mdps = not AutoBand.saved.bw_sorc_as_mdps
    local bw_sorc_label = AB_const.GetBWSorcAsMDPSLabel()
    AB_util.print(bw_sorc_label .. ": " .. tostring(AutoBand.saved.bw_sorc_as_mdps))
    -- Refresh GUI if open
    if AutoBandWindow.showing() and AutoBandWindow.SelectedTab == AB_const.TABS_CONFIG then
        AutoBandWindowConfig.Show() -- Refresh the whole config tab
    end
    -- Trigger role update as roles might change
    need_role_update = true
end

function AutoBand.cmd_toggle_restrict_race(args)
    AutoBand.saved.restrict_same_race = not AutoBand.saved.restrict_same_race
    local restrict_race_label = AB_const.GetRestrictRaceLabel()
    AB_util.print(restrict_race_label .. ": " .. tostring(AutoBand.saved.restrict_same_race))
    if AutoBand.saved.restrict_same_race and not AutoBand.raceDetermined then
        AB_util.print("[Warning] Could not determine your race. Restriction might not work correctly.")
    end
     -- Refresh GUI if open
    if AutoBandWindow.showing() and AutoBandWindow.SelectedTab == AB_const.TABS_CONFIG then
       AutoBandWindowConfig.Show() -- Refresh the whole config tab
    end
end

function AutoBand.auto_kick()
  if (not AutoBand.has_permission() or AutoBand.debugon) then
    return
  end

  -- Cache frequently used saved settings locally for this function execution
  local ak_low_enabled = AutoBand.saved.autokick_lowrnk_enabled
  local ak_enabled = AutoBand.saved.autokick_enabled
  local ak_wewh_enabled = AutoBand.saved.autokick_we_wh_enabled
  local ak_zone_enabled = AutoBand.saved.autokick_rvrzone_enabled
  local restrict_race_enabled = AutoBand.saved.restrict_same_race
  local guild_prio_enabled = AutoBand.saved.guild_priority_enabled

  -- Early exit if no relevant auto-kick features are enabled
  if not ak_low_enabled and not ak_enabled and not ak_wewh_enabled and not ak_zone_enabled and not restrict_race_enabled then
    -- Clear _old tables if features are off to prevent stale data
    tanks_t_old, healers_t_old, dps_t_old, mdps_t_old, rdps_t_old = {}, {}, {}, {}, {}
    return
  end

  local wb_obj = AutoBand.get_wb()
  if not wb_obj then AB_util.print("AutoKick: Could not get Warband Object."); return end -- Safety check

  local pending_kicks = {} -- Store all players to kick { [name] = reason }

  -- Variables needed for autoforming preset composition logic (initialized only if ak_enabled)
  local tanks_t, healers_t, dps_t, mdps_t, rdps_t
  local tanks, healers, dpss, mdpss, rdpss
  local guild_member
  local g_m, guild_members, ign

  -- Initialize role composition specific variables and data
  if ak_enabled then
    tanks_t, healers_t, dps_t, mdps_t, rdps_t = {}, {}, {}, {}, {}
    tanks, healers, dpss, mdpss, rdpss = 0, 0, 0, 0, 0
    guild_member = false
    ign = GetIgnoreList() or {} -- Get ignore list
    g_m = {}
    guild_members = {}
    if guild_prio_enabled then -- Get guild list only if needed
      g_m = GetGuildMemberData() or {}
      for _, value in pairs(g_m) do
        if value and value.name then table.insert(guild_members, value.name) end
      end
    end
  end

  -- Single Loop Player Processing
  wb_obj:foreach_player(
    function(gid, player)
      -- Ensure player.name exists before proceeding (safety)
      if not player or not player.name then return end
      local player_name = player.name -- Cache for pending_kicks key
      local leader_race = AutoBand.race  -- Get leader's race
      local race_ok = AutoBand.raceDetermined -- Check if leader's race is known

      -- Race Restriction Check (Run if restrict_race_enabled)
      if restrict_race_enabled and race_ok and not pending_kicks[player_name] then
        local player_race = AB_const.CAREERLINE_RACEMAP[player.careerLine]
        if player_race and player_race ~= leader_race then
          -- Fetch the theme/title for the leader's race for the kick message
          local theme = AB_const.RACE_THEMES[leader_race] or AB_const.RACE_THEMES["Default"]
          pending_kicks[player_name] = "this is a " .. theme.title .. " only warband."
        end
      end

      -- Low Rank Check (Run if autokick_lowrnk_enabled)
      -- Check if not already marked for kick
      if ak_low_enabled and not pending_kicks[player_name] then
        local required_rank = (player.role == AB_const.HEALER) and AutoBand.saved.min_rank_healer or AutoBand.saved.min_rank
        if (player.level < required_rank) then
          pending_kicks[player_name] = "you are too low level for it (Rank " .. player.level .. " < " .. required_rank .. ")."
        end
      end

      -- WE/WH Check (Run if autokick_we_wh_enabled)
      -- Check if not already marked for kick
      if ak_wewh_enabled and not pending_kicks[player_name] then
        if player.careerLine == GameData.CareerLine.WITCH_ELF or player.careerLine == GameData.CareerLine.WITCH_HUNTER then
          pending_kicks[player_name] = "autokick of stealthers is enabled."
        end
      end

      -- Check if in a non-rvr/city zone (Run if autokick_rvrzone_enabled)
      -- Check if not already marked for kick
      if ak_zone_enabled and not pending_kicks[player_name] then
        if player.zoneNum and player.zoneNum ~= 0 then
          -- Check if their zone is NOT in the allowed set
          if not AutoBand.allowed_rvr_zones_set[player.zoneNum] then
            local zoneName = GetZoneName(player.zoneNum) or "Unknown Zone ("..player.zoneNum..")"
            pending_kicks[player_name] = "you are not in a RVR- or City-zone (Your zone: " .. tostring(zoneName) .. ")."
          end
        end
      end

      -- Ignore/Guild-checks (Run if autokick_enabled for forming specific role composition)
      -- Check if not already marked for kick
      if ak_enabled and not pending_kicks[player_name] then
        -- Ignore Check
        if ign then
          for _, value in pairs(ign) do
            if value and value.name then -- Ensure ignore entry is valid
              if player_name and value.name and player_name == value.name then
                pending_kicks[player_name] = "you are in my ignore list."
                break -- Stop checking ignore list for this player
              end
            end
          end
        end

        -- Role counting for role composition limits (only if not kicked for ignore)
        if not pending_kicks[player_name] then
          guild_member = false
          if guild_prio_enabled then
            for _, value in pairs(guild_members) do
              -- Compare stripped names to handle realm tags
              local guildMemberNameStripped = value:match("([^^]+)") or value
              local playerNameStripped = player.name:match("([^^]+)") or player.name
              if guildMemberNameStripped and playerNameStripped and guildMemberNameStripped == playerNameStripped then
                guild_member = true
                break
              end
            end
          end

          -- Populate role tables for role composition logic after loop
          if (player.role == AB_const.TANK) then
            tanks_t[player_name] = guild_member; tanks = tanks + 1
          elseif (player.role == AB_const.HEALER) then
            healers_t[player_name] = guild_member; healers = healers + 1
          elseif (player.role == AB_const.MDPS) then
            dps_t[player_name] = guild_member; mdps_t[player_name] = guild_member; dpss = dpss + 1; mdpss = mdpss + 1
          elseif (player.role == AB_const.RDPS) then
            dps_t[player_name] = guild_member; rdps_t[player_name] = guild_member; dpss = dpss + 1; rdpss = rdpss + 1
          end
        end
      end
    end
  )

  -- Perform role composition Kicking Logic based on role limits (if enabled)
  if ak_enabled then
    -- Helper function to find and mark players for kick based on role limits
    local function mark_excess_roles(role_table, old_role_table, max_allowed, role_name_plural, current_count_ref)
      local current_count = current_count_ref[1]
      local players_to_kick_count = 0
      local kicked_count = 0 -- How many we mark in this function call

      if current_count > max_allowed then
        players_to_kick_count = current_count - max_allowed

        -- Create list of candidates: new players in this role not already marked for kick
        local candidates = {}
        for key, is_guildie in pairs(role_table) do
          if not pending_kicks[key] then -- Only consider if not already marked for other reasons
            local found_in_old = false
            for key2, _ in pairs(old_role_table or {}) do
              if key == key2 then found_in_old = true; break end
            end
            if not found_in_old then
              table.insert(candidates, { name = key, is_guildie = is_guildie })
            end
          end
        end

        -- Sort candidates: Non-guildies first, then by name
        table.sort(candidates, function(a, b)
          if a.is_guildie ~= b.is_guildie then
            return not a.is_guildie -- false (non-guildie) comes before true (guildie)
          else
            return a.name < b.name -- Alphabetical tiebreaker
          end
        end)

        -- Pre-calculate if any unmarked non-guildies are available (for priority check)
        local non_guildie_candidate_available = false
        if guild_prio_enabled then
          for _, candidate_check in ipairs(candidates) do
            -- Check candidate table directly, pending_kicks check isn't needed again here
            if not candidate_check.is_guildie then
              non_guildie_candidate_available = true
              break
            end
          end
        end

        -- Iterate through sorted candidates and mark for kick
        for _, candidate in ipairs(candidates) do
          if kicked_count >= players_to_kick_count then break end -- Stop if we've marked enough

          local kick_target = candidate.name
          local should_mark_this_candidate = true -- Assume we kick unless priority logic prevents it

          -- Apply Guild Priority Logic
          if guild_prio_enabled then
            if candidate.is_guildie and non_guildie_candidate_available then
              -- Current candidate is a guildie, AND an unmarked non-guildie exists *somewhere*
              -- in the candidates list. Don't kick this guildie yet.
              should_mark_this_candidate = false
            end
          end

          -- Mark for kick if decided (and check pending_kicks again just in case)
          if should_mark_this_candidate and not pending_kicks[kick_target] then
            local kick_reason = "too many " .. role_name_plural .. " in it."
            -- Add priority note only if kicking a non-guildie while guildies were candidates
            if guild_prio_enabled and not candidate.is_guildie then
              local guildie_candidate_present = false
              for _, other_cand in ipairs(candidates) do
                if other_cand.is_guildie then guildie_candidate_present = true; break end
              end
              if guildie_candidate_present then
                kick_reason = kick_reason .. " (guild member priority)."
              end
            end

            pending_kicks[kick_target] = kick_reason
            kicked_count = kicked_count + 1
          end
        end
      end

      -- Update the referenced count accurately based on how many were marked
      current_count_ref[1] = current_count - kicked_count

      -- Update the _old table with players *not* marked for kick
      local new_old_table = {}
      for k, v in pairs(role_table or {}) do -- Add 'or {}' for safety
        if not pending_kicks[k] then new_old_table[k] = v end
      end
      return new_old_table -- Return the updated _old table
    end

    -- Use the helper function (pass counts by reference using a table)
	tanks_t_old = mark_excess_roles(tanks_t, tanks_t_old, AutoBand.saved.max_tanks, "tanks", {tanks})
	healers_t_old = mark_excess_roles(healers_t, healers_t_old, AutoBand.saved.max_healers, "healers", {healers})

    if AutoBand.saved.dps_weighting_enabled then
      mdps_t_old = mark_excess_roles(mdps_t, mdps_t_old, AutoBand.saved.max_mdps, "melee dps", {mdpss})
      rdps_t_old = mark_excess_roles(rdps_t, rdps_t_old, AutoBand.saved.max_rdps, "ranged dps", {rdpss})
      dps_t_old = {}
    else
      dps_t_old = mark_excess_roles(dps_t, dps_t_old, AutoBand.saved.max_dps, "dps", {dpss})
      mdps_t_old = {}
      rdps_t_old = {}
    end
  else
    -- Clear _old tables if role composition is off to prevent stale data affecting next enable
    tanks_t_old, healers_t_old, dps_t_old, mdps_t_old, rdps_t_old = {}, {}, {}, {}, {}
  end

  -- Enqueue all pending kicks
  for name, reason in pairs(pending_kicks) do
    AutoBand.enqueue_kick(name, reason)
  end

end

function add_role_to_message(needed, available, singular_name, plural_name, message_parts)
    plural_name = plural_name or singular_name .. "s"
    if needed > 0 and available > 0 then
        if available == 1 then
            table.insert(message_parts, singular_name)
        elseif available >= needed then
            if needed == 1 then
                table.insert(message_parts, singular_name)
            else
                table.insert(message_parts, needed .. " " .. plural_name)
            end
        else
            table.insert(message_parts, plural_name)
        end
    end
end

function AutoBand.auto_note()
    -- Cache locals and early exit
    number2 = number2 + 1
    local saved = AutoBand.saved
    if not (saved.autonote_enabled and AutoBand.has_permission()) or AutoBand.debugon then return end
    if number2 <= 60 then return end
    number2 = 0

    local wb = AutoBand.get_wb()
    if not wb then return end

    -- Settings
    local weighting     = saved.dps_weighting_enabled
    local max_mdps      = saved.max_mdps
    local max_rdps      = saved.max_rdps
	local max_dps       = saved.max_dps
	local max_tanks     = saved.max_tanks
	local max_healers   = saved.max_healers
    -- Count roles in one pass
    local tanks, healers, mdpss, rdpss = 0, 0, 0, 0
    wb:foreach_player(function(_,player)
        if     player.role == AB_const.TANK   then tanks   = tanks   + 1
        elseif player.role == AB_const.HEALER then healers = healers + 1
        elseif player.role == AB_const.MDPS   then mdpss   = mdpss   + 1
        elseif player.role == AB_const.RDPS   then rdpss   = rdpss   + 1 end
    end)

    local total_players    = tanks + healers + mdpss + rdpss
    local available_spots  = math.max(0, 24 - total_players)

    -- Determine needs
	local neededTank = math.max(0, max_tanks - tanks)
	local neededHealer = math.max(0, max_healers- healers)
    local neededMdps, neededRdps, neededDps = 0, 0, 0
    if saved.autokick_enabled and weighting then
        neededMdps = math.max(0, max_mdps - mdpss)
        neededRdps = math.max(0, max_rdps - rdpss)
    else
		neededDps = math.max(0, max_dps - (mdpss + rdpss))
    end

    -- Build message parts
    local parts = {}
    -- Stealth suffix
    local stealth_suffix = ""
    -- Stealth suffix: skip if race restriction on and race is neither Empire nor Chaos
    local skip_stealth_note = saved.restrict_same_race and AutoBand.raceDetermined
                              and (AutoBand.race ~= AB_const.EMPIRE and AutoBand.race ~= AB_const.CHAOS)
    if saved.autokick_we_wh_enabled and not skip_stealth_note then
        local icon = (AutoBand.faction == AB_const.ORDER) and AB_const.ICONS.wh
                  or (AutoBand.faction == AB_const.DESTRUCTION) and AB_const.ICONS.we
                  or ""
        if icon ~= "" then stealth_suffix = " (no " .. icon .. ")" end
    end

    add_role_to_message(neededTank,   available_spots, AB_const.ICONS.tank   .. " tank",  nil, parts)
    add_role_to_message(neededHealer, available_spots, AB_const.ICONS.healer .. " healer", nil, parts)
    if saved.autokick_enabled and weighting then
        add_role_to_message(neededMdps, available_spots, AB_const.ICONS.mdps .. " mdps" .. stealth_suffix,
                                             AB_const.ICONS.mdps .. " mdps" .. stealth_suffix, parts)
        add_role_to_message(neededRdps, available_spots, AB_const.ICONS.rdps .. " rdps",
                                             AB_const.ICONS.rdps .. " rdps", parts)
    else
        add_role_to_message(neededDps, available_spots, AB_const.ICONS.dps .. " dps" .. stealth_suffix,
                                            AB_const.ICONS.dps .. " dps" .. stealth_suffix, parts)
    end

    -- Only send if needed
    if #parts > 0 and available_spots > 0 then
        local prefixicon = AB_const.ICONS.prefix or ""
        local suffixicon = AB_const.ICONS.suffix or ""
        -- Purpose & race prefix
        local purpose_string = ""
        if AutoBand.current_purpose then
            purpose_string = (AB_const.WARBAND_PURPOSES[AutoBand.current_purpose].display or AutoBand.current_purpose) .. " "
        end
        local race_prefix = ""
        if saved.restrict_same_race and AutoBand.raceDetermined then
            race_prefix = (AB_const.RACE_THEMES[AutoBand.race] or AB_const.RACE_THEMES["Default"]).prefix
        end

        -- Separator logic
        local sep = (#parts > 1 and available_spots == 1) and " or " or " / "
        if sep == " / " then
            local need_num = false
            for _,p in ipairs(parts) do if p:match("^%d+ ") then need_num = true; break end end
            if need_num then
                for i,p in ipairs(parts) do
                    if not p:match("^%d+ ") then
                        if neededTank   == 1 and p:find(AB_const.ICONS.tank .. " tank", 1, true) then parts[i] = "1 " .. p
                        elseif neededHealer == 1 and p:find(AB_const.ICONS.healer .. " healer", 1, true) then parts[i] = "1 " .. p
                        elseif saved.dps_weighting_enabled then
                            if neededMdps == 1 and p:find(AB_const.ICONS.mdps .. " mdps", 1, true) then parts[i] = "1 " .. p
                            elseif neededRdps == 1 and p:find(AB_const.ICONS.rdps .. " rdps", 1, true) then parts[i] = "1 " .. p end
                        elseif neededDps == 1 and p:find(AB_const.ICONS.dps .. " dps", 1, true) then parts[i] = "1 " .. p end
                    end
                end
            end
        end

        -- Construct payload
		local needs_prefix = ""
		if AutoBand.saved.autokick_enabled then
			-- Use X-Y-Z format if autokick (enforcing role composition mode) is enabled
			needs_prefix = AutoBand.saved.max_tanks .. "-" .. AutoBand.saved.max_healers .. "-" .. AutoBand.saved.max_dps .. " Warband needs - "
		else
			-- Use the default text otherwise
			needs_prefix = "Warband needs - "
		end
		local payload = race_prefix .. purpose_string .. needs_prefix .. table.concat(parts, sep)
        -- local payload = race_prefix .. purpose_string .. "Warband needs - " .. table.concat(parts, sep)
        local total_needed = neededTank + neededHealer + (saved.autokick_enabled and weighting and (neededMdps + neededRdps) or neededDps)
        if total_needed > available_spots then
            payload = payload .. " - (" .. available_spots .. " spot" .. (available_spots == 1 and "" or "s") .. " available) - "
        else
            payload = payload .. " - "
        end
        if saved.min_rank_healer ~= saved.min_rank then
            payload = payload .. " Min rank healers: " .. saved.min_rank_healer .. "+, others: " .. saved.min_rank .. "+"
        else
            payload = payload .. " Min rank: " .. saved.min_rank .. "+"
        end

        -- Enqueue note
        AutoBand.enqueue_command("/1 " .. prefixicon .. AutoBand.GetFormattedPrefixRaw(true) .. payload .. suffixicon)
    end
end

function AutoBand.cmd_search_roles(args)
	local saved = AutoBand.saved
    local wb_obj = AutoBand.get_wb()
    if not wb_obj or wb_obj.player_count == 0 then
        AB_util.print("[Error] Not currently in an active warband.")
        return
    end

    -- Determine if the current player IS the leader
    local is_current_player_leader = AutoBand.has_permission()

    local actual_leader_name_str = nil
    local leader_name_found = false
    local leader_is_player_self = false

    -- Try PartyUtils first
    local success_pu, leaderInfo = pcall(PartyUtils.GetWarbandLeader)
    if success_pu and leaderInfo and leaderInfo.name then
        local leader_name_raw = leaderInfo.name
        actual_leader_name_str = tostring(AutoBand.FixString(leader_name_raw))
        if leader_name_raw == GameData.Player.name then
            leader_is_player_self = true
        end
        leader_name_found = true
    end

    -- Fallback if PartyUtils failed
    if not leader_name_found then
        wb_obj:foreach_player(function(gid, player)
            if player.isGroupLeader then
                actual_leader_name_str = tostring(AutoBand.FixString(player.name))
                if player.name == GameData.Player.name then
                    leader_is_player_self = true
                end
                leader_name_found = true
                return
            end
        end)
    end

    -- Final check if leader name was determined
    if not leader_name_found or not actual_leader_name_str or actual_leader_name_str == "" then
        AB_util.print("[Error] Could not determine the warband leader's name to generate the message.")
        return
    end

    -- *** Calculate Current Roles ***
    local tanks, healers, dpss, mdpss, rdpss = 0, 0, 0, 0, 0
    local total_players = 0
    local leader_race = AutoBand.race -- Leader's race from AutoBand state
    local race_restriction_active = AutoBand.saved.restrict_same_race and is_current_player_leader and AutoBand.raceDetermined
	
    wb_obj:foreach_player(function(gid, player)
        total_players = total_players + 1
        if     player.role == AB_const.TANK   then tanks  = tanks  + 1
        elseif player.role == AB_const.HEALER then healers = healers + 1
        elseif player.role == AB_const.MDPS   then dpss   = dpss   + 1; mdpss = mdpss + 1
        elseif player.role == AB_const.RDPS   then dpss   = dpss   + 1; rdpss = rdpss + 1
        end
    end)

    -- *** Get Player Zone Info ***
    local players_by_zid      = AutoBand.get_players_zone(wb_obj)
    local leader_zone_name_str = "Unknown Zone/Offline"
    if players_by_zid and players_by_zid["valid_as"] then
        local found = false
        for zid, group in pairs(players_by_zid["valid_as"]) do
            if found then break end
            for _, pl in ipairs(group) do
                if pl.isGroupLeader then
                    if zid and zid ~= 0 then
                        local ok, zn = pcall(GetZoneName, zid)
                        if ok and zn and zn ~= L"" then
                            leader_zone_name_str = tostring(zn)
                        else
                            leader_zone_name_str = "Unknown Zone ("..tostring(zid)..")"
                        end
                    else
                        leader_zone_name_str = "Offline"
                    end
                    found = true
                    break
                end
            end
        end
        if not found then
            AB_util.print("[Warning] Could not determine leader's zone precisely.")
        end
    else
        AB_util.print("[Warning] Could not get zone data structure.")
    end

    -- *** Calculate Needs ***
	local neededTank = math.max(0, AutoBand.saved.max_tanks - tanks)
	local neededHealer = math.max(0, AutoBand.saved.max_healers - healers)
    local neededMdps, neededRdps, neededDps = 0, 0, 0
    local available_spots = math.max(0, 24 - total_players)
    local total_needed_spots
    if AutoBand.saved.autokick_enabled and AutoBand.saved.dps_weighting_enabled then
        neededMdps = math.max(0, AutoBand.saved.max_mdps - mdpss)
        neededRdps = math.max(0, AutoBand.saved.max_rdps - rdpss)
        total_needed_spots = neededTank + neededHealer + neededMdps + neededRdps
    else
		neededDps = math.max(0, AutoBand.saved.max_dps - dpss)
        total_needed_spots = neededTank + neededHealer + neededDps
    end

    -- *** Build Role Message Parts ***
    local message_parts = {}
    local stealth_suffix = ""
    local skip_stealth_note = saved.restrict_same_race and AutoBand.raceDetermined
                              and (AutoBand.race ~= AB_const.EMPIRE and AutoBand.race ~= AB_const.CHAOS)
    if is_current_player_leader and AutoBand.saved.autokick_we_wh_enabled and not skip_stealth_note then
        local icon = (AutoBand.faction == AB_const.ORDER) and AB_const.ICONS.wh
                   or (AutoBand.faction == AB_const.DESTRUCTION) and AB_const.ICONS.we
                   or ""
        if icon ~= "" then stealth_suffix = " (no "..icon..")" end
    end

    add_role_to_message(neededTank,   available_spots, AB_const.ICONS.tank  .. " tank",  nil, message_parts)
    add_role_to_message(neededHealer, available_spots, AB_const.ICONS.healer.. " healer", nil, message_parts)
    if AutoBand.saved.autokick_enabled and AutoBand.saved.dps_weighting_enabled then
        add_role_to_message(neededMdps, available_spots, AB_const.ICONS.mdps .. " mdps"..stealth_suffix,
                                             AB_const.ICONS.mdps.." mdps"..stealth_suffix, message_parts)
        add_role_to_message(neededRdps, available_spots, AB_const.ICONS.rdps .. " rdps",
                                             AB_const.ICONS.rdps.." rdps", message_parts)
    else
        add_role_to_message(neededDps, available_spots, AB_const.ICONS.dps .. " dps"..stealth_suffix,
                                            AB_const.ICONS.dps.." dps"..stealth_suffix, message_parts)
    end

    if #message_parts > 0 and available_spots > 0 then
        -- *** Determine Channels ***
        local channels_to_send = {}
        local feedback = {}
        local valid = {["1"]=true, ["t4"]=true, ["5"]=true}
        for _, arg in ipairs(args) do
            local c = arg:lower():gsub("/", "")
            if valid[c] then channels_to_send["/"..c] = true end
        end
        if next(channels_to_send) == nil then
            AB_util.print("Usage: /ab searchroles <1|t4|5>")
            AB_util.print("Please specify at least one channel (/1, /t4, /5).")
            return
        end

        -- *** Build The Opening & Closing ***
        local message_start, join_suffix, rank_info, add_prefix = "", "", "", ""
        local prefixicon = AB_const.ICONS["prefix"] or ""
        local suffixicon = AB_const.ICONS["suffix"] or ""
        local purpose_string = ""
		local race_prefix = ""

        if is_current_player_leader then
            if AutoBand.current_purpose and AB_const.WARBAND_PURPOSES[AutoBand.current_purpose] then
                purpose_string = (AB_const.WARBAND_PURPOSES[AutoBand.current_purpose].display or AutoBand.current_purpose) .. " "
            end
            if race_restriction_active then
                 local theme = AB_const.RACE_THEMES[leader_race] or AB_const.RACE_THEMES["Default"]
                 race_prefix = theme.prefix -- Use the prefix defined in RACE_THEMES
            end
            -- message_start = purpose_string .. "Warband needs - "
			if AutoBand.saved.autokick_enabled then
				-- Use X-Y-Z format if autokick (encforcing role compositon mode) is enabled
				message_start = race_prefix .. purpose_string .. AutoBand.saved.max_tanks .. "-" .. AutoBand.saved.max_healers .. "-" .. AutoBand.saved.max_dps .. " Warband needs - "
			else
				-- Use the default text otherwise
				message_start = race_prefix .. purpose_string .. "Warband needs - "
			end
            -- message_start = race_prefix .. purpose_string .. "Warband needs - "
            add_prefix    = prefixicon .. AutoBand.GetFormattedPrefixRaw(true)
            if AutoBand.saved.min_rank_healer ~= AutoBand.saved.min_rank then
                rank_info = " - Min rank healers: "..AutoBand.saved.min_rank_healer.."+, others: "..AutoBand.saved.min_rank.."+"
            else
                rank_info = " - Min rank: "..AutoBand.saved.min_rank.."+"
            end
            join_suffix = ""
        else
            -- wrap name in colored <LINK> directly for clickable color
            local lead_color_name = AutoBand.saved.lead_color_name or AB_const.DEFAULT_LEAD_COLOR_NAME
            local rgb = AVAILABLE_COLORS[lead_color_name] or AVAILABLE_COLORS[AB_const.DEFAULT_LEAD_COLOR_NAME]
            local r,g,b = rgb[1], rgb[2], rgb[3]
            local display = "@"..actual_leader_name_str
            local colored_link = string.format(
                "<LINK data=\"PLAYER:%s\" color=\"%d,%d,%d\" text=\"%s\">",
                actual_leader_name_str, r, g, b, display
            )
            message_start = prefixicon .. colored_link .. " Warband needs - "
            join_suffix   = " - Please msg/join " .. colored_link
            rank_info     = ""
            add_prefix    = ""
        end

        -- Separator logic
        local sep = (#message_parts > 1 and available_spots == 1) and " or " or " / "
        if sep == " / " then
            local needNumeric = false
            for _, p in ipairs(message_parts) do
                if p:match("^%d+ ") then needNumeric = true; break end
            end
            if needNumeric then
                for i, p in ipairs(message_parts) do
                    if not p:match("^%d+ ") then
                        if neededTank == 1 and p:find(AB_const.ICONS.tank.." tank", 1, true) then
                            message_parts[i] = "1 " .. p
                        elseif neededHealer == 1 and p:find(AB_const.ICONS.healer.." healer", 1, true) then
                            message_parts[i] = "1 " .. p
                        elseif AutoBand.saved.dps_weighting_enabled then
                            if neededMdps == 1 and p:find(AB_const.ICONS.mdps.." mdps", 1, true) then
                                message_parts[i] = "1 " .. p
                            elseif neededRdps == 1 and p:find(AB_const.ICONS.rdps.." rdps", 1, true) then
                                message_parts[i] = "1 " .. p
                            end
                        elseif neededDps == 1 and p:find(AB_const.ICONS.dps.." dps", 1, true) then
                            message_parts[i] = "1 " .. p
                        end
                    end
                end
            end
        end

        -- Base message
        local base = message_start .. table.concat(message_parts, sep)
        if total_needed_spots > available_spots then
            base = base .. " - ("..available_spots.." spot"..(available_spots == 1 and "" or "s").." available)"
        end

        -- Final payloads
        local payload_t4 = base .. " - in - " .. leader_zone_name_str .. rank_info .. join_suffix
        local payload_1  = base .. rank_info .. join_suffix

        -- Send it
        for chan,_ in pairs(channels_to_send) do
            local target_channel = chan
			-- debug code - uncomment to send /t4 to /o
            -- if chan == "/t4" then
            --     target_channel = "/o"
            --     AB_util.print("[DEBUG] Rerouting /t4 message to /o")
            -- end
            local pl = (chan == "/t4" or chan == "/5") and payload_t4 or payload_1
            AutoBand.enqueue_command(target_channel .. " " .. add_prefix .. pl .. suffixicon)
            table.insert(feedback, chan)
        end
		
        table.sort(feedback)
        AB_util.print("Search sent in " .. table.concat(feedback, ", ") .. ".")
    else
        AB_util.print("Warband is full or no roles needed.")
    end
end

-- return a list of players who do not meet rank requirements
function AutoBand.get_low_rank(wb_obj)
    if (not wb_obj) then
        wb_obj = AutoBand.get_wb()
    end
    local list = {}
    wb_obj:foreach_player(
        function(gid, player)
            local needed = (player.role == "healer") and AutoBand.saved.min_rank_healer or AutoBand.saved.min_rank
            if (player.level < needed) then
                table.insert(list, player)
            end
        end
    )
    return list
end

function AutoBand.wb(args)
    wb_obj = AutoBand.get_wb()
    local tanks, healers, dpss, mdps, rdps, w_wh = 0, 0, 0, 0, 0, 0
    local ii = 0
    local guildmem = {}
    local guild_members = {}

    local g_m = GetGuildMemberData()
    for key, value in pairs(g_m) do
        table.insert(guild_members, value.name)
    end

    wb_obj:foreach_player(
        function(gid, player)
            if (player.role == "tank") then
                tanks = tanks + 1
            elseif (player.role == "healer") then
                healers = healers + 1
            elseif (player.role == "mdps") then
                mdps = mdps + 1
                dpss = dpss + 1
            elseif (player.role == "rdps") then
                rdps = rdps + 1
                dpss = dpss + 1
            end

            if (player.careerLine == GameData.CareerLine.WITCH_ELF or player.careerLine == GameData.CareerLine.WITCH_HUNTER) then
                w_wh = w_wh + 1
            end

            for key, value in pairs(guild_members) do
                if value:match(L"([^^]+)^?([^^]*)") == player.name then
                    ii = ii + 1
                    table.insert(guildmem, player.name)
                    break
                end
            end
        end
    )

    AB_util.print("Tanks in WB: " .. tanks)
    AB_util.print("Healers in WB: " .. healers)
    -- AB_util.print("MDPS in WB: " .. mdps)
    -- AB_util.print("RDPS in WB: " .. rdps)
    AB_util.print("DPSs in WB: " .. dpss .. " - " .. mdps .." MDPS, " .. rdps .. " RDPS.")
    -- AB_util.print("Stealthers in WB: " .. w_wh)
    AB_util.print("Guild members (including you) in WB: " .. ii)
    for key, value in pairs(guildmem) do
        AB_util.print(tostring(value))
    end
end

function AutoBand.get_players_zone(wb_obj)
    local zids = { ["valid_as"] = {}, ["valid_p"] = {} }
    local leader_zone = nil

    wb_obj:foreach_player(
        function(gid, player)
            if (player.isGroupLeader or player.isAssistant) then
                if (zids["valid_as"][player.zoneNum] == nil) then
                    zids["valid_as"][player.zoneNum] = {}
                end
                if (player.isGroupLeader) then
                    leader_zone = player.zoneNum
                    table.insert(zids["valid_as"][player.zoneNum], 1, player)
                else
                    table.insert(zids["valid_as"][player.zoneNum], player)
                end
            end
        end
    )

    if (leader_zone) then
        zids["other"] = {}
        wb_obj:foreach_player(
            function(gid, player)
                if (zids["valid_as"][player.zoneNum]) then
                    if (zids["valid_p"][player.zoneNum] == nil) then
                        zids["valid_p"][player.zoneNum] = {}
                    end
                    table.insert(zids["valid_p"][player.zoneNum], player)
                else
                    if (zids["other"][player.zoneNum] == nil) then
                        zids["other"][player.zoneNum] = {}
                    end
                    table.insert(zids["other"][player.zoneNum], player)
                end
            end
        )
    else
        AB_util.print("[ERROR] Leader cannot be found, the warband is BUGGED, reform a warband")
    end
    return zids
end

function AutoBand.get_fakewb(template)
    local wb = AB_wb:new()
    wb:set_groups()
    local num_players = 1
    for gid, tgroup in ipairs(template) do
        for j, tplayer in ipairs(tgroup) do
            wb:add_to_gid(tplayer.role, num_players, gid)
            num_players = num_players + 1
        end
    end
    wb:recalc_counters()
    wb:print()
    return wb
end

function AutoBand.FixString(str)
    if (str == nil) then
        return nil
    end
    local pos = str:find(L"^", 1, true)
    if (pos) then
        str = str:sub(1, pos - 1)
    end
    return str
end

function AutoBand.cmd_end(args)
    local wb_obj = AutoBand.get_wb()
    wb_obj:foreach_player(
        function(gid, player)
            AutoBand.enqueue_kick(player.name, "it ended, see you next time!")
        end
    )
end

function AutoBand.cmd_dump_player_data(args)
    AB_util.print("--- Dumping GameData.Player ---")
    -- Basic safety checks
    if not GameData or type(GameData) ~= "table" then
        AB_util.print("[Error] GameData object is not available or not a table.")
        AB_util.print("--- End GameData.Player Dump ---")
        return
    end
     if not GameData.Player or type(GameData.Player) ~= "table" then
         AB_util.print("[Error] GameData.Player is not available or not a table.")
         AB_util.print("Available keys directly under GameData:")
         -- Attempt to print top-level keys of GameData if Player is missing
         local game_data_keys = {}
         for k, _ in pairs(GameData) do
             table.insert(game_data_keys, tostring(k))
         end
         table.sort(game_data_keys)
         if #game_data_keys > 0 then
              AB_util.print("  " .. table.concat(game_data_keys, ", "))
         else
              AB_util.print("  (Could not list keys)")
         end
         AB_util.print("--- End GameData.Player Dump ---")
         return
     end

    -- Call the recursive dump function, wrapped in pcall for overall safety
    local success, err = pcall(AB_util.dump_recursive, GameData.Player, "  ") -- Start with indentation
     if not success then
         AB_util.print("[Error] An error occurred during the dump process: " .. tostring(err))
     end

    AB_util.print("--- End GameData.Player Dump ---")
end

function AutoBand.cmd_dump_guild_data(args)
    AB_util.print("--- Dumping GameData.Guild ---")
    -- Basic safety checks
    if not GameData or type(GameData) ~= "table" then
        AB_util.print("[Error] GameData object is not available or not a table.")
        AB_util.print("--- End GameData.Guild Dump ---")
        return
    end
     if not GameData.Guild or type(GameData.Guild) ~= "table" then
         AB_util.print("[Error] GameData.Guild is not available or not a table.")
         AB_util.print("Available keys directly under GameData:")
         -- Attempt to print top-level keys of GameData if Guild is missing
         local game_data_keys = {}
         for k, _ in pairs(GameData) do
             table.insert(game_data_keys, tostring(k))
         end
         table.sort(game_data_keys)
         if #game_data_keys > 0 then
              AB_util.print("  " .. table.concat(game_data_keys, ", "))
         else
              AB_util.print("  (Could not list keys)")
         end
         AB_util.print("--- End GameData.Guild Dump ---")
         return
     end

    -- Call the recursive dump function, wrapped in pcall for overall safety
    local success, err = pcall(AB_util.dump_recursive, GameData.Guild, "  ") -- Start with indentation
     if not success then
         AB_util.print("[Error] An error occurred during the dump process: " .. tostring(err))
     end

    AB_util.print("--- End GameData.Guild Dump ---")
end

function AutoBand.GetCurrentGuildInfo()
    if GameData and GameData.Guild and GameData.Guild.m_GuildID and GameData.Guild.m_GuildID ~= 0 and GameData.Guild.m_GuildName then
        return { id = tostring(GameData.Guild.m_GuildID), name = tostring(GameData.Guild.m_GuildName) }
    end
    return nil -- Not in a guild or data unavailable
end

function AutoBand.GenerateGuildLinkRaw(guild_id_str, guild_name_str)
    local prefix_color_name = AutoBand.saved.prefix_color_name or AB_const.DEFAULT_PREFIX_COLOR_NAME
    local color_rgb = AB_const.AVAILABLE_COLORS[prefix_color_name] or AB_const.AVAILABLE_COLORS[AB_const.DEFAULT_PREFIX_COLOR_NAME]
    if not color_rgb then -- Safety check
        color_rgb = AB_const.COLOR_WHITE -- Fallback white
    end
    local r, g, b = color_rgb[1], color_rgb[2], color_rgb[3]
    local link_color_str = string.format("%d,%d,%d", r, g, b)
    -- Use the guild *name* for the link text, wrapped in brackets
    local link_raw = string.format("[<LINK data=\"GUILD:%s\" text=\"%s\" color=\"%s\">]",
                                    guild_id_str,
                                    guild_name_str, -- Use actual guild name
                                    link_color_str)
    return link_raw
end

-- Generates the prefix as a raw Lua string (for SendChatText, /tell etc.)
function AutoBand.GetFormattedPrefixRaw(includeSpace)
    -- Check toggle and guild status
    if AutoBand.saved.prefix_use_guild then
        local guildInfo = AutoBand.GetCurrentGuildInfo()
        if guildInfo then
            -- Generate and return guild link (raw string)
            local link_raw = AutoBand.GenerateGuildLinkRaw(guildInfo.id, guildInfo.name)
            if includeSpace then return link_raw .. " " else return link_raw end
        end
        -- Fall through to normal prefix if toggle is on but not in guild
    end

    -- --- Original logic for normal prefix ---
    local prefix_text = AutoBand.saved.prefix_text or AB_const.DEFAULT_PREFIX_TEXT
    local color_name = AutoBand.saved.prefix_color_name or AB_const.DEFAULT_PREFIX_COLOR_NAME
    local color_rgb = AB_const.AVAILABLE_COLORS[color_name] or AB_const.AVAILABLE_COLORS[AB_const.DEFAULT_PREFIX_COLOR_NAME]
    if not color_rgb then color_rgb = AB_const.COLOR_WHITE end -- Safety
    local r, g, b = color_rgb[1], color_rgb[2], color_rgb[3]
    local coloredPart = string.format("<LINK data=\"0\" color=\"%d,%d,%d\" text=\"%s\">", r, g, b, prefix_text)
    local prefix = "[" .. coloredPart .. "]"
    if includeSpace then prefix = prefix .. " " end
    return prefix
end

-- Generates the prefix as a wstring (for EA_ChatWindow.Print)
function AutoBand.GetFormattedPrefixWString(includeSpace)
     -- Check toggle and guild status
    if AutoBand.saved.prefix_use_guild then
        local guildInfo = AutoBand.GetCurrentGuildInfo()
        if guildInfo then
            -- Generate guild link (raw), convert to wstring
            local link_raw = AutoBand.GenerateGuildLinkRaw(guildInfo.id, guildInfo.name)
            local link_wstring = towstring(link_raw)
            if includeSpace then return link_wstring .. L" " else return link_wstring end
        end
         -- Fall through to normal prefix if toggle is on but not in guild
    end

    -- --- Original logic for normal prefix (wstring) ---
    local prefix_text = AutoBand.saved.prefix_text or AB_const.DEFAULT_PREFIX_TEXT
    local color_name = AutoBand.saved.prefix_color_name or AB_const.DEFAULT_PREFIX_COLOR_NAME
    local color_rgb = AB_const.AVAILABLE_COLORS[color_name] or AB_const.AVAILABLE_COLORS[AB_const.DEFAULT_PREFIX_COLOR_NAME]
    if not color_rgb then color_rgb = AB_const.COLOR_WHITE end -- Safety
    local r, g, b = color_rgb[1], color_rgb[2], color_rgb[3]
    local coloredPartRaw = string.format("<LINK data=\"0\" color=\"%d,%d,%d\" text=\"%s\">", r, g, b, prefix_text)
    local prefix = L"[" .. towstring(coloredPartRaw) .. L"]"
    if includeSpace then prefix = prefix .. L" " end
    return prefix
end