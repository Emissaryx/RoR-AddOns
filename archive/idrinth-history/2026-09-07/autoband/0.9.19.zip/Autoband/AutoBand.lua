-- AutoBand.lua

AutoBand = {}
tanks_t_old = {}
healers_t_old = {}
dps_t_old = {}
mdps_t_old = {}
rdps_t_old = {}
roles_last = {}
toofar = {}
toofar_old = {}
toofar_not_changed = {}
warned = {}
number = 0
number2 = 12
g_m = {}
ign = {}
guild_members = {}
maxtanks = 8
maxhealers = 8
maxdps = 8

local MAX_MAP_POINTS = 511
local DISTANCE_FIX_COEFFICIENT = 1 / 1.06
local MapPointTypeFilter = {
    [SystemData.MapPips.PLAYER] = true,
    [SystemData.MapPips.GROUP_MEMBER] = true,
    [SystemData.MapPips.WARBAND_MEMBER] = true,
    [SystemData.MapPips.DESTRUCTION_ARMY] = true,
    [SystemData.MapPips.ORDER_ARMY] = true
}

function AutoBand.init()
    --------------------------------------------------------------------------
    -- 1) MODULE VARIABLES
    --------------------------------------------------------------------------
    AutoBand.cmd_queue				= {}
    AutoBand.cmd_current			= nil
    AutoBand.debugon				= false
    AutoBand.gizilon				= false
    AutoBand.offliners_countdown	= {}
    AutoBand.has_shortslash			= false
    AutoBand.elapsed				= 0

    --------------------------------------------------------------------------
    -- 2) PERSISTENT SETTINGS
    --------------------------------------------------------------------------
    -- A) CORE "SAVED" TABLE & CUSTOM ROLES
    AutoBand.saved					= AutoBand.saved or {}
    AutoBand.saved.custom_roles		= AutoBand.saved.custom_roles or {}

    -- B) CORE TOGGLES
    AutoBand.saved.autokick_enabled			= (AutoBand.saved.autokick_enabled == nil)       	and AB_const.AUTOKICK       or AutoBand.saved.autokick_enabled
    AutoBand.saved.autokick_toofar_enabled	= (AutoBand.saved.autokick_toofar_enabled == nil)	and AB_const.AUTOKICKTOOFAR or AutoBand.saved.autokick_toofar_enabled
	AutoBand.saved.autokick_lowrnk_enabled	= (AutoBand.saved.autokick_lowrnk_enabled == nil)	and AB_const.KICKLOWRNK		or AutoBand.saved.autokick_lowrnk_enabled
    AutoBand.saved.autonote_enabled			= (AutoBand.saved.autonote_enabled == nil)       	and AB_const.AUTONOTE       or AutoBand.saved.autonote_enabled
	AutoBand.saved.notify_buffs_enabled 	= (AutoBand.saved.notify_buffs_enabled == nil) 		and true 					or AutoBand.saved.notify_buffs_enabled

    -- C) KICK TIMERS & RANK RULES
    AutoBand.saved.autokick_period			= AutoBand.saved.autokick_period or AB_const.KICK_PERIOD
    AutoBand.saved.min_rank					= AutoBand.saved.min_rank        or AB_const.MINIMUM_RANK
    AutoBand.saved.min_rank_healer			= AutoBand.saved.min_rank_healer or AB_const.MINIMUM_RANK_HEALER
	
	if AutoBand.saved.min_rank_healer > AutoBand.saved.min_rank then
		local old_healer_rank = AutoBand.saved.min_rank_healer
		AutoBand.saved.min_rank_healer = AutoBand.saved.min_rank
	end

    -- D) TEMPLATES & ORGANIZATION ALGORITHM
    AutoBand.saved.default_template			= AutoBand.saved.default_template or AB_const.EMPTY_TEMPLATE
    AutoBand.saved.templates				= AutoBand.saved.templates        or {}
    AutoBand.saved.org_algo_mode			= AutoBand.saved.org_algo_mode    or AB_const.DEFAULT_ORG_ALGO
    AutoBand.saved.org_algo_role			= AutoBand.saved.org_algo_role    or AB_const.DEFAULT_ORG_ROLE

    -- E) ICON & GUILD PRIORITY
    AutoBand.saved.displayicon				= (AutoBand.saved.displayicon == nil) and true or AutoBand.saved.displayicon
	AutoBand.saved.right_click_organize 	= (AutoBand.saved.right_click_organize == nil) and AB_const.RIGHTCLICKORGANIZE or AutoBand.saved.right_click_organize
    AutoBand.saved.guild_priority_enabled	= (AutoBand.saved.guild_priority_enabled == nil)
												and AB_const.GUILDPRIORITY
												or AutoBand.saved.guild_priority_enabled

    -- F) KICK FUNCTION SPECIFICS
    if (AutoBand.saved.kick_func_enabled == nil) then
        AutoBand.saved.kick_func_enabled = {}
        for k, v in pairs(AB_const.KICK_FUNC_DEFAULT) do
            AutoBand.saved.kick_func_enabled[k] = v
        end
    end

    -- G) ALT SPEC CHECK & ROLE PRINTING
    AutoBand.saved.alt_speccheck_enabled	= (AutoBand.saved.alt_speccheck_enabled == nil) and AB_const.ALTCHECK  or AutoBand.saved.alt_speccheck_enabled
    AutoBand.saved.printrole_enabled		= (AutoBand.saved.printrole_enabled == nil)     and AB_const.PRINTROLE or AutoBand.saved.printrole_enabled

    -- H) DPS WEIGHTING SETTINGS
    AutoBand.saved.dps_weighting_enabled    = (AutoBand.saved.dps_weighting_enabled == nil) and AB_const.DPS_WEIGHTING_ENABLED or AutoBand.saved.dps_weighting_enabled
    AutoBand.saved.max_mdps                 = AutoBand.saved.max_mdps or AB_const.DEFAULT_MAX_MDPS
    AutoBand.saved.max_rdps                 = AutoBand.saved.max_rdps or AB_const.DEFAULT_MAX_RDPS
    -- Ensure consistency on load
    if AutoBand.saved.max_mdps + AutoBand.saved.max_rdps ~= maxdps then
        AutoBand.saved.max_mdps = AB_const.DEFAULT_MAX_MDPS
        AutoBand.saved.max_rdps = AB_const.DEFAULT_MAX_RDPS
    end
	
    -- I) DEBUG SETTINGS
    AutoBand.saved.dumps					= AutoBand.saved.dumps or {}
    AutoBand.saved.dumped_wb				= AutoBand.saved.dumped_wb or nil
    AutoBand.saved.default_dump				= AutoBand.saved.default_dump or nil

    --------------------------------------------------------------------------
    -- 3) REGISTER SLASH COMMANDS
    --------------------------------------------------------------------------
    LibSlash.RegisterSlashCmd("autoband", function(msg) AutoBand.parse_cmd(msg) end)
    if not LibSlash.IsSlashCmdRegistered("ab") then
        LibSlash.RegisterSlashCmd("ab", function(msg) AutoBand.parse_cmd(msg) end)
        AutoBand.has_shortslash = true
    end

    --------------------------------------------------------------------------
    -- 4) COMMAND LIST INITIALIZATION
    --    (help/info/UI, templates, kicking, zone, ranks, warband org, debug
    --------------------------------------------------------------------------
    AutoBand.cmd = {
        -- Help/Info & UI
        [""]				= { f=AutoBand.cmd_usage,					help="",													print_id=10 },
        ["help"]			= { f=AutoBand.cmd_usage,					help="show command list",									print_id=11 },
        ["info"]			= { f=AutoBand.cmd_show,					help="show current settings",								print_id=12 },
        ["show"]			= { f=AutoBand.cmd_toggle_gui,				help="open/close GUI",										print_id=13 },
        ["icon"]			= { f=AutoBand.cmd_toggle_icon,				help="show/hide minimap icon",								print_id=14 },
		["rco"]             = { f=AutoBand.cmd_toggle_rco,				help="toggle right-click organize on icon",          		print_id=15 },		

        -- Templates
        ["list"]			= { f=AutoBand.cmd_list_template,			help="list all templates",									print_id=20 },
        ["save"]			= { f=AutoBand.cmd_save_template,			help="<name> save current WB template",						print_id=21 },
        ["apply"]			= { f=AutoBand.cmd_apply_template,			help="<name> apply template",								print_id=22 },
        ["default"]			= { f=AutoBand.cmd_default_template,		help="set/clear default template",							print_id=23 },
        ["mode"]			= { f=AutoBand.cmd_mode,					help="<num> distribution algorithm mode",					print_id=24 },

        -- Kick / Auto-Kick
        ["kf"]				= { f=AutoBand.cmd_kick_toofar,				help="kick all far players",								print_id=30 },
        ["ak"]				= { f=AutoBand.cmd_flag_autokick,			help="toggle autokick low rank/excess roles",				print_id=31 },
        ["akf"]				= { f=AutoBand.cmd_flag_autokick_toofar,	help="toggle autokick toofar",								print_id=32 },
		["akl"]             = { f=AutoBand.cmd_flag_autokick_lowrnk,	help="toggle autokick low rank players",					print_id=33 },
        ["kicktimeout"]		= { f=AutoBand.cmd_autokick_timeout,		help="<mins> autokick toofar timeout",						print_id=34 },
        ["an"]				= { f=AutoBand.cmd_flag_autonote,			help="toggle autosearch in /1 for roles",					print_id=35 },
		["searchroles"] 	= { f=AutoBand.cmd_search_roles, 			help="[1] [t4] [5] search in chans", 						print_id=36 },
		["searchrole"]	 	= { f=AutoBand.cmd_search_roles, 			help=""		 															},
		["sr"]	 			= { f=AutoBand.cmd_search_roles, 			help=""		 															},
        ["gp"]				= { f=AutoBand.cmd_flag_guildpriority,		help="toggle guild priority",								print_id=37 },
        ["dpsweight"]       = { f=AutoBand.cmd_toggle_dps_weighting,    help="<on|off> toggle mDPS/rDPS weighting for 8-8-8", 		print_id=38 },
		["dw"]		 	    = { f=AutoBand.cmd_toggle_dps_weighting,    help=""																	},
        ["setdps"]          = { f=AutoBand.cmd_set_dps_weights,         help="<mdps> <rdps> set desired counts (sum must be 8)", 	print_id=39 },

        -- Zone
        ["zone"]			= { f=AutoBand.cmd_list_zone,				help="list players not in leader's zone",					print_id=40 },
        ["zonekick"]		= { f=AutoBand.cmd_kick_notinzone,			help="kick players not in leader's zone",					print_id=41 },

        -- Ranks
        ["rank"]			= { f=AutoBand.cmd_list_rank,				help="list players below required rank",					print_id=50 },
        ["minrank"]			= { f=AutoBand.cmd_rank,					help="<num> set min rank requirement",						print_id=51 },
        ["minrankhealer"]	= { f=AutoBand.cmd_rank_healer,				help="<num> min rank for healers",							print_id=52 },
        ["rankkick"]		= { f=AutoBand.cmd_kick_rank,				help="kick players below required rank",					print_id=53 },

        -- Warband Organization
        ["org"]				= { f=AutoBand.cmd_organize,				help="organize the warband",								print_id=60 },
		["buffnotify"] 		= { f=AutoBand.cmd_toggle_buffnotify, 		help="toggle notifying wb after org", 						print_id=61 },
		["bn"]		 		= { f=AutoBand.cmd_toggle_buffnotify, 		help=""																	},
        ["alt"]				= { f=AutoBand.cmd_alt_speccheck,			help="toggle alt-spec check",								print_id=62 },
        ["wb"]				= { f=AutoBand.wb,							help="information about the warband",						print_id=63 },
		["roles"] 			= { f=AutoBand.cmd_list_roles, 				help="[role] list players and their roles", 				print_id=64 },
		["role"]  			= { f=AutoBand.cmd_list_roles, 				help="" 																},
        ["pr"]				= { f=AutoBand.cmd_flag_printrole,			help="toggle printing of role assignments",					print_id=65 },
        ["customrole"]		= { f=AutoBand.cmd_custom_role,				help="<add/remove/list> manage role overrides",				print_id=66 },
		["customroles"]		= { f=AutoBand.cmd_custom_role,				help="<add/remove/list> manage role overrides",				print_id=66 },
		["cr"]				= { f=AutoBand.cmd_custom_role,				help=""																	},
        ["end"]				= { f=AutoBand.cmd_end,						help="end warband, kick all",								print_id=67 },

        -- Debug
        ["debug"]			= { f=AutoBand.cmd_debug,					help="",													print_id=100 },
        ["dump"]			= { f=AutoBand.cmd_dump,					help="",													print_id=101 },
        ["cleardump"]		= { f=AutoBand.cmd_cleardumps,				help="",													print_id=102 },
        ["listdump"]		= { f=AutoBand.cmd_list_dump,				help="",													print_id=103 },
        ["loaddump"]		= { f=AutoBand.cmd_load_dump,				help="",													print_id=104 },
        ["tempdump"]		= { f=AutoBand.cmd_dump_from_template,		help="",													print_id=105 },
    }

    --------------------------------------------------------------------------
    -- 5) SORT COMMANDS & DEBUG
    --------------------------------------------------------------------------
    AutoBand.cmd_ordered = {}
	for key, cmd in pairs(AutoBand.cmd) do
        if cmd.print_id ~= nil then
            cmd.key = key
            table.insert(AutoBand.cmd_ordered, cmd)
        end
    end
    table.sort(AutoBand.cmd_ordered, function(a, b) return a.print_id < b.print_id end)
    AB_util.debug(AutoBand.cmd_ordered)

    --------------------------------------------------------------------------
    -- 6) REGISTER LAYOUT WINDOW
    --------------------------------------------------------------------------
    LayoutEditor.RegisterWindow("AutoBandMapIcon", L"AutoBand", L"AutoBand Button", false, false, true, nil)

    --------------------------------------------------------------------------
    -- 7) PRINT LOADED MESSAGE
    --------------------------------------------------------------------------
    local slash = AutoBand.has_shortslash and " or /ab" or ""
    AB_util.print("AutoBand v" .. AB_const.VERSION .. " loaded. Type /autoband" .. slash .. " for instructions")
end

function AutoBand.cmd_flag_autokick_lowrnk(args)
    AutoBand.saved.autokick_lowrnk_enabled = not AutoBand.saved.autokick_lowrnk_enabled
    AB_util.print("Auto kick low rank players: " .. tostring(AutoBand.saved.autokick_lowrnk_enabled))
    if AutoBandWindow.showing() and AutoBandWindow.SelectedTab == AB_const.TABS_CONFIG then
        AutoBandWindowConfig.Show()
    end		
end

function AutoBand.cmd_toggle_buffnotify(args)
    AutoBand.saved.notify_buffs_enabled = not AutoBand.saved.notify_buffs_enabled
    AB_util.print("Notify warband after organize: " .. tostring(AutoBand.saved.notify_buffs_enabled))
    if AutoBandWindow.showing() and AutoBandWindow.SelectedTab == AB_const.TABS_TOOLS then
        AutoBandWindowTools.Show()
    end	
end

function AutoBand.cmd_alt_speccheck(args)
	AutoBand.saved.alt_speccheck_enabled = not AutoBand.saved.alt_speccheck_enabled
	AB_util.print("Use alt spec check: " .. tostring(AutoBand.saved.alt_speccheck_enabled))
    if AutoBandWindow.showing() and AutoBandWindow.SelectedTab == AB_const.TABS_CONFIG then
        AutoBandWindowConfig.Show()
    end	
end

function AutoBand.cmd_flag_printrole(args)
    AutoBand.saved.printrole_enabled = not AutoBand.saved.printrole_enabled
    AB_util.print("Print role assignments: " .. tostring(AutoBand.saved.printrole_enabled))
end

function AutoBand.cmd_list_roles(args)
    local role_filter = nil
    if args[1] then
        local role_param = args[1]:lower()
        if role_param ~= AB_const.TANK and role_param ~= AB_const.HEALER and
           role_param ~= AB_const.MDPS and role_param ~= AB_const.RDPS then
            AB_util.print("[error] Invalid role: " .. role_param .. ". Valid roles are " ..
                          AB_const.TANK .. ", " .. AB_const.HEALER .. ", " ..
                          AB_const.MDPS .. ", " .. AB_const.RDPS .. ".")
            return
        end
        role_filter = role_param
    end

    AB_util.print("Currently known player roles" ..
                  (role_filter and (" (" .. role_filter .. ")") or "") .. ":")
    local entries = {}
    for name, role in pairs(roles_last) do
        if not role_filter or role == role_filter then
            table.insert(entries, { name = name, role = role })
        end
    end

    table.sort(entries, function(a, b)
        if a.role == b.role then
            return a.name < b.name
        else
            return a.role < b.role
        end
    end)

    local count = 0
    for _, entry in ipairs(entries) do
        local msg = towstring("- [") .. towstring(entry.role) .. towstring("] - ") .. towstring(entry.name)
        AB_util.print(msg)
        count = count + 1
    end

    if count == 0 then
        AB_util.print("(no role data available)")
    end
end


function AutoBand.update(elapsed)
    AutoBand.elapsed = AutoBand.elapsed + elapsed
    if (AutoBand.elapsed > AB_const.HEARTBEAT) then
        local e = AutoBand.elapsed
        AutoBand.elapsed = 0
		need_role_update = true
        AutoBand.auto_kick()
        AutoBand.auto_kick_toofar()
        AutoBand.auto_note()
		if need_role_update then
			AutoBand.update_roles()
		end
    end

    if (AutoBand.cmd_current == nil) then
        if (#AutoBand.cmd_queue > 0) then
            AutoBand.cmd_current = table.remove(AutoBand.cmd_queue, 1)
        else
            return
        end
    end

    AutoBand.cmd_current.ticks = AutoBand.cmd_current.ticks - 1
    if (AutoBand.cmd_current.ticks <= 0) then
        if (AutoBand.debugon or AutoBand.gizilon) then
            AB_util.debug(tostring(AutoBand.cmd_current.cmd))
        end
        SendChatText(towstring(AutoBand.cmd_current.cmd), L"")
        local cmd_tmp = AutoBand.cmd_current
        AutoBand.cmd_current = nil
        if (cmd_tmp.callback) then
            cmd_tmp.callback(cmd_tmp)
        end
    end
end

function AutoBand.update_roles()
	local wb_obj = AutoBand.get_wb()
	if not wb_obj then
		AB_util.print("wb_obj is nil!")
		return
	end

	local current_players = {}

	local success, err = pcall(function()
		wb_obj:foreach_player(function(gid, player)
			AB_wb:track_role(player, current_players)
		end)
	end)

	if not success then
		AB_util.print("Error in foreach_player: " .. tostring(err))
	end

	AB_wb:remove_missing_players(current_players)
end

function AutoBand.cmd_custom_role(args)
    local subcmd = args[1]
    if subcmd == "add" and args[2] and args[3] then
        local name = args[2]
        local role = args[3]
        if role ~= "tank" and role ~= "healer" and role ~= "mdps" and role ~= "rdps" then
            AB_util.print("[error] Invalid role: " .. role .. " - valid choices are tank, healer, mdps or rdps.")
            return
        end
        AutoBand.saved.custom_roles[name] = role
        AB_util.print("Added role override: " .. name .. " -> " .. role)
		need_role_update = true
    elseif subcmd == "remove" and args[2] then
        AutoBand.saved.custom_roles[args[2]] = nil
        AB_util.print("Removed role override for: " .. args[2])
		need_role_update = true
    elseif subcmd == "list" then
        AB_util.print("Custom role overrides:")
        for k, v in pairs(AutoBand.saved.custom_roles) do
            AB_util.print("- " .. k .. ": " .. v)
        end
    else
        AB_util.print("Usage: /ab customrole add <name> <role>")
        AB_util.print("       /ab customrole remove <name>")
        AB_util.print("       /ab customrole list")
    end
end

-- enqueues a string to be processed by "AutoBand.update()"
function AutoBand.enqueue_command(cmd, ticks, callback)
    ticks = ticks or AB_const.DEFAULT_CMD_TICKS
    table.insert(AutoBand.cmd_queue, {
        ["cmd"] = cmd,
        ["ticks"] = ticks,
        ["callback"] = callback
    })
end

function AutoBand.enqueue_kick(player_name, msg_reason)
    if (msg_reason) then
        AutoBand.enqueue_command("/tell " .. tostring(player_name) ..
            " " .. AB_const.FORMATTED_PREFIX_RAW_WSPACE .. "You were kicked from the warband since " .. msg_reason)
    end
    AutoBand.enqueue_command(L"/kick " .. player_name)
    AB_util.print(L"Kicking " .. player_name)
end

function AutoBand.has_permission()
    local wb_obj = AutoBand.get_wb()
    local i = 0
    wb_obj:foreach_player(
        function(gid, player)
            i = i + 1
        end
    )
    if i == 0 then
        return false
    end
    return GameData.Player.isGroupLeader
end

-- returns a AB_wb object either from a warband, scenario or dumped_wb
function AutoBand.get_wb()
    if (AutoBand.debugon and AutoBand.saved.dumped_wb ~= nil) then
        AB_util.debug("Getting dump " .. AutoBand.saved.default_dump .. " size " ..
            AB_util.size_wb(AutoBand.saved.dumped_wb.group))
        return AB_wb:new(AutoBand.saved.dumped_wb)
    end
    local wb = AB_wb:new()
    wb:load_from_wbdata()
    return wb
end

-- ####### / Commands ####### 
function AutoBand.parse_cmd(msg)
    msg = msg:lower()
    local args = StringSplit(msg)
    cmd = table.remove(args, 1)
    if (AutoBand.cmd[cmd] ~= nil) then
        AutoBand.cmd[cmd].f(args)
    else
        AB_util.print("AutoBand unknown command: " .. msg)
    end
end

function AutoBand.cmd_usage(args)
    local ab = "/autoband "
    if (AutoBand.has_shortslash) then
        ab = "/ab "
    end
    AB_util.print("[Autoband commands]")
    for _, cmd in ipairs(AutoBand.cmd_ordered) do
        if (cmd.help ~= "" or AutoBand.debugon) then
            AB_util.print(ab .. cmd.key .. " - " .. cmd.help)
        end
    end
end

function AutoBand.cmd_show(args)
	AB_util.print(AB_const.FORMATTED_PREFIX_WSTR_NOSPACE .. towstring(" v" .. AB_const.VERSION .. " settings"))
    AB_util.print("Default template: " .. AutoBand.saved.default_template)
	
	AB_util.print("Right-click icon to organize: " .. tostring(AutoBand.saved.right_click_organize))	
    AB_util.print("Auto kick too far players: " .. tostring(AutoBand.saved.autokick_toofar_enabled))
    AB_util.print("Auto kick too far players timeout: " .. tostring(AutoBand.saved.autokick_period))
    AB_util.print("Minimum rank requirement: " .. tostring(AutoBand.saved.min_rank))
    AB_util.print("Minimum rank requirement (healer): " .. tostring(AutoBand.saved.min_rank_healer))
    AB_util.print("Auto form 8-8-8 wb (autokick): " .. tostring(AutoBand.saved.autokick_enabled))
	AB_util.print(" -> DPS Weighting Enabled: " .. tostring(AutoBand.saved.dps_weighting_enabled))
	if AutoBand.saved.dps_weighting_enabled then
		AB_util.print("    -> Max Melee DPS: " .. tostring(AutoBand.saved.max_mdps))
		AB_util.print("    -> Max Ranged DPS: " .. tostring(AutoBand.saved.max_rdps))
	end
	AB_util.print("Auto kick low rank players: " .. tostring(AutoBand.saved.autokick_lowrnk_enabled))
	AB_util.print("Guild priority when auto-kick: " .. tostring(AutoBand.saved.guild_priority_enabled))
	AB_util.print("Notify warband after organize: " .. tostring(AutoBand.saved.notify_buffs_enabled))
	AB_util.print("Use alt spec check: " .. tostring(AutoBand.saved.alt_speccheck_enabled))
	AB_util.print("Auto note in /1: " .. tostring(AutoBand.saved.autonote_enabled))
	AB_util.print("Print role assignments: " .. tostring(AutoBand.saved.printrole_enabled))
	    if (AutoBand.debugon) then
        AB_util.print("Data dumped: " .. tostring(AutoBand.saved.dumped_wb ~= nil))
        AB_util.print("Debug mode: true")
    end
end

function AutoBand.cmd_debug(args)
    AutoBand.debugon = not AutoBand.debugon
    AB_util.print("Debug mode: " .. tostring(AutoBand.debugon))
end

function AutoBand.cmd_flag_autokick(args)
    AutoBand.saved.autokick_enabled = not AutoBand.saved.autokick_enabled
    AB_util.print("Auto kick players: " .. tostring(AutoBand.saved.autokick_enabled))
    if AutoBandWindow.showing() and AutoBandWindow.SelectedTab == AB_const.TABS_CONFIG then
        AutoBandWindowConfig.Show()
    end	
end

function AutoBand.cmd_flag_autokick_toofar(args)
    AutoBand.saved.autokick_toofar_enabled = not AutoBand.saved.autokick_toofar_enabled
    if AutoBand.has_permission() then
        if AutoBand.saved.autokick_toofar_enabled then
			AutoBand.enqueue_command("/wb " .. AB_const.FORMATTED_PREFIX_RAW_WSPACE .. "Autokick players who are far away from leader ENABLED! Follow the leader PLEASE!")
        else
            AutoBand.enqueue_command("/wb " .. AB_const.FORMATTED_PREFIX_RAW_WSPACE .. "Autokick players who are far away from leader DISABLED! Free move!")
            warned = {}
			toofar = {}
            toofar_old = {}
            toofar_not_changed = {}
        end
    end
    AB_util.print("Auto kick too far players: " .. tostring(AutoBand.saved.autokick_toofar_enabled))
    if AutoBandWindow.showing() and AutoBandWindow.SelectedTab == AB_const.TABS_CONFIG then
        -- Call the Show function for the Config tab to refresh its controls
        AutoBandWindowConfig.Show()
    end 	
end

function AutoBand.cmd_flag_autonote(args)
    AutoBand.saved.autonote_enabled = not AutoBand.saved.autonote_enabled
    AB_util.print("Auto note in /1: " .. tostring(AutoBand.saved.autonote_enabled))
    if AutoBandWindow.showing() and AutoBandWindow.SelectedTab == AB_const.TABS_TOOLS then
        -- Call the Show function for the Tools tab to refresh its controls
        AutoBandWindowTools.Show()
    end	
end

function AutoBand.cmd_dump(args)
    if (args[1] == nil) then
        AB_util.print("[error] Missing argument")
        return
    end
    local wb = AB_wb:new()
    wb:load_from_wbdata()
    AutoBand.saved.dumped_wb = wb
    AutoBand.saved.default_dump = args[1]
    AutoBand.saved.dumps[args[1]] = wb
    AB_util.print("Dump complete")
end

function AutoBand.cmd_cleardumps(args)
    AutoBand.saved.dumped_wb = nil
    AutoBand.saved.dumps = {}
    AutoBand.saved.default_dump = nil
end

function AutoBand.cmd_kick_toofar(args)
    if (not AutoBand.has_permission()) then
        AB_util.print("[error] You need to be a wb leader")
        return
    end
    local wb_obj = AutoBand.get_wb()
    wb_obj:foreach_player(
        function(gid, player)
            for i = 1, MAX_MAP_POINTS do
                local mpd = GetMapPointData("EA_Window_OverheadMapMapDisplay", i)
                if (not mpd or not MapPointTypeFilter[mpd.pointType] or not mpd.name) then
                    continue
                end
                local name = AutoBand.FixString((mpd.name))
                if name == player.name then
                    player.distance = mpd.distance * DISTANCE_FIX_COEFFICIENT
                    if player.distance > 150 then
                        AutoBand.enqueue_kick(player.name, "not follow leader")
                    end
                    break
                end
            end
        end
    )
end

function AutoBand.cmd_list_offline(args)
    local wb_obj = AutoBand.get_wb()
    wb_obj:foreach_player(
        function(gid, player)
            for i = 1, MAX_MAP_POINTS do
                local mpd = GetMapPointData("EA_Window_OverheadMapMapDisplay", i)
                if (not mpd or not MapPointTypeFilter[mpd.pointType] or not mpd.name) then
                    continue
                end
                local name = AutoBand.FixString((mpd.name))
                if name == player.name then
                    player.distance = mpd.distance * DISTANCE_FIX_COEFFICIENT
                    if player.distance > 150 then
                        AB_util.print(player.name)
                    end
                end
            end
        end
    )
end

function AutoBand.cmd_list_rank(args)
    local str = ""
    local players = AutoBand.get_low_rank()
    if (#players > 0) then
        table.sort(players, function(p1, p2) return p1.level > p2.level end)
        for _, player in ipairs(players) do
            str = str .. tostring(player.name) .. "(r" .. player.level .. ") "
        end
        AB_util.print(AB_const.HEADER_MARGIN ..
            " Players with rank < (configured) " ..
            AB_const.HEADER_MARGIN ..
            " (#" .. #players .. ")")
        AB_util.print(str)
    end
end

function AutoBand.cmd_list_zone(args)
    local wb_obj = AutoBand.get_wb()
    if (wb_obj.player_count == 0) then
        AB_util.debug("No wb data found")
        return
    end

    local players_by_zid = AutoBand.get_players_zone(wb_obj)
    local num_valid_zones = AB_util.size_table(players_by_zid["valid_as"])
    if (players_by_zid["valid_as"] and num_valid_zones > 0) then
        AB_util.print(AB_const.HEADER_MARGIN ..
            " Leader's and assistants' zones " ..
            AB_const.HEADER_MARGIN)
        for zid, as_zone in pairs(players_by_zid["valid_as"]) do
            local num_assistants = AB_util.size_table(as_zone)
            local str = ""
            local num_players = AB_util.size_table(players_by_zid["valid_p"][zid])
            local zone_name = GetZoneName(zid)
            if (zid == 0) then
                zone_name = "Offline"
            end
            str = str .. tostring(zone_name) .. " (#" .. num_players .. ") "
            for _, player in ipairs(as_zone) do
                if (player.isGroupLeader) then
                    str = str .. tostring(player.name) ..
                    "(" .. AB_const.ABBREVATIONS["LEADER"] .. ") "
                else
                    str = str .. tostring(player.name) ..
                    "(" .. AB_const.ABBREVATIONS["ASSISTANT"] .. ") "
                end
            end
            AB_util.print(str)
        end
    end

    local num_invalid_zones = AB_util.size_table(players_by_zid["other"])
    if (players_by_zid["other"] and num_invalid_zones > 0) then
        AB_util.print(AB_const.HEADER_MARGIN ..
            " " ..
            AB_const.LABEL_NOTSAMEZONE ..
            " " ..
            AB_const.HEADER_MARGIN)
        for zid, other_zone in pairs(players_by_zid["other"]) do
            local str = ""
            local num_players = AB_util.size_table(other_zone)
            str = str ..
                tostring(GetZoneName(zid)) ..
                " (#" .. #other_zone .. ") "
            for _, player in ipairs(other_zone) do
                str = str .. tostring(player.name) .. " "
            end
            AB_util.print(str)
        end
    end
end

function AutoBand.cmd_kick_notinzone(args)
    if (not AutoBand.has_permission()) then
        AB_util.print("[error] You need to be a wb leader")
        return
    end

    local wb_obj = AutoBand.get_wb()
    if (wb_obj.player_count == 0) then
        AB_util.debug("No wb data found")
        return
    end

    local zone_name = GetZoneName
    local players_by_zid = AutoBand.get_players_zone(wb_obj)
    local num_valid_zones = AB_util.size_table(players_by_zid["valid_as"])

    if (players_by_zid["valid_as"] and num_valid_zones > 0) then
        local valid_zone_str = ""
        for zid, as_zone in pairs(players_by_zid["valid_as"]) do
            if (zid ~= 0) then
                valid_zone_str = valid_zone_str ..
                    tostring(zone_name(zid)) ..
                    " "
            end
        end

        local num_invalid_zones = AB_util.size_table(players_by_zid["other"])
        if (players_by_zid["other"] and num_invalid_zones > 0) then
            AB_util.print("Kicking " .. AB_const.LABEL_NOTSAMEZONE)
            for zid, other_zone in pairs(players_by_zid["other"]) do
                if (zid ~= 0) then
                    for _, player in ipairs(other_zone) do
                        AutoBand.enqueue_kick(player.name,
                            "you are not in one of the required zones {" ..
                            valid_zone_str .. "}")
                    end
                end
            end
        end
    end
    AB_util.print("Zone kick complete")
end

function AutoBand.cmd_rank(args)
    if (args[1] == nil) then
        AB_util.print("[error] Missing argument")
        return
    end
    local n = tonumber(args[1])
    if (n < 0 or n > 40) then
        AB_util.print("[error] Invalid rank value: " .. tostring(n))
        return
    end
    AutoBand.saved.min_rank = math.floor(n)

    -- Ensure the separate healer rank doesn't exceed the new min_rank
    if (AutoBand.saved.min_rank_healer > AutoBand.saved.min_rank) then
        AutoBand.saved.min_rank_healer = AutoBand.saved.min_rank
    end

    AB_util.print("Minimum rank requirement: " .. tostring(AutoBand.saved.min_rank))
    if AutoBandWindow.showing() and AutoBandWindow.SelectedTab == AB_const.TABS_CONFIG then
        AutoBandWindowConfig.Show()
    end		
end

function AutoBand.cmd_rank_healer(args)
    if (args[1] == nil) then
        AB_util.print("[error] Missing argument")
        return
    end
    local n = tonumber(args[1])
    if (n < 0 or n > 40) then
        AB_util.print("[error] Invalid healer rank value: " .. tostring(n))
        return
    end
    -- Make sure it cannot exceed the general min_rank
    if (n > AutoBand.saved.min_rank) then
        AB_util.print("[error] Healer min rank cannot exceed overall min rank (" ..
            AutoBand.saved.min_rank .. ")")
        return
    end
    AutoBand.saved.min_rank_healer = math.floor(n)
    AB_util.print("Minimum rank requirement (healer): " .. tostring(AutoBand.saved.min_rank_healer))
    if AutoBandWindow.showing() and AutoBandWindow.SelectedTab == AB_const.TABS_CONFIG then
        AutoBandWindowConfig.Show()
    end		
end

function AutoBand.cmd_kick_rank(args)
    if (not AutoBand.has_permission()) then
        AB_util.print("[error] You need to be a wb leader")
        return
    end
    local players = AutoBand.get_low_rank()
    if (#players > 0) then
        AB_util.print("Kicking players below rank requirements")
        for _, player in ipairs(players) do
            local needed = player.role == "healer" and AutoBand.saved.min_rank_healer or AutoBand.saved.min_rank
            AutoBand.enqueue_kick(player.name,
                "you don't meet the rank requirement (" .. needed .. ")")
        end
    end
    AB_util.print("Rank kick complete")
end

function AutoBand.cmd_organize(args)
    if (AutoBand.has_permission() or AutoBand.debugon) then
        if AutoBand.saved.autokick_enabled or AutoBand.saved.autokick_toofar_enabled then
            a = AutoBand.saved.autokick_enabled
            b = AutoBand.saved.autokick_toofar_enabled
            AutoBand.saved.autokick_enabled = false
            AutoBand.saved.autokick_toofar_enabled = false
            if (args[1] ~= nil) then
                AB_org.auto_organize(AutoBand.saved.templates[args[1]])
            else
                AB_org.auto_organize(AutoBand.saved.templates[AutoBand.saved.default_template])
            end
            AutoBand.saved.autokick_enabled = a
            AutoBand.saved.autokick_toofar_enabled = b
        else
            if (args[1] ~= nil) then
                AB_org.auto_organize(AutoBand.saved.templates[args[1]])
            else
                AB_org.auto_organize(AutoBand.saved.templates[AutoBand.saved.default_template])
            end
        end
    else
        AB_util.print("[error] You need to be a wb leader")
    end
end

function AutoBand.cmd_autokick_timeout(args)
    if (args[1] == nil) then
        AB_util.print("[error] Missing argument")
        return
    end
    local n = tonumber(args[1])
    if (n < 0) then
        AB_util.print("[error] Invalid timeout value: " .. tostring(n))
        return
    end
    AutoBand.saved.autokick_period = math.floor(n)
    AB_util.print("Auto kick timeout: " .. tostring(AutoBand.saved.autokick_period))
    if AutoBandWindow.showing() and AutoBandWindow.SelectedTab == AB_const.TABS_CONFIG then
        AutoBandWindowConfig.Show()
    end	
end

function AutoBand.cmd_mode(args)
    if (args[1] == nil) then
        AB_util.print("[error] Missing argument")
        return
    end
    local n = tonumber(args[1])
    if (n < 0 or n > 2) then
        AB_util.print("[error] Invalid distribution algorithm: " .. tostring(n))
        return
    end
    AutoBand.saved.org_algo_mode = math.floor(n)
    AB_util.print("Distribution algorithm mode: " ..
        tostring(AutoBand.saved.org_algo_mode) ..
        AB_const.ALGO_MODE[AutoBand.saved.org_algo_mode])
    if AutoBandWindow.showing() and AutoBandWindow.SelectedTab == AB_const.TABS_CONFIG then
        AutoBandWindowConfig.Show()
    end			
end

function AutoBand.cmd_flag_guildpriority(args)
    AutoBand.saved.guild_priority_enabled = not AutoBand.saved.guild_priority_enabled
    AB_util.print("Guild priority for auto-kick: " .. tostring(AutoBand.saved.guild_priority_enabled))
    if AutoBandWindow.showing() and AutoBandWindow.SelectedTab == AB_const.TABS_CONFIG then
        AutoBandWindowConfig.Show()
    end	
end

function AutoBand.cmd_list_template(args)
    AB_util.print("Default template " .. AutoBand.saved.default_template)
    for tname in pairs(AutoBand.saved.templates) do
        AB_util.print(tname)
    end
end

function AutoBand.cmd_save_template(args)
    if (args[1] == nil) then
        AB_util.print("[error] Missing argument")
        return
    end
    AutoBand.saved.templates[args[1]] = AB_template.from_wb(AutoBand.get_wb())
    AB_util.print("Template " .. args[1] .. " saved")
end

function AutoBand.cmd_apply_template(args)
    if (args[1] == nil) then
        AB_util.print("[error] Missing argument")
        return
    end
    if (AutoBand.saved.templates[args[1]] == nil) then
        AB_util.print("[error] Template " .. args[1] .. " does not exist")
        return
    end
    AB_org.auto_organize(AutoBand.saved.templates[args[1]])
    AB_util.print("Template " .. args[1] .. " loaded")
end

function AutoBand.cmd_default_template(args)
    if (#args > 0) then
        if (AutoBand.saved.templates[args[1]] == nil) then
            AB_util.print("[error] Template " .. args[1] .. " does not exist")
            return
        end
        AutoBand.saved.default_template = args[1]
    else
        AutoBand.saved.default_template = AB_const.EMPTY_TEMPLATE
    end
    AB_util.print("Default template set: " .. AutoBand.saved.default_template)
    if AutoBandWindow.showing() and AutoBandWindow.SelectedTab == AB_const.TABS_CONFIG then
        AutoBandWindowConfig.Show()
    end		
end

function AutoBand.cmd_toggle_gui(args)
    if (AutoBandWindow.showing()) then
        AutoBandWindow.Hide()
    else
        AutoBandWindow.Show()
    end
end

function AutoBand.cmd_toggle_icon(args)
    AutoBandWindow.toggle_mapicon()
    if AutoBandWindow.showing() and AutoBandWindow.SelectedTab == AB_const.TABS_CONFIG then
        AutoBandWindowConfig.Show()
    end	
end

function AutoBand.cmd_toggle_rco(args)
    AutoBand.saved.right_click_organize = not AutoBand.saved.right_click_organize
    AB_util.print("Right-click icon to organize: " .. tostring(AutoBand.saved.right_click_organize))
    -- Refresh GUI if open and on the correct tab
    if AutoBandWindow.showing() and AutoBandWindow.SelectedTab == AB_const.TABS_TOOLS then
        AutoBandWindowTools.Show() -- Call Show to refresh the checkbox state
    end
end

function AutoBand.HandleIconRightClick()
    if AutoBand.saved.right_click_organize then
        AB_util.print("Icon right-clicked: Organizing warband...") -- Optional user feedback
        -- Call the existing organize command function, passing an empty table for args
        AutoBand.cmd_organize({})
    else
         -- Optional: Provide feedback if the setting is disabled
         -- AB_util.print("Icon right-clicked, but organize function is disabled in settings.")
    end
end

function AutoBand.cmd_list_dump(args)
    if (AutoBand.saved.dumped_wb ~= nil) then
        AB_util.print("[AutoBand] default dump " .. AutoBand.saved.default_dump)
    end
    for tname in pairs(AutoBand.saved.dumps) do
        AB_util.print(tname)
    end
end

function AutoBand.cmd_load_dump(args)
    if (#args > 0) then
        if (AutoBand.saved.dumps[args[1]] == nil) then
            AB_util.print("[error] Dump " .. args[1] .. " does not exist")
            return
        end
        AutoBand.saved.default_dump = args[1]
        AutoBand.saved.dumped_wb = AutoBand.saved.dumps[AutoBand.saved.default_dump]
    end
    AB_util.print("[AutoBand] Default dump set: " .. AutoBand.saved.default_dump)
end

function AutoBand.cmd_dump_from_template(args)
    if (AutoBand.debugon) then
        if (#args > 1) then
            local template_name = args[1]
            local dump_name = args[2]
            if (AutoBand.saved.templates[template_name] == nil) then
                AB_util.print("[error] Template " .. template_name .. " does not exist")
                return
            end
            AutoBand.saved.dumped_wb = AutoBand.get_fakewb(AutoBand.saved.templates[template_name])
            AutoBand.saved.dumps[dump_name] = AutoBand.saved.dumped_wb
            AutoBand.saved.default_dump = dump_name
        end
    end
end

function AutoBand.auto_kick_toofar()
    if (not AutoBand.saved.autokick_toofar_enabled or not AutoBand.has_permission() or AutoBand.debugon) then
        return
    end
    local wb_obj = AutoBand.get_wb()
    wb_obj:foreach_player(
        function(gid, player)
            for i = 1, MAX_MAP_POINTS do
                local mpd = GetMapPointData("EA_Window_OverheadMapMapDisplay", i)
                if (not mpd or not MapPointTypeFilter[mpd.pointType] or not mpd.name) then
                    continue
                end
                local name = AutoBand.FixString((mpd.name))
                if name == player.name then
                    player.distance = mpd.distance * DISTANCE_FIX_COEFFICIENT
                    if player.distance > 150 then
                        if toofar[player.name] then
                            toofar[player.name] = toofar[player.name] + 1
                        else
                            toofar[player.name] = 1
                        end
                        if (toofar[player.name] == 6) then
                            local found = 0
                            for i, v in pairs(warned) do
                                if v == player.name then
                                    found = 1
                                    break
                                end
                            end
                            if found == 0 then
                                AutoBand.enqueue_command("/tell " .. tostring(player.name) ..
								    " " .. AB_const.FORMATTED_PREFIX_RAW_WSPACE .. "You are too far from leader, you will be autokicked in " ..
                                    AutoBand.saved.autokick_period * 60 - 30 ..
                                    "sec! Follow the leader PLZ")
                                table.insert(warned, player.name)
                            end
                        end
                        if (toofar[player.name] > AutoBand.saved.autokick_period * 12) then
                            AutoBand.enqueue_kick(player.name,
                                "was too far from warband leader for a long time")
                        end
                    else
                        toofar[player.name] = nil
                    end
                    break
                end
            end
        end
    )

    for i, v in pairs(toofar) do
        for ii, vv in pairs(toofar_old) do
            if i == ii then
                if v == vv then
                    if toofar_not_changed[i] then
                        toofar_not_changed[i] = toofar_not_changed[i] + 1
                    else
                        toofar_not_changed[i] = 1
                    end
                    if toofar_not_changed[i] > 60 then
                        toofar[i] = nil
                        toofar_not_changed[i] = nil
                    end
                end
                break
            end
        end
    end

    toofar_old = {}
    for key, value in pairs(toofar) do
        toofar_old[key] = value
    end
end

function AutoBand.cmd_toggle_dps_weighting(args)
    if not AutoBand.saved.autokick_enabled then
         AB_util.print("[Warning] DPS weighting only applies when 'Auto form 8-8-8 wb' (/ab ak) is enabled.")
    end

    local state = args[1]
    if state == "on" then
        AutoBand.saved.dps_weighting_enabled = true
        AB_util.print("DPS weighting for 8-8-8 enabled. Max MDPS: " .. AutoBand.saved.max_mdps .. ", Max RDPS: " .. AutoBand.saved.max_rdps)
    elseif state == "off" then
        AutoBand.saved.dps_weighting_enabled = false
        AB_util.print("DPS weighting for 8-8-8 disabled.")
    else
        AutoBand.saved.dps_weighting_enabled = not AutoBand.saved.dps_weighting_enabled
        AB_util.print("DPS weighting for 8-8-8 toggled to: " .. tostring(AutoBand.saved.dps_weighting_enabled))
        if AutoBand.saved.dps_weighting_enabled then
            AB_util.print(" -> Max MDPS: " .. AutoBand.saved.max_mdps .. ", Max RDPS: " .. AutoBand.saved.max_rdps)
        end
    end
     -- Refresh GUI if open
    if AutoBandWindow.showing() and AutoBandWindow.SelectedTab == AB_const.TABS_CONFIG then
        AutoBandWindowConfig.Show()
    end
end

function AutoBand.cmd_set_dps_weights(args)
    local mdps_count = tonumber(args[1])
    local rdps_count = tonumber(args[2])

    if not mdps_count or not rdps_count or mdps_count < 0 or rdps_count < 0 then
        AB_util.print("[Error] Invalid counts. Usage: /ab setdps <mdps_count> <rdps_count>")
        return
    end

    mdps_count = math.floor(mdps_count)
    rdps_count = math.floor(rdps_count)

    if mdps_count + rdps_count ~= maxdps then -- Use the global maxdps (8)
        AB_util.print("[Error] Counts must sum to " .. maxdps .. ". Provided: " .. mdps_count .. " MDPS + " .. rdps_count .. " RDPS.")
        return
    end

    AutoBand.saved.max_mdps = mdps_count
    AutoBand.saved.max_rdps = rdps_count
    AB_util.print("DPS weights set. Max MDPS: " .. AutoBand.saved.max_mdps .. ", Max RDPS: " .. AutoBand.saved.max_rdps)

    if not AutoBand.saved.dps_weighting_enabled then
        AB_util.print("[Warning] DPS weighting is currently disabled (/ab dpsweight on).")
    end
    if not AutoBand.saved.autokick_enabled then
         AB_util.print("[Warning] DPS weighting only applies when 'Auto form 8-8-8 wb' (/ab ak) is enabled.")
    end
     -- Refresh GUI if open
    if AutoBandWindow.showing() and AutoBandWindow.SelectedTab == AB_const.TABS_CONFIG then
		 AutoBandWindowConfig.refresh_dps_weights()
    end
end

function AutoBand.auto_kick()
    -- Basic permission/debug check first
    if (not AutoBand.has_permission() or AutoBand.debugon) then
        return
    end

    -- Check if *any* autokick feature we handle here is enabled, otherwise exit early
    if not AutoBand.saved.autokick_lowrnk_enabled and not AutoBand.saved.autokick_enabled then
        -- Clear _old tables if both features are off to prevent stale data
        tanks_t_old, healers_t_old, dps_t_old, mdps_t_old, rdps_t_old = {}, {}, {}, {}, {}
        return
    end

    local wb_obj = AutoBand.get_wb()
    if not wb_obj then AB_util.print("AutoKick: Could not get Warband Object."); return end -- Safety check

    local pending_kicks = {} -- Store all players to kick { [name] = reason }

    -- Variables needed only if 8-8-8 is enabled
    local tanks_t, healers_t, dps_t, mdps_t, rdps_t
    local tanks, healers, dpss, mdpss, rdpss
    local guild_member
    local g_m, guild_members, ign

    -- Initialize 8-8-8 specific variables and data only if that feature is enabled
    if AutoBand.saved.autokick_enabled then
        tanks_t, healers_t, dps_t, mdps_t, rdps_t = {}, {}, {}, {}, {}
        tanks, healers, dpss, mdpss, rdpss = 0, 0, 0, 0, 0
        guild_member = false
        ign = GetIgnoreList() or {} -- Get ignore list
        g_m = {}
        guild_members = {}
        if AutoBand.saved.guild_priority_enabled then -- Get guild list only if needed
            g_m = GetGuildMemberData() or {}
            for _, value in pairs(g_m) do
                if value and value.name then table.insert(guild_members, value.name) end
            end
        end
    end

    -- === Single Loop Player Processing ===
    wb_obj:foreach_player(
        function(gid, player)
            -- Ensure player.name exists before proceeding (safety)
            if not player or not player.name then return end
            local player_name = player.name -- Cache for pending_kicks key

            -- 1. Low Rank Check (Run if autokick_lowrnk_enabled)
            if AutoBand.saved.autokick_lowrnk_enabled then
                local required_rank = (player.role == AB_const.HEALER) and AutoBand.saved.min_rank_healer or AutoBand.saved.min_rank
                if (player.level < required_rank) then
                    -- Mark for kick, check done for this player regarding low level
                    pending_kicks[player_name] = "you are too low level for it (Rank " .. player.level .. " < " .. required_rank .. ")."
                end
            end

            -- 2. 8-8-8 Checks (Run if autokick_enabled)
            if AutoBand.saved.autokick_enabled then
                local kicked_for_ignore = false
                -- Ignore list check (only if not already marked for low level kick)
                if not pending_kicks[player_name] and ign then
                    for _, value in pairs(ign) do
                        if value and value.name then -- Ensure ignore entry is valid
                            local playerNameStripped = player_name:match(L"([^^]+)^?([^^]*)")
                            local ignoreNameStripped = value.name:match(L"([^^]+)^?([^^]*)")
                            if playerNameStripped and ignoreNameStripped and playerNameStripped == ignoreNameStripped then
                                pending_kicks[player_name] = "you are in my ignore list."
                                kicked_for_ignore = true
                                break -- Stop checking ignore list for this player
                            end
                        end
                    end
                end

                -- Role counting for 8-8-8 limits (only if not kicked for low level OR ignore)
                if not pending_kicks[player_name] then
                     -- Guild member check (for priority later)
                     guild_member = false
                     if AutoBand.saved.guild_priority_enabled then
                         for _, value in pairs(guild_members) do
                             local guildMemberNameStripped = value:match(L"([^^]+)^?([^^]*)")
                             if guildMemberNameStripped and player.name and guildMemberNameStripped == player.name then
                                 guild_member = true
                                 break
                             end
                         end
                     end

                    -- Populate role tables for 8-8-8 logic after loop
                    if (player.role == AB_const.TANK) then
                        tanks_t[player_name] = guild_member; tanks = tanks + 1
                    elseif (player.role == AB_const.HEALER) then
                        healers_t[player_name] = guild_member; healers = healers + 1
                    elseif (player.role == AB_const.MDPS) then
                        dps_t[player_name] = guild_member; mdps_t[player_name] = guild_member; dpss = dpss + 1; mdpss = mdpss + 1
                    elseif (player.role == AB_const.RDPS) then
                        dps_t[player_name] = guild_member; rdps_t[player_name] = guild_member; dpss = dpss + 1; rdpss = rdpss + 1
                    end
                end -- End role counting check
            end -- End 8-8-8 enabled checks for this player
        end -- End function for foreach_player
    ) -- End foreach_player call

    -- === Perform 8-8-8 Kicking Logic based on role limits (if enabled) ===
    if AutoBand.saved.autokick_enabled then
        -- Helper function to find and mark players for kick based on role limits (NO GOTO VERSION)
        local function mark_excess_roles(role_table, old_role_table, max_allowed, role_name_plural, current_count_ref)
            local current_count = current_count_ref[1]
            local players_to_kick_count = 0
            local kicked_count = 0 -- How many we mark in this function call

            if current_count > max_allowed then
                players_to_kick_count = current_count - max_allowed

                -- Create list of candidates: new players in this role not already marked for kick
                local candidates = {}
                for key, is_guildie in pairs(role_table) do
                    if not pending_kicks[key] then -- Only consider if not already marked for other reasons
                        local found_in_old = false
                        for key2, _ in pairs(old_role_table or {}) do
                            if key == key2 then found_in_old = true; break end
                        end
                        if not found_in_old then
                            table.insert(candidates, { name = key, is_guildie = is_guildie })
                        end
                    end
                end

                -- Sort candidates: Non-guildies first, then by name
                table.sort(candidates, function(a, b)
                    if a.is_guildie ~= b.is_guildie then
                        return not a.is_guildie -- false (non-guildie) comes before true (guildie)
                    else
                        return a.name < b.name -- Alphabetical tiebreaker
                    end
                end)

                -- Pre-calculate if any unmarked non-guildies are available (for priority check)
                local non_guildie_candidate_available = false
                if AutoBand.saved.guild_priority_enabled then
                    for _, candidate_check in ipairs(candidates) do
                        -- Check candidate table directly, pending_kicks check isn't needed again here
                        if not candidate_check.is_guildie then
                            non_guildie_candidate_available = true
                            break
                        end
                    end
                end

                -- Iterate through sorted candidates and mark for kick
                for _, candidate in ipairs(candidates) do
                    if kicked_count >= players_to_kick_count then break end -- Stop if we've marked enough

                    local kick_target = candidate.name
                    local should_mark_this_candidate = true -- Assume we kick unless priority logic prevents it

                    -- Apply Guild Priority Logic
                    if AutoBand.saved.guild_priority_enabled then
                        if candidate.is_guildie and non_guildie_candidate_available then
                            -- Current candidate is a guildie, AND an unmarked non-guildie exists *somewhere*
                            -- in the candidates list. Don't kick this guildie yet.
                            should_mark_this_candidate = false
                        end
                    end

                    -- Mark for kick if decided (and check pending_kicks again just in case)
                    if should_mark_this_candidate and not pending_kicks[kick_target] then
                        local kick_reason = "too many " .. role_name_plural .. " in it"
                        -- Add priority note only if kicking a non-guildie while guildies were candidates
                        if AutoBand.saved.guild_priority_enabled and not candidate.is_guildie then
                             local guildie_candidate_present = false
                             for _, other_cand in ipairs(candidates) do
                                 if other_cand.is_guildie then guildie_candidate_present = true; break end
                             end
                             if guildie_candidate_present then
                                kick_reason = kick_reason .. " (guild member priority)."
                             end
                        end

                        pending_kicks[kick_target] = kick_reason
                        kicked_count = kicked_count + 1
                    end
                end -- End loop through candidates
            end -- End if current_count > max_allowed

            -- Update the referenced count accurately based on how many were marked
            current_count_ref[1] = current_count - kicked_count

            -- Update the _old table with players *not* marked for kick
            local new_old_table = {}
            for k, v in pairs(role_table or {}) do -- Add 'or {}' for safety
                if not pending_kicks[k] then new_old_table[k] = v end
            end
            return new_old_table -- Return the updated _old table
        end -- end helper function mark_excess_roles


        -- Use the helper function (pass counts by reference using a table)
        tanks_t_old = mark_excess_roles(tanks_t, tanks_t_old, maxtanks, "tanks", {tanks})
        healers_t_old = mark_excess_roles(healers_t, healers_t_old, maxhealers, "healers", {healers})

        if AutoBand.saved.dps_weighting_enabled then
            mdps_t_old = mark_excess_roles(mdps_t, mdps_t_old, AutoBand.saved.max_mdps, "melee dps", {mdpss})
            rdps_t_old = mark_excess_roles(rdps_t, rdps_t_old, AutoBand.saved.max_rdps, "ranged dps", {rdpss})
            dps_t_old = {}
        else
            dps_t_old = mark_excess_roles(dps_t, dps_t_old, maxdps, "dps", {dpss})
            mdps_t_old = {}
            rdps_t_old = {}
        end
    else
        -- Clear _old tables if 8-8-8 is off to prevent stale data affecting next enable
        tanks_t_old, healers_t_old, dps_t_old, mdps_t_old, rdps_t_old = {}, {}, {}, {}, {}
    end -- End 8-8-8 role limit kicking

    -- === Enqueue all pending kicks ===
    for name, reason in pairs(pending_kicks) do
        AutoBand.enqueue_kick(name, reason)
    end

end -- End of function AutoBand.auto_kick

function add_role_to_message(needed, available, singular_name, plural_name, message_parts)
    plural_name = plural_name or singular_name .. "s"
    if needed > 0 and available > 0 then
        if available == 1 then
            table.insert(message_parts, singular_name)
        elseif available >= needed then
            if needed == 1 then
                table.insert(message_parts, singular_name)
            else
                table.insert(message_parts, needed .. " " .. plural_name)
            end
        else
            table.insert(message_parts, plural_name)
        end
    end
end

function add_role_to_message_old(needed, available, singular_name, plural_name, message_parts)
    plural_name = plural_name or singular_name .. "s"
	if needed > 0 and available > 0 then
		if available == 1 then
			table.insert(message_parts, singular_name)
		elseif available >= needed then
            table.insert(message_parts, needed .. " " .. (needed == 1 and singular_name or plural_name))
		else
			table.insert(message_parts, plural_name)
        end
    end
end

function AutoBand.auto_note()
    number2 = number2 + 1
    if (not AutoBand.saved.autonote_enabled or not AutoBand.has_permission() or AutoBand.debugon) then
        return
    end

    local wb_obj = AutoBand.get_wb()
    if not wb_obj then return end -- Silently exit if not in WB

    local tanks, healers, dpss, mdpss, rdpss = 0, 0, 0, 0, 0
    local total_players = 0

    wb_obj:foreach_player(
        function(gid, player)
            total_players = total_players + 1
            if (player.role == AB_const.TANK) then
                tanks = tanks + 1
            elseif (player.role == AB_const.HEALER) then
                healers = healers + 1
            elseif (player.role == AB_const.MDPS) then
                dpss = dpss + 1
                mdpss = mdpss + 1
            elseif (player.role == AB_const.RDPS) then
                dpss = dpss + 1
                rdpss = rdpss + 1
            end
        end
    )

    -- Calculate needs
    local neededTank   = math.max(0, maxtanks - tanks)
    local neededHealer = math.max(0, maxhealers - healers)
    local neededMdps = 0
    local neededRdps = 0
    local neededDps = 0
    local available_spots = math.max(0, 24 - total_players)
	local total_needed_spots

    if AutoBand.saved.autokick_enabled and AutoBand.saved.dps_weighting_enabled then
        neededMdps = math.max(0, AutoBand.saved.max_mdps - mdpss)
        neededRdps = math.max(0, AutoBand.saved.max_rdps - rdpss)
		total_needed_spots = neededTank + neededHealer + neededMdps + neededRdps
    else
        neededDps = math.max(0, maxdps - dpss)
        total_needed_spots = neededTank + neededHealer + neededDps
    end

    -- Build the message dynamically
    local message_parts = {}

    add_role_to_message(neededTank, available_spots, AB_const.ICONS.tank .. " tank", nil, message_parts)
    add_role_to_message(neededHealer, available_spots, AB_const.ICONS.healer .. " healer", nil, message_parts)

    if AutoBand.saved.autokick_enabled and AutoBand.saved.dps_weighting_enabled then
        add_role_to_message(neededMdps, available_spots, AB_const.ICONS.mdps .. " mdps", AB_const.ICONS.mdps .. " mdps", message_parts)
        add_role_to_message(neededRdps, available_spots, AB_const.ICONS.rdps .. " rdps", AB_const.ICONS.rdps .. " rdps", message_parts)
    else
        add_role_to_message(neededDps, available_spots, AB_const.ICONS.dps .. " dps", AB_const.ICONS.dps .. " dps", message_parts)
    end
	
    -- Only proceed if roles are needed AND there are spots available
    if #message_parts > 0 and available_spots > 0 then
        if number2 > 60 then -- every 5 min (original logic: 12 * 5 seconds)
			local prefixicon = AB_const.ICONS["prefix"] or ""
			local suffixicon = AB_const.ICONS["suffix"] or ""
		    local separator
            if available_spots == 1 and #message_parts > 1 then
                separator = " or "
            else
                separator = " / "
            end
            -- *** Construct the message PAYLOAD first, without the prefix ***
            local message_payload = "Warband needs - " .. table.concat(message_parts, separator)

            -- Add available spots info if we couldn't advertise the exact numbers needed
			if total_needed_spots > available_spots then
                message_payload = message_payload .. " - (" .. available_spots .. " spot" .. (available_spots == 1 and "" or "s") .. " available) -"
            else
                message_payload = message_payload .. " - "
            end

            -- Append Rank Info
            if AutoBand.saved.min_rank_healer ~= AutoBand.saved.min_rank then
                message_payload = message_payload .. " Min rank healers: "
                                    .. AutoBand.saved.min_rank_healer
                                    .. "+, others: "
                                    .. AutoBand.saved.min_rank
                                    .. "+"
            else
                message_payload = message_payload .. " Min rank: "
                                    .. AutoBand.saved.min_rank
                                    .. "+"
            end

            -- *** Enqueue the command with the RAW formatted prefix ***
            AutoBand.enqueue_command("/1 " .. prefixicon .. AB_const.FORMATTED_PREFIX_RAW_WSPACE .. message_payload .. suffixicon )
            number2 = 0
        end
    end
end

function AutoBand.cmd_search_roles(args)
    local wb_obj = AutoBand.get_wb()
    if not wb_obj or wb_obj.player_count == 0 then
         AB_util.print("[Error] Not currently in an active warband.")
         return
    end

    -- Determine if the current player IS the leader
    local is_current_player_leader = AutoBand.has_permission()

    local actual_leader_name_str = nil
    local leader_name_found = false
    local leader_is_player_self = false

    -- Try PartyUtils first
    local success_pu, leaderInfo = pcall(PartyUtils.GetWarbandLeader)
    if success_pu and leaderInfo and leaderInfo.name then
        local leader_name_raw = leaderInfo.name
        actual_leader_name_str = tostring(AutoBand.FixString(leader_name_raw)) -- Cleaned name
        if leader_name_raw == GameData.Player.name then
             leader_is_player_self = true
        end
        leader_name_found = true
    end

    -- Fallback if PartyUtils failed or leader is self
    if not leader_name_found then
        wb_obj:foreach_player(function(gid, player)
            if player.isGroupLeader then
                actual_leader_name_str = tostring(AutoBand.FixString(player.name))
                if player.name == GameData.Player.name then
                     leader_is_player_self = true
                end
                leader_name_found = true
                return -- Simulate exiting loop once found
            end
        end)
    end

    -- Final check if leader name was determined
    if not leader_name_found or not actual_leader_name_str or actual_leader_name_str == "" then
         AB_util.print("[Error] Could not determine the warband leader's name to generate the message.")
         return
    end

    -- *** Calculate Current Roles ***
    local tanks, healers, dpss, mdpss, rdpss = 0, 0, 0, 0, 0
    local total_players = 0
    wb_obj:foreach_player(function(gid, player)
        total_players = total_players + 1
        -- Role counting based on player.role determined by load_from_wbdata/scdata
        if (player.role == AB_const.TANK) then tanks = tanks + 1
        elseif (player.role == AB_const.HEALER) then healers = healers + 1
        elseif (player.role == AB_const.MDPS) then dpss = dpss + 1; mdpss = mdpss + 1
        elseif (player.role == AB_const.RDPS) then dpss = dpss + 1; rdpss = rdpss + 1
        end
    end)
    -- *** End Role Calculation ***

    -- *** Get Player Zone Info ***
    local players_by_zid = AutoBand.get_players_zone(wb_obj)
    local leader_zone_name_str = "Unknown Zone/Offline" -- Default/fallback
    if players_by_zid and players_by_zid["valid_as"] then
        local found_leader_zone = false
        for zoneNum, as_zone in pairs(players_by_zid["valid_as"]) do
            if found_leader_zone then break end
            for _, player in ipairs(as_zone) do
                if player.isGroupLeader then
                    if zoneNum and zoneNum ~= 0 then
                        local success_zn, zoneNameResult = pcall(GetZoneName, zoneNum)
                        if success_zn and zoneNameResult and zoneNameResult ~= L"" then
                             leader_zone_name_str = tostring(zoneNameResult)
                        else
                             leader_zone_name_str = "Unknown Zone (" .. tostring(zoneNum) .. ")"
                        end
                    else
                         leader_zone_name_str = "Offline"
                    end
                    found_leader_zone = true
                    break
                end
            end
        end
         if not found_leader_zone then
            AB_util.print("[Warning] Could not determine leader's zone precisely.")
         end
    else
         AB_util.print("[Warning] Could not get zone data structure.")
    end
    -- *** End Zone Info ***

    -- *** Calculate Needs ***
    local neededTank   = math.max(0, maxtanks - tanks)
    local neededHealer = math.max(0, maxhealers - healers)
    local neededMdps = 0
    local neededRdps = 0
    local neededDps = 0
    local available_spots = math.max(0, 24 - total_players)
	local total_needed_spots
    if AutoBand.saved.autokick_enabled and AutoBand.saved.dps_weighting_enabled then
        neededMdps = math.max(0, AutoBand.saved.max_mdps - mdpss)
        neededRdps = math.max(0, AutoBand.saved.max_rdps - rdpss)
        total_needed_spots = neededTank + neededHealer + neededMdps + neededRdps
    else
        neededDps = math.max(0, maxdps - dpss)
		total_needed_spots = neededTank + neededHealer + neededDps
    end
    -- *** End Needs Calculation ***

    -- *** Build Role Message Parts ***
    local message_parts = {}
    add_role_to_message(neededTank, available_spots, AB_const.ICONS.tank .. " tank", nil, message_parts)
    add_role_to_message(neededHealer, available_spots, AB_const.ICONS.healer .. " healer", nil, message_parts)
	if is_current_player_leader and AutoBand.saved.autokick_enabled and AutoBand.saved.dps_weighting_enabled then
        add_role_to_message(neededMdps, available_spots, AB_const.ICONS.mdps .. " mdps", AB_const.ICONS.mdps .. " mdps", message_parts)
        add_role_to_message(neededRdps, available_spots, AB_const.ICONS.rdps .. " rdps", AB_const.ICONS.rdps .. " rdps", message_parts)
    else
        add_role_to_message(neededDps, available_spots, AB_const.ICONS.dps .. " dps", AB_const.ICONS.dps .. " dps", message_parts)
    end
    -- *** End Role Message Parts ***

    -- Only proceed if roles are needed AND there are spots available
    if #message_parts > 0 and available_spots > 0 then
        -- *** Determine Channels ***
        local channels_to_send = {}
        local sent_channels_feedback = {}
        local valid_channel_arg_found = false
        local valid_channels = {["1"]=true, ["t4"]=true, ["5"]=true}
        for _, channel_arg in ipairs(args) do
            local channel = channel_arg:lower():gsub("/", "") -- Ensure lowercase and no slash
            if valid_channels[channel] then
                channels_to_send["/" .. channel] = true -- Store with leading slash
                valid_channel_arg_found = true
            end
        end
        if not valid_channel_arg_found then
            AB_util.print("Usage: /ab searchroles [1] [t4] [5]")
            AB_util.print("Please specify at least one channel (/1, /t4, /5) to send the search message.")
            return
        end
        -- *** End Channel Determination ***

        -- *** Conditional Message Construction ***
        local message_start = ""
		local display_text_base = ""
        local rank_info_string = ""
        local addon_chat_prefix = ""
		local join_message_suffix = ""
        local colored_leader_mention_str = ""
		local prefixicon = AB_const.ICONS["prefix"] or ""
		local suffixicon = AB_const.ICONS["suffix"] or ""

        if is_current_player_leader then
            -- LEADER running the command: Standard message format
            message_start = "Warband needs - "
            addon_chat_prefix = prefixicon .. AB_const.FORMATTED_PREFIX_RAW_WSPACE -- Addon prefix + space

            -- Add Rank Info
            if AutoBand.saved.min_rank_healer ~= AutoBand.saved.min_rank then
                rank_info_string = " - Min rank healers: " .. AutoBand.saved.min_rank_healer .. "+, others: " .. AutoBand.saved.min_rank .. "+"
            else
                rank_info_string = " - Min rank: " .. AutoBand.saved.min_rank .. "+"
            end
        else
            -- NON-LEADER running the command: Use CreateHyperLink for leader name
            local r, g, b = AB_const.COLOR_WBLEAD[1], AB_const.COLOR_WBLEAD[2], AB_const.COLOR_WBLEAD[3]
			local display_text_base = "@" .. actual_leader_name_str
			local colored_leader_mention_str = string.format("<LINK data=\"0\" color=\"%d,%d,%d\" text=\"%s\">", r, g, b, display_text_base)
            message_start = prefixicon .. colored_leader_mention_str .. " warband needs - "
            join_message_suffix = " - Please msg/join " .. colored_leader_mention_str
            rank_info_string = "" -- NO rank info
            addon_chat_prefix = "" -- NO addon prefix
        end

        -- Determine separator for roles list
        local separator
        if available_spots == 1 and #message_parts > 1 then
            separator = " or "
        else
            separator = " / "
        end

        -- Construct the base message payload (common part after prefix)
        local message_base_payload = message_start .. table.concat(message_parts, separator)

        -- Add available spots info if needed
        if total_needed_spots > available_spots then
             message_base_payload = message_base_payload .. " - (" .. available_spots .. " spot" .. (available_spots == 1 and "" or "s") .. " available)"
        end

        -- Create final channel-specific message PAYLOADS (includes conditional rank_info_string)
        local message_t4_t5_payload = message_base_payload .. " - in - " .. leader_zone_name_str .. rank_info_string .. join_message_suffix
        local message_1_payload = message_base_payload .. rank_info_string .. join_message_suffix
        -- *** End Conditional Message Construction ***

        -- *** Enqueue Sending Loop (Modified Prefix) ***
        for channel, _ in pairs(channels_to_send) do
            local message_to_send_payload
            local target_channel = channel -- Keep original requested channel

            -- Choose the correct message PAYLOAD based on the channel
            if target_channel == "/t4" or target_channel == "/5" then
                message_to_send_payload = message_t4_t5_payload
            else -- Assume /1 or others get the simpler format
                message_to_send_payload = message_1_payload
            end

            -- <<<<< TEMPORARY DEBUG CHANGE >>>>> --
             -- Uncomment the next lines to redirect /t4 messages to /o for testing

             -- if target_channel == "/t4" then
             --     target_channel = "/o" -- Reroute /t4 to /o for debug
             --     AB_util.print("[DEBUG] Rerouting /t4 message to /o")
             -- end

            -- <<<<< END TEMPORARY DEBUG CHANGE >>>>>

            -- Enqueue with the CONDITIONAL addon chat prefix and suffix icon
            AutoBand.enqueue_command(target_channel .. " " .. addon_chat_prefix .. message_to_send_payload .. suffixicon )
            table.insert(sent_channels_feedback, target_channel) -- Add the *original* requested channel to feedback
        end

        -- Sort feedback for consistent output
        table.sort(sent_channels_feedback)
        AB_util.print("Search sent in " .. table.concat(sent_channels_feedback, ", ") .. ".")

    else
        AB_util.print("Warband is full or no roles needed.")
    end
end

-- return a list of players who do not meet rank requirements
function AutoBand.get_low_rank(wb_obj)
    if (not wb_obj) then
        wb_obj = AutoBand.get_wb()
    end
    local list = {}
    wb_obj:foreach_player(
        function(gid, player)
            local needed = (player.role == "healer") and AutoBand.saved.min_rank_healer or AutoBand.saved.min_rank
            if (player.level < needed) then
                table.insert(list, player)
            end
        end
    )
    return list
end

function AutoBand.wb(args)
    wb_obj = AutoBand.get_wb()
    local tanks, healers, dpss, mdps, rdps, w_wh = 0, 0, 0, 0, 0, 0
    local ii = 0
    local guildmem = {}
    local guild_members = {}

    local g_m = GetGuildMemberData()
    for key, value in pairs(g_m) do
        table.insert(guild_members, value.name)
    end

    wb_obj:foreach_player(
        function(gid, player)
            if (player.role == "tank") then
                tanks = tanks + 1
            elseif (player.role == "healer") then
                healers = healers + 1
            elseif (player.role == "mdps") then
                mdps = mdps + 1
                dpss = dpss + 1
            elseif (player.role == "rdps") then
                rdps = rdps + 1
                dpss = dpss + 1
            end

            if (player.careerLine == GameData.CareerLine.WITCH_ELF or player.careerLine == GameData.CareerLine.WITCH_HUNTER) then
                w_wh = w_wh + 1
            end

            for key, value in pairs(guild_members) do
                if value:match(L"([^^]+)^?([^^]*)") == player.name then
                    ii = ii + 1
                    table.insert(guildmem, player.name)
                    break
                end
            end
        end
    )

    AB_util.print("Tanks in WB: " .. tanks)
    AB_util.print("Healers in WB: " .. healers)
    -- AB_util.print("MDPS in WB: " .. mdps)
    -- AB_util.print("RDPS in WB: " .. rdps)
    AB_util.print("DPSs in WB: " .. dpss .. " - " .. mdps .." MDPS, " .. rdps .. " RDPS.")
    -- AB_util.print("Stealthers in WB: " .. w_wh)
    AB_util.print("Guild members (including you) in WB: " .. ii)
    for key, value in pairs(guildmem) do
        AB_util.print(tostring(value))
    end
end

function AutoBand.get_players_zone(wb_obj)
    local zids = { ["valid_as"] = {}, ["valid_p"] = {} }
    local leader_zone = nil

    wb_obj:foreach_player(
        function(gid, player)
            if (player.isGroupLeader or player.isAssistant) then
                if (zids["valid_as"][player.zoneNum] == nil) then
                    zids["valid_as"][player.zoneNum] = {}
                end
                if (player.isGroupLeader) then
                    leader_zone = player.zoneNum
                    table.insert(zids["valid_as"][player.zoneNum], 1, player)
                else
                    table.insert(zids["valid_as"][player.zoneNum], player)
                end
            end
        end
    )

    if (leader_zone) then
        zids["other"] = {}
        wb_obj:foreach_player(
            function(gid, player)
                if (zids["valid_as"][player.zoneNum]) then
                    if (zids["valid_p"][player.zoneNum] == nil) then
                        zids["valid_p"][player.zoneNum] = {}
                    end
                    table.insert(zids["valid_p"][player.zoneNum], player)
                else
                    if (zids["other"][player.zoneNum] == nil) then
                        zids["other"][player.zoneNum] = {}
                    end
                    table.insert(zids["other"][player.zoneNum], player)
                end
            end
        )
    else
        AB_util.print("[ERROR] Leader cannot be found, the warband is BUGGED, reform a warband")
    end
    return zids
end

function AutoBand.get_fakewb(template)
    local wb = AB_wb:new()
    wb:set_groups()
    local num_players = 1
    for gid, tgroup in ipairs(template) do
        for j, tplayer in ipairs(tgroup) do
            wb:add_to_gid(tplayer.role, num_players, gid)
            num_players = num_players + 1
        end
    end
    wb:recalc_counters()
    wb:print()
    return wb
end

function AutoBand.FixString(str)
    if (str == nil) then
        return nil
    end
    local pos = str:find(L"^", 1, true)
    if (pos) then
        str = str:sub(1, pos - 1)
    end
    return str
end

function AutoBand.cmd_end(args)
    local wb_obj = AutoBand.get_wb()
    wb_obj:foreach_player(
        function(gid, player)
            AutoBand.enqueue_kick(player.name, "it ended, see you next time!")
        end
    )
end