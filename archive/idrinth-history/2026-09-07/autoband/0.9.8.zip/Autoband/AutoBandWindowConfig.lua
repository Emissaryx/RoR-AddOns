--
AutoBandWindowConfig = {}

AutoBandWindowConfig.name = "AutoBandWindowConfigTab"
AutoBandWindowConfig.combobox_name = AutoBandWindowConfig.name .. "ComboBox"


function AutoBandWindowConfig.Initialize()
	-- Settings: Templates
	LabelSetText(AutoBandWindowConfig.name .. "DefaultLabel", L"Default Template")
	ButtonSetText(AutoBandWindowConfig.name .. "ClearTemplateButton", L"Reset")

	AutoBandWindowConfig.refresh_default_template() 	

	LabelSetText(AutoBandWindowConfig.name .. "ComboBoxLabel", L"Distribution Algorithm:")
	AutoBandWindowConfig.init_combobox()
	AutoBandWindowConfig.refresh_combobox()

	-- Settings: Auto Kick Offliners 
	LabelSetText(AutoBandWindowConfig.name .. "AutoKickLabel", L"Auto form 8-8-8 wb")
	ButtonSetCheckButtonFlag(AutoBandWindowConfig.name .. "KickCheckBox", true)
	
	LabelSetText(AutoBandWindowConfig.name .. "AutoKickToofarLabel", L"Auto Kick too far players")
	ButtonSetCheckButtonFlag(AutoBandWindowConfig.name .. "KickToofarCheckBox", true)

	-- Guild priority
	LabelSetText(AutoBandWindowConfig.name .. "GuildPriorityLabel", L"Guild priority")
	ButtonSetCheckButtonFlag(AutoBandWindowConfig.name .. "GuildPriorityCheckBox", true)
	
	LabelSetText(AutoBandWindowConfig.name .. "KickTimeLabel", L"Timeout for kick too far players (min)") -- (min)")
	AutoBandWindowConfig.refresh_kickoff()	

	-- Settings: Rank requirement
	LabelSetText(AutoBandWindowConfig.name .. "RankReqLabel", L"Rank Requirement")
--	LabelSetText(AutoBandWindowConfig.name .. "MinRankLabel", L"Minimum")

	-- Settings: Healer Rank requirement
	LabelSetText(AutoBandWindowConfig.name .. "HealerRankReqLabel", L"Healer Rankreq")

	-- Alt Check
	LabelSetText(AutoBandWindowConfig.name .. "AltCheckLabel", L"Alt-Spec check")
	ButtonSetCheckButtonFlag(AutoBandWindowConfig.name .. "AltCheckCheckBox", true)

	-- Minimap icon
	LabelSetText(AutoBandWindowConfig.name .. "MapIconLabel", L"Minimap icon")
	ButtonSetCheckButtonFlag(AutoBandWindowConfig.name .. "MapIconCheckBox", true)
--	ButtonSetPressedFlag(AutoBandWindowConfig.name .. "MapIconCheckBox", AutoBand.saved.displayicon)

	AutoBandWindowConfig.refresh_min_rank()	
	AutoBandWindowConfig.refresh_min_rank_healer()	
	
	LabelSetText(AutoBandWindowConfig.name .. "VersionLabel", L"v" .. towstring(AB_const.VERSION))

	-- Button bar
	ButtonSetText(AutoBandWindowConfig.name .. "ResetButton", L"Restore Defaults")
	WindowSetShowing(AutoBandWindowConfig.name .. "DisplaySeperator1", false) 
	WindowSetShowing(AutoBandWindowConfig.name .. "DisplaySeperator2", true) 
	WindowSetShowing(AutoBandWindowConfig.name .. "DisplaySeperator3", false) 
end

function AutoBandWindowConfig.refresh_default_template()
	local clear_default = true
	local default_template = AB_const.EMPTY_TEMPLATE

	if (AutoBand.saved.default_template ~= AB_const.EMPTY_TEMPLATE) then
		clear_default = false
		default_template = AutoBand.saved.default_template
		AB_util.debug("Default is not set to automatic: " .. default_template)
	end

	LabelSetText(AutoBandWindowConfig.name .. "DefaultTemplateLabel", towstring(default_template))	
	ButtonSetDisabledFlag(AutoBandWindowConfig.name .. "ClearTemplateButton", clear_default)
end


function AutoBandWindowConfig.init_combobox()
	-- reloadui combobox
	AutoBandWindowConfig.combo_items = {}
	ComboBoxClearMenuItems(AutoBandWindowConfig.combobox_name)
	-- add from templates
	for mid, mode in pairs(AB_const.ALGO_MODE) do
		ComboBoxAddMenuItem(AutoBandWindowConfig.combobox_name, towstring("(" .. mid .. ") " .. mode))
		table.insert(AutoBandWindowConfig.combo_items, "(" .. mid .. ") " .. mode)
	end
end

function AutoBandWindowConfig.refresh_combobox()
	ComboBoxSetSelectedMenuItem(AutoBandWindowConfig.combobox_name, AutoBand.saved.org_algo_mode)
end

-- return selected text
function AutoBandWindowConfig.selected_combobox()
	return tostring(ComboBoxGetSelectedText(AutoBandWindowConfig.combobox_name))
end

-- load selected algorithm
function AutoBandWindowConfig.OnSelChangedComboBox()
	local name = AutoBandWindowConfig.selected_combobox()
	local index = nil
	for i, v in ipairs(AutoBandWindowConfig.combo_items) do
		if (v == name) then
			index = i
			break
		end
	end
	if (index) then
		AutoBand.saved.org_algo_mode = index
		ComboBoxSetSelectedMenuItem(AutoBandWindowConfig.combobox_name, AutoBand.saved.org_algo_mode)
		AB_util.debug(AutoBand.saved.org_algo_mode)
	end
end

function AutoBandWindowConfig.Hide()
	WindowSetShowing(AutoBandWindowConfig.name, false)
end

function AutoBandWindowConfig.Show()
	AutoBandWindowConfig.refresh_kickoff()
	AutoBandWindowConfig.refresh_default_template()
	AutoBandWindowConfig.refresh_combobox()
	AutoBandWindowConfig.refresh_min_rank()
	AutoBandWindowConfig.refresh_min_rank_healer()
	ButtonSetPressedFlag(AutoBandWindowConfig.name .. "MapIconCheckBox", AutoBand.saved.displayicon)
	ButtonSetPressedFlag(AutoBandWindowConfig.name .. "GuildPriorityCheckBox", AutoBand.saved.guild_priority_enabled)
    ButtonSetPressedFlag(AutoBandWindowConfig.name .. "AltCheckCheckBox", AutoBand.saved.alt_speccheck_enabled)
	AutoBandWindow.toggle_mapicon(AutoBand.saved.displayicon)
	WindowSetShowing(AutoBandWindowConfig.name, true)
end

function AutoBandWindowConfig.OnClearTemplateButton()
	if (ButtonGetDisabledFlag(AutoBandWindowConfig.name .. "ClearTemplateButton")) then
		return
	end
	AutoBand.saved.default_template = AB_const.EMPTY_TEMPLATE
	AutoBandWindowConfig.refresh_default_template()
end

function AutoBandWindowConfig.OnPressTimeMinusButton()
	AutoBand.saved.autokick_period = AutoBand.saved.autokick_period - 1
	if (AutoBand.saved.autokick_period < 0) then
		AutoBand.saved.autokick_period = AB_const.MAX_KICKOFF_TIME
	end
	LabelSetText(AutoBandWindowConfig.name .. "AutoKickTimeoutLabel", L"" .. AutoBand.saved.autokick_period)
	if AutoBand.has_permission() then
		--AutoBand.enqueue_command("/wb [AutoBand] Timeout for auto kick players who are far away from leader now " .. AutoBand.saved.autokick_period .. "min")
	end
end

function AutoBandWindowConfig.OnPressTimePlusButton()
	AutoBand.saved.autokick_period = AutoBand.saved.autokick_period + 1
	if (AutoBand.saved.autokick_period > AB_const.MAX_KICKOFF_TIME) then
		AutoBand.saved.autokick_period = 0
	end
	LabelSetText(AutoBandWindowConfig.name .. "AutoKickTimeoutLabel", L"" .. AutoBand.saved.autokick_period)
	if AutoBand.has_permission() then
		--AutoBand.enqueue_command("/wb [AutoBand] Timeout for auto kick players who are far away from leader now " .. AutoBand.saved.autokick_period .. "min")
	end

end


function AutoBandWindowConfig.OnPressRankMinusButton()
    AutoBand.saved.min_rank = AutoBand.saved.min_rank - 1
    if (AutoBand.saved.min_rank < 1) then
        AutoBand.saved.min_rank = AB_const.MAXIMUM_RANK
    end
    -- Ensure healer rank <= default rank
    if (AutoBand.saved.min_rank_healer > AutoBand.saved.min_rank) then
        AutoBand.saved.min_rank_healer = AutoBand.saved.min_rank
    end
    LabelSetText(AutoBandWindowConfig.name .. "MinRankValueLabel", L"" .. AutoBand.saved.min_rank)
    LabelSetText(AutoBandWindowConfig.name .. "MinHealerRankValueLabel", L"" .. AutoBand.saved.min_rank_healer)
end

function AutoBandWindowConfig.OnPressRankPlusButton()
    AutoBand.saved.min_rank = AutoBand.saved.min_rank + 1
    if (AutoBand.saved.min_rank > AB_const.MAXIMUM_RANK ) then
        AutoBand.saved.min_rank = 1
    end
    -- Ensure healer rank <= default rank
    if (AutoBand.saved.min_rank_healer > AutoBand.saved.min_rank) then
        AutoBand.saved.min_rank_healer = AutoBand.saved.min_rank
    end
    LabelSetText(AutoBandWindowConfig.name .. "MinRankValueLabel", L"" .. AutoBand.saved.min_rank)
    LabelSetText(AutoBandWindowConfig.name .. "MinHealerRankValueLabel", L"" .. AutoBand.saved.min_rank_healer)
end

function AutoBandWindowConfig.OnPressHealerRankMinusButton()
    AutoBand.saved.min_rank_healer = AutoBand.saved.min_rank_healer - 1
    if (AutoBand.saved.min_rank_healer < 1) then
        AutoBand.saved.min_rank_healer = AB_const.MAXIMUM_RANK
    end
    -- Ensure healer rank <= default rank
    if (AutoBand.saved.min_rank_healer > AutoBand.saved.min_rank) then
        AutoBand.saved.min_rank_healer = AutoBand.saved.min_rank
    end
    LabelSetText(AutoBandWindowConfig.name .. "MinHealerRankValueLabel", L"" .. AutoBand.saved.min_rank_healer)
end

function AutoBandWindowConfig.OnPressHealerRankPlusButton()
    AutoBand.saved.min_rank_healer = AutoBand.saved.min_rank_healer + 1
    if (AutoBand.saved.min_rank_healer > AB_const.MAXIMUM_RANK ) then
        AutoBand.saved.min_rank_healer = 1
    end
    -- Ensure healer rank <= default rank
    if (AutoBand.saved.min_rank_healer > AutoBand.saved.min_rank) then
        AutoBand.saved.min_rank_healer = AutoBand.saved.min_rank
    end
    LabelSetText(AutoBandWindowConfig.name .. "MinHealerRankValueLabel", L"" .. AutoBand.saved.min_rank_healer)
end

function AutoBandWindowConfig.refresh_kickoff() 
	LabelSetText(AutoBandWindowConfig.name .. "AutoKickTimeoutLabel", L"" .. AutoBand.saved.autokick_period)
	ButtonSetPressedFlag(AutoBandWindowConfig.name .. "KickCheckBox", AutoBand.saved.autokick_enabled)
end


function AutoBandWindowConfig.refresh_min_rank() 
	LabelSetText(AutoBandWindowConfig.name .. "MinRankValueLabel", L"" .. AutoBand.saved.min_rank)
end

function AutoBandWindowConfig.refresh_min_rank_healer() 
	LabelSetText(AutoBandWindowConfig.name .. "MinHealerRankValueLabel", L"" .. AutoBand.saved.min_rank_healer)
end


function AutoBandWindowConfig.OnKickCheckBox()
	AutoBand.saved.autokick_enabled = ButtonGetPressedFlag(AutoBandWindowConfig.name .. "KickCheckBox")
--[[	if AutoBand.has_permission() then
		if AutoBand.saved.autokick_enabled then
			AutoBand.enqueue_command("/wb [AutoBand] Auto forming 8-8-8 wb ENABLED!")
		else
			AutoBand.enqueue_command("/wb [AutoBand] Auto forming 8-8-8 wb DISABLED!")
		end
	end]]--
	AB_util.print("Auto kick to form 8-8-8 wb: " .. tostring(AutoBand.saved.autokick_enabled))
end

function AutoBandWindowConfig.OnKickToofarCheckBox()
	AutoBand.saved.autokick_toofar_enabled = ButtonGetPressedFlag(AutoBandWindowConfig.name .. "KickToofarCheckBox")
	if AutoBand.has_permission() then
		if AutoBand.saved.autokick_toofar_enabled then
			AutoBand.enqueue_command("/wb [AutoBand] Auto kick players who are far away from leader ENABLED! Follow the leader PLZ")
		else
			AutoBand.enqueue_command("/wb [AutoBand] Auto kick players who are far away from leader DISABLED!")
			warned = {}
		end
	end

	AB_util.print("Auto kick too far players: " .. tostring(AutoBand.saved.autokick_toofar_enabled))
end

function AutoBandWindowConfig.OnResetConfig()
	AutoBand.saved.autokick_enabled = AB_const.AUTOKICK
	AutoBand.saved.autokick_period = AB_const.KICK_PERIOD
    AutoBand.saved.autokick_toofar_enabled = AB_const.AUTOKICKTOOFAR
    AutoBand.saved.guild_priority_enabled  = AB_const.GUILDPRIORITY  	
	AutoBand.saved.default_template = AB_const.EMPTY_TEMPLATE
	AutoBand.saved.org_algo_mode = AB_const.DEFAULT_ORG_ALGO
	AutoBand.saved.min_rank = AB_const.MINIMUM_RANK
	AutoBand.saved.min_rank_healer = AB_const.MINIMUM_RANK_HEALER
	AutoBand.saved.displayicon = AutoBand.saved.displayicon
	AutoBand.saved.alt_speccheck_enabled = AB_const.ALTCHECK
	AutoBand.saved.guild_priority_enabled = AutoBand.saved.guild_priority_enabled
	AutoBandWindowConfig.Show()
end

function AutoBandWindowConfig.OnAltCheckCheckBox()
	AutoBand.saved.alt_speccheck_enabled = ButtonGetPressedFlag(AutoBandWindowConfig.name .. "AltCheckCheckBox")
	AB_util.print("Use alt spec check: " .. tostring(AutoBand.saved.alt_speccheck_enabled))
end

function AutoBandWindowConfig.OnMapIconCheckBox()
	AutoBandWindow.toggle_mapicon(ButtonGetPressedFlag(AutoBandWindowConfig.name .. "MapIconCheckBox"))
end

function AutoBandWindowConfig.OnGuildPriorityCheckBox()
	AutoBand.saved.guild_priority_enabled = ButtonGetPressedFlag(AutoBandWindowConfig.name .. "GuildPriorityCheckBox")
	AB_util.print("Guild priority for auto-kick: " .. tostring(AutoBand.saved.guild_priority_enabled))
end