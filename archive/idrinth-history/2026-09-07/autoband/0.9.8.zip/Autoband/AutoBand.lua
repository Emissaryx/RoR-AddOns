-- AutoBand.lua

AutoBand = {}
tanks_t_old = {}
healers_t_old = {}
dps_t_old = {}
roles_last = {}
toofar = {}
toofar_old = {}
toofar_not_changed = {}
warned = {}
number = 0
number2 = 12
g_m = {}
ign = {}
guild_members = {}
maxtanks = 8
maxhealers = 8
maxdps = 8

local MAX_MAP_POINTS = 511
local DISTANCE_FIX_COEFFICIENT = 1 / 1.06
local MapPointTypeFilter = {
    [SystemData.MapPips.PLAYER] = true,
    [SystemData.MapPips.GROUP_MEMBER] = true,
    [SystemData.MapPips.WARBAND_MEMBER] = true,
    [SystemData.MapPips.DESTRUCTION_ARMY] = true,
    [SystemData.MapPips.ORDER_ARMY] = true
}

function AutoBand.init()
    --------------------------------------------------------------------------
    -- 1) MODULE VARIABLES
    --------------------------------------------------------------------------
    AutoBand.cmd_queue				= {}
    AutoBand.cmd_current			= nil
    AutoBand.debugon				= false
    AutoBand.gizilon				= false
    AutoBand.offliners_countdown	= {}
    AutoBand.has_shortslash			= false
    AutoBand.elapsed				= 0

    --------------------------------------------------------------------------
    -- 2) PERSISTENT SETTINGS
    --------------------------------------------------------------------------
    -- A) CORE "SAVED" TABLE & CUSTOM ROLES
    AutoBand.saved					= AutoBand.saved or {}
    AutoBand.saved.custom_roles		= AutoBand.saved.custom_roles or {}

    -- B) CORE TOGGLES
    AutoBand.saved.autokick_enabled			= (AutoBand.saved.autokick_enabled == nil)       	and AB_const.AUTOKICK       or AutoBand.saved.autokick_enabled
    AutoBand.saved.autokick_toofar_enabled	= (AutoBand.saved.autokick_toofar_enabled == nil)	and AB_const.AUTOKICKTOOFAR or AutoBand.saved.autokick_toofar_enabled
    AutoBand.saved.autonote_enabled			= (AutoBand.saved.autonote_enabled == nil)       	and AB_const.AUTONOTE       or AutoBand.saved.autonote_enabled
	AutoBand.saved.notify_buffs_enabled 	= (AutoBand.saved.notify_buffs_enabled == nil) 		and true 					or AutoBand.saved.notify_buffs_enabled

    -- C) KICK TIMERS & RANK RULES
    AutoBand.saved.autokick_period			= AutoBand.saved.autokick_period or AB_const.KICK_PERIOD
    AutoBand.saved.min_rank					= AutoBand.saved.min_rank        or AB_const.MINIMUM_RANK
    AutoBand.saved.min_rank_healer			= AutoBand.saved.min_rank_healer or AB_const.MINIMUM_RANK_HEALER

    -- D) TEMPLATES & ORGANIZATION ALGORITHM
    AutoBand.saved.default_template			= AutoBand.saved.default_template or AB_const.EMPTY_TEMPLATE
    AutoBand.saved.templates				= AutoBand.saved.templates        or {}
    AutoBand.saved.org_algo_mode			= AutoBand.saved.org_algo_mode    or AB_const.DEFAULT_ORG_ALGO
    AutoBand.saved.org_algo_role			= AutoBand.saved.org_algo_role    or AB_const.DEFAULT_ORG_ROLE

    -- E) ICON & GUILD PRIORITY
    AutoBand.saved.displayicon				= (AutoBand.saved.displayicon == nil) and true or AutoBand.saved.displayicon
    AutoBand.saved.guild_priority_enabled	= (AutoBand.saved.guild_priority_enabled == nil)
												and AB_const.GUILDPRIORITY
												or AutoBand.saved.guild_priority_enabled

    -- F) KICK FUNCTION SPECIFICS
    if (AutoBand.saved.kick_func_enabled == nil) then
        AutoBand.saved.kick_func_enabled = {}
        for k, v in pairs(AB_const.KICK_FUNC_DEFAULT) do
            AutoBand.saved.kick_func_enabled[k] = v
        end
    end

    -- G) ALT SPEC CHECK & ROLE PRINTING
    AutoBand.saved.alt_speccheck_enabled	= (AutoBand.saved.alt_speccheck_enabled == nil) and AB_const.ALTCHECK  or AutoBand.saved.alt_speccheck_enabled
    AutoBand.saved.printrole_enabled		= (AutoBand.saved.printrole_enabled == nil)     and AB_const.PRINTROLE or AutoBand.saved.printrole_enabled

    -- H) DEBUG SETTINGS
    AutoBand.saved.dumps					= AutoBand.saved.dumps or {}
    AutoBand.saved.dumped_wb				= AutoBand.saved.dumped_wb or nil
    AutoBand.saved.default_dump				= AutoBand.saved.default_dump or nil

    --------------------------------------------------------------------------
    -- 3) REGISTER SLASH COMMANDS
    --------------------------------------------------------------------------
    LibSlash.RegisterSlashCmd("autoband", function(msg) AutoBand.parse_cmd(msg) end)
    if not LibSlash.IsSlashCmdRegistered("ab") then
        LibSlash.RegisterSlashCmd("ab", function(msg) AutoBand.parse_cmd(msg) end)
        AutoBand.has_shortslash = true
    end

    --------------------------------------------------------------------------
    -- 4) COMMAND LIST INITIALIZATION
    --    (help/info/UI, templates, kicking, zone, ranks, warband org, debug
    --------------------------------------------------------------------------
    AutoBand.cmd = {
        -- Help/Info & UI
        [""]				= { f=AutoBand.cmd_usage,					help="",									print_id=10 },
        ["help"]			= { f=AutoBand.cmd_usage,					help="show command list",					print_id=11 },
        ["info"]			= { f=AutoBand.cmd_show,					help="show current settings",				print_id=12 },
        ["show"]			= { f=AutoBand.cmd_toggle_gui,				help="open/close GUI",						print_id=13 },
        ["icon"]			= { f=AutoBand.cmd_toggle_icon,				help="show/hide minimap icon",				print_id=14 },

        -- Templates
        ["list"]			= { f=AutoBand.cmd_list_template,			help="list all templates",					print_id=20 },
        ["save"]			= { f=AutoBand.cmd_save_template,			help="<name> save current WB template",		print_id=21 },
        ["apply"]			= { f=AutoBand.cmd_apply_template,			help="<name> apply template",				print_id=22 },
        ["default"]			= { f=AutoBand.cmd_default_template,		help="set/clear default template",			print_id=23 },
        ["mode"]			= { f=AutoBand.cmd_mode,					help="<num> distribution algorithm mode",	print_id=24 },

        -- Kick / Auto-Kick
        ["kf"]				= { f=AutoBand.cmd_kick_toofar,				help="kick all far players",				print_id=30 },
        ["ak"]				= { f=AutoBand.cmd_flag_autokick,			help="toggle autokick lowlvl/excess roles",	print_id=31 },
        ["akf"]				= { f=AutoBand.cmd_flag_autokick_toofar,	help="toggle autokick toofar",				print_id=32 },
        ["kicktimeout"]		= { f=AutoBand.cmd_autokick_timeout,		help="<mins> autokick toofar timeout",		print_id=33 },
        ["an"]				= { f=AutoBand.cmd_flag_autonote,			help="toggle autosearch in /1 for roles",	print_id=34 },
        ["gp"]				= { f=AutoBand.cmd_flag_guildpriority,		help="toggle guild priority",				print_id=35 },

        -- Zone
        ["zone"]			= { f=AutoBand.cmd_list_zone,				help="list players not in leader's zone",	print_id=40 },
        ["zonekick"]		= { f=AutoBand.cmd_kick_notinzone,			help="kick players not in leader's zone",	print_id=41 },

        -- Ranks
        ["rank"]			= { f=AutoBand.cmd_list_rank,				help="list players below required rank",	print_id=50 },
        ["minrank"]			= { f=AutoBand.cmd_rank,					help="<num> set min rank requirement",		print_id=51 },
        ["minrankhealer"]	= { f=AutoBand.cmd_rank_healer,				help="<num> min rank for healers",			print_id=52 },
        ["rankkick"]		= { f=AutoBand.cmd_kick_rank,				help="kick players below required rank",	print_id=53 },

        -- Warband Organization
        ["org"]				= { f=AutoBand.cmd_organize,				help="organize the warband",				print_id=60 },
		["buffnotify"] 		= { f=AutoBand.cmd_toggle_buffnotify, 		help="toggle notifying wb after org", 		print_id=61 },
        ["alt"]				= { f=AutoBand.cmd_alt_speccheck,			help="toggle alt-spec check",				print_id=62 },
        ["wb"]				= { f=AutoBand.wb,							help="information about the warband",		print_id=63 },
        ["roles"]			= { f=AutoBand.cmd_list_roles,				help="list players and their roles",		print_id=64 },
        ["pr"]				= { f=AutoBand.cmd_flag_printrole,			help="toggle printing of role assignments",	print_id=65 },
        ["customrole"]		= { f=AutoBand.cmd_custom_role,				help="manage custom role overrides",		print_id=66 },
        ["end"]				= { f=AutoBand.cmd_end,						help="end warband, kick all",				print_id=67 },

        -- Debug
        ["debug"]			= { f=AutoBand.cmd_debug,					help="",									print_id=100 },
        ["dump"]			= { f=AutoBand.cmd_dump,					help="",									print_id=101 },
        ["cleardump"]		= { f=AutoBand.cmd_cleardumps,				help="",									print_id=102 },
        ["listdump"]		= { f=AutoBand.cmd_list_dump,				help="",									print_id=103 },
        ["loaddump"]		= { f=AutoBand.cmd_load_dump,				help="",									print_id=104 },
        ["tempdump"]		= { f=AutoBand.cmd_dump_from_template,		help="",									print_id=105 },
    }

    --------------------------------------------------------------------------
    -- 5) SORT COMMANDS & DEBUG
    --------------------------------------------------------------------------
    AutoBand.cmd_ordered = {}
    for key, cmd in pairs(AutoBand.cmd) do
        cmd.key = key
        table.insert(AutoBand.cmd_ordered, cmd)
    end
    table.sort(AutoBand.cmd_ordered, function(a, b) return a.print_id < b.print_id end)
    AB_util.debug(AutoBand.cmd_ordered)

    --------------------------------------------------------------------------
    -- 6) REGISTER LAYOUT WINDOW
    --------------------------------------------------------------------------
    LayoutEditor.RegisterWindow("AutoBandMapIcon", L"AutoBand", L"AutoBand Button", false, false, true, nil)

    --------------------------------------------------------------------------
    -- 7) PRINT LOADED MESSAGE
    --------------------------------------------------------------------------
    local slash = AutoBand.has_shortslash and " or /ab" or ""
    AB_util.print("AutoBand v" .. AB_const.VERSION .. " loaded. Type /autoband" .. slash .. " for instructions")
end

function AutoBand.cmd_toggle_buffnotify(args)
    AutoBand.saved.notify_buffs_enabled = not AutoBand.saved.notify_buffs_enabled
    AB_util.print("Notify warband after organize: " .. tostring(AutoBand.saved.notify_buffs_enabled))
end

function AutoBand.cmd_alt_speccheck(args)
	AutoBand.saved.alt_speccheck_enabled = not AutoBand.saved.alt_speccheck_enabled
	AB_util.print("Use alt spec check: " .. tostring(AutoBand.saved.alt_speccheck_enabled))
end

function AutoBand.cmd_flag_printrole(args)
    AutoBand.saved.printrole_enabled = not AutoBand.saved.printrole_enabled
    AB_util.print("Print role assignments: " .. tostring(AutoBand.saved.printrole_enabled))
end

function AutoBand.cmd_list_roles(args)
    AB_util.print("Currently known player roles:")
    local entries = {}
    for name, role in pairs(roles_last) do
        table.insert(entries, { name = name, role = role })
    end
    -- sort by role (and name as tiebreaker)
    table.sort(entries, function(a, b)
        if a.role == b.role then
            return a.name < b.name
        else
            return a.role < b.role
        end
    end)
    -- print sorted entries
    local count = 0
    for _, entry in ipairs(entries) do
        local msg = towstring("- [") .. towstring(entry.role) .. towstring("] - ") .. towstring(entry.name)
        AB_util.print(msg)
        count = count + 1
    end
    if count == 0 then
        AB_util.print("(no role data available)")
    end
end

function AutoBand.update(elapsed)
    AutoBand.elapsed = AutoBand.elapsed + elapsed
    if (AutoBand.elapsed > AB_const.HEARTBEAT) then
        local e = AutoBand.elapsed
        AutoBand.elapsed = 0
		need_role_update = true
        AutoBand.auto_kick()
        AutoBand.auto_kick_toofar()
        AutoBand.auto_note()
		if need_role_update then
			AutoBand.update_roles()
		end
    end

    if (AutoBand.cmd_current == nil) then
        if (#AutoBand.cmd_queue > 0) then
            AutoBand.cmd_current = table.remove(AutoBand.cmd_queue, 1)
        else
            return
        end
    end

    AutoBand.cmd_current.ticks = AutoBand.cmd_current.ticks - 1
    if (AutoBand.cmd_current.ticks <= 0) then
        if (AutoBand.debugon or AutoBand.gizilon) then
            AB_util.debug(tostring(AutoBand.cmd_current.cmd))
        end
        SendChatText(towstring(AutoBand.cmd_current.cmd), L"")
        local cmd_tmp = AutoBand.cmd_current
        AutoBand.cmd_current = nil
        if (cmd_tmp.callback) then
            cmd_tmp.callback(cmd_tmp)
        end
    end
end

function AutoBand.update_roles()
	local wb_obj = AutoBand.get_wb()
	if not wb_obj then
		AB_util.print("wb_obj is nil!")
		return
	end

	local current_players = {}

	local success, err = pcall(function()
		wb_obj:foreach_player(function(gid, player)
			AB_wb:track_role(player, current_players)
		end)
	end)

	if not success then
		AB_util.print("Error in foreach_player: " .. tostring(err))
	end

	AB_wb:remove_missing_players(current_players)
end

function AutoBand.cmd_custom_role(args)
    local subcmd = args[1]
    if subcmd == "add" and args[2] and args[3] then
        local name = args[2]
        local role = args[3]
        if role ~= "tank" and role ~= "healer" and role ~= "mdps" and role ~= "rdps" then
            AB_util.print("[error] Invalid role: " .. role .. " - valid choices are tank, healer, mdps or rdps.")
            return
        end
        AutoBand.saved.custom_roles[name] = role
        AB_util.print("Added role override: " .. name .. " -> " .. role)
    elseif subcmd == "remove" and args[2] then
        AutoBand.saved.custom_roles[args[2]] = nil
        AB_util.print("Removed role override for: " .. args[2])
    elseif subcmd == "list" then
        AB_util.print("Custom role overrides:")
        for k, v in pairs(AutoBand.saved.custom_roles) do
            AB_util.print("- " .. k .. ": " .. v)
        end
    else
        AB_util.print("Usage: /ab customrole add <name> <role>")
        AB_util.print("       /ab customrole remove <name>")
        AB_util.print("       /ab customrole list")
    end
end

-- enqueues a string to be processed by "AutoBand.update()"
function AutoBand.enqueue_command(cmd, ticks, callback)
    ticks = ticks or AB_const.DEFAULT_CMD_TICKS
    table.insert(AutoBand.cmd_queue, {
        ["cmd"] = cmd,
        ["ticks"] = ticks,
        ["callback"] = callback
    })
end

function AutoBand.enqueue_kick(player_name, msg_reason)
    if (msg_reason) then
        AutoBand.enqueue_command("/tell " .. tostring(player_name) ..
            " [AutoBand] You were kicked from the warband since " .. msg_reason)
    end
    AutoBand.enqueue_command(L"/kick " .. player_name)
    AB_util.print(L"Kicking " .. player_name)
end

function AutoBand.has_permission()
    local wb_obj = AutoBand.get_wb()
    local i = 0
    wb_obj:foreach_player(
        function(gid, player)
            i = i + 1
        end
    )
    if i == 0 then
        return false
    end
    return GameData.Player.isGroupLeader
end

-- returns a AB_wb object either from a warband, scenario or dumped_wb
function AutoBand.get_wb()
    if (AutoBand.debugon and AutoBand.saved.dumped_wb ~= nil) then
        AB_util.debug("Getting dump " .. AutoBand.saved.default_dump .. " size " ..
            AB_util.size_wb(AutoBand.saved.dumped_wb.group))
        return AB_wb:new(AutoBand.saved.dumped_wb)
    end
    local wb = AB_wb:new()
    wb:load_from_wbdata()
    return wb
end

-- ####### / Commands ####### 
function AutoBand.parse_cmd(msg)
    msg = msg:lower()
    local args = StringSplit(msg)
    cmd = table.remove(args, 1)
    if (AutoBand.cmd[cmd] ~= nil) then
        AutoBand.cmd[cmd].f(args)
    else
        AB_util.print("AutoBand unknown command: " .. msg)
    end
end

function AutoBand.cmd_usage(args)
    local ab = "/autoband "
    if (AutoBand.has_shortslash) then
        ab = "/ab "
    end
    AB_util.print("[Autoband commands]")
    for _, cmd in ipairs(AutoBand.cmd_ordered) do
        if (cmd.help ~= "" or AutoBand.debugon) then
            AB_util.print(ab .. cmd.key .. " - " .. cmd.help)
        end
    end
end

function AutoBand.cmd_show(args)
    AB_util.print("[AutoBand v" .. AB_const.VERSION .. " settings]")
    AB_util.print("Default template: " .. AutoBand.saved.default_template)
    AB_util.print("Auto kick too far players: " .. tostring(AutoBand.saved.autokick_toofar_enabled))
    AB_util.print("Auto kick too far players timeout: " .. tostring(AutoBand.saved.autokick_period))
    AB_util.print("Minimum rank requirement: " .. tostring(AutoBand.saved.min_rank))
    AB_util.print("Minimum rank requirement (healer): " .. tostring(AutoBand.saved.min_rank_healer))
    AB_util.print("Auto kick players: " .. tostring(AutoBand.saved.autokick_enabled))
	AB_util.print("Guild priority when auto-kick: " .. tostring(AutoBand.saved.guild_priority_enabled))
	AB_util.print("Notify warband after organize: " .. tostring(AutoBand.saved.notify_buffs_enabled))
	AB_util.print("Use alt spec check: " .. tostring(AutoBand.saved.alt_speccheck_enabled))
	AB_util.print("Print role assignments: " .. tostring(AutoBand.saved.printrole_enabled))
	    if (AutoBand.debugon) then
        AB_util.print("Data dumped: " .. tostring(AutoBand.saved.dumped_wb ~= nil))
        AB_util.print("Debug mode: true")
    end
end

function AutoBand.cmd_debug(args)
    AutoBand.debugon = not AutoBand.debugon
    AB_util.print("Debug mode: " .. tostring(AutoBand.debugon))
end

function AutoBand.cmd_flag_autokick(args)
    AutoBand.saved.autokick_enabled = not AutoBand.saved.autokick_enabled
    AB_util.print("Auto kick players: " .. tostring(AutoBand.saved.autokick_enabled))
end

function AutoBand.cmd_flag_autokick_toofar(args)
    AutoBand.saved.autokick_toofar_enabled = not AutoBand.saved.autokick_toofar_enabled
    if AutoBand.has_permission() then
        if AutoBand.saved.autokick_toofar_enabled then
            AutoBand.enqueue_command("/wb [AutoBand] Auto kick players who are far away from leader ENABLED! Follow the leader PLZ")
        else
            AutoBand.enqueue_command("/wb [AutoBand] Auto kick players who are far away from leader DISABLED! Free move")
            warned = {}
        end
    end
    AB_util.print("Auto kick too far players: " .. tostring(AutoBand.saved.autokick_toofar_enabled))
end

function AutoBand.cmd_flag_autonote(args)
    AutoBand.saved.autonote_enabled = not AutoBand.saved.autonote_enabled
    AB_util.print("Auto note in /1: " .. tostring(AutoBand.saved.autonote_enabled))
end

function AutoBand.cmd_dump(args)
    if (args[1] == nil) then
        AB_util.print("[error] Missing argument")
        return
    end
    local wb = AB_wb:new()
    wb:load_from_wbdata()
    AutoBand.saved.dumped_wb = wb
    AutoBand.saved.default_dump = args[1]
    AutoBand.saved.dumps[args[1]] = wb
    AB_util.print("Dump complete")
end

function AutoBand.cmd_cleardumps(args)
    AutoBand.saved.dumped_wb = nil
    AutoBand.saved.dumps = {}
    AutoBand.saved.default_dump = nil
end

function AutoBand.cmd_kick_toofar(args)
    if (not AutoBand.has_permission()) then
        AB_util.print("[error] You need to be a wb leader")
        return
    end
    local wb_obj = AutoBand.get_wb()
    wb_obj:foreach_player(
        function(gid, player)
            for i = 1, MAX_MAP_POINTS do
                local mpd = GetMapPointData("EA_Window_OverheadMapMapDisplay", i)
                if (not mpd or not MapPointTypeFilter[mpd.pointType] or not mpd.name) then
                    continue
                end
                local name = AutoBand.FixString((mpd.name))
                if name == player.name then
                    player.distance = mpd.distance * DISTANCE_FIX_COEFFICIENT
                    if player.distance > 150 then
                        AutoBand.enqueue_kick(player.name, "not follow leader")
                    end
                    break
                end
            end
        end
    )
end

function AutoBand.cmd_list_offline(args)
    local wb_obj = AutoBand.get_wb()
    wb_obj:foreach_player(
        function(gid, player)
            for i = 1, MAX_MAP_POINTS do
                local mpd = GetMapPointData("EA_Window_OverheadMapMapDisplay", i)
                if (not mpd or not MapPointTypeFilter[mpd.pointType] or not mpd.name) then
                    continue
                end
                local name = AutoBand.FixString((mpd.name))
                if name == player.name then
                    player.distance = mpd.distance * DISTANCE_FIX_COEFFICIENT
                    if player.distance > 150 then
                        AB_util.print(player.name)
                    end
                end
            end
        end
    )
end

function AutoBand.cmd_list_rank(args)
    local str = ""
    local players = AutoBand.get_low_rank()
    if (#players > 0) then
        table.sort(players, function(p1, p2) return p1.level > p2.level end)
        for _, player in ipairs(players) do
            str = str .. tostring(player.name) .. "(r" .. player.level .. ") "
        end
        AB_util.print(AB_const.HEADER_MARGIN ..
            " Players with rank < (configured) " ..
            AB_const.HEADER_MARGIN ..
            " (#" .. #players .. ")")
        AB_util.print(str)
    end
end

function AutoBand.cmd_list_zone(args)
    local wb_obj = AutoBand.get_wb()
    if (wb_obj.player_count == 0) then
        AB_util.debug("No wb data found")
        return
    end

    local players_by_zid = AutoBand.get_players_zone(wb_obj)
    local num_valid_zones = AB_util.size_table(players_by_zid["valid_as"])
    if (players_by_zid["valid_as"] and num_valid_zones > 0) then
        AB_util.print(AB_const.HEADER_MARGIN ..
            " Leader's and assistants' zones " ..
            AB_const.HEADER_MARGIN)
        for zid, as_zone in pairs(players_by_zid["valid_as"]) do
            local num_assistants = AB_util.size_table(as_zone)
            local str = ""
            local num_players = AB_util.size_table(players_by_zid["valid_p"][zid])
            local zone_name = GetZoneName(zid)
            if (zid == 0) then
                zone_name = "Offline"
            end
            str = str .. tostring(zone_name) .. " (#" .. num_players .. ") "
            for _, player in ipairs(as_zone) do
                if (player.isGroupLeader) then
                    str = str .. tostring(player.name) ..
                    "(" .. AB_const.ABBREVATIONS["LEADER"] .. ") "
                else
                    str = str .. tostring(player.name) ..
                    "(" .. AB_const.ABBREVATIONS["ASSISTANT"] .. ") "
                end
            end
            AB_util.print(str)
        end
    end

    local num_invalid_zones = AB_util.size_table(players_by_zid["other"])
    if (players_by_zid["other"] and num_invalid_zones > 0) then
        AB_util.print(AB_const.HEADER_MARGIN ..
            " " ..
            AB_const.LABEL_NOTSAMEZONE ..
            " " ..
            AB_const.HEADER_MARGIN)
        for zid, other_zone in pairs(players_by_zid["other"]) do
            local str = ""
            local num_players = AB_util.size_table(other_zone)
            str = str ..
                tostring(GetZoneName(zid)) ..
                " (#" .. #other_zone .. ") "
            for _, player in ipairs(other_zone) do
                str = str .. tostring(player.name) .. " "
            end
            AB_util.print(str)
        end
    end
end

function AutoBand.cmd_kick_notinzone(args)
    if (not AutoBand.has_permission()) then
        AB_util.print("[error] You need to be a wb leader")
        return
    end

    local wb_obj = AutoBand.get_wb()
    if (wb_obj.player_count == 0) then
        AB_util.debug("No wb data found")
        return
    end

    local zone_name = GetZoneName
    local players_by_zid = AutoBand.get_players_zone(wb_obj)
    local num_valid_zones = AB_util.size_table(players_by_zid["valid_as"])

    if (players_by_zid["valid_as"] and num_valid_zones > 0) then
        local valid_zone_str = ""
        for zid, as_zone in pairs(players_by_zid["valid_as"]) do
            if (zid ~= 0) then
                valid_zone_str = valid_zone_str ..
                    tostring(zone_name(zid)) ..
                    " "
            end
        end

        local num_invalid_zones = AB_util.size_table(players_by_zid["other"])
        if (players_by_zid["other"] and num_invalid_zones > 0) then
            AB_util.print("Kicking " .. AB_const.LABEL_NOTSAMEZONE)
            for zid, other_zone in pairs(players_by_zid["other"]) do
                if (zid ~= 0) then
                    for _, player in ipairs(other_zone) do
                        AutoBand.enqueue_kick(player.name,
                            "you are not in one of the required zones {" ..
                            valid_zone_str .. "}")
                    end
                end
            end
        end
    end
    AB_util.print("Zone kick complete")
end

function AutoBand.cmd_rank(args)
    if (args[1] == nil) then
        AB_util.print("[error] Missing argument")
        return
    end
    local n = tonumber(args[1])
    if (n < 0 or n > 40) then
        AB_util.print("[error] Invalid rank value: " .. tostring(n))
        return
    end
    AutoBand.saved.min_rank = math.floor(n)

    -- Ensure the separate healer rank doesn't exceed the new min_rank
    if (AutoBand.saved.min_rank_healer > AutoBand.saved.min_rank) then
        AutoBand.saved.min_rank_healer = AutoBand.saved.min_rank
    end

    AB_util.print("Minimum rank requirement: " .. tostring(AutoBand.saved.min_rank))
end

function AutoBand.cmd_rank_healer(args)
    if (args[1] == nil) then
        AB_util.print("[error] Missing argument")
        return
    end
    local n = tonumber(args[1])
    if (n < 0 or n > 40) then
        AB_util.print("[error] Invalid healer rank value: " .. tostring(n))
        return
    end
    -- Make sure it cannot exceed the general min_rank
    if (n > AutoBand.saved.min_rank) then
        AB_util.print("[error] Healer min rank cannot exceed overall min rank (" ..
            AutoBand.saved.min_rank .. ")")
        return
    end
    AutoBand.saved.min_rank_healer = math.floor(n)
    AB_util.print("Minimum rank requirement (healer): " .. tostring(AutoBand.saved.min_rank_healer))
end

function AutoBand.cmd_kick_rank(args)
    if (not AutoBand.has_permission()) then
        AB_util.print("[error] You need to be a wb leader")
        return
    end
    local players = AutoBand.get_low_rank()
    if (#players > 0) then
        AB_util.print("Kicking players below rank requirements")
        for _, player in ipairs(players) do
            local needed = player.role == "healer" and AutoBand.saved.min_rank_healer or AutoBand.saved.min_rank
            AutoBand.enqueue_kick(player.name,
                "you don't meet the rank requirement (" .. needed .. ")")
        end
    end
    AB_util.print("Rank kick complete")
end

function AutoBand.cmd_organize(args)
    if (AutoBand.has_permission() or AutoBand.debugon) then
        if AutoBand.saved.autokick_enabled or AutoBand.saved.autokick_toofar_enabled then
            a = AutoBand.saved.autokick_enabled
            b = AutoBand.saved.autokick_toofar_enabled
            AutoBand.saved.autokick_enabled = false
            AutoBand.saved.autokick_toofar_enabled = false
            if (args[1] ~= nil) then
                AB_org.auto_organize(AutoBand.saved.templates[args[1]])
            else
                AB_org.auto_organize(AutoBand.saved.templates[AutoBand.saved.default_template])
            end
            AutoBand.saved.autokick_enabled = a
            AutoBand.saved.autokick_toofar_enabled = b
        else
            if (args[1] ~= nil) then
                AB_org.auto_organize(AutoBand.saved.templates[args[1]])
            else
                AB_org.auto_organize(AutoBand.saved.templates[AutoBand.saved.default_template])
            end
        end
    else
        AB_util.print("[error] You need to be a wb leader")
    end
end

function AutoBand.cmd_autokick_timeout(args)
    if (args[1] == nil) then
        AB_util.print("[error] Missing argument")
        return
    end
    local n = tonumber(args[1])
    if (n < 0) then
        AB_util.print("[error] Invalid timeout value: " .. tostring(n))
        return
    end
    AutoBand.saved.autokick_period = math.floor(n)
    AB_util.print("Auto kick timeout: " .. tostring(AutoBand.saved.autokick_period))
end

function AutoBand.cmd_mode(args)
    if (args[1] == nil) then
        AB_util.print("[error] Missing argument")
        return
    end
    local n = tonumber(args[1])
    if (n < 0 or n > 2) then
        AB_util.print("[error] Invalid distribution algorithm: " .. tostring(n))
        return
    end
    AutoBand.saved.org_algo_mode = math.floor(n)
    AB_util.print("Distribution algorithm mode: " ..
        tostring(AutoBand.saved.org_algo_mode) ..
        AB_const.ALGO_MODE[AutoBand.saved.org_algo_mode])
end

function AutoBand.cmd_flag_guildpriority(args)
    AutoBand.saved.guild_priority_enabled = not AutoBand.saved.guild_priority_enabled
    AB_util.print("Guild priority for auto-kick: " .. tostring(AutoBand.saved.guild_priority_enabled))
end

function AutoBand.cmd_list_template(args)
    AB_util.print("Default template " .. AutoBand.saved.default_template)
    for tname in pairs(AutoBand.saved.templates) do
        AB_util.print(tname)
    end
end

function AutoBand.cmd_save_template(args)
    if (args[1] == nil) then
        AB_util.print("[error] Missing argument")
        return
    end
    AutoBand.saved.templates[args[1]] = AB_template.from_wb(AutoBand.get_wb())
    AB_util.print("Template " .. args[1] .. " saved")
end

function AutoBand.cmd_apply_template(args)
    if (args[1] == nil) then
        AB_util.print("[error] Missing argument")
        return
    end
    if (AutoBand.saved.templates[args[1]] == nil) then
        AB_util.print("[error] Template " .. args[1] .. " does not exist")
        return
    end
    AB_org.auto_organize(AutoBand.saved.templates[args[1]])
    AB_util.print("Template " .. args[1] .. " loaded")
end

function AutoBand.cmd_default_template(args)
    if (#args > 0) then
        if (AutoBand.saved.templates[args[1]] == nil) then
            AB_util.print("[error] Template " .. args[1] .. " does not exist")
            return
        end
        AutoBand.saved.default_template = args[1]
    else
        AutoBand.saved.default_template = AB_const.EMPTY_TEMPLATE
    end
    AB_util.print("Default template set: " .. AutoBand.saved.default_template)
end

function AutoBand.cmd_toggle_gui(args)
    if (AutoBandWindow.showing()) then
        AutoBandWindow.Hide()
    else
        AutoBandWindow.Show()
    end
end

function AutoBand.cmd_toggle_icon(args)
    AutoBandWindow.toggle_mapicon()
end

function AutoBand.cmd_list_dump(args)
    if (AutoBand.saved.dumped_wb ~= nil) then
        AB_util.print("[AutoBand] default dump " .. AutoBand.saved.default_dump)
    end
    for tname in pairs(AutoBand.saved.dumps) do
        AB_util.print(tname)
    end
end

function AutoBand.cmd_load_dump(args)
    if (#args > 0) then
        if (AutoBand.saved.dumps[args[1]] == nil) then
            AB_util.print("[error] Dump " .. args[1] .. " does not exist")
            return
        end
        AutoBand.saved.default_dump = args[1]
        AutoBand.saved.dumped_wb = AutoBand.saved.dumps[AutoBand.saved.default_dump]
    end
    AB_util.print("[AutoBand] Default dump set: " .. AutoBand.saved.default_dump)
end

function AutoBand.cmd_dump_from_template(args)
    if (AutoBand.debugon) then
        if (#args > 1) then
            local template_name = args[1]
            local dump_name = args[2]
            if (AutoBand.saved.templates[template_name] == nil) then
                AB_util.print("[error] Template " .. template_name .. " does not exist")
                return
            end
            AutoBand.saved.dumped_wb = AutoBand.get_fakewb(AutoBand.saved.templates[template_name])
            AutoBand.saved.dumps[dump_name] = AutoBand.saved.dumped_wb
            AutoBand.saved.default_dump = dump_name
        end
    end
end

function AutoBand.auto_kick_toofar()
    if (not AutoBand.saved.autokick_toofar_enabled or not AutoBand.has_permission() or AutoBand.debugon) then
        return
    end
    local wb_obj = AutoBand.get_wb()
    wb_obj:foreach_player(
        function(gid, player)
            for i = 1, MAX_MAP_POINTS do
                local mpd = GetMapPointData("EA_Window_OverheadMapMapDisplay", i)
                if (not mpd or not MapPointTypeFilter[mpd.pointType] or not mpd.name) then
                    continue
                end
                local name = AutoBand.FixString((mpd.name))
                if name == player.name then
                    player.distance = mpd.distance * DISTANCE_FIX_COEFFICIENT
                    if player.distance > 150 then
                        if toofar[player.name] then
                            toofar[player.name] = toofar[player.name] + 1
                        else
                            toofar[player.name] = 1
                        end
                        if (toofar[player.name] == 6) then
                            local found = 0
                            for i, v in pairs(warned) do
                                if v == player.name then
                                    found = 1
                                    break
                                end
                            end
                            if found == 0 then
                                AutoBand.enqueue_command("/tell " .. tostring(player.name) ..
                                    " [AutoBand] You are too far from leader, you will be autokicked in " ..
                                    AutoBand.saved.autokick_period * 60 - 30 ..
                                    "sec! Follow the leader PLZ")
                                table.insert(warned, player.name)
                            end
                        end
                        if (toofar[player.name] > AutoBand.saved.autokick_period * 12) then
                            AutoBand.enqueue_kick(player.name,
                                "was too far from warband leader for a long time")
                        end
                    else
                        toofar[player.name] = nil
                    end
                    break
                end
            end
        end
    )

    for i, v in pairs(toofar) do
        for ii, vv in pairs(toofar_old) do
            if i == ii then
                if v == vv then
                    if toofar_not_changed[i] then
                        toofar_not_changed[i] = toofar_not_changed[i] + 1
                    else
                        toofar_not_changed[i] = 1
                    end
                    if toofar_not_changed[i] > 60 then
                        toofar[i] = nil
                        toofar_not_changed[i] = nil
                    end
                end
                break
            end
        end
    end

    toofar_old = {}
    for key, value in pairs(toofar) do
        toofar_old[key] = value
    end
end

function AutoBand.auto_kick()
    if (not AutoBand.saved.autokick_enabled or not AutoBand.has_permission() or AutoBand.debugon) then
        return
    end
    local wb_obj = AutoBand.get_wb()
    local tanks_t = {}
    local healers_t = {}
    local dps_t = {}
    local found = 0
    local tanks, healers, dpss = 0, 0, 0
    local guild_member = false

    -- Only get guild members if priority is enabled
    g_m = {}
    guild_members = {}
    if AutoBand.saved.guild_priority_enabled then
        g_m = GetGuildMemberData()
        for key, value in pairs(g_m) do
            table.insert(guild_members, value.name)
        end
    end

    ign = GetIgnoreList()

    wb_obj:foreach_player(
        function(gid, player)
            if ign ~= nil then
                for key, value in pairs(ign) do
                    if player.name:match(L"([^^]+)^?([^^]*)") == value.name:match(L"([^^]+)^?([^^]*)") then
                        AutoBand.enqueue_kick(player.name, "you are in my ignore list.")
                    end
                end
            end

            local required_rank = (player.role == "healer") and AutoBand.saved.min_rank_healer or AutoBand.saved.min_rank
            if (player.level < required_rank) then
                AutoBand.enqueue_kick(player.name, "you are too low level for it.")
                return
            end

            guild_member = false
            if AutoBand.saved.guild_priority_enabled then
                for key, value in pairs(guild_members) do
                    if value:match(L"([^^]+)^?([^^]*)") == player.name then
                        guild_member = true
                        break
                    end
                end
            end
			
            if (player.role == "tank") then
                tanks_t[player.name] = guild_member
                tanks = tanks + 1
            elseif (player.role == "healer") then
                healers_t[player.name] = guild_member
                healers = healers + 1
            elseif (player.role == "mdps" or player.role == "rdps") then
                dps_t[player.name] = guild_member
                dpss = dpss + 1
            end
        end
    )

    -- Tanks
    if (tanks > maxtanks) then
        for key, value in pairs(tanks_t) do
            for key2, value2 in pairs(tanks_t_old) do
                if (key == key2) then
                    found = 1
                    break
                end
            end
            if (found == 0) then
                if value then
                    -- Removed guild_priority_enabled check; now simply 'if value then...'
                    for key2, value2 in pairs(tanks_t) do
                        if not value2 then
                            AutoBand.enqueue_kick(key2, "too many tanks in it (guild member priority).")
                            tanks_t[key2] = nil
                            tanks = tanks - 1
                            break
                        end
                    end
                else
                    AutoBand.enqueue_kick(key, "too many tanks in it.")
                    tanks_t[key] = nil
                    tanks = tanks - 1
                end
                if tanks <= maxtanks then
                    break
                end
            end
            found = 0
        end
    end

    tanks_t_old = {}
    local i = 0
    for key, value in pairs(tanks_t) do
        i = i + 1
        if (i <= maxtanks) then
            tanks_t_old[key] = value
        end
    end

    found = 0
    -- Healers
    if (healers > maxhealers) then
        for key, value in pairs(healers_t) do
            for key2, value2 in pairs(healers_t_old) do
                if (key == key2) then
                    found = 1
                    break
                end
            end
            if (found == 0) then
                if value then
                    for key2, value2 in pairs(healers_t) do
                        if not value2 then
                            AutoBand.enqueue_kick(key2, "too many healers in it (guild member priority).")
                            healers_t[key2] = nil
                            healers = healers - 1
                            break
                        end
                    end
                else
                    AutoBand.enqueue_kick(key, "too many healers in it.")
                    healers_t[key] = nil
                    healers = healers - 1
                end
                if healers <= maxhealers then
                    break
                end
            end
            found = 0
        end
    end

    healers_t_old = {}
    i = 0
    for key, value in pairs(healers_t) do
        i = i + 1
        if (i <= maxhealers) then
            healers_t_old[key] = value
        end
    end

    found = 0
    -- DPS
    if (dpss > maxdps) then
        for key, value in pairs(dps_t) do
            for key2, value2 in pairs(dps_t_old) do
                if (key == key2) then
                    found = 1
                    break
                end
            end
            if (found == 0) then
                if value then
                    for key2, value2 in pairs(dps_t) do
                        if not value2 then
                            AutoBand.enqueue_kick(key2, "too many dps in it (guild member priority).")
                            dps_t[key2] = nil
                            dpss = dpss - 1
                            break
                        end
                    end
                else
                    AutoBand.enqueue_kick(key, "too many dps in it.")
                    dps_t[key] = nil
                    dpss = dpss - 1
                end
                if dpss <= maxdps then
                    break
                end
            end
            found = 0
        end
    end

    dps_t_old = {}
    i = 0
    for key, value in pairs(dps_t) do
        i = i + 1
        if (i <= maxdps) then
            dps_t_old[key] = value
        end
    end
end

function AutoBand.auto_note()
    number2 = number2 + 1
    if (not AutoBand.saved.autonote_enabled or not AutoBand.has_permission() or AutoBand.debugon) then
        return
    end

    local wb_obj = AutoBand.get_wb()
    local tanks, healers, dpss = 0, 0, 0
    wb_obj:foreach_player(
        function(gid, player)
            if (player.role == "tank") then
                tanks = tanks + 1
            elseif (player.role == "healer") then
                healers = healers + 1
            elseif (player.role == "mdps" or player.role == "rdps") then
                dpss = dpss + 1
            end
        end
    )

    if (tanks == 0 and healers == 0 and dpss == 0) then
        return
    end

    if ((tanks < maxhealers or healers < maxhealers or dpss < maxdps) and (tanks + healers + dpss < 24)) then
        if number2 > 60 then -- every 5 min
            local neededTank   = math.max(0, maxtanks - tanks)
            local neededHealer = math.max(0, maxhealers - healers)
            local neededDps    = math.max(0, maxdps - dpss)

            local message = "/1 [AutoBand] Warband need "
                .. neededTank .. " tanks, "
                .. neededHealer .. " healers, "
                .. neededDps .. " dps. "

            -- Only show separate healer min rank if it's different
            if AutoBand.saved.min_rank_healer ~= AutoBand.saved.min_rank then
                message = message .. "Min rank healers: "
                    .. AutoBand.saved.min_rank_healer
                    .. "+, others: "
                    .. AutoBand.saved.min_rank
                    .. "+"
            else
                message = message .. "Min rank: "
                    .. AutoBand.saved.min_rank
                    .. "+"
            end

            AutoBand.enqueue_command(message)
            number2 = 0
        end
    end
end

-- return a list of players who do not meet rank requirements
function AutoBand.get_low_rank(wb_obj)
    if (not wb_obj) then
        wb_obj = AutoBand.get_wb()
    end
    local list = {}
    wb_obj:foreach_player(
        function(gid, player)
            local needed = (player.role == "healer") and AutoBand.saved.min_rank_healer or AutoBand.saved.min_rank
            if (player.level < needed) then
                table.insert(list, player)
            end
        end
    )
    return list
end

function AutoBand.wb(args)
    wb_obj = AutoBand.get_wb()
    local tanks, healers, dpss, w_wh = 0, 0, 0, 0
    local ii = 0
    local guildmem = {}
    g_m = GetGuildMemberData()
    local guild_members = {}
    for key, value in pairs(g_m) do
        table.insert(guild_members, value.name)
    end
    wb_obj:foreach_player(
        function(gid, player)
            if (player.role == "tank") then
                tanks = tanks + 1
            elseif (player.role == "healer") then
                healers = healers + 1
            elseif (player.role == "mdps" or player.role == "rdps") then
                dpss = dpss + 1
            end
            if (player.careerLine == (GameData.CareerLine.WITCH_ELF or GameData.CareerLine.WITCH_HUNTER)) then
                w_wh = w_wh + 1
            end
            for key, value in pairs(guild_members) do
                if value:match(L"([^^]+)^?([^^]*)") == player.name then
                    ii = ii + 1
                    table.insert(guildmem, player.name)
                    break
                end
            end
        end
    )
    AB_util.print("Tanks in WB: " .. tanks)
    AB_util.print("Healers in WB: " .. healers)
    AB_util.print("DPSs in WB: " .. dpss)
    -- AB_util.print("Stealthers in WB: " .. w_wh)
    AB_util.print("Guild members (including you) in WB: " .. ii)
    for key, value in pairs(guildmem) do
        AB_util.print(tostring(value))
    end
end

function AutoBand.get_players_zone(wb_obj)
    local zids = { ["valid_as"] = {}, ["valid_p"] = {} }
    local leader_zone = nil

    wb_obj:foreach_player(
        function(gid, player)
            if (player.isGroupLeader or player.isAssistant) then
                if (zids["valid_as"][player.zoneNum] == nil) then
                    zids["valid_as"][player.zoneNum] = {}
                end
                if (player.isGroupLeader) then
                    leader_zone = player.zoneNum
                    table.insert(zids["valid_as"][player.zoneNum], 1, player)
                else
                    table.insert(zids["valid_as"][player.zoneNum], player)
                end
            end
        end
    )

    if (leader_zone) then
        zids["other"] = {}
        wb_obj:foreach_player(
            function(gid, player)
                if (zids["valid_as"][player.zoneNum]) then
                    if (zids["valid_p"][player.zoneNum] == nil) then
                        zids["valid_p"][player.zoneNum] = {}
                    end
                    table.insert(zids["valid_p"][player.zoneNum], player)
                else
                    if (zids["other"][player.zoneNum] == nil) then
                        zids["other"][player.zoneNum] = {}
                    end
                    table.insert(zids["other"][player.zoneNum], player)
                end
            end
        )
    else
        AB_util.print("[ERROR] Leader cannot be found, the warband is BUGGED, reform a warband")
    end
    return zids
end

function AutoBand.get_fakewb(template)
    local wb = AB_wb:new()
    wb:set_groups()
    local num_players = 1
    for gid, tgroup in ipairs(template) do
        for j, tplayer in ipairs(tgroup) do
            wb:add_to_gid(tplayer.role, num_players, gid)
            num_players = num_players + 1
        end
    end
    wb:recalc_counters()
    wb:print()
    return wb
end

function AutoBand.FixString(str)
    if (str == nil) then
        return nil
    end
    local pos = str:find(L"^", 1, true)
    if (pos) then
        str = str:sub(1, pos - 1)
    end
    return str
end

function AutoBand.cmd_end(args)
    local wb_obj = AutoBand.get_wb()
    wb_obj:foreach_player(
        function(gid, player)
            AutoBand.enqueue_kick(player.name, "it ended, see you next time!")
        end
    )
end