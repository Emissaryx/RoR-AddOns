--
AutoBandWindowTools = {}

AutoBandWindowTools.name = "AutoBandWindowToolsTab"

AutoBandWindowTools.tools_data = {
        [AB_const.KICK_OFFLINE] = { ["button"] = "KickOfflineCheckBox" , ["label"] = "KickOfflineLabel", ["func_kick"]= AutoBand.cmd_kick_toofar, ["func_print"] = AutoBand.cmd_list_offline},
        [AB_const.KICK_ZONE] = { ["button"] = "KickZoneCheckBox" , ["label"] = "KickZoneLabel", ["func_kick"]= AutoBand.cmd_kick_notinzone, ["func_print"] = AutoBand.cmd_list_zone},
        [AB_const.KICK_RANK] = { ["button"] = "KickRankCheckBox" , ["label"] = "KickRankLabel", ["func_kick"]= AutoBand.cmd_kick_rank, ["func_print"] = AutoBand.cmd_list_rank} }


function AutoBandWindowTools.Initialize()
        LabelSetText(AutoBandWindowTools.name .. "KickLabel", L"Manage Players")

        for fid, func in pairs(AutoBandWindowTools.tools_data) do
                LabelSetText(AutoBandWindowTools.name .. func["label"], towstring(AB_const.LABEL_KICK[fid]))
                ButtonSetCheckButtonFlag(AutoBandWindowTools.name .. func["button"], true)
                ButtonSetPressedFlag(AutoBandWindowTools.name .. func["button"], AutoBand.saved.kick_func_enabled[fid])
        end

        ButtonSetText(AutoBandWindowTools.name .. "PrintButton", L"Print")
        ButtonSetText(AutoBandWindowTools.name .. "KickButton", L"Kick")

        LabelSetText(AutoBandWindowTools.name .. "SearchRoleLabel", L"Manual Search for Players")
        LabelSetText(AutoBandWindowTools.name .. "SearchRoleChan1Label", L"Manual Search in /1 (region)")
        LabelSetText(AutoBandWindowTools.name .. "SearchRoleChanT4Label", L"Manual Search in /t4")
        LabelSetText(AutoBandWindowTools.name .. "SearchRoleChan5Label", L"Manual Search in /5 (lfg)")

        ButtonSetCheckButtonFlag(AutoBandWindowTools.name .. "SearchRoleChan1CheckBox", true) -- Enable check button behavior
        ButtonSetPressedFlag(AutoBandWindowTools.name .. "SearchRoleChan1CheckBox", true)  -- Check it
        -- ButtonSetDisabledFlag(AutoBandWindowTools.name .. "SearchRoleChan1CheckBox", true)  -- Disable it

        ButtonSetCheckButtonFlag(AutoBandWindowTools.name .. "SearchRoleChanT4CheckBox", true) -- Enable check button behavior
        ButtonSetPressedFlag(AutoBandWindowTools.name .. "SearchRoleChanT4CheckBox", false)  -- Default unchecked

        ButtonSetCheckButtonFlag(AutoBandWindowTools.name .. "SearchRoleChan5CheckBox", true) -- Enable check button behavior
        ButtonSetPressedFlag(AutoBandWindowTools.name .. "SearchRoleChan5CheckBox", false)  -- Default unchecked

        ButtonSetText(AutoBandWindowTools.name .. "SearchRoleButton", L"Manual Search")

        LabelSetText(AutoBandWindowTools.name .. "AutoSearchLabel", L"Auto Search in /1 every 5 mins")
        ButtonSetCheckButtonFlag(AutoBandWindowTools.name .. "AutoSearchCheckBox", true)
        ButtonSetPressedFlag(AutoBandWindowTools.name .. "AutoSearchCheckBox", AutoBand.saved.autonote_enabled)

        LabelSetText(AutoBandWindowTools.name .. "AutoPartyNoteLabel", L"Auto Update /partynote for WB")
        ButtonSetCheckButtonFlag(AutoBandWindowTools.name .. "AutoPartyNoteCheckBox", true)
        ButtonSetPressedFlag(AutoBandWindowTools.name .. "AutoPartyNoteCheckBox", AutoBand.saved.autopartynote_enabled)

        ButtonSetText(AutoBandWindowTools.name .. "OrganizeButton", L"Organize WB")
        ButtonSetText(AutoBandWindowTools.name .. "OrganizeRangeButton", L"Organize WB (distance)")

        LabelSetText(AutoBandWindowTools.name .. "NotifyBuffsLabel", L"Notify WB after Organize")
        ButtonSetCheckButtonFlag(AutoBandWindowTools.name .. "NotifyBuffsCheckBox", true) -- Enable check button behavior

        LabelSetText(AutoBandWindowTools.name .. "PrintRoleLabel", L"Print Role Assignments")
        ButtonSetCheckButtonFlag(AutoBandWindowTools.name .. "PrintRoleCheckBox", true) -- Enable check button behavior

        LabelSetText(AutoBandWindowTools.name .. "AutoFormSearchLabel", L"Autoform WB if leader of party")
        ButtonSetCheckButtonFlag(AutoBandWindowTools.name .. "AutoFormSearchCheckBox", true)

        LabelSetText(AutoBandWindowTools.name .. "RightClickOrganizeLabel", L"RClick Icon to Organize")
        ButtonSetCheckButtonFlag(AutoBandWindowTools.name .. "RightClickOrganizeCheckBox", true) -- Enable check button behavior
        ButtonSetPressedFlag(AutoBandWindowTools.name .. "RightClickOrganizeCheckBox", AutoBand.saved.right_click_organize)

        LabelSetText(AutoBandWindowTools.name .. "MiddleClickOrganizeRangeLabel", L"MClick Icon to Organize (distance)")
        ButtonSetCheckButtonFlag(AutoBandWindowTools.name .. "MiddleClickOrganizeRangeCheckBox", true)
        ButtonSetPressedFlag(AutoBandWindowTools.name .. "MiddleClickOrganizeRangeCheckBox", AutoBand.saved.middle_click_organize_range)

        -- Button bar
        ButtonSetText(AutoBandWindowTools.name .. "ResetButton", L"Restore Defaults")
end


function AutoBandWindowTools.Hide()
        WindowSetShowing(AutoBandWindowTools.name, false)
end


function AutoBandWindowTools.Show()
        ButtonSetPressedFlag(AutoBandWindowTools.name .. "AutoSearchCheckBox", AutoBand.saved.autonote_enabled)
        ButtonSetPressedFlag(AutoBandWindowTools.name .. "AutoPartyNoteCheckBox", AutoBand.saved.autopartynote_enabled)
        ButtonSetPressedFlag(AutoBandWindowTools.name .. "NotifyBuffsCheckBox", AutoBand.saved.notify_buffs_enabled)
        ButtonSetPressedFlag(AutoBandWindowTools.name .. "RightClickOrganizeCheckBox", AutoBand.saved.right_click_organize)
        ButtonSetPressedFlag(AutoBandWindowTools.name .. "MiddleClickOrganizeRangeCheckBox", AutoBand.saved.middle_click_organize_range)
        ButtonSetPressedFlag(AutoBandWindowTools.name .. "PrintRoleCheckBox", AutoBand.saved.printrole_enabled)
        ButtonSetPressedFlag(AutoBandWindowTools.name .. "AutoFormSearchCheckBox", AutoBand.saved.autoform_search_enabled)
        WindowSetShowing(AutoBandWindowTools.name, true)
end


function AutoBandWindowTools.reset_kick_enabled()
        for fid, func in pairs(AutoBandWindowTools.tools_data) do
                ButtonSetPressedFlag(AutoBandWindowTools.name .. func["button"], AB_const.KICK_FUNC_DEFAULT[fid])
                AutoBand.saved.kick_func_enabled[fid] = AB_const.KICK_FUNC_DEFAULT[fid]
        end
end


function AutoBandWindowTools.OnKickOfflineCheckBox()
        AutoBand.saved.kick_func_enabled[AB_const.KICK_OFFLINE] = ButtonGetPressedFlag(AutoBandWindowTools.name .. "KickOfflineCheckBox")
end


function AutoBandWindowTools.OnKickZoneCheckBox()
        AutoBand.saved.kick_func_enabled[AB_const.KICK_ZONE] = ButtonGetPressedFlag(AutoBandWindowTools.name .. "KickZoneCheckBox")
end


function AutoBandWindowTools.OnKickRankCheckBox()
        AutoBand.saved.kick_func_enabled[AB_const.KICK_RANK] = ButtonGetPressedFlag(AutoBandWindowTools.name .. "KickRankCheckBox")
end


function AutoBandWindowTools.OnKickButton()
        for fid, kick_func in pairs(AutoBandWindowTools.tools_data) do
                -- to make sure that you read the values from check boxes
                AutoBand.saved.kick_func_enabled[fid] = ButtonGetPressedFlag(AutoBandWindowTools.name .. kick_func["button"])
                if (AutoBand.saved.kick_func_enabled[fid]) then
                        kick_func.func_kick()
                end
        end
end

function AutoBandWindowTools.OnPrintButton()
        AB_util.print("Warband Report ")
        for fid, kick_func in pairs(AutoBandWindowTools.tools_data) do
                -- to make sure that you read the values from check boxes
                AutoBand.saved.kick_func_enabled[fid] = ButtonGetPressedFlag(AutoBandWindowTools.name .. kick_func["button"])
                if (AutoBand.saved.kick_func_enabled[fid]) then
                        kick_func.func_print()
                end
        end
end

function AutoBandWindowTools.OnOrganizeButton()
  -- Call the existing command function directly
  AutoBand.cmd_organize({}) -- Pass empty args table
end

function AutoBandWindowTools.OnOrganizeRangeButton()
  AutoBand.cmd_organize({"distance"}) -- Pass "distance" as the first argument in a table
end

function AutoBandWindowTools.OnNotifyBuffsCheckBox()
  -- Call the existing command function which handles toggling and feedback
  AutoBand.cmd_toggle_buffnotify({})
end

function AutoBandWindowTools.OnRightClickOrganizeCheckBox()
  -- Call the existing command function which handles toggling and feedback
  AutoBand.cmd_toggle_rco({})
end

function AutoBandWindowTools.OnMiddleClickOrganizeRangeCheckBox()
    AutoBand.cmd_toggle_mcor({})
end

function AutoBandWindowTools.OnPrintRoleCheckBox()
  -- Call the existing command function which handles toggling and feedback
  AutoBand.cmd_flag_printrole({})
end

function AutoBandWindowTools.OnAutoFormSearchCheckBox()
    AutoBand.cmd_toggle_autoform_search({})
end

function AutoBandWindowTools.OnSearchRoleButton()
  local args = {} -- Table to hold the channel arguments

        if ButtonGetPressedFlag(AutoBandWindowTools.name .. "SearchRoleChan1CheckBox") then
                table.insert(args, "1")
        end

  if ButtonGetPressedFlag(AutoBandWindowTools.name .. "SearchRoleChanT4CheckBox") then
    table.insert(args, "t4")
  end

  if ButtonGetPressedFlag(AutoBandWindowTools.name .. "SearchRoleChan5CheckBox") then
    table.insert(args, "5")
  end

  AutoBand.cmd_search_roles(args)
end

function AutoBandWindowTools.OnAutoSearchCheckBox()
        -- Call the existing command function which toggles the setting and prints feedback
        AutoBand.cmd_flag_autonote({})
end

function AutoBandWindowTools.OnAutoPartyNoteCheckBox()
    AutoBand.cmd_toggle_partynote({})
end

function AutoBandWindowTools.OnResetTools()
    AB_util.debug(AutoBand.saved.kick_func_enabled)
    AB_util.debug(AB_const.KICK_FUNC_DEFAULT)
    AutoBandWindowTools.reset_kick_enabled()

    AutoBand.saved.autonote_enabled = AB_const.AUTONOTE
    AutoBand.saved.autopartynote_enabled = AB_const.AUTOPARTYNOTE
    AutoBand.saved.notify_buffs_enabled = true
    AutoBand.saved.right_click_organize = AB_const.RIGHTCLICKORGANIZE
    AutoBand.saved.middle_click_organize_range = AB_const.MIDDLECLICKORGANIZERANGE
    AutoBand.saved.printrole_enabled = AB_const.PRINTROLE
    AutoBand.saved.autoform_search_enabled = AB_const.AUTOFORM_SEARCH

    AB_util.print("Reset ToolsTab-settings to Default.")

    AutoBandWindowTools.Show()
end

-- Helper for labels that should trigger the original checkbox logic
function AutoBandWindowTools.GenericLabelClickHandler(checkboxRelativeName, originalCheckboxHandlerFunction)
    PlaySound(GameData.Sound.BUTTON_CLICK)
    local checkboxFullName = AutoBandWindowTools.name .. checkboxRelativeName
    ButtonSetPressedFlag(checkboxFullName, not ButtonGetPressedFlag(checkboxFullName))
    if originalCheckboxHandlerFunction then
        originalCheckboxHandlerFunction()
    end
end

-- Helper for labels that ONLY toggle the checkbox visual state (state read later by a separate button)
function AutoBandWindowTools.ToggleCheckboxVisualState(checkboxRelativeName)
    PlaySound(GameData.Sound.BUTTON_CLICK)
    local checkboxFullName = AutoBandWindowTools.name .. checkboxRelativeName
    ButtonSetPressedFlag(checkboxFullName, not ButtonGetPressedFlag(checkboxFullName))
end

-- Specific label click handlers for AutoBandWindowTools

-- Cases where label click should only toggle checkbox visual state:
function AutoBandWindowTools.OnClickSearchRoleChan1Label()
    PlaySound(GameData.Sound.BUTTON_CLICK)
    AutoBandWindowTools.ToggleCheckboxVisualState("SearchRoleChan1CheckBox")
end
function AutoBandWindowTools.OnClickSearchRoleChanT4Label()
    PlaySound(GameData.Sound.BUTTON_CLICK)
    AutoBandWindowTools.ToggleCheckboxVisualState("SearchRoleChanT4CheckBox")
end
function AutoBandWindowTools.OnClickSearchRoleChan5Label()
    PlaySound(GameData.Sound.BUTTON_CLICK)
    AutoBandWindowTools.ToggleCheckboxVisualState("SearchRoleChan5CheckBox")
end

-- Cases where label click should mimic checkbox action (toggle + call handler):
function AutoBandWindowTools.OnClickKickOfflineLabel()
    AutoBandWindowTools.GenericLabelClickHandler("KickOfflineCheckBox", AutoBandWindowTools.OnKickOfflineCheckBox)
end
function AutoBandWindowTools.OnClickKickZoneLabel()
    AutoBandWindowTools.GenericLabelClickHandler("KickZoneCheckBox", AutoBandWindowTools.OnKickZoneCheckBox)
end
function AutoBandWindowTools.OnClickKickRankLabel()
    AutoBandWindowTools.GenericLabelClickHandler("KickRankCheckBox", AutoBandWindowTools.OnKickRankCheckBox)
end

function AutoBandWindowTools.OnClickAutoSearchLabel()
    AutoBandWindowTools.GenericLabelClickHandler("AutoSearchCheckBox", AutoBandWindowTools.OnAutoSearchCheckBox)
end

function AutoBandWindowTools.OnClickAutoPartyNoteLabel()
    AutoBandWindowTools.GenericLabelClickHandler("AutoPartyNoteCheckBox", AutoBandWindowTools.OnAutoPartyNoteCheckBox)
end

function AutoBandWindowTools.OnClickNotifyBuffsLabel()
    AutoBandWindowTools.GenericLabelClickHandler("NotifyBuffsCheckBox", AutoBandWindowTools.OnNotifyBuffsCheckBox)
end

function AutoBandWindowTools.OnClickRightClickOrganizeLabel()
    AutoBandWindowTools.GenericLabelClickHandler("RightClickOrganizeCheckBox", AutoBandWindowTools.OnRightClickOrganizeCheckBox)
end

function AutoBandWindowTools.OnClickMiddleClickOrganizeRangeLabel()
    AutoBandWindowTools.GenericLabelClickHandler("MiddleClickOrganizeRangeCheckBox", AutoBandWindowTools.OnMiddleClickOrganizeRangeCheckBox)
end

function AutoBandWindowTools.OnClickPrintRoleLabel()
    AutoBandWindowTools.GenericLabelClickHandler("PrintRoleCheckBox", AutoBandWindowTools.OnPrintRoleCheckBox)
end

function AutoBandWindowTools.OnClickAutoFormSearchLabel()
    AutoBandWindowTools.GenericLabelClickHandler("AutoFormSearchCheckBox", AutoBandWindowTools.OnAutoFormSearchCheckBox)
end
