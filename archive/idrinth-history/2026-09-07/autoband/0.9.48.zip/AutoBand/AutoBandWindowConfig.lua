--
AutoBandWindowConfig = {}

AutoBandWindowConfig.name = "AutoBandWindowConfigTab"
AutoBandWindowConfig.combobox_name = AutoBandWindowConfig.name .. "ComboBox"


function AutoBandWindowConfig.Initialize()
  -- Settings: Templates
  LabelSetText(AutoBandWindowConfig.name .. "DefaultLabel", L"Default Template")
  ButtonSetText(AutoBandWindowConfig.name .. "ClearTemplateButton", L"Reset")

  AutoBandWindowConfig.refresh_default_template()

  LabelSetText(AutoBandWindowConfig.name .. "ComboBoxLabel", L"Distribution Algorithm:")
  AutoBandWindowConfig.init_combobox()
  AutoBandWindowConfig.refresh_combobox()

  -- Settings: Auto Kick for Composition
  ButtonSetCheckButtonFlag(AutoBandWindowConfig.name .. "KickCheckBox", true)

  -- Settings: Auto Kick too far
  LabelSetText(AutoBandWindowConfig.name .. "AutoKickToofarLabel", L"AKick too far")
  ButtonSetCheckButtonFlag(AutoBandWindowConfig.name .. "KickToofarCheckBox", true)
  LabelSetText(AutoBandWindowConfig.name .. "KickTimeLabel", L"Timeout") -- (min)")
  AutoBandWindowConfig.refresh_kickoff()

  -- Settings: Auto Kick Low Rank
  LabelSetText(AutoBandWindowConfig.name .. "AutoKickLowRankLabel", L"AKick below rank req")
  ButtonSetCheckButtonFlag(AutoBandWindowConfig.name .. "KickLowRankCheckBox", true)

  -- Settings: Auto Kick Stealthers
  LabelSetText(AutoBandWindowConfig.name .. "AutoKickStealthersLabel", L"AKick stealthers")
  ButtonSetCheckButtonFlag(AutoBandWindowConfig.name .. "KickStealthersCheckBox", true)

  -- Settings: Auto Kick players in non-oRVR or Cities
  LabelSetText(AutoBandWindowConfig.name .. "AutoKickRvRZonesLabel", L"AKick players in SCs")
  ButtonSetCheckButtonFlag(AutoBandWindowConfig.name .. "KickRvRZonesCheckBox", true)

  -- Settings: Treat BW/Sorc as MDPS
  LabelSetText(AutoBandWindowConfig.name .. "BWSorcAsMDPSLabel", towstring( AB_const.GetBWSorcAsMDPSLabel() ) )
  ButtonSetCheckButtonFlag(AutoBandWindowConfig.name .. "BWSorcAsMDPSCheckBox", true)

  -- Settings: Initialize Restrict Race <<
  LabelSetText(AutoBandWindowConfig.name .. "RestrictRaceLabel", towstring( AB_const.GetRestrictRaceLabel() ) )
  ButtonSetCheckButtonFlag(AutoBandWindowConfig.name .. "RestrictRaceCheckBox", true)

  -- Settings: Guild priority
  LabelSetText(AutoBandWindowConfig.name .. "GuildPriorityLabel", L"Guild priority")
  ButtonSetCheckButtonFlag(AutoBandWindowConfig.name .. "GuildPriorityCheckBox", true)

  -- Settings: AKick ignored players
  LabelSetText(AutoBandWindowConfig.name .. "KickIgnoreLabel", L"AKick ignored")
  ButtonSetCheckButtonFlag(AutoBandWindowConfig.name .. "KickIgnoreCheckBox", true)

  -- Settings: Rank requirement
  LabelSetText(AutoBandWindowConfig.name .. "RankReqLabel", L"Rank Req")
  --    LabelSetText(AutoBandWindowConfig.name .. "MinRankLabel", L"Minimum")

  -- Settings: Healer Rank requirement
  LabelSetText(AutoBandWindowConfig.name .. "HealerRankReqLabel", L"Heal Rankreq")

  -- Settings: Alt Check
  LabelSetText(AutoBandWindowConfig.name .. "AltCheckLabel", L"Alt-Spec check")
  ButtonSetCheckButtonFlag(AutoBandWindowConfig.name .. "AltCheckCheckBox", true)
  ButtonSetText(AutoBandWindowConfig.name .. "ListAltSpecButton", L"List Alt-Specs")

  -- Settings: Minimap icon
  -- LabelSetText(AutoBandWindowConfig.name .. "MapIconLabel", L"Minimap icon")
  -- ButtonSetCheckButtonFlag(AutoBandWindowConfig.name .. "MapIconCheckBox", true)
  --    ButtonSetPressedFlag(AutoBandWindowConfig.name .. "MapIconCheckBox", AutoBand.saved.displayicon)

  -- Settings: DPS Weighting
  ButtonSetCheckButtonFlag(AutoBandWindowConfig.name .. "DpsWeightingCheckBox", true)
  LabelSetText(AutoBandWindowConfig.name .. "MaxMdpsLabel", L"  Max mDPS")
  LabelSetText(AutoBandWindowConfig.name .. "MaxRdpsLabel", L"  Max rDPS")
  ButtonSetPressedFlag(AutoBandWindowConfig.name .. "DpsWeightingCheckBox", AutoBand.saved.dps_weighting_enabled)

  AutoBandWindowConfig.refresh_min_rank()
  AutoBandWindowConfig.refresh_min_rank_healer()
  AutoBandWindowConfig.refresh_dps_weights()

  LabelSetText(AutoBandWindowConfig.name .. "VersionLabel", L"v" .. towstring(AB_const.VERSION))
  AutoBandWindowConfig.refresh_autokick_label()

  -- Button bar
  ButtonSetText(AutoBandWindowConfig.name .. "ResetButton", L"Restore Defaults")
  WindowSetShowing(AutoBandWindowConfig.name .. "DisplaySeperator1", false)
  WindowSetShowing(AutoBandWindowConfig.name .. "DisplaySeperator2", true)
  WindowSetShowing(AutoBandWindowConfig.name .. "DisplaySeperator3", true)
end

function AutoBandWindowConfig.refresh_default_template()
        local clear_default = true
        local default_template = AB_const.EMPTY_TEMPLATE

        if (AutoBand.saved.default_template ~= AB_const.EMPTY_TEMPLATE) then
                clear_default = false
                default_template = AutoBand.saved.default_template
                AB_util.debug("Default is not set to automatic: " .. default_template)
        end

        LabelSetText(AutoBandWindowConfig.name .. "DefaultTemplateLabel", towstring(default_template))
        ButtonSetDisabledFlag(AutoBandWindowConfig.name .. "ClearTemplateButton", clear_default)
end


function AutoBandWindowConfig.init_combobox()
        -- reloadui combobox
        AutoBandWindowConfig.combo_items = {}
        ComboBoxClearMenuItems(AutoBandWindowConfig.combobox_name)
        -- add from templates
        for mid, mode in pairs(AB_const.ALGO_MODE) do
                ComboBoxAddMenuItem(AutoBandWindowConfig.combobox_name, towstring("(" .. mid .. ") " .. mode))
                table.insert(AutoBandWindowConfig.combo_items, "(" .. mid .. ") " .. mode)
        end
end

function AutoBandWindowConfig.refresh_combobox()
        ComboBoxSetSelectedMenuItem(AutoBandWindowConfig.combobox_name, AutoBand.saved.org_algo_mode)
end

-- return selected text
function AutoBandWindowConfig.selected_combobox()
        return tostring(ComboBoxGetSelectedText(AutoBandWindowConfig.combobox_name))
end

-- load selected algorithm
function AutoBandWindowConfig.OnSelChangedComboBox()
        local name = AutoBandWindowConfig.selected_combobox()
        local index = nil
        for i, v in ipairs(AutoBandWindowConfig.combo_items) do
                if (v == name) then
                        index = i
                        break
                end
        end
        if (index) then
                AutoBand.saved.org_algo_mode = index
                ComboBoxSetSelectedMenuItem(AutoBandWindowConfig.combobox_name, AutoBand.saved.org_algo_mode)
                AB_util.debug(AutoBand.saved.org_algo_mode)
        end
end

function AutoBandWindowConfig.Hide()
        WindowSetShowing(AutoBandWindowConfig.name, false)
end

function AutoBandWindowConfig.Show()
    AutoBandWindowConfig.refresh_default_template()
    AutoBandWindowConfig.refresh_combobox()
    AutoBandWindowConfig.refresh_min_rank()
    AutoBandWindowConfig.refresh_min_rank_healer()
    AutoBandWindowConfig.refresh_dps_weights()
    AutoBandWindowConfig.refresh_autokick_controls()
    -- ButtonSetPressedFlag(AutoBandWindowConfig.name .. "MapIconCheckBox", AutoBand.saved.displayicon)
    ButtonSetPressedFlag(AutoBandWindowConfig.name .. "GuildPriorityCheckBox", AutoBand.saved.guild_priority_enabled)
    ButtonSetPressedFlag(AutoBandWindowConfig.name .. "AltCheckCheckBox", AutoBand.saved.alt_speccheck_enabled)
    ButtonSetPressedFlag(AutoBandWindowConfig.name .. "DpsWeightingCheckBox", AutoBand.saved.dps_weighting_enabled)
    LabelSetText(AutoBandWindowConfig.name .. "BWSorcAsMDPSLabel", towstring ( AB_const.GetBWSorcAsMDPSLabel() ) )
    ButtonSetPressedFlag(AutoBandWindowConfig.name .. "BWSorcAsMDPSCheckBox", AutoBand.saved.bw_sorc_as_mdps)
    LabelSetText(AutoBandWindowConfig.name .. "RestrictRaceLabel", towstring ( AB_const.GetRestrictRaceLabel() ) )
    ButtonSetPressedFlag(AutoBandWindowConfig.name .. "RestrictRaceCheckBox", AutoBand.saved.restrict_same_race)
    AutoBandWindow.toggle_mapicon(AutoBand.saved.displayicon)
    WindowSetShowing(AutoBandWindowConfig.name, true)
end

function AutoBandWindowConfig.OnClearTemplateButton()
        if (ButtonGetDisabledFlag(AutoBandWindowConfig.name .. "ClearTemplateButton")) then
                return
        end
        AutoBand.saved.default_template = AB_const.EMPTY_TEMPLATE
        AutoBandWindowConfig.refresh_default_template()
end

function AutoBandWindowConfig.OnPressTimeMinusButton()
        AutoBand.saved.autokick_period = AutoBand.saved.autokick_period - 1
        if (AutoBand.saved.autokick_period < 0) then
                AutoBand.saved.autokick_period = AB_const.MAX_KICKOFF_TIME
        end
        LabelSetText(AutoBandWindowConfig.name .. "AutoKickTimeoutLabel", L"" .. AutoBand.saved.autokick_period)
        if AutoBand.is_wb_leader() then
                --AutoBand.enqueue_command("/wb [AutoBand] Timeout for auto kick players who are far away from leader now " .. AutoBand.saved.autokick_period .. "min")
        end
end

function AutoBandWindowConfig.OnPressTimePlusButton()
        AutoBand.saved.autokick_period = AutoBand.saved.autokick_period + 1
        if (AutoBand.saved.autokick_period > AB_const.MAX_KICKOFF_TIME) then
                AutoBand.saved.autokick_period = 0
        end
        LabelSetText(AutoBandWindowConfig.name .. "AutoKickTimeoutLabel", L"" .. AutoBand.saved.autokick_period)
        if AutoBand.is_wb_leader() then
                --AutoBand.enqueue_command("/wb [AutoBand] Timeout for auto kick players who are far away from leader now " .. AutoBand.saved.autokick_period .. "min")
        end

end

function AutoBandWindowConfig.OnPressRankMinusButton()
  AutoBand.saved.min_rank = AutoBand.saved.min_rank - 1
  if (AutoBand.saved.min_rank < 1) then
    AutoBand.saved.min_rank = AB_const.MAXIMUM_RANK
  end
  -- Ensure healer rank <= default rank
  if (AutoBand.saved.min_rank_healer > AutoBand.saved.min_rank) then
    AutoBand.saved.min_rank_healer = AutoBand.saved.min_rank
  end
  LabelSetText(AutoBandWindowConfig.name .. "MinRankValueLabel", L"" .. AutoBand.saved.min_rank)
  LabelSetText(AutoBandWindowConfig.name .. "MinHealerRankValueLabel", L"" .. AutoBand.saved.min_rank_healer)
end

function AutoBandWindowConfig.OnPressRankPlusButton()
  AutoBand.saved.min_rank = AutoBand.saved.min_rank + 1
  if (AutoBand.saved.min_rank > AB_const.MAXIMUM_RANK ) then
    AutoBand.saved.min_rank = 1
  end
  -- Ensure healer rank <= default rank
  if (AutoBand.saved.min_rank_healer > AutoBand.saved.min_rank) then
    AutoBand.saved.min_rank_healer = AutoBand.saved.min_rank
  end
  LabelSetText(AutoBandWindowConfig.name .. "MinRankValueLabel", L"" .. AutoBand.saved.min_rank)
  LabelSetText(AutoBandWindowConfig.name .. "MinHealerRankValueLabel", L"" .. AutoBand.saved.min_rank_healer)
end

function AutoBandWindowConfig.OnPressHealerRankMinusButton()
  AutoBand.saved.min_rank_healer = AutoBand.saved.min_rank_healer - 1
  if (AutoBand.saved.min_rank_healer < 1) then
    AutoBand.saved.min_rank_healer = AB_const.MAXIMUM_RANK
  end
  -- Ensure healer rank <= default rank
  if (AutoBand.saved.min_rank_healer > AutoBand.saved.min_rank) then
    AutoBand.saved.min_rank_healer = AutoBand.saved.min_rank
  end
  LabelSetText(AutoBandWindowConfig.name .. "MinHealerRankValueLabel", L"" .. AutoBand.saved.min_rank_healer)
end

function AutoBandWindowConfig.OnPressHealerRankPlusButton()
  AutoBand.saved.min_rank_healer = AutoBand.saved.min_rank_healer + 1
  if (AutoBand.saved.min_rank_healer > AB_const.MAXIMUM_RANK ) then
    AutoBand.saved.min_rank_healer = 1
  end
  -- Ensure healer rank <= default rank
  if (AutoBand.saved.min_rank_healer > AutoBand.saved.min_rank) then
    AutoBand.saved.min_rank_healer = AutoBand.saved.min_rank
  end
  LabelSetText(AutoBandWindowConfig.name .. "MinHealerRankValueLabel", L"" .. AutoBand.saved.min_rank_healer)
end

function AutoBandWindowConfig.refresh_kickoff()
        LabelSetText(AutoBandWindowConfig.name .. "AutoKickTimeoutLabel", L"" .. AutoBand.saved.autokick_period)
        ButtonSetPressedFlag(AutoBandWindowConfig.name .. "KickCheckBox", AutoBand.saved.autokick_enabled)
end

function AutoBandWindowConfig.refresh_min_rank()
        LabelSetText(AutoBandWindowConfig.name .. "MinRankValueLabel", L"" .. AutoBand.saved.min_rank)
end

function AutoBandWindowConfig.refresh_min_rank_healer()
        LabelSetText(AutoBandWindowConfig.name .. "MinHealerRankValueLabel", L"" .. AutoBand.saved.min_rank_healer)
end

function AutoBandWindowConfig.refresh_dps_weights()
  LabelSetText(AutoBandWindowConfig.name .. "MaxMdpsValueLabel", L"" .. AutoBand.saved.max_mdps)
  LabelSetText(AutoBandWindowConfig.name .. "MaxRdpsValueLabel", L"" .. AutoBand.saved.max_rdps)
  ButtonSetPressedFlag(AutoBandWindowConfig.name .. "DpsWeightingCheckBox", AutoBand.saved.dps_weighting_enabled)
end

function AutoBandWindowConfig.OnKickCheckBox()
  local enabled = ButtonGetPressedFlag(AutoBandWindowConfig.name .. "KickCheckBox")
  AutoBand.set_autokick_enabled(enabled, { skip_gui_refresh = true })
  ButtonSetPressedFlag(AutoBandWindowConfig.name .. "KickCheckBox", AutoBand.saved.autokick_enabled)
  AutoBandWindowConfig.refresh_autokick_label() -- Ensure label also updates
end

function AutoBandWindowConfig.OnKickToofarCheckBox()
        local enabled = ButtonGetPressedFlag(AutoBandWindowConfig.name .. "KickToofarCheckBox")
        AutoBand.set_autokick_toofar_enabled(enabled, { skip_gui_refresh = true })
end

function AutoBandWindowConfig.OnKickLowRankCheckBox()
  local enabled = ButtonGetPressedFlag(AutoBandWindowConfig.name .. "KickLowRankCheckBox")
  AutoBand.set_autokick_low_rank_enabled(enabled, { skip_gui_refresh = true })
end

function AutoBandWindowConfig.OnKickStealthersCheckBox()
  local enabled = ButtonGetPressedFlag(AutoBandWindowConfig.name .. "KickStealthersCheckBox")
  AutoBand.set_autokick_we_wh_enabled(enabled, { skip_gui_refresh = true })
end

function AutoBandWindowConfig.OnKickRvRZonesCheckBox()
  local enabled = ButtonGetPressedFlag(AutoBandWindowConfig.name .. "KickRvRZonesCheckBox")
  AutoBand.set_autokick_rvrzone_enabled(enabled, { skip_gui_refresh = true })
end

function AutoBandWindowConfig.OnKickIgnoreCheckBox()
    local enabled = ButtonGetPressedFlag(AutoBandWindowConfig.name .. "KickIgnoreCheckBox")
    AutoBand.set_autokick_ignorelist_enabled(enabled, { skip_gui_refresh = true })
end

function AutoBandWindowConfig.OnBWSorcAsMDPSCheckBox()
  AutoBand.cmd_toggle_bw_sorc_mdps({})
end

function AutoBandWindowConfig.OnRestrictRaceCheckBox()
  AutoBand.cmd_toggle_restrict_race({})
end

function AutoBandWindowConfig.OnDpsWeightingCheckBox()
  AutoBand.cmd_toggle_dps_weighting({})
end

function AutoBandWindowConfig.OnPressMaxMdpsPlusButton()
  if AutoBand.saved.max_mdps < AutoBand.saved.max_dps then
    local new_mdps = AutoBand.saved.max_mdps + 1
    local new_rdps = AutoBand.saved.max_dps - new_mdps
    if new_rdps < 0 then -- Prevent rdps from becoming negative
      new_rdps = 0
      new_mdps = AutoBand.saved.max_dps -- MDPS takes all remaining
    end
    AutoBand.cmd_set_dps_weights({tostring(new_mdps), tostring(new_rdps)}, true) -- Pass true for called_from_gui
  else
    -- Optional: AB_util.print("[Info] Max mDPS cannot exceed total Max DPS.")
    AutoBandWindowConfig.refresh_dps_weights() -- Refresh to show current valid state
  end
end

function AutoBandWindowConfig.OnPressMaxMdpsMinusButton()
  local new_mdps = AutoBand.saved.max_mdps - 1
  if new_mdps >= 0 then
    local new_rdps = AutoBand.saved.max_dps - new_mdps
    AutoBand.cmd_set_dps_weights({tostring(new_mdps), tostring(new_rdps)}, true) -- Pass true
  else
    -- AB_util.print("[Info] Max mDPS is already 0.")
    AutoBandWindowConfig.refresh_dps_weights()
  end
end

function AutoBandWindowConfig.OnPressMaxRdpsPlusButton()
  if AutoBand.saved.max_rdps < AutoBand.saved.max_dps then
    local new_rdps = AutoBand.saved.max_rdps + 1
    local new_mdps = AutoBand.saved.max_dps - new_rdps
    if new_mdps < 0 then -- Prevent mdps from becoming negative
      new_mdps = 0
      new_rdps = AutoBand.saved.max_dps -- RDPS takes all remaining
    end
    AutoBand.cmd_set_dps_weights({tostring(new_mdps), tostring(new_rdps)}, true) -- Pass true
  else
    -- AB_util.print("[Info] Max rDPS cannot exceed total Max DPS.")
    AutoBandWindowConfig.refresh_dps_weights()
  end
end

function AutoBandWindowConfig.OnPressMaxRdpsMinusButton()
  local new_rdps = AutoBand.saved.max_rdps - 1
  if new_rdps >= 0 then
    local new_mdps = AutoBand.saved.max_dps - new_rdps
    AutoBand.cmd_set_dps_weights({tostring(new_mdps), tostring(new_rdps)}, true) -- Pass true
  else
    -- AB_util.print("[Info] Max rDPS is already 0.")
    AutoBandWindowConfig.refresh_dps_weights()
  end
end

function AutoBandWindowConfig.OnResetConfig()
        AutoBand.saved.autokick_enabled = AB_const.AUTOKICK
        AutoBand.saved.autokick_period = AB_const.KICK_PERIOD
        AutoBand.saved.autokick_toofar_enabled = AB_const.AUTOKICKTOOFAR
        AutoBand.saved.autokick_low_rank_enabled = AB_const.KICKLOWRNK
        AutoBand.saved.max_tanks = AB_const.DEFAULT_MAX_TANKS
        AutoBand.saved.max_healers = AB_const.DEFAULT_MAX_HEALERS
        AutoBand.saved.max_dps = AB_const.DEFAULT_MAX_DPS
        AutoBand.saved.guild_priority_enabled = AB_const.GUILDPRIORITY
        AutoBand.saved.default_template = AB_const.EMPTY_TEMPLATE
        AutoBand.saved.org_algo_mode = AB_const.DEFAULT_ORG_ALGO
        AutoBand.saved.min_rank = AB_const.MINIMUM_RANK
        AutoBand.saved.min_rank_healer = AB_const.MINIMUM_RANK_HEALER
        AutoBand.saved.displayicon = AutoBand.saved.displayicon
        AutoBand.saved.alt_speccheck_enabled = AB_const.ALTCHECK
        AutoBand.saved.dps_weighting_enabled = AB_const.DPS_WEIGHTING_ENABLED
        AutoBand.saved.max_mdps = AB_const.DEFAULT_MAX_MDPS
        AutoBand.saved.max_rdps = AB_const.DEFAULT_MAX_RDPS
        AutoBand.saved.autokick_we_wh_enabled = AB_const.AUTOKICK_WE_WH
        AutoBand.saved.autokick_rvrzone_enabled = AB_const.AUTOKICKRVRZONE
        AutoBand.saved.bw_sorc_as_mdps = AB_const.BW_SORC_AS_MDPS
        AutoBand.saved.restrict_same_race = AB_const.RESTRICT_RACE
        AutoBand.saved.autokick_ignorelist_enabled = AB_const.AUTOKICK_IGNORELIST
        AutoBandWindowConfig.refresh_autokick_label()
        AB_util.print("Reset ConfigTab-settings to Default.")
        AutoBandWindowConfig.Show()

        if AutoBandWindowTemplate and AutoBandWindowTemplate.refresh_role_limits then
            AutoBandWindowTemplate.refresh_role_limits()
        end
end

function AutoBandWindowConfig.OnAltCheckCheckBox()
        AutoBand.saved.alt_speccheck_enabled = ButtonGetPressedFlag(AutoBandWindowConfig.name .. "AltCheckCheckBox")
        AB_util.print("Use alt spec check: " .. tostring(AutoBand.saved.alt_speccheck_enabled))
end

function AutoBandWindowConfig.OnListAltSpecButton()
  PlaySound(GameData.Sound.BUTTON_CLICK)
  AutoBand.cmd_list_alt_specs({})
end

-- function AutoBandWindowConfig.OnMapIconCheckBox()
--      AutoBandWindow.toggle_mapicon(ButtonGetPressedFlag(AutoBandWindowConfig.name .. "MapIconCheckBox"))
-- end

function AutoBandWindowConfig.OnGuildPriorityCheckBox()
        AutoBand.saved.guild_priority_enabled = ButtonGetPressedFlag(AutoBandWindowConfig.name .. "GuildPriorityCheckBox")
        AB_util.print("Guild priority for auto-kick: " .. tostring(AutoBand.saved.guild_priority_enabled))
end

function AutoBandWindowConfig.refresh_autokick_label()
    -- Construct the dynamic composition part first
    local composition_string = towstring(AutoBand.saved.max_tanks) .. L"-" .. towstring(AutoBand.saved.max_healers) .. L"-" .. towstring(AutoBand.saved.max_dps)
    -- Update Auto Kick Label
    local autokick_label_text = L"Auto enforce " .. composition_string .. L" WB"
    LabelSetText(AutoBandWindowConfig.name .. "AutoKickLabel", autokick_label_text)
    -- Update DPS Weighting Label (Added)
    local dpsweight_label_text = L"DPS Weight when " .. composition_string .. L":"
    LabelSetText(AutoBandWindowConfig.name .. "DpsWeightingLabel", dpsweight_label_text)
    -- Also refresh the checkbox state
    ButtonSetPressedFlag(AutoBandWindowConfig.name .. "KickCheckBox", AutoBand.saved.autokick_enabled)
end

function AutoBandWindowConfig.refresh_autokick_controls()
    AutoBandWindowConfig.refresh_kickoff()
    AutoBandWindowConfig.refresh_autokick_label()
    ButtonSetPressedFlag(AutoBandWindowConfig.name .. "KickToofarCheckBox", AutoBand.saved.autokick_toofar_enabled)
    ButtonSetPressedFlag(AutoBandWindowConfig.name .. "KickLowRankCheckBox", AutoBand.saved.autokick_low_rank_enabled)
    ButtonSetPressedFlag(AutoBandWindowConfig.name .. "KickStealthersCheckBox", AutoBand.saved.autokick_we_wh_enabled)
    ButtonSetPressedFlag(AutoBandWindowConfig.name .. "KickRvRZonesCheckBox", AutoBand.saved.autokick_rvrzone_enabled)
    ButtonSetPressedFlag(AutoBandWindowConfig.name .. "KickIgnoreCheckBox", AutoBand.saved.autokick_ignorelist_enabled)
end

-- Helper function to be called by label click handlers
function AutoBandWindowConfig.GenericLabelClickHandler(checkboxRelativeName, originalCheckboxHandlerFunction)
    local checkboxFullName = AutoBandWindowConfig.name .. checkboxRelativeName
    PlaySound(GameData.Sound.BUTTON_CLICK)
    -- 1. Toggle the checkbox's visual state
    ButtonSetPressedFlag(checkboxFullName, not ButtonGetPressedFlag(checkboxFullName))
    -- 2. Call the original handler function that the checkbox itself uses
    if originalCheckboxHandlerFunction then
        originalCheckboxHandlerFunction()
    end
end

-- Specific label click handlers
function AutoBandWindowConfig.OnClickAutoKickLabel()
    AutoBandWindowConfig.GenericLabelClickHandler("KickCheckBox", AutoBandWindowConfig.OnKickCheckBox)
end

function AutoBandWindowConfig.OnClickDpsWeightingLabel()
    AutoBandWindowConfig.GenericLabelClickHandler("DpsWeightingCheckBox", AutoBandWindowConfig.OnDpsWeightingCheckBox)
end

function AutoBandWindowConfig.OnClickKickToofarLabel()
    AutoBandWindowConfig.GenericLabelClickHandler("KickToofarCheckBox", AutoBandWindowConfig.OnKickToofarCheckBox)
end

function AutoBandWindowConfig.OnClickKickLowRankLabel()
    AutoBandWindowConfig.GenericLabelClickHandler("KickLowRankCheckBox", AutoBandWindowConfig.OnKickLowRankCheckBox)
end

function AutoBandWindowConfig.OnClickKickStealthersLabel()
    AutoBandWindowConfig.GenericLabelClickHandler("KickStealthersCheckBox", AutoBandWindowConfig.OnKickStealthersCheckBox)
end

function AutoBandWindowConfig.OnClickKickRvRZonesLabel()
    AutoBandWindowConfig.GenericLabelClickHandler("KickRvRZonesCheckBox", AutoBandWindowConfig.OnKickRvRZonesCheckBox)
end

function AutoBandWindowConfig.OnClickBWSorcAsMDPSLabel()
    AutoBandWindowConfig.GenericLabelClickHandler("BWSorcAsMDPSCheckBox", AutoBandWindowConfig.OnBWSorcAsMDPSCheckBox)
end

function AutoBandWindowConfig.OnClickRestrictRaceLabel()
    AutoBandWindowConfig.GenericLabelClickHandler("RestrictRaceCheckBox", AutoBandWindowConfig.OnRestrictRaceCheckBox)
end

function AutoBandWindowConfig.OnClickAltCheckLabel()
    AutoBandWindowConfig.GenericLabelClickHandler("AltCheckCheckBox", AutoBandWindowConfig.OnAltCheckCheckBox)
end

function AutoBandWindowConfig.OnClickGuildPriorityLabel()
    AutoBandWindowConfig.GenericLabelClickHandler("GuildPriorityCheckBox", AutoBandWindowConfig.OnGuildPriorityCheckBox)
end

function AutoBandWindowConfig.OnClickKickIgnoreLabel()
    AutoBandWindowConfig.GenericLabelClickHandler("KickIgnoreCheckBox", AutoBandWindowConfig.OnKickIgnoreCheckBox)
end
