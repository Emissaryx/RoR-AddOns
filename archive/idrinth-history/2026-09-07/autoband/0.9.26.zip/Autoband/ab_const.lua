-- ab_const.lua
-- The constants

AB_const = {}
AB_const.VERSION = "0.9.26"

AB_const.DEFAULT_PREFIX_TEXT = "AutoBand"
AB_const.MAX_PREFIX_LENGTH = 20
AB_const.DEFAULT_PREFIX_COLOR_NAME = "cyan"
AB_const.DEFAULT_LEAD_COLOR_NAME = "red"

-- Complete AB_const color palette
-- Primary and neutral colors
AB_const.COLOR_WHITE     = { 255, 255, 255 }
AB_const.COLOR_GRAY      = { 128, 128, 128 }
AB_const.COLOR_SILVER    = { 192, 192, 192 }
-- Legacy palette
AB_const.COLOR_CYAN      = { 0, 255, 255 }
AB_const.COLOR_GREEN     = { 0, 255, 0 }
AB_const.COLOR_MAGENTA   = { 255, 0, 255 }
AB_const.COLOR_RED       = { 255, 0, 0 }
AB_const.COLOR_YELLOW    = { 255, 255, 0 }
AB_const.COLOR_ORANGE    = { 255, 128, 0 }
AB_const.COLOR_LIME      = { 128, 255, 0 }
AB_const.COLOR_TEAL      = { 0, 128, 128 }
AB_const.COLOR_PINK      = { 255, 192, 203 }
AB_const.COLOR_BROWN     = { 150, 75, 0 }
AB_const.COLOR_TAN       = { 210, 180, 140 }
-- Premium / accent hues
AB_const.COLOR_GOLD      = { 255, 215, 0 }
AB_const.COLOR_GOLDENROD = { 218, 165, 32 }
AB_const.COLOR_CRIMSON   = { 220, 20, 60 }
AB_const.COLOR_SALMON    = { 250, 128, 114 }
-- Soft pastels
AB_const.COLOR_SKY       = { 135, 206, 235 }
AB_const.COLOR_TURQUOISE = { 64, 224, 208 }
AB_const.COLOR_MINT      = { 189, 252, 201 }

-- Consolidated lookup table
AB_const.AVAILABLE_COLORS = {
    ["brown"]     = AB_const.COLOR_BROWN,
    ["cyan"]      = AB_const.COLOR_CYAN,
    ["crimson"]   = AB_const.COLOR_CRIMSON,
    ["gold"]      = AB_const.COLOR_GOLD,
    ["goldenrod"] = AB_const.COLOR_GOLDENROD,
    ["gray"]      = AB_const.COLOR_GRAY,
    ["green"]     = AB_const.COLOR_GREEN,
    ["lime"]      = AB_const.COLOR_LIME,
    ["magenta"]   = AB_const.COLOR_MAGENTA,
    ["mint"]      = AB_const.COLOR_MINT,
    ["orange"]    = AB_const.COLOR_ORANGE,
    ["pink"]      = AB_const.COLOR_PINK,
    ["red"]       = AB_const.COLOR_RED,
    ["salmon"]    = AB_const.COLOR_SALMON,
    ["silver"]    = AB_const.COLOR_SILVER,
    ["sky"]       = AB_const.COLOR_SKY,
	["tan"]       = AB_const.COLOR_TAN,
    ["teal"]      = AB_const.COLOR_TEAL,
    ["turquoise"] = AB_const.COLOR_TURQUOISE,
    ["white"]     = AB_const.COLOR_WHITE,
    ["yellow"]    = AB_const.COLOR_YELLOW,
}
AB_const.AVAILABLE_COLOR_NAMES_SORTED = nil

AB_const.GROUP_SIZE = 6
AB_const.MAX_WB_GROUPS = 4
AB_const.MAX_DPS_TOTAL = 8
AB_const.HEARTBEAT = 5            -- period in seconds
AB_const.KICK_PERIOD = 5          -- number of HEARTBEATs someone can go offline, after that they will be kicked off
AB_const.DEFAULT_CMD_TICKS = 1    -- default number of ticks a command must wait to be executed
AB_const.AUTOKICK = false
AB_const.AUTOKICKTOOFAR = false
AB_const.AUTOKICK_WE_WH = false
AB_const.AUTOKICKRVRZONE = false
AB_const.GUILDPRIORITY = false 
AB_const.ALTCHECK = true
AB_const.PRINTROLE = true
AB_const.AUTONOTE = false
AB_const.KICKLOWRNK = true
AB_const.DPS_WEIGHTING_ENABLED = false
AB_const.DEFAULT_MAX_MDPS = 4
AB_const.DEFAULT_MAX_RDPS = 4
AB_const.RIGHTCLICKORGANIZE = false

AB_const.EMPTY_TEMPLATE = "<Automatic>" -- name of the automatic template
AB_const.EMPTY_WB_TEMPLATE = { [1] = {}, [2] = {}, [3] = {}, [4] = {} }

AB_const.MINIMUM_RANK = 16
AB_const.MINIMUM_RANK_HEALER = 16
AB_const.MAXIMUM_RANK = 40
AB_const.ABBREVATIONS = { ["LEADER"] = "L", ["ASSISTANT"] = "A" }

AB_const.HEALER = "healer"
AB_const.TANK = "tank"
AB_const.MDPS = "mdps"
AB_const.RDPS = "rdps"

-- Define Factions
AB_const.ORDER = "Order"
AB_const.DESTRUCTION = "Destruction"

-- Define Races
AB_const.DWARFS = "Dawi"
AB_const.EMPIRE = "Empire"
AB_const.HIGHELVES = "Asur"
AB_const.CHAOS = "Chaos"
AB_const.DARKELVES = "Druchii"
AB_const.GREENSKINS = "Greenskins"

AB_const.WARBAND_PURPOSES = {
    ["sieging"] = { display = "Sieging", description = "Attacking keeps/BOs" },
    ["defending"] = { display = "Defending", description = "Defending keeps/BOs" },
	["ranking"] = { display = "Ranking keep", description = "Ranking up keep" },
    ["roaming"] = { display = "Roaming", description = "Open RvR roaming" },
    ["city"] = { display = "City Siege", description = "Running city siege" },
    ["lotd"] = { display = "LotD", description = "Land of the Dead event" },
	["ch22"] = { display = "Chap22", description = "Chapter22 public events" },
	["fort"] = { display = "Fortress", description = "Fortress battle" },
}

AB_const.PURPOSE_ALIASES = {
    -- Sieging
    ["sieging"] = "sieging",
	["siegeing"] = "sieging",
	["siege"] = "sieging",
    ["attack"] = "sieging",
	["attacking"] = "sieging",
    ["ram"] = "sieging",
	["ramming"] = "sieging",
    -- Defending
    ["defending"] = "defending",
    ["defend"] = "defending",
    ["defence"] = "defending",
	["defense"] = "defending",
	["def"] = "defending",
    -- Roaming
    ["roaming"] = "roaming",
    ["roam"] = "roaming",
    ["kill"] = "roaming",
	["kills"] = "roaming",
    ["killing"] = "roaming",
    -- City Siege
    ["city"] = "city",
    ["citysiege"] = "city",
    -- Land of the Dead
    ["lotd"] = "lotd",
    ["land"] = "lotd",
    ["dead"] = "lotd",
	-- Chapter22
	["ch22"] = "ch22",
	["chap22"] = "ch22",
	["chapter22"] = "ch22",
	["c22"] = "ch22",
	-- Ranking
	["ranking"] = "ranking",
	["boxing"] = "ranking",
	["boxes"] = "ranking",
	["box"] = "ranking",
	["boxrunning"] = "ranking",
	["supplies"] = "ranking",	
	["supply"] = "ranking",	
	["supplyrunning"] = "ranking",
	["running"] = "ranking",
	-- fort
	["fort"] = "fort",
	["fortress"] = "fort",
}

function AB_const.GetPurposeNames()
    local names = {}
    for key, _ in pairs(AB_const.WARBAND_PURPOSES) do
        table.insert(names, key)
    end
    table.sort(names)
    return table.concat(names, "|")
end

AB_const.HEADER_MARGIN = "==="

AB_const.CAREERLINE_MAP = {
    [GameData.CareerLine.ENGINEER]        = AB_const.RDPS,
    [GameData.CareerLine.BRIGHT_WIZARD]   = AB_const.RDPS,
    [GameData.CareerLine.SORCERER]        = AB_const.RDPS,
    [GameData.CareerLine.SQUIG_HERDER]    = AB_const.RDPS,
    [GameData.CareerLine.MAGUS]           = AB_const.RDPS,
    [GameData.CareerLine.SHADOW_WARRIOR]  = AB_const.RDPS,

    [GameData.CareerLine.WITCH_ELF]       = AB_const.MDPS,
    [GameData.CareerLine.WHITE_LION]      = AB_const.MDPS,
    [GameData.CareerLine.SLAYER]          = AB_const.MDPS,
    [GameData.CareerLine.WITCH_HUNTER]    = AB_const.MDPS,
    [GameData.CareerLine.CHOPPA]          = AB_const.MDPS,
    [GameData.CareerLine.MARAUDER]        = AB_const.MDPS,

    [GameData.CareerLine.IRON_BREAKER]    = AB_const.TANK,
    [GameData.CareerLine.CHOSEN]          = AB_const.TANK,
    [GameData.CareerLine.BLACK_ORC]       = AB_const.TANK,
    [GameData.CareerLine.KNIGHT]          = AB_const.TANK,
    [GameData.CareerLine.SWORDMASTER]     = AB_const.TANK,
    [GameData.CareerLine.BLACKGUARD]      = AB_const.TANK,

    [GameData.CareerLine.ZEALOT]          = AB_const.HEALER,
    [GameData.CareerLine.WARRIOR_PRIEST]  = AB_const.HEALER,
    [GameData.CareerLine.RUNE_PRIEST]     = AB_const.HEALER,
    [GameData.CareerLine.ARCHMAGE]        = AB_const.HEALER,
    [GameData.CareerLine.SHAMAN]          = AB_const.HEALER,
    [GameData.CareerLine.DISCIPLE]        = AB_const.HEALER
}

AB_const.CAREERLINE_RACEMAP = {
    [GameData.CareerLine.ENGINEER]        = AB_const.DWARFS,
    [GameData.CareerLine.BRIGHT_WIZARD]   = AB_const.EMPIRE,
    [GameData.CareerLine.SORCERER]        = AB_const.DARKELVES,
    [GameData.CareerLine.SQUIG_HERDER]    = AB_const.GREENSKINS,
    [GameData.CareerLine.MAGUS]           = AB_const.CHAOS,
    [GameData.CareerLine.SHADOW_WARRIOR]  = AB_const.HIGHELVES,

    [GameData.CareerLine.WITCH_ELF]       = AB_const.DARKELVES,
    [GameData.CareerLine.WHITE_LION]      = AB_const.HIGHELVES,
    [GameData.CareerLine.SLAYER]          = AB_const.DWARFS,
    [GameData.CareerLine.WITCH_HUNTER]    = AB_const.EMPIRE,
    [GameData.CareerLine.CHOPPA]          = AB_const.GREENSKINS,
    [GameData.CareerLine.MARAUDER]        = AB_const.CHAOS,

    [GameData.CareerLine.IRON_BREAKER]    = AB_const.DWARFS,
    [GameData.CareerLine.CHOSEN]          = AB_const.CHAOS,
    [GameData.CareerLine.BLACK_ORC]       = AB_const.GREENSKINS,
    [GameData.CareerLine.KNIGHT]          = AB_const.EMPIRE,
    [GameData.CareerLine.SWORDMASTER]     = AB_const.HIGHELVES,
    [GameData.CareerLine.BLACKGUARD]      = AB_const.DARKELVES,

    [GameData.CareerLine.ZEALOT]          = AB_const.CHAOS,
    [GameData.CareerLine.WARRIOR_PRIEST]  = AB_const.EMPIRE,
    [GameData.CareerLine.RUNE_PRIEST]     = AB_const.DWARFS,
    [GameData.CareerLine.ARCHMAGE]        = AB_const.HIGHELVES,
    [GameData.CareerLine.SHAMAN]          = AB_const.GREENSKINS,
    [GameData.CareerLine.DISCIPLE]        = AB_const.DARKELVES
}

AB_const.CAREERLINE_FACTIONMAP = {
    [GameData.CareerLine.ENGINEER]        = AB_const.ORDER,
    [GameData.CareerLine.BRIGHT_WIZARD]   = AB_const.ORDER,
    [GameData.CareerLine.SORCERER]        = AB_const.DESTRUCTION,
    [GameData.CareerLine.SQUIG_HERDER]    = AB_const.DESTRUCTION,
    [GameData.CareerLine.MAGUS]           = AB_const.DESTRUCTION,
    [GameData.CareerLine.SHADOW_WARRIOR]  = AB_const.ORDER,

    [GameData.CareerLine.WITCH_ELF]       = AB_const.DESTRUCTION,
    [GameData.CareerLine.WHITE_LION]      = AB_const.ORDER,
    [GameData.CareerLine.SLAYER]          = AB_const.ORDER,
    [GameData.CareerLine.WITCH_HUNTER]    = AB_const.ORDER,
    [GameData.CareerLine.CHOPPA]          = AB_const.DESTRUCTION,
    [GameData.CareerLine.MARAUDER]        = AB_const.DESTRUCTION,

    [GameData.CareerLine.IRON_BREAKER]    = AB_const.ORDER,
    [GameData.CareerLine.CHOSEN]          = AB_const.DESTRUCTION,
    [GameData.CareerLine.BLACK_ORC]       = AB_const.DESTRUCTION,
    [GameData.CareerLine.KNIGHT]          = AB_const.ORDER,
    [GameData.CareerLine.SWORDMASTER]     = AB_const.ORDER,
    [GameData.CareerLine.BLACKGUARD]      = AB_const.DESTRUCTION,

    [GameData.CareerLine.ZEALOT]          = AB_const.DESTRUCTION,
    [GameData.CareerLine.WARRIOR_PRIEST]  = AB_const.ORDER,
    [GameData.CareerLine.RUNE_PRIEST]     = AB_const.ORDER,
    [GameData.CareerLine.ARCHMAGE]        = AB_const.ORDER,
    [GameData.CareerLine.SHAMAN]          = AB_const.DESTRUCTION,
    [GameData.CareerLine.DISCIPLE]        = AB_const.DESTRUCTION
}

AB_const.FAKE_PLAYERS = {
    [AB_const.HEALER] = {
        ["careerLine"] = GameData.CareerLine.ZEALOT,
        ["online"] = true
    },
    [AB_const.TANK] = {
        ["careerLine"] = GameData.CareerLine.CHOSEN,
        ["online"] = true
    },
    [AB_const.MDPS] = {
        ["careerLine"] = GameData.CareerLine.CHOPPA,
        ["online"] = true
    },
    [AB_const.RDPS] = {
        ["careerLine"] = GameData.CareerLine.SORCERER,
        ["online"] = true
    }
}

AB_const.ROLE_CATEGORIES = {
    [AB_const.HEALER] = 1,
    [AB_const.TANK]   = 2,
    [AB_const.MDPS]   = 3,
    [AB_const.RDPS]   = 4
}

AB_const.MODE_SPREAD = 1
AB_const.MODE_AGGREGATE = 2
AB_const.ALGO_MODE = {
    [AB_const.MODE_SPREAD]    = "Spread categories",
    [AB_const.MODE_AGGREGATE] = "Aggregate categories"
}

AB_const.DEFAULT_ORG_ALGO = AB_const.MODE_SPREAD -- distributing equally
AB_const.DEFAULT_ORG_ROLE = AB_const.HEALER
AB_const.LOOP_MAX = 100

AB_const.TABS_TEMPLATE = 1
AB_const.TABS_TOOLS = 2
AB_const.TABS_CONFIG = 3
-- AB_const.TABS_HISTORY = 4

AB_const.LABEL_EMPTY = "---"
AB_const.LABEL_ROLE_COLORS = {
    [AB_const.HEALER]     = { 0, 210, 0 },
    [AB_const.TANK]       = { 0, 0, 210 },
    [AB_const.MDPS]       = { 210, 0, 0 },
    [AB_const.RDPS]       = { 210, 0, 210 },
    [AB_const.LABEL_EMPTY]= { 210, 210, 210 }
}
AB_const.LABEL_ROLE_CATEGORIES = {
    [AB_const.HEALER]      = 1,
    [AB_const.TANK]        = 2,
    [AB_const.MDPS]        = 3,
    [AB_const.RDPS]        = 4,
    [AB_const.LABEL_EMPTY] = 5
}
AB_const.LABEL_ROLE_CATEGORIES_REV = {
    AB_const.HEALER,
    AB_const.TANK,
    AB_const.MDPS,
    AB_const.RDPS,
    AB_const.LABEL_EMPTY
}

-- Define icon variables
AB_const.ICONS = {
    tank   = "<icon22702>",
    healer = "<icon22706>",
    mdps   = "<icon22701>",
    rdps   = "<icon22703>",
    dps    = "<icon22701>",
	we     = "<icon20201>",
	wh     = "<icon20202>",
	prefix = "<icon44> ",
	suffix = " <icon44>"
}

AB_const.CURRENT_WB = "<Warband>"
AB_const.MAX_KICKOFF_TIME = 9
AB_const.LABEL_NOTSAMEZONE = "Players not in leader's / assistants' zone"

AB_const.KICK_OFFLINE = 1
AB_const.KICK_ZONE = 2
AB_const.KICK_RANK = 3

AB_const.LABEL_KICK = {
    [AB_const.KICK_OFFLINE] = "too far",
    [AB_const.KICK_ZONE]    = "not in leader's / assistants' zone",
    [AB_const.KICK_RANK]    = "low rank"
}

AB_const.KICK_FUNC_DEFAULT = {
    [AB_const.KICK_OFFLINE] = false,
    [AB_const.KICK_ZONE]    = false,
    [AB_const.KICK_RANK]    = false
}

AB_const.ZONEIDS = {
	--Dwarfs vs Greenskins
	6, -- "Ekrund"
	11, -- "Mount Bloodhorn"
	7, -- "Barak Varr"
	1, -- "Marshes of Madness"
	2, -- "The Badlands"
	8, -- "Black Fire Pass"
	9, -- "Kadrin Valley"
	5, -- "Thunder Mountain"
	3, -- "Black Crag"

	-- Forts
	4, -- "Butcher's Pass"
	10, -- "Stonewatch"

	--Chaos vs Empire
	100, -- "Norsca"
	106, -- "Nordland"
	107, -- "Ostland"
	101, -- "Troll Country"
	102, -- "High Pass"
	108, -- "Talabecland"
	103, -- "Chaos Wastes"
	105, -- "Praag"
	109, -- "Reikland"

	-- Forts
	104, -- "The Maw"
	110, -- "Reikwald"

	--Cities
	61, -- "Karak Eight Peaks"
	96, -- "Karak Eight Peaks Da Deeps"
	62, -- "Karaz-a-Karak"
	68, -- "Karaz-a-Karak"
	97, -- "Karaz-a-Karak Middle Deeps"
	161, -- "The Inevitable City"
	162, -- "Altdorf"
	170, -- "Altdorf Palace"
	172, -- "The Eternal Citadel"
	178, -- "The Viper Pit"
	198, -- "Sigmar's Hammer"

	--Land of the Dead
	191, -- "Necropolis of Zandri"
	413, -- "Garden of Qu'aph"

	--High Elves vs Dark Elves
	200, -- "The Blighted Isle"
	206, -- "Chrace"
	201, -- "The Shadowlands"
	207, -- "Ellyrion"
	202, -- "Avelorn"
	208, -- "Saphery"
	203, -- "Caledor"
	205, -- "Dragonwake"
	209, -- "Eataine"

	-- Forts
	204, -- "Fell Landing"
	210, -- "Shining Way"
};

function AB_const.GetFormattedPrefixRaw(includeSpace)
    local prefix_text = AutoBand.saved.prefix_text or AB_const.DEFAULT_PREFIX_TEXT
    local color_name = AutoBand.saved.prefix_color_name or AB_const.DEFAULT_PREFIX_COLOR_NAME
    local color_rgb = AB_const.AVAILABLE_COLORS[color_name] or AB_const.AVAILABLE_COLORS[AB_const.DEFAULT_PREFIX_COLOR_NAME]
    local r, g, b = color_rgb[1], color_rgb[2], color_rgb[3]

    -- Construct the <LINK> tag for the colored text part
    local coloredPart = string.format("<LINK data=\"0\" color=\"%d,%d,%d\" text=\"%s\">", r, g, b, prefix_text)
    -- Combine with non-colored brackets
    local prefix = "[" .. coloredPart .. "]"
    if includeSpace then
        prefix = prefix .. " "
    end
    return prefix
end

-- Helper function to generate the formatted prefix string (wstring for EA_ChatWindow.Print)
-- Now uses the saved settings
function AB_const.GetFormattedPrefixWString(includeSpace)
    local prefix_text = AutoBand.saved.prefix_text or AB_const.DEFAULT_PREFIX_TEXT
    local color_name = AutoBand.saved.prefix_color_name or AB_const.DEFAULT_PREFIX_COLOR_NAME
    local color_rgb = AB_const.AVAILABLE_COLORS[color_name] or AB_const.AVAILABLE_COLORS[AB_const.DEFAULT_PREFIX_COLOR_NAME]
    local r, g, b = color_rgb[1], color_rgb[2], color_rgb[3]

    -- Construct the <LINK> tag for the colored text part (as a standard Lua string first)
    local coloredPartRaw = string.format("<LINK data=\"0\" color=\"%d,%d,%d\" text=\"%s\">", r, g, b, prefix_text)
    -- Combine with non-colored brackets using wstring concatenation
    local prefix = L"[" .. towstring(coloredPartRaw) .. L"]"
    if includeSpace then
        prefix = prefix .. L" "
    end
    return prefix
end