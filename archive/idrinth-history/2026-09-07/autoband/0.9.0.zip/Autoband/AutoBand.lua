-- AutoBand.lua

AutoBand = {}
tanks_t_old = {}
healers_t_old = {}
dps_t_old = {}
--wh_t_old = {}
toofar = {}
toofar_old = {}
toofar_not_changed = {}
warned = {}
number = 0
number2 = 12
g_m = {}
ign = {}
guild_members = {}

--tanks, healers, dpss = 0, 0, 0

local MAX_MAP_POINTS = 511
local DISTANCE_FIX_COEFFICIENT = 1 / 1.06
local MapPointTypeFilter = {
	[SystemData.MapPips.PLAYER] = true,
	[SystemData.MapPips.GROUP_MEMBER] = true,
	[SystemData.MapPips.WARBAND_MEMBER] = true,
	[SystemData.MapPips.DESTRUCTION_ARMY] = true,
	[SystemData.MapPips.ORDER_ARMY] = true
}

function AutoBand.init()
	AutoBand.cmd_queue = {}				-- global command queue
	AutoBand.cmd_current = nil			-- current queue command to be executed
	AutoBand.debugon = false			-- debug flag
	AutoBand.gizilon = false			-- gizil debug flag
	AutoBand.offliners_countdown = {}	-- offline players and their remaining time
	AutoBand.has_shortslash = false		-- true if we can register /ab
	AutoBand.elapsed = 0				-- elapsed update time
	--AutoBand.elapsed2 = 0				-- elapsed update time

	-- persistent data
	AutoBand.saved = AutoBand.saved or {}

	if (AutoBand.saved.autokick_enabled == nil) then
		AutoBand.saved.autokick_enabled = AB_const.AUTOKICK	-- auto kick flag
	end
	if (AutoBand.saved.autokick_toofar_enabled == nil) then
		AutoBand.saved.autokick_toofar_enabled = AB_const.AUTOKICKTOOFAR	-- auto kick flag
	end
	if (AutoBand.saved.autonote_enabled == nil) then
		AutoBand.saved.autonote_enabled = AB_const.AUTONOTE	-- auto note flag
	end
	AutoBand.saved.autokick_period = AutoBand.saved.autokick_period or AB_const.KICK_PERIOD
	AutoBand.saved.min_rank = AutoBand.saved.min_rank or AB_const.MINIMUM_RANK
	AutoBand.saved.default_template = AutoBand.saved.default_template or AB_const.EMPTY_TEMPLATE	-- default template to be applied
	AutoBand.saved.templates = AutoBand.saved.templates or {}

	--[[ DEBUG PURPOSES ]]--
	AutoBand.saved.dumps = AutoBand.saved.dumps or {}
	AutoBand.saved.dumped_wb = AutoBand.saved.dumped_wb or nil
	AutoBand.saved.default_dump = AutoBand.saved.default_dump or nil
	--[[ DEBUG PURPOSES ]]--

	AutoBand.saved.org_algo_mode = AutoBand.saved.org_algo_mode or AB_const.DEFAULT_ORG_ALGO
	AutoBand.saved.org_algo_role = AutoBand.saved.org_algo_role or AB_const.DEFAULT_ORG_ROLE

	if (AutoBand.saved.displayicon == nil) then
		AutoBand.saved.displayicon = true
	end

	if (AutoBand.saved.kick_func_enabled == nil) then
		AutoBand.saved.kick_func_enabled = {}
		for k, v in pairs(AB_const.KICK_FUNC_DEFAULT) do
			AutoBand.saved.kick_func_enabled[k] = v
		end
	end

	-- register LibSlash command "/autoband" and tries "/ab"
	LibSlash.RegisterSlashCmd("autoband", function (msg) AutoBand.parse_cmd(msg) end)
	if (not LibSlash.IsSlashCmdRegistered("ab")) then
		LibSlash.RegisterSlashCmd("ab", function (msg) AutoBand.parse_cmd(msg) end)
		AutoBand.has_shortslash = true
	end

	-- load command list
	AutoBand.cmd = {}
	AutoBand.cmd[""] = { ["f"] = AutoBand.cmd_usage, ["help"] = "" , ["print_id"] = 10}
	AutoBand.cmd["help"] = { ["f"] = AutoBand.cmd_usage, ["help"] = "show command list" , ["print_id"] = 11}
	AutoBand.cmd["info"] = { ["f"] = AutoBand.cmd_show, ["help"] = "show current settings" , ["print_id"] = 12}
	AutoBand.cmd["show"] = { ["f"] = AutoBand.cmd_toggle_gui, ["help"] = "open/close GUI" , ["print_id"] = 12}
	
	AutoBand.cmd["org"] = { ["f"] = AutoBand.cmd_organize, ["help"] = "organize the warband" , ["print_id"] = 20}
	

	AutoBand.cmd["wb"] = { ["f"] = AutoBand.wb, ["help"] = "list all players types" , ["print_id"] = 30}
	AutoBand.cmd["kf"] = { ["f"] = AutoBand.cmd_kick_toofar, ["help"] = "kick all far players" , ["print_id"] = 31}
	AutoBand.cmd["ak"] = { ["f"] = AutoBand.cmd_flag_autokick, ["help"] = "toggle auto kick low lvl or too many tank, heal, dps players" , ["print_id"] = 32}
	AutoBand.cmd["akf"] = { ["f"] = AutoBand.cmd_flag_autokick_toofar, ["help"] = "toggle auto kick too far players" , ["print_id"] = 33}
	AutoBand.cmd["an"] = { ["f"] = AutoBand.cmd_flag_autonote, ["help"] = "toggle auto search new player in /1" , ["print_id"] = 34}
	AutoBand.cmd["kicktimeout"] = { ["f"] = AutoBand.cmd_autokick_timeout, ["help"] = "<number> sets autokick too far players timeout in minutes" , ["print_id"] = 35}

	AutoBand.cmd["zone"] = { ["f"] = AutoBand.cmd_list_zone, ["help"] = "list all players' not in leader's / assistants' zone" , ["print_id"] = 40}
	AutoBand.cmd["zonekick"] = { ["f"] = AutoBand.cmd_kick_notinzone, ["help"] = "kick all players not in leader's / assistants' zone" , ["print_id"] = 41}	
	AutoBand.cmd["rank"] = { ["f"] = AutoBand.cmd_list_rank, ["help"] = "list all players' not in leader's / assistants' zone" , ["print_id"] = 50}
	AutoBand.cmd["minrank"] = { ["f"] = AutoBand.cmd_rank, ["help"] = "<number> sets the minimum rank requirement" , ["print_id"] = 51}
	AutoBand.cmd["rankkick"] = { ["f"] = AutoBand.cmd_kick_rank, ["help"] = "kick all players less than required rank" , ["print_id"] = 52}
	--AutoBand.cmd["cb"] = { ["f"] = AutoBand.checkBuffs, ["help"] = "checks buffs" , ["print_id"] = 53}

	AutoBand.cmd["list"] = { ["f"] = AutoBand.cmd_list_template, ["help"] = "list all the templates" , ["print_id"] = 60}
	AutoBand.cmd["save"] = { ["f"] = AutoBand.cmd_save_template, ["help"] = "<name> save the current warband as a template" , ["print_id"] = 61}
	AutoBand.cmd["apply"] = { ["f"] = AutoBand.cmd_apply_template, ["help"] = "<name> apply the template" , ["print_id"] = 62}
	AutoBand.cmd["default"] = { ["f"] = AutoBand.cmd_default_template, ["help"] = "sets to <name> or clear the default template" , ["print_id"] = 63}
	AutoBand.cmd["mode"] = { ["f"] = AutoBand.cmd_mode, ["help"] = "<number> sets the distribution algorithm mode" , ["print_id"] = 64}
	AutoBand.cmd["end"] = { ["f"] = AutoBand.cmd_end, ["help"] = "end warband, kick all" , ["print_id"] = 65}
	--AutoBand.cmd["an"] = { ["f"] = AutoBand.auto_note, ["help"] = "" , ["print_id"] = 66}
	
	AutoBand.cmd["icon"] = { ["f"] = AutoBand.cmd_toggle_icon, ["help"] = "show/hide the minimap icon" , ["print_id"] = 70}

	AutoBand.cmd["dump"] = { ["f"] = AutoBand.cmd_dump, ["help"] = "" , ["print_id"] = 80} -- dump groups for debug purpose
	AutoBand.cmd["cleardump"] = { ["f"] = AutoBand.cmd_cleardumps, ["help"] = "" , ["print_id"] = 81} -- clears last wb dump
	AutoBand.cmd["listdump"] = { ["f"] = AutoBand.cmd_list_dump, ["help"] = "" , ["print_id"] = 83}
	AutoBand.cmd["loaddump"] = { ["f"] = AutoBand.cmd_load_dump, ["help"] = "" , ["print_id"] = 84}
	AutoBand.cmd["tempdump"] = { ["f"] = AutoBand.cmd_dump_from_template, ["help"] = "" , ["print_id"] = 85}
	AutoBand.cmd["debug"] = { ["f"] = AutoBand.cmd_debug, ["help"] = "" , ["print_id"] = 100} -- toggle debug mode

	AutoBand.cmd_ordered = {}
	for cmdkey, cmd in pairs(AutoBand.cmd) do
		cmd.key = cmdkey
		table.insert(AutoBand.cmd_ordered, cmd)
	end
	table.sort(AutoBand.cmd_ordered, function(cm1, cm2) return cm1.print_id < cm2.print_id end)
	AB_util.debug(AutoBand.cmd_ordered)

	local motd = "AutoBand v" .. AB_const.VERSION .. " loaded. Type /autoband"
	if (AutoBand.has_shortslash) then
		motd = motd .. " or /ab"
	end
	motd = motd .. " for instructions"
	AB_util.print(motd)

	-- register our icon
	LayoutEditor.RegisterWindow("AutoBandMapIcon", L"AutoBand", L"AutoBand Button", false, false, true, nil)
end


function AutoBand.update(elapsed)
	AutoBand.elapsed = AutoBand.elapsed + elapsed
	--if AutoBand.elapsed2 >= 0 then AutoBand.elapsed2 = AutoBand.elapsed2 + elapsed end
	if (AutoBand.elapsed > AB_const.HEARTBEAT) then
		local e = AutoBand.elapsed
		AutoBand.elapsed = 0		-- just in case something goes wrong inside auto_kick()
		AutoBand.auto_kick()
		AutoBand.auto_kick_toofar()
		AutoBand.auto_note()
		--AutoBand.auto_organize(e)
	end
	--[[if AutoBand.elapsed2 > 40 then
		g_m = GetGuildMemberData()
		for key,value in pairs(g_m) do
			table.insert(guild_members, value.name)
		end
		ign = GetIgnoreList()
		AutoBand.elapsed2 = -1
		AB_util.print(L"Guild members and ignore list loaded!")
	end]]--
	if (AutoBand.cmd_current == nil) then
		if (#AutoBand.cmd_queue > 0) then
			AutoBand.cmd_current = table.remove(AutoBand.cmd_queue, 1)		-- remove first cmd
		else
			return				-- no current and nothing to dequeue, just return
		end
	end
	AutoBand.cmd_current.ticks = AutoBand.cmd_current.ticks - 1
	if (AutoBand.cmd_current.ticks <= 0) then
		if (AutoBand.debugon or AutoBand.gizilon) then
			AB_util.debug(tostring(AutoBand.cmd_current.cmd))
		end
		SendChatText (towstring(AutoBand.cmd_current.cmd), L"")
		local cmd_tmp = AutoBand.cmd_current
		AutoBand.cmd_current = nil	-- for security clear cmd_current before callback
		if (cmd_tmp.callback) then
			cmd_tmp.callback(cmd_tmp)
		end
	end
end


-- enqueues a string to be processed by "AutoBand.update()"
function AutoBand.enqueue_command(cmd, ticks, callback)
	ticks = ticks or AB_const.DEFAULT_CMD_TICKS
	table.insert(AutoBand.cmd_queue, {["cmd"] = cmd, ["ticks"] = ticks, ["callback"] = callback})
end

function AutoBand.enqueue_kick(player_name, msg_reason)
	if (msg_reason) then
		AutoBand.enqueue_command("/tell " .. tostring(player_name) ..  " [AutoBand] You were kicked from the wb since " .. msg_reason  )
	end
	AutoBand.enqueue_command(L"/kick " .. player_name)
	AB_util.print(L"Kicking " .. player_name)
end


function AutoBand.has_permission()
	local wb_obj = AutoBand.get_wb()
	local i = 0
	wb_obj:foreach_player(
		function(gid, player)
			i = i + 1
		end
	)
	if i == 0 then
		return false
	end
	return GameData.Player.isGroupLeader
end


-- returns a AB_wb object either from a warband, scenario or dumped_wb
function AutoBand.get_wb()
	if (AutoBand.debugon and AutoBand.saved.dumped_wb ~= nil) then
		AB_util.debug("Getting dump " .. AutoBand.saved.default_dump .." size " .. AB_util.size_wb(AutoBand.saved.dumped_wb.group))
		return AB_wb:new(AutoBand.saved.dumped_wb)		-- returns dumped wb
	end

	local wb = AB_wb:new()
	wb:load_from_wbdata()
	return wb
end


-- ####### / Commands #######

function AutoBand.parse_cmd(msg)
	msg = msg:lower()
	local args = StringSplit(msg)
	cmd = table.remove(args, 1)
	if (AutoBand.cmd[cmd] ~= nil) then
		AutoBand.cmd[cmd].f(args)
	else
		AB_util.print("AutoBand unknown command: " .. msg)
	end
end

function AutoBand.cmd_usage(args)
	local ab = "/autoband "
	if (AutoBand.has_shortslash) then
		ab = "/ab "
	end
	AB_util.print("[Autoband commands]")
	--for cmdkey, cmd in pairs(AutoBand.cmd) do
	for _, cmd in ipairs(AutoBand.cmd_ordered) do
		if (cmd.help ~= "" or AutoBand.debugon) then
			AB_util.print(ab .. cmd.key .. " - " .. cmd.help)
		end
	end
end

function AutoBand.cmd_show(args)
	AB_util.print("[AutoBand settings]")
	AB_util.print("Auto kick players: " .. tostring(AutoBand.saved.autokick_enabled))
	AB_util.print("Auto kick too far players: " .. tostring(AutoBand.saved.autokick_toofar_enabled))
	AB_util.print("Auto kick too far players timeout: " .. tostring(AutoBand.saved.autokick_period))
	AB_util.print("Minimum rank requirement: " .. tostring(AutoBand.saved.min_rank))
	AB_util.print("Default template: " .. AutoBand.saved.default_template)
	if (AutoBand.debugon) then
		AB_util.print("Data dumped: " .. tostring(AutoBand.saved.dumped_wb ~= nil))
		AB_util.print("Debug mode: true")
	end
end

function AutoBand.cmd_debug(args)
	AutoBand.debugon = not AutoBand.debugon
	AB_util.print("Debug mode: " .. tostring(AutoBand.debugon))
end

function AutoBand.cmd_flag_autokick(args)
	AutoBand.saved.autokick_enabled = not AutoBand.saved.autokick_enabled
--[[	if AutoBand.has_permission() then
		if AutoBand.saved.autokick_enabled then
			AutoBand.enqueue_command("/wb [AutoBand] Auto forming 8-8-8 wb ENABLED!")
		else
			AutoBand.enqueue_command("/wb [AutoBand] Auto forming 8-8-8 wb DISABLED!")
		end
	end]]--
	AB_util.print("Auto kick players: " .. tostring(AutoBand.saved.autokick_enabled))
end

function AutoBand.cmd_flag_autokick_toofar(args)
	AutoBand.saved.autokick_toofar_enabled = not AutoBand.saved.autokick_toofar_enabled
	if AutoBand.has_permission() then
		if AutoBand.saved.autokick_toofar_enabled then
			AutoBand.enqueue_command("/wb [AutoBand] Auto kick players who are far away from leader ENABLED! Follow the leader PLZ")
		else
			AutoBand.enqueue_command("/wb [AutoBand] Auto kick players who are far away from leader DISABLED! Free move")
			warned = {}
		end
	end
	AB_util.print("Auto kick too far players: " .. tostring(AutoBand.saved.autokick_toofar_enabled))
end

function AutoBand.cmd_flag_autonote(args)
	AutoBand.saved.autonote_enabled = not AutoBand.saved.autonote_enabled
	AB_util.print("Auto note in /1: " .. tostring(AutoBand.saved.autonote_enabled))
end

function AutoBand.cmd_dump(args)	-- give a name to your dump
	if (args[1] == nil) then
		AB_util.print("[error] Missing argument")
		return
	end
	local wb = AB_wb:new()
	wb:load_from_wbdata()
	AutoBand.saved.dumped_wb = wb 
	AutoBand.saved.default_dump = args[1]
	AutoBand.saved.dumps[args[1]] = wb 
	AB_util.print("Dump complete")
end

function AutoBand.cmd_cleardumps(args)
	AutoBand.saved.dumped_wb = nil
	AutoBand.saved.dumps = {}
	AutoBand.saved.default_dump = nil
end

function AutoBand.cmd_kick_toofar(args)
	if (not AutoBand.has_permission()) then
		AB_util.print("[error] You need to be a wb leader")
		return
	end
	local wb_obj = AutoBand.get_wb()
	wb_obj:foreach_player(
		function(gid, player)
			for i = 1, MAX_MAP_POINTS do
				local mpd = GetMapPointData ("EA_Window_OverheadMapMapDisplay", i)
				if (not mpd or not MapPointTypeFilter[mpd.pointType] or not mpd.name) then continue end							
				local name = AutoBand.FixString((mpd.name))
				if name == player.name then
					player.distance = mpd.distance * DISTANCE_FIX_COEFFICIENT
					--AB_util.print(L"Name " .. player.name)
					--AB_util.print("Distance " .. player.distance)
					if player.distance > 150 then
						--AB_util.print(player.name)
						AutoBand.enqueue_kick(player.name, "not follow leader")
					end
					break				
				end			
			end
		end
	)
end


function AutoBand.cmd_list_offline(args)
	local wb_obj = AutoBand.get_wb()
	wb_obj:foreach_player(
		function(gid, player)
			for i = 1, MAX_MAP_POINTS do
				local mpd = GetMapPointData ("EA_Window_OverheadMapMapDisplay", i)
				if (not mpd or not MapPointTypeFilter[mpd.pointType] or not mpd.name) then continue end							
				local name = AutoBand.FixString((mpd.name))
				if name == player.name then
					player.distance = mpd.distance * DISTANCE_FIX_COEFFICIENT
					if player.distance > 150 then
						AB_util.print(player.name)
					end			
				end			
			end

		end
	)
end


function AutoBand.cmd_list_rank(args)
	local str = ""
	local players = AutoBand.get_low_rank()
	if (#players > 0) then
		table.sort(players, function(p1,p2) return p1.level > p2.level end)
		for _, player in ipairs(players) do
			str = str .. tostring(player.name) .. "(r" .. player.level .. ") "
		end
		AB_util.print(AB_const.HEADER_MARGIN .. " Players with rank < " .. AutoBand.saved.min_rank .. " " .. AB_const.HEADER_MARGIN .. " (#" .. #players .. ")")
		AB_util.print(str)
	end
end


function AutoBand.cmd_list_zone(args)
	local wb_obj = AutoBand.get_wb()
	if (wb_obj.player_count == 0) then
		AB_util.debug("No wb data found")
		return
	end
	local players_by_zid = AutoBand.get_players_zone(wb_obj)
	local num_valid_zones = AB_util.size_table(players_by_zid["valid_as"])
	if (players_by_zid["valid_as"] and num_valid_zones > 0) then
		AB_util.print(AB_const.HEADER_MARGIN .. " Leader's and assistants' zones " .. AB_const.HEADER_MARGIN)
		for zid, as_zone in pairs(players_by_zid["valid_as"]) do
			local num_assistants = AB_util.size_table(as_zone)
			local _num_assistants = AB_util.size_table(players_by_zid["valid_as"][zid])
			AB_util.debug("1st " .. zid .. " " ..num_assistants .. " =? " .. _num_assistants)
			local str = ""
			local num_players = AB_util.size_table(players_by_zid["valid_p"][zid]) -- num_assistants + 
			local zone_name = GetZoneName(zid)
			if (zid == 0) then
				zone_name = "Offline"
			end	
			str = str .. tostring(zone_name) .. " (#" .. num_players .. ") "
			for _, player in ipairs(as_zone) do
				if (player.isGroupLeader) then
					str = str .. tostring(player.name) .. "(" .. AB_const.ABBREVATIONS["LEADER"] .. ") "
				else
					str = str .. tostring(player.name) .. "(" .. AB_const.ABBREVATIONS["ASSISTANT"] .. ") "
				end
			end
			AB_util.print(str)
		end
	end
	local num_invalid_zones = AB_util.size_table(players_by_zid["other"])
	if (players_by_zid["other"] and num_invalid_zones > 0) then	
		AB_util.print(AB_const.HEADER_MARGIN .. " " .. AB_const.LABEL_NOTSAMEZONE .. " " .. AB_const.HEADER_MARGIN)
		for zid, other_zone in pairs(players_by_zid["other"]) do
			local str = ""
			local num_players = AB_util.size_table(other_zone)
			AB_util.debug("2nd " .. zid .. " " .. num_players .. " =? " .. #other_zone)
			str = str .. tostring(GetZoneName(zid)) .. " (#" .. #other_zone .. ") "
			for _, player in ipairs(other_zone) do
				str = str .. tostring(player.name) .. " "
			end
		--	str = str .. "\n"
			AB_util.print(str)
		end
		
		
	end
end	

function AutoBand.cmd_kick_notinzone(args)
	if (not AutoBand.has_permission()) then
		AB_util.print("[error] You need to be a wb leader")
		return
	end

	local wb_obj = AutoBand.get_wb()
	if (wb_obj.player_count == 0) then
		AB_util.debug("No wb data found")
		return
	end
	local zone_name = GetZoneName
	local players_by_zid = AutoBand.get_players_zone(wb_obj)
	local num_valid_zones = AB_util.size_table(players_by_zid["valid_as"])
	if (players_by_zid["valid_as"] and num_valid_zones > 0) then
		local valid_zone_str = ""
		for zid, as_zone in pairs(players_by_zid["valid_as"]) do
			if (zid ~= 0) then
				-- offline is not reported as a valid zone
				valid_zone_str = valid_zone_str .. tostring(zone_name(zid)) .. " "
			end
		end
		local num_invalid_zones = AB_util.size_table(players_by_zid["other"])
		if (players_by_zid["other"] and num_invalid_zones > 0) then	
			AB_util.print("Kicking " .. AB_const.LABEL_NOTSAMEZONE)
			for zid, other_zone in pairs(players_by_zid["other"]) do
				if (zid ~= 0) then	-- i dont want to kick offline players
					for _, player in ipairs(other_zone) do
						AutoBand.enqueue_kick(player.name, "you are not in one of the required zones {" .. valid_zone_str .. "}")
					end
				end
			end	
			
		end
	end
	AB_util.print("Zone kick complete")
end

function AutoBand.cmd_rank(args)
	if (args[1] == nil) then
		AB_util.print("[error] Missing argument")
		return
	end
	local n = tonumber(args[1])
	if (n < 0 or n >40) then
		AB_util.print("[error] Invalid rank value: " .. n)
		return
	end
	AutoBand.saved.min_rank = math.floor(n)
	AB_util.print("Minimum rank requirement: " .. tostring(AutoBand.saved.min_rank))
end

function AutoBand.cmd_kick_rank(args)
	if (not AutoBand.has_permission()) then
		AB_util.print("[error] You need to be a wb leader")
		return
	end
	local players = AutoBand.get_low_rank()
	if (#players > 0) then
		AB_util.print("Kicking players with rank < " .. AutoBand.saved.min_rank)
		for _, player in ipairs(players) do
			AutoBand.enqueue_kick(player.name, "you dont meet the rank requirement ("  .. AutoBand.saved.min_rank .. ")")
		end
	end
	AB_util.print("Rank < " .. AutoBand.saved.min_rank .." kick complete")
end

function AutoBand.cmd_organize(args)
	if (AutoBand.has_permission() or AutoBand.debugon) then
		if AutoBand.saved.autokick_enabled or AutoBand.saved.autokick_toofar_enabled then
			a = AutoBand.saved.autokick_enabled
			b = AutoBand.saved.autokick_toofar_enabled
			AutoBand.saved.autokick_enabled = false	-- safe measure to prevent changes during auto_organize
			AutoBand.saved.autokick_toofar_enabled = false
			if (args[1] ~= nil) then
				AB_org.auto_organize(AutoBand.saved.templates[args[1]])
			else
				AB_org.auto_organize(AutoBand.saved.templates[AutoBand.saved.default_template])
			end
			AutoBand.saved.autokick_enabled = a	-- NOTE: we could still be already inside auto_kick()
			AutoBand.saved.autokick_toofar_enabled = b
		else
			if (args[1] ~= nil) then
				AB_org.auto_organize(AutoBand.saved.templates[args[1]])
			else
				AB_org.auto_organize(AutoBand.saved.templates[AutoBand.saved.default_template])
			end
		end
	else
		AB_util.print("[error] You need to be a wb leader")
	end
end

function AutoBand.cmd_autokick_timeout(args)
	if (args[1] == nil) then
		AB_util.print("[error] Missing argument")
		return
	end
	local n = tonumber(args[1])
	if (n < 0) then
		AB_util.print("[error] Invalid timeout value: " .. n)
		return
	end
	AutoBand.saved.autokick_period = math.floor(n)
	AB_util.print("Auto kick timeout: " .. tostring(AutoBand.saved.autokick_period))
end

function AutoBand.cmd_mode(args)
	if (args[1] == nil) then
		AB_util.print("[error] Missing argument")
		return
	end
	local n = tonumber(args[1])
	if (n < 0 or n > 2) then
		AB_util.print("[error] Invalid distribution algorithm: " .. n)
		return
	end
	AutoBand.saved.org_algo_mode = math.floor(n)
	AB_util.print("Distribution algorithm mode: " .. tostring(AutoBand.saved.org_algo_mode) .. AB_const.ALGO_MODE[AutoBand.saved.org_algo_mode])
end

function AutoBand.cmd_list_template(args)
	AB_util.print("Default template " .. AutoBand.saved.default_template)

	for tname in pairs(AutoBand.saved.templates) do
		AB_util.print(tname)
	end
end

function AutoBand.cmd_save_template(args)
	if (args[1] == nil) then
		AB_util.print("[error] Missing argument")
		return
	end
	AutoBand.saved.templates[args[1]] = AB_template.from_wb(AutoBand.get_wb())
	AB_util.print("Template " .. args[1].. " saved")
end

function AutoBand.cmd_apply_template(args)
	if (args[1] == nil) then
		AB_util.print("[error] Missing argument")
		return
	end
	if (AutoBand.saved.templates[args[1]] == nil) then
		AB_util.print("[error] Template " .. args[1] .. " does not exist")
		return
	end
	AB_org.auto_organize(AutoBand.saved.templates[args[1]])
	AB_util.print("Template " .. args[1].. " loaded")
end

function AutoBand.cmd_default_template(args)
	if (#args > 0) then
		if (AutoBand.saved.templates[args[1]] == nil) then
			AB_util.print("[error] Template " .. args[1] .. " does not exist")
			return
		end
		AutoBand.saved.default_template = args[1]
	else
		AutoBand.saved.default_template = AB_const.EMPTY_TEMPLATE
	end
	AB_util.print("Default template set: " .. AutoBand.saved.default_template)
end

function AutoBand.cmd_toggle_gui(args)
	if (AutoBandWindow.showing()) then
		AutoBandWindow.Hide()
	else
		AutoBandWindow.Show()
	end
end

function AutoBand.cmd_toggle_icon(args)
	AutoBandWindow.toggle_mapicon()
end

-- ####### [end] / Commands #######

-- ####### [start] / Debug Purposes Commands #######

function AutoBand.cmd_list_dump(args)
--	if (AutoBand.saved.default_dump ~= nil) then
--		AB_util.print("[AutoBand] default dump " .. AutoBand.saved.default_dump)
	if (AutoBand.saved.dumped_wb ~= nil) then
		AB_util.print("[AutoBand] default dump " .. AutoBand.saved.default_dump)
	end
	for tname in pairs(AutoBand.saved.dumps) do
		AB_util.print(tname)
	end
end

function AutoBand.cmd_load_dump(args)
	if (#args > 0) then
		if (AutoBand.saved.dumps[args[1]] == nil) then
			AB_util.print("[error] Dump " .. args[1] .. " does not exist")
			return
		end
		AutoBand.saved.default_dump = args[1]
		AutoBand.saved.dumped_wb = AutoBand.saved.dumps[AutoBand.saved.default_dump]
	end
	AB_util.print("[AutoBand] Default dump set: " .. AutoBand.saved.default_dump)
end

function AutoBand.cmd_dump_from_template(args)
	if(AutoBand.debugon) then
		if (#args > 1) then
			local template_name = args[1]
			local dump_name = args[2]
			if (AutoBand.saved.templates[template_name] == nil) then
				AB_util.print("[error] Template " .. template_name .. " does not exist")
				return
			end
			AutoBand.saved.dumped_wb = AutoBand.get_fakewb(AutoBand.saved.templates[template_name])
			AutoBand.saved.dumps[dump_name] = AutoBand.saved.dumped_wb
			AutoBand.saved.default_dump = dump_name
		end
	end
end

-- ####### [end] / Debug Purposes Commands #######

function AutoBand.auto_kick_toofar()
	if (not AutoBand.saved.autokick_toofar_enabled or not AutoBand.has_permission() or AutoBand.debugon) then
		return
	end
	--AB_util.print("Autokick toofar working....")
	local wb_obj = AutoBand.get_wb()
	wb_obj:foreach_player(
		function(gid, player)
			for i = 1, MAX_MAP_POINTS do
				local mpd = GetMapPointData ("EA_Window_OverheadMapMapDisplay", i)
				if (not mpd or not MapPointTypeFilter[mpd.pointType] or not mpd.name) then continue end							
				local name = AutoBand.FixString((mpd.name))
				if name == player.name then
					player.distance = mpd.distance * DISTANCE_FIX_COEFFICIENT
					--AB_util.print(L"Name " .. player.name)
					--AB_util.print("Distance " .. player.distance)
					if player.distance > 150 then
						if toofar[player.name] then toofar[player.name] = toofar[player.name] + 1
						else
							toofar[player.name] = 1
							--AB_util.print("Player will be kicked: " .. tostring(player.name))
						end
						if (toofar[player.name] == 6) then
							found = 0
							for i, v in pairs(warned) do
								if v == player.name then
									found = 1
									break
								end
							end
							if found == 0 then
								AutoBand.enqueue_command("/tell " .. tostring(player.name) ..  " [AutoBand] You are too far from leader, you will be autokicked in " .. AutoBand.saved.autokick_period * 60 - 30 .. "sec! Follow the leader PLZ")
								table.insert(warned, player.name)
							end							
							--AB_util.print("Player kicked: " .. tostring(player.name))
						end
						if (toofar[player.name] > AutoBand.saved.autokick_period * 12) then 
							AutoBand.enqueue_kick(player.name, "was too far from warband leader for long time")
							--AutoBand.enqueue_command("/wb [AutoBand] " .. tostring(player.name) .. " kicked! (was too far from warband leader for long time)")
							--AB_util.print("Player kicked: " .. tostring(player.name))
						end
					else
						toofar[player.name] = nil
					end
					break				
				end			
			end

		end
	)
	for i, v in pairs(toofar) do
		for ii, vv in pairs(toofar_old) do
			if i == ii then
				if v == vv then
					if toofar_not_changed[i] then
						toofar_not_changed[i] = toofar_not_changed[i] + 1
					else
						toofar_not_changed[i] = 1
						--AB_util.print("Player start count to delete from toofar " .. tostring(i))
					end
					if toofar_not_changed[i] > 60 then 
						toofar[i] = nil
						toofar_not_changed[i] = nil
						--AB_util.print("Player delete from toofar " .. tostring(i))
					end
				end
				break
			end
		end
	end
	toofar_old = {}
	--kk = 0
	for key,value in pairs(toofar) do
		--kk = kk + 1
		toofar_old[key] = value
	end
	--number = number + 1
	--if number > 120 then
	--	warned = {}
	--	number = 0
	--end
end


function AutoBand.auto_kick()
	-- check for flag, permission and debugmode
	if (not AutoBand.saved.autokick_enabled or not AutoBand.has_permission() or AutoBand.debugon) then
		return
	end
	--AB_util.print("Autokick working....")
	local wb_obj = AutoBand.get_wb()
--	local whs = 0
	local tanks_t = {}
	local healers_t = {}
	local dps_t = {}
--	local wh_t = {}
	local found = 0
	local tanks, healers, dpss = 0, 0, 0
	local guild_member = false
	g_m = {}
	g_m = GetGuildMemberData()
	guild_members = {}
	for key,value in pairs(g_m) do
		table.insert(guild_members, value.name)
	end
	ign = {}
	ign = GetIgnoreList()
	--AB_util.print("GM " .. #guild_members)
	wb_obj:foreach_player(
		function(gid, player)
			if ign ~= nil then
				for key,value in pairs(ign) do
					if player.name:match(L"([^^]+)^?([^^]*)") == value.name:match(L"([^^]+)^?([^^]*)") then
						AutoBand.enqueue_kick(player.name, "sry, you are in my ignore list")
					end
				end
			end
			if (player.level < AutoBand.saved.min_rank) then
				AutoBand.enqueue_kick(player.name, "sry, you are too low level for this warband")
				return
			end
			guild_member = false
			for key,value in pairs(guild_members) do
				if value:match(L"([^^]+)^?([^^]*)") == player.name then
					guild_member = true
					break
				end
			end
			if (player.role == "tank") then
				tanks_t[player.name] = guild_member
				tanks = tanks + 1
			end
			if (player.role == "healer") then
				healers_t[player.name] = guild_member
				healers = healers + 1
			end
--[[			if (player.careerLine == (GameData.CareerLine.WITCH_ELF or GameData.CareerLine.WITCH_HUNTER)) then
				AutoBand.enqueue_kick(player.name, "sry no WE or WH allowed in this warband")
				return
			end]]--
			if (player.role == "mdps" or player.role == "rdps") then
				dps_t[player.name] = guild_member
				dpss = dpss + 1
			end
		end
	)
	--AB_util.print("Autokick working....")
	if (tanks > 8) then
		for key,value in pairs(tanks_t) do
			for key2,value2 in pairs(tanks_t_old) do
				if (key == key2) then
					found = 1
					break
				end
			end
			if (found == 0) then
				if value then
					for key2,value2 in pairs(tanks_t) do
						if not value2 then
							AutoBand.enqueue_kick(key2, "sry, too many tanks (guild member priority)")
							--AB_util.print("Player kick too many tanks " .. key)
							tanks_t[key2] = nil
							tanks = tanks - 1
							break
						end
					end
				else
					AutoBand.enqueue_kick(key, "sry, too many tanks")
					--AB_util.print("Player kick too many tanks " .. key)
					tanks_t[key] = nil
					tanks = tanks - 1
				end
				if tanks <= 8 then
					break
				end
			end
			found = 0
		end
	end
	tanks_t_old = {}
	i = 0
	for key,value in pairs(tanks_t) do
		i = i + 1
		if (i <= 8) then
			tanks_t_old[key] = value
		end
	end
	found = 0
	if (healers > 8) then
		for key,value in pairs(healers_t) do
			for key2,value2 in pairs(healers_t_old) do
				if (key == key2) then
					found = 1
					break
				end
			end
			if (found == 0) then
				if value then
					for key2,value2 in pairs(healers_t) do
						if not value2 then
							AutoBand.enqueue_kick(key2, "sry, too many healers (guild member priority)")
							--AB_util.print("Player kick too many tanks " .. key)
							healers_t[key2] = nil
							healers = healers - 1
							break
						end
					end
				else
					AutoBand.enqueue_kick(key, "sry, too many healers")
					--AB_util.print("Player kick too many tanks " .. key)
					healers_t[key] = nil
					healers = healers - 1					
				end
				if healers <= 8 then
					break
				end
			end
			found = 0
		end
	end
	i = 0
	healers_t_old = {}
	for key,value in pairs(healers_t) do
		i = i + 1
		if (i <= 8) then
			healers_t_old[key] = value
		end
	end
	found = 0
	if (dpss > 8) then
		for key,value in pairs(dps_t) do
			for key2,value2 in pairs(dps_t_old) do
				if (key == key2) then
					found = 1
					break
				end
			end
			if (found == 0) then
				if value then
					for key2,value2 in pairs(dps_t) do
						if not value2 then
							AutoBand.enqueue_kick(key2, "sry, too many dps (guild member priority)")
							--AB_util.print("Player kick too many tanks " .. key)
							dps_t[key2] = nil
							dpss = dpss - 1
							break
						end
					end
				else
					AutoBand.enqueue_kick(key, "sry, too many dps")
					--AB_util.print("Player kick too many tanks " .. key)
					dps_t[key] = nil
					dpss = dpss - 1
				end
				if dpss <= 8 then
					break
				end
			end
			found = 0
		end
	end
	dps_t_old = {}
	i = 0
	for key,value in pairs(dps_t) do
		i = i + 1
		if (i <= 8) then
			dps_t_old[key] = value
		end
	end
	--AB_util.print("Tanks " .. #tanks_t)
	--AB_util.print("Tanks old " .. #tanks_t_old)
	--AB_util.print("Healers " .. #healers_t)
	--AB_util.print("Healers old " .. #healers_t_old)
	--AB_util.print("Dps " .. #dps_t)
	--AB_util.print("Dps old " .. #dps_t_old)
end

function AutoBand.auto_note()
	number2 = number2 + 1
	if (not AutoBand.saved.autonote_enabled or not AutoBand.has_permission() or AutoBand.debugon) then
		return
	end
	--AB_util.print("Autonote working....")
	local wb_obj = AutoBand.get_wb()
	local tanks, healers, dpss = 0, 0, 0
	wb_obj:foreach_player(
		function(gid, player)
			if (player.role == "tank") then
				tanks = tanks + 1
			end
			if (player.role == "healer") then
				healers = healers + 1
			end
			if (player.role == "mdps") then
				dpss = dpss + 1
			end
			if (player.role == "rdps") then
				dpss = dpss + 1
			end
		end
	)
	if (tanks == 0 and healers == 0 and dpss == 0) then return end
	if (tanks < 8 or healers < 8 or dpss < 8) and tanks+healers+dpss < 24 then
		if number2 > 60 then -- every 5 min
			if tanks > 8 then tanks = 8 end
			if healers > 8 then healers = 8 end
			if dpss > 8 then dpss = 8 end
			AutoBand.enqueue_command("/1 [AutoBand] Warband need " .. 8 - tanks .. " tanks, " .. 8 - healers .. " healers, " .. 8 - dpss .. " dps " .. AutoBand.saved.min_rank .. "+ level")
			number2 = 0
			--AB_util.print("[AutoBand] Automated PUG warband in " .. tostring(GetZoneName(leader_zone)) .. " need " .. 8 - tanks .. " tanks, " .. 8 - healers .. " healers, " .. 8 - dpss .. " dps " .. AutoBand.saved.min_rank .. "+ level")
		end
	end
end

-- ####### [start] / Get Functions #######

-- return a list of players < AutoBand.saved.min_rank
function AutoBand.get_low_rank(wb_obj)
	if (not wb_obj) then
		wb_obj = AutoBand.get_wb()
	end
	local list = {}
	wb_obj:foreach_player(
		function(gid, player)
			if (player.level < AutoBand.saved.min_rank) then
				table.insert(list, player)
			end
		end
	)
	return list
end

-- return a list of offline players
function AutoBand.wb(args)
	--[[if (not AutoBand.has_permission() or AutoBand.debugon) then
		AB_util.print("You need to be in warband.")
		return
	end]]--
	--if (not wb_obj) then
	wb_obj = AutoBand.get_wb()
	--end
	local list = {}
	local tanks, healers, dpss, w_wh = 0, 0, 0, 0, 0
	local found = 0
	local tanks_t = {}
	local healers_t = {}
	local dps_t = {}
	local ii = 0
	local g_m = {}
	local guildmem = {}
	g_m = GetGuildMemberData()
	local guild_members = {}
	for key,value in pairs(g_m) do
		table.insert(guild_members, value.name)
	end
	wb_obj:foreach_player(
		function(gid, player)
			if (player.role == "tank") then
				--tanks_t[player.name] = "t" .. gid
				tanks = tanks + 1
			end
			if (player.role == "healer") then
				--healers_t[player.name] = "h" .. gid
				healers = healers + 1
			end
			if (player.role == "mdps" or player.role == "rdps") then
				--dps_t[player.name] = "d" .. gid
				dpss = dpss + 1
			end
			if (player.careerLine == (GameData.CareerLine.WITCH_ELF or GameData.CareerLine.WITCH_HUNTER)) then
				w_wh = w_wh + 1
			end
			for key,value in pairs(guild_members) do
				--if tostring(value) == tostring(player.name) .. string.char(94, 77) then
				
				if value:match(L"([^^]+)^?([^^]*)") == player.name then
					ii = ii + 1
					table.insert(guildmem, player.name)
					break
				end
			end
		end
	)
	AB_util.print("Tanks " .. tanks)
	AB_util.print("Healers " .. healers)
	AB_util.print("Dps " .. dpss)
	AB_util.print("WE or WH " .. w_wh)
	--AutoBand.enqueue_command("/wb [AutoBand] Tanks " .. tanks)
	--AutoBand.enqueue_command("/wb [AutoBand] Healers " .. healers)
	--AutoBand.enqueue_command("/wb [AutoBand] DPS " .. dpss)

	AB_util.print("Guild members(include you) " .. ii)
	for key,value in pairs(guildmem) do
		AB_util.print(tostring(value))
	end
end

-- return a list of players by zone : assumes that the player is in a warband
function AutoBand.get_players_zone(wb_obj)
	local zids = {["valid_as"]= {}, ["valid_p"]= {}}
	local leader_zone = nil
	wb_obj:foreach_player(
		function(gid, player)
			if (player.isGroupLeader or player.isAssistant) then
				if (zids["valid_as"][player.zoneNum] == nil) then
					zids["valid_as"][player.zoneNum] = {}
				end
				if (player.isGroupLeader) then
					leader_zone = player.zoneNum
					table.insert(zids["valid_as"][player.zoneNum], 1, player)
				else
					table.insert(zids["valid_as"][player.zoneNum], player)
				end
			end
		end
	)
	if (leader_zone) then
		zids["other"]= {}
		wb_obj:foreach_player(
			function(gid, player)
	--			if (player.online) then
					if (zids["valid_as"][player.zoneNum]) then
						if (zids["valid_p"][player.zoneNum] == nil) then
							zids["valid_p"][player.zoneNum] = {}
						end
						table.insert(zids["valid_p"][player.zoneNum], player)
					else
						if (zids["other"][player.zoneNum] == nil) then
							zids["other"][player.zoneNum] = {}
						end
						table.insert(zids["other"][player.zoneNum], player)
					end
	--			end
			end
		)
	else 
		AB_util.print("[ERROR] Leader cannot be found, the warband is BUGGED, reform a warband")
	end
	return zids
end



-- [DEBUG] returns a AB_wb object either from a warband, scenario or dumped_wb
function AutoBand.get_fakewb(template)
	local wb = AB_wb:new()
	wb:set_groups()
	local num_players = 1
	for gid, tgroup in ipairs(template) do
		for j, tplayer in ipairs(tgroup) do
			wb:add_to_gid(tplayer.role, num_players, gid)
			num_players = num_players + 1
		end
	end
	wb:recalc_counters()
	wb:print()
	return wb
end

function AutoBand.FixString (str)
	if (str == nil) then return nil end
	local str = str
	local pos = str:find (L"^", 1, true)
	if (pos) then str = str:sub (1, pos - 1) end	
	return str
end

function AutoBand.cmd_end(args)
	local wb_obj = AutoBand.get_wb()
	wb_obj:foreach_player(
		function(gid, player)
			AutoBand.enqueue_kick(player.name, "warband ended, cya")
		end
	)
	--AutoBand.saved.autokick_enabled = false
	--AutoBand.saved.autokick_toofar_enabled = false
end

--[[function AutoBand.isinyourguild(name)
	for key,value in pairs(guild_members) do
		if value == tostring(name) .. string.char(94, 77) then return 1 end
	end
	return 0
end]]--

-- ####### [end] / Get Functions #######

