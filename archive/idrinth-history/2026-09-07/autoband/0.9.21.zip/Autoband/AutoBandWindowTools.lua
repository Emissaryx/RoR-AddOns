--
AutoBandWindowTools = {}

AutoBandWindowTools.name = "AutoBandWindowToolsTab"

AutoBandWindowTools.tools_data = {
	[AB_const.KICK_OFFLINE] = { ["button"] = "KickOfflineCheckBox" , ["label"] = "KickOfflineLabel", ["func_kick"]= AutoBand.cmd_kick_toofar, ["func_print"] = AutoBand.cmd_list_offline},
	[AB_const.KICK_ZONE] = { ["button"] = "KickZoneCheckBox" , ["label"] = "KickZoneLabel", ["func_kick"]= AutoBand.cmd_kick_notinzone, ["func_print"] = AutoBand.cmd_list_zone},
	[AB_const.KICK_RANK] = { ["button"] = "KickRankCheckBox" , ["label"] = "KickRankLabel", ["func_kick"]= AutoBand.cmd_kick_rank, ["func_print"] = AutoBand.cmd_list_rank} }


function AutoBandWindowTools.Initialize()
	LabelSetText(AutoBandWindowTools.name .. "KickLabel", L"Manage Players")

	for fid, func in pairs(AutoBandWindowTools.tools_data) do
		LabelSetText(AutoBandWindowTools.name .. func["label"], towstring(AB_const.LABEL_KICK[fid]))
		ButtonSetCheckButtonFlag(AutoBandWindowTools.name .. func["button"], true)
		ButtonSetPressedFlag(AutoBandWindowTools.name .. func["button"],  AutoBand.saved.kick_func_enabled[fid])
	end

	ButtonSetText(AutoBandWindowTools.name .. "PrintButton", L"Print")
	ButtonSetText(AutoBandWindowTools.name .. "KickButton", L"Kick")
	
    LabelSetText(AutoBandWindowTools.name .. "SearchRoleLabel", L"Manual Search for Players")
    LabelSetText(AutoBandWindowTools.name .. "SearchRoleChan1Label", L"/1 (region)")
    LabelSetText(AutoBandWindowTools.name .. "SearchRoleChanT4Label", L"/t4")
    LabelSetText(AutoBandWindowTools.name .. "SearchRoleChan5Label", L"/5 (lfg)")

    ButtonSetCheckButtonFlag(AutoBandWindowTools.name .. "SearchRoleChan1CheckBox", true) -- Enable check button behavior
    ButtonSetPressedFlag(AutoBandWindowTools.name .. "SearchRoleChan1CheckBox", true)     -- Check it
    -- ButtonSetDisabledFlag(AutoBandWindowTools.name .. "SearchRoleChan1CheckBox", true)    -- Disable it

    ButtonSetCheckButtonFlag(AutoBandWindowTools.name .. "SearchRoleChanT4CheckBox", true) -- Enable check button behavior
    ButtonSetPressedFlag(AutoBandWindowTools.name .. "SearchRoleChanT4CheckBox", false)    -- Default unchecked

    ButtonSetCheckButtonFlag(AutoBandWindowTools.name .. "SearchRoleChan5CheckBox", true)  -- Enable check button behavior
    ButtonSetPressedFlag(AutoBandWindowTools.name .. "SearchRoleChan5CheckBox", false)     -- Default unchecked

    ButtonSetText(AutoBandWindowTools.name .. "SearchRoleButton", L"Search")

	LabelSetText(AutoBandWindowTools.name .. "AutoSearchLabel", L"Auto Search in /1 every 5 mins")
	ButtonSetCheckButtonFlag(AutoBandWindowTools.name .. "AutoSearchCheckBox", true)
	ButtonSetPressedFlag(AutoBandWindowTools.name .. "AutoSearchCheckBox", AutoBand.saved.autonote_enabled)
	
	ButtonSetText(AutoBandWindowTools.name .. "OrganizeButton", L"Organize WB")
    LabelSetText(AutoBandWindowTools.name .. "NotifyBuffsLabel", L"Notify WB after Organize")
    ButtonSetCheckButtonFlag(AutoBandWindowTools.name .. "NotifyBuffsCheckBox", true) -- Enable check button behavior

	LabelSetText(AutoBandWindowTools.name .. "PrintRoleLabel", L"Print Role Assignments")
	ButtonSetCheckButtonFlag(AutoBandWindowTools.name .. "PrintRoleCheckBox", true) -- Enable check button behavior

	LabelSetText(AutoBandWindowTools.name .. "RightClickOrganizeLabel", L"Enable RClick Icon to Organize")
    ButtonSetCheckButtonFlag(AutoBandWindowTools.name .. "RightClickOrganizeCheckBox", true) -- Enable check button behavior

	-- Button bar
	ButtonSetText(AutoBandWindowTools.name .. "ResetButton", L"Restore Defaults")
end


function AutoBandWindowTools.Hide()
	WindowSetShowing(AutoBandWindowTools.name, false)
end


function AutoBandWindowTools.Show()
    ButtonSetPressedFlag(AutoBandWindowTools.name .. "AutoSearchCheckBox", AutoBand.saved.autonote_enabled)
    ButtonSetPressedFlag(AutoBandWindowTools.name .. "NotifyBuffsCheckBox", AutoBand.saved.notify_buffs_enabled)
	ButtonSetPressedFlag(AutoBandWindowTools.name .. "RightClickOrganizeCheckBox", AutoBand.saved.right_click_organize)
	ButtonSetPressedFlag(AutoBandWindowTools.name .. "PrintRoleCheckBox", AutoBand.saved.printrole_enabled)
	WindowSetShowing(AutoBandWindowTools.name, true)
end


function AutoBandWindowTools.reset_kick_enabled()
	for fid, func in pairs(AutoBandWindowTools.tools_data) do
		ButtonSetPressedFlag(AutoBandWindowTools.name .. func["button"], AB_const.KICK_FUNC_DEFAULT[fid])
		AutoBand.saved.kick_func_enabled[fid] = AB_const.KICK_FUNC_DEFAULT[fid]
	end
end


function AutoBandWindowTools.OnKickOfflineCheckBox()
	AutoBand.saved.kick_func_enabled[AB_const.KICK_OFFLINE] = ButtonGetPressedFlag(AutoBandWindowTools.name .. "KickOfflineCheckBox")
end


function AutoBandWindowTools.OnKickZoneCheckBox()
	AutoBand.saved.kick_func_enabled[AB_const.KICK_ZONE] = ButtonGetPressedFlag(AutoBandWindowTools.name .. "KickZoneCheckBox")
end


function AutoBandWindowTools.OnKickRankCheckBox()
	AutoBand.saved.kick_func_enabled[AB_const.KICK_RANK] = ButtonGetPressedFlag(AutoBandWindowTools.name .. "KickRankCheckBox")
end


function AutoBandWindowTools.OnKickButton()
	for fid, kick_func in pairs(AutoBandWindowTools.tools_data) do
		-- to make sure that you read the values from check boxes
		AutoBand.saved.kick_func_enabled[fid] = ButtonGetPressedFlag(AutoBandWindowTools.name .. kick_func["button"])
		if (AutoBand.saved.kick_func_enabled[fid]) then
			kick_func.func_kick()
		end
	end
end

function AutoBandWindowTools.OnPrintButton()
	AB_util.print("Warband Report ")
	for fid, kick_func in pairs(AutoBandWindowTools.tools_data) do
		-- to make sure that you read the values from check boxes
		AutoBand.saved.kick_func_enabled[fid] = ButtonGetPressedFlag(AutoBandWindowTools.name .. kick_func["button"])
		if (AutoBand.saved.kick_func_enabled[fid]) then
			kick_func.func_print()
		end
	end
end

function AutoBandWindowTools.OnOrganizeButton()
    -- Call the existing command function directly
    AutoBand.cmd_organize({}) -- Pass empty args table
end

function AutoBandWindowTools.OnNotifyBuffsCheckBox()
    -- Call the existing command function which handles toggling and feedback
    AutoBand.cmd_toggle_buffnotify({})
end

function AutoBandWindowTools.OnRightClickOrganizeCheckBox()
    -- Call the existing command function which handles toggling and feedback
    AutoBand.cmd_toggle_rco({})
end

function AutoBandWindowTools.OnPrintRoleCheckBox()
    -- Call the existing command function which handles toggling and feedback
    AutoBand.cmd_flag_printrole({})
end

function AutoBandWindowTools.OnSearchRoleButton()
    local args = {} -- Table to hold the channel arguments

	if ButtonGetPressedFlag(AutoBandWindowTools.name .. "SearchRoleChan1CheckBox") then
		table.insert(args, "1")
	end

    if ButtonGetPressedFlag(AutoBandWindowTools.name .. "SearchRoleChanT4CheckBox") then
        table.insert(args, "t4")
    end

    if ButtonGetPressedFlag(AutoBandWindowTools.name .. "SearchRoleChan5CheckBox") then
        table.insert(args, "5")
    end

    AutoBand.cmd_search_roles(args)
end

function AutoBandWindowTools.OnAutoSearchCheckBox()
	-- Call the existing command function which toggles the setting and prints feedback
	AutoBand.cmd_flag_autonote({})
end

function AutoBandWindowTools.OnResetTools()
	AB_util.debug(AutoBand.saved.kick_func_enabled)
	AB_util.debug(AB_const.KICK_FUNC_DEFAULT)
	AutoBandWindowTools.reset_kick_enabled()
	AutoBandWindowTools.Show()
end
