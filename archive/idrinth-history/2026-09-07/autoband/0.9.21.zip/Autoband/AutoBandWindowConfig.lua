--
AutoBandWindowConfig = {}

AutoBandWindowConfig.name = "AutoBandWindowConfigTab"
AutoBandWindowConfig.combobox_name = AutoBandWindowConfig.name .. "ComboBox"


function AutoBandWindowConfig.Initialize()
	-- Settings: Templates
	LabelSetText(AutoBandWindowConfig.name .. "DefaultLabel", L"Default Template")
	ButtonSetText(AutoBandWindowConfig.name .. "ClearTemplateButton", L"Reset")

	AutoBandWindowConfig.refresh_default_template() 	

	LabelSetText(AutoBandWindowConfig.name .. "ComboBoxLabel", L"Distribution Algorithm:")
	AutoBandWindowConfig.init_combobox()
	AutoBandWindowConfig.refresh_combobox()

	-- Settings: Auto Kick Offliners 
	LabelSetText(AutoBandWindowConfig.name .. "AutoKickLabel", L"Auto form 8-8-8 wb")
	ButtonSetCheckButtonFlag(AutoBandWindowConfig.name .. "KickCheckBox", true)
	
	LabelSetText(AutoBandWindowConfig.name .. "AutoKickToofarLabel", L"Auto Kick too far")
	ButtonSetCheckButtonFlag(AutoBandWindowConfig.name .. "KickToofarCheckBox", true)

	LabelSetText(AutoBandWindowConfig.name .. "KickTimeLabel", L"Timeout for kick too far (min)") -- (min)")
	AutoBandWindowConfig.refresh_kickoff()	

    -- Settings: Auto Kick Low Rank
	LabelSetText(AutoBandWindowConfig.name .. "AutoKickLowRankLabel", L"Auto Kick low rank")
    ButtonSetCheckButtonFlag(AutoBandWindowConfig.name .. "KickLowRankCheckBox", true)

    -- Settings: Auto Kick Stealthers
    LabelSetText(AutoBandWindowConfig.name .. "AutoKickStealthersLabel", L"Auto Kick stealthers")
    ButtonSetCheckButtonFlag(AutoBandWindowConfig.name .. "KickStealthersCheckBox", true)
	
	-- Settings: Guild priority
	LabelSetText(AutoBandWindowConfig.name .. "GuildPriorityLabel", L"Guild priority")
	ButtonSetCheckButtonFlag(AutoBandWindowConfig.name .. "GuildPriorityCheckBox", true)

	-- Settings: Rank requirement
	LabelSetText(AutoBandWindowConfig.name .. "RankReqLabel", L"Rank Requirement")
--	LabelSetText(AutoBandWindowConfig.name .. "MinRankLabel", L"Minimum")

	-- Settings: Healer Rank requirement
	LabelSetText(AutoBandWindowConfig.name .. "HealerRankReqLabel", L"Healer Rankreq")

	-- Settings: Alt Check
	LabelSetText(AutoBandWindowConfig.name .. "AltCheckLabel", L"Alt-Spec check")
	ButtonSetCheckButtonFlag(AutoBandWindowConfig.name .. "AltCheckCheckBox", true)

	-- Settings: Minimap icon
	LabelSetText(AutoBandWindowConfig.name .. "MapIconLabel", L"Minimap icon")
	ButtonSetCheckButtonFlag(AutoBandWindowConfig.name .. "MapIconCheckBox", true)
--	ButtonSetPressedFlag(AutoBandWindowConfig.name .. "MapIconCheckBox", AutoBand.saved.displayicon)

    -- Settings: DPS Weighting
    LabelSetText(AutoBandWindowConfig.name .. "DpsWeightingLabel", L"DPS Weighting when 8-8-8")
    ButtonSetCheckButtonFlag(AutoBandWindowConfig.name .. "DpsWeightingCheckBox", true)
    LabelSetText(AutoBandWindowConfig.name .. "MaxMdpsLabel", L"    Max MDPS")
    LabelSetText(AutoBandWindowConfig.name .. "MaxRdpsLabel", L"     Max RDPS")

	AutoBandWindowConfig.refresh_min_rank()	
	AutoBandWindowConfig.refresh_min_rank_healer()
	AutoBandWindowConfig.refresh_dps_weights()
	
	LabelSetText(AutoBandWindowConfig.name .. "VersionLabel", L"v" .. towstring(AB_const.VERSION))

	-- Button bar
	ButtonSetText(AutoBandWindowConfig.name .. "ResetButton", L"Restore Defaults")
	WindowSetShowing(AutoBandWindowConfig.name .. "DisplaySeperator1", false) 
	WindowSetShowing(AutoBandWindowConfig.name .. "DisplaySeperator2", true) 
	WindowSetShowing(AutoBandWindowConfig.name .. "DisplaySeperator3", true) 
end

function AutoBandWindowConfig.refresh_default_template()
	local clear_default = true
	local default_template = AB_const.EMPTY_TEMPLATE

	if (AutoBand.saved.default_template ~= AB_const.EMPTY_TEMPLATE) then
		clear_default = false
		default_template = AutoBand.saved.default_template
		AB_util.debug("Default is not set to automatic: " .. default_template)
	end

	LabelSetText(AutoBandWindowConfig.name .. "DefaultTemplateLabel", towstring(default_template))	
	ButtonSetDisabledFlag(AutoBandWindowConfig.name .. "ClearTemplateButton", clear_default)
end


function AutoBandWindowConfig.init_combobox()
	-- reloadui combobox
	AutoBandWindowConfig.combo_items = {}
	ComboBoxClearMenuItems(AutoBandWindowConfig.combobox_name)
	-- add from templates
	for mid, mode in pairs(AB_const.ALGO_MODE) do
		ComboBoxAddMenuItem(AutoBandWindowConfig.combobox_name, towstring("(" .. mid .. ") " .. mode))
		table.insert(AutoBandWindowConfig.combo_items, "(" .. mid .. ") " .. mode)
	end
end

function AutoBandWindowConfig.refresh_combobox()
	ComboBoxSetSelectedMenuItem(AutoBandWindowConfig.combobox_name, AutoBand.saved.org_algo_mode)
end

-- return selected text
function AutoBandWindowConfig.selected_combobox()
	return tostring(ComboBoxGetSelectedText(AutoBandWindowConfig.combobox_name))
end

-- load selected algorithm
function AutoBandWindowConfig.OnSelChangedComboBox()
	local name = AutoBandWindowConfig.selected_combobox()
	local index = nil
	for i, v in ipairs(AutoBandWindowConfig.combo_items) do
		if (v == name) then
			index = i
			break
		end
	end
	if (index) then
		AutoBand.saved.org_algo_mode = index
		ComboBoxSetSelectedMenuItem(AutoBandWindowConfig.combobox_name, AutoBand.saved.org_algo_mode)
		AB_util.debug(AutoBand.saved.org_algo_mode)
	end
end

function AutoBandWindowConfig.Hide()
	WindowSetShowing(AutoBandWindowConfig.name, false)
end

function AutoBandWindowConfig.Show()
	AutoBandWindowConfig.refresh_kickoff()
	AutoBandWindowConfig.refresh_default_template()
	AutoBandWindowConfig.refresh_combobox()
	AutoBandWindowConfig.refresh_min_rank()
	AutoBandWindowConfig.refresh_min_rank_healer()
	ButtonSetPressedFlag(AutoBandWindowConfig.name .. "MapIconCheckBox", AutoBand.saved.displayicon)
	ButtonSetPressedFlag(AutoBandWindowConfig.name .. "KickToofarCheckBox", AutoBand.saved.autokick_toofar_enabled)
	ButtonSetPressedFlag(AutoBandWindowConfig.name .. "KickLowRankCheckBox", AutoBand.saved.autokick_lowrnk_enabled)
    ButtonSetPressedFlag(AutoBandWindowConfig.name .. "KickStealthersCheckBox", AutoBand.saved.autokick_we_wh_enabled)
	ButtonSetPressedFlag(AutoBandWindowConfig.name .. "GuildPriorityCheckBox", AutoBand.saved.guild_priority_enabled)
    ButtonSetPressedFlag(AutoBandWindowConfig.name .. "AltCheckCheckBox", AutoBand.saved.alt_speccheck_enabled)
	ButtonSetPressedFlag(AutoBandWindowConfig.name .. "DpsWeightingCheckBox", AutoBand.saved.dps_weighting_enabled)
	AutoBandWindow.toggle_mapicon(AutoBand.saved.displayicon)
	WindowSetShowing(AutoBandWindowConfig.name, true)
end

function AutoBandWindowConfig.OnClearTemplateButton()
	if (ButtonGetDisabledFlag(AutoBandWindowConfig.name .. "ClearTemplateButton")) then
		return
	end
	AutoBand.saved.default_template = AB_const.EMPTY_TEMPLATE
	AutoBandWindowConfig.refresh_default_template()
end

function AutoBandWindowConfig.OnPressTimeMinusButton()
	AutoBand.saved.autokick_period = AutoBand.saved.autokick_period - 1
	if (AutoBand.saved.autokick_period < 0) then
		AutoBand.saved.autokick_period = AB_const.MAX_KICKOFF_TIME
	end
	LabelSetText(AutoBandWindowConfig.name .. "AutoKickTimeoutLabel", L"" .. AutoBand.saved.autokick_period)
	if AutoBand.has_permission() then
		--AutoBand.enqueue_command("/wb [AutoBand] Timeout for auto kick players who are far away from leader now " .. AutoBand.saved.autokick_period .. "min")
	end
end

function AutoBandWindowConfig.OnPressTimePlusButton()
	AutoBand.saved.autokick_period = AutoBand.saved.autokick_period + 1
	if (AutoBand.saved.autokick_period > AB_const.MAX_KICKOFF_TIME) then
		AutoBand.saved.autokick_period = 0
	end
	LabelSetText(AutoBandWindowConfig.name .. "AutoKickTimeoutLabel", L"" .. AutoBand.saved.autokick_period)
	if AutoBand.has_permission() then
		--AutoBand.enqueue_command("/wb [AutoBand] Timeout for auto kick players who are far away from leader now " .. AutoBand.saved.autokick_period .. "min")
	end

end

function AutoBandWindowConfig.OnPressRankMinusButton()
    AutoBand.saved.min_rank = AutoBand.saved.min_rank - 1
    if (AutoBand.saved.min_rank < 1) then
        AutoBand.saved.min_rank = AB_const.MAXIMUM_RANK
    end
    -- Ensure healer rank <= default rank
    if (AutoBand.saved.min_rank_healer > AutoBand.saved.min_rank) then
        AutoBand.saved.min_rank_healer = AutoBand.saved.min_rank
    end
    LabelSetText(AutoBandWindowConfig.name .. "MinRankValueLabel", L"" .. AutoBand.saved.min_rank)
    LabelSetText(AutoBandWindowConfig.name .. "MinHealerRankValueLabel", L"" .. AutoBand.saved.min_rank_healer)
end

function AutoBandWindowConfig.OnPressRankPlusButton()
    AutoBand.saved.min_rank = AutoBand.saved.min_rank + 1
    if (AutoBand.saved.min_rank > AB_const.MAXIMUM_RANK ) then
        AutoBand.saved.min_rank = 1
    end
    -- Ensure healer rank <= default rank
    if (AutoBand.saved.min_rank_healer > AutoBand.saved.min_rank) then
        AutoBand.saved.min_rank_healer = AutoBand.saved.min_rank
    end
    LabelSetText(AutoBandWindowConfig.name .. "MinRankValueLabel", L"" .. AutoBand.saved.min_rank)
    LabelSetText(AutoBandWindowConfig.name .. "MinHealerRankValueLabel", L"" .. AutoBand.saved.min_rank_healer)
end

function AutoBandWindowConfig.OnPressHealerRankMinusButton()
    AutoBand.saved.min_rank_healer = AutoBand.saved.min_rank_healer - 1
    if (AutoBand.saved.min_rank_healer < 1) then
        AutoBand.saved.min_rank_healer = AB_const.MAXIMUM_RANK
    end
    -- Ensure healer rank <= default rank
    if (AutoBand.saved.min_rank_healer > AutoBand.saved.min_rank) then
        AutoBand.saved.min_rank_healer = AutoBand.saved.min_rank
    end
    LabelSetText(AutoBandWindowConfig.name .. "MinHealerRankValueLabel", L"" .. AutoBand.saved.min_rank_healer)
end

function AutoBandWindowConfig.OnPressHealerRankPlusButton()
    AutoBand.saved.min_rank_healer = AutoBand.saved.min_rank_healer + 1
    if (AutoBand.saved.min_rank_healer > AB_const.MAXIMUM_RANK ) then
        AutoBand.saved.min_rank_healer = 1
    end
    -- Ensure healer rank <= default rank
    if (AutoBand.saved.min_rank_healer > AutoBand.saved.min_rank) then
        AutoBand.saved.min_rank_healer = AutoBand.saved.min_rank
    end
    LabelSetText(AutoBandWindowConfig.name .. "MinHealerRankValueLabel", L"" .. AutoBand.saved.min_rank_healer)
end

function AutoBandWindowConfig.refresh_kickoff() 
	LabelSetText(AutoBandWindowConfig.name .. "AutoKickTimeoutLabel", L"" .. AutoBand.saved.autokick_period)
	ButtonSetPressedFlag(AutoBandWindowConfig.name .. "KickCheckBox", AutoBand.saved.autokick_enabled)
end

function AutoBandWindowConfig.refresh_min_rank() 
	LabelSetText(AutoBandWindowConfig.name .. "MinRankValueLabel", L"" .. AutoBand.saved.min_rank)
end

function AutoBandWindowConfig.refresh_min_rank_healer() 
	LabelSetText(AutoBandWindowConfig.name .. "MinHealerRankValueLabel", L"" .. AutoBand.saved.min_rank_healer)
end

function AutoBandWindowConfig.refresh_dps_weights()
    LabelSetText(AutoBandWindowConfig.name .. "MaxMdpsValueLabel", L"" .. AutoBand.saved.max_mdps)
    LabelSetText(AutoBandWindowConfig.name .. "MaxRdpsValueLabel", L"" .. AutoBand.saved.max_rdps)
    ButtonSetPressedFlag(AutoBandWindowConfig.name .. "DpsWeightingCheckBox", AutoBand.saved.dps_weighting_enabled)
end

function AutoBandWindowConfig.OnKickCheckBox()
	AutoBand.saved.autokick_enabled = ButtonGetPressedFlag(AutoBandWindowConfig.name .. "KickCheckBox")
--[[	if AutoBand.has_permission() then
		if AutoBand.saved.autokick_enabled then
			AutoBand.enqueue_command("/wb [AutoBand] Auto forming 8-8-8 wb ENABLED!")
		else
			AutoBand.enqueue_command("/wb [AutoBand] Auto forming 8-8-8 wb DISABLED!")
		end
	end]]--
	AB_util.print("Auto kick to form 8-8-8 wb: " .. tostring(AutoBand.saved.autokick_enabled))
end

function AutoBandWindowConfig.OnKickToofarCheckBox()
	AutoBand.saved.autokick_toofar_enabled = ButtonGetPressedFlag(AutoBandWindowConfig.name .. "KickToofarCheckBox")
	if AutoBand.has_permission() then
		if AutoBand.saved.autokick_toofar_enabled then
			AutoBand.enqueue_command("/wb " .. AB_const.FORMATTED_PREFIX_RAW_WSPACE .. "Autokick players who are far away from leader ENABLED! Follow the leader PLEASE!")
		else
            AutoBand.enqueue_command("/wb " .. AB_const.FORMATTED_PREFIX_RAW_WSPACE .. "Autokick players who are far away from leader DISABLED! Free move!")
			warned = {}
			toofar = {}
            toofar_old = {}
            toofar_not_changed = {}
		end
	end

	AB_util.print("Auto kick too far players: " .. tostring(AutoBand.saved.autokick_toofar_enabled))
end

function AutoBandWindowConfig.OnKickLowRankCheckBox()
    AutoBand.saved.autokick_lowrnk_enabled = ButtonGetPressedFlag(AutoBandWindowConfig.name .. "KickLowRankCheckBox")
    AB_util.print("Auto kick low rank players: " .. tostring(AutoBand.saved.autokick_lowrnk_enabled))
end

function AutoBandWindowConfig.OnKickStealthersCheckBox()
    AutoBand.saved.autokick_we_wh_enabled = ButtonGetPressedFlag(AutoBandWindowConfig.name .. "KickStealthersCheckBox")
    AB_util.print("Auto kick stealthers: " .. tostring(AutoBand.saved.autokick_we_wh_enabled))
end

function AutoBandWindowConfig.OnDpsWeightingCheckBox()
    AutoBand.saved.dps_weighting_enabled = ButtonGetPressedFlag(AutoBandWindowConfig.name .. "DpsWeightingCheckBox")
    AB_util.print("DPS Weighting for 8-8-8: " .. tostring(AutoBand.saved.dps_weighting_enabled))
     if not AutoBand.saved.autokick_enabled then
         AB_util.print("[Warning] DPS weighting only applies when 'Auto form 8-8-8 wb' is enabled.")
     end
end

function AutoBandWindowConfig.OnPressMaxMdpsPlusButton()
    if AutoBand.saved.max_mdps < AB_const.MAX_DPS_TOTAL then
        AutoBand.saved.max_mdps = AutoBand.saved.max_mdps + 1
        AutoBand.saved.max_rdps = AB_const.MAX_DPS_TOTAL - AutoBand.saved.max_mdps -- Adjust RDPS
        AutoBandWindowConfig.refresh_dps_weights()
    end
end

function AutoBandWindowConfig.OnPressMaxMdpsMinusButton()
    if AutoBand.saved.max_mdps > 0 then
        AutoBand.saved.max_mdps = AutoBand.saved.max_mdps - 1
        AutoBand.saved.max_rdps = AB_const.MAX_DPS_TOTAL - AutoBand.saved.max_mdps -- Adjust RDPS
        AutoBandWindowConfig.refresh_dps_weights()
    end
end

function AutoBandWindowConfig.OnPressMaxRdpsPlusButton()
     if AutoBand.saved.max_rdps < AB_const.MAX_DPS_TOTAL then
        AutoBand.saved.max_rdps = AutoBand.saved.max_rdps + 1
        AutoBand.saved.max_mdps = AB_const.MAX_DPS_TOTAL - AutoBand.saved.max_rdps -- Adjust MDPS
        AutoBandWindowConfig.refresh_dps_weights()
    end
end

function AutoBandWindowConfig.OnPressMaxRdpsMinusButton()
    if AutoBand.saved.max_rdps > 0 then
        AutoBand.saved.max_rdps = AutoBand.saved.max_rdps - 1
        AutoBand.saved.max_mdps = AB_const.MAX_DPS_TOTAL - AutoBand.saved.max_rdps -- Adjust MDPS
        AutoBandWindowConfig.refresh_dps_weights()
    end
end

function AutoBandWindowConfig.OnResetConfig()
	AutoBand.saved.autokick_enabled = AB_const.AUTOKICK
	AutoBand.saved.autokick_period = AB_const.KICK_PERIOD
    AutoBand.saved.autokick_toofar_enabled = AB_const.AUTOKICKTOOFAR
	AutoBand.saved.autokick_lowrnk_enabled = AB_const.KICKLOWRNK
    AutoBand.saved.guild_priority_enabled  = AB_const.GUILDPRIORITY  	
	AutoBand.saved.default_template = AB_const.EMPTY_TEMPLATE
	AutoBand.saved.org_algo_mode = AB_const.DEFAULT_ORG_ALGO
	AutoBand.saved.min_rank = AB_const.MINIMUM_RANK
	AutoBand.saved.min_rank_healer = AB_const.MINIMUM_RANK_HEALER
	AutoBand.saved.displayicon = AutoBand.saved.displayicon
	AutoBand.saved.alt_speccheck_enabled = AB_const.ALTCHECK
    AutoBand.saved.dps_weighting_enabled = AB_const.DPS_WEIGHTING_ENABLED
    AutoBand.saved.max_mdps = AB_const.DEFAULT_MAX_MDPS
    AutoBand.saved.max_rdps = AB_const.DEFAULT_MAX_RDPS
    AutoBand.saved.autokick_we_wh_enabled = AB_const.AUTOKICK_WE_WH
	AutoBandWindowConfig.refresh_dps_weights()
	AutoBandWindowConfig.Show()
end

function AutoBandWindowConfig.OnAltCheckCheckBox()
	AutoBand.saved.alt_speccheck_enabled = ButtonGetPressedFlag(AutoBandWindowConfig.name .. "AltCheckCheckBox")
	AB_util.print("Use alt spec check: " .. tostring(AutoBand.saved.alt_speccheck_enabled))
end

function AutoBandWindowConfig.OnMapIconCheckBox()
	AutoBandWindow.toggle_mapicon(ButtonGetPressedFlag(AutoBandWindowConfig.name .. "MapIconCheckBox"))
end

function AutoBandWindowConfig.OnGuildPriorityCheckBox()
	AutoBand.saved.guild_priority_enabled = ButtonGetPressedFlag(AutoBandWindowConfig.name .. "GuildPriorityCheckBox")
	AB_util.print("Guild priority for auto-kick: " .. tostring(AutoBand.saved.guild_priority_enabled))
end