-- ab_wb.lua

AB_wb = {
	group = {},
	player_count = 0,
	group_count = 0,
	fullgroup_count = 0,
	remainder_count = 0,
	MAX_GROUPS = 0			-- max number of groups (wb=4, sc=6)
}

-- default ctor
function AB_wb:new(t)
	t = t or {}
	setmetatable(t, self)
	self.__index = self
	return t
end

function AB_wb:set_groups()
	self.group = {}
	self.player_count = 0 
	self.MAX_GROUPS = AB_const.MAX_WB_GROUPS
	for i= 1, AB_const.MAX_WB_GROUPS do
		self.group[i] = {}
	end
end

function AB_wb:add_to_gid(role, pid, gid)
	local player = {["name"]= "Fake_" .. gid .. "_" .. pid }
	for key, fake in pairs(AB_const.FAKE_PLAYERS[role]) do
		player[key] = fake
	end
	player.role = role
	player.online = false
	player.zid = 0
--	self.group[gid] = self.group[gid] or {}
	table.insert(self.group[gid], player)
	self.player_count = self.player_count + 1
end

-- loads group data from scenario party
function AB_wb:load_from_scdata()
	self.group = {}
	self.player_count = 0
	local current_players = {}

	local scdata = GameData.GetScenarioPlayerGroups()	-- get scenario wb
	for _, player in ipairs(scdata) do
		if (self.group[player.sgroupindex] == nil) then
			self.group[player.sgroupindex] = {}	-- create group
		end
		-- Conditionally use the alt spec check
		local name = tostring(player.name):lower()
		local override = AutoBand.saved.custom_roles and AutoBand.saved.custom_roles[name]
        if override and (override == AB_const.TANK 
                         or override == AB_const.HEALER 
                         or override == AB_const.MDPS 
                         or override == AB_const.RDPS) then
            player.role = override
		elseif (AutoBand.saved.alt_speccheck_enabled) then
			player.role = AB_util.career_category(AB_wb:getArcheType(player))
		else
			player.role = AB_util.career_category(player.careerLine)
		end
		self.group[player.sgroupindex][player.sgroupslotnum] = player
		self.player_count = self.player_count + 1
		AB_wb:track_role(player, current_players)
	end
	AB_wb:remove_missing_players(current_players)
	need_role_update = false
	self.MAX_GROUPS = 6
	self:recalc_counters()
end

-- loads group data from warband party
function AB_wb:load_from_wbdata()
	self.group = {}
	self.player_count = 0
	local current_players = {}
	local wbdata = GetBattlegroupMemberData()		-- get warband
	for i in ipairs(wbdata) do
		self.group[i] = {}
	end
	for gid, grp in ipairs(wbdata) do
		for pid, player in ipairs(grp.players) do
			-- Conditionally use the alt spec check
			local name = tostring(player.name):lower()
			local override = AutoBand.saved.custom_roles and AutoBand.saved.custom_roles[name]
			if override and (override == AB_const.TANK 
							or override == AB_const.HEALER 
							or override == AB_const.MDPS 
							or override == AB_const.RDPS) then
				player.role = override
			elseif (AutoBand.saved.alt_speccheck_enabled) then
				player.role = AB_util.career_category(AB_wb:getArcheType(player))
			else
				player.role = AB_util.career_category(player.careerLine)
			end
			table.insert(self.group[gid], player)
			self.player_count = self.player_count + 1
			AB_wb:track_role(player, current_players)
		end
	end
	AB_wb:remove_missing_players(current_players)
	need_role_update = false
	self.MAX_GROUPS = AB_const.MAX_WB_GROUPS
	self:recalc_counters()
end

-- Function that checks if player is using alt-spec and returns careerLine value accordingly
function AB_wb:getArcheType(player)
	for _, p in pairs(RoRGroupScoreboard.playersDataRaw) do
		if p.name == towstring(player.name) and p.archtype > 0 then
			if player.careerLine == GameData.CareerLine.ZEALOT then
				-- Treat dps Zealot as Magus (rDPS)
				return GameData.CareerLine.MAGUS
			elseif player.careerLine == GameData.CareerLine.WARRIOR_PRIEST then
				-- Treat dps Warrior Priest as Slayer (mDPS)
				return GameData.CareerLine.SLAYER
			elseif player.careerLine == GameData.CareerLine.RUNE_PRIEST then
				-- Treat dps Rune Priest as Engineer (rDPS)
				return GameData.CareerLine.ENGINEER
			elseif player.careerLine == GameData.CareerLine.ARCHMAGE then
				-- Treat dps Archmage as Engineer (rDPS)
				return GameData.CareerLine.ENGINEER
			elseif player.careerLine == GameData.CareerLine.SHAMAN then
				-- Treat dps Shaman as Magus (rDPS)
				return GameData.CareerLine.MAGUS 
			elseif player.careerLine == GameData.CareerLine.DISCIPLE then
				-- Treat dps Disciple of Khaine as Choppa (mDPS)
				return GameData.CareerLine.CHOPPA
			elseif player.careerLine == GameData.CareerLine.SQUIG_HERDER then
				-- Treat melee Squig Herder as Choppa (mDPS)
				return GameData.CareerLine.CHOPPA
			elseif player.careerLine == GameData.CareerLine.SHADOW_WARRIOR then
				-- Treat melee Shadow Warrior as Slayer (mDPS)
				return GameData.CareerLine.SLAYER
			end
		end
	end
	-- No alt-spec found return actual careerLine
	return player.careerLine
end

function AB_wb:track_role(player, current_players)
	local name = tostring(player.name)
	local new_role = tostring(player.role)
	current_players[name] = true

	local prev_role = roles_last[name]
	local icon = AB_const.ICONS[new_role] or ""
	
	if AutoBand.saved.printrole_enabled then
		if not prev_role then
			AB_util.print(name .. " assigned role " .. icon .. " " .. new_role .. ".")
		elseif prev_role ~= new_role then
			local prev_icon = AB_const.ICONS[prev_role] or ""
			AB_util.print(name .. " switched role from " ..prev_icon .. " " .. prev_role .. " to " .. icon .. " " ..  new_role .. ".")
		end
	end

	roles_last[name] = new_role
end

function AB_wb:remove_missing_players(current_players)
	local MAX_DETAILED_LEAVERS = 6
	local leavers = {}

	for name in pairs(roles_last) do
		if not current_players[name] then
			table.insert(leavers, name)
		end
	end

	if AutoBand.saved.printrole_enabled and #leavers > 0 then
		if #leavers <= MAX_DETAILED_LEAVERS then
			for _, name in ipairs(leavers) do
				local role = roles_last[name]
				local icon = AB_const.ICONS[role] or ""
				AB_util.print(name .. " (" .. icon .. " " .. role .. ") left.")
			end
		else
			AB_util.print(#leavers .. " players cleared from the the warband.")
		end
	end

	for _, name in ipairs(leavers) do
		roles_last[name] = nil
	end
end

-- iterates over every player in data calling "f(group id, player object, player position)"
function AB_wb:foreach_player(func)
	for i, grp in ipairs(self.group) do
		for j, player in ipairs(grp) do
			func(i, player, j)
		end
	end
end

--
function AB_wb:recalc_counters()
	self.group_count = math.ceil(self.player_count / AB_const.GROUP_SIZE)		-- total number of groups
	self.fullgroup_count = math.floor(self.player_count / AB_const.GROUP_SIZE)	-- full groups
	self.remainder = self.player_count % AB_const.GROUP_SIZE			-- last group size
	if (self.remainder > math.floor(AB_const.GROUP_SIZE / 2)) then
		self.fullgroup_count = self.fullgroup_count + 1
		self.remainder = 0
	end
end

--
function AB_wb:print()
	AB_util.debug("groups: " .. self.group_count)
	AB_util.debug("full groups: " .. self.fullgroup_count)
	AB_util.debug("remainder group size: " .. self.remainder)
	self:foreach_player(
		function (gid, player, pid)
			AB_util.debug("gid " .. gid .. " " .. tostring(player.name) .. " " .. player.role)
		end
	)
end