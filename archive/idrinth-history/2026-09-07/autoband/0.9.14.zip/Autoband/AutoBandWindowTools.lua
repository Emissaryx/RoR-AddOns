--
AutoBandWindowTools = {}

AutoBandWindowTools.name = "AutoBandWindowToolsTab"

AutoBandWindowTools.tools_data = {
	[AB_const.KICK_OFFLINE] = { ["button"] = "KickOfflineCheckBox" , ["label"] = "KickOfflineLabel", ["func_kick"]= AutoBand.cmd_kick_toofar, ["func_print"] = AutoBand.cmd_list_offline},
	[AB_const.KICK_ZONE] = { ["button"] = "KickZoneCheckBox" , ["label"] = "KickZoneLabel", ["func_kick"]= AutoBand.cmd_kick_notinzone, ["func_print"] = AutoBand.cmd_list_zone},
	[AB_const.KICK_RANK] = { ["button"] = "KickRankCheckBox" , ["label"] = "KickRankLabel", ["func_kick"]= AutoBand.cmd_kick_rank, ["func_print"] = AutoBand.cmd_list_rank} }


function AutoBandWindowTools.Initialize()
	LabelSetText(AutoBandWindowTools.name .. "KickLabel", L"Manage Players")

	for fid, func in pairs(AutoBandWindowTools.tools_data) do
		LabelSetText(AutoBandWindowTools.name .. func["label"], towstring(AB_const.LABEL_KICK[fid]))
		ButtonSetCheckButtonFlag(AutoBandWindowTools.name .. func["button"], true)
		ButtonSetPressedFlag(AutoBandWindowTools.name .. func["button"],  AutoBand.saved.kick_func_enabled[fid])
	end

	ButtonSetText(AutoBandWindowTools.name .. "PrintButton", L"Print")
	ButtonSetText(AutoBandWindowTools.name .. "KickButton", L"Kick")
	
    -- Search Roles Section Initialisation -- NEW
    LabelSetText(AutoBandWindowTools.name .. "SearchRoleLabel", L"Search for Players")
    LabelSetText(AutoBandWindowTools.name .. "SearchRoleChan1Label", L"/1")
    LabelSetText(AutoBandWindowTools.name .. "SearchRoleChanT4Label", L"/t4")
    LabelSetText(AutoBandWindowTools.name .. "SearchRoleChan5Label", L"/5")

    -- Set initial state for Search checkboxes
    ButtonSetCheckButtonFlag(AutoBandWindowTools.name .. "SearchRoleChan1CheckBox", true) -- Enable check button behavior
    ButtonSetPressedFlag(AutoBandWindowTools.name .. "SearchRoleChan1CheckBox", true)     -- Check it
    ButtonSetDisabledFlag(AutoBandWindowTools.name .. "SearchRoleChan1CheckBox", true)    -- Disable it

    ButtonSetCheckButtonFlag(AutoBandWindowTools.name .. "SearchRoleChanT4CheckBox", true) -- Enable check button behavior
    ButtonSetPressedFlag(AutoBandWindowTools.name .. "SearchRoleChanT4CheckBox", false)    -- Default unchecked

    ButtonSetCheckButtonFlag(AutoBandWindowTools.name .. "SearchRoleChan5CheckBox", true)  -- Enable check button behavior
    ButtonSetPressedFlag(AutoBandWindowTools.name .. "SearchRoleChan5CheckBox", false)     -- Default unchecked

    ButtonSetText(AutoBandWindowTools.name .. "SearchRoleButton", L"Search")
    -- END NEW

	-- Button bar
	ButtonSetText(AutoBandWindowTools.name .. "ResetButton", L"Restore Defaults")
end


function AutoBandWindowTools.Hide()
	WindowSetShowing(AutoBandWindowTools.name, false)
end


function AutoBandWindowTools.Show()
	WindowSetShowing(AutoBandWindowTools.name, true)
end


function AutoBandWindowTools.reset_kick_enabled()
	for fid, func in pairs(AutoBandWindowTools.tools_data) do
		ButtonSetPressedFlag(AutoBandWindowTools.name .. func["button"], AB_const.KICK_FUNC_DEFAULT[fid])
		AutoBand.saved.kick_func_enabled[fid] = AB_const.KICK_FUNC_DEFAULT[fid]
	end
end


function AutoBandWindowTools.OnKickOfflineCheckBox()
	AutoBand.saved.kick_func_enabled[AB_const.KICK_OFFLINE] = ButtonGetPressedFlag(AutoBandWindowTools.name .. "KickOfflineCheckBox")
end


function AutoBandWindowTools.OnKickZoneCheckBox()
	AutoBand.saved.kick_func_enabled[AB_const.KICK_ZONE] = ButtonGetPressedFlag(AutoBandWindowTools.name .. "KickZoneCheckBox")
end


function AutoBandWindowTools.OnKickRankCheckBox()
	AutoBand.saved.kick_func_enabled[AB_const.KICK_RANK] = ButtonGetPressedFlag(AutoBandWindowTools.name .. "KickRankCheckBox")
end


function AutoBandWindowTools.OnKickButton()
	for fid, kick_func in pairs(AutoBandWindowTools.tools_data) do
		-- to make sure that you read the values from check boxes
		AutoBand.saved.kick_func_enabled[fid] = ButtonGetPressedFlag(AutoBandWindowTools.name .. kick_func["button"])
		if (AutoBand.saved.kick_func_enabled[fid]) then
			kick_func.func_kick()
		end
	end
end

function AutoBandWindowTools.OnPrintButton()
	AB_util.print("Warband Report ")
	for fid, kick_func in pairs(AutoBandWindowTools.tools_data) do
		-- to make sure that you read the values from check boxes
		AutoBand.saved.kick_func_enabled[fid] = ButtonGetPressedFlag(AutoBandWindowTools.name .. kick_func["button"])
		if (AutoBand.saved.kick_func_enabled[fid]) then
			kick_func.func_print()
		end
	end
end

-- NEW FUNCTION for the Search button
function AutoBandWindowTools.OnSearchRoleButton()
    local args = {} -- Table to hold the channel arguments

    -- Check the state of the /t4 checkbox
    if ButtonGetPressedFlag(AutoBandWindowTools.name .. "SearchRoleChanT4CheckBox") then
        table.insert(args, "t4")
    end

    -- Check the state of the /5 checkbox
    if ButtonGetPressedFlag(AutoBandWindowTools.name .. "SearchRoleChan5CheckBox") then
        table.insert(args, "5")
    end

    -- Call the core AutoBand function with the collected arguments
    -- Note: /1 is implicitly handled by AutoBand.cmd_search_roles
    AutoBand.cmd_search_roles(args)
end

function AutoBandWindowTools.OnResetTools()
	AB_util.debug(AutoBand.saved.kick_func_enabled)
	AB_util.debug(AB_const.KICK_FUNC_DEFAULT)
	AutoBandWindowTools.reset_kick_enabled()
	AutoBandWindowTools.Show()
end
