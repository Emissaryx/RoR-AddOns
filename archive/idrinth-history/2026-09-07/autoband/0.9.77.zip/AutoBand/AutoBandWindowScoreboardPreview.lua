AutoBandWindowScoreboardPreview = {}

AutoBandWindowScoreboardPreview.name = "AutoBandWindowScoreboardPreview"
AutoBandWindowScoreboardPreview.pending_commands = nil
AutoBandWindowScoreboardPreview.initialized = false

local function preview_to_wstring(text)
    if type(towstring) == "function" then
        return towstring(text or "")
    end
    return text or ""
end

local function preview_window_exists(name)
    if type(DoesWindowExist) ~= "function" then
        return false
    end
    local ok_exists, exists = pcall(DoesWindowExist, name)
    return ok_exists and exists == true
end

local function build_preview_lines(commands)
    local lines = {}
    if type(commands) ~= "table" then
        return lines
    end
    for i = 1, #commands do
        local line = tostring(commands[i] or "")
        line = string.gsub(line, "^/wb%s+", "")
        line = string.gsub(line, '%<LINK[^>]-text="([^"]*)"[^>]*%>', "%1")
        lines[#lines + 1] = line
    end
    return lines
end

local function build_summary_text(commands)
    return "Review the formatted preview below.\n"
        .. "Confirm to send it to /wb."
end

function AutoBandWindowScoreboardPreview.Initialize()
    if AutoBandWindowScoreboardPreview.initialized == true then
        return
    end
    AutoBandWindowScoreboardPreview.initialized = true

    if type(LabelSetText) == "function" then
        LabelSetText(AutoBandWindowScoreboardPreview.name .. "TitleBarText", L"Send Scoreboard to WB?")
    end
    if type(ButtonSetText) == "function" then
        ButtonSetText(AutoBandWindowScoreboardPreview.name .. "ConfirmButton", L"Send")
        ButtonSetText(AutoBandWindowScoreboardPreview.name .. "CancelButton", L"Cancel")
    end
end

function AutoBandWindowScoreboardPreview.EnsureWindow()
    if preview_window_exists(AutoBandWindowScoreboardPreview.name) then
        AutoBandWindowScoreboardPreview.Initialize()
        return true
    end

    if type(CreateWindow) ~= "function" then
        return false
    end

    local ok_create = pcall(CreateWindow, AutoBandWindowScoreboardPreview.name, false)
    if not ok_create then
        return false
    end

    if type(DoesWindowExist) == "function" and not preview_window_exists(AutoBandWindowScoreboardPreview.name) then
        return false
    end

    AutoBandWindowScoreboardPreview.Initialize()
    return true
end

function AutoBandWindowScoreboardPreview.Hide()
    AutoBandWindowScoreboardPreview.pending_commands = nil
    if type(WindowSetShowing) == "function" and preview_window_exists(AutoBandWindowScoreboardPreview.name) then
        WindowSetShowing(AutoBandWindowScoreboardPreview.name, false)
    end
end

function AutoBandWindowScoreboardPreview.OnCancel()
    AutoBandWindowScoreboardPreview.Hide()
end

function AutoBandWindowScoreboardPreview.OnConfirm()
    local commands = AutoBandWindowScoreboardPreview.pending_commands
    AutoBandWindowScoreboardPreview.Hide()

    if type(commands) ~= "table" then
        return
    end

    for i = 1, #commands do
        AutoBand.enqueue_command(commands[i], nil, nil, "scoreboard")
    end
end

function AutoBandWindowScoreboardPreview.ShowModal(commands)
    if type(commands) ~= "table" or #commands == 0 then
        return false
    end
    if not AutoBandWindowScoreboardPreview.EnsureWindow() then
        return false
    end

    AutoBandWindowScoreboardPreview.pending_commands = commands
    AutoBandWindowScoreboardPreview.Initialize()

    if type(LabelSetText) == "function" then
        LabelSetText(
            AutoBandWindowScoreboardPreview.name .. "SummaryLabel",
            preview_to_wstring(build_summary_text(commands))
        )
        local preview_lines = build_preview_lines(commands)
        LabelSetText(
            AutoBandWindowScoreboardPreview.name .. "DetailsLabel",
            preview_to_wstring(table.concat(preview_lines, "\n\n"))
        )
    end
    if type(WindowSetShowing) == "function" then
        WindowSetShowing(AutoBandWindowScoreboardPreview.name, true)
    end
    return true
end
