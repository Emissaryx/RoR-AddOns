-- AutoBand.lua

AutoBand = {}
tanks_t_old = {}
healers_t_old = {}
dps_t_old = {}
mdps_t_old = {}
rdps_t_old = {}
roles_last = {}
toofar = {}
toofar_old = {}
toofar_not_changed = {}
warned = {}
ab_auto_note_counter = 12
ab_guild_member_names = {}
AutoBand.CareerLineToNameMap = {}
AutoBand.map_point_lookup_cache = nil
AutoBand.original_add_group_menu_items = nil
AutoBand.original_show_menu = nil
AutoBand.right_clicked_player_name = nil

local AVAILABLE_COLORS = AB_const.AVAILABLE_COLORS
local MAX_MAP_POINTS = 511
local DISTANCE_FIX_COEFFICIENT = 1 / 1.06
local MapPointTypeFilter = {
    [SystemData.MapPips.PLAYER] = true,
    [SystemData.MapPips.GROUP_MEMBER] = true,
    [SystemData.MapPips.WARBAND_MEMBER] = true,
    [SystemData.MapPips.DESTRUCTION_ARMY] = true,
    [SystemData.MapPips.ORDER_ARMY] = true
}

local function BuildMapPointLookup()
    if AutoBand.map_point_lookup_cache then
        return AutoBand.map_point_lookup_cache
    end

    local lookup = {}
    for i = 1, MAX_MAP_POINTS do
        local mpd = GetMapPointData("EA_Window_OverheadMapMapDisplay", i)
        if mpd and MapPointTypeFilter[mpd.pointType] and mpd.name then
            local fixed = AutoBand.FixString(mpd.name)
            if fixed then
                lookup[fixed] = mpd
            end
        end
    end

    AutoBand.map_point_lookup_cache = lookup
    return lookup
end

function AutoBand.init()
    --------------------------------------------------------------------------
    -- 1) MODULE VARIABLES
    --------------------------------------------------------------------------
    AutoBand.allow_guild_prefix_override = false
    AutoBand.cache_dirty                 = true
    AutoBand.cached_wb                   = nil
    AutoBand.cmd_queue                   = {}
    AutoBand.cmd_current                 = nil
    AutoBand.current_purpose             = nil
    AutoBand.debugon                     = false
    AutoBand.elapsed                     = 0
    AutoBand.faction                     = nil
    AutoBand.factionDetermined           = false
    AutoBand.gizilon                     = false
    AutoBand.has_shortslash              = false
    AutoBand.live_org_verbose            = false
    AutoBand.nameDetermined              = false
    AutoBand.need_role_update            = false
    AutoBand.offliners_countdown         = {}
    AutoBand.playername                  = nil
    AutoBand.race                        = nil
    AutoBand.raceDetermined              = false

    --------------------------------------------------------------------------
    -- 2) PERSISTENT SETTINGS
    --------------------------------------------------------------------------
    -- A) CORE "SAVED" TABLE & CUSTOM ROLES
    AutoBand.saved               = AutoBand.saved or {}
    AutoBand.saved.custom_roles  = AutoBand.saved.custom_roles or {}

    -- A.1) ROLE COMPOSITION LIMITS
    AutoBand.saved.max_tanks   = AutoBand.saved.max_tanks   or AB_const.DEFAULT_MAX_TANKS
    AutoBand.saved.max_healers = AutoBand.saved.max_healers or AB_const.DEFAULT_MAX_HEALERS
    AutoBand.saved.max_dps     = AutoBand.saved.max_dps     or AB_const.DEFAULT_MAX_DPS

    -- Validate that loaded/default roles add up to 24
    if AutoBand.saved.max_tanks + AutoBand.saved.max_healers + AutoBand.saved.max_dps ~= 24 then
        AB_util.print("[Warning] Saved role counts did not sum to 24. Resetting to defaults (" .. AB_const.DEFAULT_MAX_TANKS .. "-" .. AB_const.DEFAULT_MAX_HEALERS .. "-" .. AB_const.DEFAULT_MAX_DPS .. ").")
        AutoBand.saved.max_tanks   = AB_const.DEFAULT_MAX_TANKS
        AutoBand.saved.max_healers = AB_const.DEFAULT_MAX_HEALERS
        AutoBand.saved.max_dps     = AB_const.DEFAULT_MAX_DPS
    end

    -- B) CORE TOGGLES
    if AutoBand.saved.autokick_enabled        == nil then AutoBand.saved.autokick_enabled        = AB_const.AUTOKICK          end
    if AutoBand.saved.autokick_toofar_enabled == nil then AutoBand.saved.autokick_toofar_enabled = AB_const.AUTOKICKTOOFAR    end
    if AutoBand.saved.autokick_low_rank_enabled == nil then AutoBand.saved.autokick_low_rank_enabled = AB_const.KICKLOWRNK        end
    if AutoBand.saved.autonote_enabled        == nil then AutoBand.saved.autonote_enabled        = AB_const.AUTONOTE          end
    if AutoBand.saved.notify_buffs_enabled    == nil then AutoBand.saved.notify_buffs_enabled    = true                       end
    if AutoBand.saved.autokick_we_wh_enabled  == nil then AutoBand.saved.autokick_we_wh_enabled  = AB_const.AUTOKICK_WE_WH    end
    if AutoBand.saved.autokick_rvrzone_enabled== nil then AutoBand.saved.autokick_rvrzone_enabled= AB_const.AUTOKICKRVRZONE   end
    if AutoBand.saved.bw_sorc_as_mdps         == nil then AutoBand.saved.bw_sorc_as_mdps         = AB_const.BW_SORC_AS_MDPS   end
    if AutoBand.saved.restrict_same_race      == nil then AutoBand.saved.restrict_same_race      = AB_const.RESTRICT_RACE     end
    if AutoBand.saved.autokick_ignorelist_enabled == nil then AutoBand.saved.autokick_ignorelist_enabled = AB_const.AUTOKICK_IGNORELIST end

    -- C) KICK TIMERS & RANK RULES
    AutoBand.saved.autokick_period   = AutoBand.saved.autokick_period   or AB_const.KICK_PERIOD
    AutoBand.saved.min_rank          = AutoBand.saved.min_rank          or AB_const.MINIMUM_RANK
    AutoBand.saved.min_rank_healer   = AutoBand.saved.min_rank_healer   or AB_const.MINIMUM_RANK_HEALER

    if AutoBand.saved.min_rank_healer > AutoBand.saved.min_rank then
        local old_healer_rank         = AutoBand.saved.min_rank_healer
        AutoBand.saved.min_rank_healer = AutoBand.saved.min_rank
    end

    -- D) TEMPLATES & ORGANIZATION ALGORITHM
    AutoBand.saved.default_template = AutoBand.saved.default_template or AB_const.EMPTY_TEMPLATE
    AutoBand.saved.templates        = AutoBand.saved.templates        or {}
    AutoBand.saved.org_algo_mode    = AutoBand.saved.org_algo_mode    or AB_const.DEFAULT_ORG_ALGO
    AutoBand.saved.org_algo_role    = AutoBand.saved.org_algo_role    or AB_const.DEFAULT_ORG_ROLE

    -- E) ICON & GUILD PRIORITY
    if AutoBand.saved.displayicon                 == nil then AutoBand.saved.displayicon                 = true                              end
    if AutoBand.saved.right_click_organize        == nil then AutoBand.saved.right_click_organize        = AB_const.RIGHTCLICKORGANIZE       end
    if AutoBand.saved.middle_click_organize_range == nil then AutoBand.saved.middle_click_organize_range = AB_const.MIDDLECLICKORGANIZERANGE end
    if AutoBand.saved.guild_priority_enabled      == nil then AutoBand.saved.guild_priority_enabled      = AB_const.GUILDPRIORITY            end

    -- F) KICK FUNCTION SPECIFICS
    if AutoBand.saved.kick_func_enabled == nil then
        AutoBand.saved.kick_func_enabled = {}
        for k, v in pairs(AB_const.KICK_FUNC_DEFAULT) do
            AutoBand.saved.kick_func_enabled[k] = v
        end
    end

    -- G) ALT SPEC CHECK & ROLE PRINTING
    if AutoBand.saved.alt_speccheck_enabled == nil then AutoBand.saved.alt_speccheck_enabled = AB_const.ALTCHECK  end
    if AutoBand.saved.printrole_enabled     == nil then AutoBand.saved.printrole_enabled     = AB_const.PRINTROLE end

    -- H) DPS WEIGHTING SETTINGS
    if AutoBand.saved.dps_weighting_enabled == nil then AutoBand.saved.dps_weighting_enabled = AB_const.DPS_WEIGHTING_ENABLED end
    AutoBand.saved.max_mdps = AutoBand.saved.max_mdps or AB_const.DEFAULT_MAX_MDPS
    AutoBand.saved.max_rdps = AutoBand.saved.max_rdps or AB_const.DEFAULT_MAX_RDPS

    -- Ensure consistency on load: mdps + rdps must sum to the *current* max_dps
    if AutoBand.saved.max_mdps + AutoBand.saved.max_rdps ~= AutoBand.saved.max_dps then
        AB_util.print("[Warning] Saved mDPS/rDPS counts did not sum to max DPS (" .. AutoBand.saved.max_dps .. "). Resetting mDPS/rDPS based on current max DPS.")
        AutoBand.saved.max_rdps = math.floor(AutoBand.saved.max_dps / 2)
        AutoBand.saved.max_mdps = AutoBand.saved.max_dps - AutoBand.saved.max_rdps
    end

    -- I) PREFIX & COLOR SETTINGS
    if AutoBand.saved.prefix_text        == nil then AutoBand.saved.prefix_text        = AB_const.DEFAULT_PREFIX_TEXT       end
    if AutoBand.saved.prefix_color_name  == nil then AutoBand.saved.prefix_color_name  = AB_const.DEFAULT_PREFIX_COLOR_NAME end
    if AutoBand.saved.lead_color_name    == nil then AutoBand.saved.lead_color_name    = AB_const.DEFAULT_LEAD_COLOR_NAME   end
    if AutoBand.saved.prefix_use_guild   == nil then AutoBand.saved.prefix_use_guild   = AB_const.DEFAULT_PREFIX_USE_GUILD  end

    -- Validate loaded prefix on init, fallback to default if invalid
    if #AutoBand.saved.prefix_text > AB_const.MAX_PREFIX_LENGTH then
        AB_util.print("[Warning] Saved prefix text was too long (>" .. AB_const.MAX_PREFIX_LENGTH .. " characters). Resetting to default.")
        AutoBand.saved.prefix_text = AB_const.DEFAULT_PREFIX_TEXT
    end
    if AutoBand.saved.prefix_text == "" then
        AB_util.print("[Warning] Saved prefix text was empty. Resetting to default.")
        AutoBand.saved.prefix_text = AB_const.DEFAULT_PREFIX_TEXT
    end

    -- Validate loaded colors on init, fallback to default if invalid
    if not AVAILABLE_COLORS[AutoBand.saved.prefix_color_name:lower()] then
        AB_util.print("[Warning] Saved prefix color '" .. AutoBand.saved.prefix_color_name .. "' is invalid. Resetting to default.")
        AutoBand.saved.prefix_color_name = AB_const.DEFAULT_PREFIX_COLOR_NAME
    else
        AutoBand.saved.prefix_color_name = AutoBand.saved.prefix_color_name:lower()
    end

    if not AVAILABLE_COLORS[AutoBand.saved.lead_color_name:lower()] then
        AB_util.print("[Warning] Saved lead color '" .. AutoBand.saved.lead_color_name .. "' is invalid. Resetting to default.")
        AutoBand.saved.lead_color_name = AB_const.DEFAULT_LEAD_COLOR_NAME
    else
        AutoBand.saved.lead_color_name = AutoBand.saved.lead_color_name:lower()
    end

    -- J) DISTANCE SETTING
    if AutoBand.saved.toofar_radius_setting == nil then
        AutoBand.saved.toofar_radius_setting = AB_const.DEFAULT_SAVED_TOOFAR_RADIUS_SETTING
    end
    -- Validate loaded setting to ensure it's one of the known keys
    if not AB_const.TOOFAR_DISTANCE_VALUES[AutoBand.saved.toofar_radius_setting] then
        AB_util.print("[Warning] Saved 'toofar' radius setting '" .. tostring(AutoBand.saved.toofar_radius_setting) .. "' is invalid. Resetting to default (" .. AB_const.DEFAULT_SAVED_TOOFAR_RADIUS_SETTING .. ").")
        AutoBand.saved.toofar_radius_setting = AB_const.DEFAULT_SAVED_TOOFAR_RADIUS_SETTING
    end
    if AutoBand.saved.range_sort_distance_threshold == nil then
        AutoBand.saved.range_sort_distance_threshold = AB_const.DEFAULT_RANGE_SORT_DISTANCE_THRESHOLD
    end
    if type(AutoBand.saved.range_sort_distance_threshold) ~= "number" or AutoBand.saved.range_sort_distance_threshold < 0 then
        AB_util.print("[Warning] Invalid 'range_sort_distance_threshold' (" .. tostring(AutoBand.saved.range_sort_distance_threshold) .. "). Resetting to default (" .. AB_const.DEFAULT_RANGE_SORT_DISTANCE_THRESHOLD .. ").")
        AutoBand.saved.range_sort_distance_threshold = AB_const.DEFAULT_RANGE_SORT_DISTANCE_THRESHOLD
    end


    -- K) DEBUG SETTINGS
    AutoBand.saved.dumps        = AutoBand.saved.dumps or {}
    AutoBand.saved.dumped_wb    = AutoBand.saved.dumped_wb or nil
    AutoBand.saved.default_dump = AutoBand.saved.default_dump or nil

    --------------------------------------------------------------------------
    -- 3) CREATE ZONE ID SET & REGISTER SLASH COMMANDS
    --------------------------------------------------------------------------
    AutoBand.allowed_rvr_zones_set = {}
    for _, zone_id in ipairs(AB_const.ZONEIDS) do
        AutoBand.allowed_rvr_zones_set[zone_id] = true
    end

    LibSlash.RegisterSlashCmd("autoband", function(msg) AutoBand.parse_cmd(msg) end)
    if not LibSlash.IsSlashCmdRegistered("ab") then
        LibSlash.RegisterSlashCmd("ab", function(msg) AutoBand.parse_cmd(msg) end)
        AutoBand.has_shortslash = true
    end

    AutoBand.BuildCareerLineToNameMap()

    --------------------------------------------------------------------------
    -- 4) COMMAND LIST INITIALIZATION
    --    (help/info/UI, templates, kicking, zone, ranks, warband org, debug)
    --------------------------------------------------------------------------
    AutoBand.cmd = {
        -- Help/Info & UI
        [""]      = { f = AutoBand.cmd_usage,         help = "",                            print_id = 10 },
        ["help"]  = { f = AutoBand.cmd_usage,         help = "show command list",           print_id = 11 },
        ["info"]  = { f = AutoBand.cmd_show,          help = "show current settings",       print_id = 12 },
        ["show"]  = { f = AutoBand.cmd_toggle_gui,    help = "open/close GUI",              print_id = 13 },
        ["icon"]  = { f = AutoBand.cmd_toggle_icon,   help = "show/hide minimap icon",      print_id = 14 },
        ["rco"]   = { f = AutoBand.cmd_toggle_rco,    help = "toggle right-click organize on icon", print_id = 15 },
        ["mcor"]  = { f = AutoBand.cmd_toggle_mcor,   help = "toggle middle-click organize distance on icon", print_id = 16 },

        -- Config Commands
        ["setprefix"]        = { f = AutoBand.cmd_set_prefix,          help = "<string> set the chat prefix text",               print_id = 17 },
        ["prefix"]           = { f = AutoBand.cmd_set_prefix,          help = "" },
        ["resetprefix"]      = { f = AutoBand.cmd_reset_prefix,        help = "reset chat prefix text to default",               print_id = 18 },
        ["prefixreset"]      = { f = AutoBand.cmd_reset_prefix,        help = "" },
        ["listcolors"]       = { f = AutoBand.cmd_list_colors,         help = "list available color names",                      print_id = 19 },
        ["prefixcolors"]     = { f = AutoBand.cmd_list_colors,         help = "" },
        ["listcolor"]        = { f = AutoBand.cmd_list_colors,         help = "" },
        ["prefixcolor"]      = { f = AutoBand.cmd_set_prefix_color,    help = "<color_name> set prefix color",                   print_id = 20 },
        ["colorprefix"]      = { f = AutoBand.cmd_set_prefix_color,    help = "" },
        ["setprefixcolor"]   = { f = AutoBand.cmd_set_prefix_color,    help = "" },
        ["resetprefixcolor"] = { f = AutoBand.cmd_reset_prefix_color,  help = "reset prefix color to default",                   print_id = 21 },
        ["prefixcolorreset"] = { f = AutoBand.cmd_reset_prefix_color,  help = "" },
        ["prefixguild"]      = { f = AutoBand.cmd_toggle_prefix_guild, help = "use guild name as prefix in advertisement",       print_id = 22 },
        ["guildprefix"]      = { f = AutoBand.cmd_toggle_prefix_guild, help = "" },
        ["leadcolor"]        = { f = AutoBand.cmd_set_lead_color,      help = "<color_name> set WB lead mention color",          print_id = 23 },
        ["colorlead"]        = { f = AutoBand.cmd_set_lead_color,      help = "" },
        ["setleadcolor"]     = { f = AutoBand.cmd_set_lead_color,      help = "" },
        ["resetleadcolor"]   = { f = AutoBand.cmd_reset_lead_color,    help = "reset WB lead mention color to default",          print_id = 24 },
        ["leadcolorreset"]   = { f = AutoBand.cmd_reset_lead_color,    help = "" },

        -- Templates
        ["list"]    = { f = AutoBand.cmd_list_template,   help = "list all templates",                       print_id = 25 },
        ["save"]    = { f = AutoBand.cmd_save_template,   help = "<name> save current WB template",          print_id = 26 },
        ["apply"]   = { f = AutoBand.cmd_apply_template,  help = "<name> apply template",                    print_id = 27 },
        ["default"] = { f = AutoBand.cmd_default_template,help = "set/clear default template",               print_id = 28 },
        ["mode"]    = { f = AutoBand.cmd_mode,            help = "<num> distribution algorithm mode",        print_id = 29 },

        -- Kick / Auto-Kick
        ["kf"]          = { f = AutoBand.cmd_kick_toofar,            help = "kick all far players",                           print_id = 30 },
        ["ak"]          = { f = AutoBand.cmd_flag_autokick,          help = "toggle autokick low rank/excess roles",          print_id = 31 },
        ["akl"]         = { f = AutoBand.cmd_flag_autokick_lowrnk,   help = "toggle autokick low rank players",               print_id = 32 },
        ["akf"]         = { f = AutoBand.cmd_flag_autokick_toofar,   help = "toggle autokick toofar",                         print_id = 33 },
        ["kicktimeout"] = { f = AutoBand.cmd_autokick_timeout,       help = "<mins> autokick toofar timeout",                 print_id = 34 },

        ["settoofardistance"] = {
            f = AutoBand.cmd_set_toofar_distance,
            help = function()
                local settings_with_values = {}
                for k_setting, v_distance in pairs(AB_const.TOOFAR_DISTANCE_VALUES) do
                    table.insert(settings_with_values, { key = k_setting, distance = v_distance })
                end
                table.sort(settings_with_values, function(a, b)
                    return a.distance < b.distance
                end)
                local sorted_keys = {}
                for _, setting_info in ipairs(settings_with_values) do
                    table.insert(sorted_keys, setting_info.key)
                end
                return "<" .. table.concat(sorted_keys, "|") .. "> set 'too far' kick radius"
            end,
            print_id = 35
        },
        ["setdistance"]          = { f = AutoBand.cmd_set_toofar_distance, help = "" },
        ["setdist"]              = { f = AutoBand.cmd_set_toofar_distance, help = "" },
        ["settoofardist" ]       = { f = AutoBand.cmd_set_toofar_distance, help = "" },
        ["toofardist"]           = { f = AutoBand.cmd_set_toofar_distance, help = "" },
        ["setdistancethreshold"] = { f = AutoBand.cmd_set_range_sort_distance_threshold, help = "<units> set distance threshold for '/ab org distance'",   print_id = 36 },
        ["setdisthres"]          = { f = AutoBand.cmd_set_range_sort_distance_threshold, help = "" },

        ["wewhk"]       = { f = AutoBand.cmd_toggle_autokick_we_wh,      help = "toggle autokick WE/WH",                          print_id = 37 },
        ["wek"]         = { f = AutoBand.cmd_toggle_autokick_we_wh,      help = "" },
        ["whk"]         = { f = AutoBand.cmd_toggle_autokick_we_wh,      help = "" },
        ["akz"]         = { f = AutoBand.cmd_flag_autokick_rvrzone,      help = "toggle autokick players in scenarios",           print_id = 38 },
        ["akignore"]    = { f = AutoBand.cmd_toggle_autokick_ignorelist, help = "toggle autokick ignored players",                print_id = 39 },
        ["an"]          = { f = AutoBand.cmd_flag_autonote,              help = "toggle autosearch in /1 for roles",              print_id = 40 },
        ["searchroles"] = { f = AutoBand.cmd_search_roles,               help = "<1|t4|5> search in chans",                       print_id = 41 },
        ["searchrole"]  = { f = AutoBand.cmd_search_roles,               help = "" },
        ["sr"]          = { f = AutoBand.cmd_search_roles,               help = "" },
        ["gp"]          = { f = AutoBand.cmd_flag_guildpriority,         help = "toggle guild priority",                          print_id = 42 },
        ["dpsweight"]   = {
            f    = AutoBand.cmd_toggle_dps_weighting,
            help = function()
                return "<on|off> toggle mDPS/rDPS weighting for " ..
                       AutoBand.saved.max_tanks .. "-" ..
                       AutoBand.saved.max_healers .. "-" ..
                       AutoBand.saved.max_dps
            end,
            print_id = 43
        },
        ["dw"]       = { f = AutoBand.cmd_toggle_dps_weighting, help = "" },
        ["setdps"]   = {
            f    = AutoBand.cmd_set_dps_weights,
            help = function()
                return "<mdps> <rdps> set desired counts (sum must be " .. AutoBand.saved.max_dps .. ")"
            end,
            print_id = 44
        },
        ["setroles"]   		= { f = AutoBand.cmd_setroles,   help = "<tanks> <healers> <dps> set role limits (sum must be 24)",  print_id = 45 },
        ["resetroles"] 		= { f = AutoBand.cmd_resetroles, help = "reset role limits to default (" .. AB_const.DEFAULT_MAX_TANKS .. "-" .. AB_const.DEFAULT_MAX_HEALERS .. "-" .. AB_const.DEFAULT_MAX_DPS .. ")", print_id = 46 },
        ["bwsmdps"]    		= { f = AutoBand.cmd_toggle_bw_sorc_mdps, help = "treat BW/Sorc as mDPS", print_id = 47 },
        ["bwm"]        		= { f = AutoBand.cmd_toggle_bw_sorc_mdps, help = "" },
        ["sorcm"]      		= { f = AutoBand.cmd_toggle_bw_sorc_mdps, help = "" },
        ["restrictrace"]	= { f = AutoBand.cmd_toggle_restrict_race, help = "restricting WB to leader's race", print_id = 48 },
        ["rr"]         		= { f = AutoBand.cmd_toggle_restrict_race, help = "" },
        ["raceonly"]   		= { f = AutoBand.cmd_toggle_restrict_race, help = "" },

        -- Zone
        ["zone"]     = { f = AutoBand.cmd_list_zone,     help = "list players not in leader's zone", print_id = 50 },
        ["zones"]    = { f = AutoBand.cmd_list_zone,     help = "" },
        ["zonekick"] = { f = AutoBand.cmd_kick_notinzone,help = "kick players not in leader's zone", print_id = 51 },
        ["zk"]       = { f = AutoBand.cmd_kick_notinzone,help = "" },

        -- Ranks
        ["rank"]           = { f = AutoBand.cmd_list_rank,     help = "list players below required rank",    print_id = 60 },
        ["minrank"]        = { f = AutoBand.cmd_rank,          help = "<num> set min rank requirement",      print_id = 61 },
        ["minrankhealer"]  = { f = AutoBand.cmd_rank_healer,   help = "<num> min rank for healers",          print_id = 62 },
        ["minrankheal"]    = { f = AutoBand.cmd_rank_healer,   help = "" },
        ["minrankh"]       = { f = AutoBand.cmd_rank_healer,   help = "" },
        ["rankkick"]       = { f = AutoBand.cmd_kick_rank,     help = "kick players below required rank",    print_id = 63 },

        -- Warband Organization
        ["org"]          = { f = AutoBand.cmd_organize,          help = "[template] [distance] - organize warband. 'distance' prioritizes near players",                                     print_id = 70 },
        ["buffnotify"]   = { f = AutoBand.cmd_toggle_buffnotify, help = "toggle notifying wb after org",                            print_id = 71 },
        ["bn"]           = { f = AutoBand.cmd_toggle_buffnotify, help = "" },
        ["alt"]          = { f = AutoBand.cmd_alt_speccheck,     help = "toggle alt-spec check",                                    print_id = 72 },
        ["wb"]           = { f = AutoBand.wb,                    help = "information about the warband",                            print_id = 73 },
        ["roles"]        = { f = AutoBand.cmd_list_roles,        help = "<role> list players and their roles",                      print_id = 74 },
        ["role"]         = { f = AutoBand.cmd_list_roles,        help = "" },
        ["pr"]           = { f = AutoBand.cmd_flag_printrole,    help = "toggle printing of role assignments",                      print_id = 75 },
        ["customrole"]   = { f = AutoBand.cmd_custom_role,       help = "<add|remove|delete|list> manage role overrides",                  print_id = 76 },
        ["customroles"]  = { f = AutoBand.cmd_custom_role,       help = "" },
        ["cr"]           = { f = AutoBand.cmd_custom_role,       help = "" },
        ["purpose"]      = { f = AutoBand.cmd_set_purpose,       help = "<"..AB_const.GetPurposeNames().."|clear> set wb purpose",  print_id = 77 },
        ["purposelist"]  = { f = AutoBand.cmd_list_purposes,     help = "list available warband purposes",                          print_id = 78 },
        ["end"]          = { f = AutoBand.cmd_end,               help = "end warband, kick all",                                    print_id = 79 },
        ["printguild"]   = { f = AutoBand.cmd_print_guild,       help = "prints your current guild info",                           print_id = 80 },
        ["guildprint"]   = { f = AutoBand.cmd_print_guild,       help = "" },
        ["listaltspecs"] = { f = AutoBand.cmd_list_alt_specs,    help = "list players with reassinged roles",                       print_id = 81 },
        ["listalts"]     = { f = AutoBand.cmd_list_alt_specs,    help = "" },
        ["listalt"]      = { f = AutoBand.cmd_list_alt_specs,    help = "" },

        -- Debug
        ["debug"]    		= { f = AutoBand.cmd_debug,        			  help = "", print_id = 100 },
        ["dump"]     		= { f = AutoBand.cmd_dump,         			  help = "", print_id = 101 },
        ["cleardump"]		= { f = AutoBand.cmd_cleardumps,   			  help = "", print_id = 102 },
        ["listdump"] 		= { f = AutoBand.cmd_list_dump,    			  help = "", print_id = 103 },
        ["loaddump"] 		= { f = AutoBand.cmd_load_dump,    			  help = "", print_id = 104 },
        ["tempdump"] 		= { f = AutoBand.cmd_dump_from_template, 	  help = "", print_id = 105 },
        ["dumpguild"] 		= { f = AutoBand.cmd_dump_guild_data, 		  help = "", print_id = 106 },
        ["dumpplayer"] 		= { f = AutoBand.cmd_dump_player_data, 		  help = "", print_id = 107 },
        ["dumpwarband"] 	= { f = AutoBand.cmd_dump_warband_data,       help = "", print_id = 108 },
		["dumpparty"] 		= { f = AutoBand.cmd_dump_party_data,         help = "", print_id = 109 },
		["dumpignorelist"] 	= { f = AutoBand.cmd_dump_ignore_list,        help = "", print_id = 110 },
        ["orgverbose"]  	= { f = AutoBand.cmd_toggle_live_org_verbose, help = "", print_id = 111 },
        ["openparty"]   	= { f = AutoBand.cmd_open_party_status,       help = "", print_id = 112 },
    }

    --------------------------------------------------------------------------
    -- 5) SORT COMMANDS & DEBUG
    --------------------------------------------------------------------------
    AB_const.AVAILABLE_COLOR_NAMES_SORTED = {}
    for name, _ in pairs(AB_const.AVAILABLE_COLORS) do
        table.insert(AB_const.AVAILABLE_COLOR_NAMES_SORTED, name)
    end
    table.sort(AB_const.AVAILABLE_COLOR_NAMES_SORTED)

    AutoBand.cmd_ordered = {}
    for key, cmd in pairs(AutoBand.cmd) do
        -- Handle help text potentially being a function
        local help_text = ""
        if type(cmd.help) == "function" then
            help_text = cmd.help()
        elseif type(cmd.help) == "string" then
            help_text = cmd.help
        end
        if cmd.print_id ~= nil then
            cmd.key            = key
            cmd.resolved_help  = help_text -- Store resolved help text for sorting/display
            table.insert(AutoBand.cmd_ordered, cmd)
        end
    end
    table.sort(AutoBand.cmd_ordered, function(a, b)
        return a.print_id < b.print_id
    end)
    -- AB_util.debug(AutoBand.cmd_ordered)

    --------------------------------------------------------------------------
    -- 6) REGISTER LAYOUT WINDOW
    --------------------------------------------------------------------------
    LayoutEditor.RegisterWindow("AutoBandMapIcon", L"AutoBand", L"AutoBand Button", false, false, true, nil)

    --------------------------------------------------------------------------
    -- 7) REGISTERING EVENTS
    --------------------------------------------------------------------------
    RegisterEventHandler(SystemData.Events.ENTER_WORLD,          "AutoBand.OnPlayerEnteringWorldOrReload")
    RegisterEventHandler(SystemData.Events.INTERFACE_RELOADED,   "AutoBand.OnPlayerEnteringWorldOrReload")
    RegisterEventHandler(SystemData.Events.GROUP_LEAVE,          "AutoBand.OnGroupLeave")
    RegisterEventHandler(SystemData.Events.GROUP_UPDATED,        "AutoBand.OnBattleGroupDataChanged")
    RegisterEventHandler(SystemData.Events.BATTLEGROUP_UPDATED,  "AutoBand.OnBattleGroupDataChanged")

    --------------------------------------------------------------------------
    -- 7.5) HOOK PLAYER RIGHT-CLICK MENU FOR CUSTOM ROLES
    --------------------------------------------------------------------------
    AutoBand.original_show_menu = PlayerMenuWindow.ShowMenu
    AutoBand.original_add_group_menu_items = PlayerMenuWindow.AddGroupMenuItems
    PlayerMenuWindow.ShowMenu = AutoBand.ModifiedShowMenu
    PlayerMenuWindow.AddGroupMenuItems = AutoBand.ModifiedAddGroupMenuItems

    --------------------------------------------------------------------------
    -- 8) PRINT LOADED MESSAGE
    --------------------------------------------------------------------------
    local slash = AutoBand.has_shortslash and " or /ab" or ""
    AB_util.print("AutoBand v" .. AB_const.VERSION .. " loaded. Type /autoband" .. slash .. " for instructions.")
end

function AutoBand.BuildCareerLineToNameMap()
    if not GameData or not GameData.CareerLine then
        -- This case should ideally not happen if GameData is loaded
        AB_util.print("[Warning] GameData.CareerLine not available for building career name map.")
        return
    end
    for name_str, line_val in pairs(GameData.CareerLine) do
        local name_parts = {}
        for part in name_str:gmatch("([^_]+)") do -- Split by underscore
            if #part > 0 then
                table.insert(name_parts, part:sub(1,1):upper() .. part:sub(2):lower()) -- Title case each part
            end
        end
        AutoBand.CareerLineToNameMap[line_val] = table.concat(name_parts, " ")
    end
end

function AutoBand.GetCareerName(career_line_id)
    if AutoBand.CareerLineToNameMap and AutoBand.CareerLineToNameMap[career_line_id] then
        return AutoBand.CareerLineToNameMap[career_line_id]
    end
    return "Unknown Career (" .. tostring(career_line_id) .. ")"
end

function AutoBand.cmd_toggle_live_org_verbose(args)
    AutoBand.live_org_verbose = not AutoBand.live_org_verbose
    AB_util.print("Live Organize Verbose Printing: " .. tostring(AutoBand.live_org_verbose))
end

function AutoBand.cmd_list_alt_specs(args)
    local wb_obj = AutoBand.get_wb()
    if not wb_obj or wb_obj.player_count == 0 then
        AB_util.print("Not in a warband or warband is empty.")
        return
    end

    if not next(AutoBand.CareerLineToNameMap) then -- Ensure map is built
        AutoBand.BuildCareerLineToNameMap()
    end

    local reassigned_players_info = {}
    local count = 0
    local ror_gs_available = RoRGroupScoreboard and RoRGroupScoreboard.playersDataRaw

    wb_obj:foreach_player(function(gid, player_data_from_wb)
        local player_name_str = tostring(player_data_from_wb.name)
        local player_name_lower = player_name_str:lower()

        local original_career_line = player_data_from_wb.careerLine
        local original_default_role = AB_const.CAREERLINE_MAP[original_career_line]
        local current_assigned_role = player_data_from_wb.role -- Final role from AutoBand

        if original_default_role ~= current_assigned_role then
            local reason_tag = ""
            local custom_role_setting = AutoBand.saved.custom_roles[player_name_lower]

            -- Determine the primary reason for the role change based on AutoBand's logic priority
            if custom_role_setting and custom_role_setting == current_assigned_role then
                reason_tag = "(custom role)"
            else
                local is_bw_sorc_career = (original_career_line == GameData.CareerLine.BRIGHT_WIZARD or original_career_line == GameData.CareerLine.SORCERER)
                if AutoBand.saved.bw_sorc_as_mdps and is_bw_sorc_career and current_assigned_role == AB_const.MDPS then
                    if AutoBand.faction == AB_const.ORDER then
                        reason_tag = "(BW as mDPS)"
                    elseif AutoBand.faction == AB_const.DESTRUCTION then
                        reason_tag = "(Sorc as mDPS)"
                    else
                        reason_tag = "(BW/Sorc as mDPS)"
                    end
                elseif AutoBand.saved.alt_speccheck_enabled then
                    -- If alt_speccheck is on, it's the next most likely cause if not BW/Sorc or Custom
                    local career_after_getarchetype = AB_wb:getArcheType(player_data_from_wb) -- Uses RoRGS internally
                    local role_from_getarchetype = AB_util.career_category(career_after_getarchetype)

                    if role_from_getarchetype == current_assigned_role then -- Check if this step was the one setting the final role
                        local is_confirmed_ror_alt_spec = false
                        if ror_gs_available then
                            for _, ror_player_data in pairs(RoRGroupScoreboard.playersDataRaw) do
                                if ror_player_data.name == towstring(player_name_str) and ror_player_data.archtype > 0 then
                                    -- Confirm if the game's alt-spec data aligns with getArchetype's decision
                                    local ror_gs_implied_career = original_career_line
                                    if original_career_line == GameData.CareerLine.ZEALOT then ror_gs_implied_career = GameData.CareerLine.MAGUS
                                    elseif original_career_line == GameData.CareerLine.WARRIOR_PRIEST then ror_gs_implied_career = GameData.CareerLine.SLAYER
                                    elseif original_career_line == GameData.CareerLine.RUNE_PRIEST then ror_gs_implied_career = GameData.CareerLine.ENGINEER
                                    elseif original_career_line == GameData.CareerLine.ARCHMAGE then ror_gs_implied_career = GameData.CareerLine.ENGINEER
                                    elseif original_career_line == GameData.CareerLine.SHAMAN then ror_gs_implied_career = GameData.CareerLine.MAGUS
                                    elseif original_career_line == GameData.CareerLine.DISCIPLE then ror_gs_implied_career = GameData.CareerLine.CHOPPA
                                    elseif original_career_line == GameData.CareerLine.SQUIG_HERDER then ror_gs_implied_career = GameData.CareerLine.CHOPPA
                                    elseif original_career_line == GameData.CareerLine.SHADOW_WARRIOR then ror_gs_implied_career = GameData.CareerLine.SLAYER
                                    end
                                    if ror_gs_implied_career == career_after_getarchetype then
                                        is_confirmed_ror_alt_spec = true
                                    end
                                    break
                                end
                            end
                        end
                        if is_confirmed_ror_alt_spec then
                            reason_tag = "(spec check)"
                        end
                    end
                end
            end

            if reason_tag == "" then -- Fallback if no specific toggle/override matched the final role change
                reason_tag = "(AutoBand)"
            end

            table.insert(reassigned_players_info, {
                name = player_name_str,
                original_career_name = AutoBand.GetCareerName(original_career_line),
                original_role = original_default_role,
                current_role = current_assigned_role,
                reason = reason_tag
            })
            count = count + 1
        end
    end)

    if count > 0 then
        AB_util.print("Players with reassigned roles (original -> reassigned [reason]):")
        for _, p_info in ipairs(reassigned_players_info) do
            local msg = string.format("- %s (%s): %s -> %s %s",
                p_info.name, -- Already a Lua string
                p_info.original_career_name,
                p_info.original_role or "N/A",
                p_info.current_role or "N/A",
                p_info.reason
            )
            AB_util.print(towstring(msg))
        end
    else
        AB_util.print("No players with reassigned roles found.")
    end

    if not ror_gs_available then
        AB_util.print("WARNING: RoRGroupScoreboard data (from GroupScoreboard addon) not available.")
    end
end

function AutoBand.cmd_set_range_sort_distance_threshold(args)
    local new_threshold_str = args[1]
    if not new_threshold_str then
        AB_util.print("[Error] Missing argument. Usage: /ab setrangethreshold <units>")
        AB_util.print("Current /ab org distance threshold: " .. AutoBand.saved.range_sort_distance_threshold .. " units.")
        return
    end

    local new_threshold = tonumber(new_threshold_str)
    -- Ensure it's a number and not negative. Allow 0.
    if not new_threshold or type(new_threshold) ~= "number" or new_threshold < 0 then
        AB_util.print("[Error] Invalid threshold value: '" .. new_threshold_str .. "'. Must be a non-negative number.")
        return
    end

    AutoBand.saved.range_sort_distance_threshold = math.floor(new_threshold) -- Store as an integer
    AB_util.print("/ab org distance threshold set to: " .. AutoBand.saved.range_sort_distance_threshold .. " units.")

    -- If you implement GUI changes, refresh the config window here if it's open
    -- if AutoBandWindow.showing() and AutoBandWindow.SelectedTab == AB_const.TABS_CONFIG then
    --     AutoBandWindowConfig.Show() -- This re-initializes/refreshes the config tab
    -- end
end

function AutoBand.cmd_print_guild(args)
  if not GameData or not GameData.Guild or not GameData.Guild.m_GuildID or GameData.Guild.m_GuildID == 0 or not GameData.Guild.m_GuildName then
    AB_util.print("[Error] Could not retrieve guild information. Are you in a guild?")
    return
  end

  local guild_id_num = GameData.Guild.m_GuildID
  local guild_id_str = tostring(guild_id_num)
  local guild_name_str = tostring(GameData.Guild.m_GuildName)

  local prefix_color_name = AutoBand.saved.prefix_color_name or AB_const.DEFAULT_PREFIX_COLOR_NAME
  local color_rgb = AB_const.AVAILABLE_COLORS[prefix_color_name] or AB_const.AVAILABLE_COLORS[AB_const.DEFAULT_PREFIX_COLOR_NAME]
  local r, g, b = color_rgb[1], color_rgb[2], color_rgb[3]
  local link_color_str = string.format("%d,%d,%d", r, g, b)

    -- The raw LINK tag structure (without the outer [])
  local link_tag_content = string.format("LINK data=\"GUILD:%s\" text=\"%s\" color=\"%s\"",
                     guild_id_str,
                     guild_name_str,
                     link_color_str)

  local clickable_link_raw = string.format("<%s>", link_tag_content) -- This is the actual clickable part

    local output_message = L"Guild Info:\n" ..
                           L"  - ID: " .. towstring(guild_id_str) .. L"\n" ..
                           L"  - Name: " .. towstring(guild_name_str) .. L"\n" ..
                           L"  - Color RGB (from AutoBand settings): " .. towstring(link_color_str) .. L"\n" ..
                           L"  - Raw LINK Tag Content: " .. towstring(link_tag_content) .. L"\n" ..
                           L"  - Clickable Link: [" .. towstring(clickable_link_raw) .. L"]"

  AB_util.print(output_message)
end

function AutoBand.OnBattleGroupDataChanged()
    AutoBand.cache_dirty = true
    AutoBand.need_role_update = true
end

function AutoBand.OnPlayerEnteringWorldOrReload()
    AutoBand.DetermineRaceAndFaction()
end

function AutoBand.DetermineRaceAndFaction()
    AutoBand.faction = nil
    AutoBand.factionDetermined = false
    AutoBand.race = nil
    AutoBand.raceDetermined = false

    if GameData and GameData.Player and GameData.Player.career and GameData.Player.career.line then
         local faction = AB_const.CAREERLINE_FACTIONMAP[GameData.Player.career.line]
         local race = AB_const.CAREERLINE_RACEMAP[GameData.Player.career.line]

         if faction then
             AutoBand.faction = faction
             AutoBand.factionDetermined = true
             -- AB_util.print("Determined Faction as " .. AutoBand.faction .. ".")
         else
             AB_util.print("Could not determine faction.")
         end

         if race then
             AutoBand.race = race
             AutoBand.raceDetermined = true
             -- AB_util.print("Determined Race as " .. AutoBand.race .. ".")
         else
             AB_util.print("Could not determine race.")
         end

    else
         AB_util.print("Player data not ready for race/faction determination on ENTER_WORLD/INTERFACE_RELOADED.")
    end
end

function AutoBand.cmd_set_prefix(raw_prefix_string)
    local new_prefix = raw_prefix_string
    local MAX_PREFIX_LENGTH = 20

    new_prefix = string.gsub(new_prefix, "^%s+", "")
    new_prefix = string.gsub(new_prefix, "%s+$", "")

    if new_prefix == "" then
        AB_util.print("[Error] Prefix cannot be empty or only spaces. Use /ab resetprefix to restore default.")
        return
    end

    if #new_prefix > MAX_PREFIX_LENGTH then
        AB_util.print("[Error] Prefix is too long (max " .. MAX_PREFIX_LENGTH .. " characters). Prefix not set.")
        return
    end

    AutoBand.saved.prefix_text = new_prefix
    -- Add quotes in feedback to make spaces visible
    AB_util.print("Chat prefix set to: \"" .. new_prefix .. "\"")
end

function AutoBand.cmd_toggle_prefix_guild(args)
    AutoBand.saved.prefix_use_guild = not AutoBand.saved.prefix_use_guild
    local guildInfo = AutoBand.GetCurrentGuildInfo()

    if AutoBand.saved.prefix_use_guild then
        if guildInfo then
            -- Use GenerateGuildLinkRaw and convert to wstring for printing the example
            local example_link_raw = AutoBand.GenerateGuildLinkRaw(guildInfo.id, guildInfo.name)
            AB_util.print(L"Prefix set to use guild in searches: " .. towstring(example_link_raw))
        else
            -- Get normal prefix example (wstring)
            local normal_prefix_example = AutoBand.GetFormattedPrefixWString(false)
            AB_util.print(L"Prefix guild link enabled, but you are not in a guild. Will use normal prefix: " .. normal_prefix_example)
        end
    else
         -- Get normal prefix example (wstring)
        local normal_prefix_example = AutoBand.GetFormattedPrefixWString(false)
        AB_util.print(L"Prefix guild link disabled. Using normal prefix: " .. normal_prefix_example)
    end

    -- if AutoBandWindow.showing() and AutoBandWindow.SelectedTab == AB_const.TABS_CONFIG then
    --     AutoBandWindowConfig.Show()
    -- end
end

function AutoBand.cmd_reset_prefix(args)
    AutoBand.saved.prefix_text = AB_const.DEFAULT_PREFIX_TEXT
    AB_util.print("Chat prefix reset to default: " .. AutoBand.saved.prefix_text)
end

function AutoBand.cmd_list_colors(args)
    AB_util.print("Available color names:")
    local color_list_str = table.concat(AB_const.AVAILABLE_COLOR_NAMES_SORTED, ", ")
    AB_util.print(color_list_str)
end

function AutoBand.cmd_set_prefix_color(args)
    local color_name = args[1]
    if not color_name then
        AB_util.print("[Error] Missing color name. Usage: /ab setprefixcolor <color_name>")
        AutoBand.cmd_list_colors({}) -- Show available colors
        return
    end
    color_name = color_name:lower() -- Ensure lowercase for comparison

    if AVAILABLE_COLORS[color_name] then
        AutoBand.saved.prefix_color_name = color_name
        -- Get the formatted prefix with the NEW color for feedback (as wstring)
        local example_prefix = AutoBand.GetFormattedPrefixWString(false) -- Get prefix without space
        local feedback_message = L"Prefix color set to " .. example_prefix

        -- Pass the complete wstring message to AB_util.print
        AB_util.print(feedback_message)
    else
        AB_util.print("[Error] Invalid color name: '" .. color_name .. "'.")
        AutoBand.cmd_list_colors({}) -- Show available colors
    end
end

function AutoBand.cmd_reset_prefix_color(args)
    AutoBand.saved.prefix_color_name = AB_const.DEFAULT_PREFIX_COLOR_NAME
    -- Get the formatted prefix using the NEWLY reset default color for feedback
    local example_prefix = AutoBand.GetFormattedPrefixWString(false) -- Get prefix without space
    -- Construct the full feedback message as a wstring
    local feedback_message = L"Prefix color reset to default (" .. example_prefix .. L")"
    AB_util.print(feedback_message)
end

function AutoBand.cmd_set_lead_color(args)
    local color_name = args[1]
    if not color_name then
        AB_util.print("[Error] Missing color name. Usage: /ab setleadcolor <color_name>")
        AutoBand.cmd_list_colors({}) -- Show available colors
        return
    end
    color_name = color_name:lower() -- Ensure lowercase for comparison

    if AVAILABLE_COLORS[color_name] then
        AutoBand.saved.lead_color_name = color_name
        -- Generate example colored text for feedback
        local color_rgb = AVAILABLE_COLORS[color_name]
        local r, g, b = color_rgb[1], color_rgb[2], color_rgb[3]
        -- Keep the raw string for formatting, then convert
        local example_text_raw = string.format("<LINK data=\"0\" color=\"%d,%d,%d\" text=\"%s\">", r, g, b, color_name)
        local example_text_wstring = towstring(example_text_raw) -- Convert the link to wstring
        local feedback_message = L"WB Lead mention color set to " .. example_text_wstring

        -- Pass the complete wstring message to AB_util.print
        AB_util.print(feedback_message)
    else
        AB_util.print("[Error] Invalid color name: '" .. color_name .. "'.")
        AutoBand.cmd_list_colors({}) -- Show available colors
    end
end

function AutoBand.cmd_reset_lead_color(args)
    AutoBand.saved.lead_color_name = AB_const.DEFAULT_LEAD_COLOR_NAME
    -- Generate example colored text for feedback using the default color
    local default_color_name = AB_const.DEFAULT_LEAD_COLOR_NAME
    -- Ensure default color exists (should always be true if defaults are in AVAILABLE_COLORS)
    local color_rgb = AB_const.AVAILABLE_COLORS[default_color_name] or {255, 255, 255} -- Fallback just in case
    local r, g, b = color_rgb[1], color_rgb[2], color_rgb[3]
    local example_text_raw = string.format("<LINK data=\"0\" color=\"%d,%d,%d\" text=\"%s\">", r, g, b, default_color_name)
    local example_text_wstring = towstring(example_text_raw) -- Convert the link to wstring
    -- Construct the full feedback message as a wstring
    local feedback_message = L"WB Lead mention color reset to default (" .. example_text_wstring .. L")"
    AB_util.print(feedback_message)
end

function AutoBand.cmd_flag_autokick_lowrnk(args)
    AutoBand.saved.autokick_low_rank_enabled = not AutoBand.saved.autokick_low_rank_enabled
    AB_util.print("Auto kick players below rank req: " .. tostring(AutoBand.saved.autokick_low_rank_enabled))
    if AutoBandWindow.showing() and AutoBandWindow.SelectedTab == AB_const.TABS_CONFIG then
        AutoBandWindowConfig.Show()
    end
end

function AutoBand.cmd_flag_autokick_rvrzone(args)
    AutoBand.saved.autokick_rvrzone_enabled = not AutoBand.saved.autokick_rvrzone_enabled
    AB_util.print("Auto kick players in scenarios: " .. tostring(AutoBand.saved.autokick_rvrzone_enabled))
    if AutoBandWindow.showing() and AutoBandWindow.SelectedTab == AB_const.TABS_CONFIG then
        AutoBandWindowConfig.Show()
    end
end

function AutoBand.cmd_toggle_autokick_ignorelist(args)
    AutoBand.saved.autokick_ignorelist_enabled = not AutoBand.saved.autokick_ignorelist_enabled
    AB_util.print("Auto kick ignored players: " .. tostring(AutoBand.saved.autokick_ignorelist_enabled))
    if AutoBandWindow.showing() and AutoBandWindow.SelectedTab == AB_const.TABS_CONFIG then
        AutoBandWindowConfig.Show()
    end
end

function AutoBand.cmd_toggle_buffnotify(args)
    AutoBand.saved.notify_buffs_enabled = not AutoBand.saved.notify_buffs_enabled
    AB_util.print("Notify warband after organize: " .. tostring(AutoBand.saved.notify_buffs_enabled))
    if AutoBandWindow.showing() and AutoBandWindow.SelectedTab == AB_const.TABS_TOOLS then
        AutoBandWindowTools.Show()
    end
end

function AutoBand.cmd_alt_speccheck(args)
    AutoBand.saved.alt_speccheck_enabled = not AutoBand.saved.alt_speccheck_enabled
    AB_util.print("Use alt spec check: " .. tostring(AutoBand.saved.alt_speccheck_enabled))
    if AutoBandWindow.showing() and AutoBandWindow.SelectedTab == AB_const.TABS_CONFIG then
        AutoBandWindowConfig.Show()
    end
end

function AutoBand.cmd_flag_printrole(args)
    AutoBand.saved.printrole_enabled = not AutoBand.saved.printrole_enabled
    AB_util.print("Print role assignments: " .. tostring(AutoBand.saved.printrole_enabled))
end


function AutoBand.cmd_list_roles(args)
    local role_filter = nil
    if args[1] then
        local role_param = args[1]:lower()
        if role_param == "tanks" then
            role_param = AB_const.TANK -- Convert to singular constant
        elseif role_param == "healers" then
            role_param = AB_const.HEALER -- Convert to singular constant
        elseif role_param == "heals" then
            role_param = AB_const.HEALER -- Convert to singular constant
        elseif role_param == "heal" then
            role_param = AB_const.HEALER -- Convert to singular constant
        end
        if role_param ~= AB_const.TANK and role_param ~= AB_const.HEALER and
           role_param ~= AB_const.MDPS and role_param ~= AB_const.RDPS then
            AB_util.print("[error] Invalid role: " .. role_param .. ". Valid roles are " ..
                          AB_const.TANK .. ", " .. AB_const.HEALER .. ", " ..
                          AB_const.MDPS .. ", " .. AB_const.RDPS .. ".")
            return
        end
        role_filter = role_param
    end

    AB_util.print("Currently known player roles" ..
                  (role_filter and (" (" .. role_filter .. ")") or "") .. ":")
    local entries = {}
    for name, role in pairs(roles_last) do
        if not role_filter or role == role_filter then
            table.insert(entries, { name = name, role = role })
        end
    end

    table.sort(entries, function(a, b)
        if a.role == b.role then
            return a.name < b.name
        else
            return a.role < b.role
        end
    end)

    local count = 0
    for _, entry in ipairs(entries) do
        local msg = towstring("- [") .. towstring(entry.role) .. towstring("] - ") .. towstring(entry.name)
        AB_util.print(msg)
        count = count + 1
    end

    if count == 0 then
        AB_util.print("(no role data available)")
    end
end


function AutoBand.update(elapsed)
    AutoBand.elapsed = AutoBand.elapsed + elapsed
    if (AutoBand.elapsed > AB_const.HEARTBEAT) then
        local e = AutoBand.elapsed
        AutoBand.elapsed = 0
        AutoBand.cache_dirty = true
        AutoBand.map_point_lookup_cache = nil
        AutoBand.need_role_update = true
        AutoBand.auto_kick()
        AutoBand.auto_kick_toofar()
        AutoBand.auto_note()
        if AutoBand.need_role_update then
            AutoBand.update_roles()
            AutoBand.need_role_update = false
        end
    end

    if (AutoBand.cmd_current == nil) then
        if (#AutoBand.cmd_queue > 0) then
            AutoBand.cmd_current = table.remove(AutoBand.cmd_queue, 1)
        else
            return
        end
    end

    AutoBand.cmd_current.ticks = AutoBand.cmd_current.ticks - 1
    if (AutoBand.cmd_current.ticks <= 0) then
        if (AutoBand.debugon or AutoBand.gizilon) then
            AB_util.debug(tostring(AutoBand.cmd_current.cmd))
        end
        SendChatText(towstring(AutoBand.cmd_current.cmd), L"")
        local cmd_tmp = AutoBand.cmd_current
        AutoBand.cmd_current = nil
        if (cmd_tmp.callback) then
            cmd_tmp.callback(cmd_tmp)
        end
    end
end

function AutoBand.update_roles()
    local wb_obj = AutoBand.get_wb()
    if not wb_obj then
        AB_util.print("wb_obj is nil!")
        return
    end

    local current_players = {}

    local success, err = pcall(function()
        wb_obj:foreach_player(function(gid, player)
            AB_wb:track_role(player, current_players)
        end)
    end)

    if not success then
        AB_util.print("Error in foreach_player: " .. tostring(err))
    end

    AB_wb:remove_missing_players(current_players)
end

function AutoBand.cmd_custom_role(args)
    local subcmd = args[1]
    if not subcmd then
        AB_util.print("Usage: /ab customrole <add|remove|delete|list> ...")
        return
    end
    subcmd = subcmd:lower()

    local leader_name_lower = nil
    if GameData and GameData.Player and GameData.Player.name then
        leader_name_lower = tostring(AutoBand.FixString(GameData.Player.name)):lower()
    end

    if subcmd == "add" and args[2] and args[3] then
        local name_param = args[2]
        local name_lower_param = name_param:lower()
        local role_param_new_custom_role = args[3]:lower()

        if role_param_new_custom_role ~= AB_const.TANK and role_param_new_custom_role ~= AB_const.HEALER and role_param_new_custom_role ~= AB_const.MDPS and role_param_new_custom_role ~= AB_const.RDPS then
            AB_util.print("[Error] Invalid role: " .. args[3] .. ". Valid choices are tank, healer, mdps, or rdps.")
            return
        end

        if leader_name_lower and name_lower_param == leader_name_lower then
            -- Leader is setting their own custom role to role_param_new_custom_role
            if role_param_new_custom_role == AB_const.TANK and AutoBand.saved.max_tanks == 0 then
                AB_util.print("[Error] Cannot set your custom role to Tank. Max tanks limit is 0.")
                return
            elseif role_param_new_custom_role == AB_const.HEALER and AutoBand.saved.max_healers == 0 then
                AB_util.print("[Error] Cannot set your custom role to Healer. Max healers limit is 0.")
                return
            elseif (role_param_new_custom_role == AB_const.MDPS or role_param_new_custom_role == AB_const.RDPS) then
                if AutoBand.saved.max_dps == 0 then
                    AB_util.print("[Error] Cannot set your custom role to " .. role_param_new_custom_role .. ". Max DPS limit is 0.")
                    return
                end
                if AutoBand.saved.dps_weighting_enabled then
                    if role_param_new_custom_role == AB_const.MDPS and AutoBand.saved.max_mdps == 0 then
                        AB_util.print("[Error] Cannot set custom role to mDPS. Max mDPS is 0 (DPS weighting active).")
                        return
                    elseif role_param_new_custom_role == AB_const.RDPS and AutoBand.saved.max_rdps == 0 then
                        AB_util.print("[Error] Cannot set custom role to rDPS. Max rDPS is 0 (DPS weighting active).")
                        return
                    end
                end
            end
        end
        AutoBand.saved.custom_roles[name_lower_param] = role_param_new_custom_role
        AB_util.print("Added role override: " .. name_param .. " -> " .. role_param_new_custom_role)
        AutoBand.need_role_update = true

   elseif (subcmd == "remove" or subcmd == "delete") and args[2] then
        local name_to_remove_param = args[2]
        local name_to_remove_lower = name_to_remove_param:lower()

        if leader_name_lower and name_to_remove_lower == leader_name_lower then
            -- Leader is removing their own custom role. Check what they revert to.
            -- The 'true' flag tells GetLeaderEffectiveRoleCategory to ignore the custom role for this specific check.
            local reverted_role = AutoBand.GetLeaderEffectiveRoleCategory(true)

            if reverted_role then
                if reverted_role == AB_const.TANK and AutoBand.saved.max_tanks == 0 then
                    AB_util.print("[Error] Cannot remove your custom role. Your resulting role (Tank) has a max limit of 0.")
                    return
                elseif reverted_role == AB_const.HEALER and AutoBand.saved.max_healers == 0 then
                    AB_util.print("[Error] Cannot remove your custom role. Your resulting role (Healer) has a max limit of 0.")
                    return
                elseif (reverted_role == AB_const.MDPS or reverted_role == AB_const.RDPS) then
                    if AutoBand.saved.max_dps == 0 then
                        AB_util.print("[Error] Cannot remove custom role. Your resulting role ("..reverted_role..") has max DPS limit of 0.")
                        return
                    end
                    if AutoBand.saved.dps_weighting_enabled then
                        if reverted_role == AB_const.MDPS and AutoBand.saved.max_mdps == 0 then
                            AB_util.print("[Error] Cannot remove custom role. Your resulting role (mDPS) has max mDPS limit of 0 (DPS weighting active).")
                            return
                        elseif reverted_role == AB_const.RDPS and AutoBand.saved.max_rdps == 0 then
                            AB_util.print("[Error] Cannot remove custom role. Your resulting role (rDPS) has max rDPS limit of 0 (DPS weighting active).")
                            return
                        end
                    end
                end
            else
                AB_util.print("[Warning] Could not determine your resulting role if custom role is removed. Proceeding with removal.")
            end
        end
        AutoBand.saved.custom_roles[name_to_remove_lower] = nil
        AB_util.print("Removed role override for: " .. name_to_remove_param)
        AutoBand.need_role_update = true
    elseif subcmd == "list" then
        AB_util.print("Custom role overrides:")
        if next(AutoBand.saved.custom_roles) == nil then
            AB_util.print("(none)")
        else
            for k, v in pairs(AutoBand.saved.custom_roles) do
                AB_util.print("- " .. k .. ": " .. v)
            end
        end
    else
        AB_util.print("Usage: /ab customrole add <name> <role>")
        AB_util.print("   /ab customrole remove <name>")
        AB_util.print("   /ab customrole list")
    end
end

-- enqueues a string to be processed by "AutoBand.update()"
function AutoBand.enqueue_command(cmd, ticks, callback)
    ticks = ticks or AB_const.DEFAULT_CMD_TICKS
    table.insert(AutoBand.cmd_queue, {
        ["cmd"] = cmd,
        ["ticks"] = ticks,
        ["callback"] = callback
    })
end

function AutoBand.is_player_ignored(player_name_str)
    if not player_name_str then return false end

    local ignore_list = GetIgnoreList()
    if not ignore_list or type(ignore_list) ~= "table" then
        return false
    end

    for _, ignored_player_data in ipairs(ignore_list) do
        if ignored_player_data and ignored_player_data.name then
            local ignored_name_fixed = tostring(AutoBand.FixString(ignored_player_data.name))
            if ignored_name_fixed == player_name_str then
                return true
            end
        end
    end

    return false
end

function AutoBand.enqueue_kick(player_name, msg_reason)
    if (msg_reason and not AutoBand.is_player_ignored(tostring(player_name))) then
        -- Use the helper function to get the current prefix format for the tell message
        local prefix_raw_wspace = AutoBand.GetFormattedPrefixRaw(true)
        AutoBand.enqueue_command("/tell " .. tostring(player_name) ..
            " " .. prefix_raw_wspace .. "You were removed from the warband since " .. msg_reason)
    end
    AutoBand.enqueue_command(L"/kick " .. player_name)
    AB_util.print(L"Kicking " .. player_name)
end

function AutoBand.is_wb_leader()
    local wb_obj = AutoBand.get_wb()
    local i = 0
    wb_obj:foreach_player(
        function(gid, player)
            i = i + 1
        end
    )
    if i == 0 then
        return false
    end
    if not GameData or not GameData.Player then
        return false
    end
    return GameData.Player.isGroupLeader
end

-- Legacy helper kept for compatibility
function AutoBand.has_permission()
    return AutoBand.is_wb_leader()
end

function AutoBand.is_assistant()
    local wb_obj = AutoBand.get_wb() -- Get current group/wb data
    local i = 0
    -- Check if we are actually in a group recognised by the addon
    wb_obj:foreach_player(
        function(gid, player)
            i = i + 1
        end
    )
    if i == 0 then
        return false -- Can't be assistant if not in a group
    end
    return GameData.Player.isWarbandAssistant
end

function AutoBand.get_current_toofar_distance()
    local setting = AutoBand.saved.toofar_radius_setting
    if AB_const.TOOFAR_DISTANCE_VALUES[setting] then
        return AB_const.TOOFAR_DISTANCE_VALUES[setting]
    end
    -- Fallback if the setting is somehow corrupted or invalid post-init
    AB_util.print("[Internal Warning] Invalid 'toofar_radius_setting' (" .. tostring(setting) .. ") encountered. Using default distance.")
    return AB_const.TOOFAR_DISTANCE_VALUES[AB_const.DEFAULT_SAVED_TOOFAR_RADIUS_SETTING]
end

function AutoBand.cmd_set_toofar_distance(args)
    local setting_arg = args[1]

    -- Collect all the valid setting keys
    local valid_settings_keys = {}
    for k, _ in pairs(AB_const.TOOFAR_DISTANCE_VALUES) do
        table.insert(valid_settings_keys, k)
    end

    -- Sort them by their numeric distance (ascending)
    table.sort(valid_settings_keys, function(a, b)
        return AB_const.TOOFAR_DISTANCE_VALUES[a] < AB_const.TOOFAR_DISTANCE_VALUES[b]
    end)

    -- Build the usage/options string in sorted order
    local usage_options_str = table.concat(valid_settings_keys, "|")

    -- No argument provided: show usage & current setting
    if not setting_arg then
        AB_util.print(
            "[Error] Missing argument. Usage: /ab settoofardistance <"
            .. usage_options_str .. ">"
        )
        AB_util.print(
            "Current setting: "
            .. AutoBand.saved.toofar_radius_setting
            .. " (" .. AutoBand.get_current_toofar_distance() .. " units). Available: "
            .. table.concat(valid_settings_keys, ", ")
            .. "."
        )
        return
    end

    -- Normalize user input
    setting_arg = string.lower(setting_arg)

    -- If its valid, apply it
    if AB_const.TOOFAR_DISTANCE_VALUES[setting_arg] then
        AutoBand.saved.toofar_radius_setting = setting_arg
        AB_util.print(
            "'Too far' distance setting changed to: "
            .. setting_arg
            .. " (" .. AutoBand.get_current_toofar_distance() .. " units)."
        )

        -- If auto-kick is on, broadcast the change
        if AutoBand.saved.autokick_toofar_enabled and AutoBand.is_wb_leader() then
            local prefix_raw_wspace = AutoBand.GetFormattedPrefixRaw(true)
            local current_distance_str = AutoBand.get_current_toofar_distance() .. " units"
            AutoBand.enqueue_command(
                "/wb "
                .. prefix_raw_wspace
                .. "'Too far' distance has been updated to "
                .. current_distance_str
                .. "."
            )
        end

        -- If you had a GUI, youd refresh it here:
        -- if AutoBandWindow.showing() and AutoBandWindow.SelectedTab == AB_const.TABS_CONFIG then
        --     AutoBandWindowConfig.RefreshTooFarDistanceSetting()
        -- end

    else
        -- Invalid input: show error + valid options
        AB_util.print(
            "[Error] Invalid setting: '"
            .. setting_arg
            .. "'. Valid settings are: "
            .. table.concat(valid_settings_keys, ", ")
            .. "."
        )
    end
end

-- returns a AB_wb object either from a warband, scenario or dumped_wb
function AutoBand.get_wb()
    if (AutoBand.debugon and AutoBand.saved.dumped_wb ~= nil) then
        AB_util.debug("Getting dump " .. AutoBand.saved.default_dump .. " size " ..
            AB_util.size_wb(AutoBand.saved.dumped_wb.group) .. " (Debug mode, bypasses cache)")
        return AB_wb:new(AutoBand.saved.dumped_wb)
    end
    if not AutoBand.cache_dirty and AutoBand.cached_wb then
        return AutoBand.cached_wb
    end
    local wb = AB_wb:new()
    local success, err = pcall(function() wb:load_from_wbdata() end)
    if not success then
        AB_util.print("[Error] Failed to load warband data during cache refresh: " .. tostring(err))
    end
    AutoBand.cached_wb = wb
    AutoBand.cache_dirty = false
    return AutoBand.cached_wb
end

-- ####### / Commands #######
function AutoBand.parse_cmd(original_msg)
    local cmd_key = nil
    local args_str = "" -- Raw argument string (including spaces, original case)
    local args_tbl = {} -- Split arguments table (for most commands)

    -- Trim leading/trailing whitespace from the whole input
    original_msg = string.gsub(original_msg, "^%s+", "")
    original_msg = string.gsub(original_msg, "%s+$", "")

    -- Find the first space to separate command from arguments
    local first_space = string.find(original_msg, " ", 1, true)

    if first_space then
        -- Extract command part and convert ONLY the command to lowercase for lookup
        cmd_key = string.sub(original_msg, 1, first_space - 1):lower()
        -- Extract the rest of the string (arguments) with original case
        args_str = string.sub(original_msg, first_space + 1)
        -- Only split into a table IF NOT the setprefix command (or others needing raw string)
        if cmd_key ~= "setprefix" and args_str ~= "" then
             args_tbl = StringSplit(args_str)
        end
    else
        -- No space found, the whole message is the command
        cmd_key = original_msg:lower()
        -- args_str remains ""
        -- args_tbl remains {}
    end

    -- Find and execute the command handler
    if cmd_key and AutoBand.cmd[cmd_key] ~= nil then
        local handler_func = AutoBand.cmd[cmd_key].f
        -- Decide what to pass based on the command
        if cmd_key == "setprefix" or cmd_key == "prefix" then
            -- Pass the raw argument string directly for setprefix
            handler_func(args_str)
        else
            -- Pass the split arguments table for other commands
            handler_func(args_tbl)
        end
    else
        AB_util.print("AutoBand unknown command: " .. original_msg)
    end
end

function AutoBand.cmd_setroles(args, called_from_gui)
    called_from_gui = called_from_gui or false

    local function print_if_not_gui(message)
        if not called_from_gui then
            AB_util.print(message)
        end
    end
    local num_tanks_input = tonumber(args[1])
    local num_healers_input = tonumber(args[2])
    local num_dps_input = tonumber(args[3])

    if not num_tanks_input or not num_healers_input or not num_dps_input then
        print_if_not_gui("[Error] Invalid input. Usage: /ab setroles <tanks> <healers> <dps>")
        return
    end

    local num_tanks = math.floor(num_tanks_input)
    local num_healers = math.floor(num_healers_input)
    local num_dps = math.floor(num_dps_input)

    if num_tanks < 0 or num_healers < 0 or num_dps < 0 then
        print_if_not_gui("[Error] Role counts cannot be negative.")
        return
    end

    if num_tanks + num_healers + num_dps ~= 24 then
        print_if_not_gui("[Error] Role counts must sum to 24. Provided: " .. num_tanks .. "+" .. num_healers .. "+" .. num_dps .. " = " .. (num_tanks + num_healers + num_dps))
        return
    end

    local leader_effective_role = AutoBand.GetLeaderEffectiveRoleCategory()
    if not leader_effective_role then
        print_if_not_gui("[Warning] Could not determine your effective role. Proceeding with setting roles, but validation might be incomplete.")
    else
        if leader_effective_role == AB_const.TANK and num_tanks == 0 then
            print_if_not_gui("[Error] Cannot set max tanks to 0. Your current effective role is Tank.")
            return
        elseif leader_effective_role == AB_const.HEALER and num_healers == 0 then
            print_if_not_gui("[Error] Cannot set max healers to 0. Your current effective role is Healer.")
            return
        elseif (leader_effective_role == AB_const.MDPS or leader_effective_role == AB_const.RDPS) and num_dps == 0 then
            print_if_not_gui("[Error] Cannot set max DPS to 0. Your current effective role is " .. leader_effective_role .. ".")
            return
        end
    end

    AutoBand.saved.max_tanks = num_tanks
    AutoBand.saved.max_healers = num_healers
    AutoBand.saved.max_dps = num_dps

    print_if_not_gui("Role limits set to: Tanks=" .. num_tanks .. ", Healers=" .. num_healers .. ", DPS=" .. num_dps)

    if AutoBand.saved.max_mdps + AutoBand.saved.max_rdps ~= AutoBand.saved.max_dps then
        print_if_not_gui("[Warning] Max DPS changed. Resetting mDPS/rDPS weights proportionally.")
        if AutoBand.saved.max_dps > 0 then
            AutoBand.saved.max_rdps = math.floor(AutoBand.saved.max_dps / 2)
            AutoBand.saved.max_mdps = AutoBand.saved.max_dps - AutoBand.saved.max_rdps
            if AutoBand.saved.max_mdps == 0 and AutoBand.saved.max_dps > 0 and AutoBand.saved.max_rdps > 0 then
                AutoBand.saved.max_mdps = 1
                AutoBand.saved.max_rdps = AutoBand.saved.max_dps - 1
            elseif AutoBand.saved.max_rdps == 0 and AutoBand.saved.max_dps > 0 and AutoBand.saved.max_mdps > 0 then
                AutoBand.saved.max_rdps = 1
                AutoBand.saved.max_mdps = AutoBand.saved.max_dps - 1
            end
        else
            AutoBand.saved.max_mdps = 0
            AutoBand.saved.max_rdps = 0
        end
        print_if_not_gui(" -> New mDPS/rDPS weights: mDPS=" .. AutoBand.saved.max_mdps .. ", rDPS=" .. AutoBand.saved.max_rdps)
    end

    if AutoBandWindowConfig and AutoBandWindowConfig.refresh_autokick_label then
        AutoBandWindowConfig.refresh_autokick_label()
        AutoBandWindowConfig.refresh_dps_weights()
    end

    if AutoBandWindowTemplate and AutoBandWindowTemplate.refresh_role_limits then
        AutoBandWindowTemplate.refresh_role_limits()
    end
end

function AutoBand.cmd_resetroles(args)
       AutoBand.saved.max_tanks = AB_const.DEFAULT_MAX_TANKS
       AutoBand.saved.max_healers = AB_const.DEFAULT_MAX_HEALERS
       AutoBand.saved.max_dps = AB_const.DEFAULT_MAX_DPS
       AutoBand.saved.max_mdps = AB_const.DEFAULT_MAX_MDPS
       AutoBand.saved.max_rdps = AB_const.DEFAULT_MAX_RDPS
       AB_util.print("Role limits reset to default: Tanks=" .. AutoBand.saved.max_tanks .. ", Healers=" .. AutoBand.saved.max_healers .. ", DPS=" .. AutoBand.saved.max_dps)
	   AutoBand.cmd_setroles({AutoBand.saved.max_tanks, AutoBand.saved.max_healers, AutoBand.saved.max_dps}, true)
end

function AutoBand.cmd_usage(args)
    local ab = "/autoband "
    if (AutoBand.has_shortslash) then
        ab = "/ab "
    end
    AB_util.print("[Autoband v" .. AB_const.VERSION .. " commands]")
    for _, cmd in ipairs(AutoBand.cmd_ordered) do
       if (cmd.help ~= "" or AutoBand.debugon) then
            -- Use resolved_help which handles functions
            local help_text = cmd.resolved_help or ""
            if type(cmd.help) == "function" then -- Resolve again just in case order changes things (unlikely here)
                 help_text = cmd.help()
            end
      AB_util.print(ab .. cmd.key .. " - " .. help_text)
      end
    end
end

function AutoBand.cmd_show(args)
    AB_util.print("[Autoband v" .. AB_const.VERSION .. " settings]")
    local current_prefix_example = AutoBand.GetFormattedPrefixRaw(false) -- Get raw string example
    AB_util.print("Chat Prefix: " .. current_prefix_example .. " (Color: " .. AutoBand.saved.prefix_color_name .. ")")
    AB_util.print("Use Guild Prefix in searches: " .. tostring(AutoBand.saved.prefix_use_guild))
    -- AB_util.print("Chat Prefix: '" .. AutoBand.saved.prefix_text .. "' (Color: " .. AutoBand.saved.prefix_color_name .. ")")
    AB_util.print("WB Lead Mention Color: " .. AutoBand.saved.lead_color_name .. ".")
    AB_util.print("Faction detected as " .. (AutoBand.faction or "Unknown") .. ".")
    AB_util.print("Race detected as " .. (AutoBand.race or "Unknown") .. ".")
    AB_util.print("Default template: " .. AutoBand.saved.default_template)
    AB_util.print("Right-click icon to organize: " .. tostring(AutoBand.saved.right_click_organize))
    AB_util.print("Middle-click icon to organize (distance): " .. tostring(AutoBand.saved.middle_click_organize_range))
    AB_util.print("Auto kick too far players: " .. tostring(AutoBand.saved.autokick_toofar_enabled))
    AB_util.print(" -> 'Too far' distance setting: " .. AutoBand.saved.toofar_radius_setting .. " (" .. AutoBand.get_current_toofar_distance() .. " units)")
    AB_util.print("Auto kick too far players timeout: " .. tostring(AutoBand.saved.autokick_period))
    AB_util.print("/ab org distance threshold: " .. AutoBand.saved.range_sort_distance_threshold .. " units.")
    AB_util.print("Minimum rank requirement: " .. tostring(AutoBand.saved.min_rank))
    AB_util.print("Minimum rank requirement (healer): " .. tostring(AutoBand.saved.min_rank_healer))
    AB_util.print("Auto enforcing " .. AutoBand.saved.max_tanks .. "-" .. AutoBand.saved.max_healers .. "-" .. AutoBand.saved.max_dps .." WB (autokick): " .. tostring(AutoBand.saved.autokick_enabled))
    AB_util.print(" -> DPS Weighting Enabled: " .. tostring(AutoBand.saved.dps_weighting_enabled))
    if AutoBand.saved.dps_weighting_enabled then
        AB_util.print("    -> Max Melee DPS: " .. tostring(AutoBand.saved.max_mdps))
        AB_util.print("    -> Max Ranged DPS: " .. tostring(AutoBand.saved.max_rdps))
    end
    AB_util.print("Auto kick players below rank req: " .. tostring(AutoBand.saved.autokick_low_rank_enabled))
    AB_util.print("Auto kick stealthers: " .. tostring(AutoBand.saved.autokick_we_wh_enabled))
    AB_util.print("Auto kick players outside RvR zones: " .. tostring(AutoBand.saved.autokick_rvrzone_enabled))
	AB_util.print("Auto kick ignored players: " .. tostring(AutoBand.saved.autokick_ignorelist_enabled))
    AB_util.print("Guild priority when auto-kick: " .. tostring(AutoBand.saved.guild_priority_enabled))
    AB_util.print("Notify warband after organize: " .. tostring(AutoBand.saved.notify_buffs_enabled))
    AB_util.print("Use alt spec check: " .. tostring(AutoBand.saved.alt_speccheck_enabled))
    AB_util.print("Auto note in /1: " .. tostring(AutoBand.saved.autonote_enabled))
    AB_util.print("Print role assignments: " .. tostring(AutoBand.saved.printrole_enabled))
    local bw_sorc_label = AB_const.GetBWSorcAsMDPSLabel() -- Get faction-aware label
    AB_util.print(bw_sorc_label .. ": " .. tostring(AutoBand.saved.bw_sorc_as_mdps))
    local restrict_race_label = AB_const.GetRestrictRaceLabel() -- Get race-aware label
    AB_util.print(restrict_race_label .. ": " .. tostring(AutoBand.saved.restrict_same_race))
    if AutoBand.current_purpose then
        local purpose_display = AB_const.WARBAND_PURPOSES[AutoBand.current_purpose].display or AutoBand.current_purpose
        AB_util.print("Current warband purpose: " .. purpose_display)
    else
        AB_util.print("Current warband purpose: none set")
    end
    if (AutoBand.debugon) then
        AB_util.print("Data dumped: " .. tostring(AutoBand.saved.dumped_wb ~= nil))
        AB_util.print("Debug mode: true")
    end
end

function AutoBand.cmd_debug(args)
    AutoBand.debugon = not AutoBand.debugon
    AB_util.print("Debug mode: " .. tostring(AutoBand.debugon))
end

function AutoBand.cmd_flag_autokick(args)
    AutoBand.saved.autokick_enabled = not AutoBand.saved.autokick_enabled
    AB_util.print("Auto enforcing " .. AutoBand.saved.max_tanks .. "-" .. AutoBand.saved.max_healers .. "-" .. AutoBand.saved.max_dps .." WB (autokick): " .. tostring(AutoBand.saved.autokick_enabled))
    if AutoBandWindow.showing() and AutoBandWindow.SelectedTab == AB_const.TABS_CONFIG then
        AutoBandWindowConfig.Show()
    end
end

function AutoBand.cmd_flag_autokick_toofar(args)
    AutoBand.saved.autokick_toofar_enabled = not AutoBand.saved.autokick_toofar_enabled
    if AutoBand.is_wb_leader() then
        local prefix_raw_wspace = AutoBand.GetFormattedPrefixRaw(true)
        local current_distance_str = AutoBand.get_current_toofar_distance() .. " units" -- Get current distance for message
        if AutoBand.saved.autokick_toofar_enabled then
            AutoBand.enqueue_command("/wb " .. prefix_raw_wspace .. "Autokick players too far (current max: " .. current_distance_str .. ") ENABLED! Follow the leader PLEASE!")
        else
            AutoBand.enqueue_command("/wb " .. prefix_raw_wspace .. "Autokick players too far DISABLED!")
            warned = {}
            toofar = {}
            toofar_old = {}
            toofar_not_changed = {}
        end
    end
    AB_util.print("Auto kick too far players: " .. tostring(AutoBand.saved.autokick_toofar_enabled))
    if AutoBandWindow.showing() and AutoBandWindow.SelectedTab == AB_const.TABS_CONFIG then
        AutoBandWindowConfig.Show()
    end
end

function AutoBand.cmd_flag_autonote(args)
    AutoBand.saved.autonote_enabled = not AutoBand.saved.autonote_enabled
    AB_util.print("Auto note in /1: " .. tostring(AutoBand.saved.autonote_enabled))
    if AutoBandWindow.showing() and AutoBandWindow.SelectedTab == AB_const.TABS_TOOLS then
        AutoBandWindowTools.Show()
    end
end

function AutoBand.cmd_dump(args)
    if (args[1] == nil) then
        AB_util.print("[error] Missing argument")
        return
    end
    local wb = AB_wb:new()
    wb:load_from_wbdata()
    AutoBand.saved.dumped_wb = wb
    AutoBand.saved.default_dump = args[1]
    AutoBand.saved.dumps[args[1]] = wb
    AB_util.print("Dump complete")
end

function AutoBand.cmd_cleardumps(args)
    AutoBand.saved.dumped_wb = nil
    AutoBand.saved.dumps = {}
    AutoBand.saved.default_dump = nil
end

function AutoBand.cmd_kick_toofar(args)
    if (not AutoBand.is_wb_leader()) then
        AB_util.print("[error] You need to be a wb leader")
        return
    end
    local wb_obj = AutoBand.get_wb()
    local current_toofar_distance = AutoBand.get_current_toofar_distance() -- Get dynamic distance
    local kicked_count = 0
    local mp_lookup = BuildMapPointLookup()

    wb_obj:foreach_player(
        function(gid, player)
            local mpd = mp_lookup[player.name]
            if mpd and mpd.distance then
                player.distance = mpd.distance * DISTANCE_FIX_COEFFICIENT
                if player.distance > current_toofar_distance then
                    AutoBand.enqueue_kick(player.name, "not following leader (distance " .. math.floor(player.distance) .. " > " .. current_toofar_distance .. ")")
                    kicked_count = kicked_count + 1
                end
            end
        end
    )
    if kicked_count > 0 then
         AB_util.print("Kicked " .. kicked_count .. " player(s) for being too far (current threshold: " .. current_toofar_distance .. " units).")
    else
         AB_util.print("No players found exceeding the 'too far' distance of " .. current_toofar_distance .. " units.")
    end
end

function AutoBand.cmd_list_offline(args)
  local wb_obj = AutoBand.get_wb()
  local current_toofar_distance = AutoBand.get_current_toofar_distance() -- Get dynamic distance
  local listed_count = 0

  AB_util.print("Players further than " .. current_toofar_distance .. " units:")

  local mp_lookup = BuildMapPointLookup()
  wb_obj:foreach_player(
    function(gid, player)
      local mpd = mp_lookup[player.name]
      if mpd and mpd.distance then
        player.distance = mpd.distance * DISTANCE_FIX_COEFFICIENT
        if player.distance > current_toofar_distance then
          local zoneName = L"Unknown Zone"
          if player.zoneNum and player.zoneNum ~= 0 then
            local success, zn = pcall(GetZoneName, player.zoneNum)
            if success and zn and zn ~= L"" then
              zoneName = zn
            elseif success and (zn == L"" or zn == nil) then
              zoneName = L"Zone ID: " .. towstring(player.zoneNum)
            end
          elseif player.zoneNum == 0 then
            zoneName = L"Offline"
          end
          local message = L"- " .. towstring(player.name) ..
                  L" (distance: " .. towstring(math.floor(player.distance)) ..
                  L", zone: " .. zoneName .. L")"
          AB_util.print(message)
          listed_count = listed_count + 1
        end
      end
    end
  )
  if listed_count == 0 then
    AB_util.print("(none found)")
  end
end

function AutoBand.cmd_list_rank(args)
    local str = ""
    local players = AutoBand.get_low_rank()
    if (#players > 0) then
        table.sort(players, function(p1, p2) return p1.level > p2.level end)
        for _, player in ipairs(players) do
            str = str .. tostring(player.name) .. "(r" .. player.level .. ") "
        end
        AB_util.print(AB_const.HEADER_MARGIN ..
            " Players with rank < (configured) " ..
            AB_const.HEADER_MARGIN ..
            " (#" .. #players .. ")")
        AB_util.print(str)
    end
end

function AutoBand.cmd_list_zone(args)
    local wb_obj = AutoBand.get_wb()
    if (wb_obj.player_count == 0) then
        AB_util.debug("No wb data found")
        return
    end

    local players_by_zid = AutoBand.get_players_zone(wb_obj)
    local num_valid_zones = AB_util.size_table(players_by_zid["valid_as"])
    if (players_by_zid["valid_as"] and num_valid_zones > 0) then
        AB_util.print(AB_const.HEADER_MARGIN ..
            " Leader's and assistants' zones " ..
            AB_const.HEADER_MARGIN)
        for zid, as_zone in pairs(players_by_zid["valid_as"]) do
            local num_assistants = AB_util.size_table(as_zone)
            local str = ""
            local num_players = AB_util.size_table(players_by_zid["valid_p"][zid])
            local zone_name = GetZoneName(zid)
            if (zid == 0) then
                zone_name = "Offline"
            end
            str = str .. tostring(zone_name) .. " (#" .. num_players .. ") "
            for _, player in ipairs(as_zone) do
                if (player.isGroupLeader) then
                    str = str .. tostring(player.name) ..
                    "(" .. AB_const.ABBREVATIONS["LEADER"] .. ") "
                else
                    str = str .. tostring(player.name) ..
                    "(" .. AB_const.ABBREVATIONS["ASSISTANT"] .. ") "
                end
            end
            AB_util.print(str)
        end
    end

    local num_invalid_zones = AB_util.size_table(players_by_zid["other"])
    if (players_by_zid["other"] and num_invalid_zones > 0) then
        AB_util.print(AB_const.HEADER_MARGIN ..
            " " ..
            AB_const.LABEL_NOTSAMEZONE ..
            " " ..
            AB_const.HEADER_MARGIN)
        for zid, other_zone in pairs(players_by_zid["other"]) do
            local str = ""
            local num_players = AB_util.size_table(other_zone)
            str = str ..
                tostring(GetZoneName(zid)) ..
                " (#" .. #other_zone .. ") "
            for _, player in ipairs(other_zone) do
                str = str .. tostring(player.name) .. " "
            end
            AB_util.print(str)
        end
    end
end

function AutoBand.cmd_kick_notinzone(args)
    if (not AutoBand.is_wb_leader()) then
        AB_util.print("[error] You need to be a wb leader")
        return
    end

    local wb_obj = AutoBand.get_wb()
    if (wb_obj.player_count == 0) then
        AB_util.debug("No wb data found")
        return
    end

    local zone_name = GetZoneName
    local players_by_zid = AutoBand.get_players_zone(wb_obj)
    local num_valid_zones = AB_util.size_table(players_by_zid["valid_as"])

    if (players_by_zid["valid_as"] and num_valid_zones > 0) then
        local valid_zone_str = ""
        for zid, as_zone in pairs(players_by_zid["valid_as"]) do
            if (zid ~= 0) then
                valid_zone_str = valid_zone_str ..
                    tostring(zone_name(zid)) ..
                    " "
            end
        end

        local num_invalid_zones = AB_util.size_table(players_by_zid["other"])
        if (players_by_zid["other"] and num_invalid_zones > 0) then
            AB_util.print("Kicking " .. AB_const.LABEL_NOTSAMEZONE)
            for zid, other_zone in pairs(players_by_zid["other"]) do
                if (zid ~= 0) then
                    for _, player in ipairs(other_zone) do
                        AutoBand.enqueue_kick(player.name,
                            "you are not in one of the required zones {" ..
                            valid_zone_str .. "}")
                    end
                end
            end
        end
    end
    AB_util.print("Zone kick complete")
end

function AutoBand.cmd_toggle_autokick_we_wh(args)
    AutoBand.saved.autokick_we_wh_enabled = not AutoBand.saved.autokick_we_wh_enabled
    AB_util.print("Auto kick stealthers: " .. tostring(AutoBand.saved.autokick_we_wh_enabled))
    if AutoBandWindow.showing() and AutoBandWindow.SelectedTab == AB_const.TABS_CONFIG then
        AutoBandWindowConfig.Show()
    end
end

function AutoBand.cmd_rank(args)
    if (args[1] == nil) then
        AB_util.print("[error] Missing argument")
        return
    end
    local n = tonumber(args[1])
    if (n < 0 or n > 40) then
        AB_util.print("[error] Invalid rank value: " .. tostring(n))
        return
    end
    AutoBand.saved.min_rank = math.floor(n)

    -- Ensure the separate healer rank doesn't exceed the new min_rank
    if (AutoBand.saved.min_rank_healer > AutoBand.saved.min_rank) then
        AutoBand.saved.min_rank_healer = AutoBand.saved.min_rank
    end

    AB_util.print("Minimum rank requirement: " .. tostring(AutoBand.saved.min_rank))
    if AutoBandWindow.showing() and AutoBandWindow.SelectedTab == AB_const.TABS_CONFIG then
        AutoBandWindowConfig.Show()
    end
end

function AutoBand.cmd_rank_healer(args)
    if (args[1] == nil) then
        AB_util.print("[error] Missing argument")
        return
    end
    local n = tonumber(args[1])
    if (n < 0 or n > 40) then
        AB_util.print("[error] Invalid healer rank value: " .. tostring(n))
        return
    end
    -- Make sure it cannot exceed the general min_rank
    if (n > AutoBand.saved.min_rank) then
        AB_util.print("[error] Healer min rank cannot exceed overall min rank (" ..
            AutoBand.saved.min_rank .. ")")
        return
    end
    AutoBand.saved.min_rank_healer = math.floor(n)
    AB_util.print("Minimum rank requirement (healer): " .. tostring(AutoBand.saved.min_rank_healer))
    if AutoBandWindow.showing() and AutoBandWindow.SelectedTab == AB_const.TABS_CONFIG then
        AutoBandWindowConfig.Show()
    end
end

function AutoBand.cmd_kick_rank(args)
    if (not AutoBand.is_wb_leader()) then
        AB_util.print("[error] You need to be a wb leader")
        return
    end
    local players = AutoBand.get_low_rank()
    if (#players > 0) then
        AB_util.print("Kicking players below rank requirements")
        for _, player in ipairs(players) do
            local needed = player.role == "healer" and AutoBand.saved.min_rank_healer or AutoBand.saved.min_rank
            AutoBand.enqueue_kick(player.name,
                "you don't meet the rank requirement (" .. needed .. ")")
        end
    end
    AB_util.print("Rank kick complete")
end

function AutoBand.cmd_organize(args)
    local is_leader_perm = AutoBand.is_wb_leader()
    local is_assist_perm = AutoBand.is_assistant()
    local debug_mode = AutoBand.debugon

    if not (is_leader_perm or is_assist_perm or debug_mode) then
        AB_util.print("[error] You need to be a wb leader or assistant")
        return
    end

    local organize_by_distance_param = false
    local template_name_arg = args[1] -- Could be template name OR "distance"
    local distance_keyword_arg = args[2] -- Could be "distance" if args[1] is a template name

    -- Determine if the "distance" parameter is used and which template key to use
    local tpl_to_use_key

    if template_name_arg and string.lower(template_name_arg) == "distance" then
        organize_by_distance_param = true
        tpl_to_use_key = AutoBand.saved.default_template -- /ab org distance -> use default
        -- No specific template name was given before "distance"
    elseif distance_keyword_arg and string.lower(distance_keyword_arg) == "distance" then
        organize_by_distance_param = true
        tpl_to_use_key = template_name_arg -- /ab org <template> distance -> use specific_template
    else
        -- No "distance" keyword, or not in a recognized position for this simple parse
        tpl_to_use_key = template_name_arg or AutoBand.saved.default_template -- /ab org [template_name_or_nil]
    end

    local tpl = AutoBand.saved.templates[tpl_to_use_key]
    if not tpl and tpl_to_use_key ~= AB_const.EMPTY_TEMPLATE then
        AB_util.print("[Warning] Template '" .. tostring(tpl_to_use_key) .. "' not found. Using empty layout.")
        tpl = nil -- AB_org.auto_organize and AB_template.match will handle nil as empty
    end

    -- Range processing logic
    AB_org.is_distance_sort_active = false -- Reset flag

    if organize_by_distance_param then
        if is_leader_perm or debug_mode then
            AB_org.is_distance_sort_active = true
            local current_player_name_for_log = (GameData.Player and GameData.Player.name and tostring(GameData.Player.name)) or "Current Player"
            AB_util.print("Distance-based organization activated (Distances relative to: " .. current_player_name_for_log .. ").")

            local wb_obj_for_distances = AutoBand.get_wb() -- Get the WB object
            if wb_obj_for_distances and wb_obj_for_distances.group then
                local current_player_direct_name = GameData.Player.name -- Assuming this is a wstring for comparison

                local mp_lookup = BuildMapPointLookup()

                wb_obj_for_distances:foreach_player(function(gid, p_to_update)
                    p_to_update.distance_to_leader = 99999 -- Default to far

                    if p_to_update.name == current_player_direct_name then -- Compare wstring to wstring
                        p_to_update.distance_to_leader = 0
                    else
                        local mpd_p = mp_lookup[p_to_update.name]
                        if mpd_p and type(mpd_p.distance) == "number" then
                            p_to_update.distance_to_leader = mpd_p.distance * DISTANCE_FIX_COEFFICIENT
                        elseif AutoBand.debugon then
                            AB_util.print("[Debug] Player " .. tostring(p_to_update.name) .. " not found on map with valid distance for range sort.")
                        end
                    end
                end)
                -- If get_wb() returned a cached object, we've modified it.
                -- Ensure the cache system knows if it needs to be "dirty" or if this is fine.
                -- For simplicity, we assume get_wb() handles its cache; if it returns a live modifiable object, this is okay.
                -- If AutoBand.cached_wb was returned, it's now updated.
            else
                AB_util.print("[Error] Could not get warband data to calculate distances for distance sort.")
                AB_org.is_distance_sort_active = false -- Disable if we can't process
            end
        else
            -- Silently ignore "distance" for assistants not in debug mode
            AB_org.is_distance_sort_active = false
            AB_util.print("[Info] As an assistant, the 'distance' parameter is ignored. Proceeding with normal warband organization" .. template_message_part)
        end
    end

    -- Store original settings
    local original_settings = {
        autokick_enabled = AutoBand.saved.autokick_enabled,
        autokick_toofar_enabled = AutoBand.saved.autokick_toofar_enabled,
        autokick_low_rank_enabled = AutoBand.saved.autokick_low_rank_enabled,
        autokick_we_wh_enabled = AutoBand.saved.autokick_we_wh_enabled,
        notify_buffs_enabled = AutoBand.saved.notify_buffs_enabled
    }

    -- Disable during organization
    AutoBand.saved.autokick_enabled = false
    AutoBand.saved.autokick_toofar_enabled = false
    AutoBand.saved.autokick_low_rank_enabled = false
    AutoBand.saved.autokick_we_wh_enabled = false
    if is_assist_perm or debug_mode then
        AutoBand.saved.notify_buffs_enabled = false
    end

    AB_org.auto_organize(tpl) -- Call with ONLY the template data

    -- Restore original flags
    AutoBand.saved.autokick_enabled = original_settings.autokick_enabled
    AutoBand.saved.autokick_toofar_enabled = original_settings.autokick_toofar_enabled
    AutoBand.saved.autokick_low_rank_enabled = original_settings.autokick_low_rank_enabled
    AutoBand.saved.autokick_we_wh_enabled = original_settings.autokick_we_wh_enabled
    if is_assist_perm or debug_mode then
        AutoBand.saved.notify_buffs_enabled = original_settings.notify_buffs_enabled
    end
end

function AutoBand.cmd_autokick_timeout(args)
    if (args[1] == nil) then
        AB_util.print("[error] Missing argument")
        return
    end
    local n = tonumber(args[1])
    if (n < 0) then
        AB_util.print("[error] Invalid timeout value: " .. tostring(n))
        return
    end
    AutoBand.saved.autokick_period = math.floor(n)
    AB_util.print("Auto kick timeout: " .. tostring(AutoBand.saved.autokick_period))
    if AutoBandWindow.showing() and AutoBandWindow.SelectedTab == AB_const.TABS_CONFIG then
        AutoBandWindowConfig.Show()
    end
end

function AutoBand.cmd_mode(args)
    if (args[1] == nil) then
        AB_util.print("[error] Missing argument")
        return
    end
    local n = tonumber(args[1])
    if (n < 0 or n > 2) then
        AB_util.print("[error] Invalid distribution algorithm: " .. tostring(n))
        return
    end
    AutoBand.saved.org_algo_mode = math.floor(n)
    AB_util.print("Distribution algorithm mode: " ..
        tostring(AutoBand.saved.org_algo_mode) ..
        AB_const.ALGO_MODE[AutoBand.saved.org_algo_mode])
    if AutoBandWindow.showing() and AutoBandWindow.SelectedTab == AB_const.TABS_CONFIG then
        AutoBandWindowConfig.Show()
    end
end

function AutoBand.cmd_set_purpose(args)
    if not AutoBand.is_wb_leader() then
        AB_util.print("[Error] Only the warband leader can set the purpose.")
        return
    end
    local purpose_arg = args[1]
    if not purpose_arg then
        AB_util.print("[Error] Missing purpose type. Usage: /ab purpose <" .. AB_const.GetPurposeNames() .. "|clear>")
        return
    end

    purpose_arg = purpose_arg:lower() -- Convert input to lowercase

    if purpose_arg == "clear" or purpose_arg == "none" then
        if AutoBand.current_purpose then
            AutoBand.current_purpose = nil
            AB_util.print("Warband purpose cleared.")
        else
            AB_util.print("Warband purpose was not set.")
        end
        return
    end

    local canonical_purpose = AB_const.PURPOSE_ALIASES[purpose_arg]

    if canonical_purpose then
        if AB_const.WARBAND_PURPOSES[canonical_purpose] then
            AutoBand.current_purpose = canonical_purpose -- Store the canonical key
            local purpose_display = AB_const.WARBAND_PURPOSES[canonical_purpose].display or canonical_purpose
            AB_util.print("Warband purpose set to: " .. purpose_display)
        else
            AB_util.print("[Internal Error] Alias '" .. purpose_arg .. "' maps to invalid purpose '" .. canonical_purpose .. "'.")
            AutoBand.current_purpose = nil -- Ensure purpose is not set incorrectly
        end
    else
        AB_util.print("[Error] Invalid purpose type '" .. purpose_arg .. "'. Valid types: " .. AB_const.GetPurposeNames() .. ", clear")
    end
end

function AutoBand.cmd_list_purposes(args)
    AB_util.print("Available warband purposes:")
    local purpose_keys = {}
    for key, _ in pairs(AB_const.WARBAND_PURPOSES) do
        table.insert(purpose_keys, key)
    end

    if #purpose_keys == 0 then
        AB_util.print("- None defined.")
        return
    end

    table.sort(purpose_keys)

    for _, key in ipairs(purpose_keys) do
        local purpose_data = AB_const.WARBAND_PURPOSES[key]
        if purpose_data then
            local display_name = purpose_data.display or key -- Fallback to key if display name is missing
            local description = purpose_data.description or "No description available." -- Fallback description
            local output_line = L"- " .. towstring(key) .. L" - " .. towstring(display_name) .. L": " .. towstring(description)
            AB_util.print(output_line)
        end
    end
    AB_util.print(L"Set the current purpose using: /ab purpose <name>")
end

function AutoBand.OnGroupLeave()
    if AutoBand.current_purpose then
        -- AB_util.print("GROUP_LEAVE event fired, clearing warband purpose.")
        AutoBand.current_purpose = nil
    end
end

function AutoBand.cmd_flag_guildpriority(args)
    AutoBand.saved.guild_priority_enabled = not AutoBand.saved.guild_priority_enabled
    AB_util.print("Guild priority for auto-kick: " .. tostring(AutoBand.saved.guild_priority_enabled))
    if AutoBandWindow.showing() and AutoBandWindow.SelectedTab == AB_const.TABS_CONFIG then
        AutoBandWindowConfig.Show()
    end
end

function AutoBand.cmd_list_template(args)
    AB_util.print("Default template " .. AutoBand.saved.default_template)
    for tname in pairs(AutoBand.saved.templates) do
        AB_util.print(tname)
    end
end

function AutoBand.cmd_save_template(args)
  if (args[1] == nil) then
    AB_util.print("[Error] Missing argument. Usage: /ab save <name>") -- Enhanced error message
    return
  end
    local template_name = args[1]
    local template_name_lower = template_name:lower() -- Case-insensitive check

    -- Check if the lowercase version of the template name is "distance"
    if template_name_lower == "distance" then
        AB_util.print("[Error] 'distance' is a reserved keyword and cannot be used for template names.")
        return
    end

    -- Also check against other special template names already handled by the GUI's is_special_template
    -- These are <Warband> and <Automatic>
    if template_name == AB_const.CURRENT_WB or template_name == AB_const.EMPTY_TEMPLATE then
         AB_util.print("[Error] '" .. template_name .. "' is a reserved name and cannot be used for templates.")
         return
    end

  AutoBand.saved.templates[template_name] = AB_template.from_wb(AutoBand.get_wb())
  AB_util.print("Template '" .. template_name .. "' saved.") -- Added quotes for clarity
end

function AutoBand.cmd_apply_template(args)
    if (args[1] == nil) then
        AB_util.print("[error] Missing argument")
        return
    end
    if (AutoBand.saved.templates[args[1]] == nil) then
        AB_util.print("[error] Template " .. args[1] .. " does not exist")
        return
    end
    AB_org.auto_organize(AutoBand.saved.templates[args[1]])
    AB_util.print("Template " .. args[1] .. " loaded")
end

function AutoBand.cmd_default_template(args)
    if (#args > 0) then
        if (AutoBand.saved.templates[args[1]] == nil) then
            AB_util.print("[error] Template " .. args[1] .. " does not exist")
            return
        end
        AutoBand.saved.default_template = args[1]
    else
        AutoBand.saved.default_template = AB_const.EMPTY_TEMPLATE
    end
    AB_util.print("Default template set: " .. AutoBand.saved.default_template)
    if AutoBandWindow.showing() and AutoBandWindow.SelectedTab == AB_const.TABS_CONFIG then
        AutoBandWindowConfig.Show()
    end
end

function AutoBand.cmd_toggle_gui(args)
    if (AutoBandWindow.showing()) then
        AutoBandWindow.Hide()
    else
        AutoBandWindow.Show()
    end
end

function AutoBand.cmd_toggle_icon(args)
    AutoBandWindow.toggle_mapicon()
    AB_util.print("Show map-icon: " .. tostring(AutoBand.saved.displayicon))
    if AutoBandWindow.showing() and AutoBandWindow.SelectedTab == AB_const.TABS_CONFIG then
        AutoBandWindowConfig.Show()
    end
end

function AutoBand.cmd_toggle_rco(args)
    AutoBand.saved.right_click_organize = not AutoBand.saved.right_click_organize
    AB_util.print("Right-click icon to organize: " .. tostring(AutoBand.saved.right_click_organize))
    if AutoBandWindow.showing() and AutoBandWindow.SelectedTab == AB_const.TABS_TOOLS then
        AutoBandWindowTools.Show()
    end
end

function AutoBand.HandleIconRightClick()
    PlaySound(GameData.Sound.BUTTON_CLICK)
    if AutoBand.saved.right_click_organize then
        AB_util.print("Icon right-clicked: Organizing warband...")
        AutoBand.cmd_organize({})
    else
    end
end

function AutoBand.cmd_toggle_mcor(args)
    AutoBand.saved.middle_click_organize_range = not AutoBand.saved.middle_click_organize_range
    AB_util.print("Middle-click icon to organize (distance): " .. tostring(AutoBand.saved.middle_click_organize_range))
    if AutoBandWindow.showing() and AutoBandWindow.SelectedTab == AB_const.TABS_TOOLS then
        AutoBandWindowTools.Show()
    end
end

function AutoBand.HandleIconMiddleClick()
    PlaySound(GameData.Sound.BUTTON_CLICK)
    if AutoBand.saved.middle_click_organize_range then
        AB_util.print("Icon middle-clicked: Organizing warband by distance...")
        AutoBand.cmd_organize({"distance"}) -- Pass "distance" as an argument
    else
    end
end

--[[
    New Tooltip Functions
]]
function AutoBand.OnIconMouseOver()
    -- Define anchor point for the tooltip relative to the icon
    local anchor = { Point="topleft", RelativeTo=SystemData.ActiveWindow.name, RelativePoint="bottomleft", XOffset=5, YOffset=-10 }
    Tooltips.CreateTextOnlyTooltip(SystemData.ActiveWindow.name)

    -- Build tooltip text based on current settings
    local tooltipText = L"AutoBand\n" ..
                        L"LClick: Open AutoBand Window"

    if AutoBand.saved.right_click_organize then
        tooltipText = tooltipText .. L"\nRClick: Organize Warband"
    end

    if AutoBand.saved.middle_click_organize_range then
        tooltipText = tooltipText .. L"\nMClick: Organize by Distance"
    end

    -- Set, finalize, and anchor the tooltip
    Tooltips.SetTooltipText(1, 1, tooltipText)
    Tooltips.Finalize()
    Tooltips.AnchorTooltip(anchor)
end

function AutoBand.OnIconMouseLeave()
    Tooltips.DestroyTooltip(SystemData.ActiveWindow.name)
end

function AutoBand.cmd_list_dump(args)
    if (AutoBand.saved.dumped_wb ~= nil) then
        AB_util.print("[AutoBand] default dump " .. AutoBand.saved.default_dump)
    end
    for tname in pairs(AutoBand.saved.dumps) do
        AB_util.print(tname)
    end
end

function AutoBand.cmd_load_dump(args)
    if (#args > 0) then
        if (AutoBand.saved.dumps[args[1]] == nil) then
            AB_util.print("[error] Dump " .. args[1] .. " does not exist")
            return
        end
        AutoBand.saved.default_dump = args[1]
        AutoBand.saved.dumped_wb = AutoBand.saved.dumps[AutoBand.saved.default_dump]
    end
    AB_util.print("[AutoBand] Default dump set: " .. AutoBand.saved.default_dump)
end

function AutoBand.cmd_dump_from_template(args)
    if (AutoBand.debugon) then
        if (#args > 1) then
            local template_name = args[1]
            local dump_name = args[2]
            if (AutoBand.saved.templates[template_name] == nil) then
                AB_util.print("[error] Template " .. template_name .. " does not exist")
                return
            end
            AutoBand.saved.dumped_wb = AutoBand.get_fakewb(AutoBand.saved.templates[template_name])
            AutoBand.saved.dumps[dump_name] = AutoBand.saved.dumped_wb
            AutoBand.saved.default_dump = dump_name
        end
    end
end

function AutoBand.auto_kick_toofar()
    if (not AutoBand.saved.autokick_toofar_enabled or not AutoBand.is_wb_leader() or AutoBand.debugon) then
        return
    end
    local wb_obj = AutoBand.get_wb()
    local prefix_raw_wspace = AutoBand.GetFormattedPrefixRaw(true)
    local current_toofar_distance = AutoBand.get_current_toofar_distance() -- Get dynamic distance
    local mp_lookup = BuildMapPointLookup()

    wb_obj:foreach_player(
        function(gid, player)
            local mpd = mp_lookup[player.name]
            if mpd and mpd.distance then
                player.distance = mpd.distance * DISTANCE_FIX_COEFFICIENT
                if player.distance > current_toofar_distance then -- Use dynamic distance
                    if toofar[player.name] then
                        toofar[player.name] = toofar[player.name] + 1
                    else
                        toofar[player.name] = 1
                    end
                    if (toofar[player.name] == 6) then -- Initial warning
                        local found = 0
                        for _, v_warned in ipairs(warned) do
                            if v_warned == player.name then
                                found = 1
                                break
                            end
                        end
                        if found == 0 then
                            AutoBand.enqueue_command("/tell " .. tostring(player.name) ..
                                " " .. prefix_raw_wspace .. "You are too far from leader (current max: " .. current_toofar_distance .. " units), you will be removed in " ..
                                (AutoBand.saved.autokick_period * 60 - 30) ..
                                " sec! Follow the leader PLEASE!")
                            table.insert(warned, player.name)
                        end
                    end
                    if (toofar[player.name] > (AutoBand.saved.autokick_period * 12)) then -- Kick condition
                        AutoBand.enqueue_kick(player.name,
                            "you were too far (>" .. current_toofar_distance .. " units) from warband leader for a long time")
                    end
                else
                    toofar[player.name] = nil -- Player is back in range
                end
            end
        end
    )

    for i_key, v_val in pairs(toofar) do
        local matched_old = false
        for ii_key, vv_val_old in pairs(toofar_old) do
            if i_key == ii_key then
                matched_old = true
                if v_val == vv_val_old then
                    if toofar_not_changed[i_key] then
                        toofar_not_changed[i_key] = toofar_not_changed[i_key] + 1
                    else
                        toofar_not_changed[i_key] = 1
                    end
                    if toofar_not_changed[i_key] > 60 then -- roughly 5 minutes of no change (60 * 5s heartbeat)
                        toofar[i_key] = nil
                        toofar_not_changed[i_key] = nil
                    end
                else
                    toofar_not_changed[i_key] = nil -- Value changed, reset counter
                end
                break
            end
        end
        if not matched_old then -- New entry in toofar, clear any stale not_changed
             toofar_not_changed[i_key] = nil
        end
    end

    toofar_old = {}
    for key, value in pairs(toofar) do
        toofar_old[key] = value
    end
end

function AutoBand.GetLeaderEffectiveRoleCategory(ignore_custom_role_for_this_check)
    ignore_custom_role_for_this_check = ignore_custom_role_for_this_check or false
    local leader_name_lower = nil
    local leader_career_line = nil
    local leader_archtype = 0 -- Default to main spec (path 0)

    if GameData and GameData.Player and GameData.Player.name and GameData.Player.career and GameData.Player.career.line then
        leader_name_lower = tostring(AutoBand.FixString(GameData.Player.name)):lower()
        leader_career_line = GameData.Player.career.line
        if GameData.Player.archtype then -- archtype is 0, 1, or 2
            leader_archtype = GameData.Player.archtype
        end
    else
        AB_util.print("[Warning] GetLeaderEffectiveRoleCategory: Could not get complete player data.")
        return AB_const.MDPS -- Fallback to a generic DPS to be safe, or handle error
    end

    -- 1. Custom Role (Highest priority, unless explicitly ignoring for this check)
    if not ignore_custom_role_for_this_check then
        local custom_role = AutoBand.saved.custom_roles and AutoBand.saved.custom_roles[leader_name_lower]
        if custom_role and (custom_role == AB_const.TANK or custom_role == AB_const.HEALER or custom_role == AB_const.MDPS or custom_role == AB_const.RDPS) then
            return custom_role
        end
    end

    -- 2. Alt Spec (Simplified for local player using GameData.Player.archtype)
    -- This mirrors the logic in AB_wb:getArcheType for when p.archtype > 0
    local effective_career_for_role_calc = leader_career_line
    if AutoBand.saved.alt_speccheck_enabled and leader_archtype > 0 then -- archtype > 0 usually means a non-default/DPS spec for healers
        -- This mapping needs to be identical to the transformations in AB_wb:getArcheType
        if leader_career_line == GameData.CareerLine.ZEALOT then effective_career_for_role_calc = GameData.CareerLine.MAGUS
        elseif leader_career_line == GameData.CareerLine.WARRIOR_PRIEST then effective_career_for_role_calc = GameData.CareerLine.SLAYER
        elseif leader_career_line == GameData.CareerLine.RUNE_PRIEST then effective_career_for_role_calc = GameData.CareerLine.ENGINEER
        elseif leader_career_line == GameData.CareerLine.ARCHMAGE then effective_career_for_role_calc = GameData.CareerLine.ENGINEER -- As per your ab_wb.lua
        elseif leader_career_line == GameData.CareerLine.SHAMAN then effective_career_for_role_calc = GameData.CareerLine.MAGUS    -- As per your ab_wb.lua
        elseif leader_career_line == GameData.CareerLine.DISCIPLE then effective_career_for_role_calc = GameData.CareerLine.CHOPPA   -- As per your ab_wb.lua
        -- For classes that are DPS by default, their alt-spec might still be DPS.
        -- SQUIG_HERDER -> CHOPPA (if archtype > 0 and it represents melee spec)
        -- SHADOW_WARRIOR -> SLAYER (if archtype > 0 and it represents melee spec)
        -- This part needs careful alignment with how your getArcheType interprets archtype for base DPS classes.
        -- For now, this primarily handles healer-to-dps alt specs.
        elseif leader_career_line == GameData.CareerLine.SQUIG_HERDER and leader_archtype > 0 then effective_career_for_role_calc = GameData.CareerLine.CHOPPA
        elseif leader_career_line == GameData.CareerLine.SHADOW_WARRIOR and leader_archtype > 0 then effective_career_for_role_calc = GameData.CareerLine.SLAYER
        end
    end
    local current_role_category = AB_util.career_category(effective_career_for_role_calc)

    -- 3. BW/Sorc as MDPS Toggle (Applied if not overridden by custom role and if currently RDPS)
    if AutoBand.saved.bw_sorc_as_mdps then
        if (leader_career_line == GameData.CareerLine.BRIGHT_WIZARD or leader_career_line == GameData.CareerLine.SORCERER) then
            if current_role_category == AB_const.RDPS then -- Only switch if they are effectively RDPS before this toggle
                current_role_category = AB_const.MDPS
            end
        end
    end

    return current_role_category
end

function AutoBand.cmd_toggle_dps_weighting(args)
    local current_dps_weighting_state = AutoBand.saved.dps_weighting_enabled
    local new_dps_weighting_state

    local state_arg = args and args[1] and args[1]:lower()
    if state_arg == "on" then new_dps_weighting_state = true
    elseif state_arg == "off" then new_dps_weighting_state = false
    else new_dps_weighting_state = not current_dps_weighting_state end

    if new_dps_weighting_state == true and current_dps_weighting_state == false then -- Only check when turning ON
        local leader_effective_role = AutoBand.GetLeaderEffectiveRoleCategory()
        if leader_effective_role then
            if (leader_effective_role == AB_const.MDPS) then
                if AutoBand.saved.max_mdps == 0 then
                    AB_util.print("[Error] Cannot enable DPS weighting. Your effective role (MDPS) has a max limit of 0.")
                    AB_util.print("Use /ab setdps or /ab setroles to adjust mDPS/rDPS limits first.")
                    return
                end
            elseif (leader_effective_role == AB_const.RDPS) then
                 if AutoBand.saved.max_rdps == 0 then
                    AB_util.print("[Error] Cannot enable DPS weighting. Your effective role (RDPS) has a max limit of 0.")
                    AB_util.print("Use /ab setdps or /ab setroles to adjust mDPS/rDPS limits first.")
                    return
                end
            end
        end
    end

    AutoBand.saved.dps_weighting_enabled = new_dps_weighting_state

    local composition_str = AutoBand.saved.max_tanks .. "-" .. AutoBand.saved.max_healers .. "-" .. AutoBand.saved.max_dps
    if AutoBand.saved.dps_weighting_enabled then
        AB_util.print("DPS weighting for " .. composition_str .." enabled. Max MDPS: " .. AutoBand.saved.max_mdps .. ", Max RDPS: " .. AutoBand.saved.max_rdps)
        if not AutoBand.saved.autokick_enabled then
            AB_util.print("[Warning] DPS weighting only enforced when 'Auto enforcing " .. composition_str .." WB' (/ab ak) is also enabled.")
        end
    else
        AB_util.print("DPS weighting for " .. composition_str .." disabled.")
    end

    if AutoBandWindow.showing() and AutoBandWindow.SelectedTab == AB_const.TABS_CONFIG then
        AutoBandWindowConfig.Show()
    end
end

function AutoBand.cmd_set_dps_weights(args, called_from_gui)
    called_from_gui = called_from_gui or false -- Default to false if not provided

    local mdps_count_input = tonumber(args[1])
    local rdps_count_input = tonumber(args[2])

    if not mdps_count_input or not rdps_count_input then
        AB_util.print("[Error] Missing MDPS or RDPS count. Usage: /ab setdps <mdps_count> <rdps_count>")
        return
    end

    local new_max_mdps = math.floor(mdps_count_input)
    local new_max_rdps = math.floor(rdps_count_input)

    if new_max_mdps < 0 or new_max_rdps < 0 then
        AB_util.print("[Error] MDPS and RDPS counts cannot be negative.")
        return
    end

    if new_max_mdps + new_max_rdps ~= AutoBand.saved.max_dps then
        AB_util.print("[Error] Counts must sum to the current max DPS setting (" .. AutoBand.saved.max_dps .. "). Provided: " .. new_max_mdps .. " MDPS + " .. new_max_rdps .. " RDPS = " .. (new_max_mdps + new_max_rdps) .. ".")
        return
    end

    local leader_effective_role = AutoBand.GetLeaderEffectiveRoleCategory()
    if leader_effective_role then
        if (leader_effective_role == AB_const.MDPS) and new_max_mdps == 0 then
            AB_util.print("[Error] Cannot set max mDPS to 0. Your current effective role is mDPS.")
            return
        elseif (leader_effective_role == AB_const.RDPS) and new_max_rdps == 0 then
            AB_util.print("[Error] Cannot set max rDPS to 0. Your current effective role is rDPS.")
            return
        end
    end

    -- If checks pass:
    AutoBand.saved.max_mdps = new_max_mdps
    AutoBand.saved.max_rdps = new_max_rdps

    if not called_from_gui then
        -- Only print success message and related warnings if NOT called from GUI
        AB_util.print("DPS weights set. Max MDPS: " .. AutoBand.saved.max_mdps .. ", Max RDPS: " .. AutoBand.saved.max_rdps)

        if not AutoBand.saved.dps_weighting_enabled then
            AB_util.print("[Warning] DPS weighting is currently disabled (/ab dw on). Changes will apply if/when enabled.")
        end
        if not AutoBand.saved.autokick_enabled then
            AB_util.print("[Warning] DPS weighting only enforced when 'Auto enforcing " .. AutoBand.saved.max_tanks .. "-" .. AutoBand.saved.max_healers .. "-" .. AutoBand.saved.max_dps .." WB' (/ab ak) is also enabled.")
        end
    end

    -- Refresh GUI if it's open and the relevant tab is selected
    if AutoBandWindow.showing() and AutoBandWindow.SelectedTab == AB_const.TABS_CONFIG then
         if AutoBandWindowConfig and AutoBandWindowConfig.refresh_dps_weights then
            AutoBandWindowConfig.refresh_dps_weights()
         end
    end
end

function AutoBand.cmd_toggle_bw_sorc_mdps(args)
    local current_bw_sorc_setting = AutoBand.saved.bw_sorc_as_mdps
    local new_bw_sorc_setting = not current_bw_sorc_setting

    if GameData and GameData.Player and GameData.Player.career and GameData.Player.career.line then
        local leader_career_line = GameData.Player.career.line
        local is_leader_bw_or_sorc = (leader_career_line == GameData.CareerLine.BRIGHT_WIZARD or
                                      leader_career_line == GameData.CareerLine.SORCERER)

        if is_leader_bw_or_sorc and AutoBand.saved.dps_weighting_enabled then
            -- Determine what the leader's effective sub-role WILL BE after this toggle
            local future_leader_effective_role_is_mdps
            if new_bw_sorc_setting then -- If BW/Sorc will be treated as MDPS
                future_leader_effective_role_is_mdps = true
            else -- BW/Sorc will revert to default (RDPS)
                future_leader_effective_role_is_mdps = false
            end

            if future_leader_effective_role_is_mdps and AutoBand.saved.max_mdps == 0 then
                AB_util.print("[Error] Cannot treat you as MDPS because max MDPS is currently 0.")
                AB_util.print("Use /ab setdps or /ab setroles to allow at least one MDPS slot.")
                return
            elseif not future_leader_effective_role_is_mdps and AutoBand.saved.max_rdps == 0 then
                AB_util.print("[Error] Cannot revert to treating you as RDPS because max RDPS is currently 0.")
                AB_util.print("Use /ab setdps or /ab setroles to allow at least one RDPS slot.")
                return
            end
        end
    end

    AutoBand.saved.bw_sorc_as_mdps = new_bw_sorc_setting

    local bw_sorc_label = AB_const.GetBWSorcAsMDPSLabel()
    AB_util.print(bw_sorc_label .. ": " .. tostring(AutoBand.saved.bw_sorc_as_mdps))

    if AutoBandWindow.showing() and AutoBandWindow.SelectedTab == AB_const.TABS_CONFIG then
        AutoBandWindowConfig.Show()
    end
    AutoBand.need_role_update = true
end

function AutoBand.cmd_toggle_restrict_race(args)
    AutoBand.saved.restrict_same_race = not AutoBand.saved.restrict_same_race
    local restrict_race_label = AB_const.GetRestrictRaceLabel()
    AB_util.print(restrict_race_label .. ": " .. tostring(AutoBand.saved.restrict_same_race))
    if AutoBand.saved.restrict_same_race and not AutoBand.raceDetermined then
        AB_util.print("[Warning] Could not determine your race. Restriction might not work correctly.")
    end
     -- Refresh GUI if open
    if AutoBandWindow.showing() and AutoBandWindow.SelectedTab == AB_const.TABS_CONFIG then
       AutoBandWindowConfig.Show() -- Refresh the whole config tab
    end
end

function AutoBand.auto_kick()
  if (not AutoBand.is_wb_leader() or AutoBand.debugon) then
    return
  end

  -- Cache frequently used saved settings locally for this function execution
  local ak_low_enabled = AutoBand.saved.autokick_low_rank_enabled
  local ak_enabled = AutoBand.saved.autokick_enabled
  local ak_wewh_enabled = AutoBand.saved.autokick_we_wh_enabled
  local ak_zone_enabled = AutoBand.saved.autokick_rvrzone_enabled
  local ak_ignore_enabled = AutoBand.saved.autokick_ignorelist_enabled
  local restrict_race_enabled = AutoBand.saved.restrict_same_race
  local guild_prio_enabled = AutoBand.saved.guild_priority_enabled

  -- Early exit if no relevant auto-kick features are enabled
  if not ak_low_enabled and not ak_enabled and not ak_wewh_enabled and not ak_zone_enabled and not restrict_race_enabled and not ak_ignore_enabled then
    -- Clear _old tables if features are off to prevent stale data
    tanks_t_old, healers_t_old, dps_t_old, mdps_t_old, rdps_t_old = {}, {}, {}, {}, {}
    return
  end

  local wb_obj = AutoBand.get_wb()
  if not wb_obj then AB_util.print("AutoKick: Could not get Warband Object."); return end -- Safety check

  local pending_kicks = {} -- Store all players to kick { [name] = reason }

  -- Variables needed for autoforming preset composition logic (initialized only if ak_enabled)
  local tanks_t, healers_t, dps_t, mdps_t, rdps_t
  local tanks, healers, dpss, mdpss, rdpss
  local guild_member
  local guild_member_data, guild_member_names, ignore_list

  -- Initialize role composition specific variables and data
  if ak_enabled or ak_ignore_enabled then
    ignore_list = GetIgnoreList() or {}
  end
  if ak_enabled then
    tanks_t, healers_t, dps_t, mdps_t, rdps_t = {}, {}, {}, {}, {}
    tanks, healers, dpss, mdpss, rdpss = 0, 0, 0, 0, 0
    guild_member = false
    guild_member_data = {}
    guild_member_names = {}
    if guild_prio_enabled then -- Get guild list only if needed
      guild_member_data = GetGuildMemberData() or {}
      for _, value in pairs(guild_member_data) do
        if value and value.name then table.insert(guild_member_names, value.name) end
      end
    end
  end

  -- Single Loop Player Processing
  wb_obj:foreach_player(
    function(gid, player)
      -- Ensure player.name exists before proceeding (safety)
      if not player or not player.name then return end
      local player_name = player.name -- Cache for pending_kicks key
      local leader_race = AutoBand.race  -- Get leader's race
      local race_ok = AutoBand.raceDetermined -- Check if leader's race is known

      -- Race Restriction Check (Run if restrict_race_enabled)
      if restrict_race_enabled and race_ok and not pending_kicks[player_name] then
        local player_race = AB_const.CAREERLINE_RACEMAP[player.careerLine]
        if player_race and player_race ~= leader_race then
          -- Fetch the theme/title for the leader's race for the kick message
          local theme = AB_const.RACE_THEMES[leader_race] or AB_const.RACE_THEMES["Default"]
          pending_kicks[player_name] = "this is a " .. theme.title .. " only warband."
        end
      end

      -- Low Rank Check (Run if autokick_low_rank_enabled)
      -- Check if not already marked for kick
      if ak_low_enabled and not pending_kicks[player_name] then
        local required_rank = (player.role == AB_const.HEALER) and AutoBand.saved.min_rank_healer or AutoBand.saved.min_rank
        if (player.level < required_rank) then
          pending_kicks[player_name] = "you are too low level (Rank " .. player.level .. " < " .. required_rank .. ")."
        end
      end

      -- WE/WH Check (Run if autokick_we_wh_enabled)
      -- Check if not already marked for kick
      if ak_wewh_enabled and not pending_kicks[player_name] then
        if player.careerLine == GameData.CareerLine.WITCH_ELF or player.careerLine == GameData.CareerLine.WITCH_HUNTER then
          pending_kicks[player_name] = "autokick of stealthers is enabled."
        end
      end

      -- Check if in a non-rvr/city zone (Run if autokick_rvrzone_enabled)
      -- Check if not already marked for kick
      if ak_zone_enabled and not pending_kicks[player_name] then
        if player.zoneNum and player.zoneNum ~= 0 then
          -- Check if their zone is NOT in the allowed set
          if not AutoBand.allowed_rvr_zones_set[player.zoneNum] then
            local zoneName = GetZoneName(player.zoneNum) or "Unknown Zone ("..player.zoneNum..")"
            pending_kicks[player_name] = "you are not in a RVR- or City-zone (Your zone: " .. tostring(zoneName) .. ")."
          end
        end
      end

      -- Ignore List Check (independent toggle)
      if ak_ignore_enabled and not pending_kicks[player_name] then
        if ignore_list then
          for _, value in pairs(ignore_list) do
			if value and value.name and player_name and tostring(player_name) == tostring(AutoBand.FixString(value.name)) then
              pending_kicks[player_name] = "you are on my ignore list."
              break
            end
          end
        end
      end

      -- Ignore/Guild-checks (Run if autokick_enabled for forming specific role composition)
      -- Check if not already marked for kick
      if ak_enabled and not pending_kicks[player_name] then

        -- Role counting for role composition limits (only if not kicked for ignore)
        if not pending_kicks[player_name] then
          guild_member = false
          if guild_prio_enabled then
            for _, value in pairs(guild_member_names) do
              -- Compare stripped names to handle realm tags
              local guildMemberNameStripped = value:match("([^^]+)") or value
              local playerNameStripped = player.name:match("([^^]+)") or player.name
              if guildMemberNameStripped and playerNameStripped and guildMemberNameStripped == playerNameStripped then
                guild_member = true
                break
              end
            end
          end

          -- Populate role tables for role composition logic after loop
          if (player.role == AB_const.TANK) then
            tanks_t[player_name] = guild_member; tanks = tanks + 1
          elseif (player.role == AB_const.HEALER) then
            healers_t[player_name] = guild_member; healers = healers + 1
          elseif (player.role == AB_const.MDPS) then
            dps_t[player_name] = guild_member; mdps_t[player_name] = guild_member; dpss = dpss + 1; mdpss = mdpss + 1
          elseif (player.role == AB_const.RDPS) then
            dps_t[player_name] = guild_member; rdps_t[player_name] = guild_member; dpss = dpss + 1; rdpss = rdpss + 1
          end
        end
      end
    end
  )

  -- Perform role composition Kicking Logic based on role limits (if enabled)
  if ak_enabled then
    -- Helper function to find and mark players for kick based on role limits
    local function mark_excess_roles(role_table, old_role_table, max_allowed, role_name_plural, current_count_ref)
      local current_count = current_count_ref[1]
      local players_to_kick_count = 0
      local kicked_count = 0 -- How many we mark in this function call

      if current_count > max_allowed then
        players_to_kick_count = current_count - max_allowed

        -- Create list of candidates: new players in this role not already marked for kick
        local candidates = {}
        for key, is_guildie in pairs(role_table) do
          if not pending_kicks[key] then -- Only consider if not already marked for other reasons
            local found_in_old = false
            for key2, _ in pairs(old_role_table or {}) do
              if key == key2 then found_in_old = true; break end
            end
            if not found_in_old then
              table.insert(candidates, { name = key, is_guildie = is_guildie })
            end
          end
        end

        -- Sort candidates: Non-guildies first, then by name
        table.sort(candidates, function(a, b)
          if a.is_guildie ~= b.is_guildie then
            return not a.is_guildie -- false (non-guildie) comes before true (guildie)
          else
            return a.name < b.name -- Alphabetical tiebreaker
          end
        end)

        -- Pre-calculate if any unmarked non-guildies are available (for priority check)
        local non_guildie_candidate_available = false
        if guild_prio_enabled then
          for _, candidate_check in ipairs(candidates) do
            -- Check candidate table directly, pending_kicks check isn't needed again here
            if not candidate_check.is_guildie then
              non_guildie_candidate_available = true
              break
            end
          end
        end

        -- Iterate through sorted candidates and mark for kick
        for _, candidate in ipairs(candidates) do
          if kicked_count >= players_to_kick_count then break end -- Stop if we've marked enough

          local kick_target = candidate.name
          local should_mark_this_candidate = true -- Assume we kick unless priority logic prevents it

          -- Apply Guild Priority Logic
          if guild_prio_enabled then
            if candidate.is_guildie and non_guildie_candidate_available then
              -- Current candidate is a guildie, AND an unmarked non-guildie exists *somewhere*
              -- in the candidates list. Don't kick this guildie yet.
              should_mark_this_candidate = false
            end
          end

          -- Mark for kick if decided (and check pending_kicks again just in case)
          if should_mark_this_candidate and not pending_kicks[kick_target] then
            local kick_reason = "there are too many " .. role_name_plural .. " in it right now."
            -- Add priority note only if kicking a non-guildie while guildies were candidates
            if guild_prio_enabled and not candidate.is_guildie then
              local guildie_candidate_present = false
              for _, other_cand in ipairs(candidates) do
                if other_cand.is_guildie then guildie_candidate_present = true; break end
              end
              if guildie_candidate_present then
                kick_reason = kick_reason .. " (guild member priority)."
              end
            end

            pending_kicks[kick_target] = kick_reason
            kicked_count = kicked_count + 1
          end
        end
      end

      -- Update the referenced count accurately based on how many were marked
      current_count_ref[1] = current_count - kicked_count

      -- Update the _old table with players *not* marked for kick
      local new_old_table = {}
      for k, v in pairs(role_table or {}) do -- Add 'or {}' for safety
        if not pending_kicks[k] then new_old_table[k] = v end
      end
      return new_old_table -- Return the updated _old table
    end

    -- Use the helper function (pass counts by reference using a table)
    tanks_t_old = mark_excess_roles(tanks_t, tanks_t_old, AutoBand.saved.max_tanks, "tanks", {tanks})
    healers_t_old = mark_excess_roles(healers_t, healers_t_old, AutoBand.saved.max_healers, "healers", {healers})

    if AutoBand.saved.dps_weighting_enabled then
      mdps_t_old = mark_excess_roles(mdps_t, mdps_t_old, AutoBand.saved.max_mdps, "melee dps", {mdpss})
      rdps_t_old = mark_excess_roles(rdps_t, rdps_t_old, AutoBand.saved.max_rdps, "ranged dps", {rdpss})
      dps_t_old = {}
    else
      dps_t_old = mark_excess_roles(dps_t, dps_t_old, AutoBand.saved.max_dps, "dps", {dpss})
      mdps_t_old = {}
      rdps_t_old = {}
    end
  else
    -- Clear _old tables if role composition is off to prevent stale data affecting next enable
    tanks_t_old, healers_t_old, dps_t_old, mdps_t_old, rdps_t_old = {}, {}, {}, {}, {}
  end

  -- Enqueue all pending kicks
  for name, reason in pairs(pending_kicks) do
    AutoBand.enqueue_kick(name, reason)
  end

end

function add_role_to_message(needed, available, singular_name_full, plural_name_full_override, message_parts)
    -- singular_name_full example: "<icon123> mdps (no wh)" or "<icon456> tank"
    -- plural_name_full_override is usually nil from current calls.

    if not (needed > 0 and available > 0) then
        return -- No spots needed or no spots available, don't add to message
    end

    local role_display_name_final

    if needed == 1 then
        role_display_name_final = singular_name_full
    else -- needed > 1, so we need a plural form (or non-plural for dps variants)
        local base_name_for_plural_logic = singular_name_full
        local suffix_text_for_plural = ""

        -- Intelligently find the suffix like " (no wh)" to separate it from the base role name
        -- This looks for the last occurrence of " (" to ensure it's a suffix pattern
        local suffix_start_position = nil
        for i = #singular_name_full - 1, 1, -1 do -- Iterate backwards
            if string.sub(singular_name_full, i, i + 1) == " (" then
                suffix_start_position = i
                break
            end
        end

        if suffix_start_position then
            base_name_for_plural_logic = string.sub(singular_name_full, 1, suffix_start_position - 1) -- e.g., "<icon> mdps" or "<icon> tank"
            suffix_text_for_plural = string.sub(singular_name_full, suffix_start_position)          -- e.g., " (no wh)"
        end

        local plural_form_of_role_name
        if plural_name_full_override then
            plural_form_of_role_name = plural_name_full_override -- Use override if provided
        else
            -- Check the end of the base_name_for_plural_logic (which has icons and role text)
            if string.match(base_name_for_plural_logic, " mdps$") or
               string.match(base_name_for_plural_logic, " rdps$") or
               string.match(base_name_for_plural_logic, " dps$") then
                plural_form_of_role_name = base_name_for_plural_logic .. suffix_text_for_plural -- No 's' added
            else
                plural_form_of_role_name = base_name_for_plural_logic .. "s" .. suffix_text_for_plural -- Add 's' for others
            end
        end
        role_display_name_final = needed .. " " .. plural_form_of_role_name
    end

    table.insert(message_parts, role_display_name_final)
end

function AutoBand.GetRoleIcons(role_key, generic_mode)
    local use_race_specific_icons = false
    if not generic_mode then
        use_race_specific_icons = AutoBand.saved.restrict_same_race and
                                  AutoBand.factionDetermined and
                                  AutoBand.raceDetermined and
                                  AB_const.RACE_CAREER_ROLE_ICONS and
                                  AB_const.RACE_CAREER_ROLE_ICONS[AutoBand.faction] and
                                  AB_const.RACE_CAREER_ROLE_ICONS[AutoBand.faction][AutoBand.race]
    end

    local icons_string = ""

    if use_race_specific_icons then
        local race_icons_table = AB_const.RACE_CAREER_ROLE_ICONS[AutoBand.faction][AutoBand.race]

        -- Start with the base icons from the static table for the requested role_key
        icons_string = race_icons_table[role_key] or ""

        -- Apply BW/Sorc as MDPS logic if the setting is enabled
        if AutoBand.saved.bw_sorc_as_mdps then
            local bw_icon_str = AB_const.ICONS.bw or ""
            local sorc_icon_str = AB_const.ICONS.sorc or ""
            local current_faction = AutoBand.faction
            local current_race = AutoBand.race

            if role_key == AB_const.MDPS then
                -- Add BW/Sorc to the MDPS string if they are not already listed (e.g. by RACE_CAREER_ROLE_ICONS)
                if current_faction == AB_const.ORDER and current_race == AB_const.EMPIRE and bw_icon_str ~= "" then
                    if not string.find(icons_string, bw_icon_str, 1, true) then
                        icons_string = icons_string .. (icons_string ~= "" and "" or "") .. bw_icon_str
                    end
                elseif current_faction == AB_const.DESTRUCTION and current_race == AB_const.DARKELVES and sorc_icon_str ~= "" then
                    if not string.find(icons_string, sorc_icon_str, 1, true) then
                        icons_string = icons_string .. (icons_string ~= "" and "" or "") .. sorc_icon_str
                    end
                end
            elseif role_key == AB_const.RDPS then
                -- No change needed here due to bw_sorc_as_mdps.
                -- BW/Sorc are still the primary RDPS for Empire/DarkElves respectively,
                -- so their icons should come from race_icons_table[AB_const.RDPS] as defined.
                -- If they are also treated as MDPS, they appear in MDPS list too.
            elseif role_key == "dps" then
                -- The static combined "dps" string from RACE_CAREER_ROLE_ICONS already includes BW/Sorc.
                -- If bw_sorc_as_mdps is on, this means BW/Sorc are now *also* potential MDPS.
                -- The existing combined string is generally fine, as it shows all DPS careers.
                -- No specific change here, as the component MDPS/RDPS calls (when weighting is on)
                -- will reflect the dual consideration.
            end
        end

        -- Strip WH/WE if autokick_we_wh is enabled (applied AFTER BW/Sorc logic for MDPS)
        if (not generic_mode) and AutoBand.saved.autokick_we_wh_enabled and (role_key == AB_const.MDPS or role_key == "dps") then
            local temp_icons_string = icons_string
            local stripped_this_pass = false

            if AutoBand.race == AB_const.EMPIRE and AB_const.ICONS.wh and string.find(temp_icons_string, AB_const.ICONS.wh, 1, true) then
                temp_icons_string = string.gsub(temp_icons_string, AB_const.ICONS.wh, "")
                stripped_this_pass = true
            elseif AutoBand.race == AB_const.DARKELVES and AB_const.ICONS.we and string.find(temp_icons_string, AB_const.ICONS.we, 1, true) then
                temp_icons_string = string.gsub(temp_icons_string, AB_const.ICONS.we, "")
                stripped_this_pass = true
            end

            if stripped_this_pass then
                if temp_icons_string == "" and icons_string ~= "" then
                    icons_string = ""
                else
                    icons_string = temp_icons_string
                end
            end
        end

    else -- Generic icons (not race-restricted)
        if role_key == "dps" then
            icons_string = AB_const.ICONS.dps or ""
        elseif role_key == AB_const.MDPS then
             icons_string = AB_const.ICONS.mdps or AB_const.ICONS.dps or ""
        elseif role_key == AB_const.RDPS then
            icons_string = AB_const.ICONS.rdps or ""
        else
            icons_string = AB_const.ICONS[role_key] or ""
        end
    end
    return icons_string
end

function AutoBand.auto_note()
    -- Cache locals and early exit
    ab_auto_note_counter = ab_auto_note_counter + 1
    local saved = AutoBand.saved
    if not (saved.autonote_enabled and AutoBand.is_wb_leader()) or AutoBand.debugon then return end
    if ab_auto_note_counter <= 60 then return end
    ab_auto_note_counter = 0

    local wb = AutoBand.get_wb()
    if not wb then return end

    -- Settings
    local weighting        = saved.dps_weighting_enabled
    local max_mdps         = saved.max_mdps
    local max_rdps         = saved.max_rdps
    local max_dps          = saved.max_dps
    local max_tanks        = saved.max_tanks
    local max_healers      = saved.max_healers

    local tanks, healers, mdpss, rdpss = 0, 0, 0, 0
    wb:foreach_player(function(_,player)
        if     player.role == AB_const.TANK   then tanks   = tanks   + 1
        elseif player.role == AB_const.HEALER then healers = healers + 1
        elseif player.role == AB_const.MDPS   then mdpss   = mdpss   + 1
        elseif player.role == AB_const.RDPS   then rdpss   = rdpss   + 1 end
    end)

    local total_players    = tanks + healers + mdpss + rdpss
    local available_spots  = math.max(0, 24 - total_players)

    local neededTank = math.max(0, max_tanks - tanks)
    local neededHealer = math.max(0, max_healers- healers)
    local neededMdps, neededRdps, neededDps = 0, 0, 0

    local use_dps_weighting_for_message = saved.autokick_enabled and weighting

    if use_dps_weighting_for_message then
        neededMdps = math.max(0, max_mdps - mdpss)
        neededRdps = math.max(0, max_rdps - rdpss)
    else
        neededDps = math.max(0, max_dps - (mdpss + rdpss))
    end

    local parts = {}

    local stealth_suffix = ""
    if saved.autokick_we_wh_enabled then
        -- Only add the textual suffix if the warband is NOT effectively race-restricted.
        if not (saved.restrict_same_race and AutoBand.raceDetermined) then
            local stealth_icon_to_mention = ""
            -- Determine which icon to mention based on the leader's overall faction for a generic message
            if AutoBand.faction == AB_const.ORDER then
                stealth_icon_to_mention = AB_const.ICONS.wh or ""
            elseif AutoBand.faction == AB_const.DESTRUCTION then
                stealth_icon_to_mention = AB_const.ICONS.we or ""
            end

            if stealth_icon_to_mention ~= "" then
                stealth_suffix = " (no " .. stealth_icon_to_mention .. ")"
            end
        end
    end

    local tank_icons_str = AutoBand.GetRoleIcons(AB_const.TANK)
    local healer_icons_str = AutoBand.GetRoleIcons(AB_const.HEALER)

    if tank_icons_str ~= "" then add_role_to_message(neededTank, available_spots, tank_icons_str .. " tank", nil, parts) end
    if healer_icons_str ~= "" then add_role_to_message(neededHealer, available_spots, healer_icons_str .. " healer", nil, parts) end

    if use_dps_weighting_for_message then
        local mdps_icons_str = AutoBand.GetRoleIcons(AB_const.MDPS)
        local rdps_icons_str = AutoBand.GetRoleIcons(AB_const.RDPS)
        if mdps_icons_str ~= "" then add_role_to_message(neededMdps, available_spots, mdps_icons_str .. " mdps" .. stealth_suffix, nil, parts) end
        if rdps_icons_str ~= "" then add_role_to_message(neededRdps, available_spots, rdps_icons_str .. " rdps", nil, parts) end -- Typically no stealth suffix for RDPS unless specific design.
    else
        local dps_icons_str = AutoBand.GetRoleIcons("dps")
        if dps_icons_str ~= "" then add_role_to_message(neededDps, available_spots, dps_icons_str .. " dps" .. stealth_suffix, nil, parts) end
    end

    local final_parts = {}
    for _, part_text in ipairs(parts) do
        if not string.match(part_text, "^%s*+(tank|healer|mdps|rdps|dps)%s*$") or string.find(part_text, "<icon") then
            table.insert(final_parts, part_text)
        end
    end
    parts = final_parts

    if #parts > 0 and available_spots > 0 then
        local prefixicon = AB_const.ICONS.prefix or ""
        local suffixicon = AB_const.ICONS.suffix or ""
        local purpose_string = ""
        if AutoBand.current_purpose then
            purpose_string = (AB_const.WARBAND_PURPOSES[AutoBand.current_purpose].display or AutoBand.current_purpose) .. " "
        end
        local race_prefix = ""
        if saved.restrict_same_race and AutoBand.raceDetermined then
            race_prefix = (AB_const.RACE_THEMES[AutoBand.race] or AB_const.RACE_THEMES["Default"]).prefix
        end

        local sep = (#parts > 1 and available_spots == 1) and " or " or " / "
        if sep == " / " then
            local need_num = false
            for _,p_text in ipairs(parts) do if p_text:match("^%d+ ") then need_num = true; break end end
            if need_num then
                for i,p_text in ipairs(parts) do
                    if not p_text:match("^%d+ ") then
                        if neededTank   == 1 and p_text:find(" tank", 1, true) then parts[i] = "1 " .. p_text
                        elseif neededHealer == 1 and p_text:find(" healer", 1, true) then parts[i] = "1 " .. p_text
                        elseif use_dps_weighting_for_message then -- Check if we are in weighted mode
                            if neededMdps == 1 and p_text:find(" mdps", 1, true) then parts[i] = "1 " .. p_text
                            elseif neededRdps == 1 and p_text:find(" rdps", 1, true) then parts[i] = "1 " .. p_text end
                        elseif neededDps == 1 and p_text:find(" dps", 1, true) then parts[i] = "1 " .. p_text end
                    end
                end
            end
        end

        local needs_prefix_text = ""
        if AutoBand.saved.autokick_enabled then
            needs_prefix_text = AutoBand.saved.max_tanks .. "-" .. AutoBand.saved.max_healers .. "-" .. AutoBand.saved.max_dps .. " Warband needs - "
        else
            needs_prefix_text = "Warband needs - "
        end
        local payload = race_prefix .. purpose_string .. needs_prefix_text .. table.concat(parts, sep)
        local total_needed = neededTank + neededHealer
        if use_dps_weighting_for_message then
            total_needed = total_needed + neededMdps + neededRdps
        else
            total_needed = total_needed + neededDps
        end

        if total_needed > available_spots and not saved.autokick_enabled then
            payload = payload .. " - (" .. available_spots .. " spot" .. (available_spots == 1 and "" or "s") .. " available) - "
        else
            payload = payload .. " - "
        end

        if saved.autokick_enabled or saved.autokick_low_rank_enabled then
            if saved.min_rank_healer ~= saved.min_rank then
                payload = payload .. "Min rank healers: " .. saved.min_rank_healer .. "+, others: " .. saved.min_rank .. "+"
            else
                payload = payload .. "Min rank: " .. saved.min_rank .. "+"
            end
            if AutoBand.is_open_party and AutoBand.is_wb_leader() and not AutoBand.is_open_party() then
                local self_name_raw = GameData.Player.name
                local self_name_str = "Leader"
                if self_name_raw then self_name_str = tostring(AutoBand.FixString(self_name_raw)) end
                local lead_color_name_self = AutoBand.saved.lead_color_name or AB_const.DEFAULT_LEAD_COLOR_NAME
                local rgb_self = AVAILABLE_COLORS[lead_color_name_self] or AVAILABLE_COLORS[AB_const.DEFAULT_LEAD_COLOR_NAME]
                local r_self, g_self, b_self = rgb_self[1], rgb_self[2], rgb_self[3]
                local display_self = "@"..self_name_str
                local colored_link_self = string.format(
                    "<LINK data=\"PLAYER:%s\" color=\"%d,%d,%d\" text=\"%s\">",
                    self_name_str, r_self, g_self, b_self, display_self)
                payload = payload .. " - Please msg " .. colored_link_self
            end
        else
            if string.sub(payload, -3) == " - " then
                payload = string.sub(payload, 1, -4)
            end
            local self_name_raw = GameData.Player.name
            local self_name_str = "Leader"
            if self_name_raw then self_name_str = tostring(AutoBand.FixString(self_name_raw)) end
            local lead_color_name_self = AutoBand.saved.lead_color_name or AB_const.DEFAULT_LEAD_COLOR_NAME
            local rgb_self = AVAILABLE_COLORS[lead_color_name_self] or AVAILABLE_COLORS[AB_const.DEFAULT_LEAD_COLOR_NAME]
            local r_self, g_self, b_self = rgb_self[1], rgb_self[2], rgb_self[3]
            local display_self = "@"..self_name_str
            local colored_link_self = string.format(
                "<LINK data=\"PLAYER:%s\" color=\"%d,%d,%d\" text=\"%s\">",
                self_name_str, r_self, g_self, b_self, display_self)
            local join_text = "msg/join"
            if AutoBand.is_open_party and AutoBand.is_wb_leader() and not AutoBand.is_open_party() then
                join_text = "msg"
            end
            if payload ~= "" then payload = payload .. " - Please " .. join_text .. " " .. colored_link_self
            else payload = "Please " .. join_text .. " " .. colored_link_self end
        end
        AutoBand.allow_guild_prefix_override = true
        AutoBand.enqueue_command("/1 " .. prefixicon .. AutoBand.GetFormattedPrefixRaw(true) .. payload .. suffixicon)
    end
end

function AutoBand.cmd_search_roles(args)
    local saved = AutoBand.saved
    local wb_obj = AutoBand.get_wb()
    if not wb_obj or wb_obj.player_count == 0 then
        AB_util.print("[Error] Not currently in an active warband.")
        return
    end

    local is_current_player_leader = AutoBand.is_wb_leader()
    local generic_mode = not is_current_player_leader

    if is_current_player_leader then
        AutoBand.auto_kick() -- This might update roles, good to have before calculating needs.
    end

    local actual_leader_name_str = nil
    local leader_name_found = false
    local leader_is_player_self = AutoBand.is_wb_leader()
    local success_pu, leaderInfo = pcall(PartyUtils.GetWarbandLeader)
    if success_pu and leaderInfo and leaderInfo.name then
        local leader_name_raw = leaderInfo.name
        actual_leader_name_str = tostring(AutoBand.FixString(leader_name_raw))
        leader_name_found = true
    end
    if not leader_name_found then
        wb_obj:foreach_player(function(gid, player)
                if player.isGroupLeader then
                    actual_leader_name_str = tostring(AutoBand.FixString(player.name))
                    leader_name_found = true; return
                end
        end)
    end
    if not leader_name_found or not actual_leader_name_str or actual_leader_name_str == "" then
        AB_util.print("[Error] Could not determine the warband leader's name.")
        return
    end

    -- *** Calculate Current Roles ***
    local tanks, healers, dpss, mdpss, rdpss = 0, 0, 0, 0, 0
    local total_players = 0
    wb_obj:foreach_player(function(gid, player)
        total_players = total_players + 1
        if     player.role == AB_const.TANK   then tanks  = tanks  + 1
        elseif player.role == AB_const.HEALER then healers = healers + 1
        elseif player.role == AB_const.MDPS   then dpss   = dpss   + 1; mdpss = mdpss + 1
        elseif player.role == AB_const.RDPS   then dpss   = dpss   + 1; rdpss = rdpss + 1
        end
    end)

    -- *** Get Player Zone Info ***
    local players_by_zid       = AutoBand.get_players_zone(wb_obj)
    local leader_zone_name_str = "Unknown Zone/Offline"
    if players_by_zid and players_by_zid["valid_as"] then
        local found_zone = false
        for zid, group_zone in pairs(players_by_zid["valid_as"]) do
            if found_zone then break end
            for _, pl_zone in ipairs(group_zone) do
                if pl_zone.isGroupLeader then
                    if zid and zid ~= 0 then
                        local ok_zn, zn = pcall(GetZoneName, zid)
                        if ok_zn and zn and zn ~= L"" then leader_zone_name_str = tostring(zn)
                        else leader_zone_name_str = "Unknown Zone ("..tostring(zid)..")" end
                    else leader_zone_name_str = "Offline" end
                    found_zone = true; break
                end
            end
        end
        if not found_zone then AB_util.print("[Warning] Could not determine leader's zone precisely.") end
    else AB_util.print("[Warning] Could not get zone data structure.") end

    -- *** Calculate Needs ***
    local neededTank = math.max(0, AutoBand.saved.max_tanks - tanks)
    local neededHealer = math.max(0, AutoBand.saved.max_healers - healers)
    local neededMdps, neededRdps, neededDps = 0, 0, 0
    local available_spots = math.max(0, 24 - total_players)
    local total_needed_spots

    local use_dps_weighting_for_message = AutoBand.saved.autokick_enabled and AutoBand.saved.dps_weighting_enabled
    if generic_mode then
        use_dps_weighting_for_message = false
    end

    if use_dps_weighting_for_message then
        neededMdps = math.max(0, AutoBand.saved.max_mdps - mdpss)
        neededRdps = math.max(0, AutoBand.saved.max_rdps - rdpss)
        total_needed_spots = neededTank + neededHealer + neededMdps + neededRdps
    else
        neededDps = math.max(0, AutoBand.saved.max_dps - dpss)
        total_needed_spots = neededTank + neededHealer + neededDps
    end

    -- *** Build Role Message Parts ***
    local message_parts = {}

    local stealth_suffix = ""
    if (not generic_mode) and saved.autokick_we_wh_enabled then
        -- Only add the textual suffix if the warband is NOT effectively race-restricted.
        if not (saved.restrict_same_race and AutoBand.raceDetermined) then
            local stealth_icon_to_mention = ""
            -- Determine which icon to mention based on the leader's overall faction for a generic message
            if AutoBand.faction == AB_const.ORDER then
                stealth_icon_to_mention = AB_const.ICONS.wh or ""
            elseif AutoBand.faction == AB_const.DESTRUCTION then
                stealth_icon_to_mention = AB_const.ICONS.we or ""
            end

            if stealth_icon_to_mention ~= "" then
                stealth_suffix = " (no " .. stealth_icon_to_mention .. ")"
            end
        end
    end

    local tank_icons_str = AutoBand.GetRoleIcons(AB_const.TANK, generic_mode)
    local healer_icons_str = AutoBand.GetRoleIcons(AB_const.HEALER, generic_mode)

    if tank_icons_str ~= "" then add_role_to_message(neededTank, available_spots, tank_icons_str .. " tank", nil, message_parts) end
    if healer_icons_str ~= "" then add_role_to_message(neededHealer, available_spots, healer_icons_str .. " healer", nil, message_parts) end

    if use_dps_weighting_for_message then
        local mdps_icons_str = AutoBand.GetRoleIcons(AB_const.MDPS, generic_mode)
        local rdps_icons_str = AutoBand.GetRoleIcons(AB_const.RDPS, generic_mode)
        if mdps_icons_str ~= "" then add_role_to_message(neededMdps, available_spots, mdps_icons_str .. " mdps" .. stealth_suffix, nil, message_parts) end
        if rdps_icons_str ~= "" then add_role_to_message(neededRdps, available_spots, rdps_icons_str .. " rdps", nil, message_parts) end
    else
        local dps_icons_str = AutoBand.GetRoleIcons("dps", generic_mode)
        if dps_icons_str ~= "" then add_role_to_message(neededDps, available_spots, dps_icons_str .. " dps" .. stealth_suffix, nil, message_parts) end
    end

    local final_parts = {}
    for _, part_text in ipairs(message_parts) do
        if not string.match(part_text, "^%s*+(tank|healer|mdps|rdps|dps)%s*$") or string.find(part_text, "<icon") then
            table.insert(final_parts, part_text)
        end
    end
    message_parts = final_parts

    if #message_parts > 0 and available_spots > 0 then
        -- *** Determine Channels ***
        local channels_to_send = {}
        local feedback = {}
        local valid_channels = {["1"]=true, ["t4"]=true, ["5"]=true} -- Renamed 'valid' to avoid conflict
        for _, arg_val in ipairs(args) do
            local c = arg_val:lower():gsub("/", "")
            if valid_channels[c] then channels_to_send["/"..c] = true end
        end
        if next(channels_to_send) == nil then
            AB_util.print("Usage: /ab searchroles <1|t4|5>")
            AB_util.print("Please specify at least one channel (/1, /t4, /5).")
            return
        end

        -- *** Build The Opening & Closing ***
        local message_start, join_suffix, rank_info_str, add_prefix_str = "", "", "", "" -- Renamed some vars to avoid conflict
        local prefixicon = AB_const.ICONS["prefix"] or ""
        local suffixicon = AB_const.ICONS["suffix"] or ""
        local purpose_string = ""
        local race_prefix_for_msg = "" -- Renamed to avoid conflict with AutoBand.race_prefix if it were global
        local leader_race_for_theme = AutoBand.race -- Use the leader's determined race for theme

        if is_current_player_leader then
            if AutoBand.current_purpose and AB_const.WARBAND_PURPOSES[AutoBand.current_purpose] then
                purpose_string = (AB_const.WARBAND_PURPOSES[AutoBand.current_purpose].display or AutoBand.current_purpose) .. " "
            end
            if saved.restrict_same_race and AutoBand.raceDetermined then -- Use leader's race for theme
                local theme = AB_const.RACE_THEMES[leader_race_for_theme] or AB_const.RACE_THEMES["Default"]
                race_prefix_for_msg = theme.prefix
            end

            if AutoBand.saved.autokick_enabled then
                message_start = race_prefix_for_msg .. purpose_string .. AutoBand.saved.max_tanks .. "-" .. AutoBand.saved.max_healers .. "-" .. AutoBand.saved.max_dps .. " Warband needs - "
            else
                message_start = race_prefix_for_msg .. purpose_string .. "Warband needs - "
            end
            AutoBand.allow_guild_prefix_override = true
            add_prefix_str = prefixicon .. AutoBand.GetFormattedPrefixRaw(true)

            if AutoBand.saved.autokick_enabled or AutoBand.saved.autokick_low_rank_enabled then
                if AutoBand.saved.min_rank_healer ~= AutoBand.saved.min_rank then
                    rank_info_str = " - Min rank healers: "..AutoBand.saved.min_rank_healer.."+, others: "..AutoBand.saved.min_rank.."+"
                else
                    rank_info_str = " - Min rank: "..AutoBand.saved.min_rank.."+"
                end
                if AutoBand.is_open_party and is_current_player_leader and not AutoBand.is_open_party() then
                    local self_name_raw = GameData.Player.name
                    local self_name_str_val = "Leader"
                    if self_name_raw then self_name_str_val = tostring(AutoBand.FixString(self_name_raw)) end
                    local lead_color_name_self = AutoBand.saved.lead_color_name or AB_const.DEFAULT_LEAD_COLOR_NAME
                    local rgb_self = AVAILABLE_COLORS[lead_color_name_self] or AVAILABLE_COLORS[AB_const.DEFAULT_LEAD_COLOR_NAME]
                    local r_self, g_self, b_self = rgb_self[1], rgb_self[2], rgb_self[3]
                    local display_self = "@"..self_name_str_val
                    local colored_link_self = string.format(
                        "<LINK data=\"PLAYER:%s\" color=\"%d,%d,%d\" text=\"%s\">",
                        self_name_str_val, r_self, g_self, b_self, display_self)
                    join_suffix = " - Please msg " .. colored_link_self
                else
                    join_suffix = ""
                end
            else
                rank_info_str = ""
                local self_name_raw = GameData.Player.name
                local self_name_str_val = "Leader" -- Renamed variable
                if self_name_raw then self_name_str_val = tostring(AutoBand.FixString(self_name_raw)) end
                local lead_color_name_self = AutoBand.saved.lead_color_name or AB_const.DEFAULT_LEAD_COLOR_NAME
                local rgb_self = AVAILABLE_COLORS[lead_color_name_self] or AVAILABLE_COLORS[AB_const.DEFAULT_LEAD_COLOR_NAME]
                local r_self, g_self, b_self = rgb_self[1], rgb_self[2], rgb_self[3]
                local display_self = "@"..self_name_str_val
                local colored_link_self = string.format(
                    "<LINK data=\"PLAYER:%s\" color=\"%d,%d,%d\" text=\"%s\">",
                    self_name_str_val, r_self, g_self, b_self, display_self)
                local join_text = "msg/join"
                if AutoBand.is_open_party and AutoBand.is_wb_leader() and not AutoBand.is_open_party() then
                    join_text = "msg"
                end
                join_suffix = " - Please " .. join_text .. " " .. colored_link_self
            end
        else
            local lead_color_name = AutoBand.saved.lead_color_name or AB_const.DEFAULT_LEAD_COLOR_NAME
            local rgb = AVAILABLE_COLORS[lead_color_name] or AVAILABLE_COLORS[AB_const.DEFAULT_LEAD_COLOR_NAME]
            local r,g,b = rgb[1], rgb[2], rgb[3]
            local display_leader = "@"..actual_leader_name_str
            local colored_link_leader = string.format(
                "<LINK data=\"PLAYER:%s\" color=\"%d,%d,%d\" text=\"%s\">",
                actual_leader_name_str, r, g, b, display_leader)
            message_start = prefixicon .. colored_link_leader .. " Warband needs - "
            join_suffix   = " - Please msg/join " .. colored_link_leader
            rank_info_str = ""
            add_prefix_str = ""
        end

        local sep = (#message_parts > 1 and available_spots == 1) and " or " or " / "
        if sep == " / " then
            local needNumeric = false
            for _, p_text in ipairs(message_parts) do if p_text:match("^%d+ ") then needNumeric = true; break end end
            if needNumeric then
                for i, p_text in ipairs(message_parts) do
                    if not p_text:match("^%d+ ") then
                        if neededTank == 1 and p_text:find(" tank", 1, true) then message_parts[i] = "1 " .. p_text
                        elseif neededHealer == 1 and p_text:find(" healer", 1, true) then message_parts[i] = "1 " .. p_text
                        elseif use_dps_weighting_for_message then
                            if neededMdps == 1 and p_text:find(" mdps", 1, true) then message_parts[i] = "1 " .. p_text
                            elseif neededRdps == 1 and p_text:find(" rdps", 1, true) then message_parts[i] = "1 " .. p_text end
                        elseif neededDps == 1 and p_text:find(" dps", 1, true) then message_parts[i] = "1 " .. p_text end
                    end
                end
            end
        end

        local base = message_start .. table.concat(message_parts, sep)
        if total_needed_spots > available_spots and not saved.autokick_enabled then
            base = base .. " - ("..available_spots.." spot"..(available_spots == 1 and "" or "s").." available)"
        end

        local payload_t4 = base .. " - in - " .. leader_zone_name_str .. rank_info_str .. join_suffix
        local payload_1  = base .. rank_info_str .. join_suffix

        for chan_key,_ in pairs(channels_to_send) do
            local target_channel_cmd = chan_key
            local payload_to_send = (chan_key == "/t4" or chan_key == "/5") and payload_t4 or payload_1
            AutoBand.enqueue_command(target_channel_cmd .. " " .. add_prefix_str .. payload_to_send .. suffixicon)
            table.insert(feedback, chan_key)
        end

        table.sort(feedback)
        AB_util.print("Search sent in " .. table.concat(feedback, ", ") .. ".")
    else
        AB_util.print("Warband is full or no roles needed.")
    end
end

-- return a list of players who do not meet rank requirements
function AutoBand.get_low_rank(wb_obj)
    if (not wb_obj) then
        wb_obj = AutoBand.get_wb()
    end
    local list = {}
    wb_obj:foreach_player(
        function(gid, player)
            local needed = (player.role == "healer") and AutoBand.saved.min_rank_healer or AutoBand.saved.min_rank
            if (player.level < needed) then
                table.insert(list, player)
            end
        end
    )
    return list
end

function AutoBand.wb(args)
    wb_obj = AutoBand.get_wb()
    local tanks, healers, dpss, mdps, rdps, w_wh = 0, 0, 0, 0, 0, 0
    local guild_member_count = 0
    local guild_members_in_wb = {}
    local guild_member_names = {}

    local guild_member_data = GetGuildMemberData()
    for key, value in pairs(guild_member_data) do
        table.insert(guild_member_names, value.name)
    end

    wb_obj:foreach_player(
        function(gid, player)
            if (player.role == "tank") then
                tanks = tanks + 1
            elseif (player.role == "healer") then
                healers = healers + 1
            elseif (player.role == "mdps") then
                mdps = mdps + 1
                dpss = dpss + 1
            elseif (player.role == "rdps") then
                rdps = rdps + 1
                dpss = dpss + 1
            end

            if (player.careerLine == GameData.CareerLine.WITCH_ELF or player.careerLine == GameData.CareerLine.WITCH_HUNTER) then
                w_wh = w_wh + 1
            end

            for key, value in pairs(guild_member_names) do
                if value:match(L"([^^]+)^?([^^]*)") == player.name then
                    guild_member_count = guild_member_count + 1
                    table.insert(guild_members_in_wb, player.name)
                    break
                end
            end
        end
    )

    AB_util.print("Tanks in WB: " .. tanks)
    AB_util.print("Healers in WB: " .. healers)
    -- AB_util.print("MDPS in WB: " .. mdps)
    -- AB_util.print("RDPS in WB: " .. rdps)
    AB_util.print("DPSs in WB: " .. dpss .. " - " .. mdps .." MDPS, " .. rdps .. " RDPS.")
    -- AB_util.print("Stealthers in WB: " .. w_wh)
    AB_util.print("Guild members (including you) in WB: " .. guild_member_count)
    for key, value in pairs(guild_members_in_wb) do
        AB_util.print(tostring(value))
    end
end

function AutoBand.get_players_zone(wb_obj)
    local zids = { ["valid_as"] = {}, ["valid_p"] = {} }
    local leader_zone = nil

    wb_obj:foreach_player(
        function(gid, player)
            if (player.isGroupLeader or player.isAssistant) then
                if (zids["valid_as"][player.zoneNum] == nil) then
                    zids["valid_as"][player.zoneNum] = {}
                end
                if (player.isGroupLeader) then
                    leader_zone = player.zoneNum
                    table.insert(zids["valid_as"][player.zoneNum], 1, player)
                else
                    table.insert(zids["valid_as"][player.zoneNum], player)
                end
            end
        end
    )

    if (leader_zone) then
        zids["other"] = {}
        wb_obj:foreach_player(
            function(gid, player)
                if (zids["valid_as"][player.zoneNum]) then
                    if (zids["valid_p"][player.zoneNum] == nil) then
                        zids["valid_p"][player.zoneNum] = {}
                    end
                    table.insert(zids["valid_p"][player.zoneNum], player)
                else
                    if (zids["other"][player.zoneNum] == nil) then
                        zids["other"][player.zoneNum] = {}
                    end
                    table.insert(zids["other"][player.zoneNum], player)
                end
            end
        )
    else
        AB_util.print("[ERROR] Leader cannot be found, the warband is BUGGED, reform a warband")
    end
    return zids
end

function AutoBand.get_fakewb(template)
    local wb = AB_wb:new()
    wb:set_groups()
    local num_players = 1
    for gid, tgroup in ipairs(template) do
        for j, tplayer in ipairs(tgroup) do
            wb:add_to_gid(tplayer.role, num_players, gid)
            num_players = num_players + 1
        end
    end
    wb:recalc_counters()
    wb:print()
    return wb
end

function AutoBand.FixString(str)
    if (str == nil) then
        return nil
    end
    local pos = str:find(L"^", 1, true)
    if (pos) then
        str = str:sub(1, pos - 1)
    end
    return str
end

function AutoBand.cmd_end(args)
    local wb_obj = AutoBand.get_wb()
    wb_obj:foreach_player(
        function(gid, player)
            AutoBand.enqueue_kick(player.name, "it ended, see you next time!")
        end
    )
end

function AutoBand.cmd_dump_player_data(args)
    AB_util.print("--- Dumping GameData.Player ---")
    -- Basic safety checks
    if not GameData or type(GameData) ~= "table" then
        AB_util.print("[Error] GameData object is not available or not a table.")
        AB_util.print("--- End GameData.Player Dump ---")
        return
    end
     if not GameData.Player or type(GameData.Player) ~= "table" then
         AB_util.print("[Error] GameData.Player is not available or not a table.")
         AB_util.print("Available keys directly under GameData:")
         -- Attempt to print top-level keys of GameData if Player is missing
         local game_data_keys = {}
         for k, _ in pairs(GameData) do
             table.insert(game_data_keys, tostring(k))
         end
         table.sort(game_data_keys)
         if #game_data_keys > 0 then
              AB_util.print("  " .. table.concat(game_data_keys, ", "))
         else
              AB_util.print("  (Could not list keys)")
         end
         AB_util.print("--- End GameData.Player Dump ---")
         return
     end

    -- Call the recursive dump function, wrapped in pcall for overall safety
    local success, err = pcall(AB_util.dump_recursive, GameData.Player, "  ") -- Start with indentation
     if not success then
         AB_util.print("[Error] An error occurred during the dump process: " .. tostring(err))
     end

    AB_util.print("--- End GameData.Player Dump ---")
end

function AutoBand.cmd_dump_guild_data(args)
    AB_util.print("--- Dumping GameData.Guild ---")
    -- Basic safety checks
    if not GameData or type(GameData) ~= "table" then
        AB_util.print("[Error] GameData object is not available or not a table.")
        AB_util.print("--- End GameData.Guild Dump ---")
        return
    end
     if not GameData.Guild or type(GameData.Guild) ~= "table" then
         AB_util.print("[Error] GameData.Guild is not available or not a table.")
         AB_util.print("Available keys directly under GameData:")
         -- Attempt to print top-level keys of GameData if Guild is missing
         local game_data_keys = {}
         for k, _ in pairs(GameData) do
             table.insert(game_data_keys, tostring(k))
         end
         table.sort(game_data_keys)
         if #game_data_keys > 0 then
              AB_util.print("  " .. table.concat(game_data_keys, ", "))
         else
              AB_util.print("  (Could not list keys)")
         end
         AB_util.print("--- End GameData.Guild Dump ---")
         return
     end

    -- Call the recursive dump function, wrapped in pcall for overall safety
    local success, err = pcall(AB_util.dump_recursive, GameData.Guild, "  ") -- Start with indentation
     if not success then
         AB_util.print("[Error] An error occurred during the dump process: " .. tostring(err))
     end

    AB_util.print("--- End GameData.Guild Dump ---")
end

function AutoBand.cmd_dump_warband_data(args)
    AB_util.print("--- Dumping GetBattlegroupMemberData() (Raw Warband/Battlegroup Data) ---")

    -- Directly call the game API function
    local raw_warband_data = GetBattlegroupMemberData()

    if not raw_warband_data then
        AB_util.print("[Error] GetBattlegroupMemberData() returned nil or no data.")
    elseif type(raw_warband_data) ~= "table" then
        AB_util.print("[Error] GetBattlegroupMemberData() did not return a table. Type: " .. type(raw_warband_data) .. ", Value: " .. tostring(raw_warband_data))
    else
        if next(raw_warband_data) == nil then -- Check if the table is empty
             AB_util.print("(GetBattlegroupMemberData() returned an empty table - likely not in a warband)")
        else
            -- Call the recursive dump function, wrapped in pcall for overall safety
            local success, err = pcall(AB_util.dump_recursive, raw_warband_data, "  ", 0, 7) -- Explicitly pass depth and max_depth
            if not success then
                AB_util.print("[Error] An error occurred during the raw warband data dump process: " .. tostring(err))
            end
        end
    end
    AB_util.print("--- End GetBattlegroupMemberData() Dump ---")
end

function AutoBand.cmd_dump_party_data(args)
  AB_util.print("--- Dumping PartyUtils.GetPartyData() ---")

  -- Directly call the game API function you requested
  local party_data = PartyUtils.GetPartyData()

  if not party_data then
    AB_util.print("[Info] PartyUtils.GetPartyData() returned nil. (Not in a party)")
  elseif type(party_data) ~= "table" then
    AB_util.print("[Error] PartyUtils.GetPartyData() did not return a table. Type: " .. type(party_data) .. ", Value: " .. tostring(party_data))
  else
    if next(party_data) == nil then -- Check if the table is empty
      AB_util.print("(PartyUtils.GetPartyData() returned an empty table)")
    else
      -- Call the addon's existing recursive dump function for nice formatting
      local success, err = pcall(AB_util.dump_recursive, party_data, "  ", 0, 7)
      if not success then
        AB_util.print("[Error] An error occurred during the party data dump process: " .. tostring(err))
      end
    end
  end
  AB_util.print("--- End PartyUtils.GetPartyData() Dump ---")
end

function AutoBand.cmd_dump_ignore_list(args)
    AB_util.print("--- Dumping Ignore List ---")
    
    -- Get the ignore list from the game's API
    local ignore_list = GetIgnoreList()

    -- Check if the API returned anything valid
    if not ignore_list or type(ignore_list) ~= "table" then
        AB_util.print(L"[Error] GetIgnoreList() returned nil or is not a table.")
        AB_util.print(L"--- End Ignore List Dump ---")
        return
    end

    -- Check if the returned list is empty
    if next(ignore_list) == nil then
        AB_util.print(L"(Ignore list is empty)")
    else
        AB_util.print(L"Found " .. towstring(#ignore_list) .. L" entries. Dumping recursively:")
        -- Use the existing recursive dump utility for maximum detail.
        -- This will show the exact structure and content of the list.
        local success, err = pcall(AB_util.dump_recursive, ignore_list, "  ")
        if not success then
            AB_util.print(L"[Error] An error occurred during the dump process: " .. tostring(err))
        end
    end

    AB_util.print(L"--- End Ignore List Dump ---")
end

function AutoBand.cmd_open_party_status(args)
    local is_open = false
    if GameData and GameData.Player and GameData.Player.Group and
       GameData.Player.Group.Settings and
       type(GameData.Player.Group.Settings.isPublic) == "boolean" then
        is_open = GameData.Player.Group.Settings.isPublic
    end
    AB_util.print("Open party: " .. tostring(is_open))
end

function AutoBand.is_open_party()
    if GameData and GameData.Player and GameData.Player.Group and
       GameData.Player.Group.Settings and
       type(GameData.Player.Group.Settings.isPublic) == "boolean" then
        return GameData.Player.Group.Settings.isPublic
    end
    return false
end

function AutoBand.GetCurrentGuildInfo()
    if GameData and GameData.Guild and GameData.Guild.m_GuildID and GameData.Guild.m_GuildID ~= 0 and GameData.Guild.m_GuildName then
        return { id = tostring(GameData.Guild.m_GuildID), name = tostring(GameData.Guild.m_GuildName) }
    end
    return nil -- Not in a guild or data unavailable
end

function AutoBand.GenerateGuildLinkRaw(guild_id_str, guild_name_str)
    local prefix_color_name = AutoBand.saved.prefix_color_name or AB_const.DEFAULT_PREFIX_COLOR_NAME
    local color_rgb = AB_const.AVAILABLE_COLORS[prefix_color_name] or AB_const.AVAILABLE_COLORS[AB_const.DEFAULT_PREFIX_COLOR_NAME]
    if not color_rgb then -- Safety check
        color_rgb = AB_const.COLOR_WHITE -- Fallback white
    end
    local r, g, b = color_rgb[1], color_rgb[2], color_rgb[3]
    local link_color_str = string.format("%d,%d,%d", r, g, b)
    -- Use the guild *name* for the link text, wrapped in brackets
    local link_raw = string.format("[<LINK data=\"GUILD:%s\" text=\"%s\" color=\"%s\">]",
                                    guild_id_str,
                                    guild_name_str, -- Use actual guild name
                                    link_color_str)
    return link_raw
end

function AutoBand.GetFormattedPrefixRaw(includeSpace)
    local use_guild_prefix = false
    if AutoBand.saved.prefix_use_guild and AutoBand.allow_guild_prefix_override then
        local guildInfo = AutoBand.GetCurrentGuildInfo()
        if guildInfo then
            use_guild_prefix = true
        end
    end
    AutoBand.allow_guild_prefix_override = false
    if use_guild_prefix then
        local guildInfo = AutoBand.GetCurrentGuildInfo()
        local link_raw = AutoBand.GenerateGuildLinkRaw(guildInfo.id, guildInfo.name)
        if includeSpace then return link_raw .. " " else return link_raw end
    else
        local prefix_text = AutoBand.saved.prefix_text or AB_const.DEFAULT_PREFIX_TEXT
        local color_name = AutoBand.saved.prefix_color_name or AB_const.DEFAULT_PREFIX_COLOR_NAME
        local color_rgb = AB_const.AVAILABLE_COLORS[color_name] or AB_const.AVAILABLE_COLORS[AB_const.DEFAULT_PREFIX_COLOR_NAME]
        if not color_rgb then color_rgb = AB_const.COLOR_WHITE end -- Safety
        local r, g, b = color_rgb[1], color_rgb[2], color_rgb[3]
        local coloredPart = string.format("<LINK data=\"0\" color=\"%d,%d,%d\" text=\"%s\">", r, g, b, prefix_text)
        local prefix = "[" .. coloredPart .. "]"
        if includeSpace then prefix = prefix .. " " end
        return prefix
    end
end

function AutoBand.GetFormattedPrefixWString(includeSpace)
    local use_guild_prefix = false
    if AutoBand.saved.prefix_use_guild and AutoBand.allow_guild_prefix_override then
        local guildInfo = AutoBand.GetCurrentGuildInfo()
        if guildInfo then
            use_guild_prefix = true
        end
    end
    AutoBand.allow_guild_prefix_override = false
    if use_guild_prefix then
         local guildInfo = AutoBand.GetCurrentGuildInfo()
         local link_raw = AutoBand.GenerateGuildLinkRaw(guildInfo.id, guildInfo.name)
         local link_wstring = towstring(link_raw)
         if includeSpace then return link_wstring .. L" " else return link_wstring end
    else
        local prefix_text = AutoBand.saved.prefix_text or AB_const.DEFAULT_PREFIX_TEXT
        local color_name = AutoBand.saved.prefix_color_name or AB_const.DEFAULT_PREFIX_COLOR_NAME
        local color_rgb = AB_const.AVAILABLE_COLORS[color_name] or AB_const.AVAILABLE_COLORS[AB_const.DEFAULT_PREFIX_COLOR_NAME]
        if not color_rgb then color_rgb = AB_const.COLOR_WHITE end -- Safety
        local r, g, b = color_rgb[1], color_rgb[2], color_rgb[3]
        local coloredPartRaw = string.format("<LINK data=\"0\" color=\"%d,%d,%d\" text=\"%s\">", r, g, b, prefix_text)
        local prefix = L"[" .. towstring(coloredPartRaw) .. L"]"
        if includeSpace then prefix = prefix .. L" " end
        return prefix
    end
end

--------------------------------------------------------------------------
-- Right-Click Menu Integration Functions
--------------------------------------------------------------------------

-- Capture the name of the player that was right-clicked
function AutoBand.ModifiedShowMenu(playerName, playerObjNum, customItems)
    AutoBand.right_clicked_player_name = playerName
    if AutoBand.original_show_menu then
        AutoBand.original_show_menu(playerName, playerObjNum, customItems)
    end
end

-- Add AutoBand custom role entries to the player menu
function AutoBand.ModifiedAddGroupMenuItems(targetSelf)
    -- IMPORTANT: Call the original function first to add all default menu items
    -- (Invite, Kick, Whisper) and items from other addons.
    if AutoBand.original_add_group_menu_items then
        AutoBand.original_add_group_menu_items(targetSelf)
    end

    -- Don't show our menu if the player right-clicked themselves.
    if targetSelf then
        return
    end

    local playerName = AutoBand.right_clicked_player_name
    if not playerName or playerName == L"" then
        return -- Exit if we don't have a valid player name.
    end
    
    local playerNameStr = tostring(playerName)
    local playerNameLower = playerNameStr:lower()
    local currentCustomRole = AutoBand.saved.custom_roles[playerNameLower]

    -- Add a separator to visually distinguish our addon's options.
    EA_Window_ContextMenu.AddMenuDivider(EA_Window_ContextMenu.CONTEXT_MENU_1)
    
    -- Create a disabled item to act as a header for our section.
    EA_Window_ContextMenu.AddMenuItem(L"AutoBand - Set Role", nil, true, true, EA_Window_ContextMenu.CONTEXT_MENU_1)

    -- Define the roles and their corresponding callback functions.
    local roles = {
        { label = "Tank",   value = AB_const.TANK,   callback = AutoBand.OnSetRoleTank },
        { label = "Healer", value = AB_const.HEALER, callback = AutoBand.OnSetRoleHealer },
        { label = "mDPS",   value = AB_const.MDPS,   callback = AutoBand.OnSetRoleMDPS },
        { label = "rDPS",   value = AB_const.RDPS,   callback = AutoBand.OnSetRoleRDPS }
    }

    -- Add each role to the menu, indented to look like a sub-menu.
    for _, roleInfo in ipairs(roles) do
        -- Indent the text with spaces for a sub-menu appearance.
        local label = L"  Set as " .. towstring(roleInfo.label)
        -- Add a checkmark for visual feedback if this is the player's current custom role.
        if currentCustomRole == roleInfo.value then
            label = label .. L" (*)"
        end
        EA_Window_ContextMenu.AddMenuItem(label, roleInfo.callback, false, true, EA_Window_ContextMenu.CONTEXT_MENU_1)
    end

    -- Add the option to remove the custom role, also indented.
    local isRemoveDisabled = (currentCustomRole == nil) -- Disable if no custom role is set.
    EA_Window_ContextMenu.AddMenuItem(L"  Remove Set Role", AutoBand.OnRemoveRole, isRemoveDisabled, true, EA_Window_ContextMenu.CONTEXT_MENU_1)
end

function AutoBand.ModifiedAddGroupMenuItems_old(targetSelf)
    if AutoBand.original_add_group_menu_items then
        AutoBand.original_add_group_menu_items(targetSelf)
    end

    if targetSelf then
        return
    end

    local playerName = AutoBand.right_clicked_player_name
    if not playerName or playerName == L"" then
        return
    end

    local playerNameStr = tostring(playerName)
    local currentCustomRole = AutoBand.saved.custom_roles[playerNameStr:lower()]

    EA_Window_ContextMenu.AddMenuDivider(EA_Window_ContextMenu.CONTEXT_MENU_1)

    local subMenuId = 99
    EA_Window_ContextMenu.AddMenuItemWithSubMenu(L"AutoBand - Set Role", subMenuId, false, EA_Window_ContextMenu.CONTEXT_MENU_1)

    local roles = {
        { label = "Tank",   value = AB_const.TANK,   callback = AutoBand.OnSetRoleTank },
        { label = "Healer", value = AB_const.HEALER, callback = AutoBand.OnSetRoleHealer },
        { label = "mDPS",   value = AB_const.MDPS,   callback = AutoBand.OnSetRoleMDPS },
        { label = "rDPS",   value = AB_const.RDPS,   callback = AutoBand.OnSetRoleRDPS }
    }

    for _, roleInfo in ipairs(roles) do
        local label = L"Set as " .. towstring(roleInfo.label)
        if currentCustomRole == roleInfo.value then
            label = label .. L" (*)"
        end
        EA_Window_ContextMenu.AddMenuItem(label, roleInfo.callback, false, true, subMenuId)
    end

    EA_Window_ContextMenu.AddMenuDivider(subMenuId)
    local removeDisabled = (currentCustomRole == nil)
    EA_Window_ContextMenu.AddMenuItem(L"Remove Custom Role", AutoBand.OnRemoveRole, removeDisabled, true, subMenuId)
end

function AutoBand.HandleSetOrToggleRole(roleToSet)
    local playerName = AutoBand.right_clicked_player_name
    if not (playerName and playerName ~= L"") then
        return -- Exit if we don't have a player name
    end

    local playerNameStr = tostring(playerName)
    local playerNameLower = playerNameStr:lower()
    local currentCustomRole = AutoBand.saved.custom_roles[playerNameLower]
    
    local args

    if currentCustomRole == roleToSet then
        args = {"remove", playerNameStr}
        if AutoBand.debugon then AB_util.print("Toggling OFF role for: " .. playerNameStr) end
    else
        args = {"add", playerNameStr, roleToSet}
        if AutoBand.debugon then AB_util.print("Setting role '" .. roleToSet .. "' for: " .. playerNameStr) end
    end
    
    AutoBand.cmd_custom_role(args)
end

function AutoBand.OnSetRoleTank()
    AutoBand.HandleSetOrToggleRole(AB_const.TANK)
end

function AutoBand.OnSetRoleHealer()
    AutoBand.HandleSetOrToggleRole(AB_const.HEALER)
end

function AutoBand.OnSetRoleMDPS()
    AutoBand.HandleSetOrToggleRole(AB_const.MDPS)
end

function AutoBand.OnSetRoleRDPS()
    AutoBand.HandleSetOrToggleRole(AB_const.RDPS)
end

function AutoBand.OnRemoveRole()
    local playerName = AutoBand.right_clicked_player_name
    if playerName and playerName ~= L"" then
        local args = {"remove", tostring(playerName)}
        AutoBand.cmd_custom_role(args)
    end
end

function AutoBand.Shutdown()
    if AutoBand.original_show_menu then
        PlayerMenuWindow.ShowMenu = AutoBand.original_show_menu
    end
    if AutoBand.original_add_group_menu_items then
        PlayerMenuWindow.AddGroupMenuItems = AutoBand.original_add_group_menu_items
    end
end
