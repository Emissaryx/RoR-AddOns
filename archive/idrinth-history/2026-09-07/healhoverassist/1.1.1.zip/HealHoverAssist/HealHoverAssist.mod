<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
<UiMod name="HealHoverAssist" version="1.0" date="15/02/2022">
	<Author name="Zapz" email="n/a"/>
	<VersionSettings gameVersion="1.0.0" windowsVersion="1.0" savedVariablesVersion="1.0"/>
	<Description text="Creates a macro that targets friendly hurt players"/>

	<Files>
		<File name="HealHoverAssist.lua"/>
	</Files>

	<OnInitialize>
		<CallFunction name="HealHoverAssist.OnInitialize"/>
	</OnInitialize>
    
    <OnUpdate>
		<CallFunction name="HealHoverAssist.OnUpdate"/>
	</OnUpdate>

	<SavedVariables>
		<SavedVariable name=""/>
	</SavedVariables>

</UiMod>
</ModuleFile>