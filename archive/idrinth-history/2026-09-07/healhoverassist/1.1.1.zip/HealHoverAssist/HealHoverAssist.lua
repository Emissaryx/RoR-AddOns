HealHoverAssist = {}

HealHoverAssist.MacroName    = L"HealHoverAssist"
HealHoverAssist.LASTFRIENDLY = {}

HealHoverAssist.UPDATE_PERIOD = 2
HealHoverAssist.decay         = 0

function HealHoverAssist.OnInitialize()
	RegisterEventHandler( SystemData.Events.PLAYER_TARGET_UPDATED,      "HealHoverAssist.on_target_updated")
	RegisterEventHandler( SystemData.Events.ALL_MODULES_INITIALIZED, 	"HealHoverAssist.AllModulesInit")
    RegisterEventHandler( SystemData.Events.LOADING_END,                "HealHoverAssist.AllModulesInit")
    RegisterEventHandler( SystemData.Events.RELOAD_INTERFACE,           "HealHoverAssist.AllModulesInit")
end

function HealHoverAssist.AllModulesInit()
	HealHoverAssist.UpdateMacro(HealHoverAssist.MacroName, "", 23166) 
    HealHoverAssist.SetMacroTarget(HealHoverAssist.FixName(GameData.Player.name))
end

function HealHoverAssist.on_target_updated( targetClassification, targetId, targetType )
	TargetInfo:UpdateFromClient()
	
    local target_info = {
		id = targetId,
		name = HealHoverAssist.FixName(TargetInfo:UnitName (targetClassification)),
		hp = TargetInfo:UnitHealth (targetClassification)
	}

    if targetClassification == "mouseovertarget" and targetType == SystemData.TargetObjectType.ALLY_PLAYER then
        if target_info["hp"] < 100 then
            HealHoverAssist.LASTFRIENDLY = target_info
            HealHoverAssist.SetMacroTarget( HealHoverAssist.LASTFRIENDLY["name"] )
            HealHoverAssist.decay = HealHoverAssist.UPDATE_PERIOD
            return
        end
        
    end
end

function HealHoverAssist.OnUpdate( timePassed )
	if HealHoverAssist.decay > 0 then
		HealHoverAssist.decay = HealHoverAssist.decay - timePassed
        if HealHoverAssist.decay < 0 then
            HealHoverAssist.SetMacroTarget(HealHoverAssist.FixName(GameData.Player.name))
            HealHoverAssist.decay = 0
        end
	end
end

function HealHoverAssist.SetMacroTarget(playerName)
	local macroSlots = HealHoverAssist.GetMacroSlots( HealHoverAssist.GetMacroId(HealHoverAssist.MacroName) )
	if #macroSlots == 0 then return end
	for i = 1, #macroSlots do
		local hbar, buttonid = ActionBars:BarAndButtonIdFromSlot(macroSlots[i])
		local macroButton = hbar.m_Buttons[buttonid]
		
		WindowSetGameActionData(macroButton.m_Name.."Action", GameData.PlayerActions.SET_TARGET, 0, towstring(playerName))
	end
end

function HealHoverAssist.UpdateMacro(macroName, macroText, macroIcon)
	local macros = GetMacrosData()
	local macroSlot = nil

	for i = 1, #macros do
		if macros[i].name == towstring(macroName) then
			macroSlot = i
			break
		elseif macros[i].iconNum == 0 and macroSlot == nil then
			macroSlot = i
		end
	end

	if macroSlot ~= nil then 
		SetMacroData(towstring(macroName), towstring(macroText), macroIcon, macroSlot)
		return true
	else
		return false
	end
end

function HealHoverAssist.GetMacroSlots(macroId)
	local macroSlots = {}
	for i = 1, #ActionBars.m_Bars do
	   for j = 1, #ActionBars.m_Bars[i].m_Buttons do
		  if ActionBars.m_Bars[i].m_Buttons[j].m_ActionType == 4 then
			 if ActionBars.m_Bars[i].m_Buttons[j].m_ActionId == macroId then
				macroSlots[#macroSlots + 1] = ActionBars.m_Bars[i].m_Buttons[j].m_HotBarSlot
			 end
		  end
	   end
	end
	return macroSlots
end

function HealHoverAssist.GetMacroId(macroName)
	local macros = GetMacrosData()
	macroName = towstring(macroName)
	for i = 1, #macros do
		if macros[i].name == macroName then
			return i
		end
	end
	return nil
end

function HealHoverAssist.FixName (str)
	if (str == nil) then return nil end

	local str = str
	local pos = str:find (L"^", 1, true)
	if (pos) then str = str:sub (1, pos - 1) end

	return str
end