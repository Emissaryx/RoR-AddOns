if not TastyButtons then TastyButtons={} end
if not TastySettings then TastySettings={} end
	
function TastySettings.OnShutdown()
	d("Save Save! GoGo Power - Rangers")
end