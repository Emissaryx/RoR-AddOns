<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
	<UiMod name="TastySettings" version="1.0" date="03/03/2009" >

		<Author name="MrOffline" email="i@m.hungry" />
		<Description text="Stores settings for TastyButtons" />
        
		<Files>
			<File name="TastySettings.lua" />
		</Files> 
		
		<SavedVariables>
			<SavedVariable name="TastyButtonsSettings_CharacterSettings" />
		</SavedVariables>
     
		<OnShutdown>
			<CallFunction name="TastySettings.OnShutdown" />
		</OnShutdown>
		
	</UiMod>
</ModuleFile>
