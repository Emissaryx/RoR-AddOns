if not TastyButtons_CharacterSettings then TastyButtons_CharacterSettings = {} end

--if not TastyButtons_Settings then TastyButtons_Settings  = {} end
 
---- Lua Calls ----

local towstring = towstring
local tostring = tostring
local string = string

----------------Global Variables ------------------------------
---------------with explanataion!-----------------------------

-- Enables or disables debugmessages --
local TastyButtonsDebugMode = false
--[[
directionTable[direction] = 	{	anchor
						relanchor }

--]]
local directionTable = {}	
					
-- These are Stance Names.... congratulation for needing to read this to figure this out :P 
--stanceNameTable[abilityId]  = stanceName
local stanceNameTable = {	[0] 	= 	"normal",
							[8394]	=	"Savagery",
							[8398]	= 	"Brutality",
							[8403]	=	"Monstrosity",
							--[8415]	= 	"Gift of Release",
							[9080]	= 	"Scout",
							[9090]	=	"Assault",
							[9094]	=	"Skirmish",
							[8090]	=	"WH_Stealth",
							[9393]	=	"WE_Stealth",
							[1830]	= 	"Squig_Armor"
						}

---- The PetName Table --
local petNameTable = {	[16] 	= 	{L"Flamer", L"Pink Horror", L"Blue Horror", L"Daemonic Infestation"},
						[8]		=	{L"Squig", L"Horned Squig", L"Spiked Squig", L"Gas Squig"},
						[4]		=	{L"Gun Turret", L"Flame Turret", L"Bombardment Turret"},	--, L"Land Mine",L"Keg O' Stout",L"Lightning Rod"
						[19] 	=	{L"War Lion"}
					 }
-- name of the states Currently Available (not all yet implemenented though xD)
local stateNameTable = 	{	default 		= "default", 
							OnCooldown 		= "OnCooldown",
							hideOn			= "hideOn",
							sequence		= "sequence",
							OnResource 		= "OnResource",
							OnNotEnoughAP	= "OnNotEnoughAP"
						}
-- staty Type that are available currently --
local stateTypeTable =	{	RvR 	=	"RvR",
							PvE		=	"PvE"
						}
----- TastyButtons Table seems to be a mystic table ... it's unknown where it came from and what it does !----------

TastyButtons = {
    --m_NeedsCooldownUpdate   = false,
	m_NeedsCooldownUpdate   = true,
    m_NeedsInventoryUpdate  = true,
    m_PreviousResource      = 0,
    m_CurrentResource       = 0,
	m_update_timelapse		= 0,
	do_load=false,
	activate_default=false
}
--[[	Key is the ButtonName
	TastyButtons_Save[	ButtonName]	={slot ,		<== 	Slot in which the Button resides
								scale,			<== 	Scale the button has
								states,		<==	Table for the states of a button
								anchor,		<== 	Table which holds the anchor of the button
								isRegistered}	<==	Boolean: true if Button is registered in the LayoutEditor, otherwise false
--]]
local buttonHandles = {}
--[[ buttonHandles:  holds the "button" objects created in the TastyButtons.ParseArgs_CreateSingleButton function 
	Key is the SlotNumber of the Button
	buttonHandles[buttonSlot] = <button object> 	<== this is just the buttonobject. 
--]]
local anchorTable = {}
--[[	Key is the SlotNumber of the Button
	anchorTable[buttonSlot]={	relWin,		<== The Window the button is anchored too
						xgap,			<== The distance between the button and the button anchored to on the x-axis
						ygap,			<== The distance between the button and the button anchored to on the y-axis
						anchor,		<==  the Point which the anchor on the button is set on (for example top left corner of the button)
						relAnchor		<== the Point which the anchor on the relative button is set on (for example top right corner of the button)
						group	}		<== the group in which the button is currently
--]]
local buttonStateTable	= {}
--[[	This holds the buttonStates of the button (Used for saving, checking and so on
	Key 1 is the ButtonSlot,Key 2 is the Name of the Stance, Key 3 is the name of State
	buttonStateTable[buttonSlot][currentStateType][stanceName][stateName] =  {	actionId, 		<== the actionId of the ability/item/macro wuteva 
														iconNum,		<== the icon Number according to the actionId
														actionType,		<== the Type of the action (captain obvious ftw!)
														showing}
														
	stances normal and clear should ALWAYS be in the table. State normal is the default state of the button.
	Stance clear is a "clean" state of the button. aka actionId, iconNum and actionType = [0,0,0]
--]]
local cleanState ={actionId = 0, iconNum = 0, actionType = 0}
--[[	Not Used if a new state is added to the Button.
	Just to keep the code beautiful xD
--]]
local lastexistingButton = "Root"
--[[ 	Global variable used for grouping buttons. Default is root.
	it is used in TastyButtons.Button_Anchor_Add. if the button that should be anchored on doesnt exist
	it anchors to lastexistingButton. Initiate value is "Root".  While grouping it is set to the lastexistingButton that was anchored on! 
--]]
local	serverName,_ = string.gsub(tostring(SystemData.Server.Name), "-", "_")
		serverName,_ = string.gsub(serverName, " ", "_")
		
local ButtonNameStart = "TastyButtons_"..serverName.."__"..(tostring(GameData.Player.name)).."_Button_"
--[[	Used to concatenate with the Slot Number to get the Button Name  --]]
local currentButtonStateTable = {} 
--[[	Key is the Slotnumber
	currentButtonStateTable[buttonSlot] = {	stance, 	<== name of the stance in which the button is ^^
								state,		<== the Name of the State the button currently has
								stateType		<== the state Type (default is pve)
--]]
local ButtonGroups = {}
--[[ Currentlym No Used
ButtonGroups[GroupNumber] = 	{ 	Buttonnumber 	}		<== ButtonNumbers
--]]
local OnCooldownSkills = {} 
--[[
OnCooldownSkills[Skill] = 
--]]
----- For Changing Textures mhope it works :/ ---
local buttonTextures = {}

local playerClass = tostring(GameData.Player.career.name)
local StanceSwap = true
local currentStance
local currentStateType = "PvE"
local currentPet = GameData.Player.Pet.name
local hiddenButtonTable = {}
local phantomInstalled = false
local inScenario = false

local buttonScale = {}
local varname=(serverName).."__"..(tostring(GameData.Player.name))
---------- captain hoook!!!! -------------

TastyButtons_Original_LayoutEditor_SaveExit = LayoutEditor.SaveExit


function TastyButtons.LayoutEditor_SaveExitPcallme()
	TastyButtons.PrintD("LAYOUTEDITORSAVELOL")
	for n in pairs(buttonHandles) do
		--isAnchored, startButton = TastyButtons.Button_Anchor_Add_CycleDetection(buttonSlot, relbuttonSlot, startButton)
		--buttonHandles[n]:ResizeRelative(startButton)
		if TastyButtons_Save[buttonHandles[n]:GetName()]["isRegistered"] then
			local x ,y = WindowGetScreenPosition(buttonHandles[n]:GetName())
--			TastyButtons.PrintD("---------------------------------------------------------------------")
--			TastyButtons.PrintD("x: "..x.."      y: "..y)
			TastyButtons.Window_Set_Pos(buttonHandles[n]:GetName(),x ,y )
		end
	end
end

function TastyButtons.LayoutEditor_SaveExit()
	TastyButtons.Pcall(TastyButtons.LayoutEditor_SaveExitPcallme)
	TastyButtons_Original_LayoutEditor_SaveExit()
end
if (1==1) then LayoutEditor.SaveExit = TastyButtons.LayoutEditor_SaveExit end



----- LOAD SAVE AND INITIALIZE ------------
function TastyButtons.Load_CharacterSettings()

	
	
	if not TastyButtonsSettings_CharacterSettings then TastyButtonsSettings_CharacterSettings = {} end
	if TastyButtons_CharacterSettings["saved"] == nil then
		TastyButtons_CharacterSettings["saved"] = true
		TastyButtonsSettings_CharacterSettings = DataUtils.CopyTable(TastyButtons_CharacterSettings)
	end 	
	TastyButtons_CharacterSettings = TastyButtonsSettings_CharacterSettings

	
	if TastyButtons_CharacterSettings[varname]==nil then
		TastyButtons_CharacterSettings[varname]={}
	end
	if TastyButtons_CharacterSettings[varname]["buttons"]==nil then
		TastyButtons_CharacterSettings[varname]["buttons"]={}
	end
	if TastyButtons_CharacterSettings[varname]["settings"]==nil then
		TastyButtons_CharacterSettings[varname]["settings"]={}
	end
	TastyButtons_Save = TastyButtons_CharacterSettings[varname]["buttons"]
	TastyButtons_Settings = TastyButtons_CharacterSettings[varname]["settings"]
end

function TastyButtons.Initialize()
    LibSlash.RegisterSlashCmd("TastyButtons", function(input) TastyButtons.ParseArgs_SlashCommand(input) end)
    LibSlash.RegisterSlashCmd("tasty", function(input) TastyButtons.ParseArgs_SlashCommand(input) end)
	TastyButtons.Fill_directionTable()
	TastyButtons.Load_CharacterSettings()
	LibCooldown.RegisterAbilityCallback(TastyButtons.OnCooldown)
	local menuButtonWindow ="TastyButtonsOptionsMenuButton"
	CreateWindow(menuButtonWindow ,true)
	if TastyButtons.Window_IsRegistered( menuButtonWindow ) == false then
		LayoutEditor.RegisterWindow( menuButtonWindow ,L"Meat",L"drop the anchor!",false,false,true,nil)
	end
	CreateWindow("TastyButtonsGeneralOptionsWindow", false)
	TastyButtons.CheckInitialSetting()
end

function TastyButtons.CheckInitialSetting()
	--currently not used --
	if TastyButtons_Settings["lastStance"] == nil then
		currentStance = 0
	  else
		currentStance = TastyButtons_Settings["lastStance"]
	end
	-- till here at least--
	if TastyButtons_Settings["actionBars"] == nil then
		TastyButtons_Settings["actionBars"] = true
	end
	
	if TastyButtons_Settings["HotKeyFont"] == nil then
		TastyButtons_Settings["HotKeyFont"] = "font_chat_text"
	end

	if TastyButtons_Settings["CooldownFont"] == nil then
		TastyButtons_Settings["CooldownFont"] = "font_chat_text"
	end
	
	if TastyButtons_Settings["HotKeyFontColor"] == nil then
		TastyButtons_Settings["HotKeyFontColor"] = {255,255,255}
	end
	
	if TastyButtons_Settings["CooldownFontColor"] == nil then
		TastyButtons_Settings["CooldownFontColor"] = {230,230,0}
	end	
	
	if TastyButtons_Settings["NoTimeIndicator"] == nil then
		TastyButtons_Settings["NoTimeIndicator"] = false
	end

	if TastyButtons_Settings["showEmpty"] == nil then
		TastyButtons_Settings["showEmpty"] = true
	end

	if TastyButtons_Settings["ABCMode"] == nil then
		TastyButtons_Settings["ABCMode"] = false
	end
	
	if TastyButtons_Settings["autoMode"] == nil then
		TastyButtons_Settings["autoMode"] = false
	end

	if TastyButtons_Settings["globalCD"] == nil then
		TastyButtons_Settings["globalCD"] = true
	end

	if TastyButtons_Settings["showTooltips"] == nil then
		TastyButtons_Settings["showTooltips"] = true
	end
	
	if TastyButtons_Settings["tintIconOnly"] == nil then
		TastyButtons_Settings["tintIconOnly"] = false
	end

	if TastyButtons_Settings["showHotkeys"] == nil then
		TastyButtons_Settings["showHotkeys"] = true
	end	
	
	if TastyButtons_Settings["APHandler"] == nil then
		TastyButtons_Settings["APHandler"] = true
	end	
	
	if TastyButtons_Settings["ResourceHandler"] == nil then
		TastyButtons_Settings["ResourceHandler"] = true
	end	
	
	if TastyButtons_Settings["OORTint"] == nil then
		TastyButtons_Settings["OORTint"] = {r = 125, g = 125, b = 125}
	end

	if TastyButtons_Settings["ABCTint"] == nil then
		TastyButtons_Settings["ABCTint"] = {r = 225, g = 0, b = 0}
	end
	
	if TastyButtons_Settings["enabled"] then
		TastyButtons.do_load=true
		ButtonSetText("TastyButtonsGeneralOptionsWindowButtonAddonEnabled", L"Addon Enabled")	
	else
		TastyButtons.activate_default=true
		ButtonSetText("TastyButtonsGeneralOptionsWindowButtonAddonEnabled", L"Addon Disabled")	
		TastyButtons.PrintD("FromCheckInitial")
	end
end

function TastyButtons.OnCareerResourceUpdated(oldValue, newValue)
    TastyButtons.m_CurrentResource = newValue
	local resStateName = "default"
	local maxRessource = CareerResourceData:GetMaximum()
	if (newValue == 250 and oldValue == 0) or (newValue == 0 and oldValue == 250) then  
		return
	end
	--TastyButtons.Print("resStateName: "..resStateName)
	for buttonSlot in pairs(currentButtonStateTable) do
		if ((currentButtonStateTable[buttonSlot]["state"] == stateNameTable["default"]) or (string.find(currentButtonStateTable[buttonSlot]["state"],"OnResource")))
		then	
			local start  = 1
			local step = 1
			local finish = newValue
			if newValue > 5 then
				start = 5
			end
			if maxRessource == 100 then
				step = 5
			end
			if maxRessource == 250 then
				step = -5
				start = 245
				finish = newValue
			end	
			for i = start, newValue, step do
				local tempResStateName = stateNameTable["OnResource"]..i
				if ((buttonStateTable[buttonSlot][currentButtonStateTable[buttonSlot]["stateType"]][currentButtonStateTable[buttonSlot]["stance"]][tempResStateName] ~= nil) 
					and (currentButtonStateTable[buttonSlot]["state"] == stateNameTable["default"])) then
					resStateName  = tempResStateName
				end
			end
			if resStateName ~= currentButtonStateTable[buttonSlot]["state"] then
				TastyButtons.Button_State_Load(buttonSlot, currentButtonStateTable[buttonSlot]["stance"],resStateName,currentButtonStateTable[buttonSlot]["stateType"] )	
			end
		end
	end	
	
end

function TastyButtons.OnEnergyUpdated(currentEnergy)
	for buttonSlot in pairs(currentButtonStateTable) do
		if not((currentEnergy == GameData.Player.actionPoints.maximum) and (currentButtonStateTable[buttonSlot]["state"] == "default")) then
			if (((currentButtonStateTable[buttonSlot]["state"] == stateNameTable["default"]) or (currentButtonStateTable[buttonSlot]["state"] == stateNameTable["OnNotEnoughAP"]))
			and (buttonStateTable[buttonSlot][currentButtonStateTable[buttonSlot]["stateType"]][currentButtonStateTable[buttonSlot]["stance"]][stateNameTable["OnNotEnoughAP"]] ~= nil))
			then
				local abilityId = buttonStateTable[buttonSlot][currentButtonStateTable[buttonSlot]["stateType"]][currentButtonStateTable[buttonSlot]["stance"]]["default"]["actionId"]
				if abilityId ~= nil then
					--TastyButtons.PrintD("CurrentState is: "..currentButtonStateTable[buttonSlot]["state"])
					local abilityCost = GetAbilityActionPointCost(abilityId)
					if abilityCost > currentEnergy then
						TastyButtons.Button_State_Load(buttonSlot, currentButtonStateTable[buttonSlot]["stance"],stateNameTable["OnNotEnoughAP"] )
						TastyButtons.PrintD("me Would swap cause of energy now")
					  elseif (abilityCost <= currentEnergy)then
						if currentButtonStateTable[buttonSlot]["state"] ~= "default" then
							TastyButtons.Button_State_Load(buttonSlot, currentButtonStateTable[buttonSlot]["stance"],stateNameTable["default"] )				  
							TastyButtons.PrintD("me Would UNSWAP cause of energy now")	
						end
					end
				end
			end
		end
	end
end

function TastyButtons.OnTargetUpdated( targetClassification, targetId, targetTypes )
	if TargetClassification == "mouseovertarget" or TargetClassification == "selffriendlytarget" then
		return
	end
	if ((targetClassification == "selfhostiletarget") and ((targetTypes == 2) or (targetTypes == 5))) then
		if currentStateType ~= "RvR" then
			TastyButtons.Button_State_TypeSwap("RvR")
		end
	  elseif  ((targetClassification == "selfhostiletarget") and (targetTypes == 6)) then
		if currentStateType ~= "PvE" then
			TastyButtons.Button_State_TypeSwap("PvE")
		end
	end
end

function TastyButtons.OnPetUpdated()
	if GameData.Player.Pet.name == nil then
		return
	end
	if GameData.Player.Pet.name ~= L"" then
		for line, petName in pairs(petNameTable[GameData.Player.career.line]) do
			if petName == GameData.Player.Pet.name then
				currentPet = petName
			  elseif GameData.Player.career.line == 19 then
				currentPet = petName
			end
		end
		if currentPet ~= GameData.Player.Pet.name then
			return
		end
		for buttonSlot, buttonState in pairs(currentButtonStateTable) do
			if buttonStateTable[buttonSlot][buttonState.stateType][buttonState.stance][tostring(currentPet)] == nil or buttonState.state == tostring(currentPet) then
				continue
			elseif buttonStateTable[buttonSlot][buttonState.stateType][buttonState.stance][tostring(currentPet)] == nil and buttonState.state ~= "default" then
				astyButtons.Button_State_Load(buttonSlot, buttonState.stance, "default", buttonState.stateType)
			elseif buttonState.state ~= tostring(currentPet) then
				TastyButtons.Button_State_Load(buttonSlot, buttonState.stance, tostring(currentPet), buttonState.stateType)
			end
		end
	  elseif GameData.Player.Pet.name == L"" then
	  	for buttonSlot, buttonState in pairs(currentButtonStateTable) do
			if buttonState.state == tostring(currentPet) then
				TastyButtons.Button_State_Load(buttonSlot, buttonState.stance, "default", buttonState.stateType)
			end
		end
	end
			
end

function TastyButtons.UpdateKeyBindings()
	TastyButtons.PrintD("updating keybindings")
	for _,button in pairs(buttonHandles) do
		button:UpdateKeyBindingText()
	end
--button:UpdateKeyBindingText ()
end

function TastyButtons.OnUpdate(timeElapsed)
	--throttling ------------------------------------------------------------------
	TastyButtons.m_update_timelapse=TastyButtons.m_update_timelapse+timeElapsed
	if TastyButtons.m_update_timelapse<0.1 then
		return
	end
	TastyButtons.m_update_timelapse=0
	---------------------------------------------------------------------------------- 

	for k,button in pairs(buttonHandles) do
		button:Update(timeElapsed,true,true,TastyButtons.m_PreviousResource,TastyButtons.m_CurrentResource,0)
	end

	TastyButtons.m_PreviousResource     = TastyButtons.m_CurrentResource

	--delayed loading:
	if TastyButtons.do_load and DoesWindowExist("EA_ActionBar4Action1") then
		TastyButtons.do_load=false
		TastyButtons.Load()
		TastyButtons.Print("TastyButtons is enabled and loaded, you're ready for WAR now")
		TastyButtons.Print("Open the Options window with /tasty opt")
	  elseif TastyButtons.activate_default and DoesWindowExist("EA_ActionBar4Action12") then
		TastyButtons.PrintD("haxxoring defaultbars")
		TastyButtons.activate_default=false
		TastyButtons.PrintD("FromOnUpdate")
		TastyButtons.ActionBars_Activate()
	end
	
end


function TastyButtons.ParseArgs_SlashCommand(args)
	local opt, val = args:match("([a-z0-9]+)%s?(.*)")
	
	if opt == "createbutton" or opt == "cb" 			then TastyButtonsParser.ParseArgs_CreateSingleButton(val) 
--	  elseif opt == "createbuttons" or opt == "cbs" 	then TastyButtonsParser.ParseArgs_CreateButtonGroup(val) 
	  elseif opt == "setposition" or opt == "setpos"	then TastyButtonsParser.ParseArgs_SetPos(val) 
--	  elseif opt == "group" or opt == "grp" 			then TastyButtonsParser.ParseArgs_AnchorGroup(val,true)
--	  elseif opt == "ungroup" or opt == "ungrp" 		then TastyButtonsParser.ParseArgs_AnchorGroup(val,false)	  
	  elseif opt == "delete" or opt == "del" 			then TastyButtonsParser.Button_Delete_makeTable(val,"del") 
	  elseif opt == "scale" or opt == "sc" 				then TastyButtonsParser.Button_Delete_makeTable(val,"scale")
--	  elseif opt == "addstate" or opt == "adds" 		then TastyButtonsParser.ParseArgs_AddState(val)
--	  elseif opt == "delstate" or opt == "dels" 		then TastyButtonsParser.ParseArgs_DelState(val)
--	  elseif opt == "actstate" or opt == "acts" 		then TastyButtonsParser.ParseArgs_Button_Load_State(val)
	  elseif opt == "halp" 								then TastyButtonsParser.Halp(val)
	  elseif opt == "opt" or opt == "options" 			then TastyButtonsOptions.Toggle()
	  elseif opt == "list" or opt == "ls" 				then TastyButtons.Button_List()
	  elseif opt == "enabled" or opt == "on" 			then TastyButtons.ToggleEnabled(val) 
	  elseif opt == "actionbars" 						then TastyButtons.ActionBars_Deactivate()
	  elseif opt == "hello" 							then TastyButtons.Print("Hello World")
	  elseif opt == "pos" 								then TastyButtons.Button_GetPos(val)
	  elseif opt == "hide"								then TastyButtonsParser.HideButtons(val)
	  elseif opt == "show"								then TastyButtonsParser.ShowButtons(val)
	  elseif opt == "mode"								then TastyButtonsOptions.ToggleStateTypeButton(val)
	  elseif opt == "thanks" 							then TastyButtonsParser.Thanks()
	  elseif opt == "invisible" or opt == "invis"		then TastyButtonsParser.MakeInvisible(args,true)
	  elseif opt == "visible" or opt == "vis"			then TastyButtonsParser.MakeInvisible(args,false)
--	  elseif opt == "clearanchor" 						then TastyButtons.Button_Anchor_Delete_Single(val)
	  elseif opt == "test" 								then TastyButtons.Test()
	  elseif opt == "load" then 
		TastyButtons.Load() 
		TastyButtons.ToggleEnabled("on")
	  elseif opt == "unload" then 
		TastyButtons.UnLoad() 
		TastyButtons.ToggleEnabled("off")
	  elseif opt == "purge" then 
		TastyButtonsParser.Button_Delete_makeTable("all","del")
		for k in pairs(TastyButtons_Save) do TastyButtons_Save[k]=nil end
			TastyButtons_Save_Anchors={} 
	  elseif not opt then TastyButtons.Print("no Parameter given, type   /tasty halp   for more info")
	  else
		TastyButtons.Print("Paramater "..opt.." does not exist, type   /tasty halp   for more info")
	end
end


function TastyButtons.Button_Save_All(isForCopy)
	for slot,button in pairs(buttonHandles) do
		if button ~= nil then
			TastyButtons.Button_Save(button,isForCopy)
		end
	end

end
--[[
	!!!! DO NOT CALL SaveButton BEFORE ANCHORS ARE LOADED !!!!!
		or you will fail!
]]--
function TastyButtons.Button_Save(button,isForCopy)
	local buttonSlot = button:GetSlot()

	local anchor = anchorTable[buttonSlot]
	local isCustomTemp = button:GetisCustom()
	local isRoundTemp = button:GetisRound()
	
	if buttonTextures[button:GetSlot()] ~= nil then
		isCustomTemp = buttonTextures[button:GetSlot()]["isCustom"]
		isRoundTemp = buttonTextures[button:GetSlot()]["isRound"]
	end

	
	TastyButtons_Save[button:GetName()]={slot = button:GetSlot(),
											scale = button:GetScale(),
											state = buttonStateTable[button:GetSlot()],
											anchor = anchor,
											isRegistered = TastyButtons.Window_IsRegistered(button:GetName()),
											isCustom = isCustomTemp,
											isRound = isRoundTemp
											}
	
	TastyButtons.Button_State_Load_activeCurrentState(buttonSlot)
end


function TastyButtons.Load()
	--d("i be loading")
	TastyButtonsOptions.CreateOptionsWindow()
	if TastyButtons_Settings["actionBars"] then
		TastyButtons.PrintD("From Load")
		TastyButtons.ActionBars_Activate()
	  else
		TastyButtons.ActionBars_Deactivate()
	end
	if TastyButtons_Settings["stateType"] then
		TastyButtons.Button_State_TypeSwap(TastyButtons_Settings["stateType"])
	  else
		TastyButtons.Button_State_TypeSwap("PvE")	  
	end
	
	ButtonSetText("TastyButtonsGeneralOptionsWindowButtonAddonEnabled", L"Addon Enabled")	

	if not (buttonHandles==nil) then
		local showed=false
		for n in pairs(buttonHandles) do
			local bname=buttonHandles[n]:GetName()
			WindowSetShowing(bname,true)
			showed=true
		end
		if showed then return end
	end

	TastyButtons.RegisterEventHandlers()
	--- LOADING THE BUTTONS NOW -------------
	for n in pairs(TastyButtons_Save) do
		TastyButtons.PrintD("trying to load "..n)

		local slot = TastyButtons_Save[n]["slot"] 				--1
		local scale = TastyButtons_Save[n]["scale"] 			--2
		local register = TastyButtons_Save[n]["isRegistered"]		--7	
		local isRound = TastyButtons_Save[n]["isRound"]
		local isCustom = TastyButtons_Save[n]["isCustom"]
		
		local actionId = 0		--3
		local iconNum = 0		--4
		local actionType =0
		TastyButtons.Button_Create(slot,scale,actionId,iconNum,actionType,register,isCustom,isRound)
		buttonStateTable[slot] = {}
		buttonStateTable[slot] = TastyButtons_Save[n]["state"]
		TastyButtons.Button_State_Load_activeCurrentState_forAll()
	end
	
	local antiscale = math.floor(1 / InterfaceCore.GetScale())
	--- ANCHORS ARE LOADED AFTER ALL BUTTONS HAVE BEEN LOADED!!!!!! ---
	for n in pairs(TastyButtons_Save) do
		local slot=TastyButtons_Save[n]["slot"]
		if (TastyButtons_Save[n]["anchor"] ~= nil) then
			if (TastyButtons_Save[n]["anchor"]["relWin"]~=nil) then		-- 6
			--if true then
				local butohn2=TastyButtons_Save[n]["anchor"]["relWin"]		--1
				local xgap=TastyButtons_Save[n]["anchor"]["xgap"]			--2
				local ygap=TastyButtons_Save[n]["anchor"]["ygap"]			--3
				local anchor1=TastyButtons_Save[n]["anchor"]["anchor"]		--4
				local anchor2=TastyButtons_Save[n]["anchor"]["relAnchor"]	--5
				local anchorSlot=TastyButtons_Save[n]["anchor"]["anchorSlot"]
				
			
				if butohn2 == "Root" then
					xgap = math.floor(xgap / antiscale )
					ygap = math.floor(ygap / antiscale )

					TastyButtons.Window_Set_Pos(ButtonNameStart..slot,xgap,ygap)
				  else
					--TastyButtons.Button_Anchor_Add(ButtonNameStart..slot, butohn2, xgap, ygap, anchor1, anchor2)
					--[[
						Irgendjemand hat beim refactoring die Aufrufkonventionen der Funktion ge�ndert und vergessen das hier anzupassen -.-
						toll, und wie soll ich jetzt an den slot f�r butohn2 kommen O_o, 
						heul doch :P war doch garnicht so schwer :P
					]]--
					TastyButtons.Button_Anchor_Add(slot, anchorSlot, xgap, ygap, anchor1, anchor2)
				end

			else 
				TastyButtons.PrintD("no anchors for slot "..slot)
				TastyButtons.Window_Set_Pos(ButtonNameStart..slot,0,200)
			end
		end
		TastyButtons.Button_Save(TastyButtons.Button_Get_ButtonObjectByName(ButtonNameStart..slot))				
	end	
	WindowSetMovable("AbilitiesWindow",true)
	TastyButtons.Button_State_Load_activeCurrentState_forAll()
	BroadcastEvent(SystemData.Events.PLAYER_STANCE_UPDATED)
end

function TastyButtons.Shutdown()
	TastyButtons.PrintD("From Shutdown")
	TastyButtons.ActionBars_Activate(false)	
	if TastyButtons_Settings["ResourceHandler"] then
		TastyButtons.Pcall(UnregisterEventHandler, SystemData.Events.PLAYER_CAREER_RESOURCE_UPDATED,"TastyButtons.OnCareerResourceUpdated")
	end
	if TastyButtons_Settings["APHandler"] then
		TastyButtons.Pcall(UnregisterEventHandler, SystemData.Events.PLAYER_CUR_ACTION_POINTS_UPDATED,"TastyButtons.OnEnergyUpdated")
	end
	if TastyButtons_Settings["autoMode"] then
		TastyButtons.Pcall(UnregisterEventHandler, SystemData.Events.PLAYER_TARGET_UPDATED,"TastyButtons.OnTargetUpdated")
	end
	TastyButtons.Pcall(UnregisterEventHandler, SystemData.Events.PLAYER_STANCE_UPDATED, "TastyButtons.OnStanceUpdated")
	TastyButtons.Pcall(UnregisterEventHandler, SystemData.Events.USER_SETTINGS_CHANGED,"TastyButtons.UpdateKeyBindings")
	TastyButtonsOptions.Shutdown()
end

function TastyButtons.RegisterEventHandlers()
	if TastyButtons_Settings["ResourceHandler"] then
		TastyButtons.Pcall(RegisterEventHandler, SystemData.Events.PLAYER_CAREER_RESOURCE_UPDATED,"TastyButtons.OnCareerResourceUpdated")
	end
	if TastyButtons_Settings["APHandler"] then
		TastyButtons.Pcall(RegisterEventHandler, SystemData.Events.PLAYER_CUR_ACTION_POINTS_UPDATED,"TastyButtons.OnEnergyUpdated")
	end
	if TastyButtons_Settings["autoMode"] then
		TastyButtons.Pcall(RegisterEventHandler, SystemData.Events.PLAYER_TARGET_UPDATED,"TastyButtons.OnTargetUpdated")	
	end
	if petNameTable[GameData.Player.career.line] ~= nil then
		TastyButtons.Pcall(RegisterEventHandler, SystemData.Events.PLAYER_PET_UPDATED,"TastyButtons.OnPetUpdated")
	end
	TastyButtons.Pcall(RegisterEventHandler, SystemData.Events.PLAYER_STANCE_UPDATED, "TastyButtons.OnStanceUpdated")
	TastyButtons.Pcall(RegisterEventHandler, SystemData.Events.USER_SETTINGS_CHANGED,"TastyButtons.UpdateKeyBindings")

end

function TastyButtons.UnLoad()
	for n in pairs(buttonHandles) do	
		local bname=buttonHandles[n]:GetName()
		WindowSetShowing(bname,false)
	end
	TastyButtons.Shutdown()
	--TastyButtonsOptions.Shutdown()
	ButtonSetText("TastyButtonsGeneralOptionsWindowButtonAddonEnabled", L"Addon Disabled")
end

function TastyButtons.ActionBars_Activate(save)
	TastyButtons.PrintD("activating default actionbars")
	local slot=1
	for bar=1,4 do
		for button = 1,12 do
			if DoesWindowExist("EA_ActionBar"..bar.."Action"..button) then
				WindowSetGameActionTrigger ("EA_ActionBar"..bar.."Action"..button, GetActionIdFromName ("ACTION_BAR_"..slot))
				slot=slot+1
			end
		end
	end
	if save == false then return end
	ButtonSetText("TastyButtonsGeneralOptionsWindowButtonToggleBars",L"Bar Hotkeys(on)")
	TastyButtons_Settings["actionBars"] = true
end

function TastyButtons.SaveProfile(profile)
	TastyProfiles.SaveProfile(profile, TastyButtons_Settings, TastyButtons_Save)
end

function TastyButtons.LoadProfile(profile)
	TastyButtonsOptions.Delete_AllButtons()
	local settings, buttons = TastyProfiles.LoadProfile(profile)
	TastyButtons_CharacterSettings[varname]["settings"] 	= DataUtils.CopyTable(settings)
	TastyButtons_CharacterSettings[varname]["buttons"]		= DataUtils.CopyTable(buttons)
	TastyButtons.Load_CharacterSettings()
	TastyButtons.Load()
end

function TastyButtons.ActionBars_Deactivate()
	TastyButtons.PrintD("deactivating default actionbars")
	if not TastyButtons_Settings["enabled"] then
		TastyButtons.ActionBars_Activate(false)
		return
	end
	for bar=1,4 do
		for button = 1,12 do
			if DoesWindowExist("EA_ActionBar"..bar.."Action"..button) then
				WindowSetGameActionTrigger ("EA_ActionBar"..bar.."Action"..button, GetActionIdFromName (""))
			end
		end
	end
	ButtonSetText("TastyButtonsGeneralOptionsWindowButtonToggleBars",L"Bar Hotkeys(off)")
	TastyButtons_Settings["actionBars"] = false
end

---------------------------- MAIN FUNCTIONS --------------------
--THESE FUNCTIONS ARE AWESOME --

function TastyButtons.Button_Create(buttonSlot,scale,actionId,iconNum,actionType,register,isCustom,isRound)
	
	local buttonName = ButtonNameStart..buttonSlot
	local button
	scale = tonumber(scale)
	if ((scale == nil) or (tonumber(scale) <= 0)) then
		scale = InterfaceCore.GetScale()
	end		

	if DoesWindowExist(buttonName) then
		button = TastyButtons.Button_Get_ButtonObjectByName(buttonName)
		d("Button "..buttonSlot.." does already exist")
		return button
	  else
		button = TastyButtonsButton:Create (buttonName, root, buttonSlot, {false,true},(isCustom==true),(isRound==true))
		
		WindowRegisterCoreEventHandler(buttonName,"OnRButtonUp","TastyButtonsOptions.OnButton_RightClick") --register right click on button to update optionsinfowindow
		

		buttonHandles[button:GetSlot()] = button:GetSelf()
		TastyButtons.Button_Create_standardStatesinTable(buttonSlot)
		button:SetScale(scale)
		button:SetTintColor(255,255,255)
		local stateType = currentButtonStateTable[buttonSlot].stateType
		if actionId == nil then
			actionId 	= 0
			iconNum 	= 0
			actionType 	= 1
			stateType 	= "PvE"
		end
		button:SetState(actionId, iconNum, actionType, stateType)
		button:SetIcon(iconNum)
		button:SetActionData(actionType,actionId)
		WindowSetGameActionData (button:GetName().."Action", actionType, actionId, L"")

		--- SET ADVANCED OPTIONS FEATURES --
		button:SetCooldownFont(TastyButtons_Settings["CooldownFont"])
		button:SetCooldownFontColor(TastyButtons_Settings["CooldownFontColor"][1],TastyButtons_Settings["CooldownFontColor"][2],TastyButtons_Settings["CooldownFontColor"][3])
		button:SetHotKeyFont(TastyButtons_Settings["HotKeyFont"])
		button:SetHotKeyFontColor(TastyButtons_Settings["HotKeyFontColor"][1],TastyButtons_Settings["HotKeyFontColor"][2],TastyButtons_Settings["HotKeyFontColor"][3])
		button:SetShowGlobalCooldown(TastyButtons_Settings["globalCD"])
		button:SetNoTimeIndicator(TastyButtons_Settings["NoTimeIndicator"])
		button:SetAbcMode(TastyButtons_Settings["ABCMode"])
		button:SetEmptyShowing(TastyButtons_Settings["showEmpty"])
		button:SetShowTooltips(TastyButtons_Settings["showTooltips"])
		button:SetTintIconOnly(TastyButtons_Settings["tintIconOnly"])
		button:SetHotKeyShowing(TastyButtons_Settings["showHotkeys"])
		button:SetOORTint(TastyButtons_Settings["OORTint"].r,TastyButtons_Settings["OORTint"].g,TastyButtons_Settings["OORTint"].b)
		button:SetABCTint(TastyButtons_Settings["ABCTint"].r,TastyButtons_Settings["ABCTint"].g,TastyButtons_Settings["ABCTint"].b)
		-- NO MORE ADVANCED OPTIONS ---
		
		if register then
			LayoutEditor.RegisterWindow(button:GetName(), towstring("Tasty"..tostring(button:GetSlot())), L"Some stupid anchor point",
										false, false, true, nil)
		end
		--TastyButtons.Button_Save(button) --do this and you kill em all		
	end
	TastyButtonsOptions.Add_Button_to_List(buttonSlot,0)
	buttonScale[buttonSlot] = scale
	return button
end

function TastyButtons.Button_Create_standardStatesinTable(buttonSlot)
	-- Set the state default in stance normal --
	buttonStateTable[buttonSlot] = {}
	buttonStateTable[buttonSlot]["PvE"] = {}
	buttonStateTable[buttonSlot]["PvE"]["normal"] = {}
	buttonStateTable[buttonSlot]["PvE"]["normal"]["default"] = {actionId = 0, iconNum = 0, actionType = 0, showing = true}
	
	--- set the clear stance ---
	buttonStateTable[buttonSlot]["PvE"]["clear"] = {}
	buttonStateTable[buttonSlot]["PvE"]["clear"]["default"] = {actionId = 0, iconNum = 0, actionType = 0,  showing = true}

	-- set the currentButtonStatTable, to stance normal, state default and stateType PvE
	currentButtonStateTable[buttonSlot]	= {stance = "normal", state = "default",stateType = "PvE"}

end

function TastyButtons.Button_Create_fromOptions(scale, buttonSlot, useCustomTextures, buttonShape)
	if TastyButtons_Settings["enabled"] == true then
		if ((buttonSlot ~= nil) and ( tonumber(buttonSlot) > 0) and not(DoesWindowExist(ButtonNameStart..buttonSlot))) then
			local button = TastyButtons.Button_Create(buttonSlot,scale,0,0,0,true, useCustomTextures, buttonShape)
			TastyButtons.Button_Save(button)
			return buttonSlot
		  elseif buttonSlot == nil then
			local count = #buttonHandles+1
			for buttonSlotCount = 1, count do
				if not DoesWindowExist(ButtonNameStart..buttonSlotCount) then
					local button = TastyButtons.Button_Create(buttonSlotCount,scale,0,0,0,true, useCustomTextures, buttonShape)
					TastyButtons.Button_Save(button)
					return buttonSlotCount
				end
			end
		  else
			TastyButtons.Print("Button "..buttonSlot.." already exists")
			return 0
		  end
	  else
		TastyButtons.Print("Addon must be enabled")
	end
end

function TastyButtons.Button_Anchor_Ungroup_fromTable(buttonTable)
--	TastyButtons.PrintD("I are still right")
	for n in pairs(buttonTable) do
		TastyButtons.Button_Anchor_Ungroup_Button(buttonTable[n])
	end	
end

function TastyButtons.Button_Anchor_Ungroup_Button(buttonSlot)
	local buttonName = ButtonNameStart..buttonSlot
	local xpos,ypos = WindowGetScreenPosition(buttonName)
	WindowClearAnchors(buttonName)
	anchorTable[buttonSlot] = nil
	TastyButtons.Window_Set_Pos(buttonName, xpos, ypos)
	if not(TastyButtons.Window_IsRegistered(buttonName)) then
		LayoutEditor.RegisterWindow(buttonName, towstring("Tasty"..tostring(buttonSlot)), L"Some stupid anchor point",
		false, false, true, nil)
	end
	local buttonObject = TastyButtons.Button_Get_ButtonObjectByName(buttonName)
	TastyButtons.Button_Save(buttonObject)
	
end

function TastyButtons.Button_Anchor_fromTable(buttonTable)
	for n in pairs(buttonTable) do
		local anchor1,anchor2 = TastyButtons.Get_AnchorPointByDirection(buttonTable[n][5])
		TastyButtons.Button_Anchor_Add(buttonTable[n][1],buttonTable[n][2], buttonTable[n][3], buttonTable[n][4], anchor1, anchor2)
	end
end

function TastyButtons.Button_Anchor_Add_CycleDetection(buttonSlot, relbuttonSlot, startButton)
	if relbuttonSlot == nil or relbuttonSlot == "Root" or anchorTable[relbuttonSlot]== nil or anchorTable[relbuttonSlot]["anchorSlot"] == nil then
		return false, relbuttonSlot
	  elseif relbuttonSlot == startButton then
		return true
	  else	
		local newRelButton = tonumber(anchorTable[relbuttonSlot]["anchorSlot"])
		return TastyButtons.Button_Anchor_Add_CycleDetection(relbuttonSlot, newRelButton, startButton)
	end
end

function TastyButtons.Button_Anchor_Add(buttonSlot, relbuttonSlot, x, y, anchor, relanchor)
	
	local buttonName 	=	ButtonNameStart..buttonSlot
	local relbuttonName =	ButtonNameStart..relbuttonSlot
	if x == nil then
		x = 0
	end
	if y == nil then
		y = 0
	end
	
	if DoesWindowExist(buttonName) then

		if relbuttonSlot == "Root" then
			TastyButtons.Window_Set_Pos(buttonName,x,y)
			lastexistingButton = buttonName
		  else
			local cycleCheck = TastyButtons.Button_Anchor_Add_CycleDetection(tonumber(buttonSlot), tonumber(relbuttonSlot), tonumber(buttonSlot))
			if cycleCheck then
				--- relButton is already anchored to button, allowing to add a anchor from button to relButton would cause am game crash...  --		
				TastyButtons.Print("Recursive Anchoring leads to game crashes, and thus is not allowed")
				return
				
			  elseif not DoesWindowExist(relbuttonName) then
				--- the relButton does not exist. so the button wil be anchored to the last existing window
				TastyButtons.PrintD("Button "..relbuttonSlot.." does not exist, anchoring to button "..lastexistingButton)
				relbuttonName = lastexistingButton
				WindowClearAnchors(buttonName)
				WindowAddAnchor(buttonName, anchor, relbuttonName, relanchor,x ,y)
				LayoutEditor.UnregisterWindow(buttonName)
				lastexistingButton = buttonName
				
			  else
			    ----- Add a normal anchor ------
				WindowClearAnchors(buttonName)
				WindowAddAnchor(buttonName, anchor, relbuttonName, relanchor,x ,y)
				LayoutEditor.UnregisterWindow(buttonName)
				lastexistingButton = buttonName
			end	
		end
			
		if relbuttonName == "Root" then
			relbuttonSlot = "Root"
		  else
			relbuttonSlot = relbuttonName:match(ButtonNameStart.."(%d+)")
		end
		
		anchorTable[buttonSlot] = {}
		anchorTable[buttonSlot]["relWin"] 		=	relbuttonName 	
		anchorTable[buttonSlot]["xgap"] 		= 	x
		anchorTable[buttonSlot]["ygap"] 		= 	y
		anchorTable[buttonSlot]["anchor"] 		= 	anchor
		anchorTable[buttonSlot]["relAnchor"] 	= 	relanchor
		anchorTable[buttonSlot]["anchorSlot"]	= 	relbuttonSlot
		
		local button = TastyButtons.Button_Get_ButtonObjectByName(buttonName)
		TastyButtons.Button_Save(button)
		
	  else
		TastyButtons.Print("Button "..buttonSlot.." does not exist, skipping")
	end
end

function TastyButtons.Button_Add_toGroup(buttonSlot, buttonGroup)
	
end
--[[
buttonTable[n] = buttonName
--]]
function TastyButtons.Button_Delete_fromTable(buttonTable)
	for _,buttonSlot in ipairs(buttonTable) do
		TastyButtons.Button_Delete(buttonSlot)
	end
end

function TastyButtons.Button_Delete(buttonSlot)
	local buttonName = ButtonNameStart..buttonSlot
	if not TastyButtons.Window_IsRegistered(buttonName) and DoesWindowExist(buttonName) then
		LayoutEditor.RegisterWindow(buttonName, towstring("Tasty"..tostring(buttonSlot)), L"Some stupid anchor point",
										false, false, true, nil)
	end	
	TastyButtons.PrintD("n is: "..buttonSlot)
	TastyButtons.PrintD("buttonName is : "..buttonName)
	
	if DoesWindowExist(buttonName) then
		TastyButtons.Print("Destroying Button "..buttonSlot)
		DestroyWindow(buttonName)
	end
	buttonStateTable[buttonSlot] = nil
	currentButtonStateTable[buttonSlot] = nil
	anchorTable[buttonSlot] = nil
	buttonHandles[buttonSlot] = nil
	TastyButtons_Save[buttonName] = nil
	TastyButtonsOptions.Del_Button_from_List(buttonSlot)
	if TastyButtons.Window_IsRegistered(buttonName) then
		LayoutEditor.UnregisterWindow(buttonName)
	end

end


function TastyButtons.Button_State_Add_fromTable(buttonTable, stanceName, stateName,stateType, showing)
	for buttonSlot in pairs(buttonTable) do
		TastyButtons.Button_State_Add(buttonTable[buttonSlot], stanceName, stateName,stateType, showing)
	end
end

-- Adds a Stance/State Combo to a Button --
function TastyButtons.Button_State_Add(buttonSlot, stanceName, stateName, stateType, showing) -- (number,string)
	local buttonSlot = tonumber(buttonSlot)
	if stateType == nil then
		stateType = "PvE"
	end
	-- Check: Add Only States to existing Buttons--
	if DoesWindowExist(ButtonNameStart..buttonSlot) then
		if buttonStateTable[buttonSlot][stateType] == nil then
			buttonStateTable[buttonSlot][stateType] = {}
		end
		if buttonStateTable[buttonSlot][stateType][stanceName] == nil then
			buttonStateTable[buttonSlot][stateType][stanceName] = {}
		end
		if buttonStateTable[buttonSlot][stateType][stanceName][stateName] == nil then
			buttonStateTable[buttonSlot][stateType][stanceName][stateName] = {}
		end
		-- Checking if the default state is already available for the stance, otherwise adding it --
		if ((buttonStateTable[buttonSlot][stateType][stanceName]["default"] == nil) and (stateName ~= "default")) then
			TastyButtons.Print("Adding Default State cause its missing")
			TastyButtons.Button_State_Add(buttonSlot,stanceName, "default", stateType, showing)
		end
		-- Now adding the wanted state --
		if #buttonStateTable[buttonSlot][stateType][stanceName][stateName] <= 0 then	
			local Button = TastyButtons.Button_Get_ButtonObjectByName(ButtonNameStart..buttonSlot)
			TastyButtons.Button_State_Clear(buttonSlot,stanceName,stateName,stateType,showing)
			TastyButtons.Button_Save(Button)
			TastyButtons.Print("Added State: "..stateName.." to Button "..buttonSlot.." for stance "..stanceName.." for mode "..stateType)
		end
	end	
end

function TastyButtons.Button_State_Del_fromTable(buttonTable, stanceName, stateName,stateType)
	for buttonSlot in pairs(buttonTable) do
		TastyButtons.Button_State_Del(buttonTable[buttonSlot], stanceName, stateName)
	end
end

--Deletes a Stance/State Combo of a Button --
function TastyButtons.Button_State_Del(buttonSlot, stanceName, stateName,stateType)
	local buttonSlot = tonumber(buttonSlot)
	local lstanceName = stanceName
	local stateChange = "doNothing"
	if not lstanceName then 
		lstanceName = stanceNameTable[0]
	end
	if ((not stateType) or (not buttonStateTable[buttonSlot][stateType])) then
		stateType = currentButtonStateTable[buttonSlot]["stateType"]
	end
	--- Check witch deletion is wanted --
	if ((stateName == "default") and (lstanceName ~= "normal"))  then
		stateChange = "deleteStance"
	  elseif ((stateName == "default") and (lstanceName == "normal") and (stateType == "RvR")) then
		stateChange = "deleteRvRMode"
	  elseif ((stateName == "default") and (lstanceName == "normal")) then
		TastyButtons.Print("You cannot delete the default state of the normal stance")
	  else
		stateChange = "deleteOneState"
	end
	
	--- act accordingly to it --
	if stateChange == "deleteOneState" then
		buttonStateTable[buttonSlot][stateType][lstanceName][stateName] = nil
		TastyButtons.Print("Deleted State: "..stateName.." of Button "..buttonSlot)
		if currentButtonStateTable[buttonSlot]["state"] == stateName then
			currentButtonStateTable[buttonSlot]["state"] = "default"
		end
	  elseif stateChange == "deleteStance" then
		buttonStateTable[buttonSlot][stateType][lstanceName] = nil
		TastyButtons.Print("Deleted Stance: "..lstanceName.." of Button "..buttonSlot)		
		if currentButtonStateTable[buttonSlot]["stance"] == lstanceName then
			currentButtonStateTable[buttonSlot]["state"] = "default"
			currentButtonStateTable[buttonSlot]["stance"] = "normal"
		end
	  elseif stateChange == "deleteRvRMode" then
		if currentButtonStateTable[buttonSlot]["stateType"] == stateType then		
			buttonStateTable[buttonSlot][stateType] = nil
			currentButtonStateTable[buttonSlot]["state"] = "default"
			currentButtonStateTable[buttonSlot]["stance"] = "normal"
			currentButtonStateTable[buttonSlot]["stateType"] = "PvE"
			TastyButtons.Print("Deleted the RvR Buttonstates for Button "..buttonSlot)
		end	
	  else
		TastyButtons.PrintD("Sumthing went wrong")
	end
	TastyButtons.Button_State_Load(buttonSlot, currentButtonStateTable[buttonSlot]["stance"], currentButtonStateTable[buttonSlot]["state"],currentButtonStateTable[buttonSlot]["stateType"])
	
end


function TastyButtons.OnStanceUpdated(stance, updateType)

	if ((currentStance ~= stance) and (updateType == GameData.STANCE_ADDED))then
		currentStance = stance
		TastyButtons_Settings["lastStance"] = stance
		TastyButtons.Button_State_Load_activeCurrentState_forAll()
		--TastyButtons.Button_Swap(currentStance, "default")
	end
	
	if ((currentStance == stance) and (updateType == GameData.STANCE_REMOVED))then
		currentStance = 0
		TastyButtons_Settings["lastStance"] = 0
		TastyButtons.Button_State_Load_activeCurrentState_forAll()
		--TastyButtons.Button_Swap(currentStance, "default")
	end
	
end

function TastyButtons.Button_EffectsUpdated()
	TastyButtons.PrintD("EffectsUpdated was called")
	--GetAbilityData(abilityId).name
	local blah = GetBuffs (GameData.BuffTargetType.SELF)
	LibCooldown.PrintTable(blah)
	
	for k,v in pairs(blah) do
      --new buff
      TastyButtons.PrintD(L"["..v.name..L"]")
      --get type
      TastyButtons.PrintD(DataUtils.GetAbilityTypeText(v))
      --see if type
	end

end
function TastyButtons.Button_StanceSwap(stance)
	local lstanceName = stanceNameTable[stance]
	
	for buttonSlot in pairs(buttonHandles) do
		if ((buttonStateTable[buttonSlot] ~= nil) and (buttonStateTable[buttonSlot][currentStateType] ~= nil) and (buttonStateTable[buttonSlot][currentStateType][lstanceName] ~= nil)) then
			TastyButtons.Button_State_Load(buttonSlot, lstanceName, "default")
		end	
	end
end

function TastyButtons.Button_Swap(stance, state)
	local lstanceName = stanceNameTable[stance]
	if not state then
		state = "default"
	end
	for buttonSlot in pairs(buttonHandles) do
		if ((buttonStateTable[buttonSlot][currentButtonStateTable[buttonSlot]["stateType"]] ~= nil) and (buttonStateTable[buttonSlot][currentButtonStateTable[buttonSlot]["stateType"]][lstanceName] ~= nil)) 
		then
			if buttonStateTable[buttonSlot][currentButtonStateTable[buttonSlot]["stateType"]][lstanceName]["OnCooldown"] ~= nil then
				for skill in pairs(OnCooldownSkills) do
					if buttonStateTable[buttonSlot][currentButtonStateTable[buttonSlot]["stateType"]][lstanceName]["default"]["actionId"] == skill  then
						TastyButtons.Button_State_Load(buttonSlot, lstanceName, "OnCooldown")
					  else
						TastyButtons.Button_State_Load(buttonSlot, lstanceName, state)  
					end
				end
			 else
				TastyButtons.Button_State_Load(buttonSlot, lstanceName, state)
			end	
		  else
			TastyButtons.Button_State_Load(buttonSlot, 0, "default")
		end
	end
end

--[[

I dont know why i added this comment space here. So i thought about writing wiriting smth in it that they be of interest for other People.
My real name is Efstathios Amanatidis. I'm living in germany and studying computer science. This is the "second" addon that i develop.
My First one was "Comix" for WoW. Anyway, i started playing WAR and thought that a addon like this is missing. So i started to hack around a bit.
This was the outcome. And know I'mm thinkin about improving the peroformance and the "style" in this addon. Hopefully you like using the Addon.
My Friend "Vidhar" is currently having problems with "R-Trees" and isn't able to split them, cause we don't know which algorithm to use.

]]--



-- THIS FUNCTION IS REALLY THE DEVIL (AND i DO NOT KNOW WHY I HAVE TO DO IT LIKE THIS) .. lawl -.-  --
function TastyButtons.Window_Set_Pos(window, xpos, ypos)
	if DoesWindowExist(window) then
		local uiScale = InterfaceCore.GetScale()    
		-- just so you know.... x and y values ARE ZERO I MEAN      0        
		-- this is such a fucking hack and i don't know why this happens -.-
		local x,y = WindowGetScreenPosition("Root")	
		local butohnhandle = TastyButtons.Button_Get_ButtonObjectByName(window)
		local tempxpos = xpos
		local tempypos = ypos
		-- now this is the most devilish part.... actually this function only works if i add x + xpos
		-- you'll probably remember that x was zero ... STILL THIS FUCKING SHIT DOES NOT WORK WITHOUT IT 
		-- WTF IS WAR THINKING????
		local xpos = math.floor((x+xpos)/uiScale)
		local ypos = math.floor((y+ypos)/uiScale)

--		TastyButtons.PrintD("tx: "..tempxpos.."       ty: "..tempypos)
--		TastyButtons.PrintD("x: "..xpos.."       y: "..ypos)
--		TastyButtons.PrintD("---------------------------------------------------------------------")

		-- me be create anchors ... cause this be working! he doesnt like adding an Anchor via WindowAddAnchor to the Root window ... so ill do it this way :D
		local anchor = { Point="topleft", RelativeTo="Root", RelativePoint="topleft", XOffset=xpos, YOffset=ypos }
		WindowClearAnchors(butohnhandle:GetName ())
		butohnhandle:SetAnchor( anchor )
		-- Force is always good.... 
		butohnhandle:ForceProcessAnchors()
		anchorTable[butohnhandle:GetSlot()] = {relWin ="Root", xgap = tempxpos, ygap = tempypos, anchor = "topleft", relAnchor = "topleft", anchorSlot = "Root"}
		LibCooldown.PrintTable(anchorTable[butohnhandle:GetSlot()])
		if TastyButtons.Window_IsRegistered(window) == false then
			LayoutEditor.RegisterWindow(window,towstring("Tasty"..tostring(butohnhandle:GetSlot())),L"anchor lol",false,false,true,nil)
		end
		butohnhandle:Save()
	  else
		TastyButtons.PrintD("Window "..window.." does not exists")
	end
end

function TastyButtons.Button_State_Set(buttonSlot, actionId, iconNum, actionType, gstance, gstate,gstateType)
	local stateType = gstateType
	local stance = gstance
	local state = gstate
	if stateType == nil then
		stateType = currentButtonStateTable[buttonSlot]["stateType"]
	end
	if stance ==nil then
		stance = currentButtonStateTable[buttonSlot]["stance"]
	end
	if state == nil then
		state = currentButtonStateTable[buttonSlot]["state"]
	end
	
	local button = TastyButtons.Button_Get_ButtonObjectByName(ButtonNameStart..buttonSlot)
		buttonStateTable[buttonSlot][stateType][stance][state]["actionId"] =  actionId
		buttonStateTable[buttonSlot][stateType][stance][state]["iconNum"] = iconNum	
		buttonStateTable[buttonSlot][stateType][stance][state]["actionType"] = actionType 
		buttonStateTable[buttonSlot][stateType][stance][state]["showing"] = true 
		button:Save()
end

--	ButtonGetText(windowNameTable["default"].."ButtonToggleStateType")

function TastyButtons.Button_State_TypeToggle()
	if currentStateType == "PvE" then
		TastyButtons.Button_State_TypeSwap("RvR")
		WindowSetTintColor("TastyButtonsOptionsMenuButton",200,0,0)
	  else
		TastyButtons.Button_State_TypeSwap("PvE")
		WindowSetTintColor("TastyButtonsOptionsMenuButton",255,255,255)
	end
end

function TastyButtons.Button_State_TypeSwap(stateType)
	currentStateType = stateType
	for buttonSlot in pairs(buttonStateTable) do
		if buttonStateTable[buttonSlot][stateType] ~= nil then
			currentButtonStateTable[buttonSlot]["stateType"] = stateType
		end
	end
	TastyButtons_Settings["stateType"] = stateType
	TastyButtons.PrintD("CurrentStateType is "..currentStateType)
	if currentStateType == "PvE" then
		WindowSetTintColor("TastyButtonsOptionsMenuButton",255,255,255)
		ButtonSetTextColor("TastyButtonsOptionsWindowStateViewStateModeButton", 0, 0, 255, 0)
		ButtonSetText("TastyButtonsOptionsWindowStateViewStateModeButton",L"Current Mode: PvE")
	  else
		WindowSetTintColor("TastyButtonsOptionsMenuButton",200,0,0)	
		ButtonSetTextColor("TastyButtonsOptionsWindowStateViewStateModeButton", 0, 255, 0, 0)
		ButtonSetText("TastyButtonsOptionsWindowStateViewStateModeButton",L"Current Mode: RvR")
	end		
	TastyButtonsOptions.OnComboButtonSelectionChanged()
	TastyButtons.Button_State_Load_activeCurrentState_forAll()
end

----------------- Assistance Functions ----------------------------------- 
-- Functions made to assist or keep the code ... eh clean 

-- Most used function in this addon.
function TastyButtons.Print(text)
	EA_ChatWindow.Print(towstring("tasty: "..tostring(text)))
end
function TastyButtons.PrintD(text)
	if TastyButtonsDebugMode then
		d(("tasty: "..tostring(text)))
	end
end

function TastyButtons.PrintVariable(variable,variablename)
	TastyButtons.Print(variablename..": ("..tostring(type(variable))..") "..tostring(variable))
end
--I can list all my buttohns.... awesome stuff... mainly for "checking" while developing
function TastyButtons.Button_List()
	for n in pairs(buttonHandles) do
		if n == nil or n == "" then
			TastyButtons.Print("Button does not exist")
		  else
			TastyButtons.Print(n.."   Scale : "..TastyButtons.Button_Get_ButtonObjectByName(ButtonNameStart..n):GetScale())
		end
	end	
end

function TastyButtons.Button_Get_List()
	local buttonList = {}
	for n in pairs(buttonHandles) do
		table.insert(buttonList,n,n)
	end	
	return buttonList
end

-- Creates a Table out of the Given Paramater to use with "TastyButtons.Button_Create_fromTable". 
-- it's just there to keep the code a bit more clean :D
function TastyButtons.Button_Anchor_makeTable(firstButton, lastButton , xgap, ygap, direction,toButton)
	local buttonTable = {}
	local step = 1
	local firstButton = tonumber(firstButton)
	local lastButton = tonumber(lastButton)
	TastyButtons.PrintD("Firstbutton "..firstButton)
	
	if toButton ~= nil then
		buttonTable[firstButton] = {}
		buttonTable[firstButton][1] = 	firstButton
		buttonTable[firstButton][2] = 	toButton
		buttonTable[firstButton][3] = 	xgap		
		buttonTable[firstButton][4] =	ygap
		buttonTable[firstButton][5] =	direction
	end
	--- Check if buttons are given in reverse order ---
	if firstButton > lastButton then
		firstButton = firstButton-1
		step = -1
	 else
		firstButton = firstButton+1
	end
	
	TastyButtons.PrintD("Firstbutton now"..firstButton)
	---- fill the table with many anhors :D ----
	if lastButton > 0 then
		for buttonSlot = firstButton, lastButton, step do
			buttonTable[buttonSlot] = {}
			--- setting relativetobutton to the previous button --
			relativetoButton = buttonSlot - step
			---Saving the anchor in the table ---
			buttonTable[buttonSlot][1] = 	buttonSlot
			buttonTable[buttonSlot][2] = 	relativetoButton
			buttonTable[buttonSlot][3] = 	xgap		
			buttonTable[buttonSlot][4] =	ygap
			buttonTable[buttonSlot][5] =	direction
		end
	end
	return buttonTable 
end

function TastyButtons.Button_Anchor_makeTablefromTable(buttonTable , xgap, ygap, direction,toButton)
	local anchorTable = {}
	
	if toButton ~= nil then
		anchorTable[1] = {}
		anchorTable[1][1] = buttonTable[1]
		anchorTable[1][2] = toButton
		anchorTable[1][3] = xgap		
		anchorTable[1][4] =	ygap
		anchorTable[1][5] =	direction
	end
	
	for index = 2, #buttonTable do
		anchorTable[index] = {}
		anchorTable[index][1] = buttonTable[index]
		anchorTable[index][2] = buttonTable[index-1]
		anchorTable[index][3] = xgap		
		anchorTable[index][4] =	ygap
		anchorTable[index][5] =	direction
	end
	
	return anchorTable
end


function TastyButtons.Button_Anchor_makeBlockTable(buttonTable, x, y, columndirection, rowdirection, columns, rows)

	local buttonAnchorTable = {}
	local rowcount = 0
	
	for counter,buttonSlot in ipairs(buttonTable) do
		local nextColumn = (math.mod(counter-1,columns) == 0)
		if nextColumn then rowcount = rowcount +1 end
		if counter > 1 and rowcount <= rows then		
			buttonAnchorTable[counter] = {}
			buttonAnchorTable[counter][1] = buttonTable[counter]
			buttonAnchorTable[counter][3] = x		
			buttonAnchorTable[counter][4] = y
			if nextColumn then 
				buttonAnchorTable[counter][5] = columndirection
				buttonAnchorTable[counter][2] = buttonTable[counter-columns]
			  else	
				buttonAnchorTable[counter][5] = rowdirection
				buttonAnchorTable[counter][2] = buttonTable[counter-1]
			end
			
		  elseif rowcount > rows then TastyButtons.Button_Anchor_Ungroup_Button(buttonSlot) --d("Button "..buttonSlot.." did not fit,ungrouped Button")
		end
	end
	
	return buttonAnchorTable
end

--this is .... just look at it and figure
function TastyButtons.Button_Create_fromTable(buttonTable, scale, isCustom, isRound)
	for buttonName in pairs(buttonTable) do
		TastyButtons.PrintD("bname: "..tostring(buttonName))
		local button=TastyButtons.Button_Create(buttonTable[buttonName], scale, 0, 0, 0, true, isCustom, isRound )
		TastyButtons.Button_Save(button) 
	end
end

-- just a getter for the Position of a window on the screen ...
function TastyButtons.Button_GetPos(args)
	local button = ButtonNameStart..args
	local xpos, ypos = WindowGetScreenPosition(button)
	if xpos and ypos then
		TastyButtons.PrintD("x: "..xpos)
		TastyButtons.PrintD("y: "..ypos)
	end
end

-- deletes the anchor for a button
function TastyButtons.Button_Anchor_Delete_Single(args)
  local butohn = ButtonNameStart..args
  WindowClearAnchors(butohn)
end

-- this checks if a window is already registered in the LayoutEditor needed sometimes :D
function TastyButtons.Window_IsRegistered(windowName)
	-- see: http://www.thewarwiki.com/wiki/API:LayoutEditor.UnregisterWindow
	if( LayoutEditor.windowsList[ windowName ] == nil ) then
		return false
	else 
		return true
	end
end

--If the button "object" is needed it can be obtained by calling this function  with the window name :D
function TastyButtons.Button_Get_ButtonObjectByName(windowName)
	for i in pairs(buttonHandles) do
		if buttonHandles[i]:GetName()==windowName then
			return buttonHandles[i]
		end
	end
	TastyButtons.PrintD("ButtonObject not found")
	return nil
end

function TastyButtons.Fill_directionTable()
	directionTable["Down"] = {}
	directionTable["Down"] = {anchor = "bottom", relanchor = "top"}
	
	directionTable["Up"] = {}
	directionTable["Up"] = {anchor = "top", relanchor = "bottom"}
	
	directionTable["Left"] = {}
	directionTable["Left"] = {anchor = "topleft", relanchor = "topright"}
	
	directionTable["Right"] = {}
	directionTable["Right"] = {anchor = "topright", relanchor = "topleft"}

	directionTable["Rightup"] = {}
	directionTable["Rightup"] = {anchor = "topright", relanchor = "bottomleft"}

	directionTable["Rightdown"] = {}
	directionTable["Rightdown"] = {anchor = "bottomright", relanchor = "topleft"}	
	
	directionTable["Leftup"] = {}
	directionTable["Leftup"] = {anchor = "topleft", relanchor = "bottomright"}	
	
	directionTable["Leftdown"] = {}
	directionTable["Leftdown"] = {anchor = "bottomleft", relanchor = "topright"}	
end

--[[
	Engi: 		Turret
	Magus: 	Summon
	White Lion:	Call
	Squig H	Squig
 --]]
-- number from GameData.Player.career.line
local petSearchTable = 	{	[4] 	= {L"Gun Turret", L"Flame Turret", L"Bombardment Turret"	},		-- Engineer
							[8] 	= {L"Summon Squig", L"Horned Squig", L"Spked Squig", L"Gas Squig"	},		--Squig Herder
							[16] 	= {L"Summon "	},		--Magus
							[19] 	= {L"Call "	}			-- White Lion
						}	
						
local petNameTable = {	[16] 	= 	{L"Flamer", L"Pink Horror", L"Blue Horror", L"Daemonic Infestation"},
						[8]		=	{L"Squig", L"Horned Squig", L"Spiked Squig", L"Gas Squig"},
						[4]		=	{L"Gun Turret", L"Flame Turret", L"Bombardment Turret"}, --, L"Land Mine",L"Keg O' Stout",L"Lightning Rod"
						[19]	= 	{L"War Lion"}
					}


-- this is just to make the direction the buttons should go easier :D
-- if no arguments are given it returns the anchors for the default direction (which is right)
function TastyButtons.Get_AnchorPointByDirection(direction)
	local anchor, relanchor
	if ((directionTable[direction] ~= nil) and (directionTable[direction] ~= {})) then
		anchor = directionTable[direction]["anchor"]		
		relanchor = directionTable[direction]["relanchor"]		
	  else 
		anchor = "topright"
		relanchor = "topleft"	  
	end
	return anchor,relanchor
end
-- SOME GETTERS--
function TastyButtons.Get_petNameTable()
	return petNameTable
end

function TastyButtons.Get_directionNames()
	local directions = {}
	for directionName in pairs(directionTable) do
		table.insert(directions,directionName)
	end
	return directions
end

function TastyButtons.Get_stanceNameTable()
	return stanceNameTable
end

function TastyButtons.Get_stateNameTable()
	return stateNameTable
end

function TastyButtons.GetButtonStateTable()
	return buttonStateTable
end

function TastyButtons.GetButtonHandles()
	return buttonHandles
end

function TastyButtons.Get_States(buttonSlot)
	if not currentButtonStateTable[buttonSlot]["stateType"] then
		return buttonStateTable[buttonSlot]["PvE"]
	  else
		return buttonStateTable[buttonSlot][currentButtonStateTable[buttonSlot]["stateType"]]
	end
end

function TastyButtons.Get_stateType(buttonSlot)
	if currentButtonStateTable[buttonSlot] ~= nil then
		return currentButtonStateTable[buttonSlot]["stateType"]
	  else
		return "PvE"
	end
end

function TastyButtons.Get_ButtonAnchor(buttonSlot)
	return anchorTable[buttonSlot]
end

function TastyButtons.Get_currentButtonStateTable()
	return currentButtonStateTable
end
function TastyButtons.Get_ButtonNameStart()
	return ButtonNameStart
end
function TastyButtons.Get_ButtonScale(buttonSlot)
	return WindowGetScale(ButtonNameStart..buttonSlot)
end
function TastyButtons.Get_playerClass()
	return playerClass
end

function TastyButtons.Get_ButtonInfo(buttonSlot)

	local buttonName = ButtonNameStart..buttonSlot
	local buttonScale = InterfaceCore.GetScale() --WindowGetScale(buttonName)
	local anchor = anchorTable[buttonSlot]
	local xpos,ypos = WindowGetScreenPosition(buttonName)
	
	local buttonInfo = {	buttonName 	= buttonName,
							scale		= buttonScale,
							anchor		= anchor,
							x			= xpos,
							y			= ypos
						}
	return buttonInfo
end

-- SOME SETTERS --

function TastyButtons.Set_ButtonStateTable(stable)
	buttonStateTable=stable
end

function TastyButtons.Set_OORTint_All(r,g,b)
	for _,button in pairs(buttonHandles) do
		button:SetOORTint(r,g,b)
	end
	TastyButtons_Settings["OORTint"] = {r = r, g = g, b = b}
end

function TastyButtons.Set_ABCTint_All(r,g,b)
	for _,button in pairs(buttonHandles) do
		button:SetABCTint(r,g,b)
	end
	TastyButtons_Settings["ABCTint"] = {r = r, g = g, b = b}
end

function TastyButtons.Set_autoMode(isEnabled)
	if isEnabled and not TastyButtons_Settings["autoMode"] then
		TastyButtons.Pcall(RegisterEventHandler, SystemData.Events.PLAYER_TARGET_UPDATED,"TastyButtons.OnTargetUpdated")	  
	  elseif not isEnabled and TastyButtons_Settings["autoMode"] then
		TastyButtons.Pcall(UnregisterEventHandler, SystemData.Events.PLAYER_TARGET_UPDATED,"TastyButtons.OnTargetUpdated")	  	  
	end
	TastyButtons_Settings["autoMode"] = isEnabled
end


function TastyButtons.Set_globalCD_All(isEnabled)
	for _,button in pairs(buttonHandles) do
		button:SetShowGlobalCooldown(isEnabled)
	end
	TastyButtons_Settings["globalCD"] = isEnabled
end

function TastyButtons.Set_ABCMode_all(isEnabled)
	for _,button in pairs(buttonHandles) do
		button:SetAbcMode(isEnabled)
	end
	TastyButtons_Settings["ABCMode"] = isEnabled
end

function TastyButtons.Set_EmptyShowing_all(isEnabled)
	for _,button in pairs(buttonHandles) do
		button:SetEmptyShowing(isEnabled)
	end
	TastyButtons_Settings["showEmpty"] = isEnabled
end

function TastyButtons.Set_CooldownTimerFont_All(font)
	for _,button in pairs(buttonHandles) do
		button:SetCooldownFont(font)
	end
	TastyButtons_Settings["CooldownFont"] = font
end

function TastyButtons.Set_HotKeyFont_All(font)
	for _,button in pairs(buttonHandles) do
		button:SetHotKeyFont(font)
	end
	TastyButtons_Settings["HotKeyFont"] = font
end

function TastyButtons.Set_CooldownTimerFontColor_All(r,g,b)
	for _,button in pairs(buttonHandles) do
		button:SetCooldownFontColor(r,g,b)
	end
	TastyButtons_Settings["CooldownFontColor"] = {r,g,b}
end

function TastyButtons.Set_HotKeyFontColor_All(r,g,b)
	for _,button in pairs(buttonHandles) do
		button:SetHotKeyFontColor(r,g,b)
	end
	TastyButtons_Settings["HotKeyFontColor"] = {r,g,b}
end

function TastyButtons.Set_NoTimeIndicator_all(enabled)
	for _,button in pairs(buttonHandles) do
		button:SetNoTimeIndicator(enabled)
	end
	TastyButtons_Settings["NoTimeIndicator"] = enabled
end

function TastyButtons.Set_ShowTooltips_all(enabled)
	for _,button in pairs(buttonHandles) do
		button:SetShowTooltips(enabled)
	end
	TastyButtons_Settings["showTooltips"] = enabled
end

function TastyButtons.Set_TintIconOnly_all(enabled)
	for index, button in pairs(buttonHandles) do
		button:SetTintIconOnly(enabled)
		button:ResetTintColor()
	end
	TastyButtons_Settings["tintIconOnly"] = (enabled == true)
end

function TastyButtons.Set_HotkeyShowing_all(showing, save)
	for index, button in pairs(buttonHandles) do
		button:SetHotKeyShowing(showing)
	end
	if save then
		TastyButtons_Settings["showHotkeys"] = showing
	end
end

function TastyButtons.Set_APHandler_all(enabled)
	if enabled and not TastyButtons_Settings["APHandler"] then
		TastyButtons.Pcall(RegisterEventHandler, SystemData.Events.PLAYER_CUR_ACTION_POINTS_UPDATED,"TastyButtons.OnEnergyUpdated")	
		TastyButtons_Settings["APHandler"] = true
	  elseif not enabled and TastyButtons_Settings["APHandler"] then
		TastyButtons.Pcall(UnregisterEventHandler, SystemData.Events.PLAYER_CUR_ACTION_POINTS_UPDATED,"TastyButtons.OnEnergyUpdated")	  
		TastyButtons_Settings["APHandler"] = false
	end
end

function TastyButtons.Set_ResourceHandler_all(enabled)
	if enabled and not TastyButtons_Settings["ResourceHandler"] then
		TastyButtons.Pcall(RegisterEventHandler, SystemData.Events.PLAYER_CAREER_RESOURCE_UPDATED,"TastyButtons.OnCareerResourceUpdated")
		TastyButtons_Settings["ResourceHandler"] = true
	  elseif not enabled and TastyButtons_Settings["ResourceHandler"] then
		TastyButtons.Pcall(UnregisterEventHandler, SystemData.Events.PLAYER_CAREER_RESOURCE_UPDATED,"TastyButtons.OnCareerResourceUpdated")	 
		TastyButtons_Settings["ResourceHandler"] = false
	end
end

-- just to enable or disable the addon  but with some functionalty :D
function TastyButtons.ToggleEnabled(args)
	if args == "on" then
			TastyButtons_Settings["enabled"] = true
			TastyButtons.RegisterEventHandlers()
			TastyButtons.Load()
			TastyButtons.Print("TastyButtons is now enabled")
	  elseif args == "off" then
			TastyButtons_Settings["enabled"] = false
			TastyButtons.UnLoad()
			TastyButtons.Print("TastyButtons is now disabled")	
	  else
		if TastyButtons_Settings["enabled"] == true then
			TastyButtons_Settings["enabled"] = false
			TastyButtons.UnLoad()
			TastyButtons.Print("TastyButtons is now disabled")
		else
			TastyButtons_Settings["enabled"] = true
			TastyButtons.RegisterEventHandlers()
			TastyButtons.Load()
			TastyButtons.Print("TastyButtons is now enabled")
		end
	end	
end

function TastyButtons.Button_Set_Texture_fromTable(buttonTable, isCustom, isRound)
	for _,buttonSlot in pairs(buttonTable) do
		TastyButtons.Button_Set_Texture(buttonSlot, isCustom, isRound)
	end
end

function TastyButtons.Button_Set_Texture(buttonSlot, isCustom, isRound)
	local button = TastyButtons.Button_Get_ButtonObjectByName(ButtonNameStart..buttonSlot)
	if button ~= nil then
		buttonTextures[button:GetSlot()] = {}
		buttonTextures[button:GetSlot()] = {isRound = isRound, isCustom =isCustom}
		TastyButtons.Button_Save(button)
		TastyButtons.PrintD(buttonTextures)
	end
end

-- this is just to set the button scale :d
function TastyButtons.Button_SetScale(buttonSlot,scale)
	button = TastyButtons.Button_Get_ButtonObjectByName(ButtonNameStart..buttonSlot)
	button:SetScale(tonumber(scale))
	button:Save()
end

function TastyButtons.Button_SetScale_fromTable(buttonTable,scale)
	for _,buttonSlot in pairs(buttonTable) do
		TastyButtons.Button_SetScale(buttonSlot,scale)
	end
end

function TastyButtons.Button_makeTable(firstButton, lastButton)
	local buttonTable = {}
	if firstButton and lastButton then
		for buttonSlot = firstButton, lastButton do
			table.insert(buttonTable,buttonSlot)
		end
	end	
	return buttonTable
end

function TastyButtons.CopyActionBars(isCustom,isRound)
	--delete all buttons i has :<
	d("Copy ActionBars Called")
		TastyButtonsParser.Button_Delete_makeTable("all","del")
		for k in pairs(TastyButtons_Save) do TastyButtons_Save[k]=nil end
		TastyButtons_Save_Anchors={} 
	--delete all buttons i has :<
	
	--get strange table
	local buttonStateTable=TastyButtons.GetButtonStateTableFromServer()
	--d("first element in newly created buttonStateTable:")
	--d(buttonStateTable[1])
	--prepare variables for making buttons
	local scale=nil
	local firstButton=1
	local lastButton=0
	for _,_ in pairs(buttonStateTable) do
		lastButton=lastButton+1
	end
	--local lastButton=#buttonStateTable
	--d("lastButton: "..tostring(lastButton))
	local buttonTable = TastyButtons.Button_makeTable(firstButton, lastButton)
	
	--d("calling TastyButtons.Button_Create_fromTable(buttonTable,scale)")
	TastyButtons.Button_Create_fromTable(buttonTable,scale,isCustom, isRound)
	
	local buttonAnchorTable={}
	local buttonTable = {}
	local rows = 1
	local rowdirection = "Right"
	local columndirection = "Down"
	--create normal bar arrangement
	local layoutmode=ActionBarClusterManager:GetLayoutMode ()

	if layoutmode == LAYOUT_MODE_2_ACTION_BARS_STACKED then

		for i = 1,24 do table.insert(buttonTable,i) end
		rows = 2
		
		local buttonAnchorTable = TastyButtons.Button_Anchor_makeBlockTable(buttonTable, 0, 0, columndirection, rowdirection, 12, rows)
		TastyButtons.Button_Anchor_fromTable(buttonAnchorTable)

	  elseif layoutmode ==  LAYOUT_MODE_2_ACTION_BARS then

		for i = 1,24 do table.insert(buttonTable,i) end
		rows = 1
		local buttonAnchorTable = TastyButtons.Button_Anchor_makeBlockTable(buttonTable, 0, 0, columndirection, rowdirection, 24, rows)
		TastyButtons.Button_Anchor_fromTable(buttonAnchorTable)
		
	  
	  elseif layoutmode ==	LAYOUT_MODE_4_ACTION_BARS then

		for i = 1,48 do table.insert(buttonTable,i) end
		rows = 2
		local buttonAnchorTable = TastyButtons.Button_Anchor_makeBlockTable(buttonTable, 0, 0, columndirection, rowdirection, 24, rows)
		TastyButtons.Button_Anchor_fromTable(buttonAnchorTable)	

	  else

		for i = 1,12 do table.insert(buttonTable,i) end
		rows = 2
		
		local buttonAnchorTable = TastyButtons.Button_Anchor_makeBlockTable(buttonTable, 0, 0, columndirection , rowdirection, 12, rows)
		TastyButtons.Button_Anchor_fromTable(buttonAnchorTable)
	end
	

	--------------------------------
	
	
	--d("calling TastyButtons.Set_ButtonStateTable(buttonStateTable)")
	TastyButtons.Set_ButtonStateTable(buttonStateTable)
	
	--d("calling TastyButtons.Button_Save_All()")
	TastyButtons.Button_Save_All(true)
	--d("table now:"..tostring(TastyButtons.GetButtonStateTable()))
	--d("calling TastyButtons.Button_State_Load_activeCurrentState_forAll()")
	TastyButtons.Button_State_Load_activeCurrentState_forAll()
end

-- helper function for TastyButtons.CopyActionBars()
function ActionBarStanceSwaps:Tasty_GetSwaps ()
	return self.m_Swaps
end
function TastyButtons.GetButtonStateTableFromServer()
	local amountOfBarsTable={	[LAYOUT_MODE_1_ACTION_BAR]			= 1,
								[LAYOUT_MODE_2_ACTION_BARS]			= 2,
								[LAYOUT_MODE_2_ACTION_BARS_STACKED]	= 2,
								[LAYOUT_MODE_4_ACTION_BARS]			= 4}
	local buttonStateTable={}
--[[	This holds the buttonStates of the button (Used for saving, checking and so on
	Key 1 is the ButtonSlot,Key 2 is the Name of the Stance, Key 3 is the name of State
	buttonStateTable[buttonSlot][currentStateType][stanceName][stateName] =  {	actionId, 		<== the actionId of the ability/item/macro wuteva 
																	iconNum,		<== the icon Number according to the actionId
																	actionType}		<== the Type of the action (captain obvious ftw!)
	stances normal and clear should ALWAYS be in the table. State normal is the default state of the button.
	Stance clear is a "clean" state of the button. aka actionId, iconNum and actionType = [0,0,0]
--]]	
	local layoutmode=ActionBarClusterManager:GetLayoutMode ()
	local amountOfBars=amountOfBarsTable[layoutmode]
	local stanceNameTable=TastyButtons.Get_stanceNameTable()
	local swaps=ActionBarStanceSwaps:Tasty_GetSwaps()
	
	--local oldPage=GetHotbarPage(1)	-- save current logical page on bar1, i will use bar 1 to flip through all pages.
	
	-- get normal pages
	for i=1,amountOfBars do
		--SetHotbarPage(1,i)				--get i. page
		for x=1,GameData.HOTBAR_BUTTONS_PER_BAR do
			local slot=(i-1)*GameData.HOTBAR_BUTTONS_PER_BAR+x
			local actionType,actionId=GetHotbarData(slot)
			local iconNum=TastyButtonsButton:GetIcon(slot, actionType,actionId)
			buttonStateTable[slot]={
				PvE={

				}
			}
			buttonStateTable[slot]["PvE"][stanceNameTable[0]]=
				{
					default={
						actionId=actionId,
						iconNum=iconNum,
						actionType=actionType,
						showing=true
					}
				}
			buttonStateTable[slot]["PvE"]["clear"]	=	{}	
			buttonStateTable[slot]["PvE"]["clear"]["default"]	=	{  	actionId = 0, iconNum = 0, actionType = 0, showing=true}
			--TastyBars[i][x+1]={actionType=actionType,actionId=actionId}
		end
	end
	
	--get stance pages
	for id,name in pairs(stanceNameTable) do
--[[		if id==0 then d("skipping empty stance")break end							--skip empty stance
		if GetAbilityData(id).id==0 then d("skipping unknown stance: "..name) break end		--skip stances not known to this character
		if swaps[id]==1 then d("skipping useless stance: "..name)  break end					--skip if stance does not change the page]]--
		if not ((id==0) or (GetAbilityData(id).id==0) or (swaps[id]==1)) then
					local i=swaps[id][1]
					d("adding stance: "..name)
					for x=1,GameData.HOTBAR_BUTTONS_PER_BAR do
						local slot=(i-1)*GameData.HOTBAR_BUTTONS_PER_BAR+x
						local actionType,actionId=GetHotbarData(slot)
						local iconNum=TastyButtonsButton:GetIcon(slot, actionType,actionId)
						slot=x
						buttonStateTable[slot]["PvE"][name]=
							{
								default={
									actionId=actionId,
									iconNum=iconNum,
									actionType=actionType,
									showing=true
								}
							}
					end
		end
	end
	--SetHotbarPage(1,oldPage)
	return buttonStateTable
end
--------- MY PERSONAL TEST FUNCTION --------------
--------- DO NOT TOUCH THIS FAG!!!!!!!!!!!--------------

function TastyButtons.OnCooldown(abilityId, onCooldown,isGlobal)
	if isGlobal then
		return
	end
	local abilityId = abilityId
	local onCooldown = onCooldown
	local lstanceName, lstateName
	TastyButtons.PrintD("abilityId "..abilityId.."    cd "..tostring(onCooldown))
	if ((abilityId ~= nil) and (onCooldown ~= nil)) then
		if onCooldown then 
			OnCooldownSkills[abilityId] = onCooldown
		  else
			OnCooldownSkills[abilityId] = nil
		end
		for buttonSlot in pairs(currentButtonStateTable) do
			lstanceName  = currentButtonStateTable[buttonSlot]["stance"]
--[[			TastyButtons.PrintD("-------------------------------------")
			TastyButtons.PrintD("In for!!!")
			TastyButtons.PrintD("buttonSlot "..buttonSlot)
			TastyButtons.PrintD("lstanceName "..lstanceName)
			LibCooldown.PrintTable(buttonStateTable[buttonSlot][lstanceName]["default"])
			TastyButtons.PrintD("abilityId of table: "..buttonStateTable[buttonSlot][lstanceName]["default"]["actionId"])
			TastyButtons.PrintD("abilityId "..abilityId)
			TastyButtons.PrintD("-------------------------------------")
--]]
			if ((currentButtonStateTable[buttonSlot]["state"] ~= "OnCooldown") and (currentButtonStateTable[buttonSlot]["state"] ~= "default")) then
				return
			end
			if (buttonStateTable[buttonSlot][currentButtonStateTable[buttonSlot]["stateType"]][lstanceName]["default"]["actionId"] == abilityId)
				then
				TastyButtons.PrintD("Ability found!")
				if onCooldown then
--					TastyButtons.PrintD("Cooldown started, buttonSlot is "..buttonSlot)
--					LibCooldown.PrintTable(currentButtonStateTable[buttonSlot])
--					TastyButtons.PrintD("Cooldown started, ability found")
					if buttonStateTable[buttonSlot][currentButtonStateTable[buttonSlot]["stateType"]][lstanceName]["OnCooldown"] ~= nil then
--						TastyButtons.PrintD("setting "..buttonName.." to stance: "..lstanceName)
						TastyButtons.Button_State_Load(buttonSlot, lstanceName, "OnCooldown")
					end
				
				  else
					lstanceName = currentButtonStateTable[buttonSlot]["stance"]
					lstateName 	= currentButtonStateTable[buttonSlot]["state"]
--					TastyButtons.PrintD("lstanceName: "..lstanceName)
--					TastyButtons.PrintD("matchedlstateName: "..lstateName)
					if (buttonStateTable[buttonSlot][currentButtonStateTable[buttonSlot]["stateType"]][lstanceName]["default"]["actionId"] == abilityId) then
--						TastyButtons.PrintD("Cooldown stopped, ability found")
						TastyButtons.Button_State_Load(buttonSlot, lstanceName, "default")
					end
				end				
			end
		end	
	end
end 

function TastyButtons.Button_State_Load_activeCurrentState_forAll()
	for buttonSlot in pairs(buttonStateTable) do
		TastyButtons.Button_State_Load_activeCurrentState(buttonSlot)
	end
end

function TastyButtons.Button_State_Load_activeCurrentState(buttonSlot)
	local stance, stateType
	local state = "default"
	-- Checking the stateType --
	TastyButtons.PrintD("currentStateType is: "..currentStateType)
	if buttonStateTable[buttonSlot][currentStateType] ~= nil then
		stateType = currentStateType 
		TastyButtons.PrintD("stateType is set to:"..stateType)
	  else
		stateType = stateTypeTable["PvE"]
	end
	--Checking the Stance --
	if buttonStateTable[buttonSlot][stateType][stanceNameTable[currentStance]] ~= nil then
		stance = stanceNameTable[currentStance]
	  else
	    stance = stanceNameTable[0] 
	end
	local petName = tostring(currentPet)
	
	if buttonStateTable[buttonSlot][stateType][stance][petName] ~= nil then
		state = tostring(currentPet)
	end
	local showing = buttonStateTable[buttonSlot][stateType][stance][state]["showing"] 
	currentButtonStateTable[buttonSlot] = { stance = stance, state = state, stateType = stateType, showing = showing}
	TastyButtons.Button_State_Load(buttonSlot, stance, state, stateType)
end

function TastyButtons.Button_State_Load_fromTable(buttonTable, stanceName, stateName,stateType)
	for buttonSlot in pairs(buttonTable) do
		TastyButtons.Button_State_Load(buttonTable[buttonSlot], stanceName, stateName,stateType)
	end
end

-- Sets and Loads the Current Stance/State Combo --
function TastyButtons.Button_State_Load(buttonSlot, stanceName, stateName,stateType)
	if stateType == nil then
		stateType = currentButtonStateTable[buttonSlot]["stateType"]
	end
	if TastyButtons_Settings["enabled"]	then
		if ((buttonStateTable[buttonSlot][currentButtonStateTable[buttonSlot]["stateType"]] ~= nil) and (buttonStateTable[buttonSlot][currentButtonStateTable[buttonSlot]["stateType"]][stanceName] ~= nil) 
		and (buttonStateTable[buttonSlot][currentButtonStateTable[buttonSlot]["stateType"]][stanceName][stateName] ~= nil)) then
			local actionId = buttonStateTable[buttonSlot][stateType][stanceName][stateName]["actionId"]
			local iconNum	= buttonStateTable[buttonSlot][stateType][stanceName][stateName]["iconNum"]
			local actionType = buttonStateTable[buttonSlot][stateType][stanceName][stateName]["actionType"]
			local showing = buttonStateTable[buttonSlot][stateType][stanceName][stateName]["showing"]
			if hiddenButtonTable[buttonSlot] ~= nil then
				showing = false
			end
			if ((actionId ~= nil) and ( iconNum ~= nil) and (actionType ~= nil)) then
				currentButtonStateTable[buttonSlot]["stance"] = stanceName
				currentButtonStateTable[buttonSlot]["state"] = stateName
				local button = TastyButtons.Button_Get_ButtonObjectByName(ButtonNameStart..buttonSlot)
				button:SetState(actionId ,iconNum ,actionType, stateName, showing)
				TastyButtons.PrintD("State "..stateName.." in stance "..stanceName.." loaded for Button "..buttonSlot)
			end
	      else
			TastyButtons.PrintD("State does not exist for Button "..buttonSlot)
		end
	end
end

function TastyButtons.Button_State_Modify_fromTable(buttonTable, stanceName, stateName, stateType, showing)
	for buttonSlot in pairs(buttonTable) do
		TastyButtons.Button_State_Modify(buttonTable[buttonSlot], stanceName, stateName, stateType, showing)
	end
end

function TastyButtons.Button_State_Modify(buttonSlot, stanceName, stateName,stateType,showing)
	d("Modifying State")
	if buttonStateTable[buttonSlot][stateType][stanceName][stateName] ~= nil then
		buttonStateTable[buttonSlot][stateType][stanceName][stateName]["showing"] = showing
		button = TastyButtons.Button_Get_ButtonObjectByName(ButtonNameStart..buttonSlot)
		TastyButtons.Button_Save(button)
	end
end

function TastyButtons.Button_State_Clear_fromTable(buttonTable, stanceName, stateName,stateType)
	for buttonSlot in pairs(buttonTable) do
		TastyButtons.Button_State_Clear(buttonTable[buttonSlot], stanceName, stateName,stateType)
	end
end

-- Clears a Stance/State Combo of Button --
function TastyButtons.Button_State_Clear(buttonSlot, stanceName, stateName,stateType,showing)
	if showing == nil then
		showing = true
	end
	if ((buttonStateTable[buttonSlot][stateType][stanceName] ~= nil) and (buttonStateTable[buttonSlot][stateType][stanceName][stateName] ~= nil)) then
		buttonStateTable[buttonSlot][stateType][stanceName][stateName]	=	{	actionId 	= 0, iconNum = 0, actionType = 0, showing = showing}
		local button = TastyButtons.Button_Get_ButtonObjectByName(ButtonNameStart..buttonSlot)
		button:Save()
	end
	TastyButtons.Button_State_Load(buttonSlot, currentButtonStateTable[buttonSlot]["stanceName"], currentButtonStateTable[buttonSlot]["stateName"])
end


function TastyButtons.Pcall(command,...)
	local success, errmsg,ret2,ret3,ret4 = pcall(command,...)
	if not success then
		TastyButtons.Print("TastyButtons produced an error:")
		TastyButtons.Print(errmsg)
	else
		return errmsg,ret2,ret3,ret4
	end
end

function TastyButtons.Button_SetShowing_fromTable(buttonTable,showing)
	for _,buttonSlot in pairs(buttonTable) do
		TastyButtons.Button_SetShowing(buttonSlot,showing)
	end
end

function TastyButtons.Button_SetShowing(buttonSlot,showing)
	local buttonName = ButtonNameStart..buttonSlot
	WindowSetShowing(buttonName, showing)
	if showing == false then
		hiddenButtonTable[buttonSlot] = buttonSlot
	  else
		hiddenButtonTable[buttonSlot] = nil		
	end
end

function TastyButtons.Button_MakeInvisible_fromTable(buttonTable, makeInvisible)
	for _,buttonSlot in pairs(buttonTable) do
		TastyButtons.Button_MakeInvisible(buttonSlot,makeInvisible)
	end
end

function TastyButtons.Button_MakeInvisible(buttonSlot,makeInvisible)
	if buttonHandles[buttonSlot] ~= nil then
		if makeInvisible then
			buttonScale[buttonSlot] = buttonHandles[buttonSlot]:GetScale()
			TastyButtons.Button_SetScale(buttonSlot,0.01)
		  else
			local scale = InterfaceCore.GetScale()
			if buttonScale[buttonSlot] ~= nil  and  buttonScale[buttonSlot] >= 0.1 then
				scale = buttonScale[buttonSlot]
			end
			TastyButtons.Button_SetScale(buttonSlot, scale)
		end
	  else
		d("Button "..buttonSlot.." does not exist")
	end
end

------------------- BULLSHIT --------------------

function TastyButtons.Test(args)

end

--[[
Magus Pet Names:
Flamer, Pink Horror, Blue Horror, Daemonic Infestation

local petNameTable = {	[16] 	= 	{L"Flamer", L"Pink Horror", L"Blue Horror", L"Daemonic Infestation"},
						[8]		=	{L"Squig", L"Horned Squig", L"Spiked Squig", L"Gas Squig"},
						[4]		=	{L"Gun Turret", L"Flame Turret", L"Bombardment Turret", L"Land Mine",L"Keg O' Stout",L"Lightning Rod"}
					 }

local petTable	=	{	[1828] = "Farty Squig",
					[1841] = "Summon Squig"
					[1842] = "Horned Squig"
					[1843] = "Gas Squig"
					[1844] = "Spiked Squig"


				}
Pet Summon Event Triggered 2 times:
TastyButtons.Pcall(RegisterEventHandler, SystemData.Events.PLAYER_PET_UPDATED,"TastyButtons.Test2")
--]]
