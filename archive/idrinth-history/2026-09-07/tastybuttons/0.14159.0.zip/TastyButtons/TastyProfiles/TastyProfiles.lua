if not TastyProfiles then TastyProfiles={} end
if not TastyButtonsProfiles then TastyButtonsProfiles = {} end

local	serverName,_ = string.gsub(tostring(SystemData.Server.Name), "-", "_")
		serverName,_ = string.gsub(serverName, " ", "_")

local ButtonNameStart = "TastyButtons_"..serverName.."__"..(tostring(GameData.Player.name)).."_Button_"		
local saveName = (serverName).."__"..(tostring(GameData.Player.name))

function TastyProfiles.OnInitialize()
	
end


function TastyProfiles.SaveProfile(profileName, settingsTable, buttonTable)
	
	TastyButtonsProfiles[profileName] = {}
	TastyButtonsProfiles[profileName]["settings"]	= DataUtils.CopyTable(settingsTable)
	TastyButtonsProfiles[profileName]["buttons"] 	= DataUtils.CopyTable(buttonTable)

end

function TastyProfiles.DeleteProfile(profileName)
	TastyButtonsProfiles[profileName] = nil
end

function TastyProfiles.Clean_Profile(buttonTable)
	local accomodatedTable = {}
	for buttonName, buttonData in pairs(buttonTable) do
		local newButtonName = ButtonNameStart..buttonName:match("(%d+)")
		accomodatedTable[newButtonName] = DataUtils.CopyTable(buttonData)
	end
	return accomodatedTable
end


function TastyProfiles.LoadProfile(profileName)
	if TastyButtonsProfiles[profileName]["settings"]  ~= nil and TastyButtonsProfiles[profileName]["buttons"] ~= nil then
		local settingsTable = DataUtils.CopyTable(TastyButtonsProfiles[profileName]["settings"])
		local buttonsTable = TastyProfiles.Clean_Profile(DataUtils.CopyTable(TastyButtonsProfiles[profileName]["buttons"]))
		return settingsTable, buttonsTable
	  else
		d("Profile: "..profileName.."does not exist")
		return false
	end
end



function TastyProfiles.OnShutdown()
	d("Save Save! GoGo Power - Rangers")
end

