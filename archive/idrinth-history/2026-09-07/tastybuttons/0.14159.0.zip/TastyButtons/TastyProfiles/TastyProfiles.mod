<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
	<UiMod name="TastyProfiles" version="1.0" date="03/03/2009" >

		<Author name="MrOffline" email="i@m.hungry" />
		<Description text="Load and Save Profile for TastyButtons" />

		<Files>
			<File name="TastyProfiles.lua" />
		</Files> 
		
		<SavedVariables>
			<SavedVariable name="TastyButtonsProfiles" />
		</SavedVariables>
		
		<OnInitialize>
			<CallFunction name="TastyProfiles.Initialize" />
		</OnInitialize>
		
	</UiMod>
</ModuleFile>
