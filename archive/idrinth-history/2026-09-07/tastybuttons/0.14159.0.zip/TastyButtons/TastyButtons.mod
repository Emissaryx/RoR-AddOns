<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
	<UiMod name="TastyButtons" version="0.14159" date="03/03/2009" >

		<Author name="MrOffline & mrrattlz" email="email@is.not.good" />
		<Description text="Ultimate control of Actionbars! Create you own Actionbars, add stances and states, scale them idependently and group them as you wish!" />
        
        <Dependencies>
            <Dependency name="LibSlash" />
			<Dependency name="LibCooldown" />
			<Dependency name="EA_ActionBars" />
			<Dependency name="Phantom" />
			<Dependency name="TastySettings" />
			<Dependency name="TastyProfiles" />
        </Dependencies>
        
		<Files>
			<File name="Textures.xml" />
			<File name="CustomTextures\CustomTextures.xml" />
			<File name="TastyButtons.lua" />
			<File name="TastyButtonsButton.lua" />
			<File name="TastyButtonsParser.lua" />			
			<File name="TastyButtonsOptions.lua" />
			<File name="TastyButtonsOptions.xml" />
			<File name="TastyButtonsButtonTemplate.xml" />
			<File name="CustomTextures\CustomTextures.lua" />
			<File name="CustomTextures\TastyButtonsButtonTemplate.xml" />
		</Files>
		
		<OnInitialize>
            <CallFunction name="TastyButtons.Initialize" />
            <CallFunction name="TastyButtonsOptions.Initialize" />
		</OnInitialize>
		<OnUpdate>
            <CallFunction name="TastyButtons.OnUpdate" />
        </OnUpdate>
		<OnShutdown/>
		
		<SavedVariables>
			<SavedVariable name="TastyButtons_CharacterSettings" />
		</SavedVariables>
	
	</UiMod>
</ModuleFile>