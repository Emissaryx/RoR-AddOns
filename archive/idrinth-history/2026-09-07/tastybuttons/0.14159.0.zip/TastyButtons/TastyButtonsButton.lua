TastyButtonsButton = ActionButton:Subclass("ActionButton")
--[[
local TradeSkillTooltips = --see itemtooltips.lua if this changes, used in this : function Tooltips.CreateTradeskillTooltip (tradeSkillId, anchor)
{
    { name = GetString (StringTables.Default.LABEL_SKILL_BUTCHERING),           desc = GetString (StringTables.Default.TOOLTIP_SKILL_BUTCHERING),   },
    { name = GetString (StringTables.Default.LABEL_SKILL_SCAVENGING),           desc = GetString (StringTables.Default.TOOLTIP_SKILL_SCAVENGING),   },
    { name = GetString (StringTables.Default.LABEL_SKILL_CULTIVATION),          desc = GetString (StringTables.Default.TOOLTIP_SKILL_CULTIVATION),  },
    { name = GetString (StringTables.Default.LABEL_SKILL_APOTHECARY),           desc = GetString (StringTables.Default.TOOLTIP_SKILL_APOTHECARY),   },
    { name = GetString (StringTables.Default.LABEL_SKILL_TALISMAN),             desc = GetString (StringTables.Default.TOOLTIP_SKILL_TALISMAN),     },
    { name = GetString (StringTables.Default.LABEL_SKILL_SALVAGING),            desc = GetString (StringTables.Default.TOOLTIP_SKILL_SALVAGING),    },
}
]]--

local buttonTintColorR = 139
local buttonTintColorG = 139
local buttonTintColorB = 0
local currentState
local ABCMode = false
local showOnEmpty = true
local tintIconOnly = false
local stateShowing
local ABCTint = { ["r"] = 225, ["g"] = 0, ["b"] = 0 }
local OORTint = { ["r"] = 125, ["g"] = 125, ["b"] = 125 }

local CursorSourceTranslation = --see actionbutton.lua
{
    [Cursor.SOURCE_ACTION_LIST] = GameData.PlayerActions.DO_ABILITY,
    [Cursor.SOURCE_EQUIPMENT]   = GameData.PlayerActions.USE_ITEM,
    [Cursor.SOURCE_INVENTORY]   = GameData.PlayerActions.USE_ITEM,
    [Cursor.SOURCE_QUEST_ITEM]  = GameData.PlayerActions.USE_ITEM,    
    [Cursor.SOURCE_MACRO]       = GameData.PlayerActions.DO_MACRO,
    [Cursor.SOURCE_CRAFTING]    = GameData.PlayerActions.DO_CRAFTING,
    
    -- The action-type keys are also in this table in case the cursor was created with one of them as the 
    -- source type!
    
    [GameData.PlayerActions.DO_ABILITY]     = GameData.PlayerActions.DO_ABILITY,
    [GameData.PlayerActions.USE_ITEM]       = GameData.PlayerActions.USE_ITEM,
    [GameData.PlayerActions.DO_MACRO]       = GameData.PlayerActions.DO_MACRO,
    [GameData.PlayerActions.DO_CRAFTING]    = GameData.PlayerActions.DO_CRAFTING,
}
local INITIAL_COOLDOWN_ALPHA    = .9
local BASE_COOLDOWN_ALPHA       = .1


local BASE_ICON         = 0
local BUTTON_TEXT       = 1
local COOLDOWN          = 2
local COOLDOWN_TIMER    = 3
local FLASH_ANIM        = 4
local ACTIVE_ANIM       = 5
local GLOW_ANIM         = 6
local STACK_COUNT_TEXT  = 7

local USE_ENABLED_ICON  = 42
local USE_DISABLED_ICON = 84
local USE_EMPTY_ICON    = 168


local COLOR_IT_VALID    = true
local COLOR_IT_INVALID  = false

local noTimeIndicator = false

local ActionButtonTooltipCreators =
{   
    [GameData.PlayerActions.DO_ABILITY] = function (actionId, clickText, anchor)
        local abilityData = Player.GetAbilityData (actionId)
                
        if (abilityData ~= nil) 
        then            
            Tooltips.CreateAbilityTooltip (abilityData, SystemData.MouseOverWindow.name, anchor, clickText)
        end    
    end,
    
    [GameData.PlayerActions.USE_ITEM] = function (actionId, clickText, anchor, slot)
        local itemData = DataUtils.FindItem (actionId)
        local cacheThisItem = true
        
        if (itemData == nil) 
        then
            itemData = GetCachedData (GameData.PlayerActions.USE_ITEM, actionId, "itemData")
            cacheThisItem = false
        end
        
        if (itemData ~= nil)
        then
            Tooltips.CreateItemTooltip (itemData, SystemData.MouseOverWindow.name, anchor, true, clickText)
            
            if (cacheThisItem == true)
            then
                CacheData (GameData.PlayerActions.USE_ITEM, actionId, "itemData", DataUtils.CopyTable (itemData))
            end
        end
    end,
    
    [GameData.PlayerActions.DO_MACRO] = function (actionId, clickText, anchor)
        local macroTable    = DataUtils.GetMacros ()
        local macroData     = macroTable[actionId]
        
        if (macroData ~= nil) 
        then            
            Tooltips.CreateMacroTooltip (macroData, SystemData.MouseOverWindow.name, anchor, clickText)
        end    
    end,
    
    [GameData.PlayerActions.DO_CRAFTING] = function (actionId, clickText, anchor)
        Tooltips.CreateTradeskillTooltip (actionId, anchor)
    end,
    
    [GameData.PlayerActions.COMMAND_PET] = function (actionId, clickText, anchor)
        -- This function is the devil
        local line1 = L""
        local line2 = L""
        local line3 = L""
        if (actionId == GameData.PetCommand.STAY) then
            line1 = GetString( StringTables.Default.LABEL_PET_STAY )
            line2 = GetString( StringTables.Default.TEXT_PET_STAY ) 
            line3 = L"("..SystemData.Settings.Keybindings.PET_STAY.bindings[1]..L")"
        elseif (actionId == GameData.PetCommand.FOLLOW) then
            line1 = GetString( StringTables.Default.LABEL_PET_FOLLOW )
            line2 = GetString( StringTables.Default.TEXT_PET_FOLLOW )   
            line3 = L"("..SystemData.Settings.Keybindings.PET_FOLLOW.bindings[1]..L")"
        elseif (actionId == GameData.PetCommand.ATTACK) then
            line1 = GetString( StringTables.Default.LABEL_PET_ATTACK )
            line2 = GetString( StringTables.Default.TEXT_PET_ATTACK )
            line3 = L"("..SystemData.Settings.Keybindings.PET_ATTACK.bindings[1]..L")"
		elseif (actionId == GameData.PetCommand.PASSIVE ) then
			line1 = L"Passive"
			line2 = L"Set's you pet to the Passive State"
		elseif (actionId == GameData.PetCommand.AGGRESSIVE ) then
			line1 = L"Aggressive"
			line2 = L"Set's you pet to the Aggressive State"		
			line3 = L"Greetz to everyone from #waruidev"
		elseif (actionId == GameData.PetCommand.DEFENSIVE ) then
			line1 = L"Defensive"
			line2 = L"Set's you pet to the Defensive State"	
			line3 = L"Thanks Ratty for your help and your Textures"
		elseif (actionId == GameData.PetCommand.RELEASE ) then
 			line1 = L"Release"
			line2 = L"Releases your Pet"
			line3 = L"Captain Obvious to the Rescue"
		end

        Tooltips.CreateTextOnlyTooltip( SystemData.MouseOverWindow.name )
        Tooltips.SetTooltipText( 1, 1, line1)
        Tooltips.SetTooltipColorDef( 1, 1, Tooltips.COLOR_HEADING )
        Tooltips.SetTooltipText( 2, 1, line2)
        Tooltips.SetTooltipText( 3, 1, line3)
        Tooltips.SetTooltipColor( 3, 1, 140, 100, 0 ) 
        Tooltips.Finalize()    
        Tooltips.AnchorTooltip (anchor)
    end,
    
    [GameData.PlayerActions.COMMAND_PET_DO_ABILITY] = function (actionId, clickText, anchor)
        local abilityData = Player.GetAbilityData (actionId)
        
        if (abilityData ~= nil)
        then
            local text = GetString( StringTables.Default.TEXT_PET_ABILITY_FLASH )
            Tooltips.CreateAbilityTooltip (abilityData, SystemData.MouseOverWindow.name, anchor, text)
        end
    end,
}


function TastyButtonsButton:Create (windowName, parentName, hotbarSlot, allowableModifications,isCustom,isRound)
	
	self.m_isCustom = 	(isCustom==true)
	self.m_isRound 	= 	(isRound==true)
	
	if self.m_isCustom then
		if self.m_isRound then
			self.m_Template="TastyButtonCustomRound"
		else
			self.m_Template="TastyButtonCustomRect"
		end
	elseif self.m_isRound then
		self.m_Template="TastyButtonRound"
	else
		self.m_Template="TastyButtonRect"
	end
	
	-- delete possibly existing stuff from the framemanager to prevent asserting errors when debug library is loaded
	-- todo: should be moved to the delete function if possible, or add TastyButtonsButton:Destroy and call it from the delete function
		local framesToDelete={	windowName.."ActionIcon",
								windowName.."ActionText",
								windowName.."ActionCooldown",
								windowName.."ActionCooldownTimer",
								windowName.."ActionCount",
								windowName.."OverlayFlash",
								windowName.."OverlayActive",
								windowName.."OverlayGlow",
								windowName.."Action",
								windowName
								}
		for k=1 , #framesToDelete do
			FrameManager.m_Frames[framesToDelete[k]]=nil
		end
	---------------------------
	
	local tastyButton=ActionButton.Create (self,windowName, parentName, hotbarSlot, allowableModifications)
	tastyButton.m_isCustom=self.m_isCustom
	tastyButton.m_isRound=self.m_isRound
	return tastyButton
end


function TastyButtonsButton:Update (timeElapsed, updateCooldown, updateInventory, previousResource, currentResource)
    if (self.m_ActionId ~= 0) then
	local isEnabled=true
	local isTargetValid=true
	--DANIELS CODE:
		if self:GetActionType()==GameData.PlayerActions.DO_ABILITY then
			isEnabled=IsAbilityEnabled(self:GetActionId())
			isTargetValid=IsTargetValid(self:GetActionId())
			
		-------------------------------------------
	        self:UpdateCooldownAnimation (timeElapsed, updateCooldown)
	        self:UpdateActiveAbilityAnimation ()
	        self:UpdateBurning (previousResource, currentResource)
        elseif self:GetActionType()==GameData.PlayerActions.USE_ITEM then
			self:UpdateCooldownAnimation (timeElapsed, updateCooldown)
			
		elseif self:GetActionType() == GameData.PlayerActions.COMMAND_PET_DO_ABILITY or self:GetActionType() == GameData.PlayerActions.COMMAND_PET then
			self:UpdateActiveAbilityAnimation ()
		end
		self:UpdateEnabledState (isEnabled, isTargetValid)
        if (updateInventory) 
        then
            self:UpdateInventory ()
        end
    end
    
	if not showOnEmpty then
		if self:GetActionId() == 0 then 
			self:SetShowing(false)
		  else
			if not stateShowing then
				self:SetShowing(true)
			end
		end
	end
	
    self.m_RequiresFullUpdate = false
end


function TastyButtonsButton:UpdateEnabledState (isSlotEnabled, isTargetValid)
    local iconType = USE_ENABLED_ICON
    self.m_IsEnabled        = isSlotEnabled
    self.m_IsTargetValid    = isTargetValid

    if (not isSlotEnabled)
    then
        iconType = USE_DISABLED_ICON
    end
        
    iconType = self:SetIcon (self.m_IconNum, iconType)
    
    if (isSlotEnabled == true)
    then                  
        self.m_Windows[BASE_ICON]:SetTintColor (255, 255, 255)
		--self.m_Windows[BUTTON_TEXT]:SetTextColor (self.m_HotKeyColorR, self.m_HotKeyColorG, self.m_HotKeyColorB)
    elseif ((isSlotEnabled == false) and (iconType == USE_ENABLED_ICON)) -- for missing disabled icons
    then
        self.m_Windows[BASE_ICON]:SetTintColor (buttonTintColorR, buttonTintColorG, buttonTintColorB)
    end
    
    local r = 255
    local g = 0
    local b = 0
    
    -- The number should be white if the target is valid 
    -- or 
    -- if the target is invalid, but it's only because the player doesn't have the required unit type targeted.
    if (isTargetValid == true)
    then
        r = self.m_HotKeyColorR
		g = self.m_HotKeyColorG
		b = self.m_HotKeyColorB
	  else
		self.m_Windows[BASE_ICON]:SetTintColor (buttonTintColorR, buttonTintColorG, buttonTintColorB)
    end
    
    self.m_Windows[BUTTON_TEXT]:SetTextColor (r, g, b)  
	
	if not ABCMode then
		return
	end
	
	if (self.m_IsEnabled == true) and (self.m_IsTargetValid == true) then                  
		self.m_Windows[BASE_ICON]:SetTintColor(255, 255, 255)
	elseif (self.m_IsEnabled == true) then
		-- tint icons for invalid targets red
		self.m_Windows[BASE_ICON]:SetTintColor(ABCTint.r, ABCTint.g, ABCTint.b)
	elseif (self.m_IsEnabled == false) and (iconType == USE_ENABLED_ICON) then
		self.m_Windows[BASE_ICON]:SetTintColor(OORTint.r, OORTint.g, OORTint.b)
	end

end

function TastyButtonsButton:UpdateBurning (previousResource, currentResource)
    if ((previousResource == currentResource) and (not self.m_RequiresFullUpdate))
	--if ((previousResource == currentResource)) --requiresFullUpdate ist mal gerade ausgeschaltet :<
    then
        return
    end
    TastyButtons.PrintD("UpdateBurning")
	--LibCooldown.PrintVariable(previousResource,"previousResource")
	--LibCooldown.PrintVariable(currentResource,"currentResource")
	--LibCooldown.PrintVariable(self.m_RequiresFullUpdate,"self.m_RequiresFullUpdate")
    local glowLevel = 0
    local glowInfo  = EA_CareerResourceData[GameData.Player.career.line]

	--LibCooldown.PrintVariable(glowInfo,"glowInfo")
    if (nil ~= glowInfo) then
        local glowBeginThreshold, glowCap = self:GetGlowLevels ()
        glowLevel = glowInfo:GetGlowLevel (currentResource, CareerResource:GetMaximum (), glowBeginThreshold, glowCap)
	end
    
    local glowFrame = self.m_Windows[GLOW_ANIM]

    if ((glowLevel == 0) and (glowFrame:IsShowing ()))
    then
        glowFrame:StopAnimation (true)
        glowFrame:Show (false)
    elseif ((glowLevel > 0) and ((not glowFrame:IsShowing ()) or (self.m_GlowLevel ~= glowLevel)))
    then
        glowFrame:StopAnimation (true)
        glowFrame:SetAnimationTexture (self.m_GlowBase..glowLevel)
        glowFrame:StartAnimation (0, true, false, 0)
        self.m_GlowLevel = glowLevel
    end             
end

function TastyButtonsButton:UpdateGlowTexture ()
    self.m_GlowBase = "anim_waaagh_" -- For destruction characters...

    if (GameData.Realm.ORDER == GameData.Player.realm) then 
        self.m_GlowBase  = "anim_fury_" -- For Order characters...
    end
    if self.m_isCustom then
		self.m_GlowBase="Tasty_"..self.m_GlowBase
	end
	if self.m_isRound then
		self.m_GlowBase=self.m_GlowBase.."round_"
	end
    -- Default it to animation level 1...
    self.m_Windows[GLOW_ANIM]:SetAnimationTexture (self.m_GlowBase.."1")
end

function TastyButtonsButton:UpdateCooldownAnimation (timeElapsed, updateCooldown)
	local actionName=self:GetName().."Action"
	local overlayName   = self:GetName().."Overlay"

	local cooldownFrame     = self.m_Windows[COOLDOWN]
	local timerFrame        = self.m_Windows[COOLDOWN_TIMER]


    local updateCooldown    = updateCooldown or self.m_RequiresFullUpdate
    
    if (updateCooldown)
    then
        --self.m_Cooldown, self.m_MaxCooldown = LibCooldown.GetActionCooldown (self:GetActionId(),self:GetActionType())
		local Cooldown,MaxCooldown,isGlobal=LibCooldown.GetActionCooldown (self:GetActionId(),self:GetActionType())
		if (((self.m_ShowGlobalCooldown==true) and (isGlobal==true)) or (isGlobal==false)) then
			self.m_Cooldown=Cooldown
			self.m_MaxCooldown=MaxCooldown
		else
			self.m_Cooldown=0
			self.m_MaxCooldown=MaxCooldown
		end
	end
    
    if ((self.m_Cooldown > 0) and (self.m_MaxCooldown > 0))
    then 
        local oldTime       = TimeUtils.FormatRoundedSeconds (self.m_Cooldown, ActionButton.COOLDOWN_GRANULARITY)
        local updateLabel   = false
        
        self.m_Cooldown = self.m_Cooldown - timeElapsed
        
        if (TimeUtils.FormatRoundedSeconds (self.m_Cooldown, ActionButton.COOLDOWN_GRANULARITY) < oldTime)
        then
            updateLabel = true
        end
        
        if (updateLabel or updateCooldown)
        then
            local labelTime
            
            -- The 3 seconds is arbitrary, this just says don't display values like 15.8
            -- only start the fractional cooldown at 3 seconds or less (3.0, 2.5, etc...)
            if (self.m_Cooldown < 3.5)
            then
                _, labelTime = TimeUtils.FormatRoundedSeconds(self.m_Cooldown, ActionButton.COOLDOWN_GRANULARITY, true)
            else
                labelTime = TimeUtils.FormatSeconds(self.m_Cooldown, true)
            end

            if noTimeIndicator then
				labelTime = labelTime:match(L"(%d*[.]?%d+)")
			end

			timerFrame:SetText (labelTime)
        end
        
        local percent   = self.m_Cooldown / self.m_MaxCooldown
        local newAlpha  = (INITIAL_COOLDOWN_ALPHA * percent) + BASE_COOLDOWN_ALPHA
            
        cooldownFrame:SetAlpha (newAlpha)
        cooldownFrame:Show (true)
		
		if tintIconOnly then
			WindowSetTintColor(self:GetName().."ActionIcon",200,0,0)
		  else	
			WindowSetTintColor(self:GetName(),200,0,0)
		end
    elseif (self.m_Cooldown <= 0 and cooldownFrame:IsShowing ())
    then
        cooldownFrame:SetAlpha (INITIAL_COOLDOWN_ALPHA + BASE_COOLDOWN_ALPHA)
        cooldownFrame:Show (false)
        
        self.m_Cooldown     = 0
        self.m_MaxCooldown  = 0
        
        self.m_Windows[FLASH_ANIM]:StartAnimation (0, false, true, 0)
		--AnimatedImage:CreateFrameForExistingWindow (self:GetName().."OverlayFlash"):StartAnimation (0, false, true, 0)
		
		if tintIconOnly then
			WindowSetTintColor(self:GetName().."ActionIcon", 255, 255, 255)
		  else	
			WindowSetTintColor(self:GetName(),255,255,255)
		end		
    end 
end

function TastyButtonsButton:ResetTintColor()
	WindowSetTintColor(self:GetName().."ActionIcon",255,255,255)
	WindowSetTintColor(self:GetName(),255,255,255)
end

function TastyButtonsButton:UpdateIsShowing (parentBar)
  self:Show(true)
end
function TastyButtonsButton:UpdateKeyBindingText ()    
    -- Ignore the second key
    --local action = self:GetActionName ()
	local action = "ACTION_BAR_"..self:GetSlot ()
    local bindings = {}
    
    
    KeyUtils.GetBindingsForAction (action, bindings)
    
    if (#bindings == 0)
    then
        LabelSetText (self:GetName ().."ActionText", L"");
        return
    end
        
    -- Display the first valid keybinding found in the bindings table:
    for bindingId, bindingData in ipairs (bindings)
    do
        -- FIXME: Need to implement "short" keynames.  Ctrl = C, Shift = S, Alt = A ... Ctrl + 1 = C1
        -- And of course that has to be localized...
        if (bindingData.name ~= L"")
        then
            local shortBindingName = KeyUtils.ShortenBindingName (bindingData.name)
            LabelSetText (self:GetName ().."ActionText", shortBindingName)
            break
        end
    end    
end


function TastyButtonsButton:CursorSwap (flags, x, y)
	if (Cursor.IconOnCursor ()) then
		local actionName    = self:GetName ().."Action"
		TastyButtons.PrintD(towstring("You dropped something, asshole!"))
		

        local spellId = Cursor.Data.ObjectId
		TastyButtons.PrintD(towstring("trying to assign ability"))

		local actionType = CursorSourceTranslation[Cursor.Data.Source]
		
		if spellId == nil and actionType == nil then return end

		self.m_ActionId=spellId
		iconId=self:GetIcon(0,actionType,spellId)
				
		self.m_IconNum=iconId
		self.m_ActionType=actionType
		WindowSetGameActionData (actionName, actionType, spellId, L"")
 		self:SetIcon(iconId)
		TastyButtons.PrintD(towstring("clearing cursor"))
        Cursor.Clear ()
		
		
		--                                           evil save function, needs to be changed !!!
		self:SetActionData(actionType,spellId)
		TastyButtons.Button_State_Set(self:GetSlot(), spellId, iconId, actionType, nil, nil,nil)
		self:Save()
	end
end

function TastyButtonsButton:ResizeRelative (startButton)
	local point, relpoint, relwin, xoffset, yoffset = WindowGetAnchor(self:GetName(), 1)
	if startButton ~= nil then
		relwin = ButtonNameStart..startButton
	end
	if ((relwin ~= nil) and (relwin~="Root")) and (string.find(relwin,"LayoutEditor")==nil)then
		TastyButtons.PrintD(towstring("resizing "..(self:GetName()).." relative to "..relwin))
		local scale = WindowGetScale(self:GetName()) / WindowGetScale(relwin)
		WindowSetRelativeScale(self:GetName(),scale) --evil voodoo    WindowSetRelativeScale
	end
	self:Save()
end

----------------- SAVE AND LOAD --------------

function TastyButtonsButton:Save()
	TastyButtons.Button_Save(self)
end


-------------------- Gettahs -------------------------

function TastyButtonsButton:GetSelf()
  return self
end
function TastyButtonsButton:GetisCustom()
  	return self.m_isCustom
end
function TastyButtonsButton:GetisRound()
	return self.m_isRound
end
function TastyButtonsButton:GetActionId()
	return self.m_ActionId
end

function TastyButtonsButton:GetIconNum()
	return self.m_IconNum
end

function TastyButtonsButton:GetActionType()
	return self.m_ActionType
end

function TastyButtonsButton:GetState()
	local state = { self.m_ActionId, self.m_IconNum, self.m_ActionType}
	return	state, currentState
end 

function TastyButtonsButton:GetIcon(slot, actionType,actionId)
--		TastyButtons.PrintD(towstring("--getting icon for:---"))
--		TastyButtons.PrintD(towstring("actionType: "..actionType))
--		TastyButtons.PrintD(towstring("actionId:   "..actionId))
		local icondatas={
			[GameData.PlayerActions.DO_ABILITY] = function (id)
					return Player.GetAbilityData (id) 
				end,
			[GameData.PlayerActions.USE_ITEM]=function (id)
					local itemData=DataUtils.FindItem(id)
			        if (itemData ~= nil)
				        then
				            CacheData (actionType, actionId, "itemData", DataUtils.CopyTable (itemData))
				        else
							itemData=(GetCachedData(actionType,actionId,"itemData"))
						end	
					return itemData
				end,
			[GameData.PlayerActions.DO_MACRO]=function (id)
					return (DataUtils.GetMacros ())[id]
				end,
			[GameData.PlayerActions.DO_CRAFTING]=function (id)
					return {iconNum=GetTradeskillIcon (id)}
				end
		}
		if (actionType==nil) or (actionType==0) then return 0 end
		if not icondatas[actionType] then
			TastyButtons.PrintD(towstring("error in TastyButtonsButton:GetIcon. No Function for this actionType: ("..tostring(type(actionType))..") "..tostring(actionType)))
			return 0
		end
		local icondata=(icondatas[actionType])(actionId)
		if (icondata==nil) then return 0 end
		return icondata.iconNum
end


------------------ Settahs ------------------------------

--[[
--function TastyButtonsButton:SetActionId(actionId)
	self.m_ActionId = actionId
end

--function TastyButtonsButton:SetIconNum(iconNum)
	self.m_IconNum = iconNum
end

--function TastyButtonsButton:SetActionType(actionType)
	self.m_ActionType = actionType
end
]]--
function TastyButtonsButton:SetActionData (actionType, actionId)
    local actionName    = self:GetName ().."Action"
    local slot          = self:GetSlot ()
    
    -- If either actionType/actionId are nil, the button should pull its data
    -- directly from the game
    
    if (actionType == nil or actionId == nil)
    then
			actionId	= self.m_ActionId 
			actionType 	= self.m_ActionType
        --actionType, actionId, self.m_IsEnabled, self.m_IsTargetValid = GetHotbarData (slot)
    end
    
    self.m_ActionType                       = actionType
    self.m_ActionId                         = actionId
    self.m_GlowLevel                        = 0
    self.m_Cooldown                         = 0 
    self.m_RequiresFullUpdate               = true
	if actionType == GameData.PlayerActions.DO_ABILITY then
		self.m_GlowAtXPoints, self.m_GlowCap    = TastyButtonsButton.GetAbilityGlowLevels(actionId) --GetHotbarGlowLevels (slot) TODO: make this dynamic, idiot!
	else
		self.m_GlowAtXPoints, self.m_GlowCap    = 0,0
	end
    self.m_IconNum                          = self:GetIcon (slot, actionType, actionId)
    
    self:UpdateInventory ()
    self:UpdateEnabledState (self.m_IsEnabled, self.m_IsTargetValid)
    self:UpdateIsShowing (self:GetParent ())
    
    WindowSetGameActionData (actionName, actionType, actionId, L"")
    
    if (actionType == 0 and actionId == 0) 
    then
        WindowSetGameActionData (actionName, 0, 0, L"")
        
        self:SetIcon (0)
        
        -- Required because this never hides itself in the regular update cycle...
        --self.m_Windows[FLASH_ANIM]:StopAnimation (Frame.FORCE_HIDE) 
		
		--AnimatedImage:CreateFrameForExistingWindow (self:GetName().."OverlayFlash")
        
        -- Clearing the rest of the window states can be performed with the normally called functions...
        self:UpdateCooldownAnimation (0)
        self:UpdateActiveAbilityAnimation ()
        self:UpdateBurning (0, 0)
    end
    
    -- HACK: For items, temporarily caching their data so they can appear dimmed out on the hotbar
    -- but still have a tooltip.  Doing this is not accurate, but it's not dangerous.
    -- The second reason this is a hack is that ActionButton:SetActionData should remain action-agnostic!
    -- With a limited client-side caching system, this can be removed, and tooltips can still be generated.
    
    if (actionType == GameData.PlayerActions.USE_ITEM)
    then
        local itemData = DataUtils.FindItem (actionId)
        
        if (itemData ~= nil)
        then
            CacheData (actionType, actionId, "itemData", DataUtils.CopyTable (itemData))
        end
    end
end

--[[
about:round buttons
                local texture, x, y = GetIconData( ability.iconNum )
                if(mode == AbilitiesWindow.Modes.MODE_ACTION_ABILITIES or mode == AbilitiesWindow.Modes.MODE_TACTIC_ABILITIES) then
                    DynamicImageSetTexture (window.."SquareIcon", texture, x, y)
                elseif(mode == AbilitiesWindow.Modes.MODE_MORALE_ABILITIES) then
                    local winX, winY = WindowGetDimensions( window.."CircleIcon" )
                    CircleImageSetTexture (window.."CircleIcon", texture, x + winX/2, y + winY/2)
                end


]]--


function TastyButtonsButton:SetIcon (iconNum, iconType) --copied from actionbutton
    local texture           = L""
    local disabledTexture   = L""
    local x                 = 0
    local y                 = 0
    
    self.m_IconNum = iconNum
    
    local iconWindow    = self.m_Windows[BASE_ICON]
    local tintColor     = DefaultColor.ZERO_TINT
	
	local winX, winY = WindowGetDimensions( iconWindow:GetName() )
    
    
    if (iconNum > 0) 
    then
        texture, x, y, disabledTexture = GetIconData (iconNum)
                
        if (iconType == USE_DISABLED_ICON) 
        then
            if (disabledTexture ~= "")
            then
                texture = disabledTexture
            else
                tintColor   = DefaultColor.MEDIUM_GRAY
                iconType    = USE_ENABLED_ICON
            end
        end
        
		if self.m_isRound then
			CircleImageSetTexture (iconWindow:GetName(), texture, x + winX/2, y + winY/2)
		else
			iconWindow:SetTexture (texture, x, y)
		end
        iconWindow:SetTint (tintColor)
    else
        -- NOTE: To avoid two function calls, potentially allow DynamicImageSetTextureSlice to take a texture name as well...
        --[[iconWindow:SetTexture ("EA_HUD_01", 0, 0)
        iconWindow:SetTextureSlice ("Blank-Action-Bar-Icon-Slot", Frame.FORCE_OVERRIDE)]]--
		if self.m_isCustom and self.m_isRound then
			--TastyButtons_CustomTextures.SetEmptyIcon(iconWindow,isRound) --custom texture hack
			CircleImageSetTexture (iconWindow:GetName(), "Tasty_EmptyButton", 32, 32)
		elseif self.m_isCustom then
			iconWindow:SetTexture("Tasty_EmptyButton",0,0)		
		elseif self.m_isRound then
			CircleImageSetTexture (iconWindow:GetName(), "Tasty_EmptyButtonRound", 32, 32)
		else
			iconWindow:SetTexture ("EA_HUD_01", 0, 0)
	        iconWindow:SetTextureSlice ("Blank-Action-Bar-Icon-Slot", Frame.FORCE_OVERRIDE)
		end
        iconType = USE_EMPTY_ICON
    end
    
    -- To allow callers to determine which icon type was actually displayed...
    return iconType
end





function TastyButtonsButton:SetState(actionId,iconNum, actionType, stateName, showing)
-- needed data : actionType,iconNum, actionId
	if actionId == nil or actionType == nil or stateName == nil or showing == nil then return end
	local lshowing = showing 
	if lshowing == nil then
		lshowing = true
	end
	self.m_ActionId = actionId
	self.m_IconNum = iconNum
	self.m_ActionType = actionType
	self:SetActionData(actionType,actionId)
	self:SetIcon(iconNum)
	WindowSetGameActionData (self:GetName().."Action", actionType, actionId, L"")
	currentState = stateName
	stateShowing = lshowing
	self:SetShowing(lshowing, true)
end

function TastyButtonsButton:SetTintIconOnly(enabled)
	tintIconOnly = (enabled==true)
end

function TastyButtonsButton:SetEmptyShowing(showing)
	showOnEmpty = showing
	if showOnEmpty then
		self:SetShowing(true)
	end
end

function TastyButtonsButton:SetShowing(showing, force)
	if stateShowing or force then
		WindowSetShowing(self:GetName(), showing)
	end
end

function TastyButtonsButton:SetShowGlobalCooldown(show)
	self.m_ShowGlobalCooldown=(show==true)
end

function TastyButtonsButton:SetShowTooltips(show)
	self.m_ShowTooltips=(show==true)
end

function TastyButtonsButton:OnMouseOver (flags, x, y)
	if self.m_ShowTooltips then
		local anchor = nil
		local clickText = L"Shift-Right click to clear !!"
		local slot, slotType, slotId = self:GetActionData () 
		local tooltipFunction = ActionButtonTooltipCreators[slotType]
		
		
		if DoesWindowExist( "MouseOverTargetWindow" ) then
		   anchor = { Point = "top",  RelativeTo = self:GetName (), RelativePoint = "bottom", XOffset = 0, YOffset = -15 }
		end

		if (tooltipFunction) then
			tooltipFunction (slotId, clickText, anchor, slot)
		end
	end
end

function TastyButtonsButton:OnLButtonUp(flags, x, y)
	local slot, actionType, actionId = self:GetActionData ()
	if actionId <= 7 and actionType == GameData.PlayerActions.COMMAND_PET then
		CommandPet(actionId)
	  elseif actionType == GameData.PlayerActions.COMMAND_PET_DO_ABILITY then
		CommandPetDoAbility(actionId)
	end
end


function TastyButtonsButton:OnRButtonDown (flags, x, y)
    if ((SystemData.Settings.Interface.lockActionBars == false) and (flags == SystemData.ButtonFlags.SHIFT)) then
		self:SetState(0,0,0,currentState)
		TastyButtons.Button_State_Set(self:GetSlot(), 0, 0, 0, nil, nil,nil)
		self:Save()
	  else
		local slot, actionType, actionId = self:GetActionData ()
    
	    if (((actionType == GameData.PlayerActions.COMMAND_PET_DO_ABILITY) or (actionType == GameData.PlayerActions.COMMAND_PET)) and (actionId ~= 0)) then
			CommandPetToggleAbility (actionId)
	    end 
    end
end

function TastyButtonsButton:SetNoTimeIndicator(enabled)
	noTimeIndicator = enabled
end

function TastyButtonsButton:SetOORTint(r,g,b)
	OORTint.r = r
	OORTint.g = g
	OORTint.b = b
end

function TastyButtonsButton:SetABCTint(r,g,b)
	ABCTint.r = r
	ABCTint.g = g
	ABCTint.b = b
end

function TastyButtonsButton:SetHotKeyFont(font)
	local hotKeyLabel = self.m_Windows[BUTTON_TEXT].m_Name
	LabelSetFont(hotKeyLabel,font,23)
end

function TastyButtonsButton:SetHotKeyFontColor(r,g,b)
	local hotKeyLabel = self.m_Windows[BUTTON_TEXT].m_Name
	self.m_Windows[BUTTON_TEXT]:SetTextColor (r, g, b)
	self.m_HotKeyColorR = r
	self.m_HotKeyColorG = g
	self.m_HotKeyColorB = b
end

function TastyButtonsButton:SetCooldownFont(font)
	local timerLabel = self.m_Windows[COOLDOWN_TIMER].m_Name
	LabelSetFont(timerLabel,font,23)
	WindowSetDimensions(timerLabel, WindowGetDimensions(WindowGetParent(timerLabel)))
end

function TastyButtonsButton:SetCooldownFontColor(r,g,b)
	local timerLabel = self.m_Windows[COOLDOWN_TIMER].m_Name
	self.m_Windows[COOLDOWN_TIMER]:SetTextColor(r,g,b)
	self.m_CooldownColorR = r
	self.m_CooldownColorG = g
	self.m_CooldownColorB = b
end

function TastyButtonsButton:SetAbcMode(enabled)
	if enabled then
		ABCMode = true
	  else
		ABCMode = false
	end
end

function TastyButtonsButton:SetHotKeyShowing(showing)
	WindowSetShowing(self:GetName().."ActionText",(showing == true))
end

function TastyButtonsButton:SetBorderShowing(isEnabled)
	if enabled then
	
	  else
	  
	end
end

function TastyButtonsButton:SetPos(xpos, ypos)
	local uiScale = InterfaceCore.GetScale()    
	local x,y = WindowGetScreenPosition("Root")

	xpos = math.floor((x+xpos)/uiScale)
	ypos = math.floor((y+ypos)/uiScale)

	local anchor = { Point="topleft", RelativeTo="Root", RelativePoint="topleft", XOffset=xpos, YOffset=ypos }
    WindowClearAnchors(self:GetName())
	self:SetAnchor( anchor )
	self:ForceProcessAnchors()

end

function TastyButtonsButton.GetAbilityGlowLevels (abilityId)
	local threshold=GetAbilityData(abilityId).abilityImprovementThreshold
	if (threshold==nil) or (threshold==0) then return 0,0 end
	local glowCaps={
		[GameData.CareerLine.SHAMAN]=5,
		[GameData.CareerLine.ARCHMAGE]=5,
		
		[GameData.CareerLine.ASSASSIN]=1,
		[GameData.CareerLine.WITCH_HUNTER]=1,
		
		[GameData.CareerLine.BLACK_ORC]=1,
		[GameData.CareerLine.SWORDMASTER]=1
	}
	local caps=glowCaps[GameData.Player.career.line]
	if caps then
		return threshold,caps
	else 
		return 0,0
	end

	return 0,0
end
