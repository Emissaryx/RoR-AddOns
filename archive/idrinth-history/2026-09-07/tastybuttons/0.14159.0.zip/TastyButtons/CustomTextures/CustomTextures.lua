TastyButtons_CustomTextures = {}


TastyButtons_CustomTextures.ButtonTextures={
	[Button.ButtonState.NORMAL]				={image="TastyButtons_gloss",xpos=0,ypos=0},
    [Button.ButtonState.HIGHLIGHTED]		={image="TastyButtons_gloss",xpos=0,ypos=0},
    [Button.ButtonState.PRESSED]			={image="TastyButtons_gloss_down",xpos=0,ypos=0},
    [Button.ButtonState.PRESSED_HIGHLIGHTED]={image="TastyButtons_gloss",xpos=0,ypos=0}
}

function TastyButtons_CustomTextures.MakeButtonCustom(buttonName)
	for state,texture in pairs(TastyButtons_CustomTextures.ButtonTextures) do
		ButtonSetTexture(buttonName.."Action", state, texture.image, texture.xpos, texture.ypos)
	end
end

function TastyButtons_CustomTextures.SetEmptyIcon(iconWindow,isRound)
	if isRound==true then
		CircleImageSetTexture (iconWindow:GetName(), "Tasty_EmptyButton", 0, 0)
	else
	    iconWindow:SetTexture ("Tasty_EmptyButton", 0, 0)
	    --iconWindow:SetTextureSlice ("Blank-Action-Bar-Icon-Slot", Frame.FORCE_OVERRIDE)
	end
end
