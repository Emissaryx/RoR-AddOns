DDS Converter:
http://eliteforce2.filefront.com/file/DDS_Converter;29412

Gimp:
http://www.gimp.org/



- Blank-Action-Bar-Icon-Slot.dds
	Background of empty Buttons

__________________________________
-= Rectangular Buttons =-
 
 - ea_sqframe01_d5.dds
		Normal Border
 - ea_sqframe01_roll_d5.dds
		Mouseover Border (will be drawn additionally to Normal Border)
 - ea_sqframe01_sel_d5.dds
		Selected Border  (replaces Normal Border)
 - ea_sqframe_casting_d5.dds
		Casting Animation for the Button. Consists of 6 Slices, each 72x72 pixels in size. Only the center 64x64 used in this case.
 - recharged_square.dds
		Recharged Animation, consists of 9 Slices, each 72x72 pixels in size, only the center 64x64 used.
		Template: rechargedTemplate.xcf
 - rfury_stage...dds
		Different stages of the righteous fury animation. Consists of 20 Slices, each 100x125 pixels in size. 
		Refer to TastyButtonsButtonTemplate.xml for positions.
		Template: glowtemplate.xcf
 - waagh_stage...dds
		Different stages of the waagh animation. Consists of 20 Slices, each 100x125 pixels in size. 
		Refer to TastyButtonsButtonTemplate.xml for positions. 
		Template: glowtemplate.xcf

		
__________________________________
-= Round Buttons =-
 
 - ea_rndframe01_d5.dds
		Normal Border
 - ea_rndframe01_roll_d5.dds
		Mouseover Border (will be drawn additionally to Normal Border)
 - ea_rndframe01_sel_d5.dds
		Selected Border  (replaces Normal Border)
 - ea_rndframe_casting_d5.dds
		Casting Animation for the Button. Consists of 6 Slices, each 72x72 pixels in size. Only the center 64x64 used in this case.
 - recharged_round.dds
		Recharged Animation, consists of 9 Slices, each 72x72 pixels in size, only the center 64x64 used.
		Template: rechargedTemplate.xcf
 - rfury_stage...round.dds
		Different stages of the righteous fury animation. Consists of 20 Slices, each 100x125 pixels in size. 
		Refer to TastyButtonsButtonTemplate.xml for positions.
		Template: glowtemplate.xcf
 - waagh_stage...round.dds
		Different stages of the waagh animation. Consists of 20 Slices, each 100x125 pixels in size. 
		Refer to TastyButtonsButtonTemplate.xml for positions.  
		Template :glowtemplate.xcf

		