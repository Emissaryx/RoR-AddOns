TastyButtonsParser = {}

---------------------- Handy Stuff -------------------------
local ButtonNameStart = "TastyButtons_"..tostring(SystemData.Server.Name).."__"..(tostring(GameData.Player.name)).."_Button_"

---------------- CHAT PARSING FUNCTIONS ----------------
-- Functions mainly made to parse the slash command input

function TastyButtonsParser.ParseArgs_CreateSingleButton(args)
	TastyButtons.PrintD("args : "..args)
	local slot,scale = args:match(" *(%d+) +(%d*[.]?%d+) *")
	if scale == nil then
		_, slot = args:match("(%s*)(%d+)")
		scale = InterfaceCore.GetScale()
		TastyButtons.PrintD("Scale : "..InterfaceCore.GetScale())
	end	
	if slot and scale then
		slot=tonumber(slot)
		scale=tonumber(scale)
--		TastyButtons.PrintD("slot : "..slot)
--		TastyButtons.PrintD("scale : "..scale)
		local butohn=TastyButtons.Button_Create(slot,scale,0,0,0,true)
		TastyButtons.Button_Save(butohn)
	else
		TastyButtons.Print("haha, you suck at regex")
	end

end

function TastyButtonsParser.ParseArgs_CreateButtonGroup(args)

	local buttontable = {}

    blub, scale = args:match("(.*[-]+.-)%s+(%d*[.]?%d+)")
	if blub then
		for buttonstart, _, buttonmax in string.gfind(blub, "(%d+)(%s*[-]+%s*)(%d+)") do
--			TastyButtons.PrintD("buttonstart: "..buttonstart)
--			TastyButtons.PrintD("buttonmax: "..buttonmax)
			for n=tonumber(buttonstart), tonumber(buttonmax) do
				table.insert(buttontable,n)
			end
		end	
	end

	if scale == nil then
		scale = InterfaceCore.GetScale()
	end

	if #buttontable == 0 then
		buttonstart, buttonmax = args:match("(%d+)%s*[-]+%s*(%d+)")
		local x = tonumber(buttonmax)
		for nn = tonumber(buttonstart), x, 1 do
			local button=TastyButtons.Button_Create(nn, tonumber(scale), 0, 0, 0,true )
			TastyButtons.Button_Save(button) 
		end
	  else
		TastyButtons.Button_Create_fromTable(buttontable,scale)
	end

end


function TastyButtonsParser.ParseArgs_AnchorGroup(args,group)

	local buttonstart, buttonmax, xgap, ygap, direction = args:match("(%d+)%s+(%d+)%s+([-]?%d+)%s+([-]?%d+)%s+(%a+)")
	local buttonTable = {}
	
	if not group then
		if args:match("%a+") == "all" then
			for buttons in pairs(TastyButtons_Save) do
				table.insert(buttonTable, buttons)
			end
			buttonstart = true
		end
	end
	
	if not buttonstart then
		for buttonstart, buttonmax, direction in string.gfind(args, "(%d+)%s*[-]+%s*(%d+)%s+(%a+)") do
			xgap = 0
			ygap = 0
			local tempbuttonTable = TastyButtons.Button_Anchor_makeTable(buttonstart, buttonmax , xgap, ygap, direction)	
			for n in pairs(tempbuttonTable) do
				TastyButtons.PrintD("N is: "..n)
				table.insert(buttonTable,tempbuttonTable[n])
			end

		end
		if #buttonTable > 0 then
			buttonstart = true
		end
	end
	
	if xgap == nil then
		xgap = 0
		ygap = 0
	end	
	
	if direction == nil then 
		direction = "right"
	end
	
	if buttonstart then
		if #buttonTable == 0 then
			buttonTable = TastyButtons.Button_Anchor_makeTable(buttonstart, buttonmax , xgap, ygap, direction)
		end	
		if group then
			TastyButtons.Button_Anchor_fromTable(buttonTable)
		  else
		   TastyButtons.Button_Anchor_Ungroup_fromTable(buttonTable)
		end
	end	
end

-- the shall not think about this funktion.... juts put it on /ignore --
function TastyButtonsParser.ParseArgs_SetPos(args)
	local button1, xpos, ypos = args:match("(%d+)%s+(%d+)%s+(%d+)") 
	if button1 then
		TastyButtons.Window_Set_Pos(ButtonNameStart..button1, xpos, ypos)
	  else
		TastyButtons.Print("Wrong usage of /tasty setpos")
	end
end	

-- This function looks pretty decent.... heh ^^
function TastyButtonsParser.Button_Delete_makeTable(args, kind)
	local buttonTable = {}
	
	if kind == "scale" then
		rest,scale = args:match("(.*)%s+(%d*[.]?%d+)")
	  else
		rest = args
    end	
	
	if (rest:match("%a+") == "all") then
		for tehButton in pairs(TastyButtons_Save) do
			table.insert(buttonTable, TastyButtons_Save[tehButton]["slot"])
		end
	  elseif args:match("(%d+%s*[-]+%s*%d+)") then
		for buttonStart, buttonMax in string.gfind(rest, "(%d+)%s*[-]+%s*(%d+)") do
			for buttonSlot=tonumber(buttonStart), tonumber(buttonMax) do
				table.insert(buttonTable,buttonSlot)
			end
		end
	  else
		for buttonSlot in string.gfind(args, "(%d+)") do
			table.insert(buttonTable,buttonSlot)
		end
	end
	
	if not (buttonTable == {}) then
		if kind == "scale" then
			TastyButtons.Button_SetScale_fromTable(buttonTable, scale)
		  else
			TastyButtons.Button_Delete_fromTable(buttonTable)
		end
	end

end

function TastyButtonsParser.ParseArgs_Button_Load_State(args)
	local buttonSlot, lstanceName, stateName = args:match("%s*(%d+)%s+(%a+)%s+(%a+)")
	local buttonSlot=tonumber(buttonSlot)
	if lstanceName == nil then
		lstanceName = "normal"
	end

--	TastyButtons.PrintD("Loading state: "..stateName.." for stance: "..lstanceName.." for Slot "..buttonSlot)
	
	if buttonSlot then
		TastyButtons.Button_State_Set(buttonSlot, lstanceName, stateName)
	  else
		TastyButtons.Print("Wrong Usage of /tasty acts")
	end
	
end

function TastyButtonsParser.ParseArgs_DelState(args)
	local buttonStart, buttonMax , gstanceName, stateName =args:match("%s*(%d+)[-]+(%d+)%s+([%w_]+)%s+([%w_]+)")
	if buttonStart == nil then
		local buttonSlot, lstanceName, stateName = args:match("%s*(%d+)%s*([%w_]+)%s*([%w_]+)")
	end
	if buttonSlot then
		TastyButtons.Button_State_Del(tonumber(buttonSlot), gstanceName, stateName)
	  elseif buttonStart then
		for n=tonumber(buttonStart) , tonumber(buttonMax),1 do
			TastyButtons.Button_State_Del(n, gstanceName, stateName)
		end
		TastyButtons.Button_Swap(stanceName[currentStance], "default")
	  else
		TastyButtons.Print("Thee shalt not delete States this way!")
	end
	
end


function TastyButtonsParser.ParseArgs_AddState(args)
	local buttonStart, buttonMax , gstanceName, stateName =args:match("%s*(%d+)[-]+(%d+)%s+([%w_]+)%s+([%w_]+)")
	local buttonSlot
	if buttonStart == nil then
		buttonSlot, gstanceName, stateName = args:match("%s*(%d+)%s+([%w_]+)%s+([%w_]+)")
	end
	if buttonSlot ~= nil then
		TastyButtons.Button_State_Add(tonumber(buttonSlot), gstanceName, stateName)
	  elseif buttonStart ~= nil then
		for n=tonumber(buttonStart) , tonumber(buttonMax),1 do
			TastyButtons.Button_State_Add(n, gstanceName, stateName)
		end
		TastyButtons.Button_Swap(stanceName[currentStance], "default")
	  else
		TastyButtons.Print("no more states for you")
	end
	
end

function TastyButtonsParser.Thanks()
	TastyButtons.Print("Thanks to all people that use this mod and especially thanks to the ones that send me bugreports from time to time! Thank you very much ;)")
end

function TastyButtonsParser.Halp(args)
	if args == "setpos" then 
			TastyButtons.Print("Sets a button to a given Screen location or can be used to ungroup a button")		
			TastyButtons.Print("Usage of /tasty "..args.." <buttonnumber> <xpos> <ypos>")		
			TastyButtons.Print("If xpos or ypos are off screen, the button will cuddle the screen border :D")		
		elseif args == "createbutton" or args == "cb" then
			TastyButtons.Print("Creates a Single Button")	
			TastyButtons.Print("Usage of /tasty "..args.." <buttonnumber> [scale]")	
			TastyButtons.Print("scale default Value is set to UiScale")	
		elseif args == "createbuttons" or args == "cbs" then
			TastyButtons.Print("Creates buttons in for a given range")	
			TastyButtons.Print("Usage of /tasty "..args.." <FirstButtonToCreate> <LastButtonToCreate> [scale]")		
			TastyButtons.Print("scale default Value is set to UiScale")	
		elseif args == "load" then
			TastyButtons.Print("Loads the addon and enables it")			
		elseif args == "unload" then
			TastyButtons.Print("Unload the addon and disables it")	
		elseif args == "enabled" then
			TastyButtons.Print("Toggles the addons enabled state or sets it to the give state")	
			TastyButtons.Print("Usage of /tasty "..args.." [on|off]")	
		elseif args == "info" or args == "halp" then
			TastyButtons.Print("Thank you for using the help funktion!")
			TastyButtons.Print("<value> is needed! [value] is optional!")
			TastyButtons.Print("type /tasty halp to get a command list")	
		elseif args =="delete" or args == "del" then
			TastyButtons.Print("Deletes given Buttons or all buttons")	
			TastyButtons.Print("Usage of /tasty "..args.." [all] [buttonnumbers separated by spaces]")		
		elseif args == "show" then
			TastyButtons.Print("Resets buttons to their normal State")	
			TastyButtons.Print("Usage of /tasty "..args.."<buttonnumbers separated by spaces>")
		elseif args == "hide" then
			TastyButtons.Print("Hides the Buttons")	
			TastyButtons.Print("Usage of /tasty "..args.."<buttonnumbers separated by spaces>")
		elseif args == "mode" then
			TastyButtons.Print("Changes the Buttonmode")	
			TastyButtons.Print("Usage of /tasty "..args.." <rvr> Sets Buttons to rvr mode")			
			TastyButtons.Print("Usage of /tasty "..args.." <anything else or nothing> Sets Buttons to PvE mode")				
		elseif args == "" or args == nil then
			TastyButtons.Print("Available Commandos for /tasty ")			
			TastyButtons.Print("/tasty setpos")
			TastyButtons.Print("/tasty createbutton or cb")
			TastyButtons.Print("/tasty createbuttons or cbs")
			TastyButtons.Print("/tasty show")
			TastyButtons.Print("/tasty hide")
			TastyButtons.Print("/tasty mode")
			TastyButtons.Print("/tasty thanks")
			TastyButtons.Print("/tasty load")
			TastyButtons.Print("/tasty unload")
			TastyButtons.Print("/tasty enabled")
			TastyButtons.Print("/tasty delete or del")
			TastyButtons.Print("/tasty info or halp")
			TastyButtons.Print("/tasty halp <command> to get more info!")			
		else
			TastyButtons.Print("Unknown command/tasty "..args)
			TastyButtons.Print("type /tasty halp to get a command list")

	end	
	
end


function TastyButtonsParser.HideButtons(args)
	local buttonTable = {}
	for buttonSlot in string.gfind(args, "(%d+)") do
		table.insert(buttonTable, tonumber(buttonSlot))
	end
	if #buttonTable > 0 then
		TastyButtons.Button_SetShowing_fromTable(buttonTable, false)
	end
end

function TastyButtonsParser.ShowButtons(args)
	local buttonTable = {}
	for buttonSlot in string.gfind(args, "(%d+)") do
		table.insert(buttonTable,  tonumber(buttonSlot))
	end
	if #buttonTable > 0 then
		TastyButtons.Button_SetShowing_fromTable(buttonTable, true)
	end
end

function TastyButtonsParser.MakeInvisible(args,makeInvisible)
	local buttonTable = {}
	for buttonSlot in string.gfind(args, "(%d+)") do
		table.insert(buttonTable,  tonumber(buttonSlot))
	end
	if #buttonTable > 0 then
		TastyButtons.Button_MakeInvisible_fromTable(buttonTable, makeInvisible)
	end
end

function TastyButtonsParser.SecretFunction()
	local ButtonNameStart = TastyButtons.Get_ButtonNameStart()
	local secretButtonTable = TastyButtons.Button_makeTable(1, 39)
	TastyButtons.Button_Create_fromTable(secretButtonTable, InterfaceCore.GetScale())

	----Das erste T----
	TastyButtons.Window_Set_Pos(ButtonNameStart..1,225,100)
	secretButtonTable = TastyButtons.Button_Anchor_makeTable(1,3 , 0, 0, "right")
	TastyButtons.Button_Anchor_fromTable(secretButtonTable)
	secretButtonTable = TastyButtons.Button_Anchor_makeTable(4,6 , 0, 0, "down",2)
	TastyButtons.Button_Anchor_fromTable(secretButtonTable)


	-------- The Complex A -----
	TastyButtons.Window_Set_Pos(ButtonNameStart..7,375,250)		
	secretButtonTable = TastyButtons.Button_Anchor_makeTable(7,10 , -30, 0, "rightup")
	TastyButtons.Button_Anchor_fromTable(secretButtonTable)		
	secretButtonTable = TastyButtons.Button_Anchor_makeTable(10,13 , -30, 0, "rightdown")
	TastyButtons.Button_Anchor_fromTable(secretButtonTable)		
	secretButtonTable = TastyButtons.Button_Anchor_makeTable(14,0 , 5, 25, "right",8)
	TastyButtons.Button_Anchor_fromTable(secretButtonTable)

	-----The S -----
	TastyButtons.Window_Set_Pos(ButtonNameStart..15,590,80)		
	secretButtonTable = TastyButtons.Button_Anchor_makeTable(15,17 , 0, 0, "right")
	TastyButtons.Button_Anchor_fromTable(secretButtonTable)		
	secretButtonTable = TastyButtons.Button_Anchor_makeTable(18,19 , 0, 0, "down",15)
	TastyButtons.Button_Anchor_fromTable(secretButtonTable)		
	secretButtonTable = TastyButtons.Button_Anchor_makeTable(19,21 , 0, 0, "right")
	TastyButtons.Button_Anchor_fromTable(secretButtonTable)
	secretButtonTable = TastyButtons.Button_Anchor_makeTable(21,23 , 0, 0, "down")
	TastyButtons.Button_Anchor_fromTable(secretButtonTable)
	secretButtonTable = TastyButtons.Button_Anchor_makeTable(23, 25 , 0, 0, "left")
	TastyButtons.Button_Anchor_fromTable(secretButtonTable)
	
	----Das zweite T----
	TastyButtons.Window_Set_Pos(ButtonNameStart..26,740,100)
	secretButtonTable = TastyButtons.Button_Anchor_makeTable(26,28 , 0, 0, "right")
	TastyButtons.Button_Anchor_fromTable(secretButtonTable)
	secretButtonTable = TastyButtons.Button_Anchor_makeTable(29,31 , 0, 0, "down",27)
	TastyButtons.Button_Anchor_fromTable(secretButtonTable)

	----- Das Y -----
	TastyButtons.Window_Set_Pos(ButtonNameStart..32,910,100)
	secretButtonTable = TastyButtons.Button_Anchor_makeTable(32,34 , -25, 0, "rightdown")
	TastyButtons.Button_Anchor_fromTable(secretButtonTable)
	secretButtonTable = TastyButtons.Button_Anchor_makeTable(34,36 , -25, 0, "rightup")
	TastyButtons.Button_Anchor_fromTable(secretButtonTable)
	secretButtonTable = TastyButtons.Button_Anchor_makeTable(37,0 , 0, 0, "down", 34)
	TastyButtons.Button_Anchor_fromTable(secretButtonTable)
	
	secretButtonTable = TastyButtons.Button_makeTable(42, 102)
	TastyButtons.Button_Create_fromTable(secretButtonTable, InterfaceCore.GetScale())	
	
	-------- Das B ------------
	TastyButtons.Window_Set_Pos(ButtonNameStart..38,235,420)
	secretButtonTable = TastyButtons.Button_Anchor_makeTable(38,39 , 0, 0, "left")
	TastyButtons.Button_Anchor_fromTable(secretButtonTable)
	secretButtonTable = TastyButtons.Button_Anchor_makeTable(42,45 , 0, 0, "down",39)
	TastyButtons.Button_Anchor_fromTable(secretButtonTable)
	secretButtonTable = TastyButtons.Button_Anchor_makeTable(45,46 , 0, 0, "right")
	TastyButtons.Button_Anchor_fromTable(secretButtonTable)
	secretButtonTable = TastyButtons.Button_Anchor_makeTable(47,0 , 0, 0, "right",43)
	TastyButtons.Button_Anchor_fromTable(secretButtonTable)
	secretButtonTable = TastyButtons.Button_Anchor_makeTable(48,0 , 0, 0, "rightdown",47)
	TastyButtons.Button_Anchor_fromTable(secretButtonTable)
	secretButtonTable = TastyButtons.Button_Anchor_makeTable(50,0 , 0, 0, "rightdown",38)
	TastyButtons.Button_Anchor_fromTable(secretButtonTable)
	secretButtonTable = TastyButtons.Button_Anchor_makeTable(49,0 , 0, 0, "right",46)
	TastyButtons.Button_Anchor_fromTable(secretButtonTable)
	

	
	------ Das U ----
	TastyButtons.Window_Set_Pos(ButtonNameStart..51,350,450)
	secretButtonTable = TastyButtons.Button_Anchor_makeTable(51,54 , 0, 0, "down")
	TastyButtons.Button_Anchor_fromTable(secretButtonTable)
	secretButtonTable = TastyButtons.Button_Anchor_makeTable(54,56 , 0, 0, "right")
	TastyButtons.Button_Anchor_fromTable(secretButtonTable)
	secretButtonTable = TastyButtons.Button_Anchor_makeTable(56,59 , 0, 0, "up")
	TastyButtons.Button_Anchor_fromTable(secretButtonTable)
	
	----Das zweite T----
	TastyButtons.Window_Set_Pos(ButtonNameStart..60,515,450)
	secretButtonTable = TastyButtons.Button_Anchor_makeTable(60,62 , 0, 0, "right")
	TastyButtons.Button_Anchor_fromTable(secretButtonTable)
	secretButtonTable = TastyButtons.Button_Anchor_makeTable(63,65 , 0, 0, "down",61)
	TastyButtons.Button_Anchor_fromTable(secretButtonTable)

	----Das zweite T----
	TastyButtons.Window_Set_Pos(ButtonNameStart..66,695,450)
	secretButtonTable = TastyButtons.Button_Anchor_makeTable(66,68 , 0, 0, "right")
	TastyButtons.Button_Anchor_fromTable(secretButtonTable)
	secretButtonTable = TastyButtons.Button_Anchor_makeTable(69,71 , 0, 0, "down",67)
	TastyButtons.Button_Anchor_fromTable(secretButtonTable)	
	
	------ Das O ----
	TastyButtons.Window_Set_Pos(ButtonNameStart..72,855,450)
	secretButtonTable = TastyButtons.Button_Anchor_makeTable(72,75 , 0, 0, "down")
	TastyButtons.Button_Anchor_fromTable(secretButtonTable)
	secretButtonTable = TastyButtons.Button_Anchor_makeTable(75,77 , 0, 0, "right")
	TastyButtons.Button_Anchor_fromTable(secretButtonTable)
	secretButtonTable = TastyButtons.Button_Anchor_makeTable(77,80 , 0, 0, "up")
	TastyButtons.Button_Anchor_fromTable(secretButtonTable)
	secretButtonTable = TastyButtons.Button_Anchor_makeTable(80,81 , 0, 0, "left")
	TastyButtons.Button_Anchor_fromTable(secretButtonTable)
		
	
	------ Das N ----
	TastyButtons.Window_Set_Pos(ButtonNameStart..82,1025,450)
	secretButtonTable = TastyButtons.Button_Anchor_makeTable(82,85 , 0, 0, "down")
	TastyButtons.Button_Anchor_fromTable(secretButtonTable)
	secretButtonTable = TastyButtons.Button_Anchor_makeTable(86,88 , -20, 0, "rightdown",82)
	TastyButtons.Button_Anchor_fromTable(secretButtonTable)
	secretButtonTable = TastyButtons.Button_Anchor_makeTable(88,91 , 0, 0, "up")
	TastyButtons.Button_Anchor_fromTable(secretButtonTable)

	-----The S -----
	TastyButtons.Window_Set_Pos(ButtonNameStart..92,1195,420)		
	secretButtonTable = TastyButtons.Button_Anchor_makeTable(92,94 , 0, 0, "right")
	TastyButtons.Button_Anchor_fromTable(secretButtonTable)		
	secretButtonTable = TastyButtons.Button_Anchor_makeTable(95,96 , 0, 0, "down",92)
	TastyButtons.Button_Anchor_fromTable(secretButtonTable)		
	secretButtonTable = TastyButtons.Button_Anchor_makeTable(96,98 , 0, 0, "right")
	TastyButtons.Button_Anchor_fromTable(secretButtonTable)
	secretButtonTable = TastyButtons.Button_Anchor_makeTable(98,100 , 0, 0, "down")
	TastyButtons.Button_Anchor_fromTable(secretButtonTable)
	secretButtonTable = TastyButtons.Button_Anchor_makeTable(100, 102 , 0, 0, "left")
	TastyButtons.Button_Anchor_fromTable(secretButtonTable)	
end

