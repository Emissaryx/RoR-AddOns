TastyButtonsOptions = {}

--$parent Window Name of the Options Window --
--local windowName = "TastyButtonsOptionsWindow"
local windowNameTable = {	default 					="TastyButtonsOptionsWindow",
							CreateView					="TastyButtonsOptionsWindowCreateView",
							EditView					="TastyButtonsOptionsWindowEditView",
							StateView					="TastyButtonsOptionsWindowStateView",
							GroupView					="TastyButtonsOptionsWindowGroupView",
							MiscView					="TastyButtonsOptionsWindowMiscView",
							RangeView					="TastyButtonsButtonSelectWindowButtonRangeView",
							ListView					="TastyButtonsButtonSelectWindowButtonListView",
							ButtonInfoWindow			="TastyButtonsOptionsButtonInfoWindow",
							ButtonInfoWindowListStance 	= "TastyButtonsOptionsButtonInfoWindowListStanceRow",
							ButtonInfoWindowListState 	= "TastyButtonsOptionsButtonInfoWindowListStateRow",
							MenuButton					= "TastyButtonsOptionsMenuButton",
							GeneralWindow				= "TastyButtonsGeneralOptionsWindow",
							AdvancedWindow				= "TastyButtonsAdvancedOptionsWindow",
							ButtonSelectWindow			= "TastyButtonsButtonSelectWindow",
							ProfileWindow				= "TastyButtonsGeneralOptionsProfileWindow"
							--ButtonSelectWindowList		= TastyButtonsButtonSelectWindowListViewList
						}
						
local viewNameTable =	{	[1]	=	{viewName = "TastyButtonsOptionsWindowCreateView", tabName = windowNameTable["default"].."TabsCreateView"},
							[2]	=	{viewName = "TastyButtonsOptionsWindowEditView", tabName = windowNameTable["default"].."TabsEditView"},
							[3]	=	{viewName = "TastyButtonsOptionsWindowStateView", tabName = windowNameTable["default"].."TabsStateView"},
							[4]	=	{viewName = "TastyButtonsOptionsWindowGroupView", tabName = windowNameTable["default"].."TabsGroupView"},
							[5]	=	{viewName = "TastyButtonsOptionsWindowMiscView", tabName = windowNameTable["default"].."TabsMiscView"},
							[10]=	{viewName = windowNameTable["ListView"], tabName = windowNameTable["ButtonSelectWindow"].."TabsListView"},
							[11]=	{viewName = "TastyButtonsButtonSelectWindowButtonRangeView", tabName = windowNameTable["ButtonSelectWindow"].."TabsRangeView"}
						}							
local groupColors	= 	{	[0] = {r=100,g=0,b=0},
							[1] = {r=0,g=100,b=0},
							[2] = {r=0,g=0,b=100},
							[3] = {r=0,g=0,b=0},
							[4] = {r=255,g=255,b=255}
						}
-- Table that Holds the available Directions from TastyButtons.lua --�
local directionTable = {}
-- Available stance names from TastyButtons.lua --
local stanceName = TastyButtons.Get_stanceNameTable()
-- List of the Existsing buttons buttonList[n] = buttonSlot --
-- Should be sorted by buttonSlot --
local buttonList = {}
local advancedbuttonList = {}
-- Concatenate with ButtonSlot to get ButtonName --
local ButtonNameStart = TastyButtons.Get_ButtonNameStart()
--Holds the buttonstates ... yehaww!  while the option Window is activ--
local currentButtonStateTable = {}
--- Just holds a boolean value, if the button is visible or not -- Key is the buttonSlot--
local currentButtonShowingTable = {}

local petNameTable = {}
local lastInfoStanceWnd 
local lastInfoStateWnd
local currentButtonSlot
local currentStance = "normal"
local currentState = "default"
local currentStateType = "PvE"
local selectedButtons = ""
local selectedButtonsTable = {}
local selectionMode = 0

local availableFontsTable = { 	"font_chat_text",
								"font_default_text_small",
								"font_default_text", 
								"font_default_text_large",
								"font_default_text_huge",
								"font_clear_small_bold", 
								"font_clear_medium_bold", 
								"font_clear_large_bold",
								"font_heading_large",
								"font_heading_huge",
								"font_clear_small", 
								"font_clear_medium", 
								"font_journal_text"}
							
local petSkills = {	["FOLLOW"] 		= {abilityId = 2 , abilityName = L"Pet Follow"		,iconNum = 30, abilityType = GameData.PlayerActions.COMMAND_PET},			
					["STAY"] 		= {abilityId = 1 , abilityName = L"Pet Stay"		,iconNum = 33, abilityType = GameData.PlayerActions.COMMAND_PET},
					["ATTACK"] 		= {abilityId = 6 , abilityName = L"Pet Attack"		,iconNum = 54, abilityType = GameData.PlayerActions.COMMAND_PET},	 
					["AGGRO"] 		= {abilityId = 5 , abilityName = L"Pet Aggressiv"	,iconNum = 28, abilityType = GameData.PlayerActions.COMMAND_PET}, 
					["DEFENSIVE"]	= {abilityId = 4 , abilityName = L"Pet Defensive"	,iconNum = 29, abilityType = GameData.PlayerActions.COMMAND_PET},	 
					["PASSIVE"]		= {abilityId = 3 , abilityName = L"Pet Passive"		,iconNum = 31, abilityType = GameData.PlayerActions.COMMAND_PET},	 
					["RELEASE"]		= {abilityId = 7 , abilityName = L"Pet Release"		,iconNum = 32, abilityType = GameData.PlayerActions.COMMAND_PET}	 
				  }
				  
-- Concatenate with Selected Menu item to get the ButtonName --
local comboBoxButtonName = {ComboDirection 				= 	windowNameTable["CreateView"].."ComboDirectionMenuButton",
							ComboShape					= 	windowNameTable["AdvancedWindow"].."ComboButtonShapeMenuButton",
							ComboShapeBox				= 	windowNameTable["AdvancedWindow"].."ComboButtonShape",
							ComboStanceAdd				=	windowNameTable["StateView"].."ComboStanceAddMenuButton",
							ComboStateAdd				=	windowNameTable["StateView"].."ComboStateAddMenuButton",
							ComboStateButtonAddLastBox	=	windowNameTable["StateView"].."ComboStateButtonAddLast",
							ComboStateButtonAddLast		=	windowNameTable["StateView"].."ComboStateButtonAddLastMenuButton",
						    ComboStateButtonAddFirstBox	=	windowNameTable["StateView"].."ComboStateButtonAddFirst",
							ComboStateButtonAddFirst	=	windowNameTable["StateView"].."ComboStateButtonAddFirstMenuButton",
							ComboStateType				=	windowNameTable["StateView"].."ComboStateTypeMenuButton",
							ComboStateResource			=	windowNameTable["StateView"].."ComboResourceMenuButton",
							ComboShowing				=	windowNameTable["StateView"].."ComboShowingMenuButton",
							ComboShowingBox				=	windowNameTable["StateView"].."ComboShowing",
							ComboStateResourceBox		=	windowNameTable["StateView"].."ComboResource",
							ComboStateEqual				=	windowNameTable["StateView"].."ComboResourceEqualMenuButton",
							ComboStateEqualBox			=	windowNameTable["StateView"].."ComboResourceEqual",
							ComboButtonInfoWindow		=	windowNameTable["ButtonInfoWindow"].."ComboButton",
							ComboButtonRangeFirstBox	=	windowNameTable["RangeView"].."ComboFirstButton",
							ComboButtonRangeFirst		=	windowNameTable["RangeView"].."ComboFirstButtonMenuButton",
							ComboButtonRangeLastBox		=	windowNameTable["RangeView"].."ComboLastButton",
							ComboButtonRangeLast		=	windowNameTable["RangeView"].."ComboLastButtonMenuButton",
							ComboProfile				=	windowNameTable["ProfileWindow"].."ComboProfilesMenuButton",
							ComboProfileBox				=	windowNameTable["ProfileWindow"].."ComboProfiles"
						   }				  
-- this is the playerClass ;)				ComboButtonShape
local playerClass = TastyButtons.Get_playerClass()

---availableStates ---
local availableStates = {L"default", L"OnCooldown", L"OnNotEnoughAP", L"OnResource"}

--- what ever ... fuck off ---
local comboBoxResourcesFuckTardShitForSuckyComboBoxes = {}

TastyButtonsOptions.buttonStates = {}
TastyButtonsOptions.buttonList = {}

------------- Copypasta! ------
---�- me is ver sorry for the copy pasta .... but im not here for writing a options window .... i only wanted to make the buttons :P

local MyCopyPastaIconCreator =
{   
    [GameData.PlayerActions.DO_ABILITY] = function (actionId, clickText, anchor)
        local abilityData = Player.GetAbilityData (actionId)
                
        if (abilityData ~= nil) then            
            Tooltips.CreateAbilityTooltip (abilityData, SystemData.MouseOverWindow.name, anchor, clickText)
        end    
    end,
    
    [GameData.PlayerActions.USE_ITEM] = function (actionId, clickText, anchor, slot)
        local itemData = DataUtils.FindItem (actionId)
        local cacheThisItem = true
        
        if (itemData == nil) then
            itemData = GetCachedData (GameData.PlayerActions.USE_ITEM, actionId, "itemData")
            cacheThisItem = false
        end
        
        if (itemData ~= nil)then
            Tooltips.CreateItemTooltip (itemData, SystemData.MouseOverWindow.name, anchor, true, clickText)
            
            if (cacheThisItem == true) then
                CacheData (GameData.PlayerActions.USE_ITEM, actionId, "itemData", DataUtils.CopyTable (itemData))
            end
        end
    end,
    
    [GameData.PlayerActions.DO_MACRO] = function (actionId, clickText, anchor)
        local macroTable    = DataUtils.GetMacros ()
        local macroData     = macroTable[actionId]
        
        if (macroData ~= nil) then            
            Tooltips.CreateMacroTooltip (macroData, SystemData.MouseOverWindow.name, anchor, clickText)
        end    
    end,
    
    [GameData.PlayerActions.DO_CRAFTING] = function (actionId, clickText, anchor)
        Tooltips.CreateTradeskillTooltip (actionId, anchor)
    end,
    
    [GameData.PlayerActions.COMMAND_PET] = function (actionId, clickText, anchor)
        -- This function is the devil
        local line1 = L""
        local line2 = L""
        local line3 = L""
        if (actionId == GameData.PetCommand.STAY) then
            line1 = GetString( StringTables.Default.LABEL_PET_STAY )
            line2 = GetString( StringTables.Default.TEXT_PET_STAY ) 
            line3 = L"("..SystemData.Settings.Keybindings.PET_STAY.bindings[1]..L")"
        elseif (actionId == GameData.PetCommand.FOLLOW) then
            line1 = GetString( StringTables.Default.LABEL_PET_FOLLOW )
            line2 = GetString( StringTables.Default.TEXT_PET_FOLLOW )   
            line3 = L"("..SystemData.Settings.Keybindings.PET_FOLLOW.bindings[1]..L")"
        elseif (actionId == GameData.PetCommand.ATTACK) then
            line1 = GetString( StringTables.Default.LABEL_PET_ATTACK )
            line2 = GetString( StringTables.Default.TEXT_PET_ATTACK )
            line3 = L"("..SystemData.Settings.Keybindings.PET_ATTACK.bindings[1]..L")"
		elseif (actionId == GameData.PetCommand.PASSIVE ) then
			line1 = L"Passive"
			line2 = L"Set's you pet to the Passive State"
			line3 = L"All your buttons are belong to us!"
		elseif (actionId == GameData.PetCommand.AGGRESSIVE ) then
			line1 = L"Aggressive"
			line2 = L"Set's you pet to the Aggresive State"		
			line3 = L"Down Diagonal Forward + Punch = HADOKEN"
		elseif (actionId == GameData.PetCommand.DEFENSIVE ) then
			line1 = L"Defensive"
			line2 = L"Set's you pet to the Defensive State"	
			line3 = L"Greetz to everyone from #waruidev"
		elseif (actionId == GameData.PetCommand.RELEASE ) then
 			line1 = L"Release"
			line2 = L"Releases your Pet"
			line3 = L"It'll be back"
		end

        Tooltips.CreateTextOnlyTooltip( SystemData.MouseOverWindow.name )
        Tooltips.SetTooltipText( 1, 1, line1)
        Tooltips.SetTooltipColorDef( 1, 1, Tooltips.COLOR_HEADING )
        Tooltips.SetTooltipText( 2, 1, line2)
        Tooltips.SetTooltipText( 3, 1, line3)
        Tooltips.SetTooltipColor( 3, 1, 140, 100, 0 ) 
        Tooltips.Finalize()    
        Tooltips.AnchorTooltip (anchor)
    end,
    
    [GameData.PlayerActions.COMMAND_PET_DO_ABILITY] = function (actionId, clickText, anchor)
        local abilityData = Player.GetAbilityData (actionId)
        
        if (abilityData ~= nil)
        then
            local text = GetString( StringTables.Default.TEXT_PET_ABILITY_FLASH )
            Tooltips.CreateAbilityTooltip (abilityData, SystemData.MouseOverWindow.name, anchor, text)
        end
    end,
}

---- no more copy pasta ---

function TastyButtonsOptions.Initialize()
	-- Creating the 2 Windows!!!!!--------
	TastyButtonsOptions.CreateOptionsWindow()
	
    TastyButtonsOptions.Get_directionNames()
	-- Creates the window and shows it
	EA_ChatWindow.Print(towstring("tasty: Loading Options Window!"))
    -- Writes the text in the label 
	WindowSetShowing(windowNameTable["default"],false)
	TastyButtonsOptions.Setup()
	RegisterEventHandler (SystemData.Events.L_BUTTON_UP_PROCESSED,"TastyButtonsOptions.OnLButtonUpProcessed")  
	petNameTable = TastyButtons.Get_petNameTable()
end

function TastyButtonsOptions.CreateOptionsWindow()
	if not DoesWindowExist(windowNameTable["default"]) then
		CreateWindow(windowNameTable["default"],false)
	end
	if not DoesWindowExist(windowNameTable["ButtonInfoWindow"]) then
		CreateWindow(windowNameTable["ButtonInfoWindow"],false)
	end
	if not DoesWindowExist(windowNameTable["ButtonSelectWindow"]) then
		CreateWindow(windowNameTable["ButtonSelectWindow"],false)
	end	
	if not DoesWindowExist(windowNameTable["ProfileWindow"]) then
		CreateWindow(windowNameTable["ProfileWindow"],false)
	end	
	WindowClearAnchors(windowNameTable["default"]) 
	WindowClearAnchors(windowNameTable["ButtonInfoWindow"]) 
	WindowClearAnchors(windowNameTable["ButtonSelectWindow"]) 
	WindowClearAnchors(windowNameTable["ProfileWindow"]) 
	WindowAddAnchor( windowNameTable["ButtonInfoWindow"] , "topright", windowNameTable["ButtonSelectWindow"], "topleft", 0, 0 )
	WindowAddAnchor( windowNameTable["ButtonSelectWindow"] , "right", windowNameTable["default"], "left", 0, -11 )
	WindowAddAnchor( windowNameTable["ProfileWindow"] , "topright", windowNameTable["GeneralWindow"], "topleft", 0, 30 )
end

function TastyButtonsOptions.Setup()
	
	--- GENERAL WINDOW SETTINGS ----
	--Window Title
	LabelSetText(windowNameTable["default"].."TitleBarText",L"Tasty Button Options")
	
	-- Stupid Tabs! I HATE EM --
	ButtonSetText(windowNameTable["default"].."TabsCreateView",L"Create")
	ButtonSetText(windowNameTable["default"].."TabsEditView",L"Edit")
	ButtonSetText(windowNameTable["default"].."TabsStateView",L"States")
	ButtonSetText(windowNameTable["default"].."TabsGroupView",L"Group")
	ButtonSetText(windowNameTable["default"].."TabsMiscView",L"Misc")
	
	---- VIEW SETTINGS -----
	
	---- CREATE VIEW ------
	
	--Create Button + Labels + Parameter Boxes
	ButtonSetText(windowNameTable["CreateView"].."ButtonCreate",L"Create Button(s)")
	LabelSetText(windowNameTable["CreateView"].."CreateLabel",L"Create Button(s)")
	LabelSetText(windowNameTable["CreateView"].."EditCreateBetweenLabel",L" - ")
	LabelSetText(windowNameTable["CreateView"].."EditCreateScaleLabel",L"Scale: ")
	LabelSetText(windowNameTable["CreateView"].."CheckCustomTextureLabel",L"Use Custom Texture")
	LabelSetText(windowNameTable["CreateView"].."CheckisButtonRoundLabel",L"Round Button")

	
	-- Delete Button + Labels + Checkbox
	ButtonSetText(windowNameTable["CreateView"].."ButtonDelete",L"Delete Button(s)")
	LabelSetText(windowNameTable["CreateView"].."DeleteLabel",L"Delete Button(s)")
	LabelSetText(windowNameTable["CreateView"].."CheckDelAllLabel",L"Delete All")
	ButtonSetCheckButtonFlag(windowNameTable["CreateView"].."CheckDelAllButton", false )	

	LabelSetText(windowNameTable["CreateView"].."ThanksLabel",	towstring("Thanks to: \n	Ratty, GutGut, Thurwell, WikkiFizzle, Aiiane \n and all you guys using Tasty Buttons"))

	----- EDIT VIEW ------------

	
	----- SCALE STUFF -----------
	LabelSetText(windowNameTable["EditView"].."SelectButtonsLabel",L"Select Button(s)")
	ButtonSetText(windowNameTable["EditView"].."ButtonSetScale",L"Scale Button(s)")
	LabelSetText(windowNameTable["EditView"].."EditScaleLabel",L"Scale: ")

	
	--- SET POS STUFF ---
	ButtonSetText(windowNameTable["EditView"].."ButtonSetPos",L"Set Position")
	LabelSetText(windowNameTable["EditView"].."EditSetPosXLabel",L"X:")
	LabelSetText(windowNameTable["EditView"].."EditSetPosYLabel",L"Y:")
	
	
	--- FONT OPTIONS ----
	LabelSetText(windowNameTable["EditView"].."FontOptionsLabel",L"All Buttons")	
	LabelSetText(windowNameTable["EditView"].."ComboFontLabel",L"Font")
	ComboBoxClearMenuItems(windowNameTable["EditView"].."ComboFont")
	for n = 1,#availableFontsTable,1  do
		ComboBoxAddMenuItem( windowNameTable["EditView"].."ComboFont",towstring(availableFontsTable[n]))
	end
	ComboBoxSetSelectedMenuItem(  windowNameTable["EditView"].."ComboFont",1)
	LabelSetText(windowNameTable["EditView"].."FontColorRLabel",L"Red")
	LabelSetTextColor(windowNameTable["EditView"].."FontColorRLabel",200,0,0)
	
	LabelSetText(windowNameTable["EditView"].."FontColorGLabel",L"Green")
	LabelSetTextColor(windowNameTable["EditView"].."FontColorGLabel",0,200,0)
	
	LabelSetText(windowNameTable["EditView"].."FontColorBLabel",L"Blue")
	LabelSetTextColor(windowNameTable["EditView"].."FontColorBLabel",0,0,200)
	
	LabelSetText(windowNameTable["EditView"].."ColorPreview",L"1 3 8")	
	ButtonSetText(windowNameTable["EditView"].."ButtonSaveFontTimer",L"Set CD Font")
	ButtonSetText(windowNameTable["EditView"].."ButtonSaveFontHotKey",L"Set HotKey Font")
	
	ButtonSetText(windowNameTable["EditView"].."ButtonSaveColorABCTint",L"Set OOR Color")
	ButtonSetText(windowNameTable["EditView"].."ButtonSaveColorOORTint",L"Set ABC Color")
	
	--- TEXTURES STUFF ----
	LabelSetText(windowNameTable["EditView"].."TextureOptionsLabel",L"Texture Options")
	ButtonSetText(windowNameTable["EditView"].."ButtonSetTextures",L"Set Textures")
	LabelSetText(windowNameTable["EditView"].."CheckCustomTextureLabel",L"Use Custom Texture")
	LabelSetText(windowNameTable["EditView"].."CheckisButtonRoundLabel",L"Round Button")	
	
	--- STATE VIEW ----
	
	
	-- AddStateButton --
	ButtonSetText(windowNameTable["StateView"].."ButtonStateAdd",L"Add State")
	-- Labels for the Combo Boxes --

	LabelSetText(windowNameTable["StateView"].."SelectButtonsLabel",L"Select Buttons from List or Range-Select =>")
	LabelSetText(windowNameTable["StateView"].."AddStateLabel",L"Select State:")
	LabelSetText(windowNameTable["StateView"].."SelectButtonsLabelSubtitle",L"<Manual Selection will be ignored>")
	LabelSetText(windowNameTable["StateView"].."ComboStanceAddLabel",L"in Stance")
	LabelSetText(windowNameTable["StateView"].."ComboResourceLabel",L"Resource")
	LabelSetText(windowNameTable["StateView"].."ComboShowingLabel",L"Showing:")
	LabelSetText(windowNameTable["StateView"].."ComboStateTypeLabel",L"for Mode")
	
	-- Clear Combo Boxes --
	ComboBoxClearMenuItems(windowNameTable["StateView"].."ComboStateType")
	ComboBoxClearMenuItems(windowNameTable["StateView"].."ComboShowing")
	
	--- Add Items to Combo Boxes --

	ComboBoxAddMenuItem( windowNameTable["StateView"].."ComboStateType",L"PvE")
	ComboBoxAddMenuItem( windowNameTable["StateView"].."ComboStateType",L"RvR")
	
	ComboBoxAddMenuItem( windowNameTable["StateView"].."ComboShowing",L"true")
	ComboBoxAddMenuItem( windowNameTable["StateView"].."ComboShowing",L"false")
	
	-- Set Selected Element Combo Boxes --
	ComboBoxSetSelectedMenuItem( windowNameTable["StateView"].."ComboStanceAdd",3)
	ComboBoxSetSelectedMenuItem( windowNameTable["StateView"].."ComboStateType",1)
	ComboBoxSetSelectedMenuItem( windowNameTable["StateView"].."ComboShowing",1)
	
	--- Set the text on the Buttons for the States---
	ButtonSetText(windowNameTable["StateView"].."ButtonStateAdd",L"Add")
	ButtonSetText(windowNameTable["StateView"].."ButtonStateDelete",L"Delete")
	ButtonSetText(windowNameTable["StateView"].."ButtonStateModify",L"Modify")
	ButtonSetText(windowNameTable["StateView"].."ButtonStateClear",L"Reset")	

	
	
	---- GROUP VIEW ---------
	
	
	LabelSetText(windowNameTable["GroupView"].."GroupManualLabel",L"Manual Grouping")
	LabelSetText(windowNameTable["GroupView"].."BlockButtonLabel",L"Blocks and Bars")
	LabelSetText(windowNameTable["GroupView"].."GroupSettingsLabel",L"Group Settings")
	--Group Button + Labels + ComboBox
	ButtonSetText(windowNameTable["GroupView"].."ButtonGroup",L"Group Button(s)")
	ButtonSetText(windowNameTable["GroupView"].."ButtonUnGroup",L"Ungroup Button(s)")
	ButtonSetText(windowNameTable["GroupView"].."ButtonBlock",L"Block Button(s)")
	LabelSetText(windowNameTable["GroupView"].."ComboRowDirectionLabel",L"Group/Row Direction")
	LabelSetText(windowNameTable["GroupView"].."ComboColumnDirectionLabel",L"Column Direction")
	ComboBoxClearMenuItems(windowNameTable["GroupView"].."ComboRowDirection")
	ComboBoxClearMenuItems(windowNameTable["GroupView"].."ComboColumnDirection")
	for n = 1,#directionTable,1  do
		ComboBoxAddMenuItem( windowNameTable["GroupView"].."ComboRowDirection",towstring(directionTable[n]))
		ComboBoxAddMenuItem( windowNameTable["GroupView"].."ComboColumnDirection",towstring(directionTable[n]))
	end
	ComboBoxSetSelectedMenuItem( windowNameTable["GroupView"].."ComboRowDirection",6)
	ComboBoxSetSelectedMenuItem( windowNameTable["GroupView"].."ComboColumnDirection",7)

	
	LabelSetText(windowNameTable["GroupView"].."EditGroupToButtonLabel",L"to ")
	LabelSetText(windowNameTable["GroupView"].."EditGroupXGapLabel",L"X-Gap:")
	LabelSetText(windowNameTable["GroupView"].."EditGroupYGapLabel",L"Y-Gap:")
	LabelSetText(windowNameTable["GroupView"].."EditBlockColumnsLabel",L"Columns:")
	LabelSetText(windowNameTable["GroupView"].."EditBlockRowsLabel",L"Rows:")
	LabelSetText(windowNameTable["GroupView"].."RentLabel",L"This Space for Rent!!")
	
	------ MISC VIEW ----------
	
	---- MISC OPTIONS---
	LabelSetText(windowNameTable["MiscView"].."MiscOptionsLabel",L"Misc Options")
	LabelSetText(windowNameTable["MiscView"].."CheckGlobalCooldownLabel",L"Show Global Cooldown")
	LabelSetText(windowNameTable["MiscView"].."CheckTimeIndicatorLabel",L"Hide Time Indicator")
	LabelSetText(windowNameTable["MiscView"].."CheckAutoModeLabel",L"Auto Mode Change")
	LabelSetText(windowNameTable["MiscView"].."CheckABCModeLabel",L"ABC Mode Enabled")
	LabelSetText(windowNameTable["MiscView"].."CheckShowEmptyLabel",L"Show Empty Buttons")
	LabelSetText(windowNameTable["MiscView"].."CheckHideToolTipLabel",L"Show Tooltips")
	LabelSetText(windowNameTable["MiscView"].."CheckTintIconOnlyLabel",L"Tint ButtonIcon Only (on Cooldown)")
	LabelSetText(windowNameTable["MiscView"].."CheckShowHotkeysLabel",L"Show Hotkeys")
	
	---- EVENTS ----
	
	LabelSetText(windowNameTable["MiscView"].."EventOptionsLabel",L"Tuning Options")
	LabelSetText(windowNameTable["MiscView"].."CheckAPHandlerLabel",L"Action Point Handler")
	LabelSetText(windowNameTable["MiscView"].."CheckResourceHandlerLabel",L"Resource Handler")

	--- SetCheckBoxes ---
	TastyButtonsOptions.SetStayDownFlag(windowNameTable["MiscView"].."CheckGlobalCooldownButton", TastyButtons_Settings["globalCD"])
	TastyButtonsOptions.SetStayDownFlag(windowNameTable["MiscView"].."CheckTimeIndicatorButton", TastyButtons_Settings["NoTimeIndicator"])
	TastyButtonsOptions.SetStayDownFlag(windowNameTable["MiscView"].."CheckAutoModeButton", TastyButtons_Settings["autoMode"])
	TastyButtonsOptions.SetStayDownFlag(windowNameTable["MiscView"].."CheckABCModeButton", TastyButtons_Settings["ABCMode"])
	TastyButtonsOptions.SetStayDownFlag(windowNameTable["MiscView"].."CheckShowEmptyButton", TastyButtons_Settings["showEmpty"])
	TastyButtonsOptions.SetStayDownFlag(windowNameTable["MiscView"].."CheckHideToolTipButton", TastyButtons_Settings["showTooltips"])
	TastyButtonsOptions.SetStayDownFlag(windowNameTable["MiscView"].."CheckTintIconOnlyButton", TastyButtons_Settings["tintIconOnly"])
	TastyButtonsOptions.SetStayDownFlag(windowNameTable["MiscView"].."CheckShowHotkeysButton", TastyButtons_Settings["showHotkeys"])
	TastyButtonsOptions.SetStayDownFlag(windowNameTable["MiscView"].."CheckAPHandlerButton", TastyButtons_Settings["APHandler"])
	TastyButtonsOptions.SetStayDownFlag(windowNameTable["MiscView"].."CheckResourceHandlerButton", TastyButtons_Settings["ResourceHandler"])

	ButtonSetText(windowNameTable["MiscView"].."ButtonSaveOpt",L"Apply Options")
	

	---- THE OTHER WINDOWS -----
	
	--- BUTTON INFO WINDOW ----
	
	WindowSetShowing(windowNameTable["ButtonInfoWindow"], false)
	
	--- GoGo set Label text! --
	DataUtils.SetListRowAlternatingTints( windowNameTable["ButtonInfoWindow"].."ListStance", 7 )
	DataUtils.SetListRowAlternatingTints( windowNameTable["ButtonInfoWindow"].."ListState", 7 )
	LabelSetText(windowNameTable["ButtonInfoWindow"].."TitleBarText",L"Button Info")
	LabelSetText(windowNameTable["ButtonInfoWindow"].."ComboButtonLabel",L"Button:")
	LabelSetText(windowNameTable["ButtonInfoWindow"].."ButtonModeLabel",L"Mode:")
	LabelSetText(windowNameTable["ButtonInfoWindow"].."ButtonMode",L"   ")
	LabelSetText(windowNameTable["ButtonInfoWindow"].."ListStanceLabel",L"Stances")
	LabelSetText(windowNameTable["ButtonInfoWindow"].."ListStateLabel",L"States")
	LabelSetText(windowNameTable["ButtonInfoWindow"].."ScaleLabel",L"Scale: ")
	LabelSetText(windowNameTable["ButtonInfoWindow"].."AnchoredToLabel",L"Anchored to: ")
	LabelSetText(windowNameTable["ButtonInfoWindow"].."XLabel",L"X :")
	LabelSetText(windowNameTable["ButtonInfoWindow"].."YLabel",L"Y :")
	LabelSetText(windowNameTable["ButtonInfoWindow"].."HiddenLabel",L"Showing:")
	LabelSetText(windowNameTable["ButtonInfoWindow"].."ActionIdLabelLabel",L"actionId:")
	LabelSetText(windowNameTable["ButtonInfoWindow"].."IconNumLabelLabel",L"iconNum:")
	
	
	
	---- SET STUFF IN GENERALS OPTIONS WINDOW ---
	ButtonSetText(windowNameTable["GeneralWindow"].."ButtonCopyBars", L"Copy ActionBars to TastyButtons")
	LabelSetText(windowNameTable["GeneralWindow"].."TitleBarText",L"Tasty Options")
	ButtonSetText(windowNameTable["GeneralWindow"].."ButtonToggleBars",L"Bar Toggle(on)")
	ButtonSetText(windowNameTable["GeneralWindow"].."ButtonProfiles",L"Profiles")
	
	----------- PROFILE WINDOW--------------
	LabelSetText(windowNameTable["ProfileWindow"].."TitleBar",L"Profiles")	
	ButtonSetText(windowNameTable["ProfileWindow"].."ButtonSaveProfiles",L"Save")
	ButtonSetText(windowNameTable["ProfileWindow"].."ButtonLoadProfiles",L"Load")
	ButtonSetText(windowNameTable["ProfileWindow"].."ButtonDelProfiles",L"Delete")

	---- SET STUFF IN BUTTONSELECTWINDOW ----
	
	--- LIST VIEW ----
	ButtonSetText(windowNameTable["ButtonSelectWindow"].."TabsListView",L"List")
	ButtonSetText(windowNameTable["ButtonSelectWindow"].."TabsRangeView",L"Range")
	TastyButtonsOptions.SetStayDownFlag(windowNameTable["ButtonSelectWindow"].."TabsListView",true)
	DataUtils.SetListRowAlternatingTints( windowNameTable["ListView"].."List", 12 )
	--ButtonSetText(windowNameTable["ListView"].."ButtonClearSelectedButton_All", L"Clear")
	
	----- RANGE VIEW -----
	LabelSetText(windowNameTable["ButtonSelectWindow"].."ButtonRangeViewInputLabel",L"Manual Input")
	LabelSetText(windowNameTable["ButtonSelectWindow"].."ButtonRangeViewInputBetweenLabel",L" - ")
	LabelSetText(windowNameTable["ButtonSelectWindow"].."ButtonRangeViewSelectLabel",L"Select Buttons")
	LabelSetText(windowNameTable["RangeView"].."ComboLabelBetween",L" - ")


end

function TastyButtonsOptions.Fill_StanceBox()
	local noStanceAdded = true 
	ComboBoxClearMenuItems(windowNameTable["StateView"].."ComboStanceAdd")
	ComboBoxAddMenuItem( windowNameTable["StateView"].."ComboStanceAdd",towstring(stanceName[0]))
	ComboBoxSetSelectedMenuItem( windowNameTable["StateView"].."ComboStanceAdd",1)
--	TastyButtons.Print("IM ADDING STANCES TO THE COMBO BOX NOW")
	local standardAbilities = GetAbilityTable (GameData.AbilityType.STANDARD)   
  -- Not the most efficient thing, but doesn't happen often enough that this will ever matter.
    for abilityId, abilityData in pairs (standardAbilities) do
	--	TastyButtons.Print("abilityId is :"..abilityId) 
		--TastyButtons.Print("abilityData is :"..tostring(abilityData.name)) 
		for stanceId in pairs(stanceName) do
			if abilityId == stanceId then 
				ComboBoxAddMenuItem( windowNameTable["StateView"].."ComboStanceAdd",towstring(stanceName[stanceId]))
				noStanceAdded = false
			end
		end
		for _,petName in pairs(petNameTable) do
			if abilityData.name == petName then
				ComboBoxAddMenuItem( windowNameTable["StateView"].."ComboStanceAdd",towstring(petName))
				noStanceAdded = false			
			end
		end
	end
	if noStanceAdded then
		ComboBoxSetDisabledFlag(windowNameTable["StateView"].."ComboStanceAdd", true)
	  else
		ComboBoxSetDisabledFlag(windowNameTable["StateView"].."ComboStanceAdd", false)		
	end
end

function TastyButtonsOptions.Shutdown()
	DestroyWindow(windowNameTable["ButtonInfoWindow"])
	DestroyWindow(windowNameTable["default"])
	DestroyWindow(windowNameTable["ButtonSelectWindow"])
	UnregisterEventHandler (SystemData.Events.L_BUTTON_UP_PROCESSED,"TastyButtonsOptions.OnLButtonUpProcessed")  
end


------------------------ XML ELEMENT FUNCTIONS ------------------
----------------------- BUTTON STUFF FROM HERE -----------------
function TastyButtonsOptions.CreateButton()
	local firstButton = TastyButtonsOptions.onNil_setZero(tonumber(tostring(TextEditBoxGetText( windowNameTable["CreateView"].."EditCreateFirst" )):match("(%d+)")))
	local lastButton = TastyButtonsOptions.onNil_setZero(tonumber(tostring(TextEditBoxGetText( windowNameTable["CreateView"].."EditCreateLast" )):match("(%d+)")))
	local scale = tostring(TextEditBoxGetText( windowNameTable["CreateView"].."EditScale")):match("(%d*[.]?%d+)")
	--local buttonShape = tostring(ButtonGetText(comboBoxButtonName["ComboShape"]..ComboBoxGetSelectedMenuItem(comboBoxButtonName["ComboShapeBox"])))
	local buttonShape = ButtonGetPressedFlag(windowNameTable["CreateView"].."CheckisButtonRoundButton")
	local useCustomTextures = ButtonGetPressedFlag(windowNameTable["CreateView"].."CheckCustomTextureButton")
	local buttonSlot = 0

	if ((firstButton > 0) and (lastButton > 0) and (firstButton ~= lastButton)) then 
		local buttonTable = TastyButtons.Button_makeTable(firstButton, lastButton)
		TastyButtons.Button_Create_fromTable(buttonTable, scale, useCustomTextures, buttonShape)
		TastyButtons.Print("Buttons "..firstButton.." to "..lastButton.." created")
	  elseif firstButton > 0 then
		buttonSlot = TastyButtons.Button_Create_fromOptions(scale, firstButton, useCustomTextures, buttonShape)
	  elseif lastButton > 0 then
		for n = 1, lastButton do
			TastyButtons.Button_Create_fromOptions(scale, nil, useCustomTextures, buttonShape)
		end
	  else	
		buttonSlot = TastyButtons.Button_Create_fromOptions(scale, nil, useCustomTextures, buttonShape)

	end
	if buttonSlot ~= 0 then
		TastyButtons.Print("Button "..buttonSlot.." created")
	end
	TastyButtonsOptions.UpdateComboButton()
	for k,v in pairs(TastyButtons.GetButtonHandles()) do
		LabelSetText (v:GetName ().."ActionText", towstring(v:GetSlot())) --make buttons show their slotnumber
	end
end


function TastyButtonsOptions.Get_ButtonsfromSelectWindow()
	local buttonTable = {}
	if selectionMode == 0 then
		buttonTable = TastyButtonsOptions.Get_SelectedButtons()	
	  elseif selectionMode == 1 then
		buttonTable = TastyButtonsOptions.Get_SelectedButtons()
		table.sort(buttonTable)
	  elseif selectionMode == 2 then
		buttonTable = TastyButtonsOptions.Get_ButtonsfromManual()
	  elseif selectionMode == 3 then
		buttonTable = TastyButtonsOptions.Get_ButtonsfromSelection()
	  else
		TastyButtons.Print("No SelectionMode selected")
	end 
	return buttonTable
end

function TastyButtonsOptions.Get_ButtonsfromManual()
	local firstButton = TastyButtonsOptions.onNil_setZero(tonumber(tostring(TextEditBoxGetText( windowNameTable["RangeView"].."EditFirst" )):match("(%d+)")))
	local lastButton = TastyButtonsOptions.onNil_setZero(tonumber(tostring(TextEditBoxGetText( windowNameTable["RangeView"].."EditLast" )):match("(%d+)")))
	local buttonTable = {}

	if ((firstButton > 0) and (lastButton > 0) and (firstButton ~= lastButton)) then 
		buttonTable = TastyButtons.Button_makeTable(firstButton, lastButton)
	  elseif firstButton > 0 then
		table.insert(buttonTable,firstButton)
	end
	
	local complexButtonString = TextEditBoxGetText( windowNameTable["RangeView"].."EditComplex" )
	if complexButtonString ~= nil and complexButtonString ~= "" then
		complexButtonString = tostring(complexButtonString)
		for button in string.gfind(complexButtonString, "(%d+)") do
			table.insert(buttonTable,tonumber(button))
		end
	end
	
	return buttonTable
end

function TastyButtonsOptions.Get_ButtonsfromSelection()
	local firstButton = tonumber((buttonList[ComboBoxGetSelectedMenuItem(windowNameTable["RangeView"].."ComboFirstButton")-1]))
	local lastButton = tonumber((buttonList[ComboBoxGetSelectedMenuItem(windowNameTable["RangeView"].."ComboLastButton")-1]))
	local buttonTable = {}
	d(firstButton)
	d(lastButton)
	if ((firstButton > 0) and (lastButton > 0) and (firstButton ~= lastButton)) then
		buttonTable = TastyButtons.Button_makeTable(firstButton, lastButton)
	  elseif firstButton > 0 then
		table.insert(buttonTable,firstButton)
	end
	
	return buttonTable
end

function TastyButtonsOptions.Get_SelectedButtons()
	return selectedButtonsTable
end

function TastyButtonsOptions.ScaleButton()
	local scale = tostring(TextEditBoxGetText( windowNameTable["EditView"].."EditScale")):match("(%d*[.]?%d+)")
	local buttonTable = {}
	buttonTable = TastyButtonsOptions.Get_ButtonsfromSelectWindow()
	if ((scale == nil) or (scale == ".") or (tonumber(scale) > 3)) then
		scale = InterfaceCore.GetScale()
	end

	if buttonTable ~= {} then
		TastyButtons.Button_SetScale_fromTable(buttonTable,scale)
	end
end

function TastyButtonsOptions.SetPosButton()
	local x = tonumber(tostring(TextEditBoxGetText( windowNameTable["EditView"].."EditSetPosX" )):match("(%d+)"))
	local y = tonumber(tostring(TextEditBoxGetText( windowNameTable["EditView"].."EditSetPosY" )):match("(%d+)"))
	local buttonSlot
	
	if selectedButtonsTable[1] ~= nil then
		buttonSlot = selectedButtonsTable[1]
	  else
		TastyButtons.Print("You must select a Button first")
		return
	end

	x = TastyButtonsOptions.onNil_setZero(x)
	y = TastyButtonsOptions.onNil_setZero(y)
	
	if (buttonSlot ~= nil) and (buttonSlot > 0) then
		TastyButtons.Window_Set_Pos(ButtonNameStart..buttonSlot, x, y)
	end
		
end

function TastyButtonsOptions.Button_Set_Texture()
	DialogManager.MakeThreeButtonDialog( 	L"Changes will take effext after UI-Reload",
											L"Reload Now", 
											function () TastyButtonsOptions.Set_Texture()	
														InterfaceCore.ReloadUI() end, 
											L"Reload Later", 
											function () TastyButtonsOptions.Set_Texture() end,
											L"Cancel", 
											nil, 
											nil, nil )
end

function TastyButtonsOptions.Set_Texture()
	local isRound = ButtonGetPressedFlag(windowNameTable["EditView"].."CheckisButtonRoundButton")
	local isCustom = ButtonGetPressedFlag(windowNameTable["EditView"].."CheckCustomTextureButton")
	local buttonTable = TastyButtonsOptions.Get_ButtonsfromSelectWindow()
	TastyButtons.Button_Set_Texture_fromTable(buttonTable, isCustom, isRound)
end


function TastyButtonsOptions.SetOORTint()
	TastyButtonsOptions.FontManagingFunction("OORTint")
end

function TastyButtonsOptions.SetABCTint()
	TastyButtonsOptions.FontManagingFunction("ABCTint")
end

function TastyButtonsOptions.SetTimerFont()
	TastyButtonsOptions.FontManagingFunction("Timer")
end

function TastyButtonsOptions.SetHotKeyFont()
	TastyButtonsOptions.FontManagingFunction("HotKey")
end

function TastyButtonsOptions.FontManagingFunction(label)
	local font = availableFontsTable[ComboBoxGetSelectedMenuItem(windowNameTable["EditView"].."ComboFont")]
	local r = SliderBarGetCurrentPosition(windowNameTable["EditView"].."SliderColorR")
	local g = SliderBarGetCurrentPosition(windowNameTable["EditView"].."SliderColorG")
	local b = SliderBarGetCurrentPosition(windowNameTable["EditView"].."SliderColorB")
	
	r = r * 255
	g = g * 255
	b = b * 255
	
	if r > 255 then r = 255 end
	if g > 255 then g = 255 end
	if b > 255 then b = 255 end
	
	
	if label == "Timer" then
		TastyButtons.Set_CooldownTimerFont_All(font)
		if ButtonGetPressedFlag(windowNameTable["EditView"].."ButtonChangeFontColor") then
			TastyButtons.Set_CooldownTimerFontColor_All(r,g,b)
		end
	  elseif label == "HotKey" then
		TastyButtons.Set_HotKeyFont_All(font)
		if ButtonGetPressedFlag(windowNameTable["EditView"].."ButtonChangeFontColor") then
			TastyButtons.Set_HotKeyFontColor_All(r,g,b)
		end
	  elseif label == "OORTint" then
		TastyButtons.Set_OORTint_All(r,g,b)
	  elseif label == "ABCTint" then
		TastyButtons.Set_ABCTint_All(r,g,b)
	end
end

function TastyButtonsOptions.BlockButton()
	local rows = TextEditBoxGetText(windowNameTable["GroupView"].."EditBlockRows"):match(L"(%d+)")
	local columns = TextEditBoxGetText(windowNameTable["GroupView"].."EditBlockColumns"):match(L"(%d+)")
	local x = TastyButtonsOptions.onNil_setZero(tonumber(tostring(TextEditBoxGetText( windowNameTable["GroupView"].."EditGroupXGap" )):match("([-]?%d+)")))
	local y = TastyButtonsOptions.onNil_setZero(tonumber(tostring(TextEditBoxGetText( windowNameTable["GroupView"].."EditGroupYGap" )):match("([-]?%d+)")))	
	local buttonTable = TastyButtonsOptions.Get_ButtonsfromSelectWindow()
	local rowdirection = directionTable[ComboBoxGetSelectedMenuItem(windowNameTable["GroupView"].."ComboRowDirection")]
	local columndirection = directionTable[ComboBoxGetSelectedMenuItem(windowNameTable["GroupView"].."ComboColumnDirection")]

	
	if rows == nil or tonumber(rows) < 1 then rows = 1 else rows = tonumber(rows) end
	if columns == nil or tonumber(columns) < 1 then columns = 12 TastyButtons.Print("Columns set to default (12)") else columns = tonumber(columns) end	

	local anchorTable = TastyButtons.Button_Anchor_makeBlockTable(buttonTable, x, y, columndirection, rowdirection, columns, rows)
	TastyButtons.Button_Anchor_fromTable(anchorTable)
	
end

function TastyButtonsOptions.GroupButton()
	TastyButtonsOptions.GroupManagingFunction(false)
end

function TastyButtonsOptions.UnGroupButton()
	TastyButtonsOptions.GroupManagingFunction(true)
end

function TastyButtonsOptions.GroupManagingFunction(ungroup)

	local x = TastyButtonsOptions.onNil_setZero(tonumber(tostring(TextEditBoxGetText( windowNameTable["GroupView"].."EditGroupXGap" )):match("([-]?%d+)")))
	local y = TastyButtonsOptions.onNil_setZero(tonumber(tostring(TextEditBoxGetText( windowNameTable["GroupView"].."EditGroupYGap" )):match("([-]?%d+)")))	
	local toButton = tonumber(tostring(TextEditBoxGetText( windowNameTable["GroupView"].."EditGroupToButton" )):match("(%d+)"))	
	local direction = directionTable[ComboBoxGetSelectedMenuItem(windowNameTable["GroupView"].."ComboRowDirection")]
	local buttonTable = TastyButtonsOptions.Get_ButtonsfromSelectWindow()
	
	--TastyButtons.Print("tobutton is :"..toButton)
	if ungroup then
		if buttonTable ~= {} then
			TastyButtons.Button_Anchor_Ungroup_fromTable(buttonTable)
			TastyButtons.Print("Buttons ungrouped")
		  else
			TastyButtons.Print("No Buttons to Ungroup given")
		end
	  elseif buttonTable ~= {} then
		buttonTable = TastyButtons.Button_Anchor_makeTablefromTable(buttonTable , x, y, direction,toButton)
		TastyButtons.Button_Anchor_fromTable(buttonTable)	
	  else
		TastyButtons.Print("Wrong Usage of Group!")
	end
	
end

function TastyButtonsOptions.DeleteButton()
	local delAll = ButtonGetPressedFlag(windowNameTable["CreateView"].."CheckDelAllButton")
	local buttonTable = TastyButtonsOptions.Get_ButtonsfromSelectWindow()
	if delAll  then
		DialogManager.MakeTwoButtonDialog( 	L"Delete all Buttons?",
											L"Yup",
											TastyButtonsOptions.Delete_AllButtons,
											L"Nope",
											nil)
	  elseif buttonTable ~= {} then
		TastyButtons.Button_Delete_fromTable(buttonTable)
		TastyButtons.Print("Buttons deleted")
	  else
		TastyButtons.Print("Did not worx")
	end
		
end

function TastyButtonsOptions.Delete_AllButtons()
	local buttonTable = {}
	for _,buttonSlot in pairs(buttonList) do
		table.insert(buttonTable,buttonSlot)
	end
	TastyButtons.Button_Delete_fromTable(buttonTable)
end
------ STATES STUFF FROM HERE ON ------------

function TastyButtonsOptions.AddStateButton()
	TastyButtonsOptions.StateManagingFunction("add")
end

function TastyButtonsOptions.ActivateStateButton()
	TastyButtonsOptions.StateManagingFunction("load")
end

function TastyButtonsOptions.ModifyStateButton()
	TastyButtonsOptions.StateManagingFunction("mod")
end

function TastyButtonsOptions.ClearStateButton()
	TastyButtonsOptions.StateManagingFunction("clear")
end

function TastyButtonsOptions.DeleteStateButton()
	TastyButtonsOptions.StateManagingFunction("del")
end

function TastyButtonsOptions.StateManagingFunction(functionType)
	local stateName = tostring(ButtonGetText(comboBoxButtonName["ComboStateAdd"]..ComboBoxGetSelectedMenuItem(windowNameTable["StateView"].."ComboStateAdd")))
	local stanceName = tostring(ButtonGetText(comboBoxButtonName["ComboStanceAdd"]..ComboBoxGetSelectedMenuItem(windowNameTable["StateView"].."ComboStanceAdd")))
	local stateType = tostring(ButtonGetText(comboBoxButtonName["ComboStateType"]..ComboBoxGetSelectedMenuItem(windowNameTable["StateView"].."ComboStateType")))
	local showing = tostring(ButtonGetText(comboBoxButtonName["ComboShowing"]..ComboBoxGetSelectedMenuItem(comboBoxButtonName["ComboShowingBox"])))
	if showing == "false" then
		showing = false
	  else
		TastyButtons.Print("Showing is true")
		showing = true
	end
	if stateName == "OnResource" then
		local buttonNr = ComboBoxGetSelectedMenuItem(windowNameTable["StateView"].."ComboResource") 
		local resource = comboBoxResourcesFuckTardShitForSuckyComboBoxes[buttonNr]
		local shaarchplus = 0
		if ((playerClass:match("Shaman")) or (playerClass:match("Archmage"))) then
			resource = buttonNr
		  else	
			resource = tonumber(resource:match("(%d+)"))
		end
		stateName = stateName..resource
	end
	TastyButtons.PrintD("Stance is: "..stanceName)
	if selectioMode == 2 then
		TastyButtons.Print("Manual Selection not allowed when Adding State")
		return
	end
	
	local buttonTable = TastyButtonsOptions.Get_ButtonsfromSelectWindow()
	
	if buttonTable ~= {} then
		if functionType == "del" then
			TastyButtons.Button_State_Del_fromTable(buttonTable, stanceName, stateName,stateType)
		  elseif functionType == "load" then
			TastyButtons.Button_State_Load_fromTable(buttonTable, stanceName, stateName,stateType)
		  elseif functionType == "clear" then
			TastyButtons.Button_State_Clear_fromTable(buttonTable, stanceName, stateName,stateType)
		  elseif functionType == "mod" then
			TastyButtons.Button_State_Modify_fromTable(buttonTable, stanceName, stateName,stateType,showing)		
		  else
			TastyButtons.Button_State_Add_fromTable(buttonTable, stanceName, stateName,stateType,showing)
		end 
	  else
		TastyButtons.Print("The You must select Buttons first!")
	end
	TastyButtonsOptions.UpdateStateLists()
end

function TastyButtonsOptions.Fill_ProfileBox()
	ComboBoxClearMenuItems(comboBoxButtonName["ComboProfileBox"])	
	for profileName,_ in pairs(TastyButtonsProfiles) do
		ComboBoxAddMenuItem( comboBoxButtonName["ComboProfileBox"],towstring(profileName))
	end
end

function TastyButtonsOptions.ButtonSaveProfile()
	local profileName = TextEditBoxGetText(windowNameTable["ProfileWindow"].."EditProfileName")
	if profileName == nil then 
		TastyButtons.Print("Please enter a Profilename")
		return
	end
	if not tostring(profileName):match("[%w*%_?%w+]*") then
		TastyButtons.Print("Only Alphanumeric Characters and \"_\" are allowed for Profilenames")
		return
	end
	profileName = tostring(profileName):match("[%w*%_?%w+]*")
	if TastyButtonsProfiles[profileName] ~= nil then
		DialogManager.MakeTwoButtonDialog( 	L"Want to overwrite Profile: "..towstring(profileName)..L" ?",
											L"Aye",
											function () TastyButtons.SaveProfile(profileName) TastyButtonsOptions.Fill_ProfileBox() end ,
											L"No-ho-ho",
											nil)
	  else
		TastyButtons.SaveProfile(profileName)
		TastyButtonsOptions.Fill_ProfileBox()		
	end
end

function TastyButtonsOptions.ButtonDelProfile()
	local profileName = tostring(ButtonGetText((comboBoxButtonName["ComboProfile"]..ComboBoxGetSelectedMenuItem(comboBoxButtonName["ComboProfileBox"]))))
	DialogManager.MakeTwoButtonDialog( 	L"Want to delete Profile: "..towstring(profileName)..L" ?",
										L"Hell Yeah!",
										function () TastyProfiles.DeleteProfile(profileName) TastyButtonsOptions.Fill_ProfileBox() end ,
										L"plz not ;_;",
										nil)		
end

function TastyButtonsOptions.ButtonLoadProfile()
	local profileName = tostring(ButtonGetText((comboBoxButtonName["ComboProfile"]..ComboBoxGetSelectedMenuItem(comboBoxButtonName["ComboProfileBox"]))))
	DialogManager.MakeTwoButtonDialog( 	L"Want to load Profile: "..towstring(profileName)..L" ?",
										L"Yeh",
										function () TastyButtons.LoadProfile(profileName) end ,
										L"Nah",
										nil)				
end
-------- All Time Available Stuff----------------

function TastyButtonsOptions.ClearEditComplex()
	TextEditBoxSetText( windowNameTable["RangeView"].."EditComplex",L"")
end

function TastyButtonsOptions.ClearCreateView()
	TextEditBoxSetText(windowNameTable["CreateView"].."EditCreateFirst",L"")
	TextEditBoxSetText(windowNameTable["CreateView"].."EditCreateLast",L"")
	TextEditBoxSetText(windowNameTable["CreateView"].."EditScale",L"")
	TastyButtonsOptions.SetStayDownFlag(windowNameTable["CreateView"].."CheckCustomTextureButton", false )	
	TastyButtonsOptions.SetStayDownFlag(windowNameTable["CreateView"].."CheckisButtonRoundButton", false )		
	TastyButtonsOptions.SetStayDownFlag(windowNameTable["CreateView"].."CheckDelAllButton", false )	
	SliderBarSetCurrentPosition(windowNameTable["CreateView"].."ScaleSlider",0)
end


function TastyButtonsOptions.ClearEditView()
	TextEditBoxSetText(windowNameTable["EditView"].."EditScale",L"")
	TextEditBoxSetText(windowNameTable["EditView"].."EditSetPosY",L"0")
	TextEditBoxSetText(windowNameTable["EditView"].."EditSetPosX",L"0")
	
	ComboBoxSetSelectedMenuItem(windowNameTable["EditView"].."ComboFont",1)
	
	SliderBarSetCurrentPosition(windowNameTable["EditView"].."ScaleSlider",0)
	SliderBarSetCurrentPosition(windowNameTable["EditView"].."SliderColorR",0)
	SliderBarSetCurrentPosition(windowNameTable["EditView"].."SliderColorG",0)
	SliderBarSetCurrentPosition(windowNameTable["EditView"].."SliderColorB",0)
	
	TastyButtonsOptions.SetStayDownFlag(windowNameTable["EditView"].."ButtonChangeFontColor", false )	
	TastyButtonsOptions.SetStayDownFlag(windowNameTable["EditView"].."CheckCustomTextureButton", false )		
	TastyButtonsOptions.SetStayDownFlag(windowNameTable["EditView"].."CheckisButtonRoundButton", false )		
	
	

end
		

function TastyButtonsOptions.ClearGroupView()
	TextEditBoxSetText(windowNameTable["GroupView"].."EditGroupXGap",L"0")
	TextEditBoxSetText(windowNameTable["GroupView"].."EditGroupYGap",L"0")
	TextEditBoxSetText(windowNameTable["GroupView"].."EditGroupToButton",L"")
	ComboBoxSetSelectedMenuItem(windowNameTable["GroupView"].."ComboColumnDirection",6)	
	ComboBoxSetSelectedMenuItem(windowNameTable["GroupView"].."ComboRowDirection",7)	
end

function TastyButtonsOptions.ClearStateView()
	ComboBoxSetSelectedMenuItem( windowNameTable["StateView"].."ComboStateAdd",1)	
	ComboBoxSetSelectedMenuItem( windowNameTable["StateView"].."ComboStateType",1)	
	ComboBoxSetSelectedMenuItem( windowNameTable["StateView"].."ComboStanceAdd",1)
	ComboBoxSetSelectedMenuItem( windowNameTable["StateView"].."ComboResource",1)
	ComboBoxSetSelectedMenuItem( windowNameTable["StateView"].."ComboShowing",1)
end


function TastyButtonsOptions.ClearMiscView()
	TastyButtonsOptions.SetStayDownFlag(windowNameTable["MiscView"].."CheckGlobalCooldownButton", true )		
	TastyButtonsOptions.SetStayDownFlag(windowNameTable["MiscView"].."CheckTimeIndicatorButton", false )		
	TastyButtonsOptions.SetStayDownFlag(windowNameTable["MiscView"].."CheckAutoModeButton", false )		
	TastyButtonsOptions.SetStayDownFlag(windowNameTable["MiscView"].."CheckABCModeButton", false )		
	TastyButtonsOptions.SetStayDownFlag(windowNameTable["MiscView"].."CheckShowEmptyButton", true )		
	TastyButtonsOptions.SetStayDownFlag(windowNameTable["MiscView"].."CheckHideToolTipButton", true )		
	TastyButtonsOptions.SetStayDownFlag(windowNameTable["MiscView"].."CheckTintIconOnlyButton", false )		
	TastyButtonsOptions.SetStayDownFlag(windowNameTable["MiscView"].."CheckShowHotkeysButton", true )	
	
	TastyButtonsOptions.SetStayDownFlag(windowNameTable["MiscView"].."CheckAPHandlerButton", true )		
	TastyButtonsOptions.SetStayDownFlag(windowNameTable["MiscView"].."CheckResourceHandlerButton", true )		
end


function TastyButtonsOptions.ClearEditRange()
	TextEditBoxSetText( windowNameTable["RangeView"].."EditFirst",L"")
	TextEditBoxSetText( windowNameTable["RangeView"].."EditLast",L"")
	TextEditBoxSetText( windowNameTable["RangeView"].."EditComplex",L"")
end

--- Called Function from the Xml Window ... or so----

function TastyButtonsOptions.ToggleActionBarsButton()
	local buttonText = tostring(ButtonGetText(windowNameTable["GeneralWindow"].."ButtonToggleBars"))
	if string.find(buttonText,"on") then
		TastyButtons.ActionBars_Deactivate()
	  else
		TastyButtons.ActionBars_Activate()
	end
end

function TastyButtonsOptions.ToggleAddon()
	local buttonText = tostring(ButtonGetText(windowNameTable["GeneralWindow"].."ButtonAddonEnabled"))
	if string.find(buttonText,"Enabled") then
		TastyButtons.ToggleEnabled("off")
	  else
		TastyButtons.ToggleEnabled("on")
	end
end


function TastyButtonsOptions.ToggleStateTypeButton(stateType)

end

function TastyButtonsOptions.ToggleChangeFontColor()
	local buttonNamae = windowNameTable["EditView"].."ButtonChangeFontColor"
	if ButtonGetPressedFlag(buttonNamae) then
		TastyButtonsOptions.SetStayDownFlag(buttonNamae,false)
	  else
		TastyButtonsOptions.SetStayDownFlag(buttonNamae,true)
	end
end

function TastyButtonsOptions.OnTabSelect()
	
	if Cursor.IconOnCursor() then
        Cursor.Clear()
    end
	
	local viewId = WindowGetId( SystemData.ActiveWindow.name )
	TastyButtonsOptions.Set_View(viewId)
	
end

function TastyButtonsOptions.OnButton_RightClick()
    local owin="TastyButtonsOptionsButtonInfoWindow"
	if not WindowGetShowing(owin) or buttonHandles == nil then return end
	for k,v in pairs(buttonHandles) do
		if v:GetName() == SystemData.ActiveWindow.name then
			if not WindowGetShowing(windowNameTable["ButtonInfoWindow"]) then
				WindowSetShowing(windowNameTable["ButtonInfoWindow"],true)
			end
			ComboBoxSetSelectedMenuItem("TastyButtonsOptionsButtonInfoWindowComboButton",v:GetSlot())
			TastyButtonsOptions.OnComboButtonSelectionChanged()
			break
		end
	end
end

function TastyButtonsOptions.OnLButtonUpProcessed()
	local PreviewButton="TastyButtonsOptionsButtonInfoWindowButtonIcon"
	if (SystemData.MouseOverWindow.name==PreviewButton) then
		TastyButtonsOptions.PreviewButtonMouseUp()
	end
end

function TastyButtonsOptions.OnEditLButtonUp()
	if Cursor.IconOnCursor() then
        Cursor.Clear()
    end
	local listRow = tostring(SystemData.MouseOverWindow.name)
	local unflagRow
	if listRow:match(windowNameTable["ButtonInfoWindowListState"]) then
		--STATE BUTTON PRESSED --
		unflagRow = lastInfoStateWnd 
		lastInfoStateWnd  = listRow
		currentState = tostring(ButtonGetText(listRow))
		
	  elseif listRow:match(windowNameTable["ButtonInfoWindowListStance"]) then
		--- STANCE BUTTON PRESSED --
		unflagRow = lastInfoStanceWnd 
		lastInfoStanceWnd  = listRow
		TastyButtonsOptions.UpdateListStateRows(listRow)
		currentState = "default"
		TastyButtonsOptions.SetStayDownFlag(lastInfoStanceWnd,false)
		lastInfoStateWnd = windowNameTable["ButtonInfoWindow"].."ListStateRow1Button"
		TastyButtonsOptions.SetStayDownFlag(lastInfoStanceWnd,true)
		TastyButtonsOptions.UpdateListStateRows()
	end
	TastyButtonsOptions.UpdateButtonInfo()
	--Unflag the old pressed Button --
	if unflagRow ~= nil then
		TastyButtonsOptions.SetStayDownFlag(unflagRow,false)
	end
	-- Flag the last pressed button --
	TastyButtonsOptions.SetStayDownFlag(listRow,true)
	TastyButtonsOptions.UpdateButtonInfo()
end


function TastyButtonsOptions.PreviewButtonMouseUp()
	if (currentButtonSlot==nil) then
		TastyButtons.PrintD("no buttonslot found")
		return
	end
	local PreviewButton="TastyButtonsOptionsButtonInfoWindowButtonIcon"
	local CursorSourceTranslation =
{
    [Cursor.SOURCE_ACTION_LIST] = GameData.PlayerActions.DO_ABILITY,
    [Cursor.SOURCE_EQUIPMENT]   = GameData.PlayerActions.USE_ITEM,
    [Cursor.SOURCE_INVENTORY]   = GameData.PlayerActions.USE_ITEM,
    [Cursor.SOURCE_QUEST_ITEM]  = GameData.PlayerActions.USE_ITEM,    
    [Cursor.SOURCE_MACRO]       = GameData.PlayerActions.DO_MACRO,
    [Cursor.SOURCE_CRAFTING]    = GameData.PlayerActions.DO_CRAFTING,
    
    -- The action-type keys are also in this table in case the cursor was created with one of them as the 
    -- source type!
    
    [GameData.PlayerActions.DO_ABILITY]     = GameData.PlayerActions.DO_ABILITY,
    [GameData.PlayerActions.USE_ITEM]       = GameData.PlayerActions.USE_ITEM,
    [GameData.PlayerActions.DO_MACRO]       = GameData.PlayerActions.DO_MACRO,
    [GameData.PlayerActions.DO_CRAFTING]    = GameData.PlayerActions.DO_CRAFTING,
}
	if (Cursor.IconOnCursor ()) then
        local spellId = Cursor.Data.ObjectId
		local actionType = CursorSourceTranslation[Cursor.Data.Source]
		local iconId=TastyButtonsButton.GetIcon(nil,0,actionType,spellId)

		TastyButtons.PrintD(towstring("clearing cursor"))
        Cursor.Clear ()

		---------------------------------------------------------------SET ICOOOON
		    local texture           = L""
		    local disabledTexture   = L""
		    local x                 = 0
		    local y                 = 0
		    

		    local iconNum=iconId

		    local tintColor     = DefaultColor.ZERO_TINT
		    
		    if (iconNum > 0) then
		        texture, x, y, disabledTexture = GetIconData (iconNum)
		                
		        if (iconType == USE_DISABLED_ICON) then
		            if (disabledTexture ~= "") then
		                texture = disabledTexture
		            else
		                tintColor   = DefaultColor.MEDIUM_GRAY
		                iconType    = USE_ENABLED_ICON
		            end
		        end
				DynamicImageSetTexture(windowNameTable["ButtonInfoWindow"].."ButtonIconIcon", texture, x, y )
		    else
		        iconType = USE_EMPTY_ICON
		    end		
		TastyButtons.Button_State_Set(currentButtonSlot, spellId, iconNum, actionType, currentStance,currentState)

		---------------------------------------------------------------SET ICOOOON
	end
	
end

function TastyButtonsOptions.OnMouseOver()
	local anchor = { Point = "right",  RelativeTo = windowNameTable["ButtonInfoWindow"].."ButtonIcon" , RelativePoint = "left", XOffset = 20, YOffset = 0 }
	local clickText = L"Thanks for using Tasty Buttons!"
	if ((TastyButtonsOptions.buttonStates[currentStance] ~= nil) and (TastyButtonsOptions.buttonStates[currentStance][currentState] ~= nil)) then
		local actionId = TastyButtonsOptions.buttonStates[currentStance][currentState]["actionId"]
		local slotType = TastyButtonsOptions.buttonStates[currentStance][currentState]["actionType"]
		if (currentButtonSlot ~= nil)then
		    local tooltipFunction = MyCopyPastaIconCreator[slotType]
		    
		    if (tooltipFunction) then
		        tooltipFunction (actionId, clickText, anchor, slot)
		    end
					
		end
	end	
end

function TastyButtonsOptions.OnRButtonUp()
	local petSkillsPlus = DataUtils.CopyTable(petSkills)
	local standardAbilities = GetAbilityTable (GameData.AbilityType.PET)   
	for abilityId, abilityData in pairs (standardAbilities) do
		petSkillsPlus[abilityData.name] = { abilityId = abilityId, abilityName = towstring(abilityData.name), iconNum = abilityData.iconNum, abilityType =GameData.PlayerActions.COMMAND_PET_DO_ABILITY}
	end	
	local windowName = SystemData.ActiveWindow.name
	EA_Window_ContextMenu.CreateContextMenu( windowName )
	for petSkillName, petSkill in pairs(petSkillsPlus) do
		EA_Window_ContextMenu.AddMenuItem( petSkill.abilityName, function () if currentButtonSlot ~= nil then
											TastyButtons.Button_State_Set(currentButtonSlot, petSkill.abilityId, petSkill.iconNum, petSkill.abilityType , 											 currentStance,currentState)
											local texture, x, y = GetIconData(petSkill.iconNum)
											DynamicImageSetTexture(windowNameTable["ButtonInfoWindow"].."ButtonIconIcon", texture, x, y )

											end
											end, false, true )
	end
	TastyButtonsOptions.UpdateButtonInfo(currentState,currentStance,false)
	EA_Window_ContextMenu.Finalize()
	WindowSetLayer("EA_Window_ContextMenu1", 4)
end

function TastyButtonsOptions.OnComboStateChanged()
	if DoesWindowExist(comboBoxButtonName["ComboStateAdd"]..ComboBoxGetSelectedMenuItem(windowNameTable["StateView"].."ComboStateAdd")) then
		local stateName = ButtonGetText(comboBoxButtonName["ComboStateAdd"]..ComboBoxGetSelectedMenuItem(windowNameTable["StateView"].."ComboStateAdd"))
		if stateName == L"OnResource" then
			ComboBoxSetDisabledFlag(windowNameTable["StateView"].."ComboResource", false)
		  else
			ComboBoxSetDisabledFlag(windowNameTable["StateView"].."ComboResource", true)
		end
	end
end

function TastyButtonsOptions.OnComboFontChanged()
	local font = availableFontsTable[ComboBoxGetSelectedMenuItem(windowNameTable["EditView"].."ComboFont")]
	if not font then font = "font_clear_medium" end
	LabelSetFont(windowNameTable["EditView"].."ColorPreview", font, 29)
end

function TastyButtonsOptions.OnMenuButtonLUp()
	TastyButtons.Button_State_TypeToggle()
end

function TastyButtonsOptions.OnMenuButtonRUp(flags, x, y)
	if (flags == SystemData.ButtonFlags.SHIFT) then
		TastyButtonsOptions.ToggleGeneral()
	  else
		TastyButtonsOptions.Toggle()
	end
	
end

function TastyButtonsOptions.OnMenuButtonMouseOver()
	local anchor = { Point="bottomright", RelativeTo=windowNameTable["MenuButton"], RelativePoint="topright", XOffset=5, YOffset=5 }
	Tooltips.CreateTwoLineActionTooltip( 	L"Leftclick:\n   Switch PvE/RvR Mode\nRightclick:\n   Button-Options-Window \nShift-RightClick:\n  General Options Window", 
											L"Tasty Buttons are Tasty!", windowNameTable["MenuButton"], anchor )
end

function TastyButtonsOptions.OnSlidingCeateView()
	TastyButtonsOptions.OnSlidingScale("CreateView")
end

function TastyButtonsOptions.OnSlidingEditView()
	TastyButtonsOptions.OnSlidingScale("EditView")
end

function TastyButtonsOptions.OnSlidingScale(view)

	local pos = SliderBarGetCurrentPosition(windowNameTable[view].."ScaleSlider")
	local scale = 3 * pos
	if scale == 0 then
		scale = 0.01
	  elseif  scale > 3 then 
		scale = InterfaceCore.GetScale()
	end
	scale = tonumber(string.sub(tostring(scale),1,4))

	TextEditBoxSetText(windowNameTable[view].."EditScale",towstring(scale))		
end



function TastyButtonsOptions.OnSlidingColor()
	local r = SliderBarGetCurrentPosition(windowNameTable["EditView"].."SliderColorR")
	local g = SliderBarGetCurrentPosition(windowNameTable["EditView"].."SliderColorG")
	local b = SliderBarGetCurrentPosition(windowNameTable["EditView"].."SliderColorB")
	
	r = r * 255
	g = g * 255
	b = b * 255
	
	if r > 255 then r = 255 end
	if g > 255 then g = 255 end
	if b > 255 then b = 255 end
	
	LabelSetTextColor(windowNameTable["EditView"].."ColorPreview",r,g,b)
	
end

function TastyButtonsOptions.OnComboButtonSelectionChanged()
	local buttonSlot = tonumber((buttonList[ComboBoxGetSelectedMenuItem(windowNameTable["ButtonInfoWindow"].."ComboButton")]))
	if ((buttonSlot ~= nil) and (buttonSlot > 0)) then
		currentButtonSlot = buttonSlot
		-- get Button States according to the selected Slot --
		TastyButtonsOptions.buttonStates = TastyButtons.Get_States(buttonSlot)
		currentStateType = TastyButtons.Get_stateType(currentButtonSlot)		
		TastyButtonsOptions.UpdateStateLists()
		TastyButtonsOptions.UpdateButtonInfo()
		
		
		-- Get buttonInfo ----
		local buttonInfo = TastyButtons.Get_ButtonInfo(buttonSlot)
		local relWin = "none"
		if buttonInfo["anchor"] ~= nil then
			relWin = buttonInfo["anchor"]["relWin"]
			if ((relWin ~= "root") and (relWin ~= "Root")) then
				relWin = relWin:match(".*(%d+)")	
			end
		end
		
		local scale = tostring(buttonInfo["scale"]):match("(%d*[.]%d?%d?)")
		local x = string.sub(buttonInfo["x"],1,5)
		local y = string.sub(buttonInfo["y"],1,5)
		
		--Set buttonInfo the the Labels ---
		LabelSetText(windowNameTable["ButtonInfoWindow"].."AnchoredTo",towstring(relWin))
		LabelSetText(windowNameTable["ButtonInfoWindow"].."Scale",towstring(scale))
		LabelSetText(windowNameTable["ButtonInfoWindow"].."X",towstring(x))
		LabelSetText(windowNameTable["ButtonInfoWindow"].."Y",towstring(y))
		LabelSetText(windowNameTable["ButtonInfoWindow"].."ButtonMode",towstring(currentStateType))
		
	  else
	 	for n =1 , 7 do
			ButtonSetText(windowNameTable["ButtonInfoWindowListStance"]..n.."Button",L"")
			ButtonSetText(windowNameTable["ButtonInfoWindowListState"]..n.."Button",L"")
		end	 
	end
end

--buttonStateTable[buttonSlot][stanceName][stateName] =  {	actionId, 		<== the actionId of the ability/item/macro wuteva 
--															iconNum,		<== the icon Number according to the actionId
--															actionType}		<== the Type of the action (captain obvious ftw!)
-- Function called when the TastyButtonsOptions.buttonStates is changed --
function TastyButtonsOptions.UpdateListStanceRows(clearFlag)
	for n =1 , 7 do
		ButtonSetText(windowNameTable["ButtonInfoWindowListStance"]..n.."Button",L"")
	end	
	if not clearFlag then
		local count = 2
		for stanceName in pairs(TastyButtonsOptions.buttonStates) do
			if ((count <= 7)  and (stanceName ~="clear")) then
				if stanceName ~= "normal" then
					ButtonSetText(windowNameTable["ButtonInfoWindowListStance"]..count.."Button",towstring(stanceName))
					count = count + 1
				  else
					ButtonSetText(windowNameTable["ButtonInfoWindowListStance"].."1Button",towstring(stanceName))
				end
			end
		end
	end
end

-- function called when the selected stance changed --
function TastyButtonsOptions.UpdateListStateRows(clearFlag)
	for n =1 , 7 do
		ButtonSetText(windowNameTable["ButtonInfoWindowListState"]..n.."Button",L"")
	end
	if not clearFlag then
		local stanceName = tostring(ButtonGetText(lastInfoStanceWnd))
		if stanceName ~= nil then
			currentStance = stanceName
		  else
			stanceName = "normal"
		end
		local count = 2
		for stateName in pairs(TastyButtonsOptions.buttonStates[stanceName]) do
			if count <= 7 then
				if stateName ~= "default" then
					ButtonSetText(windowNameTable["ButtonInfoWindowListState"]..count.."Button",towstring(stateName))
					count = count + 1
				  else
				   	ButtonSetText(windowNameTable["ButtonInfoWindowListState"].."1Button",towstring(stateName))
				end
			  else
				TastyButtons.Print("this should be impossible ... at least for now!")
			end
		end
	end	
end

function TastyButtonsOptions.Fill_StateComboBox()
	ComboBoxClearMenuItems(windowNameTable["StateView"].."ComboStateAdd")
	ComboBoxAddMenuItem( windowNameTable["StateView"].."ComboStateAdd",availableStates[1])
	ComboBoxAddMenuItem( windowNameTable["StateView"].."ComboStateAdd",availableStates[2])
	if TastyButtons_Settings["APHandler"] then
		ComboBoxAddMenuItem( windowNameTable["StateView"].."ComboStateAdd",availableStates[3])
	end
	if petNameTable[GameData.Player.career.line] ~= nil then
		for _,petName in pairs(petNameTable[GameData.Player.career.line]) do
			ComboBoxAddMenuItem( windowNameTable["StateView"].."ComboStateAdd",petName)
		end
	end
	ComboBoxSetSelectedMenuItem( windowNameTable["StateView"].."ComboStateAdd",1)
end

function TastyButtonsOptions.UpdateButtonInfo(stateName,stanceName, clearFlag)
	if not clearFlag then
		if stateName == nil then
			stateName = currentState
		end	
		if stanceName == nil then
			stanceName = currentStance
		end
		local showing = "true"
		if ((TastyButtonsOptions.buttonStates ~= nil) and (TastyButtonsOptions.buttonStates[stanceName] ~= nil) and (TastyButtonsOptions.buttonStates[stanceName][stateName]  ~=nil)) then
			local iconNum = TastyButtonsOptions.buttonStates[stanceName][stateName]["iconNum"] --:match("(%d+)")
			local texture, x, y,_ = GetIconData(iconNum)   
			if texture ~= nil then
				DynamicImageSetTexture(windowNameTable["ButtonInfoWindow"].."ButtonIconIcon", texture, x, y )
			end
			if TastyButtonsOptions.buttonStates[stanceName][stateName]["showing"] ~= nil then
				if TastyButtonsOptions.buttonStates[stanceName][stateName]["showing"] == false then
					showing = "false"
				end
			end
			local actionId = TastyButtonsOptions.buttonStates[stanceName][stateName]["actionId"]
			LabelSetText(windowNameTable["ButtonInfoWindow"].."HiddenLabelBool",towstring(showing))
			LabelSetText(windowNameTable["ButtonInfoWindow"].."ActionIdLabel",towstring(actionId))
			LabelSetText(windowNameTable["ButtonInfoWindow"].."IconNumLabel",towstring(iconNum))			
		end
	  else
		local texture, x, y,_ = GetIconData( 0 )
		DynamicImageSetTexture(windowNameTable["ButtonInfoWindow"].."ButtonIconIcon", texture, x, y )
		LabelSetText(windowNameTable["ButtonInfoWindow"].."HiddenLabelBool",L"")
		LabelSetText(windowNameTable["ButtonInfoWindow"].."ActionIdLabel",L"")
		LabelSetText(windowNameTable["ButtonInfoWindow"].."IconNumLabel",L"")
	end


end


function TastyButtonsOptions.Set_ModeManual()
	selectionMode = 2
	TastyButtonsOptions.SetStayDownFlag(windowNameTable["RangeView"].."ButtonSetModeManual",true)
	TastyButtonsOptions.SetStayDownFlag(windowNameTable["RangeView"].."ButtonSetModeSelect",false)
end

function TastyButtonsOptions.Set_ModeSelect()
	selectionMode = 3
	TastyButtonsOptions.SetStayDownFlag(windowNameTable["RangeView"].."ButtonSetModeManual",false)
	TastyButtonsOptions.SetStayDownFlag(windowNameTable["RangeView"].."ButtonSetModeSelect",true)		
end


function TastyButtonsOptions.Set_View(viewId)
	if viewId < 10 then
		TastyButtonsOptions.Set_SelectedView(viewId)
	  elseif (viewId == 10 or viewId == 11) then
		TastyButtonsOptions.Set_ButtonSelectView(viewId)
	  else
		d("Something went wrong, while changing Views")	
	end
end

function TastyButtonsOptions.Set_SelectedView(viewId)
	for id,viewTable in pairs(viewNameTable) do
		if id < 10 then
			if id == viewId then
				WindowSetShowing(viewTable.viewName,true)
				TastyButtonsOptions.SetStayDownFlag( viewTable.tabName, true)
			  else	
			  	TastyButtonsOptions.SetStayDownFlag( viewTable.tabName, false)
				WindowSetShowing(viewTable.viewName,false)
			end
		end
	end
end

function TastyButtonsOptions.Set_ButtonSelectView(viewId)
	for id,viewTable in pairs(viewNameTable) do
		if id >= 10 then
			if id == viewId then
				WindowSetShowing(viewTable.viewName,true)
				TastyButtonsOptions.SetStayDownFlag( viewTable.tabName, true)
				selectedButtonsTable = {}
				selectionMode = 0
			  else	
			  	TastyButtonsOptions.SetStayDownFlag( viewTable.tabName, false)
				WindowSetShowing(viewTable.viewName,false)
				if ButtonGetPressedFlag(windowNameTable["RangeView"].."ButtonSetModeSelect") then
					selectionMode = 3
				  else
					selectionMode = 2
					TastyButtonsOptions.SetStayDownFlag(windowNameTable["RangeView"].."ButtonSetModeManual",true)
					TastyButtonsOptions.SetStayDownFlag(windowNameTable["RangeView"].."ButtonSetModeSelect",false)
				end
			end
			selectedButtonsTable = {}
			TastyButtonsOptions.ClearSelectedButton_All()
		end
	end
end


function TastyButtonsOptions.ToggleButtonInfo(closeFlag)
	if WindowGetShowing(windowNameTable["ButtonInfoWindow"]) then
		TastyButtonsOptions.UpdateButtonInfo(nil,nil, true)
		WindowSetShowing(windowNameTable["ButtonInfoWindow"],false)
		TastyButtonsOptions.UpdateListStanceRows(true)
		TastyButtonsOptions.UpdateListStateRows(true)
		TastyButtonsOptions.SetStayDownFlag(windowNameTable["ButtonSelectWindow"].."ButtonInfoArrow", false)
	  else
		TastyButtonsOptions.UpdateButtonInfo(nil, nil, true)
		WindowSetShowing(windowNameTable["ButtonInfoWindow"],true)
		TastyButtonsOptions.UpdateListStanceRows(true)
		TastyButtonsOptions.UpdateListStateRows(true)
		TastyButtonsOptions.SetStayDownFlag(windowNameTable["ButtonSelectWindow"].."ButtonInfoArrow", true)		
	end
end

function TastyButtonsOptions.ToggleAdvancedOptions()
	if ButtonGetPressedFlag(windowNameTable["default"].."TabsGroupView") then
		TastyButtonsOptions.SetStayDownFlag(windowNameTable["default"].."TabsGroupView", false)
		WindowSetShowing(windowNameTable["AdvancedWindow"],false)
	  else
		TastyButtonsOptions.SetStayDownFlag(windowNameTable["default"].."TabsGroupView", true)
		WindowSetShowing(windowNameTable["AdvancedWindow"],true)
	end
	
end



--------- Side Functions ----------------
function TastyButtonsOptions.EditBox_Clear()

	TextEditBoxSetText( windowNameTable["CreateView"].."EditCreateFirst",L"")
	TextEditBoxSetText( windowNameTable["CreateView"].."EditCreateLast",L"")
	TextEditBoxSetText( windowNameTable["CreateView"].."EditScale",L"")
	
	TextEditBoxSetText( windowNameTable["CreateView"].."EditSetPosButton",L"" )
	TextEditBoxSetText( windowNameTable["CreateView"].."EditSetPosX",L"" )
	TextEditBoxSetText( windowNameTable["CreateView"].."EditSetPosY",L"" )
	
	TextEditBoxSetText( windowNameTable["CreateView"].."EditGroupFirst",L"")
	TextEditBoxSetText( windowNameTable["CreateView"].."EditGroupToButton",L"")
	TextEditBoxSetText( windowNameTable["CreateView"].."EditGroupLast",L"")
	TextEditBoxSetText( windowNameTable["CreateView"].."EditGroupXGap",L"")
	TextEditBoxSetText( windowNameTable["CreateView"].."EditGroupYGap",L"")

	TextEditBoxSetText( windowNameTable["CreateView"].."EditDeleteFirst",L"")
	TextEditBoxSetText( windowNameTable["CreateView"].."EditDeleteLast",L"")
	
end	

function TastyButtonsOptions.Add_Button_to_List(buttonSlot,groupNumber)
	if ((buttonSlot ~= nil) and (tonumber(buttonSlot) > 0)) then
		TastyButtonsOptions.AdvancedList(buttonSlot,groupNumber)
		table.insert(buttonList,buttonSlot)
		table.sort(buttonList)
		TastyButtonsOptions.buttonList = buttonList
		TastyButtonsOptions.Update_Button_List(buttonSlot)
		ListBoxSetDisplayOrder(windowNameTable["ListView"].."List", buttonList)
	end
end

function TastyButtonsOptions.AdvancedList(buttonSlot,groupNumber )
	advancedbuttonList[buttonSlot] = {slot = buttonSlot, group = groupNumber}
	--table.sort(advancedbuttonList)
end

function TastyButtonsOptions.Del_Button_from_List(buttonSlot)
	if ((buttonSlot ~= nil) and (tonumber(buttonSlot) > 0)) then
		for n in pairs(buttonList) do
			if buttonList[n] == buttonSlot then
				TastyButtons.PrintD("buttonSlot: "..buttonSlot)
				TastyButtons.PrintD("n "..n)
				TastyButtons.PrintD("buttonList[n]: "..buttonList[n])
				table.remove(buttonList,n)
			end
		end
		TastyButtonsOptions.ClearSelectedButton(buttonSlot)		
		table.sort(buttonList)
		TastyButtonsOptions.Update_Button_List()
		ListBoxSetDisplayOrder(windowNameTable["ListView"].."List", buttonList)
	end
end

function TastyButtonsOptions.Show()
	for k,v in pairs(TastyButtons.GetButtonHandles()) do
		LabelSetText (v:GetName ().."ActionText", towstring(v:GetSlot())) --make buttons show their slotnumber
	end
	
	TastyButtons.Set_HotkeyShowing_all(true, false)
	WindowSetShowing(windowNameTable["default"],true)
	WindowSetShowing(windowNameTable["ButtonSelectWindow"],true)
	TastyButtonsOptions.Set_SelectedView(1)
	TastyButtonsOptions.Set_ButtonSelectView(10)
	TastyButtonsOptions.Update_Button_List()
	currentButtonStateTable = TastyButtons.Get_currentButtonStateTable()
	TastyButtonsOptions.Fill_StanceBox()
	TastyButtonsOptions.Fill_ResourceComboBox()	
	TastyButtonsOptions.UpdateButtonSelectList()
end

function TastyButtonsOptions.Hide()
	for k,v in pairs(TastyButtons.GetButtonHandles()) do
		v:UpdateKeyBindingText() --make buttons show their keybindings
	end
	
	TastyButtons.Set_HotkeyShowing_all(TastyButtons_Settings["showHotkeys"], false)	
	WindowSetShowing(windowNameTable["default"],false)
	WindowSetShowing(windowNameTable["ButtonInfoWindow"],false)
	--WindowSetShowing(windowNameTable["AdvancedWindow"],false)
	WindowSetShowing(windowNameTable["ButtonSelectWindow"],false)
	TastyButtonsOptions.SetStayDownFlag(windowNameTable["MenuButton"],false)
	TastyButtons.Button_State_Load_activeCurrentState_forAll()
	TastyButtonsOptions.UpdateListStanceRows(true)
	TastyButtonsOptions.UpdateListStateRows(true)
end

function TastyButtonsOptions.GeneralWindowHide()
	TastyButtonsOptions.ToggleGeneral()
end

function TastyButtonsOptions.Toggle()
	if TastyButtons_Settings["enabled"] then
		if DoesWindowExist(windowNameTable["default"]) then
			local state = WindowGetShowing(windowNameTable["default"])
			if state then
				TastyButtonsOptions.Hide()
				TastyButtonsOptions.SetStayDownFlag(windowNameTable["MenuButton"],false)
			  else
				TastyButtonsOptions.Show()
				TastyButtonsOptions.SetStayDownFlag(windowNameTable["MenuButton"],true)
			end
		  else
			TastyButtons.Print("Options Window not created yet, type /tasty load")
		end	
	  else
		TastyButtons.Print("Addon must be loaded to show the options Window")
	end	
end

function TastyButtonsOptions.ToggleGeneral()
	if DoesWindowExist(windowNameTable["GeneralWindow"]) then
		local state = WindowGetShowing(windowNameTable["GeneralWindow"])
		if state then
			WindowSetShowing(windowNameTable["GeneralWindow"], false)
			WindowSetShowing(windowNameTable["ProfileWindow"],false)
			TastyButtonsOptions.SetStayDownFlag(windowNameTable["MenuButton"],false)
		  else
			WindowSetShowing(windowNameTable["GeneralWindow"], true)
			TastyButtonsOptions.SetStayDownFlag(windowNameTable["MenuButton"],true)
		end
	  else
		TastyButtons.Print("General Options Window not created yet, type /tasty load")
	end		
end

function TastyButtonsOptions.ToggleProfileWindow()
	if WindowGetShowing(windowNameTable["ProfileWindow"]) then
		WindowSetShowing(windowNameTable["ProfileWindow"],false)
	  else
		WindowSetShowing(windowNameTable["ProfileWindow"],true)
	end
	TastyButtonsOptions.Fill_ProfileBox()
end

local isRoundGlobal 	= false
local isCustomGlobal 	= false
local copyBars	 		= false

function TastyButtonsOptions.CopyActionBars()
	if TastyButtons_Settings["enabled"] then
		DialogManager.MakeTwoButtonDialog( L"Copy ActionBars to TastyButtons?",
										   L"Yup",
										   function () TastyButtons.CopyActionBars( isCustomGlobal, isRoundGlobal)	
														isRoundGlobal 		= false
														isCustomGlobal 		= false end,
										   L"Nope",
										   nil)
										   
		DialogManager.MakeTwoButtonDialog( L"Create Round Buttons?",
										   L"Yup",
										   function () isRoundGlobal = true end,
										   L"Nope",
										   nil)

		DialogManager.MakeTwoButtonDialog( L"Use Custom Textures?",
										   L"Yup",
										   function () isCustomGlobal = true end ,
										   L"Nope",
										   nil)
	end
end


function TastyButtonsOptions.UpdateComboButton()
	-- SET VARIABLES USED BACK TO DEFAULT VALUES --
	currentButtonSlot = nil
	currentState = "default"
	currentStance = "normal"
	lastInfoStanceWnd = nil
	lastInfoStateWnd = nil
	
	--- CLEAR ROWS OF THE LISTS AND UPDATE BUTTON LIST --
	TastyButtonsOptions.UpdateListStanceRows(true)
	TastyButtonsOptions.UpdateListStateRows(true)
	TastyButtonsOptions.Update_Button_List()
	
end

function TastyButtonsOptions.UpdateStateLists()
	currentStance = "normal"
	currentState = "default"
	if currentButtonSlot ~= nil then
		TastyButtonsOptions.buttonStates = TastyButtons.Get_States(currentButtonSlot)
		currentStateType = TastyButtons.Get_stateType(currentButtonSlot)
		TastyButtonsOptions.UpdateListStanceRows(true)
		TastyButtonsOptions.UpdateListStateRows(true)
		lastInfoStateWnd = windowNameTable["ButtonInfoWindowListState"].."1Button"
		lastInfoStanceWnd =windowNameTable["ButtonInfoWindowListStance"].."1Button"
		TastyButtonsOptions.SetStayDownFlag(windowNameTable["ButtonInfoWindowListState"].."1Button",true)
		TastyButtonsOptions.SetStayDownFlag(windowNameTable["ButtonInfoWindowListStance"].."1Button",true)
		TastyButtonsOptions.UpdateListStanceRows()
		TastyButtonsOptions.UpdateListStateRows()
		TastyButtonsOptions.UpdateButtonInfo(currentState,currenStance,currentStateType)
	end	
end

function TastyButtonsOptions.Update_Button_List()
	if ((DoesWindowExist(windowNameTable["default"])) and (WindowGetShowing(windowNameTable["default"]))) then
		ComboBoxClearMenuItems(comboBoxButtonName["ComboButtonRangeFirstBox"])
		ComboBoxClearMenuItems(comboBoxButtonName["ComboButtonRangeLastBox"])
		ComboBoxClearMenuItems(comboBoxButtonName["ComboButtonInfoWindow"])
		ComboBoxAddMenuItem(comboBoxButtonName["ComboButtonRangeFirstBox"],L"")
		ComboBoxAddMenuItem(comboBoxButtonName["ComboButtonRangeLastBox"],L"")
		for buttonSlot in pairs(buttonList) do
			ComboBoxAddMenuItem(comboBoxButtonName["ComboButtonInfoWindow"],towstring(buttonList[buttonSlot]))
			ComboBoxAddMenuItem(comboBoxButtonName["ComboButtonRangeFirstBox"],towstring(buttonList[buttonSlot]))
			ComboBoxAddMenuItem(comboBoxButtonName["ComboButtonRangeLastBox"],towstring(buttonList[buttonSlot]))
		end
	end
	
end

function TastyButtonsOptions.SetStayDownFlag(buttonName,flag)
	ButtonSetStayDownFlag(buttonName,flag)
	ButtonSetPressedFlag(buttonName,flag)
end

function TastyButtonsOptions.Get_directionNames()
	directionTable = TastyButtons.Get_directionNames()
end

function TastyButtonsOptions.onNil_setZero(var)
	if var == nil then
		return 0
	  else
	   return var
	end
end

function TastyButtonsOptions.DoNuthing()

end

function TastyButtonsOptions.SaveAdvOptions() 
	local autoMode 			= ButtonGetPressedFlag(windowNameTable["MiscView"].."CheckAutoModeButton")
	local timeIndicator 	= ButtonGetPressedFlag(windowNameTable["MiscView"].."CheckTimeIndicatorButton")
	local globalCD 			= ButtonGetPressedFlag(windowNameTable["MiscView"].."CheckGlobalCooldownButton")
	local ABCMode 			= ButtonGetPressedFlag(windowNameTable["MiscView"].."CheckABCModeButton")
	local showEmpty 		= ButtonGetPressedFlag(windowNameTable["MiscView"].."CheckShowEmptyButton")
	local showTooltips 		= ButtonGetPressedFlag(windowNameTable["MiscView"].."CheckHideToolTipButton")
	local tintIconOnly 		= ButtonGetPressedFlag(windowNameTable["MiscView"].."CheckTintIconOnlyButton")
	local showHotkeys 		= ButtonGetPressedFlag(windowNameTable["MiscView"].."CheckShowHotkeysButton")
	local apHandler 		= ButtonGetPressedFlag(windowNameTable["MiscView"].."CheckAPHandlerButton")
	local resourceHandler	= ButtonGetPressedFlag(windowNameTable["MiscView"].."CheckResourceHandlerButton")
	
	TastyButtons.Set_autoMode(autoMode)
	TastyButtons.Set_NoTimeIndicator_all(timeIndicator)
	TastyButtons.Set_globalCD_All(globalCD)
	TastyButtons.Set_ABCMode_all(ABCMode)
	TastyButtons.Set_EmptyShowing_all(showEmpty)
	TastyButtons.Set_ShowTooltips_all(showTooltips)
	TastyButtons.Set_TintIconOnly_all(tintIconOnly)
	TastyButtons.Set_HotkeyShowing_all(showHotkeys, true)
	TastyButtons.Set_HotkeyShowing_all(true, false)
	TastyButtons.Set_APHandler_all(apHandler)
	TastyButtons.Set_ResourceHandler_all(resourceHandler)
	
	TastyButtonsOptions.Fill_ResourceComboBox()
end


-------- Me holy test function!----------
function TastyButtonsOptions.Fill_ResourceComboBox()
	ComboBoxClearMenuItems(comboBoxButtonName["ComboStateResourceBox"])
	-- Temporary here ---
	TastyButtonsOptions.Fill_StateComboBox()
	local careerResourceData  = EA_CareerResourceData[GameData.Player.career.line]
	if careerResourceData == nil then 
		return
	end
	
	local maxResource = tonumber(careerResourceData.maxPool)
	local resName = tostring(GetString (careerResourceData.tooltipLabelId))

	if maxResource > 0 then
		if ((playerClass:match("Shaman")) or (playerClass:match("Archmage"))) then
			local resName1 = "Mork "
			local resName2 = "Gork "
			if (playerClass == "Archmage") then
			 resName1 = "Force"
			 resName2 = "Tranquility"
			end
			for n=1, maxResource do
				ComboBoxAddMenuItem(comboBoxButtonName["ComboStateResourceBox"],towstring(resName2.." "..n))
				table.insert(comboBoxResourcesFuckTardShitForSuckyComboBoxes,resName1.." "..n)
			end
			for n = 1, maxResource do
				ComboBoxAddMenuItem(comboBoxButtonName["ComboStateResourceBox"],towstring(resName1.." "..n))
				table.insert(comboBoxResourcesFuckTardShitForSuckyComboBoxes,resName1.." "..n)
			end
		  else
			local step = 1
			local start = 1
			local finish = maxResource
			if maxResource == 100 then
				step = 5
				start = 5
			end
			if maxResource == 250 then
				step = -5
				start = 245
				finish = 0
			end
			for n=start, finish, step do
				ComboBoxAddMenuItem(comboBoxButtonName["ComboStateResourceBox"],towstring(resName.." "..n))
				table.insert(comboBoxResourcesFuckTardShitForSuckyComboBoxes,resName.." "..n)
			end			
		end
		if TastyButtons_Settings["ResourceHandler"] then
			ComboBoxAddMenuItem( windowNameTable["StateView"].."ComboStateAdd", availableStates[4])
		end
		ComboBoxSetSelectedMenuItem( comboBoxButtonName["ComboStateResourceBox"],1)
	end
	ComboBoxSetDisabledFlag(windowNameTable["StateView"].."ComboResource", true)
end

function TastyButtonsOptions.OnMouseOverButtonSelectWindow()

end

function TastyButtonsOptions.OnGroupSelected()
	local filterIndex = WindowGetId(SystemData.ActiveWindow.name)
	local rowValue = ListBoxGetDataIndex(windowNameTable["ListView"].."List", filterIndex)
	d(advancedbuttonList[rowValue].group)
end

function TastyButtonsOptions.ClearSelectedGroup()
	local filterIndex = WindowGetId(SystemData.ActiveWindow.name)
	local rowValue = ListBoxGetDataIndex(windowNameTable["ListView"].."List", filterIndex)
	d(advancedbuttonList[rowValue].group)
end

function TastyButtonsOptions.Select_ButtontoInfoWindow(buttonValue)
	for index,buttonSlot in ipairs(buttonList) do
		if tonumber(buttonSlot) == tonumber(buttonValue) then
			if not WindowGetShowing(windowNameTable["ButtonInfoWindow"]) then
				WindowSetShowing(windowNameTable["ButtonInfoWindow"],true)
			end
			ComboBoxSetSelectedMenuItem("TastyButtonsOptionsButtonInfoWindowComboButton",index)
			TastyButtonsOptions.SetStayDownFlag(windowNameTable["ButtonSelectWindow"].."ButtonInfoArrow", true)
			TastyButtonsOptions.OnComboButtonSelectionChanged()
			return
		end
	end
	
end

function TastyButtonsOptions.OnButtonSelected()
	--TastyButtonsOptions.SetStayDownFlag(SystemData.MouseOverWindow.name,true)
	local filterIndex = WindowGetId(SystemData.ActiveWindow.name)
	local rowValue = ListBoxGetDataIndex(windowNameTable["ListView"].."List", filterIndex)
	local valueInTable = false
	
	if ButtonGetPressedFlag(windowNameTable["ListView"].."ListRow"..filterIndex.."Button") then
		TastyButtonsOptions.ClearSelectedButton(rowValue)
		return
	end
	
	for _,value in ipairs(selectedButtonsTable) do
		if rowValue == value then
			valueInTable = true
		end
	end
	if valueInTable then
		return
	end
	
	table.insert( selectedButtonsTable,rowValue )
	
	selectedButtons = ""

	for _,value in ipairs(selectedButtonsTable) do
		selectedButtons = selectedButtons..value.." "
		local stringlength = tonumber(string.len(selectedButtons))
		if (stringlength % 14 >=11) and not(string.find(selectedButtons,"\n", stringlength-3)) then
			selectedButtons = selectedButtons.."\n"
		end	
	end

	LabelSetText(windowNameTable["ListView"].."LabelOrder", towstring(selectedButtons))
	--TastyButtonsOptions.SetStayDownFlag(windowNameTable["ListView"].."ListRow"..filterIndex.."Button",true)
	TastyButtonsOptions.OnScrollPosChanged()
end

function TastyButtonsOptions.OnScrollPosChanged()
	local pressedButtonsTable = {}
	if TastyButtonsButtonSelectWindowButtonListViewList.PopulatorIndices == nil then
		return
	end
	for row, rowIndex in ipairs(TastyButtonsButtonSelectWindowButtonListViewList.PopulatorIndices ) do
		TastyButtonsOptions.SetStayDownFlag(windowNameTable["ListView"].."ListRow"..row.."Button",false)		
		for index,value in ipairs(selectedButtonsTable) do
			if rowIndex == value then
				table.insert(pressedButtonsTable,row)
			end
		end
	end
	for _,row in pairs(pressedButtonsTable) do
		TastyButtonsOptions.SetStayDownFlag(windowNameTable["ListView"].."ListRow"..row.."Button",true)
	end
	
end

function TastyButtonsOptions.OnButtonSelectListRUp()
	local filterIndex = WindowGetId(SystemData.ActiveWindow.name)
	local rowValue = ListBoxGetDataIndex(windowNameTable["ListView"].."List", filterIndex)
	
	TastyButtonsOptions.Select_ButtontoInfoWindow(rowValue)
end

function TastyButtonsOptions.ClearSelectedButton(value)
	local filterIndex = WindowGetId(SystemData.ActiveWindow.name)
	local rowValue = ListBoxGetDataIndex(windowNameTable["ListView"].."List", filterIndex)
	local clearedButtonIndex
	
	if value then rowValue = value end
	
	selectedButtons = ""
	for index,value in ipairs(selectedButtonsTable) do
		if value == rowValue then
			clearedButtonIndex = index
		  else
			selectedButtons = selectedButtons..value.." "
		end
		local stringlength = tonumber(string.len(selectedButtons))
		if (stringlength % 14 >=11) and not(string.find(selectedButtons,"\n", stringlength-3)) then
			selectedButtons = selectedButtons.."\n"
		end
	end
	table.remove(selectedButtonsTable, clearedButtonIndex)
	--TastyButtonsOptions.SetStayDownFlag(SystemData.MouseOverWindow.name,false)
	LabelSetText(windowNameTable["ListView"].."LabelOrder", towstring(selectedButtons))
	
	--if value then return end
	--TastyButtonsOptions.SetStayDownFlag(windowNameTable["ListView"].."ListRow"..filterIndex.."Button",false)
	TastyButtonsOptions.OnScrollPosChanged()
end

function TastyButtonsOptions.ClearSelectedButton_All()
	selectedButtonsTable = {}
	LabelSetText(windowNameTable["ListView"].."LabelOrder", L"")
	TastyButtonsOptions.OnScrollPosChanged()
end

function TastyButtonsOptions.AddSelectedButton_All()
	selectedButtonsTable = {}
	selectedButtons = ""
	for _, button in ipairs(buttonList) do
		table.insert(selectedButtonsTable,button)
	end
	for index,value in ipairs(selectedButtonsTable) do
		selectedButtons = selectedButtons..value.." "
		local stringlength = tonumber(string.len(selectedButtons))
		if (stringlength % 14 >=11) and not(string.find(selectedButtons,"\n", stringlength-3)) then
			selectedButtons = selectedButtons.."\n"
		end
	end
	LabelSetText(windowNameTable["ListView"].."LabelOrder", towstring(selectedButtons))	
	TastyButtonsOptions.OnScrollPosChanged()
end

function TastyButtonsOptions.MouseOverSliderButton()

end

function TastyButtonsOptions.UpdateButtonSelectList()
	if TastyButtonsButtonSelectWindowButtonListViewList.PopulatorIndices == nil then
		return
	end
	for row, rowIndex in ipairs(TastyButtonsButtonSelectWindowButtonListViewList.PopulatorIndices) do
		local group = advancedbuttonList[rowIndex]["group"]
		ButtonSetText(windowNameTable["ListView"].."ListRow"..row.."Button",towstring("Button"..rowIndex))
		if advancedbuttonList[rowIndex]["group"] ~= nil then
			ButtonSetText(windowNameTable["ListView"].."ListRow"..row.."ButtonGroup",towstring(group))
		  else
			ButtonSetText(windowNameTable["ListView"].."ListRow"..row.."ButtonGroup",L"X")
		end
		ButtonSetTextColor(windowNameTable["ListView"].."ListRow"..row.."ButtonGroup",0,groupColors[group]["r"],groupColors[group]["g"],groupColors[group]["b"])
		WindowSetShowing(windowNameTable["ListView"].."ListRow"..row.."ButtonGroup",false)
	end
	TastyButtonsOptions.OnScrollPosChanged()
end


function TastyButtonsOptions.UpdateStateSelecList()


end

function TastyButtonsOptions.Test(fu)

end


			