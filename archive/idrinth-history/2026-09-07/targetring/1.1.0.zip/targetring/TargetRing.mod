<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <UiMod name="TargetRing" version="1.1" date="10/25/2008" >

    <Author name="Talvinen" email="redefiance@gmx.de" />
    <Description text="" />
    
    <Dependencies>
      <Dependency name="LibSlash" />
    </Dependencies>

    <Files>
      <File name="TargetRing.xml" />
      <File name="TargetRing.lua" />
    </Files>

    <SavedVariables>
      <SavedVariable name="TargetRing.Settings" />
    </SavedVariables>

    <OnInitialize>
      <CallFunction name="TargetRing.Initialize" />
    </OnInitialize>
  </UiMod>
</ModuleFile>
