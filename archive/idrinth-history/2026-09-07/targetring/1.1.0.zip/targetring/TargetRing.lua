TargetRing = {}

local cur_fid = 0
local cur_eid = 0

local function print(msg)
  EA_ChatWindow.Print(towstring(msg))
end

function TargetRing.Initialize()
  CreateWindowFromTemplate("FriendlyTargetRingAnchor","EA_Window_Default","Root")
  WindowSetDimensions("FriendlyTargetRingAnchor",1,1)
  WindowSetShowing("FriendlyTargetRingAnchor",true)

  CreateWindowFromTemplate("FriendlyTargetRing","EA_DynamicImage_DefaultSeparatorRight","FriendlyTargetRingAnchor")
  WindowClearAnchors("FriendlyTargetRing")
  WindowAddAnchor("FriendlyTargetRing","top","FriendlyTargetRingAnchor","top",0,-10)
  DynamicImageSetTexture("FriendlyTargetRing","TargetRing",0,0)
  DynamicImageSetTextureDimensions("FriendlyTargetRing",256,256)
  WindowSetDimensions("FriendlyTargetRing",100,100)
  WindowSetScale("FriendlyTargetRing",1)
  WindowSetAlpha("FriendlyTargetRing",0.5)
  WindowSetShowing("FriendlyTargetRing",false)
  WindowSetTintColor("FriendlyTargetRing",0,255,0)

  CreateWindowFromTemplate("EnemyTargetRingAnchor","EA_Window_Default","Root")
  WindowSetDimensions("EnemyTargetRingAnchor",1,1)
  WindowSetShowing("EnemyTargetRingAnchor",true)

  CreateWindowFromTemplate("EnemyTargetRing","EA_DynamicImage_DefaultSeparatorRight","EnemyTargetRingAnchor")
  WindowClearAnchors("EnemyTargetRing")
  WindowAddAnchor("EnemyTargetRing","top","EnemyTargetRingAnchor","top",0,-10)
  DynamicImageSetTexture("EnemyTargetRing","TargetRing",0,0)
  DynamicImageSetTextureDimensions("EnemyTargetRing",256,256)
  WindowSetDimensions("EnemyTargetRing",100,100)
  WindowSetScale("EnemyTargetRing",1)
  WindowSetAlpha("EnemyTargetRing",0.5)
  WindowSetShowing("EnemyTargetRing",false)
  WindowSetTintColor("EnemyTargetRing",255,0,0)

  
  RegisterEventHandler(SystemData.Events.PLAYER_TARGET_UPDATED, "TargetRing.UpdateTargets")
  
  LibSlash.RegisterSlashCmd("tr",function(msg) TargetRing.Slash(msg) end)
  LibSlash.RegisterSlashCmd("targetring",function(msg) TargetRing.Slash(msg) end)
end

function TargetRing.Slash(msg)
  msg = msg:lower()

  if (msg == "on") then
    TargetRing.Settings.Enabled = true
  elseif (msg == "off") then
    TargetRing.Settings.Enabled = false
    DetachWindowFromWorldObject("FriendlyTargetRingAnchor", cur_fid)
    DetachWindowFromWorldObject("EnemyTargetRingAnchor", cur_eid)
    WindowSetShowing("FriendlyTargetRing",false)
    WindowSetShowing("EnemyTargetRing",false)
  elseif (msg == "friend") or (msg == "friendly") then
    DetachWindowFromWorldObject("FriendlyTargetRingAnchor", cur_fid)
    TargetRing.Settings.Friend = not TargetRing.Settings.Friend
    WindowSetShowing("FriendlyTargetRing",false)
  elseif (msg == "enemy") then
    DetachWindowFromWorldObject("EnemyTargetRingAnchor", cur_fid)
    TargetRing.Settings.Enemy = not TargetRing.Settings.Enemy
    WindowSetShowing("EnemyTargetRing",false)
  end
  
  print("TargetRing is "..(TargetRing.Settings.Enabled and "enabled" or "disabled"))
  print("Showing friendly target ring is "..(TargetRing.Settings.Friend and "enabled" or "disabled"))
  print("Showing enemy target ring is "..(TargetRing.Settings.Enemy and "enabled" or "disabled"))
  print("usage: /tr on|off|friend|enemy")
end

function TargetRing.UpdateTargets()
  TargetInfo:UpdateFromClient()

  if (not TargetRing.Settings) then
    TargetRing.Settings = {
      Enabled = true,
      Friend = true,
      Enemy = true,
      }
  end
  if (TargetRing.Settings.Enabled) then
    if (TargetRing.Settings.Friend) then
      local fid = TargetInfo:UnitEntityId("selffriendlytarget")
      if (fid ~= cur_fid) then
        if (cur_fid) then
          DetachWindowFromWorldObject("FriendlyTargetRingAnchor", cur_fid)
          WindowSetShowing("FriendlyTargetRing",false)
        end
        if (fid > 0 and fid ~= GameData.Player.worldObjNum) then
          MoveWindowToWorldObject("FriendlyTargetRingAnchor",fid,1)
          AttachWindowToWorldObject("FriendlyTargetRingAnchor",fid)
          WindowSetShowing("FriendlyTargetRing",true)
        end
        cur_fid = fid
      end
    end
    if (TargetRing.Settings.Enemy) then
      local eid = TargetInfo:UnitEntityId("selfhostiletarget")
      if (eid ~= cur_eid) then
        --if (cur_eid) then
          DetachWindowFromWorldObject("EnemyTargetRingAnchor", cur_eid)
          WindowSetShowing("EnemyTargetRing",false)
        --end
        if (eid > 0) then
          MoveWindowToWorldObject("EnemyTargetRingAnchor",eid,1)
          AttachWindowToWorldObject("EnemyTargetRingAnchor",eid)
          WindowSetShowing("EnemyTargetRing",true)
        end
        cur_eid = eid
      end
    end
  end
end