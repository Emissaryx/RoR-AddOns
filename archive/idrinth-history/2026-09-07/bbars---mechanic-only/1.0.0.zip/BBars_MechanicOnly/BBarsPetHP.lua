BBarsPetHP = {}

local UnitWidth = 210
local UnitHeight = 15
local UnitBuffer = 4
local InnerBarWidth = UnitWidth - UnitBuffer
local InnerBarHeight = UnitHeight - (UnitBuffer * 1.5)

function BBars.HasPet()
    return GameData.Player.Pet.name ~= L""
end

function BBars.PetCheck()
	if DoesWindowExist("BBarsPetHPBack") then
		return 
	end
	
	local hasPet = BBars.HasPet()
	
	if ( hasPet ) then
		BBars.PetHPDraw()
		BBars.PetHPUpdate()
	else
		if DoesWindowExist("BBarsPetHPBack") then 
			Destroy("BBarsPetHPBG")
		end
	end
end

function BBars.PetHPDraw()

	CreateWindowFromTemplate("BBarsPetHPBG", "EA_DynamicImage_DefaultSeparatorRight", "Root")
	WindowAddAnchor ("BBarsPetHPBG", "bottom" , "Root", "bottom", 0, -460)
	DynamicImageSetTexture("BBarsPetHPBG", BGTexture, 0, 0)
	DynamicImageSetTextureDimensions("BBarsPetHPBG", UnitWidth, UnitHeight)
	WindowSetDimensions("BBarsPetHPBG", UnitWidth, UnitHeight - 2)

	WindowSetScale("BBarsPetHPBG", 1)
	WindowSetAlpha("BBarsPetHPBG", 1)
	WindowSetShowing("BBarsPetHPBG", true)
	WindowSetTintColor("BBarsPetHPBG", BGColour[1], BGColour[2], BGColour[3]) -- black

	-- ^^ ABOVE IS THE AP BAR BACKGROUND / PARENT

	CreateWindowFromTemplate("BBarsPetHPBack", "EA_DynamicImage_DefaultSeparatorRight", "Root")
	WindowClearAnchors("BBarsPetHPBack")
	DynamicImageSetTexture("BBarsPetHPBack", BackTexture, 0, 0)
	DynamicImageSetTextureDimensions("BBarsPetHPBack", 256, 32)
	WindowSetDimensions("BBarsPetHPBack", InnerBarWidth, InnerBarHeight)
	WindowSetParent("BBarsPetHPBack", "BBarsPetHPBG")
	WindowSetScale("BBarsPetHPBack", 1)
	WindowSetAlpha("BBarsPetHPBack", 0) -- curently invis
	WindowSetTintColor("BBarsPetHPBack", ChipColour[1], ChipColour[2], ChipColour[3]) --red
	WindowSetOffsetFromParent("BBarsPetHPBack", (UnitBuffer / 2), (UnitBuffer / 2)) --(UnitBuffer / 2))
	WindowSetShowing("BBarsPetHPBack", true)


	-- ^^ ABOVE IS THE DELAYED BACKBAR ^^ --

	CreateWindowFromTemplate("BBarsPetHPFront", "EA_DynamicImage_DefaultSeparatorRight", "Root")
	WindowClearAnchors("BBarsPetHPFront")
	DynamicImageSetTexture("BBarsPetHPFront", FrontTexture, 0, 0)
	DynamicImageSetTextureDimensions("BBarsPetHPFront", 256, 32)
	WindowSetDimensions("BBarsPetHPFront", InnerBarWidth, InnerBarHeight)
	WindowSetParent("BBarsPetHPFront", "BBarsPetHPBG")
	WindowSetScale("BBarsPetHPFront", 1)
	WindowSetAlpha("BBarsPetHPFront", 1)
	WindowSetTintColor("BBarsPetHPFront", HPColour[1], HPColour[2], HPColour[3]) --yellow
	WindowSetOffsetFromParent("BBarsPetHPFront", (UnitBuffer / 2), (UnitBuffer / 2)) --(UnitBuffer / 2))
	WindowSetShowing("BBarsPetHPFront", true)	

	-- ^^ ABOVE IS THE FRONT AP BAR ^^ --
end

function BBars.PetHPUpdate()
	if petBar == nil then
		PetHPfadeBar = InnerBarWidth
	else
		PetHPfadeBar = petBar
	end

	petBar = (GameData.Player.Pet.healthPercent / 100) * InnerBarWidth
	
	if petBar >= InnerBarWidth then
		petBar = InnerBarWidth
	end

	if petBar <= 0 then
		petBar = 0
	end

	WindowSetDimensions( "BBarsPetHPFront", petBar, InnerBarHeight)
end
