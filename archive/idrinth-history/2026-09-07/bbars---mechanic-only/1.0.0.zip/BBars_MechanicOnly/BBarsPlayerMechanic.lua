BBarsPlayerMechanic = {}

local UnitWidth = 21 -- 310
local UnitHeight = 22
local UnitBuffer = 4
local InnerBarWidth = UnitWidth - UnitBuffer
local InnerBarHeight = UnitHeight - UnitBuffer

local Offset = UnitWidth * 0.20

function BBars.MechanicSort()
	-- get player class to determine which mechanic to use
	pc = GameData.Player.career.line
	gc = GameData.CareerLine
	
	if ( pc == gc.SHAMAN ) then -- green 7

	elseif ( pc == gc.SQUIG_HERDER) then -- green 8
	--draw pet hp bar
	-- NOTHING
	elseif ( pc == gc.CHOPPA ) then -- green 6
		d("CHOPPA")
		BBars.MechDraw()
		WindowSetTintColor("BBarsPlayerMechanic1Frontbar", 255, 255, 255)
		WindowSetTintColor("BBarsPlayerMechanic2Frontbar", 255, 255, 0)
		WindowSetTintColor("BBarsPlayerMechanic3Frontbar", 255, 200, 15)
		WindowSetTintColor("BBarsPlayerMechanic4Frontbar", 255, 125, 40)
		WindowSetTintColor("BBarsPlayerMechanic5Frontbar", 255, 0, 0)
		WindowSetShowing("BBarsPlayerMechanic1Frontbar", true)
		WindowSetShowing("BBarsPlayerMechanic2Frontbar", true)
		WindowSetShowing("BBarsPlayerMechanic3Frontbar", true)
		WindowSetShowing("BBarsPlayerMechanic4Frontbar", true)
		WindowSetShowing("BBarsPlayerMechanic5Frontbar", true)
		WindowSetAlpha("BBarsPlayerMechanic1Frontbar", 0)
		WindowSetAlpha("BBarsPlayerMechanic2Frontbar", 0)
		WindowSetAlpha("BBarsPlayerMechanic3Frontbar", 0)
		WindowSetAlpha("BBarsPlayerMechanic4Frontbar", 0)
		WindowSetAlpha("BBarsPlayerMechanic5Frontbar", 0)
		RegisterEventHandler(SystemData.Events.PLAYER_CAREER_RESOURCE_UPDATED, "BBars.CHSLMechanicUpdate")

	elseif ( pc == gc.BLACK_ORC ) then -- green 5
		BBars.MechDraw()
		WindowSetAlpha("BBarsPlayerMechanic1BG", 0)
		WindowSetAlpha("BBarsPlayerMechanic5BG", 0)
		WindowSetAlpha("BBarsPlayerMechanic1Grey", 0)
		WindowSetAlpha("BBarsPlayerMechanic5Grey", 0)
		WindowSetAlpha("BBarsPlayerMechanic1ChipAway", 0)
		WindowSetAlpha("BBarsPlayerMechanic5ChipAway", 0)
		WindowSetAlpha("BBarsPlayerMechanic1Frontbar", 0)
		WindowSetAlpha("BBarsPlayerMechanic5Frontbar", 0)
		WindowSetShowing("BBarsPlayerMechanic2Frontbar", true)
		--WindowClearAnchors ("BBarsPlayerMechanic1BG")
		--WindowAddAnchor ("BBarsPlayerMechanic1BG", "topleft" , "BBarsPlayerMorale1BG", "topleft", (32 + UnitWidth), -40)
		WindowSetTintColor("BBarsPlayerMechanic2Frontbar", WhiteColour[1], WhiteColour[2], WhiteColour[3])
		WindowSetTintColor("BBarsPlayerMechanic3Frontbar", APColour[1], APColour[2], APColour[3])
		WindowSetTintColor("BBarsPlayerMechanic4Frontbar", ChipColour[1], ChipColour[2], ChipColour[3])
		RegisterEventHandler(SystemData.Events.PLAYER_CAREER_RESOURCE_UPDATED, "BBars.BOSMMechanicUpdate")
	elseif ( pc == gc.MARAUDER) then -- chaos 14

	elseif ( pc == gc.CHOSEN) then -- chaos 13
		-- NOTHING

	elseif ( pc == gc.MAGUS) then -- chaos 16
		--draw pet hp bar
		-- NOTHING
	elseif ( pc == gc.ZEALOT) then -- chaos 15

	elseif ( pc == gc.SORCERER) then -- dark elf 24
	 
	elseif ( pc == gc.DISCIPLE) then -- dark elf  23
		--dok
	
	elseif ( pc == gc.WITCH_ELF) then -- dark elf 22
		--witch elf	
		BBars.MechDraw()
		RegisterEventHandler(SystemData.Events.PLAYER_CAREER_RESOURCE_UPDATED, "BBars.WEWHMechanicUpdate")
	elseif ( pc == gc.BLACKGUARD ) then -- dark elf 21


	elseif ( pc == gc.SWORDMASTER ) then -- high elf 17
		BBars.MechDraw()
		WindowSetShowing("BBarsPlayerMechanic4BG", false)
		WindowSetShowing("BBarsPlayerMechanic5BG", false)
		WindowSetShowing("BBarsPlayerMechanic4Grey", false)
		WindowSetShowing("BBarsPlayerMechanic5Grey", false)
		WindowSetShowing("BBarsPlayerMechanic4ChipAway", false)
		WindowSetShowing("BBarsPlayerMechanic5ChipAway", false)
		WindowSetShowing("BBarsPlayerMechanic4Frontbar", false)
		WindowSetShowing("BBarsPlayerMechanic5Frontbar", false)
		WindowSetShowing("BBarsPlayerMechanic1Frontbar", true)
		WindowSetTintColor("BBarsPlayerMechanic1Frontbar", WhiteColour[1], WhiteColour[2], WhiteColour[3])
		WindowSetTintColor("BBarsPlayerMechanic2Frontbar", APColour[1], APColour[2], APColour[3])
		WindowSetTintColor("BBarsPlayerMechanic3Frontbar", ChipColour[1], ChipColour[2], ChipColour[3])
		RegisterEventHandler(SystemData.Events.PLAYER_CAREER_RESOURCE_UPDATED, "BBars.BOSMMechanicUpdate")
	elseif ( pc == gc.WHITE_LION) then -- high elf 19
		--draw pet hp bar
		-- NOTHING
	elseif ( pc == gc.ARCHMAGE ) then --high elf 20

	elseif ( pc == gc.SHADOW_WARRIOR ) then --high elf 18

	elseif ( pc == gc.BRIGHT_WIZARD ) then -- empire 11

	elseif ( pc == gc.WARRIOR_PRIEST ) then --empire 12

	elseif ( pc == gc.WITCH_HUNTER) then -- empire 9
		BBars.MechDraw()
		RegisterEventHandler(SystemData.Events.PLAYER_CAREER_RESOURCE_UPDATED, "BBars.WEWHMechanicUpdate")
	elseif ( pc == gc.KNIGHT) then -- empire 10
		-- NOTHING
		
	elseif ( pc == gc.IRON_BREAKER ) then --dwarf 1

	elseif ( pc == gc.SLAYER ) then -- dwarf 2
		BBars.MechDraw()
		WindowSetTintColor("BBarsPlayerMechanic1Frontbar", 255, 255,255)
		WindowSetTintColor("BBarsPlayerMechanic2Frontbar", 255, 255, 0)
		WindowSetTintColor("BBarsPlayerMechanic3Frontbar", 255, 200, 15)
		WindowSetTintColor("BBarsPlayerMechanic4Frontbar", 255, 125, 40)
		WindowSetTintColor("BBarsPlayerMechanic5Frontbar", 255, 0, 0)
		WindowSetShowing("BBarsPlayerMechanic1Frontbar", true)
		WindowSetShowing("BBarsPlayerMechanic2Frontbar", true)
		WindowSetShowing("BBarsPlayerMechanic3Frontbar", true)
		WindowSetShowing("BBarsPlayerMechanic4Frontbar", true)
		WindowSetShowing("BBarsPlayerMechanic5Frontbar", true)
		WindowSetAlpha("BBarsPlayerMechanic1Frontbar", 0)
		WindowSetAlpha("BBarsPlayerMechanic2Frontbar", 0)
		WindowSetAlpha("BBarsPlayerMechanic3Frontbar", 0)
		WindowSetAlpha("BBarsPlayerMechanic4Frontbar", 0)
		WindowSetAlpha("BBarsPlayerMechanic5Frontbar", 0)
		RegisterEventHandler(SystemData.Events.PLAYER_CAREER_RESOURCE_UPDATED, "BBars.CHSLMechanicUpdate")
	elseif ( pc == gc.ENGINEER) then -- dwarf 4
		--draw pet hp bar
		-- NOTHING
	elseif ( pc == gc.RUNE_PRIEST) then -- dwarf 3

	else
		-- nothing.. there should be nothing anyway but just incase... nothing
	end
end

function BBars.MechDraw()
	-- window 3, 1, 2, 4, 5
	if not DoesWindowExist("BBarsPlayerMechanic3BG") then
	CreateWindowFromTemplate("BBarsPlayerMechanic3BG", "EA_DynamicImage_DefaultSeparatorRight", "Root")
	WindowAddAnchor ("BBarsPlayerMechanic3BG", "bottom" , "Root", "bottom", 0, -460)
	DynamicImageSetTexture("BBarsPlayerMechanic3BG", "Smooth1", 0, 0)
	DynamicImageSetTextureDimensions("BBarsPlayerMechanic3BG", UnitWidth, UnitHeight)
	WindowSetDimensions("BBarsPlayerMechanic3BG", UnitWidth, UnitHeight)
	WindowSetScale("BBarsPlayerMechanic3BG", 1)
	WindowSetAlpha("BBarsPlayerMechanic3BG", 1)
	WindowSetShowing("BBarsPlayerMechanic3BG", true)
	WindowSetTintColor("BBarsPlayerMechanic3BG", BGColour[1], BGColour[2], BGColour[3]) -- black
	LayoutEditor.RegisterWindow("BBarsPlayerMechanic3BG", L"BBarsPlayerMechanic3BG", L"BBars Player Mechanic", false, false, true, nil)

	-- window 2

	CreateWindowFromTemplate("BBarsPlayerMechanic2BG", "EA_DynamicImage_DefaultSeparatorRight", "Root")
	WindowAddAnchor ("BBarsPlayerMechanic2BG", "left" , "BBarsPlayerMechanic3BG", "right", -Offset, 0)
	DynamicImageSetTexture("BBarsPlayerMechanic2BG", "Smooth1", 0, 0)
	DynamicImageSetTextureDimensions("BBarsPlayerMechanic2BG", UnitWidth, UnitHeight)
	WindowSetDimensions("BBarsPlayerMechanic2BG", UnitWidth, UnitHeight)
	WindowSetScale("BBarsPlayerMechanic2BG", 1)
	WindowSetAlpha("BBarsPlayerMechanic2BG", 1)
	WindowSetShowing("BBarsPlayerMechanic2BG", true)
	WindowSetTintColor("BBarsPlayerMechanic2BG", BGColour[1], BGColour[2], BGColour[3]) -- black

	-- window 1
	CreateWindowFromTemplate("BBarsPlayerMechanic1BG", "EA_DynamicImage_DefaultSeparatorRight", "Root")
	WindowAddAnchor ("BBarsPlayerMechanic1BG", "left" , "BBarsPlayerMechanic2BG", "right", -Offset, 0)
	DynamicImageSetTexture("BBarsPlayerMechanic1BG", "Smooth1", 0, 0)
	DynamicImageSetTextureDimensions("BBarsPlayerMechanic1BG", UnitWidth, UnitHeight)
	WindowSetDimensions("BBarsPlayerMechanic1BG", UnitWidth, UnitHeight)
	WindowSetScale("BBarsPlayerMechanic1BG", 1)
	WindowSetAlpha("BBarsPlayerMechanic1BG", 1)
	WindowSetShowing("BBarsPlayerMechanic1BG", true)
	WindowSetTintColor("BBarsPlayerMechanic1BG", BGColour[1], BGColour[2], BGColour[3]) -- black

	CreateWindowFromTemplate("BBarsPlayerMechanic4BG", "EA_DynamicImage_DefaultSeparatorRight", "Root")
	WindowAddAnchor ("BBarsPlayerMechanic4BG", "right" , "BBarsPlayerMechanic3BG", "left", Offset, 0)
	DynamicImageSetTexture("BBarsPlayerMechanic4BG", "Smooth1", 0, 0)
	DynamicImageSetTextureDimensions("BBarsPlayerMechanic4BG", UnitWidth, UnitHeight)
	WindowSetDimensions("BBarsPlayerMechanic4BG", UnitWidth, UnitHeight)
	WindowSetScale("BBarsPlayerMechanic4BG", 1)
	WindowSetAlpha("BBarsPlayerMechanic4BG", 1)
	WindowSetShowing("BBarsPlayerMechanic4BG", true)
	WindowSetTintColor("BBarsPlayerMechanic4BG", BGColour[1], BGColour[2], BGColour[3]) -- black

	CreateWindowFromTemplate("BBarsPlayerMechanic5BG", "EA_DynamicImage_DefaultSeparatorRight", "Root")
	WindowAddAnchor ("BBarsPlayerMechanic5BG", "right" , "BBarsPlayerMechanic4BG", "left", Offset, 0)
	DynamicImageSetTexture("BBarsPlayerMechanic5BG", "Smooth1", 0, 0)
	DynamicImageSetTextureDimensions("BBarsPlayerMechanic5BG", UnitWidth, UnitHeight)
	WindowSetDimensions("BBarsPlayerMechanic5BG", UnitWidth, UnitHeight)
	WindowSetScale("BBarsPlayerMechanic5BG", 1)
	WindowSetAlpha("BBarsPlayerMechanic5BG", 1)
	WindowSetShowing("BBarsPlayerMechanic5BG", true)
	WindowSetTintColor("BBarsPlayerMechanic5BG", BGColour[1], BGColour[2], BGColour[3]) -- black

	-- ^^ ABOVE ARE ALL THE BACKGROUNDS 
	
	CreateWindowFromTemplate("BBarsPlayerMechanic1Grey", "EA_DynamicImage_DefaultSeparatorRight", "Root")
	DynamicImageSetTexture("BBarsPlayerMechanic1Grey", BGTexture, 0, 0)
	DynamicImageSetTextureDimensions("BBarsPlayerMechanic1Grey", UnitWidth, UnitHeight)
	WindowSetDimensions("BBarsPlayerMechanic1Grey", InnerBarWidth, InnerBarHeight)
	WindowSetParent("BBarsPlayerMechanic1Grey", "BBarsPlayerMechanic1BG")
	WindowSetOffsetFromParent("BBarsPlayerMechanic1Grey", (UnitBuffer / 2), (UnitBuffer / 2))
	WindowSetScale("BBarsPlayerMechanic1Grey", 1)
	WindowSetAlpha("BBarsPlayerMechanic1Grey", 1)
	WindowSetShowing("BBarsPlayerMechanic1Grey", true)
	WindowSetTintColor("BBarsPlayerMechanic1Grey", GreyColour[1], GreyColour[2], GreyColour[3])

	CreateWindowFromTemplate("BBarsPlayerMechanic2Grey", "EA_DynamicImage_DefaultSeparatorRight", "Root")
	DynamicImageSetTexture("BBarsPlayerMechanic2Grey", BGTexture, 0, 0)
	DynamicImageSetTextureDimensions("BBarsPlayerMechanic2Grey", UnitWidth, UnitHeight)
	WindowSetDimensions("BBarsPlayerMechanic2Grey", InnerBarWidth, InnerBarHeight)
	WindowSetParent("BBarsPlayerMechanic2Grey", "BBarsPlayerMechanic2BG")
	WindowSetOffsetFromParent("BBarsPlayerMechanic2Grey", (UnitBuffer / 2), (UnitBuffer / 2))
	WindowSetScale("BBarsPlayerMechanic2Grey", 1)
	WindowSetAlpha("BBarsPlayerMechanic2Grey", 1)
	WindowSetShowing("BBarsPlayerMechanic2Grey", true)
	WindowSetTintColor("BBarsPlayerMechanic2Grey", GreyColour[1], GreyColour[2], GreyColour[3])

	CreateWindowFromTemplate("BBarsPlayerMechanic3Grey", "EA_DynamicImage_DefaultSeparatorRight", "Root")
	DynamicImageSetTexture("BBarsPlayerMechanic3Grey", BGTexture, 0, 0)
	DynamicImageSetTextureDimensions("BBarsPlayerMechanic3Grey", UnitWidth, UnitHeight)
	WindowSetDimensions("BBarsPlayerMechanic3Grey", InnerBarWidth, InnerBarHeight)
	WindowSetParent("BBarsPlayerMechanic3Grey", "BBarsPlayerMechanic3BG")
	WindowSetOffsetFromParent("BBarsPlayerMechanic3Grey", (UnitBuffer / 2), (UnitBuffer / 2))
	WindowSetScale("BBarsPlayerMechanic3Grey", 1)
	WindowSetAlpha("BBarsPlayerMechanic3Grey", 1)
	WindowSetShowing("BBarsPlayerMechanic3Grey", true)
	WindowSetTintColor("BBarsPlayerMechanic3Grey", GreyColour[1], GreyColour[2], GreyColour[3])

	CreateWindowFromTemplate("BBarsPlayerMechanic4Grey", "EA_DynamicImage_DefaultSeparatorRight", "Root")
	DynamicImageSetTexture("BBarsPlayerMechanic4Grey", BGTexture, 0, 0)
	DynamicImageSetTextureDimensions("BBarsPlayerMechanic4Grey", UnitWidth, UnitHeight)
	WindowSetDimensions("BBarsPlayerMechanic4Grey", InnerBarWidth, InnerBarHeight)
	WindowSetParent("BBarsPlayerMechanic4Grey", "BBarsPlayerMechanic4BG")
	WindowSetOffsetFromParent("BBarsPlayerMechanic4Grey", (UnitBuffer / 2), (UnitBuffer / 2))
	WindowSetScale("BBarsPlayerMechanic4Grey", 1)
	WindowSetAlpha("BBarsPlayerMechanic4Grey", 1)
	WindowSetShowing("BBarsPlayerMechanic4Grey", true)
	WindowSetTintColor("BBarsPlayerMechanic4Grey", GreyColour[1], GreyColour[2], GreyColour[3])

	CreateWindowFromTemplate("BBarsPlayerMechanic5Grey", "EA_DynamicImage_DefaultSeparatorRight", "Root")
	DynamicImageSetTexture("BBarsPlayerMechanic5Grey", BGTexture, 0, 0)
	DynamicImageSetTextureDimensions("BBarsPlayerMechanic5Grey", UnitWidth, UnitHeight)
	WindowSetDimensions("BBarsPlayerMechanic5Grey", InnerBarWidth, InnerBarHeight)
	WindowSetParent("BBarsPlayerMechanic5Grey", "BBarsPlayerMechanic5BG")
	WindowSetOffsetFromParent("BBarsPlayerMechanic5Grey", (UnitBuffer / 2), (UnitBuffer / 2))
	WindowSetScale("BBarsPlayerMechanic5Grey", 1)
	WindowSetAlpha("BBarsPlayerMechanic5Grey", 1)
	WindowSetShowing("BBarsPlayerMechanic5Grey", true)
	WindowSetTintColor("BBarsPlayerMechanic5Grey", GreyColour[1], GreyColour[2], GreyColour[3])
	
	-- ^^ GREY BG EFFECT

	CreateWindowFromTemplate("BBarsPlayerMechanic1Frontbar", "EA_DynamicImage_DefaultSeparatorRight", "Root")
	DynamicImageSetTexture("BBarsPlayerMechanic1Frontbar", FrontTexture, 0, 0)
	DynamicImageSetTextureDimensions("BBarsPlayerMechanic1Frontbar", UnitWidth, UnitHeight)
	WindowSetDimensions("BBarsPlayerMechanic1Frontbar", InnerBarWidth, InnerBarHeight)
	WindowSetParent("BBarsPlayerMechanic1Frontbar", "BBarsPlayerMechanic1BG")
	WindowSetOffsetFromParent("BBarsPlayerMechanic1Frontbar", (UnitBuffer / 2), (UnitBuffer / 2))
	WindowSetScale("BBarsPlayerMechanic1Frontbar", 1)
	WindowSetAlpha("BBarsPlayerMechanic1Frontbar", 1)
	WindowSetShowing("BBarsPlayerMechanic1Frontbar", false)
	WindowSetTintColor("BBarsPlayerMechanic1Frontbar", WhiteColour[1], WhiteColour[2], WhiteColour[3])

	CreateWindowFromTemplate("BBarsPlayerMechanic2Frontbar", "EA_DynamicImage_DefaultSeparatorRight", "Root")
	DynamicImageSetTexture("BBarsPlayerMechanic2Frontbar", FrontTexture, 0, 0)
	DynamicImageSetTextureDimensions("BBarsPlayerMechanic2Frontbar", UnitWidth, UnitHeight)
	WindowSetDimensions("BBarsPlayerMechanic2Frontbar", InnerBarWidth, InnerBarHeight)
	WindowSetParent("BBarsPlayerMechanic2Frontbar", "BBarsPlayerMechanic2BG")
	WindowSetOffsetFromParent("BBarsPlayerMechanic2Frontbar", (UnitBuffer / 2), (UnitBuffer / 2))
	WindowSetScale("BBarsPlayerMechanic2Frontbar", 1)
	WindowSetAlpha("BBarsPlayerMechanic2Frontbar", 1)
	WindowSetShowing("BBarsPlayerMechanic2Frontbar", false)
	WindowSetTintColor("BBarsPlayerMechanic2Frontbar", WhiteColour[1], WhiteColour[2], WhiteColour[3])

	CreateWindowFromTemplate("BBarsPlayerMechanic3Frontbar", "EA_DynamicImage_DefaultSeparatorRight", "Root")
	DynamicImageSetTexture("BBarsPlayerMechanic3Frontbar", FrontTexture, 0, 0)
	DynamicImageSetTextureDimensions("BBarsPlayerMechanic3Frontbar", UnitWidth, UnitHeight)
	WindowSetDimensions("BBarsPlayerMechanic3Frontbar", InnerBarWidth, InnerBarHeight)
	WindowSetParent("BBarsPlayerMechanic3Frontbar", "BBarsPlayerMechanic3BG")
	WindowSetOffsetFromParent("BBarsPlayerMechanic3Frontbar", (UnitBuffer / 2), (UnitBuffer / 2))
	WindowSetScale("BBarsPlayerMechanic3Frontbar", 1)
	WindowSetAlpha("BBarsPlayerMechanic3Frontbar", 1)
	WindowSetShowing("BBarsPlayerMechanic3Frontbar", false)
	WindowSetTintColor("BBarsPlayerMechanic3Frontbar", WhiteColour[1], WhiteColour[2], WhiteColour[3])

	CreateWindowFromTemplate("BBarsPlayerMechanic4Frontbar", "EA_DynamicImage_DefaultSeparatorRight", "Root")
	DynamicImageSetTexture("BBarsPlayerMechanic4Frontbar", FrontTexture, 0, 0)
	DynamicImageSetTextureDimensions("BBarsPlayerMechanic4Frontbar", UnitWidth, UnitHeight)
	WindowSetDimensions("BBarsPlayerMechanic4Frontbar", InnerBarWidth, InnerBarHeight)
	WindowSetParent("BBarsPlayerMechanic4Frontbar", "BBarsPlayerMechanic4BG")
	WindowSetOffsetFromParent("BBarsPlayerMechanic4Frontbar", (UnitBuffer / 2), (UnitBuffer / 2))
	WindowSetScale("BBarsPlayerMechanic4Frontbar", 1)
	WindowSetAlpha("BBarsPlayerMechanic4Frontbar", 1)
	WindowSetShowing("BBarsPlayerMechanic4Frontbar", false)
	WindowSetTintColor("BBarsPlayerMechanic4Frontbar", WhiteColour[1], WhiteColour[2], WhiteColour[3])

	CreateWindowFromTemplate("BBarsPlayerMechanic5Frontbar", "EA_DynamicImage_DefaultSeparatorRight", "Root")
	DynamicImageSetTexture("BBarsPlayerMechanic5Frontbar", FrontTexture, 0, 0)
	DynamicImageSetTextureDimensions("BBarsPlayerMechanic5Frontbar", UnitWidth, UnitHeight)
	WindowSetDimensions("BBarsPlayerMechanic5Frontbar", InnerBarWidth, InnerBarHeight)
	WindowSetParent("BBarsPlayerMechanic5Frontbar", "BBarsPlayerMechanic5BG")
	WindowSetOffsetFromParent("BBarsPlayerMechanic5Frontbar", (UnitBuffer / 2), (UnitBuffer / 2))
	WindowSetScale("BBarsPlayerMechanic5Frontbar", 1)
	WindowSetAlpha("BBarsPlayerMechanic5Frontbar", 1)
	WindowSetShowing("BBarsPlayerMechanic5Frontbar", false)
	WindowSetTintColor("BBarsPlayerMechanic5Frontbar", WhiteColour[1], WhiteColour[2], WhiteColour[3])
	
	-- ^^ FRONT COLOUR
	end
end

function BBars.CHSLMechanicUpdate()
	-- go through and check that this works nicely
	--PlaySound(GameData.Sound.PREGAME_ZOOM_BUTTON)
	-- no sound because it would literally just be playing always
	local Resource = GetCareerResource(GameData.BuffTargetType.SELF)

	if Resource == 0 then
		WindowSetAlpha("BBarsPlayerMechanic1Frontbar", 0)
		WindowSetAlpha("BBarsPlayerMechanic2Frontbar", 0)
		WindowSetAlpha("BBarsPlayerMechanic3Frontbar", 0)
		WindowSetAlpha("BBarsPlayerMechanic4Frontbar", 0)
		WindowSetAlpha("BBarsPlayerMechanic5Frontbar", 0)
	end
	if Resource >= 1 and Resource <= 24 then
		WindowSetAlpha("BBarsPlayerMechanic1Frontbar", 1)
		WindowSetAlpha("BBarsPlayerMechanic2Frontbar", 0)
		WindowSetAlpha("BBarsPlayerMechanic3Frontbar", 0)
		WindowSetAlpha("BBarsPlayerMechanic4Frontbar", 0)
		WindowSetAlpha("BBarsPlayerMechanic5Frontbar", 0)
	end
	if Resource >= 25 and Resource <= 35 then

		WindowSetAlpha("BBarsPlayerMechanic1Frontbar", 0)
		WindowSetAlpha("BBarsPlayerMechanic2Frontbar", 1)
		WindowSetAlpha("BBarsPlayerMechanic3Frontbar", 0)
		WindowSetAlpha("BBarsPlayerMechanic4Frontbar", 0)
		WindowSetAlpha("BBarsPlayerMechanic5Frontbar", 0)
	end
	if Resource >= 36 and Resource <= 74 then
		WindowSetAlpha("BBarsPlayerMechanic1Frontbar", 0)
		WindowSetAlpha("BBarsPlayerMechanic2Frontbar", 0)
		WindowSetAlpha("BBarsPlayerMechanic3Frontbar", 1)
		WindowSetAlpha("BBarsPlayerMechanic4Frontbar", 0)
		WindowSetAlpha("BBarsPlayerMechanic5Frontbar", 0)
	end
	if Resource >= 75 and Resource <= 89 then
		WindowSetAlpha("BBarsPlayerMechanic1Frontbar", 0)
		WindowSetAlpha("BBarsPlayerMechanic2Frontbar", 0)
		WindowSetAlpha("BBarsPlayerMechanic3Frontbar", 0)
		WindowSetAlpha("BBarsPlayerMechanic4Frontbar", 1)
		WindowSetAlpha("BBarsPlayerMechanic5Frontbar", 0)
	end
	if Resource >= 90 then
		WindowSetAlpha("BBarsPlayerMechanic1Frontbar", 0)
		WindowSetAlpha("BBarsPlayerMechanic2Frontbar", 0)
		WindowSetAlpha("BBarsPlayerMechanic3Frontbar", 0)
		WindowSetAlpha("BBarsPlayerMechanic4Frontbar", 0)
		WindowSetAlpha("BBarsPlayerMechanic5Frontbar", 1)
	end
end

function BBars.WEWHMechanicUpdate()
	-- this function is a CUCKED and triggers more than it should
	-- sometimes you will hear double because the stupid
	-- function triggers twice for no reason!? wtf!?
	local Resource = GetCareerResource(GameData.BuffTargetType.SELF)

	if Resource == 0 then
		PlaySound(GameData.Sound.PREGAME_ZOOM_BUTTON)
		--SWITCH TO A DIFFERENT SOUND LATER
		WindowSetShowing("BBarsPlayerMechanic1Frontbar", false)
		WindowSetShowing("BBarsPlayerMechanic2Frontbar", false)
		WindowSetShowing("BBarsPlayerMechanic3Frontbar", false)
		WindowSetShowing("BBarsPlayerMechanic4Frontbar", false)
		WindowSetShowing("BBarsPlayerMechanic5Frontbar", false)
	end
	if Resource == 1 then
		PlaySound(GameData.Sound.PREGAME_ZOOM_BUTTON)
		WindowSetShowing("BBarsPlayerMechanic1Frontbar", true)
		WindowSetShowing("BBarsPlayerMechanic2Frontbar", false)
		WindowSetShowing("BBarsPlayerMechanic3Frontbar", false)
		WindowSetShowing("BBarsPlayerMechanic4Frontbar", false)
		WindowSetShowing("BBarsPlayerMechanic5Frontbar", false)
	end
	if Resource == 2 then
		PlaySound(GameData.Sound.PREGAME_ZOOM_BUTTON)
		WindowSetShowing("BBarsPlayerMechanic1Frontbar", true)
		WindowSetShowing("BBarsPlayerMechanic2Frontbar", true)
		WindowSetShowing("BBarsPlayerMechanic3Frontbar", false)
		WindowSetShowing("BBarsPlayerMechanic4Frontbar", false)
		WindowSetShowing("BBarsPlayerMechanic5Frontbar", false)
	end
	if Resource == 3 then
		PlaySound(GameData.Sound.PREGAME_ZOOM_BUTTON)
		WindowSetShowing("BBarsPlayerMechanic1Frontbar", true)
		WindowSetShowing("BBarsPlayerMechanic2Frontbar", true)
		WindowSetShowing("BBarsPlayerMechanic3Frontbar", true)
		WindowSetShowing("BBarsPlayerMechanic4Frontbar", false)
		WindowSetShowing("BBarsPlayerMechanic5Frontbar", false)
	end
	if Resource == 4 then
		PlaySound(GameData.Sound.PREGAME_ZOOM_BUTTON)
		WindowSetShowing("BBarsPlayerMechanic1Frontbar", true)
		WindowSetShowing("BBarsPlayerMechanic2Frontbar", true)
		WindowSetShowing("BBarsPlayerMechanic3Frontbar", true)
		WindowSetShowing("BBarsPlayerMechanic4Frontbar", true)
		WindowSetShowing("BBarsPlayerMechanic5Frontbar", false)
	end
	if Resource == 5 then
		PlaySound(GameData.Sound.PREGAME_ZOOM_BUTTON)
		WindowSetShowing("BBarsPlayerMechanic1Frontbar", true)
		WindowSetShowing("BBarsPlayerMechanic2Frontbar", true)
		WindowSetShowing("BBarsPlayerMechanic3Frontbar", true)
		WindowSetShowing("BBarsPlayerMechanic4Frontbar", true)
		WindowSetShowing("BBarsPlayerMechanic5Frontbar", true)
	end
end

function BBars.BOSMMechanicUpdate()
	-- this function is a CUCKED and triggers more than it should
	-- sometimes you will hear double because the stupid
	-- function triggers twice for no reason!? wtf!?
	PlaySound(GameData.Sound.PREGAME_ZOOM_BUTTON)

	local Resource = GetCareerResource(GameData.BuffTargetType.SELF)

	if Resource == 0 then

		WindowSetShowing("BBarsPlayerMechanic2Frontbar", true)
		WindowSetShowing("BBarsPlayerMechanic3Frontbar", false)
		WindowSetShowing("BBarsPlayerMechanic4Frontbar", false)

	end
	if Resource == 1 then

		WindowSetShowing("BBarsPlayerMechanic2Frontbar", false)
		WindowSetShowing("BBarsPlayerMechanic3Frontbar", true)
		WindowSetShowing("BBarsPlayerMechanic4Frontbar", false)

	end
	if Resource == 2 then

		WindowSetShowing("BBarsPlayerMechanic2Frontbar", false)
		WindowSetShowing("BBarsPlayerMechanic3Frontbar", false)
		WindowSetShowing("BBarsPlayerMechanic4Frontbar", true)

	end
end

function BBars.SHMAWLENMechanicUpdate()
	-- not necessary as pet classes
	-- although magus and engineer have a buff stacking mechanic
	-- i don't feel like that's something that should be managed
	-- with this UI, but it DOES fit the 5 gears style...
end