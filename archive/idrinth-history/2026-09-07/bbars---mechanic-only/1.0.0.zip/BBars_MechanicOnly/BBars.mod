<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">	
  <UiMod name="BBars - Mechanic Only" version="1" date="2021-03-25" >		
    <Author name="Bset" email="--" />		
    <Description text="Bset's Bars with dat WeakAura A E S T H E T I C C" />       
      <VersionSettings gameVersion="1.4.8" windowsVersion="1.0" savedVariablesVersion="1.0" />		
      <Dependencies>			
	
      </Dependencies>		
      <Files>			
        <File name="BBars.lua" />			
        <File name="BBars.xml" />	
        <File name="BBarsPlayerMechanic.lua" />
        <File name="BBarsPetHP.lua" />
      </Files>
      <SavedVariables>
        </SavedVariables>		
      <OnInitialize>			
        <CallFunction name="BBars.OnInit" />		
      </OnInitialize>		
      <OnUpdate>			 
      </OnUpdate>
      <OnShutdown>
        <CallFunction name ="BBars.OnShutdown" />  		
      </OnShutdown>	
  </UiMod>
</ModuleFile>