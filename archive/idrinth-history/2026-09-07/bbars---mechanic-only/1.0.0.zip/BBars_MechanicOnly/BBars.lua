BBars = {}

ReadyColour 	= {25, 255, 25} -- green
FillColour	 	= {50, 75, 255} -- blue
BGColour 		= {0, 0, 0} -- black
ChipColour 		= {255, 0, 0} -- red
APColour 		= {255, 255, 0} -- yellow
HPColour 		= {0, 200, 0} -- {0, 255, 0} -- bright green
GreyColour 		= {75, 75, 75} -- actual grey
WhiteColour 	= {255, 255, 255} -- white
PinkColour 		= {255, 175, 200} -- pink
MoraleBGColour 	= {0, 10, 100} -- dark blue
RenownColour 	= {255, 0, 130} -- pink
HealerColour	= {0, 210, 0}
TankColour		= {0, 0, 210}
MDPSColour		= {210, 0, 0}
RDPSColour		= {210, 0, 210}
UnknownColour	= {210, 210, 210}

FrontTexture 	= "Smooth1"
BackTexture 	= "Smooth1"
BGTexture 		= "Smooth1"

BBTexture1		= {"Smooth1", 256, 32}
BBTexture2		= {"WAR1", 120, 42}
BBTexture3		= {"WAR2", 22, 28}
BBBG1			= {"WAR_BG1", 256, 64}

function round(n)
	return n % 1 >= 0.5 and math.ceil(n) or math.floor(n)
end


function BBars.OnInit()
	RegisterEventHandler(SystemData.Events.PLAYER_PET_UPDATED, "BBars.PetCheck")
	RegisterEventHandler(SystemData.Events.PLAYER_PET_STATE_UPDATED, "BBars.PetCheck")
    RegisterEventHandler(SystemData.Events.PLAYER_PET_HEALTH_UPDATED, "BBars.PetHPUpdate")
    RegisterEventHandler(SystemData.Events.ENTER_WORLD, "BBars.MechanicSort")
    RegisterEventHandler(SystemData.Events.INTERFACE_RELOADED, "BBars.MechanicSort")
	TextLogAddEntry("Chat", 0, L"<icon57> BBars (Mechanics Only), beh-beh!")
end

function BBars.OnShutdown()
	UnregisterEventHandler(SystemData.Events.PLAYER_CAREER_RESOURCE_UPDATED, "BBars.BOSMMechanicUpdate")
	UnregisterEventHandler(SystemData.Events.PLAYER_CAREER_RESOURCE_UPDATED, "BBars.WEWHMechanicUpdate")
	UnregisterEventHandler(SystemData.Events.PLAYER_CAREER_RESOURCE_UPDATED, "BBars.CHSLMechanicUpdate")
	if DoesWindowExist("BBarsPlayerMechanic3BG") then DestroyWindow("BBarsPlayerMechanic3BG") end
	if DoesWindowExist("BBarsPlayerMechanic3Grey") then DestroyWindow("BBarsPlayerMechanic3Grey") end
	if DoesWindowExist("BBarsPlayerMechanic3Frontbar") then DestroyWindow("BBarsPlayerMechanic3Frontbar") end
	if DoesWindowExist("BBarsPetHPBG") then DestroyWindow("BBarsPetHPBG") end
end