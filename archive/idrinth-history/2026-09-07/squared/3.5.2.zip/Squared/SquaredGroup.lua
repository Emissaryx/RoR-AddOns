SquaredGroup = {}

-- Make Squared table ref local for performance
local Squared = Squared

-- Make utility functions local for performance
local pairs = pairs
local unpack = unpack
local tonumber = tonumber
local tostring = tostring
local towstring = towstring
local max = math.max
local min = math.min
local wstring_sub = wstring.sub
local wstring_format = wstring.format
local tinsert = table.insert
local tremove = table.remove

local parent = nil

local groupData = nil

local QueuedMenuGroup = nil
local QueuedMenuMember = nil

-- 1.1.1 prep: use PartyUtils for group data once it's available; don't until then
local GetGroupData = PartyUtils and PartyUtils.GetPartyData or GetGroupData

function SquaredGroup.Initialize()
    -- register us as a handler with Squared
    parent = Squared.RegisterModeHandler("group", SquaredGroup)
end

function SquaredGroup.OnLoad()
    RegisterEventHandler( SystemData.Events.PLAYER_CUR_HIT_POINTS_UPDATED, "SquaredGroup.UpdateCurHP")
    RegisterEventHandler( SystemData.Events.PLAYER_MAX_HIT_POINTS_UPDATED, "SquaredGroup.UpdateMaxHP")
    RegisterEventHandler( SystemData.Events.PLAYER_CUR_ACTION_POINTS_UPDATED, "SquaredGroup.UpdateAP")
    RegisterEventHandler( SystemData.Events.PLAYER_CAREER_RANK_UPDATED, "SquaredGroup.UpdateLevel")
    RegisterEventHandler( SystemData.Events.GROUP_UPDATED, "SquaredGroup.UpdateGroup")
    RegisterEventHandler( SystemData.Events.GROUP_STATUS_UPDATED, "SquaredGroup.UpdateGroupStatus")
   
    SquaredGroup.UpdateGroup()
end

function SquaredGroup.OnUnload()
    UnregisterEventHandler( SystemData.Events.PLAYER_CUR_HIT_POINTS_UPDATED, "SquaredGroup.UpdateCurHP")
    UnregisterEventHandler( SystemData.Events.PLAYER_MAX_HIT_POINTS_UPDATED, "SquaredGroup.UpdateMaxHP")
    UnregisterEventHandler( SystemData.Events.PLAYER_CUR_ACTION_POINTS_UPDATED, "SquaredGroup.UpdateAP")
    UnregisterEventHandler( SystemData.Events.PLAYER_CAREER_RANK_UPDATED, "SquaredGroup.UpdateLevel")
    UnregisterEventHandler( SystemData.Events.GROUP_UPDATED, "SquaredGroup.UpdateGroup")
    UnregisterEventHandler( SystemData.Events.GROUP_STATUS_UPDATED, "SquaredGroup.UpdateGroupStatus")
end

function SquaredGroup.OnUpdate()
    if QueuedMenuGroup then
        SquaredGroup:ShowMenu(QueuedMenuGroup, QueuedMenuMember)
        QueuedMenuGroup = nil
        QueuedMenuMember = nil
    end
end

function SquaredGroup.UpdateGroup()
    parent.ClearGroups()
    SquaredGroup.frames = {}
    groupData = GetGroupData()
    
    -- add a frame for the player
    SquaredGroup.frames[1] = parent.AddUnit(1, 1, true)
	SquaredGroup.frames[1]:SetName(GameData.Player.name)
    SquaredGroup.frames[1]:SetCareer(GameData.Player.career.line)
    SquaredGroup.frames[1]:SetMaxVal(GameData.Player.hitPoints.maximum)
    SquaredGroup.frames[1]:SetVal(GameData.Player.hitPoints.current)
    SquaredGroup.frames[1]:SetAP((GameData.Player.actionPoints.current/GameData.Player.actionPoints.maximum)*100)
    SquaredGroup.frames[1]:SetLevel(GameData.Player.level)
    if GameData.Player.isGroupLeader then SquaredGroup.frames[1]:SetLeaderFlag(true) end
    SquaredGroup.frames[1]:Update()
    -- add frames for each group member
    for index,memberData in ipairs(groupData) do
        if memberData.name == GameData.Player.name then continue end
        local unitFrame = parent.AddUnit(1, index+1, true)
        if memberData.name and memberData.name ~= L"" then
            unitFrame:SetName(memberData.name)
            unitFrame:SetMaxVal(100)
			unitFrame:SetInRegion(memberData.isInSameRegion)
            unitFrame:SetVal(memberData.healthPercent)
            unitFrame:SetAP(memberData.actionPointPercent)
            unitFrame:SetCareer(memberData.careerLine)
            unitFrame:SetLevel(memberData.level)
            if memberData.isGroupLeader then unitFrame:SetLeaderFlag(true) end
            unitFrame:Update()
        else
            unitFrame:Show(false)
        end
        SquaredGroup.frames[index+1] = unitFrame
    end
    parent.ReanchorGroups()
end

function SquaredGroup.UpdateGroupStatus(memberIndex)
	local unitFrame = SquaredGroup.frames[memberIndex+1]
	
	if PartyUtils then
		local memberData = PartyUtils.GetPartyMember(memberIndex)
		
		unitFrame:SetVal(memberData.healthPercent)
		unitFrame:SetAP(memberData.actionPointPercent)
		unitFrame:SetLevel(memberData.level)
		unitFrame:Update()
	else
		local hp, ap, morale, rank, rvrFlag = GetGroupMemberStatusData(memberIndex)
		
		unitFrame:SetVal(hp)
		unitFrame:SetAP(ap)
		unitFrame:SetLevel(rank)
		unitFrame:Update()
	end
end

function SquaredGroup.UpdateCurHP()
    --update hp for player
    SquaredGroup.frames[1]:SetVal(GameData.Player.hitPoints.current)
    SquaredGroup.frames[1]:UpdateText()
end

function SquaredGroup.UpdateMaxHP()
    SquaredGroup.frames[1]:SetMaxVal(GameData.Player.hitPoints.maximum)
    SquaredGroup.frames[1]:UpdateText()
end

function SquaredGroup.UpdateAP()
    SquaredGroup.frames[1]:SetAP((GameData.Player.actionPoints.current/GameData.Player.actionPoints.maximum)*100)
    SquaredGroup.frames[1]:UpdateText()
end

function SquaredGroup.UpdateLevel()
    SquaredGroup.frames[1]:SetLevel(GameData.Player.level)
    SquaredGroup.frames[1]:UpdateText()
end

function SquaredGroup:UnitLClick(group, member, flags)
    return
end

function SquaredGroup:UnitRClick(group, member)
    if Squared.GetSetting("showmenu") then
        QueuedMenuGroup = group
        QueuedMenuMember = member
    end
end

function SquaredGroup:ShowMenu(group, member)
    
    local unit = Squared.GetUnit(group, member)
    if not unit then return end
    local playerName = unit.name
    if not playerName then return end
    
    SystemData.UserInput.selectedGroupMember = playerName
    
    -- Build the Custom Section of the Player Menu    
    local customMenuItems = {}    
    
    -- 1) World-Based Group Options
    local isNotLeader = GameData.Player.isGroupLeader ~= true
    if( GameData.Player.isInScenario == false or GameData.Player.isInSiege )
    then
        table.insert( customMenuItems, PlayerMenuWindow.NewCustomItem( GetString( StringTables.Default.LABEL_GROUP_OPTIONS ), SquaredGroup.OnViewGroupOptions, false ) )
        table.insert( customMenuItems, PlayerMenuWindow.NewCustomItem( GetString( StringTables.Default.LABEL_PARTY_FORM_WARPARTY ), GroupWindow.OnFormWarparty, isNotLeader ) )
        table.insert( customMenuItems, PlayerMenuWindow.NewCustomItem( GetString( StringTables.Default.LABEL_MAKE_LEADER ), GroupWindow.OnMakeLeader, isNotLeader ) )
        table.insert( customMenuItems, PlayerMenuWindow.NewCustomItem( GetString( StringTables.Default.LABEL_LEAVE_GROUP ), GroupWindow.OnLeaveGroup, false ) )       
    end

    -- 2) Main Assist
    -- Don't show the main assist option unless the player is the current main assist or group leader in a non scenario party
    -- This is done to keep persistent with how battlegroup context menu behaves
    local currentMainAssist = GroupWindow.GetMainAssist()
    if( ( GameData.Player.isGroupLeader and not GameData.Player.isInScenario ) or currentMainAssist == GameData.Player.name )
    then
        local disableMainAssist = currentMainAssist == playerName
        table.insert( customMenuItems, PlayerMenuWindow.NewCustomItem( GetString( StringTables.Default.LABEL_MAKE_MAIN_ASSIST ), GroupWindow.OnMakeMainAssist, disableMainAssist ) ) 
    end

    -- Create the Menu
    PlayerMenuWindow.ShowMenu( playerName, 0, customMenuItems )
    
end

function SquaredGroup.OnViewGroupOptions()
    if EA_Window_OpenParty then
        EA_Window_OpenParty.OpenToManageTab()
    elseif GroupWindow.OnViewGroupOptions then
        GroupWindow.OnViewGroupOptions()
    end
end