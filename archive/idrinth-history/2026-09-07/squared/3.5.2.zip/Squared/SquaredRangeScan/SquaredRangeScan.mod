<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
	<UiMod name="SquaredRangeScan" version="discontinued" date="1/12/2008" >

		<Author name="Aiiane" email="aiiane@aiiane.net" />
		<Description text="Full-group rangescan trigger plugin for Squared. ATTENTION: THIS WILL NO LONGER WORK, AND THIS DIRECTORY WILL BE REMOVED IN FUTURE RELEASES. IT IS INCLUDED ONLY TO MAKE SURE NO ERRORS ARE CAUSED BY OLD VERSIONS NOT BEING REMOVED WHEN UPDATING." />
        
        <Dependencies>
            <Dependency name="Squared" />
        </Dependencies>
		
	</UiMod>
</ModuleFile>
