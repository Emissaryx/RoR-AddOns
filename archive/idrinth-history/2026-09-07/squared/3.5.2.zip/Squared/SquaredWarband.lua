SquaredWarband = {}

local parent = nil

local groupData = nil

local QueuedMenuGroup = nil
local QueuedMenuMember = nil

local QueuedNextUpdate = nil

local lastUpdate = 0
local timeCount = 0
local updateDelay = 0.5

local playersName

-- 1.1.1 upgrades, use if present, otherwise fall back to old
local GetBattlegroupMemberData = PartyUtils and PartyUtils.GetWarbandData or GetBattlegroupMemberData

function SquaredWarband.Initialize()
    -- register us as a handler with Squared
    parent = Squared.RegisterModeHandler("warband", SquaredWarband)
end

function SquaredWarband.OnLoad()
    RegisterEventHandler(SystemData.Events.BATTLEGROUP_UPDATED, "SquaredWarband.UpdateGroup")
	
	-- 1.1.1 check
	if PartyUtils then
		RegisterEventHandler(SystemData.Events.BATTLEGROUP_MEMBER_UPDATED, "SquaredWarband.UpdateMember")
	end
	
    playersName = GameData.Player.name:match(L"([^^]+)^?([^^]*)")
    updateDelay = Squared.GetSetting("update-freq") or 0.5
    
    SquaredWarband.UpdateGroup()
end

function SquaredWarband.OnUnload()
    UnregisterEventHandler(SystemData.Events.BATTLEGROUP_UPDATED, "SquaredWarband.UpdateGroup")
	
	-- 1.1.1 check
	if PartyUtils then
		UnregisterEventHandler(SystemData.Events.BATTLEGROUP_MEMBER_UPDATED, "SquaredWarband.UpdateMember")
	end
	
    QueuedMenuGroup = nil
    QueuedMenuMember = nil
end

function SquaredWarband.OnUpdate(timePassed)
    timeCount = timeCount + timePassed
    
    if QueuedMenuGroup then
        SquaredWarband:ShowMenu(QueuedMenuGroup, QueuedMenuMember)
        QueuedMenuGroup = nil
        QueuedMenuMember = nil
    end
    
	-- auto-disable queueing updates once 1.1.1 is live
	if not PartyUtils then
	    if QueuedNextUpdate then
	        if lastUpdate + updateDelay < timeCount then
	            SquaredWarband.UpdateGroup()
	        end
	    end
	end
end

function SquaredWarband.UpdateGroup()
    
	-- auto-disable queueing updates once 1.1.1 is live
	if not PartyUtils then
	    if timeCount - lastUpdate < updateDelay then
	        QueuedNextUpdate = true
	        return
	    end
	    
	    lastUpdate = timeCount
	    QueuedNextUpdate = false
	end
    
    groupData = GetBattlegroupMemberData()
    
    if not groupData then return end
    
    parent.ClearGroups()
    
    for groupIndex = 4,1,-1 do
        local playersGroup = false
        local groupSize = table.getn(groupData[groupIndex].players)
        for memberIndex = 1,groupSize do
            --is this the player's group?
            if groupData[groupIndex].players[memberIndex].name:match(L"([^^]+)^?([^^]*)") == playersName then
                playersGroup = true
            end
        end
        for memberIndex = 1,6 do
            if memberIndex <= groupSize then
                local unitFrame = parent.AddUnit(groupIndex, memberIndex, true)
                local memberData = groupData[groupIndex].players[memberIndex]
                unitFrame:SetName(memberData.name)
                unitFrame:SetCareer(memberData.careerLine)
                unitFrame:SetMaxVal(100)
                unitFrame:SetVal(memberData.healthPercent)
                unitFrame:SetAP(memberData.actionPointPercent)
                unitFrame:SetLevel(memberData.level)
                if playersGroup then unitFrame:SetMyGroupFlag(true) end
                unitFrame:SetLeaderFlag(memberData.isGroupLeader)
                unitFrame:Update()
            end
        end
    end
    
    parent.ReanchorGroups()
end

function SquaredWarband.UpdateMember(partyIndex, memberIndex)
	-- 1.1.1 safety check (even though this should never be called until the new event is added in 1.1.1)
	if not PartyUtils then return end
	
	local unitFrame = parent.GetUnit(partyIndex, memberIndex)
	local memberData = PartyUtils.GetWarbandMember(partyIndex, memberIndex)
	unitFrame:SetVal(memberData.healthPercent)
	unitFrame:SetAP(memberData.actionPointPercent)
	unitFrame:SetLevel(memberData.careerLine)
    unitFrame:SetLevel(memberData.level)
	unitFrame:Update()
end

function SquaredWarband:UnitLClick(group, member, flags)
    return
end

function SquaredWarband:UnitRClick(group, member)
    if Squared.GetSetting("showmenu") then
        QueuedMenuGroup = group
        QueuedMenuMember = member
    end
end

function SquaredWarband:ShowMenu(group, member)

    local playerName = nil
    local groupNum = tonumber(group)
    if not groupData then return end
    if groupData[groupNum] then
        if groupData[groupNum].players[member] then
            playerName = groupData[groupNum].players[member].name
        end
    end
    
    if not playerName then return end
    
    SystemData.UserInput.selectedGroupMember = playerName
        
    -- Build the Custom Section of the Player Menu    
    local customMenuItems = {}            
    
    -- 2) Show the "Show Warband" option if the player is in an active warband
    if( IsWarBandActive() ) 
    then
        table.insert( customMenuItems, PlayerMenuWindow.NewCustomItem( GetStringFromTable("HUDStrings", StringTables.HUD.LABEL_SHOW_WARBAND), SquaredWarband.OnMenuClickShowWarband, false ) )
    end
    
    if GroupWindow.OnViewGroupOptions then
        table.insert( customMenuItems, PlayerMenuWindow.NewCustomItem( GetString( StringTables.Default.LABEL_GROUP_OPTIONS ), GroupWindow.OnViewGroupOptions, false ))
    end
    
    -- 4) Show the "Make Leader" option if the player is a group leader
    if( GameData.Player.isGroupLeader ) then
        table.insert( customMenuItems, PlayerMenuWindow.NewCustomItem( GetString( StringTables.Default.LABEL_MAKE_LEADER ), SquaredWarband.OnMenuClickMakeLeader, false ))
    end
    
    -- 5) Main Assist
    local currentMainAssist = nil
    if PartyUtils then
        local MAData = PartyUtils.GetWarbandMainAssist()
        currentMainAssist = MAData.name
    else
        currentMainAssist = GroupWindow.GetMainAssist()
    end
    if( GameData.Player.isGroupLeader or ( WStringsCompareIgnoreGrammer( currentMainAssist, GameData.Player.name ) == 0 )  )
    then
        local disableMainAssist = ( WStringsCompareIgnoreGrammer( currentMainAssist, playerName ) == 0 )
        table.insert( customMenuItems, PlayerMenuWindow.NewCustomItem( GetString( StringTables.Default.LABEL_MAKE_MAIN_ASSIST ), SquaredWarband.OnMenuClickMakeMainAssist, disableMainAssist ))
    end
    
    -- 6) Show the "Leave Party" option if the player is currently in a player-made party
    if( GroupWindow.inWorldGroup or IsWarBandActive() ) then
        table.insert( customMenuItems, PlayerMenuWindow.NewCustomItem( GetStringFromTable("HUDStrings", StringTables.HUD.LABEL_LEAVE_GROUP), SquaredWarband.OnMenuClickLeaveGroup, false ))
    end
  
     -- Create the Menu
    PlayerMenuWindow.ShowMenu( playerName, 0, customMenuItems ) 

end

function SquaredWarband.OnMenuClickShowWarband()
    if EA_Window_OpenParty then
        EA_Window_OpenParty.OpenToManageTab()
    elseif DoesWindowExist("BattlegroupWindow") then
        WindowSetShowing("BattlegroupWindow", true)
    end
end

function SquaredWarband.OnMenuClickGroupKick()
    SystemData.UserInput.ChatText = L"/partyremove "..SystemData.UserInput.selectedGroupMember
    BroadcastEvent( SystemData.Events.SEND_CHAT_TEXT )
end

function SquaredWarband.OnMenuClickMakeLeader()    
    SystemData.UserInput.ChatText = L"/warbandleader "..SystemData.UserInput.selectedGroupMember
    BroadcastEvent( SystemData.Events.SEND_CHAT_TEXT ) 
end

function SquaredWarband.OnMenuClickTellMember()
    local text = L"/tell "..SystemData.UserInput.selectedGroupMember..L" "
    EA_ChatWindow.SwitchChannelWithExistingText(text)
end

function SquaredWarband.OnMenuClickTargetMember()
    SystemData.UserInput.ChatText = L"/target "..SystemData.UserInput.selectedGroupMember
    BroadcastEvent( SystemData.Events.SEND_CHAT_TEXT )
end

function SquaredWarband.OnMenuClickAssistMember()
    SystemData.UserInput.ChatText = L"/assist "..SystemData.UserInput.selectedGroupMember
    BroadcastEvent( SystemData.Events.SEND_CHAT_TEXT )
end

function SquaredWarband.OnMenuClickLeaveGroup()
    BroadcastEvent( SystemData.Events.GROUP_LEAVE )
end

function SquaredWarband.OnMenuClickMakeMainAssist()    
    if( ButtonGetDisabledFlag(SystemData.ActiveWindow.name ) == true ) then
        return
    end
    
    BroadcastEvent( SystemData.Events.GROUP_SET_MAIN_ASSIST )    
end