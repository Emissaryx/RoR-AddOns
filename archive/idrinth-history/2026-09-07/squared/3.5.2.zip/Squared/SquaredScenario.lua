SquaredScenario = {}

-- Make Squared table ref local for performance
local Squared = Squared

-- Make utility functions local for performance
local pairs = pairs
local ipairs = ipairs
local unpack = unpack
local tonumber = tonumber
local tostring = tostring
local towstring = towstring
local max = math.max
local min = math.min
local wstring_sub = wstring.sub
local wstring_format = wstring.format
local tinsert = table.insert
local tremove = table.remove

local parent = nil

local groupData = nil
local groups = nil

local updateFlag = false
local delay = 0
local UPDATE_DELAY = 0.3

local careerLines = {}

local QueuedMenuGroup = nil
local QueuedMenuMember = nil

function SquaredScenario.Initialize()
    -- register us as a handler with Squared
    parent = Squared.RegisterModeHandler("scenario", SquaredScenario)
    
    local careerIDsToLines = {
        [20] = GameData.CareerLine.IRON_BREAKER,
        [100] = GameData.CareerLine.SWORDMASTER,
        [64] = GameData.CareerLine.CHOSEN,
        [24] = GameData.CareerLine.BLACK_ORC,
        [60] = GameData.CareerLine.WITCH_HUNTER,
        [102] = GameData.CareerLine.SEER,
        [65] = GameData.CareerLine.WARRIOR,
        [105] = GameData.CareerLine.ASSASSIN,
        [62] = GameData.CareerLine.BRIGHT_WIZARD,
        [67] = GameData.CareerLine.MAGUS,
        [107] = GameData.CareerLine.SORCERER,
        [23] = GameData.CareerLine.ENGINEER,
        [101] = GameData.CareerLine.SHADOW_WARRIOR,
        [27] = GameData.CareerLine.SQUIG_HERDER,
        [63] = GameData.CareerLine.WARRIOR_PRIEST,
        [106] = GameData.CareerLine.BLOOD_PRIEST,
        [103] = GameData.CareerLine.ARCHMAGE,
        [26] = GameData.CareerLine.SHAMAN,
        [22] = GameData.CareerLine.RUNE_PRIEST,
        [66] = GameData.CareerLine.ZEALOT,
        [104] = GameData.CareerLine.SHADE,
        [61] = GameData.CareerLine.KNIGHT,
        [25] = GameData.CareerLine.CHOPPA,
        [21] = GameData.CareerLine.SLAYER or GameData.CareerLine.HAMMERER,
    }

    
    -- Build localized careername -> careerLine mapping table from the only decent source we have.
    for k,v in pairs(GameData.Account.CharacterCreation.DestructionCareers) do
        for k2,v2 in ipairs(v) do
            if careerIDsToLines[v2.Career] then
                careerLines[(v2.MaleCareerName):match(L"^(.*)%^.*")] = careerIDsToLines[v2.Career]
                careerLines[(v2.FemaleCareerName):match(L"^(.*)%^.*")] = careerIDsToLines[v2.Career]
            end
        end
    end
    for k,v in ipairs(GameData.Account.CharacterCreation.OrderCareers) do
        for k2,v2 in ipairs(v) do
            if careerIDsToLines[v2.Career] then
                careerLines[(v2.MaleCareerName):match(L"^(.*)%^.*")] = careerIDsToLines[v2.Career]
                careerLines[(v2.FemaleCareerName):match(L"^(.*)%^.*")] = careerIDsToLines[v2.Career]
            end
        end
    end
    
end

function SquaredScenario.OnLoad()
    RegisterEventHandler(SystemData.Events.SCENARIO_PLAYERS_LIST_GROUPS_UPDATED, "SquaredScenario.FlagUpdate")
    RegisterEventHandler(SystemData.Events.SCENARIO_PLAYERS_LIST_RESERVATIONS_UPDATED, "SquaredScenario.FlagUpdate")
   
    UPDATE_DELAY = Squared.GetSetting("update-freq") or 0.5
   
    SquaredScenario.UpdateGroup()
end

function SquaredScenario.OnUnload()
    UnregisterEventHandler( SystemData.Events.SCENARIO_PLAYERS_LIST_GROUPS_UPDATED, "SquaredScenario.FlagUpdate")
    UnregisterEventHandler(SystemData.Events.SCENARIO_PLAYERS_LIST_RESERVATIONS_UPDATED, "SquaredScenario.FlagUpdate")
    QueuedMenuGroup = nil
    QueuedMenuMember = nil
end

function SquaredScenario.FlagUpdate()
    updateFlag = true
end

function SquaredScenario.OnUpdate(timePassed)
    delay = delay - timePassed
    
    if QueuedMenuGroup then
        SquaredScenario:ShowMenu(QueuedMenuGroup, QueuedMenuMember)
        QueuedMenuGroup = nil
        QueuedMenuMember = nil
    end
    
    if delay <= 0 and updateFlag then
        updateFlag = false
        SquaredScenario.UpdateGroup()
        delay = UPDATE_DELAY
    end
end

-- sort function that sorts elements in a table according to each subtable's second element
local function groupsortfunc(a,b)
	if a[2] < b[2] then return true else return false end
end

function SquaredScenario.UpdateGroup()
    
    groupData = GameData.GetScenarioPlayerGroups()
    
    if not groupData then return end
    
    parent.ClearGroups()
    
    groups = {}
    
    for index, player in ipairs(groupData) do
        if player.sgroupindex > 0 then
            local groupIndex = player.sgroupindex
            local groupSlotNum = player.sgroupslotnum
            if not groups[groupIndex] then groups[groupIndex] = {} end
            tinsert(groups[groupIndex], {index, groupSlotNum})
        end
    end
            
    for group,groupIndexes in pairs(groups) do
		
		-- sort the groups according to slot number
		table.sort(groupIndexes, groupsortfunc)
		
        local playerGroup = nil
        local playersName = GameData.Player.name:match(L"([^^]+)^?([^^]*)")
        for index,memberIndexData in ipairs(groupIndexes) do
			local memberIndex = memberIndexData[1]
            local memberData = groupData[memberIndex]
            if (memberData.name):match(L"([^^]+)^?([^^]*)") == playersName then
                playerGroup = true
            end
        end
        for index,memberIndexData in ipairs(groupIndexes) do
            local memberIndex = memberIndexData[1]
			local memberData = groupData[memberIndex]
            local unitFrame = parent.AddUnit(group, index, true)
            if memberData.name and memberData.name ~= L"" then
                unitFrame:SetName(memberData.name)
                unitFrame:SetCareer(careerLines[memberData.career:match(L"([^^]+)^?([^^]*)")])
                unitFrame:SetMaxVal(100)
                unitFrame:SetVal(memberData.health)
                unitFrame:SetAP(memberData.ap)
                unitFrame:SetLevel(memberData.rank)
                if playerGroup then unitFrame:SetMyGroupFlag(true) end
                unitFrame:Update()
            else
                unitFrame:Show(false)
            end
        end
    end
    
    parent.ReanchorGroups()
end

function SquaredScenario:UnitLClick(group, member, flags)
    return
end

function SquaredScenario:UnitRClick(group, member)
    if Squared.GetSetting("showmenu") then
        QueuedMenuGroup = group
        QueuedMenuMember = member
    end
end

function SquaredScenario:ShowMenu(group, member)
    local unit = Squared.GetUnit(group, member)
    if not unit then return end
    local playerName = unit.name
    if not playerName then return end
    
    SystemData.UserInput.selectedGroupMember = playerName
    
    PlayerMenuWindow.ShowMenu(playerName, 0)
end