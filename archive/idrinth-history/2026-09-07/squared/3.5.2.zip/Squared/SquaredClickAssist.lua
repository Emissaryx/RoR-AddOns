-- Make Squared table ref local for performance
local Squared = Squared

function Squared.PotentialClickAssist(group, member, flags)
    local keyassist = Squared.GetSetting("key-assist")
    
    if (keyassist == "alt" and flags == SystemData.ButtonFlags.ALT)
    or (keyassist == "ctrl" and flags == SystemData.ButtonFlags.CONTROL)
    or (keyassist == "shift" and flags == SystemData.ButtonFlags.SHIFT) then
        local unit = Squared.GetUnit(group, member)
        if not unit then return end
        
        local unitname = unit.name
        if not unitname or unitname == L"" then return end
        
        unitname = unitname:match(L"([^^]+)^?[^^]*")
        
        SystemData.UserInput.ChatText = L"/assist "..unitname
        BroadcastEvent(SystemData.Events.SEND_CHAT_TEXT)
    end
    
    if Squared.GetSetting("key-assist-final") then return true else return false end
end

Squared.RegisterEventHandler("unitlclick", Squared.PotentialClickAssist)