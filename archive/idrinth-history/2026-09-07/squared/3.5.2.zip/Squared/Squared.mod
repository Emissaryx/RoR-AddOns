<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
	<UiMod name="Squared" version="3.5.2" date="19/2/2009" >

		<Author name="Aiiane" email="aiiane@aiiane.net" />
		<Description text="Concise unit status indicators." />
        
        <Dependencies>
			<Dependency name="EASystem_Utils" />
            <Dependency name="EASystem_LayoutEditor" />
            <Dependency name="EASystem_WindowUtils" />
            <Dependency name="EA_ActionBars" />
            <Dependency name="EA_TargetWindow" />
			<Dependency name="SharedAssetsSquared" />
        </Dependencies>
        
		<Files>
            <File name="TargetInfoFix.lua" />
			<File name="LibStub.lua" />
			<File name="LibSharedAssets.lua" />
			<File name="SquaredIcon.xml" />
            <File name="Squared.xml" />
            <File name="SquaredDefaultSettings.lua" />
            <File name="Squared.lua" />
            <File name="SquaredUnitFrame.lua" />
            <File name="SquaredPlayer.lua" />
            <File name="SquaredGroup.lua" />
            <File name="SquaredScenario.lua" />
            <File name="SquaredWarband.lua" />
            <File name="SquaredTestmode.lua" />
            <File name="SquaredSlashConfig.lua" />
            <File name="SquaredRangeFading.lua" />
            <File name="SquaredClickAssist.lua" />
			<File name="SquaredProfiles.lua" />
		</Files>
		
		<OnInitialize>
            <CreateWindow name="SquaredAnchor" />
			<CreateWindow name="SquaredIcon" />
            <CallFunction name="Squared.Initialize" />
            <CallFunction name="SquaredPlayer.Initialize" />
            <CallFunction name="SquaredGroup.Initialize" />
            <CallFunction name="SquaredScenario.Initialize" />
            <CallFunction name="SquaredWarband.Initialize" />
            <CallFunction name="SquaredTestmode.Initialize" />
            <CallFunction name="SquaredRangeFading.Initialize" />
		</OnInitialize>
		<OnUpdate>
            <CallFunction name="Squared.OnUpdate" />
        </OnUpdate>
		<OnShutdown/>
		
	</UiMod>
</ModuleFile>
