<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <UiMod name="RezEmote" version="1.0.0" date="11/26/25">
    <VersionSettings gameVersion="2.4.8" windowsVersion="1.0" savedVariablesVersion="1.0" />
    <Author name="Ninjas" email="" />
    <Description text="Automatically emotes /rez when you die so you show up on ResHelp addon." />

    <Files>
      <File name="RezEmote.lua" />
    </Files>

    <OnInitialize>
      <CallFunction name="RezEmote.Initialize" />
    </OnInitialize>

  </UiMod>
</ModuleFile>