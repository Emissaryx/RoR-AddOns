RezEmote = RezEmote or {}

function RezEmote.Initialize()
    if SystemData and SystemData.Events and SystemData.Events.PLAYER_DEATH then
        RegisterEventHandler(SystemData.Events.PLAYER_DEATH, "RezEmote.OnPlayerDeath")
    else
        if TextLogAddEntry and SystemData and SystemData.ChatLogFilters then
            TextLogAddEntry("Chat", SystemData.ChatLogFilters.SAY, L"[RezEmote] PLAYER_DEATH event not found.")
        end
    end
end

function RezEmote.Shutdown()
    if SystemData and SystemData.Events and SystemData.Events.PLAYER_DEATH then
        UnregisterEventHandler(SystemData.Events.PLAYER_DEATH, "RezEmote.OnPlayerDeath")
    end
end

function RezEmote.OnPlayerDeath()
    if not (GameData and GameData.Player and GameData.Player.rvrZoneFlagged) then
        return
    end

    if SendChatText ~= nil then
        SendChatText(L"/rez", L"")
    elseif TextLogAddEntry ~= nil and SystemData and SystemData.ChatLogFilters then
        TextLogAddEntry("Chat", SystemData.ChatLogFilters.SAY, L"/rez")
    end
end