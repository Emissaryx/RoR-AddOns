CoolDownTracker = CoolDownTracker or {}
local Addon = CoolDownTracker

Addon.Private = Addon.Private or {}
CoolDownTracker_Saved = CoolDownTracker_Saved or {}

Addon.ANCHOR_WINDOW = "CoolDownTrackerAnchor"
Addon.ANCHOR_HOVER_WINDOW = "CoolDownTrackerAnchorHover"
Addon.ANCHOR_HOVER_LABEL_TEXT = "CoolDownTracker"
Addon.POSITION_LOCK_ICON_ID = 39
Addon.VERSION = "0.7.3"
Addon.SLOT_TEMPLATE = "CoolDownTrackerAbilitySlotTemplate"
Addon.SLOT_PREFIX = "CoolDownTrackerAbilitySlot"
Addon.SLOT_WIDTH = 96
Addon.SLOT_HEIGHT = 108
Addon.SLOT_SPACING_X = 116
Addon.SLOT_SPACING_Y = 140
Addon.SLOT_OFFSET_Y = 18
Addon.HORIZONTAL_SLOT_OFFSET_Y = 24
Addon.ANCHOR_EXTRA_HEIGHT = 18
Addon.DEFAULT_SLOT_SCALE = 0.5
Addon.DEFAULT_BUILD_DIRECTION = "right"
Addon.MIN_SLOT_SCALE = 0.25
Addon.MAX_SLOT_SCALE = 2.0
Addon.COOLDOWN_MUTED_ALPHA = 0.75
Addon.MAX_SESSION_INSTANCES = 6
Addon.GROUP_SHARED_RESET_MIN_DELTA = 0.75
Addon.GROUP_SHARED_RESET_NEAR_FULL_TOLERANCE = 1.0
Addon.DRAG_HOVER_TARGET_ALPHA = 1.0
Addon.DRAG_FADE_IN_SECONDS = 0.12
Addon.DRAG_FADE_OUT_SECONDS = 0.18
Addon.DRAG_HIDE_DELAY_SECONDS = 0.3
Addon.OBSERVED_REFRESH_DELAY = 0.50
Addon.OBSERVED_REFRESH_MIN_INTERVAL = 0.75
Addon.SHARED_COUNTDOWN_INTERVAL = 1.0
Addon.CHAT_PREFIX_COLOR = "200,200,200"
Addon.TOOLTIP_ANCHOR = {
    Point = "bottomleft",
    RelativeTo = "",
    RelativePoint = "topleft",
    XOffset = 0,
    YOffset = 0,
}

Addon.TRACKED_ABILITIES = {
    -- Roster-gated class/group watches, alphabetized by display name.
    -- Add new class-source watches in this section.
    {
        key = "absolute_preservation",
        name = "Absolute Preservation",
        abilityId = 28303,
        iconId = 23175,
        cooldownSeconds = 120,
        effectDurationSeconds = 10,
        observeSelf = true,
        observeGroup = true,
        isGroupSharedBuff = true,
        minRosterLevel = 40,
        eligibleCareerNames = {
            "ARCHMAGE",
            "RUNE_PRIEST",
            "SHAMAN",
            "ZEALOT",
        },
        note = "Archmage/Shaman King's Ransom Sovereign and Runepriest/Zealot Warlord granted ability.",
    },
    {
        key = "for_the_witch_king",
        name = "For The Witch King!",
        abilityId = 6020,
        altAbilityIds = {
            9352,
            5775,
        },
        iconId = 11046,
        cooldownSeconds = 30,
        effectDurationSeconds = 10,
        observeSelf = true,
        observeGroup = true,
        isGroupSharedBuff = true,
        faction = "destruction",
        minRosterLevel = 29,
        eligibleCareerNames = {
            "BLACKGUARD",
        },
        note = "Black Guard For The Witch King group cooldown-reduction buff.",
    },
    {
        key = "wez_bigger",
        name = "We'z Bigger",
        abilityId = 1696,
        altAbilityIds = {
            859,
        },
        iconId = 2568,
        cooldownSeconds = 30,
        effectDurationSeconds = 5,
        observeSelf = true,
        observeGroup = true,
        isGroupSharedBuff = true,
        faction = "destruction",
        minRosterLevel = 30,
        eligibleCareerNames = {
            "BLACK_ORC",
        },
        requiredEffectTextContains = "Movement speed increased",
        note = "Black Orc We'z Bigger movement-speed buff, detected from the live effect text.",
    },
    {
        key = "whispering_wind",
        name = "Whispering Wind",
        abilityId = 3335,
        altAbilityIds = {
            9030,
            2178,
        },
        iconId = 13380,
        cooldownSeconds = 30,
        effectDurationSeconds = 10,
        observeSelf = true,
        observeGroup = true,
        isGroupSharedBuff = true,
        faction = "order",
        minRosterLevel = 29,
        eligibleCareerNames = {
            "SWORDMASTER",
        },
        note = "Swordmaster Whispering Wind group cooldown-reduction buff.",
    },

    -- Always-scannable nearby-ally movement watches, alphabetized by display name.
    -- Add fixed-cap area buffs here.
    {
        key = "into_the_fray",
        name = "Into the Fray",
        abilityId = 27044,
        iconId = 13372,
        trackEnabledByDefault = false,
        cooldownSeconds = 120,
        effectDurationSeconds = 4,
        observeSelf = true,
        observeGroup = true,
        isGroupSharedBuff = true,
        maxPlausibleInstances = 4,
        note = "Tank Onslaught granted nearby-ally movement-speed buff; disabled by default and uses the same fixed duplicate cap.",
    },
    {
        key = "leading_the_charge",
        name = "Leading The Charge",
        abilityId = 28301,
        iconId = 13372,
        cooldownSeconds = 120,
        effectDurationSeconds = 10,
        observeSelf = true,
        observeGroup = true,
        isGroupSharedBuff = true,
        maxPlausibleInstances = 4,
        note = "Tank Sovereign granted nearby-ally movement-speed buff; always scannable with a fixed duplicate cap.",
    },
}

Addon._states = Addon._states or {}
Addon._sessions = Addon._sessions or {}
Addon._sessionByKey = Addon._sessionByKey or {}
Addon._sessionByIdentifier = Addon._sessionByIdentifier or {}
Addon._sessionByAbilityId = Addon._sessionByAbilityId or {}
Addon._stateByWindowId = Addon._stateByWindowId or {}
Addon._statesBySessionKey = Addon._statesBySessionKey or {}
Addon._scannableTrackedByAbilityId = Addon._scannableTrackedByAbilityId or {}
Addon._requiredObservedAnyAbilityIdSet = Addon._requiredObservedAnyAbilityIdSet or {}
Addon._trackedByIdentifier = Addon._trackedByIdentifier or {}
Addon._trackedByAbilityId = Addon._trackedByAbilityId or {}
Addon._trackedByDisplayIndex = Addon._trackedByDisplayIndex or {}
Addon._eventsRegistered = Addon._eventsRegistered or false
Addon._factionBootstrapEventsRegistered = Addon._factionBootstrapEventsRegistered == true
Addon._updateHandlerRegistered = Addon._updateHandlerRegistered == true
Addon._slashRegistered = Addon._slashRegistered or false
Addon._initializedAfterFactionKnown = Addon._initializedAfterFactionKnown == true
Addon._waitingForPlayerFaction = Addon._waitingForPlayerFaction == true
Addon._nextUpdateAt = tonumber(Addon._nextUpdateAt) or -1
Addon._nextCountdownUpdateAt = tonumber(Addon._nextCountdownUpdateAt) or -1
Addon._nextTimedStateUpdateAt = tonumber(Addon._nextTimedStateUpdateAt) or -1
Addon._pendingObservedRefresh = Addon._pendingObservedRefresh == true
Addon._pendingObservedRefreshRequestedAt = tonumber(Addon._pendingObservedRefreshRequestedAt) or -1
Addon._lastObservedRefreshAt = tonumber(Addon._lastObservedRefreshAt) or -1
Addon._observesSelf = Addon._observesSelf == true
Addon._observesGroup = Addon._observesGroup == true
Addon._tracksGroupRoster = Addon._tracksGroupRoster == true
Addon._registeredEventConfigKey = Addon._registeredEventConfigKey or ""
Addon._scannableStateCount = tonumber(Addon._scannableStateCount) or 0
Addon._groupRosterSignature = Addon._groupRosterSignature or ""
Addon._eligibleRosterCountByKey = Addon._eligibleRosterCountByKey or {}
Addon._maxPlausibleInstancesByKey = Addon._maxPlausibleInstancesByKey or {}
Addon._anchorWidth = tonumber(Addon._anchorWidth) or 0
Addon._anchorHeight = tonumber(Addon._anchorHeight) or 0
Addon._countdownCadenceAnchorAt = tonumber(Addon._countdownCadenceAnchorAt) or -1
Addon._dirtySessionKeys = Addon._dirtySessionKeys or {}
Addon._dirtyAllSessions = Addon._dirtyAllSessions == true
