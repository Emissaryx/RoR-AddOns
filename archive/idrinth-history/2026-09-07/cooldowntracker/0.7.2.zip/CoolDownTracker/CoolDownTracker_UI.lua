local Addon = CoolDownTracker
local Private = Addon.Private

local function CoolDownTracker_SetShadowedLabel(
    coolDownTracker_bgWindowName,
    coolDownTracker_windowName,
    coolDownTracker_text
)
    Private.SetLabelTextFast(coolDownTracker_bgWindowName, coolDownTracker_text)
    Private.SetLabelTextFast(coolDownTracker_windowName, coolDownTracker_text)
end

local function CoolDownTracker_SetColor(
    coolDownTracker_color,
    coolDownTracker_red,
    coolDownTracker_green,
    coolDownTracker_blue
)
    coolDownTracker_color.red = coolDownTracker_red
    coolDownTracker_color.green = coolDownTracker_green
    coolDownTracker_color.blue = coolDownTracker_blue
    return coolDownTracker_color
end

local function CoolDownTracker_GetReusableVisualState(coolDownTracker_state)
    local coolDownTracker_visual = coolDownTracker_state._visualScratch
    if type(coolDownTracker_visual) ~= "table" then
        coolDownTracker_visual = {
            timerColor = {},
            statusColor = {},
            iconTint = {},
            frameTint = {},
        }
        coolDownTracker_state._visualScratch = coolDownTracker_visual
    end

    return coolDownTracker_visual
end

local function CoolDownTracker_GetAppliedVisualCache(coolDownTracker_state)
    if coolDownTracker_state._appliedVisualWindowName ~= coolDownTracker_state.windowName then
        coolDownTracker_state._appliedVisualWindowName = coolDownTracker_state.windowName
        coolDownTracker_state._appliedVisual = nil
    end

    if type(coolDownTracker_state._appliedVisual) ~= "table" then
        coolDownTracker_state._appliedVisual = {}
    end

    return coolDownTracker_state._appliedVisual
end

local function CoolDownTracker_GetAppliedLayoutCache(coolDownTracker_state)
    if coolDownTracker_state._appliedLayoutWindowName ~= coolDownTracker_state.windowName then
        coolDownTracker_state._appliedLayoutWindowName = coolDownTracker_state.windowName
        coolDownTracker_state._appliedLayout = nil
    end

    if type(coolDownTracker_state._appliedLayout) ~= "table" then
        coolDownTracker_state._appliedLayout = {}
    end

    return coolDownTracker_state._appliedLayout
end

local function CoolDownTracker_SetSlotWindowIds(coolDownTracker_state)
    if type(WindowSetId) ~= "function" then
        return
    end

    local coolDownTracker_windowId = coolDownTracker_state.windowId
    local coolDownTracker_windowNames = {
        coolDownTracker_state.windowName,
        coolDownTracker_state.iconWindowName,
        coolDownTracker_state.frameWindowName,
        coolDownTracker_state.timerBgWindowName,
        coolDownTracker_state.timerWindowName,
        coolDownTracker_state.statusBgWindowName,
        coolDownTracker_state.statusWindowName,
    }
    for _, coolDownTracker_windowName in ipairs(coolDownTracker_windowNames) do
        if Private.DoesWindowExist(coolDownTracker_windowName) then
            pcall(WindowSetId, coolDownTracker_windowName, coolDownTracker_windowId)
        end
    end
end

local function CoolDownTracker_DidCachedColorChange(
    coolDownTracker_cache,
    coolDownTracker_key,
    coolDownTracker_color
)
    local coolDownTracker_redKey = coolDownTracker_key .. "Red"
    local coolDownTracker_greenKey = coolDownTracker_key .. "Green"
    local coolDownTracker_blueKey = coolDownTracker_key .. "Blue"
    local coolDownTracker_red = coolDownTracker_color.red
    local coolDownTracker_green = coolDownTracker_color.green
    local coolDownTracker_blue = coolDownTracker_color.blue

    if coolDownTracker_cache[coolDownTracker_redKey] == coolDownTracker_red
        and coolDownTracker_cache[coolDownTracker_greenKey] == coolDownTracker_green
        and coolDownTracker_cache[coolDownTracker_blueKey] == coolDownTracker_blue then
        return false
    end

    coolDownTracker_cache[coolDownTracker_redKey] = coolDownTracker_red
    coolDownTracker_cache[coolDownTracker_greenKey] = coolDownTracker_green
    coolDownTracker_cache[coolDownTracker_blueKey] = coolDownTracker_blue
    return true
end

local function CoolDownTracker_GetAnchorAxisFactor(coolDownTracker_point, coolDownTracker_axis)
    local coolDownTracker_normalized = string.lower(Private.ToPlainString(coolDownTracker_point))
    if coolDownTracker_axis == "x" then
        if string.find(coolDownTracker_normalized, "right", 1, true) ~= nil then
            return 1
        end
        if string.find(coolDownTracker_normalized, "center", 1, true) ~= nil
            or coolDownTracker_normalized == "top"
            or coolDownTracker_normalized == "bottom" then
            return 0.5
        end
        return 0
    end

    if string.find(coolDownTracker_normalized, "bottom", 1, true) ~= nil then
        return 1
    end
    if string.find(coolDownTracker_normalized, "center", 1, true) ~= nil
        or coolDownTracker_normalized == "left"
        or coolDownTracker_normalized == "right" then
        return 0.5
    end
    return 0
end

local function CoolDownTracker_GetAnchorResizeOffsetDelta(
    coolDownTracker_delta,
    coolDownTracker_currentAnchorPoint,
    coolDownTracker_axis,
    coolDownTracker_preserveMaxEdge
)
    local coolDownTracker_factor = CoolDownTracker_GetAnchorAxisFactor(
        coolDownTracker_currentAnchorPoint,
        coolDownTracker_axis
    )
    if coolDownTracker_preserveMaxEdge == true then
        return -coolDownTracker_delta * (1 - coolDownTracker_factor)
    end

    return coolDownTracker_delta * coolDownTracker_factor
end

local function CoolDownTracker_AdjustAnchorWindowForResize(
    coolDownTracker_newWidth,
    coolDownTracker_newHeight,
    coolDownTracker_direction
)
    local coolDownTracker_oldWidth = tonumber(Addon._anchorWidth) or 0
    local coolDownTracker_oldHeight = tonumber(Addon._anchorHeight) or 0
    if coolDownTracker_oldWidth <= 0 and coolDownTracker_oldHeight <= 0 then
        Addon._anchorWidth = coolDownTracker_newWidth
        Addon._anchorHeight = coolDownTracker_newHeight
        return
    end

    if type(WindowGetAnchor) ~= "function"
        or type(WindowClearAnchors) ~= "function"
        or type(WindowAddAnchor) ~= "function"
        or not Private.DoesWindowExist(Addon.ANCHOR_WINDOW) then
        Addon._anchorWidth = coolDownTracker_newWidth
        Addon._anchorHeight = coolDownTracker_newHeight
        return
    end

    local coolDownTracker_ok, coolDownTracker_anchorPoint, coolDownTracker_relativePoint, coolDownTracker_relativeTo,
        coolDownTracker_xOffset, coolDownTracker_yOffset = pcall(WindowGetAnchor, Addon.ANCHOR_WINDOW, 1)
    if not coolDownTracker_ok
        or type(coolDownTracker_anchorPoint) ~= "string"
        or type(coolDownTracker_relativePoint) ~= "string"
        or type(coolDownTracker_relativeTo) ~= "string" then
        Addon._anchorWidth = coolDownTracker_newWidth
        Addon._anchorHeight = coolDownTracker_newHeight
        return
    end

    local coolDownTracker_deltaWidth = (tonumber(coolDownTracker_newWidth) or 0) - coolDownTracker_oldWidth
    local coolDownTracker_deltaHeight = (tonumber(coolDownTracker_newHeight) or 0) - coolDownTracker_oldHeight
    if coolDownTracker_deltaWidth == 0 and coolDownTracker_deltaHeight == 0 then
        Addon._anchorWidth = coolDownTracker_newWidth
        Addon._anchorHeight = coolDownTracker_newHeight
        return
    end

    pcall(WindowClearAnchors, Addon.ANCHOR_WINDOW)
    local coolDownTracker_preserveRightEdge = coolDownTracker_direction == "left"
    local coolDownTracker_preserveBottomEdge = coolDownTracker_direction == "up"
    pcall(
        WindowAddAnchor,
        Addon.ANCHOR_WINDOW,
        coolDownTracker_anchorPoint,
        coolDownTracker_relativeTo,
        coolDownTracker_relativePoint,
        (tonumber(coolDownTracker_xOffset) or 0)
            + CoolDownTracker_GetAnchorResizeOffsetDelta(
                coolDownTracker_deltaWidth,
                coolDownTracker_anchorPoint,
                "x",
                coolDownTracker_preserveRightEdge
            ),
        (tonumber(coolDownTracker_yOffset) or 0)
            + CoolDownTracker_GetAnchorResizeOffsetDelta(
                coolDownTracker_deltaHeight,
                coolDownTracker_anchorPoint,
                "y",
                coolDownTracker_preserveBottomEdge
            )
    )

    Addon._anchorWidth = coolDownTracker_newWidth
    Addon._anchorHeight = coolDownTracker_newHeight
end

local function CoolDownTracker_IsVerticalBuildDirection(coolDownTracker_direction)
    return coolDownTracker_direction == "up" or coolDownTracker_direction == "down"
end

local function CoolDownTracker_GetAnchorLayoutMetrics()
    local coolDownTracker_trackedCount = #Addon._states
    local coolDownTracker_scale, coolDownTracker_slotWidth, coolDownTracker_slotHeight, coolDownTracker_spacingX,
        coolDownTracker_spacingY = Private.GetScaledSlotMetrics()
    local coolDownTracker_direction = Private.GetBuildDirection()
    local coolDownTracker_gapCount = math.max(coolDownTracker_trackedCount - 1, 0)
    local coolDownTracker_anchorWidth = coolDownTracker_slotWidth
    local coolDownTracker_anchorHeight = Addon.HORIZONTAL_SLOT_OFFSET_Y + coolDownTracker_slotHeight

    if CoolDownTracker_IsVerticalBuildDirection(coolDownTracker_direction) then
        coolDownTracker_anchorHeight = Addon.SLOT_OFFSET_Y
            + coolDownTracker_slotHeight
            + (coolDownTracker_gapCount * coolDownTracker_spacingY)
        if coolDownTracker_direction == "up" then
            coolDownTracker_anchorHeight = coolDownTracker_anchorHeight
                + (Addon.ANCHOR_EXTRA_HEIGHT + 2)
                + Private.RoundToNearestInt((Addon.ANCHOR_EXTRA_HEIGHT + 2) * coolDownTracker_scale)
        end
    else
        coolDownTracker_anchorWidth = coolDownTracker_slotWidth
            + (coolDownTracker_gapCount * coolDownTracker_spacingX)
    end

    return coolDownTracker_direction,
        coolDownTracker_anchorWidth,
        coolDownTracker_anchorHeight
end

local function CoolDownTracker_ApplyAnchorHoverLayout(
    coolDownTracker_direction,
    coolDownTracker_anchorWidth,
    coolDownTracker_anchorHeight
)
    local coolDownTracker_hoverHeight = Addon.ANCHOR_EXTRA_HEIGHT + 2
    local coolDownTracker_hoverYOffset = 0
    if coolDownTracker_direction == "up" then
        coolDownTracker_hoverYOffset = math.max((tonumber(coolDownTracker_anchorHeight) or 0) - coolDownTracker_hoverHeight, 0)
    end

    if Private.DoesWindowExist(Addon.ANCHOR_HOVER_WINDOW)
        and type(WindowClearAnchors) == "function"
        and type(WindowAddAnchor) == "function" then
        if Addon._anchorHoverAnchorRelativeTo ~= Addon.ANCHOR_WINDOW
            or Addon._anchorHoverAnchorXOffset ~= 0
            or Addon._anchorHoverAnchorYOffset ~= coolDownTracker_hoverYOffset then
            pcall(WindowClearAnchors, Addon.ANCHOR_HOVER_WINDOW)
            pcall(
                WindowAddAnchor,
                Addon.ANCHOR_HOVER_WINDOW,
                "topleft",
                Addon.ANCHOR_WINDOW,
                "topleft",
                0,
                coolDownTracker_hoverYOffset
            )
            Addon._anchorHoverAnchorRelativeTo = Addon.ANCHOR_WINDOW
            Addon._anchorHoverAnchorXOffset = 0
            Addon._anchorHoverAnchorYOffset = coolDownTracker_hoverYOffset
        end
    end

    if Addon._anchorHoverWidth == coolDownTracker_anchorWidth
        and Addon._anchorHoverHeight == coolDownTracker_hoverHeight then
        return
    end

    if Private.DoesWindowExist(Addon.ANCHOR_HOVER_WINDOW) and type(WindowSetDimensions) == "function" then
        pcall(
            WindowSetDimensions,
            Addon.ANCHOR_HOVER_WINDOW,
            coolDownTracker_anchorWidth,
            coolDownTracker_hoverHeight
        )
    end
    if Private.DoesWindowExist(Addon.ANCHOR_HOVER_WINDOW .. "BG") and type(WindowSetDimensions) == "function" then
        pcall(
            WindowSetDimensions,
            Addon.ANCHOR_HOVER_WINDOW .. "BG",
            coolDownTracker_anchorWidth,
            coolDownTracker_hoverHeight
        )
    end
    if Private.DoesWindowExist(Addon.ANCHOR_HOVER_WINDOW .. "Label") and type(WindowSetDimensions) == "function" then
        pcall(
            WindowSetDimensions,
            Addon.ANCHOR_HOVER_WINDOW .. "Label",
            coolDownTracker_anchorWidth,
            coolDownTracker_hoverHeight
        )
    end

    Addon._anchorHoverWidth = coolDownTracker_anchorWidth
    Addon._anchorHoverHeight = coolDownTracker_hoverHeight
end

local function CoolDownTracker_GetSlotAnchorOffsets(
    coolDownTracker_index,
    coolDownTracker_count,
    coolDownTracker_direction,
    coolDownTracker_spacingX,
    coolDownTracker_spacingY
)
    if coolDownTracker_direction == "left" then
        return (coolDownTracker_count - coolDownTracker_index) * coolDownTracker_spacingX,
            Addon.HORIZONTAL_SLOT_OFFSET_Y
    end

    if coolDownTracker_direction == "down" then
        return 0, Addon.SLOT_OFFSET_Y + ((coolDownTracker_index - 1) * coolDownTracker_spacingY)
    end

    if coolDownTracker_direction == "up" then
        return 0, (coolDownTracker_count - coolDownTracker_index) * coolDownTracker_spacingY
    end

    return (coolDownTracker_index - 1) * coolDownTracker_spacingX,
        Addon.HORIZONTAL_SLOT_OFFSET_Y
end

function Private.RefreshAnchorHoverLabel()
    local coolDownTracker_labelText = Addon.ANCHOR_HOVER_LABEL_TEXT
    if Private.IsPositionLocked() then
        coolDownTracker_labelText = coolDownTracker_labelText
            .. " <icon"
            .. tostring(Addon.POSITION_LOCK_ICON_ID)
            .. ">"
    end

    Private.SetLabelText(Addon.ANCHOR_HOVER_WINDOW .. "Label", coolDownTracker_labelText)
end

function Private.ApplyAnchorMovableState()
    if type(WindowSetMovable) ~= "function" or not Private.DoesWindowExist(Addon.ANCHOR_WINDOW) then
        return
    end

    pcall(WindowSetMovable, Addon.ANCHOR_WINDOW, Private.IsPositionLocked() ~= true)
end

function Private.EnsureAnchorWindow()
    if Private.DoesWindowExist(Addon.ANCHOR_WINDOW) then
        if not Private.DoesWindowExist(Addon.ANCHOR_HOVER_WINDOW) and type(CreateWindow) == "function" then
            pcall(CreateWindow, Addon.ANCHOR_HOVER_WINDOW, false)
        end
        Private.TryRegisterLayoutEditorAnchor()
        Private.ApplyAnchorMovableState()
        return Private.DoesWindowExist(Addon.ANCHOR_HOVER_WINDOW)
    end

    if type(CreateWindow) == "function" then
        pcall(CreateWindow, Addon.ANCHOR_WINDOW, false)
        pcall(CreateWindow, Addon.ANCHOR_HOVER_WINDOW, false)
    end

    Private.TryRegisterLayoutEditorAnchor()
    Private.ApplyAnchorMovableState()
    return Private.DoesWindowExist(Addon.ANCHOR_WINDOW)
        and Private.DoesWindowExist(Addon.ANCHOR_HOVER_WINDOW)
end

function Private.TryRegisterLayoutEditorAnchor()
    if Addon._layoutEditorAnchorRegistered == true then
        return
    end
    if not Private.DoesWindowExist(Addon.ANCHOR_WINDOW) then
        return
    end
    local coolDownTracker_layoutEditor = _G and _G.LayoutEditor
    if type(coolDownTracker_layoutEditor) ~= "table"
        or type(coolDownTracker_layoutEditor.RegisterWindow) ~= "function" then
        return
    end

    local coolDownTracker_label = Private.ToWString("CoolDownTracker Anchor")
    local coolDownTracker_ok = pcall(
        coolDownTracker_layoutEditor.RegisterWindow,
        Addon.ANCHOR_WINDOW,
        coolDownTracker_label,
        coolDownTracker_label,
        true,
        true,
        true,
        nil
    )
    if coolDownTracker_ok then
        Addon._layoutEditorAnchorRegistered = true
    end
end

local function CoolDownTracker_GetWindowAlpha(coolDownTracker_windowName)
    if type(WindowGetAlpha) == "function" and Private.DoesWindowExist(coolDownTracker_windowName) then
        local coolDownTracker_ok, coolDownTracker_alpha = pcall(WindowGetAlpha, coolDownTracker_windowName)
        if coolDownTracker_ok and type(coolDownTracker_alpha) == "number" then
            return coolDownTracker_alpha
        end
    end

    return 1
end

function Private.FadeAnchorWidget(
    coolDownTracker_windowName,
    coolDownTracker_targetAlpha,
    coolDownTracker_duration,
    coolDownTracker_hideAfter
)
    if not Private.DoesWindowExist(coolDownTracker_windowName) then
        return
    end

    if type(WindowStopAlphaAnimation) == "function" then
        pcall(WindowStopAlphaAnimation, coolDownTracker_windowName)
    end

    if coolDownTracker_hideAfter ~= true then
        Private.SetWindowShowing(coolDownTracker_windowName, true)
    end

    if type(WindowStartAlphaAnimation) == "function"
        and type(Window) == "table"
        and type(Window.AnimationType) == "table" then
        local coolDownTracker_animationType = Window.AnimationType.SINGLE_NO_RESET
        if coolDownTracker_hideAfter == true and Window.AnimationType.SINGLE_NO_RESET_HIDE ~= nil then
            coolDownTracker_animationType = Window.AnimationType.SINGLE_NO_RESET_HIDE
        end
        local coolDownTracker_animationStarted = pcall(
            WindowStartAlphaAnimation,
            coolDownTracker_windowName,
            coolDownTracker_animationType,
            CoolDownTracker_GetWindowAlpha(coolDownTracker_windowName),
            coolDownTracker_targetAlpha,
            coolDownTracker_duration or 0,
            false,
            0,
            0
        )
        if coolDownTracker_animationStarted
            and (coolDownTracker_hideAfter ~= true
                or coolDownTracker_animationType == Window.AnimationType.SINGLE_NO_RESET_HIDE) then
            return
        end
    end

    Private.SetWindowAlpha(coolDownTracker_windowName, coolDownTracker_targetAlpha)
    if coolDownTracker_hideAfter == true and coolDownTracker_targetAlpha <= 0 then
        Private.SetWindowShowing(coolDownTracker_windowName, false)
    end
end

function Private.GetAnchorHoverHideDueAt()
    local coolDownTracker_dueAt = tonumber(Addon._anchorHoverHideAt)
    if coolDownTracker_dueAt ~= nil and coolDownTracker_dueAt >= 0 then
        return coolDownTracker_dueAt
    end

    return nil
end

function Private.CancelAnchorHoverHide(coolDownTracker_now)
    if (tonumber(Addon._anchorHoverHideAt) or -1) < 0 then
        return
    end

    Addon._anchorHoverHideAt = -1
    if type(Private.RefreshUpdateHandlerState) == "function" then
        Private.RefreshUpdateHandlerState(tonumber(coolDownTracker_now) or Private.GetNow())
    end
end

function Private.ScheduleAnchorHoverHide(coolDownTracker_now)
    if not Private.IsEnabled() then
        return
    end

    local coolDownTracker_currentTime = tonumber(coolDownTracker_now) or Private.GetNow()
    Addon._anchorHoverHideAt = coolDownTracker_currentTime + (tonumber(Addon.DRAG_HIDE_DELAY_SECONDS) or 1.0)
    if type(Private.RefreshUpdateHandlerState) == "function" then
        Private.RefreshUpdateHandlerState(coolDownTracker_currentTime)
    end
end

function Private.ProcessAnchorHoverHide(coolDownTracker_now)
    if not Private.IsDueAt(coolDownTracker_now, Addon._anchorHoverHideAt) then
        return false
    end

    Addon._anchorHoverHideAt = -1
    Addon._anchorDragActive = false
    Private.FadeAnchorWidget(
        Addon.ANCHOR_HOVER_WINDOW,
        0,
        Addon.DRAG_FADE_OUT_SECONDS,
        true
    )
    return true
end

function Private.ResizeAnchorWindow()
    local coolDownTracker_direction, coolDownTracker_anchorWidth, coolDownTracker_anchorHeight =
        CoolDownTracker_GetAnchorLayoutMetrics()
    local coolDownTracker_dimensionsChanged = coolDownTracker_anchorWidth ~= (tonumber(Addon._anchorWidth) or 0)
        or coolDownTracker_anchorHeight ~= (tonumber(Addon._anchorHeight) or 0)
    CoolDownTracker_AdjustAnchorWindowForResize(
        coolDownTracker_anchorWidth,
        coolDownTracker_anchorHeight,
        coolDownTracker_direction
    )
    CoolDownTracker_ApplyAnchorHoverLayout(
        coolDownTracker_direction,
        coolDownTracker_anchorWidth,
        coolDownTracker_anchorHeight
    )
    if coolDownTracker_dimensionsChanged ~= true then
        return
    end

    if type(WindowSetDimensions) == "function" and Private.DoesWindowExist(Addon.ANCHOR_WINDOW) then
        pcall(WindowSetDimensions, Addon.ANCHOR_WINDOW, coolDownTracker_anchorWidth, coolDownTracker_anchorHeight)
    end
end

function Private.HideAllWindows()
    Private.SetWindowShowing(Addon.ANCHOR_WINDOW, false)
    Private.SetWindowShowing(Addon.ANCHOR_HOVER_WINDOW, false)
    Private.SetWindowShowing(Addon.ANCHOR_HOVER_WINDOW .. "BG", false)
    Private.SetWindowShowing(Addon.ANCHOR_HOVER_WINDOW .. "Label", false)
    Private.SetWindowAlpha(Addon.ANCHOR_HOVER_WINDOW, 0)

    for _, coolDownTracker_state in ipairs(Addon._states or {}) do
        Private.SetWindowShowing(coolDownTracker_state.windowName, false)
        if type(coolDownTracker_state._appliedLayout) == "table" then
            coolDownTracker_state._appliedLayout.isShowing = false
        end
    end

    if type(Tooltips) == "table" and type(Tooltips.ClearTooltip) == "function" then
        Tooltips.ClearTooltip()
    end
end

function Private.EnsureWindows()
    if not Private.EnsureAnchorWindow() then
        return
    end

    if #(Addon._states or {}) <= 0 then
        Private.SetWindowShowing(Addon.ANCHOR_WINDOW, false)
        Private.SetWindowShowing(Addon.ANCHOR_HOVER_WINDOW, false)
        Private.SetWindowShowing(Addon.ANCHOR_HOVER_WINDOW .. "BG", false)
        Private.SetWindowShowing(Addon.ANCHOR_HOVER_WINDOW .. "Label", false)
        Private.SetWindowAlpha(Addon.ANCHOR_HOVER_WINDOW, 0)
        return
    end

    local coolDownTracker_scale, _, _, coolDownTracker_spacingX, coolDownTracker_spacingY =
        Private.GetScaledSlotMetrics()
    local coolDownTracker_direction = Private.GetBuildDirection()
    local coolDownTracker_stateCount = #(Addon._states or {})
    Private.SetWindowShowing(Addon.ANCHOR_WINDOW, true)
    Private.ApplyAnchorMovableState()
    Private.SetWindowShowing(Addon.ANCHOR_HOVER_WINDOW, false)
    Private.SetWindowShowing(Addon.ANCHOR_HOVER_WINDOW .. "BG", true)
    Private.SetWindowShowing(Addon.ANCHOR_HOVER_WINDOW .. "Label", true)
    Private.SetWindowAlpha(Addon.ANCHOR_HOVER_WINDOW, 0)
    Private.RefreshAnchorHoverLabel()
    Private.SetLabelColor(Addon.ANCHOR_HOVER_WINDOW .. "Label", 255, 255, 255)
    Private.ResizeAnchorWindow()

    for coolDownTracker_index, coolDownTracker_state in ipairs(Addon._states or {}) do
        local coolDownTracker_windowName = coolDownTracker_state.windowName
        local coolDownTracker_hadWindow = Private.DoesWindowExist(coolDownTracker_windowName)
        if not Private.DoesWindowExist(coolDownTracker_windowName) and type(CreateWindowFromTemplate) == "function" then
            pcall(CreateWindowFromTemplate, coolDownTracker_windowName, Addon.SLOT_TEMPLATE, "Root")
        end

        if Private.DoesWindowExist(coolDownTracker_windowName) then
            if coolDownTracker_hadWindow ~= true then
                coolDownTracker_state._appliedLayout = nil
                coolDownTracker_state._appliedLayoutWindowName = nil
                coolDownTracker_state._appliedVisual = nil
                coolDownTracker_state._appliedVisualWindowName = nil
            end

            local coolDownTracker_appliedLayout = CoolDownTracker_GetAppliedLayoutCache(coolDownTracker_state)
            local coolDownTracker_xOffset, coolDownTracker_yOffset = CoolDownTracker_GetSlotAnchorOffsets(
                coolDownTracker_index,
                coolDownTracker_stateCount,
                coolDownTracker_direction,
                coolDownTracker_spacingX,
                coolDownTracker_spacingY
            )
            if coolDownTracker_appliedLayout.windowId ~= coolDownTracker_state.windowId then
                CoolDownTracker_SetSlotWindowIds(coolDownTracker_state)
                coolDownTracker_appliedLayout.windowId = coolDownTracker_state.windowId
            end
            if type(WindowSetScale) == "function" then
                if coolDownTracker_appliedLayout.scale ~= coolDownTracker_scale then
                    pcall(WindowSetScale, coolDownTracker_windowName, coolDownTracker_scale)
                    coolDownTracker_appliedLayout.scale = coolDownTracker_scale
                end
            end

            if type(WindowClearAnchors) == "function" and type(WindowAddAnchor) == "function" then
                if coolDownTracker_appliedLayout.anchorPoint ~= "topleft"
                    or coolDownTracker_appliedLayout.anchorRelativeTo ~= Addon.ANCHOR_WINDOW
                    or coolDownTracker_appliedLayout.anchorRelativePoint ~= "topleft"
                    or coolDownTracker_appliedLayout.anchorXOffset ~= coolDownTracker_xOffset
                    or coolDownTracker_appliedLayout.anchorYOffset ~= coolDownTracker_yOffset then
                    pcall(WindowClearAnchors, coolDownTracker_windowName)
                    pcall(
                        WindowAddAnchor,
                        coolDownTracker_windowName,
                        "topleft",
                        Addon.ANCHOR_WINDOW,
                        "topleft",
                        coolDownTracker_xOffset,
                        coolDownTracker_yOffset
                    )
                    coolDownTracker_appliedLayout.anchorPoint = "topleft"
                    coolDownTracker_appliedLayout.anchorRelativeTo = Addon.ANCHOR_WINDOW
                    coolDownTracker_appliedLayout.anchorRelativePoint = "topleft"
                    coolDownTracker_appliedLayout.anchorXOffset = coolDownTracker_xOffset
                    coolDownTracker_appliedLayout.anchorYOffset = coolDownTracker_yOffset
                end
            end

            if coolDownTracker_appliedLayout.isShowing ~= true then
                Private.SetWindowShowing(coolDownTracker_windowName, true)
                coolDownTracker_appliedLayout.isShowing = true
            end
            if coolDownTracker_appliedLayout.iconId ~= coolDownTracker_state.tracked.iconId then
                Private.SetIconTextureFast(coolDownTracker_state.iconWindowName, coolDownTracker_state.tracked.iconId)
                coolDownTracker_appliedLayout.iconId = coolDownTracker_state.tracked.iconId
            end
        end
    end
end

local function CoolDownTracker_BuildVisualStateData(coolDownTracker_state, coolDownTracker_now)
    Private.RefreshDerivedActiveState(coolDownTracker_state, coolDownTracker_now)

    local coolDownTracker_remaining = Private.GetCooldownRemaining(coolDownTracker_state, coolDownTracker_now)
    local coolDownTracker_visual = CoolDownTracker_GetReusableVisualState(coolDownTracker_state)
    coolDownTracker_visual.timerText = ""
    coolDownTracker_visual.statusText = ""
    CoolDownTracker_SetColor(coolDownTracker_visual.timerColor, 255, 255, 255)
    CoolDownTracker_SetColor(coolDownTracker_visual.statusColor, 215, 215, 215)
    CoolDownTracker_SetColor(coolDownTracker_visual.iconTint, 255, 255, 255)
    CoolDownTracker_SetColor(coolDownTracker_visual.frameTint, 255, 255, 255)
    coolDownTracker_visual.slotAlpha = 1
    coolDownTracker_visual.timerAlpha = 1
    coolDownTracker_visual.timerBgAlpha = 1
    coolDownTracker_visual.statusAlpha = 1
    coolDownTracker_visual.statusBgAlpha = 1

    if coolDownTracker_state.isObservedActive then
        coolDownTracker_visual.timerText = Private.FormatRemainingSeconds(coolDownTracker_remaining)
        coolDownTracker_visual.statusText = "Active"
        CoolDownTracker_SetColor(coolDownTracker_visual.timerColor, 255, 232, 132)
        CoolDownTracker_SetColor(coolDownTracker_visual.statusColor, 215, 232, 132)
        CoolDownTracker_SetColor(coolDownTracker_visual.frameTint, 255, 232, 132)
    elseif coolDownTracker_remaining > 0 then
        coolDownTracker_visual.timerText = Private.FormatRemainingSeconds(coolDownTracker_remaining)
        coolDownTracker_visual.statusText = "Cooldown"
        CoolDownTracker_SetColor(coolDownTracker_visual.statusColor, 195, 195, 195)
        CoolDownTracker_SetColor(coolDownTracker_visual.iconTint, 175, 175, 175)
        CoolDownTracker_SetColor(coolDownTracker_visual.frameTint, 165, 165, 165)
        coolDownTracker_visual.slotAlpha = Addon.COOLDOWN_MUTED_ALPHA
    elseif coolDownTracker_state.hasEverTriggered then
        coolDownTracker_visual.statusText = "Ready"
        CoolDownTracker_SetColor(coolDownTracker_visual.statusColor, 120, 215, 160)
        CoolDownTracker_SetColor(coolDownTracker_visual.frameTint, 120, 255, 160)
    else
        coolDownTracker_visual.statusText = "Waiting"
        CoolDownTracker_SetColor(coolDownTracker_visual.statusColor, 200, 200, 200)
        coolDownTracker_visual.slotAlpha = 0.45
        CoolDownTracker_SetColor(coolDownTracker_visual.iconTint, 180, 180, 180)
    end

    return coolDownTracker_visual
end

function Private.ApplyVisualState(coolDownTracker_state, coolDownTracker_now)
    local coolDownTracker_windowName = coolDownTracker_state.windowName
    if not Private.DoesWindowExist(coolDownTracker_windowName) then
        return
    end

    local coolDownTracker_visual = CoolDownTracker_BuildVisualStateData(coolDownTracker_state, coolDownTracker_now)
    local coolDownTracker_applied = CoolDownTracker_GetAppliedVisualCache(coolDownTracker_state)

    if coolDownTracker_applied.timerText ~= coolDownTracker_visual.timerText then
        CoolDownTracker_SetShadowedLabel(
            coolDownTracker_state.timerBgWindowName,
            coolDownTracker_state.timerWindowName,
            coolDownTracker_visual.timerText
        )
        coolDownTracker_applied.timerText = coolDownTracker_visual.timerText
    end
    if coolDownTracker_applied.statusText ~= coolDownTracker_visual.statusText then
        CoolDownTracker_SetShadowedLabel(
            coolDownTracker_state.statusBgWindowName,
            coolDownTracker_state.statusWindowName,
            coolDownTracker_visual.statusText
        )
        coolDownTracker_applied.statusText = coolDownTracker_visual.statusText
    end

    if CoolDownTracker_DidCachedColorChange(coolDownTracker_applied, "timerColor", coolDownTracker_visual.timerColor) then
        Private.SetLabelColorFast(
            coolDownTracker_state.timerWindowName,
            coolDownTracker_visual.timerColor.red,
            coolDownTracker_visual.timerColor.green,
            coolDownTracker_visual.timerColor.blue
        )
    end
    if CoolDownTracker_DidCachedColorChange(
        coolDownTracker_applied,
        "statusColor",
        coolDownTracker_visual.statusColor
    ) then
        Private.SetLabelColorFast(
            coolDownTracker_state.statusWindowName,
            coolDownTracker_visual.statusColor.red,
            coolDownTracker_visual.statusColor.green,
            coolDownTracker_visual.statusColor.blue
        )
    end
    if CoolDownTracker_DidCachedColorChange(coolDownTracker_applied, "iconTint", coolDownTracker_visual.iconTint) then
        Private.SetWindowTintFast(
            coolDownTracker_state.iconWindowName,
            coolDownTracker_visual.iconTint.red,
            coolDownTracker_visual.iconTint.green,
            coolDownTracker_visual.iconTint.blue
        )
    end
    if CoolDownTracker_DidCachedColorChange(coolDownTracker_applied, "frameTint", coolDownTracker_visual.frameTint) then
        Private.SetWindowTintFast(
            coolDownTracker_state.frameWindowName,
            coolDownTracker_visual.frameTint.red,
            coolDownTracker_visual.frameTint.green,
            coolDownTracker_visual.frameTint.blue
        )
    end

    if coolDownTracker_applied.slotAlpha ~= coolDownTracker_visual.slotAlpha then
        Private.SetWindowAlphaFast(coolDownTracker_windowName, coolDownTracker_visual.slotAlpha)
        Private.SetWindowAlphaFast(coolDownTracker_state.iconWindowName, coolDownTracker_visual.slotAlpha)
        Private.SetWindowAlphaFast(coolDownTracker_state.frameWindowName, coolDownTracker_visual.slotAlpha)
        coolDownTracker_applied.slotAlpha = coolDownTracker_visual.slotAlpha
    end
    if coolDownTracker_applied.timerBgAlpha ~= coolDownTracker_visual.timerBgAlpha then
        Private.SetWindowAlphaFast(coolDownTracker_state.timerBgWindowName, coolDownTracker_visual.timerBgAlpha)
        coolDownTracker_applied.timerBgAlpha = coolDownTracker_visual.timerBgAlpha
    end
    if coolDownTracker_applied.timerAlpha ~= coolDownTracker_visual.timerAlpha then
        Private.SetWindowAlphaFast(coolDownTracker_state.timerWindowName, coolDownTracker_visual.timerAlpha)
        coolDownTracker_applied.timerAlpha = coolDownTracker_visual.timerAlpha
    end
    if coolDownTracker_applied.statusBgAlpha ~= coolDownTracker_visual.statusBgAlpha then
        Private.SetWindowAlphaFast(coolDownTracker_state.statusBgWindowName, coolDownTracker_visual.statusBgAlpha)
        coolDownTracker_applied.statusBgAlpha = coolDownTracker_visual.statusBgAlpha
    end
    if coolDownTracker_applied.statusAlpha ~= coolDownTracker_visual.statusAlpha then
        Private.SetWindowAlphaFast(coolDownTracker_state.statusWindowName, coolDownTracker_visual.statusAlpha)
        coolDownTracker_applied.statusAlpha = coolDownTracker_visual.statusAlpha
    end
end

function Addon.UpdateAllVisuals(coolDownTracker_now, coolDownTracker_forceAll)
    if not Private.IsEnabled() then
        return
    end

    local coolDownTracker_currentTime = tonumber(coolDownTracker_now) or Private.GetNow()
    local coolDownTracker_shouldForceAll = coolDownTracker_forceAll == true
    local coolDownTracker_hasDirtySessions = Private.HasDirtySessions() == true
    local coolDownTracker_isTimedWake = Private.IsDueAt(coolDownTracker_currentTime, Addon._nextTimedStateUpdateAt)

    local coolDownTracker_didCollapseReadyStates = false
    if coolDownTracker_hasDirtySessions == true or coolDownTracker_isTimedWake == true then
        if coolDownTracker_shouldForceAll == true
            or coolDownTracker_isTimedWake == true
            or Addon._dirtyAllSessions == true then
            coolDownTracker_didCollapseReadyStates = Private.CollapseReadyExtraStates(coolDownTracker_currentTime) == true
        else
            coolDownTracker_didCollapseReadyStates = Private.CollapseDirtyReadyExtraStates(
                coolDownTracker_currentTime
            ) == true
        end
    end

    if coolDownTracker_didCollapseReadyStates == true then
        Private.EnsureWindows()
        coolDownTracker_shouldForceAll = true
        coolDownTracker_hasDirtySessions = true
    end

    if coolDownTracker_shouldForceAll ~= true and coolDownTracker_hasDirtySessions ~= true then
        Private.RefreshUpdateHandlerState(coolDownTracker_currentTime)
        return
    end

    if coolDownTracker_shouldForceAll == true or Addon._dirtyAllSessions == true then
        for _, coolDownTracker_state in ipairs(Addon._states or {}) do
            Private.ApplyVisualState(coolDownTracker_state, coolDownTracker_currentTime)
        end
    else
        local coolDownTracker_statesBySessionKey = Addon._statesBySessionKey or {}
        Private.ForEachDirtySession(function(coolDownTracker_session)
            for _, coolDownTracker_state in ipairs(coolDownTracker_statesBySessionKey[coolDownTracker_session.key] or {}) do
                Private.ApplyVisualState(coolDownTracker_state, coolDownTracker_currentTime)
            end
        end)
    end

    Private.ClearDirtySessions()

    Private.RefreshUpdateHandlerState(coolDownTracker_currentTime)
end

local function CoolDownTracker_GetStateForActiveWindow()
    local coolDownTracker_activeWindowName = nil
    if type(SystemData) == "table" and type(SystemData.MouseOverWindow) == "table" then
        coolDownTracker_activeWindowName = SystemData.MouseOverWindow.name
    end
    if (type(coolDownTracker_activeWindowName) ~= "string" or coolDownTracker_activeWindowName == "")
        and type(SystemData) == "table"
        and type(SystemData.ActiveWindow) == "table" then
        coolDownTracker_activeWindowName = SystemData.ActiveWindow.name
    end

    while type(coolDownTracker_activeWindowName) == "string" and coolDownTracker_activeWindowName ~= "" do
        if type(WindowGetId) == "function" then
            local coolDownTracker_ok, coolDownTracker_windowId = pcall(WindowGetId, coolDownTracker_activeWindowName)
            if coolDownTracker_ok then
                local coolDownTracker_state = Addon._stateByWindowId[tonumber(coolDownTracker_windowId)]
                if coolDownTracker_state ~= nil then
                    return coolDownTracker_state
                end
            end
        end

        for _, coolDownTracker_state in ipairs(Addon._states or {}) do
            if coolDownTracker_state.windowName == coolDownTracker_activeWindowName then
                return coolDownTracker_state
            end
        end

        if type(WindowGetParent) ~= "function" then
            break
        end
        local coolDownTracker_ok, coolDownTracker_parent = pcall(WindowGetParent, coolDownTracker_activeWindowName)
        if not coolDownTracker_ok
            or type(coolDownTracker_parent) ~= "string"
            or coolDownTracker_parent == coolDownTracker_activeWindowName then
            break
        end
        coolDownTracker_activeWindowName = coolDownTracker_parent
    end

    return nil
end

function Addon.OnMouseOver()
    if not Private.IsEnabled() then
        return
    end

    local coolDownTracker_state = CoolDownTracker_GetStateForActiveWindow()
    if coolDownTracker_state == nil or type(Tooltips) ~= "table" then
        return
    end

    local coolDownTracker_now = Private.GetNow()
    Private.RefreshDerivedActiveState(coolDownTracker_state, coolDownTracker_now)

    local coolDownTracker_anchor = {
        Point = Addon.TOOLTIP_ANCHOR.Point,
        RelativeTo = coolDownTracker_state.windowName,
        RelativePoint = Addon.TOOLTIP_ANCHOR.RelativePoint,
        XOffset = Addon.TOOLTIP_ANCHOR.XOffset,
        YOffset = Addon.TOOLTIP_ANCHOR.YOffset,
    }
    local coolDownTracker_extraText = Private.BuildTooltipExtraText(coolDownTracker_state, coolDownTracker_now)

    local coolDownTracker_mouseOverWindowName = coolDownTracker_state.windowName
    if type(SystemData) == "table"
        and type(SystemData.MouseOverWindow) == "table"
        and type(SystemData.MouseOverWindow.name) == "string"
        and SystemData.MouseOverWindow.name ~= "" then
        coolDownTracker_mouseOverWindowName = SystemData.MouseOverWindow.name
    end

    if type(Tooltips.CreateTextOnlyTooltip) == "function" then
        Tooltips.CreateTextOnlyTooltip(coolDownTracker_mouseOverWindowName, nil)
        if type(Tooltips.SetTooltipText) == "function" then
            Tooltips.SetTooltipText(
                1,
                1,
                Private.ToWString(Private.GetStateDisplayName(coolDownTracker_state))
            )
        end
        if type(Tooltips.SetTooltipText) == "function" and coolDownTracker_extraText ~= nil then
            Tooltips.SetTooltipText(2, 1, coolDownTracker_extraText)
        end
        if type(Tooltips.Finalize) == "function" then
            Tooltips.Finalize()
        end
        if type(Tooltips.AnchorTooltip) == "function" then
            Tooltips.AnchorTooltip(
                (type(Tooltips.ANCHOR_WINDOW_TOP) == "table" and Tooltips.ANCHOR_WINDOW_TOP)
                    or coolDownTracker_anchor
            )
        end
    end
end

function Addon.OnMouseOverEnd()
    if type(Tooltips) == "table" and type(Tooltips.ClearTooltip) == "function" then
        Tooltips.ClearTooltip()
    end
end

function Addon.OnAnchorMouseOver()
    if not Private.IsEnabled() then
        return
    end

    Private.CancelAnchorHoverHide()
    Private.FadeAnchorWidget(
        Addon.ANCHOR_HOVER_WINDOW,
        Addon.DRAG_HOVER_TARGET_ALPHA,
        Addon.DRAG_FADE_IN_SECONDS,
        false
    )
end

function Addon.OnAnchorMouseOverEnd()
    if not Private.IsEnabled() then
        return
    end
    if Addon._anchorDragActive == true then
        return
    end

    Private.ScheduleAnchorHoverHide()
end

function Addon.OnAnchorDragStart()
    if not Private.IsEnabled() then
        return
    end
    if Private.IsPositionLocked() then
        Addon._anchorDragActive = false
        Addon.OnAnchorMouseOver()
        return
    end

    Addon._anchorDragActive = true
    Addon.OnAnchorMouseOver()
end

function Addon.OnAnchorDragEnd()
    if not Private.IsEnabled() then
        return
    end

    Addon._anchorDragActive = false
    Private.ScheduleAnchorHoverHide()
end

function Addon.TogglePositionLock()
    local coolDownTracker_isLocked = Private.SetPositionLocked(Private.IsPositionLocked() ~= true)
    Private.ApplyAnchorMovableState()
    Private.RefreshAnchorHoverLabel()
    Private.PrintChat("Position lock " .. (coolDownTracker_isLocked and "enabled." or "disabled."))
end

function Addon.RotateBuildDirection()
    local coolDownTracker_direction = Private.RotateBuildDirection()
    if Private.IsEnabled() then
        Private.EnsureWindows()
        Private.MarkAllSessionsDirty()
        Addon.UpdateAllVisuals(Private.GetNow(), true)
    end
    Private.PrintChat("Direction set to " .. coolDownTracker_direction .. ".")
end

function Addon.RotateSlotScale()
    local coolDownTracker_scale = Private.RotateSlotScale()
    if Private.IsEnabled() then
        Private.EnsureWindows()
        Private.MarkAllSessionsDirty()
        Addon.UpdateAllVisuals(Private.GetNow(), true)
    end
    Private.PrintChat("Scale set to " .. Private.FormatScaleText(coolDownTracker_scale) .. ".")
end

function Addon.OnAnchorRButtonUp()
    if not Private.IsEnabled() then
        return
    end

    local coolDownTracker_contextMenu = _G and _G.EA_Window_ContextMenu
    if type(coolDownTracker_contextMenu) ~= "table"
        or type(coolDownTracker_contextMenu.CreateContextMenu) ~= "function"
        or type(coolDownTracker_contextMenu.AddMenuItem) ~= "function"
        or type(coolDownTracker_contextMenu.Finalize) ~= "function" then
        Private.PrintChat("Use /cdt lock toggle, /cdt direction, /cdt scale, or /cdt hide.")
        return
    end

    local coolDownTracker_windowName = Addon.ANCHOR_WINDOW
    if type(SystemData) == "table"
        and type(SystemData.ActiveWindow) == "table"
        and type(SystemData.ActiveWindow.name) == "string"
        and SystemData.ActiveWindow.name ~= "" then
        coolDownTracker_windowName = SystemData.ActiveWindow.name
    end

    local coolDownTracker_menuNumber = coolDownTracker_contextMenu.CONTEXT_MENU_1 or 1
    local coolDownTracker_created = pcall(
        coolDownTracker_contextMenu.CreateContextMenu,
        coolDownTracker_windowName,
        coolDownTracker_menuNumber,
        Private.ToWString("CoolDownTracker")
    )
    if not coolDownTracker_created then
        return
    end

    local coolDownTracker_isLocked = Private.IsPositionLocked()
    local coolDownTracker_label = coolDownTracker_isLocked and "Unlock position" or "Lock position"
    local coolDownTracker_direction = Private.GetBuildDirection()
    local coolDownTracker_scale = Private.GetSlotScale()
    local coolDownTracker_directionLabel = "Rotate build direction ("
        .. coolDownTracker_direction
        .. " > "
        .. Private.GetNextBuildDirection(coolDownTracker_direction)
        .. ")"
    local coolDownTracker_scaleLabel = "Rotate scale ("
        .. Private.FormatScaleText(coolDownTracker_scale)
        .. " > "
        .. Private.FormatScaleText(Private.GetNextSlotScale(coolDownTracker_scale))
        .. ")"
    pcall(
        coolDownTracker_contextMenu.AddMenuItem,
        Private.ToWString(coolDownTracker_label),
        Addon.TogglePositionLock,
        false,
        true,
        coolDownTracker_menuNumber
    )
    pcall(
        coolDownTracker_contextMenu.AddMenuItem,
        Private.ToWString(coolDownTracker_directionLabel),
        Addon.RotateBuildDirection,
        coolDownTracker_isLocked,
        true,
        coolDownTracker_menuNumber
    )
    pcall(
        coolDownTracker_contextMenu.AddMenuItem,
        Private.ToWString(coolDownTracker_scaleLabel),
        Addon.RotateSlotScale,
        coolDownTracker_isLocked,
        true,
        coolDownTracker_menuNumber
    )
    pcall(
        coolDownTracker_contextMenu.AddMenuItem,
        Private.ToWString("Hide tracker"),
        Addon.HideTracker,
        coolDownTracker_isLocked,
        true,
        coolDownTracker_menuNumber
    )
    pcall(coolDownTracker_contextMenu.Finalize, coolDownTracker_menuNumber)
end
