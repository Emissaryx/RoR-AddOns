local Addon = CoolDownTracker
local Private = Addon.Private

function Private.GetSelfTargetType()
    if type(GameData) == "table" and type(GameData.BuffTargetType) == "table" then
        return tonumber(GameData.BuffTargetType.SELF)
    end

    return nil
end

local function CoolDownTracker_IsTrackedVisibleOnTarget(
    coolDownTracker_tracked,
    coolDownTracker_isSelfTarget,
    coolDownTracker_isGroupTarget
)
    return coolDownTracker_tracked ~= nil and (
        (coolDownTracker_isSelfTarget == true and Private.IsTrackedSelfObservationEnabled(coolDownTracker_tracked))
        or (coolDownTracker_isGroupTarget == true and Private.IsTrackedGroupObservationEnabled(coolDownTracker_tracked))
    )
end

function Private.GetGroupTargetRange()
    if type(GameData) ~= "table" or type(GameData.BuffTargetType) ~= "table" then
        return nil, nil
    end

    return tonumber(GameData.BuffTargetType.GROUP_MEMBER_START), tonumber(GameData.BuffTargetType.GROUP_MEMBER_END)
end

function Private.IsGroupTargetType(coolDownTracker_targetType)
    local coolDownTracker_startType, coolDownTracker_endType = Private.GetGroupTargetRange()
    return type(coolDownTracker_targetType) == "number"
        and type(coolDownTracker_startType) == "number"
        and type(coolDownTracker_endType) == "number"
        and coolDownTracker_targetType >= coolDownTracker_startType
        and coolDownTracker_targetType <= coolDownTracker_endType
end

function Private.GetTargetLabel(coolDownTracker_targetType)
    local coolDownTracker_selfType = Private.GetSelfTargetType()
    if coolDownTracker_selfType ~= nil and coolDownTracker_targetType == coolDownTracker_selfType then
        local coolDownTracker_playerName = Private.TrimGenderSuffix(
            type(GameData.Player) == "table" and GameData.Player.name or ""
        )
        if coolDownTracker_playerName ~= "" then
            return coolDownTracker_playerName
        end
        return "Self"
    end

    if Private.IsGroupTargetType(coolDownTracker_targetType) then
        local coolDownTracker_startType = tonumber(GameData.BuffTargetType.GROUP_MEMBER_START)
        local coolDownTracker_groupIndex = coolDownTracker_targetType - coolDownTracker_startType + 1
        if type(GroupWindow) == "table" and type(GroupWindow.groupData) == "table" then
            local coolDownTracker_member = GroupWindow.groupData[coolDownTracker_groupIndex]
            if type(coolDownTracker_member) == "table" then
                local coolDownTracker_memberName = Private.TrimGenderSuffix(coolDownTracker_member.name)
                if coolDownTracker_memberName ~= "" then
                    return coolDownTracker_memberName
                end
            end
        end

        return "Group " .. tostring(coolDownTracker_groupIndex)
    end

    return "Observed"
end

function Private.ResolveTrackedFromBuff(coolDownTracker_buffData)
    if type(coolDownTracker_buffData) ~= "table" then
        return nil
    end

    local coolDownTracker_tracked = Addon._scannableTrackedByAbilityId[tonumber(coolDownTracker_buffData.abilityId)]
    if coolDownTracker_tracked == false then
        return nil
    end

    return coolDownTracker_tracked
end

local function CoolDownTracker_DoesBuffMatchScannableObservedRequirement(coolDownTracker_buffData)
    if type(coolDownTracker_buffData) ~= "table" then
        return false
    end

    local coolDownTracker_abilityId = tonumber(coolDownTracker_buffData.abilityId)
    if coolDownTracker_abilityId ~= nil
        and Addon._requiredObservedAnyAbilityIdSet[coolDownTracker_abilityId] ~= nil then
        return true
    end

    return false
end

local function CoolDownTracker_ListContainsAbilityId(coolDownTracker_abilityIds, coolDownTracker_value)
    local coolDownTracker_abilityId = tonumber(coolDownTracker_value)
    if coolDownTracker_abilityId == nil or type(coolDownTracker_abilityIds) ~= "table" then
        return false
    end

    for _, coolDownTracker_candidate in ipairs(coolDownTracker_abilityIds) do
        if coolDownTracker_abilityId == tonumber(coolDownTracker_candidate) then
            return true
        end
    end

    return false
end

local function CoolDownTracker_AreRequiredObservedAnyAbilityIdsPresent(coolDownTracker_tracked, coolDownTracker_buffs)
    local coolDownTracker_requiredAbilityIds = coolDownTracker_tracked
        and coolDownTracker_tracked.requiredObservedAnyAbilityIds
        or nil
    if type(coolDownTracker_requiredAbilityIds) ~= "table" then
        return true
    end

    for _, coolDownTracker_buffData in pairs(coolDownTracker_buffs or {}) do
        if CoolDownTracker_ListContainsAbilityId(
            coolDownTracker_requiredAbilityIds,
            type(coolDownTracker_buffData) == "table" and coolDownTracker_buffData.abilityId or nil
        ) then
            return true
        end
    end

    return false
end

local function CoolDownTracker_DoesBuffMatchRequiredEffectText(coolDownTracker_tracked, coolDownTracker_buffData)
    local coolDownTracker_requiredText = Private.Trim(coolDownTracker_tracked
        and coolDownTracker_tracked.requiredEffectTextContains
        or nil)
    if coolDownTracker_requiredText == "" then
        return true
    end

    local coolDownTracker_effectText = coolDownTracker_buffData
        and coolDownTracker_buffData.effectText
        or nil
    local coolDownTracker_text = Private.ToPlainString(coolDownTracker_effectText)
    if coolDownTracker_text == "" then
        return false
    end

    return string.find(
        string.lower(coolDownTracker_text),
        string.lower(coolDownTracker_requiredText),
        1,
        true
    ) ~= nil
end

local function CoolDownTracker_HasObservedTarget(coolDownTracker_targetType)
    local coolDownTracker_numericTargetType = tonumber(coolDownTracker_targetType)
    if coolDownTracker_numericTargetType == nil then
        return false
    end

    for _, coolDownTracker_session in ipairs(Addon._sessions or {}) do
        if coolDownTracker_session.isObservedPresent == true
            and tonumber(coolDownTracker_session.lastObservedTargetType) == coolDownTracker_numericTargetType then
            return true
        end
    end

    return false
end

function Private.ShouldQueueObservedRefreshForEffectUpdate(
    coolDownTracker_targetType,
    coolDownTracker_updatedEffects,
    coolDownTracker_isFullList
)
    local coolDownTracker_scannableCount = tonumber(Addon._scannableStateCount) or 0
    local coolDownTracker_targetHasObservedState = CoolDownTracker_HasObservedTarget(coolDownTracker_targetType)
    if coolDownTracker_scannableCount <= 0 and coolDownTracker_targetHasObservedState ~= true then
        return false
    end

    if coolDownTracker_updatedEffects == nil then
        return true
    end
    if type(coolDownTracker_updatedEffects) ~= "table" then
        return true
    end
    if coolDownTracker_isFullList == true and next(coolDownTracker_updatedEffects) == nil then
        return true
    end

    for _, coolDownTracker_buffData in pairs(coolDownTracker_updatedEffects) do
        if type(coolDownTracker_buffData) ~= "table" then
            return true
        end
        if Private.ResolveTrackedFromBuff(coolDownTracker_buffData) ~= nil then
            return true
        end
        if CoolDownTracker_DoesBuffMatchScannableObservedRequirement(coolDownTracker_buffData) then
            return true
        end
        if coolDownTracker_isFullList ~= true
            and next(coolDownTracker_buffData) == nil
            and coolDownTracker_targetHasObservedState == true then
            return true
        end
    end

    if coolDownTracker_isFullList == true and coolDownTracker_targetHasObservedState == true then
        return true
    end

    return false
end

function Private.StartCooldown(
    coolDownTracker_state,
    coolDownTracker_sourceLabel,
    coolDownTracker_eventAt,
    coolDownTracker_isSynthetic,
    coolDownTracker_observedRemaining,
    coolDownTracker_observedAt
)
    local coolDownTracker_tracked = coolDownTracker_state and coolDownTracker_state.tracked or nil
    if coolDownTracker_tracked == nil then
        return
    end

    local coolDownTracker_cooldownSeconds = tonumber(coolDownTracker_tracked.cooldownSeconds) or 0
    local coolDownTracker_startAt = tonumber(coolDownTracker_eventAt)
    if coolDownTracker_startAt == nil then
        coolDownTracker_startAt = Private.GetNow()
    end

    if coolDownTracker_isSynthetic ~= true then
        local coolDownTracker_effectDuration = tonumber(coolDownTracker_tracked.effectDurationSeconds) or 0
        local coolDownTracker_seenAt = tonumber(coolDownTracker_observedAt)
        local coolDownTracker_remaining = tonumber(coolDownTracker_observedRemaining)
        if coolDownTracker_effectDuration > 0
            and coolDownTracker_seenAt ~= nil
            and coolDownTracker_remaining ~= nil
            and coolDownTracker_remaining > 0 then
            if coolDownTracker_remaining > coolDownTracker_effectDuration then
                coolDownTracker_remaining = coolDownTracker_effectDuration
            end

            -- Buff tables report time left on the active window, so recover the earliest
            -- plausible start without moving the cooldown later than the queued event time.
            local coolDownTracker_observedStartAt = coolDownTracker_seenAt
                - (coolDownTracker_effectDuration - coolDownTracker_remaining)
            if coolDownTracker_observedStartAt < coolDownTracker_startAt then
                coolDownTracker_startAt = coolDownTracker_observedStartAt
            end
        end
    end

    coolDownTracker_state.hasEverTriggered = true
    coolDownTracker_state.cooldownStartedAt = coolDownTracker_startAt
    coolDownTracker_state.cooldownEndsAt = coolDownTracker_startAt + coolDownTracker_cooldownSeconds
    coolDownTracker_state.lastTriggeredAt = coolDownTracker_startAt
    coolDownTracker_state.lastTriggeredBy = coolDownTracker_sourceLabel or coolDownTracker_state.lastTriggeredBy or ""
    coolDownTracker_state.lastTriggerWasSynthetic = coolDownTracker_isSynthetic == true
end

function Private.ScanBuffTable(coolDownTracker_targetType, coolDownTracker_observedMap, coolDownTracker_pendingCount)
    if coolDownTracker_pendingCount ~= nil and coolDownTracker_pendingCount <= 0 then
        return 0
    end

    if type(GetBuffs) ~= "function" then
        return coolDownTracker_pendingCount or 0
    end

    local coolDownTracker_selfType = Private.GetSelfTargetType()
    local coolDownTracker_isSelfTarget = coolDownTracker_selfType ~= nil
        and coolDownTracker_targetType == coolDownTracker_selfType
    local coolDownTracker_isGroupTarget = coolDownTracker_isSelfTarget ~= true
        and Private.IsGroupTargetType(coolDownTracker_targetType)
    if coolDownTracker_isSelfTarget ~= true and coolDownTracker_isGroupTarget ~= true then
        return coolDownTracker_pendingCount or 0
    end

    local coolDownTracker_ok, coolDownTracker_buffs = pcall(GetBuffs, coolDownTracker_targetType)
    if not coolDownTracker_ok or type(coolDownTracker_buffs) ~= "table" then
        return coolDownTracker_pendingCount or 0
    end

    local coolDownTracker_targetLabel = nil
    for _, coolDownTracker_buffData in pairs(coolDownTracker_buffs) do
        local coolDownTracker_tracked = Private.ResolveTrackedFromBuff(coolDownTracker_buffData)
        if CoolDownTracker_IsTrackedVisibleOnTarget(
            coolDownTracker_tracked,
            coolDownTracker_isSelfTarget,
            coolDownTracker_isGroupTarget
        ) and CoolDownTracker_AreRequiredObservedAnyAbilityIdsPresent(
            coolDownTracker_tracked,
            coolDownTracker_buffs
        ) and CoolDownTracker_DoesBuffMatchRequiredEffectText(
            coolDownTracker_tracked,
            coolDownTracker_buffData
        ) then
            local coolDownTracker_key = coolDownTracker_tracked.key
            local coolDownTracker_observation = coolDownTracker_observedMap[coolDownTracker_key]
            if type(coolDownTracker_observation) == "table" and coolDownTracker_observation.isPresent ~= true then
                coolDownTracker_observation.isPresent = true
                if coolDownTracker_targetLabel == nil then
                    coolDownTracker_targetLabel = Private.GetTargetLabel(coolDownTracker_targetType)
                end
                coolDownTracker_observation.sourceLabel = coolDownTracker_targetLabel
                coolDownTracker_observation.sourceTargetType = coolDownTracker_targetType
                coolDownTracker_observation.matchedBuff = coolDownTracker_buffData
                if coolDownTracker_pendingCount ~= nil and coolDownTracker_pendingCount > 0 then
                    coolDownTracker_pendingCount = coolDownTracker_pendingCount - 1
                    if coolDownTracker_pendingCount <= 0 then
                        break
                    end
                end
            end
        end
    end

    return coolDownTracker_pendingCount or 0
end

local function CoolDownTracker_RefreshObservedEffectsInternal(coolDownTracker_requestedAt, coolDownTracker_scanAt)
    if not Private.IsEnabled() then
        return false
    end

    local coolDownTracker_observedMap = {}
    local coolDownTracker_now = tonumber(coolDownTracker_scanAt) or Private.GetNow()
    local coolDownTracker_refreshAt = tonumber(coolDownTracker_requestedAt) or coolDownTracker_now
    local coolDownTracker_pendingCount = tonumber(Addon._scannableStateCount) or 0
    local coolDownTracker_layoutChanged = false
    local coolDownTracker_didVisualStateChange = false

    for _, coolDownTracker_session in ipairs(Addon._sessions or {}) do
        coolDownTracker_observedMap[coolDownTracker_session.key] = {
            isPresent = false,
            sourceLabel = "",
            sourceTargetType = nil,
            matchedBuff = nil,
        }
    end

    local coolDownTracker_selfType = Private.GetSelfTargetType()
    if coolDownTracker_pendingCount > 0 and Addon._observesSelf == true and coolDownTracker_selfType ~= nil then
        coolDownTracker_pendingCount = Private.ScanBuffTable(
            coolDownTracker_selfType,
            coolDownTracker_observedMap,
            coolDownTracker_pendingCount
        )
    end

    local coolDownTracker_startType, coolDownTracker_endType = nil, nil
    if coolDownTracker_pendingCount > 0 and Addon._observesGroup == true then
        coolDownTracker_startType, coolDownTracker_endType = Private.GetGroupTargetRange()
    end
    if coolDownTracker_pendingCount > 0 and coolDownTracker_startType ~= nil and coolDownTracker_endType ~= nil then
        for coolDownTracker_targetType = coolDownTracker_startType, coolDownTracker_endType do
            coolDownTracker_pendingCount = Private.ScanBuffTable(
                coolDownTracker_targetType,
                coolDownTracker_observedMap,
                coolDownTracker_pendingCount
            )
            if coolDownTracker_pendingCount <= 0 then
                break
            end
        end
    end

    for _, coolDownTracker_session in ipairs(Addon._sessions or {}) do
        local coolDownTracker_observation = coolDownTracker_observedMap[coolDownTracker_session.key] or {}
        local coolDownTracker_isPresent = coolDownTracker_observation.isPresent == true
        local coolDownTracker_matchedBuff = coolDownTracker_observation.matchedBuff
        local coolDownTracker_observedRemaining = tonumber(
            coolDownTracker_matchedBuff and coolDownTracker_matchedBuff.duration
        ) or 0

        if coolDownTracker_isPresent then
            local coolDownTracker_shouldStart = coolDownTracker_session.isObservedPresent ~= true
            if coolDownTracker_shouldStart ~= true then
                coolDownTracker_shouldStart = Private.ShouldInferAdditionalSharedTrigger(
                    coolDownTracker_session,
                    coolDownTracker_observedRemaining,
                    coolDownTracker_refreshAt
                )
            end

            if coolDownTracker_shouldStart == true then
                local coolDownTracker_state, coolDownTracker_stateLayoutChanged = Private.AcquireSessionState(
                    coolDownTracker_session,
                    coolDownTracker_now,
                    false,
                    true
                )
                if coolDownTracker_state ~= nil then
                    coolDownTracker_layoutChanged = coolDownTracker_layoutChanged or coolDownTracker_stateLayoutChanged
                    Private.StartCooldown(
                        coolDownTracker_state,
                        coolDownTracker_observation.sourceLabel,
                        coolDownTracker_refreshAt,
                        false,
                        coolDownTracker_observedRemaining,
                        coolDownTracker_now
                    )
                    coolDownTracker_session.activeState = coolDownTracker_state
                    Private.MarkSessionDirty(coolDownTracker_session)
                    coolDownTracker_didVisualStateChange = true
                end
            end
        end

        if Private.ApplySessionObservedState(
            coolDownTracker_session,
            coolDownTracker_isPresent,
            coolDownTracker_observedRemaining,
            coolDownTracker_now,
            coolDownTracker_observation.sourceTargetType
        ) == true then
            Private.MarkSessionDirty(coolDownTracker_session)
            coolDownTracker_didVisualStateChange = true
        end
    end

    if coolDownTracker_layoutChanged == true then
        Private.MarkAllSessionsDirty()
        Private.EnsureWindows()
        coolDownTracker_didVisualStateChange = true
    end

    return coolDownTracker_didVisualStateChange == true
end

function Private.RequestObservedRefresh(coolDownTracker_allowWithoutScannable)
    if (tonumber(Addon._scannableStateCount) or 0) <= 0
        and coolDownTracker_allowWithoutScannable ~= true then
        return false
    end

    local coolDownTracker_now = Private.GetNow()
    local coolDownTracker_wasPending = Addon._pendingObservedRefresh == true
    local coolDownTracker_nextUpdateAt = tonumber(Addon._nextUpdateAt) or -1
    local coolDownTracker_hasDueTimedWake = Private.IsDueAt(coolDownTracker_now, Addon._nextCountdownUpdateAt)
        or Private.IsDueAt(coolDownTracker_now, Addon._nextTimedStateUpdateAt)
    local coolDownTracker_shouldPreserveDueTimedWake = coolDownTracker_hasDueTimedWake == true
        and Addon._updateHandlerRegistered == true
        and coolDownTracker_nextUpdateAt >= 0
    Addon._pendingObservedRefresh = true
    if Addon._pendingObservedRefreshRequestedAt < 0 then
        Addon._pendingObservedRefreshRequestedAt = coolDownTracker_now
    end
    if coolDownTracker_shouldPreserveDueTimedWake == true then
        -- Keep the already-due visual wake alive; recomputing from a later event time can skip the final paint.
        if coolDownTracker_nextUpdateAt > coolDownTracker_now then
            Addon._nextUpdateAt = coolDownTracker_now
        end
    elseif coolDownTracker_wasPending ~= true
        or Addon._updateHandlerRegistered ~= true
        or coolDownTracker_nextUpdateAt < 0 then
        -- Recompute due caches from the current uptime, not the oldest queued event time.
        Private.RefreshUpdateHandlerState(coolDownTracker_now)
    elseif coolDownTracker_hasDueTimedWake == true then
        -- If a supporting due cache has already gone stale, refresh it before the next update callback.
        Private.RefreshUpdateHandlerState(coolDownTracker_now)
    end

    return true
end

function Private.GetPendingObservedRefreshDueAt(coolDownTracker_now)
    if Addon._pendingObservedRefresh ~= true or not Private.IsEnabled() then
        return nil
    end

    local coolDownTracker_requestedAt = tonumber(Addon._pendingObservedRefreshRequestedAt)
    if coolDownTracker_requestedAt == nil or coolDownTracker_requestedAt < 0 then
        coolDownTracker_requestedAt = tonumber(coolDownTracker_now) or Private.GetNow()
    end

    local coolDownTracker_dueAt = coolDownTracker_requestedAt + (tonumber(Addon.OBSERVED_REFRESH_DELAY) or 0)
    local coolDownTracker_lastRefreshAt = tonumber(Addon._lastObservedRefreshAt) or -1
    if coolDownTracker_lastRefreshAt >= 0 then
        local coolDownTracker_minDueAt = coolDownTracker_lastRefreshAt
            + (tonumber(Addon.OBSERVED_REFRESH_MIN_INTERVAL) or 0)
        if coolDownTracker_minDueAt > coolDownTracker_dueAt then
            coolDownTracker_dueAt = coolDownTracker_minDueAt
        end
    end

    return coolDownTracker_dueAt
end

function Private.ProcessPendingObservedRefresh(coolDownTracker_now)
    if Addon._pendingObservedRefresh ~= true or not Private.IsEnabled() then
        return false
    end

    local coolDownTracker_currentTime = tonumber(coolDownTracker_now) or Private.GetNow()
    local coolDownTracker_dueAt = Private.GetPendingObservedRefreshDueAt(coolDownTracker_currentTime)
    if coolDownTracker_dueAt ~= nil and coolDownTracker_currentTime < coolDownTracker_dueAt then
        return false
    end

    local coolDownTracker_requestedAt = tonumber(Addon._pendingObservedRefreshRequestedAt) or -1
    if coolDownTracker_requestedAt < 0 or coolDownTracker_requestedAt > coolDownTracker_currentTime then
        coolDownTracker_requestedAt = coolDownTracker_currentTime
    end

    Addon._pendingObservedRefresh = false
    Addon._pendingObservedRefreshRequestedAt = -1
    Addon._lastObservedRefreshAt = coolDownTracker_currentTime
    CoolDownTracker_RefreshObservedEffectsInternal(coolDownTracker_requestedAt, coolDownTracker_currentTime)
    return true
end

function Addon.RefreshObservedEffects()
    local coolDownTracker_now = Private.GetNow()
    Addon._pendingObservedRefresh = false
    Addon._pendingObservedRefreshRequestedAt = -1
    local coolDownTracker_didRefresh = CoolDownTracker_RefreshObservedEffectsInternal(
        coolDownTracker_now,
        coolDownTracker_now
    )
    Addon.UpdateAllVisuals(coolDownTracker_now, true)
    return coolDownTracker_didRefresh
end

function Private.ResetTransientObservedState()
    Private.ClearDirtySessions()
    for _, coolDownTracker_session in ipairs(Addon._sessions or {}) do
        coolDownTracker_session.isObservedPresent = false
        coolDownTracker_session.lastObservedRemaining = 0
        coolDownTracker_session.lastObservedAt = 0
        coolDownTracker_session.lastObservedTargetType = nil
        coolDownTracker_session.activeState = nil
        for _, coolDownTracker_state in ipairs(coolDownTracker_session.instances or {}) do
            coolDownTracker_state.isLiveObservedActive = false
            coolDownTracker_state.isObservedActive = false
            coolDownTracker_state.mockActiveUntil = 0
        end
    end
    Addon._lastObservedRefreshAt = -1
end
