local Addon = CoolDownTracker
local Private = Addon.Private

local CoolDownTracker_SLOT_SCALE_ROTATION = {
    0.25,
    0.50,
    0.75,
    1.00,
    1.25,
    1.50,
    2.00,
}

function Private.ToWString(coolDownTracker_value)
    if type(towstring) == "function" then
        return towstring(coolDownTracker_value or "")
    end

    return coolDownTracker_value or ""
end

function Private.ToPlainString(coolDownTracker_value)
    if coolDownTracker_value == nil then
        return ""
    end

    if type(coolDownTracker_value) == "string" then
        return coolDownTracker_value
    end

    if type(WStringToString) == "function" then
        local coolDownTracker_ok, coolDownTracker_text = pcall(WStringToString, coolDownTracker_value)
        if coolDownTracker_ok and type(coolDownTracker_text) == "string" then
            return coolDownTracker_text
        end
    end

    local coolDownTracker_ok, coolDownTracker_text = pcall(tostring, coolDownTracker_value)
    if coolDownTracker_ok and type(coolDownTracker_text) == "string" then
        return coolDownTracker_text
    end

    return ""
end

function Private.Trim(coolDownTracker_text)
    local coolDownTracker_plain = Private.ToPlainString(coolDownTracker_text)
    coolDownTracker_plain = string.gsub(coolDownTracker_plain, "^%s+", "")
    coolDownTracker_plain = string.gsub(coolDownTracker_plain, "%s+$", "")
    return coolDownTracker_plain
end

function Private.NormalizeIdentifier(coolDownTracker_text)
    return string.lower(Private.Trim(coolDownTracker_text))
end

function Private.TrimGenderSuffix(coolDownTracker_text)
    local coolDownTracker_plain = Private.ToPlainString(coolDownTracker_text)
    if coolDownTracker_plain == "" then
        return ""
    end

    local coolDownTracker_trimmed = string.match(coolDownTracker_plain, "([^%^]+)")
    return coolDownTracker_trimmed or coolDownTracker_plain
end

function Private.GetNow()
    if type(GetGameTime) == "function" then
        local coolDownTracker_ok, coolDownTracker_value = pcall(GetGameTime)
        if coolDownTracker_ok and type(coolDownTracker_value) == "number" then
            return coolDownTracker_value
        end
    end

    return 0
end

function Private.GetEarlierDueAt(coolDownTracker_current, coolDownTracker_candidate)
    local coolDownTracker_currentTime = tonumber(coolDownTracker_current)
    local coolDownTracker_candidateTime = tonumber(coolDownTracker_candidate)
    if coolDownTracker_candidateTime == nil or coolDownTracker_candidateTime < 0 then
        return coolDownTracker_currentTime
    end
    if coolDownTracker_currentTime == nil or coolDownTracker_currentTime < 0 then
        return coolDownTracker_candidateTime
    end
    if coolDownTracker_candidateTime < coolDownTracker_currentTime then
        return coolDownTracker_candidateTime
    end
    return coolDownTracker_currentTime
end

function Private.DoesWindowExist(coolDownTracker_windowName)
    if type(DoesWindowExist) ~= "function" then
        return false
    end

    local coolDownTracker_ok, coolDownTracker_exists = pcall(DoesWindowExist, coolDownTracker_windowName)
    return coolDownTracker_ok and coolDownTracker_exists == true
end

function Private.SetWindowShowing(coolDownTracker_windowName, coolDownTracker_isShowing)
    if type(WindowSetShowing) == "function" and Private.DoesWindowExist(coolDownTracker_windowName) then
        pcall(WindowSetShowing, coolDownTracker_windowName, not not coolDownTracker_isShowing)
    end
end

function Private.SetWindowAlpha(coolDownTracker_windowName, coolDownTracker_alpha)
    if type(WindowSetAlpha) == "function" and Private.DoesWindowExist(coolDownTracker_windowName) then
        pcall(WindowSetAlpha, coolDownTracker_windowName, coolDownTracker_alpha)
    end
end

function Private.SetWindowAlphaFast(coolDownTracker_windowName, coolDownTracker_alpha)
    if type(WindowSetAlpha) == "function" then
        pcall(WindowSetAlpha, coolDownTracker_windowName, coolDownTracker_alpha)
    end
end

function Private.SetWindowTintFast(
    coolDownTracker_windowName,
    coolDownTracker_red,
    coolDownTracker_green,
    coolDownTracker_blue
)
    if type(WindowSetTintColor) == "function" then
        pcall(
            WindowSetTintColor,
            coolDownTracker_windowName,
            coolDownTracker_red,
            coolDownTracker_green,
            coolDownTracker_blue
        )
    end
end

function Private.SetLabelText(coolDownTracker_windowName, coolDownTracker_text)
    if type(LabelSetText) == "function" and Private.DoesWindowExist(coolDownTracker_windowName) then
        pcall(LabelSetText, coolDownTracker_windowName, Private.ToWString(coolDownTracker_text or ""))
    end
end

function Private.SetLabelTextFast(coolDownTracker_windowName, coolDownTracker_text)
    if type(LabelSetText) == "function" then
        pcall(LabelSetText, coolDownTracker_windowName, Private.ToWString(coolDownTracker_text or ""))
    end
end

function Private.SetLabelColor(
    coolDownTracker_windowName,
    coolDownTracker_red,
    coolDownTracker_green,
    coolDownTracker_blue
)
    if type(LabelSetTextColor) == "function" and Private.DoesWindowExist(coolDownTracker_windowName) then
        pcall(
            LabelSetTextColor,
            coolDownTracker_windowName,
            coolDownTracker_red,
            coolDownTracker_green,
            coolDownTracker_blue
        )
    end
end

function Private.SetLabelColorFast(
    coolDownTracker_windowName,
    coolDownTracker_red,
    coolDownTracker_green,
    coolDownTracker_blue
)
    if type(LabelSetTextColor) == "function" then
        pcall(
            LabelSetTextColor,
            coolDownTracker_windowName,
            coolDownTracker_red,
            coolDownTracker_green,
            coolDownTracker_blue
        )
    end
end

function Private.PrintChat(coolDownTracker_message)
    local function coolDownTracker_link(coolDownTracker_text, coolDownTracker_color)
        return "<LINK data=\"\" text=\""
            .. Private.ToPlainString(coolDownTracker_text)
            .. "\" color=\""
            .. Private.ToPlainString(coolDownTracker_color)
            .. "\">"
    end

    local coolDownTracker_prefix = coolDownTracker_link("[CoolDownTracker]:", Addon.CHAT_PREFIX_COLOR) .. " "
    local coolDownTracker_line = Private.ToWString(coolDownTracker_prefix .. Private.Trim(coolDownTracker_message))
    if type(EA_ChatWindow) == "table" and type(EA_ChatWindow.Print) == "function" then
        EA_ChatWindow.Print(coolDownTracker_line)
    elseif type(TextLogAddEntry) == "function" then
        TextLogAddEntry("Chat", 0, coolDownTracker_line)
    end
end

function Private.ResolveIconTexture(coolDownTracker_iconId)
    local coolDownTracker_iconNumber = tonumber(coolDownTracker_iconId) or 0
    if coolDownTracker_iconNumber <= 0 or type(GetIconData) ~= "function" then
        return nil, 0, 0
    end

    local coolDownTracker_ok, coolDownTracker_texture, coolDownTracker_x, coolDownTracker_y = pcall(
        GetIconData,
        coolDownTracker_iconNumber
    )
    if not coolDownTracker_ok or type(coolDownTracker_texture) ~= "string" then
        return nil, 0, 0
    end

    return coolDownTracker_texture, coolDownTracker_x or 0, coolDownTracker_y or 0
end

function Private.SetIconTextureFast(coolDownTracker_windowName, coolDownTracker_iconId)
    if type(DynamicImageSetTexture) ~= "function" then
        return
    end

    local coolDownTracker_texture, coolDownTracker_x, coolDownTracker_y = Private.ResolveIconTexture(
        coolDownTracker_iconId
    )
    if coolDownTracker_texture == nil then
        pcall(DynamicImageSetTexture, coolDownTracker_windowName, "", 0, 0)
        return
    end

    pcall(
        DynamicImageSetTexture,
        coolDownTracker_windowName,
        coolDownTracker_texture,
        coolDownTracker_x,
        coolDownTracker_y
    )
end

function Private.FormatRemainingSeconds(coolDownTracker_seconds)
    local coolDownTracker_remaining = math.max(tonumber(coolDownTracker_seconds) or 0, 0)
    return tostring(math.ceil(coolDownTracker_remaining))
end

function Private.RoundToNearestInt(coolDownTracker_value)
    return math.floor((tonumber(coolDownTracker_value) or 0) + 0.5)
end

function Private.ClampSlotScale(coolDownTracker_value)
    local coolDownTracker_scale = tonumber(coolDownTracker_value) or Addon.DEFAULT_SLOT_SCALE
    if coolDownTracker_scale < Addon.MIN_SLOT_SCALE then
        coolDownTracker_scale = Addon.MIN_SLOT_SCALE
    elseif coolDownTracker_scale > Addon.MAX_SLOT_SCALE then
        coolDownTracker_scale = Addon.MAX_SLOT_SCALE
    end
    return coolDownTracker_scale
end

function Private.GetSlotScale()
    return Private.ClampSlotScale(CoolDownTracker_Saved.slotScale)
end

function Private.SetSlotScale(coolDownTracker_value)
    local coolDownTracker_scale = Private.ClampSlotScale(coolDownTracker_value)
    CoolDownTracker_Saved.slotScale = coolDownTracker_scale
    return coolDownTracker_scale
end

function Private.GetNextSlotScale(coolDownTracker_currentScale)
    coolDownTracker_currentScale = Private.ClampSlotScale(coolDownTracker_currentScale)
    for _, coolDownTracker_scale in ipairs(CoolDownTracker_SLOT_SCALE_ROTATION) do
        if coolDownTracker_scale > coolDownTracker_currentScale + 0.001 then
            return coolDownTracker_scale
        end
    end

    return CoolDownTracker_SLOT_SCALE_ROTATION[1]
end

function Private.RotateSlotScale()
    return Private.SetSlotScale(Private.GetNextSlotScale(Private.GetSlotScale()))
end

function Private.ParseScaleValue(coolDownTracker_text)
    local coolDownTracker_trimmed = Private.Trim(coolDownTracker_text)
    if coolDownTracker_trimmed == "" then
        return nil
    end

    local coolDownTracker_percent = false
    if string.sub(coolDownTracker_trimmed, -1) == "%" then
        coolDownTracker_percent = true
        coolDownTracker_trimmed = string.sub(coolDownTracker_trimmed, 1, -2)
    end

    local coolDownTracker_numeric = tonumber(coolDownTracker_trimmed)
    if coolDownTracker_numeric == nil or coolDownTracker_numeric <= 0 then
        return nil
    end

    if coolDownTracker_percent or coolDownTracker_numeric > 5 then
        coolDownTracker_numeric = coolDownTracker_numeric / 100
    end

    return Private.ClampSlotScale(coolDownTracker_numeric)
end

function Private.FormatScaleText(coolDownTracker_scale)
    return tostring(Private.RoundToNearestInt((tonumber(coolDownTracker_scale) or 0) * 100)) .. "%"
end

function Private.NormalizeBuildDirection(coolDownTracker_text)
    local coolDownTracker_direction = Private.NormalizeIdentifier(coolDownTracker_text)
    if coolDownTracker_direction == "right" or coolDownTracker_direction == "r" then
        return "right"
    end
    if coolDownTracker_direction == "left" or coolDownTracker_direction == "l" then
        return "left"
    end
    if coolDownTracker_direction == "up"
        or coolDownTracker_direction == "u"
        or coolDownTracker_direction == "top" then
        return "up"
    end
    if coolDownTracker_direction == "down"
        or coolDownTracker_direction == "d"
        or coolDownTracker_direction == "bottom" then
        return "down"
    end

    return nil
end

function Private.GetBuildDirection()
    return Private.NormalizeBuildDirection(CoolDownTracker_Saved.buildDirection)
        or Addon.DEFAULT_BUILD_DIRECTION
end

function Private.SetBuildDirection(coolDownTracker_direction)
    local coolDownTracker_normalized = Private.NormalizeBuildDirection(coolDownTracker_direction)
        or Addon.DEFAULT_BUILD_DIRECTION
    CoolDownTracker_Saved.buildDirection = coolDownTracker_normalized
    return coolDownTracker_normalized
end

function Private.GetNextBuildDirection(coolDownTracker_direction)
    coolDownTracker_direction = Private.NormalizeBuildDirection(coolDownTracker_direction)
        or Addon.DEFAULT_BUILD_DIRECTION
    if coolDownTracker_direction == "right" then
        return "down"
    end
    if coolDownTracker_direction == "down" then
        return "left"
    end
    if coolDownTracker_direction == "left" then
        return "up"
    end

    return "right"
end

function Private.RotateBuildDirection()
    return Private.SetBuildDirection(Private.GetNextBuildDirection(Private.GetBuildDirection()))
end

function Private.IsEnabled()
    return CoolDownTracker_Saved.isHidden ~= true
end

function Private.SetHidden(coolDownTracker_isHidden)
    CoolDownTracker_Saved.isHidden = coolDownTracker_isHidden == true
end

function Private.IsPositionLocked()
    return CoolDownTracker_Saved.positionLocked == true
end

function Private.SetPositionLocked(coolDownTracker_isLocked)
    CoolDownTracker_Saved.positionLocked = coolDownTracker_isLocked == true
    return CoolDownTracker_Saved.positionLocked == true
end

function Private.IsSelfOnlyModeEnabled()
    return CoolDownTracker_Saved.selfOnlyMode ~= false
end

function Private.SetSelfOnlyModeEnabled(coolDownTracker_enabled)
    CoolDownTracker_Saved.selfOnlyMode = coolDownTracker_enabled == true
    return CoolDownTracker_Saved.selfOnlyMode == true
end

function Private.GetDisabledTrackedMap()
    if type(CoolDownTracker_Saved.disabledTracked) ~= "table" then
        CoolDownTracker_Saved.disabledTracked = {}
    end

    return CoolDownTracker_Saved.disabledTracked
end

function Private.PruneDisabledTrackedMap()
    local coolDownTracker_disabledTracked = Private.GetDisabledTrackedMap()
    local coolDownTracker_trackedByKey = {}

    for _, coolDownTracker_tracked in ipairs(Addon.TRACKED_ABILITIES or {}) do
        if type(coolDownTracker_tracked) == "table" and type(coolDownTracker_tracked.key) == "string" then
            coolDownTracker_trackedByKey[coolDownTracker_tracked.key] = coolDownTracker_tracked
        end
    end

    for coolDownTracker_key, coolDownTracker_value in pairs(coolDownTracker_disabledTracked) do
        local coolDownTracker_tracked = coolDownTracker_trackedByKey[coolDownTracker_key]
        if coolDownTracker_tracked == nil then
            coolDownTracker_disabledTracked[coolDownTracker_key] = nil
        elseif coolDownTracker_value ~= true and coolDownTracker_value ~= false then
            coolDownTracker_disabledTracked[coolDownTracker_key] = nil
        elseif coolDownTracker_value == false and Private.IsTrackedEnabledByDefault(coolDownTracker_tracked) == true then
            coolDownTracker_disabledTracked[coolDownTracker_key] = nil
        elseif coolDownTracker_value == true and Private.IsTrackedEnabledByDefault(coolDownTracker_tracked) ~= true then
            coolDownTracker_disabledTracked[coolDownTracker_key] = nil
        end
    end
end

function Private.IsTrackedEnabledByDefault(coolDownTracker_tracked)
    return type(coolDownTracker_tracked) == "table" and coolDownTracker_tracked.trackEnabledByDefault ~= false
end

function Private.IsTrackedEnabled(coolDownTracker_tracked)
    if type(coolDownTracker_tracked) ~= "table" or type(coolDownTracker_tracked.key) ~= "string" then
        return false
    end

    -- disabledTracked is a persisted override table, not a plain disabled-only set:
    -- true = explicitly disabled, false = explicitly enabled, nil = use table default.
    local coolDownTracker_savedValue = Private.GetDisabledTrackedMap()[coolDownTracker_tracked.key]
    if coolDownTracker_savedValue == true then
        return false
    end
    if coolDownTracker_savedValue == false then
        return true
    end

    return Private.IsTrackedEnabledByDefault(coolDownTracker_tracked)
end

function Private.SetTrackedEnabled(coolDownTracker_tracked, coolDownTracker_enabled)
    if type(coolDownTracker_tracked) ~= "table" or type(coolDownTracker_tracked.key) ~= "string" then
        return false
    end

    local coolDownTracker_disabledTracked = Private.GetDisabledTrackedMap()
    local coolDownTracker_enabledByDefault = Private.IsTrackedEnabledByDefault(coolDownTracker_tracked)
    if coolDownTracker_enabled == true then
        -- For default-disabled entries we need an explicit false override so the enable survives reload.
        if coolDownTracker_enabledByDefault == true then
            coolDownTracker_disabledTracked[coolDownTracker_tracked.key] = nil
        else
            coolDownTracker_disabledTracked[coolDownTracker_tracked.key] = false
        end
        return true
    end

    if coolDownTracker_enabledByDefault == true then
        coolDownTracker_disabledTracked[coolDownTracker_tracked.key] = true
    else
        coolDownTracker_disabledTracked[coolDownTracker_tracked.key] = nil
    end
    return false
end

function Private.IsTrackedSelfObservationEnabled(coolDownTracker_tracked)
    return type(coolDownTracker_tracked) == "table"
        and Private.IsTrackedEnabled(coolDownTracker_tracked)
        and coolDownTracker_tracked.observeSelf ~= false
end

function Private.IsTrackedGroupObservationEnabled(coolDownTracker_tracked)
    return type(coolDownTracker_tracked) == "table"
        and Private.IsTrackedEnabled(coolDownTracker_tracked)
        and coolDownTracker_tracked.observeGroup ~= false
        and Private.IsSelfOnlyModeEnabled() ~= true
end

function Private.DoesTrackedObserveAnyBuffs(coolDownTracker_tracked)
    return Private.IsTrackedSelfObservationEnabled(coolDownTracker_tracked)
        or Private.IsTrackedGroupObservationEnabled(coolDownTracker_tracked)
end

function Private.GetLiveTrackingStatusSuffix(coolDownTracker_tracked)
    local coolDownTracker_key = coolDownTracker_tracked and coolDownTracker_tracked.key
    local coolDownTracker_eligibleCount = tonumber(
        Addon._eligibleRosterCountByKey and Addon._eligibleRosterCountByKey[coolDownTracker_key]
    ) or 0
    if coolDownTracker_eligibleCount > 0
        and Private.DoesTrackedObserveAnyBuffs(coolDownTracker_tracked) == true then
        return " (tracking)"
    end

    return " (no source)"
end

function Private.GetScaledSlotMetrics()
    local coolDownTracker_scale = Private.GetSlotScale()
    local coolDownTracker_slotWidth = Private.RoundToNearestInt(Addon.SLOT_WIDTH * coolDownTracker_scale)
    local coolDownTracker_slotHeight = Private.RoundToNearestInt(Addon.SLOT_HEIGHT * coolDownTracker_scale)
    local coolDownTracker_spacingX = Private.RoundToNearestInt(Addon.SLOT_SPACING_X * coolDownTracker_scale)
    local coolDownTracker_spacingY = Private.RoundToNearestInt(Addon.SLOT_SPACING_Y * coolDownTracker_scale)
    return coolDownTracker_scale,
        coolDownTracker_slotWidth,
        coolDownTracker_slotHeight,
        coolDownTracker_spacingX,
        coolDownTracker_spacingY
end

function Private.AppendLookup(coolDownTracker_lookup, coolDownTracker_key, coolDownTracker_value)
    if coolDownTracker_key == nil then
        return
    end

    local coolDownTracker_existing = coolDownTracker_lookup[coolDownTracker_key]
    if coolDownTracker_existing == nil then
        coolDownTracker_lookup[coolDownTracker_key] = coolDownTracker_value
    elseif coolDownTracker_existing ~= coolDownTracker_value then
        coolDownTracker_lookup[coolDownTracker_key] = false
    end
end

function Private.GetTrackedWindowName(coolDownTracker_index)
    return Addon.SLOT_PREFIX .. tostring(coolDownTracker_index)
end
