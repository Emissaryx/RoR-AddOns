# CoolDownTracker

CoolDownTracker is a Return of Reckoning addon that watches a small set of important buffs and shows simple on-screen timers for them.

It does not watch casts directly. By default it watches buffs on you, then works out when a tracked buff is active, cooling down, or ready again. When it first sees a tracked buff already partway through its active window, it uses the buff time left to line the cooldown up more closely.

If you want group buff scanning too, you can turn self-only mode off. Some watches use the current group roster for career-based gating, so the icon can be visible for your faction while scanning stays asleep until the matching class is in the group. The two tank movement buffs are treated as nearby-ally area buffs and can be detected without a tank in your party.

Each tracked slot can show:
- `Waiting`
- `Active`
- `Cooldown`
- `Ready`

If the same tracked buff seems to get used again before the first timer is ready, the addon can temporarily show another copy of that timer until things settle back down.

## Update Model

- It is meant to be quiet and light on the client.
- Buff changes are usually picked up within about one second.
- Cooldown numbers update in whole seconds.
- It does not try to refresh or animate more than it needs to.

## What It Tracks

Right now the addon tracks these buffs:

- `Absolute Preservation`
- `For The Witch King!` (Destruction only)
- `We'z Bigger` (Destruction only, movement-speed effect only)
- `Whispering Wind` (Order only)
- `Into the Fray` (`off` by default until you enable it)
- `Leading The Charge`

## How To Use It

- Move the tracker by dragging its anchor on screen.
- Right-click the tracker to lock movement, or to rotate layout options and hide it while movement is unlocked.
- Tracked slots start at `50%` scale by default, and you can rotate through common sizes from the right-click menu while movement is unlocked.
- Tracked slots build to the right by default, but you can rotate that from the right-click menu while movement is unlocked or use `/cdt direction` to pick right, left, up, or down.
- Disable one specific tracked buff if you want the addon to ignore it without hiding the whole tracker.
- Use `/cdt status` if you want a quick text readout in chat and the current `entry` number for each tracked ability available to you.

## Slash Commands

- `/cdt help` shows the command list.
- `/cdt status` shows the current tracker status in chat, including the faction-filtered `entry` number each per-ability slash command uses.
- `/cdt show` turns the tracker back on if it is hidden.
- `/cdt hide` hides the tracker and turns its event watching off until shown again.
- `/cdt lock <on|off|toggle>` locks or unlocks tracker movement. This setting is saved per character.
- `/cdt selfonly <on|off|toggle>` enables or disables self-only scanning. This setting is saved per character and defaults to `on`.
- `/cdt track <entry> <on|off|toggle>` enables or disables tracking for one watched ability. This setting is saved per character.
- `/cdt enable <entry>`, `/cdt disable <entry>`, and `/cdt toggle <entry>` are shortcuts for per-ability tracking changes.
- `/cdt scale <value>` changes the size of the tracked icons. The default is `50%`, and you can use values like `0.75`, `75`, or `75%`.
- `/cdt direction <right|left|up|down>` changes the direction the icon cluster builds. This setting is saved per character.
- `/cdt trigger <entry> [extra]` starts a test trigger for one tracked ability. You can use the tracked number, the ability name, or the ability id. Add `extra` if you want to test another copy of the same buff while the earlier one is on cooldown.
- `/cdt trigger all` starts test triggers for every currently enabled, available tracked ability. Use `/cdt trigger all extra` to spawn extra test copies for abilities that can show duplicate instances.

## Changelog

### 0.7.2 - 2026-05-13 - Wholdar

- Added right-click direction and scale rotation plus a hide option while movement is unlocked.
- Changed `We'z Bigger` detection to use the movement-speed text on the live buff.

### 0.7.1 - 2026-05-13 - Wholdar

- Changed the tracker window layer.
- Added a saved position lock, available from right-click or `/cdt lock`, with a small lock icon while locked.

### 0.7.0 - 2026-04-28 - Wholdar

- Added faction-specific tracking for `For The Witch King!`, `We'z Bigger`, and `Whispering Wind`.
- Kept those watches hidden on the wrong faction and quiet until the matching class is in the group.
- `/cdt status` now marks enabled entries as tracking or no source.
- Fixed a rare case where a cooldown could stay visually stuck at `1` until another group update happened.
- Icon tooltips now show the same tracking or no-source marker as `/cdt status`.
- Added `/cdt direction` so the icon cluster can build right, left, up, or down.
- Added `/cdt trigger all` and `/cdt trigger all extra` for testing every currently available tracked cooldown or duplicate-capable extra copy at once.

### 0.6.0 - 2026-04-18 - Wholdar

- Added tracking for the Onslaught tank buff `Into the Fray`, disabled by default until enabled per character.
- Added slash commands to disable or re-enable tracking for individual watched buffs.
- Tightened cooldown alignment when a tracked buff is first seen after part of its active window has already passed.

### 0.5.0 - 2026-04-18 - Wholdar

- Added self-only scanning as the default behavior.
- Added `/cdt selfonly` so group buff scanning can be turned on when wanted.

### 0.4.0 - 2026-04-18 - Wholdar

- Made the tracker quieter and lighter on the client.
- Cleaned up how timers update so it does less needless work.
- Added a saved self-only scan mode for people who do not want group buff scanning.

### 0.3.0 - 2026-04-18 - Wholdar

- Cut down on needless updating.

### 0.2.0 - 2026-04-17 - Wholdar

- Added temporary extra timer copies when the same tracked buff seems to be used again early.
- Improved general responsiveness.

### 0.1.0 - 2026-04-17 - Wholdar

- First release.
