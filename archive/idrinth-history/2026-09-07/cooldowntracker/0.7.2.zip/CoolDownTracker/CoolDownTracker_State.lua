local Addon = CoolDownTracker
local Private = Addon.Private

local CoolDownTracker_ORDER_CAREER_NAMES = {
    "IRON_BREAKER",
    "KNIGHT",
    "SWORDMASTER",
    "ARCHMAGE",
    "WARRIOR_PRIEST",
    "RUNE_PRIEST",
    "ENGINEER",
    "SLAYER",
    "WHITE_LION",
    "SHADOW_WARRIOR",
    "BRIGHT_WIZARD",
    "WITCH_HUNTER",
}

local CoolDownTracker_DESTRUCTION_CAREER_NAMES = {
    "CHOSEN",
    "BLACK_ORC",
    "BLACKGUARD",
    "SHAMAN",
    "ZEALOT",
    "DISCIPLE",
    "SORCERER",
    "MAGUS",
    "MARAUDER",
    "WITCH_ELF",
    "CHOPPA",
    "SQUIG_HERDER",
}

local coolDownTracker_factionCareerLineSource = nil
local CoolDownTracker_orderCareerLineSet = {}
local CoolDownTracker_destructionCareerLineSet = {}

local function CoolDownTracker_NormalizeInstanceLimit(coolDownTracker_value)
    local coolDownTracker_limit = math.floor(tonumber(coolDownTracker_value) or 1)
    if coolDownTracker_limit < 1 then
        coolDownTracker_limit = 1
    elseif coolDownTracker_limit > Addon.MAX_SESSION_INSTANCES then
        coolDownTracker_limit = Addon.MAX_SESSION_INSTANCES
    end
    return coolDownTracker_limit
end

local function CoolDownTracker_AssignStateWindowLayout(coolDownTracker_state, coolDownTracker_flatIndex)
    coolDownTracker_state.windowName = Private.GetTrackedWindowName(coolDownTracker_flatIndex)
    coolDownTracker_state.windowId = coolDownTracker_flatIndex
    coolDownTracker_state.iconWindowName = coolDownTracker_state.windowName .. "Icon"
    coolDownTracker_state.frameWindowName = coolDownTracker_state.windowName .. "Frame"
    coolDownTracker_state.timerBgWindowName = coolDownTracker_state.windowName .. "TimerBG"
    coolDownTracker_state.timerWindowName = coolDownTracker_state.windowName .. "Timer"
    coolDownTracker_state.statusBgWindowName = coolDownTracker_state.windowName .. "StatusBG"
    coolDownTracker_state.statusWindowName = coolDownTracker_state.windowName .. "Status"
end

local function CoolDownTracker_BuildTrackedState(
    coolDownTracker_prior,
    coolDownTracker_tracked,
    coolDownTracker_session,
    coolDownTracker_instanceIndex
)
    local coolDownTracker_state = coolDownTracker_prior or {}
    coolDownTracker_state.tracked = coolDownTracker_tracked
    coolDownTracker_state.session = coolDownTracker_session
    coolDownTracker_state.instanceIndex = math.max(math.floor(tonumber(coolDownTracker_instanceIndex) or 1), 1)
    coolDownTracker_state.cooldownStartedAt = tonumber(coolDownTracker_state.cooldownStartedAt) or 0
    coolDownTracker_state.cooldownEndsAt = tonumber(coolDownTracker_state.cooldownEndsAt) or 0
    coolDownTracker_state.lastTriggeredAt = tonumber(coolDownTracker_state.lastTriggeredAt) or 0
    coolDownTracker_state.lastTriggeredBy = coolDownTracker_state.lastTriggeredBy or ""
    coolDownTracker_state.hasEverTriggered = coolDownTracker_state.hasEverTriggered == true
    coolDownTracker_state.lastTriggerWasSynthetic = coolDownTracker_state.lastTriggerWasSynthetic == true
    coolDownTracker_state.isLiveObservedActive = coolDownTracker_state.isLiveObservedActive == true
    coolDownTracker_state.mockActiveUntil = tonumber(coolDownTracker_state.mockActiveUntil) or 0
    coolDownTracker_state.isObservedActive = coolDownTracker_state.isObservedActive == true
    return coolDownTracker_state
end

local function CoolDownTracker_BuildTrackedSession(
    coolDownTracker_prior,
    coolDownTracker_tracked,
    coolDownTracker_index
)
    local coolDownTracker_session = coolDownTracker_prior or {}
    if coolDownTracker_tracked.key == nil or coolDownTracker_tracked.key == "" then
        coolDownTracker_tracked.key = "tracked_" .. tostring(coolDownTracker_index)
    end

    local coolDownTracker_priorInstances = coolDownTracker_session.instances or {}
    local coolDownTracker_priorActiveState = coolDownTracker_session.activeState
    coolDownTracker_session.tracked = coolDownTracker_tracked
    coolDownTracker_session.key = coolDownTracker_tracked.key
    coolDownTracker_session.instances = {}
    coolDownTracker_session.activeState = nil
    coolDownTracker_session.isObservedPresent = coolDownTracker_session.isObservedPresent == true
    coolDownTracker_session.lastObservedRemaining = tonumber(coolDownTracker_session.lastObservedRemaining) or 0
    coolDownTracker_session.lastObservedAt = tonumber(coolDownTracker_session.lastObservedAt) or 0
    coolDownTracker_session.lastObservedTargetType = tonumber(coolDownTracker_session.lastObservedTargetType)
    coolDownTracker_session.maxPlausibleInstances = CoolDownTracker_NormalizeInstanceLimit(
        coolDownTracker_session.maxPlausibleInstances
    )

    local coolDownTracker_instanceCount = math.max(#coolDownTracker_priorInstances, 1)
    for coolDownTracker_instanceIndex = 1, coolDownTracker_instanceCount do
        local coolDownTracker_priorState = coolDownTracker_priorInstances[coolDownTracker_instanceIndex]
        local coolDownTracker_state = CoolDownTracker_BuildTrackedState(
            coolDownTracker_priorState,
            coolDownTracker_tracked,
            coolDownTracker_session,
            coolDownTracker_instanceIndex
        )
        coolDownTracker_session.instances[coolDownTracker_instanceIndex] = coolDownTracker_state
        if coolDownTracker_priorState == coolDownTracker_priorActiveState then
            coolDownTracker_session.activeState = coolDownTracker_state
        end
    end

    coolDownTracker_session.baseState = coolDownTracker_session.instances[1]
    return coolDownTracker_session
end

local function CoolDownTracker_HideUnusedStateWindows(coolDownTracker_oldStateCount, coolDownTracker_usedCount)
    for coolDownTracker_index = (coolDownTracker_usedCount or 0) + 1, (tonumber(coolDownTracker_oldStateCount) or 0) do
        Private.SetWindowShowing(Private.GetTrackedWindowName(coolDownTracker_index), false)
    end
end

local function CoolDownTracker_GetMemberCareerLine(coolDownTracker_member)
    if type(coolDownTracker_member) ~= "table" then
        return nil
    end

    local coolDownTracker_careerLine = tonumber(coolDownTracker_member.careerLine)
    if coolDownTracker_careerLine ~= nil then
        return coolDownTracker_careerLine
    end

    if type(coolDownTracker_member.career) == "table" then
        return tonumber(coolDownTracker_member.career.line)
    end

    return tonumber(coolDownTracker_member.career)
end

local function CoolDownTracker_GetMemberLevel(coolDownTracker_member)
    if type(coolDownTracker_member) ~= "table" then
        return nil
    end

    return tonumber(coolDownTracker_member.level)
end

local function CoolDownTracker_BuildCareerLineSet(coolDownTracker_names)
    local coolDownTracker_set = {}
    local coolDownTracker_careerLines = type(GameData) == "table"
        and type(GameData.CareerLine) == "table"
        and GameData.CareerLine
        or nil
    if coolDownTracker_careerLines == nil then
        return coolDownTracker_set
    end

    for _, coolDownTracker_name in ipairs(coolDownTracker_names or {}) do
        local coolDownTracker_careerLine = tonumber(coolDownTracker_careerLines[coolDownTracker_name])
        if coolDownTracker_careerLine ~= nil then
            coolDownTracker_set[coolDownTracker_careerLine] = true
        end
    end

    return coolDownTracker_set
end

local function CoolDownTracker_RefreshFactionCareerLineSets()
    local coolDownTracker_careerLines = type(GameData) == "table"
        and type(GameData.CareerLine) == "table"
        and GameData.CareerLine
        or nil
    if coolDownTracker_factionCareerLineSource == coolDownTracker_careerLines then
        return
    end

    coolDownTracker_factionCareerLineSource = coolDownTracker_careerLines
    CoolDownTracker_orderCareerLineSet = CoolDownTracker_BuildCareerLineSet(
        CoolDownTracker_ORDER_CAREER_NAMES
    )
    CoolDownTracker_destructionCareerLineSet = CoolDownTracker_BuildCareerLineSet(
        CoolDownTracker_DESTRUCTION_CAREER_NAMES
    )
end

local function CoolDownTracker_NormalizeFaction(coolDownTracker_faction)
    local coolDownTracker_normalized = Private.NormalizeIdentifier(coolDownTracker_faction)
    if coolDownTracker_normalized == "destro" then
        return "destruction"
    end
    return coolDownTracker_normalized
end

function Private.GetPlayerFaction()
    local coolDownTracker_playerCareerLine = CoolDownTracker_GetMemberCareerLine(
        type(GameData) == "table" and GameData.Player or nil
    )
    if coolDownTracker_playerCareerLine == nil then
        return nil
    end

    CoolDownTracker_RefreshFactionCareerLineSets()
    if CoolDownTracker_orderCareerLineSet[coolDownTracker_playerCareerLine] == true then
        return "order"
    end
    if CoolDownTracker_destructionCareerLineSet[coolDownTracker_playerCareerLine] == true then
        return "destruction"
    end

    return nil
end

function Private.IsPlayerFactionKnown()
    return Private.GetPlayerFaction() ~= nil
end

function Private.IsTrackedAllowedForPlayerFaction(coolDownTracker_tracked)
    if type(coolDownTracker_tracked) ~= "table" then
        return false
    end

    local coolDownTracker_faction = CoolDownTracker_NormalizeFaction(coolDownTracker_tracked.faction)
    if coolDownTracker_faction == ""
        or coolDownTracker_faction == "all"
        or coolDownTracker_faction == "both" then
        return true
    end

    local coolDownTracker_playerFaction = Private.GetPlayerFaction()
    if coolDownTracker_playerFaction == nil then
        return true
    end

    return coolDownTracker_playerFaction == coolDownTracker_faction
end

local function CoolDownTracker_ResolveEligibleCareerSet(coolDownTracker_tracked)
    if type(coolDownTracker_tracked) ~= "table" then
        return {}
    end

    local coolDownTracker_careerLines = type(GameData) == "table"
        and type(GameData.CareerLine) == "table"
        and GameData.CareerLine
        or nil
    if coolDownTracker_tracked._eligibleCareerLineSource == coolDownTracker_careerLines
        and type(coolDownTracker_tracked._eligibleCareerLineSet) == "table" then
        return coolDownTracker_tracked._eligibleCareerLineSet
    end

    local coolDownTracker_set = {}
    if coolDownTracker_careerLines ~= nil and type(coolDownTracker_tracked.eligibleCareerNames) == "table" then
        for _, coolDownTracker_name in ipairs(coolDownTracker_tracked.eligibleCareerNames) do
            local coolDownTracker_careerLine = tonumber(coolDownTracker_careerLines[coolDownTracker_name])
            if coolDownTracker_careerLine ~= nil then
                coolDownTracker_set[coolDownTracker_careerLine] = true
            end
        end
    end

    coolDownTracker_tracked._eligibleCareerLineSource = coolDownTracker_careerLines
    coolDownTracker_tracked._eligibleCareerLineSet = coolDownTracker_set
    return coolDownTracker_set
end

local function CoolDownTracker_IsTrackedRosterGated(coolDownTracker_tracked)
    if type(coolDownTracker_tracked) ~= "table" then
        return false
    end

    if type(coolDownTracker_tracked.eligibleCareerNames) == "table"
        and #coolDownTracker_tracked.eligibleCareerNames > 0 then
        return true
    end

    return (tonumber(coolDownTracker_tracked.minRosterLevel) or 0) > 0
end

local function CoolDownTracker_IsMemberEligibleForTracked(coolDownTracker_tracked, coolDownTracker_member)
    local coolDownTracker_careerLine = CoolDownTracker_GetMemberCareerLine(coolDownTracker_member)
    if coolDownTracker_careerLine == nil then
        return false
    end

    local coolDownTracker_minLevel = tonumber(coolDownTracker_tracked and coolDownTracker_tracked.minRosterLevel) or 0
    local coolDownTracker_level = CoolDownTracker_GetMemberLevel(coolDownTracker_member) or 0
    if coolDownTracker_level < coolDownTracker_minLevel then
        return false
    end

    return CoolDownTracker_ResolveEligibleCareerSet(coolDownTracker_tracked)[coolDownTracker_careerLine] == true
end

local function CoolDownTracker_AppendRequiredObservedAbilityId(coolDownTracker_lookup, coolDownTracker_value)
    local coolDownTracker_id = tonumber(coolDownTracker_value)
    if coolDownTracker_id ~= nil then
        coolDownTracker_lookup[coolDownTracker_id] = true
    end
end

local function CoolDownTracker_AppendRequiredObservedAnyAbilityIds(
    coolDownTracker_abilityLookup,
    coolDownTracker_tracked
)
    if type(coolDownTracker_tracked) ~= "table"
        or type(coolDownTracker_tracked.requiredObservedAnyAbilityIds) ~= "table" then
        return
    end

    for _, coolDownTracker_abilityId in ipairs(coolDownTracker_tracked.requiredObservedAnyAbilityIds) do
        CoolDownTracker_AppendRequiredObservedAbilityId(
            coolDownTracker_abilityLookup,
            coolDownTracker_abilityId
        )
    end
end

local function CoolDownTracker_RebuildFlattenedStates()
    local coolDownTracker_oldStateCount = #(Addon._states or {})
    local coolDownTracker_newStates = {}
    local coolDownTracker_newStateByWindowId = {}
    local coolDownTracker_newStatesBySessionKey = {}
    local coolDownTracker_flatIndex = 0

    for _, coolDownTracker_session in ipairs(Addon._sessions or {}) do
        local coolDownTracker_sessionStates = {}
        coolDownTracker_newStatesBySessionKey[coolDownTracker_session.key] = coolDownTracker_sessionStates
        for coolDownTracker_instanceIndex, coolDownTracker_state in ipairs(coolDownTracker_session.instances or {}) do
            coolDownTracker_flatIndex = coolDownTracker_flatIndex + 1
            coolDownTracker_state.instanceIndex = coolDownTracker_instanceIndex
            coolDownTracker_state.session = coolDownTracker_session
            CoolDownTracker_AssignStateWindowLayout(coolDownTracker_state, coolDownTracker_flatIndex)
            coolDownTracker_newStates[coolDownTracker_flatIndex] = coolDownTracker_state
            coolDownTracker_newStateByWindowId[coolDownTracker_flatIndex] = coolDownTracker_state
            coolDownTracker_sessionStates[#coolDownTracker_sessionStates + 1] = coolDownTracker_state
        end
    end

    CoolDownTracker_HideUnusedStateWindows(coolDownTracker_oldStateCount, #coolDownTracker_newStates)

    Addon._states = coolDownTracker_newStates
    Addon._stateByWindowId = coolDownTracker_newStateByWindowId
    Addon._statesBySessionKey = coolDownTracker_newStatesBySessionKey
    Private.MarkAllSessionsDirty()
end

function Private.ClearTrackedRuntimeState()
    Addon._sessions = {}
    Addon._sessionByKey = {}
    Addon._sessionByIdentifier = {}
    Addon._sessionByAbilityId = {}
    Addon._states = {}
    Addon._stateByWindowId = {}
    Addon._statesBySessionKey = {}
    Addon._scannableTrackedByAbilityId = {}
    Addon._requiredObservedAnyAbilityIdSet = {}
    Addon._trackedByIdentifier = {}
    Addon._trackedByAbilityId = {}
    Addon._trackedByDisplayIndex = {}
    Addon._eligibleRosterCountByKey = {}
    Addon._maxPlausibleInstancesByKey = {}
    Addon._scannableStateCount = 0
    Addon._observesSelf = false
    Addon._observesGroup = false
    Addon._tracksGroupRoster = false
    Addon._groupRosterSignature = ""
    Addon._dirtySessionKeys = {}
    Addon._dirtyAllSessions = false
end

local function CoolDownTracker_GetAbilityTooltipData(coolDownTracker_tracked)
    local coolDownTracker_abilityId = tonumber(coolDownTracker_tracked and coolDownTracker_tracked.abilityId)
    if coolDownTracker_abilityId == nil then
        return nil
    end

    if type(GetAbilityData) == "function" then
        local coolDownTracker_ok, coolDownTracker_data = pcall(GetAbilityData, coolDownTracker_abilityId)
        if coolDownTracker_ok and type(coolDownTracker_data) == "table" then
            return coolDownTracker_data
        end
    end

    if type(Player) == "table" and type(Player.GetAbilityData) == "function" then
        local coolDownTracker_ok, coolDownTracker_data = pcall(Player.GetAbilityData, coolDownTracker_abilityId)
        if coolDownTracker_ok and type(coolDownTracker_data) == "table" then
            return coolDownTracker_data
        end
    end

    return nil
end

function Private.GetAbilityDisplayName(coolDownTracker_tracked)
    local coolDownTracker_abilityData = CoolDownTracker_GetAbilityTooltipData(coolDownTracker_tracked)
    if type(coolDownTracker_abilityData) == "table" and coolDownTracker_abilityData.name ~= nil then
        local coolDownTracker_name = Private.TrimGenderSuffix(coolDownTracker_abilityData.name)
        if coolDownTracker_name ~= "" then
            return coolDownTracker_name
        end
    end

    return coolDownTracker_tracked.name or ("Ability " .. tostring(coolDownTracker_tracked.abilityId or "?"))
end

function Private.GetStateDisplayName(coolDownTracker_state)
    local coolDownTracker_label = Private.GetAbilityDisplayName(coolDownTracker_state.tracked)
    local coolDownTracker_instanceIndex = tonumber(coolDownTracker_state.instanceIndex) or 1
    if coolDownTracker_instanceIndex > 1 then
        return coolDownTracker_label .. " #" .. tostring(coolDownTracker_instanceIndex)
    end
    return coolDownTracker_label
end

function Private.RefreshDerivedActiveState(coolDownTracker_state, coolDownTracker_now)
    local coolDownTracker_mockActiveUntil = tonumber(coolDownTracker_state.mockActiveUntil) or 0
    if coolDownTracker_mockActiveUntil > 0 and coolDownTracker_now >= coolDownTracker_mockActiveUntil then
        coolDownTracker_state.mockActiveUntil = 0
        coolDownTracker_mockActiveUntil = 0
    end

    coolDownTracker_state.isObservedActive = (coolDownTracker_state.isLiveObservedActive == true)
        or (coolDownTracker_mockActiveUntil > coolDownTracker_now)
end

function Private.GetCooldownRemaining(coolDownTracker_state, coolDownTracker_now)
    local coolDownTracker_endsAt = tonumber(coolDownTracker_state and coolDownTracker_state.cooldownEndsAt) or 0
    return math.max(coolDownTracker_endsAt - coolDownTracker_now, 0)
end

function Private.MarkSessionDirty(coolDownTracker_session)
    if type(coolDownTracker_session) ~= "table" or type(coolDownTracker_session.key) ~= "string" then
        Addon._dirtyAllSessions = true
        return
    end

    local coolDownTracker_dirtyKeys = Addon._dirtySessionKeys
    if type(coolDownTracker_dirtyKeys) ~= "table" then
        coolDownTracker_dirtyKeys = {}
        Addon._dirtySessionKeys = coolDownTracker_dirtyKeys
    end
    coolDownTracker_dirtyKeys[coolDownTracker_session.key] = true
end

function Private.MarkAllSessionsDirty()
    Addon._dirtyAllSessions = true
    Addon._dirtySessionKeys = {}
end

function Private.ClearDirtySessions()
    Addon._dirtyAllSessions = false
    Addon._dirtySessionKeys = {}
end

function Private.HasDirtySessions()
    if Addon._dirtyAllSessions == true then
        return true
    end

    for _, coolDownTracker_isDirty in pairs(Addon._dirtySessionKeys or {}) do
        if coolDownTracker_isDirty == true then
            return true
        end
    end

    return false
end

function Private.ForEachDirtySession(coolDownTracker_callback)
    if type(coolDownTracker_callback) ~= "function" then
        return 0
    end

    local coolDownTracker_count = 0
    if Addon._dirtyAllSessions == true then
        for _, coolDownTracker_session in ipairs(Addon._sessions or {}) do
            coolDownTracker_count = coolDownTracker_count + 1
            coolDownTracker_callback(coolDownTracker_session)
        end
        return coolDownTracker_count
    end

    for coolDownTracker_key, coolDownTracker_isDirty in pairs(Addon._dirtySessionKeys or {}) do
        if coolDownTracker_isDirty == true then
            local coolDownTracker_session = (Addon._sessionByKey or {})[coolDownTracker_key]
            if type(coolDownTracker_session) == "table" then
                coolDownTracker_count = coolDownTracker_count + 1
                coolDownTracker_callback(coolDownTracker_session)
            end
        end
    end

    return coolDownTracker_count
end

function Private.GetNextCooldownDisplayAt(coolDownTracker_state, coolDownTracker_now)
    local coolDownTracker_currentTime = tonumber(coolDownTracker_now) or 0
    local coolDownTracker_remaining = Private.GetCooldownRemaining(coolDownTracker_state, coolDownTracker_currentTime)
    if coolDownTracker_remaining <= 0 then
        return nil
    end

    local coolDownTracker_displayedSeconds = math.ceil(coolDownTracker_remaining)
    local coolDownTracker_endsAt = tonumber(coolDownTracker_state and coolDownTracker_state.cooldownEndsAt) or 0
    return coolDownTracker_endsAt - (coolDownTracker_displayedSeconds - 1)
end

function Private.GetNextSharedCountdownUpdateAt(coolDownTracker_now)
    local coolDownTracker_currentTime = tonumber(coolDownTracker_now) or 0
    local coolDownTracker_earliestDisplayAt = nil

    for _, coolDownTracker_state in ipairs(Addon._states or {}) do
        coolDownTracker_earliestDisplayAt = Private.GetEarlierDueAt(
            coolDownTracker_earliestDisplayAt,
            Private.GetNextCooldownDisplayAt(coolDownTracker_state, coolDownTracker_currentTime)
        )
    end

    if coolDownTracker_earliestDisplayAt == nil then
        Addon._countdownCadenceAnchorAt = -1
        return nil
    end

    local coolDownTracker_anchorAt = tonumber(Addon._countdownCadenceAnchorAt) or -1
    if coolDownTracker_anchorAt < 0 then
        coolDownTracker_anchorAt = coolDownTracker_earliestDisplayAt
        Addon._countdownCadenceAnchorAt = coolDownTracker_anchorAt
        return coolDownTracker_anchorAt
    end

    if coolDownTracker_currentTime < coolDownTracker_anchorAt
        and coolDownTracker_earliestDisplayAt < coolDownTracker_anchorAt then
        coolDownTracker_anchorAt = coolDownTracker_earliestDisplayAt
        Addon._countdownCadenceAnchorAt = coolDownTracker_anchorAt
        return coolDownTracker_anchorAt
    end

    local coolDownTracker_interval = tonumber(Addon.SHARED_COUNTDOWN_INTERVAL) or 1
    if coolDownTracker_interval <= 0 then
        Addon._countdownCadenceAnchorAt = coolDownTracker_earliestDisplayAt
        return coolDownTracker_earliestDisplayAt
    end

    if coolDownTracker_currentTime < coolDownTracker_anchorAt then
        return coolDownTracker_anchorAt
    end

    local coolDownTracker_steps = math.floor(
        ((coolDownTracker_currentTime - coolDownTracker_anchorAt) / coolDownTracker_interval)
    ) + 1
    return coolDownTracker_anchorAt + (coolDownTracker_steps * coolDownTracker_interval)
end

function Private.GetStateNextSyntheticExpiryAt(coolDownTracker_state, coolDownTracker_now)
    local coolDownTracker_currentTime = tonumber(coolDownTracker_now) or 0
    Private.RefreshDerivedActiveState(coolDownTracker_state, coolDownTracker_currentTime)

    local coolDownTracker_mockActiveUntil = tonumber(coolDownTracker_state.mockActiveUntil) or 0
    if coolDownTracker_mockActiveUntil > coolDownTracker_currentTime then
        return coolDownTracker_mockActiveUntil
    end

    return nil
end

function Private.GetStateNextReadyAt(coolDownTracker_state, coolDownTracker_now)
    local coolDownTracker_currentTime = tonumber(coolDownTracker_now) or 0
    Private.RefreshDerivedActiveState(coolDownTracker_state, coolDownTracker_currentTime)

    local coolDownTracker_mockActiveUntil = tonumber(coolDownTracker_state.mockActiveUntil) or 0
    if coolDownTracker_mockActiveUntil > coolDownTracker_currentTime then
        return coolDownTracker_mockActiveUntil
    end

    if coolDownTracker_state.isObservedActive == true then
        return nil
    end

    local coolDownTracker_remaining = Private.GetCooldownRemaining(coolDownTracker_state, coolDownTracker_currentTime)
    if coolDownTracker_state.hasEverTriggered == true and coolDownTracker_remaining > 0 then
        return tonumber(coolDownTracker_state.cooldownEndsAt) or nil
    end

    return nil
end

function Private.DoesSessionNeedReadyCollapse(coolDownTracker_session, coolDownTracker_now)
    local coolDownTracker_currentTime = tonumber(coolDownTracker_now) or 0
    local coolDownTracker_readyCount = 0

    for _, coolDownTracker_state in ipairs(coolDownTracker_session and coolDownTracker_session.instances or {}) do
        Private.RefreshDerivedActiveState(coolDownTracker_state, coolDownTracker_currentTime)
        if coolDownTracker_state.hasEverTriggered == true
            and coolDownTracker_state.isObservedActive ~= true
            and Private.GetCooldownRemaining(coolDownTracker_state, coolDownTracker_currentTime) <= 0 then
            coolDownTracker_readyCount = coolDownTracker_readyCount + 1
            if coolDownTracker_readyCount > 1 then
                return true
            end
        end
    end

    return false
end

function Private.GetSessionNextCollapseAt(coolDownTracker_session, coolDownTracker_now)
    local coolDownTracker_instances = coolDownTracker_session and coolDownTracker_session.instances or {}
    if #coolDownTracker_instances <= 1 then
        return nil
    end

    local coolDownTracker_currentTime = tonumber(coolDownTracker_now) or 0
    if Private.DoesSessionNeedReadyCollapse(coolDownTracker_session, coolDownTracker_currentTime) == true then
        return coolDownTracker_currentTime
    end

    local coolDownTracker_nextAt = nil
    for _, coolDownTracker_state in ipairs(coolDownTracker_instances) do
        coolDownTracker_nextAt = Private.GetEarlierDueAt(
            coolDownTracker_nextAt,
            Private.GetStateNextReadyAt(coolDownTracker_state, coolDownTracker_currentTime)
        )
    end

    return coolDownTracker_nextAt
end

function Private.GetNextTimedStateUpdateAt(coolDownTracker_now)
    local coolDownTracker_currentTime = tonumber(coolDownTracker_now) or 0
    local coolDownTracker_nextAt = nil

    for _, coolDownTracker_session in ipairs(Addon._sessions or {}) do
        coolDownTracker_nextAt = Private.GetEarlierDueAt(
            coolDownTracker_nextAt,
            Private.GetSessionNextCollapseAt(coolDownTracker_session, coolDownTracker_currentTime)
        )
        for _, coolDownTracker_state in ipairs(coolDownTracker_session.instances or {}) do
            coolDownTracker_nextAt = Private.GetEarlierDueAt(
                coolDownTracker_nextAt,
                Private.GetStateNextSyntheticExpiryAt(coolDownTracker_state, coolDownTracker_currentTime)
            )
        end
    end

    return coolDownTracker_nextAt
end

function Private.BuildTooltipExtraText(coolDownTracker_state, coolDownTracker_now)
    local coolDownTracker_statusText = "Waiting"
    if coolDownTracker_state.isObservedActive then
        coolDownTracker_statusText = "Active"
    elseif coolDownTracker_state.hasEverTriggered then
        local coolDownTracker_remaining = Private.GetCooldownRemaining(coolDownTracker_state, coolDownTracker_now)
        if coolDownTracker_remaining > 0 then
            coolDownTracker_statusText = "Cooldown " .. Private.FormatRemainingSeconds(coolDownTracker_remaining) .. "s"
        else
            coolDownTracker_statusText = "Ready"
        end
    end

    return Private.ToWString(
        coolDownTracker_statusText .. Private.GetLiveTrackingStatusSuffix(coolDownTracker_state.tracked)
    )
end

function Private.FindTrackedSessionByIdentifier(coolDownTracker_identifier)
    local coolDownTracker_trimmed = Private.Trim(coolDownTracker_identifier)
    if coolDownTracker_trimmed == "" then
        local coolDownTracker_displayTracked = Addon._trackedByDisplayIndex[1]
        if type(coolDownTracker_displayTracked) == "table" then
            return Addon._sessionByKey[coolDownTracker_displayTracked.key]
        end
        return Addon._sessions[1]
    end

    local coolDownTracker_numeric = tonumber(coolDownTracker_trimmed)
    if coolDownTracker_numeric ~= nil then
        local coolDownTracker_session = Addon._sessionByAbilityId[coolDownTracker_numeric]
        if coolDownTracker_session ~= nil and coolDownTracker_session ~= false then
            return coolDownTracker_session
        end
    end

    local coolDownTracker_session = Addon._sessionByIdentifier[Private.NormalizeIdentifier(coolDownTracker_trimmed)]
    if coolDownTracker_session ~= nil and coolDownTracker_session ~= false then
        return coolDownTracker_session
    end

    if coolDownTracker_numeric ~= nil then
        local coolDownTracker_index = math.floor(coolDownTracker_numeric)
        if coolDownTracker_index >= 1 then
            local coolDownTracker_displayTracked = Addon._trackedByDisplayIndex[coolDownTracker_index]
            if type(coolDownTracker_displayTracked) == "table" then
                return Addon._sessionByKey[coolDownTracker_displayTracked.key]
            end
        end
    end

    return nil
end

function Private.FindTrackedDefinitionByIdentifier(coolDownTracker_identifier)
    local coolDownTracker_trimmed = Private.Trim(coolDownTracker_identifier)
    if coolDownTracker_trimmed == "" then
        return Addon._trackedByDisplayIndex[1]
    end

    local coolDownTracker_numeric = tonumber(coolDownTracker_trimmed)
    if coolDownTracker_numeric ~= nil then
        local coolDownTracker_tracked = Addon._trackedByAbilityId[coolDownTracker_numeric]
        if coolDownTracker_tracked ~= nil and coolDownTracker_tracked ~= false then
            return coolDownTracker_tracked
        end
    end

    local coolDownTracker_tracked = Addon._trackedByIdentifier[Private.NormalizeIdentifier(coolDownTracker_trimmed)]
    if coolDownTracker_tracked ~= nil and coolDownTracker_tracked ~= false then
        return coolDownTracker_tracked
    end

    if coolDownTracker_numeric ~= nil then
        local coolDownTracker_index = math.floor(coolDownTracker_numeric)
        if coolDownTracker_index >= 1 then
            return Addon._trackedByDisplayIndex[coolDownTracker_index]
        end
    end

    return nil
end

function Private.GetSessionStateLimit(coolDownTracker_session, coolDownTracker_allowOverflow)
    if coolDownTracker_allowOverflow == true then
        return Addon.MAX_SESSION_INSTANCES
    end

    return CoolDownTracker_NormalizeInstanceLimit(coolDownTracker_session and coolDownTracker_session.maxPlausibleInstances)
end

function Private.GetReusableSessionState(coolDownTracker_session, coolDownTracker_now)
    for _, coolDownTracker_state in ipairs(coolDownTracker_session.instances or {}) do
        Private.RefreshDerivedActiveState(coolDownTracker_state, coolDownTracker_now)
        if coolDownTracker_state.isObservedActive ~= true then
            local coolDownTracker_remaining = Private.GetCooldownRemaining(coolDownTracker_state, coolDownTracker_now)
            if coolDownTracker_state.hasEverTriggered ~= true or coolDownTracker_remaining <= 0 then
                return coolDownTracker_state
            end
        end
    end

    return nil
end

function Private.GetActiveSessionState(coolDownTracker_session, coolDownTracker_now)
    for _, coolDownTracker_state in ipairs(coolDownTracker_session.instances or {}) do
        Private.RefreshDerivedActiveState(coolDownTracker_state, coolDownTracker_now)
        if coolDownTracker_state.isObservedActive == true then
            return coolDownTracker_state
        end
    end

    return nil
end

function Private.GetMostRecentTriggeredState(coolDownTracker_session)
    for coolDownTracker_index = #(coolDownTracker_session.instances or {}), 1, -1 do
        local coolDownTracker_state = coolDownTracker_session.instances[coolDownTracker_index]
        if coolDownTracker_state.hasEverTriggered == true then
            return coolDownTracker_state
        end
    end

    return coolDownTracker_session.baseState or coolDownTracker_session.instances[1]
end

local function CoolDownTracker_CountLimitedSessionStates(
    coolDownTracker_instances,
    coolDownTracker_ignoreSyntheticStates
)
    local coolDownTracker_count = 0
    for _, coolDownTracker_state in ipairs(coolDownTracker_instances or {}) do
        if coolDownTracker_ignoreSyntheticStates ~= true
            or coolDownTracker_state.lastTriggerWasSynthetic ~= true then
            coolDownTracker_count = coolDownTracker_count + 1
        end
    end

    return coolDownTracker_count
end

function Private.AcquireSessionState(
    coolDownTracker_session,
    coolDownTracker_now,
    coolDownTracker_allowOverflow,
    coolDownTracker_ignoreSyntheticStatesForLimit
)
    local coolDownTracker_state = Private.GetReusableSessionState(coolDownTracker_session, coolDownTracker_now)
    if coolDownTracker_state ~= nil then
        return coolDownTracker_state, false
    end

    return Private.AcquireAdditionalSessionState(
        coolDownTracker_session,
        coolDownTracker_allowOverflow,
        coolDownTracker_ignoreSyntheticStatesForLimit
    )
end

function Private.AcquireAdditionalSessionState(
    coolDownTracker_session,
    coolDownTracker_allowOverflow,
    coolDownTracker_ignoreSyntheticStatesForLimit
)
    local coolDownTracker_instances = coolDownTracker_session.instances or {}
    if CoolDownTracker_CountLimitedSessionStates(
        coolDownTracker_instances,
        coolDownTracker_ignoreSyntheticStatesForLimit
    ) >= Private.GetSessionStateLimit(
        coolDownTracker_session,
        coolDownTracker_allowOverflow
    ) then
        return nil, false
    end

    local coolDownTracker_newState = CoolDownTracker_BuildTrackedState(
        nil,
        coolDownTracker_session.tracked,
        coolDownTracker_session,
        #coolDownTracker_instances + 1
    )
    coolDownTracker_instances[#coolDownTracker_instances + 1] = coolDownTracker_newState
    coolDownTracker_session.instances = coolDownTracker_instances
    CoolDownTracker_RebuildFlattenedStates()
    return coolDownTracker_newState, true
end

function Private.ApplySessionObservedState(
    coolDownTracker_session,
    coolDownTracker_isPresent,
    coolDownTracker_observedRemaining,
    coolDownTracker_now,
    coolDownTracker_observedTargetType
)
    local coolDownTracker_changed = false
    local coolDownTracker_activeState = nil
    local coolDownTracker_previousActiveState = coolDownTracker_session.activeState
    if coolDownTracker_isPresent == true then
        coolDownTracker_activeState = coolDownTracker_session.activeState
        if coolDownTracker_activeState == nil then
            coolDownTracker_activeState = Private.GetMostRecentTriggeredState(coolDownTracker_session)
            coolDownTracker_session.activeState = coolDownTracker_activeState
        end
    else
        coolDownTracker_session.activeState = nil
    end
    if coolDownTracker_previousActiveState ~= coolDownTracker_session.activeState then
        coolDownTracker_changed = true
    end

    for _, coolDownTracker_state in ipairs(coolDownTracker_session.instances or {}) do
        local coolDownTracker_previousLiveObserved = coolDownTracker_state.isLiveObservedActive == true
        local coolDownTracker_previousObservedActive = coolDownTracker_state.isObservedActive == true
        coolDownTracker_state.isLiveObservedActive = (coolDownTracker_isPresent == true)
            and (coolDownTracker_state == coolDownTracker_activeState)
        Private.RefreshDerivedActiveState(coolDownTracker_state, coolDownTracker_now)
        if coolDownTracker_previousLiveObserved ~= (coolDownTracker_state.isLiveObservedActive == true)
            or coolDownTracker_previousObservedActive ~= (coolDownTracker_state.isObservedActive == true) then
            coolDownTracker_changed = true
        end
    end

    local coolDownTracker_previousIsObservedPresent = coolDownTracker_session.isObservedPresent == true
    coolDownTracker_session.isObservedPresent = coolDownTracker_isPresent == true
    coolDownTracker_session.lastObservedRemaining = tonumber(coolDownTracker_observedRemaining) or 0
    coolDownTracker_session.lastObservedAt = tonumber(coolDownTracker_now) or 0
    coolDownTracker_session.lastObservedTargetType = nil
    if coolDownTracker_isPresent == true then
        coolDownTracker_session.lastObservedTargetType = tonumber(coolDownTracker_observedTargetType)
    end

    if coolDownTracker_previousIsObservedPresent ~= (coolDownTracker_session.isObservedPresent == true) then
        coolDownTracker_changed = true
    end

    return coolDownTracker_changed
end

function Private.ShouldInferAdditionalSharedTrigger(
    coolDownTracker_session,
    coolDownTracker_observedRemaining,
    coolDownTracker_now
)
    local coolDownTracker_tracked = coolDownTracker_session and coolDownTracker_session.tracked or nil
    if coolDownTracker_tracked == nil or coolDownTracker_tracked.isGroupSharedBuff ~= true then
        return false
    end

    local coolDownTracker_effectDuration = tonumber(coolDownTracker_tracked.effectDurationSeconds) or 0
    local coolDownTracker_previousRemaining = tonumber(coolDownTracker_session.lastObservedRemaining) or 0
    local coolDownTracker_lastObservedAt = tonumber(coolDownTracker_session.lastObservedAt) or 0
    local coolDownTracker_currentRemaining = tonumber(coolDownTracker_observedRemaining) or 0
    local coolDownTracker_elapsed = math.max((tonumber(coolDownTracker_now) or 0) - coolDownTracker_lastObservedAt, 0)
    local coolDownTracker_expectedRemaining = math.max(
        coolDownTracker_previousRemaining - coolDownTracker_elapsed,
        0
    )
    if coolDownTracker_effectDuration <= 0 or coolDownTracker_currentRemaining <= 0 then
        return false
    end

    if coolDownTracker_currentRemaining < (
        coolDownTracker_effectDuration - Addon.GROUP_SHARED_RESET_NEAR_FULL_TOLERANCE
    ) then
        return false
    end

    return coolDownTracker_currentRemaining > (
        coolDownTracker_expectedRemaining + Addon.GROUP_SHARED_RESET_MIN_DELTA
    )
end

function Private.CollapseSessionReadyExtraStates(coolDownTracker_session, coolDownTracker_now)
    local coolDownTracker_instances = coolDownTracker_session and coolDownTracker_session.instances or {}
    if #coolDownTracker_instances <= 1 then
        return false
    end

    local coolDownTracker_layoutChanged = false
    local coolDownTracker_newInstances = {}
    local coolDownTracker_keptReadyState = nil

    for coolDownTracker_index, coolDownTracker_state in ipairs(coolDownTracker_instances) do
        Private.RefreshDerivedActiveState(coolDownTracker_state, coolDownTracker_now)
        local coolDownTracker_isReady = coolDownTracker_state.hasEverTriggered == true
            and coolDownTracker_state.isObservedActive ~= true
            and Private.GetCooldownRemaining(coolDownTracker_state, coolDownTracker_now) <= 0
        local coolDownTracker_keepState = true

        if coolDownTracker_index == 1 then
            if coolDownTracker_isReady then
                coolDownTracker_keptReadyState = coolDownTracker_state
            end
        elseif coolDownTracker_isReady then
            if coolDownTracker_keptReadyState == nil then
                coolDownTracker_keptReadyState = coolDownTracker_state
            else
                coolDownTracker_keepState = false
            end
        end

        if coolDownTracker_keepState then
            coolDownTracker_newInstances[#coolDownTracker_newInstances + 1] = coolDownTracker_state
        else
            coolDownTracker_layoutChanged = true
            if coolDownTracker_session.activeState == coolDownTracker_state then
                coolDownTracker_session.activeState = nil
            end
        end
    end

    if coolDownTracker_layoutChanged == true then
        coolDownTracker_session.instances = coolDownTracker_newInstances
        coolDownTracker_session.baseState = coolDownTracker_newInstances[1]
    end

    return coolDownTracker_layoutChanged
end

function Private.CollapseDirtyReadyExtraStates(coolDownTracker_now)
    local coolDownTracker_layoutChanged = false

    Private.ForEachDirtySession(function(coolDownTracker_session)
        if Private.CollapseSessionReadyExtraStates(coolDownTracker_session, coolDownTracker_now) == true then
            coolDownTracker_layoutChanged = true
        end
    end)

    if coolDownTracker_layoutChanged == true then
        CoolDownTracker_RebuildFlattenedStates()
    end

    return coolDownTracker_layoutChanged
end

function Private.CollapseReadyExtraStates(coolDownTracker_now)
    local coolDownTracker_layoutChanged = false

    for _, coolDownTracker_session in ipairs(Addon._sessions or {}) do
        if Private.CollapseSessionReadyExtraStates(coolDownTracker_session, coolDownTracker_now) == true then
            coolDownTracker_layoutChanged = true
        end
    end

    if coolDownTracker_layoutChanged == true then
        CoolDownTracker_RebuildFlattenedStates()
    end

    return coolDownTracker_layoutChanged
end

function Private.RefreshGroupRosterCache(coolDownTracker_force)
    local coolDownTracker_countsByKey = {}
    local coolDownTracker_signatureParts = {}
    local coolDownTracker_scannableTrackedByAbilityId = {}
    local coolDownTracker_requiredObservedAnyAbilityIdSet = {}
    local coolDownTracker_scannableStateCount = 0

    for _, coolDownTracker_session in ipairs(Addon._sessions or {}) do
        local coolDownTracker_count = 1
        if CoolDownTracker_IsTrackedRosterGated(coolDownTracker_session.tracked) then
            coolDownTracker_count = 0
            if CoolDownTracker_IsMemberEligibleForTracked(coolDownTracker_session.tracked, GameData and GameData.Player) then
                coolDownTracker_count = coolDownTracker_count + 1
            end

            if type(GroupWindow) == "table" and type(GroupWindow.groupData) == "table" then
                for _, coolDownTracker_member in ipairs(GroupWindow.groupData) do
                    if CoolDownTracker_IsMemberEligibleForTracked(coolDownTracker_session.tracked, coolDownTracker_member) then
                        coolDownTracker_count = coolDownTracker_count + 1
                    end
                end
            end
        end

        coolDownTracker_countsByKey[coolDownTracker_session.key] = coolDownTracker_count
        coolDownTracker_signatureParts[#coolDownTracker_signatureParts + 1] = coolDownTracker_session.key
            .. "="
            .. tostring(coolDownTracker_count)
    end

    local coolDownTracker_signature = table.concat(coolDownTracker_signatureParts, "|")
    if coolDownTracker_force ~= true and coolDownTracker_signature == (Addon._groupRosterSignature or "") then
        return false
    end

    Addon._groupRosterSignature = coolDownTracker_signature
    Addon._eligibleRosterCountByKey = coolDownTracker_countsByKey
    Addon._maxPlausibleInstancesByKey = {}
    for _, coolDownTracker_session in ipairs(Addon._sessions or {}) do
        local coolDownTracker_eligibleCount = tonumber(coolDownTracker_countsByKey[coolDownTracker_session.key]) or 0
        local coolDownTracker_scannableCount = coolDownTracker_eligibleCount
        local coolDownTracker_fixedLimit = tonumber(coolDownTracker_session.tracked.maxPlausibleInstances)
        local coolDownTracker_limit = CoolDownTracker_NormalizeInstanceLimit(
            coolDownTracker_fixedLimit or coolDownTracker_scannableCount
        )
        Addon._maxPlausibleInstancesByKey[coolDownTracker_session.key] = coolDownTracker_limit
        coolDownTracker_session.maxPlausibleInstances = coolDownTracker_limit

        if coolDownTracker_scannableCount > 0
            and Private.DoesTrackedObserveAnyBuffs(coolDownTracker_session.tracked) then
            coolDownTracker_scannableStateCount = coolDownTracker_scannableStateCount + 1
            Private.AppendLookup(
                coolDownTracker_scannableTrackedByAbilityId,
                tonumber(coolDownTracker_session.tracked.abilityId),
                coolDownTracker_session.tracked
            )

            if type(coolDownTracker_session.tracked.altAbilityIds) == "table" then
                for _, coolDownTracker_altAbilityId in ipairs(coolDownTracker_session.tracked.altAbilityIds) do
                    Private.AppendLookup(
                        coolDownTracker_scannableTrackedByAbilityId,
                        tonumber(coolDownTracker_altAbilityId),
                        coolDownTracker_session.tracked
                    )
                end
            end

            CoolDownTracker_AppendRequiredObservedAnyAbilityIds(
                coolDownTracker_requiredObservedAnyAbilityIdSet,
                coolDownTracker_session.tracked
            )
        end
    end

    Addon._scannableTrackedByAbilityId = coolDownTracker_scannableTrackedByAbilityId
    Addon._requiredObservedAnyAbilityIdSet = coolDownTracker_requiredObservedAnyAbilityIdSet
    Addon._scannableStateCount = coolDownTracker_scannableStateCount

    return true
end

function Private.RebuildTrackedLookups()
    local coolDownTracker_oldSessionsByKey = Addon._sessionByKey or {}
    local coolDownTracker_newSessions = {}
    local coolDownTracker_newSessionByKey = {}
    local coolDownTracker_newSessionByIdentifier = {}
    local coolDownTracker_newSessionByAbilityId = {}
    local coolDownTracker_newTrackedByIdentifier = {}
    local coolDownTracker_newTrackedByAbilityId = {}
    local coolDownTracker_newTrackedByDisplayIndex = {}
    local coolDownTracker_displayIndex = 0
    local coolDownTracker_observesSelf = false
    local coolDownTracker_observesGroup = false
    local coolDownTracker_tracksGroupRoster = false

    Private.PruneDisabledTrackedMap()
    Addon._scannableTrackedByAbilityId = {}
    Addon._requiredObservedAnyAbilityIdSet = {}
    Addon._eligibleRosterCountByKey = {}
    Addon._scannableStateCount = 0

    for coolDownTracker_index, coolDownTracker_tracked in ipairs(Addon.TRACKED_ABILITIES or {}) do
        if type(coolDownTracker_tracked) == "table" then
            local coolDownTracker_isAllowedForFaction = Private.IsTrackedAllowedForPlayerFaction(
                coolDownTracker_tracked
            )
            if coolDownTracker_isAllowedForFaction == true then
                coolDownTracker_displayIndex = coolDownTracker_displayIndex + 1
                coolDownTracker_newTrackedByDisplayIndex[coolDownTracker_displayIndex] = coolDownTracker_tracked
            end
            Private.AppendLookup(
                coolDownTracker_newTrackedByIdentifier,
                Private.NormalizeIdentifier(coolDownTracker_tracked.key),
                coolDownTracker_tracked
            )
            Private.AppendLookup(
                coolDownTracker_newTrackedByIdentifier,
                Private.NormalizeIdentifier(coolDownTracker_tracked.name),
                coolDownTracker_tracked
            )
            Private.AppendLookup(
                coolDownTracker_newTrackedByAbilityId,
                tonumber(coolDownTracker_tracked.abilityId),
                coolDownTracker_tracked
            )
            if type(coolDownTracker_tracked.altAbilityIds) == "table" then
                for _, coolDownTracker_altAbilityId in ipairs(coolDownTracker_tracked.altAbilityIds) do
                    Private.AppendLookup(
                        coolDownTracker_newTrackedByAbilityId,
                        tonumber(coolDownTracker_altAbilityId),
                        coolDownTracker_tracked
                    )
                end
            end

            if Private.IsTrackedEnabled(coolDownTracker_tracked) == true
                and coolDownTracker_isAllowedForFaction == true then
                local coolDownTracker_session = CoolDownTracker_BuildTrackedSession(
                    coolDownTracker_oldSessionsByKey[coolDownTracker_tracked.key],
                    coolDownTracker_tracked,
                    coolDownTracker_index
                )
                coolDownTracker_newSessions[#coolDownTracker_newSessions + 1] = coolDownTracker_session
                coolDownTracker_newSessionByKey[coolDownTracker_session.key] = coolDownTracker_session

                Private.AppendLookup(
                    coolDownTracker_newSessionByIdentifier,
                    Private.NormalizeIdentifier(coolDownTracker_tracked.key),
                    coolDownTracker_session
                )
                Private.AppendLookup(
                    coolDownTracker_newSessionByIdentifier,
                    Private.NormalizeIdentifier(coolDownTracker_tracked.name),
                    coolDownTracker_session
                )
                Private.AppendLookup(
                    coolDownTracker_newSessionByAbilityId,
                    tonumber(coolDownTracker_tracked.abilityId),
                    coolDownTracker_session
                )

                if type(coolDownTracker_tracked.altAbilityIds) == "table" then
                    for _, coolDownTracker_altAbilityId in ipairs(coolDownTracker_tracked.altAbilityIds) do
                        Private.AppendLookup(
                            coolDownTracker_newSessionByAbilityId,
                            tonumber(coolDownTracker_altAbilityId),
                            coolDownTracker_session
                        )
                    end
                end

                if Private.IsTrackedSelfObservationEnabled(coolDownTracker_tracked) then
                    coolDownTracker_observesSelf = true
                end
                if Private.IsTrackedGroupObservationEnabled(coolDownTracker_tracked) then
                    coolDownTracker_observesGroup = true
                end
                if CoolDownTracker_IsTrackedRosterGated(coolDownTracker_tracked) then
                    coolDownTracker_tracksGroupRoster = true
                end
            end
        end
    end

    Addon._sessions = coolDownTracker_newSessions
    Addon._sessionByKey = coolDownTracker_newSessionByKey
    Addon._sessionByIdentifier = coolDownTracker_newSessionByIdentifier
    Addon._sessionByAbilityId = coolDownTracker_newSessionByAbilityId
    Addon._trackedByIdentifier = coolDownTracker_newTrackedByIdentifier
    Addon._trackedByAbilityId = coolDownTracker_newTrackedByAbilityId
    Addon._trackedByDisplayIndex = coolDownTracker_newTrackedByDisplayIndex
    Addon._observesSelf = coolDownTracker_observesSelf
    Addon._observesGroup = coolDownTracker_observesGroup
    Addon._tracksGroupRoster = coolDownTracker_tracksGroupRoster

    CoolDownTracker_RebuildFlattenedStates()
    Private.RefreshGroupRosterCache(true)
end

function Addon.GetTrackedAbilityState(coolDownTracker_keyOrAbilityId)
    local coolDownTracker_session = Private.FindTrackedSessionByIdentifier(coolDownTracker_keyOrAbilityId)
    if coolDownTracker_session == nil then
        return nil
    end

    return coolDownTracker_session.baseState or coolDownTracker_session.instances[1]
end

function Addon.GetTrackedAbilityStates(coolDownTracker_keyOrAbilityId)
    local coolDownTracker_session = Private.FindTrackedSessionByIdentifier(coolDownTracker_keyOrAbilityId)
    if coolDownTracker_session == nil then
        return nil
    end

    return coolDownTracker_session.instances
end

function Addon.IsTrackedAbilityEnabled(coolDownTracker_keyOrAbilityId)
    local coolDownTracker_tracked = Private.FindTrackedDefinitionByIdentifier(coolDownTracker_keyOrAbilityId)
    return coolDownTracker_tracked ~= nil and Private.IsTrackedEnabled(coolDownTracker_tracked) == true
end
