<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
    <UiMod name="CoolDownTracker" version="0.7.2" date="2026-05-14">
        <Author name="Wholdar" />
        <Description text="Tracks cooldowns for selected abilities by watching your buffs, with optional group buff scanning." />
        <VersionSettings gameVersion="1.4.8" windowsVersion="1.0" savedVariablesVersion="1.0" />
        <Dependencies>
            <Dependency name="LibSlash" forceEnable="true" />
            <Dependency name="EA_ContextMenu" />
        </Dependencies>
        <SavedVariables>
            <SavedVariable name="CoolDownTracker_Saved" global="false" />
        </SavedVariables>
        <Files>
            <File name="CoolDownTracker.xml" />
            <File name="CoolDownTracker.lua" />
            <File name="CoolDownTracker_Core.lua" />
            <File name="CoolDownTracker_State.lua" />
            <File name="CoolDownTracker_Scan.lua" />
            <File name="CoolDownTracker_UI.lua" />
            <File name="CoolDownTracker_Slash.lua" />
            <File name="CoolDownTracker_Lifecycle.lua" />
        </Files>
        <OnInitialize>
            <CallFunction name="CoolDownTracker.Initialize" />
        </OnInitialize>
    </UiMod>
</ModuleFile>
