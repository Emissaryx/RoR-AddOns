local Addon = CoolDownTracker
local Private = Addon.Private

function Private.PrintUsage()
    Private.PrintChat("Commands: version " .. tostring(Addon.VERSION or "?"))
    Private.PrintChat("/cdt status - show current tracker state and per-ability entry numbers")
    Private.PrintChat("/cdt show | /cdt hide - enable or disable the tracker")
    Private.PrintChat("/cdt lock <on|off|toggle> - lock or unlock tracker movement")
    Private.PrintChat("/cdt selfonly <on|off|toggle> - enable or disable self-only buff scanning")
    Private.PrintChat(
        "/cdt track [entry|key|abilityId|abilityName] <on|off|toggle> - enable or disable tracking for one ability"
    )
    Private.PrintChat("/cdt enable | /cdt disable | /cdt toggle <entry> - per-ability tracking shortcuts")
    Private.PrintChat(
        "/cdt scale <value> - set icon scale (default "
            .. Private.FormatScaleText(Addon.DEFAULT_SLOT_SCALE)
            .. "; 0.25-2.0 or 25%-200%)"
    )
    Private.PrintChat("/cdt direction <right|left|up|down> - set the icon build direction")
    Private.PrintChat(
        "/cdt trigger [all|entry|key|abilityId|abilityName] [extra] - trigger synthetic cooldowns"
    )
end

local function CoolDownTracker_PrintTrackedChoices()
    Private.PrintChat("Tracked abilities:")
    for coolDownTracker_index, coolDownTracker_tracked in ipairs(Addon._trackedByDisplayIndex or {}) do
        local coolDownTracker_suffix = ""
        if Private.IsTrackedEnabled(coolDownTracker_tracked) ~= true then
            coolDownTracker_suffix = " (disabled)"
        end

        Private.PrintChat(
            "[" .. tostring(coolDownTracker_index or "?") .. "] "
                .. Private.GetAbilityDisplayName(coolDownTracker_tracked)
                .. coolDownTracker_suffix
        )
    end
end

local function CoolDownTracker_GetStatusEntryLabel(
    coolDownTracker_tracked,
    coolDownTracker_entryIndex,
    coolDownTracker_state
)
    local coolDownTracker_label = coolDownTracker_state ~= nil
        and Private.GetStateDisplayName(coolDownTracker_state)
        or Private.GetAbilityDisplayName(coolDownTracker_tracked)

    return "[" .. tostring(coolDownTracker_entryIndex or "?") .. "] " .. coolDownTracker_label
end

function Private.PrintStatus()
    local coolDownTracker_now = Private.GetNow()
    Private.PrintChat(
        "Settings: "
            .. "version "
            .. tostring(Addon.VERSION or "?")
            .. ", "
            .. (Private.IsEnabled() and "shown" or "hidden")
            .. ", scale "
            .. Private.FormatScaleText(Private.GetSlotScale())
            .. ", self-only "
            .. (Private.IsSelfOnlyModeEnabled() and "on" or "off")
            .. ", direction "
            .. Private.GetBuildDirection()
            .. ", position "
            .. (Private.IsPositionLocked() and "locked" or "unlocked")
    )

    for coolDownTracker_index, coolDownTracker_tracked in ipairs(Addon._trackedByDisplayIndex or {}) do
        local coolDownTracker_entryLabel = CoolDownTracker_GetStatusEntryLabel(
            coolDownTracker_tracked,
            coolDownTracker_index,
            nil
        )
        if Private.IsTrackedEnabled(coolDownTracker_tracked) ~= true then
            Private.PrintChat(coolDownTracker_entryLabel .. ": Disabled")
        else
            local coolDownTracker_liveStatusSuffix = Private.GetLiveTrackingStatusSuffix(
                coolDownTracker_tracked
            )
            local coolDownTracker_session = Addon._sessionByKey[coolDownTracker_tracked.key]
            if coolDownTracker_session == nil or type(coolDownTracker_session.instances) ~= "table" then
                Private.PrintChat(coolDownTracker_entryLabel .. ": Waiting" .. coolDownTracker_liveStatusSuffix)
            else
                local coolDownTracker_printedState = false
                for _, coolDownTracker_state in ipairs(coolDownTracker_session.instances) do
                    coolDownTracker_printedState = true
                    Private.RefreshDerivedActiveState(coolDownTracker_state, coolDownTracker_now)
                    local coolDownTracker_label = CoolDownTracker_GetStatusEntryLabel(
                        coolDownTracker_tracked,
                        coolDownTracker_index,
                        coolDownTracker_state
                    )
                    if coolDownTracker_state.isObservedActive then
                        Private.PrintChat(coolDownTracker_label .. ": Active" .. coolDownTracker_liveStatusSuffix)
                    elseif coolDownTracker_state.hasEverTriggered then
                        local coolDownTracker_remaining = Private.GetCooldownRemaining(coolDownTracker_state, coolDownTracker_now)
                        if coolDownTracker_remaining > 0 then
                            Private.PrintChat(
                                coolDownTracker_label
                                    .. ": "
                                    .. Private.FormatRemainingSeconds(coolDownTracker_remaining)
                                    .. "s"
                                    .. coolDownTracker_liveStatusSuffix
                            )
                        else
                            Private.PrintChat(coolDownTracker_label .. ": Ready" .. coolDownTracker_liveStatusSuffix)
                        end
                    else
                        Private.PrintChat(coolDownTracker_label .. ": Waiting" .. coolDownTracker_liveStatusSuffix)
                    end
                end

                if coolDownTracker_printedState ~= true then
                    Private.PrintChat(coolDownTracker_entryLabel .. ": Waiting" .. coolDownTracker_liveStatusSuffix)
                end
            end
        end
    end
end

local function CoolDownTracker_ParseTriggerRequest(coolDownTracker_text)
    local coolDownTracker_identifier = Private.Trim(coolDownTracker_text)
    local coolDownTracker_preferExtra = false
    local coolDownTracker_prefix, coolDownTracker_suffix = string.match(
        coolDownTracker_identifier,
        "^(.-)%s+(%S+)$"
    )
    local coolDownTracker_normalizedSuffix = Private.NormalizeIdentifier(coolDownTracker_suffix or "")
    if coolDownTracker_prefix ~= nil
        and Private.Trim(coolDownTracker_prefix) ~= ""
        and (
            coolDownTracker_normalizedSuffix == "extra"
            or coolDownTracker_normalizedSuffix == "copy"
            or coolDownTracker_normalizedSuffix == "new"
        ) then
        coolDownTracker_identifier = Private.Trim(coolDownTracker_prefix)
        coolDownTracker_preferExtra = true
    end

    return coolDownTracker_identifier, coolDownTracker_preferExtra
end

local function CoolDownTracker_ParseToggleToken(coolDownTracker_text)
    local coolDownTracker_value = Private.NormalizeIdentifier(coolDownTracker_text)
    if coolDownTracker_value == "" then
        return nil
    end
    if coolDownTracker_value == "on"
        or coolDownTracker_value == "true"
        or coolDownTracker_value == "yes"
        or coolDownTracker_value == "1"
        or coolDownTracker_value == "enable"
        or coolDownTracker_value == "enabled" then
        return true
    end
    if coolDownTracker_value == "off"
        or coolDownTracker_value == "false"
        or coolDownTracker_value == "no"
        or coolDownTracker_value == "0"
        or coolDownTracker_value == "disable"
        or coolDownTracker_value == "disabled" then
        return false
    end
    if coolDownTracker_value == "toggle" then
        return "toggle"
    end
    return nil
end

local function CoolDownTracker_ResolveToggleToken(coolDownTracker_token, coolDownTracker_currentValue)
    if coolDownTracker_token == "toggle" then
        return coolDownTracker_currentValue ~= true
    end

    return coolDownTracker_token == true
end

local function CoolDownTracker_ParseTrackedToggleRequest(coolDownTracker_text)
    local coolDownTracker_trimmed = Private.Trim(coolDownTracker_text)
    if coolDownTracker_trimmed == "" then
        return "", nil
    end

    local coolDownTracker_prefix, coolDownTracker_suffix = string.match(
        coolDownTracker_trimmed,
        "^(.-)%s+(%S+)$"
    )
    if coolDownTracker_prefix ~= nil and Private.Trim(coolDownTracker_prefix) ~= "" then
        local coolDownTracker_token = CoolDownTracker_ParseToggleToken(coolDownTracker_suffix)
        if coolDownTracker_token ~= nil then
            return Private.Trim(coolDownTracker_prefix), coolDownTracker_token
        end
    end

    return coolDownTracker_trimmed, nil
end

local function CoolDownTracker_PrintTrackedToggleUsage()
    Private.PrintChat(
        "Usage: /cdt track <entry|key|abilityId|abilityName> <on|off|toggle>"
    )
end

local function CoolDownTracker_PrintTriggerUsage()
    Private.PrintChat(
        "Usage: /cdt trigger [all|entry|key|abilityId|abilityName] [extra]"
    )
end

local function CoolDownTracker_IsTriggerAllIdentifier(coolDownTracker_identifier)
    local coolDownTracker_normalized = Private.NormalizeIdentifier(coolDownTracker_identifier)
    return coolDownTracker_normalized == "all" or coolDownTracker_normalized == "*"
end

local function CoolDownTracker_SetTrackedEnabledFromSlash(
    coolDownTracker_identifier,
    coolDownTracker_token
)
    local coolDownTracker_tracked = Private.FindTrackedDefinitionByIdentifier(coolDownTracker_identifier)
    if coolDownTracker_tracked == nil then
        return nil, "unknown"
    end

    local coolDownTracker_currentEnabled = Private.IsTrackedEnabled(coolDownTracker_tracked)
    if coolDownTracker_token == nil then
        return coolDownTracker_tracked, (coolDownTracker_currentEnabled and "status_enabled" or "status_disabled")
    end

    local coolDownTracker_nextEnabled = CoolDownTracker_ResolveToggleToken(
        coolDownTracker_token,
        coolDownTracker_currentEnabled
    )
    if coolDownTracker_nextEnabled == coolDownTracker_currentEnabled then
        return coolDownTracker_tracked, (coolDownTracker_nextEnabled and "already_enabled" or "already_disabled")
    end

    Private.SetTrackedEnabled(coolDownTracker_tracked, coolDownTracker_nextEnabled)
    Addon.Reconfigure()
    return coolDownTracker_tracked, (coolDownTracker_nextEnabled and "enabled" or "disabled")
end

local function CoolDownTracker_HandleTrackedToggleCommand(
    coolDownTracker_identifier,
    coolDownTracker_token
)
    if Private.Trim(coolDownTracker_identifier) == "" then
        CoolDownTracker_PrintTrackedToggleUsage()
        CoolDownTracker_PrintTrackedChoices()
        return true
    end

    local coolDownTracker_tracked, coolDownTracker_result = CoolDownTracker_SetTrackedEnabledFromSlash(
        coolDownTracker_identifier,
        coolDownTracker_token
    )
    if coolDownTracker_result == "unknown" or coolDownTracker_tracked == nil then
        Private.PrintChat("Unknown tracked ability: " .. Private.Trim(coolDownTracker_identifier))
        CoolDownTracker_PrintTrackedToggleUsage()
        CoolDownTracker_PrintTrackedChoices()
        return true
    end

    local coolDownTracker_name = Private.GetAbilityDisplayName(coolDownTracker_tracked)
    if coolDownTracker_result == "status_enabled" then
        Private.PrintChat("Tracking is currently enabled for " .. coolDownTracker_name .. ".")
        CoolDownTracker_PrintTrackedToggleUsage()
        return true
    end
    if coolDownTracker_result == "status_disabled" then
        Private.PrintChat("Tracking is currently disabled for " .. coolDownTracker_name .. ".")
        CoolDownTracker_PrintTrackedToggleUsage()
        return true
    end
    if coolDownTracker_result == "already_enabled" then
        Private.PrintChat("Tracking is already enabled for " .. coolDownTracker_name .. ".")
        return true
    end
    if coolDownTracker_result == "already_disabled" then
        Private.PrintChat("Tracking is already disabled for " .. coolDownTracker_name .. ".")
        return true
    end
    if coolDownTracker_result == "enabled" then
        Private.PrintChat("Tracking enabled for " .. coolDownTracker_name .. ".")
        return true
    end
    if coolDownTracker_result == "disabled" then
        Private.PrintChat("Tracking disabled for " .. coolDownTracker_name .. ".")
        return true
    end

    return false
end

function Addon.TriggerActivate(
    coolDownTracker_identifier,
    coolDownTracker_preferExtra,
    coolDownTracker_options
)
    coolDownTracker_options = coolDownTracker_options or {}
    local coolDownTracker_tracked = Private.FindTrackedDefinitionByIdentifier(coolDownTracker_identifier)
    if coolDownTracker_tracked == nil then
        return nil, "unknown", nil
    end
    if Private.IsTrackedEnabled(coolDownTracker_tracked) ~= true then
        return nil, "disabled", coolDownTracker_tracked
    end
    if Private.IsTrackedAllowedForPlayerFaction(coolDownTracker_tracked) ~= true then
        return nil, "unavailable", coolDownTracker_tracked
    end

    local coolDownTracker_session = Private.FindTrackedSessionByIdentifier(coolDownTracker_identifier)
    if coolDownTracker_session == nil then
        return nil, "unknown", coolDownTracker_tracked
    end

    local coolDownTracker_now = Private.GetNow()
    local coolDownTracker_state = coolDownTracker_session.baseState or coolDownTracker_session.instances[1]
    local coolDownTracker_layoutChanged = false
    local coolDownTracker_activeState = Private.GetActiveSessionState(coolDownTracker_session, coolDownTracker_now)
    if coolDownTracker_preferExtra == true
        and coolDownTracker_activeState ~= nil then
        return coolDownTracker_activeState, "blocked_active", coolDownTracker_tracked
    end
    if coolDownTracker_preferExtra == true then
        if coolDownTracker_options.forceExtraInstance == true then
            if (tonumber(Private.GetSessionStateLimit(coolDownTracker_session, false)) or 1) <= 1 then
                return nil, "no_extra", coolDownTracker_tracked
            end
            coolDownTracker_state, coolDownTracker_layoutChanged = Private.AcquireAdditionalSessionState(
                coolDownTracker_session,
                coolDownTracker_options.usePlausibleExtraLimit ~= true
            )
            if coolDownTracker_state == nil then
                return nil, "no_extra", coolDownTracker_tracked
            end
        elseif Private.GetReusableSessionState(coolDownTracker_session, coolDownTracker_now) == nil then
            coolDownTracker_state, coolDownTracker_layoutChanged = Private.AcquireSessionState(
                coolDownTracker_session,
                coolDownTracker_now,
                true
            )
        end
    end
    if coolDownTracker_state == nil then
        coolDownTracker_state = coolDownTracker_session.baseState or Private.GetMostRecentTriggeredState(
            coolDownTracker_session
        )
        if coolDownTracker_state == nil then
            return nil, "unknown", coolDownTracker_tracked
        end
    end

    Private.StartCooldown(
        coolDownTracker_state,
        "Trigger",
        coolDownTracker_now,
        true
    )
    coolDownTracker_session.activeState = nil
    coolDownTracker_session.isObservedPresent = false
    coolDownTracker_session.lastObservedRemaining = 0
    local coolDownTracker_effectDuration = tonumber(coolDownTracker_state.tracked.effectDurationSeconds) or 0
    coolDownTracker_state.mockActiveUntil = coolDownTracker_now + coolDownTracker_effectDuration
    coolDownTracker_state.isLiveObservedActive = false
    Private.RefreshDerivedActiveState(coolDownTracker_state, coolDownTracker_now)
    if coolDownTracker_layoutChanged == true then
        Private.MarkAllSessionsDirty()
        Private.EnsureWindows()
    else
        Private.MarkSessionDirty(coolDownTracker_session)
    end
    Addon.UpdateAllVisuals(coolDownTracker_now, coolDownTracker_layoutChanged == true)
    return coolDownTracker_state, (coolDownTracker_preferExtra == true and "triggered_extra" or "triggered"), coolDownTracker_tracked
end

function Addon.TriggerAll(coolDownTracker_preferExtra)
    local coolDownTracker_triggeredCount = 0
    local coolDownTracker_blockedActiveCount = 0
    local coolDownTracker_noExtraCount = 0
    local coolDownTracker_options = nil
    if coolDownTracker_preferExtra == true then
        coolDownTracker_options = {
            forceExtraInstance = true,
            usePlausibleExtraLimit = true,
        }
    end

    for _, coolDownTracker_session in ipairs(Addon._sessions or {}) do
        local coolDownTracker_tracked = coolDownTracker_session.tracked
        if type(coolDownTracker_tracked) == "table" and coolDownTracker_tracked.key ~= nil then
            local coolDownTracker_state, coolDownTracker_result = Addon.TriggerActivate(
                coolDownTracker_tracked.key,
                coolDownTracker_preferExtra,
                coolDownTracker_options
            )
            if coolDownTracker_state ~= nil
                and (
                    coolDownTracker_result == "triggered"
                    or coolDownTracker_result == "triggered_extra"
                ) then
                coolDownTracker_triggeredCount = coolDownTracker_triggeredCount + 1
            elseif coolDownTracker_result == "blocked_active" then
                coolDownTracker_blockedActiveCount = coolDownTracker_blockedActiveCount + 1
            elseif coolDownTracker_result == "no_extra" then
                coolDownTracker_noExtraCount = coolDownTracker_noExtraCount + 1
            end
        end
    end

    return coolDownTracker_triggeredCount, coolDownTracker_blockedActiveCount, coolDownTracker_noExtraCount
end

function Addon.HandleSlash(coolDownTracker_input)
    local coolDownTracker_trimmed = Private.Trim(coolDownTracker_input)
    local coolDownTracker_command, coolDownTracker_rest = string.match(coolDownTracker_trimmed, "^(%S+)%s*(.-)%s*$")
    coolDownTracker_command = Private.NormalizeIdentifier(coolDownTracker_command or "")

    if coolDownTracker_command == "" or coolDownTracker_command == "help" then
        Private.PrintUsage()
        return
    end

    if coolDownTracker_command == "status" then
        Private.PrintStatus()
        return
    end

    if coolDownTracker_command == "hide" then
        Addon.HideTracker()
        return
    end

    if coolDownTracker_command == "show" then
        if Private.IsEnabled() then
            Private.PrintChat("Tracker is already shown.")
            return
        end

        Private.SetHidden(false)
        Addon.Reconfigure()
        Private.PrintChat("Tracker shown.")
        return
    end

    if coolDownTracker_command == "lock" or coolDownTracker_command == "unlock" then
        local coolDownTracker_token = CoolDownTracker_ParseToggleToken(coolDownTracker_rest)
        if coolDownTracker_command == "unlock" and coolDownTracker_token == nil then
            coolDownTracker_token = false
        end
        if coolDownTracker_token == nil then
            Private.PrintChat(
                "Position lock is currently " .. (Private.IsPositionLocked() and "on." or "off.")
            )
            Private.PrintChat("Usage: /cdt lock <on|off|toggle>")
            return
        end

        local coolDownTracker_isLocked = CoolDownTracker_ResolveToggleToken(
            coolDownTracker_token,
            Private.IsPositionLocked()
        )
        if Private.IsPositionLocked() == coolDownTracker_isLocked then
            Private.PrintChat(
                "Position lock is already " .. (coolDownTracker_isLocked and "enabled." or "disabled.")
            )
            return
        end

        Private.SetPositionLocked(coolDownTracker_isLocked)
        if type(Private.ApplyAnchorMovableState) == "function" then
            Private.ApplyAnchorMovableState()
        end
        if type(Private.RefreshAnchorHoverLabel) == "function" then
            Private.RefreshAnchorHoverLabel()
        end
        Private.PrintChat(
            "Position lock " .. (coolDownTracker_isLocked and "enabled." or "disabled.")
        )
        return
    end

    if coolDownTracker_command == "selfonly" then
        local coolDownTracker_token = CoolDownTracker_ParseToggleToken(coolDownTracker_rest)
        if coolDownTracker_token == nil then
            Private.PrintChat(
                "Self-only scan is currently " .. (Private.IsSelfOnlyModeEnabled() and "on." or "off.")
            )
            Private.PrintChat("Usage: /cdt selfonly <on|off|toggle>")
            return
        end

        local coolDownTracker_enabled = CoolDownTracker_ResolveToggleToken(
            coolDownTracker_token,
            Private.IsSelfOnlyModeEnabled()
        )
        if Private.IsSelfOnlyModeEnabled() == coolDownTracker_enabled then
            Private.PrintChat(
                "Self-only scan is already " .. (coolDownTracker_enabled and "enabled." or "disabled.")
            )
            return
        end

        Private.SetSelfOnlyModeEnabled(coolDownTracker_enabled)
        Addon.Reconfigure()
        Private.PrintChat(
            "Self-only scan " .. (coolDownTracker_enabled and "enabled." or "disabled.")
        )
        return
    end

    if coolDownTracker_command == "track" then
        local coolDownTracker_identifier, coolDownTracker_token = CoolDownTracker_ParseTrackedToggleRequest(
            coolDownTracker_rest
        )
        if CoolDownTracker_HandleTrackedToggleCommand(
            coolDownTracker_identifier,
            coolDownTracker_token
        ) == true then
            return
        end
    end

    if coolDownTracker_command == "enable"
        or coolDownTracker_command == "disable"
        or coolDownTracker_command == "toggle" then
        if CoolDownTracker_HandleTrackedToggleCommand(
            coolDownTracker_rest,
            CoolDownTracker_ParseToggleToken(coolDownTracker_command)
        ) == true then
            return
        end
    end

    if coolDownTracker_command == "scale" or coolDownTracker_command == "size" then
        local coolDownTracker_scale = Private.ParseScaleValue(coolDownTracker_rest)
        if coolDownTracker_scale == nil then
            Private.PrintChat("Current scale: " .. Private.FormatScaleText(Private.GetSlotScale()))
            Private.PrintChat(
                "Usage: /cdt scale <0.25-2.0, 25%-200%> (default "
                    .. Private.FormatScaleText(Addon.DEFAULT_SLOT_SCALE)
                    .. ")"
            )
            return
        end

        coolDownTracker_scale = Private.SetSlotScale(coolDownTracker_scale)
        if Private.IsEnabled() then
            Private.EnsureWindows()
            Private.MarkAllSessionsDirty()
            Addon.UpdateAllVisuals(Private.GetNow(), true)
        end
        Private.PrintChat("Scale set to " .. Private.FormatScaleText(coolDownTracker_scale) .. ".")
        return
    end

    if coolDownTracker_command == "direction" or coolDownTracker_command == "dir" then
        local coolDownTracker_direction = Private.NormalizeBuildDirection(coolDownTracker_rest)
        if coolDownTracker_direction == nil then
            Private.PrintChat("Current direction: " .. Private.GetBuildDirection())
            Private.PrintChat("Usage: /cdt direction <right|left|up|down>")
            return
        end

        coolDownTracker_direction = Private.SetBuildDirection(coolDownTracker_direction)
        if Private.IsEnabled() then
            Private.EnsureWindows()
            Private.MarkAllSessionsDirty()
            Addon.UpdateAllVisuals(Private.GetNow(), true)
        end
        Private.PrintChat("Direction set to " .. coolDownTracker_direction .. ".")
        return
    end

    if coolDownTracker_command == "trigger" then
        local coolDownTracker_identifier, coolDownTracker_preferExtra = CoolDownTracker_ParseTriggerRequest(
            coolDownTracker_rest
        )
        if Private.Trim(coolDownTracker_identifier) == "" then
            CoolDownTracker_PrintTriggerUsage()
            CoolDownTracker_PrintTrackedChoices()
            return
        end
        if CoolDownTracker_IsTriggerAllIdentifier(coolDownTracker_identifier) then
            local coolDownTracker_triggeredCount, coolDownTracker_blockedActiveCount, coolDownTracker_noExtraCount =
                Addon.TriggerAll(coolDownTracker_preferExtra)
            if coolDownTracker_triggeredCount <= 0 then
                if coolDownTracker_preferExtra == true then
                    Private.PrintChat("No extra tracked abilities were triggered.")
                else
                    Private.PrintChat("No available tracked abilities were triggered.")
                end
            elseif coolDownTracker_triggeredCount == 1 then
                Private.PrintChat("Triggered 1" .. (coolDownTracker_preferExtra == true and " extra" or "") .. " ability.")
            else
                Private.PrintChat(
                    "Triggered "
                        .. tostring(coolDownTracker_triggeredCount)
                        .. (coolDownTracker_preferExtra == true and " extra" or "")
                        .. " abilities."
                )
            end
            if coolDownTracker_blockedActiveCount == 1 then
                Private.PrintChat("Skipped 1 active ability.")
            elseif coolDownTracker_blockedActiveCount > 1 then
                Private.PrintChat("Skipped " .. tostring(coolDownTracker_blockedActiveCount) .. " active abilities.")
            end
            if coolDownTracker_preferExtra == true and coolDownTracker_noExtraCount == 1 then
                Private.PrintChat("Skipped 1 ability with no extra slot available.")
            elseif coolDownTracker_preferExtra == true and coolDownTracker_noExtraCount > 1 then
                Private.PrintChat(
                    "Skipped " .. tostring(coolDownTracker_noExtraCount) .. " abilities with no extra slot available."
                )
            end
            return
        end
        local coolDownTracker_state, coolDownTracker_result, coolDownTracker_tracked = Addon.TriggerActivate(
            coolDownTracker_identifier,
            coolDownTracker_preferExtra
        )
        if coolDownTracker_result == "disabled" and coolDownTracker_tracked ~= nil then
            Private.PrintChat(
                "Tracking is disabled for " .. Private.GetAbilityDisplayName(coolDownTracker_tracked) .. "."
            )
            return
        end
        if coolDownTracker_result == "unavailable" and coolDownTracker_tracked ~= nil then
            Private.PrintChat(
                Private.GetAbilityDisplayName(coolDownTracker_tracked)
                    .. " is not available for this character's faction."
            )
            return
        end
        if coolDownTracker_result == "unknown" or coolDownTracker_state == nil then
            if Private.Trim(coolDownTracker_identifier) ~= "" then
                Private.PrintChat("Unknown tracked ability: " .. Private.Trim(coolDownTracker_identifier))
            end
            Private.PrintUsage()
            CoolDownTracker_PrintTrackedChoices()
            return
        end
        if coolDownTracker_result == "blocked_active" then
            Private.PrintChat(
                "Cannot spawn an extra "
                    .. Private.GetAbilityDisplayName(coolDownTracker_state.tracked)
                    .. " copy while one is Active."
            )
            return
        end
        Private.PrintChat("Triggered " .. Private.GetStateDisplayName(coolDownTracker_state) .. ".")
        return
    end

    Private.PrintUsage()
end
