local Addon = CoolDownTracker
local Private = Addon.Private

function Private.ClearScheduledUpdateState()
    Addon._nextUpdateAt = -1
    Addon._nextCountdownUpdateAt = -1
    Addon._nextTimedStateUpdateAt = -1
    Addon._anchorHoverHideAt = -1
end

function Private.IsDueAt(coolDownTracker_now, coolDownTracker_dueAt)
    local coolDownTracker_currentTime = tonumber(coolDownTracker_now)
    local coolDownTracker_dueTime = tonumber(coolDownTracker_dueAt)
    return coolDownTracker_currentTime ~= nil
        and coolDownTracker_dueTime ~= nil
        and coolDownTracker_dueTime >= 0
        and coolDownTracker_currentTime >= coolDownTracker_dueTime
end

local function CoolDownTracker_ShouldForceFullVisualPass(coolDownTracker_now)
    return Private.IsDueAt(coolDownTracker_now, Addon._nextCountdownUpdateAt)
        or Private.IsDueAt(coolDownTracker_now, Addon._nextTimedStateUpdateAt)
end

local function CoolDownTracker_GetDesiredEventConfigKey()
    return tostring(Addon._observesSelf == true)
        .. "|"
        .. tostring(Addon._observesGroup == true)
        .. "|"
        .. tostring(Addon._tracksGroupRoster == true)
end

local function CoolDownTracker_CanManageEvents()
    return type(SystemData) == "table"
        and type(SystemData.Events) == "table"
        and type(RegisterEventHandler) == "function"
        and type(UnregisterEventHandler) == "function"
end

function Private.SetUpdateHandlerEnabled(coolDownTracker_enabled)
    if type(SystemData) ~= "table"
        or type(SystemData.Events) ~= "table"
        or SystemData.Events.UPDATE_PROCESSED == nil
        or type(RegisterEventHandler) ~= "function"
        or type(UnregisterEventHandler) ~= "function" then
        Addon._updateHandlerRegistered = false
        return false
    end

    if coolDownTracker_enabled == true then
        if Addon._updateHandlerRegistered ~= true then
            RegisterEventHandler(SystemData.Events.UPDATE_PROCESSED, "CoolDownTracker.OnUpdateProcessed")
            Addon._updateHandlerRegistered = true
        end
        return true
    end

    if Addon._updateHandlerRegistered == true then
        UnregisterEventHandler(SystemData.Events.UPDATE_PROCESSED, "CoolDownTracker.OnUpdateProcessed")
        Addon._updateHandlerRegistered = false
    end

    return false
end

function Private.TryRegisterSlash()
    if Addon._slashRegistered == true or type(LibSlash) ~= "table" then
        return
    end

    local coolDownTracker_register = LibSlash.RegisterWSlashCmd
    if type(coolDownTracker_register) ~= "function" then
        coolDownTracker_register = LibSlash.RegisterSlashCmd
    end
    if type(coolDownTracker_register) ~= "function" then
        return
    end

    coolDownTracker_register("cdt", Addon.HandleSlash)
    coolDownTracker_register("cooldowntracker", Addon.HandleSlash)
    Addon._slashRegistered = true
end

function Private.RegisterFactionBootstrapEvents()
    if Addon._factionBootstrapEventsRegistered == true then
        return true
    end

    if not CoolDownTracker_CanManageEvents() then
        Addon._factionBootstrapEventsRegistered = false
        return false
    end

    local coolDownTracker_events = SystemData.Events
    local coolDownTracker_registered = false
    if coolDownTracker_events.ENTER_WORLD ~= nil then
        RegisterEventHandler(coolDownTracker_events.ENTER_WORLD, "CoolDownTracker.OnReloadOrEnterWorld")
        coolDownTracker_registered = true
    end
    if coolDownTracker_events.INTERFACE_RELOADED ~= nil then
        RegisterEventHandler(coolDownTracker_events.INTERFACE_RELOADED, "CoolDownTracker.OnReloadOrEnterWorld")
        coolDownTracker_registered = true
    end

    Addon._factionBootstrapEventsRegistered = coolDownTracker_registered == true
    return Addon._factionBootstrapEventsRegistered
end

function Private.UnregisterFactionBootstrapEvents()
    if Addon._factionBootstrapEventsRegistered ~= true then
        return
    end

    if CoolDownTracker_CanManageEvents() then
        local coolDownTracker_events = SystemData.Events
        if coolDownTracker_events.ENTER_WORLD ~= nil then
            UnregisterEventHandler(coolDownTracker_events.ENTER_WORLD, "CoolDownTracker.OnReloadOrEnterWorld")
        end
        if coolDownTracker_events.INTERFACE_RELOADED ~= nil then
            UnregisterEventHandler(coolDownTracker_events.INTERFACE_RELOADED, "CoolDownTracker.OnReloadOrEnterWorld")
        end
    end

    Addon._factionBootstrapEventsRegistered = false
end

function Private.GetNextScheduledUpdateAt(coolDownTracker_now)
    local coolDownTracker_currentTime = tonumber(coolDownTracker_now) or Private.GetNow()
    local coolDownTracker_nextAt = Private.GetPendingObservedRefreshDueAt(coolDownTracker_currentTime)
    local coolDownTracker_nextCountdownAt = Private.GetNextSharedCountdownUpdateAt(coolDownTracker_currentTime)
    local coolDownTracker_nextTimedStateAt = Private.GetNextTimedStateUpdateAt(coolDownTracker_currentTime)
    local coolDownTracker_nextAnchorHoverHideAt = nil
    if type(Private.GetAnchorHoverHideDueAt) == "function" then
        coolDownTracker_nextAnchorHoverHideAt = Private.GetAnchorHoverHideDueAt()
    end
    Addon._nextCountdownUpdateAt = tonumber(coolDownTracker_nextCountdownAt) or -1
    Addon._nextTimedStateUpdateAt = tonumber(coolDownTracker_nextTimedStateAt) or -1
    coolDownTracker_nextAt = Private.GetEarlierDueAt(
        coolDownTracker_nextAt,
        coolDownTracker_nextCountdownAt
    )
    coolDownTracker_nextAt = Private.GetEarlierDueAt(
        coolDownTracker_nextAt,
        coolDownTracker_nextTimedStateAt
    )
    coolDownTracker_nextAt = Private.GetEarlierDueAt(
        coolDownTracker_nextAt,
        coolDownTracker_nextAnchorHoverHideAt
    )

    return coolDownTracker_nextAt
end

function Private.RefreshUpdateHandlerState(coolDownTracker_now)
    if not Private.IsEnabled() then
        Private.ClearScheduledUpdateState()
        return Private.SetUpdateHandlerEnabled(false)
    end

    local coolDownTracker_currentTime = tonumber(coolDownTracker_now) or Private.GetNow()
    local coolDownTracker_nextAt = Private.GetNextScheduledUpdateAt(coolDownTracker_currentTime)
    if coolDownTracker_nextAt == nil then
        Private.ClearScheduledUpdateState()
        return Private.SetUpdateHandlerEnabled(false)
    end

    if coolDownTracker_nextAt < coolDownTracker_currentTime then
        coolDownTracker_nextAt = coolDownTracker_currentTime
    end

    Addon._nextUpdateAt = coolDownTracker_nextAt
    return Private.SetUpdateHandlerEnabled(true)
end

local function CoolDownTracker_AreRegisteredEventsCurrent()
    return Addon._eventsRegistered == true
        and Addon._registeredEventConfigKey == CoolDownTracker_GetDesiredEventConfigKey()
end

function Private.RegisterEvents()
    if type(SystemData) ~= "table"
        or type(SystemData.Events) ~= "table"
        or type(RegisterEventHandler) ~= "function" then
        return
    end

    if CoolDownTracker_AreRegisteredEventsCurrent() then
        Private.UnregisterFactionBootstrapEvents()
        return
    end

    if Addon._eventsRegistered == true then
        Private.UnregisterEvents()
    end
    Private.UnregisterFactionBootstrapEvents()

    local coolDownTracker_events = SystemData.Events
    if Addon._observesSelf == true and coolDownTracker_events.PLAYER_EFFECTS_UPDATED ~= nil then
        RegisterEventHandler(coolDownTracker_events.PLAYER_EFFECTS_UPDATED, "CoolDownTracker.OnPlayerEffectsUpdated")
    end
    if Addon._observesGroup == true and coolDownTracker_events.GROUP_EFFECTS_UPDATED ~= nil then
        RegisterEventHandler(coolDownTracker_events.GROUP_EFFECTS_UPDATED, "CoolDownTracker.OnGroupEffectsUpdated")
    end
    if Addon._tracksGroupRoster == true and coolDownTracker_events.GROUP_UPDATED ~= nil then
        RegisterEventHandler(coolDownTracker_events.GROUP_UPDATED, "CoolDownTracker.OnGroupUpdated")
    end
    if coolDownTracker_events.ENTER_WORLD ~= nil then
        RegisterEventHandler(coolDownTracker_events.ENTER_WORLD, "CoolDownTracker.OnReloadOrEnterWorld")
    end
    if coolDownTracker_events.INTERFACE_RELOADED ~= nil then
        RegisterEventHandler(coolDownTracker_events.INTERFACE_RELOADED, "CoolDownTracker.OnReloadOrEnterWorld")
    end

    Addon._eventsRegistered = true
    Addon._registeredEventConfigKey = CoolDownTracker_GetDesiredEventConfigKey()
end

function Private.UnregisterEvents()
    Private.UnregisterFactionBootstrapEvents()

    if Addon._eventsRegistered ~= true
        or type(SystemData) ~= "table"
        or type(SystemData.Events) ~= "table"
        or type(UnregisterEventHandler) ~= "function" then
        Addon._updateHandlerRegistered = false
        Addon._eventsRegistered = false
        Addon._registeredEventConfigKey = ""
        Private.ClearScheduledUpdateState()
        return
    end

    local coolDownTracker_events = SystemData.Events
    Private.ClearScheduledUpdateState()
    Private.SetUpdateHandlerEnabled(false)
    if coolDownTracker_events.PLAYER_EFFECTS_UPDATED ~= nil then
        UnregisterEventHandler(coolDownTracker_events.PLAYER_EFFECTS_UPDATED, "CoolDownTracker.OnPlayerEffectsUpdated")
    end
    if coolDownTracker_events.GROUP_EFFECTS_UPDATED ~= nil then
        UnregisterEventHandler(coolDownTracker_events.GROUP_EFFECTS_UPDATED, "CoolDownTracker.OnGroupEffectsUpdated")
    end
    if coolDownTracker_events.GROUP_UPDATED ~= nil then
        UnregisterEventHandler(coolDownTracker_events.GROUP_UPDATED, "CoolDownTracker.OnGroupUpdated")
    end
    if coolDownTracker_events.ENTER_WORLD ~= nil then
        UnregisterEventHandler(coolDownTracker_events.ENTER_WORLD, "CoolDownTracker.OnReloadOrEnterWorld")
    end
    if coolDownTracker_events.INTERFACE_RELOADED ~= nil then
        UnregisterEventHandler(coolDownTracker_events.INTERFACE_RELOADED, "CoolDownTracker.OnReloadOrEnterWorld")
    end

    Addon._eventsRegistered = false
    Addon._registeredEventConfigKey = ""
end

local CoolDownTracker_TryFinishInitialization

function Addon.HideTracker()
    if not Private.IsEnabled() then
        Private.PrintChat("Tracker is already hidden. Use /cdt show to show it again.")
        return
    end

    Private.SetHidden(true)
    Addon.Reconfigure()
    Private.PrintChat("Tracker hidden. Use /cdt show to show it again.")
end

function Addon.Reconfigure()
    if Addon._initializedAfterFactionKnown ~= true then
        if type(CoolDownTracker_TryFinishInitialization) == "function" then
            CoolDownTracker_TryFinishInitialization()
        end
        return
    end

    Private.RebuildTrackedLookups()
    if not Private.IsEnabled() then
        Private.UnregisterEvents()
        Private.ResetTransientObservedState()
        Private.HideAllWindows()
        Private.ClearScheduledUpdateState()
        Addon._pendingObservedRefresh = false
        Addon._pendingObservedRefreshRequestedAt = -1
        Addon._countdownCadenceAnchorAt = -1
        Addon._updateHandlerRegistered = false
        return
    end

    Private.RegisterEvents()
    Private.EnsureWindows()
    Addon.RefreshObservedEffects()
end

CoolDownTracker_TryFinishInitialization = function()
    if Private.IsPlayerFactionKnown() ~= true then
        Addon._initializedAfterFactionKnown = false
        Addon._waitingForPlayerFaction = true
        Private.UnregisterEvents()
        Private.HideAllWindows()
        Private.ClearTrackedRuntimeState()
        Private.ClearScheduledUpdateState()
        Addon._pendingObservedRefresh = false
        Addon._pendingObservedRefreshRequestedAt = -1
        Addon._countdownCadenceAnchorAt = -1
        Private.RegisterFactionBootstrapEvents()
        return false
    end

    Addon._initializedAfterFactionKnown = true
    Addon._waitingForPlayerFaction = false
    Private.UnregisterFactionBootstrapEvents()
    Private.TryRegisterSlash()
    Addon.Reconfigure()
    return true
end

function Addon.Initialize()
    Addon._initializedAfterFactionKnown = false
    CoolDownTracker_TryFinishInitialization()
end

function Addon.OnPlayerEffectsUpdated(coolDownTracker_updatedEffects, coolDownTracker_isFullList)
    if Addon._initializedAfterFactionKnown ~= true or not Private.IsEnabled() then
        return
    end

    if Private.ShouldQueueObservedRefreshForEffectUpdate(
        Private.GetSelfTargetType(),
        coolDownTracker_updatedEffects,
        coolDownTracker_isFullList
    ) then
        Private.RequestObservedRefresh()
    end
end

function Addon.OnGroupEffectsUpdated(coolDownTracker_updateType, coolDownTracker_updatedEffects, coolDownTracker_isFullList)
    if Addon._initializedAfterFactionKnown ~= true or not Private.IsEnabled() then
        return
    end

    local coolDownTracker_numericUpdateType = tonumber(coolDownTracker_updateType)
    if coolDownTracker_updateType ~= nil
        and coolDownTracker_numericUpdateType ~= nil
        and not Private.IsGroupTargetType(coolDownTracker_numericUpdateType) then
        return
    end

    if Private.ShouldQueueObservedRefreshForEffectUpdate(
        coolDownTracker_numericUpdateType,
        coolDownTracker_updatedEffects,
        coolDownTracker_isFullList
    ) then
        Private.RequestObservedRefresh()
    end
end

function Addon.OnGroupUpdated()
    if Addon._initializedAfterFactionKnown ~= true or not Private.IsEnabled() then
        return
    end

    if Private.RefreshGroupRosterCache(false) == true then
        Private.RequestObservedRefresh(true)
    end
end

function Addon.OnReloadOrEnterWorld()
    if Addon._initializedAfterFactionKnown ~= true then
        CoolDownTracker_TryFinishInitialization()
        return
    end

    if not Private.IsEnabled() then
        return
    end

    Addon.Reconfigure()
end

function Addon.OnUpdateProcessed()
    if Addon._initializedAfterFactionKnown ~= true then
        Private.ClearScheduledUpdateState()
        Private.SetUpdateHandlerEnabled(false)
        return
    end

    if not Private.IsEnabled() then
        Private.ClearScheduledUpdateState()
        Private.SetUpdateHandlerEnabled(false)
        return
    end

    local coolDownTracker_now = Private.GetNow()
    local coolDownTracker_nextAt = tonumber(Addon._nextUpdateAt) or -1
    if coolDownTracker_nextAt < 0 then
        Private.RefreshUpdateHandlerState(coolDownTracker_now)
        return
    end

    if coolDownTracker_now < coolDownTracker_nextAt then
        return
    end

    if type(Private.ProcessAnchorHoverHide) == "function" then
        Private.ProcessAnchorHoverHide(coolDownTracker_now)
    end

    Private.ProcessPendingObservedRefresh(coolDownTracker_now)

    local coolDownTracker_forceFullVisualPass = CoolDownTracker_ShouldForceFullVisualPass(coolDownTracker_now)
    if coolDownTracker_forceFullVisualPass ~= true
        and Private.HasDirtySessions() ~= true then
        Private.RefreshUpdateHandlerState(coolDownTracker_now)
        return
    end

    Addon.UpdateAllVisuals(coolDownTracker_now, coolDownTracker_forceFullVisualPass)
end
