<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">	
  <UiMod name="ObjectInspector" version="1.3" date="17/08/2010" >		
    <Author name="Medikage" email="medikage@gmail.com" />		
    <Description text="Used to view a table object in detail" />		
    <VersionSettings gameVersion="1.9.9" windowsVersion="1.0"/>		
    <Dependencies>			
      <Dependency name="LibSlash" />		
    </Dependencies>		
    <Files>			
      <File name="ObjectInspector.xml" />		
    </Files>		
    <SavedVariables/>		
    <OnInitialize>			
      <CallFunction name="ObjectInspector.Initialise" />		
    </OnInitialize>		
    <OnUpdate/>		
    <OnShutdown/>	
  </UiMod>
</ModuleFile>