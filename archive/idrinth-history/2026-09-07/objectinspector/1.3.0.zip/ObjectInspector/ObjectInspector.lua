ObjectInspector = {}
ObjectInspector.Debug = {}
ObjectInspector.Debug.Enabled = false
ObjectInspector.Debug.Level   = 1
ObjectInspector.Window = "ObjectInspector"
ObjectInspector.Version = 1.3
ObjectInspector.TemporaryObjectList = {}

function ObjectInspector.Initialise()
	ObjectInspector.DebugMsg(L"Entering Initialise",3)
	-- Register the slash command
	LibSlash.RegisterSlashCmd("obj", ObjectInspector.Slash)
	LibSlash.RegisterSlashCmd("objd", function(args) ObjectInspector.SlashDebug(args) end)
	-- Initialise the options window
	ObjectInspector.WindowInit()
	EA_ChatWindow.Print(L"Object Inspector is initialised. Type /obj to activate")
	ObjectInspector.DebugMsg(L"Leaving Initialise",3)
end

function ObjectInspector.DebugMsg(str,lvl)
	-- If debug is enabled and the priority of the message is high enough then send a debug message
	if ObjectInspector.Debug.Enabled and lvl <= ObjectInspector.Debug.Level then
		d(towstring(str))
	end
end

function ObjectInspector.SlashDebug(args)
	ObjectInspector.DebugMsg(L"Entering SlashDebug",3)
	local arg, argv = args:match("([a-z0-9]+)[ ]?(.*)")
	ObjectInspector.DebugMsg("SlashDebug: arg ["..arg.."] argv ["..argv.."]",2)
	if arg == nil then
		ObjectInspector.Debug.Enabled = not ObjectInspector.Debug.Enabled
		return
	end
	-- Set to true to display debug messaObjectInspector in the debug window (Note: type /debug in game to see this window and pObjectInspectors the button "Logs(off)")
	-- Set the debug level (4 = Update Ticks, 3 = Position, 2 = Setting values, 1 = Return values, 0 = Illegal flow catches)
	if arg == "on" then
		ObjectInspector.Debug.Enabled = true
	elseif arg == "off" then
		ObjectInspector.Debug.Enabled = false
	elseif arg == "1" then
		ObjectInspector.Debug.Enabled = true
		ObjectInspector.Debug.Level = 1
	elseif arg == "2" then
		ObjectInspector.Debug.Enabled = true
		ObjectInspector.Debug.Level = 2
	elseif arg == "3" then
		ObjectInspector.Debug.Enabled = true
		ObjectInspector.Debug.Level = 3
	elseif arg == "4" then
		ObjectInspector.Debug.Enabled = true
		ObjectInspector.Debug.Level = 4
	else
		ObjectInspector.DebugMsg("SlashDebug: Invalid Argument ["..arg.."]",0)
	end
	ObjectInspector.DebugMsg(L"Leaving SlashDebug",3)
end

function ObjectInspector.DisplayObject(obj, objName, targetDepth)
	ObjectInspector.DebugMsg(L"Entering DisplayObject",3)
	-- Inititalise the object list
	ObjectInspector.TemporaryObjectList = {}
	local currentDepth = 0
	local contents = TextEditBoxGetText(ObjectInspector.Window.."ObjectEditBox")
	-- Call the recursive algorithm to traverse through the object
	local objDetails = ObjectInspector.GetObjectDetails(obj, objName, targetDepth, currentDepth)
	-- Clear out the Object List between uses to free up memory
	ObjectInspector.TemporaryObjectList = {}
	TextEditBoxSetText(ObjectInspector.Window.."ObjectEditBox",contents..towstring(objDetails))
	ObjectInspector.DebugMsg(L"Leaving DisplayObject",3)
end

function ObjectInspector.GetObjectDetails(obj, objName, targetDepth, previousDepth)
	-- A recursive algorithm to traverse the object
	local contents = ""
	local currentDepth = previousDepth + 1
	-- Check the current depth against the targetDepth to see if we should continue traversing 
	-- and if the object is a table and then begin the traversal of the table
	if type(obj) == "table" and (targetDepth == 0 or targetDepth >= currentDepth) then 
		-- Check to see if we have already traversed this object and act accordingly
		if ObjectInspector.TemporaryObjectList[tostring(obj)] then
			return "Endless Loop detected on object ["..tostring(objName).."]\n"
		else
			ObjectInspector.TemporaryObjectList[tostring(obj)] = true
		end
		-- Retrieve the contents of the table via a recursive call.
		for k, a in pairs(obj) do
			contents = contents..ObjectInspector.GetObjectDetails(a, tostring(objName).."."..tostring(k), targetDepth, currentDepth)
		end
	else
		-- No more traversal required, add the value of the object to the name of the object
		contents = tostring(objName).." = "
		if type(obj) == "wstring" then
			contents = contents.."\""..tostring(obj).."\"\n"
		else
			contents = contents..tostring(obj).."\n"
		end
	end
	-- Return the obj value back to the parent call
	return contents
end


----------------------------------
---   Gui Specific Functions   ---
----------------------------------

function ObjectInspector.Slash()
	ObjectInspector.DebugMsg(L"Entering Slash",3)
	ObjectInspector.ShowWindow()
	ObjectInspector.DebugMsg(L"Leaving Slash",3)
end

function ObjectInspector.WindowInit()
	ObjectInspector.DebugMsg(L"Entering WindowInit",3)
	-- Create the window and then hide it.
	CreateWindow(ObjectInspector.Window, true)
	WindowSetShowing(ObjectInspector.Window,false)
	-- Apply text to the buttons so they are not blank.
	ButtonSetText(ObjectInspector.Window.."ClearButton", L"Clear")
	ButtonSetText(ObjectInspector.Window.."CloseButton", L"Close")
	ButtonSetText(ObjectInspector.Window.."InspectButton", L"Inspect")
	-- Apply text to the labels so they are not blank.
	LabelSetText(ObjectInspector.Window.."TitleBarText", L"Object Inspector v"..towstring(ObjectInspector.Version))
	ObjectInspector.DebugMsg(L"Leaving WindowInit",3)
end

function ObjectInspector.ShowWindow()
	ObjectInspector.DebugMsg(L"Entering ShowWindow",3)
	ObjectInspector.ClearObjects(nil,nil,nil)
	TextEditBoxSetText(ObjectInspector.Window.."DepthEditBox",towstring("0"))
	-- Show the window
	WindowSetShowing(ObjectInspector.Window,true)
	ObjectInspector.DebugMsg(L"Leaving ShowWindow",3)
end

function ObjectInspector.CloseWindow(flags, mouseX, mouseY)
	ObjectInspector.DebugMsg(L"Entering CloseWindow",3)
	-- When the button is clicked, hide the ObjectInspector window.
	WindowSetShowing(ObjectInspector.Window,false)
	ObjectInspector.DebugMsg(L"Leaving CloseWindow",3)
end

function ObjectInspector.ClearObjects(flags, mouseX, mouseY)
	ObjectInspector.DebugMsg(L"Entering ClearObjects",3)
	TextEditBoxSetText(ObjectInspector.Window.."ObjectEditBox", L"")
	ObjectInspector.DebugMsg(L"Leaving ClearObjects",3)
end

function ObjectInspector.InspectObject(flags, mouseX, mouseY)
	ObjectInspector.DebugMsg(L"Entering InspectObject",3)
	local object = TextEditBoxGetText(ObjectInspector.Window.."CommandEditBox")
	if not object then return end
	local targetDepth = tonumber(tostring(TextEditBoxGetText(ObjectInspector.Window.."DepthEditBox")))
	if not targetDepth then targetDepth = 0 end
	if string.len(tostring(object)) < 15 then
		SendChatText(L"/script ObjectInspector.DisplayObject("..object..L",\""..object..L"\","..towstring(targetDepth)..L")",L"")
	else
		SendChatText(L"/script ObjectInspector.DisplayObject("..object..L",\"O\","..towstring(targetDepth)..L")",L"")
	end
	ObjectInspector.DebugMsg(L"Leaving InspectObject",3)
end

function ObjectInspector.DepthPlus(flags, mouseX, mouseY)
	ObjectInspector.DebugMsg(L"Entering DepthPlus",3)
	local targetDepth = tonumber(tostring(TextEditBoxGetText(ObjectInspector.Window.."DepthEditBox")))
	if not targetDepth then targetDepth = 0 end
	TextEditBoxSetText(ObjectInspector.Window.."DepthEditBox",towstring(targetDepth + 1))
	ObjectInspector.DebugMsg(L"Leaving DepthPlus",3)
end

function ObjectInspector.DepthMinus(flags, mouseX, mouseY)
	ObjectInspector.DebugMsg(L"Entering DepthMinus",3)
	local targetDepth = tonumber(tostring(TextEditBoxGetText(ObjectInspector.Window.."DepthEditBox")))
	if not targetDepth or targetDepth == 0 then targetDepth = 1 end
	TextEditBoxSetText(ObjectInspector.Window.."DepthEditBox",towstring(targetDepth - 1))
	ObjectInspector.DebugMsg(L"Leaving DepthMinus",3)
end
