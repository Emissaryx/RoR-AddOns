<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <UiMod name="PetAssist" version="6.2" date="14/11/2024" >
    <Author name="SilverWF" email="silverwf@gmail.com" />
    <Description text="Forces Pet to Attack your target at every offensive spell cast and heel at every defensive spell cast.<br>Please read Readme.txt file" />
    <VersionSettings gameVersion="9.9.9" />
    <Dependencies>
      <Dependency name="LibSlash" />
    </Dependencies>
    <Files>
      <File name="PetAssist.lua" />
    </Files>
    <OnInitialize>
      <CallFunction name="PetAssist.Initialize" />
    </OnInitialize>
    <WARInfo>
      <Careers>
        <Career name="ENGINEER" />
        <Career name="SQUIG_HERDER" />
        <Career name="MAGUS" />
        <Career name="WHITE_LION" />
      </Careers>
    </WARInfo>
  </UiMod>
</ModuleFile>