<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <UiMod name="PetAssist" version="1.0" date="01/01/2010" >
    <Author name="SilverWF" email="silverwf@gmail.com" />
    <Description text="Forces Pet to Attack 'My Target' at every hostile spell cast. This addon didn't have any settings: just put your pet into the passive mode and enjoy." />
    <VersionSettings gameVersion="1.9.9" />
    <Dependencies>
      <Dependency name="LibSlash" />
    </Dependencies>
    <Files>
      <File name="PetAssist.lua" />
    </Files>
    <OnInitialize>
      <CallFunction name="PetAssist.Initialize" />
    </OnInitialize>
    <WARInfo>
      <Careers>
        <Career name="ENGINEER" />
        <Career name="SQUIG_HERDER" />
        <Career name="MAGUS" />
        <Career name="WHITE_LION" />
      </Careers>
    </WARInfo>
  </UiMod>
</ModuleFile>