<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
    <UiMod name="BankArkel" version="1.1" date="07/29/2025">
        <Author name="Arkel Anfall & Schlegler" email="" />
        <Description text="You can look at the bank of every char everywhere" />
	<VersionSettings gameVersion="1.4.8" windowsVersion="1.1" savedVariablesVersion="1.2" />
        <Dependencies>
	    	    <Dependency name="EA_UiDebugTools" />
            <Dependency name="EA_SettingsWindow" />
		        <Dependency name="EA_BackpackWindow" optional="false"	forceEnable="true"/>
         	  <Dependency name="EA_ChatSystem" />
            <Dependency name="EASystem_Utils" />
        </Dependencies>
        <Files>
           	<File name="BankArkel.xml" />
           	<File name="BankArkel.lua" />
        </Files>

        <SavedVariables>
            <SavedVariable name="BankArkel.db" global="true"/>
        </SavedVariables>
 
        <OnInitialize>
            <CallFunction name="BankArkel.Init" />
        </OnInitialize>
        <OnUpdate />

        <OnShutdown />
    </UiMod>
</ModuleFile>