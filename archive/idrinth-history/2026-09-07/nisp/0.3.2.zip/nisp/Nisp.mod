<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">    
  <UiMod name="NPC Item Sale Price" version="0.3.2" date="25/10/2008" >                 
    <Author name="Sniperumm" email="sniperumm@hotmail.com" />        
    <Description text="Adds the npc item sale price into tooltip" />        
    <VersionSettings gameVersion="1.9.9" />        
    <Dependencies>			    
      <Dependency name="EASystem_Tooltips"/>			    
      <Dependency name="EA_BackpackWindow"/>          
      <Dependency name="LibSlash" />          
      <Dependency name="EA_ChatWindow"/>        
    </Dependencies>                 
    <Files>            
      <File name="Source/Nisp.lua" />        
    </Files>                 
    <OnInitialize>            
      <CallFunction name="Nisp.Init" />        
    </OnInitialize>        
    <OnUpdate/>        
    <OnShutdown/>        
    <SavedVariables>          
      <SavedVariable name="Enabled" />          
      <SavedVariable name="DebugEnabled" />          
      <SavedVariable name="DumpItemsTable" />        
    </SavedVariables>    
  </UiMod>
</ModuleFile>