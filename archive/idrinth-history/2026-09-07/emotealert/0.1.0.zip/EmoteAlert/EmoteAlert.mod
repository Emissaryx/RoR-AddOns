<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
    <UiMod name="EmoteAlert" version="0.1.0" date="2026-03-05">
        <VersionSettings gameVersion="1.4.8" windowsVersion="0.1" />
        <Author name="Wholdar" />
        <Description text="Reprints emotes targeting you with a colored [EA] prefix and linked sender. Inspired by an idea from FixxerTV (fixxertv.live)." />
        <Files>
            <File name="EmoteAlert.lua" />
        </Files>
        <OnInitialize>
            <CallFunction name="EmoteAlert.Initialize" />
        </OnInitialize>
    </UiMod>
</ModuleFile>
