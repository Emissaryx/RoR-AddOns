EmoteAlert = EmoteAlert or {}

EmoteAlert.VERSION = EmoteAlert.VERSION or "0.1.0"
EmoteAlert.PREFIX_COLOR = EmoteAlert.PREFIX_COLOR or { 255, 200, 0 }
EmoteAlert.PLAYER_LINK_COLOR = EmoteAlert.PLAYER_LINK_COLOR or { 180, 230, 255 }

local EA = EmoteAlert

local function toWide(value)
    if value == nil then
        return towstring("")
    end
    if type(value) == "wstring" then
        return value
    end
    return towstring(tostring(value))
end

local function toNarrow(value)
    if value == nil then
        return ""
    end
    if type(value) == "wstring" and WStringToString then
        return WStringToString(value)
    end
    return tostring(value)
end

local function trim(text)
    return string.gsub(text or "", "^%s*(.-)%s*$", "%1")
end

local function sanitizeLinkText(text)
    return string.gsub(tostring(text or ""), "\"", "'")
end

local function clampByte(value)
    local number = tonumber(value) or 255
    if number < 0 then return 0 end
    if number > 255 then return 255 end
    return math.floor(number + 0.5)
end

local function escapePattern(text)
    return (text:gsub("([%(%)%.%%%+%-%*%?%[%]%^%$])", "%%%1"))
end

local function normalizePlayerName(nameInput)
    local text = toNarrow(nameInput)
    text = string.gsub(text, "%^%a,in", "")
    text = string.gsub(text, "%^%a", "")
    return trim(text)
end

local function getSelfName()
    if not (GameData and GameData.Player and GameData.Player.name) then
        return ""
    end
    return normalizePlayerName(GameData.Player.name)
end

local function extractActorName(line)
    local actor = string.match(line or "", "^([^%s]+)")
    if not actor then
        return nil
    end

    actor = string.gsub(actor, "^[%[%(%{\"']+", "")
    actor = string.gsub(actor, "[%]%)%}%.,:;!?\"']+$", "")
    actor = normalizePlayerName(actor)
    if actor == "" then
        return nil
    end

    if string.lower(actor) == "you" then
        return nil
    end

    return actor
end

local function lineTargetsSelf(line, selfName)
    if not line or line == "" then
        return false
    end

    if not selfName or selfName == "" then
        return false
    end

    local lowerLine = string.lower(line)
    if string.match(lowerLine, "^you[%s%p]") then
        return false
    end

    local lowerName = string.lower(selfName)
    local namePattern = "%f[%w]" .. escapePattern(lowerName) .. "%f[%W]"
    return string.find(lowerLine, namePattern) ~= nil
end

local function buildPrefixRaw()
    local color = EA.PREFIX_COLOR or { 255, 200, 0 }
    local r = clampByte(color[1] or color.r)
    local g = clampByte(color[2] or color.g)
    local b = clampByte(color[3] or color.b)
    local coloredText = string.format("<LINK data=\"0\" color=\"%d,%d,%d\" text=\"EA\">", r, g, b)
    return "[" .. coloredText .. "] "
end

local function buildPlayerLink(actorName)
    local color = EA.PLAYER_LINK_COLOR or { 180, 230, 255 }
    local r = clampByte(color[1] or color.r)
    local g = clampByte(color[2] or color.g)
    local b = clampByte(color[3] or color.b)
    local safeActor = sanitizeLinkText(actorName)
    local display = sanitizeLinkText("@" .. actorName)
    return string.format("<LINK data=\"PLAYER:%s\" color=\"%d,%d,%d\" text=\"%s\">", safeActor, r, g, b, display)
end

local function rewriteActorWithLink(line, actorName)
    if not actorName or actorName == "" then
        return line
    end

    local actorPattern = "^" .. escapePattern(actorName) .. "(%f[%W])"
    local actorLink = buildPlayerLink(actorName)
    local updated, replacements = string.gsub(line, actorPattern, actorLink .. "%1", 1)
    if replacements > 0 then
        return updated
    end

    updated, replacements = string.gsub(line, "^" .. escapePattern(actorName), actorLink, 1)
    if replacements > 0 then
        return updated
    end

    return line
end

local function printChat(message)
    if EA_ChatWindow and EA_ChatWindow.Print then
        EA_ChatWindow.Print(toWide(message))
        return
    end
    if TextLogAddEntry and SystemData and SystemData.ChatLogFilters then
        TextLogAddEntry("Chat", SystemData.ChatLogFilters.SAY or 0, toWide(message))
    end
end

function EmoteAlert.OnChatText(updateType, filterType)
    if updateType ~= SystemData.TextLogUpdate.ADDED then return end
    if filterType ~= SystemData.ChatLogFilters.EMOTE then return end

    local count = TextLogGetNumEntries("Chat")
    if not count or count <= 0 then return end

    local _, _, rawText = TextLogGetEntry("Chat", count - 1)
    if not rawText or rawText == "" then return end

    local line = toNarrow(rawText)
    local selfName = getSelfName()
    if not lineTargetsSelf(line, selfName) then
        return
    end

    local actorName = extractActorName(line)
    if actorName and selfName ~= "" and string.lower(actorName) == string.lower(selfName) then
        return
    end

    local linkedLine = rewriteActorWithLink(line, actorName)
    printChat(buildPrefixRaw() .. linkedLine)
end

function EmoteAlert.Initialize()
    if not (RegisterEventHandler and TextLogGetUpdateEventId) then
        return
    end
    RegisterEventHandler(TextLogGetUpdateEventId("Chat"), "EmoteAlert.OnChatText")
end
