EmoteAlert = EmoteAlert or {}

EmoteAlert.VERSION = EmoteAlert.VERSION or "0.2.0"
EmoteAlert.PREFIX_COLOR = EmoteAlert.PREFIX_COLOR or { 255, 200, 0 }
EmoteAlert.PLAYER_LINK_COLOR = EmoteAlert.PLAYER_LINK_COLOR or { 180, 230, 255 }
EmoteAlert.ALERT_THROTTLE_SECONDS = EmoteAlert.ALERT_THROTTLE_SECONDS or 5

local EA = EmoteAlert

EA.DEFAULT_SOUND_KEY = EA.DEFAULT_SOUND_KEY or "PUBLIC_TOME_UNLOCKED"
-- Keep this curated list aligned with the player-facing sound choices from MegaPhonePlusPlus.
EA.SOUND_OPTIONS = EA.SOUND_OPTIONS or {
    { key = "ACTION_FAILED", name = "Action Failed" },
    { key = "ADVANCE_RANK", name = "Advance Rank" },
    { key = "ADVANCE_TIER", name = "Advance Tier" },
    { key = "APOTHECARY_ADD_FAILED", name = "Apothecary Add Failed" },
    { key = "APOTHECARY_BREW_STARTED", name = "Apothecary Brew Started" },
    { key = "APOTHECARY_CONTAINER_ADDED", name = "Apothecary Container Added" },
    { key = "APOTHECARY_DETERMINENT_ADDED", name = "Apothecary Determinent Added" },
    { key = "APOTHECARY_FAILED", name = "Apothecary Failed" },
    { key = "APOTHECARY_ITEM_REMOVED", name = "Apothecary Item Removed" },
    { key = "APOTHECARY_RESOURCE_ADDED", name = "Apothecary Resource Added" },
    { key = "BETA_WARNING", name = "Beta Warning" },
    { key = "BUTTON_CLICK", name = "Button Click" },
    { key = "BUTTON_OVER", name = "Button Over" },
    { key = "CULTIVATING_HARVEST_CROP", name = "Cultivating Harvest Crop" },
    { key = "CULTIVATING_NUTRIENT_ADDED", name = "Cultivating Nutrient Added" },
    { key = "CULTIVATING_SEED_ADDED", name = "Cultivating Seed Added" },
    { key = "CULTIVATING_SOIL_ADDED", name = "Cultivating Soil Added" },
    { key = "CULTIVATING_WATER_ADDED", name = "Cultivating Water Added" },
    { key = "ICON_CLEAR", name = "Icon Clear" },
    { key = "ICON_DROP", name = "Icon Drop" },
    { key = "ICON_PICKUP", name = "Icon Pickup" },
    { key = "LOOT_MONEY", name = "Loot Money" },
    { key = "MONETARY_TRANSACTION", name = "Monetary Transaction" },
    { key = "OBJECTIVE_CAPTURE", name = "Objective Capture" },
    { key = "OBJECTIVE_LOSE", name = "Objective Lose" },
    { key = "PREGAME_PLAY_GAME_BUTTON", name = "Pregame Play Game Button" },
    { key = "PUBLIC_TOME_UNLOCKED", name = "Public Tome Unlocked" },
    { key = "QUEST_ABANDONED", name = "Quest Abandoned" },
    { key = "QUEST_ACCEPTED", name = "Quest Accepted" },
    { key = "QUEST_COMPLETED", name = "Quest Completed" },
    { key = "QUEST_OBJECTIVES_COMPLETED", name = "Quest Objective Complete" },
    { key = "RESPAWN", name = "Respawn" },
    { key = "RVR_FLAG_OFF", name = "RvR Flag Off" },
    { key = "RVR_FLAG_ON", name = "RvR Flag On" },
    { key = "TARGET_DESELECT", name = "Target Deselect" },
    { key = "TARGET_SELECT", name = "Target Select" },
    { key = "TOME_TURN_PAGE", name = "Tome Turn Page" },
    { key = "WINDOW_CLOSE", name = "Window Close" },
    { key = "WINDOW_OPEN", name = "Window Open" },
    { key = "CLOSE_WORLD_MAP", name = "World Map Close" },
    { key = "OPEN_WORLD_MAP", name = "World Map Open" },
}

local function getDefaultSoundKey()
    return tostring(EA.DEFAULT_SOUND_KEY or "PUBLIC_TOME_UNLOCKED")
end

local function ensureSettings()
    if not EA.Settings then
        EA.Settings = {}
    end
    if EA.Settings.SoundEnabled == nil then
        EA.Settings.SoundEnabled = false
    end
    if EA.Settings.OnscreenEnabled == nil then
        EA.Settings.OnscreenEnabled = false
    end
    if type(EA.Settings.SoundKey) ~= "string" or EA.Settings.SoundKey == "" then
        EA.Settings.SoundKey = getDefaultSoundKey()
    end
    EA.Settings.SoundEnabled = not not EA.Settings.SoundEnabled
    EA.Settings.OnscreenEnabled = not not EA.Settings.OnscreenEnabled
end

local function toWide(value)
    if value == nil then
        return towstring("")
    end
    if type(value) == "wstring" then
        return value
    end
    return towstring(tostring(value))
end

local function toNarrow(value)
    if value == nil then
        return ""
    end
    if type(value) == "wstring" and WStringToString then
        return WStringToString(value)
    end
    return tostring(value)
end

local function trim(text)
    return string.gsub(text or "", "^%s*(.-)%s*$", "%1")
end

local function normalizeSoundToken(text)
    local normalized = string.lower(trim(tostring(text or "")))
    normalized = string.gsub(normalized, "_", " ")
    normalized = string.gsub(normalized, "[^%w]+", " ")
    return trim(normalized)
end

local function getSoundOptions()
    return EA.SOUND_OPTIONS or {}
end

local function getSoundOptionAt(index)
    local options = getSoundOptions()
    return options[index]
end

local function findSoundOptionByKey(soundKey)
    local options = getSoundOptions()
    for index = 1, #options do
        local option = options[index]
        if option and option.key == soundKey then
            return option, index
        end
    end
    return nil, nil
end

local function getConfiguredSoundOption()
    local soundKey = EA.Settings and EA.Settings.SoundKey or nil
    local option, index = nil, nil
    if type(soundKey) == "string" and soundKey ~= "" then
        option, index = findSoundOptionByKey(soundKey)
    end
    if option ~= nil then
        return option, index
    end

    soundKey = getDefaultSoundKey()
    if EA.Settings then
        EA.Settings.SoundKey = soundKey
    end
    return findSoundOptionByKey(soundKey)
end

local function resolveSoundSelection(choiceText)
    local normalizedChoice = normalizeSoundToken(choiceText)
    if normalizedChoice == "" then
        return nil
    end

    local optionIndex = tonumber(normalizedChoice)
    if optionIndex ~= nil then
        optionIndex = math.floor(optionIndex)
        if optionIndex >= 1 then
            return getSoundOptionAt(optionIndex)
        end
    end

    local options = getSoundOptions()
    for index = 1, #options do
        local option = options[index]
        if option and option.key then
            if normalizedChoice == normalizeSoundToken(option.key) or normalizedChoice == normalizeSoundToken(option.name) then
                return option
            end
        end
    end
    return nil
end

local function sanitizeLinkText(text)
    return string.gsub(tostring(text or ""), "\"", "'")
end

local function clampByte(value)
    local number = tonumber(value) or 255
    if number < 0 then return 0 end
    if number > 255 then return 255 end
    return math.floor(number + 0.5)
end

local function escapePattern(text)
    return (text:gsub("([%(%)%.%%%+%-%*%?%[%]%^%$])", "%%%1"))
end

local function normalizePlayerName(nameInput)
    local text = toNarrow(nameInput)
    text = string.gsub(text, "%^%a,in", "")
    text = string.gsub(text, "%^%a", "")
    return trim(text)
end

local function getSelfName()
    if not (GameData and GameData.Player and GameData.Player.name) then
        return ""
    end
    return normalizePlayerName(GameData.Player.name)
end

local function extractActorName(line)
    local actor = string.match(line or "", "^([^%s]+)")
    if not actor then
        return nil
    end

    actor = string.gsub(actor, "^[%[%(%{\"']+", "")
    actor = string.gsub(actor, "[%]%)%}%.,:;!?\"']+$", "")
    actor = normalizePlayerName(actor)
    if actor == "" then
        return nil
    end

    if string.lower(actor) == "you" then
        return nil
    end

    return actor
end

local function lineTargetsSelf(line, selfName)
    if not line or line == "" then
        return false
    end

    if not selfName or selfName == "" then
        return false
    end

    local lowerLine = string.lower(line)
    if string.match(lowerLine, "^you[%s%p]") then
        return false
    end

    local lowerName = string.lower(selfName)
    local namePattern = "%f[%w]" .. escapePattern(lowerName) .. "%f[%W]"
    return string.find(lowerLine, namePattern) ~= nil
end

local function buildPrefixRaw()
    local color = EA.PREFIX_COLOR or { 255, 200, 0 }
    local r = clampByte(color[1] or color.r)
    local g = clampByte(color[2] or color.g)
    local b = clampByte(color[3] or color.b)
    local coloredText = string.format("<LINK data=\"0\" color=\"%d,%d,%d\" text=\"EA\">", r, g, b)
    return "[" .. coloredText .. "] "
end

local function buildPlayerLink(actorName)
    local color = EA.PLAYER_LINK_COLOR or { 180, 230, 255 }
    local r = clampByte(color[1] or color.r)
    local g = clampByte(color[2] or color.g)
    local b = clampByte(color[3] or color.b)
    local safeActor = sanitizeLinkText(actorName)
    local display = sanitizeLinkText("@" .. actorName)
    return string.format("<LINK data=\"PLAYER:%s\" color=\"%d,%d,%d\" text=\"%s\">", safeActor, r, g, b, display)
end

local function rewriteActorWithLink(line, actorName)
    if not actorName or actorName == "" then
        return line
    end

    local actorPattern = "^" .. escapePattern(actorName) .. "(%f[%W])"
    local actorLink = buildPlayerLink(actorName)
    local updated, replacements = string.gsub(line, actorPattern, actorLink .. "%1", 1)
    if replacements > 0 then
        return updated
    end

    updated, replacements = string.gsub(line, "^" .. escapePattern(actorName), actorLink, 1)
    if replacements > 0 then
        return updated
    end

    return line
end

local function printChat(message)
    if EA_ChatWindow and EA_ChatWindow.Print then
        EA_ChatWindow.Print(toWide(message))
        return
    end
    if TextLogAddEntry and SystemData and SystemData.ChatLogFilters then
        TextLogAddEntry("Chat", SystemData.ChatLogFilters.SAY or 0, toWide(message))
    end
end

local function printStatusMessage(message)
    printChat(buildPrefixRaw() .. tostring(message or ""))
end

local function getSettingState(enabled)
    if enabled then
        return "ON"
    end
    return "OFF"
end

local function buildAlertSettingStatus(label, enabled)
    return tostring(label or "") .. " alert is " .. getSettingState(enabled) .. "."
end

local function buildCurrentSoundStatus()
    local option, soundIndex = getConfiguredSoundOption()
    local soundName = "Public Tome Unlocked"
    if option and option.name then
        soundName = option.name
    end
    if soundIndex ~= nil then
        return "Current sound: [" .. tostring(soundIndex) .. "] " .. soundName .. "."
    end
    return "Current sound: " .. soundName .. "."
end

local function buildSoundStatusMessage()
    return buildAlertSettingStatus("Sound", EA.Settings.SoundEnabled) .. " " .. buildCurrentSoundStatus()
end

local TEST_CHAT_ACTOR = "TestPlayer"

local function applyToggleSetting(settingName, value)
    if value == "toggle" or value == "tog" then
        EA.Settings[settingName] = not EA.Settings[settingName]
        return true
    end

    if value == "on" or value == "1" or value == "true" or value == "yes" then
        EA.Settings[settingName] = true
        return true
    end

    if value == "off" or value == "0" or value == "false" or value == "no" then
        EA.Settings[settingName] = false
        return true
    end

    return false
end

local function showSettingsStatus()
    ensureSettings()
    printStatusMessage(
        "Version " .. tostring(EA.VERSION or "?")
        .. " | " .. buildSoundStatusMessage()
        .. " | " .. buildAlertSettingStatus("Onscreen", EA.Settings.OnscreenEnabled)
        .. " | Help: /ealert help."
    )
end

local function showSlashHelp()
    printStatusMessage("Commands: /emotealert status|help | sound on|off|toggle | sound list|test [number|name]|set <number|name>")
    printStatusMessage("Commands: /emotealert onscreen on|off|toggle")
    printStatusMessage("Tests: /emotealert test sound [number|name]|onscreen|chat|all")
end

local function getSoundIdForKey(soundKey)
    if not (GameData and GameData.Sound) then
        return nil
    end
    if soundKey == nil or soundKey == "" then
        return nil
    end
    return GameData.Sound[soundKey]
end

local function getConfiguredSoundId()
    local option = getConfiguredSoundOption()
    local soundId = nil
    if option and option.key then
        soundId = getSoundIdForKey(option.key)
    end
    if soundId ~= nil then
        return soundId
    end
    return getSoundIdForKey(getDefaultSoundKey())
end

local function getPreviewSoundDetails(choiceText)
    local option = resolveSoundSelection(choiceText)
    if option == nil or option.key == nil then
        return nil, nil, nil
    end

    local _, optionIndex = findSoundOptionByKey(option.key)
    return option, optionIndex, getSoundIdForKey(option.key)
end

local function buildSoundTestMessage(option, optionIndex, soundId)
    local message = "Sound test: "
    if optionIndex ~= nil then
        message = message .. "[" .. tostring(optionIndex) .. "] "
    end
    if option and option.name then
        message = message .. option.name
    else
        message = message .. "Unknown"
    end
    if soundId ~= nil then
        message = message .. " (id " .. tostring(soundId) .. ")"
    end
    return message .. "."
end

local function getDefaultAlertType()
    if not (SystemData and SystemData.AlertText and SystemData.AlertText.Types) then
        return nil
    end
    return SystemData.AlertText.Types.QUEST_END or SystemData.AlertText.Types.DEFAULT
end

local function getCurrentAlertTime()
    if not GetGameTime then
        return nil
    end
    return tonumber(GetGameTime())
end

local function recordAlertTime(kind, now)
    if now == nil or kind == nil then
        return
    end
    if not EA.AlertTimes then
        EA.AlertTimes = {}
    end
    EA.AlertTimes[kind] = now
end

local function isAlertThrottled(kind, force)
    if force then
        return false, nil
    end

    local now = getCurrentAlertTime()
    if now == nil then
        return false, nil
    end

    local lastTime = nil
    if EA.AlertTimes then
        lastTime = EA.AlertTimes[kind]
    end

    local throttleSeconds = tonumber(EA.ALERT_THROTTLE_SECONDS) or 0
    if lastTime ~= nil and throttleSeconds > 0 and (now - lastTime) < throttleSeconds then
        return true, now
    end

    return false, now
end

local function showSoundChoices()
    local options = getSoundOptions()
    local currentOption = getConfiguredSoundOption()
    local currentKey = currentOption and currentOption.key or nil
    local line = ""
    local itemsOnLine = 0

    printStatusMessage("Available sounds: /ealert sound set <number|name> | /ealert sound test [number|name] previews without saving")

    for index = 1, #options do
        local option = options[index]
        if option and option.name then
            local label = "[" .. tostring(index) .. "] " .. option.name
            if option.key == currentKey then
                label = label .. " (current)"
            end

            -- Split the numbered list into readable chat-sized chunks.
            if line == "" then
                line = label
            else
                line = line .. " | " .. label
            end
            itemsOnLine = itemsOnLine + 1

            if itemsOnLine >= 3 or index == #options then
                printStatusMessage(line)
                line = ""
                itemsOnLine = 0
            end
        end
    end
end

local function applySoundSelection(choiceText)
    local option = resolveSoundSelection(choiceText)
    if option == nil then
        return false
    end

    EA.Settings.SoundKey = option.key
    return true
end

local function playAlertSound(force, soundId)
    ensureSettings()
    if not (LibSlash and LibSlash.RegisterSlashCmd) then
        return false
    end
    if not force and not EA.Settings.SoundEnabled then
        return false
    end
    if not PlaySound then
        return false
    end

    soundId = soundId or getConfiguredSoundId()
    if soundId == nil then
        return false
    end

    local throttled, now = isAlertThrottled("sound", force)
    if throttled then
        return false
    end

    PlaySound(soundId)
    recordAlertTime("sound", now)
    return true
end

local function showOnscreenMessage(message, force)
    ensureSettings()
    if not (LibSlash and LibSlash.RegisterSlashCmd) then
        return false
    end
    if not force and not EA.Settings.OnscreenEnabled then
        return false
    end
    if not (AlertTextWindow and AlertTextWindow.AddLine) then
        return false
    end

    local alertType = getDefaultAlertType()
    if alertType == nil then
        return false
    end

    local throttled, now = isAlertThrottled("onscreen", force)
    if throttled then
        return false
    end

    AlertTextWindow.AddLine(alertType, toWide(message))
    recordAlertTime("onscreen", now)
    return true
end

local function buildTestExampleLine()
    local selfName = getSelfName()
    local targetName = selfName
    if targetName == "" then
        targetName = "you"
    end

    return TEST_CHAT_ACTOR .. " waves at " .. targetName .. "."
end

local function showTestChatExample()
    local line = buildTestExampleLine()
    local linkedLine = rewriteActorWithLink(line, TEST_CHAT_ACTOR)
    printChat(buildPrefixRaw() .. linkedLine)
    return true
end

function EmoteAlert.SlashHandler(args)
    ensureSettings()

    local input = trim(toNarrow(args))
    local lower = string.lower(input)

    if lower == "" or lower == "status" then
        showSettingsStatus()
        return
    end

    if lower == "help" or lower == "?" or lower == "h" then
        showSlashHelp()
        return
    end

    local command, value = string.match(lower, "^(%S+)%s*(.-)$")
    if not command then
        showSlashHelp()
        return
    end

    if command == "sound" then
        if value == "" then
            printStatusMessage(buildSoundStatusMessage())
            return
        end

        if value == "list" or value == "ls" then
            showSoundChoices()
            return
        end

        local soundCommand, soundValue = string.match(value, "^(%S+)%s*(.-)$")

        if soundCommand == "test" or soundCommand == "preview" then
            if soundValue == "" then
                local option, optionIndex = getConfiguredSoundOption()
                local configuredSoundId = getConfiguredSoundId()
                if playAlertSound(true, configuredSoundId) then
                    printStatusMessage(buildSoundTestMessage(option, optionIndex, configuredSoundId))
                end
                return
            end

            local previewOption, previewOptionIndex, previewSoundId = getPreviewSoundDetails(soundValue)
            if previewSoundId == nil then
                printStatusMessage("Usage: /emotealert sound on|off|toggle|list|test [number|name]|set <number|name>")
                return
            end
            if playAlertSound(true, previewSoundId) then
                printStatusMessage(buildSoundTestMessage(previewOption, previewOptionIndex, previewSoundId))
            end
            return
        end

        if applyToggleSetting("SoundEnabled", value) then
            printStatusMessage(buildSoundStatusMessage())
            return
        end

        local soundChoice = value
        if soundCommand == "set" or soundCommand == "use" or soundCommand == "select" then
            soundChoice = soundValue
        end

        if not applySoundSelection(soundChoice) then
            printStatusMessage("Usage: /emotealert sound on|off|toggle|list|test [number|name]|set <number|name>")
            return
        end
        printStatusMessage(buildSoundStatusMessage())
        return
    end

    if command == "onscreen" or command == "screen" or command == "message" then
        if value == "" then
            printStatusMessage(buildAlertSettingStatus("Onscreen", EA.Settings.OnscreenEnabled))
            return
        end
        if not applyToggleSetting("OnscreenEnabled", value) then
            printStatusMessage("Usage: /emotealert onscreen on|off|toggle")
            return
        end
        printStatusMessage(buildAlertSettingStatus("Onscreen", EA.Settings.OnscreenEnabled))
        return
    end

    if command == "test" then
        local testCommand, testValue = string.match(value, "^(%S+)%s*(.-)$")

        if testCommand == "sound" then
            if testValue == "" then
                local option, optionIndex = getConfiguredSoundOption()
                local configuredSoundId = getConfiguredSoundId()
                if playAlertSound(true, configuredSoundId) then
                    printStatusMessage(buildSoundTestMessage(option, optionIndex, configuredSoundId))
                end
                return
            end

            local previewOption, previewOptionIndex, previewSoundId = getPreviewSoundDetails(testValue)
            if previewSoundId == nil then
                printStatusMessage("Usage: /emotealert test sound [number|name]|onscreen|chat|all")
                return
            end
            if playAlertSound(true, previewSoundId) then
                printStatusMessage(buildSoundTestMessage(previewOption, previewOptionIndex, previewSoundId))
            end
            return
        end
        if value == "onscreen" or value == "screen" or value == "message" then
            showOnscreenMessage(buildTestExampleLine(), true)
            return
        end
        if value == "chat" then
            showTestChatExample()
            return
        end
        if value == "all" then
            playAlertSound(true)
            showOnscreenMessage(buildTestExampleLine(), true)
            showTestChatExample()
            return
        end
        printStatusMessage("Usage: /emotealert test sound [number|name]|onscreen|chat|all")
        return
    end

    showSlashHelp()
end

function EmoteAlert.OnChatText(updateType, filterType)
    if updateType ~= SystemData.TextLogUpdate.ADDED then return end
    if filterType ~= SystemData.ChatLogFilters.EMOTE then return end

    local count = TextLogGetNumEntries("Chat")
    if not count or count <= 0 then return end

    local _, _, rawText = TextLogGetEntry("Chat", count - 1)
    if not rawText or rawText == "" then return end

    local line = toNarrow(rawText)
    local selfName = getSelfName()
    if not lineTargetsSelf(line, selfName) then
        return
    end

    local actorName = extractActorName(line)
    if actorName and selfName ~= "" and string.lower(actorName) == string.lower(selfName) then
        return
    end

    local linkedLine = rewriteActorWithLink(line, actorName)
    printChat(buildPrefixRaw() .. linkedLine)
    playAlertSound()
    showOnscreenMessage(line)
end

function EmoteAlert.Initialize()
    ensureSettings()

    if not (RegisterEventHandler and TextLogGetUpdateEventId) then
        return
    end

    RegisterEventHandler(TextLogGetUpdateEventId("Chat"), "EmoteAlert.OnChatText")

    if LibSlash and LibSlash.RegisterSlashCmd then
        LibSlash.RegisterSlashCmd("emotealert", EmoteAlert.SlashHandler)
        LibSlash.RegisterSlashCmd("ealert", EmoteAlert.SlashHandler)
    end
end
