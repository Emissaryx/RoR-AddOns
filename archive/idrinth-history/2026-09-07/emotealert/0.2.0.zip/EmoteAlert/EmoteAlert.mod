<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
    <UiMod name="EmoteAlert" version="0.2.0" date="2026-03-21">
        <VersionSettings gameVersion="1.4.8" windowsVersion="0.1" savedVariablesVersion="1.0" />
        <Author name="Wholdar" />
        <Description text="Reprints emotes targeting you with a colored [EA] prefix and linked sender, with optional selectable sound and onscreen alerts." />
        <Dependencies>
            <Dependency name="LibSlash" optional="true" />
        </Dependencies>
        <Files>
            <File name="EmoteAlert.lua" />
        </Files>
        <SavedVariables>
            <SavedVariable name="EmoteAlert.Settings" />
        </SavedVariables>
        <OnInitialize>
            <CallFunction name="EmoteAlert.Initialize" />
        </OnInitialize>
    </UiMod>
</ModuleFile>
