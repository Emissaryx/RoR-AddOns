local VERSION = L"1.1"

local EnableGuildCheckToggle = false
local EnableModCheckToggle = false

local ORDER_BY_NAME = 1
local ORDER_BY_HITS = 2
local ORDER_DESC = 1
local ORDER_ASC = 2

PieTracker = {}
PieTracker.AbilityList = {
		  [15149] = "Halfling Pie^n"
		, [15150] = "Halfling Pie^n"
		, [15161] = "Custard Pie^n"
		, [15176] = "Custard Pie^n"
		, [15193] = "Fling Tentacle Pie^n"
		, [22912] = "Fling Pie^n"
                         }
PieTracker.Debug = {}
PieTracker.Debug.Enabled = false
PieTracker.Debug.Level   = 0
PieTracker.Enabled = true
PieTracker.SelectedTarget = ""
PieTracker.Window = "PieTracker"
PieTracker.HitCountsOrdered = {}

function PieTracker.Initialise()
	PieTracker.DebugMsg(L"Entering Initialise",3)
	-- Check to see if any options are saved on the users profile. If not set default values.
	if not PieTracker.Settings then
		PieTracker.Settings = {}
		PieTracker.Settings.Enabled   = true
		PieTracker.Settings.GuildNote = false
		PieTracker.Settings.HitCounts = {}
		PieTracker.Settings.GrudgeTarget = ""
		PieTracker.Settings.OrderType = ORDER_BY_HITS
		PieTracker.Settings.OrderDirection = ORDER_DESC
	end

	PieTracker.Enabled = PieTracker.Settings.Enabled

	if PieTracker.Enabled then
		PieTracker.RegisterEvents()
	end

	-- Register the slash command.
	LibSlash.RegisterSlashCmd("pie", PieTracker.Slash)
	LibSlash.RegisterSlashCmd("pied", function(args) PieTracker.SlashDebug(args) end)

	--Initialise the options window
	PieTracker.WindowInit()

	local msg = ""
	if PieTracker.Enabled then
		msg = L"Pie Tracker is enabled. Type /pie for options"
	else
		msg = L"Pie Tracker is disabled. Type /pie for options"
	end
	EA_ChatWindow.Print(msg)
	PieTracker.DebugMsg(L"Leaving Initialise",3)
end

function PieTracker.RegisterEvents()
	PieTracker.DebugMsg(L"Entering RegisterEvents",3)
	--Hook the mod into the appropriate events
	RegisterEventHandler(SystemData.Events.PLAYER_BEGIN_CAST, "PieTracker.StartCast")
	PieTracker.DebugMsg(L"Leaving RegisterEvents",3)
end

function PieTracker.UnregisterEvents()
	PieTracker.DebugMsg(L"Entering UnregisterEvents",3)
	--Hook the mod into the appropriate events
	UnregisterEventHandler(SystemData.Events.PLAYER_BEGIN_CAST, "PieTracker.StartCast")
	PieTracker.DebugMsg(L"Leaving UnregisterEvents",3)
end

function PieTracker.DebugMsg(str,lvl)
	-- If debug is enabled and the priority of the message is high enough then send a debug message
	if PieTracker.Debug.Enabled and lvl <= PieTracker.Debug.Level then
		d(towstring(str))
	end
end

function PieTracker.SlashDebug(args)
	PieTracker.DebugMsg(L"Entering SlashDebug",3)
	local arg, argv = args:match("([a-z0-9]+)[ ]?(.*)")
	PieTracker.DebugMsg("SlashDebug: arg ["..arg.."] argv ["..argv.."]",2)
	if arg == nil then
		PieTracker.Debug.Enabled = not PieTracker.Debug.Enabled
		return
	end
	-- Set to true to display debug messaPieTracker in the debug window (Note: type /debug in game to see this window and pPieTrackers the button "Logs(off)")
	-- Set the debug level (4 = Update Ticks, 3 = Position, 2 = Setting values, 1 = Return values, 0 = Illegal flow catches)
	if arg == "on" then
		PieTracker.Debug.Enabled = true
	elseif arg == "off" then
		PieTracker.Debug.Enabled = false
	elseif arg == "1" then
		PieTracker.Debug.Enabled = true
		PieTracker.Debug.Level = 1
	elseif arg == "2" then
		PieTracker.Debug.Enabled = true
		PieTracker.Debug.Level = 2
	elseif arg == "3" then
		PieTracker.Debug.Enabled = true
		PieTracker.Debug.Level = 3
	elseif arg == "4" then
		PieTracker.Debug.Enabled = true
		PieTracker.Debug.Level = 4
	else
		PieTracker.DebugMsg("SlashDebug: Invalid Argument ["..arg.."]",0)
	end
	PieTracker.DebugMsg(L"Leaving SlashDebug",3)
end

function PieTracker.StartCast(abilityId, isChanneledSpell, desiredCastTime, averageLatency)
	PieTracker.DebugMsg(L"Entering StartCast",3)
	local pieThrown = false
	local targetName = string.match(tostring(TargetInfo:UnitName("selffriendlytarget")),"%a+")

	--Check to see if friendly target is selected, if not exit.
	if not targetName then return end
	PieTracker.DebugMsg("Target info ["..targetName.."]",2)
	-- Search to see if the ability used was throwing a pie
	for k, a in pairs(PieTracker.AbilityList) do
		if k == abilityId then
			pieThrown = true
			break
		end
	end
	if pieThrown then
		-- We hit someone with a pie, YAY!!!
		PieTracker.IncreaseHitCount(targetName)
		PieTracker.ApplySortOrder()
		if targetName == PieTracker.Settings.GrudgeTarget then
			PieTracker.UpdateGuildMemberNote()
		end
	end
	PieTracker.DebugMsg(L"Leaving StartCast",3)
end

function PieTracker.UpdateGuildMemberNote()
	PieTracker.DebugMsg(L"Entering UpdateGuildMemberNote",3)
	if PieTracker.Settings.GrudgeTarget == "" or not PieTracker.Settings.GuildNote then return end
	local note = PieTracker.GenerateComment(PieTracker.Settings.GrudgeTarget)
	SendChatText(L"/guildnote "..GameData.Player.name..L" "..note,L"")
	PieTracker.DebugMsg(L"Leaving UpdateGuildMemberNote",3)
end

function PieTracker.Announce()
	PieTracker.DebugMsg(L"Entering Announce",3)
	local message = PieTracker.GenerateComment(PieTracker.SelectedTarget)
	-- Send the text
	SendChatText(ChatSettings.Channels[SystemData.ChatLogFilters.SHOUT].serverCmd..L" "..message,L"")
	PieTracker.DebugMsg(L"Leaving Announce",3)
end 

function PieTracker.GenerateComment(name)
	PieTracker.DebugMsg(L"Entering GenerateComment",3)
	local hitCount = PieTracker.GetHitCount(name)
	local pieCountString = ""
	if hitCount == nil or hitCount == 0 then
		pieCountString = "no pies :("
	elseif hitCount == 1 then
		pieCountString = "only one pie"
	else
		pieCountString = hitCount.." pies"
	end
	local note = towstring("I've hit "..name.." with "..pieCountString)
	PieTracker.DebugMsg(L"Leaving GenerateComment",3)
	return note
end

----------------------------------
---   Gui Specific Functions   ---
----------------------------------

function PieTracker.Slash()
	PieTracker.DebugMsg(L"Entering Slash",3)
	PieTracker.ShowWindow()
	PieTracker.DebugMsg(L"Leaving Slash",3)
end

function PieTracker.WindowInit()
	PieTracker.DebugMsg(L"Entering WindowInit",3)
	-- Create the window and then hide it.
	CreateWindow(PieTracker.Window, true)
	WindowSetShowing(PieTracker.Window,false)
	-- Apply text to the buttons so they are not blank.
	ButtonSetText(PieTracker.Window.."SaveButton" , L"Save")
	ButtonSetText(PieTracker.Window.."ResetButton", L"Reset All")
	ButtonSetText(PieTracker.Window.."CloseButton", L"Close")
	-- Apply text to the labels so they are not blank.
	LabelSetText(PieTracker.Window.."TitleBarText"      , L"Pie Tracker Options v"..VERSION)
	LabelSetText(PieTracker.Window.."OptionsModLabel"   , L"Enable Pie Tracker")
	LabelSetText(PieTracker.Window.."OptionsGuildLabel" , L"Update Member Note")
	LabelSetText(PieTracker.Window.."OptionsTargetLabel", L"Grudge target's name")
	-- Apply text to the Sort Bar buttons
	ButtonSetText(PieTracker.Window.."SortBarNameButton", L"Name")
	ButtonSetText(PieTracker.Window.."SortBarHitsButton", L"Pies")
	PieTracker.DebugMsg(L"Leaving WindowInit",3)
end

function PieTracker.ShowWindow()
	PieTracker.DebugMsg(L"Entering ShowWindow",3)
	-- Set the gui elements to the latest values.
	-- Options section
	EnableModCheckToggle = PieTracker.Settings.Enabled
	ButtonSetPressedFlag(PieTracker.Window.."OptionsModCheckBox"  , EnableModCheckToggle)
	EnableGuildCheckToggle = PieTracker.Settings.GuildNote
	ButtonSetPressedFlag(PieTracker.Window.."OptionsGuildCheckBox", EnableGuildCheckToggle)
	TextEditBoxSetText(PieTracker.Window.."OptionsTargetEditBox"  , towstring(PieTracker.Settings.GrudgeTarget))
	-- Populate and sort the Listbox
	PieTracker.ApplySortOrder()
	-- Show the window
	WindowSetShowing(PieTracker.Window,true)
	PieTracker.DebugMsg(L"Leaving ShowWindow",3)
end

function PieTracker.CloseWindow(flags, mouseX, mouseY)
	PieTracker.DebugMsg(L"Entering CloseWindow",3)
	-- When the button is clicked, hide the PieTracker window.
	WindowSetShowing(PieTracker.Window,false)
	PieTracker.DebugMsg(L"Leaving CloseWindow",3)
end

function PieTracker.SaveOptions(flags, mouseX, mouseY)
	PieTracker.DebugMsg(L"Entering SaveOptions",3)
	PieTracker.Settings.Enabled      = ButtonGetPressedFlag(PieTracker.Window.."OptionsModCheckBox")
	PieTracker.Settings.GuildNote    = ButtonGetPressedFlag(PieTracker.Window.."OptionsGuildCheckBox")
	PieTracker.Settings.GrudgeTarget = tostring(TextEditBoxGetText(PieTracker.Window.."OptionsTargetEditBox"))

	if PieTracker.Enabled ~= PieTracker.Settings.Enabled then
		PieTracker.Enabled = PieTracker.Settings.Enabled
		if PieTracker.Settings.Enabled then
			PieTracker.RegisterEvents()
		else
			PieTracker.UnregisterEvents()
		end
	end
	if PieTracker.Settings.GuildNote then
		PieTracker.UpdateGuildMemberNote()
	end
	PieTracker.DebugMsg(L"Leaving SaveOptions",3)
end

function PieTracker.AssignGrudgeTarget()
	PieTracker.DebugMsg(L"Entering AssignGrudgeTarget",3)
	PieTracker.Settings.GrudgeTarget = PieTracker.SelectedTarget
	TextEditBoxSetText(PieTracker.Window.."OptionsTargetEditBox", towstring(PieTracker.Settings.GrudgeTarget))
	PieTracker.UpdateGuildMemberNote()
	PieTracker.SelectedTarget = ""
	PieTracker.ApplySortOrder()
	PieTracker.DebugMsg(L"Leaving AssignGrudgeTarget",3)
end

function PieTracker.EnableModCheckToggle(flags, mouseX, mouseY)
	PieTracker.DebugMsg(L"Entering EnableModCheckToggle",3)
	EnableModCheckToggle = not EnableModCheckToggle
	ButtonSetPressedFlag(PieTracker.Window.."OptionsModCheckBox",EnableModCheckToggle)
	PieTracker.DebugMsg(L"Leaving EnableModCheckToggle",3)
end

function PieTracker.EnableGuildCheckToggle(flags, mouseX, mouseY)
	PieTracker.DebugMsg(L"Entering EnableGuildCheckToggle",3)
	EnableGuildCheckToggle = not EnableGuildCheckToggle
	ButtonSetPressedFlag(PieTracker.Window.."OptionsGuildCheckBox",EnableGuildCheckToggle)
	PieTracker.DebugMsg(L"Leaving EnableGuildCheckToggle",3)
end

function PieTracker.PopulateHitCount()
	PieTracker.DebugMsg(L"Entering PopulateHitCount",3)
	if( PieTrackerList.PopulatorIndices == nil ) then return end

	for k, a in ipairs( PieTrackerList.PopulatorIndices ) do
		PieTracker.DebugMsg("PHC: Looping["..k.."]",3)
    	local rowWindow = PieTracker.Window.."ListRow"..k
		local targetData = PieTracker.Settings.HitCounts[a]
		if targetData then
			if targetData.thrower == GameData.Player.name then
				PieTracker.DebugMsg(L"PHC: Name["..towstring(targetData.name)..L"] Hits["..towstring(targetData.count)..L"]",2)
				-- Set background color
				local rowMod = math.mod( k, 2 )
				local color = DataUtils.GetAlternatingRowColor( rowMod )
				WindowSetTintColor( rowWindow.."Background", color.r, color.g, color.b )
				WindowSetAlpha( rowWindow.."Background", color.a )
				-- Color the gruidge's name red
				if( targetData.name == PieTracker.Settings.GrudgeTarget ) then
					LabelSetTextColor( rowWindow.."name",  DefaultColor.AbilityType.DAMAGING.r,  DefaultColor.AbilityType.DAMAGING.g,  DefaultColor.AbilityType.DAMAGING.b)
				else
					LabelSetTextColor( rowWindow.."name",255,255,255)
				end
				-- Set target text
				LabelSetText( rowWindow.."name" , towstring(targetData.name))
				LabelSetText( rowWindow.."count", towstring(targetData.count))
			end
		end
	end
	PieTracker.DebugMsg(L"Leaving PopulateHitCount",3)
end

function PieTracker.RowClicked(flags, mouseX, mouseY)
	PieTracker.DebugMsg(L"Entering RowClicked",3)
	-- Figure out which target was selected
	local displayIndex = WindowGetId(SystemData.ActiveWindow.name)
	PieTracker.DebugMsg("RowClicked: displayIndex   ["..displayIndex.."]",2)
	if PieTrackerList.PopulatorIndices == nil then return end
	local dataIndex = PieTrackerList.PopulatorIndices[displayIndex]
	if dataIndex == nil then PieTracker.DebugMsg("RowClicked: dataIndex   [nil]",2) return end
	PieTracker.DebugMsg("RowClicked: dataIndex   ["..dataIndex.."]",2)
	local targetSelected = PieTracker.Settings.HitCounts[dataIndex]
	PieTracker.DebugMsg("RowClicked: targetName  ["..targetSelected.name.."]",2)
	PieTracker.DebugMsg("RowClicked: targetCount ["..targetSelected.count.."]",2)
	PieTracker.SelectedTarget = tostring(targetSelected.name)
	local isGrudge = targetSelected.name == PieTracker.Settings.GrudgeTarget
	-- Build the context menu
	local contextMenuItems = {}
	table.insert( contextMenuItems, PlayerMenuWindow.NewCustomItem( L"Create Grudge"    , PieTracker.AssignGrudgeTarget, isGrudge ) )
	table.insert( contextMenuItems, PlayerMenuWindow.NewCustomItem( L"Reset Hitcount"   , PieTracker.ResetTargetCount  , false ) )
	table.insert( contextMenuItems, PlayerMenuWindow.NewCustomItem( L"Announce in chat" , PieTracker.Announce          , false ) )
	-- Display the context menu
	PlayerMenuWindow.ShowMenu( towstring(targetSelected.name), 0, contextMenuItems )
	PieTracker.DebugMsg(L"Leaving RowClicked",3)
end

function PieTracker.SortHitCount()
	PieTracker.DebugMsg(L"Entering SortHitCount",3)
	PieTracker.HitCountsOrdered = {}
	for k, a in ipairs(PieTracker.Settings.HitCounts) do
		if a.thrower == GameData.Player.name then
			table.insert(PieTracker.HitCountsOrdered,k)
		end
	end
	table.sort(PieTracker.HitCountsOrdered, PieTracker.CompareTargetDetails)
	ListBoxSetDisplayOrder(PieTracker.Window.."List", PieTracker.HitCountsOrdered)
	PieTracker.DebugMsg(L"Leaving SortHitCount",3)
end

function PieTracker.CompareTargetDetails(index1, index2)
	PieTracker.DebugMsg(L"Entering CompareTargetDetails",3)
	-- Sort Types will be Name (Up, Down), Hits (Up,Down)
	if index1 == nil then return false end
	if index2 == nil then return true  end
	local data1, data2

	if PieTracker.Settings.OrderType == ORDER_BY_HITS then
		data1 = PieTracker.Settings.HitCounts[index1].count
		data2 = PieTracker.Settings.HitCounts[index2].count
	else
		data1 = PieTracker.Settings.HitCounts[index1].name
		data2 = PieTracker.Settings.HitCounts[index2].name
	end

	if PieTracker.Settings.OrderDirection == ORDER_DESC then
		compare = data1 > data2
	else
		compare = data1 < data2
	end

	PieTracker.DebugMsg(L"Leaving CompareTargetDetails",3)
	return compare
end

function PieTracker.ReSortList(flags, mouseX, mouseY)
	PieTracker.DebugMsg(L"Entering ResortList",3)
   local buttonId = WindowGetId( SystemData.ActiveWindow.name )
	--Check if selected button pressed twice to flip the order
	if PieTracker.Settings.OrderType == buttonId then
		if PieTracker.Settings.OrderDirection == ORDER_DESC then
			PieTracker.Settings.OrderDirection = ORDER_ASC
		else
			PieTracker.Settings.OrderDirection = ORDER_DESC
		end
	else
		PieTracker.Settings.OrderType = buttonId
		PieTracker.Settings.OrderDirection = ORDER_ASC
	end
	PieTracker.ApplySortOrder()
	PieTracker.DebugMsg(L"Leaving ResortList",3)
end

function PieTracker.ApplySortOrder()
	PieTracker.DebugMsg(L"Entering ApplySortOrder",3)
	local windowName, sortDirection
	-- Hide all the arrows
	WindowSetShowing(PieTracker.Window.."SortBarNameButton".."UpArrow"  , false )
	WindowSetShowing(PieTracker.Window.."SortBarNameButton".."DownArrow", false )
	WindowSetShowing(PieTracker.Window.."SortBarHitsButton".."UpArrow"  , false )
	WindowSetShowing(PieTracker.Window.."SortBarHitsButton".."DownArrow", false )
	-- Get Window name and direction
	if PieTracker.Settings.OrderType == ORDER_BY_HITS then
		windowName = PieTracker.Window.."SortBarHitsButton"
	else
		windowName = PieTracker.Window.."SortBarNameButton"
	end
	if PieTracker.Settings.OrderDirection == ORDER_DESC then
		sortDirection = "DownArrow"
	else
		sortDirection = "UpArrow"
	end
	-- Apply the sort order
	WindowSetShowing(windowName..sortDirection, true)
	PieTracker.SortHitCount()
	PieTracker.DebugMsg(L"Leaving ApplySortOrder",3)
end

function PieTracker.MouseOverSortButton(flags, mouseX, mouseY)
	PieTracker.DebugMsg(L"Entering MouseOverSortButton",3)
	local windowName = SystemData.ActiveWindow.name
	local buttonId   = WindowGetId (windowName)
	local message
	if buttonId == ORDER_BY_HITS then
		message = L"Sort by number of pies"
	else
		message = L"Sort by victim's name"
	end
	Tooltips.CreateTextOnlyTooltip (windowName, nil)
	Tooltips.SetTooltipText (1, 1, message)
	Tooltips.SetTooltipColorDef (1, 1, Tooltips.COLOR_HEADING)
	Tooltips.Finalize ()
	Tooltips.AnchorTooltip(Tooltips.ANCHOR_WINDOW_TOP)
	Tooltips.SetTooltipAlpha (1)
	PieTracker.DebugMsg(L"Leaving MouseOverSortButton",3)
end

----------------------------------
---  Table Handling functions  ---
----------------------------------

function PieTracker.GetEntry(targetName)
	PieTracker.DebugMsg(L"Entering GetEntry",3)
	for k,a in pairs(PieTracker.Settings.HitCounts) do
		PieTracker.DebugMsg("GE: Checking Entry Index["..k.."]",3)
		if a.name == targetName and a.thrower == GameData.Player.name then
			PieTracker.DebugMsg("GE: Entry found",2)
			return k, a
		end
	end
	PieTracker.DebugMsg("GE: Entry Not found",2)
	PieTracker.DebugMsg(L"Leaving GetEntry",3)
	return nil, nil
end

function PieTracker.GetHitCount(targetName)
	PieTracker.DebugMsg(L"Entering GetHitCount",3)
	local hitCount = 0
	local index, details = PieTracker.GetEntry(targetName)
	if details then
		hitCount = details.count
	end
	PieTracker.DebugMsg("GHC: Name["..targetName.."] Hits["..hitCount.."]",2)
	PieTracker.DebugMsg(L"Leaving GetHitCount",3)
	return hitCount
end

function PieTracker.IncreaseHitCount(targetName)
	PieTracker.DebugMsg(L"Entering IncreaseHitCount",3)
	local hitCount = 1
	local index, details = PieTracker.GetEntry(targetName)
	if not index then
		index = #PieTracker.Settings.HitCounts + 1
		PieTracker.DebugMsg("AHC: Adding new entry for Name["..targetName.."], index["..index.."]",2)
	else
		hitCount = hitCount + details.count
	end
	PieTracker.Settings.HitCounts[index] = { thrower = GameData.Player.name, name = targetName , count = hitCount, received = 0 }
	PieTracker.DebugMsg(L"Leaving IncreaseHitCount",3)
end

function PieTracker.ResetAllCounts(flags, mouseX, mouseY)
	PieTracker.DebugMsg(L"Entering ResetAllCounts",3)
	PieTracker.Settings.HitCounts = {}
	PieTracker.UpdateGuildMemberNote()
	PieTracker.ApplySortOrder()
	PieTracker.DebugMsg(L"Leaving ResetAllCounts",3)
end

function PieTracker.ResetTargetCount()
	PieTracker.DebugMsg(L"Entering ResetCount",3)
	if PieTracker.SelectedTarget == "" then PieTracker.DebugMsg(L"ResetCount: Blank value for PieTracker.SelectedTarget",1) return end
	local index, details = PieTracker.GetEntry(targetName)
	table.remove(PieTracker.Settings.HitCounts, index)
	if PieTracker.SelectedTarget == PieTracker.Settings.GrudgeTarget then
		PieTracker.UpdateGuildMemberNote()
	end
	PieTracker.SelectedTarget = ""
	PieTracker.ApplySortOrder()
	PieTracker.DebugMsg(L"Leaving ResetCount",3)
end