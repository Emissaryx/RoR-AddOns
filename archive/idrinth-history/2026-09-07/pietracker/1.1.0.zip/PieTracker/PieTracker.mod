<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
	<UiMod name="PieTracker" version="1.1" date="18/08/2010" >
		<Author name="Medikage" email="medikage@gmail.com" />
		<Description text="Keeps a track of how many times you successfully hit people with a pie and updates your guild members note with the hit count of a player of your choosing, if you so desire." />
		<VersionSettings gameVersion="1.3.6" windowsVersion="1.0" savedVariablesVersion="1.0"/>
		<Dependencies>
			<Dependency name="LibSlash" />
		</Dependencies>
		<Files>
			<File name="PieTracker.xml" />
		</Files>
		<SavedVariables>
			<SavedVariable name="PieTracker.Settings" />
		</SavedVariables>
		<OnInitialize>
			<CallFunction name="PieTracker.Initialise" />
		</OnInitialize>
		<OnUpdate/>
		<OnShutdown/>
	</UiMod>
</ModuleFile>