GetStats = {}
GetStats.Compare = {}
Getstats_CompareStats = {}
GetStats.GotSomethingToCompare = false
local version = "1.2"

function GetStats.OnInitialize()
CreateWindow("GetStatsWindow", false)
CreateWindow("GetStatsCompareWindow", false)
GetStats.Populating = false
GetStats.LineNumber = 0
GetStats.LineLength = 0
GetStats.TempLineLength = 0

RegisterEventHandler(TextLogGetUpdateEventId("Chat"), "GetStats.OnChatLogUpdated")
TextLogAddEntry("Chat", 0, L"<icon00057> GetStats "..towstring(version)..L" Loaded.")
end
function GetStats.OnChatLogUpdated(updateType, filterType)

	if( updateType == SystemData.TextLogUpdate.ADDED ) then 
		local _, filterId, text = TextLogGetEntry( "Chat", TextLogGetNumEntries("Chat") - 1 ) 
		if GetStats.Populating == true then
						GetStats.LineNumber = GetStats.LineNumber+1
						if( not DoesWindowExist( "GetStatsLine"..GetStats.LineNumber ) ) then
						CreateWindowFromTemplate( "GetStatsLine"..GetStats.LineNumber, "GetStatsLabelTemplate", "GetStatsWindow" )
						end
						WindowSetParent("GetStatsLine"..GetStats.LineNumber,"GetStatsWindow")
						LabelSetText("GetStatsLine"..GetStats.LineNumber.."Text",towstring(text))
						GetStats.Compare[GetStats.LineNumber] = towstring(text)
						WindowSetOffsetFromParent( "GetStatsLine"..GetStats.LineNumber,0,6+(tonumber(GetStats.LineNumber)*22))
						GetStats.TempLineLength = LabelGetTextDimensions("GetStatsLine"..GetStats.LineNumber.."Text")						
						if GetStats.TempLineLength > GetStats.LineLength then GetStats.LineLength = GetStats.TempLineLength end								
		end
		if text:find(L"Stats for") then	
		for i = 1 , #Getstats_CompareStats do
		if DoesWindowExist( "GetStatsCompareLine"..i ) then
		DestroyWindow("GetStatsCompareLine"..i )
		end
		end
		
	
		
			Getstats_CompareStats = GetStats.Compare
			if Getstats_CompareStats ~= "" or Getstats_CompareStats ~= nil then
			GetStats_TempCompareLineLength = 0
			GetStats_CompareLineLength = 0
				for i = 1 , #Getstats_CompareStats do
				WindowSetShowing("GetStatsCompareWindow", true)	
				CreateWindowFromTemplate( "GetStatsCompareLine"..i, "GetStatsLabelTemplate", "GetStatsCompareWindow" )
				WindowSetParent("GetStatsCompareLine"..i,"GetStatsCompareWindow")
				LabelSetText("GetStatsCompareLine"..i.."Text",towstring(Getstats_CompareStats[i]))
				WindowSetOffsetFromParent( "GetStatsCompareLine"..i,0,6+(tonumber(i)*22))
--			d(Getstats_CompareStats[i])
						GetStats_TempCompareLineLength = LabelGetTextDimensions("GetStatsCompareLine"..i.."Text")						
						if GetStats_TempCompareLineLength > GetStats_CompareLineLength then GetStats_CompareLineLength = GetStats_TempCompareLineLength end			
				end
				WindowSetDimensions("GetStatsCompareWindow",GetStats_CompareLineLength+20,28+(#Getstats_CompareStats*22))
				LabelSetText("GetStatsCompareWindowTitle",L"Prev stats")	
			end
		
		
		GetStats.Compare = {}
		LabelSetText("GetStatsWindowTitle",wstring.sub(text,11,-3 ))	
		for i=1 , GetStats.LineNumber do	
		if DoesWindowExist( "GetStatsLine"..i ) then
		DestroyWindow("GetStatsLine"..i )
		end
		end		
		GetStats.LineNumber = 0
		GetStats.LineLength = 0
		GetStats.TempLineLength = 0
		WindowSetShowing("GetStatsWindow", true)
		GetStats.Populating = true		
		end
		if text:find(L"Current") then	
		GetStats.Populating = false		
		WindowSetDimensions("GetStatsWindow",GetStats.LineLength+20,28+(GetStats.LineNumber*22))		
		end
	end
end

function GetStats.CloseWindow()
WindowSetShowing("GetStatsWindow", false)	
WindowSetShowing("GetStatsCompareWindow", false)
Getstats_CompareStats = {}
GetStats_TempCompareLineLength = 0
GetStats_CompareLineLength = 0
end
