
-- vim: sw=2 ts=2
if not Effigy then Effigy = {} end
local Addon = Effigy


Addon.texture_list_local = {

	["tint_square"] = { },
	--["nameplate_glow"] = { scale = 1, width=256, height=64},
	["Melli"] = { scale = 1, width=64, height=64},
	

	["Statusbar"] = { scale = 1, width=16, height=128 },
	["Statusbar1"] = { scale = 1, width=256, height=32 },
	["Statusbar2"] = { scale = 1, width=256, height=32 },
	["Gloss"] = { scale = 1, width=64, height=64 },
	["rothTex"] = { scale = 1, width=16, height=16 },
	["rothTexV"] = { scale = 1, width=16, height=16},

	["GroupIcon Gloss"] = { scale = 1, width=50, height=50 },
	["GroupIcon Shape"] = { scale = 1, width=50, height=50 },

	["Xeon"] = { scale = 1, width=256, height=32 },
	["Wisps"] = { scale = 1, width=256, height=32 },
	["Wglass"] = { scale = 1, width=256, height=64 },
	["Water"] = { scale = 1, width=256, height=32 },
	["Tube"] = { scale = 1, width=256, height=32 },
	["Striped"] = { scale = 1, width=256, height=32 },
	["Steel"] = { scale = 1, width=256, height=32 },
	["Smudge"] = { scale = 1, width=256, height=32 },
	["Smoothv2"] = { scale = 1, width=256, height=32 },
	["Smooth"] = { scale = 1, width=256, height=32 },
	["Skewed"] = { scale = 1, width=256, height=32 },
	["Runes"] = { scale = 1, width=256, height=32 },
	["Ruben"] = { scale = 1, width=256, height=32 },
	["Round"] = { scale = 1, width=256, height=32 },
	["Rocks"] = { scale = 1, width=256, height=32 },
	["Rain"] = { scale = 1, width=256, height=32 },
	["Pill"] = { scale = 1, width=256, height=32 },
	["Perl2"] = { scale = 1, width=256, height=32 },
	["Perl"] = { scale = 1, width=64, height=8 },
	["Outline"] = { scale = 1, width=256, height=32 },
	["Otravi"] = { scale = 1, width=256, height=32 },
	["Minimalist"] = { scale = 1, width=256, height=32 },
	["MelliDarkRough"] = { scale = 1, width=64, height=64 },
	["MelliDark"] = { scale = 1, width=64, height=64 },
	["Lyfe"] = { scale = 1, width=256, height=32 },
	["LiteStepLite"] = { scale = 1, width=128, height=16 },
	["LiteStep"] = { scale = 1, width=256, height=32 },
	["Healbot"] = { scale = 1, width=256, height=32 },
	["Hatched"] = { scale = 1, width=256, height=32 },
	["Grid"] = { scale = 1, width=256, height=32 },
	["Graphite"] = { scale = 1, width=256, height=64 },
	["Gloss"] = { scale = 1, width=256, height=32 },
	["Glaze2"] = { scale = 1, width=256, height=32 },
	["Glaze"] = { scale = 1, width=256, height=32 },
	["Glass"] = { scale = 1, width=64, height=32 },
	["Glamour7"] = { scale = 1, width=256, height=64 },
	["Glamour6"] = { scale = 1, width=256, height=64 },
	["Glamour5"] = { scale = 1, width=256, height=64 },
	["Glamour4"] = { scale = 1, width=256, height=64 },
	["Glamour3"] = { scale = 1, width=256, height=64 },
	["Glamour2"] = { scale = 1, width=256, height=64 },
	["Glamour"] = { scale = 1, width=256, height=64 },
	["Frost"] = { scale = 1, width=256, height=32 },
	["Fourths"] = { scale = 1, width=256, height=32 },
	["Flat"] = { scale = 1, width=256, height=32 },
	["Fifths"] = { scale = 1, width=256, height=32 },
	["Falumn"] = { scale = 1, width=256, height=32 },
	["Empty"] = { scale = 1, width=16, height=16 },
	["Diagonal"] = { scale = 1, width=256, height=32 },
	["DarkBottom"] = { scale = 1, width=256, height=32 },
	["Dabs"] = { scale = 1, width=256, height=32 },
	["Comet"] = { scale = 1, width=256, height=32 },
	["combo"] = { scale = 1, width=16, height=16 },
	["Cloud"] = { scale = 1, width=256, height=32 },
	["Cilo"] = { scale = 1, width=128, height=128 },
	["Charcoal"] = { scale = 1, width=128, height=128 },
	["Button"] = { scale = 1, width=256, height=32 },
	["Bumps"] = { scale = 1, width=256, height=32 },
	["Bars"] = { scale = 1, width=256, height=32 },
	["BantoBar"] = { scale = 1, width=256, height=32 },
	["Armory"] = { scale = 1, width=16, height=16 },
	["Aluminium"] = { scale = 1, width=256, height=32 },
	
	
}

Addon.texture_list = Addon.texture_list_local

local LibSA = LibStub("LibSharedAssets")
Addon.TextureManager = {}

function Addon.TextureManager.GetTextureList()
	local tex = {}
	
	for k,v in pairs(Addon.texture_list_local) do tex[k]=v end
	
	a= LibSA:GetTextureList()
	for k,v in pairs (a)
	do
		local meta = LibSA:GetMetadata(v)
		
		tex[v] = {scale=1, width=meta.size[1], height=meta.size[2]}
	end
	return tex;
end

function  Addon.TextureManager.BuildTextureList()
	Addon.texture_list = Addon.TextureManager.GetTextureList()
end

function Addon.TextureManager.SetTextureFill(win_name,t, width, height, perc, direction, type )
	if (not Addon.texture_list[t] or not Addon.texture_list[t].width or not Addon.texture_list[t].height)
	then
		return nil
	end

	if (direction == "right")
	then
		if (type and type == "grow")
		then
			DynamicImageSetTexture(win_name, t, 
				Addon.texture_list[t].width - Addon.texture_list[t].width * perc,
				Addon.texture_list[t].height)
		else
			DynamicImageSetTexture(win_name, t, 
				Addon.texture_list[t].width,
				Addon.texture_list[t].height)
		end
		DynamicImageSetTextureDimensions(win_name, perc * Addon.texture_list[t].width , Addon.texture_list[t].height)
	elseif (direction == "left") 
	then
		if (type and type == "grow")
		then
			DynamicImageSetTexture(win_name, t, 
				Addon.texture_list[t].width,
				Addon.texture_list[t].height)
		else
			DynamicImageSetTexture(win_name, t, 
				Addon.texture_list[t].width - Addon.texture_list[t].width * perc,
				Addon.texture_list[t].height)	
		end
		DynamicImageSetTextureDimensions(win_name, perc * Addon.texture_list[t].width , Addon.texture_list[t].height)
	elseif (direction == "down") 
	then
		if (type and type == "grow")
		then
			DynamicImageSetTexture(win_name, t, 
				Addon.texture_list[t].width,
				Addon.texture_list[t].height - Addon.texture_list[t].height * perc)
		else
			DynamicImageSetTexture(win_name, t, 
				Addon.texture_list[t].width,
				Addon.texture_list[t].height)
		end
		DynamicImageSetTextureDimensions(win_name, Addon.texture_list[t].width , Addon.texture_list[t].height * perc )
	elseif (direction == "up") 
	then
		if (type and type == "grow")
		then
			DynamicImageSetTexture(win_name, t, 
				Addon.texture_list[t].width,
				Addon.texture_list[t].height)
		else
			DynamicImageSetTexture(win_name, t, 
				Addon.texture_list[t].width,
				Addon.texture_list[t].height - Addon.texture_list[t].height * perc)	
		end
		DynamicImageSetTextureDimensions(win_name, Addon.texture_list[t].width , Addon.texture_list[t].height * perc )
	end
end

function Addon.TextureManager.SetTexture(win_name, t)
	if (nil == Addon.texture_list[t]) then t = "tint_square" end

	if (nil ~= Addon.texture_list[t].real_texture) then
		DynamicImageSetTexture(win_name, Addon.texture_list[t].real_texture, 0, 0)
	else
		DynamicImageSetTexture(win_name, t, 
				Addon.texture_list[t].x or 0,
				Addon.texture_list[t].y or 0)
	end

	if (nil ~= Addon.texture_list[t].scale) then
		DynamicImageSetTextureScale(win_name, Addon.texture_list[t].scale)
	end

	if (nil ~= Addon.texture_list[t].width)and(nil ~= Addon.texture_list[t].height) then
		DynamicImageSetTextureDimensions(win_name, 
				Addon.texture_list[t].width, Addon.texture_list[t].height)
	end

	if (nil ~= Addon.texture_list[t].slice) then
		DynamicImageSetTextureSlice(win_name, Addon.texture_list[t].slice)
	end

end
