# BookOfGrudges

Dwarf-only addon for refusing shameful "friendly" targets.

If your "friendly" target is written in the Book, the addon clears the target, marks the grudge as noted, and says so in proper Dawi fashion. Your normal ignore list can also count as grudges, if you allow such entries into the ledger.

This addon does not work for non-Dawi characters.

## Commands

- `/book add [name]` - write a name into the Book, or use your current "friendly" target.
- `/book remove <name>` - strike a name from the Book.
- `/book list` - read the names currently written.
- `/book status` - inspect the ledger, ignore-list setting, and clear counts.
- `/book open` - open the Book window.
- `/book close` - close the Book window.
- `/book clear` - empty the Book.
- `/book stats` or `/book stats <name>` - show grudges noted and ledger marks.
- `/book stats clear` - wipe the tally of noted grudges.
- `/book ignore on|off|toggle|status` - decide whether the ignore list also counts as grudges.

In the Book window, click a column header to sort. Right-click an entry for stats or removal. Left- or right-click `Ignore source` to change ignore-list source handling.

## Changelog

### 0.1.0 - 2026-05-25 - Wholdar

- Initial release.
