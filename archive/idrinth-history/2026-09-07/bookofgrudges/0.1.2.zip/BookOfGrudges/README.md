# BookOfGrudges

Dwarf-only RoR addon that clears friendly targets listed in your Book, and optionally your ignore list.

## Commands

- `/book add [name]` - add a name, or use your friendly target.
- `/book remove <name>` - remove a name.
- `/book list` - show Book entries.
- `/book clear` - clear Book entries.
- `/book stats [name]` - show stats.
- `/book stats clear` - clear all stats.
- `/book status` - show counts and settings.
- `/book open` - open the window.
- `/book close` - close the window.
- `/book ignore on|off|toggle|status` - use or ignore the ignore list.

Window: sort headers; right-click rows for stats/remove/clear; right-click `Stats` to clear Book and stats.

## Changelog

### 0.1.2 - 2026-05-26 - Wholdar

- Add row right-click actions to clear stats, remove entries, or do both.
- Add a Stats summary clear action that reports removed counts.

### 0.1.1 - 2026-05-25 - Wholdar

- Wait for late Dawi career data during startup.

### 0.1.0 - 2026-05-25 - Wholdar

- Initial release.
