BookOfGrudges = BookOfGrudges or {}
BookOfGrudges.uiRows = BookOfGrudges.uiRows or {}
BookOfGrudges.VERSION = "0.1.2"

local FRIENDLY_TARGET = "selffriendlytarget"
local MESSAGE_COOLDOWN_SECONDS = 45
local CHAT_PREFIX_COLOR = "205,170,75"
local PLAYER_LINK_COLOR = "235,205,145"
local MAX_NOTE_HISTORY = 20
local WINDOW_NAME = "BookOfGrudgesWindow"
local DAY_SECONDS = 24 * 60 * 60
local YEAR_SECONDS = 365 * DAY_SECONDS
local LEAP_YEAR_SECONDS = YEAR_SECONDS + DAY_SECONDS
local FOUR_YEAR_SECONDS = (4 * YEAR_SECONDS) + DAY_SECONDS
local EPOCH_BASE_YEAR = 1970
local MONTH_DAYS = { -1, 30, 58, 89, 119, 150, 180, 211, 242, 272, 303, 333, 364 }
local LEAP_MONTH_DAYS = { -1, 30, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334, 365 }

local dwarf_careers = nil
local target_handler_registered = false
local retry_handlers_registered = false
local slash_registered = false
local active = false
local ui_window_created = false
local ui_window_visible = false
local ui_sort_column = "clears"
local ui_sort_descending = true
local non_dwarf_checks = 0
local last_message_at = {}

local NON_DWARF_CONFIRMATION_CHECKS = 3

local detarget_messages = {
    "Book of Grudges: %s is struck from your sight. The grudge stands.",
    "Dammaz Kron says no: %s is not worth a Dawi's gaze.",
    "Aye, %s goes back in the book. Target cleared.",
}

local test_names = {
    "Kazrik", "Snorri", "Baragor", "Thorek", "Dumgi", "Kragg", "Borin", "Dorin",
    "Grimnir", "Gromthi", "Hargin", "Kadrin", "Logazor", "Morgrim", "Norri", "Orek",
    "Rorek", "Skalf", "Thrain", "Ungrim", "Valaya", "Zaki", "Bagrik", "Drongnel",
    "Fimbur", "Garaz", "Hurgin", "Karakor", "Lokri", "Mordin", "Nargun", "Okri",
    "Ragni", "Skorri", "Thorgar", "Umgiwan", "Varek", "Zanrik", "Bokri", "Drekki",
}

local function to_plain_string(value)
    if value == nil then
        return ""
    end

    if type(WStringToString) == "function" then
        local ok, converted = pcall(WStringToString, value)
        if ok and converted ~= nil then
            return tostring(converted)
        end
    end

    local ok, converted = pcall(tostring, value)
    if ok and converted ~= nil then
        return converted
    end

    return ""
end

local function to_wstring(value)
    if type(towstring) == "function" then
        local ok, converted = pcall(towstring, value)
        if ok and converted ~= nil then
            return converted
        end
    end

    return tostring(value or "")
end

local function trim(value)
    local text = to_plain_string(value)
    text = string.gsub(text, "^%s+", "")
    text = string.gsub(text, "%s+$", "")
    return text
end

local function strip_caret_suffix(text)
    local caret_pos = string.find(text, "^", 1, true)
    if caret_pos then
        return string.sub(text, 1, caret_pos - 1)
    end
    return text
end

local function clean_display_name(value)
    local text = strip_caret_suffix(trim(value))
    text = string.gsub(text, "<[^>]*>", "")
    text = string.gsub(text, "%c", "")
    text = string.gsub(text, "^%s+", "")
    text = string.gsub(text, "%s+$", "")

    while text ~= "" and string.find(string.sub(text, 1, 1), "[%w]") == nil do
        text = string.sub(text, 2)
    end

    return text
end

local function uppercase_first_ascii(text)
    if text == nil or text == "" then
        return text
    end

    return string.upper(string.sub(text, 1, 1)) .. string.sub(text, 2)
end

local function normalize_name(value)
    local display = clean_display_name(value)
    if display == "" then
        return nil, nil
    end

    display = uppercase_first_ascii(display)

    local key = string.lower(display)
    key = string.gsub(key, "[^%w]", "")
    if key == "" then
        return nil, nil
    end

    return key, display
end

local function color_link(text, color)
    return "<LINK data=\"\" text=\"" .. to_plain_string(text) .. "\" color=\"" .. to_plain_string(color) .. "\">"
end

local function player_link_text(name)
    local display = clean_display_name(name)
    if display == "" then
        display = "unknown"
    end

    local link_name = string.gsub(display, "\"", "'")
    return "<LINK data=\"PLAYER:" .. link_name .. "\" color=\"" .. PLAYER_LINK_COLOR .. "\" text=\"@" .. link_name .. "\">"
end

local function print_chat(text)
    local line = to_wstring(color_link("[BookOfGrudges]:", CHAT_PREFIX_COLOR) .. " " .. trim(text or ""))
    if type(EA_ChatWindow) == "table" and type(EA_ChatWindow.Print) == "function" then
        EA_ChatWindow.Print(line)
    elseif type(TextLogAddEntry) == "function" then
        TextLogAddEntry("Chat", 0, line)
    end
end

local function get_time_seconds()
    if type(GetGameTime) == "function" then
        local ok, value = pcall(GetGameTime)
        if ok then
            local as_number = tonumber(value)
            if as_number ~= nil then
                return as_number
            end
        end
    end

    return 0
end

local function format_epoch_seconds(epoch)
    local value = tonumber(epoch)
    if value == nil or value < 0 then
        return nil
    end

    local floor = math.floor
    local seconds = floor(value)
    local year = floor(seconds / FOUR_YEAR_SECONDS)
    seconds = seconds - (year * FOUR_YEAR_SECONDS)
    year = (year * 4) + EPOCH_BASE_YEAR

    local days_for_month = MONTH_DAYS
    if seconds >= YEAR_SECONDS then
        year = year + 1
        seconds = seconds - YEAR_SECONDS
        if seconds >= YEAR_SECONDS then
            year = year + 1
            seconds = seconds - YEAR_SECONDS
            if seconds >= LEAP_YEAR_SECONDS then
                year = year + 1
                seconds = seconds - LEAP_YEAR_SECONDS
            else
                days_for_month = LEAP_MONTH_DAYS
            end
        end
    end

    local day_of_year = floor(seconds / DAY_SECONDS)
    seconds = seconds - (day_of_year * DAY_SECONDS)

    local month = 1
    while days_for_month[month] < day_of_year do
        month = month + 1
    end
    month = month - 1
    local day = day_of_year - days_for_month[month]

    local hour = floor(seconds / 3600)
    seconds = seconds - (hour * 3600)
    local minute = floor(seconds / 60)

    return string.format("%02d.%02d.%02d %02d:%02d", year % 100, month, day, hour, minute)
end

local function get_timestamp()
    local uptime = get_time_seconds()

    if type(GetEpochTime) == "function" then
        local ok, epoch = pcall(GetEpochTime)
        local epoch_number = ok and tonumber(epoch) or nil
        if epoch_number ~= nil and epoch_number > 0 then
            return {
                epoch = math.floor(epoch_number),
                gameTimeSeconds = uptime,
            }
        end
    end

    return {
        gameTimeSeconds = uptime,
    }
end

local function timestamp_from_epoch(epoch, uptime)
    local epoch_number = tonumber(epoch)
    if epoch_number ~= nil and epoch_number > 0 then
        return {
            epoch = math.floor(epoch_number),
            gameTimeSeconds = tonumber(uptime) or get_time_seconds(),
        }
    end

    return {
        gameTimeSeconds = tonumber(uptime) or get_time_seconds(),
    }
end

local function timestamp_days_ago(days, extra_seconds)
    local now = get_timestamp()
    if now.epoch ~= nil then
        return timestamp_from_epoch(now.epoch - ((tonumber(days) or 0) * DAY_SECONDS) - (tonumber(extra_seconds) or 0), now.gameTimeSeconds)
    end

    return {
        gameTimeSeconds = now.gameTimeSeconds,
    }
end

local function format_timestamp(timestamp)
    if type(timestamp) == "table" then
        if timestamp.epoch ~= nil then
            local label = format_epoch_seconds(timestamp.epoch)
            if label ~= nil then
                return label
            end
        end
        if timestamp.label ~= nil and timestamp.label ~= "" then
            return tostring(timestamp.label)
        end
    elseif timestamp ~= nil then
        local numeric = tonumber(timestamp)
        if numeric ~= nil and numeric > 1000000000 then
            return format_epoch_seconds(numeric) or "unknown"
        end
    end

    return "unknown"
end

local function timestamp_sort_value(timestamp)
    if type(timestamp) == "table" then
        return tonumber(timestamp.epoch) or 0
    end

    local numeric = tonumber(timestamp)
    if numeric ~= nil and numeric > 1000000000 then
        return numeric
    end
    return 0
end

local function format_percent(part, total)
    local denominator = tonumber(total) or 0
    if denominator <= 0 then
        return "0%"
    end

    return tostring(math.floor((((tonumber(part) or 0) * 100) / denominator) + 0.5)) .. "%"
end

local function format_count_percent(part, total)
    local value = tonumber(part) or 0
    return tostring(value) .. " (" .. format_percent(value, total) .. ")"
end

local function ensure_saved()
    BookOfGrudges.saved = BookOfGrudges.saved or {}
    local saved = BookOfGrudges.saved

    if type(saved.book) ~= "table" then
        saved.book = {}
    end
    if type(saved.stats) ~= "table" then
        saved.stats = {}
    end
    if saved.includeIgnoreList == nil then
        saved.includeIgnoreList = true
    end

    return saved
end

local function get_player_career_line()
    if not (GameData and GameData.Player) then
        return nil
    end

    if type(GameData.Player.career) == "table" then
        return GameData.Player.career.line or GameData.Player.career.id
    end

    return GameData.Player.careerLine
end

local function get_player_name_key()
    if not (GameData and type(GameData.Player) == "table") then
        return nil
    end

    local key = normalize_name(GameData.Player.name)
    return key
end

local function ensure_dwarf_careers()
    if dwarf_careers ~= nil then
        return dwarf_careers
    end

    dwarf_careers = {}
    if GameData and GameData.CareerLine then
        dwarf_careers[GameData.CareerLine.ENGINEER] = true
        dwarf_careers[GameData.CareerLine.SLAYER] = true
        dwarf_careers[GameData.CareerLine.IRON_BREAKER] = true
        dwarf_careers[GameData.CareerLine.RUNE_PRIEST] = true
    end

    return dwarf_careers
end

function BookOfGrudges.IsDwarf()
    local career_line = get_player_career_line()
    if career_line == nil then
        return nil
    end

    return ensure_dwarf_careers()[career_line] == true
end

local function register_event(event_id, handler_name)
    if event_id == nil or type(RegisterEventHandler) ~= "function" then
        return false
    end

    RegisterEventHandler(event_id, handler_name)
    return true
end

local function unregister_event(event_id, handler_name)
    if event_id == nil or type(UnregisterEventHandler) ~= "function" then
        return false
    end

    UnregisterEventHandler(event_id, handler_name)
    return true
end

local function register_retry_handlers()
    if retry_handlers_registered then
        return
    end
    if not (SystemData and SystemData.Events) then
        return
    end

    local any_registered = false
    any_registered = register_event(SystemData.Events.ENTER_WORLD, "BookOfGrudges.OnPlayerEnteringWorldOrReload") or any_registered
    any_registered = register_event(SystemData.Events.INTERFACE_RELOADED, "BookOfGrudges.OnPlayerEnteringWorldOrReload") or any_registered
    any_registered = register_event(SystemData.Events.LOADING_END, "BookOfGrudges.OnPlayerEnteringWorldOrReload") or any_registered
    any_registered = register_event(SystemData.Events.PLAYER_CAREER_LINE_UPDATED, "BookOfGrudges.OnPlayerEnteringWorldOrReload") or any_registered
    any_registered = register_event(SystemData.Events.ALL_MODULES_INITIALIZED, "BookOfGrudges.OnPlayerEnteringWorldOrReload") or any_registered
    retry_handlers_registered = any_registered
end

local function unregister_retry_handlers()
    if not retry_handlers_registered then
        return
    end
    if SystemData and SystemData.Events then
        unregister_event(SystemData.Events.ENTER_WORLD, "BookOfGrudges.OnPlayerEnteringWorldOrReload")
        unregister_event(SystemData.Events.INTERFACE_RELOADED, "BookOfGrudges.OnPlayerEnteringWorldOrReload")
        unregister_event(SystemData.Events.LOADING_END, "BookOfGrudges.OnPlayerEnteringWorldOrReload")
        unregister_event(SystemData.Events.PLAYER_CAREER_LINE_UPDATED, "BookOfGrudges.OnPlayerEnteringWorldOrReload")
        unregister_event(SystemData.Events.ALL_MODULES_INITIALIZED, "BookOfGrudges.OnPlayerEnteringWorldOrReload")
    end
    retry_handlers_registered = false
end

local function register_target_handler()
    if target_handler_registered then
        return
    end
    if SystemData and SystemData.Events then
        target_handler_registered = register_event(SystemData.Events.PLAYER_TARGET_UPDATED, "BookOfGrudges.OnPlayerTargetUpdated")
    end
end

local function register_one_slash(command)
    if not (type(LibSlash) == "table" and type(LibSlash.RegisterSlashCmd) == "function") then
        return false
    end

    if type(LibSlash.IsSlashCmdRegistered) == "function" then
        local ok_registered, registered = pcall(LibSlash.IsSlashCmdRegistered, command)
        if ok_registered and registered then
            return true
        end
    end

    local ok = pcall(LibSlash.RegisterSlashCmd, command, BookOfGrudges.OnSlashCommand)
    return ok == true
end

local function register_slash_commands()
    if slash_registered then
        return
    end

    local ok_book = register_one_slash("book")
    local ok_grudge = register_one_slash("grudge")
    slash_registered = ok_book or ok_grudge
end

function BookOfGrudges.OnPlayerEnteringWorldOrReload()
    BookOfGrudges.TryActivate()
end

function BookOfGrudges.TryActivate()
    ensure_saved()

    local is_dwarf = BookOfGrudges.IsDwarf()
    if is_dwarf == nil then
        non_dwarf_checks = 0
        register_retry_handlers()
        return false
    end

    if is_dwarf ~= true then
        active = false
        non_dwarf_checks = non_dwarf_checks + 1
        if non_dwarf_checks < NON_DWARF_CONFIRMATION_CHECKS then
            register_retry_handlers()
        else
            unregister_retry_handlers()
        end
        return false
    end

    active = true
    non_dwarf_checks = 0
    unregister_retry_handlers()
    register_target_handler()
    register_slash_commands()
    return true
end

local function get_friendly_target_name()
    if TargetInfo and type(TargetInfo.UpdateFromClient) == "function" then
        pcall(function() TargetInfo:UpdateFromClient() end)
    end

    if TargetInfo and type(TargetInfo.UnitName) == "function" then
        local ok, name = pcall(function() return TargetInfo:UnitName(FRIENDLY_TARGET) end)
        if ok then
            return name
        end
    end

    return nil
end

local function is_friendly_player_target(event_object_type)
    local ally_player = SystemData and SystemData.TargetObjectType and SystemData.TargetObjectType.ALLY_PLAYER
    if ally_player ~= nil and event_object_type ~= nil and event_object_type ~= ally_player then
        return false
    end

    if TargetInfo and type(TargetInfo.UnitType) == "function" and ally_player ~= nil then
        local ok, unit_type = pcall(function() return TargetInfo:UnitType(FRIENDLY_TARGET) end)
        if ok and unit_type ~= nil and unit_type ~= ally_player then
            return false
        end
    end

    return true
end

local function get_book_entry(key)
    local saved = ensure_saved()
    return saved.book[key]
end

local function get_ignore_row_name(row)
    if type(row) == "table" then
        return row.name or row.m_memberName or row.playerName or row.player_name
    end
    return row
end

function BookOfGrudges.IsIgnoredNameKey(key)
    if key == nil or type(GetIgnoreList) ~= "function" then
        return false
    end

    local ok, ignore_list = pcall(GetIgnoreList)
    if not ok or type(ignore_list) ~= "table" then
        return false
    end

    for _, row in pairs(ignore_list) do
        local row_key = normalize_name(get_ignore_row_name(row))
        if row_key == key then
            return true
        end
    end

    return false
end

function BookOfGrudges.GetBlockSource(key)
    local entry = get_book_entry(key)
    if entry ~= nil then
        return "book"
    end

    local saved = ensure_saved()
    if saved.includeIgnoreList == true and BookOfGrudges.IsIgnoredNameKey(key) then
        return "ignore"
    end

    return nil
end

local function ensure_stat_entry(key, display)
    local saved = ensure_saved()
    local stats = saved.stats[key]
    if type(stats) ~= "table" then
        stats = { name = display, clears = 0 }
        saved.stats[key] = stats
    end

    stats.name = display or stats.name
    stats.clears = tonumber(stats.clears) or 0
    if type(stats.notes) ~= "table" then
        stats.notes = {}
    end
    return stats
end

local function append_note(history, note)
    if type(history) ~= "table" or type(note) ~= "table" then
        return
    end

    table.insert(history, note)
    while #history > MAX_NOTE_HISTORY do
        table.remove(history, 1)
    end
end

local function copy_notes(notes)
    local result = {}
    if type(notes) ~= "table" then
        return result
    end

    for i = 1, #notes do
        result[i] = notes[i]
    end

    return result
end

function BookOfGrudges.RecordClear(key, display)
    local stats = ensure_stat_entry(key, display)
    local timestamp = get_timestamp()
    local note = {
        at = timestamp,
    }

    stats.clears = stats.clears + 1
    stats.lastNotedAt = timestamp
    if stats.firstNotedAt == nil then
        stats.firstNotedAt = timestamp
    end
    append_note(stats.notes, note)

    local saved = ensure_saved()
    local book_entry = saved.book[key]
    if type(book_entry) == "table" then
        book_entry.name = display or book_entry.name
        if type(book_entry.notes) ~= "table" then
            book_entry.notes = {}
        end
        append_note(book_entry.notes, note)
    end

    BookOfGrudges.RefreshWindow()

    return stats
end

local function should_announce(key)
    local now = get_time_seconds()
    local last = last_message_at[key]
    if last ~= nil and now - last < MESSAGE_COOLDOWN_SECONDS then
        return false
    end

    last_message_at[key] = now
    return true
end

function BookOfGrudges.AnnounceClear(key, display, stats)
    if not should_announce(key) then
        return false
    end

    local clears = stats and tonumber(stats.clears) or 1
    local index = ((clears - 1) % #detarget_messages) + 1
    print_chat(string.format(detarget_messages[index], player_link_text(display or "that one")))
    return true
end

function BookOfGrudges.ClearFriendlyTargetIfNeeded(target_name, event_object_type)
    local key, display = normalize_name(target_name)
    if key == nil then
        return false
    end

    if not is_friendly_player_target(event_object_type) then
        return false
    end

    local source = BookOfGrudges.GetBlockSource(key)
    if source == nil then
        return false
    end

    if not (GameData and GameData.TargetType and GameData.TargetType.FRIENDLY and type(ClearTarget) == "function") then
        return false
    end

    local ok = pcall(ClearTarget, GameData.TargetType.FRIENDLY)
    if not ok then
        return false
    end

    local stats = BookOfGrudges.RecordClear(key, display)
    BookOfGrudges.AnnounceClear(key, display, stats)
    return true
end

function BookOfGrudges.OnPlayerTargetUpdated(target_classification, _target_id, target_object_type)
    if active ~= true then
        return
    end
    if target_classification ~= FRIENDLY_TARGET then
        return
    end

    BookOfGrudges.ClearFriendlyTargetIfNeeded(get_friendly_target_name(), target_object_type)
end

function BookOfGrudges.AddName(name)
    local key, display = normalize_name(name)
    if key == nil then
        print_chat("Usage: /book add [name]")
        return false
    end
    if key == get_player_name_key() then
        print_chat("A Dawi does not write himself in the Book.")
        return false
    end

    local saved = ensure_saved()
    local entry = saved.book[key]
    if type(entry) ~= "table" then
        entry = {
            addedAt = get_timestamp(),
            notes = {},
        }
        saved.book[key] = entry
    elseif entry.addedAt == nil then
        entry.addedAt = get_timestamp()
    end

    entry.name = display
    BookOfGrudges.RefreshWindow()
    print_chat(player_link_text(display) .. " entered in the Book.")
    return true
end

function BookOfGrudges.RemoveName(name)
    local key, display = normalize_name(name)
    if key == nil then
        print_chat("Usage: /book remove <name>")
        return false
    end

    local saved = ensure_saved()
    if saved.book[key] ~= nil then
        saved.book[key] = nil
        BookOfGrudges.RefreshWindow()
        print_chat(player_link_text(display) .. " struck from the Book.")
        return true
    end

    print_chat(player_link_text(display) .. " was not in the Book.")
    return false
end

local function clear_name_stats(name)
    local key, display = normalize_name(name)
    if key == nil then
        print_chat("Usage: /book stats <name>")
        return false
    end

    local saved = ensure_saved()
    if saved.stats[key] ~= nil then
        saved.stats[key] = nil
        BookOfGrudges.RefreshWindow()
        print_chat(player_link_text(display) .. " stats cleared.")
        return true
    end

    print_chat(player_link_text(display) .. " had no stats.")
    return false
end

local function remove_name_and_stats(name)
    local key, display = normalize_name(name)
    if key == nil then
        print_chat("Usage: /book remove <name>")
        return false
    end

    local saved = ensure_saved()
    local had_book = saved.book[key] ~= nil
    local had_stats = saved.stats[key] ~= nil

    if had_book then
        saved.book[key] = nil
    end
    if had_stats then
        saved.stats[key] = nil
    end

    if had_book or had_stats then
        BookOfGrudges.RefreshWindow()
        if had_book and had_stats then
            print_chat(player_link_text(display) .. " struck from the Book; stats cleared.")
        elseif had_book then
            print_chat(player_link_text(display) .. " struck from the Book.")
        else
            print_chat(player_link_text(display) .. " stats cleared.")
        end
        return true
    end

    print_chat(player_link_text(display) .. " was not in the Book and had no stats.")
    return false
end

local function sorted_entries(source)
    local rows = {}
    if type(source) ~= "table" then
        return rows
    end

    for key, entry in pairs(source) do
        if type(entry) == "table" then
            rows[#rows + 1] = { key = key, name = entry.name or key, clears = tonumber(entry.clears) or 0 }
        end
    end

    table.sort(rows, function(a, b)
        if a.clears ~= b.clears then
            return a.clears > b.clears
        end
        return tostring(a.name) < tostring(b.name)
    end)

    return rows
end

function BookOfGrudges.PrintList()
    local rows = sorted_entries(ensure_saved().book)
    if #rows == 0 then
        print_chat("The Book is empty.")
        return
    end

    local names = {}
    for i = 1, #rows do
        names[#names + 1] = player_link_text(rows[i].name)
    end
    print_chat("Book: " .. table.concat(names, ", "))
end

function BookOfGrudges.PrintStats(name)
    local saved = ensure_saved()
    local key, display = normalize_name(name)
    if key ~= nil then
        local stats = saved.stats[key]
        local book_entry = saved.book[key]
        local written_text = type(book_entry) == "table" and format_timestamp(book_entry.addedAt) or "not written"
        if type(stats) ~= "table" then
            print_chat(player_link_text(display or name) .. ": 0 clears; written " .. written_text .. "; no marks.")
            return
        end

        local clears = tonumber(stats.clears) or 0
        local clear_label = clears == 1 and "clear" or "clears"

        print_chat(player_link_text(stats.name or display) .. ": " .. tostring(clears) .. " " .. clear_label .. "; written " .. written_text .. "; first mark " .. format_timestamp(stats.firstNotedAt) .. "; last mark " .. format_timestamp(stats.lastNotedAt) .. ".")
        return
    end

    local rows = sorted_entries(saved.stats)
    if #rows == 0 then
        print_chat("No grudges settled yet.")
        return
    end

    local parts = {}
    local total_clears = 0
    for i = 1, #rows do
        total_clears = total_clears + rows[i].clears
    end
    for i = 1, #rows do
        if i > 5 then
            break
        end
        parts[#parts + 1] = player_link_text(rows[i].name) .. " " .. format_count_percent(rows[i].clears, total_clears)
    end
    print_chat("Top clears: " .. table.concat(parts, ", "))
end

function BookOfGrudges.TestPopulate()
    local saved = ensure_saved()

    for i = 1, #test_names do
        local key, display = normalize_name(test_names[i])
        if key ~= nil then
            local clears = ((i * 7) % 23) + 1
            local note_count = clears
            if note_count > MAX_NOTE_HISTORY then
                note_count = MAX_NOTE_HISTORY
            end

            local added_days = (#test_names - i) + 14
            local notes = {}
            for note_index = 1, note_count do
                notes[note_index] = {
                    at = timestamp_days_ago(note_count - note_index, (i * 97) + note_index),
                }
            end

            saved.book[key] = {
                name = display,
                addedAt = timestamp_days_ago(added_days, i * 317),
                notes = copy_notes(notes),
            }
            saved.stats[key] = {
                name = display,
                clears = clears,
                firstNotedAt = timestamp_days_ago(added_days - 1, i * 251),
                lastNotedAt = timestamp_days_ago(i % 9, i * 173),
                notes = copy_notes(notes),
            }
        end
    end

    BookOfGrudges.RefreshWindow()
    print_chat("Test Book populated with " .. tostring(#test_names) .. " entries.")
end

local function count_table_entries(source)
    local count = 0
    if type(source) ~= "table" then
        return 0
    end

    for _ in pairs(source) do
        count = count + 1
    end

    return count
end

local function count_text(count, singular, plural)
    if count == 1 then
        return "1 " .. singular
    end
    return tostring(count) .. " " .. plural
end

local function clear_book_and_stats()
    local saved = ensure_saved()
    local book_count = count_table_entries(saved.book)
    local stats_count = count_table_entries(saved.stats)

    saved.book = {}
    saved.stats = {}
    BookOfGrudges.RefreshWindow()
    print_chat("Book and stats cleared: " .. count_text(book_count, "Book entry", "Book entries") .. ", " .. count_text(stats_count, "stats entry", "stats entries") .. " removed.")
    return book_count > 0 or stats_count > 0
end

local function count_total_clears(source)
    local names = 0
    local clears = 0
    if type(source) ~= "table" then
        return 0, 0
    end

    for _, stats in pairs(source) do
        if type(stats) == "table" then
            names = names + 1
            clears = clears + (tonumber(stats.clears) or 0)
        end
    end

    return names, clears
end

function BookOfGrudges.PrintStatus()
    local saved = ensure_saved()
    local active_text = active == true and "active" or "inactive"
    local ignore_text = saved.includeIgnoreList == true and "on" or "off"
    local book_count = count_table_entries(saved.book)
    local stat_names, stat_clears = count_total_clears(saved.stats)
    local book_label = book_count == 1 and "entry" or "entries"
    local name_label = stat_names == 1 and "name" or "names"
    local clear_label = stat_clears == 1 and "clear" or "clears"

    print_chat("Status: " .. active_text .. " (v" .. tostring(BookOfGrudges.VERSION) .. ")")
    print_chat("Book: " .. tostring(book_count) .. " " .. book_label .. " - Ignore source: " .. ignore_text)
    print_chat("Stats: " .. tostring(stat_names) .. " " .. name_label .. " - " .. tostring(stat_clears) .. " " .. clear_label)
end

local function window_exists(name)
    if type(DoesWindowExist) ~= "function" then
        return ui_window_created == true
    end

    local ok, exists = pcall(DoesWindowExist, name)
    return ok == true and exists == true
end

local function set_window_showing(name, showing)
    ui_window_visible = showing == true
    if type(WindowSetShowing) == "function" then
        pcall(WindowSetShowing, name, showing == true)
    end
end

local function set_label_text(window_name, text)
    if type(LabelSetText) == "function" then
        pcall(LabelSetText, window_name, to_wstring(text or ""))
    end
end

local function set_label_color(window_name, r, g, b)
    if type(LabelSetTextColor) == "function" then
        pcall(LabelSetTextColor, window_name, r, g, b)
    end
end

local function sort_header_text(column, label)
    if ui_sort_column ~= column then
        return label
    end
    if ui_sort_descending then
        return label .. " v"
    end
    return label .. " ^"
end

local function active_window_name(fallback)
    if type(SystemData) == "table" then
        if type(SystemData.ActiveWindow) == "table" and type(SystemData.ActiveWindow.name) == "string" and SystemData.ActiveWindow.name ~= "" then
            return SystemData.ActiveWindow.name
        end
        if type(SystemData.MouseOverWindow) == "table" and type(SystemData.MouseOverWindow.name) == "string" and SystemData.MouseOverWindow.name ~= "" then
            return SystemData.MouseOverWindow.name
        end
    end
    return fallback
end

local function create_context_menu(title)
    if type(EA_Window_ContextMenu) ~= "table"
        or type(EA_Window_ContextMenu.CreateContextMenu) ~= "function"
        or type(EA_Window_ContextMenu.AddMenuItem) ~= "function"
        or type(EA_Window_ContextMenu.Finalize) ~= "function" then
        return nil, nil
    end

    local menu_id = EA_Window_ContextMenu.CONTEXT_MENU_1 or 1
    local ok = pcall(EA_Window_ContextMenu.CreateContextMenu, active_window_name(WINDOW_NAME), menu_id, to_wstring(title))
    if not ok then
        return nil, nil
    end

    return EA_Window_ContextMenu, menu_id
end

local function add_context_menu_item(menu, menu_id, label, callback, disabled)
    pcall(menu.AddMenuItem, to_wstring(label), callback, disabled == true, true, menu_id)
end

local function finish_context_menu(menu, menu_id)
    pcall(menu.Finalize, menu_id)
end

local function positive_index(value)
    local number = tonumber(value)
    if number == nil or number <= 0 then
        return nil
    end
    return math.floor(number)
end

local function ui_row_at(index)
    local row_index = positive_index(index)
    if row_index == nil or type(BookOfGrudges.uiRows) ~= "table" then
        return nil
    end
    return BookOfGrudges.uiRows[row_index]
end

local function row_from_list_index(row_index)
    local index = positive_index(row_index)
    if index == nil then
        return nil
    end

    if type(ListBoxGetDataIndex) == "function" then
        local ok, data_index = pcall(ListBoxGetDataIndex, WINDOW_NAME .. "List", index)
        local row = ok and ui_row_at(data_index) or nil
        if type(row) == "table" then
            return row
        end
    end

    return ui_row_at(index)
end

local function row_from_window_name(window_name)
    if type(WindowGetId) ~= "function" or type(window_name) ~= "string" or window_name == "" then
        return nil
    end

    local ok, row_id = pcall(WindowGetId, window_name)
    if not ok then
        return nil
    end

    return row_from_list_index(row_id)
end

local function resolve_ui_row(row_id)
    local row = row_from_list_index(row_id)
    if type(row) == "table" then
        return row
    end

    if type(SystemData) == "table" then
        if type(SystemData.ActiveWindow) == "table" then
            row = row_from_window_name(SystemData.ActiveWindow.name)
            if type(row) == "table" then
                return row
            end
        end
        if type(SystemData.MouseOverWindow) == "table" then
            row = row_from_window_name(SystemData.MouseOverWindow.name)
            if type(row) == "table" then
                return row
            end
        end
    end

    return nil
end

local function setup_window_labels()
    set_label_text(WINDOW_NAME .. "TitleBarText", "Book of Grudges")
    set_label_text(WINDOW_NAME .. "NameHeader", sort_header_text("name", "Name"))
    set_label_text(WINDOW_NAME .. "ClearsHeader", sort_header_text("clears", "Clears"))
    set_label_text(WINDOW_NAME .. "AddedHeader", sort_header_text("written", "Written"))
    set_label_text(WINDOW_NAME .. "LastHeader", sort_header_text("last", "Last mark"))

    set_label_color(WINDOW_NAME .. "SummaryLabel", 255, 218, 73)
    set_label_color(WINDOW_NAME .. "IgnoreSourceLabel", 255, 218, 73)
    set_label_color(WINDOW_NAME .. "StatsSummaryLabel", 255, 218, 73)
    set_label_color(WINDOW_NAME .. "StatusLabel", 205, 170, 75)
end

local function add_ui_row(rows, key, row)
    local stats = type(row.stats) == "table" and row.stats or {}
    local book_entry = type(row.bookEntry) == "table" and row.bookEntry or nil
    local clears = tonumber(stats.clears) or 0
    local added_text = "-"
    local last_text = "-"

    if book_entry ~= nil then
        added_text = format_timestamp(book_entry.addedAt)
    end
    if stats.lastNotedAt ~= nil then
        last_text = format_timestamp(stats.lastNotedAt)
    end

    rows[#rows + 1] = {
        key = key,
        displayName = row.name or key,
        name = to_wstring(row.name or key),
        nameSort = string.lower(to_plain_string(row.name or key)),
        clears = clears,
        clearsText = to_wstring(tostring(clears)),
        addedSort = book_entry ~= nil and timestamp_sort_value(book_entry.addedAt) or 0,
        addedText = to_wstring(added_text),
        lastSort = timestamp_sort_value(stats.lastNotedAt),
        lastText = to_wstring(last_text),
    }
end

local function ui_sort_value(row)
    if ui_sort_column == "name" then
        return row.nameSort or ""
    elseif ui_sort_column == "written" then
        return tonumber(row.addedSort) or 0
    elseif ui_sort_column == "last" then
        return tonumber(row.lastSort) or 0
    end
    return tonumber(row.clears) or 0
end

local function compare_ui_rows(a, b)
    local a_value = ui_sort_value(a)
    local b_value = ui_sort_value(b)
    if a_value ~= b_value then
        if ui_sort_descending then
            return a_value > b_value
        end
        return a_value < b_value
    end
    return (a.nameSort or "") < (b.nameSort or "")
end

local function set_ui_sort(column, descending)
    if ui_sort_column == column then
        ui_sort_descending = not ui_sort_descending
    else
        ui_sort_column = column
        ui_sort_descending = descending == true
    end
    setup_window_labels()
    BookOfGrudges.RefreshWindow(true)
end

local function build_ui_rows()
    local saved = ensure_saved()
    local by_key = {}

    for key, entry in pairs(saved.book) do
        if type(entry) == "table" then
            by_key[key] = {
                key = key,
                name = entry.name or key,
                bookEntry = entry,
            }
        else
            by_key[key] = {
                key = key,
                name = tostring(entry or key),
            }
        end
    end

    for key, stats in pairs(saved.stats) do
        if type(stats) == "table" then
            local row = by_key[key] or { key = key }
            row.stats = stats
            row.name = stats.name or row.name or key
            by_key[key] = row
        end
    end

    local rows = {}
    for key, row in pairs(by_key) do
        add_ui_row(rows, key, row)
    end

    table.sort(rows, compare_ui_rows)

    return rows
end

function BookOfGrudges.EnsureWindow()
    if ui_window_created == true and window_exists(WINDOW_NAME) then
        return true
    end
    if type(CreateWindow) ~= "function" then
        return false
    end

    if not window_exists(WINDOW_NAME) then
        local ok = pcall(CreateWindow, WINDOW_NAME, false)
        if not ok then
            return false
        end
    end

    ui_window_created = true
    setup_window_labels()
    if type(LayoutEditor) == "table" and type(LayoutEditor.RegisterWindow) == "function" then
        pcall(LayoutEditor.RegisterWindow, WINDOW_NAME, to_wstring("Book of Grudges"), to_wstring("Book entries and grudge stats"), false, false, true, nil)
    end
    return true
end

function BookOfGrudges.RefreshWindow(force)
    if force ~= true and ui_window_visible ~= true then
        return BookOfGrudges.uiRows
    end
    if not window_exists(WINDOW_NAME) then
        return BookOfGrudges.uiRows
    end

    local rows = build_ui_rows()
    BookOfGrudges.uiRows = rows
    local saved = ensure_saved()
    local stat_names, stat_clears = count_total_clears(saved.stats)
    local ignore_text = saved.includeIgnoreList == true and "on" or "off"

    set_label_text(WINDOW_NAME .. "SummaryLabel", "Book entries: " .. tostring(count_table_entries(saved.book)))
    set_label_text(WINDOW_NAME .. "IgnoreSourceLabel", "Ignore source: " .. ignore_text)
    set_label_text(WINDOW_NAME .. "StatsSummaryLabel", "Stats: " .. tostring(stat_names) .. " names, " .. tostring(stat_clears) .. " clears")
    if #rows == 0 then
        set_label_text(WINDOW_NAME .. "StatusLabel", "No grudges entered or noted yet.")
    else
        set_label_text(WINDOW_NAME .. "StatusLabel", "Showing " .. tostring(#rows) .. " grudges and noted names.")
    end

    if type(ListBoxSetDisplayOrder) == "function" then
        local order = {}
        for i = 1, #rows do
            order[i] = i
        end
        pcall(ListBoxSetDisplayOrder, WINDOW_NAME .. "List", order)
    end

    return rows
end

function BookOfGrudges.OnWindowRowRButtonUp(_flags, row_id)
    local row = resolve_ui_row(row_id)
    if type(row) ~= "table" then
        return false
    end

    local display = to_plain_string(row.displayName or row.name or row.key)
    local menu, menu_id = create_context_menu(display)
    if menu == nil then
        return false
    end

    local saved = ensure_saved()
    local has_book = saved.book[row.key] ~= nil
    local has_stats = saved.stats[row.key] ~= nil

    add_context_menu_item(menu, menu_id, "Stats", function() BookOfGrudges.PrintStats(display) end, false)
    add_context_menu_item(menu, menu_id, "Remove from Book", function() BookOfGrudges.RemoveName(display) end, not has_book)
    add_context_menu_item(menu, menu_id, "Clear stats", function() clear_name_stats(display) end, not has_stats)
    add_context_menu_item(menu, menu_id, "Remove and clear stats", function() remove_name_and_stats(display) end, not (has_book or has_stats))
    finish_context_menu(menu, menu_id)
    return true
end

function BookOfGrudges.SortByName()
    set_ui_sort("name", false)
end

function BookOfGrudges.SortByClears()
    set_ui_sort("clears", true)
end

function BookOfGrudges.SortByWritten()
    set_ui_sort("written", true)
end

function BookOfGrudges.SortByLastMark()
    set_ui_sort("last", true)
end

function BookOfGrudges.ShowWindow()
    if active ~= true then
        return false
    end
    if BookOfGrudges.EnsureWindow() ~= true then
        print_chat("Book window unavailable.")
        return false
    end

    BookOfGrudges.RefreshWindow(true)
    set_window_showing(WINDOW_NAME, true)
    return true
end

function BookOfGrudges.HideWindow()
    set_window_showing(WINDOW_NAME, false)
end

function BookOfGrudges.OnWindowShown()
    ui_window_visible = true
    BookOfGrudges.RefreshWindow(true)
end

local function set_ignore_enabled(enabled)
    ensure_saved().includeIgnoreList = enabled == true
    BookOfGrudges.RefreshWindow()
    if enabled then
        print_chat("Ignore list grudges: on.")
    else
        print_chat("Ignore list grudges: off.")
    end
end

function BookOfGrudges.ShowIgnoreSourceMenu()
    local saved = ensure_saved()
    local menu, menu_id = create_context_menu("Ignore source")
    if menu == nil then
        return false
    end

    add_context_menu_item(menu, menu_id, "Turn ignore source on", function() set_ignore_enabled(true) end, saved.includeIgnoreList == true)
    add_context_menu_item(menu, menu_id, "Turn ignore source off", function() set_ignore_enabled(false) end, saved.includeIgnoreList ~= true)
    add_context_menu_item(menu, menu_id, "Toggle ignore source", function() set_ignore_enabled(ensure_saved().includeIgnoreList ~= true) end, false)
    finish_context_menu(menu, menu_id)
    return true
end

function BookOfGrudges.OnIgnoreSourceLButtonUp()
    return BookOfGrudges.ShowIgnoreSourceMenu()
end

function BookOfGrudges.OnIgnoreSourceRButtonUp()
    return BookOfGrudges.ShowIgnoreSourceMenu()
end

function BookOfGrudges.OnStatsSummaryRButtonUp()
    local saved = ensure_saved()
    local menu, menu_id = create_context_menu("Stats")
    if menu == nil then
        return false
    end

    add_context_menu_item(menu, menu_id, "Clear Book and stats", clear_book_and_stats, next(saved.book) == nil and next(saved.stats) == nil)
    finish_context_menu(menu, menu_id)
    return true
end

function BookOfGrudges.PrintUsage()
    print_chat("Commands (/book):")
    print_chat("Book: /book add [name], /book remove <name>, /book list, /book clear")
    print_chat("UI: /book open, /book close")
    print_chat("Stats: /book status, /book stats [name], /book stats clear")
    print_chat("Ignore: /book ignore on|off|toggle|status")
end

function BookOfGrudges.OnSlashCommand(input)
    local text = trim(input)
    local command, rest = string.match(text, "^(%S+)%s*(.-)%s*$")

    command = string.lower(command or "")
    rest = trim(rest or "")

    if command == "" or command == "help" then
        BookOfGrudges.PrintUsage()
        return
    end

    if command == "add" then
        if rest == "" then
            BookOfGrudges.AddName(get_friendly_target_name())
        else
            BookOfGrudges.AddName(rest)
        end
    elseif command == "remove" or command == "delete" or command == "del" then
        BookOfGrudges.RemoveName(rest)
    elseif command == "list" then
        BookOfGrudges.PrintList()
    elseif command == "clear" then
        local saved = ensure_saved()
        local book_count = count_table_entries(saved.book)
        saved.book = {}
        BookOfGrudges.RefreshWindow()
        print_chat("Book cleared: " .. count_text(book_count, "entry", "entries") .. " removed.")
    elseif command == "stats" then
        local subcommand = string.lower(rest)
        if subcommand == "clear" or subcommand == "reset" then
            local saved = ensure_saved()
            local stats_count = count_table_entries(saved.stats)
            saved.stats = {}
            BookOfGrudges.RefreshWindow()
            print_chat("Stats cleared: " .. count_text(stats_count, "entry", "entries") .. " removed.")
        else
            BookOfGrudges.PrintStats(rest)
        end
    elseif command == "status" then
        BookOfGrudges.PrintStatus()
    elseif command == "open" or command == "show" or command == "window" or command == "ui" then
        BookOfGrudges.ShowWindow()
    elseif command == "close" or command == "hide" then
        BookOfGrudges.HideWindow()
    elseif command == "testpopulate" then
        BookOfGrudges.TestPopulate()
    elseif command == "ignore" or command == "ignorelist" then
        local saved = ensure_saved()
        local action = string.lower(rest)
        if action == "on" or action == "enable" or action == "enabled" then
            set_ignore_enabled(true)
        elseif action == "off" or action == "disable" or action == "disabled" then
            set_ignore_enabled(false)
        elseif action == "toggle" then
            set_ignore_enabled(saved.includeIgnoreList ~= true)
        elseif action == "status" or action == "" then
            set_ignore_enabled(saved.includeIgnoreList == true)
        else
            print_chat("Usage: /book ignore on|off|toggle|status")
        end
    else
        BookOfGrudges.PrintUsage()
    end
end

function BookOfGrudges.OnInitialize()
    BookOfGrudges.TryActivate()
end
