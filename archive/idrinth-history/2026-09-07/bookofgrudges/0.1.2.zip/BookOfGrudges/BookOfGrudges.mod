<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <UiMod name="BookOfGrudges" version="0.1.2" date="26/05/2026">
    <Author name="Wholdar (Dumgi/Benmerj)" />

    <Dependencies>
      <Dependency name="LibSlash" optional="true" forceEnable="true" />
      <Dependency name="EA_ContextMenu" />
    </Dependencies>

    <Description text="Dwarf-only &quot;friendly&quot; target cleaner for names in your Book of Grudges or optionally your ignore list." />

    <Files>
      <File name="BookOfGrudges.lua" />
      <File name="BookOfGrudges.xml" />
    </Files>

    <OnInitialize>
      <CallFunction name="BookOfGrudges.OnInitialize" />
    </OnInitialize>

    <SavedVariables>
      <SavedVariable name="BookOfGrudges.saved" />
    </SavedVariables>

    <VersionSettings gameVersion="1.4.8" windowsVersion="1.0" savedVariablesVersion="1.0" />

    <WARInfo>
      <Categories>
        <Category name="SOCIAL" />
      </Categories>
      <Careers>
        <Career name="RUNE_PRIEST" />
        <Career name="IRON_BREAKER" />
      </Careers>
    </WARInfo>
  </UiMod>
</ModuleFile>
