<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
    <UiMod name="PeaceOut" version="1.0" date="10/29/2008">
        <Author name="NigelTufnel" email="adam.dew@gmail.com" />
        <Description text="Peace Out provides a logout dialog to give more direct feel to the logoff/exit process. If libslash is enabled, you can optionally enable the registering of the /exit and /logoff commands with PeaceOut by using /peaceout to toggle the usage of these commands." />
		<Dependencies />
        <Files>
            <File name="PeaceOut.lua" />
            <File name="PeaceOut.xml" />
        </Files>
        <OnInitialize>
            <CallFunction name="PeaceOut.Init" />
        </OnInitialize>
		<SavedVariables>
			<SavedVariable name="PO_UseSlash"/>
		</SavedVariables>
		<OnUpdate />
        <OnShutdown />
    </UiMod>
</ModuleFile>