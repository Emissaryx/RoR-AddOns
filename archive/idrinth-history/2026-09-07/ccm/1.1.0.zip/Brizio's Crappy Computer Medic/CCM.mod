<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
    <UiMod name="Brizio's Crappy Computer Medic" version="1.00" date="15/11/2017" >
    <Author name="Brizio" email="find me in RoR Forums!" />
    <Description text="Lagging everytime you join a keep fight? Have a old sore computer? This addon is for you! It helps you quick switch between video configs!" />
    <VersionSettings gameVersion="1.4.8" windowsVersion="1.0" savedVariablesVersion="1.0" />
	
    <Dependencies>
      <Dependency name="LibSlash" optional="true" forceEnable="true" />
    </Dependencies>
	
    <Files>
      <File name="CCM.lua" />
      <File name="CCM_GUI.xml" />	
    </Files>
        
    <OnInitialize>
      <CallFunction name="CCM.OnInitialize" />
    </OnInitialize> 
    
    <OnShutdown>
      <CallFunction name="CCM.OnShutdown" />
		</OnShutdown>
    
    <SavedVariables>
    </SavedVariables>
		
    
    <WARInfo>
      <Categories>
        <Category name="SYSTEM" />
        <Category name="OTHER" />
      </Categories>
      <Careers>
        <Career name="BLACKGUARD" />
        <Career name="WITCH_ELF" />
        <Career name="DISCIPLE" />
        <Career name="SORCERER" />
        <Career name="IRON_BREAKER" />
        <Career name="SLAYER" />
        <Career name="RUNE_PRIEST" />
        <Career name="ENGINEER" />
        <Career name="BLACK_ORC" />
        <Career name="CHOPPA" />
        <Career name="SHAMAN" />
        <Career name="SQUIG_HERDER" />
        <Career name="WITCH_HUNTER" />
        <Career name="KNIGHT" />
        <Career name="BRIGHT_WIZARD" />
        <Career name="WARRIOR_PRIEST" />
        <Career name="CHOSEN" />
        <Career name= "MARAUDER" />
        <Career name="ZEALOT" />
        <Career name="MAGUS" />
        <Career name="SWORDMASTER" />
        <Career name="SHADOW_WARRIOR" />
        <Career name="WHITE_LION" />
        <Career name="ARCHMAGE" />
      </Careers>
    </WARInfo>
	</UiMod>
</ModuleFile>