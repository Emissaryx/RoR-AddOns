if not NervAlert then NervAlert = {} end

local destroMorales = {	
	name = {
		"Sever Nerve",
		"Flames of Fate",
		"Deafening Bellow",
		"Scintillating Energy",
		"Great Fang",
		"Web of Shadows",
		"Supa Chop",
		"Tzeentch's Reversal",
		"Unleash The Winds",
		"Daemonic Winds",
		"Windblock",
		"Energy Ripple",
		"Lots Of Shootin",
		"Universal Confusion"
	},
	message = {
		towstring("/p I'm hit by <icon=943> <LINK data=\"0\" text=\"[M1] Sever Nerve 1200\" color=\"255,50,50\">"),
		towstring("/p I'm hit by <icon=20192> <LINK data=\"0\" text=\"[M1] Flames of Fate 900\" color=\"255,50,50\">"),
		towstring("/p I'm hit by <icon=20182> <LINK data=\"0\" text=\"[M3] Deafening Bellow 1200\" color=\"255,50,50\">"),
		towstring("/p I'm hit by <icon=943> <LINK data=\"0\" text=\"[M3] Scintillating Energy 800\" color=\"255,50,50\">"),
		towstring("/p I'm hit by <icon=20192> <LINK data=\"0\" text=\"[M2] Great Fang 1200\" color=\"255,50,50\">"),
		towstring("/p I'm hit by <icon=20201> <LINK data=\"0\" text=\"[M2] Web of Shadows 1200\" color=\"255,50,50\">"),
		towstring("/p I'm hit by <icon=20184> <LINK data=\"0\" text=\"[M3] Supa Chop 1800\" color=\"255,50,50\">"),
		towstring("/p I'm hit by <icon=20192> <LINK data=\"0\" text=\"[M3] Tzeentch's Reversal 1200\" color=\"255,50,50\">"),
		towstring("/p I'm hit by <icon=943> <LINK data=\"0\" text=\"[M4] Unleash The Winds 1800\" color=\"255,50,50\">"),
		towstring("/p I'm hit by <icon=20191> <LINK data=\"0\" text=\"[M4] Daemonic Winds 1600\" color=\"255,50,50\">"),
		towstring("/p I'm hit by <icon=20203> <LINK data=\"0\" text=\"[M4] Windblock 1200\" color=\"255,50,50\">"),
		towstring("/p I'm hit by <icon=20192> <LINK data=\"0\" text=\"[M4] Energy Ripple 1200\" color=\"255,50,50\">"),
		towstring("/p I'm hit by <icon=20197> <LINK data=\"0\" text=\"[M4] Lots Of Shootin 1600\" color=\"255,50,50\">"),
		towstring("/p I'm hit by <icon=20186> <LINK data=\"0\" text=\"[M3] Universal Confusion 1200\" color=\"255,50,50\">")
	}	
}

local orderMorales = {
	name = {
		"Sever Nerve",
		"Ensnare",
		"Reversal of Fortune",
		"Scintillating Energy",
		"No Escape hits you for 1200", -- slayer has an ability with the same name
		"Cannon Smash",
		"Dominance",
		"Grievous Harm",
		"Doom Seeker",
		"Ruin and Destruction",
		"The Burning Head",
		"Unleash The Winds",
		"Instill Fear",
		"Whirling Rage",
		--"Solar Flare",
		"Penance"
	},
	message = {
		towstring("/p I'm hit by <icon=943> <LINK data=\"0\" text=\"[M1] Sever Nerve 1200\" color=\"255,50,50\">"),
		towstring("/p I'm hit by <icon=20200> <LINK data=\"0\" text=\"[M1] Ensnare 900\" color=\"255,50,50\">"),
		towstring("/p I'm hit by <icon=20202> <LINK data=\"0\" text=\"[M2] Reversal of Fortune 1200\" color=\"255,50,50\">"),
		towstring("/p I'm hit by <icon=943> <LINK data=\"0\" text=\"[M3] Scintillating Energy 800\" color=\"255,50,50\">"),
		towstring("/p I'm hit by <icon=20190> <LINK data=\"0\" text=\"[M3] No Escape 1200\" color=\"255,50,50\">"),
		towstring("/p I'm hit by <icon=20187> <LINK data=\"0\" text=\"[M3] Cannon Smash 2400\" color=\"255,50,50\">"),
		towstring("/p I'm hit by <icon=20200> <LINK data=\"0\" text=\"[M3] Dominance 1800\" color=\"255,50,50\">"),
		towstring("/p I'm hit by <icon=20188> <LINK data=\"0\" text=\"[M3] Grievous Harm 1800\" color=\"255,50,50\">"),
		towstring("/p I'm hit by <icon=20188> <LINK data=\"0\" text=\"[M3] Doom Seeker 1200\" color=\"255,50,50\">"),
		towstring("/p I'm hit by <icon=20183> <LINK data=\"0\" text=\"[M2] Ruin and Destruction 1200\" color=\"255,50,50\">"),
		towstring("/p I'm hit by <icon=20183> <LINK data=\"0\" text=\"[M4] The Burning Head 1600\" color=\"255,50,50\">"),
		towstring("/p I'm hit by <icon=943> <LINK data=\"0\" text=\"[M4] Unleash The Winds 1800\" color=\"255,50,50\">"),
		towstring("/p I'm hit by <icon=20194> <LINK data=\"0\" text=\"[M3] Instill Fear 1200\" color=\"255,50,50\">"),
		towstring("/p I'm hit by <icon=20194> <LINK data=\"0\" text=\"[M4] Whirling Rage 1600\" color=\"255,50,50\">"),
		--towstring("/p I'm hit by <icon=20190> <LINK data=\"0\" text=\"[M4] Solar Flare 800\" color=\"255,50,50\">"),
		towstring("/p I'm hit by <icon=20199> <LINK data=\"0\" text=\"[M3] Penance 1200\" color=\"255,50,50\">")
	}
}

local moraleList

function NervAlert.OnInitialize()

	-- choose morale list based on players faction
	if (GameData.Player.realm == 2) then
		moraleList = orderMorales
	elseif (GameData.Player.realm == 1) then
		moraleList = destroMorales
	end

	RegisterEventHandler(TextLogGetUpdateEventId("Combat"), "NervAlert.OnChatLogUpdated")

end

local ts = tostring
local tn = tonumber
local stringfind = string.find
local stringmatch = string.match
local tlge = TextLogGetEntry

local damageMinimum = 800
local dmgMessagePattern = "hits you for (%d+) "

function NervAlert.OnChatLogUpdated(updateType, filterType)

	-- only look at new chat lines
	if not (updateType == SystemData.TextLogUpdate.ADDED) then
		return
	end	

	-- only look at damage from players 
	if not(filterType == 1001) then
		return
	end

	local _, filterId, text = tlge( "Combat", TextLogGetNumEntries("Combat") - 1 )
	text = ts(text)

	local damage = tn(stringmatch(text,dmgMessagePattern))
	
	-- only look at damage above minimum
	if (damage == nil) or (damage < damageMinimum) then
		return
	end
	
	-- check for morales
	for i, name in ipairs(moraleList.name) do
		--d("checking for "..ts(moraleList.message[i]))
		if stringfind(text,name) then
			SendChatText(moraleList.message[i], L"")
			return
		end
	end
	
end