<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
	<UiMod name="NervAlert" version="1.11" date="13/04/2017" >
		<VersionSettings gameVersion="1.4.8" windowsVersion="1.0" savedVariablesVersion="1.0" />
		<Author name="Caffeine"/>
		<Description text="Alerts your party when you get hit by a damaging morale." />
		<Files>
			<File name="NervAlert.lua" />
		</Files>
		<OnInitialize>
			<CallFunction name="NervAlert.OnInitialize" /> 
		</OnInitialize>
		<OnUpdate>
    	</OnUpdate>
        <OnShutdown>
        </OnShutdown>		
	</UiMod>
</ModuleFile>