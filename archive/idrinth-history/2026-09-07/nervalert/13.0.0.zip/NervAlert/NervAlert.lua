if not NervAlert then NervAlert = {} end

-- LUA locals for performance
local tostring = tostring
local tonumber = tonumber
local stringfind = string.find
local string_match = string.match
local TextLogGetEntry = TextLogGetEntry
local TextLogGetNumEntries = TextLogGetNumEntries
local SendChatText = SendChatText

local damageMinimum = 900;

local destroMorales = {};
destroMorales[L"Sever Nerve"] = 			L"/p I'm hit by <icon=943> <LINK data=\"0\" text=\"[M1] Sever Nerve 1200\" color=\"255,50,50\">";
destroMorales[L"Flames of Fate"] =			L"/p I'm hit by <icon=20192> <LINK data=\"0\" text=\"[M1] Flames of Fate 900\" color=\"255,50,50\">";
destroMorales[L"Deafening Bellow"] = 		L"/p I'm hit by <icon=20182> <LINK data=\"0\" text=\"[M3] Deafening Bellow 1200\" color=\"255,50,50\">";
destroMorales[L"Scintillating Energy"] =	L"/p I'm hit by <icon=943> <LINK data=\"0\" text=\"[M3] Scintillating Energy 1200\" color=\"255,50,50\">";
destroMorales[L"Great Fang"] = 				L"/p I'm hit by <icon=20192> <LINK data=\"0\" text=\"[M2] Great Fang 1200\" color=\"255,50,50\">";
destroMorales[L"Web of Shadows"] =			L"/p I'm hit by <icon=20201> <LINK data=\"0\" text=\"[M2] Web of Shadows 1200\" color=\"255,50,50\">";
destroMorales[L"Supa Chop"] =				L"/p I'm hit by <icon=20184> <LINK data=\"0\" text=\"[M3] Supa Chop 1800\" color=\"255,50,50\">";
destroMorales[L"Tzeentch's Reversal"] =		L"/p I'm hit by <icon=20192> <LINK data=\"0\" text=\"[M3] Tzeentch's Reversal 1200\" color=\"255,50,50\">";
destroMorales[L"Unleash The Winds"] =		L"/p I'm hit by <icon=943> <LINK data=\"0\" text=\"[M4] Unleash The Winds 1800\" color=\"255,50,50\">";
destroMorales[L"Daemonic Winds"] =			L"/p I'm hit by <icon=20191> <LINK data=\"0\" text=\"[M4] Daemonic Winds 1600\" color=\"255,50,50\">";
destroMorales[L"Windblock"] =				L"/p I'm hit by <icon=20203> <LINK data=\"0\" text=\"[M4] Windblock 1200\" color=\"255,50,50\">";
destroMorales[L"Energy Ripple"] =			L"/p I'm hit by <icon=20192> <LINK data=\"0\" text=\"[M4] Energy Ripple 1200\" color=\"255,50,50\">";
destroMorales[L"Lots Of Shootin"] =			L"/p I'm hit by <icon=20197> <LINK data=\"0\" text=\"[M4] Lots Of Shootin 1600\" color=\"255,50,50\">";
destroMorales[L"Wind Up Da Waaagh"] =		L"/p I'm hit by <icon=20197> <LINK data=\"0\" text=\"[M4] Wind Up Da Waaagh 2400\" color=\"255,50,50\">";
destroMorales[L"Yer Goin Down!"] =			L"/p I'm hit by <icon=20197> <LINK data=\"0\" text=\"[M4] Yer Goin Down! 1200\" color=\"255,50,50\">";
destroMorales[L"Yer Goin Down!"] =			L"/p I'm hit by <icon=20197> <LINK data=\"0\" text=\"[M4] Yer Nothin 1200\" color=\"255,50,50\">";
destroMorales[L"Universal Confusion"] =		L"/p I'm hit by <icon=20186> <LINK data=\"0\" text=\"[M3] Universal Confusion 1200\" color=\"255,50,50\">";

local orderMorales = {};
orderMorales[L"Sever Nerve"] =				L"/p I'm hit by <icon=943> <LINK data=\"0\" text=\"[M1] Sever Nerve 1200\" color=\"255,50,50\">";
orderMorales[L"Ensnare"] =					L"/p I'm hit by <icon=20200> <LINK data=\"0\" text=\"[M1] Ensnare 900\" color=\"255,50,50\">";
orderMorales[L"Reversal of Fortune"] =		L"/p I'm hit by <icon=20202> <LINK data=\"0\" text=\"[M2] Reversal of Fortune 1200\" color=\"255,50,50\">";
orderMorales[L"Scintillating Energy"] =		L"/p I'm hit by <icon=943> <LINK data=\"0\" text=\"[M3] Scintillating Energy 1200\" color=\"255,50,50\">";
orderMorales[L"No Escape"] =				L"/p I'm hit by <icon=20190> <LINK data=\"0\" text=\"[M3] No Escape 1200\" color=\"255,50,50\">";
orderMorales[L"Penetrating Arrow"] =		L"/p I'm hit by <icon=20194> <LINK data=\"0\" text=\"[M4] Penetrating Arrow 1200\" color=\"255,50,50\">";
orderMorales[L"Cannon Smash"] =				L"/p I'm hit by <icon=20187> <LINK data=\"0\" text=\"[M3] Cannon Smash 2400\" color=\"255,50,50\">";
orderMorales[L"Dominance"] =				L"/p I'm hit by <icon=20200> <LINK data=\"0\" text=\"[M3] Dominance 1800\" color=\"255,50,50\">";
orderMorales[L"Grievous Harm"] =			L"/p I'm hit by <icon=20188> <LINK data=\"0\" text=\"[M3] Grievous Harm 1800\" color=\"255,50,50\">";
orderMorales[L"Doom Seeker"] =				L"/p I'm hit by <icon=20188> <LINK data=\"0\" text=\"[M3] Doom Seeker 1200\" color=\"255,50,50\">";
orderMorales[L"Ruin and Destruction"] =		L"/p I'm hit by <icon=20183> <LINK data=\"0\" text=\"[M2] Ruin and Destruction 1200\" color=\"255,50,50\">";
orderMorales[L"The Burning Head"] =			L"/p I'm hit by <icon=20183> <LINK data=\"0\" text=\"[M4] The Burning Head 1600\" color=\"255,50,50\">";
orderMorales[L"Instill Fear"] =				L"/p I'm hit by <icon=20194> <LINK data=\"0\" text=\"[M3] Instill Fear 1200\" color=\"255,50,50\">";
orderMorales[L"Whirling Rage"] =			L"/p I'm hit by <icon=20194> <LINK data=\"0\" text=\"[M4] Whirling Rage 1600\" color=\"255,50,50\">";
orderMorales[L"Solar Flare"] =				L"/p I'm hit by <icon=20190> <LINK data=\"0\" text=\"[M4] Solar Flare 800\" color=\"255,50,50\">";
orderMorales[L"Penance"] =					L"/p I'm hit by <icon=20199> <LINK data=\"0\" text=\"[M3] Penance 1200\" color=\"255,50,50\">";
orderMorales[L"Divine Blast"] =				L"/p I'm hit by <icon=20199> <LINK data=\"0\" text=\"[M4] Divine Blast 1200\" color=\"255,50,50\">";
orderMorales[L"Expurgation"] =				L"/p I'm hit by <icon=20199> <LINK data=\"0\" text=\"[M4] Expurgation 1200\" color=\"255,50,50\">";
orderMorales[L"Axe Slam"] =					L"/p I'm hit by <icon=20199> <LINK data=\"0\" text=\"[M4] Axe Slam 1200\" color=\"255,50,50\">";
orderMorales[L"Unleash The Winds"] =		L"/p I'm hit by <icon=943> <LINK data=\"0\" text=\"[M4] Unleash The Winds 1800\" color=\"255,50,50\">";
		
local hashTable = {};

-- /script TextLogSetEnabled("Combat",true)
-- /script TextLogSetEnabled("Combat",false)

-- /script TextLogSetEnabled("Combat", false);
-- /script TextLogSetEnabled("Combat", true);

-- /script NervAlert.ToggleCombatLog()
-- /script TextLogSetEnabled("Combat", false);
-- /script TextLogSetEnabled("Combat", true);
function NervAlert.ToggleCombatLog()
	local textLogEnabled = TextLogGetEnabled("Combat");
	TextLogSetEnabled("Combat", ( not(textLogEnabled) ));	
	if (textLogEnabled == true) then 
		EA_ChatWindow.Print(L"Combat log is now ON.")
	else
		EA_ChatWindow.Print(L"Combat log is now OFF.")
	end
end

function NervAlert.OnInitialize()
	if (GameData.Player.realm == 2) then
		hashTable = orderMorales;
	elseif (GameData.Player.realm == 1) then
		hashTable = destroMorales;
	end
	RegisterEventHandler(TextLogGetUpdateEventId("Combat"), "NervAlert.OnChatLogUpdated")
	EA_ChatWindow.Print(towstring("<LINK data=\"0\" text=\"[NervAlert]\" color=\"50,255,10\"> Addon initialized."))
end

local dmgMessagePattern = "'s ([^%.]+) hits you for (%d+) ";
function NervAlert.OnChatLogUpdated(updateType, filterType)

	if not (updateType == SystemData.TextLogUpdate.ADDED) then return end	
	if not (filterType == 1001) then return end

	local _, _, text = TextLogGetEntry("Combat", TextLogGetNumEntries("Combat") - 1);
	text = tostring(text);
	
	local skill, damage = string_match(text, dmgMessagePattern);
	skill = towstring(skill);
	
	if hashTable[skill] then
		damage = tonumber(damage);
		if damage and (damage >= damageMinimum) then
			SendChatText(hashTable[skill], L"");
		end
	end
	
end













