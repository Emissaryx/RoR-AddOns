PartyAd = PartyAd or {}

-- Core constants shared across runtime logic and UI.
PartyAd.VERSION = "0.2.2"
PartyAd.ROLE_TANK = "tank"
PartyAd.ROLE_HEALER = "healer"
PartyAd.ROLE_DPS = "dps"
PartyAd.SELF_ROLE_AUTO = "auto"
PartyAd.PARTY_SIZE = 6
PartyAd.PARTYNOTE_MAX_LEN = 69
PartyAd.LFG_SCAN_MAX_ENTRIES = 8
PartyAd.LFG_SCAN_TEXT_MAX_LEN = 110
PartyAd.LFG_SCAN_BACKLOG_MAX_ENTRIES = 80
PartyAd.LFG_SOCIAL_SEARCH_COOLDOWN_SECONDS = 1.5
PartyAd.LFG_SOCIAL_SEARCH_TIMEOUT_SECONDS = 6
PartyAd.LFG_SOCIAL_SEARCH_MAX_QUEUE = 8
PartyAd.LFG_SOCIAL_SEARCH_MIN_PLAYER_LEVEL = 5
PartyAd.PURPOSE_CUSTOM_KEY = "custom"
PartyAd.REALM_ORDER = "order"
PartyAd.REALM_DESTRUCTION = "destruction"
PartyAd.REALM_BOTH = "both"
-- Inline icon IDs come from RoR-Interface eatemplate_icons/icons.xml.
PartyAd.PURPOSE_PRESETS = {
    { key = "rvr_roam", icon = "<icon25023>", label = "RvR Roam", text = "RvR Roam", realm = PartyAd.REALM_BOTH },
    { key = "sc_group", icon = "<icon25025>", label = "Scenario", text = "Scenario", realm = PartyAd.REALM_BOTH },
    { key = "q_beastlord", icon = "<icon23515>", label = "Beastlord", text = "Beastlord", realm = PartyAd.REALM_BOTH },
    { key = "pq_mayhem", icon = "<icon25024>", label = "Mayhem Farm", text = "Mayhem Farm", realm = PartyAd.REALM_BOTH },
    { key = "pq_ruin", icon = "<icon25024>", label = "Ruin Farm", text = "Ruin Farm", realm = PartyAd.REALM_BOTH },
    { key = "pq_farm", icon = "<icon25024>", label = "PQ Farm", text = "PQ Farm", realm = PartyAd.REALM_BOTH },
    -- Active dungeons from the RoR wiki list (excluding ToVL/Warpblade/Bloodwrought).
    { key = "dng_dragonback_pass", icon = "<icon43>", label = "Dragonback Pass (DBP)", text = "Dragonback Pass", realm = PartyAd.REALM_BOTH },
    { key = "dng_sacellum", icon = "<icon43>", label = "Sacellum (SD)", text = "Sacellum", realm = PartyAd.REALM_DESTRUCTION },
    { key = "dng_altdorf_sewers", icon = "<icon43>", label = "Altdorf Sewers", text = "Altdorf Sewers", realm = PartyAd.REALM_ORDER },
    { key = "dng_gunbad", icon = "<icon15077>", label = "Gunbad (GB)", text = "Gunbad", realm = PartyAd.REALM_BOTH },
    { key = "dng_sigmar_crypts", icon = "<icon43>", label = "Sigmar Crypts", text = "Sigmar Crypts", realm = PartyAd.REALM_ORDER },
    { key = "dng_bilerot_burrows", icon = "<icon43>", label = "Bilerot Burrows (BB)", text = "Bilerot Burrows", realm = PartyAd.REALM_DESTRUCTION },
    { key = "dng_bastion_stair", icon = "<icon43>", label = "Bastion Stair (BS)", text = "Bastion Stair", realm = PartyAd.REALM_BOTH },
    { key = "dng_hunters_vale", icon = "<icon14725>", label = "Hunter's Vale (HV)", text = "Hunter's Vale", realm = PartyAd.REALM_BOTH },
    { key = "dng_lost_vale", icon = "<icon15451>", label = "Lost Vale (LV)", text = "Lost Vale", realm = PartyAd.REALM_BOTH },
}

-- Prefix color used for chat prints: [PartyAd]
local PA_PREFIX_COLOR_R = 238
local PA_PREFIX_COLOR_G = 176
local PA_PREFIX_COLOR_B = 63
local PA_KILLBOARD_LINK_DATA_TAG = "PARTYAD_KILLBOARD_CHAR"
local PA_KILLBOARD_CHARACTER_URL_PREFIX = "https://killboard.returnofreckoning.com/character/"
local PA_KILLBOARD_LINK_COLOR = "200,220,255"
local PA_COPY_LINK_WINDOW_NAME = "PartyAdCopyLinkWindow"
local PA_LFG_UNKNOWN_ROLE_ICON = "<icon370>"
local PA_LFG_ROLE_ICON_BY_ROLE = {
    tank = "<icon22702>",
    healer = "<icon22706>",
    dps = "<icon22701>",
}

-- Basic conversion and string-normalization helpers.
local function pa_to_wstring(value)
    local text = tostring(value or "")
    if type(towstring) == "function" then
        local ok, wide = pcall(towstring, text)
        if ok then
            return wide
        end
    end
    return text
end

local function pa_trim(text)
    local s = tostring(text or "")
    s = string.gsub(s, "%s+", " ")
    s = string.gsub(s, "^%s*(.-)%s*$", "%1")
    return s
end

local function pa_format_inline_icon_text(icon, text)
    local safe_text = pa_trim(text)
    local safe_icon = tostring(icon or "")
    if safe_text == "" or not string.match(safe_icon, "^<icon%d+>$") then
        return safe_text
    end
    return safe_icon .. " " .. safe_text
end

local function pa_format_purpose_preset_text(preset)
    if type(preset) ~= "table" then
        return ""
    end
    return pa_format_inline_icon_text(preset.icon, preset.text or "")
end

local function pa_format_purpose_preset_label(preset)
    if type(preset) ~= "table" then
        return ""
    end
    return pa_format_inline_icon_text(preset.icon, preset.label or preset.text or preset.key or "")
end

local function pa_fix_name(raw)
    local s = tostring(raw or "")
    local pos = string.find(s, "^", 1, true)
    if pos then
        s = string.sub(s, 1, pos - 1)
    end
    return s
end

local function pa_clean_player_name(raw)
    local s = pa_fix_name(raw)
    s = pa_trim(s)
    s = string.gsub(s, "^@", "")
    s = string.gsub(s, "\"", "")
    return s
end

local function pa_normalize_link_data(link_data)
    if link_data == nil then
        return ""
    end
    if type(link_data) == "string" then
        return link_data
    end

    local ok, cast = pcall(tostring, link_data)
    if ok and cast ~= nil then
        return cast
    end
    return ""
end

local function pa_normalize_positive_integer(raw)
    if raw == nil then
        return nil
    end

    local value = raw
    if type(value) ~= "number" then
        local ok, cast = pcall(tostring, value)
        if not ok or cast == nil then
            return nil
        end
        value = string.match(cast, "%d+")
    end

    local n = tonumber(value)
    if n == nil then
        return nil
    end
    n = math.floor(n)
    if n <= 0 then
        return nil
    end
    return n
end

local function pa_escape_link_attr(text)
    local value = tostring(text or "")
    value = string.gsub(value, "\"", "'")
    return value
end

local function pa_format_hyperlink(data, color, text)
    return string.format(
        "<LINK data=\"%s\" color=\"%s\" text=\"%s\">",
        pa_escape_link_attr(data),
        pa_escape_link_attr(color),
        pa_escape_link_attr(text)
    )
end

local function pa_name_key(raw)
    local s = pa_fix_name(raw)
    s = pa_trim(s)
    s = string.lower(s)
    return s
end

local function pa_to_number(value)
    if type(value) == "number" then
        return value
    end
    if value == nil then
        return nil
    end
    local n = tonumber(value)
    if type(n) == "number" then
        return n
    end
    return nil
end

local function pa_clamp_int(value, min_value, max_value)
    local n = tonumber(value) or 0
    n = math.floor(n)
    if n < min_value then
        return min_value
    end
    if n > max_value then
        return max_value
    end
    return n
end

local function pa_reduce_target_overflow(t, h, d, party_size)
    local overflow = (t + h + d) - party_size
    if overflow <= 0 then
        return t, h, d
    end

    local reduction = math.min(d, overflow)
    d = d - reduction
    overflow = overflow - reduction

    reduction = math.min(h, overflow)
    h = h - reduction
    overflow = overflow - reduction

    if overflow > 0 then
        t = math.max(0, t - overflow)
    end

    return t, h, d
end

-- Party member extraction helpers.
local function pa_get_member_career_line(member)
    if type(member) ~= "table" then
        return nil
    end

    local career_line = member.careerLine
    if type(career_line) == "table" then
        career_line = career_line.line
    end

    if career_line == nil then
        local career = member.career
        if type(career) == "table" then
            career_line = career.line
        else
            career_line = career
        end
    end

    if career_line == nil then
        career_line = member.careerLineId
    end

    return pa_to_number(career_line)
end

local function pa_build_local_player_member()
    if not (GameData and GameData.Player and GameData.Player.name) then
        return nil
    end

    local player = GameData.Player
    local member = {
        name = player.name,
        careerLine = nil,
    }

    local career_line
    if type(player.career) == "table" then
        career_line = player.career.line
    else
        career_line = player.career
    end
    if career_line == nil then
        career_line = player.careerLine
    end

    member.careerLine = pa_to_number(career_line)
    return member
end

-- Role-label and text formatting helpers.
local function pa_apply_alt_spec_transform(career_line)
    local cl = GameData and GameData.CareerLine
    if type(cl) ~= "table" then
        return career_line
    end

    if career_line == cl.ZEALOT or
       career_line == cl.SHAMAN then
        return cl.MAGUS
    end

    if career_line == cl.WARRIOR_PRIEST or
       career_line == cl.SHADOW_WARRIOR then
        return cl.SLAYER
    end

    if career_line == cl.RUNE_PRIEST or
       career_line == cl.ARCHMAGE then
        return cl.ENGINEER
    end

    if career_line == cl.DISCIPLE or
       career_line == cl.SQUIG_HERDER then
        return cl.CHOPPA
    end

    return career_line
end

local function pa_pluralize(role, count)
    if role == PartyAd.ROLE_DPS then
        return "dps"
    end
    if count == 1 then
        return role
    end
    return role .. "s"
end

local function pa_normalize_role_key(role)
    if type(role) ~= "string" then
        return nil
    end

    local lower = string.lower(role)
    if lower == PartyAd.ROLE_TANK then
        return PartyAd.ROLE_TANK
    end
    if lower == PartyAd.ROLE_HEALER or lower == "heal" then
        return PartyAd.ROLE_HEALER
    end
    if lower == PartyAd.ROLE_DPS or lower == "mdps" or lower == "rdps" then
        return PartyAd.ROLE_DPS
    end

    return nil
end

local function pa_role_display_name(role)
    if role == PartyAd.ROLE_TANK then
        return "Tank"
    end
    if role == PartyAd.ROLE_HEALER then
        return "Healer"
    end
    if role == PartyAd.ROLE_DPS then
        return "DPS"
    end
    return nil
end

local function pa_join(parts, sep)
    if #parts == 0 then
        return ""
    end
    local out = parts[1]
    for i = 2, #parts do
        out = out .. sep .. parts[i]
    end
    return out
end

local function pa_truncate(text, max_len)
    local s = tostring(text or "")
    if #s <= max_len then
        return s
    end
    if max_len <= 3 then
        return string.sub(s, 1, max_len)
    end
    return string.sub(s, 1, max_len - 3) .. "..."
end

local function pa_strip_link_markup(text)
    local s = tostring(text or "")
    s = string.gsub(s, "<LINK[^>]-text=\"([^\"]*)\"[^>]*>", "%1")
    s = string.gsub(s, "<[^>]+>", "")
    return s
end

local function pa_escape_lua_pattern(text)
    return string.gsub(tostring(text or ""), "([^%w])", "%%%1")
end

local function pa_build_partynote_with_suffix(base, suffix)
    local prefix = "[PA] "
    local safe_base = pa_trim(base)
    local safe_suffix = tostring(suffix or "")
    if safe_base == "" then
        safe_base = "Party"
    end

    local text = prefix .. safe_base .. safe_suffix
    if #text <= PartyAd.PARTYNOTE_MAX_LEN then
        return text
    end

    local available_base_len = PartyAd.PARTYNOTE_MAX_LEN - #prefix - #safe_suffix
    if available_base_len <= 0 then
        return pa_truncate(prefix .. safe_suffix, PartyAd.PARTYNOTE_MAX_LEN)
    end

    return prefix .. pa_truncate(safe_base, available_base_len) .. safe_suffix
end

local function pa_format_filled_wanted(missing)
    if not (PartyAd.saved and PartyAd.saved.use_detected_roles_for_needs == true) then
        return ""
    end

    local saved = PartyAd.saved or {}
    local wanted = (saved.desired_tanks or 0) +
        (saved.desired_healers or 0) +
        (saved.desired_dps or 0)
    if wanted < 0 then
        wanted = 0
    end
    if wanted > PartyAd.PARTY_SIZE then
        wanted = PartyAd.PARTY_SIZE
    end
    if wanted <= 0 then
        return ""
    end

    local filled = wanted - math.max(0, missing and missing.total or 0)
    if filled < 0 then
        filled = 0
    end
    if filled > wanted then
        filled = wanted
    end

    return "(" .. tostring(filled) .. "/" .. tostring(wanted) .. ")"
end

local function pa_append_partynote_progress_if_room(text, progress)
    local marker = tostring(progress or "")
    if marker == "" then
        return text
    end

    local suffix = " " .. marker
    if #text + #suffix <= PartyAd.PARTYNOTE_MAX_LEN then
        return text .. suffix
    end
    return text
end

-- Chat/link formatting and copied URL popup helpers.
local function pa_format_leader_mention(raw_name)
    local name = pa_fix_name(raw_name)
    name = pa_trim(name)
    if name == "" then
        return "leader"
    end

    local display = "@" .. name
    return string.format(
        "<LINK data=\"PLAYER:%s\" color=\"255,0,0\" text=\"%s\">",
        name,
        display
    )
end

local function pa_format_player_mention(raw_name)
    local name = pa_clean_player_name(raw_name)
    if name == "" then
        return "unknown"
    end

    return pa_format_hyperlink("PLAYER:" .. name, "236,94,96", "@" .. name)
end

function PartyAd.build_killboard_character_url(character_id)
    local normalized_character_id = pa_normalize_positive_integer(character_id)
    if not normalized_character_id then
        return nil
    end
    return PA_KILLBOARD_CHARACTER_URL_PREFIX .. tostring(normalized_character_id) .. "/"
end

function PartyAd.build_killboard_link_data_for_character_id(character_id)
    local normalized_character_id = pa_normalize_positive_integer(character_id)
    if not normalized_character_id then
        return nil
    end
    return PA_KILLBOARD_LINK_DATA_TAG .. ":" .. tostring(normalized_character_id)
end

local function pa_resolve_killboard_url_from_link_data(link_data)
    local raw_data = pa_normalize_link_data(link_data)
    if raw_data == "" then
        return nil
    end

    local prefix = PA_KILLBOARD_LINK_DATA_TAG .. ":"
    if string.sub(raw_data, 1, string.len(prefix)) ~= prefix then
        return nil
    end

    local character_id_text = string.sub(raw_data, string.len(prefix) + 1)
    character_id_text = string.gsub(character_id_text, "^%s+", "")
    character_id_text = string.gsub(character_id_text, "%s+$", "")
    if not string.match(character_id_text, "^%d+$") then
        return nil
    end
    return PartyAd.build_killboard_character_url(character_id_text)
end

local function pa_does_window_exist(name)
    if type(DoesWindowExist) ~= "function" then
        return false
    end
    local ok, exists = pcall(DoesWindowExist, name)
    return ok and exists == true
end

function PartyAd.OnCopyLinkInitialize()
    if PartyAd.copy_link_window_initialized then
        return
    end
    PartyAd.copy_link_window_initialized = true

    if type(LabelSetText) == "function" then
        LabelSetText(PA_COPY_LINK_WINDOW_NAME .. "TitleBarText", L"Copy URL")
        LabelSetText(PA_COPY_LINK_WINDOW_NAME .. "Instruction", L"Press Ctrl+C to copy this URL.")
    end
    if type(ButtonSetText) == "function" then
        ButtonSetText(PA_COPY_LINK_WINDOW_NAME .. "CloseButton", L"Close")
    end
end

local function pa_ensure_copy_link_window()
    if pa_does_window_exist(PA_COPY_LINK_WINDOW_NAME) then
        if not PartyAd.copy_link_window_initialized then
            PartyAd.OnCopyLinkInitialize()
        end
        return true
    end

    if type(CreateWindow) ~= "function" then
        return false
    end

    local ok_create = pcall(CreateWindow, PA_COPY_LINK_WINDOW_NAME, false)
    if not ok_create or not pa_does_window_exist(PA_COPY_LINK_WINDOW_NAME) then
        return false
    end

    if not PartyAd.copy_link_window_initialized then
        PartyAd.OnCopyLinkInitialize()
    end
    return true
end

local function pa_show_copy_link(url)
    local url_text = pa_normalize_link_data(url)
    if url_text == "" then
        return false
    end
    if not pa_ensure_copy_link_window() then
        return false
    end

    local url_wstring = pa_to_wstring(url_text)
    if type(TextEditBoxSetText) == "function" then
        TextEditBoxSetText(PA_COPY_LINK_WINDOW_NAME .. "UrlInput", url_wstring)
    end
    if type(TextEditBoxSetMaxChars) == "function" then
        TextEditBoxSetMaxChars(PA_COPY_LINK_WINDOW_NAME .. "UrlInput", 1000)
    end
    if type(WindowSetShowing) == "function" then
        WindowSetShowing(PA_COPY_LINK_WINDOW_NAME, true)
    end
    if type(WindowAssignFocus) == "function" then
        WindowAssignFocus(PA_COPY_LINK_WINDOW_NAME .. "UrlInput", true)
    end
    if type(TextEditBoxSelectAll) == "function" then
        TextEditBoxSelectAll(PA_COPY_LINK_WINDOW_NAME .. "UrlInput")
    end
    return true
end

function PartyAd.HideCopyLink()
    if type(WindowSetShowing) == "function" and pa_does_window_exist(PA_COPY_LINK_WINDOW_NAME) then
        WindowSetShowing(PA_COPY_LINK_WINDOW_NAME, false)
    end
end

local function pa_open_external_url_or_copy(url)
    local url_text = pa_normalize_link_data(url)
    if url_text == "" then
        return false
    end

    if pa_show_copy_link(url_text) then
        return true
    end

    if type(EA_ChatWindow) == "table" and type(EA_ChatWindow.OnWebLinkLButtonUp) == "function" then
        pcall(EA_ChatWindow.OnWebLinkLButtonUp, pa_to_wstring(url_text), 0, 0, 0)
        return true
    end

    if type(DialogManager) == "table" and type(DialogManager.MakeTextEntryDialog) == "function" then
        pcall(
            DialogManager.MakeTextEntryDialog,
            L"Copy Link",
            L" Highlight text and ctrl+c to copy link",
            pa_to_wstring(url_text),
            nil,
            nil,
            1000,
            true,
            nil,
            true
        )
        return true
    end

    return false
end

function PartyAd.handle_hyperlink_lbutton_up(link_data, _flags, _x, _y)
    local killboard_url = pa_resolve_killboard_url_from_link_data(link_data)
    if killboard_url == nil then
        return false
    end
    return pa_open_external_url_or_copy(killboard_url)
end

local function pa_build_colored_prefix()
    local colored = string.format(
        "<LINK data=\"0\" color=\"%d,%d,%d\" text=\"PartyAd\">",
        PA_PREFIX_COLOR_R,
        PA_PREFIX_COLOR_G,
        PA_PREFIX_COLOR_B
    )
    return "[" .. colored .. "]"
end

-- Public logging plus saved-variable initialization and target configuration.
function PartyAd.print(msg)
    local text = pa_build_colored_prefix() .. " " .. tostring(msg or "")
    if EA_ChatWindow and type(EA_ChatWindow.Print) == "function" then
        EA_ChatWindow.Print(pa_to_wstring(text))
    end
end

function PartyAd.ensure_saved_defaults()
    PartyAd.saved = PartyAd.saved or {}

    if type(PartyAd.saved.desired_tanks) ~= "number" then PartyAd.saved.desired_tanks = 1 end
    if type(PartyAd.saved.desired_healers) ~= "number" then PartyAd.saved.desired_healers = 2 end
    if type(PartyAd.saved.desired_dps) ~= "number" then PartyAd.saved.desired_dps = 3 end
    if type(PartyAd.saved.purpose) ~= "string" then PartyAd.saved.purpose = "" end
    if type(PartyAd.saved.purpose_custom) ~= "string" then
        PartyAd.saved.purpose_custom = PartyAd.saved.purpose
    end
    if type(PartyAd.saved.purpose_mode) ~= "string" then
        PartyAd.saved.purpose_mode = PartyAd.PURPOSE_CUSTOM_KEY
    end
    if PartyAd.saved.use_scoreboard_spec_check == nil then
        PartyAd.saved.use_scoreboard_spec_check = true
    end
    if PartyAd.saved.use_detected_roles_for_needs == nil then
        PartyAd.saved.use_detected_roles_for_needs = true
    else
        PartyAd.saved.use_detected_roles_for_needs = (PartyAd.saved.use_detected_roles_for_needs == true)
    end
    if PartyAd.saved.use_lfg_scan == nil then
        PartyAd.saved.use_lfg_scan = false
    else
        PartyAd.saved.use_lfg_scan = (PartyAd.saved.use_lfg_scan == true)
    end
    if type(PartyAd.saved.self_role_override) ~= "string" then
        PartyAd.saved.self_role_override = PartyAd.SELF_ROLE_AUTO
    end
    PartyAd.saved.self_role_override = string.lower(PartyAd.saved.self_role_override)
    if PartyAd.saved.self_role_override ~= PartyAd.SELF_ROLE_AUTO and
       PartyAd.saved.self_role_override ~= PartyAd.ROLE_TANK and
       PartyAd.saved.self_role_override ~= PartyAd.ROLE_HEALER and
       PartyAd.saved.self_role_override ~= PartyAd.ROLE_DPS then
        PartyAd.saved.self_role_override = PartyAd.SELF_ROLE_AUTO
    end

    PartyAd.saved.purpose_custom = pa_trim(PartyAd.saved.purpose_custom)
    PartyAd.saved.purpose_mode = PartyAd.get_purpose_mode()
    PartyAd.saved.purpose = PartyAd.get_purpose()
    PartyAd.normalize_targets()
end

function PartyAd.normalize_targets()
    local party_size = PartyAd.PARTY_SIZE
    local t = pa_clamp_int(PartyAd.saved.desired_tanks, 0, party_size)
    local h = pa_clamp_int(PartyAd.saved.desired_healers, 0, party_size)
    local d = pa_clamp_int(PartyAd.saved.desired_dps, 0, party_size)

    t, h, d = pa_reduce_target_overflow(t, h, d, party_size)

    PartyAd.saved.desired_tanks = t
    PartyAd.saved.desired_healers = h
    PartyAd.saved.desired_dps = d
end

local function pa_decrement_target_for_role(role_key)
    if role_key == PartyAd.ROLE_TANK and (PartyAd.saved.desired_tanks or 0) > 0 then
        PartyAd.saved.desired_tanks = PartyAd.saved.desired_tanks - 1
        return true
    end
    if role_key == PartyAd.ROLE_HEALER and (PartyAd.saved.desired_healers or 0) > 0 then
        PartyAd.saved.desired_healers = PartyAd.saved.desired_healers - 1
        return true
    end
    if role_key == PartyAd.ROLE_DPS and (PartyAd.saved.desired_dps or 0) > 0 then
        PartyAd.saved.desired_dps = PartyAd.saved.desired_dps - 1
        return true
    end
    return false
end

local function pa_decrement_self_target_for_needed_roles()
    PartyAd.normalize_targets()

    local total = (PartyAd.saved.desired_tanks or 0) +
        (PartyAd.saved.desired_healers or 0) +
        (PartyAd.saved.desired_dps or 0)
    if total ~= PartyAd.PARTY_SIZE then
        return false
    end

    local role = PartyAd.get_self_role_override()
    if role == PartyAd.SELF_ROLE_AUTO then
        role = PartyAd.get_detected_self_role()
    end
    if pa_decrement_target_for_role(role) then
        return true
    end

    return pa_decrement_target_for_role(PartyAd.ROLE_DPS) or
        pa_decrement_target_for_role(PartyAd.ROLE_HEALER) or
        pa_decrement_target_for_role(PartyAd.ROLE_TANK)
end

function PartyAd.set_use_detected_roles_for_needs(enabled)
    if not PartyAd.saved then
        return
    end

    local was_enabled = PartyAd.saved.use_detected_roles_for_needs == true
    PartyAd.saved.use_detected_roles_for_needs = enabled == true
    if was_enabled and PartyAd.saved.use_detected_roles_for_needs ~= true then
        pa_decrement_self_target_for_needed_roles()
    end
end

function PartyAd.set_use_lfg_scan(enabled)
    if not PartyAd.saved then
        return
    end

    PartyAd.saved.use_lfg_scan = enabled == true
    if PartyAd.saved.use_lfg_scan ~= true and type(PartyAd.cancel_lfg_social_lookup_queue) == "function" then
        PartyAd.cancel_lfg_social_lookup_queue()
    end
    if type(PartyAd.sync_lfg_scan_subscription) == "function" then
        PartyAd.sync_lfg_scan_subscription()
    end
    if PartyAd.saved.use_lfg_scan == true and type(PartyAd.seed_lfg_candidates_from_chat_log) == "function" then
        PartyAd.seed_lfg_candidates_from_chat_log()
    end
end

function PartyAd.set_target(role_key, value)
    local n = tonumber(value)
    if not n then
        return false
    end
    n = math.floor(n)
    if n < 0 then n = 0 end

    local t = PartyAd.saved.desired_tanks or 0
    local h = PartyAd.saved.desired_healers or 0
    local d = PartyAd.saved.desired_dps or 0

    local other_sum
    if role_key == PartyAd.ROLE_TANK then
        other_sum = h + d
    elseif role_key == PartyAd.ROLE_HEALER then
        other_sum = t + d
    else
        other_sum = t + h
    end

    local max_allowed = PartyAd.PARTY_SIZE - other_sum
    if max_allowed < 0 then
        max_allowed = 0
    end
    if n > max_allowed then
        n = max_allowed
    end

    if role_key == PartyAd.ROLE_TANK then
        PartyAd.saved.desired_tanks = n
    elseif role_key == PartyAd.ROLE_HEALER then
        PartyAd.saved.desired_healers = n
    else
        PartyAd.saved.desired_dps = n
    end

    return true
end

function PartyAd.adjust_target(role_key, delta)
    local current
    if role_key == PartyAd.ROLE_TANK then
        current = PartyAd.saved.desired_tanks
    elseif role_key == PartyAd.ROLE_HEALER then
        current = PartyAd.saved.desired_healers
    else
        current = PartyAd.saved.desired_dps
    end
    return PartyAd.set_target(role_key, (current or 0) + (delta or 0))
end

-- Role resolution and party-member collection.
function PartyAd.get_role_from_career_line(career_line)
    local cl = GameData and GameData.CareerLine
    if type(cl) ~= "table" or type(career_line) ~= "number" then
        return nil
    end

    if career_line == cl.IRON_BREAKER or
       career_line == cl.CHOSEN or
       career_line == cl.BLACK_ORC or
       career_line == cl.KNIGHT or
       career_line == cl.SWORDMASTER or
       career_line == cl.BLACKGUARD then
        return PartyAd.ROLE_TANK
    end

    if career_line == cl.ZEALOT or
       career_line == cl.WARRIOR_PRIEST or
       career_line == cl.RUNE_PRIEST or
       career_line == cl.ARCHMAGE or
       career_line == cl.SHAMAN or
       career_line == cl.DISCIPLE then
        return PartyAd.ROLE_HEALER
    end

    if career_line == cl.ENGINEER or
       career_line == cl.BRIGHT_WIZARD or
       career_line == cl.SORCERER or
       career_line == cl.SQUIG_HERDER or
       career_line == cl.MAGUS or
       career_line == cl.SHADOW_WARRIOR or
       career_line == cl.WITCH_ELF or
       career_line == cl.WHITE_LION or
       career_line == cl.SLAYER or
       career_line == cl.WITCH_HUNTER or
       career_line == cl.CHOPPA or
       career_line == cl.MARAUDER then
        return PartyAd.ROLE_DPS
    end

    return nil
end

local function pa_get_realm_from_career_line(career_line)
    local cl = GameData and GameData.CareerLine
    if type(cl) ~= "table" or type(career_line) ~= "number" then
        return nil
    end

    if career_line == cl.IRON_BREAKER or
       career_line == cl.KNIGHT or
       career_line == cl.SWORDMASTER or
       career_line == cl.RUNE_PRIEST or
       career_line == cl.WARRIOR_PRIEST or
       career_line == cl.ARCHMAGE or
       career_line == cl.BRIGHT_WIZARD or
       career_line == cl.ENGINEER or
       career_line == cl.SHADOW_WARRIOR or
       career_line == cl.WHITE_LION or
       career_line == cl.SLAYER or
       career_line == cl.WITCH_HUNTER then
        return PartyAd.REALM_ORDER
    end

    if career_line == cl.CHOSEN or
       career_line == cl.BLACK_ORC or
       career_line == cl.BLACKGUARD or
       career_line == cl.ZEALOT or
       career_line == cl.SHAMAN or
       career_line == cl.DISCIPLE or
       career_line == cl.SORCERER or
       career_line == cl.MAGUS or
       career_line == cl.SQUIG_HERDER or
       career_line == cl.WITCH_ELF or
       career_line == cl.CHOPPA or
       career_line == cl.MARAUDER then
        return PartyAd.REALM_DESTRUCTION
    end

    return nil
end

local function pa_get_realm_from_player_data()
    local player = GameData and GameData.Player
    if type(player) ~= "table" then
        return nil
    end

    local realm = player.realm
    if type(realm) == "string" then
        local lower = string.lower(realm)
        if string.find(lower, "order", 1, true) then
            return PartyAd.REALM_ORDER
        end
        if string.find(lower, "dest", 1, true) then
            return PartyAd.REALM_DESTRUCTION
        end
    end

    local realm_info = GameData and GameData.Realm
    if type(realm) == "number" and type(realm_info) == "table" then
        if realm_info.ORDER ~= nil and realm == realm_info.ORDER then
            return PartyAd.REALM_ORDER
        end
        if realm_info.DESTRUCTION ~= nil and realm == realm_info.DESTRUCTION then
            return PartyAd.REALM_DESTRUCTION
        end
    end

    return nil
end

function PartyAd.get_member_role(member)
    if type(member) ~= "table" then
        return nil
    end

    local role = pa_normalize_role_key(member.role)
    if role then
        return role
    end

    local career_line = pa_get_member_career_line(member)

    return PartyAd.get_role_from_career_line(career_line)
end

function PartyAd.build_alt_spec_lookup()
    local lookup = {}
    if not (PartyAd.saved and PartyAd.saved.use_scoreboard_spec_check == true) then
        return lookup
    end
    if not (RoRGroupScoreboard and RoRGroupScoreboard.playersDataRaw) then
        return lookup
    end

    for _, pdata in pairs(RoRGroupScoreboard.playersDataRaw) do
        if pdata and pdata.name and pdata.archtype and pdata.archtype > 0 then
            local key = pa_name_key(pdata.name)
            if key ~= "" then
                lookup[key] = true
            end
        end
    end

    return lookup
end

local function pa_detect_role_for_member(member, alt_lookup)
    local role = PartyAd.get_member_role(member)
    if role ~= PartyAd.ROLE_HEALER then
        return role
    end
    if not (PartyAd.saved and PartyAd.saved.use_scoreboard_spec_check == true) then
        return role
    end

    local key = member and pa_name_key(member.name) or ""
    if key == "" or not alt_lookup[key] then
        return role
    end

    local career_line = pa_get_member_career_line(member)
    career_line = pa_apply_alt_spec_transform(career_line)
    return PartyAd.get_role_from_career_line(career_line)
end

local function pa_add_member(entry, members, seen)
    if type(entry) ~= "table" then
        return
    end

    if entry.name ~= nil then
        local key = pa_fix_name(entry.name)
        if key == "" then
            key = tostring(entry)
        end
        if not seen[key] then
            seen[key] = true
            members[#members + 1] = entry
        end
        return
    end

    if type(entry.Group) == "table" then
        for i = 1, #entry.Group do
            pa_add_member(entry.Group[i], members, seen)
        end
    end

    if type(entry.players) == "table" then
        for i = 1, #entry.players do
            pa_add_member(entry.players[i], members, seen)
        end
    end
end

function PartyAd.get_party_members()
    local members = {}
    local seen = {}

    if PartyUtils and type(PartyUtils.GetPartyData) == "function" then
        local ok, party_data = pcall(PartyUtils.GetPartyData)
        if ok and type(party_data) == "table" then
            for i = 1, #party_data do
                pa_add_member(party_data[i], members, seen)
            end
            if #members == 0 then
                for _, entry in pairs(party_data) do
                    pa_add_member(entry, members, seen)
                end
            end
        end
    end

    return members
end

function PartyAd.get_self_role_override()
    local role = PartyAd.saved and PartyAd.saved.self_role_override or PartyAd.SELF_ROLE_AUTO
    if type(role) ~= "string" then
        return PartyAd.SELF_ROLE_AUTO
    end
    role = string.lower(role)
    if role == PartyAd.ROLE_TANK or
       role == PartyAd.ROLE_HEALER or
       role == PartyAd.ROLE_DPS then
        return role
    end
    return PartyAd.SELF_ROLE_AUTO
end

function PartyAd.get_detected_self_role()
    local member = pa_build_local_player_member()
    if not member then
        return nil
    end
    local alt_lookup = PartyAd.build_alt_spec_lookup()
    return pa_detect_role_for_member(member, alt_lookup)
end

function PartyAd.get_self_role_menu()
    local detected_role = PartyAd.get_detected_self_role()
    local detected_label = pa_role_display_name(detected_role) or "Unknown"
    local auto_label = "Auto (Detected: " .. detected_label .. ")"

    return {
        { key = PartyAd.SELF_ROLE_AUTO, label = auto_label },
        { key = PartyAd.ROLE_TANK, label = pa_role_display_name(PartyAd.ROLE_TANK) },
        { key = PartyAd.ROLE_HEALER, label = pa_role_display_name(PartyAd.ROLE_HEALER) },
        { key = PartyAd.ROLE_DPS, label = pa_role_display_name(PartyAd.ROLE_DPS) },
    }
end

-- Party counting and missing-role calculations.
local function pa_compute_missing_count(desired, current, use_detected_roles)
    local missing = math.max(0, desired or 0)
    if use_detected_roles then
        missing = math.max(0, missing - (current or 0))
    end
    return missing
end

function PartyAd.get_party_counts()
    local counts = {
        tank = 0,
        healer = 0,
        dps = 0,
        total = 0,
    }

    local members = PartyAd.get_party_members()
    if #members > 0 then
        local local_member = pa_build_local_player_member()
        if local_member then
            local self_key = pa_name_key(local_member.name)
            local has_self = false
            for i = 1, #members do
                if pa_name_key(members[i] and members[i].name) == self_key then
                    has_self = true
                    break
                end
            end
            if not has_self then
                members[#members + 1] = local_member
            end
        end
    end

    local alt_lookup = PartyAd.build_alt_spec_lookup()
    local self_key = ""
    if GameData and GameData.Player and GameData.Player.name then
        self_key = pa_name_key(GameData.Player.name)
    end
    local self_override = PartyAd.get_self_role_override()
    if self_override == PartyAd.SELF_ROLE_AUTO then
        self_override = nil
    end

    for i = 1, #members do
        local member = members[i]
        local role
        local member_key = member and pa_name_key(member.name) or ""

        if self_override and self_key ~= "" and member_key == self_key then
            role = self_override
        else
            role = pa_detect_role_for_member(member, alt_lookup)
        end

        if role and counts[role] ~= nil then
            counts[role] = counts[role] + 1
            counts.total = counts.total + 1
        end
    end

    return counts
end

function PartyAd.get_missing_counts()
    local counts = PartyAd.get_party_counts()
    local use_detected_roles = PartyAd.saved and PartyAd.saved.use_detected_roles_for_needs == true

    local missing = {
        tank = pa_compute_missing_count(PartyAd.saved.desired_tanks, counts.tank, use_detected_roles),
        healer = pa_compute_missing_count(PartyAd.saved.desired_healers, counts.healer, use_detected_roles),
        dps = pa_compute_missing_count(PartyAd.saved.desired_dps, counts.dps, use_detected_roles),
        spots = math.max(0, PartyAd.PARTY_SIZE - counts.total),
    }
    missing.total = missing.tank + missing.healer + missing.dps

    return missing, counts
end

function PartyAd.format_need_text(missing)
    local parts = {}
    if missing.tank > 0 then
        parts[#parts + 1] = tostring(missing.tank) .. " " .. pa_pluralize(PartyAd.ROLE_TANK, missing.tank)
    end
    if missing.healer > 0 then
        parts[#parts + 1] = tostring(missing.healer) .. " " .. pa_pluralize(PartyAd.ROLE_HEALER, missing.healer)
    end
    if missing.dps > 0 then
        parts[#parts + 1] = tostring(missing.dps) .. " dps"
    end

    if #parts == 0 then
        return "none"
    end
    return pa_join(parts, " / ")
end

function PartyAd.format_current_summary(counts)
    local tank_count = counts.tank or 0
    local healer_count = counts.healer or 0
    local dps_count = counts.dps or 0

    local parts = {
        tostring(tank_count) .. " " .. pa_pluralize(PartyAd.ROLE_TANK, tank_count),
        tostring(healer_count) .. " " .. pa_pluralize(PartyAd.ROLE_HEALER, healer_count),
        tostring(dps_count) .. " dps",
    }

    return "Current: " ..
        pa_join(parts, " / ") .. " (" ..
        tostring(counts.total) .. "/" .. tostring(PartyAd.PARTY_SIZE) .. ")"
end

function PartyAd.format_missing_summary(missing)
    if missing.total == 0 then
        return "Missing: none (fulfilled)"
    end
    if missing.spots == 0 then
        return "Missing: " .. PartyAd.format_need_text(missing) .. " (party full)"
    end
    return "Missing: " .. PartyAd.format_need_text(missing)
end

-- Purpose preset and custom-purpose handling.
function PartyAd.get_player_realm_key()
    local realm = pa_get_realm_from_player_data()
    if realm ~= nil then
        return realm
    end

    local member = pa_build_local_player_member()
    local career_line = pa_get_member_career_line(member)
    return pa_get_realm_from_career_line(career_line)
end

function PartyAd.is_purpose_preset_available(preset)
    if type(preset) ~= "table" then
        return false
    end

    local preset_realm = preset.realm or PartyAd.REALM_BOTH
    if preset_realm == PartyAd.REALM_BOTH then
        return true
    end

    local player_realm = PartyAd.get_player_realm_key()
    if player_realm == nil then
        -- If realm detection fails, keep presets visible rather than hiding options.
        return true
    end

    return preset_realm == player_realm
end

function PartyAd.set_purpose(purpose_text)
    PartyAd.saved.purpose_custom = pa_trim(purpose_text)
    PartyAd.saved.purpose_mode = PartyAd.PURPOSE_CUSTOM_KEY
    PartyAd.saved.purpose = PartyAd.saved.purpose_custom
end

function PartyAd.get_purpose()
    local mode = PartyAd.get_purpose_mode()
    if mode == PartyAd.PURPOSE_CUSTOM_KEY then
        return pa_trim(PartyAd.saved.purpose_custom or "")
    end

    local preset = PartyAd.find_purpose_preset(mode)
    if preset then
        return pa_format_purpose_preset_text(preset)
    end

    return pa_trim(PartyAd.saved.purpose_custom or "")
end

function PartyAd.find_purpose_preset(key)
    if type(key) ~= "string" then
        return nil
    end
    for i = 1, #PartyAd.PURPOSE_PRESETS do
        local preset = PartyAd.PURPOSE_PRESETS[i]
        if preset and preset.key == key then
            return preset
        end
    end
    return nil
end

function PartyAd.get_purpose_mode()
    local mode = PartyAd.saved and PartyAd.saved.purpose_mode or PartyAd.PURPOSE_CUSTOM_KEY
    if mode == PartyAd.PURPOSE_CUSTOM_KEY then
        return PartyAd.PURPOSE_CUSTOM_KEY
    end
    local preset = PartyAd.find_purpose_preset(mode)
    if preset and PartyAd.is_purpose_preset_available(preset) then
        return mode
    end
    return PartyAd.PURPOSE_CUSTOM_KEY
end

function PartyAd.select_purpose_preset(key)
    local preset = PartyAd.find_purpose_preset(key)
    if not preset then
        return false
    end
    if not PartyAd.is_purpose_preset_available(preset) then
        return false
    end
    PartyAd.saved.purpose_mode = preset.key
    PartyAd.saved.purpose = pa_format_purpose_preset_text(preset)
    return true
end

function PartyAd.set_purpose_mode(mode)
    if mode == PartyAd.PURPOSE_CUSTOM_KEY then
        PartyAd.saved.purpose_mode = PartyAd.PURPOSE_CUSTOM_KEY
        PartyAd.saved.purpose = pa_trim(PartyAd.saved.purpose_custom or "")
        return true
    end
    return PartyAd.select_purpose_preset(mode)
end

function PartyAd.get_purpose_menu()
    local items = {
        { key = PartyAd.PURPOSE_CUSTOM_KEY, label = "Custom..." },
    }
    for i = 1, #PartyAd.PURPOSE_PRESETS do
        local preset = PartyAd.PURPOSE_PRESETS[i]
        if PartyAd.is_purpose_preset_available(preset) then
            items[#items + 1] = {
                key = preset.key,
                label = pa_format_purpose_preset_label(preset),
            }
        end
    end
    return items
end

-- Party-state checks and chat command dispatch.
local PA_PARTYNOTE_FIELD_KEYS = {
    "partyNote",
    "partynote",
    "groupNote",
    "groupnote",
}

local function pa_note_to_string(note_raw)
    if note_raw == nil then
        return nil
    end
    if type(note_raw) == "string" then
        return note_raw
    end
    if type(WStringToString) == "function" then
        local ok_ws, ws_val = pcall(WStringToString, note_raw)
        if ok_ws and ws_val then
            return ws_val
        end
    end
    local ok_str, str_val = pcall(tostring, note_raw)
    if ok_str and str_val then
        return str_val
    end
    return nil
end

local function pa_normalize_note_text(note_raw)
    local note_str = pa_note_to_string(note_raw)
    if not note_str then
        return nil
    end
    note_str = string.gsub(note_str, "%s+", " ")
    note_str = string.gsub(note_str, "^%s*(.-)%s*$", "%1")
    if note_str == "" then
        return nil
    end
    return note_str
end

-- LFG candidate scanning/enrichment keeps chat and Social work behind UI/option gates.
local PA_LFG_STRICT_PHRASES = {
    "lfg",
    "lf group",
    "lf grp",
    "lf party",
    "looking for group",
    "looking for grp",
    "looking for party",
}

local PA_LFG_LENIENT_PHRASES = {
    "lfg",
    "x",
    "lf group",
    "lf grp",
    "lf party",
    "lf city",
    "lf roam",
    "lf rvr",
    "looking for group",
    "looking for grp",
    "looking for party",
    "looking group",
    "looking party",
    "need group",
    "need grp",
    "need party",
    "inv",
    "invite",
    "inv me",
    "invite me",
    "any group",
    "any grp",
    "any room",
    "solo",
    "solo tank",
    "solo healer",
    "solo heal",
    "solo dps",
    "solo mdps",
    "solo rdps",
    "tank looking",
    "healer looking",
    "heal looking",
    "dps looking",
    "mdps looking",
    "rdps looking",
    "tank here",
    "healer here",
    "heal here",
    "dps here",
    "mdps here",
    "rdps here",
}

local PA_LFG_NEGATIVE_PHRASES = {
    "lfm",
    "lfg tab",
    "lfg channel",
    "lf party command",
    "looking for group window",
    "looking for more",
    "party full",
    "full for now",
    "full thanks",
    "full thx",
    "full tnx",
    "full ty",
    "anybody else need",
    "anyone else need",
    "need more",
    "needed for",
    "recruiting",
    "forming",
    "open party",
    "fort",
    "fortress",
    "warband needs",
    "warband",
    "warbands",
    "org wb",
    "org wbs",
    "org warband",
    "wb needs",
    "wb",
    "wbs",
    "owb",
    "owbs",
    "open spots",
    "open spot",
    "empty slots",
    "empty slot",
    "spots left",
    "spot left",
    "butcher s pass",
    "butchers pass",
    "stonewatch",
    "the maw",
    "reikwald",
    "fell landing",
    "shining way",
}

local PA_LFG_CANDIDATE_GROUP_NEED_QUERIES = {
    "any group need",
    "any group needs",
    "any grp need",
    "any grp needs",
    "any party need",
    "any party needs",
}

local PA_LFG_LENIENT_PATTERNS = {
    "%f[%w]lf%f[%W].-%f[%w]party%f[%W]",
    "%f[%w]tank%f[%W]",
    "%f[%w]healer%f[%W]",
    "%f[%w]heal%f[%W]",
    "%f[%w]dps%f[%W]",
    "%f[%w]mdps%f[%W]",
    "%f[%w]rdps%f[%W]",
}

local PA_LFG_NEGATIVE_PATTERNS = {
    "%f[%w]lf%d*m%f[%W]",
}

local PA_LFG_DUNGEON_META_PHRASES = {
    "means",
    "meaning",
    "stand for",
    "stands for",
    "short for",
    "abbrev",
    "abbreviation",
    "abbreviations",
    "abbreviated",
    "full name",
    "spell out",
    "spelled out",
}

local PA_LFG_CARRY_OFFER_WORDS = {
    "carry",
    "carries",
    "carrying",
    "boost",
    "boosts",
    "boosting",
    "leech",
    "leeches",
    "leeching",
}

local PA_LFG_FREE_OFFER_WORDS = {
    "free",
    "freebie",
    "freebies",
}

local PA_LFG_CARRY_OFFER_CONTEXT_WORDS = {
    "sell",
    "selling",
    "sells",
    "wts",
    "offer",
    "offering",
    "offers",
    "provide",
    "providing",
    "provides",
    "available",
}

local PA_LFG_CARRY_OFFER_CONTEXT_PHRASES = {
    "can carry",
    "can boost",
    "carry available",
    "boost available",
    "leech available",
}

local PA_LFG_RECRUITER_ROLE_WORDS = {
    tank = true,
    tanks = true,
    tand = true, -- common "and"/"tank" typo in recruiter role lists
    heal = true,
    heals = true,
    healer = true,
    healers = true,
    dps = true,
    d = true,
    dick = true,
    dd = true,
    deeps = true,
    damage = true,
    pumper = true,
    pumpers = true,
    mdps = true,
    rdps = true,
}

local PA_LFG_RECRUITER_FILLER_WORDS = {
    a = true,
    an = true,
    any = true,
    last = true,
    more = true,
    another = true,
    proper = true,
    real = true,
    good = true,
    solid = true,
    decent = true,
    strong = true,
    geared = true,
    experienced = true,
    exp = true,
    competent = true,
    reliable = true,
    bis = true,
    cracked = true,
    juiced = true,
    stacked = true,
    sweaty = true,
    skilled = true,
    veteran = true,
    clean = true,
    big = true,
    high = true,
    fresh = true,
    extra = true,
    shield = true,
    ["2h"] = true,
    melee = true,
    ranged = true,
    aoe = true,
    ae = true,
    pump = true,
    off = true,
}

local PA_LFG_RECRUITER_ALIAS_FILLERS = {
    "one",
    "two",
    "three",
    "last",
    "another",
}

local PA_LFG_SMALL_COUNT_WORDS = {
    ["1"] = true,
    ["2"] = true,
    ["3"] = true,
    ["4"] = true,
    ["5"] = true,
    ["6"] = true,
    ["1x"] = true,
    ["2x"] = true,
    ["3x"] = true,
    ["4x"] = true,
    ["5x"] = true,
    ["6x"] = true,
    one = true,
    two = true,
    three = true,
    four = true,
    five = true,
    six = true,
}

local PA_LFG_ROLE_CHATTER_STATE_WORDS = {
    are = true,
    is = true,
    get = true,
    gets = true,
    die = true,
    dies = true,
}

local PA_LFG_RECRUITER_CLOSEOUT_WORDS = {
    go = true,
    going = true,
    ready = true,
    pull = true,
    pulling = true,
    start = true,
    starts = true,
    starting = true,
    soon = true,
    now = true,
    asap = true,
}

local PA_LFG_GROUP_WORDS = {
    group = true,
    grp = true,
    party = true,
}

local PA_LFG_CAREER_REQUEST_PREFIXES = {
    "lf",
    "need",
    "needs",
    "want",
    "wants",
    "missing",
    "short",
    "looking for",
}

local PA_LFG_CAREER_ROLE_ALIAS_GROUPS = {
    [PartyAd.REALM_ORDER] = {
        {
            role = PartyAd.ROLE_DPS,
            aliases = {
                "engineer", "eng", "engi",
                "bright wizard", "bw",
                "shadow warrior", "sw",
                "witch hunter", "wh",
                "white lion", "wl",
                "slayer", "sl",
            },
        },
        {
            role = PartyAd.ROLE_TANK,
            aliases = {
                "ironbreaker", "iron breaker", "ib",
                "knight of the blazing sun", "knight", "kotbs", "kotb",
                "swordmaster", "sword master", "sm",
            },
        },
        {
            role = PartyAd.ROLE_HEALER,
            aliases = {
                "warrior priest", "wp",
                "rune priest", "rp",
                "archmage", "arch mage", "am",
            },
        },
    },
    [PartyAd.REALM_DESTRUCTION] = {
        {
            role = PartyAd.ROLE_DPS,
            aliases = {
                "sorcerer", "sorc",
                "squig herder", "squig", "sh",
                "magus", "mag",
                "witch elf", "we",
                "choppa", "chp",
                "marauder", "mara",
            },
        },
        {
            role = PartyAd.ROLE_TANK,
            aliases = {
                "chosen", "cho",
                "black orc", "bo",
                "blackguard", "black guard", "bg",
            },
        },
        {
            role = PartyAd.ROLE_HEALER,
            aliases = {
                "zealot", "ze",
                "shaman", "sha",
                "disciple of khaine", "disciple", "dok",
            },
        },
    },
}

local PA_LFG_DUNGEON_ALIASES = {
    { realm = PartyAd.REALM_BOTH, aliases = { "mayhem farm", "mayhem" } },
    { realm = PartyAd.REALM_BOTH, aliases = { "ruin farm", "ruin" } },
    { realm = PartyAd.REALM_BOTH, aliases = { "dragonback pass", "dragonback", "dbp" } },
    { realm = PartyAd.REALM_DESTRUCTION, aliases = { "sacellum", "sac", "sd" } },
    { realm = PartyAd.REALM_ORDER, aliases = { "altdorf sewers", "sewers", "sewer", "sewerz" } },
    { realm = PartyAd.REALM_BOTH, aliases = { "gunbad", "gb" } },
    { realm = PartyAd.REALM_ORDER, aliases = { "sigmar crypts", "sig crypts", "crypts" } },
    { realm = PartyAd.REALM_DESTRUCTION, aliases = { "bilerot burrows", "bilerot", "bb" } },
    { realm = PartyAd.REALM_BOTH, aliases = { "bastion stair", "bastion", "bs" } },
    { realm = PartyAd.REALM_BOTH, aliases = { "hunter s vale", "hunters vale", "hunter vale", "hv" } },
    { realm = PartyAd.REALM_BOTH, aliases = { "lost vale", "lv" } },
}

local PA_CAREER_ICON_BY_NAME = {
    ["archmage"] = "<icon20180>",
    ["black guard"] = "<icon20181>",
    ["blackguard"] = "<icon20181>",
    ["black orc"] = "<icon20182>",
    ["bright wizard"] = "<icon20183>",
    ["choppa"] = "<icon20184>",
    ["chosen"] = "<icon20185>",
    ["disciple of khaine"] = "<icon20186>",
    ["engineer"] = "<icon20187>",
    ["slayer"] = "<icon20188>",
    ["ironbreaker"] = "<icon20189>",
    ["knight of the blazing sun"] = "<icon20190>",
    ["magus"] = "<icon20191>",
    ["marauder"] = "<icon20192>",
    ["rune priest"] = "<icon20193>",
    ["shadow warrior"] = "<icon20194>",
    ["shaman"] = "<icon20195>",
    ["sorcerer"] = "<icon20196>",
    ["squig herder"] = "<icon20197>",
    ["swordmaster"] = "<icon20198>",
    ["warrior priest"] = "<icon20199>",
    ["white lion"] = "<icon20200>",
    ["witch elf"] = "<icon20201>",
    ["witch hunter"] = "<icon20202>",
    ["zealot"] = "<icon20203>",
}

local PA_CAREER_ICON_BY_LINE_KEY = {
    ENGINEER = "<icon20187>",
    BRIGHT_WIZARD = "<icon20183>",
    SORCERER = "<icon20196>",
    SQUIG_HERDER = "<icon20197>",
    MAGUS = "<icon20191>",
    SHADOW_WARRIOR = "<icon20194>",
    WITCH_ELF = "<icon20201>",
    WHITE_LION = "<icon20200>",
    SLAYER = "<icon20188>",
    WITCH_HUNTER = "<icon20202>",
    CHOPPA = "<icon20184>",
    MARAUDER = "<icon20192>",
    IRON_BREAKER = "<icon20189>",
    CHOSEN = "<icon20185>",
    BLACK_ORC = "<icon20182>",
    KNIGHT = "<icon20190>",
    SWORDMASTER = "<icon20198>",
    BLACKGUARD = "<icon20181>",
    ZEALOT = "<icon20203>",
    WARRIOR_PRIEST = "<icon20199>",
    RUNE_PRIEST = "<icon20193>",
    ARCHMAGE = "<icon20180>",
    SHAMAN = "<icon20195>",
    DISCIPLE = "<icon20186>",
}

local function pa_normalize_lfg_scan_text(text)
    local s = pa_strip_link_markup(text)
    s = string.lower(s)
    s = string.gsub(s, "[%c%p]", " ")
    s = string.gsub(s, "%s+", " ")
    s = " " .. pa_trim(s) .. " "
    return s
end

local function pa_lfg_text_has_phrase(normalized_text, phrases)
    for i = 1, #phrases do
        local phrase = " " .. phrases[i] .. " "
        if string.find(normalized_text, phrase, 1, true) then
            return true
        end
    end
    return false
end

local function pa_lfg_text_has_pattern(normalized_text, patterns)
    for i = 1, #patterns do
        if string.find(normalized_text, patterns[i]) then
            return true
        end
    end
    return false
end

local function pa_get_lfg_career_role_groups()
    local realm = PartyAd.get_player_realm_key()
    if realm == PartyAd.REALM_ORDER or realm == PartyAd.REALM_DESTRUCTION then
        return PA_LFG_CAREER_ROLE_ALIAS_GROUPS[realm]
    end
    return nil
end

local function pa_lfg_realm_matches(realm)
    if realm == nil or realm == PartyAd.REALM_BOTH then
        return true
    end
    local player_realm = PartyAd.get_player_realm_key()
    if player_realm == nil then
        return true
    end
    return realm == player_realm
end

local function pa_lfg_alias_is_short(alias)
    return string.len(alias) <= 2 and string.find(alias, " ", 1, true) == nil
end

local function pa_lfg_text_is_exact_alias(normalized_text, alias)
    return pa_trim(normalized_text) == alias
end

local function pa_lfg_short_alias_has_context(normalized_text, alias)
    local before = {
        "solo",
        "x",
        "inv",
        "invite",
    }
    local after = {
        "x",
        "here",
        "lfg",
        "looking",
        "lf group",
        "lf grp",
        "lf party",
    }

    for i = 1, #before do
        if string.find(normalized_text, " " .. before[i] .. " " .. alias .. " ", 1, true) then
            return true
        end
    end
    for i = 1, #after do
        if string.find(normalized_text, " " .. alias .. " " .. after[i] .. " ", 1, true) then
            return true
        end
    end
    return false
end

local function pa_lfg_career_alias_matches(normalized_text, alias, include_role_inference_context)
    if pa_lfg_text_is_exact_alias(normalized_text, alias) then
        return true
    end
    if not pa_lfg_alias_is_short(alias) then
        return string.find(normalized_text, " " .. alias .. " ", 1, true) ~= nil
    end
    if pa_lfg_short_alias_has_context(normalized_text, alias) then
        return true
    end
    if include_role_inference_context == true then
        return string.find(normalized_text, " " .. alias .. " lf ", 1, true) ~= nil or
            string.find(normalized_text, " " .. alias .. " need ", 1, true) ~= nil
    end
    return false
end

local function pa_lfg_text_has_dungeon(normalized_text)
    for i = 1, #PA_LFG_DUNGEON_ALIASES do
        local entry = PA_LFG_DUNGEON_ALIASES[i]
        if pa_lfg_realm_matches(entry.realm) and pa_lfg_text_has_phrase(normalized_text, entry.aliases) then
            return true
        end
    end
    return false
end

local function pa_lfg_text_has_purpose_preset(normalized_text)
    for i = 1, #PartyAd.PURPOSE_PRESETS do
        local preset = PartyAd.PURPOSE_PRESETS[i]
        if preset and pa_lfg_realm_matches(preset.realm) then
            local values = { preset.text, preset.label }
            for j = 1, #values do
                local alias = pa_trim(pa_normalize_lfg_scan_text(values[j] or ""))
                if alias ~= "" and string.find(normalized_text, " " .. alias .. " ", 1, true) then
                    return true
                end
                local short_alias = string.match(alias, "^(.-)%s+farm$")
                if short_alias ~= nil and short_alias ~= "" and
                    string.find(normalized_text, " " .. short_alias .. " ", 1, true) then
                    return true
                end
            end
        end
    end
    return false
end

local function pa_lfg_text_has_purpose_preset_request(normalized_text)
    if not pa_lfg_text_has_phrase(normalized_text, {
        "lf",
        "looking for",
        "looking",
        "any",
        "anyone",
        "anybody",
        "need group",
        "need grp",
        "need party",
    }) then
        return false
    end
    return pa_lfg_text_has_purpose_preset(normalized_text)
end

local function pa_lfg_text_has_activity_carry_offer(normalized_text)
    if not (pa_lfg_text_has_dungeon(normalized_text) or pa_lfg_text_has_purpose_preset(normalized_text)) then
        return false
    end
    if not pa_lfg_text_has_phrase(normalized_text, PA_LFG_CARRY_OFFER_WORDS) then
        return false
    end
    if pa_lfg_text_has_phrase(normalized_text, PA_LFG_FREE_OFFER_WORDS) then
        return true
    end
    if pa_lfg_text_has_phrase(normalized_text, PA_LFG_CARRY_OFFER_CONTEXT_WORDS) then
        return true
    end
    return pa_lfg_text_has_phrase(normalized_text, PA_LFG_CARRY_OFFER_CONTEXT_PHRASES)
end

local function pa_lfg_text_has_dungeon_alias_equivalence(raw_text)
    local text = string.lower(pa_strip_link_markup(tostring(raw_text or "")))
    if not string.find(text, "=", 1, true) then
        return false
    end

    text = string.gsub(text, "[%c%p]", function(ch)
        if ch == "=" then
            return " = "
        end
        return " "
    end)
    text = " " .. pa_trim(string.gsub(text, "%s+", " ")) .. " "

    local left_alias = false
    local right_alias = false
    for i = 1, #PA_LFG_DUNGEON_ALIASES do
        local entry = PA_LFG_DUNGEON_ALIASES[i]
        if pa_lfg_realm_matches(entry.realm) and type(entry.aliases) == "table" then
            for j = 1, #entry.aliases do
                local alias = entry.aliases[j]
                if string.find(text, " " .. alias .. " = ", 1, true) then
                    left_alias = true
                end
                if string.find(text, " = " .. alias .. " ", 1, true) then
                    right_alias = true
                end
                if left_alias and right_alias then
                    return true
                end
            end
        end
    end
    return false
end

local function pa_lfg_text_has_dungeon_alias_meta_chatter(normalized_text, raw_text)
    if not pa_lfg_text_has_dungeon(normalized_text) then
        return false
    end
    if pa_lfg_text_has_phrase(normalized_text, PA_LFG_DUNGEON_META_PHRASES) then
        return true
    end
    return pa_lfg_text_has_dungeon_alias_equivalence(raw_text)
end

local function pa_lfg_text_has_faction_career(normalized_text)
    local groups = pa_get_lfg_career_role_groups()
    if type(groups) ~= "table" then
        return false
    end

    for i = 1, #groups do
        local aliases = groups[i] and groups[i].aliases or nil
        if type(aliases) == "table" then
            for j = 1, #aliases do
                if pa_lfg_career_alias_matches(normalized_text, aliases[j], false) then
                    return true
                end
            end
        end
    end
    return false
end

local function pa_add_lfg_role_signal(signals, role)
    if role == PartyAd.ROLE_TANK or role == PartyAd.ROLE_HEALER or role == PartyAd.ROLE_DPS then
        signals[role] = true
    end
end

local function pa_get_single_lfg_role_signal(signals)
    local found = nil
    local count = 0
    for role in pairs(signals) do
        found = role
        count = count + 1
    end
    if count == 1 then
        return found, true, false
    end
    if count > 1 then
        return nil, true, true
    end
    return nil, false, false
end

local function pa_infer_lfg_explicit_role(normalized_text)
    local signals = {}
    if pa_lfg_text_has_phrase(normalized_text, { "tank", "tanks", "shield tank", "2h tank", "off tank", "ot" }) then
        pa_add_lfg_role_signal(signals, PartyAd.ROLE_TANK)
    end
    if pa_lfg_text_has_phrase(normalized_text, { "heal", "heals", "healer", "healers", "healing", "offheal", "off heal" }) then
        pa_add_lfg_role_signal(signals, PartyAd.ROLE_HEALER)
    end
    if pa_lfg_text_has_phrase(normalized_text, {
        "dps", "mdps", "rdps", "dd", "deeps", "damage", "pumper", "pumpers",
        "big d", "big dick", "aoe dps", "ae dps", "melee dps", "ranged dps",
    }) then
        pa_add_lfg_role_signal(signals, PartyAd.ROLE_DPS)
    end
    return pa_get_single_lfg_role_signal(signals)
end

local function pa_infer_lfg_career_role(normalized_text)
    local groups = pa_get_lfg_career_role_groups()
    if type(groups) ~= "table" then
        return nil
    end

    local signals = {}
    for i = 1, #groups do
        local group = groups[i]
        local aliases = group and group.aliases or nil
        if type(aliases) == "table" then
            for j = 1, #aliases do
                if pa_lfg_career_alias_matches(normalized_text, aliases[j], true) then
                    pa_add_lfg_role_signal(signals, group.role)
                end
            end
        end
    end
    return pa_get_single_lfg_role_signal(signals)
end

function PartyAd.infer_lfg_candidate_role(message)
    local normalized = pa_normalize_lfg_scan_text(message)
    local role, has_explicit = pa_infer_lfg_explicit_role(normalized)
    if has_explicit then
        return role
    end
    role = pa_infer_lfg_career_role(normalized)
    return role
end

local function pa_lfg_text_is_candidate_group_need_query(normalized_text)
    for i = 1, #PA_LFG_CANDIDATE_GROUP_NEED_QUERIES do
        if string.find(normalized_text, " " .. PA_LFG_CANDIDATE_GROUP_NEED_QUERIES[i] .. " ", 1, true) then
            return true
        end
    end
    return false
end

local function pa_lfg_text_has_prefixed_alias(normalized_text, prefix, alias)
    if string.find(normalized_text, " " .. prefix .. " " .. alias .. " ", 1, true) then
        return true
    end
    if string.find(normalized_text, " " .. prefix .. " a " .. alias .. " ", 1, true) then
        return true
    end
    if string.find(normalized_text, " " .. prefix .. " an " .. alias .. " ", 1, true) then
        return true
    end
    for i = 1, #PA_LFG_RECRUITER_ALIAS_FILLERS do
        if string.find(normalized_text, " " .. prefix .. " " .. PA_LFG_RECRUITER_ALIAS_FILLERS[i] .. " " .. alias .. " ", 1, true) then
            return true
        end
    end
    for n = 1, 6 do
        if string.find(normalized_text, " " .. prefix .. " " .. tostring(n) .. " " .. alias .. " ", 1, true) then
            return true
        end
    end
    return false
end

local function pa_lfg_text_has_career_request_prefix(normalized_text)
    for i = 1, #PA_LFG_CAREER_REQUEST_PREFIXES do
        if string.find(normalized_text, " " .. PA_LFG_CAREER_REQUEST_PREFIXES[i] .. " ", 1, true) then
            return true
        end
    end
    return false
end

local function pa_lfg_text_has_faction_career_request(normalized_text)
    if pa_lfg_text_is_candidate_group_need_query(normalized_text) then
        return false
    end
    if not pa_lfg_text_has_career_request_prefix(normalized_text) then
        return false
    end

    local groups = pa_get_lfg_career_role_groups()
    if type(groups) ~= "table" then
        return false
    end

    for i = 1, #groups do
        local aliases = groups[i] and groups[i].aliases or nil
        if type(aliases) == "table" then
            for j = 1, #aliases do
                for k = 1, #PA_LFG_CAREER_REQUEST_PREFIXES do
                    if pa_lfg_text_has_prefixed_alias(normalized_text, PA_LFG_CAREER_REQUEST_PREFIXES[k], aliases[j]) then
                        return true
                    end
                end
            end
        end
    end
    return false
end

local function pa_lfg_tokenize(normalized_text)
    local tokens = {}
    for token in string.gmatch(pa_trim(normalized_text), "%S+") do
        tokens[#tokens + 1] = token
    end
    return tokens
end

local function pa_lfg_text_is_role_chatter(tokens)
    for i = 1, #tokens do
        if tokens[i] == "all" then
            for j = i + 1, math.min(i + 8, #tokens - 1) do
                local is_role_word = PA_LFG_RECRUITER_ROLE_WORDS[tokens[j]] == true
                local has_chatter_state = PA_LFG_ROLE_CHATTER_STATE_WORDS[tokens[j + 1]] == true
                if is_role_word and has_chatter_state then
                    return true
                end
            end
        end
    end
    return false
end

local function pa_lfg_token_is_small_count(token)
    return PA_LFG_SMALL_COUNT_WORDS[tostring(token or "")] == true
end

local function pa_lfg_token_is_recruiter_filler(token)
    local value = tostring(token or "")
    return PA_LFG_RECRUITER_FILLER_WORDS[value] == true or
        pa_lfg_token_is_small_count(value) or
        string.match(value, "^%d+$") ~= nil or
        string.match(value, "^rr%d*$") ~= nil or
        string.match(value, "^cr%d*$") ~= nil
end

local function pa_lfg_token_is_recruiter_bridge(token)
    local value = tostring(token or "")
    return value == "for" or value == "on" or value == "to" or value == "and" or value == "or"
end

local function pa_lfg_token_is_recruiter_closeout(token)
    local value = tostring(token or "")
    if PA_LFG_RECRUITER_CLOSEOUT_WORDS[value] == true then
        return true
    end
    return string.match(value, "^go+$") ~= nil
end

local function pa_lfg_token_has_short_prefix_before(token, suffix, max_prefix_len)
    local value = tostring(token or "")
    local prefix_len = string.len(value) - string.len(suffix)
    if prefix_len < 1 or prefix_len > max_prefix_len then
        return false
    end
    if string.sub(value, prefix_len + 1) ~= suffix then
        return false
    end
    return string.match(string.sub(value, 1, prefix_len), "^%a+$") ~= nil
end

local function pa_lfg_token_has_short_suffix_after(token, prefix, max_suffix_len)
    local value = tostring(token or "")
    local suffix_len = string.len(value) - string.len(prefix)
    if suffix_len < 1 or suffix_len > max_suffix_len then
        return false
    end
    if string.sub(value, 1, string.len(prefix)) ~= prefix then
        return false
    end
    return string.match(string.sub(value, string.len(prefix) + 1), "^%a+$") ~= nil
end

local function pa_lfg_token_has_count_suffix_after(token, prefix)
    local value = tostring(token or "")
    if string.sub(value, 1, string.len(prefix)) ~= prefix then
        return false
    end
    return PA_LFG_SMALL_COUNT_WORDS[string.sub(value, string.len(prefix) + 1)] == true
end

local function pa_lfg_token_is_recruiter_request_verb(token)
    local value = tostring(token or "")
    if value == "lf" or value == "need" or value == "needs" or value == "needed" or
        value == "want" or value == "wants" or value == "missing" then
        return true
    end
    return pa_lfg_token_has_short_prefix_before(value, "lf", 1) or
        pa_lfg_token_has_short_prefix_before(value, "need", 3) or
        pa_lfg_token_has_short_prefix_before(value, "want", 3) or
        pa_lfg_token_has_short_suffix_after(value, "need", 2) or
        pa_lfg_token_has_short_suffix_after(value, "want", 2) or
        pa_lfg_token_has_count_suffix_after(value, "lf") or
        pa_lfg_token_has_count_suffix_after(value, "need") or
        pa_lfg_token_has_count_suffix_after(value, "needs") or
        pa_lfg_token_has_count_suffix_after(value, "want") or
        pa_lfg_token_has_count_suffix_after(value, "wants")
end

local function pa_lfg_tokens_have_role_after(tokens, start_index, max_steps)
    local stop_index = start_index + max_steps
    if stop_index > #tokens then
        stop_index = #tokens
    end

    for i = start_index, stop_index do
        local token = tokens[i]
        if PA_LFG_RECRUITER_ROLE_WORDS[token] == true then
            return true
        end
        if not (pa_lfg_token_is_recruiter_filler(token) or pa_lfg_token_is_recruiter_bridge(token)) then
            return false
        end
    end
    return false
end

local function pa_lfg_token_is_activity_alias(token)
    local value = pa_trim(token)
    if value == "" then
        return false
    end

    local normalized = " " .. value .. " "
    return pa_lfg_text_has_dungeon(normalized) or pa_lfg_text_has_purpose_preset(normalized)
end

local function pa_lfg_tokens_have_activity_role_after(tokens, start_index, max_steps)
    local stop_index = start_index + max_steps
    if stop_index > #tokens then
        stop_index = #tokens
    end

    local saw_activity = false
    for i = start_index, stop_index do
        local token = tokens[i]
        if PA_LFG_RECRUITER_ROLE_WORDS[token] == true then
            return saw_activity
        end
        if pa_lfg_token_is_activity_alias(token) then
            saw_activity = true
        elseif not (pa_lfg_token_is_recruiter_filler(token) or pa_lfg_token_is_recruiter_bridge(token)) then
            return false
        end
    end
    return false
end

local function pa_lfg_token_role_has_recruiter_state_after(tokens, index)
    for i = index + 1, index + 3 do
        local token = tokens[i]
        if token == nil then
            return false
        end
        if token == "needed" or token == "short" or token == "slot" or token == "slots" or
            token == "spot" or token == "spots" or token == "join" or token == "joins" then
            return true
        end
    end
    return false
end

local function pa_lfg_text_has_group_progress(raw_text)
    local text = string.lower(pa_strip_link_markup(tostring(raw_text or "")))
    for current_text, total_text in string.gmatch(text, "(%d+)%s*/%s*(%d+)") do
        local current = tonumber(current_text)
        local total = tonumber(total_text)
        if current ~= nil and total ~= nil and total >= 2 and total <= 6 and current >= 1 and current <= total then
            return true
        end
    end
    for current_text in string.gmatch(text, "%f[%d](%d+)%s*/%s*x%f[%W]") do
        local current = tonumber(current_text)
        if current ~= nil and current >= 1 and current <= 6 then
            return true
        end
    end
    return false
end

local function pa_lfg_token_is_activity_subject(token)
    local value = tostring(token or "")
    if value == "" or value == "a" or value == "an" or value == "the" or value == "any" or
        value == "for" or value == "and" or value == "or" or PA_LFG_GROUP_WORDS[value] == true then
        return false
    end
    return string.match(value, "%a") ~= nil
end

local function pa_lfg_text_has_activity_group_request(tokens)
    if not (PA_LFG_GROUP_WORDS[tokens[1]] == true and tokens[2] == "for") then
        return false
    end

    for i = 3, math.min(#tokens, 8) do
        if pa_lfg_token_is_activity_subject(tokens[i]) then
            return true
        end
    end
    return false
end

local function pa_lfg_text_has_counted_role_request(tokens, normalized_text, raw_text)
    for i = 1, #tokens do
        if pa_lfg_token_is_small_count(tokens[i]) and pa_lfg_tokens_have_role_after(tokens, i + 1, 3) then
            return pa_lfg_text_has_group_progress(raw_text) or pa_lfg_text_has_dungeon(normalized_text)
        end
    end
    return false
end

local function pa_lfg_text_has_role_list_for_run(tokens, normalized_text)
    if string.find(normalized_text, " lfg ", 1, true) then
        return false
    end
    if not pa_lfg_text_has_dungeon(normalized_text) then
        return false
    end

    local role_count = 0
    for i = 1, #tokens do
        if PA_LFG_RECRUITER_ROLE_WORDS[tokens[i]] == true then
            role_count = role_count + 1
            if role_count >= 2 then
                return true
            end
        end
    end
    return false
end

local function pa_lfg_text_has_slot_for_run(tokens, normalized_text)
    if not pa_lfg_text_has_dungeon(normalized_text) then
        return false
    end

    for i = 1, #tokens do
        if (tokens[i] == "slot" or tokens[i] == "slots" or tokens[i] == "spot" or tokens[i] == "spots") and
            tokens[i + 1] == "for" then
            return true
        end
    end
    return false
end

local function pa_lfg_text_has_any_role_for_run(tokens)
    for i = 1, #tokens do
        if tokens[i] == "any" then
            local role_index = nil
            for j = i + 1, math.min(i + 4, #tokens) do
                if PA_LFG_RECRUITER_ROLE_WORDS[tokens[j]] == true then
                    role_index = j
                    break
                end
                if not pa_lfg_token_is_recruiter_filler(tokens[j]) then
                    break
                end
            end
            if role_index ~= nil and tokens[role_index + 1] == "for" and tokens[role_index + 2] ~= nil then
                return true
            end
        end
    end
    return false
end

local function pa_lfg_role_prefix_is_recruiter_need(tokens, role_index)
    if role_index > 4 then
        return false
    end
    for i = 1, role_index - 1 do
        local token = tokens[i]
        if not (
            pa_lfg_token_is_recruiter_filler(token) or
            token == "lf" or
            token == "need" or
            token == "needs" or
            token == "want" or
            token == "wants" or
            token == "missing" or
            token == "short"
        ) then
            return false
        end
    end
    return true
end

local function pa_lfg_tokens_have_recruiter_closeout_after(tokens, start_index, max_steps)
    local stop_index = start_index + max_steps
    if stop_index > #tokens then
        stop_index = #tokens
    end
    for i = start_index, stop_index do
        if pa_lfg_token_is_recruiter_closeout(tokens[i]) then
            return true
        end
    end
    return false
end

local function pa_lfg_text_has_role_for_activity_closeout(tokens)
    for i = 1, #tokens - 2 do
        local role_token = tokens[i]
        local activity_token = tokens[i + 2]
        if PA_LFG_RECRUITER_ROLE_WORDS[role_token] == true and
            tokens[i + 1] == "for" and
            pa_lfg_role_prefix_is_recruiter_need(tokens, i) and
            pa_lfg_token_is_activity_subject(activity_token) and
            pa_lfg_tokens_have_recruiter_closeout_after(tokens, i + 3, 6) then
            return true
        end
    end
    return false
end

local function pa_lfg_text_has_recruiter_role_request(normalized_text, raw_text, tokens)
    if string.find(normalized_text, " any room ", 1, true) then
        return false
    end
    if pa_lfg_text_is_candidate_group_need_query(normalized_text) then
        return false
    end

    tokens = tokens or pa_lfg_tokenize(normalized_text)
    if pa_lfg_text_is_role_chatter(tokens) then
        return true
    end

    if pa_lfg_text_has_counted_role_request(tokens, normalized_text, raw_text) then
        return true
    end
    if pa_lfg_text_has_role_list_for_run(tokens, normalized_text) then
        return true
    end
    if pa_lfg_text_has_slot_for_run(tokens, normalized_text) then
        return true
    end
    if pa_lfg_text_has_any_role_for_run(tokens) then
        return true
    end
    if pa_lfg_text_has_role_for_activity_closeout(tokens) then
        return true
    end

    for i = 1, #tokens do
        local token = tokens[i]
        if token == "glf" then
            return true
        end
        if pa_lfg_token_is_recruiter_request_verb(token) then
            if pa_lfg_tokens_have_role_after(tokens, i + 1, 5) or
                pa_lfg_tokens_have_activity_role_after(tokens, i + 1, 5) then
                return true
            end
        elseif token == "short" then
            if pa_lfg_tokens_have_role_after(tokens, i + 1, 5) then
                return true
            end
        elseif token == "looking" and tokens[i + 1] == "for" then
            if pa_lfg_tokens_have_role_after(tokens, i + 2, 5) or
                pa_lfg_tokens_have_activity_role_after(tokens, i + 2, 5) then
                return true
            end
        elseif token == "could" and tokens[i + 1] == "use" then
            if pa_lfg_tokens_have_role_after(tokens, i + 2, 5) then
                return true
            end
        elseif token == "room" and tokens[i + 1] == "for" then
            if pa_lfg_tokens_have_role_after(tokens, i + 2, 5) then
                return true
            end
        elseif PA_LFG_GROUP_WORDS[token] == true and tokens[i + 1] == "for" then
            if pa_lfg_tokens_have_role_after(tokens, i + 2, 5) then
                return true
            end
        elseif token == "slot" or token == "slots" or token == "spot" or token == "spots" then
            if pa_lfg_tokens_have_role_after(tokens, i + 1, 4) then
                return true
            end
        elseif PA_LFG_RECRUITER_ROLE_WORDS[token] == true then
            if pa_lfg_token_role_has_recruiter_state_after(tokens, i) then
                return true
            end
        end
    end

    return false
end

local function pa_extract_linked_player_name(text)
    local raw = tostring(text or "")
    local linked = string.match(raw, "data=\"PLAYERNS:([^\"]+)\"") or
        string.match(raw, "data=\"PLAYER:([^\"]+)\"")
    if linked and linked ~= "" then
        return pa_clean_player_name(linked)
    end

    local link_text = string.match(raw, "text=\"@?([^\"]+)\"")
    if link_text and link_text ~= "" then
        return pa_clean_player_name(link_text)
    end

    return nil
end

local function pa_lfg_sender_name_is_plausible(name)
    local cleaned = pa_clean_player_name(name)
    if cleaned == "" then
        return false
    end
    if string.find(cleaned, ":", 1, true) then
        return false
    end
    if not string.match(cleaned, "^[%a][%w%-']+$") then
        return false
    end
    return true
end

local function pa_extract_sender_from_visible_text(visible_text)
    local text = tostring(visible_text or "")
    local bracket_sender = string.match(text, "%[([^%]]+)%]%s*:")
    if pa_lfg_sender_name_is_plausible(bracket_sender) then
        return pa_clean_player_name(bracket_sender)
    end

    text = string.gsub(text, "^%s*%[[^%]]+%]%s*", "")
    text = string.gsub(text, "^%s*%[[^%]]+%]%s*", "")
    text = string.gsub(text, "^%s*%d+%.%s*[^:]+:%s*", "")

    local name = string.match(text, "^@?([%a][%w%-']+)%s*:")
    if name and name ~= "" then
        return pa_clean_player_name(name)
    end

    return nil
end

local function pa_extract_message_after_sender(visible_text, sender_name)
    local text = pa_trim(visible_text)

    local name = pa_clean_player_name(sender_name)
    if name ~= "" then
        local bracket_pattern = "%[" .. pa_escape_lua_pattern(name) .. "%]%s*:%s*(.*)$"
        local after = string.match(text, bracket_pattern)
        if after and after ~= "" then
            return pa_trim(after)
        end

        local pattern = "^@?" .. pa_escape_lua_pattern(name) .. "%s*:%s*(.*)$"
        after = string.match(text, pattern)
        if after and after ~= "" then
            return pa_trim(after)
        end
        after = string.match(text, "@?" .. pa_escape_lua_pattern(name) .. "%s*:%s*(.*)$")
        if after and after ~= "" then
            return pa_trim(after)
        end
    end

    text = string.gsub(text, "^%s*%[[^%]]+%]%s*", "")
    text = string.gsub(text, "^%s*%[[^%]]+%]%s*", "")

    local fallback = string.match(text, "^@?[%a][%w%-']+%s*:%s*(.*)$")
    if fallback and fallback ~= "" then
        return pa_trim(fallback)
    end

    return text
end

local function pa_build_lfg_display_line(sender_name, message, scan_mode, truncate_message)
    local name = pa_clean_player_name(sender_name)
    if name == "" then
        return pa_trim(message)
    end

    local channel_label = "5: "
    if scan_mode == "strict" then
        channel_label = "3: "
    end
    local safe_message = pa_trim(message)
    if truncate_message ~= false then
        safe_message = pa_truncate(safe_message, PartyAd.LFG_SCAN_TEXT_MAX_LEN)
    end
    return channel_label .. pa_format_player_mention(name) .. ": " .. safe_message
end

local function pa_get_lfg_scan_channel_filter()
    local filters = SystemData and SystemData.ChatLogFilters
    if type(filters) ~= "table" then
        return nil
    end
    return filters.CHANNEL_5
end

local function pa_get_lfg_scan_strict_channel_filter()
    local filters = SystemData and SystemData.ChatLogFilters
    if type(filters) ~= "table" then
        return nil
    end
    return filters.CHANNEL_3
end

local function pa_get_lfg_scan_mode(filter_type)
    local lfg_filter = pa_get_lfg_scan_channel_filter()
    if lfg_filter ~= nil and filter_type == lfg_filter then
        return "lenient"
    end

    local strict_filter = pa_get_lfg_scan_strict_channel_filter()
    if strict_filter ~= nil and filter_type == strict_filter then
        return "strict"
    end

    return nil
end

local function pa_should_run_lfg_scan()
    if not (PartyAd.saved and PartyAd.saved.use_lfg_scan == true) then
        return false
    end
    if PartyAdWindow and type(PartyAdWindow.IsShowing) == "function" then
        return PartyAdWindow.IsShowing() == true
    end
    return false
end

local function pa_get_player_level()
    local player = GameData and GameData.Player
    if type(player) ~= "table" then
        return nil
    end
    return pa_to_number(player.level)
end

local function pa_player_level_allows_lfg_social_lookup()
    local level = pa_get_player_level()
    return level ~= nil and level >= PartyAd.LFG_SOCIAL_SEARCH_MIN_PLAYER_LEVEL
end

function PartyAd.can_use_lfg_social_lookup()
    return pa_should_run_lfg_scan() and pa_player_level_allows_lfg_social_lookup()
end

local function pa_lookup_candidate_rank(name)
    if PartyAd._lfg_scan_disable_autoband_lookup == true then
        return nil
    end
    if type(AutoBand) ~= "table" then
        return nil
    end

    if type(AutoBand.get_realm_rank_lookup_result) == "function" then
        local ok_lookup, result = pcall(AutoBand.get_realm_rank_lookup_result, name, {
            allow_cache_fallback = true,
        })
        if ok_lookup and type(result) == "table" then
            return result
        end
    end

    if type(AutoBand.get_realm_rank_for_name) == "function" then
        local ok_rr, rr = pcall(AutoBand.get_realm_rank_for_name, name)
        if ok_rr and rr ~= nil then
            return { rr = rr }
        end
    end

    return nil
end

local function pa_detail_string(value)
    local text = pa_note_to_string(value)
    if text == nil then
        return ""
    end
    return pa_trim(text)
end

local function pa_detail_number(value)
    local text = pa_detail_string(value)
    if text == "" then
        return nil
    end
    local n = tonumber(text)
    if n ~= nil then
        return n
    end
    local digits = string.match(text, "(%d+)")
    if digits ~= nil then
        return tonumber(digits)
    end
    return nil
end

local function pa_normalize_career_name(value)
    local text = pa_detail_string(value)
    if text == "" then
        return ""
    end
    local caret_pos = string.find(text, "^", 1, true)
    if caret_pos then
        text = string.sub(text, 1, caret_pos - 1)
    end
    text = string.lower(text)
    text = string.gsub(text, "[%c%p]", " ")
    text = string.gsub(text, "%s+", " ")
    text = string.gsub(text, "%s+[mf]$", "")
    return pa_trim(text)
end

local function pa_compact_career_name(value)
    local key = pa_normalize_career_name(value)
    if key == "" then
        return ""
    end
    return string.gsub(key, "[^a-z]", "")
end

local function pa_lookup_career_icon_by_line(career_line)
    local line = pa_detail_number(career_line)
    if line == nil or not (GameData and type(GameData.CareerLine) == "table") then
        return nil
    end

    for key, icon in pairs(PA_CAREER_ICON_BY_LINE_KEY) do
        if GameData.CareerLine[key] == line then
            return icon
        end
    end
    return nil
end

local function pa_lookup_career_icon_by_name(career_name)
    local key = pa_normalize_career_name(career_name)
    if key == "" then
        return nil
    end

    local icon = PA_CAREER_ICON_BY_NAME[key]
    if icon ~= nil then
        return icon
    end

    if type(CareerNames) == "table" and type(Icons) == "table" and type(Icons.GetCareerIconIDFromCareerNamesID) == "function" then
        for career_id, data in pairs(CareerNames) do
            local name = data and data.name or nil
            if pa_normalize_career_name(name) == key then
                local ok_icon, icon_id = pcall(Icons.GetCareerIconIDFromCareerNamesID, career_id)
                icon_id = ok_icon and pa_detail_number(icon_id) or nil
                if icon_id ~= nil and icon_id > 0 then
                    return "<icon" .. tostring(math.floor(icon_id)) .. ">"
                end
            end
        end
    end

    local compact_key = pa_compact_career_name(career_name)
    if compact_key ~= "" then
        for career_key, career_icon in pairs(PA_CAREER_ICON_BY_NAME) do
            if pa_compact_career_name(career_key) == compact_key then
                return career_icon
            end
        end
    end

    return nil
end

local function pa_lookup_career_icon_by_career_names_id(career_id)
    local id = pa_detail_number(career_id)
    if id == nil or not (type(Icons) == "table" and type(Icons.GetCareerIconIDFromCareerNamesID) == "function") then
        return nil
    end

    local ok_icon, icon_id = pcall(Icons.GetCareerIconIDFromCareerNamesID, id)
    icon_id = ok_icon and pa_detail_number(icon_id) or nil
    if icon_id ~= nil and icon_id > 0 then
        return "<icon" .. tostring(math.floor(icon_id)) .. ">"
    end
    return nil
end

local function pa_read_lfg_social_search_list()
    if type(GetSearchList) ~= "function" then
        return nil
    end

    local ok, list = pcall(GetSearchList)
    if ok and type(list) == "table" then
        return list
    end
    return nil
end

local function pa_lfg_social_row_name(row)
    if type(row) ~= "table" then
        return ""
    end
    return pa_detail_string(row.name or row.Name)
end

local function pa_lfg_social_detail_from_row(row)
    if type(row) ~= "table" then
        return nil
    end
    return {
        source = "social",
        level = row.level or row.rank or row.rankString or row.Level or row.Rank or row.RankString,
        career_name = row.career_name or row.careerName or row.career or row.CareerName or row.Career,
        guild_name = row.guildName or row.guild_name or row.GuildName,
        zone_id = row.zoneID or row.zone_id or row.ZoneID,
    }
end

local function pa_lookup_candidate_icon_from_detail(detail)
    if type(detail) ~= "table" then
        return ""
    end

    if detail.source == "social" then
        return pa_lookup_career_icon_by_name(detail.career_name or detail.careerName or detail.career) or ""
    end

    local icon = pa_detail_string(detail.career_icon or detail.careerIcon or detail.CareerIcon)
    local icon_id = pa_detail_number(icon)
    if icon_id ~= nil and icon_id > 0 then
        icon = "<icon" .. tostring(math.floor(icon_id)) .. ">"
    elseif not string.match(icon, "^<icon%d+>$") then
        icon = ""
    end
    if icon == "" then
        icon = pa_lookup_career_icon_by_line(detail.career_line or detail.careerLine)
            or pa_lookup_career_icon_by_name(detail.career_name or detail.careerName or detail.career)
            or pa_lookup_career_icon_by_career_names_id(detail.career_id or detail.careerID or detail.careerId)
            or ""
    end
    return icon
end

local function pa_get_killboard_link_data_from_detail(detail)
    if type(detail) ~= "table" then
        return nil
    end

    local character_id =
        detail.character_id or
        detail.characterId or
        detail.characterID or
        detail.CharacterId or
        detail.CharacterID or
        detail.id or
        detail.Id
    return PartyAd.build_killboard_link_data_for_character_id(character_id)
end

local function pa_build_candidate_detail_from_lookup(detail)
    if type(detail) ~= "table" then
        return "", false
    end

    local parts = {}
    local icon = pa_lookup_candidate_icon_from_detail(detail)
    if detail.source == "social" and icon == "" then
        return "", false
    end
    if icon ~= "" then
        parts[#parts + 1] = icon
    end
    local career_name = pa_detail_string(detail.career_name or detail.careerName or detail.career)
    if icon == "" and career_name ~= "" then
        parts[#parts + 1] = career_name
    end

    local rank_parts = {}
    local level = pa_detail_number(detail.level or detail.rank or detail.rankString)
    if level ~= nil and level >= 0 then
        rank_parts[#rank_parts + 1] = "CR" .. tostring(math.floor(level))
    end
    local rr = pa_detail_number(detail.rr)
    if rr ~= nil and rr >= 0 then
        rank_parts[#rank_parts + 1] = "RR" .. tostring(math.floor(rr))
    end
    if #rank_parts > 0 then
        parts[#parts + 1] = "(" .. pa_join(rank_parts, " ") .. ")"
    end

    if #parts == 0 then
        return "", false
    end
    return pa_join(parts, " "), true
end

local function pa_lookup_candidate_social_cache(name)
    if not pa_player_level_allows_lfg_social_lookup() then
        return nil
    end

    local name_key = pa_name_key(name)
    if name_key == "" then
        return nil
    end

    local list = pa_read_lfg_social_search_list()
    if type(list) ~= "table" then
        return nil
    end

    for i = 1, #list do
        local row = list[i]
        if type(row) == "table" then
            local row_name = pa_lfg_social_row_name(row)
            if row_name ~= "" and pa_name_key(row_name) == name_key then
                return pa_lfg_social_detail_from_row(row)
            end
        end
    end

    return nil
end

local function pa_build_candidate_detail(name)
    local detail = pa_lookup_candidate_rank(name)
    local detail_text, enriched = pa_build_candidate_detail_from_lookup(detail)
    if enriched then
        return detail_text, true, "autoband", pa_get_killboard_link_data_from_detail(detail)
    end

    detail = pa_lookup_candidate_social_cache(name)
    detail_text, enriched = pa_build_candidate_detail_from_lookup(detail)
    if enriched then
        return detail_text, true, "social", nil
    end

    return "", false, nil, nil
end

local function pa_build_lfg_fallback_detail(message)
    local role = PartyAd.infer_lfg_candidate_role(message)
    local icon = role and PA_LFG_ROLE_ICON_BY_ROLE[role] or nil
    if icon == nil or icon == "" then
        icon = PA_LFG_UNKNOWN_ROLE_ICON
    end
    return icon .. " (CR??)", role
end

local function pa_find_lfg_candidate_index(name_key)
    local entries = PartyAd.lfg_candidates or {}
    for i = 1, #entries do
        if entries[i] and entries[i].name_key == name_key then
            return i
        end
    end
    return nil
end

local function pa_get_lfg_social_lookup_queue()
    if type(PartyAd.lfg_social_lookup_queue) ~= "table" then
        PartyAd.lfg_social_lookup_queue = {}
    end
    return PartyAd.lfg_social_lookup_queue
end

local function pa_get_lfg_social_lookup_attempted()
    if type(PartyAd.lfg_social_lookup_attempted) ~= "table" then
        PartyAd.lfg_social_lookup_attempted = {}
    end
    return PartyAd.lfg_social_lookup_attempted
end

local function pa_lfg_social_lookup_is_queued(name_key)
    local queue = pa_get_lfg_social_lookup_queue()
    for i = 1, #queue do
        if queue[i] and queue[i].name_key == name_key then
            return true
        end
    end
    return false
end

local function pa_apply_lfg_social_detail_to_entry(entry, detail)
    if type(entry) ~= "table" then
        return false
    end

    local detail_text, enriched = pa_build_candidate_detail_from_lookup(detail)
    if not enriched then
        return false
    end

    if entry.detail == detail_text and entry.enriched == true and entry.enrich_source == "social" then
        return false
    end

    entry.detail = detail_text
    entry.enriched = true
    entry.enrich_source = "social"
    entry.detail_link_data = nil
    entry.inferred_role = nil
    return true
end

local function pa_get_lfg_social_result_cache()
    if type(PartyAd.lfg_social_result_cache) ~= "table" then
        PartyAd.lfg_social_result_cache = {}
    end
    return PartyAd.lfg_social_result_cache
end

local function pa_use_lfg_social_result_cache(entry)
    if type(entry) ~= "table" or entry.enriched == true then
        return false, false
    end

    local name_key = entry.name_key or pa_name_key(entry.name)
    if name_key == "" then
        return false, false
    end

    local cached = pa_get_lfg_social_result_cache()[name_key]
    if type(cached) ~= "table" then
        return false, false
    end
    if cached.status ~= "enriched" then
        return true, false
    end

    entry.detail = tostring(cached.detail or "")
    entry.enriched = true
    entry.enrich_source = "social"
    entry.detail_link_data = nil
    entry.inferred_role = nil
    return true, true
end

local function pa_cache_lfg_social_enriched_result(entry)
    if type(entry) ~= "table" or entry.enrich_source ~= "social" or entry.enriched ~= true then
        return
    end

    local name_key = entry.name_key or pa_name_key(entry.name)
    if name_key == "" then
        return
    end

    pa_get_lfg_social_result_cache()[name_key] = {
        status = "enriched",
        detail = tostring(entry.detail or ""),
    }
end

local function pa_apply_lfg_social_cache_to_candidate(name_key)
    local index = pa_find_lfg_candidate_index(name_key)
    local entry = index and PartyAd.lfg_candidates and PartyAd.lfg_candidates[index] or nil
    if type(entry) ~= "table" or entry.enriched == true then
        return false, false
    end

    local handled_by_result_cache, changed_by_result_cache = pa_use_lfg_social_result_cache(entry)
    if handled_by_result_cache then
        return true, changed_by_result_cache
    end

    local detail = pa_lookup_candidate_social_cache(entry.name)
    if type(detail) ~= "table" then
        return false, false
    end
    if pa_apply_lfg_social_detail_to_entry(entry, detail) then
        pa_cache_lfg_social_enriched_result(entry)
        return true, true
    end
    return false, false
end

local function pa_send_lfg_social_search(entry)
    if not PartyAd.can_use_lfg_social_lookup() then
        return false
    end
    if type(SendPlayerSearchRequest) ~= "function" then
        return false
    end
    if type(entry) ~= "table" or entry.name_key == nil or entry.name == nil then
        return false
    end

    if type(PartyAd.register_lfg_social_search_event) == "function" then
        PartyAd.register_lfg_social_search_event()
    end

    local zones = { -1 }
    local ok = pcall(
        SendPlayerSearchRequest,
        pa_to_wstring(entry.name),
        pa_to_wstring(""),
        pa_to_wstring(""),
        zones,
        1,
        40,
        false
    )
    if not ok then
        return false
    end

    PartyAd.lfg_social_lookup_pending_key = entry.name_key
    PartyAd.lfg_social_lookup_pending_name = entry.name
    PartyAd.lfg_social_lookup_pending_elapsed = 0
    return true
end

local function pa_trim_lfg_candidates()
    local entries = PartyAd.lfg_candidates or {}
    while #entries > PartyAd.LFG_SCAN_MAX_ENTRIES do
        table.remove(entries)
    end
end

local function pa_sort_lfg_candidates_by_party_status()
    local entries = PartyAd.lfg_candidates or {}
    if #entries <= 1 then
        return
    end

    local active = {}
    local in_party = {}
    for i = 1, #entries do
        if entries[i] and entries[i].in_party == true then
            in_party[#in_party + 1] = entries[i]
        elseif entries[i] then
            active[#active + 1] = entries[i]
        end
    end

    PartyAd.lfg_candidates = {}
    for i = 1, #active do
        PartyAd.lfg_candidates[#PartyAd.lfg_candidates + 1] = active[i]
    end
    for i = 1, #in_party do
        PartyAd.lfg_candidates[#PartyAd.lfg_candidates + 1] = in_party[i]
    end
end

local function pa_build_current_party_name_lookup()
    local members = PartyAd.get_party_members()
    if #members == 0 then
        return nil
    end

    local lookup = {}
    for i = 1, #members do
        local name_key = pa_name_key(members[i] and members[i].name)
        if name_key ~= "" then
            lookup[name_key] = true
        end
    end

    local self_key = pa_name_key(GameData and GameData.Player and GameData.Player.name)
    if self_key ~= "" then
        lookup[self_key] = true
    end
    return lookup
end

function PartyAd.clear_lfg_candidates()
    PartyAd.lfg_candidates = {}
    PartyAd.lfg_social_lookup_queue = {}
    PartyAd.lfg_social_lookup_pending_key = nil
    PartyAd.lfg_social_lookup_pending_name = nil
    PartyAd.lfg_social_lookup_pending_elapsed = 0
    PartyAd.lfg_social_lookup_cooldown_remaining = 0
    PartyAd.lfg_social_lookup_attempted = {}
    PartyAd.lfg_social_debug_pending_key = nil
    PartyAd.lfg_social_debug_pending_name = nil
    PartyAd.lfg_social_debug_pending_elapsed = 0
    PartyAd.lfg_social_result_cache = {}
    if type(PartyAd.sync_lfg_social_search_subscription) == "function" then
        PartyAd.sync_lfg_social_search_subscription()
    end
end

function PartyAd.get_lfg_candidates()
    PartyAd.lfg_candidates = PartyAd.lfg_candidates or {}
    return PartyAd.lfg_candidates
end

function PartyAd.get_lfg_candidate_count()
    return #PartyAd.get_lfg_candidates()
end

function PartyAd.get_lfg_candidate_in_party_count()
    local entries = PartyAd.get_lfg_candidates()
    local count = 0
    for i = 1, #entries do
        if entries[i] and entries[i].in_party == true then
            count = count + 1
        end
    end
    return count
end

local function pa_make_lfg_debug_fixture_entry(item)
    if type(item) ~= "table" then
        return nil
    end

    local name = pa_clean_player_name(item.name)
    local name_key = pa_name_key(name)
    if name_key == "" then
        return nil
    end

    local mode = item.mode or "lenient"
    local message = pa_trim(item.message)
    local detail = tostring(item.detail or "")
    local enriched = item.enriched
    if enriched == nil then
        enriched = detail ~= "" and item.enrich_source ~= nil
    end
    local enrich_source = item.enrich_source
    local detail_link_data = item.detail_link_data
    local inferred_role = item.inferred_role
    if enrich_source == "autoband" and PartyAd._lfg_scan_disable_autoband_lookup == true then
        detail, inferred_role = pa_build_lfg_fallback_detail(message)
        enriched = false
        enrich_source = nil
        detail_link_data = nil
    end
    return {
        name = name,
        name_key = name_key,
        message = message,
        scan_mode = mode,
        line = pa_build_lfg_display_line(name, message, mode),
        full_line = pa_build_lfg_display_line(name, message, mode, false),
        detail = detail,
        enriched = enriched == true,
        enrich_source = enrich_source,
        detail_link_data = detail_link_data,
        inferred_role = inferred_role,
        in_party = item.in_party == true,
    }
end

function PartyAd.populate_lfg_scan_debug_fixture()
    if type(PartyAd.set_use_lfg_scan) == "function" then
        PartyAd.set_use_lfg_scan(true)
    elseif PartyAd.saved then
        PartyAd.saved.use_lfg_scan = true
    end
    if PartyAdWindow and type(PartyAdWindow.Show) == "function" then
        PartyAdWindow.Show()
    end
    if type(PartyAd.sync_lfg_scan_subscription) == "function" then
        PartyAd.sync_lfg_scan_subscription()
    end

    PartyAd.clear_lfg_candidates()
    local order_samples = {
        {
            name = "Gervasius",
            message = "anyone else for sewer? i carry",
            detail = "<icon20190> (CR40)",
            enrich_source = "social",
        },
        {
            name = "Jarek",
            message = "sw lfg HV",
            detail = "<icon20194> (CR40 RR71)",
            enrich_source = "autoband",
            detail_link_data = PartyAd.build_killboard_link_data_for_character_id(155801),
        },
        {
            name = "Runemitu",
            message = "heal RP lf Ruin and mentor",
            detail = "<icon20193> (CR40 RR59)",
            enrich_source = "autoband",
            detail_link_data = PartyAd.build_killboard_link_data_for_character_id(155802),
        },
        {
            name = "Regiontank",
            message = "tank lfg HV or SC",
            mode = "strict",
            detail = "<icon20189> (CR40)",
            enrich_source = "social",
        },
        {
            name = "Brights",
            message = "BW looking for group for BS",
            mode = "strict",
            detail = "<icon20183> (CR40)",
            enrich_source = "social",
        },
        {
            name = "Emptyinfo",
            message = "dps lfg sewers",
            mode = "strict",
            detail = "<icon22701> (CR??)",
            inferred_role = PartyAd.ROLE_DPS,
        },
        {
            name = "Longline",
            message = "healer looking for sewers mentor carry with a deliberately long message to preview truncation and the row tooltip",
            detail = "<icon20199> (CR40 RR80)",
            enrich_source = "autoband",
            detail_link_data = PartyAd.build_killboard_link_data_for_character_id(155803),
        },
        {
            name = "Partymate",
            message = "WP lf crypts, already invited",
            detail = "<icon20199> (CR40 RR64)",
            enrich_source = "autoband",
            detail_link_data = PartyAd.build_killboard_link_data_for_character_id(155804),
            in_party = true,
        },
    }
    local destro_samples = {
        {
            name = "Grimtusk",
            message = "anyone else for sacellum? i carry",
            detail = "<icon20182> (CR40)",
            enrich_source = "social",
        },
        {
            name = "Darkshot",
            message = "sh lfg HV",
            detail = "<icon20197> (CR40 RR71)",
            enrich_source = "autoband",
            detail_link_data = PartyAd.build_killboard_link_data_for_character_id(155805),
        },
        {
            name = "Rotchant",
            message = "heal zealot lf Ruin and mentor",
            detail = "<icon20203> (CR40 RR59)",
            enrich_source = "autoband",
            detail_link_data = PartyAd.build_killboard_link_data_for_character_id(155806),
        },
        {
            name = "Regiontank",
            message = "chosen tank lfg HV or SC",
            mode = "strict",
            detail = "<icon20185> (CR40)",
            enrich_source = "social",
        },
        {
            name = "Frosthex",
            message = "sorc looking for group for BS",
            mode = "strict",
            detail = "<icon20196> (CR40)",
            enrich_source = "social",
        },
        {
            name = "Emptyinfo",
            message = "dps lfg Sacellum",
            mode = "strict",
            detail = "<icon22701> (CR??)",
            inferred_role = PartyAd.ROLE_DPS,
        },
        {
            name = "Longline",
            message = "healer looking for sacellum mentor carry with a deliberately long message to preview truncation and the row tooltip",
            detail = "<icon20203> (CR40 RR80)",
            enrich_source = "autoband",
            detail_link_data = PartyAd.build_killboard_link_data_for_character_id(155807),
        },
        {
            name = "Partymate",
            message = "DoK lf BB, already invited",
            detail = "<icon20186> (CR40 RR64)",
            enrich_source = "autoband",
            detail_link_data = PartyAd.build_killboard_link_data_for_character_id(155808),
            in_party = true,
        },
    }
    local samples = order_samples
    if PartyAd.get_player_realm_key() == PartyAd.REALM_DESTRUCTION then
        samples = destro_samples
    end

    PartyAd.lfg_candidates = {}
    for i = 1, #samples do
        local entry = pa_make_lfg_debug_fixture_entry(samples[i])
        if entry ~= nil then
            PartyAd.lfg_candidates[#PartyAd.lfg_candidates + 1] = entry
        end
    end
    pa_trim_lfg_candidates()

    if PartyAdWindow and type(PartyAdWindow.RefreshLfgScanWindowState) == "function" then
        PartyAdWindow.RefreshLfgScanWindowState()
    elseif PartyAdWindow and type(PartyAdWindow.RefreshLfgScan) == "function" then
        PartyAdWindow.RefreshLfgScan()
    end

    PartyAd.print("LFG debug populated /5 Candidates with " .. tostring(#PartyAd.lfg_candidates) .. " sample rows.")
    return #PartyAd.lfg_candidates
end

function PartyAd.has_lfg_social_lookup_work()
    if not PartyAd.can_use_lfg_social_lookup() then
        return false
    end
    return PartyAd.lfg_social_lookup_pending_key ~= nil or PartyAd.lfg_social_debug_pending_key ~= nil
end

function PartyAd.cancel_lfg_social_lookup_queue(skip_sync)
    PartyAd.lfg_social_lookup_queue = {}
    PartyAd.lfg_social_lookup_pending_key = nil
    PartyAd.lfg_social_lookup_pending_name = nil
    PartyAd.lfg_social_lookup_pending_elapsed = 0
    PartyAd.lfg_social_lookup_cooldown_remaining = 0
    PartyAd.lfg_social_lookup_attempted = {}
    if skip_sync ~= true and type(PartyAd.sync_lfg_social_search_subscription) == "function" then
        PartyAd.sync_lfg_social_search_subscription()
    end
end

function PartyAd.cancel_lfg_social_debug_search(skip_sync)
    PartyAd.lfg_social_debug_pending_key = nil
    PartyAd.lfg_social_debug_pending_name = nil
    PartyAd.lfg_social_debug_pending_elapsed = 0
    if skip_sync ~= true and type(PartyAd.sync_lfg_social_search_subscription) == "function" then
        PartyAd.sync_lfg_social_search_subscription()
    end
end

function PartyAd.queue_lfg_social_lookup(name)
    if not PartyAd.can_use_lfg_social_lookup() then
        return false
    end
    if type(SendPlayerSearchRequest) ~= "function" then
        return false
    end

    local clean_name = pa_clean_player_name(name)
    local name_key = pa_name_key(clean_name)
    if name_key == "" then
        return false
    end

    local handled_by_cache, changed_by_cache = pa_apply_lfg_social_cache_to_candidate(name_key)
    if handled_by_cache then
        if changed_by_cache and PartyAdWindow and type(PartyAdWindow.RefreshLfgScan) == "function" then
            PartyAdWindow.RefreshLfgScan()
        end
        return true
    end

    local attempted = pa_get_lfg_social_lookup_attempted()
    if attempted[name_key] == true then
        return false
    end
    if PartyAd.lfg_social_lookup_pending_key == name_key or pa_lfg_social_lookup_is_queued(name_key) then
        return false
    end

    local queue = pa_get_lfg_social_lookup_queue()
    if #queue >= PartyAd.LFG_SOCIAL_SEARCH_MAX_QUEUE then
        return false
    end

    attempted[name_key] = true
    queue[#queue + 1] = {
        name = clean_name,
        name_key = name_key,
    }

    if type(PartyAd.sync_lfg_social_search_subscription) == "function" then
        PartyAd.sync_lfg_social_search_subscription()
    end
    PartyAd.process_lfg_social_lookup_queue(0)
    return true
end

function PartyAd.process_lfg_social_lookup_queue(elapsed_seconds)
    local queue = PartyAd.lfg_social_lookup_queue
    local has_queue = type(queue) == "table" and #queue > 0
    local has_pending =
        PartyAd.lfg_social_lookup_pending_key ~= nil or
        PartyAd.lfg_social_debug_pending_key ~= nil
    local cooldown = tonumber(PartyAd.lfg_social_lookup_cooldown_remaining) or 0
    local has_work_state = has_queue or has_pending or cooldown > 0

    if not PartyAd.can_use_lfg_social_lookup() then
        if has_work_state or PartyAd._lfg_social_search_event_registered == true then
            PartyAd.cancel_lfg_social_lookup_queue(true)
            PartyAd.cancel_lfg_social_debug_search(true)
            if type(PartyAd.sync_lfg_social_search_subscription) == "function" then
                PartyAd.sync_lfg_social_search_subscription()
            end
        end
        return false
    end

    local elapsed = tonumber(elapsed_seconds) or 0
    if elapsed < 0 then
        elapsed = 0
    end

    if not has_work_state then
        if PartyAd._lfg_social_search_event_registered == true and type(PartyAd.sync_lfg_social_search_subscription) == "function" then
            PartyAd.sync_lfg_social_search_subscription()
        end
        return false
    end

    if PartyAd.lfg_social_debug_pending_key ~= nil then
        PartyAd.lfg_social_debug_pending_elapsed = (tonumber(PartyAd.lfg_social_debug_pending_elapsed) or 0) + elapsed
        if PartyAd.lfg_social_debug_pending_elapsed >= PartyAd.LFG_SOCIAL_SEARCH_TIMEOUT_SECONDS then
            PartyAd.print("LFG debug social search timeout name=" .. tostring(PartyAd.lfg_social_debug_pending_name or ""))
            PartyAd.cancel_lfg_social_debug_search()
        end
    end

    if PartyAd.lfg_social_lookup_pending_key ~= nil then
        PartyAd.lfg_social_lookup_pending_elapsed = (tonumber(PartyAd.lfg_social_lookup_pending_elapsed) or 0) + elapsed
        if PartyAd.lfg_social_lookup_pending_elapsed >= PartyAd.LFG_SOCIAL_SEARCH_TIMEOUT_SECONDS then
            PartyAd.lfg_social_lookup_pending_key = nil
            PartyAd.lfg_social_lookup_pending_name = nil
            PartyAd.lfg_social_lookup_pending_elapsed = 0
            PartyAd.lfg_social_lookup_cooldown_remaining = PartyAd.LFG_SOCIAL_SEARCH_COOLDOWN_SECONDS
            if type(PartyAd.sync_lfg_social_search_subscription) == "function" then
                PartyAd.sync_lfg_social_search_subscription()
            end
        end
        return false
    end

    if cooldown > 0 then
        cooldown = cooldown - elapsed
        if cooldown < 0 then
            cooldown = 0
        end
        PartyAd.lfg_social_lookup_cooldown_remaining = cooldown
        if cooldown > 0 then
            return false
        end
    end

    local lookup_queue = pa_get_lfg_social_lookup_queue()
    while #lookup_queue > 0 do
        local item = table.remove(lookup_queue, 1)
        local handled_by_cache = false
        local changed_by_cache = false
        if item and item.name_key then
            handled_by_cache, changed_by_cache = pa_apply_lfg_social_cache_to_candidate(item.name_key)
        end
        if handled_by_cache then
            if changed_by_cache and PartyAdWindow and type(PartyAdWindow.RefreshLfgScan) == "function" then
                PartyAdWindow.RefreshLfgScan()
            end
        elseif item and item.name_key then
            local index = pa_find_lfg_candidate_index(item.name_key)
            local candidate = index and PartyAd.lfg_candidates and PartyAd.lfg_candidates[index] or nil
            if candidate and candidate.enriched ~= true and candidate.in_party ~= true then
                if pa_send_lfg_social_search(item) then
                    if type(PartyAd.sync_lfg_social_search_subscription) == "function" then
                        PartyAd.sync_lfg_social_search_subscription()
                    end
                    return true
                end
            end
        end
    end

    if type(PartyAd.sync_lfg_social_search_subscription) == "function" then
        PartyAd.sync_lfg_social_search_subscription()
    end
    return false
end

function PartyAd.apply_lfg_social_search_results()
    local list = pa_read_lfg_social_search_list()
    if type(list) ~= "table" then
        return 0
    end

    local pending_key = PartyAd.lfg_social_lookup_pending_key or PartyAd.lfg_social_debug_pending_key
    local pending_enriched = false
    local changed = 0
    for i = 1, #list do
        local row = list[i]
        if type(row) == "table" then
            local row_name = pa_lfg_social_row_name(row)
            local name_key = pa_name_key(row_name)
            local index = pa_find_lfg_candidate_index(name_key)
            local entry = index and PartyAd.lfg_candidates and PartyAd.lfg_candidates[index] or nil
            if type(entry) == "table" and entry.enrich_source ~= "autoband" then
                local detail = pa_lfg_social_detail_from_row(row)
                if pa_apply_lfg_social_detail_to_entry(entry, detail) then
                    pa_cache_lfg_social_enriched_result(entry)
                    if pending_key ~= nil and name_key == pending_key then
                        pending_enriched = true
                    end
                    changed = changed + 1
                end
            end
        end
    end

    if pending_key ~= nil and pending_key ~= "" and not pending_enriched then
        pa_get_lfg_social_result_cache()[pending_key] = { status = "empty" }
    end

    return changed
end

local function pa_build_lfg_social_debug_discovered_line(row_name, detail_text)
    local clean_name = pa_clean_player_name(row_name)
    if clean_name == "" or clean_name == "unknown" then
        return "none"
    end

    local candidate_detail = tostring(detail_text or "")
    if candidate_detail == "none" then
        candidate_detail = ""
    end

    if type(PartyAd.build_lfg_discovered_line) == "function" then
        local line = PartyAd.build_lfg_discovered_line({
            name = clean_name,
            detail = candidate_detail,
        })
        if line ~= "" then
            return line
        end
    end

    local prefix = ""
    if candidate_detail ~= "" then
        prefix = candidate_detail .. " "
    end
    return prefix .. pa_format_player_mention(clean_name)
end

local function pa_build_lfg_social_debug_result(row, requested_key)
    if type(row) ~= "table" then
        return "row invalid"
    end

    local row_name = pa_lfg_social_row_name(row)
    local name_key = pa_name_key(row_name)
    local status = "row"
    if requested_key ~= "" and name_key == requested_key then
        status = "match"
    end
    if row_name == "" then
        row_name = "unknown"
    end

    local detail = pa_lfg_social_detail_from_row(row) or {}
    local career_name = pa_detail_string(detail.career_name)
    if career_name == "" then
        career_name = "unknown"
    end

    local career_key = pa_normalize_career_name(career_name)
    if career_key == "" then
        career_key = "none"
    end
    local detail_icon = pa_lookup_candidate_icon_from_detail(detail)
    if detail_icon == "" then
        detail_icon = "none"
    end

    local detail_text = pa_build_candidate_detail_from_lookup(detail)
    if detail_text == "" then
        detail_text = "none"
    end
    local discovered_line = pa_build_lfg_social_debug_discovered_line(row_name, detail_text)

    local guild = pa_detail_string(detail.guild_name)
    if guild == "" then
        guild = "none"
    end

    local zone = pa_detail_string(row.location or row.locationString or row.onlineString or row.Location)
    local zone_id = pa_detail_number(detail.zone_id)
    if zone == "" then
        if zone_id == 0 then
            zone = "offline"
        elseif zone_id ~= nil then
            zone = "zoneID " .. tostring(math.floor(zone_id))
        else
            zone = "unknown"
        end
    end

    return status ..
        " name=" .. row_name ..
        " detail=" .. detail_text ..
        " career=" .. career_name ..
        " career_key=" .. career_key ..
        " icon=" .. detail_icon ..
        " guild=" .. guild ..
        " zone=" .. zone ..
        " discovered=" .. discovered_line
end

function PartyAd.print_lfg_social_search_debug_results(label, requested_name)
    local requested_key = pa_name_key(requested_name)
    local list = pa_read_lfg_social_search_list()
    if type(list) ~= "table" then
        PartyAd.print("LFG debug social " .. tostring(label or "search") .. ": GetSearchList unavailable")
        return 0
    end
    if #list == 0 then
        PartyAd.print("LFG debug social " .. tostring(label or "search") .. ": no rows")
        return 0
    end

    local max_rows = #list
    if max_rows > 8 then
        max_rows = 8
    end

    for i = 1, max_rows do
        PartyAd.print(
            "LFG debug social " ..
            tostring(label or "search") ..
            " result " ..
            tostring(i) ..
            " " ..
            pa_build_lfg_social_debug_result(list[i], requested_key)
        )
    end
    if #list > max_rows then
        PartyAd.print("LFG debug social " .. tostring(label or "search") .. ": +" .. tostring(#list - max_rows) .. " more rows")
    end
    return #list
end

function PartyAd.start_lfg_social_debug_search(name)
    if not pa_should_run_lfg_scan() then
        PartyAd.print("LFG debug social search failed: open PartyAd and enable Scan /5 first")
        return false
    end
    if not pa_player_level_allows_lfg_social_lookup() then
        PartyAd.print("LFG debug social search failed: player level must be at least " .. tostring(PartyAd.LFG_SOCIAL_SEARCH_MIN_PLAYER_LEVEL))
        return false
    end
    if type(SendPlayerSearchRequest) ~= "function" then
        PartyAd.print("LFG debug social search failed: SendPlayerSearchRequest unavailable")
        return false
    end

    local clean_name = pa_clean_player_name(name)
    local name_key = pa_name_key(clean_name)
    if name_key == "" then
        PartyAd.print("Usage: /partyad lfgdebug search <name>")
        return false
    end

    PartyAd.cancel_lfg_social_lookup_queue()
    PartyAd.lfg_social_debug_pending_name = clean_name
    PartyAd.lfg_social_debug_pending_key = name_key
    PartyAd.lfg_social_debug_pending_elapsed = 0

    if type(PartyAd.sync_lfg_social_search_subscription) == "function" then
        PartyAd.sync_lfg_social_search_subscription()
    end

    local ok = pcall(
        SendPlayerSearchRequest,
        pa_to_wstring(clean_name),
        pa_to_wstring(""),
        pa_to_wstring(""),
        { -1 },
        1,
        40,
        false
    )
    if not ok then
        PartyAd.lfg_social_debug_pending_name = nil
        PartyAd.lfg_social_debug_pending_key = nil
        if type(PartyAd.sync_lfg_social_search_subscription) == "function" then
            PartyAd.sync_lfg_social_search_subscription()
        end
        PartyAd.print("LFG debug social search failed name=" .. clean_name)
        return false
    end

    PartyAd.print("LFG debug social search sent name=" .. clean_name)
    return true
end

function PartyAd.handle_lfg_social_debug_search_updated()
    local pending_name = PartyAd.lfg_social_debug_pending_name or ""
    if pending_name == "" then
        return false
    end

    local count = PartyAd.print_lfg_social_search_debug_results("search", pending_name)
    local changed = PartyAd.apply_lfg_social_search_results()
    PartyAd.lfg_social_debug_pending_name = nil
    PartyAd.lfg_social_debug_pending_key = nil

    if changed > 0 and PartyAdWindow and type(PartyAdWindow.RefreshLfgScan) == "function" then
        PartyAdWindow.RefreshLfgScan()
    end
    if type(PartyAd.sync_lfg_social_search_subscription) == "function" then
        PartyAd.sync_lfg_social_search_subscription()
    end
    return count > 0
end

function PartyAd.handle_lfg_social_search_updated()
    if not PartyAd.can_use_lfg_social_lookup() then
        PartyAd.cancel_lfg_social_lookup_queue(true)
        PartyAd.cancel_lfg_social_debug_search(true)
        if type(PartyAd.sync_lfg_social_search_subscription) == "function" then
            PartyAd.sync_lfg_social_search_subscription()
        end
        return false
    end

    if PartyAd.lfg_social_debug_pending_key ~= nil then
        return PartyAd.handle_lfg_social_debug_search_updated()
    end

    local changed = PartyAd.apply_lfg_social_search_results()
    PartyAd.lfg_social_lookup_pending_key = nil
    PartyAd.lfg_social_lookup_pending_name = nil
    PartyAd.lfg_social_lookup_pending_elapsed = 0
    PartyAd.lfg_social_lookup_cooldown_remaining = PartyAd.LFG_SOCIAL_SEARCH_COOLDOWN_SECONDS

    if changed > 0 and PartyAdWindow and type(PartyAdWindow.RefreshLfgScan) == "function" then
        PartyAdWindow.RefreshLfgScan()
    end
    if type(PartyAd.sync_lfg_social_search_subscription) == "function" then
        PartyAd.sync_lfg_social_search_subscription()
    end
    return changed > 0
end

function PartyAd.update_lfg_candidate_party_status()
    if type(PartyAd.lfg_candidates) ~= "table" or #PartyAd.lfg_candidates == 0 then
        return 0
    end

    local party_lookup = pa_build_current_party_name_lookup()
    local changed = 0
    for i = 1, #PartyAd.lfg_candidates do
        local entry = PartyAd.lfg_candidates[i]
        local name_key = entry and (entry.name_key or pa_name_key(entry.name)) or ""
        local in_party = false
        if type(party_lookup) == "table" and name_key ~= "" then
            in_party = party_lookup[name_key] == true
        end
        if entry and entry.in_party ~= in_party then
            entry.in_party = in_party
            changed = changed + 1
        end
    end
    pa_sort_lfg_candidates_by_party_status()
    return changed
end

function PartyAd.build_lfg_candidate_chat_line(entry)
    if type(entry) ~= "table" then
        return ""
    end

    local line = tostring(entry.line or "")
    if line == "" then
        line = pa_build_lfg_display_line(entry.name, entry.message or "", entry.scan_mode or "lenient")
    end
    return line
end

local function pa_format_lfg_detail_with_rank_link(entry, detail)
    if type(entry) ~= "table" or entry.enrich_source ~= "autoband" then
        return detail
    end

    local link_data = tostring(entry.detail_link_data or "")
    if link_data == "" then
        return detail
    end

    local icon, rank_text = string.match(detail, "^(<icon%d+>)%s*(.+)$")
    if icon ~= nil and rank_text ~= nil and rank_text ~= "" then
        return icon .. " " .. pa_format_hyperlink(link_data, PA_KILLBOARD_LINK_COLOR, rank_text)
    end
    return pa_format_hyperlink(link_data, PA_KILLBOARD_LINK_COLOR, detail)
end

function PartyAd.build_lfg_discovered_line(entry)
    if type(entry) ~= "table" then
        return ""
    end

    local detail = tostring(entry.detail or "")
    local prefix = ""
    if detail ~= "" then
        prefix = pa_format_lfg_detail_with_rank_link(entry, detail) .. " "
    end
    return prefix .. pa_format_player_mention(entry.name)
end

function PartyAd.try_extract_lfg_candidate(text, scan_mode)
    local raw = pa_note_to_string(text) or tostring(text or "")
    local visible = pa_strip_link_markup(raw)
    local name_hint = pa_extract_sender_from_visible_text(visible) or pa_extract_linked_player_name(raw)
    local scan_text = visible
    if name_hint and name_hint ~= "" then
        scan_text = pa_extract_message_after_sender(visible, name_hint)
    end
    local mode = scan_mode or "lenient"

    local normalized = pa_normalize_lfg_scan_text(scan_text)

    if pa_lfg_text_has_phrase(normalized, PA_LFG_NEGATIVE_PHRASES) then
        return nil
    end
    if pa_lfg_text_has_pattern(normalized, PA_LFG_NEGATIVE_PATTERNS) then
        return nil
    end
    if pa_lfg_text_has_dungeon_alias_meta_chatter(normalized, scan_text) then
        return nil
    end
    if pa_lfg_text_has_group_progress(scan_text) then
        return nil
    end
    if pa_lfg_text_has_activity_carry_offer(normalized) then
        return nil
    end
    if mode == "strict" and not pa_lfg_text_has_phrase(normalized, PA_LFG_STRICT_PHRASES) then
        return nil
    end

    local tokens = nil
    if mode ~= "strict" then
        local has_lenient_match = pa_lfg_text_has_phrase(normalized, PA_LFG_LENIENT_PHRASES)
        if not has_lenient_match then
            has_lenient_match = pa_lfg_text_has_pattern(normalized, PA_LFG_LENIENT_PATTERNS)
        end
        if not has_lenient_match then
            has_lenient_match = pa_lfg_text_has_faction_career(normalized)
        end
        if not has_lenient_match then
            has_lenient_match = pa_lfg_text_has_dungeon(normalized)
        end
        if not has_lenient_match then
            has_lenient_match = pa_lfg_text_has_purpose_preset_request(normalized)
        end
        if not has_lenient_match then
            tokens = pa_lfg_tokenize(normalized)
            has_lenient_match = pa_lfg_text_has_activity_group_request(tokens)
        end
        if not has_lenient_match then
            return nil
        end
    end

    tokens = tokens or pa_lfg_tokenize(normalized)
    if pa_lfg_text_has_recruiter_role_request(normalized, scan_text, tokens) then
        return nil
    end
    if pa_lfg_text_has_faction_career_request(normalized) then
        return nil
    end

    local name = name_hint
    name = pa_clean_player_name(name)
    if name == "" then
        return nil
    end

    local message = pa_extract_message_after_sender(visible, name)
    message = pa_trim(message)
    if message == "" then
        message = pa_trim(visible)
    end

    return {
        name = name,
        name_key = pa_name_key(name),
        message = message,
        scan_mode = mode,
        line = pa_build_lfg_display_line(name, message, mode),
        full_line = pa_build_lfg_display_line(name, message, mode, false),
    }
end

function PartyAd.record_lfg_candidate(candidate)
    if type(candidate) ~= "table" then
        return false
    end

    local name = pa_clean_player_name(candidate.name)
    local name_key = pa_name_key(name)
    if name_key == "" then
        return false
    end

    PartyAd.lfg_candidates = PartyAd.lfg_candidates or {}
    local detail, enriched, enrich_source, detail_link_data = pa_build_candidate_detail(name)
    local inferred_role = nil
    if enriched ~= true then
        detail, inferred_role = pa_build_lfg_fallback_detail(candidate.message)
    end
    local entry = {
        name = name,
        name_key = name_key,
        message = pa_trim(candidate.message),
        scan_mode = candidate.scan_mode or "lenient",
        line = pa_trim(candidate.line),
        full_line = pa_trim(candidate.full_line),
        detail = detail,
        enriched = enriched == true,
        enrich_source = enrich_source,
        detail_link_data = detail_link_data,
        inferred_role = inferred_role,
    }

    local social_cache_handled = false
    if entry.enriched ~= true then
        social_cache_handled = pa_use_lfg_social_result_cache(entry)
    end

    local existing_index = pa_find_lfg_candidate_index(name_key)
    if existing_index then
        table.remove(PartyAd.lfg_candidates, existing_index)
    end
    table.insert(PartyAd.lfg_candidates, 1, entry)
    PartyAd.update_lfg_candidate_party_status()
    pa_trim_lfg_candidates()
    if entry.enriched ~= true and not social_cache_handled then
        PartyAd.queue_lfg_social_lookup(name)
    end
    return true
end

function PartyAd.handle_lfg_chat_message(filter_type, text, event_filter_type)
    if not pa_should_run_lfg_scan() then
        return false
    end
    local scan_mode = pa_get_lfg_scan_mode(filter_type)
    if not scan_mode then
        return false
    end

    local candidate = PartyAd.try_extract_lfg_candidate(text, scan_mode)
    if PartyAd._lfg_scan_debug_live == true and type(PartyAd.print_lfg_scan_live_debug) == "function" then
        PartyAd.print_lfg_scan_live_debug(filter_type, text, scan_mode, candidate, event_filter_type)
    end
    if not candidate then
        return false
    end
    if not PartyAd.record_lfg_candidate(candidate) then
        return false
    end
    PartyAd.update_lfg_candidate_party_status()
    if PartyAdWindow and type(PartyAdWindow.RefreshLfgScan) == "function" then
        PartyAdWindow.RefreshLfgScan()
    end
    return true
end

function PartyAd.seed_lfg_candidates_from_chat_log()
    if not pa_should_run_lfg_scan() then
        return false
    end
    if not (type(TextLogGetNumEntries) == "function" and type(TextLogGetEntry) == "function") then
        return false
    end

    local ok_count, count = pcall(TextLogGetNumEntries, "Chat")
    if not ok_count or type(count) ~= "number" or count <= 0 then
        return false
    end

    local start_index = count - PartyAd.LFG_SCAN_BACKLOG_MAX_ENTRIES
    if start_index < 0 then
        start_index = 0
    end

    local found = false
    for i = start_index, count - 1 do
        local ok_entry, _, entry_filter, text = pcall(TextLogGetEntry, "Chat", i)
        if ok_entry then
            local scan_mode = pa_get_lfg_scan_mode(entry_filter)
            if scan_mode then
                local candidate = PartyAd.try_extract_lfg_candidate(text, scan_mode)
                if candidate and PartyAd.record_lfg_candidate(candidate) then
                    found = true
                end
            end
        end
    end

    if found then
        PartyAd.update_lfg_candidate_party_status()
    end
    if found and PartyAdWindow and type(PartyAdWindow.RefreshLfgScan) == "function" then
        PartyAdWindow.RefreshLfgScan()
    end
    return found
end

local function pa_lfg_debug_filter_label(filter_type)
    local filters = SystemData and SystemData.ChatLogFilters
    if type(filters) == "table" then
        if filter_type == filters.CHANNEL_5 then
            return "/5"
        end
        if filter_type == filters.CHANNEL_3 then
            return "/3"
        end
    end
    return tostring(filter_type or "nil")
end

local function pa_build_lfg_debug_entry(index, filter_type, text, scan_mode, candidate, event_filter_type)
    local raw = pa_note_to_string(text) or tostring(text or "")
    local visible = pa_strip_link_markup(raw)
    local event_filter_label = nil
    if event_filter_type ~= nil then
        event_filter_label = pa_lfg_debug_filter_label(event_filter_type)
    end
    return {
        index = index,
        filter_label = pa_lfg_debug_filter_label(filter_type),
        event_filter_label = event_filter_label,
        filter_type = filter_type,
        mode = scan_mode,
        raw = pa_truncate(raw, 180),
        visible = pa_truncate(visible, 180),
        accepted = candidate ~= nil,
        name = candidate and candidate.name or "",
        message = candidate and candidate.message or "",
    }
end

local function pa_add_lfg_debug_entry(entries, index, filter_type, text)
    local scan_mode = pa_get_lfg_scan_mode(filter_type)
    if not scan_mode then
        return false
    end

    local candidate = PartyAd.try_extract_lfg_candidate(text, scan_mode)
    entries[#entries + 1] = pa_build_lfg_debug_entry(index, filter_type, text, scan_mode, candidate)
    return true
end

local function pa_print_lfg_debug_entry(entry, ordinal, label)
    local status = "miss"
    if entry.accepted then
        status = "match name=" .. tostring(entry.name or "")
    end
    PartyAd.print(
        tostring(label or "LFG debug") ..
        " " .. tostring(ordinal or "") ..
        " " .. tostring(entry.filter_label) ..
        (entry.event_filter_label and " event=" .. tostring(entry.event_filter_label) or "") ..
        " mode=" .. tostring(entry.mode) ..
        " " .. status ..
        " raw=" .. tostring(entry.raw or "")
    )
    if entry.accepted and entry.message ~= "" then
        PartyAd.print("LFG parsed: " .. tostring(entry.name or "") .. " -> " .. tostring(entry.message or ""))
    end
end

function PartyAd.get_lfg_scan_debug_entries(limit)
    local max_entries = tonumber(limit) or 3
    if max_entries < 1 then
        max_entries = 1
    elseif max_entries > 8 then
        max_entries = 8
    end

    local entries = {}
    if not (type(TextLogGetNumEntries) == "function" and type(TextLogGetEntry) == "function") then
        return entries
    end

    local ok_count, count = pcall(TextLogGetNumEntries, "Chat")
    if not ok_count or type(count) ~= "number" or count <= 0 then
        return entries
    end

    local min_index = count - PartyAd.LFG_SCAN_BACKLOG_MAX_ENTRIES
    if min_index < 0 then
        min_index = 0
    end

    for i = count - 1, min_index, -1 do
        local ok_entry, _, entry_filter, text = pcall(TextLogGetEntry, "Chat", i)
        if ok_entry and pa_add_lfg_debug_entry(entries, i, entry_filter, text) and #entries >= max_entries then
            return entries
        end
    end

    return entries
end

function PartyAd.print_lfg_scan_debug(limit)
    local entries = PartyAd.get_lfg_scan_debug_entries(limit)
    if #entries == 0 then
        PartyAd.print("LFG debug: no recent /5 or /3 Chat log entries visible.")
        return
    end

    for i = 1, #entries do
        pa_print_lfg_debug_entry(entries[i], i, "LFG debug")
    end
end

function PartyAd.print_lfg_scan_live_debug(filter_type, text, scan_mode, candidate, event_filter_type)
    local entry = pa_build_lfg_debug_entry("live", filter_type, text, scan_mode or pa_get_lfg_scan_mode(filter_type), candidate, event_filter_type)
    pa_print_lfg_debug_entry(entry, "live", "LFG debug")
end

function PartyAd.print_lfg_scan_debug_status()
    if type(PartyAd.sync_lfg_scan_subscription) == "function" then
        PartyAd.sync_lfg_scan_subscription()
    end

    local queue_count = 0
    if type(PartyAd.lfg_social_lookup_queue) == "table" then
        queue_count = #PartyAd.lfg_social_lookup_queue
    end
    local pending_name = tostring(PartyAd.lfg_social_lookup_pending_name or "none")
    local debug_pending_name = tostring(PartyAd.lfg_social_debug_pending_name or "none")
    local candidate_count = 0
    if type(PartyAd.get_lfg_candidate_count) == "function" then
        candidate_count = PartyAd.get_lfg_candidate_count()
    end
    local in_party_count = 0
    if type(PartyAd.get_lfg_candidate_in_party_count) == "function" then
        in_party_count = PartyAd.get_lfg_candidate_in_party_count()
    end

    PartyAd.print(
        "LFG debug status: scan=" .. tostring(PartyAd.saved and PartyAd.saved.use_lfg_scan == true) ..
        " ui_open=" .. tostring(pa_should_run_lfg_scan()) ..
        " chat_sub=" .. tostring(PartyAd._lfg_scan_event_registered == true) ..
        " live_debug=" .. tostring(PartyAd._lfg_scan_debug_live == true) ..
        " autoband_lookup=" .. tostring(PartyAd._lfg_scan_disable_autoband_lookup ~= true) ..
        " social_level_ok=" .. tostring(pa_player_level_allows_lfg_social_lookup())
    )
    PartyAd.print(
        "LFG debug status: candidates=" .. tostring(candidate_count) ..
        " in_party=" .. tostring(in_party_count) ..
        " social_pending=" .. pending_name ..
        " social_debug_pending=" .. debug_pending_name ..
        " social_queue=" .. tostring(queue_count) ..
        " social_sub=" .. tostring(PartyAd._lfg_social_search_event_registered == true)
    )
end

function PartyAd.set_lfg_scan_autoband_lookup_disabled(disabled)
    PartyAd._lfg_scan_disable_autoband_lookup = disabled == true
    PartyAd.print("LFG AutoBand lookup: " .. tostring(PartyAd._lfg_scan_disable_autoband_lookup ~= true))
end

function PartyAd.set_lfg_scan_debug_enabled(enabled, cache_limit)
    PartyAd._lfg_scan_debug_live = enabled == true
    if PartyAd._lfg_scan_debug_live then
        if type(PartyAd.sync_lfg_scan_subscription) == "function" then
            PartyAd.sync_lfg_scan_subscription()
        end
        if type(PartyAd.seed_lfg_candidates_from_chat_log) == "function" then
            PartyAd.seed_lfg_candidates_from_chat_log()
        end
        PartyAd.print("LFG debug live: on")
        PartyAd.print_lfg_scan_debug_status()
        PartyAd.print_lfg_scan_debug(cache_limit or 3)
    else
        PartyAd.print("LFG debug live: off")
    end
end

function PartyAd.toggle_lfg_scan_debug(cache_limit)
    PartyAd.set_lfg_scan_debug_enabled(PartyAd._lfg_scan_debug_live ~= true, cache_limit)
end

local function pa_read_partynote_from_table(data, source_prefix)
    if type(data) ~= "table" then
        return nil, nil
    end

    local prefix = source_prefix or "table"
    for i = 1, #PA_PARTYNOTE_FIELD_KEYS do
        local field = PA_PARTYNOTE_FIELD_KEYS[i]
        local normalized = pa_normalize_note_text(data[field])
        if normalized ~= nil then
            return normalized, prefix .. "." .. field
        end
    end

    return nil, nil
end

local function pa_read_partynote_with_settings(data, source_prefix)
    local note, source = pa_read_partynote_from_table(data, source_prefix)
    if note ~= nil then
        return note, source
    end
    if type(data) ~= "table" then
        return nil, nil
    end

    local prefix = tostring(source_prefix or "table")
    return pa_read_partynote_from_table(data.Settings, prefix .. ".Settings")
end

local function pa_build_name_key_lookup(keys)
    local lookup = {}
    if type(keys) ~= "table" then
        return lookup
    end

    for i = 1, #keys do
        local key = keys[i]
        if type(key) == "string" and key ~= "" then
            lookup[key] = true
        end
    end
    return lookup
end

local function pa_collect_group_leader_name_keys()
    local keys = {}
    local seen = {}

    local function add_name(raw_name)
        local key = pa_name_key(raw_name)
        if key == "" or seen[key] then
            return
        end
        seen[key] = true
        keys[#keys + 1] = key
    end

    add_name(GameData and GameData.Player and GameData.Player.name)

    if PartyUtils and type(PartyUtils.GetPartyData) == "function" then
        local ok_party, party_members = pcall(PartyUtils.GetPartyData)
        if ok_party and type(party_members) == "table" then
            for i = 1, #party_members do
                local member = party_members[i]
                if type(member) == "table" and member.isGroupLeader == true then
                    add_name(member.name)
                end
            end
        end
    end

    if type(GetBattlegroupMemberData) == "function" then
        local ok_wb, wb_data = pcall(GetBattlegroupMemberData)
        if ok_wb and type(wb_data) == "table" then
            for i = 1, #wb_data do
                local party = wb_data[i]
                if type(party) == "table" and type(party.players) == "table" then
                    for j = 1, #party.players do
                        local member = party.players[j]
                        if type(member) == "table" and member.isGroupLeader == true then
                            add_name(member.name)
                            break
                        end
                    end
                end
            end
        end
    end

    return keys
end

local function pa_get_live_partynote_from_openparty_list(fetch_fn, list_name, leader_keys)
    if type(fetch_fn) ~= "function" then
        return nil, nil
    end
    if type(leader_keys) ~= "table" or #leader_keys == 0 then
        return nil, nil
    end
    local leader_lookup = pa_build_name_key_lookup(leader_keys)

    local ok, list = pcall(fetch_fn)
    if not ok or type(list) ~= "table" then
        return nil, nil
    end

    for i = 1, #list do
        local entry = list[i]
        if type(entry) == "table" then
            local entry_name_key = pa_name_key(entry.leaderName or entry.name)
            if entry_name_key ~= "" and leader_lookup[entry_name_key] then
                local prefix = tostring(list_name or "OpenPartyList") .. "[" .. tostring(i) .. "]"
                local note, source = pa_read_partynote_with_settings(entry, prefix)
                if note ~= nil then
                    return note, source
                end
            end
        end
    end

    return nil, nil
end

local function pa_get_live_partynote_from_player()
    local player = GameData and GameData.Player
    if type(player) ~= "table" then
        return nil, nil
    end

    local note, source = pa_read_partynote_from_table(player, "GameData.Player")
    if note ~= nil then
        return note, source
    end

    local group = player.Group
    if type(group) ~= "table" then
        return nil, nil
    end

    note, source = pa_read_partynote_from_table(group, "GameData.Player.Group")
    if note ~= nil then
        return note, source
    end

    return pa_read_partynote_from_table(group.Settings, "GameData.Player.Group.Settings")
end

local function pa_get_live_partynote_from_members()
    if not (PartyUtils and type(PartyUtils.GetPartyData) == "function") then
        return nil, nil
    end

    local ok, members = pcall(PartyUtils.GetPartyData)
    if not ok or type(members) ~= "table" then
        return nil, nil
    end

    local player_name_key = pa_name_key(GameData and GameData.Player and GameData.Player.name)
    local fallback = nil
    local fallback_source = nil

    for i = 1, #members do
        local member = members[i]
        if type(member) == "table" then
            local source_prefix = "PartyUtils.GetPartyData()[" .. tostring(i) .. "]"
            local note, source = pa_read_partynote_with_settings(member, source_prefix)

            if note ~= nil then
                if member.isGroupLeader == true then
                    return note, source
                end
                if player_name_key ~= "" and pa_name_key(member.name) == player_name_key then
                    return note, source
                end
                if fallback == nil then
                    fallback = note
                    fallback_source = source
                end
            end
        end
    end

    return fallback, fallback_source
end

local function pa_get_live_partynote_from_openparty()
    local leader_keys = pa_collect_group_leader_name_keys()
    local note, source = pa_get_live_partynote_from_openparty_list(GetOpenPartyFullList, "GetOpenPartyFullList", leader_keys)
    if note ~= nil then
        return note, source
    end
    return pa_get_live_partynote_from_openparty_list(GetOpenPartyWorldList, "GetOpenPartyWorldList", leader_keys)
end

-- Returns nil when the runtime does not expose a live party-note field.
function PartyAd.get_live_partynote()
    local note, source = pa_get_live_partynote_from_player()
    if note ~= nil then
        return note, source
    end

    note, source = pa_get_live_partynote_from_members()
    if note ~= nil then
        return note, source
    end

    return pa_get_live_partynote_from_openparty()
end

function PartyAd.get_last_applied_partynote()
    if type(PartyAd._last_applied_partynote) ~= "string" then
        return nil
    end
    local note = pa_trim(PartyAd._last_applied_partynote)
    if note == "" then
        return nil
    end
    return note
end

local function pa_get_party_is_public_state()
    if not (GameData and GameData.Player and GameData.Player.Group and GameData.Player.Group.Settings) then
        return nil
    end
    local is_public = GameData.Player.Group.Settings.isPublic
    if type(is_public) == "boolean" then
        return is_public
    end
    return nil
end

-- Chooses the best available baseline for mismatch hinting.
function PartyAd.get_partynote_hint_candidate()
    local is_public = pa_get_party_is_public_state()
    if is_public == false then
        return nil, "GameData.Player.Group.Settings.isPublic=false", "none_closed"
    end

    local live_note, live_source = PartyAd.get_live_partynote()
    if live_note ~= nil then
        return pa_trim(live_note), tostring(live_source or "(unknown)"), "live"
    end

    local last_applied = PartyAd.get_last_applied_partynote()
    if last_applied ~= nil then
        return last_applied, "PartyAd._last_applied_partynote", "fallback_last_sent"
    end

    return nil, "(not found)", "none"
end

function PartyAd.is_party_leader()
    return GameData and GameData.Player and GameData.Player.isGroupLeader == true
end

function PartyAd.is_party_active()
    if PartyUtils and type(PartyUtils.IsPartyActive) == "function" then
        local ok, active = pcall(PartyUtils.IsPartyActive)
        if ok and active == true then
            return true
        end
    end
    local members = PartyAd.get_party_members()
    return #members > 0
end

function PartyAd.send_chat_command(command)
    if type(SendChatText) ~= "function" then
        PartyAd.print("[Error] SendChatText is unavailable.")
        return false
    end
    SendChatText(pa_to_wstring(command), L"")
    return true
end

local function pa_request_openparty_refresh()
    -- Mirror the default Open Party "Refresh" action when available.
    if EA_Window_OpenPartyNearby and type(EA_Window_OpenPartyNearby.RequestUpdateFullList) == "function" then
        pcall(EA_Window_OpenPartyNearby.RequestUpdateFullList)
        return
    end

    local request_all = GameData and GameData.OpenPartyRequestType and GameData.OpenPartyRequestType.ALL
    if request_all ~= nil and type(SendOpenPartySearchRequest) == "function" then
        pcall(SendOpenPartySearchRequest, request_all)
    end
end

function PartyAd.request_openparty_refresh()
    pa_request_openparty_refresh()
end

-- Output text builders and outgoing commands.
function PartyAd.build_partynote_text(missing)
    local purpose = PartyAd.get_purpose()
    local base = "Party"
    if purpose ~= "" then
        base = purpose
    end

    local suffix
    if missing.total == 0 then
        suffix = " - Full!"
    else
        suffix = " - Need: " .. PartyAd.format_need_text(missing)
    end

    local text = pa_build_partynote_with_suffix(base, suffix)
    return pa_append_partynote_progress_if_room(text, pa_format_filled_wanted(missing))
end

function PartyAd.apply_partynote()
    if not PartyAd.is_party_active() then
        PartyAd.print("[Error] You need an active party.")
        return
    end
    if not PartyAd.is_party_leader() then
        PartyAd.print("[Error] You need to be party leader.")
        return
    end

    local missing = PartyAd.get_missing_counts()

    local note_text = PartyAd.build_partynote_text(missing)
    local sent = PartyAd.send_chat_command("/partynote " .. note_text)
    if sent then
        PartyAd._last_applied_partynote = note_text
        pa_request_openparty_refresh()
    end
    PartyAd.print("Updated /partynote.")
end

function PartyAd.clear_partynote(is_manual)
    if not PartyAd.is_party_active() then
        PartyAd.print("[Error] You need an active party.")
        return
    end
    if not PartyAd.is_party_leader() then
        PartyAd.print("[Error] You need to be party leader.")
        return
    end

    local sent = PartyAd.send_chat_command("/partynote")
    if sent then
        PartyAd._last_applied_partynote = nil
    end
    if is_manual then
        PartyAd.print("Cleared /partynote.")
    end
end

function PartyAd.build_advertise_text()
    local missing = PartyAd.get_missing_counts()
    local purpose = PartyAd.get_purpose()

    local base = "Party"
    if purpose ~= "" then
        base = purpose .. " party"
    end

    local leader_name = GameData and GameData.Player and GameData.Player.name or nil
    local leader = pa_format_leader_mention(leader_name)

    local message
    local progress = pa_format_filled_wanted(missing)
    if missing.total == 0 then
        message = base .. " full for now!"
        if progress ~= "" then
            message = message .. " " .. progress
        end
    else
        message = base .. " needs " .. PartyAd.format_need_text(missing)
        if progress ~= "" then
            message = message .. " " .. progress
        end
        message = message .. "; msg " .. leader
    end

    return pa_truncate(message, 220)
end

function PartyAd.advertise_lfg()
    local text = PartyAd.build_advertise_text()
    PartyAd.send_chat_command("/5 " .. text)
    PartyAd.print("Advertised in /5.")
end
