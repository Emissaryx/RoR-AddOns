PartyAd = PartyAd or {}

-- Core constants shared across runtime logic and UI.
PartyAd.VERSION = "0.1.0"
PartyAd.ROLE_TANK = "tank"
PartyAd.ROLE_HEALER = "healer"
PartyAd.ROLE_DPS = "dps"
PartyAd.SELF_ROLE_AUTO = "auto"
PartyAd.PARTY_SIZE = 6
PartyAd.PARTYNOTE_MAX_LEN = 69
PartyAd.PURPOSE_CUSTOM_KEY = "custom"
PartyAd.REALM_ORDER = "order"
PartyAd.REALM_DESTRUCTION = "destruction"
PartyAd.REALM_BOTH = "both"
PartyAd.PURPOSE_PRESETS = {
    { key = "rvr_roam", label = "RvR Roam", text = "RvR Roam", realm = PartyAd.REALM_BOTH },
    { key = "sc_group", label = "Scenario", text = "Scenario", realm = PartyAd.REALM_BOTH },
    { key = "q_beastlord", label = "Beastlord", text = "Beastlord", realm = PartyAd.REALM_BOTH },
    { key = "pq_mayhem", label = "Mayhem Farm", text = "Mayhem Farm", realm = PartyAd.REALM_BOTH },
    { key = "pq_ruin", label = "Ruin Farm", text = "Ruin Farm", realm = PartyAd.REALM_BOTH },
    { key = "pq_farm", label = "PQ Farm", text = "PQ Farm", realm = PartyAd.REALM_BOTH },
    -- Active dungeons from the RoR wiki list (excluding ToVL/Warpblade/Bloodwrought).
    { key = "dng_dragonback_pass", label = "Dragonback Pass (DBP)", text = "Dragonback Pass", realm = PartyAd.REALM_BOTH },
    { key = "dng_sacellum", label = "Sacellum (SD)", text = "Sacellum", realm = PartyAd.REALM_DESTRUCTION },
    { key = "dng_altdorf_sewers", label = "Altdorf Sewers", text = "Altdorf Sewers", realm = PartyAd.REALM_ORDER },
    { key = "dng_gunbad", label = "Gunbad (GB)", text = "Gunbad", realm = PartyAd.REALM_BOTH },
    { key = "dng_sigmar_crypts", label = "Sigmar Crypts", text = "Sigmar Crypts", realm = PartyAd.REALM_ORDER },
    { key = "dng_bilerot_burrows", label = "Bilerot Burrows (BB)", text = "Bilerot Burrows", realm = PartyAd.REALM_DESTRUCTION },
    { key = "dng_bastion_stair", label = "Bastion Stair (BS)", text = "Bastion Stair", realm = PartyAd.REALM_BOTH },
    { key = "dng_hunters_vale", label = "Hunter's Vale (HV)", text = "Hunter's Vale", realm = PartyAd.REALM_BOTH },
    { key = "dng_lost_vale", label = "Lost Vale (LV)", text = "Lost Vale", realm = PartyAd.REALM_BOTH },
}

-- Prefix color used for chat prints: [PartyAd]
local PA_PREFIX_COLOR_R = 238
local PA_PREFIX_COLOR_G = 176
local PA_PREFIX_COLOR_B = 63

-- Basic conversion and string-normalization helpers.
local function pa_to_wstring(value)
    local text = tostring(value or "")
    if type(towstring) == "function" then
        local ok, wide = pcall(towstring, text)
        if ok then
            return wide
        end
    end
    return text
end

local function pa_trim(text)
    local s = tostring(text or "")
    s = string.gsub(s, "%s+", " ")
    s = string.gsub(s, "^%s*(.-)%s*$", "%1")
    return s
end

local function pa_fix_name(raw)
    local s = tostring(raw or "")
    local pos = string.find(s, "^", 1, true)
    if pos then
        s = string.sub(s, 1, pos - 1)
    end
    return s
end

local function pa_name_key(raw)
    local s = pa_fix_name(raw)
    s = pa_trim(s)
    s = string.lower(s)
    return s
end

local function pa_to_number(value)
    if type(value) == "number" then
        return value
    end
    if value == nil then
        return nil
    end
    local n = tonumber(value)
    if type(n) == "number" then
        return n
    end
    return nil
end

local function pa_clamp_int(value, min_value, max_value)
    local n = tonumber(value) or 0
    n = math.floor(n)
    if n < min_value then
        return min_value
    end
    if n > max_value then
        return max_value
    end
    return n
end

local function pa_reduce_target_overflow(t, h, d, party_size)
    local overflow = (t + h + d) - party_size
    if overflow <= 0 then
        return t, h, d
    end

    local reduction = math.min(d, overflow)
    d = d - reduction
    overflow = overflow - reduction

    reduction = math.min(h, overflow)
    h = h - reduction
    overflow = overflow - reduction

    if overflow > 0 then
        t = math.max(0, t - overflow)
    end

    return t, h, d
end

-- Party member extraction helpers.
local function pa_get_member_career_line(member)
    if type(member) ~= "table" then
        return nil
    end

    local career_line = member.careerLine
    if type(career_line) == "table" then
        career_line = career_line.line
    end

    if career_line == nil then
        local career = member.career
        if type(career) == "table" then
            career_line = career.line
        else
            career_line = career
        end
    end

    if career_line == nil then
        career_line = member.careerLineId
    end

    return pa_to_number(career_line)
end

local function pa_build_local_player_member()
    if not (GameData and GameData.Player and GameData.Player.name) then
        return nil
    end

    local player = GameData.Player
    local member = {
        name = player.name,
        careerLine = nil,
    }

    local career_line = nil
    if type(player.career) == "table" then
        career_line = player.career.line
    else
        career_line = player.career
    end
    if career_line == nil then
        career_line = player.careerLine
    end

    member.careerLine = pa_to_number(career_line)
    return member
end

-- Role-label and text formatting helpers.
local function pa_apply_alt_spec_transform(career_line)
    local cl = GameData and GameData.CareerLine
    if type(cl) ~= "table" then
        return career_line
    end

    if career_line == cl.ZEALOT or
       career_line == cl.SHAMAN then
        return cl.MAGUS
    end

    if career_line == cl.WARRIOR_PRIEST or
       career_line == cl.SHADOW_WARRIOR then
        return cl.SLAYER
    end

    if career_line == cl.RUNE_PRIEST or
       career_line == cl.ARCHMAGE then
        return cl.ENGINEER
    end

    if career_line == cl.DISCIPLE or
       career_line == cl.SQUIG_HERDER then
        return cl.CHOPPA
    end

    return career_line
end

local function pa_pluralize(role, count)
    if role == PartyAd.ROLE_DPS then
        return "dps"
    end
    if count == 1 then
        return role
    end
    return role .. "s"
end

local function pa_normalize_role_key(role)
    if type(role) ~= "string" then
        return nil
    end

    local lower = string.lower(role)
    if lower == PartyAd.ROLE_TANK then
        return PartyAd.ROLE_TANK
    end
    if lower == PartyAd.ROLE_HEALER or lower == "heal" then
        return PartyAd.ROLE_HEALER
    end
    if lower == PartyAd.ROLE_DPS or lower == "mdps" or lower == "rdps" then
        return PartyAd.ROLE_DPS
    end

    return nil
end

local function pa_role_display_name(role)
    if role == PartyAd.ROLE_TANK then
        return "Tank"
    end
    if role == PartyAd.ROLE_HEALER then
        return "Healer"
    end
    if role == PartyAd.ROLE_DPS then
        return "DPS"
    end
    return nil
end

local function pa_join(parts, sep)
    if #parts == 0 then
        return ""
    end
    local out = parts[1]
    local i
    for i = 2, #parts do
        out = out .. sep .. parts[i]
    end
    return out
end

local function pa_truncate(text, max_len)
    local s = tostring(text or "")
    if #s <= max_len then
        return s
    end
    if max_len <= 3 then
        return string.sub(s, 1, max_len)
    end
    return string.sub(s, 1, max_len - 3) .. "..."
end

local function pa_build_partynote_with_suffix(base, suffix)
    local prefix = "[PA] "
    local safe_base = pa_trim(base)
    local safe_suffix = tostring(suffix or "")
    if safe_base == "" then
        safe_base = "Party"
    end

    local text = prefix .. safe_base .. safe_suffix
    if #text <= PartyAd.PARTYNOTE_MAX_LEN then
        return text
    end

    local available_base_len = PartyAd.PARTYNOTE_MAX_LEN - #prefix - #safe_suffix
    if available_base_len <= 0 then
        return pa_truncate(prefix .. safe_suffix, PartyAd.PARTYNOTE_MAX_LEN)
    end

    return prefix .. pa_truncate(safe_base, available_base_len) .. safe_suffix
end

-- Chat-friendly leader mention formatting.
local function pa_format_leader_mention(raw_name)
    local name = pa_fix_name(raw_name)
    name = pa_trim(name)
    if name == "" then
        return "leader"
    end

    local display = "@" .. name
    return string.format(
        "<LINK data=\"PLAYER:%s\" color=\"255,0,0\" text=\"%s\">",
        name,
        display
    )
end

local function pa_build_colored_prefix()
    local colored = string.format(
        "<LINK data=\"0\" color=\"%d,%d,%d\" text=\"PartyAd\">",
        PA_PREFIX_COLOR_R,
        PA_PREFIX_COLOR_G,
        PA_PREFIX_COLOR_B
    )
    return "[" .. colored .. "]"
end

-- Public logging plus saved-variable initialization and target configuration.
function PartyAd.print(msg)
    local text = pa_build_colored_prefix() .. " " .. tostring(msg or "")
    if EA_ChatWindow and type(EA_ChatWindow.Print) == "function" then
        EA_ChatWindow.Print(pa_to_wstring(text))
    end
end

function PartyAd.ensure_saved_defaults()
    PartyAd.saved = PartyAd.saved or {}

    if type(PartyAd.saved.desired_tanks) ~= "number" then PartyAd.saved.desired_tanks = 1 end
    if type(PartyAd.saved.desired_healers) ~= "number" then PartyAd.saved.desired_healers = 2 end
    if type(PartyAd.saved.desired_dps) ~= "number" then PartyAd.saved.desired_dps = 3 end
    if type(PartyAd.saved.purpose) ~= "string" then PartyAd.saved.purpose = "" end
    if type(PartyAd.saved.purpose_custom) ~= "string" then
        PartyAd.saved.purpose_custom = PartyAd.saved.purpose
    end
    if type(PartyAd.saved.purpose_mode) ~= "string" then
        PartyAd.saved.purpose_mode = PartyAd.PURPOSE_CUSTOM_KEY
    end
    if PartyAd.saved.use_scoreboard_spec_check == nil then
        PartyAd.saved.use_scoreboard_spec_check = true
    end
    if PartyAd.saved.use_detected_roles_for_needs == nil then
        PartyAd.saved.use_detected_roles_for_needs = true
    else
        PartyAd.saved.use_detected_roles_for_needs = (PartyAd.saved.use_detected_roles_for_needs == true)
    end
    if type(PartyAd.saved.self_role_override) ~= "string" then
        PartyAd.saved.self_role_override = PartyAd.SELF_ROLE_AUTO
    end
    PartyAd.saved.self_role_override = string.lower(PartyAd.saved.self_role_override)
    if PartyAd.saved.self_role_override ~= PartyAd.SELF_ROLE_AUTO and
       PartyAd.saved.self_role_override ~= PartyAd.ROLE_TANK and
       PartyAd.saved.self_role_override ~= PartyAd.ROLE_HEALER and
       PartyAd.saved.self_role_override ~= PartyAd.ROLE_DPS then
        PartyAd.saved.self_role_override = PartyAd.SELF_ROLE_AUTO
    end

    PartyAd.saved.purpose_custom = pa_trim(PartyAd.saved.purpose_custom)
    PartyAd.saved.purpose_mode = PartyAd.get_purpose_mode()
    PartyAd.saved.purpose = PartyAd.get_purpose()
    PartyAd.normalize_targets()
end

function PartyAd.normalize_targets()
    local party_size = PartyAd.PARTY_SIZE
    local t = pa_clamp_int(PartyAd.saved.desired_tanks, 0, party_size)
    local h = pa_clamp_int(PartyAd.saved.desired_healers, 0, party_size)
    local d = pa_clamp_int(PartyAd.saved.desired_dps, 0, party_size)

    t, h, d = pa_reduce_target_overflow(t, h, d, party_size)

    PartyAd.saved.desired_tanks = t
    PartyAd.saved.desired_healers = h
    PartyAd.saved.desired_dps = d
end

function PartyAd.set_target(role_key, value)
    local n = tonumber(value)
    if not n then
        return false
    end
    n = math.floor(n)
    if n < 0 then n = 0 end

    local t = PartyAd.saved.desired_tanks or 0
    local h = PartyAd.saved.desired_healers or 0
    local d = PartyAd.saved.desired_dps or 0

    local other_sum = 0
    if role_key == PartyAd.ROLE_TANK then
        other_sum = h + d
    elseif role_key == PartyAd.ROLE_HEALER then
        other_sum = t + d
    else
        other_sum = t + h
    end

    local max_allowed = PartyAd.PARTY_SIZE - other_sum
    if max_allowed < 0 then
        max_allowed = 0
    end
    if n > max_allowed then
        n = max_allowed
    end

    if role_key == PartyAd.ROLE_TANK then
        PartyAd.saved.desired_tanks = n
    elseif role_key == PartyAd.ROLE_HEALER then
        PartyAd.saved.desired_healers = n
    else
        PartyAd.saved.desired_dps = n
    end

    return true
end

function PartyAd.adjust_target(role_key, delta)
    local current
    if role_key == PartyAd.ROLE_TANK then
        current = PartyAd.saved.desired_tanks
    elseif role_key == PartyAd.ROLE_HEALER then
        current = PartyAd.saved.desired_healers
    else
        current = PartyAd.saved.desired_dps
    end
    return PartyAd.set_target(role_key, (current or 0) + (delta or 0))
end

-- Role resolution and party-member collection.
function PartyAd.get_role_from_career_line(career_line)
    local cl = GameData and GameData.CareerLine
    if type(cl) ~= "table" or type(career_line) ~= "number" then
        return nil
    end

    if career_line == cl.IRON_BREAKER or
       career_line == cl.CHOSEN or
       career_line == cl.BLACK_ORC or
       career_line == cl.KNIGHT or
       career_line == cl.SWORDMASTER or
       career_line == cl.BLACKGUARD then
        return PartyAd.ROLE_TANK
    end

    if career_line == cl.ZEALOT or
       career_line == cl.WARRIOR_PRIEST or
       career_line == cl.RUNE_PRIEST or
       career_line == cl.ARCHMAGE or
       career_line == cl.SHAMAN or
       career_line == cl.DISCIPLE then
        return PartyAd.ROLE_HEALER
    end

    if career_line == cl.ENGINEER or
       career_line == cl.BRIGHT_WIZARD or
       career_line == cl.SORCERER or
       career_line == cl.SQUIG_HERDER or
       career_line == cl.MAGUS or
       career_line == cl.SHADOW_WARRIOR or
       career_line == cl.WITCH_ELF or
       career_line == cl.WHITE_LION or
       career_line == cl.SLAYER or
       career_line == cl.WITCH_HUNTER or
       career_line == cl.CHOPPA or
       career_line == cl.MARAUDER then
        return PartyAd.ROLE_DPS
    end

    return nil
end

local function pa_get_realm_from_career_line(career_line)
    local cl = GameData and GameData.CareerLine
    if type(cl) ~= "table" or type(career_line) ~= "number" then
        return nil
    end

    if career_line == cl.IRON_BREAKER or
       career_line == cl.KNIGHT or
       career_line == cl.SWORDMASTER or
       career_line == cl.RUNE_PRIEST or
       career_line == cl.WARRIOR_PRIEST or
       career_line == cl.ARCHMAGE or
       career_line == cl.BRIGHT_WIZARD or
       career_line == cl.ENGINEER or
       career_line == cl.SHADOW_WARRIOR or
       career_line == cl.WHITE_LION or
       career_line == cl.SLAYER or
       career_line == cl.WITCH_HUNTER then
        return PartyAd.REALM_ORDER
    end

    if career_line == cl.CHOSEN or
       career_line == cl.BLACK_ORC or
       career_line == cl.BLACKGUARD or
       career_line == cl.ZEALOT or
       career_line == cl.SHAMAN or
       career_line == cl.DISCIPLE or
       career_line == cl.SORCERER or
       career_line == cl.MAGUS or
       career_line == cl.SQUIG_HERDER or
       career_line == cl.WITCH_ELF or
       career_line == cl.CHOPPA or
       career_line == cl.MARAUDER then
        return PartyAd.REALM_DESTRUCTION
    end

    return nil
end

local function pa_get_realm_from_player_data()
    local player = GameData and GameData.Player
    if type(player) ~= "table" then
        return nil
    end

    local realm = player.realm
    if type(realm) == "string" then
        local lower = string.lower(realm)
        if string.find(lower, "order", 1, true) then
            return PartyAd.REALM_ORDER
        end
        if string.find(lower, "dest", 1, true) then
            return PartyAd.REALM_DESTRUCTION
        end
    end

    local realm_info = GameData and GameData.Realm
    if type(realm) == "number" and type(realm_info) == "table" then
        if realm_info.ORDER ~= nil and realm == realm_info.ORDER then
            return PartyAd.REALM_ORDER
        end
        if realm_info.DESTRUCTION ~= nil and realm == realm_info.DESTRUCTION then
            return PartyAd.REALM_DESTRUCTION
        end
    end

    return nil
end

function PartyAd.get_member_role(member)
    if type(member) ~= "table" then
        return nil
    end

    local role = pa_normalize_role_key(member.role)
    if role then
        return role
    end

    local career_line = pa_get_member_career_line(member)

    return PartyAd.get_role_from_career_line(career_line)
end

function PartyAd.build_alt_spec_lookup()
    local lookup = {}
    if not (PartyAd.saved and PartyAd.saved.use_scoreboard_spec_check == true) then
        return lookup
    end
    if not (RoRGroupScoreboard and RoRGroupScoreboard.playersDataRaw) then
        return lookup
    end

    for _, pdata in pairs(RoRGroupScoreboard.playersDataRaw) do
        if pdata and pdata.name and pdata.archtype and pdata.archtype > 0 then
            local key = pa_name_key(pdata.name)
            if key ~= "" then
                lookup[key] = true
            end
        end
    end

    return lookup
end

local function pa_detect_role_for_member(member, alt_lookup)
    local role = PartyAd.get_member_role(member)
    if role ~= PartyAd.ROLE_HEALER then
        return role
    end
    if not (PartyAd.saved and PartyAd.saved.use_scoreboard_spec_check == true) then
        return role
    end

    local key = member and pa_name_key(member.name) or ""
    if key == "" or not alt_lookup[key] then
        return role
    end

    local career_line = pa_get_member_career_line(member)
    career_line = pa_apply_alt_spec_transform(career_line)
    return PartyAd.get_role_from_career_line(career_line)
end

local function pa_add_member(entry, members, seen)
    if type(entry) ~= "table" then
        return
    end

    if entry.name ~= nil then
        local key = pa_fix_name(entry.name)
        if key == "" then
            key = tostring(entry)
        end
        if not seen[key] then
            seen[key] = true
            members[#members + 1] = entry
        end
        return
    end

    if type(entry.Group) == "table" then
        local i
        for i = 1, #entry.Group do
            pa_add_member(entry.Group[i], members, seen)
        end
    end

    if type(entry.players) == "table" then
        local i
        for i = 1, #entry.players do
            pa_add_member(entry.players[i], members, seen)
        end
    end
end

function PartyAd.get_party_members()
    local members = {}
    local seen = {}

    if PartyUtils and type(PartyUtils.GetPartyData) == "function" then
        local ok, party_data = pcall(PartyUtils.GetPartyData)
        if ok and type(party_data) == "table" then
            local i
            for i = 1, #party_data do
                pa_add_member(party_data[i], members, seen)
            end
            if #members == 0 then
                for _, entry in pairs(party_data) do
                    pa_add_member(entry, members, seen)
                end
            end
        end
    end

    return members
end

function PartyAd.get_self_role_override()
    local role = PartyAd.saved and PartyAd.saved.self_role_override or PartyAd.SELF_ROLE_AUTO
    if type(role) ~= "string" then
        return PartyAd.SELF_ROLE_AUTO
    end
    role = string.lower(role)
    if role == PartyAd.ROLE_TANK or
       role == PartyAd.ROLE_HEALER or
       role == PartyAd.ROLE_DPS then
        return role
    end
    return PartyAd.SELF_ROLE_AUTO
end

function PartyAd.get_detected_self_role()
    local member = pa_build_local_player_member()
    if not member then
        return nil
    end
    local alt_lookup = PartyAd.build_alt_spec_lookup()
    return pa_detect_role_for_member(member, alt_lookup)
end

function PartyAd.get_self_role_menu()
    local detected_role = PartyAd.get_detected_self_role()
    local detected_label = pa_role_display_name(detected_role) or "Unknown"
    local auto_label = "Auto (Detected: " .. detected_label .. ")"

    return {
        { key = PartyAd.SELF_ROLE_AUTO, label = auto_label },
        { key = PartyAd.ROLE_TANK, label = pa_role_display_name(PartyAd.ROLE_TANK) },
        { key = PartyAd.ROLE_HEALER, label = pa_role_display_name(PartyAd.ROLE_HEALER) },
        { key = PartyAd.ROLE_DPS, label = pa_role_display_name(PartyAd.ROLE_DPS) },
    }
end

-- Party counting and missing-role calculations.
local function pa_compute_missing_count(desired, current, use_detected_roles)
    local missing = math.max(0, desired or 0)
    if use_detected_roles then
        missing = math.max(0, missing - (current or 0))
    end
    return missing
end

function PartyAd.get_party_counts()
    local counts = {
        tank = 0,
        healer = 0,
        dps = 0,
        total = 0,
    }

    local members = PartyAd.get_party_members()
    if #members > 0 then
        local local_member = pa_build_local_player_member()
        if local_member then
            local self_key = pa_name_key(local_member.name)
            local has_self = false
            local i
            for i = 1, #members do
                if pa_name_key(members[i] and members[i].name) == self_key then
                    has_self = true
                    break
                end
            end
            if not has_self then
                members[#members + 1] = local_member
            end
        end
    end

    local alt_lookup = PartyAd.build_alt_spec_lookup()
    local self_key = ""
    if GameData and GameData.Player and GameData.Player.name then
        self_key = pa_name_key(GameData.Player.name)
    end
    local self_override = PartyAd.get_self_role_override()
    if self_override == PartyAd.SELF_ROLE_AUTO then
        self_override = nil
    end

    local i
    for i = 1, #members do
        local member = members[i]
        local role
        local member_key = member and pa_name_key(member.name) or ""

        if self_override and self_key ~= "" and member_key == self_key then
            role = self_override
        else
            role = pa_detect_role_for_member(member, alt_lookup)
        end

        if role and counts[role] ~= nil then
            counts[role] = counts[role] + 1
            counts.total = counts.total + 1
        end
    end

    return counts
end

function PartyAd.get_missing_counts()
    local counts = PartyAd.get_party_counts()
    local use_detected_roles = PartyAd.saved and PartyAd.saved.use_detected_roles_for_needs == true

    local missing = {
        tank = pa_compute_missing_count(PartyAd.saved.desired_tanks, counts.tank, use_detected_roles),
        healer = pa_compute_missing_count(PartyAd.saved.desired_healers, counts.healer, use_detected_roles),
        dps = pa_compute_missing_count(PartyAd.saved.desired_dps, counts.dps, use_detected_roles),
        spots = math.max(0, PartyAd.PARTY_SIZE - counts.total),
    }
    missing.total = missing.tank + missing.healer + missing.dps

    return missing, counts
end

function PartyAd.format_need_text(missing)
    local parts = {}
    if missing.tank > 0 then
        parts[#parts + 1] = tostring(missing.tank) .. " " .. pa_pluralize(PartyAd.ROLE_TANK, missing.tank)
    end
    if missing.healer > 0 then
        parts[#parts + 1] = tostring(missing.healer) .. " " .. pa_pluralize(PartyAd.ROLE_HEALER, missing.healer)
    end
    if missing.dps > 0 then
        parts[#parts + 1] = tostring(missing.dps) .. " dps"
    end

    if #parts == 0 then
        return "none"
    end
    return pa_join(parts, " / ")
end

function PartyAd.format_current_summary(counts)
    local tank_count = counts.tank or 0
    local healer_count = counts.healer or 0
    local dps_count = counts.dps or 0

    local parts = {
        tostring(tank_count) .. " " .. pa_pluralize(PartyAd.ROLE_TANK, tank_count),
        tostring(healer_count) .. " " .. pa_pluralize(PartyAd.ROLE_HEALER, healer_count),
        tostring(dps_count) .. " dps",
    }

    return "Current: " ..
        pa_join(parts, " / ") .. " (" ..
        tostring(counts.total) .. "/" .. tostring(PartyAd.PARTY_SIZE) .. ")"
end

function PartyAd.format_missing_summary(missing)
    if missing.total == 0 then
        return "Missing: none (fulfilled)"
    end
    if missing.spots == 0 then
        return "Missing: " .. PartyAd.format_need_text(missing) .. " (party full)"
    end
    return "Missing: " .. PartyAd.format_need_text(missing)
end

-- Purpose preset and custom-purpose handling.
function PartyAd.get_player_realm_key()
    local realm = pa_get_realm_from_player_data()
    if realm ~= nil then
        return realm
    end

    local member = pa_build_local_player_member()
    local career_line = pa_get_member_career_line(member)
    return pa_get_realm_from_career_line(career_line)
end

function PartyAd.is_purpose_preset_available(preset)
    if type(preset) ~= "table" then
        return false
    end

    local preset_realm = preset.realm or PartyAd.REALM_BOTH
    if preset_realm == PartyAd.REALM_BOTH then
        return true
    end

    local player_realm = PartyAd.get_player_realm_key()
    if player_realm == nil then
        -- If realm detection fails, keep presets visible rather than hiding options.
        return true
    end

    return preset_realm == player_realm
end

function PartyAd.set_purpose(purpose_text)
    PartyAd.saved.purpose_custom = pa_trim(purpose_text)
    PartyAd.saved.purpose_mode = PartyAd.PURPOSE_CUSTOM_KEY
    PartyAd.saved.purpose = PartyAd.saved.purpose_custom
end

function PartyAd.get_purpose()
    local mode = PartyAd.get_purpose_mode()
    if mode == PartyAd.PURPOSE_CUSTOM_KEY then
        return pa_trim(PartyAd.saved.purpose_custom or "")
    end

    local preset = PartyAd.find_purpose_preset(mode)
    if preset and type(preset.text) == "string" then
        return pa_trim(preset.text)
    end

    return pa_trim(PartyAd.saved.purpose_custom or "")
end

function PartyAd.find_purpose_preset(key)
    if type(key) ~= "string" then
        return nil
    end
    local i
    for i = 1, #PartyAd.PURPOSE_PRESETS do
        local preset = PartyAd.PURPOSE_PRESETS[i]
        if preset and preset.key == key then
            return preset
        end
    end
    return nil
end

function PartyAd.get_purpose_mode()
    local mode = PartyAd.saved and PartyAd.saved.purpose_mode or PartyAd.PURPOSE_CUSTOM_KEY
    if mode == PartyAd.PURPOSE_CUSTOM_KEY then
        return PartyAd.PURPOSE_CUSTOM_KEY
    end
    local preset = PartyAd.find_purpose_preset(mode)
    if preset and PartyAd.is_purpose_preset_available(preset) then
        return mode
    end
    return PartyAd.PURPOSE_CUSTOM_KEY
end

function PartyAd.select_purpose_preset(key)
    local preset = PartyAd.find_purpose_preset(key)
    if not preset then
        return false
    end
    if not PartyAd.is_purpose_preset_available(preset) then
        return false
    end
    PartyAd.saved.purpose_mode = preset.key
    PartyAd.saved.purpose = pa_trim(preset.text or "")
    return true
end

function PartyAd.set_purpose_mode(mode)
    if mode == PartyAd.PURPOSE_CUSTOM_KEY then
        PartyAd.saved.purpose_mode = PartyAd.PURPOSE_CUSTOM_KEY
        PartyAd.saved.purpose = pa_trim(PartyAd.saved.purpose_custom or "")
        return true
    end
    return PartyAd.select_purpose_preset(mode)
end

function PartyAd.get_purpose_menu()
    local items = {
        { key = PartyAd.PURPOSE_CUSTOM_KEY, label = "Custom..." },
    }
    local i
    for i = 1, #PartyAd.PURPOSE_PRESETS do
        local preset = PartyAd.PURPOSE_PRESETS[i]
        if PartyAd.is_purpose_preset_available(preset) then
            items[#items + 1] = {
                key = preset.key,
                label = preset.label or preset.text or preset.key,
            }
        end
    end
    return items
end

-- Party-state checks and chat command dispatch.
local PA_PARTYNOTE_FIELD_KEYS = {
    "partyNote",
    "partynote",
    "groupNote",
    "groupnote",
}

local function pa_note_to_string(note_raw)
    if note_raw == nil then
        return nil
    end
    if type(note_raw) == "string" then
        return note_raw
    end
    if type(WStringToString) == "function" then
        local ok_ws, ws_val = pcall(WStringToString, note_raw)
        if ok_ws and ws_val then
            return ws_val
        end
    end
    local ok_str, str_val = pcall(tostring, note_raw)
    if ok_str and str_val then
        return str_val
    end
    return nil
end

local function pa_normalize_note_text(note_raw)
    local note_str = pa_note_to_string(note_raw)
    if not note_str then
        return nil
    end
    note_str = string.gsub(note_str, "%s+", " ")
    note_str = string.gsub(note_str, "^%s*(.-)%s*$", "%1")
    if note_str == "" then
        return nil
    end
    return note_str
end

local function pa_read_partynote_from_table(data, source_prefix)
    if type(data) ~= "table" then
        return nil, nil
    end

    local prefix = source_prefix or "table"
    local i
    for i = 1, #PA_PARTYNOTE_FIELD_KEYS do
        local field = PA_PARTYNOTE_FIELD_KEYS[i]
        local normalized = pa_normalize_note_text(data[field])
        if normalized ~= nil then
            return normalized, prefix .. "." .. field
        end
    end

    return nil, nil
end

local function pa_read_partynote_with_settings(data, source_prefix)
    local note, source = pa_read_partynote_from_table(data, source_prefix)
    if note ~= nil then
        return note, source
    end
    if type(data) ~= "table" then
        return nil, nil
    end

    local prefix = tostring(source_prefix or "table")
    return pa_read_partynote_from_table(data.Settings, prefix .. ".Settings")
end

local function pa_build_name_key_lookup(keys)
    local lookup = {}
    if type(keys) ~= "table" then
        return lookup
    end

    local i
    for i = 1, #keys do
        local key = keys[i]
        if type(key) == "string" and key ~= "" then
            lookup[key] = true
        end
    end
    return lookup
end

local function pa_collect_group_leader_name_keys()
    local keys = {}
    local seen = {}

    local function add_name(raw_name)
        local key = pa_name_key(raw_name)
        if key == "" or seen[key] then
            return
        end
        seen[key] = true
        keys[#keys + 1] = key
    end

    add_name(GameData and GameData.Player and GameData.Player.name)

    if PartyUtils and type(PartyUtils.GetPartyData) == "function" then
        local ok_party, party_members = pcall(PartyUtils.GetPartyData)
        if ok_party and type(party_members) == "table" then
            local i
            for i = 1, #party_members do
                local member = party_members[i]
                if type(member) == "table" and member.isGroupLeader == true then
                    add_name(member.name)
                end
            end
        end
    end

    if type(GetBattlegroupMemberData) == "function" then
        local ok_wb, wb_data = pcall(GetBattlegroupMemberData)
        if ok_wb and type(wb_data) == "table" then
            local i
            for i = 1, #wb_data do
                local party = wb_data[i]
                if type(party) == "table" and type(party.players) == "table" then
                    local j
                    for j = 1, #party.players do
                        local member = party.players[j]
                        if type(member) == "table" and member.isGroupLeader == true then
                            add_name(member.name)
                            break
                        end
                    end
                end
            end
        end
    end

    return keys
end

local function pa_get_live_partynote_from_openparty_list(fetch_fn, list_name, leader_keys)
    if type(fetch_fn) ~= "function" then
        return nil, nil
    end
    if type(leader_keys) ~= "table" or #leader_keys == 0 then
        return nil, nil
    end
    local leader_lookup = pa_build_name_key_lookup(leader_keys)

    local ok, list = pcall(fetch_fn)
    if not ok or type(list) ~= "table" then
        return nil, nil
    end

    local i
    for i = 1, #list do
        local entry = list[i]
        if type(entry) == "table" then
            local entry_name_key = pa_name_key(entry.leaderName or entry.name)
            if entry_name_key ~= "" and leader_lookup[entry_name_key] then
                local prefix = tostring(list_name or "OpenPartyList") .. "[" .. tostring(i) .. "]"
                local note, source = pa_read_partynote_with_settings(entry, prefix)
                if note ~= nil then
                    return note, source
                end
            end
        end
    end

    return nil, nil
end

local function pa_get_live_partynote_from_player()
    local player = GameData and GameData.Player
    if type(player) ~= "table" then
        return nil, nil
    end

    local note, source = pa_read_partynote_from_table(player, "GameData.Player")
    if note ~= nil then
        return note, source
    end

    local group = player.Group
    if type(group) ~= "table" then
        return nil, nil
    end

    note, source = pa_read_partynote_from_table(group, "GameData.Player.Group")
    if note ~= nil then
        return note, source
    end

    return pa_read_partynote_from_table(group.Settings, "GameData.Player.Group.Settings")
end

local function pa_get_live_partynote_from_members()
    if not (PartyUtils and type(PartyUtils.GetPartyData) == "function") then
        return nil, nil
    end

    local ok, members = pcall(PartyUtils.GetPartyData)
    if not ok or type(members) ~= "table" then
        return nil, nil
    end

    local player_name_key = pa_name_key(GameData and GameData.Player and GameData.Player.name)
    local fallback = nil
    local fallback_source = nil

    local i
    for i = 1, #members do
        local member = members[i]
        if type(member) == "table" then
            local source_prefix = "PartyUtils.GetPartyData()[" .. tostring(i) .. "]"
            local note, source = pa_read_partynote_with_settings(member, source_prefix)

            if note ~= nil then
                if member.isGroupLeader == true then
                    return note, source
                end
                if player_name_key ~= "" and pa_name_key(member.name) == player_name_key then
                    return note, source
                end
                if fallback == nil then
                    fallback = note
                    fallback_source = source
                end
            end
        end
    end

    return fallback, fallback_source
end

local function pa_get_live_partynote_from_openparty()
    local leader_keys = pa_collect_group_leader_name_keys()
    local note, source = pa_get_live_partynote_from_openparty_list(GetOpenPartyFullList, "GetOpenPartyFullList", leader_keys)
    if note ~= nil then
        return note, source
    end
    return pa_get_live_partynote_from_openparty_list(GetOpenPartyWorldList, "GetOpenPartyWorldList", leader_keys)
end

-- Returns nil when the runtime does not expose a live party-note field.
function PartyAd.get_live_partynote()
    local note, source = pa_get_live_partynote_from_player()
    if note ~= nil then
        return note, source
    end

    note, source = pa_get_live_partynote_from_members()
    if note ~= nil then
        return note, source
    end

    return pa_get_live_partynote_from_openparty()
end

function PartyAd.get_last_applied_partynote()
    if type(PartyAd._last_applied_partynote) ~= "string" then
        return nil
    end
    local note = pa_trim(PartyAd._last_applied_partynote)
    if note == "" then
        return nil
    end
    return note
end

local function pa_get_party_is_public_state()
    if not (GameData and GameData.Player and GameData.Player.Group and GameData.Player.Group.Settings) then
        return nil
    end
    local is_public = GameData.Player.Group.Settings.isPublic
    if type(is_public) == "boolean" then
        return is_public
    end
    return nil
end

-- Chooses the best available baseline for mismatch hinting.
function PartyAd.get_partynote_hint_candidate()
    local is_public = pa_get_party_is_public_state()
    if is_public == false then
        return nil, "GameData.Player.Group.Settings.isPublic=false", "none_closed"
    end

    local live_note, live_source = PartyAd.get_live_partynote()
    if live_note ~= nil then
        return pa_trim(live_note), tostring(live_source or "(unknown)"), "live"
    end

    local last_applied = PartyAd.get_last_applied_partynote()
    if last_applied ~= nil then
        return last_applied, "PartyAd._last_applied_partynote", "fallback_last_sent"
    end

    return nil, "(not found)", "none"
end

function PartyAd.is_party_leader()
    return GameData and GameData.Player and GameData.Player.isGroupLeader == true
end

function PartyAd.is_party_active()
    if PartyUtils and type(PartyUtils.IsPartyActive) == "function" then
        local ok, active = pcall(PartyUtils.IsPartyActive)
        if ok and active == true then
            return true
        end
    end
    local members = PartyAd.get_party_members()
    return #members > 0
end

function PartyAd.send_chat_command(command)
    if type(SendChatText) ~= "function" then
        PartyAd.print("[Error] SendChatText is unavailable.")
        return false
    end
    SendChatText(pa_to_wstring(command), L"")
    return true
end

local function pa_request_openparty_refresh()
    -- Mirror the default Open Party "Refresh" action when available.
    if EA_Window_OpenPartyNearby and type(EA_Window_OpenPartyNearby.RequestUpdateFullList) == "function" then
        pcall(EA_Window_OpenPartyNearby.RequestUpdateFullList)
        return
    end

    local request_all = GameData and GameData.OpenPartyRequestType and GameData.OpenPartyRequestType.ALL
    if request_all ~= nil and type(SendOpenPartySearchRequest) == "function" then
        pcall(SendOpenPartySearchRequest, request_all)
    end
end

function PartyAd.request_openparty_refresh()
    pa_request_openparty_refresh()
end

-- Output text builders and outgoing commands.
function PartyAd.build_partynote_text(missing)
    local purpose = PartyAd.get_purpose()
    local base = "Party"
    if purpose ~= "" then
        base = purpose
    end

    local suffix = ""
    if missing.total == 0 then
        suffix = " - Full!"
    else
        suffix = " - Need: " .. PartyAd.format_need_text(missing)
    end

    return pa_build_partynote_with_suffix(base, suffix)
end

function PartyAd.apply_partynote()
    if not PartyAd.is_party_active() then
        PartyAd.print("[Error] You need an active party.")
        return
    end
    if not PartyAd.is_party_leader() then
        PartyAd.print("[Error] You need to be party leader.")
        return
    end

    local missing = PartyAd.get_missing_counts()

    local note_text = PartyAd.build_partynote_text(missing)
    local sent = PartyAd.send_chat_command("/partynote " .. note_text)
    if sent then
        PartyAd._last_applied_partynote = note_text
        pa_request_openparty_refresh()
    end
    PartyAd.print("Updated /partynote.")
end

function PartyAd.clear_partynote(is_manual)
    if not PartyAd.is_party_active() then
        PartyAd.print("[Error] You need an active party.")
        return
    end
    if not PartyAd.is_party_leader() then
        PartyAd.print("[Error] You need to be party leader.")
        return
    end

    local sent = PartyAd.send_chat_command("/partynote")
    if sent then
        PartyAd._last_applied_partynote = nil
    end
    if is_manual then
        PartyAd.print("Cleared /partynote.")
    end
end

function PartyAd.build_advertise_text()
    local missing = PartyAd.get_missing_counts()
    local purpose = PartyAd.get_purpose()

    local base = "Party"
    if purpose ~= "" then
        base = purpose .. " party"
    end

    local leader_name = GameData and GameData.Player and GameData.Player.name or nil
    local leader = pa_format_leader_mention(leader_name)

    local message
    if missing.total == 0 then
        message = base .. " full for now!"
    else
        message = base .. " needs " .. PartyAd.format_need_text(missing) .. "; msg " .. leader
    end

    return pa_truncate(message, 220)
end

function PartyAd.advertise_lfg()
    local text = PartyAd.build_advertise_text()
    PartyAd.send_chat_command("/5 " .. text)
    PartyAd.print("Advertised in /5.")
end
