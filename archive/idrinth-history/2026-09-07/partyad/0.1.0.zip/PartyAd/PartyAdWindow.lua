PartyAdWindow = PartyAdWindow or {}

-- Window identity and local UI state.
PartyAdWindow.name = "PartyAdWindow"
PartyAdWindow.purpose_combo_name = PartyAdWindow.name .. "PurposePresetComboBox"
PartyAdWindow.purpose_combo_items = {}
PartyAdWindow.self_role_combo_name = PartyAdWindow.name .. "SelfRoleComboBox"
PartyAdWindow.self_role_combo_items = {}
PartyAdWindow.default_width = 496
PartyAdWindow.default_height = 688
PartyAdWindow.is_refreshing = false
PartyAdWindow.partynote_poll_interval_seconds = 2
PartyAdWindow.partynote_poll_elapsed_seconds = 0
PartyAdWindow.partynote_hint_grace_seconds = 3
PartyAdWindow.partynote_hint_grace_remaining_seconds = 0
PartyAdWindow.partynote_refresh_after_grace_pending = false
PartyAdWindow.preview_note_hint_text = ""

-- Local conversion/format helpers for labels and edit boxes.
local function paw_to_wstring(value)
    local text = tostring(value or "")
    if type(towstring) == "function" then
        local ok, wide = pcall(towstring, text)
        if ok then
            return wide
        end
    end
    return text
end

local function paw_trim(text)
    local s = tostring(text or "")
    s = string.gsub(s, "%s+", " ")
    s = string.gsub(s, "^%s*(.-)%s*$", "%1")
    return s
end

local function paw_format_detected_count(count, singular, plural)
    local n = tonumber(count) or 0
    local role = singular
    if n ~= 1 then
        role = plural or singular
    end
    return tostring(n) .. " " .. tostring(role or "")
end

local function paw_has_partyad_prefix(text)
    local s = paw_trim(text)
    return string.sub(s, 1, 4) == "[PA]"
end

local function paw_set_preview_note_hint(text, r, g, b)
    PartyAdWindow.preview_note_hint_text = tostring(text or "")
    local label_name = PartyAdWindow.name .. "PreviewNoteStatusLabel"
    if type(LabelSetText) == "function" then
        LabelSetText(label_name, paw_to_wstring(text or ""))
    end
    if type(LabelSetTextColor) == "function" then
        LabelSetTextColor(label_name, r or 255, g or 255, b or 255)
    end
end

local function paw_reset_partynote_poll_state()
    PartyAdWindow.partynote_poll_elapsed_seconds = 0
    PartyAdWindow.partynote_hint_grace_remaining_seconds = 0
    PartyAdWindow.partynote_refresh_after_grace_pending = false
end

-- Window visibility and sizing helpers.
local function paw_window_exists(window_name)
    if type(DoesWindowExist) ~= "function" then
        return true
    end

    local ok, exists = pcall(DoesWindowExist, window_name)
    if not ok then
        return false
    end
    return exists == true
end

function PartyAdWindow.IsShowing()
    if type(WindowGetShowing) ~= "function" then
        return false
    end

    local window_name = PartyAdWindow.name
    if not paw_window_exists(window_name) then
        return false
    end

    local ok, is_showing = pcall(WindowGetShowing, window_name)
    if not ok then
        return false
    end
    return is_showing == true
end

-- Backward-compatibility alias; prefer IsShowing for new code.
function PartyAdWindow.showing()
    return PartyAdWindow.IsShowing()
end

function PartyAdWindow.Hide()
    if PartyAd and type(PartyAd.unregister_runtime_events) == "function" then
        PartyAd.unregister_runtime_events()
    end
    paw_reset_partynote_poll_state()
    WindowSetShowing(PartyAdWindow.name, false)
end

function PartyAdWindow.Show()
    WindowSetShowing(PartyAdWindow.name, true)
    if PartyAd and type(PartyAd.register_runtime_events) == "function" then
        PartyAd.register_runtime_events()
    end
    paw_reset_partynote_poll_state()
    PartyAdWindow.ApplyWindowSize()
    PartyAdWindow.RefreshAll()
end

function PartyAdWindow.Toggle()
    if PartyAdWindow.IsShowing() then
        PartyAdWindow.Hide()
    else
        PartyAdWindow.Show()
    end
end

function PartyAdWindow.ApplyWindowSize()
    if type(WindowSetDimensions) == "function" then
        WindowSetDimensions(PartyAdWindow.name, PartyAdWindow.default_width, PartyAdWindow.default_height)
    end
end

-- OnUpdate polling keeps the partynote mismatch hint fresh while visible.
function PartyAdWindow.OnUpdate(elapsed_seconds)
    if not PartyAdWindow.IsShowing() then
        paw_reset_partynote_poll_state()
        return
    end

    local elapsed = tonumber(elapsed_seconds) or 0
    if elapsed < 0 then
        elapsed = 0
    end

    if PartyAdWindow.partynote_hint_grace_remaining_seconds > 0 then
        PartyAdWindow.partynote_hint_grace_remaining_seconds = PartyAdWindow.partynote_hint_grace_remaining_seconds - elapsed
        if PartyAdWindow.partynote_hint_grace_remaining_seconds <= 0 then
            PartyAdWindow.partynote_hint_grace_remaining_seconds = 0
            if PartyAdWindow.partynote_refresh_after_grace_pending and PartyAd and type(PartyAd.request_openparty_refresh) == "function" then
                PartyAd.request_openparty_refresh()
            end
            PartyAdWindow.partynote_refresh_after_grace_pending = false
        end
    end

    PartyAdWindow.partynote_poll_elapsed_seconds = PartyAdWindow.partynote_poll_elapsed_seconds + elapsed
    if PartyAdWindow.partynote_poll_elapsed_seconds < PartyAdWindow.partynote_poll_interval_seconds then
        return
    end

    PartyAdWindow.partynote_poll_elapsed_seconds = 0
    PartyAdWindow.RefreshPartynoteSyncHint()
end

-- Window bootstrap and static label setup.
function PartyAdWindow.Initialize()
    PartyAdWindow.ApplyWindowSize()

    local label_texts = {
        { "TitleBarText", L"PartyAd" },
        { "TargetsLabel", L"Party Targets (max 6)" },
        { "CurrentColumnLabel", L"Detected" },
        { "TankLabel", L"Tank" },
        { "HealerLabel", L"Healer" },
        { "DpsLabel", L"DPS" },
        { "PurposePresetLabel", L"Purpose Preset" },
        { "PurposeLabel", L"Purpose" },
        { "OptionsLabel", L"Detection Options" },
        { "UseSpecCheckLabel", L"Enable alt-spec check" },
        { "UseDetectedNeedsLabel", L"Use detected roles for note/ad numbers" },
        { "SelfRoleLabel", L"Your Role" },
        { "PreviewLabel", L"Partynote Preview" },
        { "PreviewNoteStatusLabel", L"" },
        { "AdvertisePreviewLabel", L"/5 Advertise Preview" },
    }
    local i
    for i = 1, #label_texts do
        local entry = label_texts[i]
        LabelSetText(PartyAdWindow.name .. entry[1], entry[2])
    end

    local white_labels = {
        "TargetsLabel",
        "CurrentColumnLabel",
        "PurposePresetLabel",
        "PurposeLabel",
        "OptionsLabel",
        "UseSpecCheckLabel",
        "UseDetectedNeedsLabel",
        "SelfRoleLabel",
        "PreviewLabel",
        "PreviewNoteStatusLabel",
        "AdvertisePreviewLabel",
    }
    for i = 1, #white_labels do
        LabelSetTextColor(PartyAdWindow.name .. white_labels[i], 255, 255, 255)
    end

    PartyAdWindow.InitPurposeCombo()
    ComboBoxClearMenuItems(PartyAdWindow.self_role_combo_name)

    ButtonSetStayDownFlag(PartyAdWindow.name .. "UseSpecCheckButton", true)
    ButtonSetStayDownFlag(PartyAdWindow.name .. "UseDetectedNeedsButton", true)

    ButtonSetText(PartyAdWindow.name .. "UpdateNoteButton", L"Update Note")
    ButtonSetText(PartyAdWindow.name .. "AdvertiseButton", L"Advertise /5")
    ButtonSetText(PartyAdWindow.name .. "ClearNoteButton", L"Clear Note")

    PartyAdWindow.RefreshAll()
end

-- Purpose preset combobox population/selection helpers.
function PartyAdWindow.InitPurposeCombo()
    PartyAdWindow.purpose_combo_items = PartyAd.get_purpose_menu()
    ComboBoxClearMenuItems(PartyAdWindow.purpose_combo_name)

    local i
    for i = 1, #PartyAdWindow.purpose_combo_items do
        local item = PartyAdWindow.purpose_combo_items[i]
        ComboBoxAddMenuItem(PartyAdWindow.purpose_combo_name, paw_to_wstring(item.label))
    end
end

function PartyAdWindow.RefreshPurposeCombo()
    local mode = PartyAd.get_purpose_mode()
    local selected = 1
    local i
    for i = 1, #PartyAdWindow.purpose_combo_items do
        local item = PartyAdWindow.purpose_combo_items[i]
        if item.key == mode then
            selected = i
            break
        end
    end
    ComboBoxSetSelectedMenuItem(PartyAdWindow.purpose_combo_name, selected)
end

-- Live refresh helpers used after state changes.
function PartyAdWindow.RefreshTargets()
    if not PartyAd or not PartyAd.saved then
        return
    end

    LabelSetText(PartyAdWindow.name .. "TankValue", paw_to_wstring(PartyAd.saved.desired_tanks or 0))
    LabelSetText(PartyAdWindow.name .. "HealerValue", paw_to_wstring(PartyAd.saved.desired_healers or 0))
    LabelSetText(PartyAdWindow.name .. "DpsValue", paw_to_wstring(PartyAd.saved.desired_dps or 0))
end

function PartyAdWindow.RefreshPurpose()
    if not PartyAd or not PartyAd.saved then
        return
    end
    PartyAdWindow.RefreshPurposeCombo()

    local current_text = tostring(TextEditBoxGetText(PartyAdWindow.name .. "PurposeEditBox") or "")
    local mode = PartyAd.get_purpose_mode()
    local expected = ""
    if mode == PartyAd.PURPOSE_CUSTOM_KEY then
        expected = PartyAd.saved.purpose_custom or ""
    else
        expected = PartyAd.get_purpose()
    end
    if current_text ~= expected then
        TextEditBoxSetText(PartyAdWindow.name .. "PurposeEditBox", paw_to_wstring(expected))
    end
end

function PartyAdWindow.RefreshCounts()
    if not PartyAd then
        return
    end

    local _, counts = PartyAd.get_missing_counts()
    counts = counts or {}

    LabelSetText(PartyAdWindow.name .. "TankCurrentValue", paw_to_wstring(paw_format_detected_count(counts.tank, "Tank", "Tanks")))
    LabelSetText(PartyAdWindow.name .. "HealerCurrentValue", paw_to_wstring(paw_format_detected_count(counts.healer, "Healer", "Healers")))
    LabelSetText(PartyAdWindow.name .. "DpsCurrentValue", paw_to_wstring(paw_format_detected_count(counts.dps, "DPS", "DPS")))
end

-- Self-role combobox and option toggle refresh.
function PartyAdWindow.InitSelfRoleCombo()
    PartyAdWindow.self_role_combo_items = PartyAd.get_self_role_menu()
    ComboBoxClearMenuItems(PartyAdWindow.self_role_combo_name)

    local i
    for i = 1, #PartyAdWindow.self_role_combo_items do
        local item = PartyAdWindow.self_role_combo_items[i]
        ComboBoxAddMenuItem(PartyAdWindow.self_role_combo_name, paw_to_wstring(item.label))
    end
end

function PartyAdWindow.RefreshOptions()
    if not PartyAd or not PartyAd.saved then
        return
    end

    ButtonSetPressedFlag(PartyAdWindow.name .. "UseSpecCheckButton", PartyAd.saved.use_scoreboard_spec_check == true)
    ButtonSetPressedFlag(PartyAdWindow.name .. "UseDetectedNeedsButton", PartyAd.saved.use_detected_roles_for_needs == true)

    PartyAdWindow.InitSelfRoleCombo()

    local selected_key = PartyAd.get_self_role_override()
    local selected = 1
    local i
    for i = 1, #PartyAdWindow.self_role_combo_items do
        local item = PartyAdWindow.self_role_combo_items[i]
        if item and item.key == selected_key then
            selected = i
            break
        end
    end
    ComboBoxSetSelectedMenuItem(PartyAdWindow.self_role_combo_name, selected)
end

-- Preview renderers for /partynote and /5 text.
function PartyAdWindow.RefreshPartynoteSyncHint(partynote_preview_text)
    if not PartyAd then
        paw_set_preview_note_hint("")
        return
    end

    if PartyAdWindow.partynote_hint_grace_remaining_seconds > 0 then
        paw_set_preview_note_hint("")
        return
    end

    local preview_text = partynote_preview_text
    if type(preview_text) ~= "string" then
        local missing = PartyAd.get_missing_counts()
        preview_text = PartyAd.build_partynote_text(missing)
    end
    preview_text = paw_trim(preview_text)

    local baseline_note = nil
    if type(PartyAd.get_partynote_hint_candidate) == "function" then
        baseline_note = PartyAd.get_partynote_hint_candidate()
    elseif type(PartyAd.get_live_partynote) == "function" then
        baseline_note = PartyAd.get_live_partynote()
    end
    if baseline_note == nil then
        paw_set_preview_note_hint("")
        return
    end

    local baseline_text = paw_trim(baseline_note)
    if not paw_has_partyad_prefix(baseline_text) then
        paw_set_preview_note_hint("")
        return
    end
    if baseline_text == preview_text then
        paw_set_preview_note_hint("")
        return
    end

    paw_set_preview_note_hint("mismatch", 255, 64, 64)
end

-- Tooltip handlers for the mismatch status indicator.
function PartyAdWindow.OnMouseOverPreviewNoteStatus()
    local hint_text = paw_trim(PartyAdWindow.preview_note_hint_text or "")
    if hint_text == "" then
        return
    end
    if not (Tooltips and type(Tooltips.CreateTextOnlyTooltip) == "function" and type(Tooltips.SetTooltipText) == "function") then
        return
    end

    local anchor_window = PartyAdWindow.name .. "PreviewNoteStatusLabel"
    if SystemData and SystemData.ActiveWindow and SystemData.ActiveWindow.name then
        anchor_window = SystemData.ActiveWindow.name
    end

    Tooltips.CreateTextOnlyTooltip(anchor_window)
    Tooltips.SetTooltipText(1, 1, paw_to_wstring("Current /partynote does not match this preview."))
    if type(Tooltips.SetTooltipColorDef) == "function" and Tooltips.COLOR_BODY then
        Tooltips.SetTooltipColorDef(1, 1, Tooltips.COLOR_BODY)
    end
    if type(Tooltips.Finalize) == "function" then
        Tooltips.Finalize()
    end
    if type(Tooltips.AnchorTooltip) == "function" then
        local anchor = Tooltips.ANCHOR_WINDOW_RIGHT or Tooltips.ANCHOR_CURSOR
        Tooltips.AnchorTooltip(anchor)
    end
end

function PartyAdWindow.OnMouseOverEndPreviewNoteStatus()
    if Tooltips and type(Tooltips.ClearTooltip) == "function" then
        Tooltips.ClearTooltip()
    end
end

function PartyAdWindow.RefreshPreview()
    if not PartyAd then
        return
    end

    local missing = PartyAd.get_missing_counts()
    local partynote_preview_text = PartyAd.build_partynote_text(missing)
    local advertise_preview_text = PartyAd.build_advertise_text()
    advertise_preview_text = string.gsub(advertise_preview_text, "<LINK[^>]-text=\"([^\"]*)\"[^>]*>", "%1")
    advertise_preview_text = string.gsub(advertise_preview_text, "<[^>]+>", "")

    LabelSetText(PartyAdWindow.name .. "PreviewNoteTextLabel", paw_to_wstring(partynote_preview_text))
    LabelSetText(PartyAdWindow.name .. "AdvertisePreviewTextLabel", paw_to_wstring(advertise_preview_text))
    PartyAdWindow.RefreshPartynoteSyncHint(partynote_preview_text)
end

function PartyAdWindow.RefreshAll()
    if PartyAdWindow.is_refreshing then
        return
    end
    PartyAdWindow.is_refreshing = true
    PartyAdWindow.RefreshTargets()
    PartyAdWindow.RefreshPurpose()
    PartyAdWindow.RefreshOptions()
    PartyAdWindow.RefreshCounts()
    PartyAdWindow.RefreshPreview()
    PartyAdWindow.is_refreshing = false
end

-- Purpose text persistence from the UI input control.
function PartyAdWindow.SavePurposeFromUi()
    if not PartyAd then
        return
    end
    local text = tostring(TextEditBoxGetText(PartyAdWindow.name .. "PurposeEditBox") or "")
    local mode = PartyAd.get_purpose_mode()
    if mode == PartyAd.PURPOSE_CUSTOM_KEY then
        PartyAd.set_purpose(text)
        return
    end

    if paw_trim(text) ~= paw_trim(PartyAd.get_purpose()) then
        PartyAd.set_purpose(text)
    end
end

-- Purpose and option event handlers.
local function paw_toggle_option(saved_key, button_name_suffix)
    if PartyAdWindow.is_refreshing or not PartyAd or not PartyAd.saved then
        return
    end

    local button_name = PartyAdWindow.name .. button_name_suffix
    local next_state = not (PartyAd.saved[saved_key] == true)
    ButtonSetPressedFlag(button_name, next_state)
    PartyAd.saved[saved_key] = next_state
    PartyAdWindow.RefreshAll()
end

local function paw_get_selected_combo_item(combo_name, items)
    local selected_index = ComboBoxGetSelectedMenuItem(combo_name)
    if type(selected_index) ~= "number" or selected_index < 1 or selected_index > #items then
        return nil
    end
    return items[selected_index]
end

local function paw_adjust_target(role_key, delta)
    PartyAdWindow.SavePurposeFromUi()
    PartyAd.adjust_target(role_key, delta)
    PartyAdWindow.RefreshAll()
end

function PartyAdWindow.OnPurposeFocusLost()
    PartyAdWindow.SavePurposeFromUi()
    PartyAdWindow.RefreshAll()
end

function PartyAdWindow.OnPurposeTextChanged()
    if PartyAdWindow.is_refreshing then
        return
    end
    PartyAdWindow.SavePurposeFromUi()
    PartyAdWindow.RefreshPurposeCombo()
    PartyAdWindow.RefreshPreview()
end

function PartyAdWindow.OnSelChangedPurposePreset()
    if PartyAdWindow.is_refreshing then
        return
    end

    local item = paw_get_selected_combo_item(PartyAdWindow.purpose_combo_name, PartyAdWindow.purpose_combo_items)
    if not item or not item.key then
        return
    end

    PartyAd.set_purpose_mode(item.key)
    PartyAdWindow.RefreshAll()
end

function PartyAdWindow.OnToggleSpecCheck()
    paw_toggle_option("use_scoreboard_spec_check", "UseSpecCheckButton")
end

function PartyAdWindow.OnToggleDetectedNeeds()
    paw_toggle_option("use_detected_roles_for_needs", "UseDetectedNeedsButton")
end

function PartyAdWindow.OnToggleSpecCheckLabel()
    PartyAdWindow.OnToggleSpecCheck()
end

function PartyAdWindow.OnToggleDetectedNeedsLabel()
    PartyAdWindow.OnToggleDetectedNeeds()
end

function PartyAdWindow.OnSelChangedSelfRole()
    if PartyAdWindow.is_refreshing or not PartyAd or not PartyAd.saved then
        return
    end

    local item = paw_get_selected_combo_item(PartyAdWindow.self_role_combo_name, PartyAdWindow.self_role_combo_items)
    if not item or not item.key then
        return
    end

    PartyAd.saved.self_role_override = item.key
    PartyAdWindow.RefreshAll()
end

-- Target adjustment button handlers.
function PartyAdWindow.OnMinusTank()
    paw_adjust_target(PartyAd.ROLE_TANK, -1)
end

function PartyAdWindow.OnPlusTank()
    paw_adjust_target(PartyAd.ROLE_TANK, 1)
end

function PartyAdWindow.OnMinusHealer()
    paw_adjust_target(PartyAd.ROLE_HEALER, -1)
end

function PartyAdWindow.OnPlusHealer()
    paw_adjust_target(PartyAd.ROLE_HEALER, 1)
end

function PartyAdWindow.OnMinusDps()
    paw_adjust_target(PartyAd.ROLE_DPS, -1)
end

function PartyAdWindow.OnPlusDps()
    paw_adjust_target(PartyAd.ROLE_DPS, 1)
end

-- Action button handlers.
function PartyAdWindow.OnUpdateNote()
    PartyAdWindow.SavePurposeFromUi()
    PartyAd.apply_partynote()
    PartyAdWindow.partynote_hint_grace_remaining_seconds = PartyAdWindow.partynote_hint_grace_seconds
    PartyAdWindow.partynote_refresh_after_grace_pending = true
    paw_set_preview_note_hint("")
    PartyAdWindow.RefreshAll()
end

function PartyAdWindow.OnAdvertise()
    PartyAdWindow.SavePurposeFromUi()
    PartyAd.advertise_lfg()
    PartyAdWindow.RefreshAll()
end

function PartyAdWindow.OnClearNote()
    PartyAdWindow.SavePurposeFromUi()
    PartyAd.clear_partynote(true)
    PartyAdWindow.RefreshAll()
end
