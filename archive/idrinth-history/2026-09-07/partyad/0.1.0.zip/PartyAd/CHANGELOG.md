# Changelog
All notable changes to this project are documented in this file.

## About PartyAd
PartyAd is a Return of Reckoning addon for single-party recruiting.
It helps party leaders set role targets, choose a party purpose, update or clear `/partynote`, and advertise current needs in `/5`.

## [0.1.0] - 2026-02-13
Initial documented release baseline.

### Added
- Core party-target logic for `Tank/Healer/DPS` with normalization to a 6-player party cap.
- Purpose system with preset support, realm-aware dungeon preset filtering, and `Custom...` text mode.
- `/partynote` text builder with `[PA]` prefix and a 69-character cap.
- `/5` advertise text builder including purpose, missing roles, and clickable leader mention formatting.
- Slash command surface:
  - `/partyad`
  - `/partyad update note`
  - `/partyad clear note`
  - `/partyad advertise`
  - `/partyad targets <t> <h> <d>`
  - `/partyad purpose <text>`
  - `/partyad purposepreset <name|custom>`
  - `/partyad altspec <on|off|toggle>`
  - `/partyad detectedroles <on|off|toggle>`
  - `/partyad yourrole <auto|tank|healer|dps>`
  - `/partyad status`
- PartyAd window UI for targets, purpose selection, detection options, self-role override, previews, and action buttons.
- Alt-spec role steering via `RoRGroupScoreboard.playersDataRaw` (healer careers in DPS spec count as DPS).
- Toggle to compute missing-role needs from detected current roles or from configured targets only.
- Self-role override for local player (`auto|tank|healer|dps`).
