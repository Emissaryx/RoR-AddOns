PartyAd = PartyAd or {}

-- UI refresh hooks triggered by runtime events/actions.
local function pa_window_is_showing()
    if not PartyAdWindow then
        return false
    end

    if type(PartyAdWindow.IsShowing) == "function" then
        return PartyAdWindow.IsShowing()
    end

    if type(PartyAdWindow.showing) == "function" then
        return PartyAdWindow.showing()
    end

    return false
end

function PartyAd.refresh_window()
    if not pa_window_is_showing() then
        return
    end

    if type(PartyAdWindow.RefreshAll) == "function" then
        PartyAdWindow.RefreshAll()
    elseif type(PartyAdWindow.RefreshCounts) == "function" then
        PartyAdWindow.RefreshCounts()
    end
end

function PartyAd.refresh_window_runtime_state()
    if not pa_window_is_showing() then
        return
    end

    local refreshed = false
    if type(PartyAdWindow.RefreshCounts) == "function" then
        PartyAdWindow.RefreshCounts()
        refreshed = true
    end
    if type(PartyAdWindow.RefreshOptions) == "function" then
        PartyAdWindow.RefreshOptions()
        refreshed = true
    end
    if type(PartyAdWindow.RefreshPreview) == "function" then
        PartyAdWindow.RefreshPreview()
        refreshed = true
    end

    if not refreshed and type(PartyAdWindow.RefreshAll) == "function" then
        PartyAdWindow.RefreshAll()
    end
end

function PartyAd.OnPartyUpdated()
    PartyAd.refresh_window_runtime_state()
end

-- Runtime event subscription helpers.
local function pa_get_runtime_events()
    if not (SystemData and type(SystemData.Events) == "table") then
        return nil
    end

    local events = {}
    local defs = SystemData.Events
    if defs.GROUP_UPDATED ~= nil then
        events[#events + 1] = defs.GROUP_UPDATED
    end
    if defs.BATTLEGROUP_UPDATED ~= nil then
        events[#events + 1] = defs.BATTLEGROUP_UPDATED
    end
    if defs.GROUP_LEAVE ~= nil then
        events[#events + 1] = defs.GROUP_LEAVE
    end

    if #events == 0 then
        return nil
    end
    return events
end

local function pa_for_each_runtime_event(callback)
    if type(callback) ~= "function" then
        return false
    end

    local events = pa_get_runtime_events()
    if not events then
        return false
    end

    local i
    for i = 1, #events do
        callback(events[i])
    end
    return true
end

function PartyAd.register_runtime_events()
    if PartyAd._runtime_events_registered == true then
        return
    end
    if type(RegisterEventHandler) ~= "function" then
        return
    end

    local registered = pa_for_each_runtime_event(function(event_id)
        RegisterEventHandler(event_id, "PartyAd.OnPartyUpdated")
    end)
    if not registered then
        return
    end
    PartyAd._runtime_events_registered = true
end

function PartyAd.unregister_runtime_events()
    if PartyAd._runtime_events_registered ~= true then
        return
    end
    if type(UnregisterEventHandler) ~= "function" then
        return
    end

    local unregistered = pa_for_each_runtime_event(function(event_id)
        UnregisterEventHandler(event_id, "PartyAd.OnPartyUpdated")
    end)
    if not unregistered then
        PartyAd._runtime_events_registered = false
        return
    end
    PartyAd._runtime_events_registered = false
end

-- Addon lifecycle entrypoints.
function PartyAd.Initialize()
    PartyAd.ensure_saved_defaults()
    PartyAd._runtime_events_registered = false

    if LibSlash and type(LibSlash.RegisterSlashCmd) == "function" then
        if not (LibSlash.IsSlashCmdRegistered and LibSlash.IsSlashCmdRegistered("partyad")) then
            LibSlash.RegisterSlashCmd("partyad", function(msg) PartyAd.on_slash(msg) end)
        end
    end

    if pa_window_is_showing() then
        PartyAd.register_runtime_events()
    end

    PartyAd.print("Loaded. Use /partyad to open the window.")
end

function PartyAd.Shutdown()
    PartyAd.unregister_runtime_events()
end
