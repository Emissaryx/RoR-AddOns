<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
<UiMod name="PartyAd" version="0.2.0" date="2026-05-04">
    <Author name="Wholdar" email="no@way" />
    <VersionSettings gameVersion="1.4.8" windowsVersion="1.0" savedVariablesVersion="1.0" />
    <Description text="Small party recruitment helper: set role targets, update /partynote, advertise in /5, and optionally spot LFG candidates." />

    <WARInfo>
        <Categories>
            <Category name="GROUPING" />
        </Categories>
    </WARInfo>

    <Dependencies>
        <Dependency name="LibSlash"/>
        <Dependency name="EASystem_Strings"/>
    </Dependencies>

    <Files>
        <File name="PartyAdCore.lua"/>
        <File name="PartyAdCommands.lua"/>
        <File name="PartyAdLifecycle.lua"/>
        <File name="PartyAdWindow.xml"/>
    </Files>

    <SavedVariables>
        <SavedVariable name="PartyAd.saved"/>
    </SavedVariables>

    <OnInitialize>
        <CallFunction name="PartyAd.Initialize"/>
        <CreateWindow name="PartyAdWindow" show="false"/>
        <CreateWindow name="PartyAdLfgScanWindow" show="false"/>
    </OnInitialize>

    <OnShutdown>
        <CallFunction name="PartyAd.Shutdown"/>
    </OnShutdown>
</UiMod>
</ModuleFile>
