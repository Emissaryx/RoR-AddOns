# Changelog
All notable changes to this project are documented in this file.

## About PartyAd
PartyAd is a Return of Reckoning addon for single-party recruiting.
It helps party leaders set role targets, choose a party purpose, update or clear `/partynote`, advertise current needs in `/5`, and optionally spot likely solo LFG candidates.

## [0.2.1] - 2026-05-15

### Changed
- Aligned LFG scan include/exclude phrases to keep more solo-candidate posts while filtering recruiter and abbreviation-chatter lines.
- Added inline icons to purpose presets so `/partynote` and `/5` previews/ads show the selected activity more clearly.

## [0.2.0] - 2026-05-04

### Added
- Added the optional `Scan /5 (/lfg)` UI toggle and attached `/5 Candidates` side window.
- Shows likely solo LFG players from `/5` and clear LFG messages from `/3`, including recent chat when the window opens.
- Shows matched chat lines and discovered players in separate sections, with clickable player names, full-message tooltips, and muted rows for players already in your party.
- Recognizes common role, career, dungeon, and abbreviation phrasing while filtering out group or warband recruiting messages.
- Can show extra character details when available, including killboard links.
- Shows an estimated role and `CR??` for discovered players when no character details are available.

### Changed
- When switching from detected-role mode to `Needed roles` mode with 6 configured targets, deduct the addon user's own role once so direct needed-role counters total at most 5.
- Main window title now includes the addon version.

## [0.1.1] - 2026-05-02

### Changed
- Added filled/wanted progress after role needs in `/5` ads when detected-role steering is enabled.
- Added the same progress marker to `/partynote` only when it fits within the 69-character cap.
- Changed the role target UI header to `Needed roles` when detected-role steering is disabled.
- Omitted filled/wanted progress in target-only `Needed roles` mode.

## [0.1.0] - 2026-02-13
Initial documented release baseline.

### Added
- Core party-target logic for `Tank/Healer/DPS` with normalization to a 6-player party cap.
- Purpose system with preset support, realm-aware dungeon preset filtering, and `Custom...` text mode.
- `/partynote` text builder with `[PA]` prefix and a 69-character cap.
- `/5` advertise text builder including purpose, missing roles, and clickable leader mention formatting.
- Slash command surface:
  - `/partyad`
  - `/partyad update note`
  - `/partyad clear note`
  - `/partyad advertise`
  - `/partyad targets <t> <h> <d>`
  - `/partyad purpose <text>`
  - `/partyad purposepreset <name|custom>`
  - `/partyad altspec <on|off|toggle>`
  - `/partyad detectedroles <on|off|toggle>`
  - `/partyad yourrole <auto|tank|healer|dps>`
  - `/partyad status`
- PartyAd window UI for targets, purpose selection, detection options, self-role override, previews, and action buttons.
- Alt-spec role steering via `RoRGroupScoreboard.playersDataRaw` (healer careers in DPS spec count as DPS).
- Toggle to compute missing-role needs from detected current roles or from configured targets only.
- Self-role override for local player (`auto|tank|healer|dps`).
