PartyAd = PartyAd or {}

-- Slash-command parsing and command handlers.
local function pa_split_args(msg)
    local args = {}
    local text = tostring(msg or "")
    for token in string.gmatch(text, "%S+") do
        args[#args + 1] = token
    end
    return args
end

local function pa_lower(value)
    return string.lower(tostring(value or ""))
end

local function pa_parse_toggle_arg(value)
    local arg = pa_lower(value)
    if arg == "on" then
        return true
    end
    if arg == "off" then
        return false
    end
    if arg == "toggle" then
        return "toggle"
    end
    return nil
end

local function pa_apply_toggle(saved_key, value)
    local parsed = pa_parse_toggle_arg(value)
    if parsed == nil then
        return false
    end
    local next_state
    if parsed == "toggle" then
        next_state = PartyAd.saved[saved_key] ~= true
    else
        next_state = parsed
    end

    if saved_key == "use_detected_roles_for_needs" then
        PartyAd.set_use_detected_roles_for_needs(next_state)
        return true
    end
    if saved_key == "use_lfg_scan" and type(PartyAd.set_use_lfg_scan) == "function" then
        PartyAd.set_use_lfg_scan(next_state)
        return true
    end
    PartyAd.saved[saved_key] = next_state
    return true
end

local function pa_normalize_self_role(value)
    local role = pa_lower(value)
    if role == PartyAd.SELF_ROLE_AUTO then
        return PartyAd.SELF_ROLE_AUTO
    end
    if role == PartyAd.ROLE_TANK then
        return PartyAd.ROLE_TANK
    end
    if role == PartyAd.ROLE_HEALER or role == "heal" then
        return PartyAd.ROLE_HEALER
    end
    if role == PartyAd.ROLE_DPS or role == "mdps" or role == "rdps" then
        return PartyAd.ROLE_DPS
    end
    return nil
end

local function pa_print_purpose_status()
    local purpose = PartyAd.get_purpose()
    if purpose == "" then
        PartyAd.print("Purpose text: (empty)")
        return
    end
    PartyAd.print("Purpose text: " .. purpose)
end

function PartyAd.print_help()
    PartyAd.print("/partyad to toggle the UI.")
    PartyAd.print("/partyad update note, /partyad advertise, /partyad clear note")
    PartyAd.print("/partyad targets <t> <h> <d>, /partyad purpose <text>, /partyad purposepreset <name|custom>")
    PartyAd.print("/partyad altspec <on|off|toggle>, /partyad lfgscan <on|off|toggle>")
    PartyAd.print("/partyad detectedroles <on|off|toggle>, /partyad yourrole <auto|tank|healer|dps>, /partyad status")
end

function PartyAd.print_status()
    local missing, counts = PartyAd.get_missing_counts()
    PartyAd.print("Targets: " .. tostring(PartyAd.saved.desired_tanks) .. "T/" .. tostring(PartyAd.saved.desired_healers) .. "H/" .. tostring(PartyAd.saved.desired_dps) .. "D")
    PartyAd.print("Purpose preset: " .. PartyAd.get_purpose_mode())
    pa_print_purpose_status()
    PartyAd.print("Enable alt-spec check: " .. tostring(PartyAd.saved.use_scoreboard_spec_check == true))
    PartyAd.print("Scan /5 (/lfg): " .. tostring(PartyAd.saved.use_lfg_scan == true))
    PartyAd.print("Use detected roles for note/ad numbers: " .. tostring(PartyAd.saved.use_detected_roles_for_needs == true))
    PartyAd.print("Your role: " .. PartyAd.get_self_role_override())
    PartyAd.print(PartyAd.format_current_summary(counts))
    PartyAd.print(PartyAd.format_missing_summary(missing))
end

local function pa_call_window_action(action_name)
    if PartyAdWindow and type(PartyAdWindow[action_name]) == "function" then
        PartyAdWindow[action_name]()
    end
end

local function pa_toggle_window()
    pa_call_window_action("Toggle")
end

-- Shared for slash handlers that mutate state and should repaint immediately.
local function pa_run_with_window_refresh(action_fn)
    if type(action_fn) == "function" then
        action_fn()
    end
    PartyAd.refresh_window()
end

local function pa_print_current_purpose()
    local purpose = PartyAd.get_purpose()
    PartyAd.print("Purpose: " .. (purpose ~= "" and purpose or "(empty)"))
end

local function pa_handle_show()
    pa_call_window_action("Show")
end

local function pa_handle_hide()
    pa_call_window_action("Hide")
end

local function pa_handle_updatenote()
    pa_run_with_window_refresh(PartyAd.apply_partynote)
end

local function pa_handle_advertise()
    pa_run_with_window_refresh(PartyAd.advertise_lfg)
end

local function pa_handle_clearnote()
    pa_run_with_window_refresh(function()
        PartyAd.clear_partynote(true)
    end)
end

local function pa_handle_targets(args)
    if #args < 4 then
        PartyAd.print("Usage: /partyad targets <tanks> <healers> <dps>")
        return
    end

    PartyAd.saved.desired_tanks = tonumber(args[2]) or 0
    PartyAd.saved.desired_healers = tonumber(args[3]) or 0
    PartyAd.saved.desired_dps = tonumber(args[4]) or 0
    PartyAd.normalize_targets()
    PartyAd.refresh_window()
    PartyAd.print_status()
end

local function pa_handle_purpose(_, raw_msg)
    local purpose = tostring(raw_msg or "")
    purpose = string.gsub(purpose, "^%s*[^%s]+", "")
    PartyAd.set_purpose(purpose)
    PartyAd.refresh_window()
    pa_print_current_purpose()
end

local function pa_handle_purposepreset(args)
    if #args < 2 then
        local menu = PartyAd.get_purpose_menu()
        local labels = {}
        for i = 1, #menu do
            labels[#labels + 1] = tostring(menu[i].key)
        end
        PartyAd.print("Usage: /partyad purposepreset <" .. table.concat(labels, "|") .. ">")
        return
    end

    local key = pa_lower(args[2])
    local ok = PartyAd.set_purpose_mode(key)
    if not ok then
        PartyAd.print("[Error] Unknown preset: " .. tostring(args[2] or ""))
        return
    end
    PartyAd.refresh_window()
    pa_print_current_purpose()
end

local function pa_handle_toggle_setting(args, saved_key, status_label, usage)
    if #args < 2 then
        PartyAd.print(status_label .. tostring(PartyAd.saved[saved_key] == true))
        PartyAd.print("Usage: " .. usage)
        return
    end
    if not pa_apply_toggle(saved_key, args[2]) then
        PartyAd.print("Usage: " .. usage)
        return
    end
    PartyAd.refresh_window()
    PartyAd.print(status_label .. tostring(PartyAd.saved[saved_key] == true))
end

local function pa_handle_altspec(args)
    pa_handle_toggle_setting(args, "use_scoreboard_spec_check", "Enable alt-spec check: ", "/partyad altspec <on|off|toggle>")
end

local function pa_handle_lfgscan(args)
    pa_handle_toggle_setting(args, "use_lfg_scan", "Scan /5 (/lfg): ", "/partyad lfgscan <on|off|toggle>")
end

local function pa_print_lfgdebug_help()
    PartyAd.print("Usage: /partyad lfgdebug [on|off|toggle|status] [count]")
    PartyAd.print("Usage: /partyad lfgdebug search <name>")
    PartyAd.print("Usage: /partyad lfgdebug populate|clear")
    PartyAd.print("Usage: /partyad lfgdebug noautoband|autoband [on|off|toggle]")
end

local function pa_handle_lfgdebug_autoband(args, enables_lookup)
    if type(PartyAd.set_lfg_scan_autoband_lookup_disabled) ~= "function" then
        return
    end

    local parsed = pa_parse_toggle_arg(args[3])
    local current_lookup_enabled = PartyAd._lfg_scan_disable_autoband_lookup ~= true
    local next_lookup_enabled
    if parsed == nil or parsed == "toggle" then
        next_lookup_enabled = not current_lookup_enabled
    elseif enables_lookup then
        next_lookup_enabled = parsed == true
    else
        next_lookup_enabled = parsed ~= true
    end
    PartyAd.set_lfg_scan_autoband_lookup_disabled(not next_lookup_enabled)
end

local function pa_handle_lfgdebug(args)
    if type(PartyAd.set_lfg_scan_debug_enabled) ~= "function" then
        return
    end

    local subcommand = pa_lower(args[2])
    if subcommand == "help" then
        pa_print_lfgdebug_help()
        return
    end

    if subcommand == "status" then
        if type(PartyAd.print_lfg_scan_debug_status) == "function" then
            PartyAd.print_lfg_scan_debug_status()
        end
        PartyAd.print_lfg_scan_debug(tonumber(args[3]) or 3)
        return
    end

    if subcommand == "search" then
        if type(PartyAd.start_lfg_social_debug_search) ~= "function" then
            return
        end
        PartyAd.start_lfg_social_debug_search(args[3])
        return
    end

    if subcommand == "populate" then
        if type(PartyAd.populate_lfg_scan_debug_fixture) == "function" then
            PartyAd.populate_lfg_scan_debug_fixture()
        end
        return
    end

    if subcommand == "clear" then
        if type(PartyAd.clear_lfg_candidates) == "function" then
            PartyAd.clear_lfg_candidates()
        end
        if PartyAdWindow and type(PartyAdWindow.RefreshLfgScanWindowState) == "function" then
            PartyAdWindow.RefreshLfgScanWindowState()
        end
        PartyAd.print("LFG debug candidates cleared.")
        return
    end

    if subcommand == "noautoband" then
        pa_handle_lfgdebug_autoband(args, false)
        return
    end

    if subcommand == "autoband" then
        pa_handle_lfgdebug_autoband(args, true)
        return
    end

    local parsed = pa_parse_toggle_arg(args[2])
    local count = tonumber(args[3]) or tonumber(args[2]) or 3
    if parsed == true or parsed == false then
        PartyAd.set_lfg_scan_debug_enabled(parsed, count)
        return
    end
    if parsed == "toggle" or args[2] == nil or tonumber(args[2]) ~= nil then
        PartyAd.toggle_lfg_scan_debug(count)
        return
    end

    pa_print_lfgdebug_help()
end

local function pa_handle_detectedroles(args)
    pa_handle_toggle_setting(args, "use_detected_roles_for_needs", "Use detected roles for note/ad numbers: ", "/partyad detectedroles <on|off|toggle>")
end

local function pa_handle_yourrole(args)
    if #args < 2 then
        PartyAd.print("Your role: " .. PartyAd.get_self_role_override())
        PartyAd.print("Usage: /partyad yourrole <auto|tank|healer|dps>")
        return
    end

    local normalized = pa_normalize_self_role(args[2])
    if not normalized then
        PartyAd.print("Usage: /partyad yourrole <auto|tank|healer|dps>")
        return
    end

    PartyAd.saved.self_role_override = normalized
    PartyAd.refresh_window()
    PartyAd.print("Your role: " .. PartyAd.get_self_role_override())
end

local function pa_resolve_command(args)
    local cmd = pa_lower(args[1])
    if cmd == "update" and pa_lower(args[2]) == "note" then
        return "updatenote"
    end
    if cmd == "clear" and pa_lower(args[2]) == "note" then
        return "clearnote"
    end
    return cmd
end

local PA_SLASH_HANDLERS = {
    show = pa_handle_show,
    hide = pa_handle_hide,
    updatenote = pa_handle_updatenote,
    advertise = pa_handle_advertise,
    clearnote = pa_handle_clearnote,
    targets = pa_handle_targets,
    purpose = pa_handle_purpose,
    purposepreset = pa_handle_purposepreset,
    altspec = pa_handle_altspec,
    lfgscan = pa_handle_lfgscan,
    lfgdebug = pa_handle_lfgdebug,
    detectedroles = pa_handle_detectedroles,
    yourrole = pa_handle_yourrole,
    status = PartyAd.print_status,
    help = PartyAd.print_help,
}

function PartyAd.on_slash(msg)
    local args = pa_split_args(msg)
    if #args == 0 then
        pa_toggle_window()
        return
    end

    local cmd = pa_resolve_command(args)
    local handler = PA_SLASH_HANDLERS[cmd]
    if type(handler) == "function" then
        handler(args, msg)
    else
        PartyAd.print_help()
    end
end
