PartyAd = PartyAd or {}

-- UI refresh hooks triggered by runtime events/actions.
local function pa_window_is_showing()
    if not PartyAdWindow then
        return false
    end

    if type(PartyAdWindow.IsShowing) == "function" then
        return PartyAdWindow.IsShowing()
    end

    if type(PartyAdWindow.showing) == "function" then
        return PartyAdWindow.showing()
    end

    return false
end

function PartyAd.refresh_window()
    if not pa_window_is_showing() then
        return
    end

    if type(PartyAdWindow.RefreshAll) == "function" then
        PartyAdWindow.RefreshAll()
    elseif type(PartyAdWindow.RefreshCounts) == "function" then
        PartyAdWindow.RefreshCounts()
    end
end

function PartyAd.refresh_window_runtime_state()
    if not pa_window_is_showing() then
        return
    end

    local refreshed = false
    if type(PartyAdWindow.RefreshCounts) == "function" then
        PartyAdWindow.RefreshCounts()
        refreshed = true
    end
    if type(PartyAdWindow.RefreshOptions) == "function" then
        PartyAdWindow.RefreshOptions()
        refreshed = true
    end
    if type(PartyAdWindow.RefreshPreview) == "function" then
        PartyAdWindow.RefreshPreview()
        refreshed = true
    end

    if not refreshed and type(PartyAdWindow.RefreshAll) == "function" then
        PartyAdWindow.RefreshAll()
    end
end

function PartyAd.OnPartyUpdated()
    local changed = 0
    if type(PartyAd.update_lfg_candidate_party_status) == "function" then
        changed = PartyAd.update_lfg_candidate_party_status()
    end
    PartyAd.refresh_window_runtime_state()
    if changed > 0 and PartyAdWindow and type(PartyAdWindow.RefreshLfgScan) == "function" then
        PartyAdWindow.RefreshLfgScan()
    end
end

-- Runtime event subscription helpers.
local function pa_get_runtime_events()
    if not (SystemData and type(SystemData.Events) == "table") then
        return nil
    end

    local events = {}
    local defs = SystemData.Events
    if defs.GROUP_UPDATED ~= nil then
        events[#events + 1] = defs.GROUP_UPDATED
    end
    if defs.BATTLEGROUP_UPDATED ~= nil then
        events[#events + 1] = defs.BATTLEGROUP_UPDATED
    end
    if defs.GROUP_LEAVE ~= nil then
        events[#events + 1] = defs.GROUP_LEAVE
    end

    if #events == 0 then
        return nil
    end
    return events
end

local function pa_for_each_runtime_event(callback)
    if type(callback) ~= "function" then
        return false
    end

    local events = pa_get_runtime_events()
    if not events then
        return false
    end

    for i = 1, #events do
        callback(events[i])
    end
    return true
end

-- LFG scan subscription helpers.
local function pa_get_lfg_scan_event()
    if type(TextLogGetUpdateEventId) ~= "function" then
        return nil
    end

    local ok, event_id = pcall(TextLogGetUpdateEventId, "Chat")
    if not ok then
        return nil
    end
    return event_id
end

local function pa_lfg_scan_should_be_registered()
    if not (PartyAd.saved and PartyAd.saved.use_lfg_scan == true) then
        return false
    end
    return pa_window_is_showing()
end

function PartyAd.register_lfg_scan_event()
    if PartyAd._lfg_scan_event_registered == true then
        return
    end
    if type(RegisterEventHandler) ~= "function" then
        return
    end

    local event_id = pa_get_lfg_scan_event()
    if event_id == nil then
        return
    end

    RegisterEventHandler(event_id, "PartyAd.OnChatLogUpdated")
    PartyAd._lfg_scan_event_registered = true
end

function PartyAd.unregister_lfg_scan_event()
    if PartyAd._lfg_scan_event_registered ~= true then
        return
    end
    if type(UnregisterEventHandler) ~= "function" then
        PartyAd._lfg_scan_event_registered = false
        return
    end

    local event_id = pa_get_lfg_scan_event()
    if event_id ~= nil then
        UnregisterEventHandler(event_id, "PartyAd.OnChatLogUpdated")
    end
    PartyAd._lfg_scan_event_registered = false
end

local function pa_get_lfg_social_search_event()
    if not (SystemData and type(SystemData.Events) == "table") then
        return nil
    end
    return SystemData.Events.SOCIAL_SEARCH_UPDATED
end

function PartyAd.register_lfg_social_search_event()
    if PartyAd._lfg_social_search_event_registered == true then
        return
    end
    if type(RegisterEventHandler) ~= "function" then
        return
    end

    local event_id = pa_get_lfg_social_search_event()
    if event_id == nil then
        return
    end

    RegisterEventHandler(event_id, "PartyAd.OnSocialSearchUpdated")
    PartyAd._lfg_social_search_event_registered = true
end

function PartyAd.unregister_lfg_social_search_event()
    if PartyAd._lfg_social_search_event_registered ~= true then
        return
    end
    if type(UnregisterEventHandler) ~= "function" then
        PartyAd._lfg_social_search_event_registered = false
        return
    end

    local event_id = pa_get_lfg_social_search_event()
    if event_id ~= nil then
        UnregisterEventHandler(event_id, "PartyAd.OnSocialSearchUpdated")
    end
    PartyAd._lfg_social_search_event_registered = false
end

function PartyAd.sync_lfg_social_search_subscription()
    local has_work = false
    if type(PartyAd.has_lfg_social_lookup_work) == "function" then
        has_work = PartyAd.has_lfg_social_lookup_work()
    end

    if pa_lfg_scan_should_be_registered() and has_work then
        PartyAd.register_lfg_social_search_event()
    else
        PartyAd.unregister_lfg_social_search_event()
    end
end

function PartyAd.sync_lfg_scan_subscription()
    if pa_lfg_scan_should_be_registered() then
        PartyAd.register_lfg_scan_event()
    else
        PartyAd.unregister_lfg_scan_event()
        if type(PartyAd.cancel_lfg_social_lookup_queue) == "function" then
            PartyAd.cancel_lfg_social_lookup_queue(true)
        else
            PartyAd.unregister_lfg_social_search_event()
        end
        if type(PartyAd.cancel_lfg_social_debug_search) == "function" then
            PartyAd.cancel_lfg_social_debug_search(true)
        end
    end
    PartyAd.sync_lfg_social_search_subscription()
end

function PartyAd.OnChatLogUpdated(update_type, filter_type)
    if not (PartyAd.saved and PartyAd.saved.use_lfg_scan == true) then
        PartyAd.sync_lfg_scan_subscription()
        return
    end
    if not pa_window_is_showing() then
        PartyAd.sync_lfg_scan_subscription()
        return
    end

    local added = SystemData and SystemData.TextLogUpdate and SystemData.TextLogUpdate.ADDED
    if added ~= nil and update_type ~= added then
        return
    end
    if not (type(TextLogGetNumEntries) == "function" and type(TextLogGetEntry) == "function") then
        return
    end

    local ok_count, count = pcall(TextLogGetNumEntries, "Chat")
    if not ok_count or type(count) ~= "number" or count <= 0 then
        return
    end
    local ok_entry, _, entry_filter, text = pcall(TextLogGetEntry, "Chat", count - 1)
    if not ok_entry then
        return
    end

    PartyAd.handle_lfg_chat_message(entry_filter or filter_type, text, filter_type)
end

function PartyAd.OnSocialSearchUpdated()
    if not (PartyAd.saved and PartyAd.saved.use_lfg_scan == true) then
        PartyAd.unregister_lfg_social_search_event()
        return
    end
    if not pa_window_is_showing() then
        if type(PartyAd.cancel_lfg_social_lookup_queue) == "function" then
            PartyAd.cancel_lfg_social_lookup_queue(true)
        else
            PartyAd.unregister_lfg_social_search_event()
        end
        if type(PartyAd.cancel_lfg_social_debug_search) == "function" then
            PartyAd.cancel_lfg_social_debug_search(true)
        end
        PartyAd.sync_lfg_social_search_subscription()
        return
    end

    if type(PartyAd.handle_lfg_social_search_updated) == "function" then
        PartyAd.handle_lfg_social_search_updated()
    end
end

function PartyAd.register_runtime_events()
    if PartyAd._runtime_events_registered == true then
        return
    end
    if type(RegisterEventHandler) ~= "function" then
        return
    end

    local registered = pa_for_each_runtime_event(function(event_id)
        RegisterEventHandler(event_id, "PartyAd.OnPartyUpdated")
    end)
    if not registered then
        return
    end
    PartyAd._runtime_events_registered = true
end

function PartyAd.unregister_runtime_events()
    if PartyAd._runtime_events_registered ~= true then
        return
    end
    if type(UnregisterEventHandler) ~= "function" then
        return
    end

    local unregistered = pa_for_each_runtime_event(function(event_id)
        UnregisterEventHandler(event_id, "PartyAd.OnPartyUpdated")
    end)
    if not unregistered then
        PartyAd._runtime_events_registered = false
        return
    end
    PartyAd._runtime_events_registered = false
end

-- Addon lifecycle entrypoints.
function PartyAd.Initialize()
    PartyAd.ensure_saved_defaults()
    PartyAd._runtime_events_registered = false
    PartyAd._lfg_scan_event_registered = false
    PartyAd._lfg_social_search_event_registered = false
    PartyAd.copy_link_window_initialized = false

    if LibSlash and type(LibSlash.RegisterSlashCmd) == "function" then
        if not (LibSlash.IsSlashCmdRegistered and LibSlash.IsSlashCmdRegistered("partyad")) then
            LibSlash.RegisterSlashCmd("partyad", function(msg) PartyAd.on_slash(msg) end)
        end
    end

    if pa_window_is_showing() then
        PartyAd.register_runtime_events()
    end
    PartyAd.sync_lfg_scan_subscription()
    if type(PartyAd.seed_lfg_candidates_from_chat_log) == "function" then
        PartyAd.seed_lfg_candidates_from_chat_log()
    end

    PartyAd.print("Loaded. Use /partyad to open the window.")
end

function PartyAd.Shutdown()
    PartyAd.unregister_lfg_scan_event()
    PartyAd.unregister_lfg_social_search_event()
    PartyAd.unregister_runtime_events()
    if type(PartyAd.HideCopyLink) == "function" then
        PartyAd.HideCopyLink()
    end
    PartyAd.copy_link_window_initialized = false
end
