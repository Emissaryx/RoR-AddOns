-- This addon displays the next effect that can be cleansed off of a group member. The challenge is that the API does not provide a sorted list of the effects on a target. 
-- If a new effect is added than the next best slot in a table is filled. This addon tries to create and maintain a sorted list of groupmembers through the GROUP_EFFECTS_UPDATED event. 
-- Therefore allowing to determine the next cleansable effect on a groupmember

CB = CB or {}
local settings = {}
local currentTarget = 10000
local cleanseableEffects = {}
local groupMembers = {}
local activeGroupMember = 6

--this will run on start
function CB.OnInitialize()
	if not CB.SavedSettings then CB.SetDefaults() end
	settings = CB.SavedSettings
	RegisterEventHandler(SystemData.Events.PLAYER_TARGET_UPDATED,				"CB.PlayerTargetsUpdated")
	RegisterEventHandler(SystemData.Events.GROUP_EFFECTS_UPDATED, 				"CB.GroupEffectUpdated")
	RegisterEventHandler(SystemData.Events.PLAYER_EFFECTS_UPDATED, 				"CB.PlayerEffectUpdated")

	RegisterEventHandler(SystemData.Events.BATTLEGROUP_UPDATED, 				"CB.GroupPlayersUpdated")
	RegisterEventHandler(SystemData.Events.GROUP_PLAYER_ADDED, 					"CB.GroupPlayersUpdated")
	RegisterEventHandler(SystemData.Events.GROUP_UPDATED, 						"CB.GroupPlayersUpdated")
	RegisterEventHandler(SystemData.Events.SCENARIO_BEGIN, 						"CB.GroupPlayersUpdated")
    RegisterEventHandler(SystemData.Events.SCENARIO_END, 						"CB.GroupPlayersUpdated")
    RegisterEventHandler(SystemData.Events.SCENARIO_GROUP_LEAVE, 				"CB.GroupPlayersUpdated")
	RegisterEventHandler(SystemData.Events.SCENARIO_GROUP_JOIN, 				"CB.GroupPlayersUpdated")
	RegisterEventHandler(SystemData.Events.GROUP_STATUS_UPDATED, 				"CB.GroupPlayersUpdated")
	
	-- define cleanseable effect types
	playerCareer = GameData.Player.career.line	
	if (playerCareer == GameData.CareerLine.WARRIOR_PRIEST or playerCareer == GameData.CareerLine.ZEALOT) then
		settings.canCleanseHex = true
		settings.canCleanseAilment = false
		settings.canCleanseCurse = true		
	elseif (playerCareer == GameData.CareerLine.DISCIPLE or playerCareer == GameData.CareerLine.ARCHMAGE) then
		settings.canCleanseHex = true
		settings.canCleanseAilment = true
		settings.canCleanseCurse = false
	elseif (playerCareer == GameData.CareerLine.SHAMAN or playerCareer == GameData.CareerLine.RUNE_PRIEST) then
		settings.canCleanseHex = false
		settings.canCleanseAilment = true
		settings.canCleanseCurse = true
	else -- this addon will do nothing for you
		CB.OnShutdown()
	end
	
	for i=1,6 do
		cleanseableEffects[i] = {}
	end
	
	groupMembers[6] = wstring.sub(GameData.Player.name,1,-3)
	CreateWindow("CBMainWindow", true)
	LayoutEditor.RegisterWindow( "CBMainWindow", L"CB", L"Cleansing Buddy", true, true, false, nil)
	end

--this will run on exit
function CB.OnShutdown()	
	UnregisterEventHandler(SystemData.Events.PLAYER_TARGET_UPDATED,				"CB.PlayerTargetsUpdated")
	UnregisterEventHandler(SystemData.Events.GROUP_EFFECTS_UPDATED, 			"CB.GroupEffectUpdated")
	UnregisterEventHandler(SystemData.Events.PLAYER_EFFECTS_UPDATED, 			"CB.PlayerEffectUpdated")
	
	UnregisterEventHandler(SystemData.Events.BATTLEGROUP_UPDATED, 				"CB.GroupPlayersUpdated")
	UnregisterEventHandler(SystemData.Events.GROUP_PLAYER_ADDED, 				"CB.GroupPlayersUpdated")
	UnregisterEventHandler(SystemData.Events.GROUP_UPDATED, 					"CB.GroupPlayersUpdated")
	UnregisterEventHandler(SystemData.Events.SCENARIO_BEGIN, 					"CB.GroupPlayersUpdated")
    UnregisterEventHandler(SystemData.Events.SCENARIO_END, 						"CB.GroupPlayersUpdated")
    UnregisterEventHandler(SystemData.Events.SCENARIO_GROUP_LEAVE, 				"CB.GroupPlayersUpdated")
	UnregisterEventHandler(SystemData.Events.SCENARIO_GROUP_JOIN, 				"CB.GroupPlayersUpdated")
	UnregisterEventHandler(SystemData.Events.GROUP_STATUS_UPDATED, 				"CB.GroupPlayersUpdated")
end

function CB.SetDefaults()
	CB.SavedSettings = {}
	CB.SavedSettings.IDs = {}
	IDs = 	{2,431,1358,1387,1509,1542,1670,1692,1727,1825,1831,1878,1914,1927,2815,3012,3248,3262,3280,3289,  -- these are all snares
					3302,3311,3319,3438,3465,3468,3500,3963,3981,4213,8012,8080,8154,8255,8324,8377,8396,8484,8499,8527, 
					9004,9057,9092,9251,9255,9318,9348,9387,9394,9479,9549,10533,10544,10555,10566,10715,14430,14900, 
					9249,1911,8418,9192,1691,1772,1464,8165,9475,9349,8419,1756,1444,3443,9333,1690,8424,8431,3060,  -- these are other important ids
					3220,3218,1850,1521,3368,3028,3540,3178,1676,3032,3033,3630,8541,3569,3915,1410,1633,9109,1434, 
					9191,8112,8099,9373,1773,1746,9602,8401,1905,1853,9424,9407,3075}
	for _,x in ipairs(IDs) do CB.SavedSettings.IDs[x] = true end
end

--identify group members and activate the correct effect tracker
function CB.PlayerTargetsUpdated(targetClassification,targetId,targetType)
	TargetInfo:UpdateFromClient()
	local targetName = CB.fixName(TargetInfo:UnitName("selffriendlytarget"))
	local targetId = TargetInfo:UnitEntityId(targetClassification)
	-- check if the target is selected and if its a new target
	if(targetClassification == "selffriendlytarget") and (currentTarget ~= targetId) then
		activeGroupMember = 0 -- target not a groupMember --> No reliable information
		for groupSlot,playerName in pairs(groupMembers) do
				if targetName == playerName then 
				activeGroupMember = tonumber(groupSlot)
				break
			end
		end
		CB.UpdateIconDisplay()
		currentTarget = targetId
	end
end

function CB.RemoveEffectFromQue(Que, effectIndex)
	for effectQueNumber, cleansableKeys in pairs(Que) do
		if tonumber(cleansableKeys.effectIndex) == tonumber(effectIndex) then
			table.remove(Que, effectQueNumber)
		end
	end
end

function CB.UpdateEffectList(GroupMemberNr, BuffTable)
	if (BuffTable ~= nil) then
		for effectIndex, keys in pairs(BuffTable) do
			if keys.name == nil then -- the server sends an empty table so signal that an effect has ended
				CB.RemoveEffectFromQue(cleanseableEffects[GroupMemberNr], effectIndex)
			elseif (keys.isAilment == settings.canCleanseAilment) or (keys.isCurse == settings.canCleanseCurse) or (keys.isHex == settings.canCleanseHex) then
				-- When a running effect gets reapplied it maintains its effectIndex but needs to move back in the sorted list --> remove effect from list and add it at the end again 
				CB.RemoveEffectFromQue(cleanseableEffects[GroupMemberNr], effectIndex)
				cleanseableEffects[GroupMemberNr][#cleanseableEffects[GroupMemberNr]+1] = {["iconNum"]  = keys.iconNum, ["effectIndex"] = keys.effectIndex, ["abilityId"] = keys.abilityId}
			end
		end
		CB.UpdateIconDisplay()
	end
end

function CB.GroupPlayersUpdated()
local groupData = GetGroupData()
	for tableNum, keys in pairs(groupData) do
		local grpNumber = tonumber(tableNum)
		if  groupMembers[grpNumber] ~= keys.name then
			d("Group Setup Changed")
			groupMembers[grpNumber] = keys.name
			for k,v in pairs(cleanseableEffects[grpNumber]) do cleanseableEffects[grpNumber][k] = nil end -- reset cleanseableEffects list
		end
	end
end

function CB.PlayerEffectUpdated(BuffTable,isFullList)
	local GroupMemberNr = 6
	CB.UpdateEffectList(GroupMemberNr, BuffTable)
end

function CB.GroupEffectUpdated(GroupMemberNr,BuffTable,isFullList)
	local GroupMemberNr = GroupMemberNr + 1
	CB.UpdateEffectList(GroupMemberNr, BuffTable)
end

function CB.PlayerTargetEffectUpdated(TargetType, BuffTable, isFullList) -- isFullList appears to be always false. Probably not implemented serverside
		-- if (BuffTable ~= nil) and (TargetType == 8) then --  TargetType = 8 --> Friendly Target
		-- Run through the entire table and look at each effect
end

function CB.UpdateIconDisplay()
	if activeGroupMember == 0 then 
		if DoesWindowExist("NextCleanse") then DestroyWindow("NextCleanse") end-- destory window if target is not a group member
	elseif (cleanseableEffects[activeGroupMember][1] == nil) and DoesWindowExist("NextCleanse") then DestroyWindow("NextCleanse") -- destory the window if there are no cleanseable effects
	elseif cleanseableEffects[activeGroupMember][1] ~= nil then
		if (not DoesWindowExist("NextCleanseIcon")) then CreateWindowFromTemplate("NextCleanse", "CBBuffTemplate", "CBMainWindow") end
		local texture, x, y, disabledTexture = GetIconData(cleanseableEffects[activeGroupMember][1].iconNum)
		if settings.IDs[cleanseableEffects[activeGroupMember][1].abilityId] then
			DynamicImageSetTexture("NextCleanseIcon", texture, x, y)
		else
			DynamicImageSetTexture("NextCleanseIcon", disabledTexture, x, y)
		end	
	end
end

function CB.fixName(name)
	if not name then return nil end
	local pos = name:find (L"^", 1, true);
	if (pos) then name = name:sub (1, pos - 1); end	
	return name;
end


-- Config functions past this point
-- /script CB.AddID(abilityID)
function CB.AddID(abilityID)
	CB.SavedSettings.IDs[abilityID] = true
end

-- /script CB.RemoveID(abilityID)
function CB.RemoveID(abilityID)
	CB.SavedSettings.IDs[abilityID] = nil
end

