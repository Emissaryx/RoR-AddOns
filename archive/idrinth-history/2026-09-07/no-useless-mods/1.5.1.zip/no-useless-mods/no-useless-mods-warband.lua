BattlegroupHUD = {}
BattlegroupHUD.OnMenuClickMakeMainAssist = function()
    if( ButtonGetDisabledFlag(SystemData.ActiveWindow.name ) == false ) then
    	BroadcastEvent( SystemData.Events.GROUP_SET_MAIN_ASSIST )
    end    
end
BattlegroupHUD.OnMenuClickLeaveGroup = function()
    BroadcastEvent( SystemData.Events.GROUP_LEAVE )
end
BattlegroupHUD.OnMenuClickMakeLeader = function()    
    SendChatText( L"/warbandleader "..SystemData.UserInput.selectedGroupMember, L"" )
end