<?xml version="1.0" encoding="UTF-8"?>

<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" >

	<UiMod name="NoUselessMods-Video" version="1.0.1" date="2021-03-12" >

		<Author name="Idrinth" />
		
		<VersionSettings gameVersion="1.4.8" windowsVersion="1.0" savedVariablesVersion="1.0" />

		<Description text="Disables useless mods" />
		<Replaces name="EA_VideoPlayer" />
	</UiMod>

</ModuleFile>