local wstc = WindowSetTintColor;
WindowSetTintColor = function(window, r, g, b)
	if DoesWindowExist(window) then
		wstc(window, r, g, b)
	end
end
local dist = DynamicImageSetTexture;
DynamicImageSetTexture = function(window, texture, num1, num2)
	if DoesWindowExist(window) then
		dist(window, texture, num1, num2)
	end
end
local bsdf = ButtonSetDisabledFlag;
ButtonSetDisabledFlag = function(button, able)
	if DoesWindowExist(button) then
		bsdf(button, able)
	end
end
local wss = WindowSetShowing;
WindowSetShowing = function(window, able)
	if DoesWindowExist(window) then
		wss(window, able)
	end
end
local wreh = WindowRegisterEventHandler;
WindowRegisterEventHandler = function(window, event, handler)
	if DoesWindowExist(window) then
		wreh(window, event, handler)
	end
end