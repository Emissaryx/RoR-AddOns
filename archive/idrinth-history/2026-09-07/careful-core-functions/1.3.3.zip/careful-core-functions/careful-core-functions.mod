<?xml version="1.0" encoding="UTF-8"?>

<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" >

	<UiMod name="Careful Core Functions" version="1.3.3" date="2021-03-21" >

		<Author name="Idrinth" />
		
		<VersionSettings gameVersion="1.4.8" windowsVersion="1.0" savedVariablesVersion="1.0" />

		<Files>
            <File name="careful-core-functions.lua" />
		</Files>
		<Description text="Makes functions check before trying to modify none-existing windows" />
	</UiMod>

</ModuleFile>