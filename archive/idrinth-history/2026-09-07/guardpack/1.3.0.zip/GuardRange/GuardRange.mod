<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
	<UiMod name="GuardRange" version="1.3" date="10/10/2022" >

		<Author name="Sullemunk"/>
		<Description text="MultiGuard Range" />
		
        <Dependencies>
			<Dependency name="LibGuard" />
        </Dependencies>
        
		<SavedVariables>
        	<SavedVariable name="GuardRange.Settings" />
        </SavedVariables> 
        
		<Files>
			<File name="GuardRange.xml" />
		</Files>
		
		<OnInitialize>
            <CallFunction name="GuardRange.Initialize" />
		</OnInitialize>
		<OnUpdate>
        </OnUpdate>
		<OnShutdown/>
		
	</UiMod>
</ModuleFile>
