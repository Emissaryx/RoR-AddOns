WarBoard_Loc = {}

local TIME_DELAY = 1
local timeleft = TIME_DELAY 

function WarBoard_Loc.Initialize()
	if ( WarBoard.AddMod( "WarBoard_Loc" ) ) then
		d( "WarBoard_Location Module Loaded" )
		
		RegisterEventHandler( SystemData.Events.PLAYER_POSITION_UPDATED, "WarBoard_Loc.OnPlayerPositionUpdated" )

		WindowSetShowing("WarBoard_Loc_lblHidden", false)

		WarBoard_Loc.OnPlayerPositionUpdated(1)

		LabelSetTextColor("WarBoard_Loc_lblLocation2", 0, 185, 174)
	end
end


function WarBoard_Loc.Convert(num)
	num = num / 1000
	
	return towstring(tostring(string.format("%.2f",num)))
	
end


function WarBoard_Loc.OnPlayerPositionUpdated(elapsed)
	timeleft = timeleft - elapsed
	if timeleft > 0 then
		return
	end
	timeleft = TIME_DELAY

	local px, py = WarBoard_Loc.Convert(LibSurveyor.PlayerLocation.zoneX),WarBoard_Loc.Convert(LibSurveyor.PlayerLocation.zoneY)

	
	if (LibSurveyor.PlayerLocation.zoneX == 0) or (LibSurveyor.PlayerLocation.zoney == 0) then
                LabelSetText( "WarBoard_Loc_lblHidden", towstring( GetZoneName( GameData.Player.zone ) ) )
		local xwidth, xheight = LabelGetTextDimensions("WarBoard_Loc_lblHidden")
		WindowSetDimensions("WarBoard_Loc", 200, 30)
		WindowSetDimensions("WarBoard_Loc_lblLocation" , 200, 30)
		WindowSetDimensions("WarBoard_Loc_lblLocation3", 200, 30)
		WindowSetDimensions("WarBoard_Loc_lblLocation2", 200, 30)	
		LabelSetText( "WarBoard_Loc_lblLocation" , L"" )
		LabelSetText( "WarBoard_Loc_lblLocation2", L"" )
		LabelSetText( "WarBoard_Loc_lblLocation3", towstring( GetZoneName( GameData.Player.zone ) ) )
	else
		LabelSetText( "WarBoard_Loc_lblHidden", towstring( GetZoneName( GameData.Player.zone ) ) )
		local xwidth, xheight = LabelGetTextDimensions("WarBoard_Loc_lblHidden")
		WindowSetDimensions("WarBoard_Loc", 200, 30)
		WindowSetDimensions("WarBoard_Loc_lblLocation" , 200, 30)
		WindowSetDimensions("WarBoard_Loc_lblLocation2", 200, 30)
		WindowSetDimensions("WarBoard_Loc_lblLocation3", 200, 30)
		LabelSetText( "WarBoard_Loc_lblLocation" , towstring( GetZoneName( GameData.Player.zone ) ) )
		LabelSetText( "WarBoard_Loc_lblLocation2", L""..px..L","..py..L"" )
		LabelSetText( "WarBoard_Loc_lblLocation3", L"" )

	end
end


function WarBoard_Loc.OnLButtonUp()

	broadcast = L"Broadcast"

	EA_Window_ContextMenu.CreateContextMenu("Chat Menu")
	
	EA_Window_ContextMenu.AddMenuItem(L"Send my position to Region.",WarBoard_Loc.Broadcast1, false, true)
	EA_Window_ContextMenu.AddMenuItem(L"Send my position to RvR.", WarBoard_Loc.Broadcast2, false, true)
	EA_Window_ContextMenu.AddMenuItem(L"Send my position to Guild.", WarBoard_Loc.BroadcastG, false, true)
	EA_Window_ContextMenu.AddMenuItem(L"Send my position to Alliance.", WarBoard_Loc.BroadcastA, false, true)
		if IsWarBandActive() then
			EA_Window_ContextMenu.AddMenuItem(L"Send my position to Warband.", WarBoard_Loc.BroadcastW, false, true);
		else
			EA_Window_ContextMenu.AddMenuItem(L"Send my position to Party.", WarBoard_Loc.BroadcastP, false, true);
		end
	EA_Window_ContextMenu.Finalize() 
end


function WarBoard_Loc.OnSetWidth()
	WindowClearAnchors( "WarBoard_Loc_SetWidthWindow" )
	WindowAddAnchor( "WarBoard_Loc_SetWidthWindow", "bottom", "WarBoard_Loc", "top", 0, 0 )
	WindowSetShowing( "WarBoard_Loc_SetWidthWindow", true )
end


function WarBoard_Loc.CloseSetWidthWindow()
	WindowSetShowing( "WarBoard_Loc_SetWidthWindow", false )
end


function WarBoard_Loc.OnMouseOver()
	local px, py = LibSurveyor.PlayerLocation.zoneX,LibSurveyor.PlayerLocation.zoneY

	if (px == 0) or (py == 0) then
		return
	end

	Tooltips.CreateTextOnlyTooltip ("WarBoard_Loc")
	Tooltips.AnchorTooltip(Tooltips.ANCHOR_WINDOW_BOTTOM)

	Tooltips.SetTooltipText(1, 1,  L"Location Info")
	Tooltips.SetTooltipColorDef(1, 1, Tooltips.COLOR_HEADING)
	Tooltips.SetTooltipText(2, 1,  L"X:")
	Tooltips.SetTooltipText(2, 2,  towstring(towstring(string.format("%.2f", px / 1000))))
	Tooltips.SetTooltipText(3, 1,  L"Y: ")
	Tooltips.SetTooltipText(3, 2,  towstring(towstring(string.format("%.2f", py / 1000))))

	Tooltips.Finalize()
	
end


--function WarBoard_Loc.OnRButtonUp()
--	WindowSetShowing( "EA_Window_WorldMap", true)
--end


function WarBoard_Loc.Broadcast1()
	local px, py   = LibSurveyor.PlayerLocation.zoneX,LibSurveyor.PlayerLocation.zoneY
	local areaName = GameData.Player.area.name
	local message  = ""

	if (px == 0) or (py == 0) then
		local message = L"/1 I am in " .. towstring(GetZoneName(GameData.Player.zone)) ..L"."
		SendChatText(message, L"")
	else
		if tostring(areaName) == "" then
			local message = L"/1 I am in " .. towstring(GetZoneName(GameData.Player.zone)) ..L" @ ["..towstring(string.format("%.2f", px / 1000))..L" , "..towstring(string.format("%.2f", py / 1000))..L"]."
			SendChatText(message, L"")
		else
			local message = L"/1 I am at " .. towstring(GameData.Player.area.name) ..L" in " .. towstring(GetZoneName(GameData.Player.zone)) ..L" ["..towstring(string.format("%.2f", px / 1000))..L" , "..towstring(string.format("%.2f", py / 1000))..L"]."
			SendChatText(message, L"")
		end
	end
end


function WarBoard_Loc.Broadcast2()
	local px, py   = LibSurveyor.PlayerLocation.zoneX,LibSurveyor.PlayerLocation.zoneY
	local areaName = GameData.Player.area.name
	local message  = ""

	if (px == 0) or (py == 0) then
		local message = L"/2 I am in " .. towstring(GetZoneName(GameData.Player.zone)) ..L"."
		SendChatText(message, L"")
	else
		if tostring(areaName) == "" then
			local message = L"/2 I am in " .. towstring(GetZoneName(GameData.Player.zone)) ..L" @ ["..towstring(string.format("%.2f", px / 1000))..L" , "..towstring(string.format("%.2f", py / 1000))..L"]."
			SendChatText(message, L"")
		else
			local message = L"/2 I am at " .. towstring(GameData.Player.area.name) ..L" in " .. towstring(GetZoneName(GameData.Player.zone)) ..L" ["..towstring(string.format("%.2f", px / 1000))..L" , "..towstring(string.format("%.2f", py / 1000))..L"]."
			SendChatText(message, L"")
		end
	end
end


function WarBoard_Loc.BroadcastG()
	local px, py   = LibSurveyor.PlayerLocation.zoneX,LibSurveyor.PlayerLocation.zoneY
	local areaName = GameData.Player.area.name
	local message  = ""

	if (px == 0) or (py == 0) then
		local message = L"/g I am in " .. towstring(GetZoneName(GameData.Player.zone)) ..L"."
		SendChatText(message, L"")
	else
		if tostring(areaName) == "" then
			local message = L"/g I am in " .. towstring(GetZoneName(GameData.Player.zone)) ..L" @ ["..towstring(string.format("%.2f", px / 1000))..L" , "..towstring(string.format("%.2f", py / 1000))..L"]."
			SendChatText(message, L"")
		else
			local message = L"/g I am at " .. towstring(GameData.Player.area.name) ..L" in " .. towstring(GetZoneName(GameData.Player.zone)) ..L" ["..towstring(string.format("%.2f", px / 1000))..L" , "..towstring(string.format("%.2f", py / 1000))..L"]."
			SendChatText(message, L"")
		end
	end
end


function WarBoard_Loc.BroadcastA()
	local px, py   = LibSurveyor.PlayerLocation.zoneX,LibSurveyor.PlayerLocation.zoneY
	local areaName = GameData.Player.area.name

	if (px == 0) or (py == 0) then
		local message = L"/a I am in " .. towstring(GetZoneName(GameData.Player.zone)) .. L"."
		SendChatText(message, L"")
	else
		if tostring(areaName) == "" then
			local message = L"/a I am in " .. towstring(GetZoneName(GameData.Player.zone)) .. L" @ ["..towstring(string.format("%.2f", px / 1000))..L" , "..towstring(string.format("%.2f", py / 1000))..L"]."
			SendChatText(message, L"")
		else
			local message = L"/a I am at " .. towstring(GameData.Player.area.name) .. L" in " .. towstring(GetZoneName(GameData.Player.zone)) .. L" ["..towstring(string.format("%.2f", px / 1000))..L" , "..towstring(string.format("%.2f", py / 1000))..L"]."
			SendChatText(message, L"")
		end
	end
end

function WarBoard_Loc.BroadcastP()
	local px, py   = LibSurveyor.PlayerLocation.zoneX,LibSurveyor.PlayerLocation.zoneY
	local areaName = GameData.Player.area.name
	local message  = ""

	if (px == 0) or (py == 0) then
		local message = L"/war I am in " .. towstring(GetZoneName(GameData.Player.zone)) ..L"."
		SendChatText(message, L"")
	else
		if tostring(areaName) == "" then
			local message = L"/p I am in " .. towstring(GetZoneName(GameData.Player.zone)) ..L" @ ["..towstring(string.format("%.2f", px / 1000))..L" , "..towstring(string.format("%.2f", py / 1000))..L"]."
			SendChatText(message, L"")
		else
			local message = L"/p I am at " .. towstring(GameData.Player.area.name) ..L" in " .. towstring(GetZoneName(GameData.Player.zone)) ..L" ["..towstring(string.format("%.2f", px / 1000))..L" , "..towstring(string.format("%.2f", py / 1000))..L"]."
			SendChatText(message, L"")
		end
	end
end


function WarBoard_Loc.BroadcastW()
	local px, py   = LibSurveyor.PlayerLocation.zoneX,LibSurveyor.PlayerLocation.zoneY
	local areaName = GameData.Player.area.name
	local message  = ""

	if (px == 0) or (py == 0) then
		local message = L"/g I am in " .. towstring(GetZoneName(GameData.Player.zone)) ..L"."
		SendChatText(message, L"")
	else
		if tostring(areaName) == "" then
			local message = L"/g I am in " .. towstring(GetZoneName(GameData.Player.zone)) ..L" @ ["..towstring(string.format("%.2f", px / 1000))..L" , "..towstring(string.format("%.2f", py / 1000))..L"]."
			SendChatText(message, L"")
		else
			local message = L"/g I am at " .. towstring(GameData.Player.area.name) ..L" in " .. towstring(GetZoneName(GameData.Player.zone)) ..L" ["..towstring(string.format("%.2f", px / 1000))..L" , "..towstring(string.format("%.2f", py / 1000))..L"]."
			SendChatText(message, L"")
		end
	end
end


----------------------------------------------------------------
-- Layout Mode Functions, argument is the name of the window.
----------------------------------------------------------------
function WarBoard_Loc.OnDisable()
	WarBoard.DisableMod("WarBoard_Loc")
end

function WarBoard_Loc.MoveRight()
	WarBoard.MoveModRight("WarBoard_Loc")
end

function WarBoard_Loc.MoveLeft()
	WarBoard.MoveModLeft("WarBoard_Loc")
end