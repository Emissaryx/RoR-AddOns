RangeCircle 1.2.7
=================

Creators: Gingerbel and Kpihuss

Projection-only range circle overlay for Return of Reckoning.

This build removes the old fixed 2D ellipse mode. RangeCircle now uses the WorldToScreen projection approach only: it calculates real horizontal circles around the player in world coordinates and projects those points to the screen.

It is still not a true 3D ground decal, but it follows camera angle and zoom much better than the old pseudo-ground ellipse.

Installation:
Copy the RangeCircle folder to:

Warhammer Online - Age of Reckoning\Interface\AddOns\RangeCircle

Requires LibSlash.

Open the in-game menu:

/rangecircle menu

Current projected range presets:

10 ft
20 ft
25 ft
30 ft
45 ft

Useful commands:

/rangecircle menu
/rangecircle show | hide | toggle
/rangecircle center
/rangecircle move x y
/rangecircle nudge dx dy
/rangecircle ring 1|2|3
/rangecircle enable | disable | ringtoggle
/rangecircle one
/rangecircle three
/rangecircle preset 10|20|25|30|40|45
/rangecircle quality low|normal|high
/rangecircle zoffset 4
/rangecircle pointsize 20
/rangecircle alpha 70
/rangecircle color 80 200 255
/rangecircle status
/rangecircle reset

Notes:
- Use /rangecircle nudge dx dy to centre the projected circle visually over your character.
- Use /rangecircle zoffset if the circle appears to slide over the floor when the camera angle changes. Recommended starting value: /rangecircle zoffset 4.
- Use /rangecircle pointsize if the points are too small or too large.
- Low/normal/high quality changes the number of projected points per ring.

Credits for the projection approach: Compass3D by Zomega/Omegus, with public release update by Kpihuss.


Version 1.2.2: added more colour presets in the menu (White, Cyan, Purple, Orange, Pink and Lime).


Version 1.2.2: reorganised the configuration menu into clearer columns and sections.


Version 1.2.3: added CALIBRATION_GUIDE.txt and changed the recommended/default projected ground height to zoffset 4 after in-game testing.


Version 1.2.6 calibration update:
- Projected range presets were recalibrated using War Quarters floor tiles, treating each tile as 5 ft.
- The projected world scale uses 16 internal units per foot for 10/20/25/30/40/45 ft rings.
- Dot placement now uses adaptive screen-space spacing, so large rings have more uniform point distribution and fewer empty edges.


Version 1.2.6 notes:
- Added the 40 ft preset.
- PROJECTED_UNITS_PER_FOOT is now calibrated to 16.
- Added custom projected radius commands: /rangecircle range <feet>, /rangecircle feet <feet>, /rangecircle radius <feet>.
- Added menu buttons Range -1 ft and Range +1 ft for active ring custom sizes.


Version 1.2.6: added a Default ranges button and /rangecircle defaultranges command to restore the default Ring 1/2/3 preset ranges.

Version 1.2.7 performance update:
- Projected point windows are now created only when they are actually needed.
- Hidden and disabled rings no longer scan and reset all 360 possible points every update.
- Point size, colour, alpha and visibility calls are cached and only sent to the UI when changed.
- Circle sine/cosine samples are cached per quality level.
- Hidden overlays no longer run the projection update loop.
