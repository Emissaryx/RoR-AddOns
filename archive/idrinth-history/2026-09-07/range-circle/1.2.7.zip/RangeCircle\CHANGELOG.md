# Changelog

## 1.2.7 - 2026-07-15

- Create projected point windows only when they are needed.
- Stop scanning and resetting all possible points for disabled and hidden rings.
- Cache point size, colour, alpha and visibility state.
- Cache sine and cosine samples for each quality level.
- Stop projection updates while the overlay is hidden.
- Keep the existing projection quality and update rate.

## 1.2.6

- Added the 40 ft preset and custom projected ranges.
- Calibrated the projected world scale to 16 internal units per foot.
- Added adaptive screen-space point spacing.
- Added the default-ranges reset command and menu button.

## 1.2.3

- Added the calibration guide.
- Set 4 ft as the recommended projected ground offset.

## 1.2.2

- Added colour presets and reorganised the configuration menu.

## 1.2.0

- Removed the legacy fixed 2D ellipse mode.
- Made WorldToScreen projection the only rendering mode.
