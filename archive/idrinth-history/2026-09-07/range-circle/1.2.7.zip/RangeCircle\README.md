# RangeCircle 1.2.7

RangeCircle is a projection-only range overlay addon for Return of Reckoning. It projects up to three horizontal range circles around the player with WorldToScreen.

## Features

- Three independently configurable projected rings.
- Presets for 10, 20, 25, 30, 40 and 45 ft.
- Custom projected ranges from 1 to 200 ft.
- Low, normal and high projection quality.
- Configurable colour, alpha, point size and ground offset.
- In-game configuration menu.
- Lazy point-window creation and cached UI state in version 1.2.7.

## Installation

Copy the RangeCircle folder to:

    <Return of Reckoning>\Interface\AddOns\RangeCircle

RangeCircle requires the LibSlash addon.

## Usage

Open the configuration menu:

    /rangecircle menu

Common commands:

    /rangecircle show | hide | toggle
    /rangecircle ring 1|2|3
    /rangecircle enable | disable | ringtoggle
    /rangecircle preset 10|20|25|30|40|45
    /rangecircle range <feet>
    /rangecircle quality low|normal|high
    /rangecircle zoffset 4
    /rangecircle pointsize 20
    /rangecircle center
    /rangecircle reset

See MANUAL.txt and CALIBRATION_GUIDE.txt for full instructions.

## Limitations

RangeCircle draws projected UI points; it is not a terrain-following 3D decal. Slopes, stairs and unusual camera states can require small manual offsets.

## Credits

Created by Gingerbel and Kpihuss. The projection approach is based on Compass3D by Zomega/Omegus, with a public release update by Kpihuss.

See CHANGELOG.md for release history.
