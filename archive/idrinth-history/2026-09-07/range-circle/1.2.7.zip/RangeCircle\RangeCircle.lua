-- RangeCircle 1.2.7
-- Projection-only range circle overlay for Return of Reckoning.
-- This build removes the legacy fixed 2D ellipse mode and keeps only the WorldToScreen projected mode.
-- It draws real horizontal circles in world coordinates and projects them to the screen.

RangeCircle = RangeCircle or {}
RangeCircle.VERSION = "1.2.7"

local WINDOW = "RangeCircleWindow"
local DOT = "RangeCircleWindowCenterDot"
local TEXT = "RangeCircleWindowText"
local CONFIG_WINDOW = "RangeCircleConfigWindow"

local RING_WINDOWS = {
    [1] = "RangeCircleWindowRing1",
    [2] = "RangeCircleWindowRing2",
    [3] = "RangeCircleWindowRing3",
}

local PROJECTED_POINT_TEMPLATE = "T_RangeCircleProjectedPoint"
local PROJECTED_POINT_PREFIX = "RangeCircleProjectedPoint"
local PROJECTED_MAX_RINGS = 3
local PROJECTED_MAX_POINTS = 360
local PROJECTED_TWO_PI = 6.283185307179586

-- Projected dots are expensive WAR UI windows. Keep their runtime state so the
-- hot update path only touches windows that are visible and actually changed.
local projectedPointStates = {}
local projectedVisibleCounts = { 0, 0, 0 }
local projectedAngleCache = {}
local projectedCreateWarningShown = false

local function projectedPointState(ringIndex, pointIndex)
    local ringStates = projectedPointStates[ringIndex]
    if ringStates == nil then
        ringStates = {}
        projectedPointStates[ringIndex] = ringStates
    end

    local state = ringStates[pointIndex]
    if state == nil then
        state = {}
        ringStates[pointIndex] = state
    end

    return state
end

local function projectedAngles(samples)
    local cached = projectedAngleCache[samples]
    if cached ~= nil then return cached end

    cached = { cos = {}, sin = {} }
    local step = PROJECTED_TWO_PI / samples
    for sampleIndex = 1, samples do
        local angle = (sampleIndex - 1) * step
        cached.cos[sampleIndex] = math.cos(angle)
        cached.sin[sampleIndex] = math.sin(angle)
    end
    projectedAngleCache[samples] = cached
    return cached
end

-- Calibrated against the War Quarters floor tiles used for testing.
-- One visible floor tile is treated as 5 ft.
-- The raw Compass3D conversion used 12 units per ft; practical tile tests
-- showed that 16 gives a closer match for the calibrated range presets.
RangeCircle.PROJECTED_UNITS_PER_FOOT = 16
RangeCircle.PROJECTED_DOT_SPACING = { low = 2.20, normal = 1.65, high = 1.20 }

RangeCircle.DefaultRings = {
    [1] = {
        enabled = true,
        name = "20 ft",
        preset = "20",
        projectedFeet = 20,
        width = 1440,
        height = 544,
        offsetX = 0,
        offsetY = 110,
        alpha = 0.85,
        r = 80,
        g = 200,
        b = 255,
        thickness = "auto",
    },
    [2] = {
        enabled = false,
        name = "30 ft",
        preset = "30",
        projectedFeet = 30,
        width = 2100,
        height = 794,
        offsetX = 0,
        offsetY = 110,
        alpha = 0.60,
        r = 255,
        g = 220,
        b = 80,
        thickness = "auto",
    },
    [3] = {
        enabled = false,
        name = "10 ft",
        preset = "10",
        projectedFeet = 10,
        width = 760,
        height = 287,
        offsetX = 0,
        offsetY = 110,
        alpha = 0.75,
        r = 100,
        g = 255,
        b = 120,
        thickness = "auto",
    },
}

RangeCircle.Defaults = {
    showing = true,
    locked = true,
    mode = "projected", -- projected only
    x = 0,
    y = 0,
    activeRing = 1,
    label = false,
    dot = false,
    calibrationVersion = 9,
    projectedQuality = "normal",
    projectedGroundOffsetFeet = 4,
    projectedPointSize = 20,
    projectedUpdateRate = 0.04,
    rings = nil,
}

RangeCircle.DEFAULT_FLATTEN = 0.378

RangeCircle.PresetFeet = {
    ["10"] = 10,
    ["20"] = 20,
    ["25"] = 25,
    ["30"] = 30,
    ["40"] = 40,
    ["45"] = 45,
}

RangeCircle.PresetWidths = {
    ["10"] = 760,
    ["20"] = 1440,
    ["25"] = 1800,
    ["30"] = 2100,
    ["40"] = 2560,
    ["45"] = 2800,
}

RangeCircle.RingTextureAssets = {
    thin = "rangecircle_ring_thin",
    normal = "rangecircle_ring_normal",
    bold = "rangecircle_ring_bold",
}

local function deepCopy(source)
    if type(source) ~= "table" then return source end
    local target = {}
    for k, v in pairs(source) do
        target[k] = deepCopy(v)
    end
    return target
end

local function defaultSettings()
    local t = deepCopy(RangeCircle.Defaults)
    t.rings = deepCopy(RangeCircle.DefaultRings)
    return t
end

local function toNumber(value, fallback)
    local n = tonumber(value)
    if n == nil then return fallback end
    return n
end

local function clamp(value, minValue, maxValue)
    value = toNumber(value, minValue)
    if value < minValue then return minValue end
    if value > maxValue then return maxValue end
    return value
end

local function round(value)
    return math.floor(toNumber(value, 0) + 0.5)
end

local function wtext(value)
    if towstring ~= nil then
        return towstring(tostring(value))
    end
    return tostring(value)
end

local function windowExists(name)
    return DoesWindowExist ~= nil and DoesWindowExist(name) == true
end

local function boolValue(value, fallback)
    if value == true then return true end
    if value == false then return false end
    return fallback
end

function RangeCircle.Print(message)
    local text = L"[RangeCircle] " .. wtext(message)

    if TextLogAddEntry ~= nil then
        local ok = pcall(TextLogAddEntry, "Chat", 0, text)
        if ok then return end
    end

    if EA_ChatWindow ~= nil and EA_ChatWindow.Print ~= nil then
        local ok = pcall(EA_ChatWindow.Print, text)
        if ok then return end
    end

    if d ~= nil then
        pcall(d, text)
    end
end

function RangeCircle.MigrateOldSettings()
    if RangeCircle.Settings == nil or RangeCircle.Settings.rings ~= nil then
        return
    end

    local old = RangeCircle.Settings
    local migrated = defaultSettings()

    migrated.showing = boolValue(old.showing, migrated.showing)
    migrated.locked = boolValue(old.locked, migrated.locked)
    migrated.mode = tostring(old.mode or migrated.mode)
    migrated.x = toNumber(old.x, migrated.x)
    migrated.y = toNumber(old.y, migrated.y)
    migrated.label = boolValue(old.label, false)
    migrated.dot = boolValue(old.dot, false)
    migrated.calibrationVersion = 1

    local radius = toNumber(old.radius, nil)
    if radius ~= nil then
        migrated.rings[1].width = clamp(radius * 2, 20, 3200)
        local flatten = toNumber(old.flatten, RangeCircle.DEFAULT_FLATTEN)
        migrated.rings[1].height = clamp(migrated.rings[1].width * clamp(flatten, 0.10, 1.00), 10, 1200)
    end

    migrated.rings[1].offsetX = toNumber(old.ringOffsetX, migrated.rings[1].offsetX)
    migrated.rings[1].offsetY = toNumber(old.ringOffsetY, migrated.rings[1].offsetY)
    migrated.rings[1].alpha = clamp(toNumber(old.alpha, migrated.rings[1].alpha), 0.05, 1.00)
    migrated.rings[1].r = clamp(toNumber(old.r, migrated.rings[1].r), 0, 255)
    migrated.rings[1].g = clamp(toNumber(old.g, migrated.rings[1].g), 0, 255)
    migrated.rings[1].b = clamp(toNumber(old.b, migrated.rings[1].b), 0, 255)
    migrated.rings[1].preset = tostring(old.preset or migrated.rings[1].preset)
    migrated.rings[1].name = migrated.rings[1].preset .. " ft"

    RangeCircle.Settings = migrated
end

function RangeCircle.MigratePresetCalibration()
    if RangeCircle.Settings == nil then return end
    if RangeCircle.Settings.calibrationVersion == 7 then return end

    if RangeCircle.Settings.rings == nil then
        RangeCircle.Settings.rings = deepCopy(RangeCircle.DefaultRings)
    end

    for i = 1, 3 do
        local current = RangeCircle.Settings.rings[i]
        local def = RangeCircle.DefaultRings[i]

        if current == nil then
            RangeCircle.Settings.rings[i] = deepCopy(def)
        else
            local enabled = boolValue(current.enabled, def.enabled)
            local offsetX = toNumber(current.offsetX, def.offsetX)
            local offsetY = toNumber(current.offsetY, def.offsetY)
            local alpha = clamp(toNumber(current.alpha, def.alpha), 0.05, 1.00)
            local r = clamp(toNumber(current.r, def.r), 0, 255)
            local g = clamp(toNumber(current.g, def.g), 0, 255)
            local b = clamp(toNumber(current.b, def.b), 0, 255)
            local thickness = tostring(current.thickness or def.thickness or "auto")
            local preset = tostring(current.preset or def.preset)
            local width = RangeCircle.PresetWidths[preset] or def.width

            current.enabled = enabled
            current.preset = RangeCircle.PresetWidths[preset] and preset or def.preset
            current.name = current.preset .. " ft"
            current.width = width
            current.height = clamp(width * RangeCircle.DEFAULT_FLATTEN, 10, 1200)
            current.offsetX = offsetX
            current.offsetY = offsetY
            current.alpha = alpha
            current.r = r
            current.g = g
            current.b = b
            current.thickness = thickness
        end
    end

    RangeCircle.Settings.calibrationVersion = 7
end

function RangeCircle.EnsureSettings()
    if RangeCircle.Settings == nil then
        RangeCircle.Settings = defaultSettings()
    end

    RangeCircle.MigrateOldSettings()
    RangeCircle.MigratePresetCalibration()

    for k, v in pairs(RangeCircle.Defaults) do
        if k ~= "rings" and RangeCircle.Settings[k] == nil then
            RangeCircle.Settings[k] = v
        end
    end

    if RangeCircle.Settings.rings == nil then
        RangeCircle.Settings.rings = deepCopy(RangeCircle.DefaultRings)
    end

    for i = 1, 3 do
        if RangeCircle.Settings.rings[i] == nil then
            RangeCircle.Settings.rings[i] = deepCopy(RangeCircle.DefaultRings[i])
        end

        local ring = RangeCircle.Settings.rings[i]
        local def = RangeCircle.DefaultRings[i]

        for k, v in pairs(def) do
            if ring[k] == nil then
                ring[k] = v
            end
        end

        ring.enabled = boolValue(ring.enabled, def.enabled)
        ring.name = tostring(ring.name or def.name)
        ring.preset = tostring(ring.preset or def.preset)
        if ring.projectedFeet == nil then
            local presetFeet = RangeCircle.PresetFeet[tostring(ring.preset or "")]
            if presetFeet ~= nil then
                ring.projectedFeet = presetFeet
            end
        end
        if ring.projectedFeet ~= nil then
            ring.projectedFeet = clamp(toNumber(ring.projectedFeet, 20), 1, 200)
        end
        ring.width = clamp(toNumber(ring.width, def.width), 20, 3200)
        ring.height = clamp(toNumber(ring.height, def.height), 10, 1200)
        ring.offsetX = clamp(toNumber(ring.offsetX, def.offsetX), -1000, 1000)
        ring.offsetY = clamp(toNumber(ring.offsetY, def.offsetY), -1000, 1000)
        ring.alpha = clamp(toNumber(ring.alpha, def.alpha), 0.05, 1.00)
        ring.r = clamp(toNumber(ring.r, def.r), 0, 255)
        ring.g = clamp(toNumber(ring.g, def.g), 0, 255)
        ring.b = clamp(toNumber(ring.b, def.b), 0, 255)
        ring.thickness = tostring(ring.thickness or def.thickness or "auto")
        if ring.thickness ~= "auto" and ring.thickness ~= "thin" and ring.thickness ~= "normal" and ring.thickness ~= "bold" then
            ring.thickness = "auto"
        end
    end

    RangeCircle.Settings.activeRing = clamp(toNumber(RangeCircle.Settings.activeRing, 1), 1, 3)
    RangeCircle.Settings.activeRing = math.floor(RangeCircle.Settings.activeRing)

    RangeCircle.Settings.mode = "projected"

    if RangeCircle.Settings.projectedQuality ~= "low" and RangeCircle.Settings.projectedQuality ~= "normal" and RangeCircle.Settings.projectedQuality ~= "high" then
        RangeCircle.Settings.projectedQuality = "normal"
    end
    RangeCircle.Settings.projectedGroundOffsetFeet = clamp(toNumber(RangeCircle.Settings.projectedGroundOffsetFeet, 6), -20, 20)
    RangeCircle.Settings.projectedPointSize = clamp(toNumber(RangeCircle.Settings.projectedPointSize, 20), 6, 64)
    RangeCircle.Settings.projectedUpdateRate = clamp(toNumber(RangeCircle.Settings.projectedUpdateRate, 0.04), 0.01, 0.25)

    RangeCircle.Settings.x = clamp(toNumber(RangeCircle.Settings.x, 0), -2000, 2000)
    RangeCircle.Settings.y = clamp(toNumber(RangeCircle.Settings.y, 0), -2000, 2000)
    RangeCircle.Settings.showing = boolValue(RangeCircle.Settings.showing, true)
    RangeCircle.Settings.locked = boolValue(RangeCircle.Settings.locked, true)
    RangeCircle.Settings.label = boolValue(RangeCircle.Settings.label, false)
    RangeCircle.Settings.dot = boolValue(RangeCircle.Settings.dot, false)
end

function RangeCircle.ActiveRing()
    RangeCircle.EnsureSettings()
    return RangeCircle.Settings.rings[RangeCircle.Settings.activeRing]
end

function RangeCircle.CreateMainWindow()
    if windowExists(WINDOW) then
        return true
    end

    if CreateWindow == nil then
        RangeCircle.Print("ERROR: CreateWindow API not available")
        return false
    end

    local ok, err = pcall(CreateWindow, WINDOW, true)
    if not ok then
        RangeCircle.Print("ERROR: CreateWindow failed: " .. tostring(err))
        return false
    end

    if not windowExists(WINDOW) then
        RangeCircle.Print("ERROR: " .. WINDOW .. " was not created. Check RangeCircle.xml syntax/load order.")
        return false
    end

    if WindowSetLayer ~= nil and Window ~= nil and Window.Layers ~= nil and Window.Layers.POPUP ~= nil then
        pcall(WindowSetLayer, WINDOW, Window.Layers.POPUP)
    end

    return true
end


function RangeCircle.CreateConfigWindow()
    if windowExists(CONFIG_WINDOW) then
        return true
    end

    if CreateWindow == nil then
        RangeCircle.Print("ERROR: CreateWindow API not available for config window")
        return false
    end

    local ok, err = pcall(CreateWindow, CONFIG_WINDOW, false)
    if not ok then
        RangeCircle.Print("ERROR: CreateWindow config failed: " .. tostring(err))
        return false
    end

    if not windowExists(CONFIG_WINDOW) then
        RangeCircle.Print("ERROR: " .. CONFIG_WINDOW .. " was not created.")
        return false
    end

    if WindowSetLayer ~= nil and Window ~= nil and Window.Layers ~= nil and Window.Layers.POPUP ~= nil then
        pcall(WindowSetLayer, CONFIG_WINDOW, Window.Layers.POPUP)
    end

    return true
end

function RangeCircle.GetRingTextureAsset(ring)
    local thickness = tostring(ring.thickness or "auto")

    if thickness == "auto" then
        local width = toNumber(ring.width, 570)
        if width >= 650 then
            thickness = "thin"
        elseif width >= 360 then
            thickness = "normal"
        else
            thickness = "bold"
        end
    end

    return RangeCircle.RingTextureAssets[thickness] or RangeCircle.RingTextureAssets.normal
end

function RangeCircle.RefreshTextures()
    if DynamicImageSetTexture == nil then return end
    RangeCircle.EnsureSettings()

    for i = 1, 3 do
        if windowExists(RING_WINDOWS[i]) then
            local ring = RangeCircle.Settings.rings[i]
            pcall(DynamicImageSetTexture, RING_WINDOWS[i], RangeCircle.GetRingTextureAsset(ring), 0, 0)
        end
    end

    if windowExists(DOT) then
        pcall(DynamicImageSetTexture, DOT, "rangecircle_dot", 0, 0)
    end
end

function RangeCircle.DetachFromPlayer()
    if RangeCircle.AttachedObjectId ~= nil and DetachWindowFromWorldObject ~= nil then
        pcall(DetachWindowFromWorldObject, WINDOW, RangeCircle.AttachedObjectId)
    end
    RangeCircle.AttachedObjectId = nil
end

function RangeCircle.AttachToPlayer()
    -- Projection-only build: object-attached 2D billboard mode has been removed.
    return false
end

function RangeCircle.ApplyPosition()
    local s = RangeCircle.Settings

    if s.mode == "self" then
        RangeCircle.AttachToPlayer()
    end

    if s.mode ~= "self" then
        RangeCircle.DetachFromPlayer()
        if WindowClearAnchors ~= nil and WindowAddAnchor ~= nil then
            pcall(WindowClearAnchors, WINDOW)
            pcall(WindowAddAnchor, WINDOW, "center", "Root", "center", toNumber(s.x, 0), toNumber(s.y, 150))
        elseif WindowSetOffsetFromParent ~= nil then
            pcall(WindowSetOffsetFromParent, WINDOW, toNumber(s.x, 0), toNumber(s.y, 150))
        end
    end
end

function RangeCircle.ApplyLayout()
    local s = RangeCircle.Settings
    local maxHalfWidth = 420
    local maxHalfHeight = 260

    for i = 1, 3 do
        local ring = s.rings[i]
        local halfW = (toNumber(ring.width, 300) / 2) + math.abs(toNumber(ring.offsetX, 0))
        local top = toNumber(ring.offsetY, 0) - (toNumber(ring.height, 126) / 2)
        local bottom = toNumber(ring.offsetY, 0) + (toNumber(ring.height, 126) / 2)
        maxHalfWidth = math.max(maxHalfWidth, halfW + 80)
        maxHalfHeight = math.max(maxHalfHeight, math.abs(top) + 80, math.abs(bottom) + 80)
    end

    local parentWidth = clamp(round(maxHalfWidth * 2), 120, 3600)
    local parentHeight = clamp(round(maxHalfHeight * 2), 120, 1600)

    if WindowSetDimensions ~= nil then
        pcall(WindowSetDimensions, WINDOW, parentWidth, parentHeight)

        for i = 1, 3 do
            if windowExists(RING_WINDOWS[i]) then
                local ring = s.rings[i]
                pcall(WindowSetDimensions, RING_WINDOWS[i], round(ring.width), round(ring.height))
            end
        end

        if windowExists(DOT) then
            pcall(WindowSetDimensions, DOT, 10, 10)
        end

        if windowExists(TEXT) then
            pcall(WindowSetDimensions, TEXT, math.min(900, math.max(420, parentWidth - 40)), 26)
        end
    end

    if WindowClearAnchors ~= nil and WindowAddAnchor ~= nil then
        for i = 1, 3 do
            if windowExists(RING_WINDOWS[i]) then
                local ring = s.rings[i]
                pcall(WindowClearAnchors, RING_WINDOWS[i])
                pcall(WindowAddAnchor, RING_WINDOWS[i], "center", WINDOW, "center", toNumber(ring.offsetX, 0), toNumber(ring.offsetY, 110))
            end
        end

        local active = RangeCircle.ActiveRing()

        if windowExists(DOT) then
            pcall(WindowClearAnchors, DOT)
            pcall(WindowAddAnchor, DOT, "center", WINDOW, "center", toNumber(active.offsetX, 0), toNumber(active.offsetY, 110))
        end

        if windowExists(TEXT) then
            pcall(WindowClearAnchors, TEXT)
            pcall(WindowAddAnchor, TEXT, "bottom", RING_WINDOWS[s.activeRing], "top", 0, -4)
        end
    end
end

function RangeCircle.ApplyVisuals()
    local s = RangeCircle.Settings

    for i = 1, 3 do
        local ring = s.rings[i]
        local win = RING_WINDOWS[i]

        if windowExists(win) then
            if WindowSetTintColor ~= nil then
                pcall(WindowSetTintColor, win, toNumber(ring.r, 80), toNumber(ring.g, 200), toNumber(ring.b, 255))
            end
            if WindowSetAlpha ~= nil then
                pcall(WindowSetAlpha, win, clamp(toNumber(ring.alpha, 0.85), 0.05, 1.0))
            end
            if WindowSetShowing ~= nil then
                pcall(WindowSetShowing, win, s.showing == true and ring.enabled == true and s.mode ~= "projected")
            end
            if WindowSetHandleInput ~= nil then
                pcall(WindowSetHandleInput, win, false)
            end
        end
    end

    if windowExists(DOT) then
        local active = RangeCircle.ActiveRing()
        if WindowSetTintColor ~= nil then
            pcall(WindowSetTintColor, DOT, toNumber(active.r, 80), toNumber(active.g, 200), toNumber(active.b, 255))
        end
        if WindowSetAlpha ~= nil then
            pcall(WindowSetAlpha, DOT, 0.90)
        end
        if WindowSetShowing ~= nil then
            pcall(WindowSetShowing, DOT, s.showing == true and s.mode ~= "projected" and (s.dot == true or s.locked ~= true))
        end
        if WindowSetHandleInput ~= nil then
            pcall(WindowSetHandleInput, DOT, false)
        end
    end

    if windowExists(TEXT) then
        if WindowSetShowing ~= nil then
            pcall(WindowSetShowing, TEXT, s.showing == true and s.mode ~= "projected" and (s.label == true or s.locked ~= true))
        end
        if WindowSetHandleInput ~= nil then
            pcall(WindowSetHandleInput, TEXT, false)
        end
        if LabelSetText ~= nil then
            local active = RangeCircle.ActiveRing()
            local msg = "RangeCircle " .. RangeCircle.VERSION .. " | ring " .. tostring(s.activeRing) .. " " .. tostring(active.name)
            msg = msg .. " | " .. tostring(round(active.width)) .. "x" .. tostring(round(active.height))
            msg = msg .. " | offset " .. tostring(round(active.offsetX)) .. "," .. tostring(round(active.offsetY))
            msg = msg .. " | " .. tostring(s.mode)
            if s.locked == true then msg = msg .. " | locked" else msg = msg .. " | unlocked" end
            pcall(LabelSetText, TEXT, wtext(msg))
        end
    end

    if WindowSetShowing ~= nil then
        pcall(WindowSetShowing, WINDOW, s.showing == true and s.mode ~= "projected")
    end

    if WindowSetMovable ~= nil then
        pcall(WindowSetMovable, WINDOW, s.locked ~= true and s.mode == "screen")
    end

    if WindowSetHandleInput ~= nil then
        pcall(WindowSetHandleInput, WINDOW, s.locked ~= true and s.mode == "screen")
    end
end

function RangeCircle.Apply()
    RangeCircle.EnsureSettings()

    if not RangeCircle.CreateMainWindow() then
        return
    end

    RangeCircle.RefreshTextures()
    RangeCircle.ApplyLayout()
    RangeCircle.ApplyPosition()
    RangeCircle.ApplyVisuals()

    if RangeCircle.Settings.mode == "self" and RangeCircle.AttachedObjectId ~= nil then
        local id = RangeCircle.AttachedObjectId
        RangeCircle.AttachedObjectId = nil
        RangeCircle.DetachFromPlayer()
        RangeCircle.AttachedObjectId = nil
        if AttachWindowToWorldObject ~= nil then
            pcall(AttachWindowToWorldObject, WINDOW, id)
            RangeCircle.AttachedObjectId = id
        end
    end

    RangeCircle.UpdateConfigWindow()
end

function RangeCircle.SetActiveRing(value)
    RangeCircle.EnsureSettings()
    local index = math.floor(clamp(toNumber(value, RangeCircle.Settings.activeRing), 1, 3))
    RangeCircle.Settings.activeRing = index
    RangeCircle.Apply()
    RangeCircle.Print("active ring set to " .. tostring(index))
end

function RangeCircle.SetMode(mode)
    RangeCircle.EnsureSettings()
    RangeCircle.Settings.mode = "projected"
    RangeCircle.Settings.locked = true
    RangeCircle.Settings.showing = true
    RangeCircle.DetachFromPlayer()
    RangeCircle.Apply()
    RangeCircle.ProjectedCreateWindows()
    RangeCircle.ProjectedUpdate(true)
    RangeCircle.Print("projection-only mode active. Use /rangecircle move x y or /rangecircle nudge x y to centre it.")
end

function RangeCircle.Show()
    RangeCircle.EnsureSettings()
    RangeCircle.Settings.showing = true
    RangeCircle.Apply()
end

function RangeCircle.Hide()
    RangeCircle.EnsureSettings()
    RangeCircle.Settings.showing = false
    RangeCircle.Apply()
end

function RangeCircle.Toggle()
    RangeCircle.EnsureSettings()
    RangeCircle.Settings.showing = not RangeCircle.Settings.showing
    RangeCircle.Apply()
end

function RangeCircle.Lock()
    RangeCircle.EnsureSettings()
    RangeCircle.Settings.locked = true
    RangeCircle.Apply()
    RangeCircle.Print("locked")
end

function RangeCircle.Unlock()
    RangeCircle.EnsureSettings()
    RangeCircle.Settings.locked = true
    RangeCircle.Settings.mode = "projected"
    RangeCircle.Print("projection-only mode does not use draggable 2D overlay. Use /rangecircle move x y or /rangecircle nudge x y.")
    RangeCircle.Apply()
end

function RangeCircle.EnableRing()
    local ring = RangeCircle.ActiveRing()
    ring.enabled = true
    RangeCircle.Apply()
    RangeCircle.Print("ring " .. tostring(RangeCircle.Settings.activeRing) .. " enabled")
end

function RangeCircle.DisableRing()
    local ring = RangeCircle.ActiveRing()
    ring.enabled = false
    RangeCircle.Apply()
    RangeCircle.Print("ring " .. tostring(RangeCircle.Settings.activeRing) .. " disabled")
end

function RangeCircle.ToggleRing()
    local ring = RangeCircle.ActiveRing()
    ring.enabled = not ring.enabled
    RangeCircle.Apply()
    RangeCircle.Print("ring " .. tostring(RangeCircle.Settings.activeRing) .. " " .. (ring.enabled and "enabled" or "disabled"))
end

function RangeCircle.SetSize(width, height)
    local ring = RangeCircle.ActiveRing()
    ring.width = clamp(toNumber(width, ring.width), 20, 3200)
    ring.height = clamp(toNumber(height, ring.height), 10, 1200)
    ring.preset = "manual"
    ring.name = "manual"
    ring.enabled = true
    RangeCircle.Apply()
    RangeCircle.Print("ring " .. tostring(RangeCircle.Settings.activeRing) .. " size set to " .. tostring(round(ring.width)) .. "x" .. tostring(round(ring.height)))
end

function RangeCircle.SetWidth(width)
    local ring = RangeCircle.ActiveRing()
    ring.width = clamp(toNumber(width, ring.width), 20, 3200)
    ring.preset = "manual"
    ring.name = "manual"
    ring.enabled = true
    RangeCircle.Apply()
    RangeCircle.Print("ring " .. tostring(RangeCircle.Settings.activeRing) .. " width set to " .. tostring(round(ring.width)))
end

function RangeCircle.SetHeight(height)
    local ring = RangeCircle.ActiveRing()
    ring.height = clamp(toNumber(height, ring.height), 10, 1200)
    ring.preset = "manual"
    ring.name = "manual"
    ring.enabled = true
    RangeCircle.Apply()
    RangeCircle.Print("ring " .. tostring(RangeCircle.Settings.activeRing) .. " height set to " .. tostring(round(ring.height)))
end

function RangeCircle.SetProjectedRangeFeet(value)
    local ring = RangeCircle.ActiveRing()
    local feet = clamp(toNumber(value, RangeCircle.ProjectedRingFeet(ring)), 1, 200)

    ring.projectedFeet = feet
    ring.preset = "manual"
    ring.name = tostring(feet) .. " ft"
    ring.enabled = true

    local referenceWidth = RangeCircle.PresetWidths["20"] or 1440
    ring.width = clamp((referenceWidth / 20) * feet, 20, 9999)
    ring.height = clamp(ring.width * RangeCircle.DEFAULT_FLATTEN, 10, 3000)

    RangeCircle.Apply()
    if RangeCircle.Settings ~= nil and RangeCircle.Settings.mode == "projected" then
        RangeCircle.ProjectedUpdate(true)
    end
    RangeCircle.Print("ring " .. tostring(RangeCircle.Settings.activeRing) .. " custom projected radius set to " .. tostring(feet) .. " ft")
end

function RangeCircle.AdjustProjectedRangeFeet(delta)
    local ring = RangeCircle.ActiveRing()
    local current = RangeCircle.ProjectedRingFeet(ring)
    RangeCircle.SetProjectedRangeFeet(current + toNumber(delta, 0))
end

function RangeCircle.SetRadius(value)
    RangeCircle.SetProjectedRangeFeet(value)
end

function RangeCircle.SetFlatten(value)
    local ring = RangeCircle.ActiveRing()
    local flatten = toNumber(value, ring.height / ring.width)
    if flatten > 1 then flatten = flatten / 100 end
    flatten = clamp(flatten, 0.10, 1.00)
    ring.height = clamp(ring.width * flatten, 10, 1200)
    ring.enabled = true
    RangeCircle.Apply()
    RangeCircle.Print("ring " .. tostring(RangeCircle.Settings.activeRing) .. " flatten set to " .. tostring(math.floor(flatten * 100)) .. "%")
end

function RangeCircle.SetOffset(x, y)
    local ring = RangeCircle.ActiveRing()
    if x ~= nil then ring.offsetX = clamp(toNumber(x, ring.offsetX), -1000, 1000) end
    if y ~= nil then ring.offsetY = clamp(toNumber(y, ring.offsetY), -1000, 1000) end
    RangeCircle.Apply()
    RangeCircle.Print("ring " .. tostring(RangeCircle.Settings.activeRing) .. " offset set to " .. tostring(round(ring.offsetX)) .. "," .. tostring(round(ring.offsetY)))
end

function RangeCircle.SetAlpha(value)
    local ring = RangeCircle.ActiveRing()
    local alpha = toNumber(value, ring.alpha)
    if alpha > 1 then alpha = alpha / 100 end
    ring.alpha = clamp(alpha, 0.05, 1.00)
    ring.enabled = true
    RangeCircle.Apply()
    RangeCircle.Print("ring " .. tostring(RangeCircle.Settings.activeRing) .. " alpha set to " .. tostring(math.floor(ring.alpha * 100)) .. "%")
end

function RangeCircle.SetColor(r, g, b)
    local ring = RangeCircle.ActiveRing()
    ring.r = clamp(toNumber(r, ring.r), 0, 255)
    ring.g = clamp(toNumber(g, ring.g), 0, 255)
    ring.b = clamp(toNumber(b, ring.b), 0, 255)
    ring.enabled = true
    RangeCircle.Apply()
    RangeCircle.Print("ring " .. tostring(RangeCircle.Settings.activeRing) .. " color set to " .. tostring(round(ring.r)) .. " " .. tostring(round(ring.g)) .. " " .. tostring(round(ring.b)))
end

function RangeCircle.SetLineThickness(value)
    local ring = RangeCircle.ActiveRing()
    value = string.lower(tostring(value or "auto"))

    if value == "medium" then value = "normal" end

    if value ~= "auto" and value ~= "thin" and value ~= "normal" and value ~= "bold" then
        RangeCircle.Print("unknown line thickness. Use: auto, thin, normal or bold")
        return
    end

    ring.thickness = value
    ring.enabled = true
    RangeCircle.Apply()
    RangeCircle.Print("ring " .. tostring(RangeCircle.Settings.activeRing) .. " line thickness set to " .. value)
end

function RangeCircle.SetPreset(key)
    RangeCircle.EnsureSettings()
    key = tostring(key or "")

    local presetFeet = RangeCircle.PresetFeet[key]
    if presetFeet == nil then
        RangeCircle.Print("unknown preset. Available: 10, 20, 25, 30, 40, 45")
        return
    end

    local ring = RangeCircle.ActiveRing()
    local width = RangeCircle.PresetWidths[key] or ((RangeCircle.PresetWidths["20"] or 1440) / 20 * presetFeet)
    local flatten = RangeCircle.DEFAULT_FLATTEN

    ring.projectedFeet = presetFeet
    ring.width = width
    ring.height = clamp(width * flatten, 10, 3000)
    ring.preset = key
    ring.name = key .. " ft"
    ring.enabled = true

    RangeCircle.Apply()
    if RangeCircle.Settings ~= nil and RangeCircle.Settings.mode == "projected" then
        RangeCircle.ProjectedUpdate(true)
    end
    RangeCircle.Print("ring " .. tostring(RangeCircle.Settings.activeRing) .. " projected range set to " .. key .. " ft")
end

function RangeCircle.SetScreenOffset(x, y)
    RangeCircle.EnsureSettings()
    RangeCircle.Settings.mode = "projected"
    RangeCircle.Settings.x = clamp(toNumber(x, RangeCircle.Settings.x), -2000, 2000)
    RangeCircle.Settings.y = clamp(toNumber(y, RangeCircle.Settings.y), -2000, 2000)
    RangeCircle.Apply()
    RangeCircle.Print("screen/projected offset set to x=" .. tostring(round(RangeCircle.Settings.x)) .. " y=" .. tostring(round(RangeCircle.Settings.y)))
end

function RangeCircle.SetOverlayOffset(x, y)
    RangeCircle.EnsureSettings()
    RangeCircle.Settings.x = clamp(toNumber(x, RangeCircle.Settings.x), -2000, 2000)
    RangeCircle.Settings.y = clamp(toNumber(y, RangeCircle.Settings.y), -2000, 2000)
    RangeCircle.Apply()
    if RangeCircle.Settings.mode == "projected" then
        RangeCircle.ProjectedUpdate(true)
    end
    RangeCircle.Print("overlay offset set to x=" .. tostring(round(RangeCircle.Settings.x)) .. " y=" .. tostring(round(RangeCircle.Settings.y)))
end

function RangeCircle.NudgeOverlay(dx, dy)
    RangeCircle.EnsureSettings()
    RangeCircle.SetOverlayOffset(toNumber(RangeCircle.Settings.x, 0) + toNumber(dx, 0), toNumber(RangeCircle.Settings.y, 0) + toNumber(dy, 0))
end

function RangeCircle.Center()
    RangeCircle.EnsureSettings()
    RangeCircle.Settings.mode = "projected"
    RangeCircle.Settings.x = 0
    RangeCircle.Settings.y = 0
    RangeCircle.Apply()
    RangeCircle.ProjectedUpdate(true)
    RangeCircle.Print("projected offset reset to 0,0")
end

function RangeCircle.LabelToggle()
    RangeCircle.EnsureSettings()
    RangeCircle.Settings.label = not RangeCircle.Settings.label
    RangeCircle.Apply()
    RangeCircle.Print("label " .. (RangeCircle.Settings.label and "enabled" or "disabled"))
end

function RangeCircle.DotToggle()
    RangeCircle.EnsureSettings()
    RangeCircle.Settings.dot = not RangeCircle.Settings.dot
    RangeCircle.Apply()
    RangeCircle.Print("center dot " .. (RangeCircle.Settings.dot and "enabled" or "disabled"))
end

function RangeCircle.OneRing()
    RangeCircle.EnsureSettings()
    for i = 1, 3 do
        RangeCircle.Settings.rings[i].enabled = (i == RangeCircle.Settings.activeRing)
    end
    RangeCircle.Apply()
    RangeCircle.Print("only ring " .. tostring(RangeCircle.Settings.activeRing) .. " enabled")
end

function RangeCircle.ThreeRings()
    RangeCircle.EnsureSettings()

    RangeCircle.Settings.activeRing = 1
    RangeCircle.Settings.rings[1] = deepCopy(RangeCircle.DefaultRings[3])
    RangeCircle.Settings.rings[1].enabled = true

    RangeCircle.Settings.rings[2] = deepCopy(RangeCircle.DefaultRings[1])
    RangeCircle.Settings.rings[2].enabled = true

    RangeCircle.Settings.rings[3] = deepCopy(RangeCircle.DefaultRings[2])
    RangeCircle.Settings.rings[3].enabled = true

    RangeCircle.Settings.locked = true
    RangeCircle.Settings.showing = true
    RangeCircle.Settings.mode = "projected"
    RangeCircle.Settings.label = false
    RangeCircle.Settings.dot = false

    RangeCircle.Apply()
    RangeCircle.Print("three-ring projected test enabled: 10 ft, 20 ft and 30 ft")
end

function RangeCircle.GroundTest()
    RangeCircle.DetachFromPlayer()
    RangeCircle.Settings = defaultSettings()
    RangeCircle.Settings.showing = true
    RangeCircle.Settings.locked = true
    RangeCircle.Settings.mode = "projected"
    RangeCircle.Settings.label = false
    RangeCircle.Settings.dot = false
    RangeCircle.Apply()
    RangeCircle.Print("projected test: one projected circle enabled")
end

function RangeCircle.Reset()
    RangeCircle.DetachFromPlayer()
    RangeCircle.Settings = defaultSettings()
    RangeCircle.Apply()
    RangeCircle.Print("settings reset to " .. RangeCircle.VERSION .. " defaults")
end

function RangeCircle.ResetDefaultRanges()
    RangeCircle.EnsureSettings()
    local activeRing = RangeCircle.Settings.activeRing or 1
    RangeCircle.Settings.rings = deepCopy(RangeCircle.DefaultRings)
    RangeCircle.Settings.activeRing = math.floor(clamp(toNumber(activeRing, 1), 1, 3))
    RangeCircle.Apply()
    if RangeCircle.ProjectedUpdate ~= nil then
        RangeCircle.ProjectedUpdate(true)
    end
    RangeCircle.Print("default ring ranges restored: Ring 1 = 20 ft, Ring 2 = 30 ft, Ring 3 = 10 ft")
end

function RangeCircle.Status()
    RangeCircle.EnsureSettings()
    RangeCircle.Print("mode=" .. tostring(RangeCircle.Settings.mode) .. " screenOffset=" .. tostring(round(RangeCircle.Settings.x)) .. "," .. tostring(round(RangeCircle.Settings.y)) .. " activeRing=" .. tostring(RangeCircle.Settings.activeRing) .. " projectedQuality=" .. tostring(RangeCircle.Settings.projectedQuality) .. " zoffset=" .. tostring(RangeCircle.Settings.projectedGroundOffsetFeet))

    for i = 1, 3 do
        local ring = RangeCircle.Settings.rings[i]
        local state = ring.enabled and "ON" or "off"
        RangeCircle.Print("ring " .. tostring(i) .. " " .. state .. " " .. tostring(ring.name) .. " size=" .. tostring(round(ring.width)) .. "x" .. tostring(round(ring.height)) .. " offset=" .. tostring(round(ring.offsetX)) .. "," .. tostring(round(ring.offsetY)) .. " alpha=" .. tostring(math.floor(ring.alpha * 100)) .. "%")
    end
end


function RangeCircle.ShowConfigWindow()
    if not RangeCircle.CreateConfigWindow() then
        return
    end
    if WindowSetShowing ~= nil then
        pcall(WindowSetShowing, CONFIG_WINDOW, true)
    end
    RangeCircle.UpdateConfigWindow()
end

function RangeCircle.HideConfigWindow()
    if windowExists(CONFIG_WINDOW) and WindowSetShowing ~= nil then
        pcall(WindowSetShowing, CONFIG_WINDOW, false)
    end
end

function RangeCircle.ToggleConfigWindow()
    if not windowExists(CONFIG_WINDOW) then
        RangeCircle.ShowConfigWindow()
        return
    end

    if WindowGetShowing ~= nil then
        local showing = false
        local ok, result = pcall(WindowGetShowing, CONFIG_WINDOW)
        if ok then showing = result == true end
        if showing then
            RangeCircle.HideConfigWindow()
        else
            RangeCircle.ShowConfigWindow()
        end
    else
        RangeCircle.ShowConfigWindow()
    end
end

function RangeCircle.SetLabelTextSafe(name, value)
    if windowExists(name) and LabelSetText ~= nil then
        pcall(LabelSetText, name, wtext(value))
    end
end

function RangeCircle.SetButtonTextSafe(name, value)
    if windowExists(name) and ButtonSetText ~= nil then
        pcall(ButtonSetText, name, wtext(value))
    end
end

function RangeCircle.UpdateConfigWindow()
    if not windowExists(CONFIG_WINDOW) then
        return
    end

    RangeCircle.EnsureSettings()
    local s = RangeCircle.Settings
    local ring = RangeCircle.ActiveRing()
    local feet = RangeCircle.ProjectedRingFeet(ring)

    RangeCircle.SetLabelTextSafe("RangeCircleConfigWindowHeader", "RangeCircle - Projected Mode")
    RangeCircle.SetLabelTextSafe("RangeCircleConfigWindowHint", "Projection-only build. Use nudge controls to centre the circle on your character.")
    RangeCircle.SetLabelTextSafe("RangeCircleConfigWindowSectionGeneral", "1. General")
    RangeCircle.SetLabelTextSafe("RangeCircleConfigWindowSectionRing", "2. Active ring")
    RangeCircle.SetLabelTextSafe("RangeCircleConfigWindowSectionPreset", "3. Range preset")
    RangeCircle.SetLabelTextSafe("RangeCircleConfigWindowSectionProjection", "4. Projection tuning")
    RangeCircle.SetLabelTextSafe("RangeCircleConfigWindowSectionQuality", "5. Quality")
    RangeCircle.SetLabelTextSafe("RangeCircleConfigWindowSectionColour", "6. Colours")

    RangeCircle.SetLabelTextSafe("RangeCircleConfigWindowInfoPanelInfo1", "Status: " .. (s.showing and "visible" or "hidden") .. " | mode=projected only | quality=" .. tostring(s.projectedQuality))
    RangeCircle.SetLabelTextSafe("RangeCircleConfigWindowInfoPanelInfo2", "Active ring: " .. tostring(s.activeRing) .. " | " .. (ring.enabled and "enabled" or "disabled") .. " | range=" .. tostring(feet) .. " ft")
    RangeCircle.SetLabelTextSafe("RangeCircleConfigWindowInfoPanelInfo3", "Projection offset: " .. tostring(round(s.x)) .. "," .. tostring(round(s.y)) .. " | z offset=" .. tostring(s.projectedGroundOffsetFeet) .. " ft | point size=" .. tostring(round(s.projectedPointSize)) .. " px")
    RangeCircle.SetLabelTextSafe("RangeCircleConfigWindowInfoPanelInfo4", "Opacity: " .. tostring(math.floor(ring.alpha * 100 + 0.5)) .. "% | RGB=" .. tostring(round(ring.r)) .. "," .. tostring(round(ring.g)) .. "," .. tostring(round(ring.b)))

    RangeCircle.SetButtonTextSafe("RangeCircleConfigWindowShowButton", s.showing and "Hide rings" or "Show rings")
    RangeCircle.SetButtonTextSafe("RangeCircleConfigWindowCenterButton", "Reset centre")
    RangeCircle.SetButtonTextSafe("RangeCircleConfigWindowResetButton", "Reset all")

    RangeCircle.SetButtonTextSafe("RangeCircleConfigWindowRing1Button", s.activeRing == 1 and "[Ring 1]" or "Ring 1")
    RangeCircle.SetButtonTextSafe("RangeCircleConfigWindowRing2Button", s.activeRing == 2 and "[Ring 2]" or "Ring 2")
    RangeCircle.SetButtonTextSafe("RangeCircleConfigWindowRing3Button", s.activeRing == 3 and "[Ring 3]" or "Ring 3")
    RangeCircle.SetButtonTextSafe("RangeCircleConfigWindowEnableButton", ring.enabled and "Disable ring" or "Enable ring")
    RangeCircle.SetButtonTextSafe("RangeCircleConfigWindowOneButton", "Only this")
    RangeCircle.SetButtonTextSafe("RangeCircleConfigWindowThreeButton", "3 rings")

    for _, p in ipairs({"10","20","25","30","40","45"}) do
        RangeCircle.SetButtonTextSafe("RangeCircleConfigWindowPreset" .. p .. "Button", p .. " ft")
    end

    RangeCircle.SetButtonTextSafe("RangeCircleConfigWindowRangeMinusButton", "Range -1 ft")
    RangeCircle.SetButtonTextSafe("RangeCircleConfigWindowRangePlusButton", "Range +1 ft")
    RangeCircle.SetButtonTextSafe("RangeCircleConfigWindowDefaultRangesButton", "Default ranges")

    RangeCircle.SetButtonTextSafe("RangeCircleConfigWindowNudgeLeftButton", "Nudge left")
    RangeCircle.SetButtonTextSafe("RangeCircleConfigWindowNudgeRightButton", "Nudge right")
    RangeCircle.SetButtonTextSafe("RangeCircleConfigWindowNudgeUpButton", "Nudge up")
    RangeCircle.SetButtonTextSafe("RangeCircleConfigWindowNudgeDownButton", "Nudge down")
    RangeCircle.SetButtonTextSafe("RangeCircleConfigWindowZOffsetMinusButton", "Z offset -")
    RangeCircle.SetButtonTextSafe("RangeCircleConfigWindowZOffsetPlusButton", "Z offset +")
    RangeCircle.SetButtonTextSafe("RangeCircleConfigWindowPointSizeMinusButton", "Point size -")
    RangeCircle.SetButtonTextSafe("RangeCircleConfigWindowPointSizePlusButton", "Point size +")
    RangeCircle.SetButtonTextSafe("RangeCircleConfigWindowAlphaMinusButton", "Opacity -")
    RangeCircle.SetButtonTextSafe("RangeCircleConfigWindowAlphaPlusButton", "Opacity +")

    RangeCircle.SetButtonTextSafe("RangeCircleConfigWindowQualityLowButton", s.projectedQuality == "low" and "[Low]" or "Low")
    RangeCircle.SetButtonTextSafe("RangeCircleConfigWindowQualityNormalButton", s.projectedQuality == "normal" and "[Normal]" or "Normal")
    RangeCircle.SetButtonTextSafe("RangeCircleConfigWindowQualityHighButton", s.projectedQuality == "high" and "[High]" or "High")
    RangeCircle.SetButtonTextSafe("RangeCircleConfigWindowColorBlueButton", "Blue")
    RangeCircle.SetButtonTextSafe("RangeCircleConfigWindowColorGreenButton", "Green")
    RangeCircle.SetButtonTextSafe("RangeCircleConfigWindowColorYellowButton", "Yellow")
    RangeCircle.SetButtonTextSafe("RangeCircleConfigWindowColorRedButton", "Red")
    RangeCircle.SetButtonTextSafe("RangeCircleConfigWindowColorWhiteButton", "White")
    RangeCircle.SetButtonTextSafe("RangeCircleConfigWindowColorCyanButton", "Cyan")
    RangeCircle.SetButtonTextSafe("RangeCircleConfigWindowColorPurpleButton", "Purple")
    RangeCircle.SetButtonTextSafe("RangeCircleConfigWindowColorOrangeButton", "Orange")
    RangeCircle.SetButtonTextSafe("RangeCircleConfigWindowColorPinkButton", "Pink")
    RangeCircle.SetButtonTextSafe("RangeCircleConfigWindowColorLimeButton", "Lime")
end

function RangeCircle.AdjustActiveRing(deltaWidth, deltaHeight, deltaOffsetX, deltaOffsetY, deltaAlpha)
    local ring = RangeCircle.ActiveRing()
    if deltaWidth ~= nil and deltaWidth ~= 0 then
        ring.width = clamp(toNumber(ring.width, 200) + deltaWidth, 20, 3200)
    end
    if deltaHeight ~= nil and deltaHeight ~= 0 then
        ring.height = clamp(toNumber(ring.height, 100) + deltaHeight, 10, 1200)
    end
    if deltaOffsetX ~= nil and deltaOffsetX ~= 0 then
        ring.offsetX = clamp(toNumber(ring.offsetX, 0) + deltaOffsetX, -1000, 1000)
    end
    if deltaOffsetY ~= nil and deltaOffsetY ~= 0 then
        ring.offsetY = clamp(toNumber(ring.offsetY, 0) + deltaOffsetY, -1000, 1000)
    end
    if deltaAlpha ~= nil and deltaAlpha ~= 0 then
        ring.alpha = clamp(toNumber(ring.alpha, 0.8) + deltaAlpha, 0.05, 1.0)
    end
    ring.enabled = true
    ring.preset = "manual"
    if ring.name ~= nil then ring.name = "manual" end
    RangeCircle.Apply()
end

function RangeCircle.ConfigToggleShow() RangeCircle.Toggle() end
function RangeCircle.ConfigToggleLock() if RangeCircle.Settings ~= nil and RangeCircle.Settings.locked then RangeCircle.Unlock() else RangeCircle.Lock() end end
function RangeCircle.ConfigToggleMode() RangeCircle.SetMode("projected") end
function RangeCircle.ConfigCenter() RangeCircle.Center() end
function RangeCircle.ConfigReset() RangeCircle.Reset(); RangeCircle.ShowConfigWindow() end
function RangeCircle.ConfigSelectRing1() RangeCircle.SetActiveRing(1) end
function RangeCircle.ConfigSelectRing2() RangeCircle.SetActiveRing(2) end
function RangeCircle.ConfigSelectRing3() RangeCircle.SetActiveRing(3) end
function RangeCircle.ConfigToggleRingEnabled() RangeCircle.ToggleRing() end
function RangeCircle.ConfigOneRing() RangeCircle.OneRing() end
function RangeCircle.ConfigThreeRings() RangeCircle.ThreeRings() end
function RangeCircle.ConfigPreset10() RangeCircle.SetPreset("10") end
function RangeCircle.ConfigPreset20() RangeCircle.SetPreset("20") end
function RangeCircle.ConfigPreset25() RangeCircle.SetPreset("25") end
function RangeCircle.ConfigPreset30() RangeCircle.SetPreset("30") end
function RangeCircle.ConfigPreset40() RangeCircle.SetPreset("40") end
function RangeCircle.ConfigPreset45() RangeCircle.SetPreset("45") end
function RangeCircle.ConfigRangeMinus() RangeCircle.AdjustProjectedRangeFeet(-1) end
function RangeCircle.ConfigRangePlus() RangeCircle.AdjustProjectedRangeFeet(1) end
function RangeCircle.ConfigDefaultRanges() RangeCircle.ResetDefaultRanges() end
function RangeCircle.ConfigWidthMinus() RangeCircle.AdjustActiveRing(-20, 0, 0, 0, 0) end
function RangeCircle.ConfigWidthPlus() RangeCircle.AdjustActiveRing(20, 0, 0, 0, 0) end
function RangeCircle.ConfigHeightMinus() RangeCircle.AdjustActiveRing(0, -10, 0, 0, 0) end
function RangeCircle.ConfigHeightPlus() RangeCircle.AdjustActiveRing(0, 10, 0, 0, 0) end
function RangeCircle.ConfigVOffsetMinus() RangeCircle.AdjustActiveRing(0, 0, 0, -10, 0) end
function RangeCircle.ConfigVOffsetPlus() RangeCircle.AdjustActiveRing(0, 0, 0, 10, 0) end
function RangeCircle.ConfigHOffsetMinus() RangeCircle.AdjustActiveRing(0, 0, -10, 0, 0) end
function RangeCircle.ConfigHOffsetPlus() RangeCircle.AdjustActiveRing(0, 0, 10, 0, 0) end
function RangeCircle.ConfigAlphaMinus() local r = RangeCircle.ActiveRing(); RangeCircle.SetAlpha(toNumber(r.alpha, 0.85) - 0.05) end
function RangeCircle.ConfigAlphaPlus() local r = RangeCircle.ActiveRing(); RangeCircle.SetAlpha(toNumber(r.alpha, 0.85) + 0.05) end
function RangeCircle.ConfigColorBlue() RangeCircle.SetColor(80, 200, 255) end
function RangeCircle.ConfigColorGreen() RangeCircle.SetColor(100, 255, 120) end
function RangeCircle.ConfigColorYellow() RangeCircle.SetColor(255, 220, 80) end
function RangeCircle.ConfigColorRed() RangeCircle.SetColor(255, 90, 90) end
function RangeCircle.ConfigColorWhite() RangeCircle.SetColor(255, 255, 255) end
function RangeCircle.ConfigColorCyan() RangeCircle.SetColor(80, 255, 255) end
function RangeCircle.ConfigColorPurple() RangeCircle.SetColor(190, 110, 255) end
function RangeCircle.ConfigColorOrange() RangeCircle.SetColor(255, 160, 60) end
function RangeCircle.ConfigColorPink() RangeCircle.SetColor(255, 120, 210) end
function RangeCircle.ConfigColorLime() RangeCircle.SetColor(180, 255, 0) end
function RangeCircle.ConfigLineAuto() RangeCircle.SetLineThickness("auto") end
function RangeCircle.ConfigLineThin() RangeCircle.SetLineThickness("thin") end
function RangeCircle.ConfigLineNormal() RangeCircle.SetLineThickness("normal") end
function RangeCircle.ConfigLineBold() RangeCircle.SetLineThickness("bold") end
function RangeCircle.ConfigToggleLabel() RangeCircle.LabelToggle() end
function RangeCircle.ConfigToggleDot() RangeCircle.DotToggle() end



function RangeCircle.ConfigNudgeLeft() RangeCircle.NudgeOverlay(-10, 0) end
function RangeCircle.ConfigNudgeRight() RangeCircle.NudgeOverlay(10, 0) end
function RangeCircle.ConfigNudgeUp() RangeCircle.NudgeOverlay(0, -10) end
function RangeCircle.ConfigNudgeDown() RangeCircle.NudgeOverlay(0, 10) end
function RangeCircle.ConfigPointSizeMinus() RangeCircle.ProjectedSetPointSize(toNumber(RangeCircle.Settings.projectedPointSize, 20) - 2) end
function RangeCircle.ConfigPointSizePlus() RangeCircle.ProjectedSetPointSize(toNumber(RangeCircle.Settings.projectedPointSize, 20) + 2) end
function RangeCircle.ConfigZOffsetMinus() RangeCircle.ProjectedSetGroundOffset(toNumber(RangeCircle.Settings.projectedGroundOffsetFeet, 6) - 1) end
function RangeCircle.ConfigZOffsetPlus() RangeCircle.ProjectedSetGroundOffset(toNumber(RangeCircle.Settings.projectedGroundOffsetFeet, 6) + 1) end
function RangeCircle.ConfigQualityLow() RangeCircle.ProjectedSetQuality("low") end
function RangeCircle.ConfigQualityNormal() RangeCircle.ProjectedSetQuality("normal") end
function RangeCircle.ConfigQualityHigh() RangeCircle.ProjectedSetQuality("high") end

function RangeCircle.ProjectedPointWindowName(ringIndex, pointIndex)
    local state = projectedPointState(ringIndex, pointIndex)
    if state.name == nil then
        state.name = PROJECTED_POINT_PREFIX .. tostring(ringIndex) .. "_" .. tostring(pointIndex)
    end
    return state.name
end

function RangeCircle.ProjectedPointIconName(ringIndex, pointIndex)
    local state = projectedPointState(ringIndex, pointIndex)
    if state.iconName == nil then
        state.iconName = RangeCircle.ProjectedPointWindowName(ringIndex, pointIndex) .. "Icon"
    end
    return state.iconName
end

function RangeCircle.ProjectedSampleCount(settingsReady)
    -- This is the oversampling count around the real world circle.
    -- Displayed dots are then selected using screen-space spacing so that
    -- perspective does not leave large gaps on the long edges of big rings.
    if settingsReady ~= true then RangeCircle.EnsureSettings() end
    if RangeCircle.Settings.projectedQuality == "low" then return 180 end
    if RangeCircle.Settings.projectedQuality == "high" then return 360 end
    return 270
end

function RangeCircle.ProjectedDotSpacing(settingsReady)
    if settingsReady ~= true then RangeCircle.EnsureSettings() end
    local q = tostring(RangeCircle.Settings.projectedQuality or "normal")
    local multiplier = RangeCircle.PROJECTED_DOT_SPACING[q] or RangeCircle.PROJECTED_DOT_SPACING.normal
    return math.max(10, toNumber(RangeCircle.Settings.projectedPointSize, 20) * multiplier)
end

local function projectedEnsurePointWindow(ringIndex, pointIndex)
    local state = projectedPointState(ringIndex, pointIndex)
    if state.exists == true then return state end
    if CreateWindowFromTemplate == nil then return nil end

    local name = RangeCircle.ProjectedPointWindowName(ringIndex, pointIndex)
    if not windowExists(name) then
        pcall(CreateWindowFromTemplate, name, PROJECTED_POINT_TEMPLATE, "Root")
    end

    if not windowExists(name) then return nil end

    state.exists = true
    state.iconName = RangeCircle.ProjectedPointIconName(ringIndex, pointIndex)
    state.iconExists = windowExists(state.iconName)
    state.showing = false
    pcall(WindowSetShowing, name, false)
    pcall(WindowSetAlpha, name, 0.0)
    pcall(WindowSetHandleInput, name, false)
    return state
end

function RangeCircle.ProjectedPlacePoint(ringIndex, pointIndex, screenX, screenY, pointSize, pointHalf, unscale, tintR, tintG, tintB, alpha)
    local state = projectedEnsurePointWindow(ringIndex, pointIndex)
    if state == nil then return false end

    local offsetX = (screenX - pointHalf) * unscale
    local offsetY = (screenY - pointHalf) * unscale
    if state.offsetX ~= offsetX or state.offsetY ~= offsetY then
        if state.anchored == true and WindowSetOffsetFromParent ~= nil then
            pcall(WindowSetOffsetFromParent, state.name, offsetX, offsetY)
        else
            pcall(WindowClearAnchors, state.name)
            pcall(WindowAddAnchor, state.name, "topleft", "Root", "center", offsetX, offsetY)
            state.anchored = true
        end
        state.offsetX = offsetX
        state.offsetY = offsetY
    end

    if state.pointSize ~= pointSize then
        pcall(WindowSetDimensions, state.name, pointSize, pointSize)
        if state.iconExists == true then
            pcall(WindowSetDimensions, state.iconName, pointSize, pointSize)
        end
        state.pointSize = pointSize
    end

    if state.tintR ~= tintR or state.tintG ~= tintG or state.tintB ~= tintB or state.alpha ~= alpha then
        if state.iconExists == true then
            pcall(WindowSetTintColor, state.iconName, tintR, tintG, tintB)
            pcall(WindowSetAlpha, state.iconName, alpha)
        end
        pcall(WindowSetTintColor, state.name, tintR, tintG, tintB)
        pcall(WindowSetAlpha, state.name, alpha)
        state.tintR = tintR
        state.tintG = tintG
        state.tintB = tintB
        state.alpha = alpha
    end

    if state.showing ~= true then
        pcall(WindowSetShowing, state.name, true)
        state.showing = true
    end
    return true
end

function RangeCircle.ProjectedHideRingFrom(ringIndex, startIndex)
    local lastVisible = projectedVisibleCounts[ringIndex] or 0
    startIndex = math.max(1, startIndex or 1)
    for pointIndex = startIndex, lastVisible do
        local state = projectedPointState(ringIndex, pointIndex)
        if state.exists == true and state.showing == true then
            pcall(WindowSetShowing, state.name, false)
            state.showing = false
        end
    end
    projectedVisibleCounts[ringIndex] = math.min(lastVisible, startIndex - 1)
end

function RangeCircle.ProjectedCreateWindows()
    -- Windows are created lazily by ProjectedPlacePoint. Preallocating all
    -- 1,080 points caused a large startup spike and every update used to walk
    -- that entire pool even when only one ring was enabled.
    if CreateWindowFromTemplate == nil then
        if projectedCreateWarningShown ~= true then
            RangeCircle.Print("CreateWindowFromTemplate API not available; projected mode cannot create points")
            projectedCreateWarningShown = true
        end
        return false
    end
    return true
end

function RangeCircle.ProjectedHideAll()
    for ringIndex = 1, PROJECTED_MAX_RINGS do
        RangeCircle.ProjectedHideRingFrom(ringIndex, 1)
    end
end
function RangeCircle.ProjectedRingFeet(ring)
    if ring == nil then return 20 end

    local customFeet = toNumber(ring.projectedFeet, nil)
    if customFeet ~= nil then
        return clamp(customFeet, 1, 200)
    end

    local preset = tostring(ring.preset or "")
    local feet = RangeCircle.PresetFeet[preset]
    if feet ~= nil then
        return feet
    end

    -- Fallback for very old saved manual rings.
    local width = toNumber(ring.width, RangeCircle.PresetWidths["20"] or 1440)
    local fallback = (width / (RangeCircle.PresetWidths["20"] or 1440)) * 20
    return clamp(fallback, 1, 200)
end

function RangeCircle.ProjectedSetQuality(value)
    RangeCircle.EnsureSettings()
    value = string.lower(tostring(value or "normal"))
    if value ~= "low" and value ~= "normal" and value ~= "high" then
        RangeCircle.Print("unknown projected quality. Use: low, normal or high")
        return
    end
    RangeCircle.Settings.projectedQuality = value
    RangeCircle.Apply()
    RangeCircle.ProjectedCreateWindows()
    RangeCircle.ProjectedUpdate(true)
    RangeCircle.Print("projected quality set to " .. value)
end

function RangeCircle.ProjectedSetGroundOffset(value)
    RangeCircle.EnsureSettings()
    RangeCircle.Settings.projectedGroundOffsetFeet = clamp(toNumber(value, RangeCircle.Settings.projectedGroundOffsetFeet), -20, 20)
    RangeCircle.ProjectedUpdate(true)
    RangeCircle.Print("projected ground offset set to " .. tostring(RangeCircle.Settings.projectedGroundOffsetFeet) .. " ft")
end

function RangeCircle.ProjectedSetPointSize(value)
    RangeCircle.EnsureSettings()
    RangeCircle.Settings.projectedPointSize = clamp(toNumber(value, RangeCircle.Settings.projectedPointSize), 6, 64)
    RangeCircle.ProjectedUpdate(true)
    RangeCircle.Print("projected point size set to " .. tostring(round(RangeCircle.Settings.projectedPointSize)) .. " px")
end

function RangeCircle.ProjectedUpdate(force)
    if RangeCircle.Settings == nil then
        RangeCircle.EnsureSettings()
    end

    if RangeCircle.Settings.mode ~= "projected" or RangeCircle.Settings.showing ~= true then
        RangeCircle.ProjectedHideAll()
        return
    end

    if WorldToScreen == nil or RangeCircle.Camera == nil or RangeCircle.Camera.GetPivotZonePosition == nil then
        RangeCircle.ProjectedHideAll()
        return
    end

    if not RangeCircle.ProjectedCreateWindows() then
        RangeCircle.ProjectedHideAll()
        return
    end

    local cameraPivotX, cameraPivotY, cameraPivotZ = RangeCircle.Camera.GetPivotZonePosition()
    if cameraPivotX == nil or cameraPivotY == nil or cameraPivotZ == nil then
        RangeCircle.ProjectedHideAll()
        return
    end

    local samples = RangeCircle.ProjectedSampleCount(true)
    local angles = projectedAngles(samples)
    local worldToScreen = WorldToScreen
    local unscale = 1.0 / 0.9
    local pointSize = round(RangeCircle.Settings.projectedPointSize)
    local pointHalf = pointSize / 2
    local pointZ = cameraPivotZ + (toNumber(RangeCircle.Settings.projectedGroundOffsetFeet, 6) * 12)
    -- Projected mode uses a screen-space calibration offset.
    -- This is needed because WorldToScreen projection gives us a useful world-space
    -- circle, but the visual origin may not perfectly match the player model/feet
    -- for every camera, mount, animation and UI scale. Use /rangecircle move x y
    -- to fine tune the projected overlay.
    local projectedOffsetX = toNumber(RangeCircle.Settings.x, 0)
    local projectedOffsetY = toNumber(RangeCircle.Settings.y, 0)

    local dotSpacing = RangeCircle.ProjectedDotSpacing(true)
    local dotSpacingSq = dotSpacing * dotSpacing
    local projectedUnitsPerFoot = toNumber(RangeCircle.PROJECTED_UNITS_PER_FOOT, 14)

    for ringIndex = 1, PROJECTED_MAX_RINGS do
        local ring = RangeCircle.Settings.rings[ringIndex]
        local visibleRing = ring ~= nil and ring.enabled == true

        if not visibleRing then
            RangeCircle.ProjectedHideRingFrom(ringIndex, 1)
        else
            local radiusFeet = RangeCircle.ProjectedRingFeet(ring)
            local radiusWorldUnits = radiusFeet * projectedUnitsPerFoot
            local tintR = toNumber(ring.r, 80)
            local tintG = toNumber(ring.g, 200)
            local tintB = toNumber(ring.b, 255)
            local alpha = clamp(toNumber(ring.alpha, 0.85), 0.05, 1.0)
            local displayedIndex = 0
            local lastX = nil
            local lastY = nil

            for sampleIndex = 1, samples do
                local px = cameraPivotX + (angles.cos[sampleIndex] * radiusWorldUnits)
                local py = cameraPivotY + (angles.sin[sampleIndex] * radiusWorldUnits)
                local screenVisible, screenX, screenY = worldToScreen(px, py, pointZ)

                if screenVisible == true then
                    screenX = screenX + projectedOffsetX
                    screenY = screenY + projectedOffsetY

                    local shouldPlace = false
                    if lastX == nil or lastY == nil then
                        shouldPlace = true
                    else
                        local dx = screenX - lastX
                        local dy = screenY - lastY
                        if ((dx * dx) + (dy * dy)) >= dotSpacingSq then
                            shouldPlace = true
                        end
                    end

                    if shouldPlace == true then
                        displayedIndex = displayedIndex + 1
                        if displayedIndex <= PROJECTED_MAX_POINTS then
                            RangeCircle.ProjectedPlacePoint(ringIndex, displayedIndex, screenX, screenY, pointSize, pointHalf, unscale, tintR, tintG, tintB, alpha)
                            lastX = screenX
                            lastY = screenY
                        else
                            break
                        end
                    end
                else
                    -- Visible segments can be discontinuous near the edge of the screen.
                    -- Reset spacing so the next visible segment gets a point immediately.
                    lastX = nil
                    lastY = nil
                end
            end

            RangeCircle.ProjectedHideRingFrom(ringIndex, displayedIndex + 1)
            projectedVisibleCounts[ringIndex] = displayedIndex
        end
    end
end
RangeCircle.ProjectedElapsed = 0

function RangeCircle.OnUpdate(timeDelta)
    local dt = toNumber(timeDelta, 0)
    RangeCircle.ProjectedElapsed = toNumber(RangeCircle.ProjectedElapsed, 0) + dt
    if RangeCircle.Settings ~= nil and RangeCircle.Settings.mode == "projected" and RangeCircle.Settings.showing == true then
        local rate = clamp(toNumber(RangeCircle.Settings.projectedUpdateRate, 0.04), 0.01, 0.25)
        if RangeCircle.ProjectedElapsed >= rate then
            RangeCircle.ProjectedElapsed = 0
            RangeCircle.ProjectedUpdate(false)
        end
    else
        if RangeCircle.ProjectedWasShowing == true then
            RangeCircle.ProjectedHideAll()
            RangeCircle.ProjectedWasShowing = false
        end
        RangeCircle.ProjectedElapsed = 0
        return
    end
    RangeCircle.ProjectedWasShowing = true
end
function RangeCircle.Help()
    RangeCircle.Print("/rangecircle menu | show | hide | toggle | reset | status")
    RangeCircle.Print("/rangecircle ring 1|2|3 | enable | disable | one | three")
    RangeCircle.Print("/rangecircle preset 10|20|25|30|40|45")
    RangeCircle.Print("/rangecircle move x y | nudge dx dy | center")
    RangeCircle.Print("/rangecircle range 17.5 | radius 17.5 | quality low|normal|high | zoffset 4 | pointsize 20")
    RangeCircle.Print("/rangecircle alpha 85 | color 80 200 255")
    RangeCircle.Print("Projection-only build: legacy 2D ellipse mode has been removed.")
end

local function splitArgs(input)
    local args = {}
    if input == nil then return args end
    input = tostring(input)
    for word in string.gmatch(input, "%S+") do
        table.insert(args, word)
    end
    return args
end

function RangeCircle.Slash(input)
    local args = splitArgs(input)
    local cmd = string.lower(args[1] or "")

    if cmd == "show" then
        RangeCircle.Show()
    elseif cmd == "hide" then
        RangeCircle.Hide()
    elseif cmd == "toggle" or cmd == "t" then
        RangeCircle.Toggle()
    elseif cmd == "lock" then
        RangeCircle.Lock()
    elseif cmd == "unlock" then
        RangeCircle.Unlock()
    elseif cmd == "menu" or cmd == "config" or cmd == "ui" then
        RangeCircle.ToggleConfigWindow()
    elseif cmd == "center" or cmd == "centre" then
        RangeCircle.Center()
    elseif cmd == "mode" then
        RangeCircle.SetMode(args[2])
    elseif cmd == "self" or cmd == "player" or cmd == "world" then
        RangeCircle.SetMode("projected")
    elseif cmd == "projected" or cmd == "projection" or cmd == "worldtoscreen" or cmd == "wts" then
        RangeCircle.SetMode("projected")
    elseif cmd == "screen" or cmd == "fixed" then
        RangeCircle.SetMode("projected")
    elseif cmd == "quality" or cmd == "q" then
        RangeCircle.ProjectedSetQuality(args[2])
    elseif cmd == "zoffset" or cmd == "groundoffset" then
        RangeCircle.ProjectedSetGroundOffset(args[2])
    elseif cmd == "pointsize" or cmd == "dotsize" then
        RangeCircle.ProjectedSetPointSize(args[2])
    elseif cmd == "ring" or cmd == "select" then
        RangeCircle.SetActiveRing(args[2])
    elseif cmd == "enable" or cmd == "on" then
        RangeCircle.EnableRing()
    elseif cmd == "disable" or cmd == "off" then
        RangeCircle.DisableRing()
    elseif cmd == "ringtoggle" or cmd == "rtoggle" then
        RangeCircle.ToggleRing()
    elseif cmd == "one" or cmd == "solo" then
        RangeCircle.OneRing()
    elseif cmd == "three" or cmd == "triple" then
        RangeCircle.ThreeRings()
    elseif cmd == "preset" or cmd == "p" then
        RangeCircle.SetPreset(args[2])
    elseif cmd == "range" or cmd == "feet" or cmd == "ft" or cmd == "radiusft" then
        RangeCircle.SetProjectedRangeFeet(args[2])
    elseif cmd == "rangeplus" then
        RangeCircle.AdjustProjectedRangeFeet(toNumber(args[2], 1))
    elseif cmd == "rangeminus" then
        RangeCircle.AdjustProjectedRangeFeet(-toNumber(args[2], 1))
    elseif cmd == "size" then
        RangeCircle.SetSize(args[2], args[3])
    elseif cmd == "width" or cmd == "w" then
        RangeCircle.SetWidth(args[2])
    elseif cmd == "height" or cmd == "h" then
        RangeCircle.SetHeight(args[2])
    elseif cmd == "radius" or cmd == "r" then
        RangeCircle.SetRadius(args[2])
    elseif cmd == "flatten" or cmd == "squash" then
        RangeCircle.SetFlatten(args[2])
    elseif cmd == "offset" or cmd == "ringoffset" then
        RangeCircle.SetOffset(args[2], args[3])
    elseif cmd == "voffset" then
        RangeCircle.SetOffset(nil, args[2])
    elseif cmd == "hoffset" then
        RangeCircle.SetOffset(args[2], nil)
    elseif cmd == "move" or cmd == "projectedoffset" or cmd == "poffset" then
        RangeCircle.SetOverlayOffset(args[2], args[3])
    elseif cmd == "nudge" then
        RangeCircle.NudgeOverlay(args[2], args[3])
    elseif cmd == "alpha" or cmd == "a" then
        RangeCircle.SetAlpha(args[2])
    elseif cmd == "color" or cmd == "colour" or cmd == "c" then
        RangeCircle.SetColor(args[2], args[3], args[4])
    elseif cmd == "line" or cmd == "thickness" or cmd == "stroke" then
        RangeCircle.SetLineThickness(args[2])
    elseif cmd == "label" then
        RangeCircle.LabelToggle()
    elseif cmd == "dot" then
        RangeCircle.DotToggle()
    elseif cmd == "groundtest" or cmd == "gtest" or cmd == "test" then
        RangeCircle.GroundTest()
    elseif cmd == "status" or cmd == "rings" then
        RangeCircle.Status()
    elseif cmd == "defaultranges" or cmd == "defaultpreset" or cmd == "defaultpresets" then
        RangeCircle.ResetDefaultRanges()
    elseif cmd == "reset" then
        RangeCircle.Reset()
    else
        RangeCircle.Help()
    end
end

local function tryRegisterSlash(command)
    if LibSlash == nil then
        return false
    end

    local fn = LibSlash.RegisterSlashCmd or LibSlash.RegisterSlashCommand or LibSlash.RegisterCommand
    if fn == nil then
        return false
    end

    local ok = pcall(fn, command, RangeCircle.Slash)
    return ok == true
end

function RangeCircle.RegisterSlashCommands()
    if RangeCircle.SlashRegistered == true then
        return true
    end

    local mainOk = tryRegisterSlash("rangecircle")
    local aliasOk = tryRegisterSlash("rc")

    RangeCircle.SlashRegistered = mainOk or aliasOk

    if not RangeCircle.SlashRegistered then
        RangeCircle.Print("LibSlash command registration failed. Try /script RangeCircle.Help()")
        return false
    end

    return true
end

function RangeCircle.OnLButtonUp(flags)
    if RangeCircle.Settings == nil then return end
    if RangeCircle.Settings.locked ~= true then
        RangeCircle.Print("position changed visually. If it does not persist after reload, use /rangecircle move x y for exact saved offset.")
    end
end

function RangeCircle.OnRButtonUp(flags)
    RangeCircle.Lock()
end

function RangeCircle.Initialize()
    RangeCircle.EnsureSettings()

    if not RangeCircle.CreateMainWindow() then
        return
    end

    if RangeCircle.Camera ~= nil and RangeCircle.Camera.OnInitialize ~= nil then
        RangeCircle.Camera.OnInitialize()
    end
    RangeCircle.CreateConfigWindow()
    RangeCircle.ProjectedCreateWindows()
    RangeCircle.RefreshTextures()
    RangeCircle.Apply()
    RangeCircle.RegisterSlashCommands()
    RangeCircle.UpdateConfigWindow()
    RangeCircle.Print("loaded v" .. RangeCircle.VERSION .. ". Use /rangecircle menu for the projected ring manager.")
end

function RangeCircle.Shutdown()
    RangeCircle.DetachFromPlayer()
    RangeCircle.ProjectedHideAll()
    if RangeCircle.Camera ~= nil and RangeCircle.Camera.OnShutdown ~= nil then
        RangeCircle.Camera.OnShutdown()
    end
end
