RangeCircle 1.0.2
=================

Creators: Gingerbel and Kpihuss

Configurable pseudo-ground range ellipse overlay for Return of Reckoning.

RangeCircle displays one or more calibrated 2D range ellipses on the UI layer. It is designed as a visual reference for aura awareness, guard positioning, short-range abilities and general spacing.

Important:
This is not a real 3D ground decal. It does not draw world geometry and it does not measure actual game distance.

Installation:
Copy the RangeCircle folder to:

Warhammer Online - Age of Reckoning\Interface\AddOns\RangeCircle

Requires LibSlash.

Open the in-game menu:

/rangecircle menu

Current presets:

10 ft = 380 px radius = 760 px diameter
20 ft = 720 px radius = 1440 px diameter
25 ft = 900 px radius = 1800 px diameter
30 ft = 1050 px radius = 2100 px diameter
45 ft = 1400 px radius = 2800 px width/diameter

Recommended first setup:

/rangecircle menu

Then select a ring, choose a preset, adjust depth/height for your normal camera angle, set line thickness to Auto or Thin, adjust opacity, and lock the overlay.

Useful commands:

/rangecircle show | hide | toggle
/rangecircle lock | unlock
/rangecircle center
/rangecircle ring 1|2|3
/rangecircle enable | disable | ringtoggle
/rangecircle one
/rangecircle three
/rangecircle preset 10|20|25|30|45
/rangecircle size 760 287
/rangecircle width 760
/rangecircle height 287
/rangecircle radius 380
/rangecircle flatten 38
/rangecircle voffset 110
/rangecircle offset 0 110
/rangecircle move 0 150
/rangecircle alpha 70
/rangecircle color 80 200 255
/rangecircle line auto|thin|normal|bold
/rangecircle label
/rangecircle dot
/rangecircle mode screen
/rangecircle mode self
/rangecircle status
/rangecircle reset

For the full manual, read MANUAL.txt included in this folder.

Version 1.0.2 notes:
- Corrected 45 ft preset to 1400 px radius / 2800 px width.
- Public release version.
- Presets use feet labels but are calibrated in pixels.
- Preset pixel values are treated as radius, not diameter.
- Default pseudo-ground depth reduced compared to early test versions.
- Auto/thin/normal/bold line thickness available.
