-- RangeCircle 1.0.2
-- Configurable pseudo-ground range ellipse overlay for Return of Reckoning.
-- This is a visual/calibrated overlay. It does not measure real 3D distance.
-- It draws screen-space ellipses intended to imitate a ground decal from the usual gameplay camera.

RangeCircle = RangeCircle or {}
RangeCircle.VERSION = "1.0.2"

local WINDOW = "RangeCircleWindow"
local DOT = "RangeCircleWindowCenterDot"
local TEXT = "RangeCircleWindowText"
local CONFIG_WINDOW = "RangeCircleConfigWindow"

local RING_WINDOWS = {
    [1] = "RangeCircleWindowRing1",
    [2] = "RangeCircleWindowRing2",
    [3] = "RangeCircleWindowRing3",
}

RangeCircle.DefaultRings = {
    [1] = {
        enabled = true,
        name = "20 ft",
        preset = "20",
        width = 1440,
        height = 544,
        offsetX = 0,
        offsetY = 110,
        alpha = 0.85,
        r = 80,
        g = 200,
        b = 255,
        thickness = "auto",
    },
    [2] = {
        enabled = false,
        name = "30 ft",
        preset = "30",
        width = 2100,
        height = 794,
        offsetX = 0,
        offsetY = 110,
        alpha = 0.60,
        r = 255,
        g = 220,
        b = 80,
        thickness = "auto",
    },
    [3] = {
        enabled = false,
        name = "10 ft",
        preset = "10",
        width = 760,
        height = 287,
        offsetX = 0,
        offsetY = 110,
        alpha = 0.75,
        r = 100,
        g = 255,
        b = 120,
        thickness = "auto",
    },
}

RangeCircle.Defaults = {
    showing = true,
    locked = true,
    mode = "screen", -- screen | self
    x = 0,
    y = 150,
    activeRing = 1,
    label = false,
    dot = false,
    calibrationVersion = 5,
    rings = nil,
}

RangeCircle.DEFAULT_FLATTEN = 0.378

RangeCircle.PresetWidths = {
    ["10"] = 760,
    ["20"] = 1440,
    ["25"] = 1800,
    ["30"] = 2100,
    ["45"] = 2800,
}

RangeCircle.RingTextureAssets = {
    thin = "rangecircle_ring_thin",
    normal = "rangecircle_ring_normal",
    bold = "rangecircle_ring_bold",
}

local function deepCopy(source)
    if type(source) ~= "table" then return source end
    local target = {}
    for k, v in pairs(source) do
        target[k] = deepCopy(v)
    end
    return target
end

local function defaultSettings()
    local t = deepCopy(RangeCircle.Defaults)
    t.rings = deepCopy(RangeCircle.DefaultRings)
    return t
end

local function toNumber(value, fallback)
    local n = tonumber(value)
    if n == nil then return fallback end
    return n
end

local function clamp(value, minValue, maxValue)
    value = toNumber(value, minValue)
    if value < minValue then return minValue end
    if value > maxValue then return maxValue end
    return value
end

local function round(value)
    return math.floor(toNumber(value, 0) + 0.5)
end

local function wtext(value)
    if towstring ~= nil then
        return towstring(tostring(value))
    end
    return tostring(value)
end

local function windowExists(name)
    return DoesWindowExist ~= nil and DoesWindowExist(name) == true
end

local function boolValue(value, fallback)
    if value == true then return true end
    if value == false then return false end
    return fallback
end

function RangeCircle.Print(message)
    local text = L"[RangeCircle] " .. wtext(message)

    if TextLogAddEntry ~= nil then
        local ok = pcall(TextLogAddEntry, "Chat", 0, text)
        if ok then return end
    end

    if EA_ChatWindow ~= nil and EA_ChatWindow.Print ~= nil then
        local ok = pcall(EA_ChatWindow.Print, text)
        if ok then return end
    end

    if d ~= nil then
        pcall(d, text)
    end
end

function RangeCircle.MigrateOldSettings()
    if RangeCircle.Settings == nil or RangeCircle.Settings.rings ~= nil then
        return
    end

    local old = RangeCircle.Settings
    local migrated = defaultSettings()

    migrated.showing = boolValue(old.showing, migrated.showing)
    migrated.locked = boolValue(old.locked, migrated.locked)
    migrated.mode = tostring(old.mode or migrated.mode)
    migrated.x = toNumber(old.x, migrated.x)
    migrated.y = toNumber(old.y, migrated.y)
    migrated.label = boolValue(old.label, false)
    migrated.dot = boolValue(old.dot, false)
    migrated.calibrationVersion = 1

    local radius = toNumber(old.radius, nil)
    if radius ~= nil then
        migrated.rings[1].width = clamp(radius * 2, 20, 3200)
        local flatten = toNumber(old.flatten, RangeCircle.DEFAULT_FLATTEN)
        migrated.rings[1].height = clamp(migrated.rings[1].width * clamp(flatten, 0.10, 1.00), 10, 1200)
    end

    migrated.rings[1].offsetX = toNumber(old.ringOffsetX, migrated.rings[1].offsetX)
    migrated.rings[1].offsetY = toNumber(old.ringOffsetY, migrated.rings[1].offsetY)
    migrated.rings[1].alpha = clamp(toNumber(old.alpha, migrated.rings[1].alpha), 0.05, 1.00)
    migrated.rings[1].r = clamp(toNumber(old.r, migrated.rings[1].r), 0, 255)
    migrated.rings[1].g = clamp(toNumber(old.g, migrated.rings[1].g), 0, 255)
    migrated.rings[1].b = clamp(toNumber(old.b, migrated.rings[1].b), 0, 255)
    migrated.rings[1].preset = tostring(old.preset or migrated.rings[1].preset)
    migrated.rings[1].name = migrated.rings[1].preset .. " ft"

    RangeCircle.Settings = migrated
end

function RangeCircle.MigratePresetCalibration()
    if RangeCircle.Settings == nil then return end
    if RangeCircle.Settings.calibrationVersion == 5 then return end

    if RangeCircle.Settings.rings == nil then
        RangeCircle.Settings.rings = deepCopy(RangeCircle.DefaultRings)
    end

    for i = 1, 3 do
        local current = RangeCircle.Settings.rings[i]
        local def = RangeCircle.DefaultRings[i]

        if current == nil then
            RangeCircle.Settings.rings[i] = deepCopy(def)
        else
            local enabled = boolValue(current.enabled, def.enabled)
            local offsetX = toNumber(current.offsetX, def.offsetX)
            local offsetY = toNumber(current.offsetY, def.offsetY)
            local alpha = clamp(toNumber(current.alpha, def.alpha), 0.05, 1.00)
            local r = clamp(toNumber(current.r, def.r), 0, 255)
            local g = clamp(toNumber(current.g, def.g), 0, 255)
            local b = clamp(toNumber(current.b, def.b), 0, 255)
            local thickness = tostring(current.thickness or def.thickness or "auto")
            local preset = tostring(current.preset or def.preset)
            local width = RangeCircle.PresetWidths[preset] or def.width

            current.enabled = enabled
            current.preset = RangeCircle.PresetWidths[preset] and preset or def.preset
            current.name = current.preset .. " ft"
            current.width = width
            current.height = clamp(width * RangeCircle.DEFAULT_FLATTEN, 10, 1200)
            current.offsetX = offsetX
            current.offsetY = offsetY
            current.alpha = alpha
            current.r = r
            current.g = g
            current.b = b
            current.thickness = thickness
        end
    end

    RangeCircle.Settings.calibrationVersion = 5
end

function RangeCircle.EnsureSettings()
    if RangeCircle.Settings == nil then
        RangeCircle.Settings = defaultSettings()
    end

    RangeCircle.MigrateOldSettings()
    RangeCircle.MigratePresetCalibration()

    for k, v in pairs(RangeCircle.Defaults) do
        if k ~= "rings" and RangeCircle.Settings[k] == nil then
            RangeCircle.Settings[k] = v
        end
    end

    if RangeCircle.Settings.rings == nil then
        RangeCircle.Settings.rings = deepCopy(RangeCircle.DefaultRings)
    end

    for i = 1, 3 do
        if RangeCircle.Settings.rings[i] == nil then
            RangeCircle.Settings.rings[i] = deepCopy(RangeCircle.DefaultRings[i])
        end

        local ring = RangeCircle.Settings.rings[i]
        local def = RangeCircle.DefaultRings[i]

        for k, v in pairs(def) do
            if ring[k] == nil then
                ring[k] = v
            end
        end

        ring.enabled = boolValue(ring.enabled, def.enabled)
        ring.name = tostring(ring.name or def.name)
        ring.preset = tostring(ring.preset or def.preset)
        ring.width = clamp(toNumber(ring.width, def.width), 20, 3200)
        ring.height = clamp(toNumber(ring.height, def.height), 10, 1200)
        ring.offsetX = clamp(toNumber(ring.offsetX, def.offsetX), -1000, 1000)
        ring.offsetY = clamp(toNumber(ring.offsetY, def.offsetY), -1000, 1000)
        ring.alpha = clamp(toNumber(ring.alpha, def.alpha), 0.05, 1.00)
        ring.r = clamp(toNumber(ring.r, def.r), 0, 255)
        ring.g = clamp(toNumber(ring.g, def.g), 0, 255)
        ring.b = clamp(toNumber(ring.b, def.b), 0, 255)
        ring.thickness = tostring(ring.thickness or def.thickness or "auto")
        if ring.thickness ~= "auto" and ring.thickness ~= "thin" and ring.thickness ~= "normal" and ring.thickness ~= "bold" then
            ring.thickness = "auto"
        end
    end

    RangeCircle.Settings.activeRing = clamp(toNumber(RangeCircle.Settings.activeRing, 1), 1, 3)
    RangeCircle.Settings.activeRing = math.floor(RangeCircle.Settings.activeRing)

    if RangeCircle.Settings.mode ~= "screen" and RangeCircle.Settings.mode ~= "self" then
        RangeCircle.Settings.mode = "screen"
    end

    RangeCircle.Settings.x = clamp(toNumber(RangeCircle.Settings.x, 0), -2000, 2000)
    RangeCircle.Settings.y = clamp(toNumber(RangeCircle.Settings.y, 150), -2000, 2000)
    RangeCircle.Settings.showing = boolValue(RangeCircle.Settings.showing, true)
    RangeCircle.Settings.locked = boolValue(RangeCircle.Settings.locked, true)
    RangeCircle.Settings.label = boolValue(RangeCircle.Settings.label, false)
    RangeCircle.Settings.dot = boolValue(RangeCircle.Settings.dot, false)
end

function RangeCircle.ActiveRing()
    RangeCircle.EnsureSettings()
    return RangeCircle.Settings.rings[RangeCircle.Settings.activeRing]
end

function RangeCircle.CreateMainWindow()
    if windowExists(WINDOW) then
        return true
    end

    if CreateWindow == nil then
        RangeCircle.Print("ERROR: CreateWindow API not available")
        return false
    end

    local ok, err = pcall(CreateWindow, WINDOW, true)
    if not ok then
        RangeCircle.Print("ERROR: CreateWindow failed: " .. tostring(err))
        return false
    end

    if not windowExists(WINDOW) then
        RangeCircle.Print("ERROR: " .. WINDOW .. " was not created. Check RangeCircle.xml syntax/load order.")
        return false
    end

    if WindowSetLayer ~= nil and Window ~= nil and Window.Layers ~= nil and Window.Layers.POPUP ~= nil then
        pcall(WindowSetLayer, WINDOW, Window.Layers.POPUP)
    end

    return true
end


function RangeCircle.CreateConfigWindow()
    if windowExists(CONFIG_WINDOW) then
        return true
    end

    if CreateWindow == nil then
        RangeCircle.Print("ERROR: CreateWindow API not available for config window")
        return false
    end

    local ok, err = pcall(CreateWindow, CONFIG_WINDOW, false)
    if not ok then
        RangeCircle.Print("ERROR: CreateWindow config failed: " .. tostring(err))
        return false
    end

    if not windowExists(CONFIG_WINDOW) then
        RangeCircle.Print("ERROR: " .. CONFIG_WINDOW .. " was not created.")
        return false
    end

    if WindowSetLayer ~= nil and Window ~= nil and Window.Layers ~= nil and Window.Layers.POPUP ~= nil then
        pcall(WindowSetLayer, CONFIG_WINDOW, Window.Layers.POPUP)
    end

    return true
end

function RangeCircle.GetRingTextureAsset(ring)
    local thickness = tostring(ring.thickness or "auto")

    if thickness == "auto" then
        local width = toNumber(ring.width, 570)
        if width >= 650 then
            thickness = "thin"
        elseif width >= 360 then
            thickness = "normal"
        else
            thickness = "bold"
        end
    end

    return RangeCircle.RingTextureAssets[thickness] or RangeCircle.RingTextureAssets.normal
end

function RangeCircle.RefreshTextures()
    if DynamicImageSetTexture == nil then return end
    RangeCircle.EnsureSettings()

    for i = 1, 3 do
        if windowExists(RING_WINDOWS[i]) then
            local ring = RangeCircle.Settings.rings[i]
            pcall(DynamicImageSetTexture, RING_WINDOWS[i], RangeCircle.GetRingTextureAsset(ring), 0, 0)
        end
    end

    if windowExists(DOT) then
        pcall(DynamicImageSetTexture, DOT, "rangecircle_dot", 0, 0)
    end
end

function RangeCircle.DetachFromPlayer()
    if RangeCircle.AttachedObjectId ~= nil and DetachWindowFromWorldObject ~= nil then
        pcall(DetachWindowFromWorldObject, WINDOW, RangeCircle.AttachedObjectId)
    end
    RangeCircle.AttachedObjectId = nil
end

function RangeCircle.AttachToPlayer()
    if AttachWindowToWorldObject == nil then
        RangeCircle.Print("AttachWindowToWorldObject API not available; using screen mode")
        RangeCircle.Settings.mode = "screen"
        return false
    end

    if GameData == nil or GameData.Player == nil or GameData.Player.worldObjNum == nil or GameData.Player.worldObjNum == 0 then
        RangeCircle.Print("player world object id not available yet; using screen mode")
        RangeCircle.Settings.mode = "screen"
        return false
    end

    local id = GameData.Player.worldObjNum
    if RangeCircle.AttachedObjectId ~= id then
        RangeCircle.DetachFromPlayer()
        local ok, err = pcall(AttachWindowToWorldObject, WINDOW, id)
        if not ok then
            RangeCircle.Print("AttachWindowToWorldObject failed: " .. tostring(err))
            RangeCircle.Settings.mode = "screen"
            return false
        end
        RangeCircle.AttachedObjectId = id
    end

    return true
end

function RangeCircle.ApplyPosition()
    local s = RangeCircle.Settings

    if s.mode == "self" then
        RangeCircle.AttachToPlayer()
    end

    if s.mode ~= "self" then
        RangeCircle.DetachFromPlayer()
        if WindowClearAnchors ~= nil and WindowAddAnchor ~= nil then
            pcall(WindowClearAnchors, WINDOW)
            pcall(WindowAddAnchor, WINDOW, "center", "Root", "center", toNumber(s.x, 0), toNumber(s.y, 150))
        elseif WindowSetOffsetFromParent ~= nil then
            pcall(WindowSetOffsetFromParent, WINDOW, toNumber(s.x, 0), toNumber(s.y, 150))
        end
    end
end

function RangeCircle.ApplyLayout()
    local s = RangeCircle.Settings
    local maxHalfWidth = 420
    local maxHalfHeight = 260

    for i = 1, 3 do
        local ring = s.rings[i]
        local halfW = (toNumber(ring.width, 300) / 2) + math.abs(toNumber(ring.offsetX, 0))
        local top = toNumber(ring.offsetY, 0) - (toNumber(ring.height, 126) / 2)
        local bottom = toNumber(ring.offsetY, 0) + (toNumber(ring.height, 126) / 2)
        maxHalfWidth = math.max(maxHalfWidth, halfW + 80)
        maxHalfHeight = math.max(maxHalfHeight, math.abs(top) + 80, math.abs(bottom) + 80)
    end

    local parentWidth = clamp(round(maxHalfWidth * 2), 120, 3600)
    local parentHeight = clamp(round(maxHalfHeight * 2), 120, 1600)

    if WindowSetDimensions ~= nil then
        pcall(WindowSetDimensions, WINDOW, parentWidth, parentHeight)

        for i = 1, 3 do
            if windowExists(RING_WINDOWS[i]) then
                local ring = s.rings[i]
                pcall(WindowSetDimensions, RING_WINDOWS[i], round(ring.width), round(ring.height))
            end
        end

        if windowExists(DOT) then
            pcall(WindowSetDimensions, DOT, 10, 10)
        end

        if windowExists(TEXT) then
            pcall(WindowSetDimensions, TEXT, math.min(900, math.max(420, parentWidth - 40)), 26)
        end
    end

    if WindowClearAnchors ~= nil and WindowAddAnchor ~= nil then
        for i = 1, 3 do
            if windowExists(RING_WINDOWS[i]) then
                local ring = s.rings[i]
                pcall(WindowClearAnchors, RING_WINDOWS[i])
                pcall(WindowAddAnchor, RING_WINDOWS[i], "center", WINDOW, "center", toNumber(ring.offsetX, 0), toNumber(ring.offsetY, 110))
            end
        end

        local active = RangeCircle.ActiveRing()

        if windowExists(DOT) then
            pcall(WindowClearAnchors, DOT)
            pcall(WindowAddAnchor, DOT, "center", WINDOW, "center", toNumber(active.offsetX, 0), toNumber(active.offsetY, 110))
        end

        if windowExists(TEXT) then
            pcall(WindowClearAnchors, TEXT)
            pcall(WindowAddAnchor, TEXT, "bottom", RING_WINDOWS[s.activeRing], "top", 0, -4)
        end
    end
end

function RangeCircle.ApplyVisuals()
    local s = RangeCircle.Settings

    for i = 1, 3 do
        local ring = s.rings[i]
        local win = RING_WINDOWS[i]

        if windowExists(win) then
            if WindowSetTintColor ~= nil then
                pcall(WindowSetTintColor, win, toNumber(ring.r, 80), toNumber(ring.g, 200), toNumber(ring.b, 255))
            end
            if WindowSetAlpha ~= nil then
                pcall(WindowSetAlpha, win, clamp(toNumber(ring.alpha, 0.85), 0.05, 1.0))
            end
            if WindowSetShowing ~= nil then
                pcall(WindowSetShowing, win, s.showing == true and ring.enabled == true)
            end
            if WindowSetHandleInput ~= nil then
                pcall(WindowSetHandleInput, win, false)
            end
        end
    end

    if windowExists(DOT) then
        local active = RangeCircle.ActiveRing()
        if WindowSetTintColor ~= nil then
            pcall(WindowSetTintColor, DOT, toNumber(active.r, 80), toNumber(active.g, 200), toNumber(active.b, 255))
        end
        if WindowSetAlpha ~= nil then
            pcall(WindowSetAlpha, DOT, 0.90)
        end
        if WindowSetShowing ~= nil then
            pcall(WindowSetShowing, DOT, s.showing == true and (s.dot == true or s.locked ~= true))
        end
        if WindowSetHandleInput ~= nil then
            pcall(WindowSetHandleInput, DOT, false)
        end
    end

    if windowExists(TEXT) then
        if WindowSetShowing ~= nil then
            pcall(WindowSetShowing, TEXT, s.showing == true and (s.label == true or s.locked ~= true))
        end
        if WindowSetHandleInput ~= nil then
            pcall(WindowSetHandleInput, TEXT, false)
        end
        if LabelSetText ~= nil then
            local active = RangeCircle.ActiveRing()
            local msg = "RangeCircle " .. RangeCircle.VERSION .. " | ring " .. tostring(s.activeRing) .. " " .. tostring(active.name)
            msg = msg .. " | " .. tostring(round(active.width)) .. "x" .. tostring(round(active.height))
            msg = msg .. " | offset " .. tostring(round(active.offsetX)) .. "," .. tostring(round(active.offsetY))
            msg = msg .. " | " .. tostring(s.mode)
            if s.locked == true then msg = msg .. " | locked" else msg = msg .. " | unlocked" end
            pcall(LabelSetText, TEXT, wtext(msg))
        end
    end

    if WindowSetShowing ~= nil then
        pcall(WindowSetShowing, WINDOW, s.showing == true)
    end

    if WindowSetMovable ~= nil then
        pcall(WindowSetMovable, WINDOW, s.locked ~= true and s.mode == "screen")
    end

    if WindowSetHandleInput ~= nil then
        pcall(WindowSetHandleInput, WINDOW, s.locked ~= true and s.mode == "screen")
    end
end

function RangeCircle.Apply()
    RangeCircle.EnsureSettings()

    if not RangeCircle.CreateMainWindow() then
        return
    end

    RangeCircle.RefreshTextures()
    RangeCircle.ApplyLayout()
    RangeCircle.ApplyPosition()
    RangeCircle.ApplyVisuals()

    if RangeCircle.Settings.mode == "self" and RangeCircle.AttachedObjectId ~= nil then
        local id = RangeCircle.AttachedObjectId
        RangeCircle.AttachedObjectId = nil
        RangeCircle.DetachFromPlayer()
        RangeCircle.AttachedObjectId = nil
        if AttachWindowToWorldObject ~= nil then
            pcall(AttachWindowToWorldObject, WINDOW, id)
            RangeCircle.AttachedObjectId = id
        end
    end

    RangeCircle.UpdateConfigWindow()
end

function RangeCircle.SetActiveRing(value)
    RangeCircle.EnsureSettings()
    local index = math.floor(clamp(toNumber(value, RangeCircle.Settings.activeRing), 1, 3))
    RangeCircle.Settings.activeRing = index
    RangeCircle.Apply()
    RangeCircle.Print("active ring set to " .. tostring(index))
end

function RangeCircle.SetMode(mode)
    RangeCircle.EnsureSettings()
    mode = string.lower(tostring(mode or ""))

    if mode == "player" or mode == "self" or mode == "me" or mode == "world" then
        RangeCircle.Settings.mode = "self"
        RangeCircle.Settings.locked = true
        RangeCircle.Settings.showing = true
        RangeCircle.Apply()
        RangeCircle.Print("mode set to self/world-object. It follows your character like Enemy marks, but remains a 2D billboard overlay.")
        return
    end

    if mode == "screen" or mode == "fixed" or mode == "ui" then
        RangeCircle.Settings.mode = "screen"
        RangeCircle.Apply()
        RangeCircle.Print("mode set to screen/fixed pseudo-ground overlay")
        return
    end

    RangeCircle.Print("unknown mode. Use: /rangecircle mode screen or /rangecircle mode self")
end

function RangeCircle.Show()
    RangeCircle.EnsureSettings()
    RangeCircle.Settings.showing = true
    RangeCircle.Apply()
end

function RangeCircle.Hide()
    RangeCircle.EnsureSettings()
    RangeCircle.Settings.showing = false
    RangeCircle.Apply()
end

function RangeCircle.Toggle()
    RangeCircle.EnsureSettings()
    RangeCircle.Settings.showing = not RangeCircle.Settings.showing
    RangeCircle.Apply()
end

function RangeCircle.Lock()
    RangeCircle.EnsureSettings()
    RangeCircle.Settings.locked = true
    RangeCircle.Apply()
    RangeCircle.Print("locked")
end

function RangeCircle.Unlock()
    RangeCircle.EnsureSettings()
    RangeCircle.Settings.mode = "screen"
    RangeCircle.Settings.locked = false
    RangeCircle.Settings.showing = true
    RangeCircle.Apply()
    RangeCircle.Print("unlocked; drag the overlay, then use /rangecircle lock")
end

function RangeCircle.EnableRing()
    local ring = RangeCircle.ActiveRing()
    ring.enabled = true
    RangeCircle.Apply()
    RangeCircle.Print("ring " .. tostring(RangeCircle.Settings.activeRing) .. " enabled")
end

function RangeCircle.DisableRing()
    local ring = RangeCircle.ActiveRing()
    ring.enabled = false
    RangeCircle.Apply()
    RangeCircle.Print("ring " .. tostring(RangeCircle.Settings.activeRing) .. " disabled")
end

function RangeCircle.ToggleRing()
    local ring = RangeCircle.ActiveRing()
    ring.enabled = not ring.enabled
    RangeCircle.Apply()
    RangeCircle.Print("ring " .. tostring(RangeCircle.Settings.activeRing) .. " " .. (ring.enabled and "enabled" or "disabled"))
end

function RangeCircle.SetSize(width, height)
    local ring = RangeCircle.ActiveRing()
    ring.width = clamp(toNumber(width, ring.width), 20, 3200)
    ring.height = clamp(toNumber(height, ring.height), 10, 1200)
    ring.preset = "manual"
    ring.name = "manual"
    ring.enabled = true
    RangeCircle.Apply()
    RangeCircle.Print("ring " .. tostring(RangeCircle.Settings.activeRing) .. " size set to " .. tostring(round(ring.width)) .. "x" .. tostring(round(ring.height)))
end

function RangeCircle.SetWidth(width)
    local ring = RangeCircle.ActiveRing()
    ring.width = clamp(toNumber(width, ring.width), 20, 3200)
    ring.preset = "manual"
    ring.name = "manual"
    ring.enabled = true
    RangeCircle.Apply()
    RangeCircle.Print("ring " .. tostring(RangeCircle.Settings.activeRing) .. " width set to " .. tostring(round(ring.width)))
end

function RangeCircle.SetHeight(height)
    local ring = RangeCircle.ActiveRing()
    ring.height = clamp(toNumber(height, ring.height), 10, 1200)
    ring.preset = "manual"
    ring.name = "manual"
    ring.enabled = true
    RangeCircle.Apply()
    RangeCircle.Print("ring " .. tostring(RangeCircle.Settings.activeRing) .. " height set to " .. tostring(round(ring.height)))
end

function RangeCircle.SetRadius(value)
    local ring = RangeCircle.ActiveRing()
    local radius = clamp(toNumber(value, ring.width / 2), 10, 1200)
    local flatten = clamp(ring.height / ring.width, 0.10, 1.00)
    ring.width = radius * 2
    ring.height = ring.width * flatten
    ring.preset = "manual"
    ring.name = "manual"
    ring.enabled = true
    RangeCircle.Apply()
    RangeCircle.Print("ring " .. tostring(RangeCircle.Settings.activeRing) .. " radius set to " .. tostring(round(radius)) .. " px")
end

function RangeCircle.SetFlatten(value)
    local ring = RangeCircle.ActiveRing()
    local flatten = toNumber(value, ring.height / ring.width)
    if flatten > 1 then flatten = flatten / 100 end
    flatten = clamp(flatten, 0.10, 1.00)
    ring.height = clamp(ring.width * flatten, 10, 1200)
    ring.enabled = true
    RangeCircle.Apply()
    RangeCircle.Print("ring " .. tostring(RangeCircle.Settings.activeRing) .. " flatten set to " .. tostring(math.floor(flatten * 100)) .. "%")
end

function RangeCircle.SetOffset(x, y)
    local ring = RangeCircle.ActiveRing()
    if x ~= nil then ring.offsetX = clamp(toNumber(x, ring.offsetX), -1000, 1000) end
    if y ~= nil then ring.offsetY = clamp(toNumber(y, ring.offsetY), -1000, 1000) end
    RangeCircle.Apply()
    RangeCircle.Print("ring " .. tostring(RangeCircle.Settings.activeRing) .. " offset set to " .. tostring(round(ring.offsetX)) .. "," .. tostring(round(ring.offsetY)))
end

function RangeCircle.SetAlpha(value)
    local ring = RangeCircle.ActiveRing()
    local alpha = toNumber(value, ring.alpha)
    if alpha > 1 then alpha = alpha / 100 end
    ring.alpha = clamp(alpha, 0.05, 1.00)
    ring.enabled = true
    RangeCircle.Apply()
    RangeCircle.Print("ring " .. tostring(RangeCircle.Settings.activeRing) .. " alpha set to " .. tostring(math.floor(ring.alpha * 100)) .. "%")
end

function RangeCircle.SetColor(r, g, b)
    local ring = RangeCircle.ActiveRing()
    ring.r = clamp(toNumber(r, ring.r), 0, 255)
    ring.g = clamp(toNumber(g, ring.g), 0, 255)
    ring.b = clamp(toNumber(b, ring.b), 0, 255)
    ring.enabled = true
    RangeCircle.Apply()
    RangeCircle.Print("ring " .. tostring(RangeCircle.Settings.activeRing) .. " color set to " .. tostring(round(ring.r)) .. " " .. tostring(round(ring.g)) .. " " .. tostring(round(ring.b)))
end

function RangeCircle.SetLineThickness(value)
    local ring = RangeCircle.ActiveRing()
    value = string.lower(tostring(value or "auto"))

    if value == "medium" then value = "normal" end

    if value ~= "auto" and value ~= "thin" and value ~= "normal" and value ~= "bold" then
        RangeCircle.Print("unknown line thickness. Use: auto, thin, normal or bold")
        return
    end

    ring.thickness = value
    ring.enabled = true
    RangeCircle.Apply()
    RangeCircle.Print("ring " .. tostring(RangeCircle.Settings.activeRing) .. " line thickness set to " .. value)
end

function RangeCircle.SetPreset(key)
    RangeCircle.EnsureSettings()
    key = tostring(key or "")

    if RangeCircle.PresetWidths[key] == nil then
        RangeCircle.Print("unknown preset. Available: 10, 20, 25, 30, 45")
        return
    end

    local ring = RangeCircle.ActiveRing()
    local width = RangeCircle.PresetWidths[key]
    local flatten = clamp(toNumber(ring.height, width * RangeCircle.DEFAULT_FLATTEN) / math.max(toNumber(ring.width, width), 1), 0.10, 1.00)
    if flatten > 0.70 then flatten = RangeCircle.DEFAULT_FLATTEN end

    ring.width = width
    ring.height = clamp(width * flatten, 10, 1200)
    ring.preset = key
    ring.name = key .. " ft"
    ring.enabled = true

    RangeCircle.Apply()
    RangeCircle.Print("ring " .. tostring(RangeCircle.Settings.activeRing) .. " preset " .. key .. " ft selected (" .. tostring(round(width / 2)) .. " px radius)")
end

function RangeCircle.SetScreenOffset(x, y)
    RangeCircle.EnsureSettings()
    RangeCircle.Settings.mode = "screen"
    RangeCircle.Settings.x = clamp(toNumber(x, RangeCircle.Settings.x), -2000, 2000)
    RangeCircle.Settings.y = clamp(toNumber(y, RangeCircle.Settings.y), -2000, 2000)
    RangeCircle.Apply()
    RangeCircle.Print("screen offset set to x=" .. tostring(round(RangeCircle.Settings.x)) .. " y=" .. tostring(round(RangeCircle.Settings.y)))
end

function RangeCircle.Center()
    RangeCircle.EnsureSettings()
    RangeCircle.Settings.mode = "screen"
    RangeCircle.Settings.x = 0
    RangeCircle.Settings.y = 150
    RangeCircle.Apply()
    RangeCircle.Print("screen anchor reset to default pseudo-ground position")
end

function RangeCircle.LabelToggle()
    RangeCircle.EnsureSettings()
    RangeCircle.Settings.label = not RangeCircle.Settings.label
    RangeCircle.Apply()
    RangeCircle.Print("label " .. (RangeCircle.Settings.label and "enabled" or "disabled"))
end

function RangeCircle.DotToggle()
    RangeCircle.EnsureSettings()
    RangeCircle.Settings.dot = not RangeCircle.Settings.dot
    RangeCircle.Apply()
    RangeCircle.Print("center dot " .. (RangeCircle.Settings.dot and "enabled" or "disabled"))
end

function RangeCircle.OneRing()
    RangeCircle.EnsureSettings()
    for i = 1, 3 do
        RangeCircle.Settings.rings[i].enabled = (i == RangeCircle.Settings.activeRing)
    end
    RangeCircle.Apply()
    RangeCircle.Print("only ring " .. tostring(RangeCircle.Settings.activeRing) .. " enabled")
end

function RangeCircle.ThreeRings()
    RangeCircle.EnsureSettings()

    RangeCircle.Settings.activeRing = 1
    RangeCircle.Settings.rings[1] = deepCopy(RangeCircle.DefaultRings[3])
    RangeCircle.Settings.rings[1].enabled = true

    RangeCircle.Settings.rings[2] = deepCopy(RangeCircle.DefaultRings[1])
    RangeCircle.Settings.rings[2].enabled = true

    RangeCircle.Settings.rings[3] = deepCopy(RangeCircle.DefaultRings[2])
    RangeCircle.Settings.rings[3].enabled = true

    RangeCircle.Settings.locked = true
    RangeCircle.Settings.showing = true
    RangeCircle.Settings.mode = "screen"
    RangeCircle.Settings.label = false
    RangeCircle.Settings.dot = false

    RangeCircle.Apply()
    RangeCircle.Print("three-ring test enabled: 10 ft, 20 ft and 30 ft pseudo-ground ellipses")
end

function RangeCircle.GroundTest()
    RangeCircle.DetachFromPlayer()
    RangeCircle.Settings = defaultSettings()
    RangeCircle.Settings.showing = true
    RangeCircle.Settings.locked = false
    RangeCircle.Settings.mode = "screen"
    RangeCircle.Settings.label = true
    RangeCircle.Settings.dot = true
    RangeCircle.Apply()
    RangeCircle.Print("ground test: one pseudo-ground ellipse, unlocked, label/dot visible")
end

function RangeCircle.Reset()
    RangeCircle.DetachFromPlayer()
    RangeCircle.Settings = defaultSettings()
    RangeCircle.Apply()
    RangeCircle.Print("settings reset to 1.0.0 defaults")
end

function RangeCircle.Status()
    RangeCircle.EnsureSettings()
    RangeCircle.Print("mode=" .. tostring(RangeCircle.Settings.mode) .. " screenOffset=" .. tostring(round(RangeCircle.Settings.x)) .. "," .. tostring(round(RangeCircle.Settings.y)) .. " activeRing=" .. tostring(RangeCircle.Settings.activeRing))

    for i = 1, 3 do
        local ring = RangeCircle.Settings.rings[i]
        local state = ring.enabled and "ON" or "off"
        RangeCircle.Print("ring " .. tostring(i) .. " " .. state .. " " .. tostring(ring.name) .. " size=" .. tostring(round(ring.width)) .. "x" .. tostring(round(ring.height)) .. " offset=" .. tostring(round(ring.offsetX)) .. "," .. tostring(round(ring.offsetY)) .. " alpha=" .. tostring(math.floor(ring.alpha * 100)) .. "%")
    end
end


function RangeCircle.ShowConfigWindow()
    if not RangeCircle.CreateConfigWindow() then
        return
    end
    if WindowSetShowing ~= nil then
        pcall(WindowSetShowing, CONFIG_WINDOW, true)
    end
    RangeCircle.UpdateConfigWindow()
end

function RangeCircle.HideConfigWindow()
    if windowExists(CONFIG_WINDOW) and WindowSetShowing ~= nil then
        pcall(WindowSetShowing, CONFIG_WINDOW, false)
    end
end

function RangeCircle.ToggleConfigWindow()
    if not windowExists(CONFIG_WINDOW) then
        RangeCircle.ShowConfigWindow()
        return
    end

    if WindowGetShowing ~= nil then
        local showing = false
        local ok, result = pcall(WindowGetShowing, CONFIG_WINDOW)
        if ok then showing = result == true end
        if showing then
            RangeCircle.HideConfigWindow()
        else
            RangeCircle.ShowConfigWindow()
        end
    else
        RangeCircle.ShowConfigWindow()
    end
end

function RangeCircle.SetLabelTextSafe(name, value)
    if windowExists(name) and LabelSetText ~= nil then
        pcall(LabelSetText, name, wtext(value))
    end
end

function RangeCircle.SetButtonTextSafe(name, value)
    if windowExists(name) and ButtonSetText ~= nil then
        pcall(ButtonSetText, name, wtext(value))
    end
end

function RangeCircle.UpdateConfigWindow()
    if not windowExists(CONFIG_WINDOW) then
        return
    end

    RangeCircle.EnsureSettings()
    local s = RangeCircle.Settings
    local ring = RangeCircle.ActiveRing()
    local flatten = 0
    if ring.width > 0 then
        flatten = math.floor((ring.height / ring.width) * 100 + 0.5)
    end

    RangeCircle.SetLabelTextSafe("RangeCircleConfigWindowHeader", "RangeCircle - Ring Manager")
    RangeCircle.SetLabelTextSafe("RangeCircleConfigWindowHint", "1) Choose Ring 1/2/3. 2) Apply a range preset. 3) Fine tune size, position, opacity and colour.")
    RangeCircle.SetLabelTextSafe("RangeCircleConfigWindowSectionGeneral", "1. General")
    RangeCircle.SetLabelTextSafe("RangeCircleConfigWindowSectionRing", "2. Active ring")
    RangeCircle.SetLabelTextSafe("RangeCircleConfigWindowSectionPreset", "3. Range preset")
    RangeCircle.SetLabelTextSafe("RangeCircleConfigWindowSectionAdjust", "4. Fine tune selected ring")
    RangeCircle.SetLabelTextSafe("RangeCircleConfigWindowSectionColors", "5. Colour and visual helpers")
    RangeCircle.SetLabelTextSafe("RangeCircleConfigWindowSectionLine", "6. Line thickness")

    RangeCircle.SetLabelTextSafe("RangeCircleConfigWindowInfoPanelInfo1", "Status: " .. (s.showing and "visible" or "hidden") .. " | " .. (s.locked and "locked" or "movable") .. " | mode=" .. (s.mode == "screen" and "screen" or "self"))
    RangeCircle.SetLabelTextSafe("RangeCircleConfigWindowInfoPanelInfo2", "Active ring: " .. tostring(s.activeRing) .. " | " .. (ring.enabled and "enabled" or "disabled") .. " | preset=" .. tostring(ring.preset) .. " | screen=" .. tostring(round(s.x)) .. "," .. tostring(round(s.y)))
    RangeCircle.SetLabelTextSafe("RangeCircleConfigWindowInfoPanelInfo3", "Ring size: " .. tostring(round(ring.width)) .. "x" .. tostring(round(ring.height)) .. " | flatten=" .. tostring(flatten) .. "% | ring offset=" .. tostring(round(ring.offsetX)) .. "," .. tostring(round(ring.offsetY)))
    RangeCircle.SetLabelTextSafe("RangeCircleConfigWindowInfoPanelInfo4", "Opacity: " .. tostring(math.floor(ring.alpha * 100 + 0.5)) .. "% | RGB=" .. tostring(round(ring.r)) .. "," .. tostring(round(ring.g)) .. "," .. tostring(round(ring.b)) .. " | line=" .. tostring(ring.thickness or "auto"))

    RangeCircle.SetButtonTextSafe("RangeCircleConfigWindowShowButton", s.showing and "Hide rings" or "Show rings")
    RangeCircle.SetButtonTextSafe("RangeCircleConfigWindowLockButton", s.locked and "Unlock" or "Lock")
    RangeCircle.SetButtonTextSafe("RangeCircleConfigWindowModeButton", s.mode == "screen" and "Mode: screen" or "Mode: self")
    RangeCircle.SetButtonTextSafe("RangeCircleConfigWindowCenterButton", "Center")
    RangeCircle.SetButtonTextSafe("RangeCircleConfigWindowResetButton", "Reset")

    RangeCircle.SetButtonTextSafe("RangeCircleConfigWindowRing1Button", s.activeRing == 1 and "[Ring 1]" or "Ring 1")
    RangeCircle.SetButtonTextSafe("RangeCircleConfigWindowRing2Button", s.activeRing == 2 and "[Ring 2]" or "Ring 2")
    RangeCircle.SetButtonTextSafe("RangeCircleConfigWindowRing3Button", s.activeRing == 3 and "[Ring 3]" or "Ring 3")
    RangeCircle.SetButtonTextSafe("RangeCircleConfigWindowEnableButton", ring.enabled and "Disable ring" or "Enable ring")
    RangeCircle.SetButtonTextSafe("RangeCircleConfigWindowOneButton", "Only this")
    RangeCircle.SetButtonTextSafe("RangeCircleConfigWindowThreeButton", "3 rings")

    for _, p in ipairs({"10","20","25","30","45"}) do
        RangeCircle.SetButtonTextSafe("RangeCircleConfigWindowPreset" .. p .. "Button", p .. " ft")
    end

    RangeCircle.SetButtonTextSafe("RangeCircleConfigWindowWidthMinusButton", "Width -")
    RangeCircle.SetButtonTextSafe("RangeCircleConfigWindowWidthPlusButton", "Width +")
    RangeCircle.SetButtonTextSafe("RangeCircleConfigWindowHeightMinusButton", "Height -")
    RangeCircle.SetButtonTextSafe("RangeCircleConfigWindowHeightPlusButton", "Height +")
    RangeCircle.SetButtonTextSafe("RangeCircleConfigWindowVOffsetMinusButton", "Up")
    RangeCircle.SetButtonTextSafe("RangeCircleConfigWindowVOffsetPlusButton", "Down")
    RangeCircle.SetButtonTextSafe("RangeCircleConfigWindowHOffsetMinusButton", "Left")
    RangeCircle.SetButtonTextSafe("RangeCircleConfigWindowHOffsetPlusButton", "Right")
    RangeCircle.SetButtonTextSafe("RangeCircleConfigWindowAlphaMinusButton", "Opacity -")
    RangeCircle.SetButtonTextSafe("RangeCircleConfigWindowAlphaPlusButton", "Opacity +")

    RangeCircle.SetButtonTextSafe("RangeCircleConfigWindowColorBlueButton", "Blue")
    RangeCircle.SetButtonTextSafe("RangeCircleConfigWindowColorGreenButton", "Green")
    RangeCircle.SetButtonTextSafe("RangeCircleConfigWindowColorYellowButton", "Yellow")
    RangeCircle.SetButtonTextSafe("RangeCircleConfigWindowColorRedButton", "Red")
    RangeCircle.SetButtonTextSafe("RangeCircleConfigWindowColorWhiteButton", "White")
    RangeCircle.SetButtonTextSafe("RangeCircleConfigWindowLabelButton", s.label and "Hide label" or "Show label")
    RangeCircle.SetButtonTextSafe("RangeCircleConfigWindowDotButton", s.dot and "Hide center" or "Show center")
    RangeCircle.SetButtonTextSafe("RangeCircleConfigWindowLineAutoButton", ring.thickness == "auto" and "[Auto]" or "Auto")
    RangeCircle.SetButtonTextSafe("RangeCircleConfigWindowLineThinButton", ring.thickness == "thin" and "[Thin]" or "Thin")
    RangeCircle.SetButtonTextSafe("RangeCircleConfigWindowLineNormalButton", ring.thickness == "normal" and "[Normal]" or "Normal")
    RangeCircle.SetButtonTextSafe("RangeCircleConfigWindowLineBoldButton", ring.thickness == "bold" and "[Bold]" or "Bold")
end

function RangeCircle.AdjustActiveRing(deltaWidth, deltaHeight, deltaOffsetX, deltaOffsetY, deltaAlpha)
    local ring = RangeCircle.ActiveRing()
    if deltaWidth ~= nil and deltaWidth ~= 0 then
        ring.width = clamp(toNumber(ring.width, 200) + deltaWidth, 20, 3200)
    end
    if deltaHeight ~= nil and deltaHeight ~= 0 then
        ring.height = clamp(toNumber(ring.height, 100) + deltaHeight, 10, 1200)
    end
    if deltaOffsetX ~= nil and deltaOffsetX ~= 0 then
        ring.offsetX = clamp(toNumber(ring.offsetX, 0) + deltaOffsetX, -1000, 1000)
    end
    if deltaOffsetY ~= nil and deltaOffsetY ~= 0 then
        ring.offsetY = clamp(toNumber(ring.offsetY, 0) + deltaOffsetY, -1000, 1000)
    end
    if deltaAlpha ~= nil and deltaAlpha ~= 0 then
        ring.alpha = clamp(toNumber(ring.alpha, 0.8) + deltaAlpha, 0.05, 1.0)
    end
    ring.enabled = true
    ring.preset = "manual"
    if ring.name ~= nil then ring.name = "manual" end
    RangeCircle.Apply()
end

function RangeCircle.ConfigToggleShow() RangeCircle.Toggle() end
function RangeCircle.ConfigToggleLock() if RangeCircle.Settings ~= nil and RangeCircle.Settings.locked then RangeCircle.Unlock() else RangeCircle.Lock() end end
function RangeCircle.ConfigToggleMode() if RangeCircle.Settings ~= nil and RangeCircle.Settings.mode == "screen" then RangeCircle.SetMode("self") else RangeCircle.SetMode("screen") end end
function RangeCircle.ConfigCenter() RangeCircle.Center() end
function RangeCircle.ConfigReset() RangeCircle.Reset(); RangeCircle.ShowConfigWindow() end
function RangeCircle.ConfigSelectRing1() RangeCircle.SetActiveRing(1) end
function RangeCircle.ConfigSelectRing2() RangeCircle.SetActiveRing(2) end
function RangeCircle.ConfigSelectRing3() RangeCircle.SetActiveRing(3) end
function RangeCircle.ConfigToggleRingEnabled() RangeCircle.ToggleRing() end
function RangeCircle.ConfigOneRing() RangeCircle.OneRing() end
function RangeCircle.ConfigThreeRings() RangeCircle.ThreeRings() end
function RangeCircle.ConfigPreset10() RangeCircle.SetPreset("10") end
function RangeCircle.ConfigPreset20() RangeCircle.SetPreset("20") end
function RangeCircle.ConfigPreset25() RangeCircle.SetPreset("25") end
function RangeCircle.ConfigPreset30() RangeCircle.SetPreset("30") end
function RangeCircle.ConfigPreset45() RangeCircle.SetPreset("45") end
function RangeCircle.ConfigWidthMinus() RangeCircle.AdjustActiveRing(-20, 0, 0, 0, 0) end
function RangeCircle.ConfigWidthPlus() RangeCircle.AdjustActiveRing(20, 0, 0, 0, 0) end
function RangeCircle.ConfigHeightMinus() RangeCircle.AdjustActiveRing(0, -10, 0, 0, 0) end
function RangeCircle.ConfigHeightPlus() RangeCircle.AdjustActiveRing(0, 10, 0, 0, 0) end
function RangeCircle.ConfigVOffsetMinus() RangeCircle.AdjustActiveRing(0, 0, 0, -10, 0) end
function RangeCircle.ConfigVOffsetPlus() RangeCircle.AdjustActiveRing(0, 0, 0, 10, 0) end
function RangeCircle.ConfigHOffsetMinus() RangeCircle.AdjustActiveRing(0, 0, -10, 0, 0) end
function RangeCircle.ConfigHOffsetPlus() RangeCircle.AdjustActiveRing(0, 0, 10, 0, 0) end
function RangeCircle.ConfigAlphaMinus() RangeCircle.AdjustActiveRing(0, 0, 0, 0, -0.05) end
function RangeCircle.ConfigAlphaPlus() RangeCircle.AdjustActiveRing(0, 0, 0, 0, 0.05) end
function RangeCircle.ConfigColorBlue() RangeCircle.SetColor(80, 200, 255) end
function RangeCircle.ConfigColorGreen() RangeCircle.SetColor(100, 255, 120) end
function RangeCircle.ConfigColorYellow() RangeCircle.SetColor(255, 220, 80) end
function RangeCircle.ConfigColorRed() RangeCircle.SetColor(255, 90, 90) end
function RangeCircle.ConfigColorWhite() RangeCircle.SetColor(255, 255, 255) end
function RangeCircle.ConfigLineAuto() RangeCircle.SetLineThickness("auto") end
function RangeCircle.ConfigLineThin() RangeCircle.SetLineThickness("thin") end
function RangeCircle.ConfigLineNormal() RangeCircle.SetLineThickness("normal") end
function RangeCircle.ConfigLineBold() RangeCircle.SetLineThickness("bold") end
function RangeCircle.ConfigToggleLabel() RangeCircle.LabelToggle() end
function RangeCircle.ConfigToggleDot() RangeCircle.DotToggle() end

function RangeCircle.Help()
    RangeCircle.Print("/rangecircle menu | show | hide | toggle | lock | unlock | center | reset | status")
    RangeCircle.Print("/rangecircle ring 1|2|3  - select active ring")
    RangeCircle.Print("/rangecircle enable | disable | ringtoggle | one | three")
    RangeCircle.Print("/rangecircle preset 10|20|25|30|45")
    RangeCircle.Print("/rangecircle size 720 272 | width 720 | height 272 | radius 360 | flatten 37.8")
    RangeCircle.Print("/rangecircle voffset 110 | offset 0 110 | move 0 150")
    RangeCircle.Print("/rangecircle alpha 85 | color 80 200 255 | line auto|thin|normal|bold | label | dot")
    RangeCircle.Print("/rangecircle mode screen | self")
    RangeCircle.Print("/rangecircle groundtest  - one unlocked pseudo-ground ellipse")
    RangeCircle.Print("Alias /rc is attempted only if free")
end

local function splitArgs(input)
    local args = {}
    if input == nil then return args end
    input = tostring(input)
    for word in string.gmatch(input, "%S+") do
        table.insert(args, word)
    end
    return args
end

function RangeCircle.Slash(input)
    local args = splitArgs(input)
    local cmd = string.lower(args[1] or "")

    if cmd == "show" then
        RangeCircle.Show()
    elseif cmd == "hide" then
        RangeCircle.Hide()
    elseif cmd == "toggle" or cmd == "t" then
        RangeCircle.Toggle()
    elseif cmd == "lock" then
        RangeCircle.Lock()
    elseif cmd == "unlock" then
        RangeCircle.Unlock()
    elseif cmd == "menu" or cmd == "config" or cmd == "ui" then
        RangeCircle.ToggleConfigWindow()
    elseif cmd == "center" or cmd == "centre" then
        RangeCircle.Center()
    elseif cmd == "mode" then
        RangeCircle.SetMode(args[2])
    elseif cmd == "self" or cmd == "player" or cmd == "world" then
        RangeCircle.SetMode("self")
    elseif cmd == "screen" or cmd == "fixed" then
        RangeCircle.SetMode("screen")
    elseif cmd == "ring" or cmd == "select" then
        RangeCircle.SetActiveRing(args[2])
    elseif cmd == "enable" or cmd == "on" then
        RangeCircle.EnableRing()
    elseif cmd == "disable" or cmd == "off" then
        RangeCircle.DisableRing()
    elseif cmd == "ringtoggle" or cmd == "rtoggle" then
        RangeCircle.ToggleRing()
    elseif cmd == "one" or cmd == "solo" then
        RangeCircle.OneRing()
    elseif cmd == "three" or cmd == "triple" then
        RangeCircle.ThreeRings()
    elseif cmd == "preset" or cmd == "p" then
        RangeCircle.SetPreset(args[2])
    elseif cmd == "size" then
        RangeCircle.SetSize(args[2], args[3])
    elseif cmd == "width" or cmd == "w" then
        RangeCircle.SetWidth(args[2])
    elseif cmd == "height" or cmd == "h" then
        RangeCircle.SetHeight(args[2])
    elseif cmd == "radius" or cmd == "r" then
        RangeCircle.SetRadius(args[2])
    elseif cmd == "flatten" or cmd == "squash" then
        RangeCircle.SetFlatten(args[2])
    elseif cmd == "offset" or cmd == "ringoffset" then
        RangeCircle.SetOffset(args[2], args[3])
    elseif cmd == "voffset" then
        RangeCircle.SetOffset(nil, args[2])
    elseif cmd == "hoffset" then
        RangeCircle.SetOffset(args[2], nil)
    elseif cmd == "move" then
        RangeCircle.SetScreenOffset(args[2], args[3])
    elseif cmd == "alpha" or cmd == "a" then
        RangeCircle.SetAlpha(args[2])
    elseif cmd == "color" or cmd == "colour" or cmd == "c" then
        RangeCircle.SetColor(args[2], args[3], args[4])
    elseif cmd == "line" or cmd == "thickness" or cmd == "stroke" then
        RangeCircle.SetLineThickness(args[2])
    elseif cmd == "label" then
        RangeCircle.LabelToggle()
    elseif cmd == "dot" then
        RangeCircle.DotToggle()
    elseif cmd == "groundtest" or cmd == "gtest" or cmd == "test" then
        RangeCircle.GroundTest()
    elseif cmd == "status" or cmd == "rings" then
        RangeCircle.Status()
    elseif cmd == "reset" then
        RangeCircle.Reset()
    else
        RangeCircle.Help()
    end
end

local function tryRegisterSlash(command)
    if LibSlash == nil then
        return false
    end

    local fn = LibSlash.RegisterSlashCmd or LibSlash.RegisterSlashCommand or LibSlash.RegisterCommand
    if fn == nil then
        return false
    end

    local ok = pcall(fn, command, RangeCircle.Slash)
    return ok == true
end

function RangeCircle.RegisterSlashCommands()
    if RangeCircle.SlashRegistered == true then
        return true
    end

    local mainOk = tryRegisterSlash("rangecircle")
    local aliasOk = tryRegisterSlash("rc")

    RangeCircle.SlashRegistered = mainOk or aliasOk

    if not RangeCircle.SlashRegistered then
        RangeCircle.Print("LibSlash command registration failed. Try /script RangeCircle.Help()")
        return false
    end

    return true
end

function RangeCircle.OnLButtonUp(flags)
    if RangeCircle.Settings == nil then return end
    if RangeCircle.Settings.locked ~= true then
        RangeCircle.Print("position changed visually. If it does not persist after reload, use /rangecircle move x y for exact saved offset.")
    end
end

function RangeCircle.OnRButtonUp(flags)
    RangeCircle.Lock()
end

function RangeCircle.Initialize()
    RangeCircle.EnsureSettings()

    if not RangeCircle.CreateMainWindow() then
        return
    end

    RangeCircle.CreateConfigWindow()
    RangeCircle.RefreshTextures()
    RangeCircle.Apply()
    RangeCircle.RegisterSlashCommands()
    RangeCircle.UpdateConfigWindow()
    RangeCircle.Print("loaded v" .. RangeCircle.VERSION .. ". Usa /rangecircle menu para abrir el menu.")
end

function RangeCircle.Shutdown()
    RangeCircle.DetachFromPlayer()
end
