<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
    <UiMod name="RangeCircle" version="1.2.6" date="05/13/2026">
        <Author name="Gingerbel &amp; Kpihuss" email="" />
        <Description text="Projected range circle overlay for Return of Reckoning." />
        <VersionSettings gameVersion="1.4.8" windowsVersion="1.0" savedVariablesVersion="1.0" />

        <Dependencies>
            <Dependency name="LibSlash" />
        </Dependencies>

        <WARInfo>
            <Categories>
                <Category name="UI_MOD" />
            </Categories>
        </WARInfo>

        <Files>
            <File name="RangeCircle.xml" />
            <File name="RangeCircleZoneData.lua" />
            <File name="RangeCircleCamera.lua" />
            <File name="RangeCircle.lua" />
        </Files>

        <SavedVariables>
            <SavedVariable name="RangeCircle.Settings" />
        </SavedVariables>

        <OnInitialize>
            <CallFunction name="RangeCircle.Initialize" />
        </OnInitialize>

        <OnUpdate>
            <CallFunction name="RangeCircle.OnUpdate" />
        </OnUpdate>

        <OnShutdown>
            <CallFunction name="RangeCircle.Shutdown" />
        </OnShutdown>
    </UiMod>
</ModuleFile>
