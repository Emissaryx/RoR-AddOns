WarBoard_TogglerRankedLeaderboard = WarBoard_TogglerRankedLeaderboard or {}
local WarBoard_TogglerRankedLeaderboard = WarBoard_TogglerRankedLeaderboard
local modName = "WarBoard_TogglerRankedLeaderboard"
local modTitle = "Toggler Ranked Leaderboard"
local modLabel = "Ranked"

function WarBoard_TogglerRankedLeaderboard.Initialize()
	if LibWBToggler.CreateToggler( modName, modLabel, "RankedIcon", 0, 0 ) then
		local textWidth, _ = LabelGetTextDimensions(modName.."Label")
		WindowSetDimensions(modName, textWidth + 37, 30)
		WindowSetDimensions(modName.."Label", textWidth, 30)
		DynamicImageSetTextureDimensions("WarBoard_TogglerRankedLeaderboardIcon", 32, 32)
		LibWBToggler.RegisterEvent( modName, "OnLButtonUp", "RoR_RankedLeaderboard.ToggleShowing" )
		LibWBToggler.RegisterEvent( modName, "OnMouseOver", "WarBoard_TogglerRankedLeaderboard.ShowStatus" )

	end
end

function WarBoard_TogglerRankedLeaderboard.ShowStatus()
	LibWBToggler.DefaultTooltip(modName, modTitle)
end
