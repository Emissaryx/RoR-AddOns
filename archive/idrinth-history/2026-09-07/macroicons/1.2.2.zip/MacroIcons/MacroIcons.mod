<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" >	
  <UiMod name="MacroIcons" version="1.2.2" date="1/10/2026" >		
    <Author name="Thurwell and Emissary" email="emissary@returnofreckoning.com" />		    
    <VersionSettings gameVersion="1.4.8" windowsVersion="1.0" savedVariablesVersion="1.0" />  		
    <Description text="More macro icons"/>		
    <Files>			
      <File name="MacroIcons.lua"/>			
      <File name="MacroIcons.xml"/>		
    </Files>	 		
    <Dependencies>         			
      <Dependency name="EA_MacroWindow"/>		
    </Dependencies>		
    <OnInitialize>			
      <CallFunction name="MacroIcons.OnInitialize" />		
    </OnInitialize>	
  </UiMod>
</ModuleFile>