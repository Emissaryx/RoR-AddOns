-- vim:sw=4 ts=4

local MacroIcons = {}

-- =========================
-- Locals / State
-- =========================
local macroId = EA_Window_Macro.MACRO_ICONS_ID_BASE
local oldId   = macroId
local reset   = false

-- =========================
-- Cached globals (performance)
-- =========================
local GetIconData                      = GetIconData
local DynamicImageSetTexture           = DynamicImageSetTexture
local VerticalScrollbarSetScrollPosition = VerticalScrollbarSetScrollPosition
local VerticalScrollbarGetScrollPosition = VerticalScrollbarGetScrollPosition
local VerticalScrollbarSetMaxScrollPosition = VerticalScrollbarSetMaxScrollPosition
local WindowRegisterCoreEventHandler   = WindowRegisterCoreEventHandler
local WindowSetShowing                 = WindowSetShowing
local WindowSetParent                  = WindowSetParent
local WindowClearAnchors               = WindowClearAnchors
local WindowAddAnchor                  = WindowAddAnchor
local CreateWindow                     = CreateWindow
local WindowGetId                      = WindowGetId
local WindowSetShowing                 = WindowSetShowing
local math_floor                       = math.floor
local math_max                         = math.max
local math_min                         = math.min

local NUM_ICONS = EA_Window_Macro.NUM_MACRO_ICONS
local SLOT_BASE = "MacroIconSelectionWindowIconSlot"

local MAX_ICON = 14330
local STEP     = 18

-- =========================
-- Init
-- =========================
function MacroIcons.OnInitialize()
	MacroIcons.hookMacroSelection = EA_Window_Macro.SelectionIconLButtonDown
	EA_Window_Macro.SelectionIconLButtonDown = MacroIcons.MacroSelection

	WindowSetShowing("IconsScrollbar", false)

	CreateWindow("MacroIcons", true)
	WindowSetParent("MacroIcons", "MacroIconSelectionWindow")
	WindowClearAnchors("MacroIcons")
	WindowAddAnchor("MacroIcons", "topright",  "MacroIconSelectionWindow", "topright",  -5,  35)
	WindowAddAnchor("MacroIcons", "bottomright","MacroIconSelectionWindow", "bottomleft",-34, -5)

	VerticalScrollbarSetMaxScrollPosition("MacroIconsScrollBar", 807)
	VerticalScrollbarSetScrollPosition("MacroIconsScrollBar", 11)

	WindowRegisterCoreEventHandler("MacroIconSelectionWindow", "OnMouseWheel", "MacroIcons.MouseWheel")
	WindowRegisterCoreEventHandler("IconsScrollChild",        "OnMouseWheel", "MacroIcons.MouseWheel")

	for k = 1, NUM_ICONS do
		WindowRegisterCoreEventHandler(SLOT_BASE .. k, "OnMouseWheel", "MacroIcons.MouseWheel")
	end
end

-- =========================
-- Core Rendering
-- =========================
function MacroIcons.NewTextures()
	-- Clamp
	macroId = math_max(1, math_min(MAX_ICON, macroId))

	-- Avoid recursion: bounded correction loop
	local tries = 0
	while tries < 10 do
		local tex1 = GetIconData(macroId + 1)
		local tex2 = GetIconData(macroId + NUM_ICONS)

		if tex1 ~= "icon-00001" or tex2 ~= "icon-00001" then
			break
		end

		if oldId < macroId then
			macroId = macroId + STEP
		else
			macroId = macroId - STEP
		end

		tries = tries + 1
	end

	oldId = macroId

	for slot = 1, NUM_ICONS do
		local texture, x, y = GetIconData(macroId + slot)
		DynamicImageSetTexture(SLOT_BASE .. slot .. "IconBase", texture, x, y)
	end

	reset = true
	VerticalScrollbarSetScrollPosition("MacroIconsScrollBar", MacroIcons.GetPage())
	reset = false
end

-- =========================
-- Selection Hook
-- =========================
function MacroIcons.MacroSelection(...)
	MacroIcons.hookMacroSelection(...)
	MacroIcons.NewIcon()
end

function MacroIcons.NewIcon()
	local slot = WindowGetId(SystemData.ActiveWindow.name)
	EA_Window_Macro.iconNum = macroId + slot

	local texture, x, y = GetIconData(EA_Window_Macro.iconNum)
	DynamicImageSetTexture("EA_Window_MacroDetailsIconIconBase", texture, x, y)
end

-- =========================
-- Scroll Handling
-- =========================
function MacroIcons.GetPage()
	return math_floor((macroId - 2) / STEP)
end

function MacroIcons.ScrollPos()
	if reset then return end

	local page = math_floor(VerticalScrollbarGetScrollPosition("MacroIconsScrollBar"))
	local newMacroId = page * STEP + 2

	if newMacroId == macroId then return end

	macroId = newMacroId
	MacroIcons.NewTextures()
end

function MacroIcons.MouseWheel(x, y, delta, flags)
	if delta > 0 then
		macroId = macroId - STEP
	elseif delta < 0 then
		macroId = macroId + STEP
	end

	MacroIcons.NewTextures()
end

-- Export
_G.MacroIcons = MacroIcons
