PTLeader =
{
    TimeLeft = 0;
    Time = 0;
    oldLeader = 0;
    newLeader = 0;
    curLeader = nil;
}


PTLeader.icons =
{
    [1] = "PTLIcon1",
    [2] = "PTLIcon2",
    [3] = "PTLIcon3",
    [4] = "PTLIcon4",
    [5] = "PTLIcon5",
    [6] = "PTLIcon6",

}


function PTLeader.OnInitialize()
    if not PTLeader.save then
        PTLeader.save = {}
        PTLeader.save.active = true
        PTLeader.save.noself = false
        PTLeader.save.scale = 0.75
        PTLeader.save.yOffset = -125
        PTLeader.save.icon = 1
        PTLeader.save.mode = "all" -- "all" = warband and party, "warband" = warband only
        PTLeader.save.hideInScenario = true
        PTLeader.save.broadcastMode = "noop" -- No operation
    end

    if PTLeader.save.yOffset == nil then
        PTLeader.save.yOffset = -125
    end

    if PTLeader.save.scale == nil then
        PTLeader.save.scale = 0.75
    end

    if PTLeader.save.icon == nil or PTLeader.icons[PTLeader.save.icon] == nil then
        PTLeader.save.icon = 1
    end


    if PTLeader.save.mode ~= "warband" and PTLeader.save.mode ~= "all" then
        PTLeader.save.mode = "all"
    end

    if PTLeader.save.hideInScenario == nil then
        PTLeader.save.hideInScenario = true
    end

    if PTLeader.save.broadcastMode == nil then
	PTLeader.save.broadcastMode = "noop"
    end

    RegisterEventHandler(SystemData.Events.INTERFACE_RELOADED, "PTLeader.OnReloadUI")
    RegisterEventHandler(SystemData.Events.BATTLEGROUP_UPDATED, "PTLeader.onWarbandChange")
    RegisterEventHandler(SystemData.Events.GROUP_UPDATED, "PTLeader.onWarbandChange")
    RegisterEventHandler(SystemData.Events.SCENARIO_BEGIN, "PTLeader.onWarbandChange")
    RegisterEventHandler(SystemData.Events.SCENARIO_END, "PTLeader.onWarbandChange")
    RegisterEventHandler(SystemData.Events.SCENARIO_GROUP_JOIN, "PTLeader.onWarbandChange")
    RegisterEventHandler(SystemData.Events.SCENARIO_GROUP_LEAVE, "PTLeader.onWarbandChange")
    RegisterEventHandler(SystemData.Events.LOADING_END, "PTLeader.OnReloadUI")
    CreateWindow("PTL_Window", false)
    PTLeader.ApplyYOffset()
    PTLeader.ApplyIcon()

    EA_ChatWindow.Print(L"PTLeader addon is now loaded. Slash command: /ptl")
    PTLeader.SlashOnInit()
end


function PTLeader.OnShutdown()
    UnregisterEventHandler(SystemData.Events.INTERFACE_RELOADED, "PTLeader.OnReloadUI")
    UnregisterEventHandler(SystemData.Events.BATTLEGROUP_UPDATED, "PTLeader.onWarbandChange")
    UnregisterEventHandler(SystemData.Events.GROUP_UPDATED, "PTLeader.onWarbandChange")
    UnregisterEventHandler(SystemData.Events.SCENARIO_BEGIN, "PTLeader.onWarbandChange")
    UnregisterEventHandler(SystemData.Events.SCENARIO_END, "PTLeader.onWarbandChange")
    UnregisterEventHandler(SystemData.Events.SCENARIO_GROUP_JOIN, "PTLeader.onWarbandChange")
    UnregisterEventHandler(SystemData.Events.SCENARIO_GROUP_LEAVE, "PTLeader.onWarbandChange")
    UnregisterEventHandler(SystemData.Events.LOADING_END, "PTLeader.OnReloadUI")
end


function PTLeader.onWarbandChange()
    local newID

    if IsWarBandActive() then
        newID = PTLeader.getWarbandLeader()
    elseif PTLeader.save.mode == "all" then
        newID = PTLeader.getGroupLeader()
    else
        newID = 0
    end

    if not PTLeader.save.active then
        newID = 0
    end

    if PTLeader.save.hideInScenario and GameData.Player.isInScenario then
        newID = 0
    end

    if PTLeader.save.noself and newID == GameData.Player.worldObjNum then
        newID = 0
    end

    PTLeader.SetMarkerWindowII(newID or 0)
end


function PTLeader.getWarbandLeader()
    local warband = GetBattlegroupMemberData()
    local playerID = nil
    local leaderID = nil

    for _, group in ipairs(warband) do
        for _, player in ipairs(group.players) do
            if player.isGroupLeader == true then
                leaderID = player.worldObjNum
            end

            if player.worldObjNum == GameData.Player.worldObjNum then
                playerID = player.worldObjNum
            end
        end
    end

    if leaderID and playerID then
        return leaderID
    end

    return 0
end


function PTLeader.getGroupLeader()
    local currentParty = nil

    -- Use PartyUtils only to verify that a current party still exists.
    if PartyUtils and PartyUtils.GetPartyData then
        currentParty = PartyUtils.GetPartyData()
    end

    if currentParty then
        local validMembers = 0
        local containsSelf = false

        for _, player in pairs(currentParty) do
            if player and player.worldObjNum and player.worldObjNum ~= 0 then
                validMembers = validMembers + 1

                if player.worldObjNum == GameData.Player.worldObjNum then
                    containsSelf = true
                end
            end
        end

        if validMembers == 0 or (containsSelf and validMembers < 2) then
            return nil
        end
    end

    local group = GetGroupData()

    if not group then
        return nil
    end

    local leaderIDs = {}

    for _, player in pairs(group) do
        if player and player.isGroupLeader == true and
           player.worldObjNum and player.worldObjNum ~= 0 then
            table.insert(leaderIDs, player.worldObjNum)
        end
    end

    if #leaderIDs == 1 then
        return leaderIDs[1]
    end

    if #leaderIDs > 1 then
        for _, leaderID in ipairs(leaderIDs) do
            if leaderID ~= PTLeader.curLeader then
                return leaderID
            end
        end

        return leaderIDs[#leaderIDs]
    end

    if GameData.Player.isGroupLeader == true then
        return GameData.Player.worldObjNum
    end

    return nil
end

function PTLeader.OnUpdate(elapsedTime)
    PTLeader.TimeLeft = PTLeader.TimeLeft - elapsedTime

    if PTLeader.TimeLeft > 0 then
        return
    end

    PTLeader.TimeLeft = 5.0
    PTLeader.onWarbandChange()

    if PTLeader.curLeader and PTLeader.curLeader == GameData.Player.worldObjNum then
        if PTLeader.save.broadcastMode == "public" then
            SystemData.UserInput.ChatText = L"/warbandconvert 1"
            BroadcastEvent(SystemData.Events.SEND_CHAT_TEXT)

        elseif PTLeader.save.broadcastMode == "private" then
            SystemData.UserInput.ChatText = L"/warbandconvert 0"
            BroadcastEvent(SystemData.Events.SEND_CHAT_TEXT)
        end
    end
end


function PTLeader.ApplyYOffset()
    WindowClearAnchors("PTL_WindowBG")
    WindowAddAnchor(
        "PTL_WindowBG",
        "center",
        "PTL_Window",
        "center",
        0,
        PTLeader.save.yOffset
    )
end


function PTLeader.ApplyIcon()
    local textureName = PTLeader.icons[PTLeader.save.icon]

    if textureName then
        DynamicImageSetTexture("PTL_WindowBG", textureName, 256, 256)
    end
end


function PTLeader.SetMarkerWindowII(newID)
    if newID == 0 then
        if PTLeader.curLeader then
            -- Detach the marker from the previous leader.
            DetachWindowFromWorldObject("PTL_Window", PTLeader.curLeader)
            PTLeader.curLeader = nil
        end

        WindowSetShowing("PTL_Window", false)

    elseif not PTLeader.curLeader then
        -- Initially attach the marker to the leader.
        PTLeader.curLeader = newID
        AttachWindowToWorldObject("PTL_Window", PTLeader.curLeader)
        WindowSetShowing("PTL_Window", true)

    elseif PTLeader.curLeader ~= newID then
        -- Reattach the marker when the leader changes.
        DetachWindowFromWorldObject("PTL_Window", PTLeader.curLeader)
        PTLeader.curLeader = newID
        AttachWindowToWorldObject("PTL_Window", PTLeader.curLeader)
        WindowSetShowing("PTL_Window", true)
    end
end


function PTLeader.OnReloadUI()
    PTLeader.SetMarkerWindowII(0)
    PTLeader.ApplyYOffset()
    PTLeader.ApplyIcon()
    PTLeader.onWarbandChange()
end


-- Slash-command handling is included directly in this file.
function PTLeader.SlashOnInit()
    PTLeader.OriginalOnKeyEnter = EA_ChatWindow.OnKeyEnter
    EA_ChatWindow.OnKeyEnter = PTLeader.OnChatKeyEnter
end


function PTLeader.OnChatKeyEnter(...)
    local chatText = EA_TextEntryGroupEntryBoxTextInput.Text
    local command, arguments = chatText:match(L"^/([a-zA-Z0-9]+)[ ]?(.*)")

    if command == L"ptl" or command == L"PTL" then
        PTLeader.HandleSlashCommand(arguments)
        EA_TextEntryGroupEntryBoxTextInput.Text = L""
    end

    PTLeader.OriginalOnKeyEnter(...)
end


function PTLeader.ToggleMode()
    if PTLeader.save.mode == "warband" then
        PTLeader.save.mode = "all"
        EA_ChatWindow.Print(L"PaintTheLeader mode: warband and party")
    else
        PTLeader.save.mode = "warband"
        EA_ChatWindow.Print(L"PaintTheLeader mode: warband only")
    end

    PTLeader.onWarbandChange()
end


function PTLeader.HandleSlashCommand(arguments)
    if arguments == L"on" then
        PTLeader.save.active = true
        PTLeader.save.noself = false
        PTLeader.onWarbandChange()
        EA_ChatWindow.Print(L"PaintTheLeader on")

    elseif arguments == L"off" then
        PTLeader.save.active = false
        PTLeader.onWarbandChange()
        EA_ChatWindow.Print(L"PaintTheLeader off")

    elseif arguments == L"noself" then
        PTLeader.save.active = true
        PTLeader.save.noself = not PTLeader.save.noself
        PTLeader.onWarbandChange()

        if PTLeader.save.noself then
            EA_ChatWindow.Print(L"PaintTheLeader self icon off")
        else
            EA_ChatWindow.Print(L"PaintTheLeader self icon on")
        end

	elseif arguments == L"mode" then
	    PTLeader.ToggleMode()

    elseif arguments == L"scenario" then
        PTLeader.save.hideInScenario = not PTLeader.save.hideInScenario
        PTLeader.onWarbandChange()

        if PTLeader.save.hideInScenario then
            EA_ChatWindow.Print(L"PaintTheLeader scenario icon off")
        else
            EA_ChatWindow.Print(L"PaintTheLeader scenario icon on")
        end

    elseif arguments == L"lock" then
        EA_ChatWindow.Print(L"PaintTheLeader window locked")

    elseif arguments == L"unlock" then
        EA_ChatWindow.Print(L"PaintTheLeader window unlocked")

    elseif arguments == L"update" then
        PTLeader.SetMarkerWindowII(0)

    else
        local command, argument = arguments:match(L"^([a-zA-Z0-9]+)[ ]?(.*)")

        if command == L"icon" then
            local iconNumber = tonumber(argument)

            if iconNumber and PTLeader.icons[iconNumber] then
                PTLeader.save.icon = iconNumber
                PTLeader.ApplyIcon()
                EA_ChatWindow.Print(L"Icon changed to "..iconNumber..L".")
            else
                EA_ChatWindow.Print(L"Invalid icon. Choose 1, 2, 3, 4, 5 or 6.")
            end

        elseif command == L"offset" then
            local yOffset = tonumber(argument)

            if yOffset then
                PTLeader.save.yOffset = yOffset
                PTLeader.ApplyYOffset()
                EA_ChatWindow.Print(L"Crown Y offset changed to "..argument..L".")
            else
                EA_ChatWindow.Print(L"Invalid Y offset. Example: /ptl offset -125")
            end

        elseif command == L"scale" then
            local scalePercent = tonumber(argument)

            if scalePercent then
                PTLeader.save.scale = scalePercent / 100
                PTLeader.SetMarkerWindowII(0)
                WindowSetScale("PTL_Window", PTLeader.save.scale)
                EA_ChatWindow.Print(L"Icon size changed to "..argument..L"%.")
            else
                EA_ChatWindow.Print(L"Invalid scale. Example: /ptl scale 100")
            end

        else
            EA_ChatWindow.Print(L"PaintTheLeader slash commands:")
            EA_ChatWindow.Print(L"/ptl on - Enables the addon")
            EA_ChatWindow.Print(L"/ptl off - Disables the addon")
            EA_ChatWindow.Print(L"/ptl noself - Toggles the icon on yourself")
            EA_ChatWindow.Print(L"/ptl scale <value> - Sets icon size in percent")
            EA_ChatWindow.Print(L"/ptl icon <value> - Selects crown icon 1 through 6")
            EA_ChatWindow.Print(L"/ptl offset <value> - Sets the crown vertical offset MUST be a negative number")
            EA_ChatWindow.Print(L"/ptl mode - Toggles between warband only and warband plus party")
            EA_ChatWindow.Print(L"/ptl scenario - Toggles the icon in scenario parties")
            local modeText

            if PTLeader.save.mode == "warband" then
                modeText = L"warband only"
            else
                modeText = L"warband and party"
            end

	EA_ChatWindow.Print(
	    L"(active = "..towstring(booltostring(PTLeader.save.active))..
	    L", noself = "..towstring(booltostring(PTLeader.save.noself))..
	    L", scale = "..(PTLeader.save.scale * 100)..L"%"..
	    L", offset = "..PTLeader.save.yOffset..
	    L", icon = "..PTLeader.save.icon..
	    L", mode = "..modeText..L")")
        end
    end
end
