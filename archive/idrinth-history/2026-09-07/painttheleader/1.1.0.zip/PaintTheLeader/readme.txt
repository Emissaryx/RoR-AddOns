Paint the Leader places a crown above the party or warband leader so you can see their location without having to manually mark them.

slash commands
"/ptl"			Show slash commands
"/ptl on" 		Enables the addon on by default
"/ptl off"		Disables the addon
"/ptl noself		Toggles hides the icon on yourself mode on and off
"/ptl mode"		Toggles between warband and party mode and warband only mode
"/ptl scale <value>"	Sets icon size in percent, defaults to 100
"/ptl icon <value>"	Selects crown icon 1 through 4
"/ptl offset <value>"	Sets the crown vertical offset, MUST be a negative number
