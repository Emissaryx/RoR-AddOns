<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">

	<UiMod name="Paint the leader" version="1.1.1" date="08/06/2026" >
		<Author name="Archivar, fixed by Ninjas" email="" />
		<Description text="Shows a Icon over the party and/or warband leader's character." />
		<VersionSettings gameVersion="1.4.8" windowsVersion="1.0" savedVariablesVersion="1.0" />

		<Dependencies>
			<Dependency name="EA_ChatWindow" />
		</Dependencies>
		<SavedVariables>
			<SavedVariable name="PTLeader.save" />
		</SavedVariables>
		<Files>
			<File name="PaintTheLeader.xml" />
		</Files>
		<OnInitialize>
			<CallFunction name="PTLeader.OnInitialize" />
		</OnInitialize>
		<OnShutdown>
			<CallFunction name="PTLeader.OnShutdown" />
		</OnShutdown>
		<OnUpdate>
			<CallFunction name="PTLeader.OnUpdate" />
		</OnUpdate>
	</UiMod>

</ModuleFile>

