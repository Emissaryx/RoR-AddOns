<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">  
  <UiMod name="BagOMatic" version="1.31" date="2010-07-10T18:50:39Z" >	     
    <Author name="Differential and Eowoyn" email="no@way" />	     
    <VersionSettings gameVersion="1.9.9" windowsVersion="1.0" savedVariablesVersion="1.0" />	     
    <Description text="Backpack manager" />	     
    <WARInfo>	           
      <Categories>	                 
        <Category name="OTHER" />	           
      </Categories>	     
    </WARInfo>	     
    <Dependencies>		       
      <Dependency name="LibSlash"/>		       
      <Dependency name="EA_BackpackWindow"/>		       
      <Dependency name="EASystem_Strings"/>		       
      <Dependency name="EASystem_Utils"/>	     
    </Dependencies>	     
    <Files>		       
      <File name="BagOMatic.lua"/>		       
      <File name="BagOMaticData.lua"/>		       
      <File name="BagOMatic.xml"/>	     
    </Files>	     
    <SavedVariables>		       
      <SavedVariable name="BagOMatic.saved"/>	     
    </SavedVariables>	     
    <OnInitialize>		       
      <CallFunction name="BagOMatic.init"/>	     
    </OnInitialize>	     
    <OnUpdate>		       
      <CallFunction name="BagOMatic.update"/>	     
    </OnUpdate>	     
    <OnShutdown/>  
  </UiMod>
</ModuleFile>