<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
    <UiMod name="BuddyBind" version="1.1" date="2/1/2018">
	<VersionSettings gameVersion="1.4.8" windowsVersion="1.0" savedVariablesVersion="1.0" /> 
     <Author name="Sullemunk" />

        <Description text="Just a targeting Buddy thingy" />
        <Dependencies>
            <Dependency name="EASystem_Utils" />
            <Dependency name="EASystem_WindowUtils" />
            <Dependency name="EASystem_TargetInfo" />>
		    <Dependency name="LibSlash" />     
		</Dependencies>
        <Files>
            <File name="BuddyBind.lua" />
			<File name="BuddyBind.xml" />
        </Files>
				<SavedVariables>								
			</SavedVariables>
        <OnInitialize>
		<CallFunction name="BuddyBind.init" />
        </OnInitialize>
        <OnUpdate> 

		<CallFunction name="BuddyBind.update" />	
	
	</OnUpdate>
               <OnShutdown>
        </OnShutdown>
    </UiMod>
</ModuleFile>