BuddyBind = {}

local KEY_ORDER_FIRST = 1
local KEY_ORDER_SECOND = 2
local KEY_ORDER_THIRD = 3
local KEY_ORDER_LAST = 4

local LCTRL = 29
local RCTRL = 157
local LSHIFT = 42
local RSHIFT = 54
local LALT = 56
local RALT = 184

local modifierKeyTableOrder =
{
    [LCTRL]     = KEY_ORDER_SECOND,
    [RCTRL]     = KEY_ORDER_SECOND,
    
    [LSHIFT]    = KEY_ORDER_THIRD,
    [RSHIFT]    = KEY_ORDER_THIRD,
    
    [LALT]      = KEY_ORDER_FIRST,
    [RALT]      = KEY_ORDER_FIRST,
}

local modiferKeyOppositeLookup =
{
    [LCTRL]     = RCTRL,
    [RCTRL]     = LCTRL,
    
    [LSHIFT]    = RSHIFT,
    [RSHIFT]    = LSHIFT,
    
    [LALT]      = RALT,
    [RALT]      = LALT,
}


function BuddyBind.init()
BuddyBind.Button = 132
CreateWindow("BuddyBindWindow", true)
BuddyBind.Name = L"Unbound"
BuddyBind.Class = L""
LabelSetText("BuddyBindWindowNameLabel",towstring(BuddyBind.Name))


WindowSetGameActionData("BuddyBindWindowExecute",GameData.PlayerActions.SET_TARGET,0,BuddyBind.Name)
WindowSetGameActionData("BuffButtonSettingsExecute",GameData.PlayerActions.SET_TARGET,0,BuddyBind.Name)
WindowSetGameActionTrigger("BuffButtonSettingsExecute", GetActionIdFromName("ACTION_BAR_"..BuddyBind.Button))
DynamicImageSetTexture("BuddyBindWindowKeyIcon","icon030440",64,64)


	local BindNumber = KeyUtils.GetFirstBindingNameForAction("ACTION_BAR_"..BuddyBind.Button)
		
	LabelSetText("BuddyBindWindowKeyLabel",L"Key: "..towstring(BindNumber))
end


function BuddyBind.GrabName()
DynamicImageSetTexture("BuddyBindWindowGrabIcon","icon000051",64,64)

BuddyBind.Name = wstring.sub(TargetInfo:UnitName("selffriendlytarget"),1,-3 ) or L"Unbound"
BuddyBind.Class = L"<icon"..towstring(Icons.GetCareerIconIDFromCareerLine(TargetInfo:UnitCareer("selffriendlytarget")))..L">"




LabelSetText("BuddyBindWindowNameLabel",towstring(BuddyBind.Class)..towstring(BuddyBind.Name))
WindowSetGameActionData("BuddyBindWindow",GameData.PlayerActions.SET_TARGET,0,towstring(BuddyBind.Name))
WindowSetGameActionData("BuddyBindWindowExecute",GameData.PlayerActions.SET_TARGET,0,towstring(BuddyBind.Name))
end

function BuddyBind.update()	
	local tarName = TargetInfo:UnitName("selffriendlytarget")	
	local tarFriendly = TargetInfo:UnitIsFriendly("selffriendlytarget")

	if wstring.sub(TargetInfo:UnitName("selffriendlytarget"),1,-3 ) == BuddyBind.Name then
		WindowSetGameActionData("BuddyBindWindowExecute",GameData.PlayerActions.ASSIST_PLAYER,0,BuddyBind.Name)
		WindowSetGameActionData("BuffButtonSettingsExecute",GameData.PlayerActions.ASSIST_PLAYER,0,BuddyBind.Name)
		DynamicImageSetTexture("BuddyBindWindowGrabIcon","icon000140",64,64)

	else
		WindowSetGameActionData("BuddyBindWindowExecute",GameData.PlayerActions.SET_TARGET,0,BuddyBind.Name)
		WindowSetGameActionData("BuffButtonSettingsExecute",GameData.PlayerActions.SET_TARGET,0,BuddyBind.Name)
		DynamicImageSetTexture("BuddyBindWindowGrabIcon","icon000051",64,64)
		end	
	if  BuddyBind.bindMode == true then
	LabelSetTextColor( "BuddyBindWindowKeyLabel", 25,175,25 )
	else
		LabelSetTextColor( "BuddyBindWindowKeyLabel", 255,255,77 )
	end

end


function BuddyBind.OnLButtonRawDeviceInput()
    buttonBound = 1

    if( BuddyBind.bindMode  )
    then
        BuddyBind.OnExitBindingMode()
	else
	    BuddyBind.bindMode = true
    end

 
    BuddyBind.bindingButtonName = SystemData.MouseOverWindow.name
    BuddyBind.bindingKeyName = L""
    BuddyBind.selectedKeys = {}
   
    ButtonSetCheckButtonFlag( BuddyBind.bindingButtonName, true )
    ButtonSetPressedFlag( BuddyBind.bindingButtonName, true )
    ButtonSetStayDownFlag( BuddyBind.bindingButtonName, true )
 
    WindowRegisterCoreEventHandler( BuddyBind.bindingButtonName, "OnRawDeviceInput", "BuddyBind.OnRawDeviceInput" )
    WindowRegisterEventHandler( BuddyBind.bindingButtonName, SystemData.Events.L_BUTTON_UP_PROCESSED, "BuddyBind.OnExitBindingMode" )
    WindowRegisterEventHandler( BuddyBind.bindingButtonName, SystemData.Events.M_BUTTON_UP_PROCESSED, "BuddyBind.OnExitBindingMode" )
    WindowRegisterEventHandler( BuddyBind.bindingButtonName, SystemData.Events.R_BUTTON_UP_PROCESSED, "BuddyBind.OnExitBindingMode" )

end





function BuddyBind.OnRawDeviceInput( deviceId, itemId, itemDown )
 
    if( deviceId == SystemData.InputDevice.MOUSE and (itemId == MOUSE1 or itemId == MOUSE2) )
    then
        return
    end
    
    if( BuddyBind.bindMode and itemDown )
    then
        if ( deviceId == SystemData.InputDevice.KEYBOARD )
        then

            if ( itemId == RCTRL )
            then
                itemId = LCTRL
            elseif ( itemId == RSHIFT )
            then
                itemId = LSHIFT
            elseif ( itemId == RALT )
            then
                itemId = LALT
            end

          BuddyBind.selectedKeys[itemId] = modifierKeyTableOrder[itemId]
            if( BuddyBind.selectedKeys[itemId] == nil )
            then
                BuddyBind.selectedKeys[itemId] = KEY_ORDER_LAST
            end
        else
            BuddyBind.selectedKeys[itemId] = KEY_ORDER_LAST
        end 
    
        local buttonName = GetButtonName( deviceId, itemId )
			LabelSetText("BuddyBindWindowKeyLabel",L"Key: "..towstring(buttonName))
        if( BuddyBind.bindingKeyName ~= L"" )
        then
            BuddyBind.bindingKeyName = BuddyBind.bindingKeyName..L" + "
        end
        
        BuddyBind.bindingKeyName = BuddyBind.bindingKeyName..buttonName
        
        if( ( deviceId ~= SystemData.InputDevice.KEYBOARD ) or not IsModifierKey( itemId ) )
        then
            local buttons = {}
            for orderValue = KEY_ORDER_FIRST, KEY_ORDER_LAST
            do
                for key, value in pairs( BuddyBind.selectedKeys )
                do
                    if ( value == orderValue )
                    then
                        table.insert( buttons, key )
                        break
                    end
                end
            end
	


              local boundKeyData = KeyMappingWindow.actionsData[ 204 ]["keys1"]
                RemoveBinding( KeyMappingWindow.actionsData[204].action, boundKeyData.deviceId, boundKeyData.buttons)

 
 AddBinding( KeyMappingWindow.actionsData[204].action, deviceId, buttons )
            
            
            ButtonSetPressedFlag( BuddyBind.bindingButtonName, false )
            ButtonSetStayDownFlag( BuddyBind.bindingButtonName, false ) 
            ButtonSetCheckButtonFlag( BuddyBind.bindingButtonName, false )
            BuddyBind.bindMode = false
            BuddyBind.bindingKeyName = L""
            
            WindowUnregisterCoreEventHandler( BuddyBind.bindingButtonName, "OnRawDeviceInput" )
            WindowUnregisterEventHandler( BuddyBind.bindingButtonName, SystemData.Events.L_BUTTON_UP_PROCESSED )
            WindowUnregisterEventHandler( BuddyBind.bindingButtonName, SystemData.Events.M_BUTTON_UP_PROCESSED )
            WindowUnregisterEventHandler( BuddyBind.bindingButtonName, SystemData.Events.R_BUTTON_UP_PROCESSED )
            
            KeyMappingWindow.bindingButtonName = ""
			
				local BindNumber = KeyUtils.GetFirstBindingNameForAction("ACTION_BAR_"..BuddyBind.Button)
		
	LabelSetText("BuddyBindWindowKeyLabel",L"Key: "..towstring(BindNumber))
			
        end
    end
end


function BuddyBind.OnExitBindingMode( flags, x, y, bForce )
    if( BuddyBind.bindMode and ( SystemData.MouseOverWindow.name ~= BuddyBind.bindingButtonName or bForce ) )
    then

        ButtonSetPressedFlag( BuddyBind.bindingButtonName, false )
        ButtonSetStayDownFlag( BuddyBind.bindingButtonName, false )
        ButtonSetCheckButtonFlag( BuddyBind.bindingButtonName, false )
        BuddyBind.bindMode = false
        BuddyBind.bindingKeyName = L""
        
        WindowUnregisterCoreEventHandler( BuddyBind.bindingButtonName, "OnRawDeviceInput" )
        WindowUnregisterEventHandler( BuddyBind.bindingButtonName, SystemData.Events.L_BUTTON_UP_PROCESSED )
        WindowUnregisterEventHandler( BuddyBind.bindingButtonName, SystemData.Events.M_BUTTON_UP_PROCESSED )
        WindowUnregisterEventHandler( BuddyBind.bindingButtonName, SystemData.Events.R_BUTTON_UP_PROCESSED )
        
        BuddyBind.bindingButtonName = ""
    end
end








