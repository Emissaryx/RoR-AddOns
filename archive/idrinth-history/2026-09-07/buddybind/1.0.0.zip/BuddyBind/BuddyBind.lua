BuddyBind = {}

function BuddyBind.init()
BuddyBind.Button = 0
CreateWindow("BuddyBindWindow", true)
BuddyBind.Name = L"Unbound"
LabelSetText("BuddyBindWindowNameLabel",towstring(BuddyBind.Name))
LabelSetText("BuddyBindWindowButtonLabel",L"Hotbar #")


WindowSetGameActionData("BuddyBindWindowExecute",GameData.PlayerActions.SET_TARGET,0,BuddyBind.Name)
WindowSetGameActionData("BuffButtonSettingsExecute",GameData.PlayerActions.SET_TARGET,0,BuddyBind.Name)
WindowSetGameActionTrigger("BuffButtonSettingsExecute", GetActionIdFromName("ACTION_BAR_"..BuddyBind.Button))
DynamicImageSetTexture("BuddyBindWindowGrabIcon","icon000051",64,64)
end
DynamicImageSetTexture("BuddyBindWindowGrabIcon","icon000051",64,64)
function BuddyBind.OnButtonTextChanged()
    local button = tonumber(TextEditBoxGetText("BuddyBindWindowActionEdit"))
    if not button then
        button = 1
    elseif button == 0 then
        return
    elseif button < 1 then
        button = 1
    elseif button > 120 then
        button = 120
    end   
    BuddyBind.Button = button
    TextEditBoxSetText("BuddyBindWindowActionEdit", towstring(button))	
	WindowSetGameActionTrigger("BuddyBindWindowExecute", GetActionIdFromName("ACTION_BAR_"..button))
end

function BuddyBind.OnButtonTextEnter()
    BuddyBind.OnButtonTextChanged()
    WindowAssignFocus("BuddyBindWindowActionEdit", false)
end

function BuddyBind.GrabName()
DynamicImageSetTexture("BuddyBindWindowGrabIcon","icon000051",64,64)

BuddyBind.Name = wstring.sub(TargetInfo:UnitName("selffriendlytarget"),1,-3 ) or L"Unbound"
LabelSetText("BuddyBindWindowNameLabel",towstring(BuddyBind.Name))
WindowSetGameActionData("BuddyBindWindow",GameData.PlayerActions.SET_TARGET,0,towstring(BuddyBind.Name))
WindowSetGameActionData("BuddyBindWindowExecute",GameData.PlayerActions.SET_TARGET,0,towstring(BuddyBind.Name))
end