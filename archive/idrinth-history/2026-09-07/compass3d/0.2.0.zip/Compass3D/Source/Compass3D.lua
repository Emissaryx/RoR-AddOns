--------------------------------------------------------------------------------
-- Compass3D
-- Original author: Zomega (Omegus)
-- Movable centre update: Kpihuss
-- Version: 0.2.0
--------------------------------------------------------------------------------

--------------------------------------------------------------------------------
-- Settings
--------------------------------------------------------------------------------

-- Customise the appearance of each point and even add more.
local compass_windows =
{
    { name = "Compass3D_PointN", icon = 20078, direction_x =  0, direction_y = -1, red = 255, green = 255, blue = 255, alpha = 0.5, scale = 1 },
    { name = "Compass3D_PointS", icon = 20083, direction_x =  0, direction_y =  1, red = 255, green = 255, blue = 255, alpha = 0.5, scale = 1 },
    { name = "Compass3D_PointE", icon = 20069, direction_x =  1, direction_y =  0, red = 255, green = 255, blue = 255, alpha = 0.5, scale = 1 },
    { name = "Compass3D_PointW", icon = 20087, direction_x = -1, direction_y =  0, red = 255, green = 255, blue = 255, alpha = 0.5, scale = 1 },
}

-- Movable origin used by the Layout Editor.
-- Move this window in the Layout Editor to move the whole compass.
-- The center frame has no visible icon; it is only a movable layout handle.
local compass_center =
{
    name = "Compass3D_Center",
    alpha = 0.0,
    scale = 1.0,
}

-- How far to lower the compass. If zero then it means to centre the compass on
-- the camera's pivot point which is the top of the player's head. 6ft works for
-- most human characters.
local compass_offset_feet = 6

-- How far each point is from the centre of your character.
local compass_radius_feet = 10

--------------------------------------------------------------------------------
-- DON'T TOUCH UNLESS YOU KNOW WHAT YOU'RE DOING
--------------------------------------------------------------------------------

-- Internally the client uses inches.
local compass_radius_inches = compass_radius_feet * 12
local compass_offset_inches = compass_offset_feet * 12

local WINDOW_NAME_TEMPLATE = "T_Compass3D_Point"
local CENTER_WINDOW_NAME_TEMPLATE = "T_Compass3D_Center"

Compass3D = Compass3D or {}

local function SafeDebugMessage (message)
  if (d ~= nil)
  then
    d (message)
  end
end

local function RegisterLayoutWindow ()
  -- Some client/addon environments expose LayoutEditor, others may not.
  -- Guarding this keeps the addon compatible and prevents startup errors.
  if (LayoutEditor ~= nil and LayoutEditor.RegisterWindow ~= nil)
  then
    LayoutEditor.RegisterWindow (
      compass_center.name,
      L"Compass3D Center",
      L"Move this frame to change the centre of the Compass3D overlay.",
      true,
      false,
      true,
      nil
    )
  end
end

local function UnregisterLayoutWindow ()
  if (LayoutEditor ~= nil and LayoutEditor.UnregisterWindow ~= nil)
  then
    LayoutEditor.UnregisterWindow (compass_center.name)
  end
end

local function GetCenterScreenOffset ()
  -- We keep the original Compass3D positioning model: the four compass points
  -- are still anchored to Root centre. The movable centre frame only contributes
  -- an extra screen-space offset. This is safer than anchoring all compass points
  -- directly to the movable frame, which can make them disappear on some clients.
  if (WindowGetScreenPosition == nil or WindowGetDimensions == nil)
  then
    return 0, 0
  end

  if (SystemData == nil or SystemData.screenResolution == nil)
  then
    return 0, 0
  end

  local center_left, center_top = WindowGetScreenPosition (compass_center.name)
  local center_width, center_height = WindowGetDimensions (compass_center.name)

  if (center_left == nil or center_top == nil or center_width == nil or center_height == nil)
  then
    return 0, 0
  end

  local root_center_x = SystemData.screenResolution.x / 2
  local root_center_y = SystemData.screenResolution.y / 2

  local center_x = center_left + (center_width / 2)
  local center_y = center_top + (center_height / 2)

  return center_x - root_center_x, center_y - root_center_y
end

function Compass3D.OnInitialize ()

  Compass3D.Camera.OnInitialize ()

  -- Create the movable centre first.
  CreateWindowFromTemplate (compass_center.name, CENTER_WINDOW_NAME_TEMPLATE, "Root")
  WindowSetShowing (compass_center.name, true)
  WindowSetScale (compass_center.name, compass_center.scale)
  WindowSetAlpha (compass_center.name, compass_center.alpha)

  RegisterLayoutWindow ()

  -- Create the 4 windows, one for each cardinal direction.
  for _, window in pairs (compass_windows)
  do
      CreateWindowFromTemplate (window.name, WINDOW_NAME_TEMPLATE, "Root")
      WindowSetShowing (window.name, true)
      WindowSetScale (window.name, window.scale)
      WindowSetTintColor (window.name, window.red, window.green, window.blue)

      local texture_name, texture_x, texture_y = GetIconData (window.icon)
      DynamicImageSetTexture (window.name .. "_Icon", texture_name, texture_x, texture_y)
  end

  SafeDebugMessage (L"[Compass3D] Loaded. Move 'Compass3D Center' in the Layout Editor to change the compass centre.")

end

function Compass3D.OnShutdown ()

  UnregisterLayoutWindow ()
  Compass3D.Camera.OnShutdown ()

end

function Compass3D.OnUpdate (time_delta_s)

  local camera_pivot_x, camera_pivot_y, camera_pivot_z, camera_pivot_zone_id = Compass3D.Camera.GetPivotZonePosition ()

  -- We can't work out the camera pivot point so just hide the compass windows.
  if (camera_pivot_x == nil)
  then
    for _, point in pairs (compass_windows)
    do
      WindowSetAlpha (point.name, 0.0)
    end

    return
  end

  local center_offset_x, center_offset_y = GetCenterScreenOffset ()

  local unscale_multiplier = 1.0 / 0.9  -- TODO: replace 0.9 with actual scaling multiplier.

  for _, window in pairs (compass_windows)
  do

    local point_zone_x = camera_pivot_x + (window.direction_x * compass_radius_inches)
    local point_zone_y = camera_pivot_y + (window.direction_y * compass_radius_inches)
    local point_zone_z = camera_pivot_z + compass_offset_inches

    local screen_visible, screen_x, screen_y = WorldToScreen (point_zone_x, point_zone_y, point_zone_z)

    local window_name = window.name

    if (screen_visible == true)
    then
      WindowClearAnchors (window_name)

      -- Keep the original Root-centred anchor, then add the offset of the
      -- movable centre marker. This preserves the original Compass3D behaviour
      -- and only shifts the final visual origin.
      WindowAddAnchor (
        window_name,
        "topleft",
        "Root",
        "center",
        (screen_x + center_offset_x) * unscale_multiplier,
        (screen_y + center_offset_y) * unscale_multiplier
      )

      WindowSetAlpha (window_name, window.alpha)
    else
      WindowSetAlpha (window_name, 0.0)
    end
  end

end
