# Compass3D Changelog

## Version 0.3.0 - 2026-05-12

Public release after 0.2.0.

- Added in-game transparency commands:
  - `/compass3d alpha 0-100`
  - `/compass3d alpha 0.0-1.0`
  - `/compass3d alpha show`
  - `/compass3d alpha reset`
  - `/c3d` alias
- Transparency is now saved between sessions.
- Added persistent compass centre positioning.
- Added Layout Editor handle: `Compass3D Center`.
- The centre handle remains invisible during normal gameplay.
- Added centre management commands:
  - `/compass3d center show`
  - `/compass3d center save`
  - `/compass3d center restore`
  - `/compass3d center set X Y`
  - `/compass3d center reset`
  - `/compass3d save`
- Centre position is saved only when explicitly using `/c3d center save` or `/c3d save`.
- Fixed progressive position drift after repeated `/rel` reloads by removing automatic centre saving during `OnUpdate` and `OnShutdown`.
- The addon SavedVariables are now the authoritative source for alpha and centre coordinates.
- Added primitive global SavedVariables:
  - `Compass3D_Alpha`
  - `Compass3D_CenterOffsetX`
  - `Compass3D_CenterOffsetY`
- Kept `Compass3D_Settings` for backwards compatibility with previous test builds.
- Updated addon metadata and notes with the public command list.
- Updated credits to include Kpihuss for the public release update.

## Version 0.2.0 - 2026-05-12

- Added a movable Layout Editor frame for the compass centre.
- Added `Compass3D Center` as the Layout Editor handle.
- Removed the visible `N` icon from the centre marker.
- Kept the original Compass3D Root-based projection and compass-point behaviour.
- Updated credits to include Kpihuss for the movable centre update.
