--------------------------------------------------------------------------------
-- Compass3D
-- Original author: Zomega (Omegus)
-- Movable centre, alpha command and public release update: Kpihuss
-- Version: 0.3.0
--------------------------------------------------------------------------------

--------------------------------------------------------------------------------
-- Settings
--------------------------------------------------------------------------------

-- Default transparency for the compass points.
-- Can be changed in-game with:
--   /compass3d alpha 50
--   /c3d alpha 50
-- Accepted values: 0-100 or 0.0-1.0.
local default_compass_alpha = 0.50

-- Customise the appearance of each point and even add more.
local compass_windows =
{
    { name = "Compass3D_PointN", icon = 20078, direction_x =  0, direction_y = -1, red = 255, green = 255, blue = 255, scale = 1 },
    { name = "Compass3D_PointS", icon = 20083, direction_x =  0, direction_y =  1, red = 255, green = 255, blue = 255, scale = 1 },
    { name = "Compass3D_PointE", icon = 20069, direction_x =  1, direction_y =  0, red = 255, green = 255, blue = 255, scale = 1 },
    { name = "Compass3D_PointW", icon = 20087, direction_x = -1, direction_y =  0, red = 255, green = 255, blue = 255, scale = 1 },
}

-- Movable origin used by the Layout Editor.
-- Move this window in the Layout Editor to move the whole compass.
-- The center frame has no visible icon; it is only a movable layout handle.
local compass_center =
{
    name = "Compass3D_CenterAnchor",
    alpha = 0.0,
    scale = 1.0,
}

-- How far to lower the compass. If zero then it means to centre the compass on
-- the camera's pivot point which is the top of the player's head. 6ft works for
-- most human characters.
local compass_offset_feet = 6

-- How far each point is from the centre of your character.
local compass_radius_feet = 10

--------------------------------------------------------------------------------
-- DON'T TOUCH UNLESS YOU KNOW WHAT YOU'RE DOING
--------------------------------------------------------------------------------

-- Internally the client uses inches.
local compass_radius_inches = compass_radius_feet * 12
local compass_offset_inches = compass_offset_feet * 12

local WINDOW_NAME_TEMPLATE = "T_Compass3D_Point"
local CENTER_WINDOW_NAME_TEMPLATE = "T_Compass3D_Center"

Compass3D = Compass3D or {}

-- Saved variables.
-- 0.3.0 deliberately keeps primitive globals as the authoritative values,
-- because WAR/RoR saves simple global SavedVariables more reliably than
-- addon-owned nested tables in some client setups.
-- Compass3D_Settings is kept for backwards compatibility/migration.
Compass3D_Settings = Compass3D_Settings or {}
Compass3D_Alpha = Compass3D_Alpha
Compass3D_CenterOffsetX = Compass3D_CenterOffsetX
Compass3D_CenterOffsetY = Compass3D_CenterOffsetY

local last_saved_center_offset_x = nil
local last_saved_center_offset_y = nil
local center_save_delay_s = 0
local center_restore_delay_s = 0
local center_restore_tick_s = 0

local function ClampNumber (value, minimum_value, maximum_value)
  if (value == nil)
  then
    return minimum_value
  end

  if (value < minimum_value)
  then
    return minimum_value
  end

  if (value > maximum_value)
  then
    return maximum_value
  end

  return value
end

local function RoundNumber (value)
  if (value == nil)
  then
    return 0
  end

  if (value >= 0)
  then
    return math.floor (value + 0.5)
  end

  return math.ceil (value - 0.5)
end

local function ToPlainString (value)
  if (value == nil)
  then
    return ""
  end

  if (type (value) == "string")
  then
    return value
  end

  if (WStringToString ~= nil)
  then
    return WStringToString (value)
  end

  return tostring (value)
end

local function ToWideString (value)
  if (towstring ~= nil)
  then
    return towstring (value)
  end

  return value
end

local function PrintMessage (message)
  if (EA_ChatWindow ~= nil and EA_ChatWindow.Print ~= nil)
  then
    EA_ChatWindow.Print (ToWideString (message))
  elseif (d ~= nil)
  then
    d (ToWideString (message))
  end
end

local function RegisterSavedSettings ()
  -- Migrate from the old table value when present, but use primitive globals
  -- as the source of truth for the public release.
  local alpha = tonumber (Compass3D_Alpha)
  if (alpha == nil and Compass3D_Settings ~= nil and Compass3D_Settings.alpha ~= nil)
  then
    alpha = tonumber (Compass3D_Settings.alpha)
  end
  if (alpha == nil)
  then
    alpha = default_compass_alpha
  end

  Compass3D_Alpha = ClampNumber (alpha, 0.0, 1.0)

  local offset_x = tonumber (Compass3D_CenterOffsetX)
  local offset_y = tonumber (Compass3D_CenterOffsetY)

  if (offset_x == nil and Compass3D_Settings ~= nil and Compass3D_Settings.center_offset_x ~= nil)
  then
    offset_x = tonumber (Compass3D_Settings.center_offset_x)
  end

  if (offset_y == nil and Compass3D_Settings ~= nil and Compass3D_Settings.center_offset_y ~= nil)
  then
    offset_y = tonumber (Compass3D_Settings.center_offset_y)
  end

  Compass3D_CenterOffsetX = RoundNumber (offset_x or 0)
  Compass3D_CenterOffsetY = RoundNumber (offset_y or 0)

  Compass3D_Settings = Compass3D_Settings or {}
  Compass3D_Settings.alpha = Compass3D_Alpha
  Compass3D_Settings.center_offset_x = Compass3D_CenterOffsetX
  Compass3D_Settings.center_offset_y = Compass3D_CenterOffsetY
  Compass3D_Settings.version = "0.3.0"

  last_saved_center_offset_x = Compass3D_CenterOffsetX
  last_saved_center_offset_y = Compass3D_CenterOffsetY

  if (RegisterForSave ~= nil)
  then
    RegisterForSave ("Compass3D_Alpha")
    RegisterForSave ("Compass3D_CenterOffsetX")
    RegisterForSave ("Compass3D_CenterOffsetY")
    RegisterForSave ("Compass3D_Settings")
  end
end

local function GetCompassAlpha ()
  local alpha = tonumber (Compass3D_Alpha)

  if (alpha == nil and Compass3D_Settings ~= nil and Compass3D_Settings.alpha ~= nil)
  then
    alpha = tonumber (Compass3D_Settings.alpha)
  end

  if (alpha == nil)
  then
    alpha = default_compass_alpha
  end

  return ClampNumber (alpha, 0.0, 1.0)
end

local function GetSavedCenterOffset ()
  local offset_x = tonumber (Compass3D_CenterOffsetX)
  local offset_y = tonumber (Compass3D_CenterOffsetY)

  if (offset_x == nil and Compass3D_Settings ~= nil)
  then
    offset_x = tonumber (Compass3D_Settings.center_offset_x)
  end

  if (offset_y == nil and Compass3D_Settings ~= nil)
  then
    offset_y = tonumber (Compass3D_Settings.center_offset_y)
  end

  return RoundNumber (offset_x or 0), RoundNumber (offset_y or 0)
end

local function SetNativeWindowSettings (offset_x, offset_y)
  -- 0.3.0: intentionally do not write the compass centre to the native
  -- Layout Editor/window settings. Some RoR clients re-apply that native
  -- position on /rel, which stacks with our own SavedVariables and causes
  -- the compass to drift farther away every reload.
  --
  -- Alpha and centre position are saved through the addon SavedVariables only.
end

local function ReadNativeWindowSettings ()
  -- Settings.GetSettingsForWindow has existed in WAR/RoR for normal UI windows,
  -- but different clients/builds may return either a table or nothing for custom
  -- addon frames. Keep this defensive so the addon never breaks if unavailable.
  if (Settings == nil or Settings.GetSettingsForWindow == nil)
  then
    return nil, nil
  end

  local settings = Settings.GetSettingsForWindow (compass_center.name)

  if (settings == nil or type (settings) ~= "table")
  then
    return nil, nil
  end

  local offset_x = settings.posX or settings.x or settings.offsetX or settings.left
  local offset_y = settings.posY or settings.y or settings.offsetY or settings.top

  if (offset_x == nil or offset_y == nil)
  then
    return nil, nil
  end

  return tonumber (offset_x), tonumber (offset_y)
end

local function RestoreCenterPosition ()
  if (DoesWindowExist ~= nil and DoesWindowExist (compass_center.name) == false)
  then
    return
  end

  local offset_x, offset_y = GetSavedCenterOffset ()
  offset_x = RoundNumber (offset_x)
  offset_y = RoundNumber (offset_y)

  -- 0.3.0: the addon SavedVariables are authoritative.
  -- Rebuild the anchor from scratch on every restore so /rel cannot compound
  -- native Layout Editor offsets with our saved offsets.
  if (WindowClearAnchors ~= nil and WindowAddAnchor ~= nil)
  then
    WindowClearAnchors (compass_center.name)
    WindowAddAnchor (compass_center.name, "center", "Root", "center", offset_x, offset_y)
  elseif (WindowSetOffsetFromParent ~= nil)
  then
    WindowSetOffsetFromParent (compass_center.name, offset_x, offset_y)
  end

  WindowSetScale (compass_center.name, compass_center.scale)
  WindowSetAlpha (compass_center.name, compass_center.alpha)
  WindowSetShowing (compass_center.name, true)

  if (WindowForceProcessAnchors ~= nil)
  then
    WindowForceProcessAnchors (compass_center.name)
  end

  last_saved_center_offset_x = offset_x
  last_saved_center_offset_y = offset_y
end

local function GetLiveCenterScreenOffset ()
  if (DoesWindowExist ~= nil and DoesWindowExist (compass_center.name) == false)
  then
    return nil, nil
  end

  if (WindowGetScreenPosition == nil or WindowGetDimensions == nil)
  then
    return nil, nil
  end

  local screen_width = nil
  local screen_height = nil

  if (GetScreenResolution ~= nil)
  then
    screen_width, screen_height = GetScreenResolution ()
  end

  if ((screen_width == nil or screen_height == nil) and SystemData ~= nil and SystemData.screenResolution ~= nil)
  then
    screen_width = SystemData.screenResolution.x
    screen_height = SystemData.screenResolution.y
  end

  if (screen_width == nil or screen_height == nil)
  then
    return nil, nil
  end

  local left, top = WindowGetScreenPosition (compass_center.name)
  local width, height = WindowGetDimensions (compass_center.name)

  if (left == nil or top == nil or width == nil or height == nil)
  then
    return nil, nil
  end

  local root_center_x = screen_width / 2
  local root_center_y = screen_height / 2
  local center_x = left + (width / 2)
  local center_y = top + (height / 2)

  return RoundNumber (center_x - root_center_x), RoundNumber (center_y - root_center_y)
end

local function ReadCenterOffsetFromWindow ()
  local live_x, live_y = GetLiveCenterScreenOffset ()
  if (live_x ~= nil and live_y ~= nil)
  then
    return live_x, live_y
  end

  if (DoesWindowExist ~= nil and DoesWindowExist (compass_center.name) == false)
  then
    return 0, 0
  end

  if (WindowGetOffsetFromParent ~= nil)
  then
    local offset_x, offset_y = WindowGetOffsetFromParent (compass_center.name)

    if (offset_x ~= nil and offset_y ~= nil)
    then
      return offset_x, offset_y
    end
  end

  return GetSavedCenterOffset ()
end

local function SaveCenterPositionFromWindow (force_save)
  -- 0.3.0: never auto-save the centre position.
  -- Auto-saving during /rel captures temporary/native layout positions and
  -- is what caused progressive drift. The centre is saved only when the user
  -- explicitly runs /c3d center save or /c3d save.
  if (force_save ~= true)
  then
    return
  end

  local offset_x, offset_y = ReadCenterOffsetFromWindow ()

  offset_x = RoundNumber (offset_x)
  offset_y = RoundNumber (offset_y)

  Compass3D_CenterOffsetX = offset_x
  Compass3D_CenterOffsetY = offset_y

  Compass3D_Settings = Compass3D_Settings or {}
  Compass3D_Settings.center_offset_x = offset_x
  Compass3D_Settings.center_offset_y = offset_y
  Compass3D_Settings.alpha = GetCompassAlpha ()
  Compass3D_Settings.version = "0.3.0"

  last_saved_center_offset_x = offset_x
  last_saved_center_offset_y = offset_y

  RestoreCenterPosition ()
end

local function GetCenterScreenOffset ()
  -- 0.3.0: draw the compass from the saved coordinates only.
  -- The live Layout Editor frame is read only by the explicit save command.
  return GetSavedCenterOffset ()
end

local function SetCompassAlpha (alpha)
  alpha = ClampNumber (tonumber (alpha), 0.0, 1.0)

  Compass3D_Alpha = alpha
  Compass3D_Settings = Compass3D_Settings or {}
  Compass3D_Settings.alpha = alpha
  Compass3D_Settings.version = "0.3.0"

  local offset_x, offset_y = GetSavedCenterOffset ()
  SetNativeWindowSettings (offset_x, offset_y)

  for _, window in pairs (compass_windows)
  do
    if (DoesWindowExist == nil or DoesWindowExist (window.name) == true)
    then
      WindowSetAlpha (window.name, alpha)
    end
  end

  PrintMessage ("[Compass3D] Compass alpha set to " .. tostring (math.floor ((alpha * 100) + 0.5)) .. "%." )
end

local function PrintHelp ()
  PrintMessage ("[Compass3D] Commands:")
  PrintMessage ("/compass3d alpha 0-100  - Set compass transparency.")
  PrintMessage ("/compass3d alpha 0.0-1.0 - Alternative decimal format.")
  PrintMessage ("/compass3d alpha show   - Show current transparency.")
  PrintMessage ("/compass3d alpha reset  - Reset transparency to default.")
  PrintMessage ("/compass3d center show  - Show saved centre offset.")
  PrintMessage ("/compass3d center save    - Save current Layout Editor centre.")
  PrintMessage ("/compass3d center restore - Restore centre from saved coordinates.")
  PrintMessage ("/compass3d center set X Y - Set centre offset manually.")
  PrintMessage ("/compass3d center reset   - Reset compass centre to screen centre.")
  PrintMessage ("/compass3d save         - Save current Layout Editor centre.")
  PrintMessage ("Alias: /c3d")
end

local function ParseAlphaValue (value_text)
  local value = tonumber (value_text)

  if (value == nil)
  then
    return nil
  end

  -- Accept both 0-100 and 0.0-1.0 formats.
  if (value > 1.0)
  then
    value = value / 100.0
  end

  return ClampNumber (value, 0.0, 1.0)
end

function Compass3D.SlashCommand (args)
  local text = string.lower (ToPlainString (args))

  local command, value = string.match (text, "^%s*(%S+)%s*(.-)%s*$")

  if (command == nil or command == "" or command == "help")
  then
    PrintHelp ()
    return
  end

  if (command == "alpha" or command == "a" or command == "transparency")
  then
    if (value == nil or value == "" or value == "show" or value == "current")
    then
      local current_alpha = GetCompassAlpha ()
      PrintMessage ("[Compass3D] Current compass alpha: " .. tostring (math.floor ((current_alpha * 100) + 0.5)) .. "%." )
      return
    end

    if (value == "reset" or value == "default")
    then
      SetCompassAlpha (default_compass_alpha)
      return
    end

    local parsed_alpha = ParseAlphaValue (value)

    if (parsed_alpha == nil)
    then
      PrintMessage ("[Compass3D] Invalid alpha value. Use /compass3d alpha 0-100, for example /compass3d alpha 50.")
      return
    end

    SetCompassAlpha (parsed_alpha)
    return
  end

  if (command == "save")
  then
    SaveCenterPositionFromWindow (true)
    local offset_x, offset_y = GetSavedCenterOffset ()
    PrintMessage ("[Compass3D] Settings saved: alpha=" .. tostring (math.floor ((GetCompassAlpha () * 100) + 0.5)) .. "%, x=" .. tostring (offset_x) .. ", y=" .. tostring (offset_y) .. ".")
    return
  end

  if (command == "center" or command == "centre" or command == "position" or command == "pos")
  then
    if (value == nil or value == "" or value == "show" or value == "current")
    then
      local saved_x, saved_y = GetSavedCenterOffset ()
      local live_x, live_y = ReadCenterOffsetFromWindow ()
      PrintMessage ("[Compass3D] Centre offset saved: x=" .. tostring (saved_x) .. ", y=" .. tostring (saved_y) .. ". Live: x=" .. tostring (RoundNumber (live_x)) .. ", y=" .. tostring (RoundNumber (live_y)) .. ".")
      return
    end

    if (value == "save")
    then
      SaveCenterPositionFromWindow (true)
      local offset_x, offset_y = GetSavedCenterOffset ()
      PrintMessage ("[Compass3D] Centre position force-saved: x=" .. tostring (offset_x) .. ", y=" .. tostring (offset_y) .. ".")
      return
    end

    if (value == "restore" or value == "load")
    then
      RestoreCenterPosition ()
      local offset_x, offset_y = GetSavedCenterOffset ()
      PrintMessage ("[Compass3D] Centre restored from saved offset: x=" .. tostring (offset_x) .. ", y=" .. tostring (offset_y) .. ".")
      return
    end

    local set_x, set_y = string.match (value or "", "^set%s+([%-%.%d]+)%s+([%-%.%d]+)%s*$")
    if (set_x ~= nil and set_y ~= nil)
    then
      Compass3D_CenterOffsetX = RoundNumber (tonumber (set_x) or 0)
      Compass3D_CenterOffsetY = RoundNumber (tonumber (set_y) or 0)
      Compass3D_Settings = Compass3D_Settings or {}
      Compass3D_Settings.center_offset_x = Compass3D_CenterOffsetX
      Compass3D_Settings.center_offset_y = Compass3D_CenterOffsetY
      Compass3D_Settings.alpha = GetCompassAlpha ()
      Compass3D_Settings.version = "0.3.0"
      RestoreCenterPosition ()
      SetNativeWindowSettings (Compass3D_CenterOffsetX, Compass3D_CenterOffsetY)
      PrintMessage ("[Compass3D] Centre offset set to x=" .. tostring (Compass3D_CenterOffsetX) .. ", y=" .. tostring (Compass3D_CenterOffsetY) .. ".")
      return
    end

    if (value == "reset" or value == "default")
    then
      Compass3D_CenterOffsetX = 0
      Compass3D_CenterOffsetY = 0
      Compass3D_Settings = Compass3D_Settings or {}
      Compass3D_Settings.center_offset_x = 0
      Compass3D_Settings.center_offset_y = 0
      Compass3D_Settings.alpha = GetCompassAlpha ()
      Compass3D_Settings.version = "0.3.0"
      last_saved_center_offset_x = 0
      last_saved_center_offset_y = 0
      RestoreCenterPosition ()
      SetNativeWindowSettings (0, 0)
      PrintMessage ("[Compass3D] Compass centre reset to screen centre.")
      return
    end

    PrintMessage ("[Compass3D] Invalid centre command. Use /compass3d center show, /compass3d center save, /compass3d center restore, /compass3d center set X Y or /compass3d center reset.")
    return
  end

  PrintHelp ()
end

local function RegisterSlashCommands ()
  if (LibSlash ~= nil and LibSlash.RegisterSlashCmd ~= nil)
  then
    LibSlash.RegisterSlashCmd ("compass3d", Compass3D.SlashCommand)
    LibSlash.RegisterSlashCmd ("c3d", Compass3D.SlashCommand)
  else
    PrintMessage ("[Compass3D] LibSlash not found. Slash commands are unavailable, but the compass still works.")
  end
end

local function RegisterLayoutWindow ()
  -- Some client/addon environments expose LayoutEditor, others may not.
  -- Guarding this keeps the addon compatible and prevents startup errors.
  if (LayoutEditor ~= nil and LayoutEditor.RegisterWindow ~= nil)
  then
    LayoutEditor.RegisterWindow (
      compass_center.name,
      L"Compass3D Center",
      L"Move this frame to change the centre of the Compass3D overlay.",
      true,
      false,
      true,
      nil
    )
  end
end

local function UnregisterLayoutWindow ()
  if (LayoutEditor ~= nil and LayoutEditor.UnregisterWindow ~= nil)
  then
    LayoutEditor.UnregisterWindow (compass_center.name)
  end
end

function Compass3D.OnInitialize ()

  RegisterSavedSettings ()
  RegisterSlashCommands ()

  Compass3D.Camera.OnInitialize ()

  -- Create the movable centre first.
  CreateWindowFromTemplate (compass_center.name, CENTER_WINDOW_NAME_TEMPLATE, "Root")
  WindowSetShowing (compass_center.name, true)
  WindowSetScale (compass_center.name, compass_center.scale)
  WindowSetAlpha (compass_center.name, compass_center.alpha)

  RegisterLayoutWindow ()
  RestoreCenterPosition ()
  center_save_delay_s = 3.0
  center_restore_delay_s = 3.0
  center_restore_tick_s = 0

  -- Create the 4 windows, one for each cardinal direction.
  for _, window in pairs (compass_windows)
  do
      CreateWindowFromTemplate (window.name, WINDOW_NAME_TEMPLATE, "Root")
      WindowSetShowing (window.name, true)
      WindowSetScale (window.name, window.scale)
      WindowSetAlpha (window.name, GetCompassAlpha ())
      WindowSetTintColor (window.name, window.red, window.green, window.blue)

      local texture_name, texture_x, texture_y = GetIconData (window.icon)
      DynamicImageSetTexture (window.name .. "_Icon", texture_name, texture_x, texture_y)
  end

  PrintMessage ("[Compass3D 0.3.0] Loaded. Alpha and centre use primitive SavedVariables. Centre position is saved only on /c3d center save to prevent reload drift.")

end

function Compass3D.OnShutdown ()

  -- Do not auto-save the centre on shutdown. During /rel the live Layout Editor
  -- position can contain temporary/native offsets and cause drift.
  -- Do not unregister the Layout Editor window on shutdown. Some clients use
  -- the registered window list while writing layout/window positions.
  Compass3D.Camera.OnShutdown ()

end

function Compass3D.OnUpdate (time_delta_s)

  local delta = time_delta_s or 0

  if (center_restore_delay_s > 0)
  then
    center_restore_delay_s = center_restore_delay_s - delta
    center_restore_tick_s = center_restore_tick_s - delta

    if (center_restore_tick_s <= 0)
    then
      RestoreCenterPosition ()
      center_restore_tick_s = 0.25
    end
  end

  if (center_save_delay_s > 0)
  then
    center_save_delay_s = center_save_delay_s - delta
  end

  local camera_pivot_x, camera_pivot_y, camera_pivot_z, camera_pivot_zone_id = Compass3D.Camera.GetPivotZonePosition ()

  -- We can't work out the camera pivot point so just hide the compass windows.
  if (camera_pivot_x == nil)
  then
    for _, point in pairs (compass_windows)
    do
      WindowSetAlpha (point.name, 0.0)
    end

    return
  end

  local center_offset_x, center_offset_y = GetCenterScreenOffset ()

  local unscale_multiplier = 1.0 / 0.9  -- TODO: replace 0.9 with actual scaling multiplier.
  local compass_alpha = GetCompassAlpha ()

  for _, window in pairs (compass_windows)
  do

    local point_zone_x = camera_pivot_x + (window.direction_x * compass_radius_inches)
    local point_zone_y = camera_pivot_y + (window.direction_y * compass_radius_inches)
    local point_zone_z = camera_pivot_z + compass_offset_inches

    local screen_visible, screen_x, screen_y = WorldToScreen (point_zone_x, point_zone_y, point_zone_z)

    local window_name = window.name

    if (screen_visible == true)
    then
      WindowClearAnchors (window_name)

      -- Keep the original Root-centred anchor, then add the offset of the
      -- movable centre marker. This preserves the original Compass3D behaviour
      -- and only shifts the final visual origin.
      WindowAddAnchor (
        window_name,
        "topleft",
        "Root",
        "center",
        (screen_x + center_offset_x) * unscale_multiplier,
        (screen_y + center_offset_y) * unscale_multiplier
      )

      WindowSetAlpha (window_name, compass_alpha)
    else
      WindowSetAlpha (window_name, 0.0)
    end
  end

end
