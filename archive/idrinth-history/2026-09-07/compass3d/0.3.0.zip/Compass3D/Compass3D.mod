<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile>
  <UiMod name="Compass3D" version="0.3.0" date="2026-05-12">

    <Author name="Zomega (Omegus); public 0.3.0 update by Kpihuss" />

    <Description text="v0.3.0. Commands: /compass3d alpha 0-100, /compass3d alpha show, /compass3d alpha reset, /compass3d center show, /compass3d center save, /compass3d center reset, /compass3d center restore, /compass3d center set X Y, /compass3d save. Alias: /c3d. Move compass origin in Layout Editor with Compass3D Center; position is saved between sessions through addon SavedVariables only. Use /c3d center save after moving Compass3D Center in the Layout Editor. This avoids progressive drift on /rel." />

    <Files>
      <!-- The order is important -->
      <File name="Source\ZoneData.lua" />
      <File name="Source\Camera.lua" />

      <File name="Source\Compass3D.xml" />
      <File name="Source\Compass3D.lua" />
    </Files>

    <SavedVariables>
      <!-- Primitive globals are the authoritative saved values for the public 0.3.0 release. -->
      <SavedVariable name="Compass3D_Alpha" global="true" />
      <SavedVariable name="Compass3D_CenterOffsetX" global="true" />
      <SavedVariable name="Compass3D_CenterOffsetY" global="true" />

      <!-- Kept for migration/backwards compatibility with previous test builds. -->
      <SavedVariable name="Compass3D_Settings" global="true" />
    </SavedVariables>

    <OnInitialize>
      <CallFunction name="Compass3D.OnInitialize" />
    </OnInitialize>

    <OnShutdown>
      <CallFunction name="Compass3D.OnShutdown" />
    </OnShutdown>

    <OnUpdate>
      <CallFunction name="Compass3D.OnUpdate" />
    </OnUpdate>

    <VersionSettings gameVersion="1.4.8" windowsVersion="1.0" savedVariablesVersion="1.0" />

  </UiMod>
</ModuleFile>
