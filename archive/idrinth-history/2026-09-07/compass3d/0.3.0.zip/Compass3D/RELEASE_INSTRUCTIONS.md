# Compass3D 0.3.0 Release Instructions

## Installation

1. Extract the ZIP file.
2. Copy the `Compass3D` folder into the game `Interface/AddOns` folder.
3. Start the game or run `/rel` if the addon folder was already present.
4. Enable `Compass3D` from the AddOns menu if needed.

## Moving the compass

1. Open the Layout Editor.
2. Move `Compass3D Center` to the desired position.
3. Close/apply the Layout Editor.
4. Run:

```text
/c3d center save
```

or:

```text
/c3d save
```

The centre position is not auto-saved. This is intentional and prevents the compass from drifting after repeated `/rel` reloads.

## Transparency commands

```text
/c3d alpha 50
/c3d alpha 0.35
/c3d alpha show
/c3d alpha reset
```

## Centre commands

```text
/c3d center show
/c3d center save
/c3d center restore
/c3d center set X Y
/c3d center reset
/c3d save
```

## Recommended release test

1. Run `/c3d alpha 40`.
2. Move `Compass3D Center` in the Layout Editor.
3. Run `/c3d center save`.
4. Run `/rel` several times.
5. Confirm that both alpha and position remain stable.
