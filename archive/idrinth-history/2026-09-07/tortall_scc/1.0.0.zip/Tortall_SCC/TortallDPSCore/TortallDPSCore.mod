<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" >
    <UiMod name="TortallDPSCore" version="2.3.0" date="05/30/2009" >
    <VersionSettings gameVersion="1.3.3" windowsVersion="1.0" savedVariablesVersion="1.0" />
        <Author name="Tortall" email="" />
        <Description text="Core mod for Tortall's mods" />
        <Dependencies>        
            <Dependency name="EA_ChatWindow" />
        </Dependencies>
        <Files>
            <File name="TortallDPSCore.lua" />
            <File name="TortallDPSCore-ru.lua" />
        </Files>
        <OnInitialize>
            <CallFunction name="TortallDPSCore.Initialize" />
        </OnInitialize>             
        <OnShutdown>
            <CallFunction name="TortallDPSCore.Shutdown" />
        </OnShutdown>
        <SavedVariables>
            <SavedVariable name="TortallDPSCore.SavedState" />
        </SavedVariables>

	<WARInfo>
			<Categories>
				<Category name="COMBAT" />
			</Categories>
			<Careers>
				<Career name="BLACKGUARD" />
				<Career name="WITCH_ELF" />
				<Career name="DISCIPLE" />
				<Career name="SORCERER" />
				<Career name="IRON_BREAKER" />
				<Career name="SLAYER" />
				<Career name="RUNE_PRIEST" />
				<Career name="ENGINEER" />
				<Career name="BLACK_ORC" />
				<Career name="CHOPPA" />
				<Career name="SHAMAN" />
				<Career name="SQUIG_HERDER" />
				<Career name="WITCH_HUNTER" />
				<Career name="KNIGHT" />
				<Career name="BRIGHT_WIZARD" />
				<Career name="WARRIOR_PRIEST" />
				<Career name="CHOSEN" />
				<Career name= "MARAUDER" />
				<Career name="ZEALOT" />
				<Career name="MAGUS" />
				<Career name="SWORDMASTER" />
				<Career name="SHADOW_WARRIOR" />
				<Career name="WHITE_LION" />
				<Career name="ARCHMAGE" />
			</Careers>
	</WARInfo>

    </UiMod>
    
</ModuleFile>
