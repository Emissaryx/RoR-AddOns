<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" >

    <UiMod name="Tortall_SCC" version="1.0.0" date="1/3/2009" >
    <VersionSettings gameVersion="1.3.3" windowsVersion="1.0" savedVariablesVersion="1.0" />
        <Author name="Tortall" email="" />
        <Description text="Tortall's Simplified Combat Log." />
        <Dependencies>        
            <Dependency name="EA_ChatWindow" />
            <Dependency name="LibSlash" />
            <Dependency name="TortallDPSCore" />
        </Dependencies>
        <Files>        
            <File name="Tortall_SCC.lua" />
        </Files>
        <OnInitialize>
            <CallFunction name="TortallSCC.Initialize" />
        </OnInitialize>             
        <SavedVariables>
            <SavedVariable name="TortallSCC.SavedState" />
        </SavedVariables>

	<WARInfo>
			<Categories>
				<Category name="COMBAT" />
			</Categories>
			<Careers>
				<Career name="BLACKGUARD" />
				<Career name="WITCH_ELF" />
				<Career name="DISCIPLE" />
				<Career name="SORCERER" />
				<Career name="IRON_BREAKER" />
				<Career name="SLAYER" />
				<Career name="RUNE_PRIEST" />
				<Career name="ENGINEER" />
				<Career name="BLACK_ORC" />
				<Career name="CHOPPA" />
				<Career name="SHAMAN" />
				<Career name="SQUIG_HERDER" />
				<Career name="WITCH_HUNTER" />
				<Career name="KNIGHT" />
				<Career name="BRIGHT_WIZARD" />
				<Career name="WARRIOR_PRIEST" />
				<Career name="CHOSEN" />
				<Career name= "MARAUDER" />
				<Career name="ZEALOT" />
				<Career name="MAGUS" />
				<Career name="SWORDMASTER" />
				<Career name="SHADOW_WARRIOR" />
				<Career name="WHITE_LION" />
				<Career name="ARCHMAGE" />
			</Careers>
	</WARInfo>

    </UiMod>
   
</ModuleFile>