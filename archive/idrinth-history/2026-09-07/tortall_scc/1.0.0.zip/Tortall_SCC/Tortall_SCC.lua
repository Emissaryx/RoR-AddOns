TortallSCC = {}

local origSetAllFiltersChanges
local origSetAllColorChanges

local MAX_WINDOW_GROUPS = 10 -- Defined locally in chatwindow.lua

local BASE_CHANNEL = 1229
local CHANNEL_DAMAGE_DEALT = BASE_CHANNEL
local CHANNEL_DAMAGE_TAKEN = BASE_CHANNEL + 1
local CHANNEL_HEAL_DEALT   = BASE_CHANNEL + 2
local CHANNEL_HEAL_TAKEN   = BASE_CHANNEL + 3
local CHANNEL_PET_HIT      = BASE_CHANNEL + 4
local MAX_CHANNEL = CHANNEL_PET_HIT

local channelNames = { [CHANNEL_DAMAGE_DEALT] = L"TSCC Damage Dealt",
                       [CHANNEL_DAMAGE_TAKEN] = L"TSCC Damage Taken",
                       [CHANNEL_HEAL_DEALT]   = L"TSCC Heal Done",
                       [CHANNEL_HEAL_TAKEN]   = L"TSCC Heal Received",
                       [CHANNEL_PET_HIT]      = L"TSCC Pet Damage" }
                       
local channelFormatDefs = { [CHANNEL_DAMAGE_DEALT] = L"[You] [$ability] [$crit $amount] [$object]",
                            [CHANNEL_DAMAGE_TAKEN] = L"[$object] [$ability] [$crit $amount] [You]",
                            [CHANNEL_HEAL_DEALT]   = L"[You] [$ability] [$crit $amount] [$object]",
                            [CHANNEL_HEAL_TAKEN]   = L"[$object] [$ability] [$crit $amount] [You]",
                            [CHANNEL_PET_HIT]      = L"[Pet] [$ability] [$crit $amount] [$object]" }

local channelFormats = { [CHANNEL_DAMAGE_DEALT] = L"[You] [$ability] [$crit $amount] [$object]",
                         [CHANNEL_DAMAGE_TAKEN] = L"[$object] [$ability] [$crit $amount] [You]",
                         [CHANNEL_HEAL_DEALT]   = L"[You] [$ability] [$crit $amount] [$object]",
                         [CHANNEL_HEAL_TAKEN]   = L"[$object] [$ability] [$crit $amount] [You]",
                         [CHANNEL_PET_HIT]      = L"[Pet] [$ability] [$crit $amount] [$object]" }
                       
local function ChannelColor( red, green, blue )
    return { r = red, g = green, b = blue }
end

local channelColors = { [CHANNEL_DAMAGE_DEALT] = ChannelColor(238, 113, 21),
                        [CHANNEL_DAMAGE_TAKEN] = ChannelColor(255, 39, 39),
                        [CHANNEL_HEAL_DEALT]   = ChannelColor(29, 217, 33),
                        [CHANNEL_HEAL_TAKEN]   = ChannelColor(55, 65, 248),
                        [CHANNEL_PET_HIT]      = ChannelColor(238, 113, 21) }
                       

local function ChatChannel( iname, iid, ilogName, ionFlag, iColor, iswitchTextIdx, icmd )
    local newChannel = 
    {
        name         = iname,
        id           = iid,
        logName      = ilogName,
        isOn         = ionFlag,
        defaultColor = iColor,
    };

    if ( iswitchTextIdx and icmd )
    then
        newChannel.slashCmds = BuildSlashCommands( ChatSettings.ChannelSwitches[iswitchTextIdx].commands )
        newChannel.labelText = ChatSettings.ChannelSwitches[iswitchTextIdx].replacement
        newChannel.serverCmd = icmd
        newChannel.remember  = ChatSettings.ChannelSwitches[iswitchTextIdx].rememberChan
    end

    return newChannel;
end

function TortallSCC.Initialize()
    if ( ChatSettings.Channels[ BASE_CHANNEL ] ~= nil ) then
        TextLogAddEntry("Chat", 0, L"TortallSCC: Required channel in use.  Not initializing.")
        return
    end
    
    LibSlash.RegisterSlashCmd("tscc", TortallSCC.SlashHandler)
    
    -- Hook ChatWindow procedures so we know when settings have chnaged.
    origSetAllFiltersChanges = ChatFiltersWindow.SetAllFiltersChanges
    ChatFiltersWindow.SetAllFiltersChanges = TortallSCC.SetAllFiltersChanges
    
    origSetAllColorChanges = ChatOptionsWindow.SetAllColorChanges
    ChatOptionsWindow.SetAllColorChanges = TortallSCC.SetAllColorChanges
    
    if ( TortallSCC.SavedState == nil ) then TortallSCC.SavedState = { Channels = {} } end
    
    if ( TortallSCC.SavedState.ChannelFormats ~= nil ) then
        channelFormats = TortallSCC.SavedState.ChannelFormats
    end
    TortallSCC.SavedState.ChannelFormats = channelFormats
    
    local channel
    for channel = CHANNEL_DAMAGE_DEALT, MAX_CHANNEL do
        TextLogAddFilterType("Combat", channel, L"")

        ChatSettings.Channels[ channel ] = ChatChannel( channelNames[channel], channel, "Combat", true, channelColors[channel] )
        ChatSettings.ChannelColors[ channel ] = channelColors[channel]
        table.insert(ChatSettings.Ordering, channel)

        for winGroup=1, MAX_WINDOW_GROUPS do
            if EA_ChatWindowGroups[winGroup].used == true then
                -- Cycle through tabs in group
                for tabIndex, tab in ipairs(EA_ChatWindowGroups[winGroup].Tabs) do
                    local tabName = EA_ChatTabManager.GetTabName( tab.tabManagerId )
                    local logName = tabName .. "TextLog"
                    
                    local state = false
                    if ( TortallSCC.SavedState.Channels[tabName] ~= nil ) and ( TortallSCC.SavedState.Channels[tabName][channel] ~= nil ) then
                        state = TortallSCC.SavedState.Channels[tabName][channel].state
                    end
                    LogDisplaySetFilterState(logName, "Combat", channel, state)
                    
                    local color = channelColors[channel]
                    if ( TortallSCC.SavedState.Channels[tabName] ~= nil ) and ( TortallSCC.SavedState.Channels[tabName][channel] ~= nil ) then
                        color = TortallSCC.SavedState.Channels[tabName][channel].color
                    end
                    LogDisplaySetFilterColor(logName, "Combat", channel, color.r, color.g, color.b)
                end
            end
        end
        
        TextLogAddEntry("Combat", channel, channelNames[channel])
    end
    
    TortallDPSCore.Register("TortallSCC", nil, nil, TortallSCC.LatestObject)
end

function TortallSCC.SetAllFiltersChanges()
    origSetAllFiltersChanges()
    
    TortallSCC.SaveSettings()
end

function TortallSCC.SetAllColorChanges()
    origSetAllColorChanges()
    
    TortallSCC.SaveSettings()
end

function TortallSCC.SaveSettings()
    local channel
    for channel = CHANNEL_DAMAGE_DEALT, MAX_CHANNEL do
        for winGroup=1, MAX_WINDOW_GROUPS do
            if EA_ChatWindowGroups[winGroup].used == true then
                -- Cycle through tabs in group
                for tabIndex, tab in ipairs(EA_ChatWindowGroups[winGroup].Tabs) do
                    local tabName = EA_ChatTabManager.GetTabName( tab.tabManagerId )
                    local logName = tabName .. "TextLog"
                    
                    if ( TortallSCC.SavedState.Channels[tabName] == nil ) then
                        TortallSCC.SavedState.Channels[tabName] = {}
                    end
                    
                    TortallSCC.SavedState.Channels[tabName][channel] = {}
                    
                    local state = LogDisplayGetFilterState(logName, "Combat", channel)
                    TortallSCC.SavedState.Channels[tabName][channel].state = state
                    
                    local color = {}
                    color.r, color.g, color.b = LogDisplayGetFilterColor(logName, "Combat", channel)
                    TortallSCC.SavedState.Channels[tabName][channel].color = color
                end
            end
        end
    end
end

local function Interpolate( str, ability, crit, amount, object, mitigated, absorbed )
    local formats = { [L"$ability"   ] = ability,
                      [L"$crit"      ] = crit,
                      [L"$amount"    ] = amount,
                      [L"$object"    ] = object,
                      [L"$mitigated" ] = mitigated,
                      [L"$absorbed"  ] = absorbed,}

    local k, v
    for k, v in pairs(formats) do
        str = str:gsub(k, towstring(v))
    end
    
    return str
end

function TortallSCC.LatestObject( dmgType, object, targetType, channel, data )
    if ( targetType == TortallDPSCore.TARGET ) then return end

    local critText = L""
    if ( data.Critical == true ) then critText = L"CRIT" end
    
    if ( dmgType == TortallDPSCore.DAMAGE_DEALT ) then
        if ( data.Pet == false ) then
            TextLogAddEntry("Combat", CHANNEL_DAMAGE_DEALT, Interpolate(channelFormats[CHANNEL_DAMAGE_DEALT], data.Ability, critText, data.Amount, data.Object, data.Mitigated, data.Absorbed))
        else
            TextLogAddEntry("Combat", CHANNEL_PET_HIT, Interpolate(channelFormats[CHANNEL_PET_HIT], data.Ability, critText, data.Amount, data.Object, data.Mitigated, data.Absorbed))
        end
    elseif ( dmgType == TortallDPSCore.DAMAGE_TAKEN ) then
        TextLogAddEntry("Combat", CHANNEL_DAMAGE_TAKEN, Interpolate(channelFormats[CHANNEL_DAMAGE_TAKEN], data.Ability, critText, data.Amount, data.Object, data.Mitigated, data.Absorbed))
    elseif ( dmgType == TortallDPSCore.HEAL_DEALT ) then
        TextLogAddEntry("Combat", CHANNEL_HEAL_DEALT, Interpolate(channelFormats[CHANNEL_HEAL_DEALT], data.Ability, critText, data.Amount, data.Object, data.Mitigated, data.Absorbed))
    elseif ( dmgType == TortallDPSCore.HEAL_TAKEN ) then
        TextLogAddEntry("Combat", CHANNEL_HEAL_TAKEN, Interpolate(channelFormats[CHANNEL_HEAL_TAKEN], data.Ability, critText, data.Amount, data.Object, data.Mitigated, data.Absorbed))
    end
end

function TortallSCC.SlashHandler( args )
    local cmdMap = { ["damagedealt"]  = CHANNEL_DAMAGE_DEALT,
                     ["damagetaken"]  = CHANNEL_DAMAGE_TAKEN,
                     ["healdone"]     = CHANNEL_HEAL_DEALT,
                     ["healreceived"] = CHANNEL_HEAL_TAKEN,
                     ["petdamage"]    = CHANNEL_PET_HIT }
                     
    local cmd, str
    _, _, cmd, str = args:find("^(%w*) (.*)")
    
    if ( cmdMap[cmd] == nil ) then return end
    
    str = str:gsub("^%s*", "")
    str = str:gsub("%s*$", "")
    if ( str == nil ) or ( str == "" ) then return end
    
    if ( str == "default" ) then str = channelFormatDefs[cmdMap[cmd]] end

    channelFormats[cmdMap[cmd]] = towstring(str)
end
