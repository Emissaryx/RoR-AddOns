<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
	<UiMod name="WarBoard_TaliMon" version="1.2" date="05/31/2009">
	<VersionSettings gameVersion="1.4.1" windowsVersion="1.0" />
		<Author name="Computerpunk" email="teromario@yahoo.com" />
		<Description text="Displays the current Talisman timers and empty slots" />
		<Dependencies>
			<Dependency name="WarBoard" />
			<Dependency name="LibSlash" />
		</Dependencies>
  
		<Files>
			<File name="WarBoard_TaliMon.lua" />
			<File name="WarBoard_TaliMon.xml" />
		</Files>
		<OnInitialize>
			<CallFunction name="WarBoard_TaliMon.Initialize" />
		</OnInitialize>
		<SavedVariables>
			<SavedVariable name="WarBoardTaliMonSettings" />
		</SavedVariables>
		<WARInfo>
	<Categories>
		<Category name="ITEMS_INVENTORY" />
		<Category name="CRAFTING" />
	</Categories>
	<Careers>
		<Career name="BLACKGUARD" />
		<Career name="WITCH_ELF" />
		<Career name="DISCIPLE" />
		<Career name="SORCERER" />
		<Career name="IRON_BREAKER" />
		<Career name="SLAYER" />
		<Career name="RUNE_PRIEST" />
		<Career name="ENGINEER" />
		<Career name="BLACK_ORC" />
		<Career name="CHOPPA" />
		<Career name="SHAMAN" />
		<Career name="SQUIG_HERDER" />
		<Career name="WITCH_HUNTER" />
		<Career name="KNIGHT" />
		<Career name="BRIGHT_WIZARD" />
		<Career name="WARRIOR_PRIEST" />
		<Career name="CHOSEN" />
		<Career name= "MARAUDER" />
		<Career name="ZEALOT" />
		<Career name="MAGUS" />
		<Career name="SWORDMASTER" />
		<Career name="SHADOW_WARRIOR" />
		<Career name="WHITE_LION" />
		<Career name="ARCHMAGE" />
	</Careers>
		</WARInfo>
	</UiMod>
</ModuleFile>
