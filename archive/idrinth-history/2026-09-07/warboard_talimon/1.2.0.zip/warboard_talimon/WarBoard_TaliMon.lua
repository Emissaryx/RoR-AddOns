if not WarBoard_TaliMon then WarBoard_TaliMon = {} end
local WarBoard_TaliMon = WarBoard_TaliMon
local windowName = "WarBoard_TaliMon"
local itemsData, empty, labels, itemsDataHolder = {}, 0, {}
local LabelSetText, getn, towstring, pairs, FormatTimeCondensedTruncate, Tooltips =
	  LabelSetText, table.getn, towstring, pairs, TimeUtils.FormatTimeCondensedTruncate, Tooltips

local function print(msg)
	EA_ChatWindow.Print(towstring(msg))
end

local function UpdateIconLabel()
	LabelSetText(windowName.."_lbl", towstring(empty))
end

function WarBoard_TaliMon.Initialize()
	if WarBoard.AddMod("WarBoard_TaliMon") then
		WarBoard_TaliMon.SetIcon("WarBoard_TaliMonIcon", 00285)
	end
	if not WarBoardTaliMonSettings then WarBoardTaliMonSettings = { ShowAll = true, } end
	UpdateIconLabel()
	RegisterEventHandler(SystemData.Events.PLAYER_ZONE_CHANGED, "WarBoard_TaliMon.GetValues")
	RegisterEventHandler(SystemData.Events.PLAYER_INVENTORY_SLOT_UPDATED, "WarBoard_TaliMon.GetValues")
	RegisterEventHandler(SystemData.Events.UPDATE_ITEM_ENHANCEMENT, "WarBoard_TaliMon.GetValues")
	RegisterEventHandler(SystemData.Events.END_ITEM_ENHANCEMENT, "WarBoard_TaliMon.GetValues")
	RegisterEventHandler(SystemData.Events.LOADING_END, "WarBoard_TaliMon.GetValues")
end

function WarBoard_TaliMon.ShowStatus()
	Tooltips.CreateTextOnlyTooltip(windowName, nil)
	Tooltips.AnchorTooltip(WarBoard.GetModToolTipAnchor(windowName))
	Tooltips.SetTooltipText(1, 1, L"Talisman Monitor")
	Tooltips.SetTooltipColor(1, 1, 163, 53, 255)
	Tooltips.SetTooltipText(2, 1, WarBoard_TaliMon.GetValues())
	Tooltips.Finalize()
end

function WarBoard_TaliMon.SetIcon(dynamicImageTitle, icon)
	local texture, x, y = GetIconData(icon)
	DynamicImageSetTexture(dynamicImageTitle, texture, x, y)
end

function WarBoard_TaliMon.GetEnhValues(myItem)
	local myValues=L""
	for key,value in pairs(myItem) do
		local slot = myItem[key]
		for k,v in pairs(slot.bonus) do
			local duration = slot.bonus[k].duration
			local value = slot.bonus[k].value
			if duration > 0 or WarBoardTaliMonSettings.ShowAll then
				if duration == 0 then
					durvalue = L""
				else
					durvalue = TimeUtils.FormatTimeCondensedTruncate(duration)
				end
				myValues = myValues..slot.name..L" [ +"..value..L" "..durvalue..L" ]\n"
			end
		end
	end
	return myValues
end

function WarBoard_TaliMon.GetValues()
	local myValues = L""
	itemsDataHolder = {}
	empty = 0
	for key,value in pairs(GameData.EquipSlots) do
		local item = DataUtils.GetEquipmentData()[value]
		if item.numEnhancementSlots > 0 then 
			if getn(item.enhSlot) > 0 then
				myValues = myValues..WarBoard_TaliMon.GetEnhValues(item.enhSlot)
			else
				empty = empty+1
			end
		end
	end
	if empty > 0 then
		myValues = myValues..L"Empty Slots "..L" - "..empty
	end
	UpdateIconLabel()
	return myValues
end

function WarBoard_TaliMon.ToggleShowAll()
	WarBoardTaliMonSettings.ShowAll = not WarBoardTaliMonSettings.ShowAll
	if WarBoardTaliMonSettings.ShowAll then 
		print("Now hiding permanent Talismans.")
	else
		print("Now showing all Talismans.")
	end
end
