local EnableGuildCheckToggle = false
local EnableModCheckToggle = false

local VERSION = L"1.2"
local ORDER_BY_GUILD  = 1
local ORDER_BY_AMOUNT = 2
local ORDER_DESC = 1
local ORDER_ASC  = 2
local AMOUNT_TYPE_TAX   = 1
local AMOUNT_TYPE_TITHE = 2
local AMOUNT_TYPE_TAX_AND_TITHE = 3
local PAYER_TYPE_ALL = 1
local PAYER_TYPE_CURRENT = 2


TaxPayer = {}
TaxPayer.Debug = {}
TaxPayer.Debug.Enabled = false
TaxPayer.Debug.Level   = 0

TaxPayer.Enabled = true
TaxPayer.Window = "TaxPayer"

TaxPayer.AmountPaid = {}
TaxPayer.AmountPaidOrdered = {}
TaxPayer.AmountType = { [AMOUNT_TYPE_TAX]           = {name = "Taxes Only"    , value = "taxes"}
                      , [AMOUNT_TYPE_TITHE]         = {name = "Tithes Only"   , value = "tithes"}
                      , [AMOUNT_TYPE_TAX_AND_TITHE] = {name = "Taxes & Tithes", value = "taxes & tithes"}
                      }

TaxPayer.PayerType = { [PAYER_TYPE_ALL]     = {name = "All Toons" , value = "All of my toons have paid "}
                     , [PAYER_TYPE_CURRENT] = {name = "This Toon" , value = "This toon has paid "}
                     }

TaxPayer.GoldIcon   = GetString(StringTables.Default.ICON_MONEY_GOLD  )
TaxPayer.GoldText   = GetString(StringTables.Default.TEXT_MONEY_GOLD  )
TaxPayer.SilverIcon = GetString(StringTables.Default.ICON_MONEY_SILVER)
TaxPayer.SilverText = GetString(StringTables.Default.TEXT_MONEY_SILVER)
TaxPayer.BrassIcon  = GetString(StringTables.Default.ICON_MONEY_BRASS )
TaxPayer.BrassText  = GetString(StringTables.Default.TEXT_MONEY_BRASS )
TaxPayer.RemoveIndex = {}
TaxPayer.RemoveIndexSorted = {}
TaxPayer.SelectedGuild = ""
TaxPayer.TaxRate = { [AMOUNT_TYPE_TAX]   = {rate = 0, percentage = 0}
                   , [AMOUNT_TYPE_TITHE] = {rate = 0, percentage = 0}
				   }

function TaxPayer.Initialise()
	TaxPayer.DebugMsg(L"Entering Initialise",3)
	-- Check to see if any options are saved on the users profile. If not set default values.
	if not TaxPayer.Settings then
		TaxPayer.Settings = {}
		TaxPayer.Settings.AmountType = AMOUNT_TYPE_TAX
		TaxPayer.Settings.Enabled   = true
		TaxPayer.Settings.GuildNote = false
		TaxPayer.Settings.OrderType = ORDER_BY_GUILD
		TaxPayer.Settings.OrderDirection = ORDER_DESC
		TaxPayer.Settings.PayerType  = PAYER_TYPE_CURRENT
		TaxPayer.Settings.Version = VERSION
	end

	TaxPayer.Settings.Version = VERSION

	if not TaxPayer.GlobalSettings then
		TaxPayer.GlobalSettings = {}
		TaxPayer.GlobalSettings.AmountPaid = {}
	end
	TaxPayer.Enabled = TaxPayer.Settings.Enabled
	if TaxPayer.Enabled then
		TaxPayer.RegisterEvents()
	end
	-- Register the slash command.
	LibSlash.RegisterSlashCmd("taxpayer", TaxPayer.Slash)
	LibSlash.RegisterSlashCmd("taxp", TaxPayer.Slash)
	LibSlash.RegisterSlashCmd("taxpd", function(args) TaxPayer.SlashDebug(args) end)

	--Initialise the options window
	TaxPayer.UpdateTaxRate(GameData.Guild.TaxRate, GameData.Guild.TitheRate)
	TaxPayer.WindowInit()
	TaxPayer.UpdateLocalAmountPaid()

	local msg = ""
	if TaxPayer.Enabled then
		msg = L"TaxPayer is enabled. Type /taxp for options"
	else
		msg = L"TaxPayer is disabled. Type /taxp for options"
	end
	EA_ChatWindow.Print(msg)
	TaxPayer.DebugMsg(L"Leaving Initialise",3)
end

function TaxPayer.RegisterEvents()
	TaxPayer.DebugMsg(L"Entering RegisterEvents",3)
	-- Hook the mod into the appropriate events
	RegisterEventHandler(SystemData.Events.GUILD_TAX_TITHE_UPDATED, "TaxPayer.UpdateTaxRate")
	RegisterEventHandler(SystemData.Events.CHAT_TEXT_ARRIVED, "TaxPayer.CommsReceived")
	TaxPayer.DebugMsg(L"Leaving RegisterEvents",3)
end

function TaxPayer.UnregisterEvents()
	TaxPayer.DebugMsg(L"Entering UnregisterEvents",3)
	-- Unhook the mod from the appropriate events
	UnregisterEventHandler(SystemData.Events.GUILD_TAX_TITHE_UPDATED, "TaxPayer.UpdateTaxRate")
	UnregisterEventHandler(SystemData.Events.CHAT_TEXT_ARRIVED, "TaxPayer.CommsReceived")
	TaxPayer.DebugMsg(L"Leaving UnregisterEvents",3)
end

function TaxPayer.DebugMsg(str,lvl)
	-- If debug is enabled and the priority of the message is high enough then send a debug message
	if TaxPayer.Debug.Enabled and lvl <= TaxPayer.Debug.Level then
		d(towstring(str))
	end
end

function TaxPayer.SlashDebug(args)
	TaxPayer.DebugMsg(L"Entering SlashDebug",3)
	local arg, argv = args:match("([a-z0-9]+)[ ]?(.*)")
	TaxPayer.DebugMsg("SlashDebug: arg ["..arg.."] argv ["..argv.."]",2)
	if arg == nil then
		TaxPayer.Debug.Enabled = not TaxPayer.Debug.Enabled
		return
	end
	-- Set to true to display debug messaTaxPayer in the debug window (Note: type /debug in game to see this window and pTaxPayers the button "Logs(off)")
	-- Set the debug level (4 = Update Ticks, 3 = Position, 2 = Setting values, 1 = Return values, 0 = Illegal flow catches)
	if arg == "on" then
		TaxPayer.Debug.Enabled = true
	elseif arg == "off" then
		TaxPayer.Debug.Enabled = false
	elseif arg == "1" then
		TaxPayer.Debug.Enabled = true
		TaxPayer.Debug.Level = 1
	elseif arg == "2" then
		TaxPayer.Debug.Enabled = true
		TaxPayer.Debug.Level = 2
	elseif arg == "3" then
		TaxPayer.Debug.Enabled = true
		TaxPayer.Debug.Level = 3
	elseif arg == "4" then
		TaxPayer.Debug.Enabled = true
		TaxPayer.Debug.Level = 4
	else
		TaxPayer.DebugMsg("SlashDebug: Invalid Argument ["..arg.."]",0)
	end
	TaxPayer.DebugMsg(L"Leaving SlashDebug",3)
end

function TaxPayer.UpdateTaxRate(taxRate, titheRate)
	TaxPayer.DebugMsg(L"Entering UpdateTaxRate",3)
	local totalTaxRate    = 0
	local totalPercentage = 0
	local taxPercentage   = 0
	local tithePercentage = 0
	if not taxRate   then taxRate   = 0 end
	if not titheRate then titheRate = 0 end
	totalTaxRate = taxRate + titheRate
	if totalTaxRate ~= 0 then
		totalPercentage = 100 / totalTaxRate
		taxPercentage   = (totalPercentage * taxRate)   / 100
		tithePercentage = (totalPercentage * titheRate) / 100
	end
	TaxPayer.TaxRate[AMOUNT_TYPE_TAX]   = {rate = taxRate  , percentage = taxPercentage}
    TaxPayer.TaxRate[AMOUNT_TYPE_TITHE] = {rate = titheRate, percentage = tithePercentage}
	TaxPayer.DebugMsg(L"Leaving StartCast",3)
end

function TaxPayer.ConvertBrassToCurrency(amount)
	TaxPayer.DebugMsg(L"Entering ConvertBrassToCurrency",3)
    if not amount then return 0, 0, 0 end
    local gold   = math.floor(amount / 10000)
    local silver = math.floor((amount - (gold * 10000)) / 100)
    local brass  = math.mod  (amount, 100)
    TaxPayer.DebugMsg(L"Leaving ConvertBrassToCurrency",3)
	return gold, silver, brass
end

function TaxPayer.ConvertCurrencyToBrass(gold, silver, brass)
	TaxPayer.DebugMsg(L"Entering ConvertCurrencyToBrass",3)
	if not gold   then gold   = 0 end
	if not silver then silver = 0 end
	if not brass  then brass  = 0 end
    local amount = (gold * 10000) + (silver * 100) + brass
    TaxPayer.DebugMsg(L"Leaving ConvertCurrencyToBrass",3)
	return amount
end

function TaxPayer.UpdateGuildMemberNote()
	TaxPayer.DebugMsg(L"Entering UpdateGuildMemberNote",3)
	if not TaxPayer.Settings.GuildNote then return end
	local note = TaxPayer.GenerateComment(GameData.Guild.m_GuildName, true)
	SendChatText(L"/guildnote "..GameData.Player.name..L" "..note, L"")
	TaxPayer.DebugMsg(L"Leaving UpdateGuildMemberNote",3)
end

function TaxPayer.AnnounceInGuild()
	TaxPayer.DebugMsg(L"Entering AnnounceInGuild",3)
	TaxPayer.Announce(ChatSettings.Channels[SystemData.ChatLogFilters.GUILD].serverCmd)
	TaxPayer.DebugMsg(L"Leaving AnnounceInGuild",3)
end

function TaxPayer.AnnounceInAlliance()
	TaxPayer.DebugMsg(L"Entering AnnounceInGuild",3)
	TaxPayer.Announce(ChatSettings.Channels[SystemData.ChatLogFilters.ALLIANCE].serverCmd)
	TaxPayer.DebugMsg(L"Leaving AnnounceInGuild",3)
end

function TaxPayer.AnnounceInParty()
	TaxPayer.DebugMsg(L"Entering AnnounceInGuild",3)
	TaxPayer.Announce(ChatSettings.Channels[SystemData.ChatLogFilters.GROUP].serverCmd)
	TaxPayer.DebugMsg(L"Leaving AnnounceInGuild",3)
end

function TaxPayer.AnnounceInWarband()
	TaxPayer.DebugMsg(L"Entering AnnounceInGuild",3)
	TaxPayer.Announce(ChatSettings.Channels[SystemData.ChatLogFilters.BATTLEGROUP].serverCmd)
	TaxPayer.DebugMsg(L"Leaving AnnounceInGuild",3)
end

function TaxPayer.Announce(channel)
	TaxPayer.DebugMsg(L"Entering Announce",3)
	local message = TaxPayer.GenerateComment(TaxPayer.SelectedGuild, false)
	if not channel then
		channel = ChatSettings.Channels[SystemData.ChatLogFilters.SHOUT].serverCmd
	end
	-- Send the text
	SendChatText(channel..L" "..message, L"")
	TaxPayer.DebugMsg(L"Leaving Announce",3)
end

function TaxPayer.GenerateComment(guildName, isGuildNote)
	TaxPayer.DebugMsg(L"Entering GenerateComment",3)
	local gold, silver, brass = TaxPayer.GetLocalAmountPaid(guildName)
	local amountType = TaxPayer.AmountType[TaxPayer.Settings.AmountType].value
	local payer = ""
	local guild = ""
	if isGuildNote then
		payer =  TaxPayer.PayerType[TaxPayer.Settings.PayerType].value
	else
		guild = " to "..tostring(guildName)
	end
	local note = towstring(payer..gold.."G, "..silver.."S, "..brass.."B in "..amountType..guild)
	TaxPayer.DebugMsg(L"Leaving GenerateComment",3)
	return note
end

function TaxPayer.CommsReceived()
	TaxPayer.DebugMsg(L"Entering CommsReceived",4)
	local isTaxes = false
	local commsGold   = 0
	local commsSilver = 0
	local commsBrass  = 0
	if GameData.ChatData.type == SystemData.ChatLogFilters.LOOT_COIN then
		TaxPayer.contents = StringSplit(tostring(GameData.ChatData.text)," ")
		if SystemData.Settings.Language.active == SystemData.Settings.Language.FRENCH then
			isTaxes, commsGold, commsSilver, commsBrass = TaxPayer.CommsParseFrench()
		else
			isTaxes, commsGold, commsSilver, commsBrass = TaxPayer.CommsParseEnglish()
		end
	end	
	if isTaxes then
		local amountPaid = TaxPayer.ConvertCurrencyToBrass(commsGold, commsSilver, commsBrass)
		local taxPaid = 0
		local tithePaid = 0
		if TaxPayer.TaxRate[AMOUNT_TYPE_TAX].percentage ~= 0 then
			taxPaid = math.floor(amountPaid * TaxPayer.TaxRate[AMOUNT_TYPE_TAX].percentage)
		end
		if TaxPayer.TaxRate[AMOUNT_TYPE_TITHE].percentage ~= 0 then
			tithePaid = math.floor(amountPaid * TaxPayer.TaxRate[AMOUNT_TYPE_TITHE].percentage)
		end
		if (amountPaid - (taxPaid + tithePaid)) == 1 then
			taxPaid = taxPaid + 1
		end
		TaxPayer.IncreaseAmountPaid(GameData.Guild.m_GuildName, taxPaid, tithePaid)
	end
	TaxPayer.DebugMsg(L"Leaving CommsReceived",4)
end

function TaxPayer.CommsParseEnglish()
	local isTaxes = false
	local commsGold   = 0
	local commsSilver = 0
	local commsBrass  = 0
	for k,a in ipairs(TaxPayer.contents) do
		if a == "taxes" then
			isTaxes = true
		elseif a == "gold" then
			commsGold = tonumber(TaxPayer.contents[k-1])
		elseif a == "silver" then
			commsSilver = tonumber(TaxPayer.contents[k-1])
		elseif a == "brass" then
			commsBrass = tonumber(TaxPayer.contents[k-1])
		end
	end
	return isTaxes, commsGold, commsSilver, commsBrass
end

function TaxPayer.CommsParseFrench()
	local isTaxes = false
	local commsGold   = 0
	local commsSilver = 0
	local commsBrass  = 0
	for k,a in ipairs(TaxPayer.contents) do 
		if a == "d�me" then 
			isTaxes = true 
		elseif a == "or" or a == "or." then 
			if TaxPayer.contents[k-2] == "pi�ces" then 
				commsGold = tonumber(TaxPayer.contents[k-3]) 
			else 
				commsGold = tonumber(TaxPayer.contents[k-2]) 
			end 
		elseif a == "argent" or a == "argent." then 
			if TaxPayer.contents[k-2] == "pi�ces" then 
				commsSilver = tonumber(TaxPayer.contents[k-3]) 
			else 
				commsSilver = tonumber(TaxPayer.contents[k-2]) 
			end 
		elseif a == "cuivre" or a == "cuivre." then 
			if TaxPayer.contents[k-2] == "pi�ces" then 
				commsBrass = tonumber(TaxPayer.contents[k-3]) 
			else 
				commsBrass = tonumber(TaxPayer.contents[k-2]) 
			end 
		end 
	end
	return isTaxes, commsGold, commsSilver, commsBrass
end

----------------------------------
---   Gui Specific Functions   ---
----------------------------------

function TaxPayer.Slash()
	TaxPayer.DebugMsg(L"Entering Slash",3)
	TaxPayer.ShowWindow()
	TaxPayer.DebugMsg(L"Leaving Slash",3)
end

function TaxPayer.WindowInit()
	TaxPayer.DebugMsg(L"Entering WindowInit",3)
	-- Create the window and then hide it.
	CreateWindow(TaxPayer.Window, true)
	WindowSetShowing(TaxPayer.Window,false)
	-- Apply text to the buttons so they are not blank.
	ButtonSetText(TaxPayer.Window.."SaveButton" , L"Save")
	ButtonSetText(TaxPayer.Window.."ResetButton", L"Reset All")
	ButtonSetText(TaxPayer.Window.."CloseButton", L"Close")
	-- Apply text to the labels so they are not blank.
	LabelSetText(TaxPayer.Window.."TitleBarText"      , L"TaxPayer v"..TaxPayer.Settings.Version)
	LabelSetText(TaxPayer.Window.."OptionsModLabel"   , L"Enable TaxPayer")
	LabelSetText(TaxPayer.Window.."OptionsGuildLabel" , L"Update Member Note")
	LabelSetText(TaxPayer.Window.."OptionsTypeLabel"  , L"Type:")
	LabelSetText(TaxPayer.Window.."OptionsPayerLabel" , L"Payer:")
	-- Apply text to the Sort Bar buttons
	ButtonSetText(TaxPayer.Window.."SortBarGuildButton" , L"Guild")
	ButtonSetText(TaxPayer.Window.."SortBarAmountButton", L"Amount")
	-- Populate Dropdown lists
	for k,a in ipairs(TaxPayer.AmountType) do
		ComboBoxAddMenuItem(TaxPayer.Window.."OptionsTypeComboBox",towstring(a.name))
	end
	for k,a in ipairs(TaxPayer.PayerType) do
		ComboBoxAddMenuItem(TaxPayer.Window.."OptionsPayerComboBox",towstring(a.name))
	end
	TaxPayer.DebugMsg(L"Leaving WindowInit",3)
end

function TaxPayer.ShowWindow()
	TaxPayer.DebugMsg(L"Entering ShowWindow",3)
	-- Set the gui elements to the latest values.
	-- Options section
	EnableModCheckToggle = TaxPayer.Settings.Enabled
	ButtonSetPressedFlag(TaxPayer.Window.."OptionsModCheckBox"  , EnableModCheckToggle)
	EnableGuildCheckToggle = TaxPayer.Settings.GuildNote
	ButtonSetPressedFlag(TaxPayer.Window.."OptionsGuildCheckBox", EnableGuildCheckToggle)
	ComboBoxSetSelectedMenuItem(TaxPayer.Window.."OptionsTypeComboBox" ,TaxPayer.Settings.AmountType)
	ComboBoxSetSelectedMenuItem(TaxPayer.Window.."OptionsPayerComboBox",TaxPayer.Settings.PayerType)
	-- Populate and sort the Listbox
	TaxPayer.ApplySortOrder()
	-- Show the window
	WindowSetShowing(TaxPayer.Window,true)
	TaxPayer.DebugMsg(L"Leaving ShowWindow",3)
end

function TaxPayer.CloseWindow(flags, mouseX, mouseY)
	TaxPayer.DebugMsg(L"Entering CloseWindow",3)
	-- When the button is clicked, hide the TaxPayer window.
	WindowSetShowing(TaxPayer.Window,false)
	TaxPayer.DebugMsg(L"Leaving CloseWindow",3)
end

function TaxPayer.SaveOptions(flags, mouseX, mouseY)
	TaxPayer.DebugMsg(L"Entering SaveOptions",3)
	TaxPayer.Settings.Enabled    = ButtonGetPressedFlag(TaxPayer.Window.."OptionsModCheckBox")
	TaxPayer.Settings.GuildNote  = ButtonGetPressedFlag(TaxPayer.Window.."OptionsGuildCheckBox")
	TaxPayer.Settings.AmountType = ComboBoxGetSelectedMenuItem(TaxPayer.Window.."OptionsTypeComboBox")
	TaxPayer.Settings.PayerType  = ComboBoxGetSelectedMenuItem(TaxPayer.Window.."OptionsPayerComboBox")

	if TaxPayer.Enabled ~= TaxPayer.Settings.Enabled then
		TaxPayer.Enabled = TaxPayer.Settings.Enabled
		if TaxPayer.Settings.Enabled then
			TaxPayer.RegisterEvents()
		else
			TaxPayer.UnregisterEvents()
		end
	end
	if TaxPayer.Settings.GuildNote then
		TaxPayer.UpdateGuildMemberNote()
	end
	TaxPayer.DebugMsg(L"Leaving SaveOptions",3)
end

function TaxPayer.EnableModCheckToggle(flags, mouseX, mouseY)
	TaxPayer.DebugMsg(L"Entering EnableModCheckToggle",3)
	EnableModCheckToggle = not EnableModCheckToggle
	ButtonSetPressedFlag(TaxPayer.Window.."OptionsModCheckBox",EnableModCheckToggle)
	TaxPayer.DebugMsg(L"Leaving EnableModCheckToggle",3)
end

function TaxPayer.EnableGuildCheckToggle(flags, mouseX, mouseY)
	TaxPayer.DebugMsg(L"Entering EnableGuildCheckToggle",3)
	EnableGuildCheckToggle = not EnableGuildCheckToggle
	ButtonSetPressedFlag(TaxPayer.Window.."OptionsGuildCheckBox",EnableGuildCheckToggle)
	TaxPayer.DebugMsg(L"Leaving EnableGuildCheckToggle",3)
end

function TaxPayer.PopulateAmountPaid()
	TaxPayer.DebugMsg(L"Entering PopulateAmountPaid",3)
	if( TaxPayerList.PopulatorIndices == nil ) then return end

	for k, a in ipairs( TaxPayerList.PopulatorIndices ) do
		local rowWindow = TaxPayer.Window.."ListRow"..k
		local details = TaxPayer.AmountPaid[a]
		if details then
			--TaxPayer.DebugMsg(L"PAP: Name["..towstring(details.name)..L"] Gold["..towstring(details.Gold)..L"] Silver["..towstring(details.Silver)..L"] Brass["..towstring(details.Brass)..L"]",2)
			-- Set background color
			local rowMod = math.mod( k, 2 )
			local color = DataUtils.GetAlternatingRowColor( rowMod )
			WindowSetTintColor(rowWindow.."Background", color.r, color.g, color.b )
			WindowSetAlpha(rowWindow.."Background", color.a )
			-- Color the own Guilds name red
--[[			if details.Guild == GameData.Guild.m_GuildName then
				LabelSetTextColor(rowWindow.."Guild",  DefaultColor.AbilityType.DAMAGING.r,  DefaultColor.AbilityType.DAMAGING.g,  DefaultColor.AbilityType.DAMAGING.b)
			else
				LabelSetTextColor(rowWindow.."Guild", 255, 255, 255)
			end
			-- Set text values
			LabelSetText(rowWindow.."Guild" , towstring(details.Guild ))
			LabelSetText(rowWindow.."Gold"  , towstring(details.Gold  ))
			LabelSetText(rowWindow.."Silver", towstring(details.Silver))
			LabelSetText(rowWindow.."Brass" , towstring(details.Brass ))
			-- Set images
--			DynamicImageSetTexture(rowWindow.."GoldIcon"  , TaxPayer.GoldIcon  , 0, 0)
--			DynamicImageSetTexture(rowWindow.."SilverIcon", TaxPayer.SilverIcon, 0, 0)
--			DynamicImageSetTexture(rowWindow.."BrassIcon" , TaxPayer.BrassIcon , 0, 0)
		--]]	
		end
	end
	TaxPayer.DebugMsg(L"Leaving PopulateAmountPaid",3)
end

function TaxPayer.RowClicked(flags, mouseX, mouseY)
	TaxPayer.DebugMsg(L"Entering RowClicked",3)
	-- Figure out which target was selected
	local window = SystemData.ActiveWindow.name
	local displayIndex = WindowGetId(window)
	TaxPayer.DebugMsg("RowClicked: displayIndex   ["..displayIndex.."]",2)
	if TaxPayerList.PopulatorIndices == nil then return end
	local dataIndex = TaxPayerList.PopulatorIndices[displayIndex]
	if dataIndex == nil then TaxPayer.DebugMsg("RowClicked: dataIndex   [nil]",2) return end
	TaxPayer.DebugMsg("RowClicked: dataIndex   ["..dataIndex.."]",2)
	local rowSelected = TaxPayer.AmountPaid[dataIndex]
	TaxPayer.DebugMsg(L"RowClicked: Guild ["..rowSelected.Guild..L"]",2)
	TaxPayer.DebugMsg( "RowClicked: Gold  ["..rowSelected.Gold..  "]",2)
	TaxPayer.DebugMsg( "RowClicked: Silver["..rowSelected.Silver.."]",2)
	TaxPayer.DebugMsg( "RowClicked: Brass ["..rowSelected.Brass.. "]",2)
	TaxPayer.SelectedGuild = rowSelected.Guild
	-- Build the context menu
	EA_Window_ContextMenu.CreateContextMenu(window, EA_Window_ContextMenu.BARMENU)
	EA_Window_ContextMenu.AddMenuItem(L"Reset Guild Count"   , TaxPayer.ResetGuildCount   , false, true, EA_Window_ContextMenu.BARMENU)
	EA_Window_ContextMenu.AddMenuItem(L"Announce in Chat"    , TaxPayer.Announce          , false, true, EA_Window_ContextMenu.BARMENU)
	EA_Window_ContextMenu.AddMenuItem(L"Announce to Guild"   , TaxPayer.AnnounceInGuild   , false, true, EA_Window_ContextMenu.BARMENU)
	EA_Window_ContextMenu.AddMenuItem(L"Announce to Alliance", TaxPayer.AnnounceInAlliance, false, true, EA_Window_ContextMenu.BARMENU)
	EA_Window_ContextMenu.AddMenuItem(L"Announce to Party"   , TaxPayer.AnnounceInParty   , false, true, EA_Window_ContextMenu.BARMENU)
	EA_Window_ContextMenu.AddMenuItem(L"Announce to Warband" , TaxPayer.AnnounceInWarband , false, true, EA_Window_ContextMenu.BARMENU)
	-- Display the context menu
	EA_Window_ContextMenu.Finalize(EA_Window_ContextMenu.BARMENU)
	TaxPayer.DebugMsg(L"Leaving RowClicked",3)
end

function TaxPayer.SortAmountPaid()
	TaxPayer.DebugMsg(L"Entering SortAmountPaid",3)
	TaxPayer.AmountPaidOrdered = {}
	for k, a in ipairs(TaxPayer.AmountPaid) do
		table.insert(TaxPayer.AmountPaidOrdered,k)
	end
	table.sort(TaxPayer.AmountPaidOrdered, TaxPayer.CompareDetails)
	ListBoxSetDisplayOrder(TaxPayer.Window.."List", TaxPayer.AmountPaidOrdered)
	TaxPayer.DebugMsg(L"Leaving SortAmountPaid",3)
end

function TaxPayer.CompareDetails(index1, index2)
	TaxPayer.DebugMsg(L"Entering CompareTargetDetails",3)
	-- Sort Types will be Guild (Up, Down), Amount (Up,Down)
	if index1 == nil then return false end
	if index2 == nil then return true  end
	local data1, data2
	if TaxPayer.Settings.OrderType == ORDER_BY_AMOUNT then
		data1 = TaxPayer.ConvertCurrencyToBrass(TaxPayer.AmountPaid[index1].Gold, TaxPayer.AmountPaid[index1].Silver, TaxPayer.AmountPaid[index1].Brass)
		data2 = TaxPayer.ConvertCurrencyToBrass(TaxPayer.AmountPaid[index2].Gold, TaxPayer.AmountPaid[index2].Silver, TaxPayer.AmountPaid[index2].Brass)
	else
		data1 = TaxPayer.AmountPaid[index1].Guild
		data2 = TaxPayer.AmountPaid[index2].Guild
	end
	if TaxPayer.Settings.OrderDirection == ORDER_DESC then
		compare = data1 > data2
	else
		compare = data1 < data2
	end
	TaxPayer.DebugMsg(L"Leaving CompareTargetDetails",3)
	return compare
end

function TaxPayer.ReSortList(flags, mouseX, mouseY)
	TaxPayer.DebugMsg(L"Entering ResortList",3)
   local buttonId = WindowGetId( SystemData.ActiveWindow.name )
	--Check if selected button pressed twice to flip the order
	if TaxPayer.Settings.OrderType == buttonId then
		if TaxPayer.Settings.OrderDirection == ORDER_DESC then
			TaxPayer.Settings.OrderDirection = ORDER_ASC
		else
			TaxPayer.Settings.OrderDirection = ORDER_DESC
		end
	else
		TaxPayer.Settings.OrderType = buttonId
		TaxPayer.Settings.OrderDirection = ORDER_ASC
	end
	TaxPayer.ApplySortOrder()
	TaxPayer.DebugMsg(L"Leaving ResortList",3)
end

function TaxPayer.ApplySortOrder()
	TaxPayer.DebugMsg(L"Entering ApplySortOrder",3)
	local windowName, sortDirection
	-- Hide all the arrows
	WindowSetShowing(TaxPayer.Window.."SortBarGuildButton".."UpArrow"   , false )
	WindowSetShowing(TaxPayer.Window.."SortBarGuildButton".."DownArrow" , false )
	WindowSetShowing(TaxPayer.Window.."SortBarAmountButton".."UpArrow"  , false )
	WindowSetShowing(TaxPayer.Window.."SortBarAmountButton".."DownArrow", false )
	-- Get Window name and direction
	if TaxPayer.Settings.OrderType == ORDER_BY_GUILD then
		windowName = TaxPayer.Window.."SortBarGuildButton"
	else
		windowName = TaxPayer.Window.."SortBarAmountButton"
	end
	if TaxPayer.Settings.OrderDirection == ORDER_DESC then
		sortDirection = "DownArrow"
	else
		sortDirection = "UpArrow"
	end
	-- Apply the sort order
	WindowSetShowing(windowName..sortDirection, true)
	TaxPayer.SortAmountPaid()
	TaxPayer.DebugMsg(L"Leaving ApplySortOrder",3)
end

function TaxPayer.MouseOverSortButton(flags, mouseX, mouseY)
	TaxPayer.DebugMsg(L"Entering MouseOverSortButton",3)
	local windowName = SystemData.ActiveWindow.name
	local buttonId   = WindowGetId (windowName)
	local message
	if buttonId == ORDER_BY_GUILD then
		message = L"Sort by Guild Name"
	else
		message = L"Sort by Amount paid"
	end
	Tooltips.CreateTextOnlyTooltip (windowName, nil)
	Tooltips.SetTooltipText (1, 1, message)
	Tooltips.SetTooltipColorDef (1, 1, Tooltips.COLOR_HEADING)
	Tooltips.Finalize ()
	Tooltips.AnchorTooltip(Tooltips.ANCHOR_WINDOW_TOP)
	Tooltips.SetTooltipAlpha (1)
	TaxPayer.DebugMsg(L"Leaving MouseOverSortButton",3)
end

function TaxPayer.UpdateSelection(flags, mouseX, mouseY)
	TaxPayer.DebugMsg(L"Entering UpdateSelection",3)
	TaxPayer.Settings.AmountType = ComboBoxGetSelectedMenuItem(TaxPayer.Window.."OptionsTypeComboBox")
	TaxPayer.Settings.PayerType  = ComboBoxGetSelectedMenuItem(TaxPayer.Window.."OptionsPayerComboBox")
	TaxPayer.UpdateLocalAmountPaid()
	TaxPayer.DebugMsg(L"Leaving UpdateSelection",3)
end

----------------------------------
---  Table Handling functions  ---
----------------------------------
function TaxPayer.GetGlobalEntry(guildName, payerName, serverID)
	TaxPayer.DebugMsg(L"Entering GetGlobalEntry",3)
	for k,a in pairs(TaxPayer.GlobalSettings.AmountPaid) do
		if a.guild == guildName and a.payer == payerName and a.server == serverID then
			TaxPayer.DebugMsg("GetGlobalEntry: Entry found",2)
			return k, a
		end
	end
	TaxPayer.DebugMsg("GetGlobalEntry: Entry Not found",2)
	TaxPayer.DebugMsg(L"Leaving GetGlobalEntry",3)
	return nil, nil
end

function TaxPayer.IncreaseAmountPaid(guildName, taxAmount, titheAmount)
	TaxPayer.DebugMsg(L"Entering IncreaseAmountPaid",3)
	TaxPayer.DebugMsg(L"IAP: Guild["..guildName..L"] TaxAmount["..taxAmount..L"] TitheAmount["..titheAmount..L"]",2)
	local totalTaxAmount   = taxAmount
	local totalTitheAmount = titheAmount
	local index, details = TaxPayer.GetGlobalEntry(guildName, GameData.Player.name, SystemData.Server.ID)
	if not index then
		index = #TaxPayer.GlobalSettings.AmountPaid + 1
		TaxPayer.DebugMsg(L"IAP: Adding new entry for GuildName["..guildName..L"], index["..index..L"]", 2)
	else
		totalTaxAmount   = totalTaxAmount   + details.amount[AMOUNT_TYPE_TAX]
		totalTitheAmount = totalTitheAmount + details.amount[AMOUNT_TYPE_TITHE]
	end
	TaxPayer.GlobalSettings.AmountPaid[index] =
		{ server = SystemData.Server.ID
		, payer  = GameData.Player.name
	    , guild  = guildName
		, amount = {[AMOUNT_TYPE_TAX] = totalTaxAmount, [AMOUNT_TYPE_TITHE] = totalTitheAmount}
        }
	TaxPayer.UpdateLocalAmountPaid()
	TaxPayer.UpdateGuildMemberNote()
	TaxPayer.DebugMsg(L"Leaving IncreaseAmountPaid",3)
end

function TaxPayer.ResetAllCounts(flags, mouseX, mouseY)
	TaxPayer.DebugMsg(L"Entering ResetAllCounts",3)
	TaxPayer.RemoveIndex = {}
	TaxPayer.RemoveIndexSorted = {}
	for k,a in ipairs(TaxPayer.GlobalSettings.AmountPaid) do
		-- Check if the entry is the entry matches our criteria
		if a.server == SystemData.Server.ID and (TaxPayer.Settings.PayerType == PAYER_TYPE_ALL or a.payer == GameData.Player.name) then
			table.insert(TaxPayer.RemoveIndex,k)
			table.insert(TaxPayer.RemoveIndexSorted,#TaxPayer.RemoveIndex)
		end
	end
	table.sort(TaxPayer.RemoveIndexSorted, TaxPayer.ReverseDetails)
	for g,e in ipairs(TaxPayer.RemoveIndexSorted) do
		table.remove(TaxPayer.GlobalSettings.AmountPaid, TaxPayer.RemoveIndex[e])
	end
	TaxPayer.UpdateLocalAmountPaid()
	TaxPayer.UpdateGuildMemberNote()
	TaxPayer.DebugMsg(L"Leaving ResetAllCounts",3)
end

function TaxPayer.ResetGuildCount()
	TaxPayer.DebugMsg(L"Entering ResetGuildCount",3)
	TaxPayer.RemoveIndex = {}
	TaxPayer.RemoveIndexSorted = {}
	if TaxPayer.SelectedGuild == "" then TaxPayer.DebugMsg(L"ResetGuildCount: Blank value for TaxPayer.SelectedGuild",1) return end
	for k,a in pairs(TaxPayer.GlobalSettings.AmountPaid) do
		-- Check if the entry is the entry matches our criteria
		if a.server == SystemData.Server.ID and (TaxPayer.Settings.PayerType == PAYER_TYPE_ALL or a.payer == GameData.Player.name) and a.guild == TaxPayer.SelectedGuild then
			table.insert(TaxPayer.RemoveIndex,k)
			table.insert(TaxPayer.RemoveIndexSorted,#TaxPayer.RemoveIndex)
		end
	end
	table.sort(TaxPayer.RemoveIndexSorted, TaxPayer.ReverseDetails)
	for g,e in pairs(TaxPayer.RemoveIndexSorted) do
		table.remove(TaxPayer.GlobalSettings.AmountPaid,TaxPayer.RemoveIndex[e])
	end
	TaxPayer.UpdateLocalAmountPaid()
	if TaxPayer.SelectedGuild == GameData.Guild.m_GuildName then
		TaxPayer.UpdateGuildMemberNote()
	end
	TaxPayer.SelectedTarget = ""
	TaxPayer.DebugMsg(L"Leaving ResetGuildCount",3)
end

function TaxPayer.UpdateLocalAmountPaid()
	TaxPayer.DebugMsg(L"Entering UpdateLocalAmountPaid",3)
	TaxPayer.AmountPaid = {}
	local guildNameIndex = {}
	for k,a in pairs(TaxPayer.GlobalSettings.AmountPaid) do
		-- Check if the entry is the entry matches our criteria
		if a.server == SystemData.Server.ID and (TaxPayer.Settings.PayerType == PAYER_TYPE_ALL or a.payer == GameData.Player.name) then
			local details = {Guild = a.guild, Gold = 0, Silver = 0, Brass = 0}
			local amount = 0
			if TaxPayer.Settings.AmountType == AMOUNT_TYPE_TAX_AND_TITHE then
				amount = a.amount[AMOUNT_TYPE_TAX] + a.amount[AMOUNT_TYPE_TITHE]
			else
				amount = a.amount[TaxPayer.Settings.AmountType]
			end
			if guildNameIndex[a.guild] then
				amount = amount + TaxPayer.ConvertCurrencyToBrass( TaxPayer.AmountPaid[guildNameIndex[a.guild]].Gold
				                                                 , TaxPayer.AmountPaid[guildNameIndex[a.guild]].Silver
				                                                 , TaxPayer.AmountPaid[guildNameIndex[a.guild]].Brass
																 )
			else
				guildNameIndex[a.guild] = #TaxPayer.AmountPaid + 1
			end
			details.Gold, details.Silver, details.Brass = TaxPayer.ConvertBrassToCurrency(amount)
			TaxPayer.AmountPaid[guildNameIndex[a.guild]] = details
		end
	end
	TaxPayer.ApplySortOrder()
	TaxPayer.DebugMsg(L"Leaving UpdateLocalAmountPaid",3)
end

function TaxPayer.GetLocalAmountPaid(guildName)
	TaxPayer.DebugMsg(L"Entering GetLocalAmountPaid",3)
	for k,a in pairs(TaxPayer.AmountPaid) do
		if a.Guild == guildName then
			return a.Gold, a.Silver, a.Brass
		end
	end
	TaxPayer.DebugMsg(L"Leaving GetLocalAmountPaid",3)
	return 0,0,0
end

function TaxPayer.ReverseDetails(index1, index2)
	TaxPayer.DebugMsg(L"Entering ReverseDetails",3)
	if index1 == nil then return true  end
	if index2 == nil then return false end
	local data1 = TaxPayer.RemoveIndex[index1]
	local data2 = TaxPayer.RemoveIndex[index2]
	if data1 == nil then return true  end
	if data2 == nil then return false end
	TaxPayer.DebugMsg(L"Leaving ReverseDetails",3)
	return data1 > data2
end
