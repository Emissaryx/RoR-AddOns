<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
	<UiMod name="TaxPayer" version="1.2" date="18/08/2010" >
		<Author name="Medikage" email="medikage@gmail.com" />
		<Description text="Keeps a track of how much taxes and tithes you have paid to each guild." />
		<VersionSettings gameVersion="1.4" windowsVersion="1.0" savedVariablesVersion="1.0"/>
		<Dependencies>
			<Dependency name="LibSlash" />
		</Dependencies>
		<Files>
			<File name="TaxPayer.xml" />
		</Files>
		<SavedVariables>
			<SavedVariable name="TaxPayer.Settings" />
			<SavedVariable name="TaxPayer.GlobalSettings" global="true" />
		</SavedVariables>
		<OnInitialize>
			<CallFunction name="TaxPayer.Initialise" />
		</OnInitialize>
		<OnUpdate/>
		<OnShutdown/>
	</UiMod>
</ModuleFile>