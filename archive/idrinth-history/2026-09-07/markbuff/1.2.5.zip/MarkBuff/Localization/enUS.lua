if (not MBuffLocalization) then
	MBuffLocalization = {};
	MBuffLocalization.Language = {};
end

MBuffLocalization.Language[SystemData.Settings.Language.ENGLISH] = 
{
	["CareerType.Caster"] = L"Caster",
	["CareerType.DPS"] = L"DPS",
	["CareerType.Healer"] = L"Healer",
	["CareerType.Melee"] = L"Melee",
	["CareerType.Ranged"] = L"Ranged",
	["CareerType.Tank"] = L"Tank",
	InitializedMessage = L"%s initialized.",
	["Labels.EmptyGroupMember"] = L"Empty",
	["Labels.ManualBuffSelection"] = L"Manually select group buffs",
	["Setup.SmartBuff"] = L"SmartBuff Settings",
	["Setup.SmartBuff.Auras"] = L"If auras are available",
	["Setup.SmartBuff.BuffPriority"] = L"Buff Priority",
	["Setup.SmartBuff.BuffPriority.Info"] = L"Each buff will be tried in order. If the first cannot be used, then the next will be tried.",
	["Setup.SmartBuff.CareerType"] = L"Career type",
	["Setup.SmartBuff.Other"] = L"Default",
	["Setup.SmartBuff.Resists"] = L"If the resist group buff is available",
	["SmartBuff.Auras"] = L"Auras",
	["SmartBuff.Auras.Resists"] = L"(Resists)",
	["SmartBuff.Auras.Strength"] = L"(Strength)",
	["SmartBuff.Override"] = L"Override",
	["SmartBuff.RememberAs"] = L"Remember as a %s",
	["SmartBuff.RememberAs.Reset"] = L"Reset",
};

