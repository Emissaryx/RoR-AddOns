if (not MBuffLocalization) then
	MBuffLocalization = {};
	MBuffLocalization.Language = {};
end

MBuffLocalization.Language[SystemData.Settings.Language.FRENCH] = 
{
	["CareerType.Caster"] = L"Magie", -- Needs review
	["CareerType.DPS"] = L"DPS", -- Needs review
	["CareerType.Healer"] = L"Gu�risseur", -- Needs review
	["CareerType.Melee"] = L"M�l�e", -- Needs review
	["CareerType.Ranged"] = L"� distance", -- Needs review
	["CareerType.Tank"] = L"Tank", -- Needs review
	InitializedMessage = L"%s initialis�.", -- Needs review
	["Labels.EmptyGroupMember"] = L"Vide", -- Needs review
	["Labels.ManualBuffSelection"] = L"S�lection manuelle", -- Needs review
	["Setup.SmartBuff"] = L"SmartBuff Param�tres", -- Needs review
	["Setup.SmartBuff.Auras"] = L"Si auras sont disponibles", -- Needs review
	["Setup.SmartBuff.BuffPriority"] = L"Buff priorit�", -- Needs review
	["Setup.SmartBuff.BuffPriority.Info"] = L"Chaque buff seront jug�s dans l'ordre. Si le premier ne peut pas �tre utilis�, alors le prochain sera jug�.", -- Needs review
	["Setup.SmartBuff.CareerType"] = L"Type de carri�re", -- Needs review
	["Setup.SmartBuff.Other"] = L"Par d�faut", -- Needs review
	["Setup.SmartBuff.Resists"] = L"Si l'am�lioration de r�sistance du groupe est disponible", -- Needs review
	["SmartBuff.Auras"] = L"Auras", -- Needs review
	["SmartBuff.Auras.Resists"] = L"(R�siste)", -- Needs review
	["SmartBuff.Auras.Strength"] = L"(Strength)", -- Needs review
	["SmartBuff.Override"] = L"Outrepasser", -- Needs review
	["SmartBuff.RememberAs"] = L"Rappelez-vous comme un %s", -- Needs review
	["SmartBuff.RememberAs.Reset"] = L"R�initialiser", -- Needs review
};

