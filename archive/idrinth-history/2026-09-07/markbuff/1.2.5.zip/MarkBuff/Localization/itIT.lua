if (not MBuffLocalization) then
	MBuffLocalization = {};
	MBuffLocalization.Language = {};
end

MBuffLocalization.Language[SystemData.Settings.Language.ITALIAN] = 
{
	["CareerType.Caster"] = L"Caster", -- Needs review
	["CareerType.DPS"] = L"Danni rivenditore", -- Needs review
	["CareerType.Healer"] = L"Guaritore", -- Needs review
	["CareerType.Melee"] = L"Mischia", -- Needs review
	["CareerType.Ranged"] = L"Ranged", -- Needs review
	["CareerType.Tank"] = L"Difensore", -- Needs review
	InitializedMessage = L"%s inizializzato.", -- Needs review
	["Labels.EmptyGroupMember"] = L"Vuoto", -- Needs review
	["Labels.ManualBuffSelection"] = L"Selezione manuale", -- Needs review
	["Setup.SmartBuff"] = L"SmartBuff Impostazioni", -- Needs review
	["Setup.SmartBuff.Auras"] = L"Se aure sono disponibili", -- Needs review
	["Setup.SmartBuff.BuffPriority"] = L"Buff Priorit�", -- Needs review
	["Setup.SmartBuff.BuffPriority.Info"] = L"Ogni buff saranno processati in ordine. Se il primo non pu� essere utilizzato, quindi il prossimo saranno processati.", -- Needs review
	["Setup.SmartBuff.CareerType"] = L"Carriera tipo", -- Needs review
	["Setup.SmartBuff.Other"] = L"Altro", -- Needs review
	["Setup.SmartBuff.Resists"] = L"Se il buff resistere gruppo � disponibile", -- Needs review
	["SmartBuff.Auras"] = L"Aure", -- Needs review
	["SmartBuff.Auras.Resists"] = L"(Resiste)", -- Needs review
	["SmartBuff.Auras.Strength"] = L"(La Forza)", -- Needs review
	["SmartBuff.Override"] = L"Override", -- Needs review
	["SmartBuff.RememberAs"] = L"%s", -- Needs review
	["SmartBuff.RememberAs.Reset"] = L"Ripristinare", -- Needs review
};

