if (not MBuffLocalization) then
	MBuffLocalization = {};
	MBuffLocalization.Language = {};
end

MBuffLocalization.Language[SystemData.Settings.Language.GERMAN] = 
{
	["CareerType.Caster"] = L"Magie", -- Needs review
	["CareerType.DPS"] = L"DPS", -- Needs review
	["CareerType.Healer"] = L"Heiler", -- Needs review
	["CareerType.Melee"] = L"Handgemenge", -- Needs review
	["CareerType.Ranged"] = L"Fernkampf", -- Needs review
	["CareerType.Tank"] = L"Tank", -- Needs review
	InitializedMessage = L"%s initialisiert.",
	["Labels.EmptyGroupMember"] = L"Leer",
	["Labels.ManualBuffSelection"] = L"Manuelle Auswahl der Buffs",
	["Setup.SmartBuff"] = L"SmartBuff Einstellungen", -- Needs review
	["Setup.SmartBuff.Auras"] = L"Wenn Auren sind verf�gbar", -- Needs review
	["Setup.SmartBuff.BuffPriority"] = L"Buff Priorit�t", -- Needs review
	["Setup.SmartBuff.BuffPriority.Info"] = L"Jeder St�rkungszauber wird damit versucht werden. Wenn die erste kann nicht verwendet werden, dann wird die n�chste versucht werden.", -- Needs review
	["Setup.SmartBuff.CareerType"] = L"Karriere-Typ", -- Needs review
	["Setup.SmartBuff.Other"] = L"Default", -- Needs review
	["Setup.SmartBuff.Resists"] = L"Wenn die Gruppe widerstehen buff ist verf�gbar", -- Needs review
	["SmartBuff.Auras"] = L"Auras", -- Needs review
	["SmartBuff.Auras.Resists"] = L"(Resists)", -- Needs review
	["SmartBuff.Auras.Strength"] = L"(Strength)", -- Needs review
	["SmartBuff.Override"] = L"Override", -- Needs review
	["SmartBuff.RememberAs"] = L"Angemeldet als %s", -- Needs review
	["SmartBuff.RememberAs.Reset"] = L"Neu setzen",
};

