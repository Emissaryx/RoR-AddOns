if (not MBuffLocalization) then
	MBuffLocalization = {};
	MBuffLocalization.Language = {};
end

MBuffLocalization.Language[SystemData.Settings.Language.SPANISH] = 
{
	["CareerType.Caster"] = L"Caster", -- Needs review
	["CareerType.DPS"] = L"DPS", -- Needs review
	["CareerType.Healer"] = L"Curador", -- Needs review
	["CareerType.Melee"] = L"Cuerpo a cuerpo", -- Needs review
	["CareerType.Ranged"] = L"A distancia", -- Needs review
	["CareerType.Tank"] = L"Tank", -- Needs review
	InitializedMessage = L"%s inicializado.", -- Needs review
	["Labels.EmptyGroupMember"] = L"Vac�o", -- Needs review
	["Labels.ManualBuffSelection"] = L"Selecci�n manual", -- Needs review
	["Setup.SmartBuff"] = L"Ajustes SmartBuff", -- Needs review
	["Setup.SmartBuff.Auras"] = L"Si se dispone de auras", -- Needs review
	["Setup.SmartBuff.BuffPriority"] = L"Buff prioridad", -- Needs review
	["Setup.SmartBuff.BuffPriority.Info"] = L"Cada aficionado ser� juzgado en orden. Si el primero no puede ser utilizado, luego el siguiente ser� juzgado.", -- Needs review
	["Setup.SmartBuff.CareerType"] = L"Formaci�n tipo", -- Needs review
	["Setup.SmartBuff.Other"] = L"Otro", -- Needs review
	["Setup.SmartBuff.Resists"] = L"Si la piel de ante resistir grupo est� disponible", -- Needs review
	["SmartBuff.Auras"] = L"Auras",
	["SmartBuff.Auras.Resists"] = L"(Resiste)", -- Needs review
	["SmartBuff.Auras.Strength"] = L"(Fuerza)", -- Needs review
	["SmartBuff.Override"] = L"Anular", -- Needs review
	["SmartBuff.RememberAs"] = L"Recuerde que un %s", -- Needs review
	["SmartBuff.RememberAs.Reset"] = L"Restablecer", -- Needs review
};
