if (not MBuffLocalization) then
	MBuffLocalization = {};
	MBuffLocalization.Language = {};
end

local localizationWarning = false;

function MBuffLocalization.GetMapping()

	local lang = MBuffLocalization.Language[SystemData.Settings.Language.active];
	
	if (not lang) then
		if (not localizationWarning) then
			d("Your current language is not supported. English will be used instead.");
			localizationWarning = true;
		end
		lang = MBuffLocalization.Language[SystemData.Settings.Language.ENGLISH];
	end
	
	return lang;
	
end