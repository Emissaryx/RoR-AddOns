<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
	<UiMod name="MarkBuff" version="1.2.5" date="10/11/2010">
		<Author name="Healix" email="" />
		<Description text="Manages Zealot/Runepriest buffs for the group." />
		<VersionSettings gameVersion="1.3.6" windowsVersion="1.0" savedVariablesVersion="1.0" />
	
		<Dependencies>			
			<Dependency name="EASystem_LayoutEditor" />
			<Dependency name="LibGroup" />
		</Dependencies>

		<Files>
			<File name="Localization.lua" />
			<File name="Localization/enUS.lua" />
			<File name="Localization/frFR.lua" />
			<File name="Localization/deDE.lua" />
			<File name="Localization/itIT.lua" />
			<File name="Localization/esES.lua" />
			<File name="Setup/SetupSmartBuff.lua" />
			<File name="Setup/SetupSmartBuff.xml" />
			<File name="Gui.lua" />
			<File name="Gui.xml" />
			<File name="Core.lua" />
		</Files>
		
		<SavedVariables>
			<SavedVariable name="MBuff.Settings" />
		</SavedVariables>
		
		<OnInitialize>
			<CreateWindow name="MarkBuffBar" show="false" />
			<CreateWindow name="MarkBuffBarTarget" show="false" />
			<CreateWindow name="MarkBuffSetupSmartBuffWindow" show="false" />
			<CreateWindow name="MarkBuffSetupWindow" show="false" />
			<CallFunction name="MBuff.Initialize" />
		</OnInitialize>
		<OnUpdate>
			<CallFunction name="MBuff.OnUpdate" />
		</OnUpdate>
		<OnShutdown/>
		<WARInfo>
			<Categories>
				<Category name="OTHER" />
			</Categories>
			<Careers>
				<Career name="RUNE_PRIEST" />
				<Career name="ZEALOT" />
				<Career name="ARCHMAGE" />
				<Career name="SHAMAN" />
			</Careers>
		</WARInfo>
	</UiMod>
</ModuleFile>
