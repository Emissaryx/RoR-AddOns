if (not MBuffSetup) then MBuffSetup = {} end
MBuffSetup.SmartBuff = {};
MBuffSetup.SmartBuff.WindowName = "MarkBuffSetupSmartBuffWindow";

local windowName = MBuffSetup.SmartBuff.WindowName;
local localization = MBuffLocalization.GetMapping();

local activeSmartBuff = {};
local abilityIdToIconNum = 
{
	--destro
	--zealot
	[8551] = 5140,
	[8556] = 5136,
	[8560] = 5137,
	[8567] = 5239,
	--shaman
	[1910] = 2472,
	
	--order
	--runepriest
	[1591] = 4562,
	[1600] = 4634,
	[1588] = 4626,
	[1608] = 4554,
	--archmage
	[9248] = 13352
};
local abilityIdToIndex = {};
local indexToAbilityId = {};

local function LoadBuffs()

	for index, abilityId in pairs(activeSmartBuff) do
		MBuffSetup.SmartBuff.SetBuffIcon(windowName .. "OtherBuffIcon" .. tostring(index), abilityId);
	end

end

function MBuffSetup.SmartBuff.Initialize()

	indexToAbilityId = { MBuff.BuffNames.StrengthBuff, MBuff.BuffNames.WillpowerBuff, MBuff.BuffNames.ResistBuff };
	local index = 1;
	for _, abilityId in ipairs(indexToAbilityId) do
		if (abilityId) then
			abilityIdToIndex[abilityId] = index;
			index = index + 1;
		end
	end

	LabelSetText(windowName .. "TitleLabel", localization["Setup.SmartBuff"]);
	LabelSetText(windowName .. "CareerTypeLabel", localization["Setup.SmartBuff.CareerType"]);
	
	ComboBoxClearMenuItems(windowName .. "ClassTypeList");
	ComboBoxAddMenuItem(windowName .. "ClassTypeList", localization["CareerType.Melee"]);
	ComboBoxAddMenuItem(windowName .. "ClassTypeList", localization["CareerType.Ranged"]);
	ComboBoxAddMenuItem(windowName .. "ClassTypeList", localization["CareerType.Caster"]);
	ComboBoxAddMenuItem(windowName .. "ClassTypeList", localization["CareerType.Healer"]);
	ComboBoxAddMenuItem(windowName .. "ClassTypeList", localization["CareerType.Tank"]);
	
	LabelSetText(windowName .. "BuffPriorityLabel", localization["Setup.SmartBuff.BuffPriority"]);
	LabelSetText(windowName .. "BuffPriorityDescriptionLabel", localization["Setup.SmartBuff.BuffPriority.Info"]);
	LabelSetText(windowName .. "OtherLabel", localization["Setup.SmartBuff.Other"]);
	
	ComboBoxSetSelectedMenuItem(windowName .. "ClassTypeList", MBuff.CareerType.Melee);
	MBuffSetup.SmartBuff.OnClassTypeChanged();
	
end

function MBuffSetup.SmartBuff.Show()

	if (WindowGetShowing(windowName)) then return end
	
	WindowSetShowing(windowName, true);
	
	WindowUtils.AddToOpenList(windowName, MBuffSetup.SmartBuff.OnCloseLUp, WindowUtils.Cascade.MODE_NONE);
	
	Sound.Play(Sound.WINDOW_OPEN);

end

function MBuffSetup.SmartBuff.Hide()

	if (not WindowGetShowing(windowName)) then return end
	
	WindowSetShowing(windowName, false);
	
	Sound.Play(Sound.WINDOW_CLOSE);
	
	WindowUtils.RemoveFromOpenList(windowName);

end

function MBuffSetup.SmartBuff.OnCloseLUp()

	MBuffSetup.SmartBuff.Hide();

end

function MBuffSetup.SmartBuff.OnClassTypeChanged()

	local value = ComboBoxGetSelectedMenuItem(windowName .. "ClassTypeList");
	
	activeSmartBuff = MBuff.Settings.SmartBuff[GameData.Player.career.line][value];
	LoadBuffs();

end

function MBuffSetup.SmartBuff.SetBuffIcon(buffIcon, abilityId)
	
	WindowSetTintColor(buffIcon, 255, 255, 255);
	WindowSetAlpha(buffIcon, 1);	
	
	local iconNum = 0;
	local width, height = 65, 65;
	
	if (abilityId) then
		iconNum = abilityIdToIconNum[abilityId];
	end
	
	if (not abilityId or not iconNum) then
		iconNum = 40;
		width, height = 30, 30;
	end
	
	local tex, texX, texY = GetIconData(iconNum);
	DynamicImageSetTexture(buffIcon, tex, texX, texY)
	DynamicImageSetTextureScale(buffIcon, 1);
	DynamicImageSetTextureDimensions(buffIcon, width, height);

end

local function GetNextBuff(abilityId)

	local index = 1;
	
	if (abilityId) then
		local temp = (abilityIdToIndex[abilityId] or 0) + 1;
		if (indexToAbilityId[temp]) then
			index = temp;
		end
	end
	
	return indexToAbilityId[index];

end

local function GetPreviousBuff(abilityId)

	local index = #indexToAbilityId;
	
	if (abilityId) then
		local temp = (abilityIdToIndex[abilityId] or 0) - 1;
		if (indexToAbilityId[temp]) then
			index = temp;
		end
	end
	
	return indexToAbilityId[index];

end

function MBuffSetup.SmartBuff.OnOtherLClick()
	
	local id = WindowGetId(SystemData.ActiveWindow.name);
	local abilityId = GetNextBuff(activeSmartBuff[id]);
	
	MBuffSetup.SmartBuff.SetBuffIcon(SystemData.ActiveWindow.name, abilityId);
	activeSmartBuff[id] = abilityId;
	MBuff.BuffsChanged();
	
end

function MBuffSetup.SmartBuff.OnOtherRClick()
	
	local id = WindowGetId(SystemData.ActiveWindow.name);
	local abilityId = GetPreviousBuff(activeSmartBuff[id]);
	
	MBuffSetup.SmartBuff.SetBuffIcon(SystemData.ActiveWindow.name, abilityId);
	activeSmartBuff[id] = abilityId;
	MBuff.BuffsChanged();
	
end
