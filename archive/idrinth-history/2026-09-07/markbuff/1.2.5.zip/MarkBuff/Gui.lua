MBuffGui = {};
MBuffGui.Elements = {};
MBuffGui.Elements.Labels = {};
MBuffGui.Elements.Checkboxes = {};
MBuffGui.Elements.Windows = {};
MBuffGui.Elements.Images = {};

MBuffGui.Elements.Windows.BuffBar = "MarkBuffBar";
MBuffGui.Elements.Windows.BuffBarTarget = "MarkBuffBarTarget";
MBuffGui.Elements.Windows.BuffSetup = "MarkBuffSetupWindow";
MBuffGui.Elements.Images.SpellIcon = MBuffGui.Elements.Windows.BuffBar .. "SpellIcon";
MBuffGui.Elements.Images.TargetCareerIcon = MBuffGui.Elements.Windows.BuffBarTarget .. "CareerIcon";
MBuffGui.Elements.Images.CareerIcon = {};
MBuffGui.Elements.Images.BuffIcon = {};
MBuffGui.Elements.Images.GroupIcon = {};
MBuffGui.Elements.Images.GroupType = {};
MBuffGui.Elements.Images.GroupBuffIcon = {};
MBuffGui.Elements.Checkboxes.ManualSelect = MBuffGui.Elements.Windows.BuffSetup .. "ManualSelect";
MBuffGui.Elements.Labels.ManualSelect = MBuffGui.Elements.Windows.BuffSetup .. "ManualSelectLabel";
MBuffGui.Elements.Labels.UnbuffedCount = MBuffGui.Elements.Windows.BuffBar .. "UnbuffedCount";
MBuffGui.Elements.Labels.TimeRemaining = MBuffGui.Elements.Windows.BuffBar .. "TimeRemaining";
MBuffGui.Elements.Labels.TargetPlayerName = MBuffGui.Elements.Windows.BuffBarTarget .. "PlayerName";
MBuffGui.Elements.Labels.Group = {};
MBuffGui.Elements.Labels.Icons = {};
MBuffGui.Elements.ContextMenu = {};
MBuffGui.Elements.ContextMenu.StrengthAura = MBuffGui.Elements.Windows.BuffSetup .. "ContextAurasStrength";
MBuffGui.Elements.ContextMenu.ResistsAura = MBuffGui.Elements.Windows.BuffSetup .. "ContextAurasResists";
MBuffGui.Elements.ContextMenu.Override = {};

local MAX_GROUP_MEMBERS = 6;

local BUFF_DISTANCE = 110;

local SORT_INDEX = "index";
local SORT_SLOT = "slot";
local groupTypeImages = { Tank = "MarkBuff_Icon_Tank", DPS = "MarkBuff_Icon_DPS", Healer = "MarkBuff_Icon_Healer" };

local mouseOverLayers = 0;
local unbuffedValue = L"";
local timerValue = L"";
local spellIconValue = 0;
local buffTargetEmpty = false;
local activeContextGroupMember = nil;
local contextIdToAbility = {};
local contextCreated = false;

local localization = MBuffLocalization.GetMapping();

MBuffGui.CareerIndex = {};

local function print(text)

	EA_ChatWindow.Print(towstring(tostring(text)), ChatSettings.Channels[SystemData.ChatLogFilters.SAY].id);

end

local function GetGroupMemberIndex(groupMember)

	if (MBuff.SortGroupBy == SORT_INDEX) then
		return groupMember.Index;
	elseif (MBuff.SortGroupBy == SORT_SLOT) then
		return groupMember.Slot;
	end
	
end

local function GetGroupMembers()

	if (MBuff.SortGroupBy == SORT_INDEX) then
		return LibGroup.GroupMembers.ByIndex;
	elseif (MBuff.SortGroupBy == SORT_SLOT) then
		return LibGroup.GroupMembers.BySlot;
	end
	
	return {};
	
end

function MBuffGui.Initialize()
	
	LayoutEditor.RegisterWindow(MBuffGui.Elements.Windows.BuffBar, towstring(MBuff.Name), MBuff.Name, false, false, true, nil);

	MBuffGui.SetupGui();

	LabelSetText(MBuffGui.Elements.Labels.ManualSelect, localization["Labels.ManualBuffSelection"]);
	ButtonSetPressedFlag(MBuffGui.Elements.Checkboxes.ManualSelect .. "Button", (not MBuff.Settings.AutoSelectBuffs));

	WindowSetAlpha(MBuffGui.Elements.Windows.BuffBar .. "Background", 0.8);
	WindowSetAlpha(MBuffGui.Elements.Windows.BuffBarTarget .. "Background", 0.8);
	
end

function MBuffGui.SetupGui()

	MBuffGui.CreateContext();
	MBuffGui.SetupCareerIcons();
	MBuffGui.SetupGroup();
	MBuffGui.SetupMembers();

end

function MBuffGui.SetupGroup()

	for index = 1, MAX_GROUP_MEMBERS
	do
	
		MBuffGui.Elements.Labels.Group[index] = MBuffGui.Elements.Windows.BuffSetup .. "GroupLabel" .. tostring(index);
		MBuffGui.Elements.Images.GroupIcon[index] = MBuffGui.Elements.Windows.BuffSetup .. "GroupCareer" .. tostring(index) .. "Icon";
		MBuffGui.Elements.Images.GroupType[index] = MBuffGui.Elements.Windows.BuffSetup .. "GroupCareer" .. tostring(index) .. "TypeIcon";
		MBuffGui.Elements.Images.GroupBuffIcon[index] = MBuffGui.Elements.Windows.BuffSetup .. "GroupBuff" .. tostring(index) .. "Icon";
		MBuffGui.Elements.Labels.Icons[index] = MBuffGui.Elements.Windows.BuffSetup .. "GroupBuff" .. tostring(index) .. "Label";
	
	end

end

function MBuffGui.SetupMembers()

	local groupMembers = GetGroupMembers();

	for index = 1, MAX_GROUP_MEMBERS
	do
	
		local groupMember = groupMembers[index];
		local careerIcon = MBuffGui.Elements.Images.GroupIcon[index];
		local nameLabel = MBuffGui.Elements.Labels.Group[index];
		local isValid = ((groupMember and groupMember.IsValid) == true);
		
		WindowSetShowing(careerIcon, isValid);
		
		local buffId = MBuff.ExpectedBuff(groupMember, true);
		local buffIcon = MBuffGui.Elements.Images.GroupBuffIcon[index];
		
		if (not MBuff.Settings.AutoSelectBuffs) then
			buffId = MBuff.BuffsByGroup[index].BuffId;
		end
		
		MBuffGui.SetGroupBuffIcon(index, buffIcon, buffId);
		
		if (isValid) then
			
			LabelSetText(nameLabel, groupMember.Name);
			
			local tex, texX, texY = GetIconData(Icons.GetCareerIconIDFromCareerLine(groupMember.CareerLine));
			DynamicImageSetTexture(careerIcon, tex, texX, texY)
			DynamicImageSetTextureScale(careerIcon, 1);
			DynamicImageSetTextureDimensions(careerIcon, 32, 32);
			
			if (MBuff.Settings.AutoSelectBuffs) then
			
				MBuffGui.SetBuffsByGroup(index, buffId);
			
			end
			
		else
		
			LabelSetText(nameLabel, localization["Labels.EmptyGroupMember"]);
			
		end
		
		MBuffGui.SetGroupTypeImage(index);
		
	end

end

function MBuffGui.SetBuffsByGroup(index, buffId)

	local buff = MBuff.Buffs[buffId];
	
	MBuff.BuffsByGroup[index].BuffId = buffId;
	
	MBuff.Settings.BuffsByGroup[GameData.Player.career.line][index] = {};
	if (buff) then
		if (buff.Type == MBuff.BuffType.Normal) then
			MBuff.Settings.BuffsByGroup[GameData.Player.career.line][index].AbilityId = MBuff.GetAbilityFromBuffId(buffId);
		end
		MBuff.Settings.BuffsByGroup[GameData.Player.career.line][index].Type = buff.Type;
	end
				
end

function MBuffGui.SetupCareerIcons()

	for careerLine,career in pairs(MBuff.BuffsByCareer) do
	
		MBuffGui.Elements.Images.CareerIcon[career.Index] = MBuffGui.Elements.Windows.BuffSetup .. "CareerIcon" .. tostring(career.Index);
		local careerIcon = MBuffGui.Elements.Images.CareerIcon[career.Index];
		
		MBuffGui.CareerIndex[career.Index] = career.CareerLine;
		
		local tex, texX, texY = GetIconData(Icons.GetCareerIconIDFromCareerLine(career.CareerLine));
		DynamicImageSetTexture(careerIcon, tex, texX, texY)
		DynamicImageSetTextureScale(careerIcon, 1);
		DynamicImageSetTextureDimensions(careerIcon, 32, 32);
		
		MBuffGui.Elements.Images.BuffIcon[career.Index] = MBuffGui.Elements.Windows.BuffSetup .. "CareerBuffIcon" .. tostring(career.Index);
		local buffIcon = MBuffGui.Elements.Images.BuffIcon[career.Index];
		
		MBuffGui.SetBuffIcon(buffIcon, career.BuffId);
	
	end

end

function MBuffGui.SetGroupBuffIcon(id, buffIcon, buffId)

	local buff = MBuff.Buffs[buffId];

	if (buff and buff.Type == MBuff.BuffType.AutoSelect) then
		LabelSetText(MBuffGui.Elements.Labels.Icons[id], L"Auto");
	elseif (buff and buff.Type == MBuff.BuffType.SmartBuff) then
		LabelSetText(MBuffGui.Elements.Labels.Icons[id], L"SB");
	else
		LabelSetText(MBuffGui.Elements.Labels.Icons[id], L"");
	end
	
	MBuffGui.SetBuffIcon(buffIcon, buffId);

end

function MBuffGui.SetBuffIcon(buffIcon, buffId)
	
	WindowSetTintColor(buffIcon, 255, 255, 255);
	WindowSetAlpha(buffIcon, 1);	
	
	local iconNum = 0;
	local width, height = 65, 65;
	
	if (not buffId) then
		iconNum = 40;
		width, height = 30, 30;
	else
		local buff = MBuff.Buffs[buffId];
		if (not buff) then return end;
		
		if (buff.Type == MBuff.BuffType.AutoSelect or buff.Type == MBuff.BuffType.SmartBuff) then
			iconNum = 3;
			WindowSetAlpha(buffIcon, 0.2);
		else
			iconNum = buff.IconNum;
		end
	end
	
	local tex, texX, texY = GetIconData(iconNum);
	DynamicImageSetTexture(buffIcon, tex, texX, texY)
	DynamicImageSetTextureScale(buffIcon, 1);
	DynamicImageSetTextureDimensions(buffIcon, width, height);

end

function MBuffGui.Show()

	local windowName = MBuffGui.Elements.Windows.BuffSetup;
	if (WindowGetShowing(windowName)) then return end

    WindowSetShowing(windowName, true);
    
    WindowUtils.AddToOpenList(windowName, MBuffGui.OnCloseLUp, WindowUtils.Cascade.MODE_NONE)
    
    Sound.Play(Sound.WINDOW_OPEN);

end

function MBuffGui.Hide()

	local windowName = MBuffGui.Elements.Windows.BuffSetup;
	if (not WindowGetShowing(windowName)) then return end

    WindowSetShowing(windowName, false);
    
    Sound.Play(Sound.WINDOW_CLOSE);
    
    WindowUtils.RemoveFromOpenList(windowName);

end

function MBuffGui.OnGroupSpellLClick()

	if (MBuff.Settings.AutoSelectBuffs) then return end
	local id = WindowGetId(SystemData.ActiveWindow.name);
	local buffId = MBuffGui.GetNextBuff(MBuff.BuffsByGroup[id].BuffId, true);
	MBuffGui.ChangeGroupSpell(buffId);
	
end

function MBuffGui.OnGroupSpellRClick()

	if (MBuff.Settings.AutoSelectBuffs) then return end
	local id = WindowGetId(SystemData.ActiveWindow.name);
	local buffId = MBuffGui.GetPreviousBuff(MBuff.BuffsByGroup[id].BuffId, true);
	MBuffGui.ChangeGroupSpell(buffId);
	
end

function MBuffGui.ChangeGroupSpell(buffId)

	if (MBuff.Settings.AutoSelectBuffs) then return end

	local id = WindowGetId(SystemData.ActiveWindow.name);
	local windowName = MBuffGui.Elements.Images.GroupBuffIcon[id];
	
	MBuffGui.SetGroupBuffIcon(id, windowName, buffId);
	MBuffGui.SetBuffsByGroup(id, buffId);

	MBuff.BuffsChanged();
	
end

function MBuffGui.OnSpellLClick()

	local id = WindowGetId(SystemData.ActiveWindow.name);
	local buffId = MBuffGui.GetNextBuff(MBuff.BuffsByCareer[MBuffGui.CareerIndex[id]].BuffId, false);
	MBuffGui.ChangeSpell(buffId);
	
end

function MBuffGui.OnSpellRClick()
	
	local id = WindowGetId(SystemData.ActiveWindow.name);
	local buffId = MBuffGui.GetPreviousBuff(MBuff.BuffsByCareer[MBuffGui.CareerIndex[id]].BuffId, false);
	MBuffGui.ChangeSpell(buffId);
	
end

function MBuffGui.ChangeSpell(buffId)

	local windowName = SystemData.ActiveWindow.name;
	local id = WindowGetId(windowName);
	
	MBuffGui.SetBuffIcon(windowName, buffId);
	MBuff.BuffsByCareer[MBuffGui.CareerIndex[id]].BuffId = buffId;
	MBuff.Settings.BuffsByCareer[GameData.Player.career.line][MBuffGui.CareerIndex[id]].AbilityId = MBuff.GetAbilityFromBuffId(buffId);
	
	if (MBuff.Settings.AutoSelectBuffs) then
	
		MBuffGui.SetupMembers(); --reset buffs
	
	end
	
	MBuff.BuffsChanged();
	
end

function MBuffGui.OnCloseLUp()

	MBuffGui.Hide();

end

function MBuffGui.OnBarRUp()

	MBuffGui.Show();

end

function MBuffGui.OnBarLDown()

	MBuff.LockBuff(true);
	MBuff.Target();

end

function MBuffGui.OnBarLUp()

	MBuff.LockBuff(false);

end

function MBuffGui.OnManualSelectLClick()

	local isChecked = ButtonGetPressedFlag(MBuffGui.Elements.Checkboxes.ManualSelect .. "Button") == false 
	ButtonSetPressedFlag(MBuffGui.Elements.Checkboxes.ManualSelect .. "Button", isChecked);
	
	-- if isChecked, manual select group buffs
	-- if not isChecked, auto select group buffs
	
	MBuff.Settings.AutoSelectBuffs = (not isChecked);
	
	if (MBuff.Settings.AutoSelectBuffs) then
	
		for index = 1, MAX_GROUP_MEMBERS do
			MBuffGui.SetBuffsByGroup(index, nil);
		end
	
		MBuffGui.SetupMembers(); --reset buffs
	
	end
	
	MBuff.BuffsChanged();
	
end

local function IsSpecialBuff(buffId)

	local buff = MBuff.Buffs[buffId];
	if (not buff) then 
		return false;
	end
	
	if (buff.Type == MBuff.BuffType.AutoSelect or buff.Type == MBuff.BuffType.SmartBuff) then
		return true;
	end
	
	return false;

end

function MBuffGui.GetNextBuff(buffId, allowSpecial)

	local startIndex = buffId;
	local endIndex = #MBuff.Buffs;
	local stepping = 1;

	if (not startIndex) then
		startIndex = 0;
	end
	
	for index = startIndex + 1, endIndex, stepping do
		if (allowSpecial or not IsSpecialBuff(index)) then
			return index
		end
	end
	
	return nil;

end

function MBuffGui.GetPreviousBuff(buffId, allowSpecial)

	local startIndex = buffId;
	local endIndex = 1;
	local stepping = -1;

	if (not startIndex) then
		startIndex = #MBuff.Buffs + 1;
	end
	
	for index = startIndex - 1, endIndex, stepping do
		if (allowSpecial or not IsSpecialBuff(index)) then
			return index
		end
	end
	
	return nil;

end

function MBuffGui.OnMouseOver()

	mouseOverLayers = mouseOverLayers + 1;

	if (mouseOverLayers == 1) then

		local scale = WindowGetScale(MBuffGui.Elements.Windows.BuffBar);
   		WindowSetScale(MBuffGui.Elements.Windows.BuffBarTarget, scale);

		if (not buffTargetEmpty) then
		
			WindowSetShowing(MBuffGui.Elements.Windows.BuffBarTarget, true); --only display if there is an active member
		
		end
	
	end

end

function MBuffGui.OnMouseOut()

	mouseOverLayers = mouseOverLayers - 1;

	if (mouseOverLayers == 0) then

		WindowSetShowing(MBuffGui.Elements.Windows.BuffBarTarget, false);
	
	end

end

local function GetCareerTypeString(careerType)

	local rememberAs = tostring(localization["SmartBuff.RememberAs"]);
	local typeString = "";
	
	if (careerType == MBuff.CareerType.Melee) then
		typeString = tostring(localization["CareerType.DPS"]);
	elseif (careerType == MBuff.CareerType.Tank) then
		typeString = tostring(localization["CareerType.Tank"]);
	elseif (careerType == MBuff.CareerType.Ranged) then
		typeString = tostring(localization["CareerType.DPS"]);
	elseif (careerType == MBuff.CareerType.Caster) then
		typeString = tostring(localization["CareerType.DPS"]);
	elseif (careerType == MBuff.CareerType.Healer) then
		typeString = tostring(localization["CareerType.Healer"]);
	end
	
	return rememberAs:format(typeString);

end

local function CreateContextItem(windowName, labelText, callFunction)

	CreateWindowFromTemplate(windowName, "ChatContextMenuItemCheckBox", "Root");
    LabelSetText(windowName .. "CheckBoxLabel", labelText);
    WindowRegisterCoreEventHandler(windowName, "OnLButtonUp", callFunction);
    WindowRegisterCoreEventHandler(windowName, "OnMouseOver", "EA_Window_ContextMenu.OnMouseOverDefaultMenuItem");
    WindowSetShowing(windowName, false);

end

local function CreateContextBuffItem(windowName, iconNum, labelText, callFunction)

	CreateWindowFromTemplate(windowName, "MarkBuffContextMenuItemBuffCheckBox", "Root");
    LabelSetText(windowName .. "Label", labelText);
	
	local tex, texX, texY = GetIconData(iconNum)
	DynamicImageSetTexture(windowName .. "BuffIcon", tex, texX, texY)
	DynamicImageSetTextureScale(windowName .. "BuffIcon", 1);
	DynamicImageSetTextureDimensions(windowName .. "BuffIcon", 65, 65);
	
    WindowRegisterCoreEventHandler(windowName, "OnLButtonUp", callFunction);
    WindowRegisterCoreEventHandler(windowName, "OnMouseOver", "EA_Window_ContextMenu.OnMouseOverDefaultMenuItem");
    WindowSetShowing(windowName, false);

end

function MBuffGui.CreateContext()

	if (not contextCreated) then
		if (GameData.Player.career.line == GameData.CareerLine.ZEALOT) then
			--destro
			CreateContextBuffItem(MBuffGui.Elements.ContextMenu.StrengthAura, 5167, localization["SmartBuff.Auras.Strength"], "MBuffGui.ToggleAurasStrength");
			CreateContextBuffItem(MBuffGui.Elements.ContextMenu.ResistsAura, 5253, localization["SmartBuff.Auras.Resists"], "MBuffGui.ToggleAurasResists");
		else
			--order
			CreateContextBuffItem(MBuffGui.Elements.ContextMenu.StrengthAura, 7995, localization["SmartBuff.Auras.Strength"], "MBuffGui.ToggleAurasStrength");
			CreateContextBuffItem(MBuffGui.Elements.ContextMenu.ResistsAura, 8002, localization["SmartBuff.Auras.Resists"], "MBuffGui.ToggleAurasResists");	
		end
	end
	
	contextIdToAbility = {};
	local count = 1;
	
	for index,buff in pairs(MBuff.Buffs) do
		if (buff.Type == MBuff.BuffType.Normal) then
			if (not MBuffGui.Elements.ContextMenu.Override[buff.AbilityId]) then
				MBuffGui.Elements.ContextMenu.Override[buff.AbilityId] = MBuffGui.Elements.Windows.BuffSetup .. "ContextOverride" .. buff.AbilityId;
				CreateContextBuffItem(MBuffGui.Elements.ContextMenu.Override[buff.AbilityId], buff.IconNum, L"", "MBuffGui.ToggleOverride");
			end
			
			contextIdToAbility[count] = buff.AbilityId;
			
			count = count + 1;
		end
	end
	
	contextCreated = true;

end

function MBuffGui.ToggleOverride()

	local windowName = SystemData.ActiveWindow.name;
	local abilityId = contextIdToAbility[WindowGetId(windowName)];
	
	if (not MBuffGui.Elements.ContextMenu.Override[abilityId]) then return end;
	
	local isChecked = ButtonGetPressedFlag(windowName .. "CheckBox") == false;
	ButtonSetPressedFlag(windowName .. "CheckBox", isChecked);
	
	local oldAbilityId = nil;
	if (MBuff.RememberedBuff[activeContextGroupMember.Name]) then
		oldAbilityId = MBuff.RememberedBuff[activeContextGroupMember.Name].AbilityId;
	end
	if (oldAbilityId and oldAbilityId ~= abilityId and MBuffGui.Elements.ContextMenu.Override[oldAbilityId]) then
		ButtonSetPressedFlag(MBuffGui.Elements.ContextMenu.Override[oldAbilityId] .. "CheckBox", false);
	end
	
	if (not isChecked) then
		abilityId = nil;
	end
	
	if (isChecked) then
		MBuff.RememberedBuff[activeContextGroupMember.Name] = { AbilityId = abilityId };
	else
		MBuff.RememberedBuff[activeContextGroupMember.Name] = nil;
	end
	
	MBuff.UpdateRemembered(activeContextGroupMember.Name);
	
	MBuffGui.SetGroupTypeImage(GetGroupMemberIndex(activeContextGroupMember));
	MBuff.BuffsChanged();

end

function MBuffGui.ToggleAurasStrength()

	local windowName = MBuffGui.Elements.ContextMenu.StrengthAura;
	local isChecked = ButtonGetPressedFlag(windowName .. "CheckBox") == false;
	ButtonSetPressedFlag(windowName .. "CheckBox", isChecked);
	
	if (activeContextGroupMember) then
		if (not MBuff.RememberedAuras[activeContextGroupMember.Name]) then
			MBuff.RememberedAuras[activeContextGroupMember.Name] = { Strength = true, Resists = true };
		end
		local rememberedAuras = MBuff.RememberedAuras[activeContextGroupMember.Name];
		rememberedAuras.Strength = isChecked;
		MBuff.UpdateRemembered(activeContextGroupMember.Name);
	end
	
	MBuff.ResetSmartBuffGroupInfo();

end

function MBuffGui.ToggleAurasResists()

	local windowName = MBuffGui.Elements.ContextMenu.ResistsAura;
	local isChecked = ButtonGetPressedFlag(windowName .. "CheckBox") == false;
	ButtonSetPressedFlag(windowName .. "CheckBox", isChecked);
	
	if (activeContextGroupMember) then
		if (not MBuff.RememberedAuras[activeContextGroupMember.Name]) then
			MBuff.RememberedAuras[activeContextGroupMember.Name] = { Strength = true, Resists = true };
		end
		local rememberedAuras = MBuff.RememberedAuras[activeContextGroupMember.Name];
		rememberedAuras.Resists = isChecked;
		MBuff.UpdateRemembered(activeContextGroupMember.Name);
	end
	
	MBuff.ResetSmartBuffGroupInfo();

end

function MBuffGui.OnGroupIconRUp()

	local id = WindowGetId(SystemData.ActiveWindow.name);
	local groupMember = GetGroupMembers()[id];
	if (not groupMember or not groupMember.IsValid) then return end
	
	activeContextGroupMember = groupMember;
	
	local menu = 1;
	
	EA_Window_ContextMenu.CreateContextMenu(SystemData.ActiveWindow.name, menu);
	
	local careerTypes = MBuff.GetCareerTypes(groupMember.CareerLine);
	for index, careerType in ipairs(careerTypes) do	
		EA_Window_ContextMenu.AddMenuItem(towstring(GetCareerTypeString(careerType)), function() MBuffGui.MarkPlayer(groupMember.Name, careerType) end , false, true, menu);
	end
	if (MBuff.RememberedCareerType[groupMember.Name]) then
		EA_Window_ContextMenu.AddMenuItem(localization["SmartBuff.RememberAs.Reset"], function() MBuffGui.MarkPlayer(groupMember.Name, nil) end , false, true, menu);
	end
	
	local seperatorVisible = false;
	
	if (groupMember.CareerLine == GameData.CareerLine.CHOSEN or groupMember.CareerLine == GameData.CareerLine.KNIGHT) then
		if (not seperatorVisible) then
			seperatorVisible = true;
			EA_Window_ContextMenu.AddMenuDivider(menu);
		end
		EA_Window_ContextMenu.AddCascadingMenuItem(localization["SmartBuff.Auras"], function() MBuffGui.ShowAurasMenu(groupMember) end, false, menu);
	end
	
	if (#contextIdToAbility > 0) then
		if (not seperatorVisible) then
			seperatorVisible = true;
			EA_Window_ContextMenu.AddMenuDivider(menu);
		end
		EA_Window_ContextMenu.AddCascadingMenuItem(localization["SmartBuff.Override"], function() MBuffGui.ShowOverrideMenu(groupMember) end, false, menu);
	end
	
	EA_Window_ContextMenu.Finalize(menu);
	
end

function MBuffGui.ShowAurasMenu(groupMember)

	local strengthAura = true;
	local resistsAura = true;
	local rememberedAuras = MBuff.RememberedAuras[groupMember.Name];
	
	if (rememberedAuras) then
		strengthAura = rememberedAuras.Strength;
		resistsAura = rememberedAuras.Resists;
	end

	local menu = 2;
	
	EA_Window_ContextMenu.CreateContextMenu(SystemData.ActiveWindow.name, menu);
	
	local windowName = MBuffGui.Elements.ContextMenu.StrengthAura;
	ButtonSetPressedFlag(windowName .. "CheckBox", strengthAura);
    EA_Window_ContextMenu.AddUserDefinedMenuItem(windowName, menu);
	
	windowName = MBuffGui.Elements.ContextMenu.ResistsAura;
	ButtonSetPressedFlag(windowName .. "CheckBox", resistsAura);
    EA_Window_ContextMenu.AddUserDefinedMenuItem(windowName, menu);
	
	EA_Window_ContextMenu.Finalize(menu);
	
end

function MBuffGui.ShowOverrideMenu(groupMember)

	local rememberedBuff = MBuff.RememberedBuff[groupMember.Name];
	local rememberedAbilityId = nil;
	
	if (rememberedBuff) then
		rememberedAbilityId = rememberedBuff.AbilityId;
	end

	local menu = 2;
	
	EA_Window_ContextMenu.CreateContextMenu(SystemData.ActiveWindow.name, menu);
	
	for abilityId, windowName in pairs(MBuffGui.Elements.ContextMenu.Override) do
		ButtonSetPressedFlag(windowName .. "CheckBox", (abilityId == rememberedAbilityId));
		EA_Window_ContextMenu.AddUserDefinedMenuItem(windowName, menu);
		contextIdToAbility[WindowGetId(windowName)] = abilityId;
	end
	
	EA_Window_ContextMenu.Finalize(menu);
	
end

function MBuffGui.SetGroupTypeImage(index)

	local groupMember = GetGroupMembers()[index];
	local groupTypeImage = MBuffGui.Elements.Images.GroupType[index];
	
	local careerType = nil;
	local rememberedBuff = nil;
	
	if (groupMember and groupMember.IsValid) then
		careerType = MBuff.RememberedCareerType[groupMember.Name];
		if (MBuff.RememberedBuff[groupMember.Name]) then
			rememberedBuff = MBuff.RememberedBuff[groupMember.Name].AbilityId;
		end
	end
	
	if (rememberedBuff) then
		
		local iconNum = MBuff.Buffs[MBuff.GetBuffFromAbilityId(rememberedBuff)].IconNum;
		local tex, texX, texY = GetIconData(iconNum)
		DynamicImageSetTexture(groupTypeImage, tex, texX, texY)
		DynamicImageSetTextureScale(groupTypeImage, 1);
		DynamicImageSetTextureDimensions(groupTypeImage, 65, 65);
		
		WindowSetShowing(groupTypeImage, true);
	
	elseif (careerType) then
		
		local image = groupTypeImages.DPS;
		
		if (careerType == MBuff.CareerType.Melee or careerType == MBuff.CareerType.Ranged or careerType == MBuff.CareerType.Caster) then
			image = groupTypeImages.DPS;
		elseif (careerType == MBuff.CareerType.Healer) then
			image = groupTypeImages.Healer;
		elseif (careerType == MBuff.CareerType.Tank) then
			image = groupTypeImages.Tank;
		end
		
		local tex, texX, texY = image, 0, 0;
		DynamicImageSetTexture(groupTypeImage, tex, texX, texY)
		DynamicImageSetTextureScale(groupTypeImage, 1);
		DynamicImageSetTextureDimensions(groupTypeImage, 38, 38);
		
		WindowSetShowing(groupTypeImage, true);
	else
		WindowSetShowing(groupTypeImage, false);
	end

end

function MBuffGui.MarkPlayer(playerName, careerType)
	MBuff.RememberedCareerType[playerName] = careerType;
	MBuff.UpdateRemembered(playerName);
	MBuff.BuffsChanged();
	
	MBuffGui.SetGroupTypeImage(GetGroupMemberIndex(LibGroup.GroupMembers.ByName[playerName]));
end

function MBuffGui.SetBuffSpellIcon(iconNum)

	if (iconNum ~= spellIconValue) then

		spellIconValue = iconNum;
		
		local tex, texX, texY = GetIconData(iconNum)
		DynamicImageSetTexture(MBuffGui.Elements.Images.SpellIcon, tex, texX, texY)
		DynamicImageSetTextureScale(MBuffGui.Elements.Images.SpellIcon, 1);
		DynamicImageSetTextureDimensions(MBuffGui.Elements.Images.SpellIcon, 65, 65);
		
	end

end

function MBuffGui.SetBuffTargetInRange(targetInRange)

end

function MBuffGui.SetBuffTarget(groupMember)

	local careerIcon = MBuffGui.Elements.Images.TargetCareerIcon;
	local nameLabel = MBuffGui.Elements.Labels.TargetPlayerName;
	
	if (not groupMember) then
	
		WindowSetShowing(careerIcon, false);
		buffTargetEmpty = true;
		
	else
	
		WindowSetShowing(careerIcon, groupMember.IsValid);
		buffTargetEmpty = false;
	
	end
		
	if (groupMember and groupMember.IsValid) then
			
		LabelSetText(nameLabel, groupMember.Name);
			
		local tex, texX, texY = GetIconData(Icons.GetCareerIconIDFromCareerLine(groupMember.CareerLine));
		DynamicImageSetTexture(careerIcon, tex, texX, texY)
		DynamicImageSetTextureScale(careerIcon, 1);
		DynamicImageSetTextureDimensions(careerIcon, 32, 32);
		
		if (groupMember.Distance and groupMember.Distance >= BUFF_DISTANCE) then
			local r, g, b = 165, 12, 8;
			WindowSetTintColor(MBuffGui.Elements.Images.SpellIcon, r, g, b);
			LabelSetTextColor(MBuffGui.Elements.Labels.UnbuffedCount, r, g, b);
			LabelSetTextColor(MBuffGui.Elements.Labels.TargetPlayerName, r, g, b);
		else
			local r, g, b = 255, 255, 255;
			WindowSetTintColor(MBuffGui.Elements.Images.SpellIcon, r, g, b);
			LabelSetTextColor(MBuffGui.Elements.Labels.UnbuffedCount, r, g, b);
			LabelSetTextColor(MBuffGui.Elements.Labels.TargetPlayerName, r, g, b);
		end
			
	else
		LabelSetText(nameLabel, L"Unknown");
	end

end

function MBuffGui.SetUnbuffedText(unbuffedCount)

	local displayValue = "";

	if (unbuffedCount > 0) then
		displayValue = unbuffedCount;
	end

	if (displayValue ~= unbuffedValue) then
	
		LabelSetText(MBuffGui.Elements.Labels.UnbuffedCount, towstring(displayValue));
		unbuffedValue = unbuffedValue;
		
	end

end

function MBuffGui.SetTimerText(timeRemaining)

	local displayValue = "";

	if (not timeRemaining) then

		if (displayValue ~= timerValue) then
	
			LabelSetText(MBuffGui.Elements.Labels.TimeRemaining, towstring(displayValue));
			LabelSetTextColor(MBuffGui.Elements.Labels.TimeRemaining, 255, 255, 255);
			timerValue = displayValue;
	
		end
	
		return;
	
	end

	timeRemaining = math.floor(timeRemaining);

	local m, s;

	m = math.floor(timeRemaining / 60);
	s = timeRemaining - m * 60;

	if (m < 10) then

		displayValue = displayValue .. "0";

	end

	displayValue = displayValue .. tostring(m) .. ":";

	if (s < 10) then

		displayValue = displayValue .. "0";

	end

	displayValue = displayValue .. tostring(s);

	local r,g,b = 255,255,255;

	if (timeRemaining <= 300) then -- 5min left
	
		r,g,b = 205,44,44;

	elseif (timeRemaining <= 1200) then -- 20min left
	
		r,g,b = 255,100,0;

	end

	if (displayValue ~= timerValue) then
	
		LabelSetText(MBuffGui.Elements.Labels.TimeRemaining, towstring(displayValue));
		LabelSetTextColor(MBuffGui.Elements.Labels.TimeRemaining, r, g, b)
		timerValue = displayValue;
	
	end

end