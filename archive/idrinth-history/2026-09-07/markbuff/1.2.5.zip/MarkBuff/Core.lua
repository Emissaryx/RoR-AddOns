MBuff = {};

local VERSION = "1.2.5";
local VERSION_SETTINGS = 4;

local MAX_GROUP_MEMBERS = 6;
local UPDATE_THROTTLE = 0.2;
local GROUP_UPDATE_THROTTLE = 0.5;
local BAR_UPDATE_THROTTLE = 0.5;
local CLEAN_BUFF_EXPIRY = 60;
local BUFF_FULL_UPDATE_POLL = 30;
local IGNORE_GROUPMEMBER_BUFF_TIME = 10;
local TEST_HOTBAR_SLOT = 119;
local BASE_COOLDOWN = 2;
local BUFF_DISTANCE = 110;
local MAX_REMEMBERED = 50;

local AUTOSELECT_BUFF_ID = 1;
local SMARTBUFF_BUFF_ID = 2;

local SORT_INDEX = "index";
local SORT_SLOT = "slot";

local throttleTime = UPDATE_THROTTLE;
local barThrottleTime = BAR_UPDATE_THROTTLE;

local ignoreTarget = false;

MBuff.Version = VERSION;
MBuff.Name = "MarkBuff";
MBuff.IsLoaded = false;
MBuff.IsEventsRegistered = false;
MBuff.CurrentTarget = L"";
MBuff.SortGroupBy = SORT_INDEX;

MBuff.Buffs = {};
MBuff.BuffsByGroup = {};
MBuff.BuffsByCareer = {};
MBuff.BuffCache = {};

MBuff.RememberedCareerType = {};
MBuff.RememberedAuras = {};
MBuff.RememberedBuff = {};

MBuff.BuffType = { Normal = 1, AutoSelect = 2, SmartBuff = 3 };
MBuff.CareerType = { Melee = 1, Ranged = 2, Caster = 3, Healer = 4, Tank = 5 };

MBuff.CastingSpell = {};

MBuff.TimeCount = 0;

local abilityIds =
{
	--zealot
	8551, 8556, 8560, 8567,
	--runepriest
	1588, 1591, 1600, 1608,
	--shaman
	1910,
	--archmage
	9248,
};
local abilityKeys = {};
MBuff.BuffNames = {};
MBuff.GroupType = { AurasInGroup = 1, ResistsInGroup = 2, Other = 3 };
	
local buffFromAbilityId = {};
local abilityFromBuffId = {};

local registeredEvents = {};

local flagBuffUpdate = true;
local flagBuffLock = false;
local flagBarUpdate = true;

local selectedBuffTarget = {};

local playersName = L"";
local warbandGroupIndex = nil;
local buffBarTimer = { Duration = 0, StartTime = 0 };
local nextCooldownUpdate = nil;

local smartBuffGroupInfo = nil;

local isLibSlashRegistered = false;
local isLibAddonButtonRegistered = false;

local localization = MBuffLocalization.GetMapping();

local function RegisterLibs()
	if (not isLibSlashRegistered) then
		if (LibSlash) then
			LibSlash.RegisterSlashCmd("markbuff", function(args) MBuff.SlashCommand(args) end);
			LibSlash.RegisterSlashCmd("mbuff", function(args) MBuff.SlashCommand(args) end);
			isLibSlashRegistered = true;
		end
	end

	if (not isLibAddonButtonRegistered) then
		if (LibAddonButton) then
			LibAddonButton.Register("fx");
			LibAddonButton.AddMenuItem("fx", "MarkBuff", MBuffSetup.SmartBuff.Show);
			isLibAddonButtonRegistered = true;
		end
	end
end

local function print(text)

	EA_ChatWindow.Print(towstring(tostring(text)), ChatSettings.Channels[SystemData.ChatLogFilters.SAY].id);

end

local function CreateEventObj(e, func)

	local event = {};
	
	event.e = e;
	event.func = func;
	
	return event;

end

local function AddEvent(events, eventObj)

	table.insert(events, eventObj);

end

local function RegisterEvents(events, enabled)

	for index, event in pairs(events) do

		if (enabled) then
		
			RegisterEventHandler(event.e, event.func);
			
		else
		
			UnregisterEventHandler(event.e, event.func);
		
		end
	
	end

end

local function UpdateRemembered(playerName)

	-- if this group member has remembered settings, update the last seen date

	if (MBuff.Settings.Remembered[playerName]) then
		local todaysDate = GetTodaysDate();
		local date = { Year = todaysDate.todaysYear, Month = todaysDate.todaysMonth, Day = todaysDate.todaysDay };
		MBuff.Settings.Remembered[playerName].Date = date;
	end

end

local function GetCount(table)

	local count = 0;
	for _,_ in pairs(table) do
		count = count + 1;
	end
	
	return count;

end

local function CompareRemembered(indexA, indexB)
	if (indexB == nil) then
		return false;
	end
	
	local entryA = MBuff.Settings.Remembered[indexA];
	local entryB = MBuff.Settings.Remembered[indexB];

	if (entryA.Date and entryB.Date) then
		if (entryA.Date.Year == entryB.Date.Year) then
			if (entryA.Date.Month == entryB.Date.Month) then
				return (entryA.Date.Day > entryB.Date.Day);
			else
				return (entryA.Date.Month > entryB.Date.Month);
			end
		else
			return (entryA.Date.Year > entryB.Date.Year);
		end
	else
		return (entryB.Date == nil);	
	end
	
end

local function CheckRemembered()
	
	MBuff.Settings.Remembered = MBuff.Settings.Remembered or {};
	
	local count = GetCount(MBuff.Settings.Remembered);
	if (count <= MAX_REMEMBERED) then return end
	
	local sortedRemembered = {};
	
	for playerName, rememberData in pairs(MBuff.Settings.Remembered) do
		table.insert(sortedRemembered, playerName);
	end
	
	table.sort(sortedRemembered, CompareRemembered);
	
	for index = MAX_REMEMBERED + 1, count do
		local name = sortedRemembered[index];
		MBuff.Settings.Remembered[name] = nil;
	end

end

local function IsSmartBuffed(groupMember)

	if (not groupMember) then return end

	if (not MBuff.Settings.AutoSelectBuffs) then
	
		local index = 1;
	
		if (MBuff.SortGroupBy == SORT_INDEX) then
			index = groupMember.Index;
		elseif (MBuff.SortGroupBy == SORT_SLOT) then
			index = groupMember.Slot;
		end
		
		local buff = MBuff.Buffs[MBuff.BuffsByGroup[index].BuffId];
		
		if (buff) then
			if (buff.Type == MBuff.BuffType.SmartBuff) then
			
				return true;
			
			end
		end
	
	end
	
	return false;
	
end

function MBuff.Initialize()
	
	registeredEvents = {};
	
	WindowSetShowing(MBuffGui.Elements.Windows.BuffBar, false);
	
	AddEvent(registeredEvents, CreateEventObj(SystemData.Events.PLAYER_TARGET_UPDATED, "MBuff.TargetUpdated"));
	AddEvent(registeredEvents, CreateEventObj(SystemData.Events.PLAYER_BEGIN_CAST, "MBuff.BeginCast"));
	AddEvent(registeredEvents, CreateEventObj(SystemData.Events.PLAYER_END_CAST, "MBuff.EndCast"));
	
	--AddEvent(registeredEvents, CreateEventObj(SystemData.Events.PLAYER_TARGET_EFFECTS_UPDATED, "MBuff.EffectsUpdated"));
	AddEvent(registeredEvents, CreateEventObj(SystemData.Events.PLAYER_EFFECTS_UPDATED, "MBuff.EffectsUpdated"));
	AddEvent(registeredEvents, CreateEventObj(SystemData.Events.GROUP_EFFECTS_UPDATED, "MBuff.EffectsUpdated"));
	
	AddEvent(registeredEvents, CreateEventObj(SystemData.Events.PLAYER_ZONE_CHANGED, "MBuff.OnZoneChange"));
	AddEvent(registeredEvents, CreateEventObj(SystemData.Events.PLAYER_NEW_ABILITY_LEARNED, "MBuff.OnPlayerAbilityLearned"));
	AddEvent(registeredEvents, CreateEventObj(SystemData.Events.RELOAD_INTERFACE, "MBuff.OnLoadComplete"));
	AddEvent(registeredEvents, CreateEventObj(SystemData.Events.LOADING_END, "MBuff.OnLoadComplete"));

	RegisterEvents(registeredEvents, true);

	MBuff.IsEventsRegistered = true;

	print(tostring(localization["InitializedMessage"]):format(MBuff.Name .. " " .. MBuff.Version));
	
	LibGroup.Register(LibGroup.Events.GROUP_MEMBER_ADDED, MBuff.OnGroupMemberAdded);
	LibGroup.Register(LibGroup.Events.GROUP_MEMBER_UPDATED, MBuff.OnGroupMemberUpdated);
	LibGroup.Register(LibGroup.Events.GROUP_UPDATED, MBuff.OnGroupUpdated);
	LibGroup.Register(LibGroup.Events.GROUP_MEMBER_DISTANCE_CHANGED, MBuff.OnGroupMemberDistanceChanged);
	LibGroup.Register(LibGroup.Events.GROUP_MEMBER_REMOVED, MBuff.OnGroupMemberRemoved);
	LibGroup.Register(LibGroup.Events.GROUP_MEMBER_DISTANCE_TO_PLAYER_CHANGED, MBuff.OnGroupMemberDistanceToPlayerChanged);
	
end

function MBuff.Unload()

	WindowSetShowing(MBuffGui.Elements.Windows.BuffBar, false);
	MBuffGui.Hide();
	
	if (MBuff.IsEventsRegistered) then
	
		RegisterEvents(registeredEvents, false);
		MBuff.IsEventsRegistered = false;
		
	end
	
	LibGroup.Unregister(LibGroup.Events.GROUP_MEMBER_ADDED, MBuff.OnGroupMemberAdded);
	LibGroup.Unregister(LibGroup.Events.GROUP_MEMBER_UPDATED, MBuff.OnGroupMemberUpdated);
	LibGroup.Unregister(LibGroup.Events.GROUP_UPDATED, MBuff.OnGroupUpdated);
	LibGroup.Unregister(LibGroup.Events.GROUP_MEMBER_DISTANCE_CHANGED, MBuff.OnGroupMemberDistanceChanged);
	LibGroup.Unregister(LibGroup.Events.GROUP_MEMBER_REMOVED, MBuff.OnGroupMemberRemoved);
	LibGroup.Unregister(LibGroup.Events.GROUP_MEMBER_DISTANCE_TO_PLAYER_CHANGED, MBuff.OnGroupMemberDistanceToPlayerChanged);
	
	MBuff.IsLoaded = false;

end

function MBuff.OnGroupMemberAdded(groupMember)

	MBuff.PurgeGroupMemberBuffData(groupMember);
	groupMember.IgnoredUntil = nil;
	
	if (groupMember.IsValid) then
		UpdateRemembered(groupMember.Name);
		groupMember.Buff.BuffIndex = MBuff.FindBuffIndexFromCache(groupMember); --attempt to find an old buff cache for this member
		groupMember.Buff.LastUpdate = nil;
	end
	
	flagBarUpdate = true;

end

function MBuff.OnGroupMemberRemoved(memberName)

	MBuff.BuffCache[memberName] = nil;
	flagBarUpdate = true;

	if (MBuff.IsLoaded) then
		MBuffGui.SetupMembers();
	end
		
end

function MBuff.OnGroupMemberDistanceChanged(groupMember)

	flagBarUpdate = true;
		
end

function MBuff.OnGroupMemberDistanceToPlayerChanged(oldDistance, newDistance, groupMember)

	if ((not oldDistance) or (not newDistance) or
		(oldDistance >= BUFF_DISTANCE and newDistance < BUFF_DISTANCE) or
		(oldDistance < BUFF_DISTANCE and newDistance >= BUFF_DISTANCE)) then

		flagBarUpdate = true;
	
	end
		
end

function MBuff.OnGroupMemberUpdated(groupMember)
	
	if (groupMember.IsValid) then
		--player is dead, clear all buffs
		if (not groupMember.IsAlive) then
			MBuff.PurgeGroupMemberBuffData(groupMember);
			MBuff.BuffCache[groupMember.Name] = {};
			flagBarUpdate = true;
		end
	end
		
end

function MBuff.OnGroupUpdated()

	MBuff.PurgeBuffCache();

	if (MBuff.IsLoaded) then
		MBuffGui.SetupMembers();
	end
	
	smartBuffGroupInfo = nil;
	
	--update smart buffs
	for index, groupMember in ipairs(LibGroup.GroupMembers.ByIndex) do
		groupMember.ExpectedBuff = nil;
	end
	
	flagBarUpdate = true;
	
end

function MBuff.ResetSmartBuffGroupInfo()
	smartBuffGroupInfo = nil;
	MBuff.BuffsChanged();
end

function MBuff.SlashCommand(args)

	if (not MBuff.IsLoaded) then return end

	MBuffSetup.SmartBuff.Show();

end

function MBuff.BeginCast(spellId, channel, castTime)
	
	MBuff.CastingSpell.SpellId = spellId;
	MBuff.CastingSpell.Channeled = channel;
	MBuff.CastingSpell.CastTime = castTime;
	
end

function MBuff.EndCast(failed)

	if (failed or not MBuff.CastingSpell.SpellId) then return end
	
	local buffId = MBuff.GetBuffFromAbilityId(MBuff.CastingSpell.SpellId);
	if (not buffId) then return end
	
	local groupMember = LibGroup.GroupMembers.ByName[MBuff.CurrentTarget];
	if (not groupMember) then return end
	
	local expectedBuff = MBuff.ExpectedBuff(groupMember);
	if (expectedBuff ~= buffId) then return end
	
	groupMember.Buff.Duration = 3600;
	groupMember.Buff.BuffId = expectedBuff;
	groupMember.Buff.LastUpdate = MBuff.TimeCount;
	
	groupMember.Buff.BuffIndex = MBuff.FindBuffIndexFromCache(groupMember);
	
	flagBarUpdate = true;

end

function MBuff.TargetUpdated(classification, targetId, targetType)
	
	if (classification == "selffriendlytarget") then

		TargetInfo:UpdateFromClient();
		
		local targetName = TargetInfo:UnitName("selffriendlytarget");
		if (not targetName) then return end
		
		MBuff.CurrentTarget = targetName:match(L"([^^]+)^?([^^]*)");
		
		MBuff.SetAction();
		
	end

end

function MBuff.PurgeBuffCache()

	local newBuffCache = {};
	
	for index = 1, MAX_GROUP_MEMBERS
	do
		
		local groupMember = LibGroup.GroupMembers.ByIndex[index];
		
		if (groupMember.IsValid) then
		
			local oldBuffCache = MBuff.BuffCache[groupMember.Name];
			if (not oldBuffCache) then
			
				oldBuffCache = {};
			
			end
			
			newBuffCache[groupMember.Name] = oldBuffCache;
			
		end
			
	end
	
	MBuff.BuffCache = newBuffCache;

end

function MBuff.EffectsUpdated(updateType, effects, isFull)
	
    if (type(updateType) == "table") then
	
        effects, isFull, updateType = updateType, effects, GameData.BuffTargetType.SELF;
		
    end
    
    if not updateType then return end
    
    local nameOfUpdatedPlayer = L"";
    
	--group member
    if (updateType >= GameData.BuffTargetType.GROUP_MEMBER_START and updateType <= GameData.BuffTargetType.GROUP_MEMBER_END) then
	
        local groupIndex = updateType - GameData.BuffTargetType.GROUP_MEMBER_START + 1;
        nameOfUpdatedPlayer = (GroupWindow.groupData[groupIndex].name):match(L"([^^]+)^?([^^]*)");
		
	--self
    elseif (updateType == GameData.BuffTargetType.SELF) then
	
        nameOfUpdatedPlayer = playersName;
	
	--friendly
    elseif (updateType == GameData.BuffTargetType.TARGET_FRIENDLY) then
	
        nameOfUpdatedPlayer = (TargetInfo:UnitName("selffriendlytarget")):match(L"([^^]+)^?([^^]*)");
        if (not nameOfUpdatedPlayer) then return end
		
	--other
    else
	
        return;
		
    end
	
	MBuff.UpdateGroupMemberBuffs(LibGroup.GroupMembers.ByName[nameOfUpdatedPlayer], effects, isFull);
	
end

function MBuff.UpdateGroupMemberBuffs(groupMember, effectsList, isFullList)

	if (not groupMember or not groupMember.IsValid) then return end
	
	if (not MBuff.BuffCache[groupMember.Name]) then
	
		MBuff.BuffCache[groupMember.Name] = {};
	
	end
	
	if (isFullList) then
	
		MBuff.PurgeGroupMemberBuffData(groupMember);
		groupMember.Buff.LastUpdate = MBuff.TimeCount;
		
		MBuff.BuffCache[groupMember.Name] = {};
		flagBarUpdate = true;
		
	end
	
	local buffsChanged = false;
	
	for index,data in pairs(effectsList) do
	
		if (not data.abilityId) then
		
			if (MBuff.BuffCache[groupMember.Name][index]) then
				
				local abilityId = MBuff.BuffCache[groupMember.Name][index].AbilityId;
				MBuff.BuffCache[groupMember.Name][index] = nil;
				
				if (abilityKeys[abilityId]) then
					buffsChanged = true;
					groupMember.ExpectedBuff = nil; -- wipe cache for smart buffs
					flagBarUpdate = true;
				end
			end
		
		elseif (abilityKeys[data.abilityId]) then
			buffsChanged = true;

			MBuff.BuffCache[groupMember.Name][index] = {};
			
			local buff = MBuff.BuffCache[groupMember.Name][index];
			buff.AbilityId = data.abilityId;
			buff.Duration = data.duration;
			buff.CastByPlayer = data.castByPlayer;
			buff.TimeAdded = MBuff.TimeCount;
	
		end
	
	end
	
	if (buffsChanged) then
		local previousBuff = MBuff.ExpectedBuff(groupMember);
		groupMember.ExpectedBuff = nil;
		local expectedBuff = MBuff.ExpectedBuff(groupMember);
		
		-- this is for when a smart buff changes because another zealot buffed what we were going to
		if (previousBuff ~= expectedBuff) then
			flagBarUpdate = true;
		end
		
		MBuff.UpdateBuff(groupMember);
	end
	
end

local function IsSettingsValid()

	if (MBuff.Settings) then
	
		if (not MBuff.Settings.Version) then
	
			return false;
		
		else
		
			if (not MBuff.BuffsByGroup or not MBuff.BuffsByCareer) then
			
				return false;
			
			end
		
		end
	
	else
	
		return false;
	
	end
	
	return true;

end

local function SetupDefaultSmartBuff()

	if (not MBuff.Settings.SmartBuff) then
		MBuff.Settings.SmartBuff = {};
	end
	MBuff.Settings.SmartBuff[GameData.Player.career.line] = {};
	
	local smartBuff = MBuff.Settings.SmartBuff[GameData.Player.career.line];
	
	smartBuff[MBuff.CareerType.Melee] = { MBuff.BuffNames.StrengthBuff, MBuff.BuffNames.ResistBuff, MBuff.BuffNames.WillpowerBuff };
	--smartBuff[MBuff.CareerType.Melee][MBuff.GroupType.AurasInGroup] = { MBuff.BuffNames.WillpowerBuff, MBuff.BuffNames.StrengthBuff, MBuff.BuffNames.ResistBuff };
	--smartBuff[MBuff.CareerType.Melee][MBuff.GroupType.ResistsInGroup] = { MBuff.BuffNames.StrengthBuff, MBuff.BuffNames.WillpowerBuff, MBuff.BuffNames.ResistBuff };
	--smartBuff[MBuff.CareerType.Melee][MBuff.GroupType.Other] = { MBuff.BuffNames.StrengthBuff, MBuff.BuffNames.ResistBuff, MBuff.BuffNames.WillpowerBuff };
	
	smartBuff[MBuff.CareerType.Tank] = { MBuff.BuffNames.WillpowerBuff, MBuff.BuffNames.ResistBuff, MBuff.BuffNames.StrengthBuff };
	--smartBuff[MBuff.CareerType.Tank][MBuff.GroupType.AurasInGroup] = { MBuff.BuffNames.WillpowerBuff, MBuff.BuffNames.ResistBuff, MBuff.BuffNames.StrengthBuff };
	--smartBuff[MBuff.CareerType.Tank][MBuff.GroupType.ResistsInGroup] = { MBuff.BuffNames.WillpowerBuff, MBuff.BuffNames.StrengthBuff, MBuff.BuffNames.ResistBuff };
	--smartBuff[MBuff.CareerType.Tank][MBuff.GroupType.Other] = { MBuff.BuffNames.WillpowerBuff, MBuff.BuffNames.ResistBuff, MBuff.BuffNames.StrengthBuff };
	
	smartBuff[MBuff.CareerType.Ranged] = { MBuff.BuffNames.StrengthBuff, MBuff.BuffNames.ResistBuff, MBuff.BuffNames.WillpowerBuff };
	--smartBuff[MBuff.CareerType.Ranged][MBuff.GroupType.AurasInGroup] = { MBuff.BuffNames.StrengthBuff, MBuff.BuffNames.WillpowerBuff, MBuff.BuffNames.ResistBuff };
	--smartBuff[MBuff.CareerType.Ranged][MBuff.GroupType.ResistsInGroup] = { MBuff.BuffNames.StrengthBuff, MBuff.BuffNames.WillpowerBuff, MBuff.BuffNames.ResistBuff };
	--smartBuff[MBuff.CareerType.Ranged][MBuff.GroupType.Other] = { MBuff.BuffNames.StrengthBuff, MBuff.BuffNames.ResistBuff, MBuff.BuffNames.WillpowerBuff };
	
	smartBuff[MBuff.CareerType.Caster] = { MBuff.BuffNames.StrengthBuff, MBuff.BuffNames.ResistBuff, MBuff.BuffNames.WillpowerBuff };
	--smartBuff[MBuff.CareerType.Caster][MBuff.GroupType.AurasInGroup] = { MBuff.BuffNames.StrengthBuff, MBuff.BuffNames.WillpowerBuff, MBuff.BuffNames.ResistBuff };
	--smartBuff[MBuff.CareerType.Caster][MBuff.GroupType.ResistsInGroup] = { MBuff.BuffNames.StrengthBuff, MBuff.BuffNames.WillpowerBuff, MBuff.BuffNames.ResistBuff };
	--smartBuff[MBuff.CareerType.Caster][MBuff.GroupType.Other] = { MBuff.BuffNames.StrengthBuff, MBuff.BuffNames.ResistBuff, MBuff.BuffNames.WillpowerBuff };
	
	smartBuff[MBuff.CareerType.Healer] = { MBuff.BuffNames.WillpowerBuff, MBuff.BuffNames.ResistBuff, MBuff.BuffNames.StrengthBuff };
	--smartBuff[MBuff.CareerType.Healer][MBuff.GroupType.AurasInGroup] = { MBuff.BuffNames.WillpowerBuff, MBuff.BuffNames.StrengthBuff, MBuff.BuffNames.ResistBuff };
	--smartBuff[MBuff.CareerType.Healer][MBuff.GroupType.ResistsInGroup] = { MBuff.BuffNames.WillpowerBuff, MBuff.BuffNames.StrengthBuff, MBuff.BuffNames.ResistBuff };
	--smartBuff[MBuff.CareerType.Healer][MBuff.GroupType.Other] = { MBuff.BuffNames.WillpowerBuff, MBuff.BuffNames.ResistBuff, MBuff.BuffNames.StrengthBuff };
		
end

local function UpdateSettings()

	-- in case of version setting changes
	local version = MBuff.Settings.Version;

	if (version == "1.2") then
		version = "1.2.1";
		
		MBuff.Settings.SmartBuff = nil;
	end
	
	if (type(version) == "string") then
		version = 3;
	end
	
	if (version == 3) then
		version = 4;
		
		if (MBuff.Settings.BuffsByCareer) then
			local buffsByCareer = {};
			for career, buff in pairs(MBuff.Settings.BuffsByCareer) do
				buffsByCareer[career] = buff;
			end
			MBuff.Settings.BuffsByCareer = {};
			MBuff.Settings.BuffsByCareer[GameData.Player.career.line] = buffsByCareer;
		end
		
		if (MBuff.Settings.BuffsByGroup) then
			local buffsByGroup = {};
			for index, buff in pairs(MBuff.Settings.BuffsByGroup) do
				buffsByGroup[index] = buff;
			end
			MBuff.Settings.BuffsByGroup = {};
			MBuff.Settings.BuffsByGroup[GameData.Player.career.line] = buffsByGroup;
		end
		
	end
	
	if (version == 4) then
		version = 5;
	end

	if (not MBuff.Settings.SmartBuff or not MBuff.Settings.SmartBuff[GameData.Player.career.line]) then
		SetupDefaultSmartBuff();
	end
	
end

function MBuff.LoadSettings()
	
	if (not IsSettingsValid()) then
		MBuff.Settings = nil;
	end

	if (not MBuff.Settings) then
		MBuff.Settings = {};
		MBuff.Settings.BuffsByCareer = {};
		MBuff.Settings.BuffsByGroup = {};
		MBuff.Settings.AutoSelectBuffs = true;
		
		MBuff.SaveSettings();
	end
	
	UpdateSettings();
	
	MBuff.Settings.BuffsByCareer = MBuff.Settings.BuffsByCareer or  {};
	MBuff.Settings.BuffsByCareer[GameData.Player.career.line] = MBuff.Settings.BuffsByCareer[GameData.Player.career.line] or {};
	
	for careerLine, career in pairs(MBuff.Settings.BuffsByCareer[GameData.Player.career.line]) do
		local buffId = MBuff.GetBuffFromAbilityId(career.AbilityId);
		if (MBuff.BuffsByCareer[careerLine]) then
			MBuff.BuffsByCareer[careerLine].BuffId = buffId;
		end
	end
	
	MBuff.Settings.BuffsByGroup = MBuff.Settings.BuffsByGroup or  {};
	MBuff.Settings.BuffsByGroup[GameData.Player.career.line] = MBuff.Settings.BuffsByGroup[GameData.Player.career.line] or {};
	
	for index = 1, MAX_GROUP_MEMBERS do
	
		MBuff.Settings.BuffsByGroup[GameData.Player.career.line][index] = MBuff.Settings.BuffsByGroup[GameData.Player.career.line][index] or {};
		local buffType = MBuff.Settings.BuffsByGroup[GameData.Player.career.line][index].Type;
		MBuff.BuffsByGroup[index] = {};
		
		if (buffType == MBuff.BuffType.AutoSelect) then
			MBuff.BuffsByGroup[index].BuffId = AUTOSELECT_BUFF_ID;
		elseif (buffType == MBuff.BuffType.SmartBuff) then
			MBuff.BuffsByGroup[index].BuffId = SMARTBUFF_BUFF_ID;
		else
			MBuff.BuffsByGroup[index].BuffId = MBuff.GetBuffFromAbilityId(MBuff.Settings.BuffsByGroup[GameData.Player.career.line][index].AbilityId);
		end
		
	end
	
	CheckRemembered();
	
	if (MBuff.Settings.Remembered) then
		for playerName, rememberedData in pairs(MBuff.Settings.Remembered) do
			if (rememberedData.Buff) then
				MBuff.RememberedBuff[playerName] = rememberedData.Buff;
			end
			if (rememberedData.Auras) then
				MBuff.RememberedAuras[playerName] = rememberedData.Auras;
			end
			if (rememberedData.Career) then
				MBuff.RememberedCareerType[playerName] = rememberedData.Career;
			end
		end
	end
	
	MBuff.SaveSettings();
	
	MBuffGui.SetupCareerIcons();

end

function MBuff.SaveSettings()

	MBuff.Settings.Version = VERSION_SETTINGS;
		
	MBuff.Settings.BuffsByCareer = MBuff.Settings.BuffsByCareer or {};
	MBuff.Settings.BuffsByCareer[GameData.Player.career.line] = {};
	
	for careerLine, career in pairs(MBuff.BuffsByCareer) do
		MBuff.Settings.BuffsByCareer[GameData.Player.career.line][careerLine] = {};
		MBuff.Settings.BuffsByCareer[GameData.Player.career.line][careerLine].AbilityId = MBuff.GetAbilityFromBuffId(career.BuffId);
	end
		
	MBuff.Settings.BuffsByGroup = MBuff.Settings.BuffsByGroup or {};
	MBuff.Settings.BuffsByGroup[GameData.Player.career.line] = {};
	
	for index = 1, MAX_GROUP_MEMBERS do
	
		MBuff.Settings.BuffsByGroup[GameData.Player.career.line][index] = {};
		
		local buff = nil;
		if (MBuff.BuffsByGroup[index].BuffId) then
			buff = MBuff.Buffs[MBuff.BuffsByGroup[index].BuffId];
		end
		
		if (buff) then
			if (buff.Type == MBuff.BuffType.Normal) then
				MBuff.Settings.BuffsByGroup[GameData.Player.career.line][index].AbilityId = MBuff.GetAbilityFromBuffId(MBuff.BuffsByGroup[index].BuffId);
			end
			MBuff.Settings.BuffsByGroup[GameData.Player.career.line][index].Type = buff.Type;
		end
	
	end

end

function MBuff.UpdateRemembered(playerName)

	MBuff.Settings.Remembered[playerName] = MBuff.Settings.Remembered[playerName] or {};
	local rememberedData = MBuff.Settings.Remembered[playerName];
	local hasData = false;
	local data = nil;
	
	data = MBuff.RememberedBuff[playerName];
	rememberedData.Buff = data;
	hasData = hasData or (data ~= nil);
	
	data = MBuff.RememberedAuras[playerName];
	rememberedData.Auras = data;
	hasData = hasData or (data ~= nil);
	
	data = MBuff.RememberedCareerType[playerName];
	rememberedData.Career = data;
	hasData = hasData or (data ~= nil);
	
	if (hasData) then
		UpdateRemembered(playerName);
	else
		MBuff.Settings.Remembered[playerName] = nil;
	end
			
end

function MBuff.SetupCareers()

	local careerLine = GameData.Player.career.line; 
	ignoreTarget = false;
	
	if (GameData.Player.realm == GameData.Realm.DESTRUCTION) then
	
		--destruction
		
		if (careerLine == GameData.CareerLine.ZEALOT) then
			MBuff.BuffNames = 
			{
				StrengthBuff = 8551,
				WillpowerBuff = 8556,
				ResistBuff = 8560,
				RezBuff = 8567
			};
		elseif (careerLine == GameData.CareerLine.SHAMAN) then
			MBuff.BuffNames = 
			{
				StrengthBuff = 1910,
				WillpowerBuff = 1910,
				ResistBuff = 1910,
			};
			ignoreTarget = true;
		end

		MBuff.BuffsByCareer[GameData.CareerLine.ZEALOT] = {};
		MBuff.BuffsByCareer[GameData.CareerLine.SHAMAN] = {};
		MBuff.BuffsByCareer[GameData.CareerLine.MARAUDER or GameData.CareerLine.WARRIOR] = {};
		MBuff.BuffsByCareer[GameData.CareerLine.DISCIPLE or GameData.CareerLine.BLOOD_PRIEST] = {};
		MBuff.BuffsByCareer[GameData.CareerLine.WITCH_ELF or GameData.CareerLine.ASSASSIN] = {};
		MBuff.BuffsByCareer[GameData.CareerLine.CHOPPA] = {};
		MBuff.BuffsByCareer[GameData.CareerLine.BLACKGUARD or GameData.CareerLine.SHADE] = {};
		MBuff.BuffsByCareer[GameData.CareerLine.MAGUS] = {};
		MBuff.BuffsByCareer[GameData.CareerLine.CHOSEN] = {};
		MBuff.BuffsByCareer[GameData.CareerLine.SQUIG_HERDER] = {};
		MBuff.BuffsByCareer[GameData.CareerLine.SORCERER] = {};
		MBuff.BuffsByCareer[GameData.CareerLine.BLACK_ORC] = {};

	else
		
		--order
		
		if (careerLine == GameData.CareerLine.RUNE_PRIEST) then
			MBuff.BuffNames = 
			{
				StrengthBuff = 1591,
				WillpowerBuff = 1600,
				ResistBuff = 1588,
				RezBuff = 1608
			};
		elseif (careerLine == GameData.CareerLine.ARCHMAGE) then
			MBuff.BuffNames = 
			{
				StrengthBuff = 9248,
				WillpowerBuff = 9248,
				ResistBuff = 9248,
			};
			ignoreTarget = true;
		end
		
		MBuff.BuffsByCareer[GameData.CareerLine.IRON_BREAKER] = {};
		MBuff.BuffsByCareer[GameData.CareerLine.SWORDMASTER] = {};
		MBuff.BuffsByCareer[GameData.CareerLine.WITCH_HUNTER] = {};
		MBuff.BuffsByCareer[GameData.CareerLine.WHITE_LION or GameData.CareerLine.SEER] = {};
		MBuff.BuffsByCareer[GameData.CareerLine.BRIGHT_WIZARD] = {};
		MBuff.BuffsByCareer[GameData.CareerLine.ENGINEER] = {};
		MBuff.BuffsByCareer[GameData.CareerLine.SHADOW_WARRIOR] = {};
		MBuff.BuffsByCareer[GameData.CareerLine.WARRIOR_PRIEST] = {};
		MBuff.BuffsByCareer[GameData.CareerLine.ARCHMAGE] = {};
		MBuff.BuffsByCareer[GameData.CareerLine.RUNE_PRIEST] = {};
		MBuff.BuffsByCareer[GameData.CareerLine.KNIGHT] = {};
		MBuff.BuffsByCareer[GameData.CareerLine.SLAYER] = {};
	
	end
	
	local index = 1;
	
	for careerLine, career in pairs(MBuff.BuffsByCareer)
	do
	
		career.CareerLine = careerLine;
		career.BuffId = nil;
		career.Index = index;
		index = index + 1;
	
	end
	
end

function MBuff.SetupAvailableBuffs()

	local abilityData = GetAbilityTable(GameData.AbilityType.STANDARD);
	local markAbility = "";
	local buffIndex = 3;
	
	MBuff.Buffs[AUTOSELECT_BUFF_ID] = { Type = MBuff.BuffType.AutoSelect };
	MBuff.Buffs[SMARTBUFF_BUFF_ID] = { Type = MBuff.BuffType.SmartBuff };
	
	for index, abilityId in pairs(abilityIds) do
	
		abilityKeys[abilityId] = true;
		local ability = abilityData[abilityId];
		
		if (ability) then

			MBuff.Buffs[buffIndex] = {};
			MBuff.Buffs[buffIndex].Type = MBuff.BuffType.Normal;
			MBuff.Buffs[buffIndex].Name = ability.name;
			MBuff.Buffs[buffIndex].AbilityId = abilityId;
			MBuff.Buffs[buffIndex].IconNum = ability.iconNum;
			
			buffFromAbilityId[abilityId] = buffIndex;
			abilityFromBuffId[buffIndex] = abilityId;

			buffIndex = buffIndex + 1;
		
		end
	
	end

end

function MBuff.SetupBuffsByGroup()

	local isValid = false;

	for index = 1, MAX_GROUP_MEMBERS do
		
		MBuff.BuffsByGroup[index] = {};

	end

end

local function buffInfoCompare(itemA, itemB)

	if (not itemA) then
		return itemB;
	end
	if (not itemB) then
		return itemA;
	end
	
	if (itemA.Duration + itemB.Duration == 0 or (itemA.Duration > 0 and itemB.Duration > 0)) then
		if (itemA.IsAbilityReady == itemB.IsAbilityReady) then
			if (itemA.IgnoredTimer + itemB.IgnoredTimer == 0) then
				if (itemA.Duration == itemB.Duration) then					
					if (itemA.GroupMember.Distance and itemB.GroupMember.Distance) then
						if (itemA.GroupMember.Distance < itemB.GroupMember.Distance) then
							return itemA;
						end
					elseif (itemA.GroupMember.Distance) then
						return itemA;
					elseif (itemB.GroupMember.Distance) then
						return itemB;
					end
				elseif (itemA.Duration < itemB.Duration) then
					return itemA;
				end
			elseif (itemA.IgnoredTimer < itemB.IgnoredTimer) then
				return itemA;
			end
		else
			if (itemA.IsAbilityReady) then
				return itemA;
			end
		end
	elseif (itemA.Duration == 0) then
		return itemA;
	elseif (itemB.Duration == 0) then
		return itemB;
	end
	
	return itemB;

end

function MBuff.GetBuffInfo()

	local unbuffedCount = 0;
	local shortestCooldown = nil;
	
	local buffInfo = nil;
	
	for index = 1, MAX_GROUP_MEMBERS
	do

		local groupMember = LibGroup.GroupMembers.BySlot[index];

		if (MBuff.IsGroupMemberValid(groupMember)) then

			local expectedBuff = MBuff.ExpectedBuff(groupMember);

			if (expectedBuff) then

				if (groupMember.Buff.Duration == 0) then
				
					unbuffedCount = unbuffedCount + 1;
				
				end
				
				local ignoredTimer = 0;
				if (groupMember.IgnoredUntil) then
					ignoredTimer = math.max(groupMember.IgnoredUntil - MBuff.TimeCount, 0);
				end
				
				local abilityCooldown = MBuff.GetAbilityCooldown(MBuff.Buffs[expectedBuff].AbilityId);
				local data = 
				{ 
					Duration = groupMember.Buff.Duration,
					GroupMember = groupMember,
					IconNum = MBuff.Buffs[expectedBuff].IconNum,
					IgnoredTimer = ignoredTimer,
					IsAbilityReady = (abilityCooldown == 0)
				};
				
				if (not data.Duration) then
					data.Duration = 0;
				end
				
				if (not shortestCooldown or abilityCooldown < shortestCooldown) then
					shortestCooldown = abilityCooldown;
				end
				
				buffInfo = buffInfoCompare(data, buffInfo);

			end

		end

	end
	
	if (shortestCooldown and shortestCooldown > 0 and (not nextCooldownUpdate or shortestCooldown < nextCooldownUpdate - MBuff.TimeCount)) then
		nextCooldownUpdate = MBuff.TimeCount + shortestCooldown;
	end
				
	if (not buffInfo) then
		buffInfo = {};
	end

	return buffInfo.GroupMember, buffInfo.Duration, buffInfo.IconNum, unbuffedCount;

end

function MBuff.IsProperCareer()

	return (GameData.Player.career.line == GameData.CareerLine.ZEALOT or GameData.Player.career.line == GameData.CareerLine.RUNE_PRIEST or
		GameData.Player.career.line == GameData.CareerLine.SHAMAN or GameData.Player.career.line == GameData.CareerLine.ARCHMAGE);

end

function MBuff.OnZoneChange()

	for index = 1, MAX_GROUP_MEMBERS do
	
		local groupMember = LibGroup.GroupMembers.ByIndex[index];
		
		if (groupMember and groupMember.Buff) then
		
			groupMember.Buff.LastUpdate = nil;
		
		end
	
	end

end

function MBuff.OnPlayerAbilityLearned()

	if (not MBuff.IsLoaded) then return end;
	
	local buffCount = #MBuff.Buffs;
	
	MBuff.SaveSettings(); -- save the current settings
	MBuff.SetupAvailableBuffs();
	
	if (#MBuff.Buffs == buffCount) then
	
		return;
	
	end
	
	MBuff.LoadSettings(); -- load setting into the new buff structure
	
	MBuffGui.SetupGui();
	
	MBuff.ResetSmartBuffGroupInfo();
	
end

function MBuff.OnLoadComplete()
	
	if (MBuff.IsLoaded) then return end
	if (not MBuff.IsProperCareer()) then 

		MBuff.Unload();
		return;

	end

	RegisterLibs();

    playersName = GameData.Player.name:match(L"([^^]+)^?([^^]*)");
	
	MBuff.SetupBuffsByGroup();
	MBuff.SetupCareers();
	MBuff.SetupAvailableBuffs();
	
	MBuff.LoadSettings();
	
	MBuffGui.Initialize();
	MBuffSetup.SmartBuff.Initialize();
	
	WindowSetShowing(MBuffGui.Elements.Windows.BuffBar, true);
		
	MBuff.IsLoaded = true;

end

function MBuff.Target()

	MBuff.ClearAction();

	if (selectedBuffTarget) then
	
		MBuff.TargetPlayer(selectedBuffTarget.Name);
	
	end

end

function MBuff.SetAction()
		
	if (selectedBuffTarget and (MBuff.CurrentTarget == selectedBuffTarget.Name or ignoreTarget)) then
			
		local expectedBuff = selectedBuffTarget.ExpectedBuff;
		if (not expectedBuff) then return end
		
		local actionId = MBuff.Buffs[expectedBuff].AbilityId;
		local actionType = GameData.PlayerActions.DO_ABILITY;
	
		local valid, selected = IsTargetValid(actionId);
		
		if (not valid) then
		
			local groupMember = LibGroup.GroupMembers.ByName[selectedBuffTarget.Name];
			
			if (groupMember) then -- and (not groupMember.IgnoredUntil or MBuff.TimeCount >= groupMember.IgnoredUntil)
			
				groupMember.IgnoredUntil = MBuff.TimeCount + IGNORE_GROUPMEMBER_BUFF_TIME;
				
				MBuff.ClearAction();
				flagBarUpdate = true;
				
				return;
			
			end
			
		elseif (groupMember and groupMember.IgnoredUntil) then
		
			groupMember.IgnoredUntil = nil;
		
		end
		
		if (actionId) then
			WindowSetGameActionTrigger(MBuffGui.Elements.Windows.BuffBar, actionId);
			WindowSetGameActionData(MBuffGui.Elements.Windows.BuffBar, actionType, actionId, L"");
			
			WindowSetGameActionTrigger(MBuffGui.Elements.Windows.BuffBarTarget, actionId);
			WindowSetGameActionData(MBuffGui.Elements.Windows.BuffBarTarget, actionType, actionId, L"");
		end
		
	else
	
		MBuff.ClearAction();
	
	end

end

function MBuff.ClearAction()
	
	if (selectedBuffTarget and selectedBuffTarget.Name) then
	
		WindowSetGameActionData(MBuffGui.Elements.Windows.BuffBar, GameData.PlayerActions.SET_TARGET, 0, selectedBuffTarget.Name)
		WindowSetGameActionData(MBuffGui.Elements.Windows.BuffBarTarget, GameData.PlayerActions.SET_TARGET, 0, selectedBuffTarget.Name)
	
	else

		local actionId = 0;
		local actionType = GameData.PlayerActions.NONE;
	
		WindowSetGameActionTrigger(MBuffGui.Elements.Windows.BuffBar, actionId);
		WindowSetGameActionData(MBuffGui.Elements.Windows.BuffBar, actionType, actionId, L"");
			
		WindowSetGameActionTrigger(MBuffGui.Elements.Windows.BuffBarTarget, actionId);
		WindowSetGameActionData(MBuffGui.Elements.Windows.BuffBarTarget, actionType, actionId, L"");
	
	end

end

function MBuff.TargetPlayer(unitname)
	
	if (not unitname or unitname == L"") then return end
	
	if (unitname == MBuff.CurrentTarget or ignoreTarget) then --target is already selected
	
		MBuff.SetAction();
	
	else
	   
		--pre 1.3.6
		--SystemData.UserInput.ChatText = L"/target " .. unitname;
		--BroadcastEvent(SystemData.Events.SEND_CHAT_TEXT);
		
		SendChatText(L"/target " .. unitname, L"");
		
	end

end

function MBuff.GetCareerTypes(careerLine)

	if (careerLine == GameData.CareerLine.IRON_BREAKER
		or careerLine == GameData.CareerLine.SWORDMASTER
		or careerLine == GameData.CareerLine.CHOSEN
		or careerLine == GameData.CareerLine.BLACK_ORC
		or careerLine == (GameData.CareerLine.BLACKGUARD or GameData.CareerLine.SHADE)
		or careerLine == GameData.CareerLine.KNIGHT) then
		
		return { MBuff.CareerType.Melee, MBuff.CareerType.Tank };
		
	elseif (careerLine == GameData.CareerLine.WITCH_HUNTER
		or careerLine == (GameData.CareerLine.WHITE_LION or GameData.CareerLine.SEER)
		or careerLine == (GameData.CareerLine.MARAUDER or GameData.CareerLine.WARRIOR)
		or careerLine == (GameData.CareerLine.WITCH_ELF or GameData.CareerLine.ASSASSIN)
		or careerLine == GameData.CareerLine.CHOPPA
		or careerLine == GameData.CareerLine.SLAYER) then
		
		return { MBuff.CareerType.Melee };
		
	elseif (careerLine == GameData.CareerLine.ENGINEER
		or careerLine == GameData.CareerLine.SQUIG_HERDER
		or careerLine == GameData.CareerLine.SHADOW_WARRIOR) then
		
		return { MBuff.CareerType.Ranged };
		
	elseif (careerLine == GameData.CareerLine.BRIGHT_WIZARD
		or careerLine == GameData.CareerLine.MAGUS
		or careerLine == GameData.CareerLine.SORCERER) then
		
		return { MBuff.CareerType.Caster };
		
	elseif (careerLine == GameData.CareerLine.WARRIOR_PRIEST
		or careerLine == (GameData.CareerLine.DISCIPLE or GameData.CareerLine.BLOOD_PRIEST)) then
		
		return { MBuff.CareerType.Healer, MBuff.CareerType.Melee };
		
	elseif (careerLine == GameData.CareerLine.ARCHMAGE
		or careerLine == GameData.CareerLine.SHAMAN
		or careerLine == GameData.CareerLine.RUNE_PRIEST
		or careerLine == GameData.CareerLine.ZEALOT) then
		
		return { MBuff.CareerType.Healer, MBuff.CareerType.Caster };
		
	end
	
	return { MBuff.CareerType.Melee };

end

function MBuff.GetCareerType(careerLine)

	local careerType = MBuff.GetCareerTypes(careerLine);
	
	return careerType[1];

end

local function SmartBuffSelectBuff(priorityBuffs, availableBuffs)

	for index, abilityId in ipairs(priorityBuffs) do
	
		if (availableBuffs[abilityId]) then
			return abilityId;
		end
	
	end
	
	return nil;

end

local function GetPriority(weightings, list)

	if (not list) then
		list = {};
	end
	if (not weightings) then
		return list;
	end

	local record = { AbilityId = nil, Max = nil };
	local count = 0;
	
	for abilityId, weighting in pairs(weightings) do
		if (not record.Max or weighting > record.Max) then
			record.Max = weighting;
			record.AbilityId = abilityId;
		end
		count = count + 1;
	end
	
	if (record.AbilityId) then
		weightings[record.AbilityId] = nil;
		table.insert(list, record.AbilityId);
	else
		count = 0;
	end
	
	if (count <= 1) then
		weightings = nil;
	end
	
	return GetPriority(weightings, list);

end

local function SmartBuffForMember(groupMember, availableBuffs)

	local type = MBuff.RememberedCareerType[groupMember.Name];
	if (not type) then
		type = MBuff.GetCareerType(groupMember.CareerLine);
	end
	
	if (MBuff.RememberedBuff[groupMember.Name]) then
		return MBuff.RememberedBuff[groupMember.Name].AbilityId;
	end
	
	local smartBuff = MBuff.Settings.SmartBuff[GameData.Player.career.line];
	local groupType = MBuff.GroupType.Other;
	
	local weightings = 
	{
		[MBuff.BuffNames.StrengthBuff] = 0,
		[MBuff.BuffNames.WillpowerBuff] = 0,
		[MBuff.BuffNames.ResistBuff] = 0,
	};
	
	for index,abilityId in pairs(smartBuff[type]) do
	
		if (abilityId == MBuff.BuffNames.StrengthBuff) then
			weightings[MBuff.BuffNames.StrengthBuff] = 0 - (index - 1) / 10;
		elseif (abilityId == MBuff.BuffNames.WillpowerBuff) then
			weightings[MBuff.BuffNames.WillpowerBuff] = 0 - (index - 1) / 10;
		elseif (abilityId == MBuff.BuffNames.ResistBuff) then
			weightings[MBuff.BuffNames.ResistBuff] = 0 - (index - 1) / 10;
		end
	end
	
	if (type == MBuff.CareerType.Melee or type == MBuff.CareerType.Tank) then
		if (smartBuffGroupInfo.StrengthAuraInGroup) then
			weightings[MBuff.BuffNames.StrengthBuff] = weightings[MBuff.BuffNames.StrengthBuff] - 1;
		end
	end
	
	if (smartBuffGroupInfo.ResistsAuraInGroup) then
		weightings[MBuff.BuffNames.ResistBuff] = weightings[MBuff.BuffNames.ResistBuff] - 1;
	end
	
	if (smartBuffGroupInfo.ResistsInGroup) then
		weightings[MBuff.BuffNames.ResistBuff] = weightings[MBuff.BuffNames.ResistBuff] - 1;
	end
	
	return SmartBuffSelectBuff(GetPriority(weightings), availableBuffs);

end

local function SmartBuffGroupInfo()

	local aurasInGroup = false; -- chosen/knight
	local resistsInGroup = false; -- shaman/am
	
	local strengthAura = false;
	local resistsAura = false;
	
	for index = 1, MAX_GROUP_MEMBERS - 1 do
		local member = LibGroup.GroupMembers.ByIndex[index];
		if (member.IsValid) then
			if (member.CareerLine == GameData.CareerLine.CHOSEN or member.CareerLine == GameData.CareerLine.KNIGHT) then
			
				local rememberedAuras = MBuff.RememberedAuras[member.Name];
				if (rememberedAuras) then
					strengthAura = strengthAura or (rememberedAuras.Strength == true);
					resistsAura = resistsAura or (rememberedAuras.Resists == true);
				else
					strengthAura = true;
					resistsAura = true;
				end
				
			elseif (not resistsInGroup and member.CareerLine == GameData.CareerLine.SHAMAN or member.CareerLine == GameData.CareerLine.ARCHMAGE) then
				resistsInGroup = true;
			end
		end
	end

	return { ResistsInGroup = resistsInGroup, StrengthAuraInGroup = strengthAura, ResistsAuraInGroup = resistsAura };

end

function MBuff.SmartBuff(groupMember)

	if (not smartBuffGroupInfo) then
		smartBuffGroupInfo = SmartBuffGroupInfo();
	end
	
	local availableBuffs = {};
	for index, buff in pairs(MBuff.Buffs) do
		if (buff.Type == MBuff.BuffType.Normal) then
			availableBuffs[buff.AbilityId] = index;
		end
	end
	
	local buffCache = MBuff.BuffCache[groupMember.Name];
	if (not buffCache) then
		return nil;
	end
	
	-- remove the buffs that others may have cast
	for index, buff in pairs(buffCache) do
		if (not buff.CastByPlayer) then
			availableBuffs[buff.AbilityId] = nil;
		end
	end
	
	local smartBuff = SmartBuffForMember(groupMember, availableBuffs);
	
	if (smartBuff) then
		return MBuff.GetBuffFromAbilityId(smartBuff);
	end
	
	return nil;

end

local function GetExpectedBuff(groupMember)

	--return the buff that the career/group slot should have
	if (not groupMember) then return end

	if (MBuff.Settings.AutoSelectBuffs) then

		if (not groupMember.IsValid) then return end
	
		local career = MBuff.BuffsByCareer[groupMember.CareerLine];
		if (not career) then return nil end
		return career.BuffId;

	else
	
		local index = 1;
	
		if (MBuff.SortGroupBy == SORT_INDEX) then
			index = groupMember.Index;
		elseif (MBuff.SortGroupBy == SORT_SLOT) then
			index = groupMember.Slot;
		end
		
		local buff = MBuff.Buffs[MBuff.BuffsByGroup[index].BuffId];
		
		if (buff) then
			if (buff.Type == MBuff.BuffType.AutoSelect) then
			
				local career = MBuff.BuffsByCareer[groupMember.CareerLine];
				if (not career) then return nil end
				return career.BuffId;
			
			elseif (buff.Type == MBuff.BuffType.SmartBuff) then
			
				return MBuff.SmartBuff(groupMember);
			
			end
		end
	
		return MBuff.BuffsByGroup[index].BuffId;
	
	end
	
end

function MBuff.ExpectedBuff(groupMember, forceReset)

	if (not groupMember) then return end

	if (not groupMember.ExpectedBuff or forceReset) then
		groupMember.ExpectedBuff = GetExpectedBuff(groupMember);
	end
	
	return groupMember.ExpectedBuff;
	
end

local function IsBuffDataValid(buffData)
	for k,v in pairs(buffData) do
		return true;
	end
	
	return false;
end

function MBuff.UpdateBuffs()

	for index = 1, MAX_GROUP_MEMBERS do
		
		local groupMember = LibGroup.GroupMembers.ByIndex[index];
		
		if (MBuff.IsGroupMemberValid(groupMember) and groupMember.Buff) then
		
			if (not groupMember.Buff.LastUpdate or (MBuff.TimeCount - groupMember.Buff.LastUpdate) > BUFF_FULL_UPDATE_POLL) then
			
				local buffTargetType = GameData.BuffTargetType.GROUP_MEMBER_START + index - 1;
				if (index == MAX_GROUP_MEMBERS) then
					buffTargetType = MAX_GROUP_MEMBERS;
				end
				
				local buffData = GetBuffs(buffTargetType);
								
				if (buffData and IsBuffDataValid(buffData)) then
					MBuff.UpdateGroupMemberBuffs(groupMember, buffData, true);
				end
			
			end
		
		end
		
		if (flagBuffUpdate and groupMember.IsValid and groupMember.Buff) then
			MBuff.UpdateBuff(groupMember);
		end
		
		MBuff.UpdateMemberBuffDuration(groupMember);
		
	end

	flagBuffUpdate = false;

end

function MBuff.UpdateBuff(groupMember)

	if (not groupMember) then return end

	local expectedBuff = MBuff.ExpectedBuff(groupMember);
	local buffCache = MBuff.BuffCache[groupMember.Name];
	
	if (not expectedBuff) then
		flagBarUpdate = true;
		return;
	end
	
	if (not buffCache) then return end
			
	for index,buff in pairs(buffCache) do
		
		if (buff.AbilityId == MBuff.Buffs[expectedBuff].AbilityId and buff.CastByPlayer) then
			
			groupMember.Buff.Duration = buff.Duration;
			groupMember.Buff.BuffId = expectedBuff;
			groupMember.Buff.BuffIndex = index;
			
			flagBarUpdate = true;
			
			return;
			
		end
	
	end
	
	--no matching buff was found
	MBuff.PurgeGroupMemberBuffData(groupMember);
	
	flagBarUpdate = true;

end

function MBuff.BuffsChanged()

	for index, groupMember in ipairs(LibGroup.GroupMembers.ByIndex) do
		groupMember.ExpectedBuff = nil;
	end

	flagBuffUpdate = true;

end

function MBuff.FindBuffIndexFromCache(groupMember)

	if (not groupMember.IsValid) then return end

	local expectedBuff = MBuff.ExpectedBuff(groupMember);
	if (not MBuff.BuffCache[groupMember.Name] or not expectedBuff) then return end
	
	for index,buff in pairs(MBuff.BuffCache[groupMember.Name]) do
	
		if (buff.AbilityId == MBuff.Buffs[expectedBuff].AbilityId and buff.CastByPlayer) then
		
			return index;
		
		end
	
	end
	
end

function MBuff.UpdateMemberBuffDuration(groupMember)

	if (not groupMember or not groupMember.IsValid) then return end
	if (not MBuff.BuffCache[groupMember.Name]) then return end
	
	local buff = groupMember.Buff;
	if (not buff.BuffIndex) then return end
	
	local buffCache = MBuff.BuffCache[groupMember.Name][buff.BuffIndex];
	
	if (not buffCache) then
		
		MBuff.PurgeGroupMemberBuffData(groupMember);
			
		flagBarUpdate = true;
		
	else
	
		if (not buffCache.TimeAdded) then return end
	
		buff.Duration = buffCache.Duration - (MBuff.TimeCount - buffCache.TimeAdded);
		
		if (buff.Duration <= 0) then
		
			MBuff.PurgeGroupMemberBuffData(groupMember);
			
			flagBarUpdate = true;
		
		end
	
	end
	
	
end

function MBuff.IsGroupMemberValid(groupMember)

	if (not groupMember or not groupMember.IsOnline or not groupMember.IsValid or (groupMember.IsDistant and not groupMember.Distance) or not groupMember.IsAlive) then
		
		return false;

	end

	return true;

end

function MBuff.IsGroupMemberBuffed(index)

	local groupMember = LibGroup.GroupMembers.ByIndex[index];

	if (not MBuff.IsGroupMemberValid(groupMember)) then
		
		return true;

	end

	local expectedBuff = MBuff.ExpectedBuff(groupMember);

	if (not expectedBuff or groupMember.Buff.BuffId and groupMember.Buff.BuffId == expectedBuff and groupMember.Buff.Duration > 0) then

		return true;

	end

	return false;

end

-- fire everytime a target is updated
function MBuff.UpdateBuffBar()

	local selectedMember, shortestDuration, iconNum, unbuffedCount = MBuff.GetBuffInfo();
	
	if (not flagBuffLock and selectedMember) then
	
		selectedBuffTarget.Name = selectedMember.Name;
		selectedBuffTarget.ExpectedBuff = MBuff.ExpectedBuff(selectedMember);

	end
	
	buffBarTimer = { Duration = shortestDuration, StartTime = MBuff.TimeCount };
	MBuffGui.SetTimerText(shortestDuration);
	MBuffGui.SetUnbuffedText(unbuffedCount);
	MBuffGui.SetBuffTarget(selectedMember);

	if (iconNum) then

		MBuffGui.SetBuffSpellIcon(iconNum);
		WindowSetShowing(MBuffGui.Elements.Images.SpellIcon, true);
	
	else
	
		WindowSetShowing(MBuffGui.Elements.Images.SpellIcon, false);
	
	end

end

function MBuff.UpdateTimer()

	local shortestDuration = nil;
	
	if (buffBarTimer.Duration) then
		shortestDuration = buffBarTimer.Duration - (MBuff.TimeCount - buffBarTimer.StartTime);
		if (shortestDuration < 0) then
			shortestDuration = 0;
		end
	end

	MBuffGui.SetTimerText(shortestDuration);

end

function MBuff.PurgeGroupMemberBuffData(groupMember)

	--note that we want to keep track of the LastUpdate time, don't nil it

	if (not groupMember.Buff) then
	
		groupMember.Buff = {};
	
	end
	
	groupMember.Buff.BuffId = nil; -- this ID links to an index in MBuff.Buffs and not an abilityId
	groupMember.Buff.BuffIndex = nil
	groupMember.Buff.Duration = 0;

	groupMember.ExpectedBuff = nil; -- reset on death since buffs are wiped
			
end

function MBuff.GetAbilityCooldown(abilityId)

	SetHotbarData(TEST_HOTBAR_SLOT, GameData.PlayerActions.DO_ABILITY, abilityId);
	local cooldown = GetHotbarCooldown(TEST_HOTBAR_SLOT);
	
	if (not cooldown or cooldown < BASE_COOLDOWN) then
		return 0;
	end
	
	return cooldown; 
	
end

function MBuff.LockBuff(locked)

	flagBuffLock = locked;

end

function MBuff.GetBuffFromAbilityId(abilityId)

	return buffFromAbilityId[abilityId];

end

function MBuff.GetAbilityFromBuffId(buffId)

	return abilityFromBuffId[buffId];

end

function MBuff.OnUpdate(elapsed)

	MBuff.TimeCount = MBuff.TimeCount + elapsed;
	if (not MBuff.IsLoaded) then return end
	
	if (nextCooldownUpdate and MBuff.TimeCount > nextCooldownUpdate) then
		nextCooldownUpdate = nil;
		flagBarUpdate = true;
	end
	
	throttleTime = throttleTime - elapsed;
	if (throttleTime <= 0) then 
	
		throttleTime = UPDATE_THROTTLE;
		
		MBuff.UpdateBuffs();
		MBuff.UpdateTimer();
		
	end
	
	barThrottleTime = barThrottleTime - elapsed;
	if (flagBarUpdate and not flagBuffLock and barThrottleTime <= 0) then
	
		MBuff.UpdateBuffBar();
		
		barThrottleTime = BAR_UPDATE_THROTTLE;
		flagBarUpdate = false;
	
	end

end