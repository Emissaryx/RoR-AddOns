KeyBar = {}

local TIME_DELAY = 0.1
local timeLeft = TIME_DELAY

local c_NUMBEROFSLOTS = 8
local c_MAXELEMENTSPERSLOT = 4
local c_DEFAULT_FADEIN_TIMER = 0.05
local c_DEFAULT_FADEOUT_TIMER = 0.1
local EmptyIcon = 20
local PlayerName = wstring.sub(GameData.Player.name,1,-3)
local SetButton = 0
local KeyIsPressed = false
local KeyIsReleased = true
local ForceClose = false
local newSlotSelected = true
local ForceRefresh = true

local SnapRotation = {}
local CachedItems = {} --hold items we want to track
local CurrentButtonIndex = {}
local CurrentConfigIndex = 1


local DefaultSettings = 
	{
		CloseOnUse = false,
		OpenAtMousePosition = true,
		AnimationFollowMouse = false,
		RGBA = {255, 255, 40, 0.5}
	}

KeyBar = {m_IsShowing = false,}

--this will run on start
function KeyBar.OnInitialize()

	PlayerName = wstring.sub(GameData.Player.name,1,-3)
	CreateWindow("KeyBarWindow", true)
	WindowSetAlpha("KeyBarWindow",0)

    RegisterEventHandler (SystemData.Events.PLAYER_HOT_BAR_UPDATED,                 "KeyBar.UpdateMacros")
    -- RegisterEventHandler (SystemData.Events.PLAYER_HOT_BAR_PAGE_UPDATED,            "KeyBar.UpdateMacros")
    RegisterEventHandler (SystemData.Events.MACRO_UPDATED,                          "KeyBar.UpdateMacros")
    RegisterEventHandler (SystemData.Events.PLAYER_INVENTORY_SLOT_UPDATED,          "KeyBar.OnUpdateInventory")

	-- Set default settings
	if not KeyBar.Settings then KeyBar.Settings = DefaultSettings end
	
	WindowSetTintColor("KeyBarWindowSelector",KeyBar.Settings.RGBA[1],KeyBar.Settings.RGBA[2],KeyBar.Settings.RGBA[3])
	
	if not KeyBar.Button then KeyBar.Button = {} end
	if not KeyBar.Button[PlayerName] then 
		KeyBar.Button[PlayerName] = {} 
		
		for i=1,c_NUMBEROFSLOTS do
			KeyBar.Button[PlayerName][i] = {}
			for j=1,c_MAXELEMENTSPERSLOT do
				KeyBar.Button[PlayerName][i][j] = {Type=0,ID=0,iconNum=EmptyIcon}
			end
		end
		KeyBar.Button[PlayerName][0] = {}
		KeyBar.Button[PlayerName][0][1] = {Type=99,ID=0,iconNum=EmptyIcon}
	end
	CurrentButtonIndex[0] = 1
	--set icon for middle button here, it never changes.
	CircleImageSetTexture("KeyBarWindowButton0Icon","icon000050",32,32)
	
	for i=1,c_NUMBEROFSLOTS do
		WindowSetTintColor("KeyBarWindowButton"..i.."AbilityCooldown",0,0,0)
		WindowSetAlpha("KeyBarWindowButton"..i.."AbilityCooldown",0)
	end	

	KeyBar.ShowIndexSelector(false)
	
	KeyBar.OnUpdateInventory(nil)
	
	KeyBar.UpdateAllCurrentIndex()

	KeyBar.KeySlots = {}
	KeyBar.UpdateMacros()
	KeyBar.Hide ()
end

function KeyBar.ShowIndexSelector(visible)
	local alpha = 0
	if(visible) then
		alpha = 1
	end
	
	local currentAlpha = WindowGetAlpha("KeyBarWindowIndexSelect")
	if(currentAlpha == 0 and visible) then
		-- we just opened the config meny 
		CurrentConfigIndex = 1
		LabelSetText("KeyBarWindowIndexSelectCurrentPageText", towstring(CurrentConfigIndex))
		--KeyBar.OnUpdateInventory()
	elseif (currentAlpha == 1 and not visible) then
		--we just closed
		LabelSetText("KeyBarWindowIndexSelectCurrentPageText", towstring(""))
		KeyBar.FixSlotIndexOrder()
	else
		return
	end
	WindowSetAlpha("KeyBarWindowIndexSelect",alpha)
	WindowSetHandleInput("KeyBarWindowIndexSelect", visible)
end

function KeyBar.UpdateAllCurrentIndex()
	for i=1,c_NUMBEROFSLOTS do
		KeyBar.UpdateCurrentIndex(i)
	end
end

function KeyBar.UpdateCurrentIndex(slot)

	if(slot < 1 or slot > c_NUMBEROFSLOTS) then return end
	
	local oldIndex = CurrentButtonIndex[slot]
	local currentIndex = 1
	local lowestCooldown = nil
	
	local done = false

	
	for i=1,c_MAXELEMENTSPERSLOT do
		if (not done) then
			if (KeyBar.Button[PlayerName][slot][i].Type == 0) then
				done = true
			elseif KeyBar.Button[PlayerName][slot][i].Type == 1 then
				local Current,Max  = LibCooldown.GetAbilityCooldown(KeyBar.Button[PlayerName][slot][i].ID)
				if (Current == 0) then
					currentIndex = i
					done = true
				else
					if(lowestCooldown == nil or Current < lowestCooldown) then
						currentIndex = i
						lowestCooldown = Current
					end
				end
			elseif KeyBar.Button[PlayerName][slot][i].Type == 2 then
				
				local item = CachedItems[KeyBar.Button[PlayerName][slot][i].ID][1]
				local ItemFound = (item ~= nil and item ~= 0)

				if(ItemFound) then
				
					local onCooldown = CachedItems[KeyBar.Button[PlayerName][slot][i].ID][4]
					if(onCooldown) then --item is on cd, check if it's done
						local Current,Max = LibCooldown.GetItemCooldown(KeyBar.Button[PlayerName][slot][i].ID)
						
						if (Current == 0) then --no longer on cd
							CachedItems[KeyBar.Button[PlayerName][slot][i].ID][4] = false
							currentIndex = i
							done = true
						elseif(lowestCooldown == nil or Current < lowestCooldown) then
							currentIndex = i
							lowestCooldown = Current
						end
					else
						--not on cd
						currentIndex = i
						done = true
					end

				end
			else
				currentIndex = i
				done = true
			end
		else
			break
		end
		
	end

	CurrentButtonIndex[slot] = currentIndex
	
	if(currentIndex ~= oldIndex) then
		--KeyBar.UpdateInventory(slot)
		WindowSetAlpha("KeyBarWindowButton"..slot.."AbilityCooldown", 0)
	end

end

local function _ConfigWindowIsOpen()
	
	local visible =
		WindowGetShowing("AbilitiesWindow") or
		WindowGetShowing("EA_Window_Backpack") or
		WindowGetShowing("EA_Window_Macro")

	return visible
end

function KeyBar.OnUpdateInventory(slotNr)
	
	--ItemDataCache = DataUtils.GetItems() --refresh cache
	
	if (slotNr == nil) then --update all
		CachedItems = {}
		for i=1,c_NUMBEROFSLOTS do
			for j=1,c_MAXELEMENTSPERSLOT do
				KeyBar.UpdateInventory(i,j)
			end
		end
		return
	end

	for k,v in pairs(CachedItems) do
		local item, loc, backpackSlot = DataUtils.FindItem(k)
		
		local onCooldown = false
		if (item.bonus ~= nil) then
			onCooldown = item.bonus[1].cooldownTimeLeft > 0
		end
		
		if(item ~= nil) then
			CachedItems[k] = {item, backpackSlot, loc, onCooldown}
		else
			CachedItems[k] = {0, nil, nil, onCooldown} -- means we have no items left
		end
	end	
end

function KeyBar.UpdateInventory(slotNr, index)

	if(KeyBar.Button[PlayerName][slotNr][index].Type == 2) then
		--do the item exist in inventory?
		local itemId = KeyBar.Button[PlayerName][slotNr][index].ID
		local item, loc, backpackSlot = DataUtils.FindItem(itemId)
		
		local onCooldown = false
		if (item.bonus ~= nil) then
			onCooldown = item.bonus[1].cooldownTimeLeft > 0
		end
		
		if(item ~= nil) then
			CachedItems[itemId] = {item, backpackSlot, loc, onCooldown}
		else
			CachedItems[itemId] = {0, nil, nil, onCooldown} -- means we have no items left
		end
	end

end

local function _FormatCoolDownText(coolDownTime)
	if (coolDownTime < 0) then
		coolDownTime = 0
	end
	if (coolDownTime < 6) then
		return towstring(string.format("%.1f", coolDownTime))
	end
	
	return towstring(TimeUtils.FormatTimeCondensed(coolDownTime))
end

function KeyBar.IndexSelectUp()
	CurrentConfigIndex = CurrentConfigIndex + 1
	if(CurrentConfigIndex > c_MAXELEMENTSPERSLOT) then
		CurrentConfigIndex = c_MAXELEMENTSPERSLOT
	end
	
	LabelSetText("KeyBarWindowIndexSelectCurrentPageText", towstring(CurrentConfigIndex))
	ForceRefresh = true
	KeyBar.Show()
end

function KeyBar.IndexSelectDown()
	CurrentConfigIndex = CurrentConfigIndex - 1
	if(CurrentConfigIndex < 1) then
		CurrentConfigIndex = 1
	end
	
	LabelSetText("KeyBarWindowIndexSelectCurrentPageText", towstring(CurrentConfigIndex))
	ForceRefresh = true
	KeyBar.Show()
end

function KeyBar.LButtonUp()
	KeyBar.OnLButtonUp(true)
end

local function _GetUniqueID(backpackSlot)
	
	local ItemData = DataUtils.GetItems()
	local item = ItemData[backpackSlot]
	
	if(item ~= nil) then
		return item.uniqueID
	end
	
	return false
end

function KeyBar.OnLButtonUp(clickedByMouse)

	if(ForceClose and not clickedByMouse) then return end
	
	local ButtonName        = SystemData.MouseOverWindow.name
	local ButtonNumber 		= tonumber(string.match(tostring(ButtonName),"(%d+)")) or SetButton	
	local allowedToUse 		= true
	ForceRefresh 			= true
	
	local configMode = _ConfigWindowIsOpen()
	local slotIndex = CurrentButtonIndex[ButtonNumber]
	
	if (configMode) then
		slotIndex = CurrentConfigIndex
	end
	
	if (not Cursor.IconOnCursor()) then
		
		if(configMode) then return end

		--Items dont seem to use Button actions, rather using Broadcast, so if it is an item do this:
		if KeyBar.Button[PlayerName][ButtonNumber][slotIndex].Type == 1 then
		--KeyBar.Button[PlayerName][i].HotBarSlot = u
			local Current,Max  = LibCooldown.GetAbilityCooldown(KeyBar.Button[PlayerName][ButtonNumber][slotIndex].ID)
			if Current > 0 then
				allowedToUse = false
				CooldownDisplaySetCooldown("KeyBarWindowButton"..ButtonNumber.."AbilityCooldown", Current, Max )
				LabelSetText("KeyBarWindowButton"..ButtonNumber.."TimeValue",_FormatCoolDownText(Current))		 --TimeUtils.FormatTimeCondensed											 
				WindowSetAlpha("KeyBarWindowButton"..ButtonNumber.."AbilityCooldown",0.75)
				WindowSetTintColor("KeyBarWindowButton"..ButtonNumber.."AbilityCooldown",0,0,0)
			else
				WindowSetAlpha("KeyBarWindowButton"..ButtonNumber.."AbilityCooldown",0)
			end

		elseif KeyBar.Button[PlayerName][ButtonNumber][slotIndex].Type == 2 then

			local item = CachedItems[KeyBar.Button[PlayerName][ButtonNumber][slotIndex].ID][1]
			local ItemFound = (item ~= nil and item ~= 0)
			
			if(ItemFound) then
				
				local CurrentItem = CachedItems[KeyBar.Button[PlayerName][ButtonNumber][slotIndex].ID][2]
				local ItemLoc = CachedItems[KeyBar.Button[PlayerName][ButtonNumber][slotIndex].ID][3]
				if(CurrentItem ~= nil) then
					SendUseItem(ItemLoc, CurrentItem, 0, 0, 0 )
				end
				
				local Current,Max = LibCooldown.GetItemCooldown(KeyBar.Button[PlayerName][ButtonNumber][slotIndex].ID)					
				if (Current > 0) then
					allowedToUse = false
					CooldownDisplaySetCooldown("KeyBarWindowButton"..ButtonNumber.."AbilityCooldown", Current, Max )	
					LabelSetText("KeyBarWindowButton"..ButtonNumber.."TimeValue",_FormatCoolDownText(Current))
					WindowSetAlpha("KeyBarWindowButton"..ButtonNumber.."AbilityCooldown",0.75)
					WindowSetTintColor("KeyBarWindowButton"..ButtonNumber.."AbilityCooldown",0,0,0)
				else
					WindowSetAlpha("KeyBarWindowButton"..ButtonNumber.."AbilityCooldown",0)
				end
			else
				--item is missing
				allowedToUse = false
			end
			
		elseif KeyBar.Button[PlayerName][ButtonNumber][slotIndex].Type == 0 then
			CooldownDisplaySetCooldown("KeyBarWindowButton"..ButtonNumber.."AbilityCooldown", 0, 0 )
			allowedToUse = false
		elseif KeyBar.Button[PlayerName][ButtonNumber][slotIndex].Type == 99 then
			KeyBar.ForceClose()
			return
		end
		
		--KeyBar.UpdateCurrentIndex(ButtonNumber)
	else
		if(ButtonNumber > 0) then
			
			if  Cursor.Data.Source == 1 then
				KeyBar.Button[PlayerName][ButtonNumber][slotIndex] = {Type=1,ID=Cursor.Data.ObjectId,iconNum=Cursor.Data.IconId}
			elseif Cursor.Data.Source == 3 then
				local id = _GetUniqueID(Cursor.Data.SourceSlot)
				KeyBar.Button[PlayerName][ButtonNumber][slotIndex] = {Type=2,ID=id,iconNum=Cursor.Data.IconId}
				
			elseif Cursor.Data.Source == 6 then
				KeyBar.Button[PlayerName][ButtonNumber][slotIndex] = {Type=4,ID=Cursor.Data.ObjectId,iconNum=Cursor.Data.IconId}	
			end	
			
			KeyBar.UpdateInventory(ButtonNumber, slotIndex)
			KeyBar.Show()				
			Cursor.Clear()
		end
	end	
	
	if(clickedByMouse and KeyBar.Settings.CloseOnUse and allowedToUse) then
		KeyBar.ForceClose()
	end

end

function KeyBar.ForceClose()
	ForceClose = true
	KeyBar.Hide()
end

function KeyBar.RButtonUp()
	--Remove a slot and recalculate
	local configMode = _ConfigWindowIsOpen()

	if (not configMode) then
		KeyBar.ForceClose()
		return 
	end
	
	local slotIndex = CurrentButtonIndex[ButtonNumber]
	if (configMode) then
		slotIndex = CurrentConfigIndex
	end
	
	local ButtonName        = SystemData.MouseOverWindow.name
	local ButtonNumber 		= tonumber(string.match(tostring(ButtonName),"(%d+)")) or SetButton

	CooldownDisplaySetCooldown("KeyBarWindowButton"..ButtonNumber.."AbilityCooldown", 0, 0 )		
	if ButtonNumber ~= 0 then
		
		KeyBar.Button[PlayerName][ButtonNumber][slotIndex] = {Type=0,ID=0,iconNum=EmptyIcon}
		KeyBar.UpdateInventory(ButtonNumber, slotIndex)
		WindowSetAlpha("KeyBarWindowButton"..ButtonNumber.."AbilityCooldown", 0)
		KeyBar.Show()
	else
		KeyBar.Button[PlayerName][ButtonNumber][slotIndex] = {Type=99,ID=0,iconNum=EmptyIcon}
	end
	ForceRefresh = true
end


function KeyBar.MouseOver(flags)
	
	local flag = false
	if flags == SystemData.ButtonFlags.SHIFT then
		flag = true
	end
	
    local ButtonName        = SystemData.MouseOverWindow.name
	local ButtonNumber 		= tonumber(string.match(tostring(ButtonName),"(%d+)")) or SetButton
	local ButtonInfoName	= L""
	local ButtonInfoDescript= L""
	local TooltipAnchor = { Point = "bottomright", RelativeTo = "CursorWindow", RelativePoint = "topleft", XOffset = 5, YOffset = 5 }

	if ButtonName == "KeyBarWindowButton0" then
		WindowSetAlpha("KeyBarWindowSelector",0)
	else
		WindowSetAlpha("KeyBarWindowSelector",0.5)
	end
	
	local configMode = _ConfigWindowIsOpen()
	local slotIndex = CurrentButtonIndex[ButtonNumber]
	if (configMode and ButtonNumber > 0) then
		slotIndex = CurrentConfigIndex
	end

	if KeyBar.Button[PlayerName][ButtonNumber][slotIndex].Type == 0 then
	--	ButtonInfoName = L"Empty Slot"
	--	ButtonInfoDescript= L"Drag and Drop an Ability/Macro/Item here"		
	elseif KeyBar.Button[PlayerName][ButtonNumber][slotIndex].Type == 1 then
		if flag then 
			Tooltips.CreateAbilityTooltip( GetAbilityData(KeyBar.Button[PlayerName][ButtonNumber][slotIndex].ID), SystemData.ActiveWindow.name, TooltipAnchor) 
		end
	elseif KeyBar.Button[PlayerName][ButtonNumber][slotIndex].Type == 2 then
		if flag then
			local ItemData = CachedItems[KeyBar.Button[PlayerName][ButtonNumber][slotIndex].ID][1]
			Tooltips.CreateItemTooltip(ItemData, SystemData.ActiveWindow.name, TooltipAnchor, true, nil, nil, true ) 
		end
	elseif KeyBar.Button[PlayerName][ButtonNumber][slotIndex].Type == 4 then
		local macros = DataUtils.GetMacros()	
		ButtonInfoName = macros[KeyBar.Button[PlayerName][ButtonNumber][slotIndex].ID].name
		ButtonInfoDescript= macros[KeyBar.Button[PlayerName][ButtonNumber][slotIndex].ID].text
	end	

	if flag and KeyBar.Button[PlayerName][ButtonNumber][slotIndex].Type == 4 then
		Tooltips.CreateTextOnlyTooltip (ButtonName)
        Tooltips.SetTooltipText (1, 1, towstring(ButtonInfoName))
        Tooltips.SetTooltipColorDef (1, 1, Tooltips.COLOR_HEADING)
        Tooltips.SetTooltipText (2, 1, towstring(ButtonInfoDescript))
        Tooltips.Finalize();
        Tooltips.AnchorTooltip( TooltipAnchor )
	end

	
	KeyBar.Show()
end

function KeyBar.MoveWindow(elapsedTime)

	if WindowGetAlpha("KeyBarWindow") < 0.1 then
		local PosX
		local PosY
		local MousePosX = SystemData.MousePosition.x
		local MousePosY = SystemData.MousePosition.y

		local startOpacity = 0;
		
		if(KeyBar.Settings.OpenAtMousePosition) then
			SystemData.MouseOverWindow.name = "KeyBarWindowButton0"
			PosX = MousePosX
			PosY = MousePosY
		else
			local ScreenWidth, ScreenHeight = GetScreenResolution()
			local CenterPosX = ScreenWidth / 2
			local CenterPosY = ScreenHeight / 2
			
			local width,height = WindowGetDimensions("KeyBarWindowButton0")
			width = width / 2
			height = height / 2
			
			-- is the mouse over the center?
			if ((MousePosX > (CenterPosX - width) and  MousePosX < (CenterPosX + width))
			 and(MousePosY > (CenterPosY - height) and  MousePosY < (CenterPosY + height))) then
				SystemData.MouseOverWindow.name = "KeyBarWindowButton0"
			else
				startOpacity = 0.5
			end
			
			PosX = CenterPosX
			PosY = CenterPosY
			
		end
		
		WindowSetAlpha("KeyBarWindowSelector",startOpacity)
		--local x,y = WindowGetOffsetFromParent("KeyBarWindow")
		local width,height = WindowGetDimensions("KeyBarWindow")
		local UIScale = InterfaceCore.GetScale()
		WindowSetOffsetFromParent("KeyBarWindow",(PosX/UIScale)-(width/2),(PosY/UIScale)-(height/2))

	end
	
	KeyBar.Show(elapsedTime)
end

function KeyBar.Show(elapsedTime)

	if WindowGetAlpha("KeyBarWindow") < 1 then
		WindowStartAlphaAnimation("KeyBarWindow", Window.AnimationType.SINGLE_NO_RESET, WindowGetAlpha("KeyBarWindow"), 1, c_DEFAULT_FADEIN_TIMER, false, 0, 0)
	end
	
	--throttle CD updates..
	if(elapsedTime ~= nil and not ForceRefresh) then
		timeLeft = timeLeft - elapsedTime
		if timeLeft > 0 then
			return -- cut out early
		end
		timeLeft = TIME_DELAY
	end

	local configMode = _ConfigWindowIsOpen()
	if(not KeyBar.m_IsShowing or configMode) then
		KeyBar.m_IsShowing      = true
		ForceRefresh			= true
		WindowSetHandleInput("KeyBarWindow", true)
	end
	
	KeyBar.ShowIndexSelector(configMode)

	for i=1,c_NUMBEROFSLOTS do	

		local slotIndex = CurrentButtonIndex[i]
		if (configMode) then
			slotIndex = CurrentConfigIndex
		else
			-- make sure nothing higher in priority has come off CD
			KeyBar.UpdateCurrentIndex(i)
			slotIndex = CurrentButtonIndex[i]

			WindowSetGameActionData("KeyBarWindowButton"..i,KeyBar.Button[PlayerName][i][slotIndex].Type,KeyBar.Button[PlayerName][i][slotIndex].ID,L"KeyBarWindow"..i)
		end
		
	    local texture, x, y, disabledTexture = GetIconData( KeyBar.Button[PlayerName][i][slotIndex].iconNum )

		CircleImageSetTexture( "KeyBarWindowButton"..i.."Icon", texture, 32, 32) 
		LabelSetText("KeyBarWindowButton"..i.."TimeValue",L"")
	
		if KeyBar.Button[PlayerName][i][slotIndex].Type == 1 then
			--KeyBar.Button[PlayerName][i].HotBarSlot = u
			
			local Current,Max  = LibCooldown.GetAbilityCooldown(KeyBar.Button[PlayerName][i][slotIndex].ID)
			if Current > 0 then
				LabelSetText("KeyBarWindowButton"..i.."TimeValue",_FormatCoolDownText(Current))
				if(WindowGetAlpha("KeyBarWindowButton"..i.."AbilityCooldown") == 0) then
					WindowSetAlpha("KeyBarWindowButton"..i.."AbilityCooldown", 0.75)
					WindowSetTintColor("KeyBarWindowButton"..i.."AbilityCooldown",0,0,0)
					CooldownDisplaySetCooldown("KeyBarWindowButton"..i.."AbilityCooldown", Current, Max )
				end
			else
				WindowSetAlpha("KeyBarWindowButton"..i.."AbilityCooldown", 0)
			end

		elseif KeyBar.Button[PlayerName][i][slotIndex].Type == 2 then
		
			local item = CachedItems[KeyBar.Button[PlayerName][i][slotIndex].ID][1]
			if (item ~= nil and item ~= 0) then
				
				local onCooldown = CachedItems[KeyBar.Button[PlayerName][i][slotIndex].ID][4]
				if(onCooldown) then
					local Current,Max = LibCooldown.GetItemCooldown(KeyBar.Button[PlayerName][i][slotIndex].ID)
					
					if(Current == 0) then -- no longer on CD
						CachedItems[KeyBar.Button[PlayerName][i][slotIndex].ID][4] = false
					end
					LabelSetText("KeyBarWindowButton"..i.."TimeValue",_FormatCoolDownText(Current))
					
					if(WindowGetAlpha("KeyBarWindowButton"..i.."AbilityCooldown") == 0) then
						WindowSetAlpha("KeyBarWindowButton"..i.."AbilityCooldown", 0.75)
						WindowSetTintColor("KeyBarWindowButton"..i.."AbilityCooldown",0,0,0)
						CooldownDisplaySetCooldown("KeyBarWindowButton"..i.."AbilityCooldown", Current, Max )
					end
				else
					WindowSetAlpha("KeyBarWindowButton"..i.."AbilityCooldown", 0)
				end
			end
		end		
	end
end


function KeyBar.Hide ()
if (_ConfigWindowIsOpen()) then return end
	if WindowGetAlpha("KeyBarWindow") > 0 then
		WindowStartAlphaAnimation("KeyBarWindow", Window.AnimationType.SINGLE_NO_RESET, WindowGetAlpha("KeyBarWindow"), 0, c_DEFAULT_FADEOUT_TIMER, false, 0, 0)	
	end
    KeyBar.m_IsShowing      = false;
	WindowSetHandleInput("KeyBarWindow", false)

end

function KeyBar.UpdateMacros()
	local MacroData = DataUtils.GetMacros()
	local MacroList = {}
	KeyBar.KeySlots = {} -- reset saved keyslots
	
	for k,v in pairs(MacroData) do
		if v.name == L"KeyBar" then
			MacroList[k] = true
		end
	end

	for i=1,GameDefs.HOTBAR_SWAPPABLE_SLOT_COUNT do
		local HotSlot = {}
		HotSlot[1],HotSlot[2],HotSlot[3],HotSlot[4],HotSlot[5] = GetHotbarData(i)
		if HotSlot[1] == 4 then
			if MacroList[HotSlot[2]] == true then	
					local Bar,Slot = ActionBarConstants:BarAndButtonFromSlot (i)
					local SlotName = "EA_ActionBar"..tostring(Bar).."Action"..tostring(Slot).."Action"
				KeyBar.KeySlots[SlotName] = true
			end
		end
	end
end

function KeyBar.FixSlotIndexOrder()
	
	for slot=1,c_NUMBEROFSLOTS do
		
		local orderedList = {}
		local elementsAdded = 0
		
		for index=1,c_MAXELEMENTSPERSLOT do
			orderedList[index] = {Type=0,ID=0,iconNum=EmptyIcon} --set default value
			
			local buttonType = KeyBar.Button[PlayerName][slot][index].Type
			if(KeyBar.Button[PlayerName][slot][index].Type ~= 0) then
				orderedList[elementsAdded+1] = KeyBar.Button[PlayerName][slot][index]
				elementsAdded = elementsAdded + 1
			end
			
			
		end
		KeyBar.Button[PlayerName][slot] = orderedList
		
	end
	
	--save changes
	--ModulesSaveSettings()
end

function KeyBar.Update(elapsedTime)
	KeyIsPressed = false
	local SlotBarName
	for k,v in pairs(KeyBar.KeySlots) do
		if (ButtonGetPressedFlag(tostring(k))) == true then
			SlotBarName = tostring(k)
			KeyIsPressed = true
		end
	end

	if (KeyIsPressed) then -- only trigger once with KeyIsReleased??
		KeyIsReleased = false
		
		if(not ForceClose) then
			KeyBar.MoveWindow(elapsedTime)
		end
	else
		
		if(KeyBar.m_IsShowing) then
			KeyBar.Hide ()
		end
		if (not KeyIsReleased) then
			KeyIsReleased = true
			
			local configMode = _ConfigWindowIsOpen()
			if(not configMode) then
				KeyBar.OnLButtonUp(false)
			end
			KeyBar.ShowIndexSelector(configMode)
			ForceClose = false
		end
	end
	
	
	if (KeyBar.m_IsShowing) then
		local MousePosX = SystemData.MousePosition.x 
		local MousePosY = SystemData.MousePosition.y
		
		
		local TargetTempWindowX,TargetTempWindowY = WindowGetScreenPosition("KeyBarWindowButton0")
		
		local WindowWidth, WindowHeight = WindowGetDimensions("KeyBarWindowButton0")
		
		local UIScale = InterfaceCore.GetScale()
		
		TargetTempWindowX = (TargetTempWindowX) + ((WindowWidth * UIScale) / 2)
		TargetTempWindowY = (TargetTempWindowY) + ((WindowHeight * UIScale) / 2)

		local xDiff = (TargetTempWindowX)-MousePosX
		local yDiff = (TargetTempWindowY)-MousePosY
		local Degrees = (math.atan2(yDiff,xDiff)*(180 / math.pi))
		
		local Degrees2 = Degrees+180
			
		local SelectorRotation = Degrees
		
		if WindowGetAlpha("KeyBarWindowSelector") > 0 then
			local degreesPerSegment = 360 / c_NUMBEROFSLOTS
			Degrees2 = Degrees2 + (degreesPerSegment / 2)
			
			if (Degrees2  < 0 ) then
				Degrees2 = 360 - Degrees2
			elseif (Degrees2  > 360) then
				Degrees2 = Degrees2 - 360
			end

			slot = math.floor(Degrees2 / degreesPerSegment) + 1
			
			newSlotSelected = SetButton ~= slot
			SetButton = slot
			
			if(not KeyBar.Settings.AnimationFollowMouse and SetButton > 0 and newSlotSelected) then
				if(SnapRotation[SetButton] ~= nil) then
					SelectorRotation = SnapRotation[SetButton]
				else
					local WindowX,WindowY = WindowGetScreenPosition("KeyBarWindowButton"..SetButton)
					local TargetWidth, TargetHeight = WindowGetDimensions("KeyBarWindowButton"..SetButton)
		
					local PosX = WindowX + ((TargetWidth * UIScale) / 2)
					local PosY = WindowY + ((TargetHeight * UIScale) / 2)
					
					xDiff = (TargetTempWindowX)-PosX
					yDiff = (TargetTempWindowY)-PosY
					Degrees = (math.atan2(yDiff,xDiff)*(180 / math.pi))
					SelectorRotation = Degrees
					SnapRotation[SetButton] = Degrees
				end
			end
		else
			newSlotSelected = true
			SetButton = 0
		end
		
		if(KeyBar.Settings.AnimationFollowMouse or newSlotSelected) then
			DynamicImageSetRotation("KeyBarWindowSelector",SelectorRotation)
		end
		
		ButtonSetHighlightFlag("KeyBarWindowButton"..SetButton,true)
		
		if (not newSlotSelected and not ForceRefresh) then return end
		ForceRefresh = false


		WindowSetGameActionData("KeyBarWindowSelector",KeyBar.Button[PlayerName][SetButton][CurrentButtonIndex[SetButton]].Type,KeyBar.Button[PlayerName][SetButton][CurrentButtonIndex[SetButton]].ID,L"KeyBarWindow0")			
			
		if (not _ConfigWindowIsOpen() and SlotBarName ~= nil) then		
			WindowSetGameActionData(SlotBarName,KeyBar.Button[PlayerName][SetButton][CurrentButtonIndex[SetButton]].Type,KeyBar.Button[PlayerName][SetButton][CurrentButtonIndex[SetButton]].ID,towstring(SlotBarName))	
		end	
		
		local ButtonName        = SystemData.MouseOverWindow.name
		local ButtonNumber 		= SetButton or tonumber(string.match(tostring(ButtonName),"(%d+)"))
		if(ButtonName == "KeyBarWindowButton0") then
			ButtonNumber = 0
		end

		for i=0,c_NUMBEROFSLOTS do
			local useDarkTint = false

			if(KeyBar.Button[PlayerName][i][CurrentButtonIndex[i]].Type == 2) then --item
				local item = CachedItems[KeyBar.Button[PlayerName][i][CurrentButtonIndex[i]].ID][1]
				
				if(item ~= nil and item == 0) then -- item is cached and was found empty
					useDarkTint = true
				end
			end

			if(not useDarkTint) then
				WindowSetTintColor("KeyBarWindowButton"..i.."Icon",150,150,150)
			else
				WindowSetTintColor("KeyBarWindowButton"..i.."Icon",75,75,75)
			end
			if ButtonNumber == i then
				if(not useDarkTint) then
					WindowSetTintColor("KeyBarWindowButton"..i.."Icon",255,255,255)
				end
			else
				ButtonSetHighlightFlag("KeyBarWindowButton"..i,false)
			end

		end		
	end
end

--this will run on exit
function KeyBar.OnShutdown()	

end

