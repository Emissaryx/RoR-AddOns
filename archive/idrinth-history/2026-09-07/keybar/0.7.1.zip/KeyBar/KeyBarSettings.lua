
-------------------
-- Settings Menu --
-------------------

KeyBarSettings = {}
KeyBarSettings.Tooltips = {}

--this will run on start
function KeyBarSettings.OnInitialize()

	if( LibSlash and LibSlash.RegisterSlashCmd ) then
        LibSlash.RegisterSlashCmd("keybar", KeyBarSettings.Slash)
	end
	
	--KeyBarSettings.OpenHelpWindow()
	--KeyBarSettings.OpenSettingsWindow()
end

function KeyBarSettings.Slash(param)
	if(param ~= nil and string.upper(param) == "HELP") then
		KeyBarSettings.OpenHelpWindow()
	else
		KeyBarSettings.OpenSettingsWindow()
	end
end

function KeyBarSettings.OpenSettingsWindow()
	local windowName = 	"KeyBarSettingsWindow"


	if(not DoesWindowExist(windowName)) then

		KeyBarSettings.Tooltips[windowName.."CloseOnUse"] = towstring("Should the keybar close when a slot is used by clicking?")
		KeyBarSettings.Tooltips[windowName.."OpenAtMouse"] = towstring("Should the keybar appear where the mouse pointer is, or in the center of the screen?")
		KeyBarSettings.Tooltips[windowName.."AnimationFollowMouse"] = towstring("With the smooth animation enabled the selection cone will follow the mouse, otherwise it will snap to the selected slot.")
		KeyBarSettings.Tooltips[windowName.."ColorLabel"] = towstring("Change the color of the selection cone.\nDefault values are 255,255,40")
		
		CreateWindow(windowName, false)

		LabelSetText(windowName.."SectionTitle", towstring("KeyBar Settings"))
		LabelSetText(windowName.."CloseOnUseLabel", towstring("Close on use"))
		LabelSetText(windowName.."OpenAtMouseLabel", towstring("Open at mouse position"))
		LabelSetText(windowName.."AnimationFollowMouseLabel", towstring("Smooth selection animation"))
		
		LabelSetText(windowName.."ColorLabel", towstring("Selection cone color"))
		LabelSetText(windowName.."ColorRLabel", towstring("R"))
		LabelSetText(windowName.."ColorGLabel", towstring("G"))
		LabelSetText(windowName.."ColorBLabel", towstring("B"))

		ButtonSetText(windowName.."SaveButton", towstring("Save"))
		ButtonSetText(windowName.."HelpButton", towstring("Help"))

	end

	if(WindowGetShowing(windowName)) then return end
	
	
	-- load default values
	local closeOnUseButton = windowName.."CloseOnUseButton"
	ButtonSetPressedFlag(closeOnUseButton, KeyBar.Settings.CloseOnUse)
	local openAtMouseButton = windowName.."OpenAtMouseButton"
	ButtonSetPressedFlag(openAtMouseButton, KeyBar.Settings.OpenAtMousePosition)
	local animationFollowMouse = windowName.."AnimationFollowMouseButton"
	ButtonSetPressedFlag(animationFollowMouse, KeyBar.Settings.AnimationFollowMouse)
	
	TextEditBoxSetText(windowName.."ColorR", towstring(KeyBar.Settings.RGBA[1]))
	TextEditBoxSetText(windowName.."ColorG", towstring(KeyBar.Settings.RGBA[2]))
	TextEditBoxSetText(windowName.."ColorB", towstring(KeyBar.Settings.RGBA[3]))
	
	WindowSetShowing(windowName, true)

end

function KeyBarSettings.OpenHelpWindow()
	local windowName = 	"KeyBarHelpWindow"

	if(not DoesWindowExist(windowName)) then

		CreateWindow(windowName, false)

		LabelSetText(windowName.."SectionTitle", towstring("KeyBar Help"))
		
		LabelSetText(windowName.."CommandsHeader", towstring("Commands"))
		LabelSetText(windowName.."CommandsText1", towstring("\"/KeyBar\"         to open settings."))
		LabelSetText(windowName.."CommandsText2", towstring("\"/KeyBar Help\" to open this window."))
		
		LabelSetText(windowName.."SetupHeader", towstring("Setup"))
		LabelSetText(windowName.."SetupText1", towstring("1. Create a empty macro named \"KeyBar\" (case sensitive)."))
		LabelSetText(windowName.."SetupText2", towstring("2. Place the macro on your hotbar and use it to activate."))
		
		LabelSetText(windowName.."UsageHeader", towstring("Usage"))
		LabelSetText(windowName.."UsageText1", towstring("Open the backpack, macro or ability window and press your"))
		LabelSetText(windowName.."UsageText2", towstring("hotkey to open KeyBar in \"Config mode\"."))
		LabelSetText(windowName.."UsageText3", towstring("While in \"Config mode\" you can drag-and-drop abilities,"))
		LabelSetText(windowName.."UsageText4", towstring("macros or items to any slot. Use right-click to remove."))
		
		LabelSetText(windowName.."UsageText5", towstring("Each slot can hold up to four items in its priority queue."))
		LabelSetText(windowName.."UsageText6", towstring("While in config mode, use the page selector in the middle to"))
		LabelSetText(windowName.."UsageText7", towstring("change which item in the queue you want to modify."))
		
		LabelSetText(windowName.."UsageText8", towstring("To use KeyBar simply press and hold the assigned hotkey,"))
		LabelSetText(windowName.."UsageText9", towstring("move the cursor to a slot and left-click to use item / ability."))
		LabelSetText(windowName.."UsageText10", towstring("You can also use the highlighted slot by releasing the hotkey."))
		
		LabelSetText(windowName.."UsageText11", towstring("If you have multiple items or abilities in the priority queue"))
		LabelSetText(windowName.."UsageText12", towstring("the first available item that is not on cooldown will always be"))
		LabelSetText(windowName.."UsageText13", towstring("shown. If all are on cooldown the lowest one will be visible."))
		
		LabelSetText(windowName.."UsageText14", towstring("To close without using anything right-click anywhere, or"))
		LabelSetText(windowName.."UsageText15", towstring("left click the center icon."))


		ButtonSetText(windowName.."OkButton", towstring("Got it!"))

		-- load default values
		WindowSetShowing(windowName, true)
	else
	
	if(WindowGetShowing(windowName)) then return end
		WindowSetShowing(windowName, true)
	end

end

function KeyBarSettings.CloseSettingsWindow()
	local windowName = "KeyBarSettingsWindow"
	WindowSetShowing(windowName, false)
end

function KeyBarSettings.CloseHelpWindow()
	local windowName = "KeyBarHelpWindow"
	WindowSetShowing(windowName, false)
end

local function _ValidateRGBValue(value)
	returnValue = 255
	local val = tonumber(value)
	if(val ~= nil) then
		val = math.floor(val)
		if(val < 0) then
			returnValue = 0
		elseif(val > 255) then
			returnValue = 255
		else
			returnValue = val
		end		
	end
	return returnValue
end

function KeyBarSettings.SaveSettingsWindow()
	local windowName = 	"KeyBarSettingsWindow"

	local closeOnUseButton = windowName.."CloseOnUseButton"
	KeyBar.Settings.CloseOnUse = ButtonGetPressedFlag(closeOnUseButton)
	
	local openAtMouseButton = windowName.."OpenAtMouseButton"
	KeyBar.Settings.OpenAtMousePosition = ButtonGetPressedFlag(openAtMouseButton)
	
	local animationFollowMouse = windowName.."AnimationFollowMouseButton"
	KeyBar.Settings.AnimationFollowMouse = ButtonGetPressedFlag(animationFollowMouse)
	
	local rValue = _ValidateRGBValue(TextEditBoxGetText(windowName.."ColorR"))
	local gValue = _ValidateRGBValue(TextEditBoxGetText(windowName.."ColorG"))
	local bValue = _ValidateRGBValue(TextEditBoxGetText(windowName.."ColorB"))

	KeyBar.Settings.RGBA = {rValue, gValue, bValue, 0.5}
	WindowSetTintColor("KeyBarWindowSelector",KeyBar.Settings.RGBA[1],KeyBar.Settings.RGBA[2],KeyBar.Settings.RGBA[3])
	
	ModulesSaveSettings()
	KeyBarSettings.CloseSettingsWindow()
end

function KeyBarSettings.CheckBoxOnLButtonUp()
	local button = SystemData.ActiveWindow.name.."Button"
	local pressed = ButtonGetPressedFlag(button)
	ButtonSetPressedFlag(button, not pressed)
end

function KeyBarSettings.CheckBoxOnMouseOver()
	local window = SystemData.ActiveWindow.name
	KeyBarSettings.MakeTooltip(window, KeyBarSettings.Tooltips[window])
end

function KeyBarSettings.MakeTooltip(window, text)
	Tooltips.CreateTextOnlyTooltip (window, text)
	Tooltips.SetTooltipColorDef (1, 1, Tooltips.COLOR_HEADING)
	Tooltips.AnchorTooltip (Tooltips.ANCHOR_WINDOW_RIGHT)
	Tooltips.Finalize ()
end



