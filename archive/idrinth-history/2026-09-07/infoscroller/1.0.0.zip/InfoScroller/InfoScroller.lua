InfoScroller = {}
local version 			= 1.0
local MAX_TICKETS 		= 24	--max displayable tickets on screen, either this or MAX_HEIGHT, witchever comes 1:st
local WAIT_TIMER 		= 0.3	--time between tickets beeing added
local TICKET_LIFE 		= 12	--time before tickets expire
local TICKET_PADDING 	= 10 	--space between tickets
local MAX_HEIGHT 		= 750	--default height of ticket window, tickets will not go past this window frame
local uiScale = InterfaceCore.GetScale()

InfoScroller.Color = {[1]={100,100,255},[2]={255,25,25}}	--Realm color
InfoScroller.InvColor = {[1]={255,25,25},[2]={100,100,255}}	--Inverted Realm color
local ALIGN_PADDING = {["left"]=10,["center"]=0,["right"]=10}

function InfoScroller.ResetSettings()
InfoScroller.Settings = {
						Orientation = "Down", 		-- Down, Up
						Alignment = "center", 		-- left, right, center
						TextAlignment = "center", 	-- left, right, center						
						Version = version,
						BGAlpha = 0.4,
						Seperator = true,
						StaticBG = false,
						ShowBG = true,
						Scale = InterfaceCore.GetScale(),
						DefaultColor = {0,0,0},
						Max_Tickets=MAX_TICKETS						
						} 
end

function InfoScroller.OnInitialize()
if(not InfoScroller.Settings) or (InfoScroller.Settings.Version < version) then InfoScroller.ResetSettings() end

	InfoScroller.Tickets		= 0
	InfoScroller.LiveTickets	= {}
	InfoScroller.TicketsQue		= {}
	InfoScroller.groupMembers 	= {}
	InfoScroller.SCROLL_TIMER 	= 0

	InfoScroller.FontAlignment = {left={"topleft","bottomleft",10,3,0,5},center={"top","bottom",0,3,0,5},right={"topright","bottomright",-10,3,0,5}}
	CreateWindow("InfoScrollerMainWindow", true)
	LayoutEditor.RegisterWindow( "InfoScrollerMainWindow", L"Scroller", L"Scroller", false, true, true, nil )
	
	LibSlash.RegisterSlashCmd("infoscroller", function(input) InfoScroller_config.Slash(input) end)
	LibSlash.RegisterSlashCmd("info", function(input) InfoScroller_config.Slash(input) end)

	--options
	InfoScroller.Register = {}
	local General = {name="General",[1]={name="combobox",title="Ticket Frame Alignment:",save="Alignment",option={"left","right","center"}},
									[2]={name="combobox",title="Text Alignment:",save="TextAlignment",option={"left","right","center"}},
									[3]={name="combobox",title="Scroll Direction Orientation:",save="Orientation",option={"Down","Up"}},
									[4]={name="textbox",title="Displayed Ticket Cap:",save="Max_Tickets"},
									[5]={name="textbox",title="Frame Scale:",save="Scale"}	
	}
	table.insert(InfoScroller.Register,General)
	
	local Colors = {name="Visual",	[1]={name="checkbox",title="Show Ticket Seperator",save="Seperator"},
									[2]={name="checkbox",title="Show Ticket Background",save="ShowBG"},
									[3]={name="checkbox",title="Use Static Background Color",save="StaticBG"},
									[4]={name="color",title="Default BG Color",save="DefaultColor"},
									[5]={name="textbox",title="Background Alpha",save="BGAlpha"}	
	}
	table.insert(InfoScroller.Register,Colors)	
end


function InfoScroller.OnShutdown()	

end


--Ticket tests
function InfoScroller.Test()
local rand = math.random(3)
	if rand == 1 then
		InfoScroller.TicketOnQue({
		BGColor={r=DefaultColor.ORANGE.r,g=DefaultColor.ORANGE.g,b=DefaultColor.ORANGE.b},
		Image={name="EA_ScenarioSummary01_d5",slice="single-skull",width=28,height=32,scale=1.3},
		[1]={text=L"DeathBlow:",color={r=255,g=150,b=25},BGColor={r=255,g=50,b=25},font="font_clear_small_bold"},
		[2]={texture={name="EA_ScenarioSummary01_d5",slice="single-skull",width=27,height=32,x=-2,y=8,anchor="left",scale=1},texture2={name="EA_ScenarioSummary01_d5",slice="single-skull",width=27,height=32,x=4,y=8,anchor="right",scale=1},text=L"      "..towstring(CreateHyperLink(L"0",L"Test-Friend", {255,75,75},{}))..L"  Killed  "..towstring(CreateHyperLink(L"0",L"Test-Enemy", {75,75,255},{}))..L"        ",color={r=255,g=255,b=255},font="font_clear_medium_bold"},
		[3]={text=L"score: 20/20",color={r=255,g=150,b=25},font="font_clear_tiny"}
		})
	
	elseif rand == 2 then
		InfoScroller.TicketOnQue({BGColor={r=DefaultColor.GREEN.r,g=DefaultColor.GREEN.g,b=DefaultColor.GREEN.b},[1]={text=L"    You Gained "..towstring(CreateHyperLink(L"0",L" 2000 Renown", {230,50,250},{}))..L" for defending "..towstring(CreateHyperLink(L"0",L"Butcher's Pass", {75,255,75},{})),texture={name="icon000045",width=16,height=16,scale=1},color={r=255,g=150,b=25},font="font_clear_small_bold"}})
	elseif rand == 3 then
		InfoScroller.TicketOnQue({BGColor={r=DefaultColor.TEAL.r,g=DefaultColor.TEAL.g,b=DefaultColor.TEAL.b},[1]={text=L"      New Mail!",texture={name="EA_HUD_01",slice="You-Have-Mail",width=28,height=29,scale=0.8,tint={75,255,75}},color={r=255,g=150,b=25},font="font_clear_small_bold"},[2]={text=L"A new mail has arrived in your mailbox",color={r=255,g=255,b=255},font="font_clear_medium_bold"}})
	end	
end

function InfoScroller.TicketOnQue(tickettable)
local TicketTable = tickettable
	table.insert (InfoScroller.TicketsQue,TicketTable)	
end

function InfoScroller.CreateCard(tickettable)
	uiScale = InfoScroller.Settings.Scale or InterfaceCore.GetScale()
	local TicketTable = tickettable
	InfoScroller.Tickets = InfoScroller.Tickets + 1
	TicketTable.ID = InfoScroller.Tickets	
	local SavedBgColor = InfoScroller.Settings.DefaultColor
	local BGColor = {r=SavedBgColor[1],g=SavedBgColor[2],b=SavedBgColor[3]}

	if InfoScroller.Settings.StaticBG == false then
		BGColor = TicketTable.BGColor or BGColor		
	end
	
	local i = TicketTable.ID	
	local TotalTicketHeight = 3
	local TotalTicketWidth = 10
	local T_ANCHOR = InfoScroller.FontAlignment[InfoScroller.Settings.TextAlignment]
	local C_ANCHOR = InfoScroller.FontAlignment[InfoScroller.Settings.Alignment]	
	
	if (not DoesWindowExist("InfoScroller_"..i)) then
		local WindowName = "InfoScroller_"..i		
				
		InfoScroller.LiveTickets[i] = {Timer=TICKET_LIFE,IsAlive=true,IsAnchored = false}
		CreateWindowFromTemplate(WindowName, "InfoScrollerTemplate", "InfoScrollerMainWindow")
		WindowSetScale(WindowName,uiScale)
		WindowSetScale("InfoScrollerMainWindow",uiScale)
	
		WindowSetShowing(WindowName.."BackGroundStart",InfoScroller.Settings.Alignment == "right" or InfoScroller.Settings.Alignment == "center")
		WindowSetShowing(WindowName.."BackGroundEnd",InfoScroller.Settings.Alignment == "left" or InfoScroller.Settings.Alignment == "center")		
		WindowSetShowing(WindowName.."BackGround",InfoScroller.Settings.ShowBG)
		WindowSetAlpha(WindowName.."BackGroundBG",InfoScroller.Settings.BGAlpha)
		WindowSetAlpha(WindowName.."BackGroundStart",InfoScroller.Settings.BGAlpha)
		WindowSetAlpha(WindowName.."BackGroundEnd",InfoScroller.Settings.BGAlpha)		
		
		if TicketTable.Image ~= nil then
			local T_Name = TicketTable.Image.name
			local width = TicketTable.Image.width or 32
			local height = TicketTable.Image.height or 32
			local scale = TicketTable.Image.scale or 1
			local alpha = TicketTable.Image.alpha or 1
			local T_X = TicketTable.Image.x or 0
			local T_Y = TicketTable.Image.y or 0
			local anchor = TicketTable.Image.anchor or "center"
			local mirror = TicketTable.Image.mirror or false
			
			WindowSetAlpha(WindowName.."Image", alpha)
			WindowSetDimensions(WindowName.."Image", width*scale, height*scale)
			DynamicImageSetTexture(WindowName.."Image",T_Name,width*scale,height*scale)


							if TicketTable.Image.slice ~= nil then
								DynamicImageSetTextureSlice(WindowName.."Image",TicketTable.Image.slice)					
							end
		

			DynamicImageSetTextureScale(WindowName.."Image",TicketTable.Image.scale)
			DynamicImageSetTextureOrientation (WindowName.."Image",mirror)
			WindowClearAnchors(WindowName.."Image")
			WindowAddAnchor(WindowName.."Image",anchor, WindowName,anchor, T_X,T_Y)			
		end
				
		--Texture_Padding.left[a]
		for a=1,#TicketTable do
			local text = TicketTable[a].text or {L""}
			local color = TicketTable[a].color or {r=255,g=255,b=255}
			local font = TicketTable[a].font or "font_clear_small_bold"
			local icon = TicketTable[a].icon or nil
			local icon2 = TicketTable[a].icon2 or nil
			local T_Texture = TicketTable[a].texture or nil	
			local T_Texture2 = TicketTable[a].texture2 or nil

				LabelSetTextColor(WindowName.."Label"..a,color.r,color.g,color.b)			
				LabelSetFont(WindowName.."Label"..a,font,WindowUtils.FONT_DEFAULT_TEXT_LINESPACING)
				LabelSetText(WindowName.."Label"..a,towstring(text))

				LabelSetTextColor(WindowName.."Label"..a,color.r,color.g,color.b)			
				LabelSetFont(WindowName.."Label"..a,font,WindowUtils.FONT_DEFAULT_TEXT_LINESPACING)
				LabelSetText(WindowName.."Label"..a,towstring(text))
				
				LabelSetFont(WindowName.."Label"..a.."BG",font,WindowUtils.FONT_DEFAULT_TEXT_LINESPACING)
				LabelSetText(WindowName.."Label"..a.."BG",LabelGetText(WindowName.."Label"..a))

				local Fontwidth,FontHeight = LabelGetTextDimensions(WindowName.."Label"..a )

				if icon ~= nil then
					local texture, _x, _y, disabledTexture = GetIconData( icon ) 
					DynamicImageSetTexture(WindowName.."Icon"..a.."LeftIcon",tostring(texture),_x,_y)
					WindowSetDimensions(WindowName.."Icon"..a.."LeftIcon", FontHeight, FontHeight)
					WindowSetDimensions(WindowName.."Icon"..a.."Left", FontHeight, FontHeight)
					DynamicImageSetTextureScale(WindowName.."Icon"..a.."LeftIcon",0.016*FontHeight )				

				end
				
				if icon2 ~= nil then
					local texture, _x, _y, disabledTexture = GetIconData( icon2 ) 
					DynamicImageSetTexture(WindowName.."Icon"..a.."RightIcon",tostring(texture),_x,_y)
					WindowSetDimensions(WindowName.."Icon"..a.."RightIcon", FontHeight, FontHeight)
					WindowSetDimensions(WindowName.."Icon"..a.."Right", FontHeight, FontHeight)
					DynamicImageSetTextureScale(WindowName.."Icon"..a.."RightIcon",0.016*FontHeight )
				
				end
	
				if T_Texture ~= nil then
					local T_Name = T_Texture.name
					local width = T_Texture.width or 32
					local height = T_Texture.height or 32
					local scale = T_Texture.scale or 1
					local x = T_Texture.x or 0
					local y = T_Texture.y or 0
					local anchor = T_Texture.anchor or "topleft"
					local mirror = T_Texture.mirror or false
					local Tint = T_Texture.tint or {255,255,255}
				
					DynamicImageSetTexture(WindowName.."Icon"..a.."LeftIcon",T_Name,width,height)
					DynamicImageSetTextureDimensions(WindowName.."Icon"..a.."LeftIcon",width,height)
					if T_Texture.slice ~= nil then
					DynamicImageSetTextureSlice(WindowName.."Icon"..a.."LeftIcon",T_Texture.slice)					
					end

					WindowSetDimensions(WindowName.."Icon"..a.."LeftIcon", width*scale, height*scale)
					WindowSetDimensions(WindowName.."Icon"..a.."Left", width*scale,height*scale)
					DynamicImageSetTextureScale(WindowName.."Icon"..a.."LeftIcon",scale)
					DynamicImageSetTextureOrientation (WindowName.."Icon"..a.."LeftIcon",mirror)
									
					WindowClearAnchors(WindowName.."Icon"..a.."Left")
					WindowAddAnchor(WindowName.."Icon"..a.."Left","topleft",WindowName.."Label"..a, anchor,x,y)	
					WindowSetTintColor(WindowName.."Icon"..a.."LeftIcon", Tint[1],Tint[2],Tint[3])					
				end	
	
				if T_Texture2 ~= nil then
					local T_Name = T_Texture2.name
					local width = T_Texture2.width or 32
					local height = T_Texture2.height or 32
					local scale = T_Texture2.scale or 1
					local x = T_Texture2.x or 0
					local y = T_Texture2.y or 0
					local anchor = T_Texture2.anchor or "topright"
					local mirror = T_Texture2.mirror or false
					local Tint = T_Texture2.tint or {255,255,255}
				
					DynamicImageSetTexture(WindowName.."Icon"..a.."RightIcon",T_Name,width,height)
					DynamicImageSetTextureDimensions(WindowName.."Icon"..a.."RightIcon",width,height)
					if T_Texture2.slice ~= nil then
						DynamicImageSetTextureSlice(WindowName.."Icon"..a.."RightIcon",T_Texture2.slice)
					end
					WindowSetDimensions(WindowName.."Icon"..a.."RightIcon", width*scale, height*scale)
					WindowSetDimensions(WindowName.."Icon"..a.."Right", width*scale, height*scale)
					DynamicImageSetTextureScale(WindowName.."Icon"..a.."RightIcon",scale )
					DynamicImageSetTextureOrientation (WindowName.."Icon"..a.."RightIcon",mirror)

					WindowClearAnchors(WindowName.."Icon"..a.."Right")
					WindowAddAnchor(WindowName.."Icon"..a.."Right","topright",WindowName.."Label"..a, anchor,x,y)
					WindowSetTintColor(WindowName.."Icon"..a.."RightIcon", Tint[1],Tint[2],Tint[3])						

				end
	
				if Fontwidth > TotalTicketWidth then TotalTicketWidth = Fontwidth end
				TotalTicketHeight = TotalTicketHeight+ FontHeight +5					

		end	
				
			TotalTicketWidth = TotalTicketWidth+ALIGN_PADDING[tostring(InfoScroller.Settings.Alignment)]
			local Main_width,Main_height = WindowGetDimensions("InfoScrollerMainWindow")
			MAX_HEIGHT = Main_height
			--
			WindowSetDimensions(WindowName,TotalTicketWidth,TotalTicketHeight)
			WindowSetDimensions(WindowName.."BackGround",TotalTicketWidth,TotalTicketHeight)			
			WindowStartAlphaAnimation(WindowName, Window.AnimationType.SINGLE_NO_RESET, 0.0, 1.0, WAIT_TIMER, false, 0.0, 0 )	
			WindowSetTintColor(WindowName.."BackGroundBG", BGColor.r, BGColor.g, BGColor.b )
			WindowSetTintColor(WindowName.."BackGroundStart", BGColor.r, BGColor.g, BGColor.b  )
			WindowSetTintColor(WindowName.."BackGroundEnd", BGColor.r, BGColor.g, BGColor.b  )
			WindowSetTintColor(WindowName.."Seperator", 175, 175, 175  )
	
		WindowClearAnchors(WindowName)
	
		local shittzy = 0
		if InfoScroller.Settings.Alignment == "right" then
		shittzy = Main_width - TotalTicketWidth
		elseif InfoScroller.Settings.Alignment == "center" then
		shittzy =(Main_width - TotalTicketWidth)/2
		end
		
	
		if InfoScroller.Settings.Orientation == "Down" then	
			WindowAddAnchor(WindowName,"topleft", "InfoScrollerMainWindow","topleft", shittzy,0)
		else
			local width,height = WindowGetDimensions("InfoScrollerMainWindow")
			local Self_Width,Self_Height = WindowGetDimensions(WindowName)
			WindowAddAnchor(WindowName,"topleft", "InfoScrollerMainWindow","topleft", shittzy,height-Self_Height-TICKET_PADDING)
		end

	
			WindowClearAnchors(WindowName.."BackGround")
			WindowAddAnchor(WindowName.."BackGround",C_ANCHOR[1], WindowName, C_ANCHOR[1],0,0)
			
			WindowClearAnchors(WindowName.."Seperator")
			WindowAddAnchor(WindowName.."Seperator",C_ANCHOR[1], WindowName, C_ANCHOR[1],0,-12)
			
				--Font Stuffz:
				WindowClearAnchors(WindowName.."Label1")
				WindowAddAnchor(WindowName.."Label1",T_ANCHOR[1], WindowName, T_ANCHOR[1], C_ANCHOR[3],C_ANCHOR[4])
				WindowClearAnchors(WindowName.."Label2")
				WindowAddAnchor(WindowName.."Label2",T_ANCHOR[2], WindowName.."Label1", T_ANCHOR[1], C_ANCHOR[5],C_ANCHOR[6])
				WindowClearAnchors(WindowName.."Label3")
				WindowAddAnchor(WindowName.."Label3",T_ANCHOR[2], WindowName.."Label2", T_ANCHOR[1], C_ANCHOR[5],C_ANCHOR[6])				
				WindowClearAnchors(WindowName.."Label4")
				WindowAddAnchor(WindowName.."Label4",T_ANCHOR[2], WindowName.."Label3", T_ANCHOR[1], C_ANCHOR[5],C_ANCHOR[6])			
				WindowClearAnchors(WindowName.."Label5")
				WindowAddAnchor(WindowName.."Label5",T_ANCHOR[2], WindowName.."Label4", T_ANCHOR[1], C_ANCHOR[5],C_ANCHOR[6])
			
				
				local Old_width,Old_height = WindowGetDimensions("InfoScroller_"..(i-1)) or 0,0		
				
				WindowSetShowing(WindowName.."Seperator",InfoScroller.Settings.Seperator)
				WindowSetShowing(WindowName.."SeperatorBG",InfoScroller.Settings.Seperator)
				
		
		if i > 1 then
			WindowSetLayer(WindowName,Window.Layers.DEFAULT)
			WindowSetLayer("InfoScroller_"..(i-1),Window.Layers.SECONDARY)
			
			local x, y = WindowGetOffsetFromParent( "InfoScroller_"..(i-1) )
		
				if InfoScroller.Settings.Alignment == "right" then
					x = (Main_width - Old_width)*uiScale
				elseif InfoScroller.Settings.Alignment == "center" then
					x = ((Main_width - Old_width)/2)*uiScale
				end
			if InfoScroller.Settings.Orientation == "Down" then
				local target_y = y+(uiScale*(TotalTicketHeight+TICKET_PADDING))
				WindowStartPositionAnimation("InfoScroller_"..(i-1),Window.AnimationType.SINGLE_NO_RESET,x,y,x,target_y,WAIT_TIMER,true, 0, 0 )
			else
				local width,height = WindowGetDimensions("InfoScroller_"..(i))
				local target_y = (y*uiScale)-(uiScale*(height+TICKET_PADDING))
				WindowStartPositionAnimation("InfoScroller_"..(i-1),Window.AnimationType.SINGLE_NO_RESET,x,y*uiScale,x,target_y,WAIT_TIMER,true, 0, 0 )
			end
		else
			InfoScroller.LiveTickets[i].IsAnchored = true
		end
	end
end

function InfoScroller.OnUpdate(timeElapsed)

	local tickets = 0
	local TotalTicketsHeight = 0
	for k,v in pairs(InfoScroller.LiveTickets) do
			if k ~= nil then
				tickets = tickets + 1 
				local width,height = WindowGetDimensions("InfoScroller_"..k)
				TotalTicketsHeight = TotalTicketsHeight + height + TICKET_PADDING				
			end
			
		if v.Timer < (TICKET_LIFE-WAIT_TIMER) and v.IsAnchored == false then --anchor after moving
		local C_ANCHOR = InfoScroller.FontAlignment[InfoScroller.Settings.Alignment]
		
			WindowClearAnchors("InfoScroller_"..(k-1))
			if InfoScroller.Settings.Orientation == "Down" then
				local width,height = WindowGetDimensions("InfoScroller_"..(k))
				WindowAddAnchor("InfoScroller_"..(k-1),C_ANCHOR[1], "InfoScroller_"..(k), C_ANCHOR[1], 0,TICKET_PADDING+(height))
			else
				local width,height = WindowGetDimensions("InfoScroller_"..(k-1))
				WindowAddAnchor("InfoScroller_"..(k-1),C_ANCHOR[1], "InfoScroller_"..(k), C_ANCHOR[1], 0,0-(height+TICKET_PADDING))
			end
			
			v.IsAnchored = true
		end
		
		if v.Timer > 0 then v.Timer = v.Timer - timeElapsed
		else
		if v.IsAlive == true then
			WindowStartAlphaAnimation("InfoScroller_"..(k), Window.AnimationType.SINGLE_NO_RESET_HIDE, 1.0, 0.0, WAIT_TIMER, false, 0.0, 0 )
			v.IsAlive = false
		end
		if (v.IsAlive == false) and (WindowGetAlpha("InfoScroller_"..(k)) < 0.01) then
			InfoScroller.LiveTickets[k] = nil
			
			if DoesWindowExist("InfoScroller_"..(k-1)) then
				DestroyWindow("InfoScroller_"..(k-1))		
			end
		end
		end		
	end
	
		if InfoScroller.SCROLL_TIMER < 0 then
		if (TotalTicketsHeight < MAX_HEIGHT) and InfoScroller.TicketsQue[1] ~= nil and tickets < InfoScroller.Settings.Max_Tickets then 
				InfoScroller.CreateCard(InfoScroller.TicketsQue[1])
				table.remove(InfoScroller.TicketsQue,1)
				InfoScroller.SCROLL_TIMER = WAIT_TIMER
			end
		else
			InfoScroller.SCROLL_TIMER = InfoScroller.SCROLL_TIMER - timeElapsed
		end
end


function InfoScroller.About()
local Alignment = {left={"bottomleft",true,145},center={"bottom",false,290},right={"bottomright",false,145,}}
local BGAlignment = Alignment[InfoScroller.Settings.Alignment]

		InfoScroller.TicketOnQue({																							--start of ticket
		BGColor={r=DefaultColor.GOLD.r,g=DefaultColor.GOLD.g,b=DefaultColor.GOLD.b},										--	background color of ticket
		Image={name="TestFlame", width=BGAlignment[3], height=52, alpha=0.8, scale=1, y=-2, mirror=BGAlignment[2], anchor=BGAlignment[1]},		--	background image of ticket
		[1]={text=L"InfoScroller:",color={r=255,g=150,b=25},BGColor={r=255,g=50,b=25},font="font_clear_small_bold"},		--	1:st row text info
		[2]={icon=2623,text=L"     By: "..towstring(CreateHyperLink(L"0",L"Sullemunk", {255,255,40},{})),color={r=255,g=255,b=255},font="font_clear_large_bold"},		
		[3]={text=L"\"All choises ever made has led up to this moment\"",color={r=55,g=250,b=225},font="font_clear_small"},	--	3:rd row text info
		[4]={text=L"Version: "..towstring(version),color={r=255,g=250,b=225},font="font_clear_tiny"}						--	4:th row text info
		})																													--end of ticket
end
