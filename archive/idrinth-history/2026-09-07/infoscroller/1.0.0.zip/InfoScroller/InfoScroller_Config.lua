-- loads an instance of LibConfig
LibConfig = LibStub("LibConfig")

InfoScroller_config = {}

local GUI

function InfoScroller_config.Slash(msg)
  if (not GUI) then
    -- parameters: title text, settings table, callback-function
    -- note that you need to have a settings table!
    GUI = LibConfig("InfoScroller Configuration", InfoScroller.Settings, true, InfoScroller_config.SettingsChanged)


--Modular Config throu script
		for key,value in pairs(InfoScroller.Register) do		
			GUI:AddTab(value.name)		
		for k,v in ipairs(InfoScroller.Register[key]) do		
				if v.name == "combobox" then
					local comboBox = GUI("combobox", v.title,v.save).combo
						for a,b in ipairs(v.option) do
							comboBox:Add(b)
						end	
				elseif v.name == "textbox" then
					GUI("textbox",  v.title,v.save)
				elseif v.name == "checkbox" then
					GUI("checkbox", v.title,v.save)
				elseif  v.name == "color" then
					GUI("color",  v.title,v.save)
				elseif  v.name == "label" then
					label = GUI("label", v.title).label	
					label:Align(v.align)					
				end
		end
		

		end

   end
  
  -- fills in all the values and shows the config GUI
  GUI:Show()
end

-- will get called after the apply-button has been hit and the settings have been changed
function InfoScroller_config.SettingsChanged()
--InfoScroller.CreateFrame()
end