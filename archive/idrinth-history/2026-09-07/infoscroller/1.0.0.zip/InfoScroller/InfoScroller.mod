<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
    <UiMod name="InfoScroller" version="1.0" date="11/12/2020">
        <Author name="Sullemunk" />
        <Description text="Frame Management Engine for Displaying Info in a scrolling style <br> use /infoscroller or /info for configuration" />
         <Dependencies>
		 	<Dependency name="EATemplate_DefaultWindowSkin" />
            <Dependency name="EASystem_Utils" />
            <Dependency name="EASystem_WindowUtils" />
            <Dependency name="LibSlash" />				
		</Dependencies>
 
        <Files>
				<File name="libs\LibStub.lua" />
				<File name="libs\LibGUI.lua" />
				<File name="libs\LibConfig.lua" />		
		
            <File name="InfoScroller.lua" />
			<File name="InfoScroller.xml" />
			
			<File name="InfoScroller_Config.lua"/>			

        </Files>

        <OnInitialize>
            <CallFunction name="InfoScroller.OnInitialize" />
        </OnInitialize>
		
		<SavedVariables>		
			<SavedVariable name="InfoScroller.Settings"/>
		</SavedVariables>
		
        <OnUpdate>
			<CallFunction name="InfoScroller.OnUpdate" />
    	 </OnUpdate>
		
        <OnShutdown>
			<CallFunction name="InfoScroller.OnShutdown" />
		</OnShutdown>
    </UiMod>
</ModuleFile>