------------WINDOW NAMES--------------


local windowName = "DevPadWindow"
local codeWindow = "DevPadWindowDevPadCode"
local codeScroll="DevPadWindowDevPadCodeDevPadCodeScrollBar"


--------------------MAIN WINDOW------------------------
DevPad = {}

function DevPad.Initialize()

	if not DevPad_Save then
		DevPad_Save = {}
	end
	if not DevPad_Settings then
		DevPad_Settings = { Code = L"", show = false }
	end

------------WINDOW LABELS------------------------------

--CreateWindow( windowName, false )
WindowSetShowing(codeScroll, false)
LabelSetText (	windowName .. "Name", L"DevPad")
ButtonSetText( windowName .. "Clear", L"Clear" )
ButtonSetText( windowName .. "Execute", L"Execute" )
ButtonSetText( windowName .. "Close", L"Close")


	TextEditBoxSetText( codeWindow, DevPad_Settings.Code )


	if DevPad_Settings.show then
		DevPadWindow.Show()
	end
end

--------------------------WINDOW FUNCTIONS---------------------------------
DevPadWindow = {}

function DevPadWindow.OnShown()
	WindowAssignFocus( codeWindow, true )
end

function DevPadWindow.Show()
	DevPad_Settings.show = true
	WindowSetShowing( windowName, true )
	WindowAssignFocus( codeWindow, true )
	WindowAssignFocus( codeWindow, false )
end

function DevPadWindow.Hide()
	DevPad_Settings.show = false
	WindowSetShowing(windowName, false)
end

function DevPadWindow.Toggle()
	if WindowGetShowing( windowName ) then
		 DevPadWindow.Hide()
		 DebugWindow.OnShowFocus()
	else
		DevPadWindow.Show()
		DevPadWindow.OnShown()
	end
end

function DevPad.OnResizeBegin()
  WindowUtils.BeginResize( "DevPadWindow", "topleft", 300, 200, nil)
end


-------------CODE SENDING FUNCTIONS-------------

function DevPadWindow.Clear()
	TextEditBoxSetText( codeWindow, L"" )
end

function DevPadWindow.Execute()
	local newCode = TextEditBoxGetText( codeWindow )
	SendChatText(L"/script "..towstring(newCode), L"")
end

function DevPadWindow.OnCodeChanged()
	DevPad_Settings.Code = TextEditBoxGetText( codeWindow )
	if wstring.match(DevPad_Settings.Code, L"\n") then
		DevPad_Settings.Code = wstring.gsub(DevPad_Settings.Code, L"\n", L"\r")
		TextEditBoxSetText( codeWindow, DevPad_Settings.Code )
	end
end
-----------------------------------
