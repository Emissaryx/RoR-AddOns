<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
	<UiMod name="ShowHealthPercent" version="1.0" date="11/18/2008" >

		<Author name="Novacane" email="novacane111@gmail.com" />
		<Description text="Allows the showing of health on static objects and percents on all targets by the default target unitframes." />

		<Dependencies>
			<Dependency name="EATemplate_UnitFrames" />
		</Dependencies>
        
		<Files>
			<File name="ShowStaticHealth.xml" />
			<File name="ShowStaticHealth.lua" />
		</Files>

		<OnInitialize>
			<CallFunction name="ShowHealth.Init" />
		</OnInitialize>
		
	</UiMod>
</ModuleFile>