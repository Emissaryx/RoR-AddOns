--[[
Module: Show Health Percent
Author: Novacane
Date: 11.20.2008
Server: Averheim
Guild: Dusk till Dawn
Site: http://www.dusktilldawnguild.com
--]]

-- Frame Definitions
local Frames = {
	["selffriendlytarget"] = {
		Parent = "FriendlyTargetWindowStatusHealthPercentBar",
		Label = "ShowHealthFriendly",
		X = 50,
	},
	["selfhostiletarget"] = {
		Parent = "TargetWindowStatusHealthPercentBar",
		Label = "ShowHealthHostile",
		X = -50,
	},
};


-- Taken from EATemplate_UnitFrames/targetunitframe.lua (line 7 : client version 1.0.4)
local UnitIdToBuffTargetMapping =
{
    ["selfhostiletarget"]   = { buffTarget = GameData.BuffTargetType.TARGET_HOSTILE,    healthColor = { r = 255, g = 0, b = 0 } },
    ["selffriendlytarget"]  = { buffTarget = GameData.BuffTargetType.TARGET_FRIENDLY,   healthColor = { r = 0, g = 255, b = 0 } }
}
-- Rewrite UpdateHealth method to allow showing of static object health
-- Taken from EATemplate_UnitFrames/targetunitframe.lua (line 415 : client version 1.0.4)
function TargetUnitFrame:UpdateHealth ()
    self.m_StatusFrame:SetUnitHealth (TargetInfo:UnitHealth (self.m_UnitId), UnitIdToBuffTargetMapping[self.m_UnitId].healthColor, true)
end



-- Global
ShowHealth = {};

function ShowHealth.Init()
	RegisterEventHandler(SystemData.Events.PLAYER_TARGET_UPDATED, "ShowHealth.TargetUpdated");
end

function ShowHealth.TargetUpdated(targetClass, targetId, targetType)
	if targetClass == "selffriendlytarget" or targetClass == "selfhostiletarget" then
		--d(targetClass .. " : " .. targetId .. " : " .. targetType); -- Debug
		TargetInfo:UpdateFromClient();
		-- Create and Destroy the labels from a template depending on the target type
		-- We could just create it on first target then let the parent deal with it but this works too..
		if targetType ~= 0 then
			if not DoesWindowExist(Frames[targetClass].Label) then -- Don't attempt to create the window if it exists
				CreateWindowFromTemplate(Frames[targetClass].Label, "ShowHealth_Template", Frames[targetClass].Parent);
				WindowAddAnchor(Frames[targetClass].Label, "center", Frames[targetClass].Parent, "center", Frames[targetClass].X, -4);
				WindowSetScale(Frames[targetClass].Label, WindowGetScale(Frames[targetClass].Parent));
			end
			-- Always set the text on a valid target
			LabelSetText(Frames[targetClass].Label, TargetInfo:UnitHealth(targetClass) .. L"%");
		else
			-- Destroy on un-target
			DestroyWindow(Frames[targetClass].Label);
		end
	end
end