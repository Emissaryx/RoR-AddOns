local VERSION = 1.04
local TIME_DELAY = 0.5
local timeLeft = TIME_DELAY
local MAX_STACK = 3
local IMMOVABLE = 4
local UNSTOPPABLE = 5
local pairs = pairs
local eventsRegistered = false

local function fixString (str)
	if (str == nil) then return nil end
	local str = str
	local pos = str:find (L"^", 1, true)
	if (pos) then str = str:sub (1, pos - 1) end
	return str
end

local function hasFriendlyTarget()
	TargetInfo:UpdateFromClient()
	local target = TargetInfo.m_Units[TargetInfo.FRIENDLY_TARGET]
	if target and target.entityid ~= 0 then
		return true
	end
	return false
end

local function hasHostileTarget()
	TargetInfo:UpdateFromClient()
	local target = TargetInfo.m_Units[TargetInfo.HOSTILE_TARGET]
	if target and target.entityid ~= 0 then
		return true
	end
	return false
end

local function hasBuff(target, abilityData, stackCount)
	TargetInfo:UpdateFromClient()
	if not target then
		return false
	end
	local buffData = GetBuffs(target)
    if not buffData then
        return false
    end

	for _, buff in pairs( buffData )
    do
		if buff.iconNum == abilityData.iconNum and buff.castByPlayer and buff.stackCount == stackCount then
			return true
        end
    end
    return false
end

local function getTargetType(targetType)
	if targetType == 0 then
		return GameData.BuffTargetType.SELF
	elseif targetType == 1 and hasHostileTarget() then
		return GameData.BuffTargetType.TARGET_HOSTILE
	elseif targetType == 1 then
		return nil -- Ugly workaround to correct for incorrect buffs when no hostile target
	elseif targetType == 2 and hasFriendlyTarget() then
		return GameData.BuffTargetType.TARGET_FRIENDLY
	elseif targetType == 2 then
		return GameData.BuffTargetType.SELF
	else
		return GameData.BuffTargetType.SELF
	end
end

local function abilityUsable(id)
	local actionType, actionId, isSlotEnabled, isTargetValid, isSlotBlocked
	for i = 1, 60 do
		actionType, actionId, isSlotEnabled, isTargetValid, isSlotBlocked = GetHotbarData(i)
		if id == actionId
		and GetHotbarCooldown(i) == 0
		and isSlotEnabled
		and isTargetValid
		then
			return true
		end
	end
	return false
end

local function alertText(text)
	if SettingsWindowTabInterface.SavedMessageSettings.combat then
		SystemData.AlertText.VecType = {SystemData.AlertText.Types.COMBAT}
		SystemData.AlertText.VecText = {towstring(text)}
		BroadcastEvent(SystemData.Events.SHOW_ALERT_TEXT)
	end
end

local function chatInfo(actionId, state)
	local name = tostring(GetAbilityData(actionId).name)
	local icon = "<icon".. tostring(GetAbilityData(actionId).iconNum) .. ">"
	if not state then
		TextLogAddEntry("Chat", 0, towstring("GCDsaver: Clearing check for " .. icon .. " " .. name))
	elseif state >= 1 and state <= 3 then
		TextLogAddEntry("Chat", 0, towstring("GCDsaver: Setting (" .. state ..  "x) Stack check for " .. icon .. " " .. name))
	elseif state == IMMOVABLE then
		TextLogAddEntry("Chat", 0, towstring("GCDsaver: Setting <icon05007> Immovable check for " .. icon .. " " .. name))
	elseif state == UNSTOPPABLE then
		TextLogAddEntry("Chat", 0, towstring("GCDsaver: Setting <icon05006> Unstoppable check for " .. icon .. " " .. name))
	end
end

GCDsaver = GCDsaver or {}
GCDsaver.TargetID = 0
GCDsaver.TargetImmovable = false
GCDsaver.TargetUnstoppable = false

GCDsaver.DefaultSettings = {
	Version = VERSION,
	Enabled = true,
	Icons = true,
	ErrorMessages = true,
	Abilities = {
		-- Ironbreaker
		[1384] = UNSTOPPABLE,	-- Cave-In
		[1369] = UNSTOPPABLE,	-- Shield of Reprisal
		[1365] = IMMOVABLE,		-- Away With Ye
		-- Slayer
		[1443] = UNSTOPPABLE,	-- Incapacitate
		-- Runepriest
		[1613] = UNSTOPPABLE,	-- Rune of Binding
		[1607] = UNSTOPPABLE,	-- Spellbinding Rune
		-- Engineer
		[1536] = UNSTOPPABLE,	-- Crack Shot
		[1531] = IMMOVABLE,		-- Concussion Grenade
		-- Black Orc
		[1688] = UNSTOPPABLE,	-- Down Ya Go
		[1683] = UNSTOPPABLE,	-- Shut Yer Face
		-- Choppa
		[1755] = UNSTOPPABLE,	-- Sit Down!
		-- Shaman
		[1929] = IMMOVABLE,		-- Geddoff!
		[1917] = UNSTOPPABLE,	-- You Got Nuthin!
		-- Squig Herder
		[1839] = UNSTOPPABLE,	-- Choking Arrer
		[1837] = UNSTOPPABLE,	-- Drop That!!
		[1835] = UNSTOPPABLE,	-- Not So Fast!
		-- Witch Hunter
		[8110] = UNSTOPPABLE,	-- Dragon Gun
		[8086] = UNSTOPPABLE,	-- Confess!
		[8115] = UNSTOPPABLE,	-- Pistol Whip
		[8100] = UNSTOPPABLE,	-- Silence The Heretic
		[8094] = UNSTOPPABLE,	-- Declare Anathema
		-- Knight of the Blazing Sun
		[8018] = UNSTOPPABLE,	-- Smashing Counter
		[8017] = IMMOVABLE,		-- Repel Darkness
		-- Bright Wizard
		[8186] = UNSTOPPABLE,	-- Stop, Drop, and Roll
		[8174] = UNSTOPPABLE,	-- Choking Smoke
		-- Warrior Priest
		[8256] = UNSTOPPABLE,	-- Vow of Silence
		-- Chosen
		[8346] = UNSTOPPABLE,	-- Downfall
		[8329] = IMMOVABLE,		-- Repel
		-- Marauder
		[8412] = UNSTOPPABLE,	-- Mutated Energy
		[8405] = UNSTOPPABLE,	-- Death Grip
		[8410] = IMMOVABLE,		-- Terrible Embrace
		-- Zealot
		[8571] = UNSTOPPABLE,	-- Aethyric Shock
		[8565] = UNSTOPPABLE,	-- Tzeentch's Lash
		-- Magus
		[8495] = UNSTOPPABLE,	-- Perils of The Warp
		[8483] = IMMOVABLE,		-- Warping Blast
		-- Swordmaster
		[9032] = IMMOVABLE,		-- Redirected Force
		-- [9030] = UNSTOPPABLE,	-- Whispering Window
		[9028] = UNSTOPPABLE,	-- Chrashing Wave
		-- Shadow Warrior
		[9096] = UNSTOPPABLE,	-- Eye Shot
		[9108] = UNSTOPPABLE,	-- Exploit Weakness
		[9098] = UNSTOPPABLE,	-- Opportunistic Strike
		-- White Lion
		[9193] = UNSTOPPABLE,	-- Brutal Pounce
		[9177] = UNSTOPPABLE,	-- Throat Bite
		[9178] = IMMOVABLE,		-- Fetch!
		-- Archmage
		[9266] = IMMOVABLE,		-- Cleansing Flare
		[9253] = UNSTOPPABLE,	-- Law of Gold
		-- Blackguard
		[2888] = UNSTOPPABLE,	-- Malignant Strike!
		[9321] = UNSTOPPABLE,	-- Spiteful Slam
		[9328] = IMMOVABLE,		-- Exile
		-- Witch Elf
		[9422] = UNSTOPPABLE,	-- On Your Knees!
		[9400] = UNSTOPPABLE,	-- Sever Limb
		[9427] = UNSTOPPABLE,	-- Heart Seeker
		[9409] = UNSTOPPABLE,	-- Throat Slitter
		[9396] = UNSTOPPABLE,	-- Agile Escape
		-- Disciple of Khaine
		[9565] = UNSTOPPABLE,	-- Consume Thought
		-- Sorcerer
		[9482] = UNSTOPPABLE,	-- Frostbite
		[9489] = UNSTOPPABLE,	-- Stricken Voices
	},
}

function GCDsaver.Initialize()
	if not GCDsaver.Settings
	or not GCDsaver.Settings.Version
	or GCDsaver.Settings.Version ~= VERSION
	then
		local defaultSettings = GCDsaver.DefaultSettings
		GCDsaver.Settings = defaultSettings
	end
	
	LibSlash.RegisterSlashCmd("gcdsaver", function(input) GCDsaver_Config.Slash(input) end)
	
	GCDsaver.UpdateButtonIcons()
	
	GCDsaver.RegisterEvents()
	
	TextLogAddEntry("Chat", 0, towstring("<icon57> GCDsaver loaded. Type /gcdsaver for settings."))
end

function GCDsaver.OnShutdown()
	GCDsaver.UnregisterEvents()
end

function GCDsaver.RegisterEvents()
	RegisterEventHandler(SystemData.Events.PLAYER_TARGET_UPDATED, "GCDsaver.PLAYER_TARGET_UPDATED")
	RegisterEventHandler(SystemData.Events.PLAYER_TARGET_IS_IMMUNE_TO_MOVEMENT_IMPARING, "GCDsaver.PLAYER_TARGET_IS_IMMUNE_TO_MOVEMENT_IMPARING")
	RegisterEventHandler(SystemData.Events.PLAYER_TARGET_IS_IMMUNE_TO_DISABLES, "GCDsaver.PLAYER_TARGET_IS_IMMUNE_TO_DISABLES")
	RegisterEventHandler(SystemData.Events.PLAYER_EFFECTS_UPDATED, "GCDsaver.PLAYER_EFFECTS_UPDATED")
	RegisterEventHandler(SystemData.Events.PLAYER_TARGET_EFFECTS_UPDATED, "GCDsaver.PLAYER_TARGET_EFFECTS_UPDATED")
	eventsRegistered = true
end

function GCDsaver.UnregisterEvents()
	UnregisterEventHandler(SystemData.Events.PLAYER_TARGET_UPDATED, "GCDsaver.PLAYER_TARGET_UPDATED")
	UnregisterEventHandler(SystemData.Events.PLAYER_TARGET_IS_IMMUNE_TO_MOVEMENT_IMPARING, "GCDsaver.PLAYER_TARGET_IS_IMMUNE_TO_MOVEMENT_IMPARING")
	UnregisterEventHandler(SystemData.Events.PLAYER_TARGET_IS_IMMUNE_TO_DISABLES, "GCDsaver.PLAYER_TARGET_IS_IMMUNE_TO_DISABLES")
	UnregisterEventHandler(SystemData.Events.PLAYER_EFFECTS_UPDATED, "GCDsaver.PLAYER_EFFECTS_UPDATED")
	UnregisterEventHandler(SystemData.Events.PLAYER_TARGET_EFFECTS_UPDATED, "GCDsaver.PLAYER_TARGET_EFFECTS_UPDATED")
	eventsRegistered = false
end

-- Event handlers
function GCDsaver.PLAYER_TARGET_UPDATED(targetClassification, targetId, targetType)
	-- Ignore mouseover target changes
	if (targetClassification == TargetInfo.FRIENDLY_TARGET or targetClassification == TargetInfo.HOSTILE_TARGET) and GCDsaver.TargetID ~= targetId then
		GCDsaver.TargetID = targetId
		GCDsaver.TargetImmovable = false
		GCDsaver.TargetUnstoppable = false
		GCDsaver.UpdateButtonsEnabledStates()
	end
end

function GCDsaver.PLAYER_TARGET_IS_IMMUNE_TO_DISABLES(state)
	GCDsaver.SetUnstoppable(state)
	GCDsaver.UpdateButtonsEnabledStates()
end

function GCDsaver.PLAYER_TARGET_IS_IMMUNE_TO_MOVEMENT_IMPARING(state)
	GCDsaver.SetImmovable(state)
	GCDsaver.UpdateButtonsEnabledStates()
end

function GCDsaver.PLAYER_EFFECTS_UPDATED(updatedEffects, isFullList)
	GCDsaver.UpdateButtonsEnabledStates()
end

function GCDsaver.PLAYER_TARGET_EFFECTS_UPDATED(updateType, updatedEffects, isFullList)
	GCDsaver.UpdateButtonsEnabledStates()
end

-- Main update function
function GCDsaver.OnUpdate(elapsed)
	if not GCDsaver.Settings.Enabled then return end
	timeLeft = timeLeft - elapsed
    if timeLeft > 0 then
        return
    end
    timeLeft = TIME_DELAY
	GCDsaver.UpdateButtonIcons()
end

function GCDsaver.UpdateSettings()
	if GCDsaver.Settings.Enabled and not eventsRegistered then
		GCDsaver.UpdateButtonIcons()
		GCDsaver.RegisterEvents()
	elseif not GCDsaver.Settings.Enabled and eventsRegistered then
		GCDsaver.UpdateButtonIcons()
		GCDsaver.UnregisterEvents()
	end

	TextLogAddEntry("Chat", 0, towstring("GCDsaver v" .. tostring(GCDsaver.Settings.Version) .. " settings: /gcdsaver"))
	if GCDsaver.Settings.Enabled then
		TextLogAddEntry("Chat", 0, L"--- <icon57> Enabled")
	else
		TextLogAddEntry("Chat", 0, L"--- <icon58> Enabled")
	end
	if GCDsaver.Settings.Icons then
		TextLogAddEntry("Chat", 0, L"--- <icon57> Show Icons")
	else
		TextLogAddEntry("Chat", 0, L"--- <icon58> Hide Icons")
	end
	if GCDsaver.Settings.ErrorMessages then
		TextLogAddEntry("Chat", 0, L"--- <icon57> Show Combat Error Messages")
	else
		TextLogAddEntry("Chat", 0, L"--- <icon58> Hide Combat Error Messages")
	end
end

function GCDsaver.SetImmovable(isImmovable)
	GCDsaver.TargetImmovable = isImmovable
end

function GCDsaver.SetUnstoppable(isUnstoppable)
	GCDsaver.TargetUnstoppable = isUnstoppable
end

-- Hook WindowGameAction
local orgWindowGameAction = WindowGameAction
function WindowGameAction(windowName)
	if GCDsaver.Settings.Enabled then
		local actionType, actionId, actionText = WindowGetGameActionData(windowName)
		local abilityData = GetAbilityData(actionId)

		if GCDsaver.TargetImmovable and GCDsaver.Settings.Abilities[actionId] and GCDsaver.Settings.Abilities[actionId] == IMMOVABLE then
			if GCDsaver.Settings.ErrorMessages and abilityUsable(actionId) then alertText("Target is Immovable") end
		elseif GCDsaver.TargetUnstoppable and GCDsaver.Settings.Abilities[actionId] and GCDsaver.Settings.Abilities[actionId] == UNSTOPPABLE then
			if GCDsaver.Settings.ErrorMessages and  abilityUsable(actionId) then alertText("Target is Unstoppable") end
		elseif GCDsaver.Settings.Abilities[actionId] and hasBuff(getTargetType(abilityData.targetType), abilityData, GCDsaver.Settings.Abilities[actionId]) then
			if GCDsaver.Settings.ErrorMessages and abilityUsable(actionId) then alertText("Target already has that effect") end
		else
			orgWindowGameAction(windowName)
		end
	else
		orgWindowGameAction(windowName)
	end
end

local function setButtonIcon(actionId, state)
	local hbar, buttonid, button
	local buttonActionId
	for i = 1, 60 do
		_, buttonActionId = GetHotbarData(i)
		if buttonActionId == actionId then
			hbar, buttonid = ActionBars:BarAndButtonIdFromSlot(i)
			if hbar and buttonid then
				button = hbar.m_Buttons[buttonid]
				button.m_Windows[7]:SetFont("font_default_war_heading", WindowUtils.FONT_DEFAULT_TEXT_LINESPACING)
				button.m_Windows[7]:SetTextColor(255, 255, 0)
				if GCDsaver.Settings.Enabled and GCDsaver.Settings.Icons and state == IMMOVABLE then
					button.m_Windows[7]:Show(true)
					button.m_Windows[7]:SetText("<icon05007>")
				elseif GCDsaver.Settings.Enabled and GCDsaver.Settings.Icons and state == UNSTOPPABLE then
					button.m_Windows[7]:Show(true)
					button.m_Windows[7]:SetText("<icon05006>")
				elseif GCDsaver.Settings.Enabled and GCDsaver.Settings.Icons and type(state) == "number" then
					
					button.m_Windows[7]:Show(true)
					button.m_Windows[7]:SetText(tostring(state).."x")
				else
					button.m_Windows[7]:Show(false)
				end
			end
		end
	end
end

function GCDsaver.UpdateButtonIcons()
	for abilityId, state in pairs(GCDsaver.Settings.Abilities) do
		setButtonIcon(abilityId, state)
	end
end

function GCDsaver.UpdateButtonsEnabledStates()
	local actionType, actionId, isSlotEnabled, isTargetValid, isSlotBlocked
	
	for i = 1, 60 do
		actionType, actionId, isSlotEnabled, isTargetValid, isSlotBlocked = GetHotbarData(i)
		if GCDsaver.Settings.Abilities[actionId] then
			ActionBars.UpdateSlotEnabledState(i, isSlotEnabled, isTargetValid, isSlotBlocked)
		end
	end
end

-- Hook ActionButton.OnLButtonUp
local orgActionButtonOnLButtonUp = ActionButton.OnLButtonUp
function ActionButton.OnLButtonUp(self, flags, x, y)
	if flags ~= SystemData.ButtonFlags.SHIFT then
		orgActionButtonOnLButtonUp(self, flags, x, y)
	end
end

-- Hook ActionButton.OnLButtonDown
local orgActionButtonOnLButtonDown = ActionButton.OnLButtonDown
function ActionButton.OnLButtonDown(self, flags, x, y)
	if flags == SystemData.ButtonFlags.SHIFT and self.m_ActionId ~= 0 then
		if not GCDsaver.Settings.Abilities[self.m_ActionId] then
			GCDsaver.Settings.Abilities[self.m_ActionId] = 1
		elseif GCDsaver.Settings.Abilities[self.m_ActionId] < 5 then
			GCDsaver.Settings.Abilities[self.m_ActionId] = GCDsaver.Settings.Abilities[self.m_ActionId] + 1
		else
			GCDsaver.Settings.Abilities[self.m_ActionId] = nil
		end
		setButtonIcon(self.m_ActionId, GCDsaver.Settings.Abilities[self.m_ActionId])
		chatInfo(self.m_ActionId, GCDsaver.Settings.Abilities[self.m_ActionId])
		GCDsaver.UpdateButtonsEnabledStates()
	else
		orgActionButtonOnLButtonDown(self, flags, x, y)
	end
end

-- Hook ActionBars.UpdateSlotEnabledState
local orgActionBarsUpdateSlotEnabledState = ActionBars.UpdateSlotEnabledState
function ActionBars.UpdateSlotEnabledState(slot, isSlotEnabled, isTargetValid, isSlotBlocked)
	local hbar, buttonid = ActionBars:BarAndButtonIdFromSlot(slot)
	if hbar and buttonid then
		local button = hbar.m_Buttons[buttonid]
		local abilityData = GetAbilityData(button.m_ActionId)
		
		if GCDsaver.Settings.Abilities[button.m_ActionId]
		and GCDsaver.Settings.Abilities[button.m_ActionId] == IMMOVABLE
		and GCDsaver.TargetImmovable
		then
			isSlotEnabled = false
		elseif GCDsaver.Settings.Abilities[button.m_ActionId]
		and GCDsaver.Settings.Abilities[button.m_ActionId] == UNSTOPPABLE
		and GCDsaver.TargetUnstoppable
		then
			isSlotEnabled = false
		elseif GCDsaver.Settings.Abilities[button.m_ActionId]
		and hasBuff(getTargetType(abilityData.targetType), abilityData, GCDsaver.Settings.Abilities[button.m_ActionId])
		then
			isSlotEnabled = false
		end
	end
	orgActionBarsUpdateSlotEnabledState(slot, isSlotEnabled, isTargetValid, isSlotBlocked)
end