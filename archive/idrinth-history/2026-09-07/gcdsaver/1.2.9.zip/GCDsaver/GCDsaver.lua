-- Local
local VERSION = "1.2.9"
local ICON_UPDATE_DELAY = 0.5
local DYNAMIC_BUTTON_UPDATE_DELAY = 0.05
local VIRTUAL_ATTEMPT_CONFIRM_DELAY = 0.05
local VIRTUAL_ATTEMPT_TIMEOUT = 0.50
local iconTimeLeft = ICON_UPDATE_DELAY
local dynamicButtonTimeLeft = DYNAMIC_BUTTON_UPDATE_DELAY
local AA_MIN_LEAD = 0
local AA_MAX_LEAD = 3
local AA_LEAD_STEP = 0.5
local EFFECT_REFRESH_MIN = 0
local EFFECT_REFRESH_MAX = 30
local EFFECT_REFRESH_STEP = 0.5
local CAREER_MECHANIC_MIN = -250
local CAREER_MECHANIC_MAX = 250
local CAREER_MECHANIC_MODE_MIN = "MIN"
local CAREER_MECHANIC_MODE_MAX = "MAX"
local CAREER_MECHANIC_MODE_EQUAL = "EQUAL"
local RUNE_PRIEST_MECHANIC_ABILITY = 1659
local ZEALOT_MECHANIC_ABILITY = 8550
local AA_SYNC_TOLERANCE = 0.20
local MAX_STACK = 3
local IMMOVABLE = 4
local UNSTOPPABLE = 5
local SELF_1 = 6
local SELF_2 = 7
local SELF_3 = 8
local MAX_BUTTONS = 60
local MAX_AP = 200
local MAX_HP_PERCENT = 100
local BUTTON_MARKER_SUFFIX = "GCDsaverMarker"
local BUTTON_MARKER_WIDTH = 42
local BUTTON_MARKER_HEIGHT = 16
local RESOURCE_MODE_AP = "AP"
local RESOURCE_MODE_HP = "HP"
local TARGET_HP_MODE_MIN = "MIN"
local TARGET_HP_MODE_MAX = "MAX"
local EFFECT_TARGET_ABILITY = "ABILITY"
local EFFECT_TARGET_HOSTILE = "HOSTILE"
local EFFECT_TARGET_FRIENDLY = "FRIENDLY"
local EFFECT_TARGET_SELF = "SELF"
local pairs = pairs
local abs = math.abs
local floor = math.floor
local eventsRegistered = false

local function T(key)
	return GCDsaver_Lang.Get(key)
end

local function defaultIfNil(value, default)
	if value == nil then
		return default
	end
	return value
end

local function clamp(value, minValue, maxValue)
	if value < minValue then return minValue end
	if value > maxValue then return maxValue end
	return value
end

local function roundToStep(value, step)
	return floor((value / step) + 0.5) * step
end

local function sanitizeResourceRule(rule)
	if type(rule) ~= "table" then return nil end
	local mode = rule.Mode or rule.mode
	if mode ~= RESOURCE_MODE_AP and mode ~= RESOURCE_MODE_HP then return nil end
	local threshold = tonumber(rule.Threshold or rule.threshold or rule.Value or rule.value)
	if threshold == nil then return nil end
	if mode == RESOURCE_MODE_AP then
		threshold = clamp(roundToStep(threshold, 10), 0, MAX_AP)
	else
		threshold = clamp(roundToStep(threshold, 10), 0, MAX_HP_PERCENT)
	end
	return { Mode = mode, Threshold = threshold }
end

local function sanitizeTargetHealthRule(rule)
	if type(rule) ~= "table" then return nil end
	local mode = rule.Mode or rule.mode
	if mode ~= TARGET_HP_MODE_MIN and mode ~= TARGET_HP_MODE_MAX then return nil end
	local threshold = tonumber(rule.Threshold or rule.threshold or rule.Value or rule.value)
	if threshold == nil then return nil end
	threshold = clamp(roundToStep(threshold, 5), 0, MAX_HP_PERCENT)
	local target = rule.Target or rule.target or EFFECT_TARGET_ABILITY
	if target ~= EFFECT_TARGET_ABILITY
	and target ~= EFFECT_TARGET_HOSTILE
	and target ~= EFFECT_TARGET_FRIENDLY
	and target ~= EFFECT_TARGET_SELF
	then
		target = EFFECT_TARGET_ABILITY
	end
	return { Mode = mode, Threshold = threshold, Target = target }
end

local function sanitizeCareerMechanicRule(rule)
	if type(rule) ~= "table" then return nil end
	local mode = rule.Mode or rule.mode
	if mode ~= CAREER_MECHANIC_MODE_MIN
	and mode ~= CAREER_MECHANIC_MODE_MAX
	and mode ~= CAREER_MECHANIC_MODE_EQUAL
	then
		return nil
	end
	local threshold = tonumber(rule.Threshold or rule.threshold or rule.Value or rule.value)
	if threshold == nil then return nil end
	threshold = clamp(roundToStep(threshold, 1), CAREER_MECHANIC_MIN, CAREER_MECHANIC_MAX)
	return { Mode = mode, Threshold = threshold }
end

local function sanitizeVirtualCooldown(value)
	value = tonumber(value)
	if value == nil or value <= 0 then return nil end
	return clamp(roundToStep(value, 0.5), 0.5, 300)
end

local function sanitizeEffectRefreshWindow(value)
	value = tonumber(value)
	if value == nil or value <= EFFECT_REFRESH_MIN then return nil end
	return clamp(roundToStep(value, EFFECT_REFRESH_STEP), EFFECT_REFRESH_STEP, EFFECT_REFRESH_MAX)
end

local function sanitizeEffectRequirement(requirement)
	if type(requirement) ~= "table" then return nil end
	local effectId = tonumber(requirement.EffectId or requirement.effectId or requirement.Id or requirement.id)
	if effectId == nil or effectId <= 0 then return nil end
	effectId = floor(effectId + 0.5)
	local target = requirement.Target or requirement.target or EFFECT_TARGET_ABILITY
	if target ~= EFFECT_TARGET_ABILITY
	and target ~= EFFECT_TARGET_HOSTILE
	and target ~= EFFECT_TARGET_FRIENDLY
	and target ~= EFFECT_TARGET_SELF
	then
		target = EFFECT_TARGET_ABILITY
	end
	return {
		EffectId = effectId,
		Target = target,
		OnlyMine = requirement.OnlyMine == true or requirement.onlyMine == true,
	}
end

local function formatAALead(value)
	if value == floor(value) then
		return tostring(floor(value))
	end
	return string.format("%.1f", value)
end

local function nextAALead(value)
	if value == nil then
		return AA_MIN_LEAD
	end
	value = value + AA_LEAD_STEP
	if value > AA_MAX_LEAD then
		return nil
	end
	return value
end

local function hasFriendlyTarget()
	local target = TargetInfo.m_Units[TargetInfo.FRIENDLY_TARGET]
	if target and target.entityid ~= 0 then
		return true
	end
	return false
end

local function hasHostileTarget()
	local target = TargetInfo.m_Units[TargetInfo.HOSTILE_TARGET]
	if target and target.entityid ~= 0 then
		return true
	end
	return false
end

local function hasBuff(target, abilityData, stackCount, refreshWindow)
	if not target then
		return false
	end
	local buffData = GetBuffs(target)
	if not buffData then
		return false
	end

	for _, buff in pairs(buffData) do
		if buff.iconNum == abilityData.iconNum and buff.castByPlayer and buff.stackCount == stackCount then
			if refreshWindow == nil or buff.permanentUntilDispelled then
				return true
			end
			local remaining = tonumber(buff.duration)
			if remaining == nil or remaining > refreshWindow then
				return true
			end
		end
	end
	return false
end

local function getTargetType(targetType)
	if targetType == 0 then
		return GameData.BuffTargetType.SELF
	elseif targetType == 1 and hasHostileTarget() then
		return GameData.BuffTargetType.TARGET_HOSTILE
	elseif targetType == 1 then
		return nil -- Ugly workaround to correct for incorrect buffs when no hostile target
	elseif targetType == 2 and hasFriendlyTarget() then
		return GameData.BuffTargetType.TARGET_FRIENDLY
	elseif targetType == 2 then
		return GameData.BuffTargetType.SELF
	else
		return GameData.BuffTargetType.SELF
	end
end

local function getCurrentAP()
	if GameData.Player and GameData.Player.actionPoints then
		local ap = GameData.Player.actionPoints.current
		if type(ap) == "number" then return ap end
	end
	return 0
end

local function getCurrentHPPercent()
	if not GameData.Player then return 100 end
	local hpData = GameData.Player.hitPoints or GameData.Player.health or GameData.Player.HitPoints
	if type(hpData) ~= "table" then return 100 end
	local current = hpData.current or hpData.Current or hpData.cur or hpData.value
	local maximum = hpData.maximum or hpData.max or hpData.Max or hpData.maxValue
	if type(current) ~= "number" or type(maximum) ~= "number" or maximum <= 0 then return 100 end
	return (current / maximum) * 100
end

local function isCareerLine(careerLine, expectedLine)
	return expectedLine ~= nil and careerLine == expectedLine
end

local function getRunepriestZealotMechanic()
	if GCDsaver.RunepriestZealotMechanic ~= nil then
		return GCDsaver.RunepriestZealotMechanic
	end
	local activeActions = ActionBars and ActionBars.m_ActiveActions
	if type(activeActions) == "table"
	and (activeActions[RUNE_PRIEST_MECHANIC_ABILITY] == true
		or activeActions[ZEALOT_MECHANIC_ABILITY] == true)
	then
		return 1
	end
	return 0
end

local function getCurrentCareerMechanic()
	local player = GameData and GameData.Player
	local careerLine = player and player.career and player.career.line
	local careerLines = GameData and GameData.CareerLine or {}

	-- NerfedButtons compatibility: Rune Priest and Zealot expose a toggle state
	-- rather than a useful numeric resource through the original client API.
	if isCareerLine(careerLine, careerLines.RUNE_PRIEST)
	or isCareerLine(careerLine, careerLines.ZEALOT)
	then
		return getRunepriestZealotMechanic()
	end

	if type(GetCareerResource) ~= "function" then return nil end
	local ok, value = pcall(GetCareerResource, GameData.BuffTargetType.SELF)
	if not ok then return nil end
	local current = tonumber(value)
	if current == nil then return nil end

	-- NerfedButtons maps the two-sided Archmage/Shaman resource as signed
	-- values: raw 1..5 becomes -1..-5, raw 6..10 becomes +1..+5.
	if isCareerLine(careerLine, careerLines.ARCHMAGE)
	or isCareerLine(careerLine, careerLines.SHAMAN)
	then
		if current > 5 then return current - 5 end
		if current > 0 then return -current end
		return 0
	end
	return current
end

local function getCareerMechanicRule(actionId)
	if not GCDsaver.Settings or type(GCDsaver.Settings.CareerMechanicRules) ~= "table" then return nil end
	return sanitizeCareerMechanicRule(GCDsaver.Settings.CareerMechanicRules[actionId])
end

local function isCareerMechanicRuleBlocked(rule)
	if rule == nil then return false, nil end
	local current = getCurrentCareerMechanic()
	if current == nil then return true, nil end
	if rule.Mode == CAREER_MECHANIC_MODE_MIN then
		return current < rule.Threshold, current
	elseif rule.Mode == CAREER_MECHANIC_MODE_MAX then
		return current > rule.Threshold, current
	end
	return current ~= rule.Threshold, current
end

local function getResourceRule(actionId)
	if not GCDsaver.Settings or type(GCDsaver.Settings.ResourceRules) ~= "table" then return nil end
	return sanitizeResourceRule(GCDsaver.Settings.ResourceRules[actionId])
end

local function getEffectRefreshWindow(actionId)
	if not GCDsaver.Settings or type(GCDsaver.Settings.EffectRefreshWindows) ~= "table" then return nil end
	return sanitizeEffectRefreshWindow(GCDsaver.Settings.EffectRefreshWindows[actionId])
end

local function isResourceRuleBlocked(rule)
	if not GCDsaver.Settings.ResourceLimitsEnabled or rule == nil then return false end
	if rule.Mode == RESOURCE_MODE_AP then
		return getCurrentAP() > rule.Threshold
	end
	return getCurrentHPPercent() > rule.Threshold
end

local function getEffectTarget(actionId, targetMode)
	if targetMode == EFFECT_TARGET_SELF then
		return GameData.BuffTargetType.SELF
	elseif targetMode == EFFECT_TARGET_HOSTILE then
		if hasHostileTarget() then return GameData.BuffTargetType.TARGET_HOSTILE end
		return nil
	elseif targetMode == EFFECT_TARGET_FRIENDLY then
		if hasFriendlyTarget() then return GameData.BuffTargetType.TARGET_FRIENDLY end
		return nil
	end

	local abilityData = GetAbilityData(actionId)
	if not abilityData then return nil end
	return getTargetType(abilityData.targetType)
end

local function getTargetHealthRule(actionId)
	if not GCDsaver.Settings or type(GCDsaver.Settings.TargetHealthRules) ~= "table" then return nil end
	return sanitizeTargetHealthRule(GCDsaver.Settings.TargetHealthRules[actionId])
end

local function getAbilityTargetHealthPercent(actionId, targetMode)
	local targetType = getEffectTarget(actionId, targetMode)
	-- Explicitly fall back to the player when the requested target is absent.
	if targetType == nil then targetType = GameData.BuffTargetType.SELF end
	if targetType == GameData.BuffTargetType.SELF then
		return clamp(getCurrentHPPercent(), 0, MAX_HP_PERCENT)
	end

	local classification = nil
	if targetType == GameData.BuffTargetType.TARGET_HOSTILE then
		classification = TargetInfo.HOSTILE_TARGET
	elseif targetType == GameData.BuffTargetType.TARGET_FRIENDLY then
		classification = TargetInfo.FRIENDLY_TARGET
	end
	if classification == nil or not TargetInfo.m_Units then return clamp(getCurrentHPPercent(), 0, MAX_HP_PERCENT) end
	local unit = TargetInfo.m_Units[classification]
	if type(unit) ~= "table" or unit.entityid == 0 then
		return clamp(getCurrentHPPercent(), 0, MAX_HP_PERCENT)
	end
	local healthPercent = tonumber(unit.healthPercent or unit.HealthPercent or unit.hitPointPercent)
	if healthPercent == nil then return clamp(getCurrentHPPercent(), 0, MAX_HP_PERCENT) end
	return clamp(healthPercent, 0, MAX_HP_PERCENT)
end

local function isTargetHealthRuleBlocked(actionId, rule)
	if rule == nil then return false, nil end
	local healthPercent = getAbilityTargetHealthPercent(actionId, rule.Target)
	if healthPercent == nil then return true, nil end
	if rule.Mode == TARGET_HP_MODE_MIN then
		return healthPercent < rule.Threshold, healthPercent
	end
	return healthPercent > rule.Threshold, healthPercent
end

local function targetHasEffect(actionId, requirement)
	if requirement == nil then return true end
	local target = getEffectTarget(actionId, requirement.Target)
	if target == nil then return false end
	local effects = GetBuffs(target)
	if type(effects) ~= "table" then return false end
	for _, effect in pairs(effects) do
		local effectId = tonumber(effect.abilityId or effect.abilityID or effect.id or effect.ID or effect.effectId or effect.effectID)
		if effectId == requirement.EffectId and (not requirement.OnlyMine or effect.castByPlayer) then
			return true
		end
	end
	return false
end

local function getVirtualCooldownRemaining(actionId)
	if not GCDsaver.VirtualCooldownExpires then return 0 end
	local expires = GCDsaver.VirtualCooldownExpires[actionId]
	if type(expires) ~= "number" then return 0 end
	local remaining = expires - (GCDsaver.RuntimeTime or 0)
	if remaining <= 0 then
		GCDsaver.VirtualCooldownExpires[actionId] = nil
		return 0
	end
	return remaining
end

local function abilityUsable(id)
	local actionType, actionId, isSlotEnabled, isTargetValid, isSlotBlocked
	for i = 1, MAX_BUTTONS do
		actionType, actionId, isSlotEnabled, isTargetValid, isSlotBlocked = GetHotbarData(i)
		if id == actionId
		and GetHotbarCooldown(i) == 0
		and isSlotEnabled
		and isTargetValid
		then
			return true
		end
	end
	return false
end

-- Auto-attack phase tracking is based on Swinger by Sullemunk, with the
-- bonus-adjusted weapon speed correction by Emissary.
local function getRightHand()
	if not CharacterWindow or not CharacterWindow.equipmentData then
		return nil
	end
	return CharacterWindow.equipmentData[GameData.EquipSlots.RIGHT_HAND]
end

local function getAASyncTarget(lead, duration)
	local target = lead
	while target > duration do
		target = target - duration
	end
	return target
end

local function getAASyncState(actionId)
	if not GCDsaver.Settings
	or not GCDsaver.Settings.Enabled
	or not GCDsaver.Settings.AASyncEnabled
	or not GCDsaver.Settings.AASyncAbilities
	then
		return false
	end

	local lead = GCDsaver.Settings.AASyncAbilities[actionId]
	if lead == nil
	or not GameData.Player
	or not GameData.Player.inCombat
	or not GCDsaver.AASwingActive
	or GCDsaver.AASwingDuration <= 0
	then
		return false
	end

	local target = getAASyncTarget(lead, GCDsaver.AASwingDuration)
	local remaining = GCDsaver.AASwingRemaining
	return abs(remaining - target) > AA_SYNC_TOLERANCE, remaining, lead, target
end

local function alertText(text)
	if SettingsWindowTabInterface
	and SettingsWindowTabInterface.SavedMessageSettings
	and SettingsWindowTabInterface.SavedMessageSettings.combat
	then
		SystemData.AlertText.VecType = {SystemData.AlertText.Types.COMBAT}
		SystemData.AlertText.VecText = {towstring(text)}
		BroadcastEvent(SystemData.Events.SHOW_ALERT_TEXT)
	end
end

local function getAbilityChatText(actionId)
	local data = GetAbilityData(actionId) or {}
	local name = towstring(data.name or actionId)
	local icon = towstring("<icon" .. tostring(data.iconNum or 0) .. ">")
	return icon .. L" " .. name
end

local function chatInfo(actionId, state)
	local abilityText = getAbilityChatText(actionId)
	if not state then
		TextLogAddEntry("Chat", 0, T("chat_no_conditions") .. abilityText)
	elseif state >= 1 and state <= 3 then
		TextLogAddEntry("Chat", 0, T("chat_target_stack_a") .. towstring(state) .. T("chat_target_stack_b") .. abilityText)
	elseif state == IMMOVABLE then
		TextLogAddEntry("Chat", 0, T("chat_immovable") .. abilityText)
	elseif state == UNSTOPPABLE then
		TextLogAddEntry("Chat", 0, T("chat_unstoppable") .. abilityText)
	elseif state >= SELF_1 and state <= SELF_3 then
		TextLogAddEntry("Chat", 0, T("chat_self_stack_a") .. towstring(state - 5) .. T("chat_self_stack_b") .. abilityText)
	end
end

local function chatInfoAA(actionId, lead)
	local abilityText = getAbilityChatText(actionId)
	if lead == nil then
		TextLogAddEntry("Chat", 0, T("chat_aa_clear") .. abilityText)
	else
		TextLogAddEntry("Chat", 0, T("chat_aa_set") .. towstring(formatAALead(lead)) .. T("chat_aa_suffix") .. abilityText)
	end
end
local function getStandardConditionBlockReason(actionId)
	local configuredCheck = GCDsaver.Settings.Abilities[actionId]
	local abilityData = GetAbilityData(actionId)
	local refreshWindow = getEffectRefreshWindow(actionId)

	if GCDsaver.TargetImmovable and configuredCheck == IMMOVABLE then
		return T("alert_immovable")
	elseif GCDsaver.TargetUnstoppable and configuredCheck == UNSTOPPABLE then
		return T("alert_unstoppable")
	elseif abilityData
	and type(configuredCheck) == "number"
	and configuredCheck >= 1 and configuredCheck <= 3
	and hasBuff(getTargetType(abilityData.targetType), abilityData, configuredCheck, refreshWindow)
	then
		return T("alert_target_effect")
	elseif abilityData
	and type(configuredCheck) == "number"
	and configuredCheck >= SELF_1 and configuredCheck <= SELF_3
	and hasBuff(GameData.BuffTargetType.SELF, abilityData, configuredCheck - 5, refreshWindow)
	then
		return T("alert_self_effect")
	end
	return nil
end

local function isAbilityBlocked(actionId, showError)
	if not GCDsaver.Settings.Enabled then return false end

	local reason = getStandardConditionBlockReason(actionId)
	local requirement = sanitizeEffectRequirement(GCDsaver.Settings.EffectRequirements[actionId])
	if reason == nil and requirement ~= nil and not targetHasEffect(actionId, requirement) then
		reason = T("alert_required_missing") .. towstring(requirement.EffectId) .. L")"
	end

	local resourceRule = getResourceRule(actionId)
	if reason == nil and isResourceRuleBlocked(resourceRule) then
		if resourceRule.Mode == RESOURCE_MODE_AP then
			reason = T("alert_too_much_ap") .. towstring(getCurrentAP()) .. T("alert_max") .. towstring(resourceRule.Threshold)
		else
			reason = T("alert_hp_high") .. towstring(floor(getCurrentHPPercent() + 0.5)) .. L"%" .. T("alert_max") .. towstring(resourceRule.Threshold) .. L"%"
		end
	end

	local mechanicRule = getCareerMechanicRule(actionId)
	local mechanicBlocked, currentMechanic = isCareerMechanicRuleBlocked(mechanicRule)
	if reason == nil and mechanicRule ~= nil and mechanicBlocked then
		if currentMechanic == nil then
			reason = T("alert_mechanic_unavailable")
		elseif mechanicRule.Mode == CAREER_MECHANIC_MODE_MIN then
			reason = T("alert_mechanic_low") .. towstring(currentMechanic) .. T("alert_min") .. towstring(mechanicRule.Threshold)
		elseif mechanicRule.Mode == CAREER_MECHANIC_MODE_MAX then
			reason = T("alert_mechanic_high") .. towstring(currentMechanic) .. T("alert_max") .. towstring(mechanicRule.Threshold)
		else
			reason = T("alert_mechanic_different") .. towstring(currentMechanic) .. T("alert_required_value") .. towstring(mechanicRule.Threshold)
		end
	end
	local targetHealthRule = getTargetHealthRule(actionId)
	local targetHealthBlocked, targetHealthPercent = isTargetHealthRuleBlocked(actionId, targetHealthRule)
	if reason == nil and targetHealthRule ~= nil and targetHealthBlocked then
		if targetHealthPercent == nil then
			reason = T("alert_target_hp_unknown")
		elseif targetHealthRule.Mode == TARGET_HP_MODE_MIN then
			reason = T("alert_target_hp_low") .. towstring(floor(targetHealthPercent + 0.5)) .. L"%" .. T("alert_min") .. towstring(targetHealthRule.Threshold) .. L"%"
		else
			reason = T("alert_target_hp_high") .. towstring(floor(targetHealthPercent + 0.5)) .. L"%" .. T("alert_max") .. towstring(targetHealthRule.Threshold) .. L"%"
		end
	end

	local virtualRemaining = getVirtualCooldownRemaining(actionId)
	if reason == nil and virtualRemaining > 0 then
		reason = T("alert_virtual_cd") .. towstring(string.format("%.1f", virtualRemaining)) .. L"s"
	end

	if reason == nil then
		local aaBlocked, remaining, lead = getAASyncState(actionId)
		if aaBlocked then
			reason = T("alert_wait_aa") .. towstring(string.format("%.1f", remaining)) .. L"s" .. T("alert_lead") .. towstring(formatAALead(lead)) .. L"s)"
		end
	end

	if reason ~= nil then
		if showError and GCDsaver.Settings.ErrorMessages and abilityUsable(actionId) then
			alertText(reason)
		end
		return true
	end
	return false
end
local function getConditionSymbol(state)
	if state == IMMOVABLE then
		return "<icon05007>", 255, 255, 255
	elseif state == UNSTOPPABLE then
		return "<icon05006>", 255, 255, 255
	elseif type(state) == "number" and state >= SELF_1 and state <= SELF_3 then
		return "S" .. tostring(state - 5), 0, 255, 255
	elseif type(state) == "number" and state >= 1 and state <= 3 then
		return tostring(state) .. "x", 255, 255, 0
	end
	return nil
end

local function formatResourceRule(rule)
	if rule == nil then return nil end
	if rule.Mode == RESOURCE_MODE_AP then
		return "AP" .. tostring(rule.Threshold)
	end
	return "HP" .. tostring(rule.Threshold) .. "%"
end

local function formatTargetHealthRule(rule)
	if rule == nil then return nil end
	local prefix = "A"
	if rule.Target == EFFECT_TARGET_FRIENDLY then
		prefix = "F"
	elseif rule.Target == EFFECT_TARGET_HOSTILE then
		prefix = "H"
	elseif rule.Target == EFFECT_TARGET_SELF then
		prefix = "S"
	end
	if rule.Mode == TARGET_HP_MODE_MIN then
		return prefix .. "+" .. tostring(rule.Threshold)
	end
	return prefix .. "-" .. tostring(rule.Threshold)
end

local function formatCareerMechanicRule(rule)
	if rule == nil then return nil end
	if rule.Mode == CAREER_MECHANIC_MODE_MIN then
		return "M>" .. tostring(rule.Threshold)
	elseif rule.Mode == CAREER_MECHANIC_MODE_MAX then
		return "M<" .. tostring(rule.Threshold)
	end
	return "M=" .. tostring(rule.Threshold)
end

local function getButtonMarkerParts(actionId)
	local parts = {}
	local conditionText = getConditionSymbol(GCDsaver.Settings.Abilities[actionId])
	if conditionText then table.insert(parts, conditionText) end

	local refreshWindow = getEffectRefreshWindow(actionId)
	local configuredCheck = GCDsaver.Settings.Abilities[actionId]
	if refreshWindow and type(configuredCheck) == "number"
	and ((configuredCheck >= 1 and configuredCheck <= 3)
		or (configuredCheck >= SELF_1 and configuredCheck <= SELF_3))
	then
		table.insert(parts, "R" .. formatAALead(refreshWindow))
	end

	local aaLead = GCDsaver.Settings.AASyncAbilities[actionId]
	if GCDsaver.Settings.AASyncEnabled and aaLead ~= nil then
		table.insert(parts, "AA" .. formatAALead(aaLead))
	end

	local resourceText = formatResourceRule(getResourceRule(actionId))
	if GCDsaver.Settings.ResourceLimitsEnabled and resourceText then
		table.insert(parts, resourceText)
	end

	local mechanicText = formatCareerMechanicRule(getCareerMechanicRule(actionId))
	if mechanicText then table.insert(parts, mechanicText) end

	local targetHealthText = formatTargetHealthRule(getTargetHealthRule(actionId))
	if targetHealthText then table.insert(parts, targetHealthText) end

	local virtualCooldown = sanitizeVirtualCooldown(GCDsaver.Settings.VirtualCooldowns[actionId])
	if virtualCooldown then
		table.insert(parts, "CD" .. formatAALead(virtualCooldown))
	end

	local requirement = sanitizeEffectRequirement(GCDsaver.Settings.EffectRequirements[actionId])
	if requirement then
		table.insert(parts, "FX" .. tostring(requirement.EffectId))
	end
	return parts
end

local function getButtonMarkerWindowName(button)
	if not button or type(button.GetName) ~= "function" then return nil end
	local ok, buttonName = pcall(button.GetName, button)
	if not ok or type(buttonName) ~= "string" or buttonName == "" then return nil end
	return buttonName .. BUTTON_MARKER_SUFFIX, buttonName
end

local function ensureButtonMarkerWindow(button)
	local markerName, buttonName = getButtonMarkerWindowName(button)
	if not markerName then return nil end
	if not DoesWindowExist(markerName) then
		if not CreateWindowFromTemplate(markerName, "EA_Label_DefaultText", buttonName) then return nil end
		WindowSetHandleInput(markerName, false)
		WindowClearAnchors(markerName)
		WindowAddAnchor(markerName, "bottomleft", buttonName, "bottomleft", 3, -3)
		WindowSetDimensions(markerName, BUTTON_MARKER_WIDTH, BUTTON_MARKER_HEIGHT)
		WindowSetLayer(markerName, Window.Layers.OVERLAY)
		LabelSetFont(markerName, "font_clear_small_bold", 9)
		LabelSetTextAlign(markerName, "left")
		LabelSetTextColor(markerName, 255, 255, 0)
		WindowSetShowing(markerName, false)
	end
	return markerName
end

local function applyButtonIcon(button, actionId)
	local parts = getButtonMarkerParts(actionId)
	local shouldShow = GCDsaver.Settings.Enabled and GCDsaver.Settings.Symbols and #parts > 0
	local markerName = getButtonMarkerWindowName(button)

	if not shouldShow then
		if markerName and DoesWindowExist(markerName) then
			LabelSetText(markerName, L"")
			WindowSetShowing(markerName, false)
		end
		return
	end

	markerName = ensureButtonMarkerWindow(button)
	if not markerName then return end
	-- This is deliberately separate from m_Windows[7], which EA_ActionBars
	-- reserves for the native item stack count.
	LabelSetText(markerName, towstring("GS:" .. table.concat(parts, "/")))
	LabelSetTextColor(markerName, 255, 255, 0)
	WindowSetShowing(markerName, true)
end
local function setButtonIcon(actionId)
	local hbar, buttonid
	local buttonActionId
	for i = 1, MAX_BUTTONS do
		_, buttonActionId = GetHotbarData(i)
		if buttonActionId == actionId then
			hbar, buttonid = ActionBars:BarAndButtonIdFromSlot(i)
			if hbar and buttonid then
				applyButtonIcon(hbar.m_Buttons[buttonid], actionId)
			end
		end
	end
end

-- GCDsaver
GCDsaver = GCDsaver or {}
GCDsaver.TargetID = 0
GCDsaver.TargetImmovable = false
GCDsaver.TargetUnstoppable = false
GCDsaver.InCombat = false
GCDsaver.AASwingActive = false
GCDsaver.AASwingRemaining = 0
GCDsaver.AASwingDuration = 0
GCDsaver.AABaseSpeed = 0
GCDsaver.DynamicSlots = {}
GCDsaver.LastDynamicSlotStates = {}
GCDsaver.RuntimeTime = 0
GCDsaver.VirtualCooldownExpires = {}
GCDsaver.PendingVirtualCast = nil
GCDsaver.PendingVirtualAttempts = {}
GCDsaver.RunepriestZealotMechanic = nil

GCDsaver.DefaultSettings = {
	Version = VERSION,
	Enabled = true,
	Symbols = true,
	ErrorMessages = true,
	UseSpanish = false,
	AASyncEnabled = true,
	AASyncAbilities = {},
	ResourceLimitsEnabled = true,
	ResourceRules = {},
	CareerMechanicRules = {},
	TargetHealthRules = {},
	VirtualCooldowns = {},
	EffectRefreshWindows = {},
	EffectRequirements = {},
	Abilities = {
		-- Ironbreaker
		[1384] = UNSTOPPABLE,	-- Cave-In
		[1369] = UNSTOPPABLE,	-- Shield of Reprisal
		[1365] = IMMOVABLE,		-- Away With Ye
		-- Slayer
		[1443] = UNSTOPPABLE,	-- Incapacitate
		-- Runepriest
		[1613] = UNSTOPPABLE,	-- Rune of Binding
		[1607] = UNSTOPPABLE,	-- Spellbinding Rune
		-- Engineer
		[1536] = UNSTOPPABLE,	-- Crack Shot
		[1531] = IMMOVABLE,		-- Concussion Grenade
		-- Black Orc
		[1688] = UNSTOPPABLE,	-- Down Ya Go
		[1683] = UNSTOPPABLE,	-- Shut Yer Face
		-- Choppa
		[1755] = UNSTOPPABLE,	-- Sit Down!
		-- Shaman
		[1929] = IMMOVABLE,		-- Geddoff!
		[1917] = UNSTOPPABLE,	-- You Got Nuthin!
		-- Squig Herder
		[1839] = UNSTOPPABLE,	-- Choking Arrer
		[1837] = UNSTOPPABLE,	-- Drop That!!
		[1835] = UNSTOPPABLE,	-- Not So Fast!
		-- Witch Hunter
		[8110] = UNSTOPPABLE,	-- Dragon Gun
		[8086] = UNSTOPPABLE,	-- Confess!
		[8115] = UNSTOPPABLE,	-- Pistol Whip
		[8100] = UNSTOPPABLE,	-- Silence The Heretic
		[8094] = UNSTOPPABLE,	-- Declare Anathema
		-- Knight of the Blazing Sun
		[8018] = UNSTOPPABLE,	-- Smashing Counter
		[8017] = IMMOVABLE,		-- Repel Darkness
		-- Bright Wizard
		[8186] = UNSTOPPABLE,	-- Stop, Drop, and Roll
		[8174] = UNSTOPPABLE,	-- Choking Smoke
		-- Warrior Priest
		[8256] = UNSTOPPABLE,	-- Vow of Silence
		-- Chosen
		[8346] = UNSTOPPABLE,	-- Downfall
		[8329] = IMMOVABLE,		-- Repel
		-- Marauder
		[8412] = UNSTOPPABLE,	-- Mutated Energy
		[8405] = UNSTOPPABLE,	-- Death Grip
		[8410] = IMMOVABLE,		-- Terrible Embrace
		-- Zealot
		[8571] = UNSTOPPABLE,	-- Aethyric Shock
		[8565] = UNSTOPPABLE,	-- Tzeentch's Lash
		-- Magus
		[8495] = UNSTOPPABLE,	-- Perils of The Warp
		[8483] = IMMOVABLE,		-- Warping Blast
		-- Swordmaster
		[9032] = IMMOVABLE,		-- Redirected Force
		-- [9030] = UNSTOPPABLE,	-- Whispering Window
		[9028] = UNSTOPPABLE,	-- Chrashing Wave
		-- Shadow Warrior
		[9096] = UNSTOPPABLE,	-- Eye Shot
		[9108] = UNSTOPPABLE,	-- Exploit Weakness
		[9098] = UNSTOPPABLE,	-- Opportunistic Strike
		-- White Lion
		[9193] = UNSTOPPABLE,	-- Brutal Pounce
		[9177] = UNSTOPPABLE,	-- Throat Bite
		[9178] = IMMOVABLE,		-- Fetch!
		-- Archmage
		[9266] = IMMOVABLE,		-- Cleansing Flare
		[9253] = UNSTOPPABLE,	-- Law of Gold
		-- Blackguard
		[2888] = UNSTOPPABLE,	-- Malignant Strike!
		[9321] = UNSTOPPABLE,	-- Spiteful Slam
		[9328] = IMMOVABLE,		-- Exile
		-- Witch Elf
		[9422] = UNSTOPPABLE,	-- On Your Knees!
		[9400] = UNSTOPPABLE,	-- Sever Limb
		[9427] = UNSTOPPABLE,	-- Heart Seeker
		[9409] = UNSTOPPABLE,	-- Throat Slitter
		[9396] = UNSTOPPABLE,	-- Agile Escape
		-- Disciple of Khaine
		[9565] = UNSTOPPABLE,	-- Consume Thought
		-- Sorcerer
		[9482] = UNSTOPPABLE,	-- Frostbite
		[9489] = UNSTOPPABLE,	-- Stricken Voices
	},
}

function GCDsaver.NormalizeSettings()
	if type(GCDsaver.Settings) ~= "table" then GCDsaver.Settings = {} end
	local settings = GCDsaver.Settings
	settings.Version = VERSION
	settings.Enabled = defaultIfNil(settings.Enabled, GCDsaver.DefaultSettings.Enabled)
	if settings.Symbols == nil and settings.Icons ~= nil then settings.Symbols = settings.Icons end
	settings.Symbols = defaultIfNil(settings.Symbols, GCDsaver.DefaultSettings.Symbols)
	settings.ErrorMessages = defaultIfNil(settings.ErrorMessages, GCDsaver.DefaultSettings.ErrorMessages)
	if settings.Language == "es" and settings.UseSpanish == nil then settings.UseSpanish = true end
	settings.UseSpanish = defaultIfNil(settings.UseSpanish, GCDsaver.DefaultSettings.UseSpanish)
	settings.Language = settings.UseSpanish and "es" or "en"
	settings.AASyncEnabled = defaultIfNil(settings.AASyncEnabled, GCDsaver.DefaultSettings.AASyncEnabled)
	settings.ResourceLimitsEnabled = defaultIfNil(settings.ResourceLimitsEnabled, GCDsaver.DefaultSettings.ResourceLimitsEnabled)

	if type(settings.Abilities) ~= "table" then
		settings.Abilities = {}
		for actionId, condition in pairs(GCDsaver.DefaultSettings.Abilities) do
			settings.Abilities[actionId] = condition
		end
	end
	if type(settings.AASyncAbilities) ~= "table" then settings.AASyncAbilities = {} end
	if type(settings.ResourceRules) ~= "table" then settings.ResourceRules = {} end
	if type(settings.CareerMechanicRules) ~= "table" then settings.CareerMechanicRules = {} end
	if type(settings.TargetHealthRules) ~= "table" then settings.TargetHealthRules = {} end
	if type(settings.VirtualCooldowns) ~= "table" then settings.VirtualCooldowns = {} end
	if type(settings.EffectRefreshWindows) ~= "table" then settings.EffectRefreshWindows = {} end
	if type(settings.EffectRequirements) ~= "table" then settings.EffectRequirements = {} end

	for actionId, lead in pairs(settings.AASyncAbilities) do
		lead = tonumber(lead)
		if lead == nil or lead < AA_MIN_LEAD or lead > AA_MAX_LEAD then
			settings.AASyncAbilities[actionId] = nil
		else
			settings.AASyncAbilities[actionId] = roundToStep(lead, AA_LEAD_STEP)
		end
	end
	for actionId, rule in pairs(settings.ResourceRules) do
		settings.ResourceRules[actionId] = sanitizeResourceRule(rule)
	end
	for actionId, rule in pairs(settings.CareerMechanicRules) do
		settings.CareerMechanicRules[actionId] = sanitizeCareerMechanicRule(rule)
	end
	for actionId, rule in pairs(settings.TargetHealthRules) do
		settings.TargetHealthRules[actionId] = sanitizeTargetHealthRule(rule)
	end
	for actionId, duration in pairs(settings.VirtualCooldowns) do
		settings.VirtualCooldowns[actionId] = sanitizeVirtualCooldown(duration)
	end
	for actionId, refreshWindow in pairs(settings.EffectRefreshWindows) do
		settings.EffectRefreshWindows[actionId] = sanitizeEffectRefreshWindow(refreshWindow)
	end
	for actionId, requirement in pairs(settings.EffectRequirements) do
		settings.EffectRequirements[actionId] = sanitizeEffectRequirement(requirement)
	end
end

function GCDsaver.ImportPotsSaverSettings()
	local legacy = type(PotsSaver) == "table" and PotsSaver.Settings or nil
	if type(legacy) ~= "table" then return false end
	local rules = legacy.AbilityRules or legacy.Rules
	if type(rules) ~= "table" then return false end
	local imported = false
	for actionId, rule in pairs(rules) do
		if GCDsaver.Settings.ResourceRules[actionId] == nil then
			local normalized = sanitizeResourceRule(rule)
			if normalized then
				GCDsaver.Settings.ResourceRules[actionId] = normalized
				imported = true
			end
		end
	end
	if legacy.Enabled ~= nil then GCDsaver.Settings.ResourceLimitsEnabled = legacy.Enabled == true end
	return imported
end

function GCDsaver.Initialize()
	GCDsaver.NormalizeSettings()
	GCDsaver.ImportPotsSaverSettings()
	GCDsaver.NormalizeSettings()
	GCDsaver.EnsureActionButtonHook()
	GCDsaver.RunepriestZealotMechanic = getRunepriestZealotMechanic()

	LibSlash.RegisterSlashCmd("gcdsaver", function(input) GCDsaver_Config.Slash(input) end)
	LibSlash.RegisterSlashCmd("potssaver", function(input) GCDsaver_Config.Slash(input) end)
	LibSlash.RegisterSlashCmd("appotssaver", function(input) GCDsaver_Config.Slash(input) end)
	LibSlash.RegisterSlashCmd("hppotssaver", function(input) GCDsaver_Config.Slash(input) end)

	PotsSaver = PotsSaver or {}
	PotsSaver.OpenConfig = function() GCDsaver_Config.Slash("") end

	GCDsaver.RegisterEvents()
	GCDsaver.RebuildDynamicSlots()
	GCDsaver.UpdateButtonIcons()
	GCDsaver.UpdateButtonsEnabledStates()
	TextLogAddEntry("Chat", 0, L"<icon57> GCDsaver v" .. towstring(GCDsaver.Settings.Version) .. T("loaded_suffix"))
	TextLogAddEntry("Chat", 0, T("credits"))
end
function GCDsaver.OnShutdown()
	GCDsaver.UnregisterEvents()
end

function GCDsaver.RegisterEvents()
	if not eventsRegistered then
		RegisterEventHandler(SystemData.Events.PLAYER_TARGET_UPDATED, "GCDsaver.PLAYER_TARGET_UPDATED")
		RegisterEventHandler(SystemData.Events.PLAYER_TARGET_IS_IMMUNE_TO_MOVEMENT_IMPARING, "GCDsaver.PLAYER_TARGET_IS_IMMUNE_TO_MOVEMENT_IMPARING")
		RegisterEventHandler(SystemData.Events.PLAYER_TARGET_IS_IMMUNE_TO_DISABLES, "GCDsaver.PLAYER_TARGET_IS_IMMUNE_TO_DISABLES")
		RegisterEventHandler(SystemData.Events.PLAYER_EFFECTS_UPDATED, "GCDsaver.PLAYER_EFFECTS_UPDATED")
		RegisterEventHandler(SystemData.Events.PLAYER_TARGET_EFFECTS_UPDATED, "GCDsaver.PLAYER_TARGET_EFFECTS_UPDATED")
		RegisterEventHandler(SystemData.Events.PLAYER_HOT_BAR_UPDATED, "GCDsaver.PLAYER_HOT_BAR_UPDATED")
		RegisterEventHandler(SystemData.Events.PLAYER_HOT_BAR_PAGE_UPDATED, "GCDsaver.PLAYER_HOT_BAR_UPDATED")
		RegisterEventHandler(SystemData.Events.PLAYER_EQUIPMENT_SLOT_UPDATED, "GCDsaver.PLAYER_EQUIPMENT_SLOT_UPDATED")
		RegisterEventHandler(SystemData.Events.PLAYER_BEGIN_CAST, "GCDsaver.PLAYER_BEGIN_CAST")
		RegisterEventHandler(SystemData.Events.PLAYER_END_CAST, "GCDsaver.PLAYER_END_CAST")
		RegisterEventHandler(SystemData.Events.PLAYER_ABILITY_TOGGLED, "GCDsaver.PLAYER_ABILITY_TOGGLED")
		RegisterEventHandler(SystemData.Events.PLAYER_CAREER_RESOURCE_UPDATED, "GCDsaver.PLAYER_CAREER_RESOURCE_UPDATED")
		RegisterEventHandler(TextLogGetUpdateEventId("Combat"), "GCDsaver.COMBAT_LOG_UPDATED")
	end
	eventsRegistered = true
end

function GCDsaver.UnregisterEvents()
	if eventsRegistered then
		UnregisterEventHandler(SystemData.Events.PLAYER_TARGET_UPDATED, "GCDsaver.PLAYER_TARGET_UPDATED")
		UnregisterEventHandler(SystemData.Events.PLAYER_TARGET_IS_IMMUNE_TO_MOVEMENT_IMPARING, "GCDsaver.PLAYER_TARGET_IS_IMMUNE_TO_MOVEMENT_IMPARING")
		UnregisterEventHandler(SystemData.Events.PLAYER_TARGET_IS_IMMUNE_TO_DISABLES, "GCDsaver.PLAYER_TARGET_IS_IMMUNE_TO_DISABLES")
		UnregisterEventHandler(SystemData.Events.PLAYER_EFFECTS_UPDATED, "GCDsaver.PLAYER_EFFECTS_UPDATED")
		UnregisterEventHandler(SystemData.Events.PLAYER_TARGET_EFFECTS_UPDATED, "GCDsaver.PLAYER_TARGET_EFFECTS_UPDATED")
		UnregisterEventHandler(SystemData.Events.PLAYER_HOT_BAR_UPDATED, "GCDsaver.PLAYER_HOT_BAR_UPDATED")
		UnregisterEventHandler(SystemData.Events.PLAYER_HOT_BAR_PAGE_UPDATED, "GCDsaver.PLAYER_HOT_BAR_UPDATED")
		UnregisterEventHandler(SystemData.Events.PLAYER_EQUIPMENT_SLOT_UPDATED, "GCDsaver.PLAYER_EQUIPMENT_SLOT_UPDATED")
		UnregisterEventHandler(SystemData.Events.PLAYER_BEGIN_CAST, "GCDsaver.PLAYER_BEGIN_CAST")
		UnregisterEventHandler(SystemData.Events.PLAYER_END_CAST, "GCDsaver.PLAYER_END_CAST")
		UnregisterEventHandler(SystemData.Events.PLAYER_ABILITY_TOGGLED, "GCDsaver.PLAYER_ABILITY_TOGGLED")
		UnregisterEventHandler(SystemData.Events.PLAYER_CAREER_RESOURCE_UPDATED, "GCDsaver.PLAYER_CAREER_RESOURCE_UPDATED")
		UnregisterEventHandler(TextLogGetUpdateEventId("Combat"), "GCDsaver.COMBAT_LOG_UPDATED")
	end
	eventsRegistered = false
end

-- Event handlers
function GCDsaver.PLAYER_TARGET_UPDATED(targetClassification, targetId, targetType)
	-- Ignore mouseover changes. Current-target health changes also arrive here.
	if targetClassification == TargetInfo.HOSTILE_TARGET then
		if GCDsaver.TargetID ~= targetId then
			GCDsaver.TargetID = targetId
			GCDsaver.TargetImmovable = false
			GCDsaver.TargetUnstoppable = false
		end
		GCDsaver.UpdateButtonsEnabledStates()
	elseif targetClassification == TargetInfo.FRIENDLY_TARGET then
		GCDsaver.UpdateButtonsEnabledStates()
	end
end

function GCDsaver.PLAYER_TARGET_IS_IMMUNE_TO_DISABLES(state)
	GCDsaver.SetUnstoppable(state)
	GCDsaver.UpdateButtonsEnabledStates()
end

function GCDsaver.PLAYER_TARGET_IS_IMMUNE_TO_MOVEMENT_IMPARING(state)
	GCDsaver.SetImmovable(state)
	GCDsaver.UpdateButtonsEnabledStates()
end

function GCDsaver.PLAYER_EFFECTS_UPDATED(updatedEffects, isFullList)
	GCDsaver.UpdateButtonsEnabledStates()
end

function GCDsaver.PLAYER_TARGET_EFFECTS_UPDATED(updateType, updatedEffects, isFullList)
	GCDsaver.UpdateButtonsEnabledStates()
end

function GCDsaver.PLAYER_CAREER_RESOURCE_UPDATED(oldValue, newValue)
	GCDsaver.LastDynamicSlotStates = {}
	GCDsaver.UpdateButtonsEnabledStates()
end

function GCDsaver.PLAYER_HOT_BAR_UPDATED()
	GCDsaver.RebuildDynamicSlots()
	GCDsaver.UpdateButtonIcons()
	GCDsaver.UpdateButtonsEnabledStates()
end

function GCDsaver.PLAYER_EQUIPMENT_SLOT_UPDATED()
	GCDsaver.RefreshAutoAttackSpeed()
end

function GCDsaver.StartVirtualCooldown(actionId)
	actionId = tonumber(actionId)
	if actionId == nil or actionId == 0 then return end
	local duration = sanitizeVirtualCooldown(GCDsaver.Settings.VirtualCooldowns[actionId])
	if duration == nil then return end
	if getVirtualCooldownRemaining(actionId) > 0 then return end
	GCDsaver.VirtualCooldownExpires[actionId] = GCDsaver.RuntimeTime + duration
	GCDsaver.PendingVirtualAttempts[actionId] = nil
	GCDsaver.LastDynamicSlotStates = {}
	GCDsaver.UpdateButtonsEnabledStates()
end

function GCDsaver.QueueVirtualCooldownAttempt(actionId, slot)
	actionId = tonumber(actionId)
	slot = tonumber(slot)
	if actionId == nil or actionId == 0 or slot == nil then return end
	if sanitizeVirtualCooldown(GCDsaver.Settings.VirtualCooldowns[actionId]) == nil then return end
	if GCDsaver.PendingVirtualCast == actionId or getVirtualCooldownRemaining(actionId) > 0 then return end

	local now = GCDsaver.RuntimeTime or 0
	GCDsaver.PendingVirtualAttempts[actionId] = {
		Slot = slot,
		CheckAt = now + VIRTUAL_ATTEMPT_CONFIRM_DELAY,
		ExpiresAt = now + VIRTUAL_ATTEMPT_TIMEOUT,
	}
end

function GCDsaver.UpdatePendingVirtualCooldownAttempts()
	local now = GCDsaver.RuntimeTime or 0
	for actionId, attempt in pairs(GCDsaver.PendingVirtualAttempts) do
		if getVirtualCooldownRemaining(actionId) > 0 then
			GCDsaver.PendingVirtualAttempts[actionId] = nil
		elseif now >= attempt.CheckAt then
			local _, currentActionId = GetHotbarData(attempt.Slot)
			local cooldown = tonumber(GetHotbarCooldown(attempt.Slot)) or 0
			if cooldown > 0 or (currentActionId and currentActionId ~= 0 and currentActionId ~= actionId) then
				GCDsaver.StartVirtualCooldown(actionId)
			elseif now >= attempt.ExpiresAt then
				-- No GCD and no sequence advance: the activation was rejected.
				GCDsaver.PendingVirtualAttempts[actionId] = nil
			end
		end
	end
end

function GCDsaver.PLAYER_BEGIN_CAST(abilityId, isChanneledSpell, desiredCastTime, averageLatency)
	abilityId = tonumber(abilityId)
	if abilityId == nil or abilityId == 0 then return end
	GCDsaver.PendingVirtualAttempts[abilityId] = nil
	if isChanneledSpell or (tonumber(desiredCastTime) or 0) == 0 then
		GCDsaver.PendingVirtualCast = nil
		GCDsaver.StartVirtualCooldown(abilityId)
	else
		GCDsaver.PendingVirtualCast = abilityId
	end
end

function GCDsaver.PLAYER_END_CAST(fail)
	local abilityId = GCDsaver.PendingVirtualCast
	GCDsaver.PendingVirtualCast = nil
	if abilityId and not fail then GCDsaver.StartVirtualCooldown(abilityId) end
end

function GCDsaver.PLAYER_ABILITY_TOGGLED(abilityId, isActive)
	abilityId = tonumber(abilityId)
	if abilityId == RUNE_PRIEST_MECHANIC_ABILITY or abilityId == ZEALOT_MECHANIC_ABILITY then
		GCDsaver.RunepriestZealotMechanic = isActive and 1 or 0
		GCDsaver.LastDynamicSlotStates = {}
		GCDsaver.UpdateButtonsEnabledStates()
	end
	if isActive then GCDsaver.StartVirtualCooldown(abilityId) end
end

function GCDsaver.COMBAT_LOG_UPDATED(updateType, filterType)
	if updateType ~= SystemData.TextLogUpdate.ADDED
	or filterType ~= SystemData.ChatLogFilters.YOUR_HITS
	then
		return
	end

	local count = TextLogGetNumEntries("Combat")
	if not count or count <= 0 then return end

	local _, _, text = TextLogGetEntry("Combat", count - 1)
	if not text then return end

	local lowerText = wstring.lower(text)
	if lowerText:find(L"attack")
	or lowerText:find(L"ability")
	or lowerText:find(L"ataque")
	or lowerText:find(L"habilidad")
	then
		GCDsaver.OnAutoAttackSwing()
	end
end

function GCDsaver.RefreshAutoAttackSpeed()
	local slot = getRightHand()
	if not slot or not slot.speed then
		GCDsaver.AABaseSpeed = 0
		return false
	end

	GCDsaver.AABaseSpeed = GetBonus(GameData.BonusTypes.EBONUS_AUTO_ATTACK_SPEED, slot.speed) or 0
	return GCDsaver.AABaseSpeed > 0
end

function GCDsaver.OnAutoAttackSwing()
	if not GCDsaver.RefreshAutoAttackSpeed() then
		GCDsaver.AASwingActive = false
		GCDsaver.AASwingRemaining = 0
		GCDsaver.AASwingDuration = 0
		return
	end

	GCDsaver.AASwingActive = true
	GCDsaver.AASwingDuration = GCDsaver.AABaseSpeed
	GCDsaver.AASwingRemaining = GCDsaver.AASwingDuration
	GCDsaver.LastDynamicSlotStates = {}
end

function GCDsaver.UpdateAutoAttackTimer(elapsed)
	local inCombat = (GameData.Player and GameData.Player.inCombat) or false
	if inCombat ~= GCDsaver.InCombat then
		GCDsaver.InCombat = inCombat
		if not inCombat then
			GCDsaver.AASwingActive = false
			GCDsaver.AASwingRemaining = 0
			GCDsaver.AASwingDuration = 0
			GCDsaver.LastDynamicSlotStates = {}
		end
	end

	if not inCombat or not GCDsaver.AASwingActive then
		return
	end

	GCDsaver.AASwingRemaining = GCDsaver.AASwingRemaining - elapsed
	if GCDsaver.AASwingRemaining <= 0 then
		GCDsaver.AASwingRemaining = 0
		GCDsaver.AASwingActive = false
		GCDsaver.LastDynamicSlotStates = {}
	end
end

-- Main update function
function GCDsaver.OnUpdate(elapsed)
	GCDsaver.RuntimeTime = GCDsaver.RuntimeTime + elapsed
	if not GCDsaver.Settings.Enabled then return end
	GCDsaver.EnsureActionButtonHook()

	GCDsaver.UpdatePendingVirtualCooldownAttempts()
	GCDsaver.UpdateAutoAttackTimer(elapsed)
	dynamicButtonTimeLeft = dynamicButtonTimeLeft - elapsed
	if dynamicButtonTimeLeft <= 0 then
		dynamicButtonTimeLeft = DYNAMIC_BUTTON_UPDATE_DELAY
		GCDsaver.UpdateDynamicButtonStates()
	end

	iconTimeLeft = iconTimeLeft - elapsed
	if iconTimeLeft <= 0 then
		iconTimeLeft = ICON_UPDATE_DELAY
		GCDsaver.RebuildDynamicSlots()
		GCDsaver.UpdateButtonIcons()
	end
end

function GCDsaver.UpdateSettings()
	GCDsaver.NormalizeSettings()
	if GCDsaver.Settings.Enabled and not eventsRegistered then
		GCDsaver.RegisterEvents()
	elseif not GCDsaver.Settings.Enabled and eventsRegistered then
		GCDsaver.UnregisterEvents()
	end

	GCDsaver.RebuildDynamicSlots()
	GCDsaver.LastDynamicSlotStates = {}
	GCDsaver.UpdateButtonIcons()
	GCDsaver.UpdateButtonsEnabledStates()

	TextLogAddEntry("Chat", 0, L"GCDsaver v" .. towstring(GCDsaver.Settings.Version) .. T("settings_suffix"))
	TextLogAddEntry("Chat", 0, GCDsaver.Settings.Enabled and T("status_enabled") or T("status_disabled"))
	TextLogAddEntry("Chat", 0, GCDsaver.Settings.Symbols and T("status_symbols_on") or T("status_symbols_off"))
	TextLogAddEntry("Chat", 0, GCDsaver.Settings.ErrorMessages and T("status_errors_on") or T("status_errors_off"))
	TextLogAddEntry("Chat", 0, GCDsaver.Settings.AASyncEnabled and T("status_aa_on") or T("status_aa_off"))
	TextLogAddEntry("Chat", 0, GCDsaver.Settings.ResourceLimitsEnabled and T("status_resource_on") or T("status_resource_off"))
end

function GCDsaver.SetImmovable(isImmovable)
	GCDsaver.TargetImmovable = isImmovable
end

function GCDsaver.SetUnstoppable(isUnstoppable)
	GCDsaver.TargetUnstoppable = isUnstoppable
end

function GCDsaver.GetAbilityConfiguration(actionId)
	return {
		Condition = GCDsaver.Settings.Abilities[actionId],
		AALead = GCDsaver.Settings.AASyncAbilities[actionId],
		ResourceRule = getResourceRule(actionId),
		CareerMechanicRule = getCareerMechanicRule(actionId),
		TargetHealthRule = getTargetHealthRule(actionId),
		VirtualCooldown = sanitizeVirtualCooldown(GCDsaver.Settings.VirtualCooldowns[actionId]),
		EffectRefreshWindow = getEffectRefreshWindow(actionId),
		EffectRequirement = sanitizeEffectRequirement(GCDsaver.Settings.EffectRequirements[actionId]),
	}
end

function GCDsaver.ConfigureAbility(actionId, configuration)
	if type(configuration) ~= "table" or not actionId or actionId == 0 then return end
	GCDsaver.Settings.Abilities[actionId] = configuration.Condition
	GCDsaver.Settings.AASyncAbilities[actionId] = configuration.AALead
	GCDsaver.Settings.ResourceRules[actionId] = configuration.ResourceRule
	GCDsaver.Settings.CareerMechanicRules[actionId] = configuration.CareerMechanicRule
	GCDsaver.Settings.TargetHealthRules[actionId] = configuration.TargetHealthRule
	GCDsaver.Settings.VirtualCooldowns[actionId] = configuration.VirtualCooldown
	GCDsaver.Settings.EffectRefreshWindows[actionId] = configuration.EffectRefreshWindow
	GCDsaver.Settings.EffectRequirements[actionId] = configuration.EffectRequirement
	GCDsaver.NormalizeSettings()
	GCDsaver.RebuildDynamicSlots()
	GCDsaver.LastDynamicSlotStates = {}
	setButtonIcon(actionId)
	GCDsaver.UpdateButtonsEnabledStates()
end

function GCDsaver.UpdateButtonIcons()
	for slot = 1, MAX_BUTTONS do
		local _, actionId = GetHotbarData(slot)
		if actionId and actionId ~= 0 then
			local hbar, buttonid = ActionBars:BarAndButtonIdFromSlot(slot)
			if hbar and buttonid then applyButtonIcon(hbar.m_Buttons[buttonid], actionId) end
		end
	end
end

local function isDynamicAction(actionId)
	return GCDsaver.Settings.AASyncAbilities[actionId] ~= nil
		or GCDsaver.Settings.ResourceRules[actionId] ~= nil
		or GCDsaver.Settings.CareerMechanicRules[actionId] ~= nil
		or GCDsaver.Settings.TargetHealthRules[actionId] ~= nil
		or GCDsaver.Settings.VirtualCooldowns[actionId] ~= nil
		or GCDsaver.Settings.EffectRefreshWindows[actionId] ~= nil
end

function GCDsaver.RebuildDynamicSlots()
	local previousSlots = GCDsaver.DynamicSlots or {}
	local newSlots = {}
	for slot = 1, MAX_BUTTONS do
		local _, actionId = GetHotbarData(slot)
		if actionId and actionId ~= 0 and isDynamicAction(actionId) then
			newSlots[slot] = actionId
		end
	end
	for slot = 1, MAX_BUTTONS do
		local previousActionId = previousSlots[slot]
		local currentActionId = newSlots[slot]
		if previousActionId ~= currentActionId then
			GCDsaver.LastDynamicSlotStates[slot] = nil
			-- RoR server-side cast sequences may not emit PLAYER_BEGIN_CAST for
			-- instant abilities. A sequence advance during the GCD confirms that
			-- the previous configured ability was successfully used.
			if previousActionId
			and sanitizeVirtualCooldown(GCDsaver.Settings.VirtualCooldowns[previousActionId]) ~= nil
			and (tonumber(GetHotbarCooldown(slot)) or 0) > 0
			then
				GCDsaver.StartVirtualCooldown(previousActionId)
			end
		end
	end
	GCDsaver.DynamicSlots = newSlots
end

local function getDynamicStateSignature(actionId)
	local aaBlocked = getAASyncState(actionId)
	local resourceBlocked = isResourceRuleBlocked(getResourceRule(actionId))
	local mechanicBlocked = isCareerMechanicRuleBlocked(getCareerMechanicRule(actionId))
	local targetHealthBlocked = isTargetHealthRuleBlocked(actionId, getTargetHealthRule(actionId))
	local virtualBlocked = getVirtualCooldownRemaining(actionId) > 0
	local refreshBlocked = getEffectRefreshWindow(actionId) ~= nil and getStandardConditionBlockReason(actionId) ~= nil
	return tostring(actionId) .. "|" .. tostring(aaBlocked) .. "|" .. tostring(resourceBlocked) .. "|" .. tostring(mechanicBlocked) .. "|" .. tostring(targetHealthBlocked) .. "|" .. tostring(virtualBlocked) .. "|" .. tostring(refreshBlocked)
end

function GCDsaver.UpdateDynamicButtonStates()
	for slot, actionId in pairs(GCDsaver.DynamicSlots) do
		local signature = getDynamicStateSignature(actionId)
		if GCDsaver.LastDynamicSlotStates[slot] ~= signature then
			GCDsaver.LastDynamicSlotStates[slot] = signature
			local actionType, currentActionId, isSlotEnabled, isTargetValid, isSlotBlocked = GetHotbarData(slot)
			if currentActionId == actionId then
				ActionBars.UpdateSlotEnabledState(slot, isSlotEnabled, isTargetValid, isSlotBlocked)
			end
		end
	end
end

function GCDsaver.UpdateButtonsEnabledStates()
	for slot = 1, MAX_BUTTONS do
		local actionType, actionId, isSlotEnabled, isTargetValid, isSlotBlocked = GetHotbarData(slot)
		ActionBars.UpdateSlotEnabledState(slot, isSlotEnabled, isTargetValid, isSlotBlocked)
	end
end
-- Hooked Functions
local orgActionButtonUpdateInventory = ActionButton.UpdateInventory
local orgActionBarsUpdateSlotEnabledState = ActionBars.UpdateSlotEnabledState
-- Original GCDsaver 1.0.7 blocks execution by replacing WindowGameAction.
-- Keep that proven gate, while restoring it safely after the matching release.
local fallbackWindowGameAction = WindowGameAction
local savedWindowGameAction = nil

local function blockedWindowGameAction(windowName)
end

local function blockWindowGameAction()
	if WindowGameAction ~= blockedWindowGameAction then
		savedWindowGameAction = WindowGameAction
	end
	WindowGameAction = blockedWindowGameAction
end

local function restoreWindowGameAction()
	if WindowGameAction == blockedWindowGameAction then
		WindowGameAction = savedWindowGameAction or fallbackWindowGameAction
	end
	savedWindowGameAction = nil
end

local function suppressNextActionButtonUp(button)
	GCDsaver.SuppressedActionButtonUps = GCDsaver.SuppressedActionButtonUps or {}
	GCDsaver.SuppressedActionButtonUps[button] = true
	blockWindowGameAction()
end

local function hasButtonFlag(flags, expectedFlag)
	if flags == expectedFlag then return true end
	if flags ~= nil and type(BitAnd) == "function" then
		return BitAnd(flags, expectedFlag) ~= 0
	end
	return false
end

function ActionButton.UpdateInventory(self)
	orgActionButtonUpdateInventory(self)
	if self and self.m_Windows and self.m_Windows[7] then
		-- Older GCDsaver builds reused this label for markers. Restore its
		-- native appearance and leave its text/showing state to EA_ActionBars.
		self.m_Windows[7]:SetFont("font_chat_text", WindowUtils.FONT_DEFAULT_TEXT_LINESPACING)
		self.m_Windows[7]:SetTextColor(255, 255, 255)
	end
	if self and self.m_ActionId and self.m_ActionId ~= 0 then
		applyButtonIcon(self, self.m_ActionId)
	end
end

function GCDsaver.HandleActionButtonOnLButtonDown(nextHandler, self, flags, x, y)
	if not self or not self.m_ActionId or self.m_ActionId == 0 then
		restoreWindowGameAction()
		return nextHandler(self, flags, x, y)
	end

	if hasButtonFlag(flags, SystemData.ButtonFlags.ALT) then
		suppressNextActionButtonUp(self)
		if GCDsaver_AbilityMenu and GCDsaver_AbilityMenu.Open then
			GCDsaver_AbilityMenu.Open(self.m_ActionId)
		else
			TextLogAddEntry("Chat", 0, T("editor_unavailable"))
		end
		return
	end

	if hasButtonFlag(flags, SystemData.ButtonFlags.SHIFT) then
		suppressNextActionButtonUp(self)
		local current = GCDsaver.Settings.Abilities[self.m_ActionId]
		if type(current) ~= "number" then
			GCDsaver.Settings.Abilities[self.m_ActionId] = 1
		elseif current < SELF_3 then
			GCDsaver.Settings.Abilities[self.m_ActionId] = current + 1
		else
			GCDsaver.Settings.Abilities[self.m_ActionId] = nil
		end
		setButtonIcon(self.m_ActionId)
		GCDsaver.UpdateButtonsEnabledStates()
		chatInfo(self.m_ActionId, GCDsaver.Settings.Abilities[self.m_ActionId])
		return
	end

	if isAbilityBlocked(self.m_ActionId, true) then
		suppressNextActionButtonUp(self)
		return
	end

	-- A key event may not always produce a matching Lua release callback.
	-- Clear any stale suppression before an allowed activation.
	if GCDsaver.SuppressedActionButtonUps then
		GCDsaver.SuppressedActionButtonUps[self] = nil
	end
	restoreWindowGameAction()
	local actionId = self.m_ActionId
	local slot = self.m_HotBarSlot
	local wasReady = slot ~= nil and (tonumber(GetHotbarCooldown(slot)) or 0) <= 0
	local result = nextHandler(self, flags, x, y)
	-- Fallback for zero-CD instant abilities, especially inside Sequencer.
	-- The attempt is only confirmed if a previously ready slot enters the GCD or advances.
	if wasReady then GCDsaver.QueueVirtualCooldownAttempt(actionId, slot) end
	return result
end

function GCDsaver.HandleActionButtonOnLButtonUp(nextHandler, self, flags, x, y)
	local suppressed = self
		and GCDsaver.SuppressedActionButtonUps
		and GCDsaver.SuppressedActionButtonUps[self]
	if suppressed then
		GCDsaver.SuppressedActionButtonUps[self] = nil
		restoreWindowGameAction()
		return
	end

	if self and self.m_ActionId and self.m_ActionId ~= 0 and isAbilityBlocked(self.m_ActionId, true) then
		restoreWindowGameAction()
		return
	end

	restoreWindowGameAction()
	return nextHandler(self, flags, x, y)
end

function GCDsaver.EnsureActionButtonHook()
	if ActionButton.OnLButtonDown ~= GCDsaver.ActionButtonDownHook then
		local nextDownHandler = ActionButton.OnLButtonDown
		if type(nextDownHandler) == "function" then
			local downHook = function(self, flags, x, y)
				return GCDsaver.HandleActionButtonOnLButtonDown(nextDownHandler, self, flags, x, y)
			end
			GCDsaver.ActionButtonDownHook = downHook
			ActionButton.OnLButtonDown = downHook
		end
	end

	if ActionButton.OnLButtonUp ~= GCDsaver.ActionButtonUpHook then
		local nextUpHandler = ActionButton.OnLButtonUp
		if type(nextUpHandler) == "function" then
			local upHook = function(self, flags, x, y)
				return GCDsaver.HandleActionButtonOnLButtonUp(nextUpHandler, self, flags, x, y)
			end
			GCDsaver.ActionButtonUpHook = upHook
			ActionButton.OnLButtonUp = upHook
		end
	end
end

function ActionBars.UpdateSlotEnabledState(slot, isSlotEnabled, isTargetValid, isSlotBlocked)
	local hbar, buttonid = ActionBars:BarAndButtonIdFromSlot(slot)
	if hbar and buttonid then
		local button = hbar.m_Buttons[buttonid]
		if button and button.m_ActionId and button.m_ActionId ~= 0 and isAbilityBlocked(button.m_ActionId, false) then
			isSlotEnabled = false
		end
	end
	orgActionBarsUpdateSlotEnabledState(slot, isSlotEnabled, isTargetValid, isSlotBlocked)
end
