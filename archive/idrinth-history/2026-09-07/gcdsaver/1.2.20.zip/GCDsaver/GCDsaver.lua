-- Local
local VERSION = "1.2.20"
local ICON_UPDATE_DELAY = 0.5
local DYNAMIC_BUTTON_UPDATE_DELAY = 0.05
local VIRTUAL_ATTEMPT_CONFIRM_DELAY = 0.05
local VIRTUAL_ATTEMPT_TIMEOUT = 0.50
local iconTimeLeft = ICON_UPDATE_DELAY
local dynamicButtonTimeLeft = DYNAMIC_BUTTON_UPDATE_DELAY
local AA_MIN_LEAD = 0
local AA_MAX_LEAD = 3
local AA_LEAD_STEP = 0.5
local EFFECT_REFRESH_MIN = 0
local EFFECT_REFRESH_MAX = 30
local EFFECT_REFRESH_STEP = 0.5
local CAREER_MECHANIC_MIN = -250
local CAREER_MECHANIC_MAX = 250
local CAREER_MECHANIC_MODE_MIN = "MIN"
local CAREER_MECHANIC_MODE_MAX = "MAX"
local CAREER_MECHANIC_MODE_EQUAL = "EQUAL"
local RUNE_PRIEST_MECHANIC_ABILITY = 1659
local ZEALOT_MECHANIC_ABILITY = 8550
local AA_SYNC_TOLERANCE = 0.20
local MAX_STACK = 3
local IMMOVABLE = 4
local UNSTOPPABLE = 5
local SELF_1 = 6
local SELF_2 = 7
local SELF_3 = 8
local MAX_BUTTONS = 60
local MAX_AP = 200
local MAX_HP_PERCENT = 100
local BUTTON_MARKER_SUFFIX = "GCDsaverMarker"
local BUTTON_MARKER_WIDTH = 42
local BUTTON_MARKER_HEIGHT = 16
local RESOURCE_MODE_AP = "AP"
local RESOURCE_MODE_HP = "HP"
local TARGET_HP_MODE_MIN = "MIN"
local TARGET_HP_MODE_MAX = "MAX"
local EFFECT_TARGET_ABILITY = "ABILITY"
local EFFECT_TARGET_HOSTILE = "HOSTILE"
local EFFECT_TARGET_FRIENDLY = "FRIENDLY"
local EFFECT_TARGET_SELF = "SELF"
local pairs = pairs
local abs = math.abs
local floor = math.floor
local eventsRegistered = false
-- Snapshots live only for one synchronous visual refresh, never across frames.
-- Input checks explicitly bypass them, including input re-entered by other addons.
local evaluationContext = nil
local diagnosticCount = 0

local function diagnosticLog(message)
	if diagnosticCount >= 200 or type(LogLuaMessage) ~= "function" then return end
	diagnosticCount = diagnosticCount + 1
	local filters = SystemData and SystemData.UiLogFilters
	local filter = filters and (filters.WARNING or filters.ERROR or filters.DEBUG) or 0
	pcall(LogLuaMessage, "Lua", filter,
		towstring("[GCDS-DIAG] " .. tostring(message)))
end

local function diagnosticAction(stage, button, flags, actionType, actionId)
	local active = SystemData and SystemData.ActiveWindow and SystemData.ActiveWindow.name or "nil"
	local slot = button and button.m_HotBarSlot or "nil"
	local cachedType = button and button.m_ActionType or "nil"
	local cachedId = button and button.m_ActionId or "nil"
	diagnosticLog(stage .. " flags=" .. tostring(flags)
		.. " active=" .. tostring(active) .. " slot=" .. tostring(slot)
		.. " actual=" .. tostring(actionType) .. ":" .. tostring(actionId)
		.. " cached=" .. tostring(cachedType) .. ":" .. tostring(cachedId))
end

local function evaluationValue(group, key, readValue)
	if not evaluationContext then return readValue(key) end
	local cache = evaluationContext[group]
	if not cache then
		cache = {}
		evaluationContext[group] = cache
	end
	local value = cache[key]
	if value == nil then
		value = readValue(key)
		cache[key] = value or false
	end
	return value or nil
end

local function finishEvaluation(previous, ok, ...)
	evaluationContext = previous
	if not ok then error((...), 0) end
	return ...
end

local function withEvaluation(callback, ...)
	if evaluationContext then return callback(...) end
	evaluationContext = {}
	return finishEvaluation(nil, pcall(callback, ...))
end

local function getBuffSnapshot(target)
	return evaluationValue("buffs", target, GetBuffs)
end

local function getAbilitySnapshot(actionId)
	return evaluationValue("abilities", actionId, GetAbilityData)
end

local function T(key)
	return GCDsaver_Lang.Get(key)
end

local function defaultIfNil(value, default)
	if value == nil then
		return default
	end
	return value
end

local function clamp(value, minValue, maxValue)
	if value < minValue then return minValue end
	if value > maxValue then return maxValue end
	return value
end

local function roundToStep(value, step)
	return floor((value / step) + 0.5) * step
end

local function getHotbarCooldownRemaining(slot)
	-- This API returns remaining AND maximum cooldown. Only the first value
	-- belongs in tonumber; the second would otherwise be treated as a base.
	local remaining = GetHotbarCooldown(slot)
	return tonumber(remaining) or 0
end

local function isLimitedActionType(actionType)
	local actions = GameData and GameData.PlayerActions
	if actions == nil or actionType == nil then return false end
	return actionType == actions.DO_ABILITY
		or actionType == actions.COMMAND_PET_DO_ABILITY
		or actionType == actions.USE_ITEM
end

local function getButtonActionType(button)
	if not button then return nil end
	if button.m_ActionType ~= nil then return button.m_ActionType end
	if button.m_HotBarSlot ~= nil then
		local actionType = GetHotbarData(button.m_HotBarSlot)
		return actionType
	end
	return nil
end

local function isLimitedButton(button)
	return button and button.m_ActionId and button.m_ActionId ~= 0
		and isLimitedActionType(getButtonActionType(button))
end

local function sanitizeResourceRule(rule)
	if type(rule) ~= "table" then return nil end
	local mode = rule.Mode or rule.mode
	if mode ~= RESOURCE_MODE_AP and mode ~= RESOURCE_MODE_HP then return nil end
	local threshold = tonumber(rule.Threshold or rule.threshold or rule.Value or rule.value)
	if threshold == nil then return nil end
	if mode == RESOURCE_MODE_AP then
		threshold = clamp(roundToStep(threshold, 10), 0, MAX_AP)
	else
		threshold = clamp(roundToStep(threshold, 10), 0, MAX_HP_PERCENT)
	end
	return { Mode = mode, Threshold = threshold }
end

local function sanitizeTargetHealthRule(rule)
	if type(rule) ~= "table" then return nil end
	local mode = rule.Mode or rule.mode
	if mode ~= TARGET_HP_MODE_MIN and mode ~= TARGET_HP_MODE_MAX then return nil end
	local threshold = tonumber(rule.Threshold or rule.threshold or rule.Value or rule.value)
	if threshold == nil then return nil end
	threshold = clamp(roundToStep(threshold, 5), 0, MAX_HP_PERCENT)
	local target = rule.Target or rule.target or EFFECT_TARGET_ABILITY
	if target ~= EFFECT_TARGET_ABILITY
	and target ~= EFFECT_TARGET_HOSTILE
	and target ~= EFFECT_TARGET_FRIENDLY
	and target ~= EFFECT_TARGET_SELF
	then
		target = EFFECT_TARGET_ABILITY
	end
	return { Mode = mode, Threshold = threshold, Target = target }
end

local function sanitizeCareerMechanicRule(rule)
	if type(rule) ~= "table" then return nil end
	local mode = rule.Mode or rule.mode
	if mode ~= CAREER_MECHANIC_MODE_MIN
	and mode ~= CAREER_MECHANIC_MODE_MAX
	and mode ~= CAREER_MECHANIC_MODE_EQUAL
	then
		return nil
	end
	local threshold = tonumber(rule.Threshold or rule.threshold or rule.Value or rule.value)
	if threshold == nil then return nil end
	threshold = clamp(roundToStep(threshold, 1), CAREER_MECHANIC_MIN, CAREER_MECHANIC_MAX)
	return { Mode = mode, Threshold = threshold }
end

local function sanitizeVirtualCooldown(value)
	value = tonumber(value)
	if value == nil or value <= 0 then return nil end
	return clamp(roundToStep(value, 0.5), 0.5, 300)
end

local function sanitizeEffectRefreshWindow(value)
	value = tonumber(value)
	if value == nil or value <= EFFECT_REFRESH_MIN then return nil end
	return clamp(roundToStep(value, EFFECT_REFRESH_STEP), EFFECT_REFRESH_STEP, EFFECT_REFRESH_MAX)
end

local function addEffectId(effectIds, seen, value)
	local effectId = tonumber(value)
	if effectId == nil or effectId <= 0 then return end
	effectId = floor(effectId + 0.5)
	if seen[effectId] then return end
	seen[effectId] = true
	table.insert(effectIds, effectId)
end

local function addEffectIds(effectIds, seen, value)
	if type(value) == "table" then
		for _, candidate in ipairs(value) do
			addEffectId(effectIds, seen, candidate)
		end
	elseif type(value) == "string" then
		for candidate in string.gmatch(value, "[^,]+") do
			candidate = string.match(candidate, "^%s*(.-)%s*$")
			addEffectId(effectIds, seen, candidate)
		end
	else
		addEffectId(effectIds, seen, value)
	end
end

local function sanitizeEffectRequirement(requirement)
	if type(requirement) ~= "table" then return nil end
	local effectIds = {}
	local seen = {}
	addEffectIds(effectIds, seen, requirement.EffectIds or requirement.effectIds or requirement.Ids or requirement.ids)
	addEffectId(effectIds, seen, requirement.EffectId or requirement.effectId or requirement.Id or requirement.id)
	if #effectIds == 0 then return nil end
	local target = requirement.Target or requirement.target or EFFECT_TARGET_ABILITY
	if target ~= EFFECT_TARGET_ABILITY
	and target ~= EFFECT_TARGET_HOSTILE
	and target ~= EFFECT_TARGET_FRIENDLY
	and target ~= EFFECT_TARGET_SELF
	then
		target = EFFECT_TARGET_ABILITY
	end
	return {
		EffectIds = effectIds,
		EffectId = effectIds[1],
		Target = target,
		OnlyMine = requirement.OnlyMine == true or requirement.onlyMine == true,
	}
end

local function effectIdListText(requirement)
	local parts = {}
	for _, effectId in ipairs(requirement.EffectIds or {}) do
		table.insert(parts, tostring(effectId))
	end
	if #parts == 0 and requirement.EffectId then
		table.insert(parts, tostring(requirement.EffectId))
	end
	return table.concat(parts, ", ")
end

local function formatAALead(value)
	if value == floor(value) then
		return tostring(floor(value))
	end
	return string.format("%.1f", value)
end

local function nextAALead(value)
	if value == nil then
		return AA_MIN_LEAD
	end
	value = value + AA_LEAD_STEP
	if value > AA_MAX_LEAD then
		return nil
	end
	return value
end

local function hasFriendlyTarget()
	local target = TargetInfo.m_Units[TargetInfo.FRIENDLY_TARGET]
	if target and target.entityid ~= 0 then
		return true
	end
	return false
end

local function hasHostileTarget()
	local target = TargetInfo.m_Units[TargetInfo.HOSTILE_TARGET]
	if target and target.entityid ~= 0 then
		return true
	end
	return false
end

local function hasBuff(target, abilityData, stackCount, refreshWindow)
	if not target then
		return false
	end
	local buffData = getBuffSnapshot(target)
	if not buffData then
		return false
	end

	for _, buff in pairs(buffData) do
		if buff.iconNum == abilityData.iconNum and buff.castByPlayer and buff.stackCount == stackCount then
			if refreshWindow == nil or buff.permanentUntilDispelled then
				return true
			end
			local remaining = tonumber(buff.duration)
			if remaining == nil or remaining > refreshWindow then
				return true
			end
		end
	end
	return false
end

local function getTargetType(targetType)
	if targetType == 0 then
		return GameData.BuffTargetType.SELF
	elseif targetType == 1 and hasHostileTarget() then
		return GameData.BuffTargetType.TARGET_HOSTILE
	elseif targetType == 1 then
		return nil -- Ugly workaround to correct for incorrect buffs when no hostile target
	elseif targetType == 2 and hasFriendlyTarget() then
		return GameData.BuffTargetType.TARGET_FRIENDLY
	elseif targetType == 2 then
		return GameData.BuffTargetType.SELF
	else
		return GameData.BuffTargetType.SELF
	end
end

local function getCurrentAP()
	if GameData.Player and GameData.Player.actionPoints then
		local ap = GameData.Player.actionPoints.current
		if type(ap) == "number" then return ap end
	end
	return 0
end

local function getCurrentHPPercent()
	if not GameData.Player then return 100 end
	local hpData = GameData.Player.hitPoints or GameData.Player.health or GameData.Player.HitPoints
	if type(hpData) ~= "table" then return 100 end
	local current = hpData.current or hpData.Current or hpData.cur or hpData.value
	local maximum = hpData.maximum or hpData.max or hpData.Max or hpData.maxValue
	if type(current) ~= "number" or type(maximum) ~= "number" or maximum <= 0 then return 100 end
	return (current / maximum) * 100
end

local function isCareerLine(careerLine, expectedLine)
	return expectedLine ~= nil and careerLine == expectedLine
end

local function getRunepriestZealotMechanic()
	if GCDsaver.RunepriestZealotMechanic ~= nil then
		return GCDsaver.RunepriestZealotMechanic
	end
	local activeActions = ActionBars and ActionBars.m_ActiveActions
	if type(activeActions) == "table"
	and (activeActions[RUNE_PRIEST_MECHANIC_ABILITY] == true
		or activeActions[ZEALOT_MECHANIC_ABILITY] == true)
	then
		return 1
	end
	return 0
end

local function getCurrentCareerMechanic()
	local player = GameData and GameData.Player
	local careerLine = player and player.career and player.career.line
	local careerLines = GameData and GameData.CareerLine or {}

	-- NerfedButtons compatibility: Rune Priest and Zealot expose a toggle state
	-- rather than a useful numeric resource through the original client API.
	if isCareerLine(careerLine, careerLines.RUNE_PRIEST)
	or isCareerLine(careerLine, careerLines.ZEALOT)
	then
		return getRunepriestZealotMechanic()
	end

	if type(GetCareerResource) ~= "function" then return nil end
	local ok, value = pcall(GetCareerResource, GameData.BuffTargetType.SELF)
	if not ok then return nil end
	local current = tonumber(value)
	if current == nil then return nil end

	-- NerfedButtons maps the two-sided Archmage/Shaman resource as signed
	-- values: raw 1..5 becomes -1..-5, raw 6..10 becomes +1..+5.
	if isCareerLine(careerLine, careerLines.ARCHMAGE)
	or isCareerLine(careerLine, careerLines.SHAMAN)
	then
		if current > 5 then return current - 5 end
		if current > 0 then return -current end
		return 0
	end
	return current
end

local function readCareerMechanicRule(actionId)
	if not GCDsaver.Settings or type(GCDsaver.Settings.CareerMechanicRules) ~= "table" then return nil end
	return sanitizeCareerMechanicRule(GCDsaver.Settings.CareerMechanicRules[actionId])
end

local function getCareerMechanicRule(actionId)
	return evaluationValue("mechanicRules", actionId, readCareerMechanicRule)
end

local function isCareerMechanicRuleBlocked(rule)
	if rule == nil then return false, nil end
	local current = getCurrentCareerMechanic()
	if current == nil then return true, nil end
	if rule.Mode == CAREER_MECHANIC_MODE_MIN then
		return current < rule.Threshold, current
	elseif rule.Mode == CAREER_MECHANIC_MODE_MAX then
		return current > rule.Threshold, current
	end
	return current ~= rule.Threshold, current
end

local function readResourceRule(actionId)
	if not GCDsaver.Settings or type(GCDsaver.Settings.ResourceRules) ~= "table" then return nil end
	return sanitizeResourceRule(GCDsaver.Settings.ResourceRules[actionId])
end

local function getResourceRule(actionId)
	return evaluationValue("resourceRules", actionId, readResourceRule)
end

local function getEffectRefreshWindow(actionId)
	if not GCDsaver.Settings or type(GCDsaver.Settings.EffectRefreshWindows) ~= "table" then return nil end
	return sanitizeEffectRefreshWindow(GCDsaver.Settings.EffectRefreshWindows[actionId])
end

local function isResourceRuleBlocked(rule)
	if not GCDsaver.Settings.ResourceLimitsEnabled or rule == nil then return false end
	if rule.Mode == RESOURCE_MODE_AP then
		return getCurrentAP() > rule.Threshold
	end
	return getCurrentHPPercent() > rule.Threshold
end

local function getEffectTarget(actionId, targetMode)
	if targetMode == EFFECT_TARGET_SELF then
		return GameData.BuffTargetType.SELF
	elseif targetMode == EFFECT_TARGET_HOSTILE then
		if hasHostileTarget() then return GameData.BuffTargetType.TARGET_HOSTILE end
		return nil
	elseif targetMode == EFFECT_TARGET_FRIENDLY then
		if hasFriendlyTarget() then return GameData.BuffTargetType.TARGET_FRIENDLY end
		return nil
	end

	local abilityData = getAbilitySnapshot(actionId)
	if not abilityData then return nil end
	return getTargetType(abilityData.targetType)
end

local function readTargetHealthRule(actionId)
	if not GCDsaver.Settings or type(GCDsaver.Settings.TargetHealthRules) ~= "table" then return nil end
	return sanitizeTargetHealthRule(GCDsaver.Settings.TargetHealthRules[actionId])
end

local function getTargetHealthRule(actionId)
	return evaluationValue("healthRules", actionId, readTargetHealthRule)
end

local function readEffectRequirement(actionId)
	local requirement = sanitizeEffectRequirement(GCDsaver.Settings.EffectRequirements[actionId])
	if requirement then
		-- Runtime-only lookup: do not add derived fields to saved settings.
		requirement.Lookup = {}
		for _, effectId in ipairs(requirement.EffectIds) do
			requirement.Lookup[effectId] = true
		end
	end
	return requirement
end

local function getEffectRequirement(actionId)
	return evaluationValue("effectRules", actionId, readEffectRequirement)
end

local function getAbilityTargetHealthPercent(actionId, targetMode)
	local targetType = getEffectTarget(actionId, targetMode)
	-- Explicitly fall back to the player when the requested target is absent.
	if targetType == nil then targetType = GameData.BuffTargetType.SELF end
	if targetType == GameData.BuffTargetType.SELF then
		return clamp(getCurrentHPPercent(), 0, MAX_HP_PERCENT)
	end

	local classification = nil
	if targetType == GameData.BuffTargetType.TARGET_HOSTILE then
		classification = TargetInfo.HOSTILE_TARGET
	elseif targetType == GameData.BuffTargetType.TARGET_FRIENDLY then
		classification = TargetInfo.FRIENDLY_TARGET
	end
	if classification == nil or not TargetInfo.m_Units then return clamp(getCurrentHPPercent(), 0, MAX_HP_PERCENT) end
	local unit = TargetInfo.m_Units[classification]
	if type(unit) ~= "table" or unit.entityid == 0 then
		return clamp(getCurrentHPPercent(), 0, MAX_HP_PERCENT)
	end
	local healthPercent = tonumber(unit.healthPercent or unit.HealthPercent or unit.hitPointPercent)
	if healthPercent == nil then return clamp(getCurrentHPPercent(), 0, MAX_HP_PERCENT) end
	return clamp(healthPercent, 0, MAX_HP_PERCENT)
end

local function isTargetHealthRuleBlocked(actionId, rule)
	if rule == nil then return false, nil end
	local healthPercent = getAbilityTargetHealthPercent(actionId, rule.Target)
	if healthPercent == nil then return true, nil end
	if rule.Mode == TARGET_HP_MODE_MIN then
		return healthPercent < rule.Threshold, healthPercent
	end
	return healthPercent > rule.Threshold, healthPercent
end

local function targetHasEffect(actionId, requirement)
	if requirement == nil then return true end
	local target = getEffectTarget(actionId, requirement.Target)
	if target == nil then return false end
	local effects = getBuffSnapshot(target)
	if type(effects) ~= "table" then return false end
	local requiredEffectIds = requirement.Lookup
	for _, effect in pairs(effects) do
		local effectId = tonumber(effect.abilityId or effect.abilityID or effect.id or effect.ID or effect.effectId or effect.effectID)
		if requiredEffectIds[effectId] and (not requirement.OnlyMine or effect.castByPlayer) then
			return true
		end
	end
	return false
end

local function getVirtualCooldownRemaining(actionId)
	if not GCDsaver.VirtualCooldownExpires then return 0 end
	local expires = GCDsaver.VirtualCooldownExpires[actionId]
	if type(expires) ~= "number" then return 0 end
	local remaining = expires - (GCDsaver.RuntimeTime or 0)
	if remaining <= 0 then
		GCDsaver.VirtualCooldownExpires[actionId] = nil
		return 0
	end
	return remaining
end

local function abilityUsable(id)
	local actionType, actionId, isSlotEnabled, isTargetValid, isSlotBlocked
	for i = 1, MAX_BUTTONS do
		actionType, actionId, isSlotEnabled, isTargetValid, isSlotBlocked = GetHotbarData(i)
		if id == actionId
		and GetHotbarCooldown(i) == 0
		and isSlotEnabled
		and isTargetValid
		then
			return true
		end
	end
	return false
end

-- Auto-attack phase tracking is based on Swinger by Sullemunk, with the
-- bonus-adjusted weapon speed correction by Emissary.
local function getRightHand()
	if not CharacterWindow or not CharacterWindow.equipmentData then
		return nil
	end
	return CharacterWindow.equipmentData[GameData.EquipSlots.RIGHT_HAND]
end

local function getAASyncTarget(lead, duration)
	local target = lead
	while target > duration do
		target = target - duration
	end
	return target
end

local function getAASyncState(actionId)
	if not GCDsaver.Settings
	or not GCDsaver.Settings.Enabled
	or not GCDsaver.Settings.AASyncEnabled
	or not GCDsaver.Settings.AASyncAbilities
	then
		return false
	end

	local lead = GCDsaver.Settings.AASyncAbilities[actionId]
	if lead == nil
	or not GameData.Player
	or not GameData.Player.inCombat
	or not GCDsaver.AASwingActive
	or GCDsaver.AASwingDuration <= 0
	then
		return false
	end

	local target = getAASyncTarget(lead, GCDsaver.AASwingDuration)
	local remaining = GCDsaver.AASwingRemaining
	return abs(remaining - target) > AA_SYNC_TOLERANCE, remaining, lead, target
end

local function alertText(text)
	if SettingsWindowTabInterface
	and SettingsWindowTabInterface.SavedMessageSettings
	and SettingsWindowTabInterface.SavedMessageSettings.combat
	then
		SystemData.AlertText.VecType = {SystemData.AlertText.Types.COMBAT}
		SystemData.AlertText.VecText = {towstring(text)}
		BroadcastEvent(SystemData.Events.SHOW_ALERT_TEXT)
	end
end

local function getAbilityChatText(actionId)
	local data = GetAbilityData(actionId) or {}
	local name = towstring(data.name or actionId)
	local icon = towstring("<icon" .. tostring(data.iconNum or 0) .. ">")
	return icon .. L" " .. name
end

local function chatInfo(actionId, state)
	local abilityText = getAbilityChatText(actionId)
	if not state then
		TextLogAddEntry("Chat", 0, T("chat_no_conditions") .. abilityText)
	elseif state >= 1 and state <= 3 then
		TextLogAddEntry("Chat", 0, T("chat_target_stack_a") .. towstring(state) .. T("chat_target_stack_b") .. abilityText)
	elseif state == IMMOVABLE then
		TextLogAddEntry("Chat", 0, T("chat_immovable") .. abilityText)
	elseif state == UNSTOPPABLE then
		TextLogAddEntry("Chat", 0, T("chat_unstoppable") .. abilityText)
	elseif state >= SELF_1 and state <= SELF_3 then
		TextLogAddEntry("Chat", 0, T("chat_self_stack_a") .. towstring(state - 5) .. T("chat_self_stack_b") .. abilityText)
	end
end

local function chatInfoAA(actionId, lead)
	local abilityText = getAbilityChatText(actionId)
	if lead == nil then
		TextLogAddEntry("Chat", 0, T("chat_aa_clear") .. abilityText)
	else
		TextLogAddEntry("Chat", 0, T("chat_aa_set") .. towstring(formatAALead(lead)) .. T("chat_aa_suffix") .. abilityText)
	end
end
local function getStandardConditionBlockReason(actionId)
	local configuredCheck = GCDsaver.Settings.Abilities[actionId]
	if GCDsaver.TargetImmovable and configuredCheck == IMMOVABLE then
		return "alert_immovable"
	elseif GCDsaver.TargetUnstoppable and configuredCheck == UNSTOPPABLE then
		return "alert_unstoppable"
	end
	if type(configuredCheck) ~= "number"
	or not ((configuredCheck >= 1 and configuredCheck <= 3)
		or (configuredCheck >= SELF_1 and configuredCheck <= SELF_3))
	then return nil end
	local abilityData = getAbilitySnapshot(actionId)
	local refreshWindow = getEffectRefreshWindow(actionId)
	if abilityData and configuredCheck >= 1 and configuredCheck <= 3
	and hasBuff(getTargetType(abilityData.targetType), abilityData, configuredCheck, refreshWindow)
	then
		return "alert_target_effect"
	elseif abilityData
	and configuredCheck >= SELF_1 and configuredCheck <= SELF_3
	and hasBuff(GameData.BuffTargetType.SELF, abilityData, configuredCheck - 5, refreshWindow)
	then
		return "alert_self_effect"
	end
	return nil
end

local function evaluateAbilityBlocked(actionId, showError)
	if not GCDsaver.Settings.Enabled then return false end

	local reason = getStandardConditionBlockReason(actionId)
	if reason and not showError then return true end
	if reason then reason = T(reason) end
	local requirement = reason == nil and getEffectRequirement(actionId) or nil
	if reason == nil and requirement ~= nil and not targetHasEffect(actionId, requirement) then
		if not showError then return true end
		reason = T("alert_required_missing") .. towstring(effectIdListText(requirement)) .. L")"
	end

	local resourceRule = reason == nil and getResourceRule(actionId) or nil
	if reason == nil and isResourceRuleBlocked(resourceRule) then
		if not showError then return true end
		if resourceRule.Mode == RESOURCE_MODE_AP then
			reason = T("alert_too_much_ap") .. towstring(getCurrentAP()) .. T("alert_max") .. towstring(resourceRule.Threshold)
		else
			reason = T("alert_hp_high") .. towstring(floor(getCurrentHPPercent() + 0.5)) .. L"%" .. T("alert_max") .. towstring(resourceRule.Threshold) .. L"%"
		end
	end

	local mechanicRule = reason == nil and getCareerMechanicRule(actionId) or nil
	local mechanicBlocked, currentMechanic = isCareerMechanicRuleBlocked(mechanicRule)
	if reason == nil and mechanicRule ~= nil and mechanicBlocked then
		if not showError then return true end
		if currentMechanic == nil then
			reason = T("alert_mechanic_unavailable")
		elseif mechanicRule.Mode == CAREER_MECHANIC_MODE_MIN then
			reason = T("alert_mechanic_low") .. towstring(currentMechanic) .. T("alert_min") .. towstring(mechanicRule.Threshold)
		elseif mechanicRule.Mode == CAREER_MECHANIC_MODE_MAX then
			reason = T("alert_mechanic_high") .. towstring(currentMechanic) .. T("alert_max") .. towstring(mechanicRule.Threshold)
		else
			reason = T("alert_mechanic_different") .. towstring(currentMechanic) .. T("alert_required_value") .. towstring(mechanicRule.Threshold)
		end
	end
	local targetHealthRule = reason == nil and getTargetHealthRule(actionId) or nil
	local targetHealthBlocked, targetHealthPercent = isTargetHealthRuleBlocked(actionId, targetHealthRule)
	if reason == nil and targetHealthRule ~= nil and targetHealthBlocked then
		if not showError then return true end
		if targetHealthPercent == nil then
			reason = T("alert_target_hp_unknown")
		elseif targetHealthRule.Mode == TARGET_HP_MODE_MIN then
			reason = T("alert_target_hp_low") .. towstring(floor(targetHealthPercent + 0.5)) .. L"%" .. T("alert_min") .. towstring(targetHealthRule.Threshold) .. L"%"
		else
			reason = T("alert_target_hp_high") .. towstring(floor(targetHealthPercent + 0.5)) .. L"%" .. T("alert_max") .. towstring(targetHealthRule.Threshold) .. L"%"
		end
	end

	local virtualRemaining = reason == nil and getVirtualCooldownRemaining(actionId) or 0
	if reason == nil and virtualRemaining > 0 then
		if not showError then return true end
		reason = T("alert_virtual_cd") .. towstring(string.format("%.1f", virtualRemaining)) .. L"s"
	end

	if reason == nil then
		local aaBlocked, remaining, lead = getAASyncState(actionId)
		if aaBlocked then
			if not showError then return true end
			reason = T("alert_wait_aa") .. towstring(string.format("%.1f", remaining)) .. L"s" .. T("alert_lead") .. towstring(formatAALead(lead)) .. L"s)"
		end
	end

	if reason ~= nil then
		if showError and GCDsaver.Settings.ErrorMessages and abilityUsable(actionId) then
			alertText(reason)
		end
		return true
	end
	return false
end

local function isAbilityBlocked(actionId, showError)
	if showError then
		local previous = evaluationContext
		evaluationContext = nil
		return finishEvaluation(previous, pcall(evaluateAbilityBlocked, actionId, true))
	end
	if not evaluationContext then return evaluateAbilityBlocked(actionId, false) end
	local blocked = evaluationContext.blocked
	if not blocked then
		blocked = {}
		evaluationContext.blocked = blocked
	end
	if blocked[actionId] == nil then blocked[actionId] = evaluateAbilityBlocked(actionId, false) end
	return blocked[actionId]
end
local function getConditionSymbol(state)
	if state == IMMOVABLE then
		return "<icon05007>", 255, 255, 255
	elseif state == UNSTOPPABLE then
		return "<icon05006>", 255, 255, 255
	elseif type(state) == "number" and state >= SELF_1 and state <= SELF_3 then
		return "S" .. tostring(state - 5), 0, 255, 255
	elseif type(state) == "number" and state >= 1 and state <= 3 then
		return tostring(state) .. "x", 255, 255, 0
	end
	return nil
end

local function formatResourceRule(rule)
	if rule == nil then return nil end
	if rule.Mode == RESOURCE_MODE_AP then
		return "AP" .. tostring(rule.Threshold)
	end
	return "HP" .. tostring(rule.Threshold) .. "%"
end

local function formatTargetHealthRule(rule)
	if rule == nil then return nil end
	local prefix = "A"
	if rule.Target == EFFECT_TARGET_FRIENDLY then
		prefix = "F"
	elseif rule.Target == EFFECT_TARGET_HOSTILE then
		prefix = "H"
	elseif rule.Target == EFFECT_TARGET_SELF then
		prefix = "S"
	end
	if rule.Mode == TARGET_HP_MODE_MIN then
		return prefix .. "+" .. tostring(rule.Threshold)
	end
	return prefix .. "-" .. tostring(rule.Threshold)
end

local function formatCareerMechanicRule(rule)
	if rule == nil then return nil end
	if rule.Mode == CAREER_MECHANIC_MODE_MIN then
		return "M>" .. tostring(rule.Threshold)
	elseif rule.Mode == CAREER_MECHANIC_MODE_MAX then
		return "M<" .. tostring(rule.Threshold)
	end
	return "M=" .. tostring(rule.Threshold)
end

local function getButtonMarkerParts(actionId)
	local parts = {}
	local conditionText = getConditionSymbol(GCDsaver.Settings.Abilities[actionId])
	if conditionText then table.insert(parts, conditionText) end

	local refreshWindow = getEffectRefreshWindow(actionId)
	local configuredCheck = GCDsaver.Settings.Abilities[actionId]
	if refreshWindow and type(configuredCheck) == "number"
	and ((configuredCheck >= 1 and configuredCheck <= 3)
		or (configuredCheck >= SELF_1 and configuredCheck <= SELF_3))
	then
		table.insert(parts, "R" .. formatAALead(refreshWindow))
	end

	local aaLead = GCDsaver.Settings.AASyncAbilities[actionId]
	if GCDsaver.Settings.AASyncEnabled and aaLead ~= nil then
		table.insert(parts, "AA" .. formatAALead(aaLead))
	end

	local resourceText = formatResourceRule(getResourceRule(actionId))
	if GCDsaver.Settings.ResourceLimitsEnabled and resourceText then
		table.insert(parts, resourceText)
	end

	local mechanicText = formatCareerMechanicRule(getCareerMechanicRule(actionId))
	if mechanicText then table.insert(parts, mechanicText) end

	local targetHealthText = formatTargetHealthRule(getTargetHealthRule(actionId))
	if targetHealthText then table.insert(parts, targetHealthText) end

	local virtualCooldown = sanitizeVirtualCooldown(GCDsaver.Settings.VirtualCooldowns[actionId])
	if virtualCooldown then
		table.insert(parts, "CD" .. formatAALead(virtualCooldown))
	end

	local requirement = sanitizeEffectRequirement(GCDsaver.Settings.EffectRequirements[actionId])
	if requirement then
		local marker = "FX" .. tostring(requirement.EffectId)
		local extraIds = #(requirement.EffectIds or {}) - 1
		if extraIds > 0 then marker = marker .. "+" .. tostring(extraIds) end
		table.insert(parts, marker)
	end
	return parts
end

local function getButtonMarkerWindowName(button)
	if not button or type(button.GetName) ~= "function" then return nil end
	local ok, buttonName = pcall(button.GetName, button)
	if not ok or type(buttonName) ~= "string" or buttonName == "" then return nil end
	return buttonName .. BUTTON_MARKER_SUFFIX, buttonName
end

local function ensureButtonMarkerWindow(button)
	local markerName, buttonName = getButtonMarkerWindowName(button)
	if not markerName then return nil end
	if not DoesWindowExist(markerName) then
		if not CreateWindowFromTemplate(markerName, "EA_Label_DefaultText", buttonName) then return nil end
		WindowSetHandleInput(markerName, false)
		WindowClearAnchors(markerName)
		WindowAddAnchor(markerName, "bottomleft", buttonName, "bottomleft", 3, -3)
		WindowSetDimensions(markerName, BUTTON_MARKER_WIDTH, BUTTON_MARKER_HEIGHT)
		WindowSetLayer(markerName, Window.Layers.OVERLAY)
		LabelSetFont(markerName, "font_clear_small_bold", 9)
		LabelSetTextAlign(markerName, "left")
		LabelSetTextColor(markerName, 255, 255, 0)
		WindowSetShowing(markerName, false)
	end
	return markerName
end

local markerStates = {}

local function applyButtonIcon(button, actionId)
	local text = ""
	if GCDsaver.Settings.Enabled and GCDsaver.Settings.Symbols and isLimitedButton(button) then
		local parts = getButtonMarkerParts(actionId)
		if #parts > 0 then text = "GS:" .. table.concat(parts, "/") end
	end
	local markerName = getButtonMarkerWindowName(button)
	if not markerName then return end
	local exists = DoesWindowExist(markerName)
	if exists and markerStates[markerName] == text then return end
	markerStates[markerName] = nil

	if text == "" then
		if exists then
			LabelSetText(markerName, L"")
			WindowSetShowing(markerName, false)
		end
		markerStates[markerName] = text
		return
	end

	markerName = ensureButtonMarkerWindow(button)
	if not markerName then return end
	-- This is deliberately separate from m_Windows[7], which EA_ActionBars
	-- reserves for the native item stack count.
	LabelSetText(markerName, towstring(text))
	LabelSetTextColor(markerName, 255, 255, 0)
	WindowSetShowing(markerName, true)
	markerStates[markerName] = text
end
local function setButtonIcon(actionId)
	local hbar, buttonid
	local buttonActionId
	for i = 1, MAX_BUTTONS do
		_, buttonActionId = GetHotbarData(i)
		if buttonActionId == actionId then
			hbar, buttonid = ActionBars:BarAndButtonIdFromSlot(i)
			if hbar and buttonid then
				applyButtonIcon(hbar.m_Buttons[buttonid], actionId)
			end
		end
	end
end

-- GCDsaver
GCDsaver = GCDsaver or {}
GCDsaver.TargetID = 0
GCDsaver.TargetImmovable = false
GCDsaver.TargetUnstoppable = false
GCDsaver.InCombat = false
GCDsaver.AASwingActive = false
GCDsaver.AASwingRemaining = 0
GCDsaver.AASwingDuration = 0
GCDsaver.AABaseSpeed = 0
GCDsaver.DynamicSlots = {}
GCDsaver.LimitedSlots = {}
GCDsaver.SlotActions = {}
GCDsaver.SlotTypes = {}
GCDsaver.SlotButtons = {}
GCDsaver.SlotButtonActions = {}
GCDsaver.SlotButtonTypes = {}
GCDsaver.DirtyCategories = {}
GCDsaver.DirtyActions = {}
GCDsaver.DirtySlots = {}
GCDsaver.HotbarDirty = false
GCDsaver.LastDynamicSlotStates = {}
GCDsaver.RuntimeTime = 0
GCDsaver.VirtualCooldownExpires = {}
GCDsaver.PendingVirtualCast = nil
GCDsaver.PendingVirtualAttempts = {}
GCDsaver.RunepriestZealotMechanic = nil
GCDsaver.ActionGate = nil
GCDsaver.ItemGate = nil

GCDsaver.DefaultSettings = {
	Version = VERSION,
	Enabled = true,
	Symbols = true,
	ErrorMessages = true,
	UseSpanish = false,
	AASyncEnabled = true,
	AASyncAbilities = {},
	ResourceLimitsEnabled = true,
	ResourceRules = {},
	CareerMechanicRules = {},
	TargetHealthRules = {},
	VirtualCooldowns = {},
	EffectRefreshWindows = {},
	EffectRequirements = {},
	Abilities = {
		-- Ironbreaker
		[1384] = UNSTOPPABLE,	-- Cave-In
		[1369] = UNSTOPPABLE,	-- Shield of Reprisal
		[1365] = IMMOVABLE,		-- Away With Ye
		-- Slayer
		[1443] = UNSTOPPABLE,	-- Incapacitate
		-- Runepriest
		[1613] = UNSTOPPABLE,	-- Rune of Binding
		[1607] = UNSTOPPABLE,	-- Spellbinding Rune
		-- Engineer
		[1536] = UNSTOPPABLE,	-- Crack Shot
		[1531] = IMMOVABLE,		-- Concussion Grenade
		-- Black Orc
		[1688] = UNSTOPPABLE,	-- Down Ya Go
		[1683] = UNSTOPPABLE,	-- Shut Yer Face
		-- Choppa
		[1755] = UNSTOPPABLE,	-- Sit Down!
		-- Shaman
		[1929] = IMMOVABLE,		-- Geddoff!
		[1917] = UNSTOPPABLE,	-- You Got Nuthin!
		-- Squig Herder
		[1839] = UNSTOPPABLE,	-- Choking Arrer
		[1837] = UNSTOPPABLE,	-- Drop That!!
		[1835] = UNSTOPPABLE,	-- Not So Fast!
		-- Witch Hunter
		[8110] = UNSTOPPABLE,	-- Dragon Gun
		[8086] = UNSTOPPABLE,	-- Confess!
		[8115] = UNSTOPPABLE,	-- Pistol Whip
		[8100] = UNSTOPPABLE,	-- Silence The Heretic
		[8094] = UNSTOPPABLE,	-- Declare Anathema
		-- Knight of the Blazing Sun
		[8018] = UNSTOPPABLE,	-- Smashing Counter
		[8017] = IMMOVABLE,		-- Repel Darkness
		-- Bright Wizard
		[8186] = UNSTOPPABLE,	-- Stop, Drop, and Roll
		[8174] = UNSTOPPABLE,	-- Choking Smoke
		-- Warrior Priest
		[8256] = UNSTOPPABLE,	-- Vow of Silence
		-- Chosen
		[8346] = UNSTOPPABLE,	-- Downfall
		[8329] = IMMOVABLE,		-- Repel
		-- Marauder
		[8412] = UNSTOPPABLE,	-- Mutated Energy
		[8405] = UNSTOPPABLE,	-- Death Grip
		[8410] = IMMOVABLE,		-- Terrible Embrace
		-- Zealot
		[8571] = UNSTOPPABLE,	-- Aethyric Shock
		[8565] = UNSTOPPABLE,	-- Tzeentch's Lash
		-- Magus
		[8495] = UNSTOPPABLE,	-- Perils of The Warp
		[8483] = IMMOVABLE,		-- Warping Blast
		-- Swordmaster
		[9032] = IMMOVABLE,		-- Redirected Force
		-- [9030] = UNSTOPPABLE,	-- Whispering Window
		[9028] = UNSTOPPABLE,	-- Chrashing Wave
		-- Shadow Warrior
		[9096] = UNSTOPPABLE,	-- Eye Shot
		[9108] = UNSTOPPABLE,	-- Exploit Weakness
		[9098] = UNSTOPPABLE,	-- Opportunistic Strike
		-- White Lion
		[9193] = UNSTOPPABLE,	-- Brutal Pounce
		[9177] = UNSTOPPABLE,	-- Throat Bite
		[9178] = IMMOVABLE,		-- Fetch!
		-- Archmage
		[9266] = IMMOVABLE,		-- Cleansing Flare
		[9253] = UNSTOPPABLE,	-- Law of Gold
		-- Blackguard
		[2888] = UNSTOPPABLE,	-- Malignant Strike!
		[9321] = UNSTOPPABLE,	-- Spiteful Slam
		[9328] = IMMOVABLE,		-- Exile
		-- Witch Elf
		[9422] = UNSTOPPABLE,	-- On Your Knees!
		[9400] = UNSTOPPABLE,	-- Sever Limb
		[9427] = UNSTOPPABLE,	-- Heart Seeker
		[9409] = UNSTOPPABLE,	-- Throat Slitter
		[9396] = UNSTOPPABLE,	-- Agile Escape
		-- Disciple of Khaine
		[9565] = UNSTOPPABLE,	-- Consume Thought
		-- Sorcerer
		[9482] = UNSTOPPABLE,	-- Frostbite
		[9489] = UNSTOPPABLE,	-- Stricken Voices
	},
}

function GCDsaver.NormalizeSettings()
	if type(GCDsaver.Settings) ~= "table" then GCDsaver.Settings = {} end
	local settings = GCDsaver.Settings
	settings.Version = VERSION
	settings.Enabled = defaultIfNil(settings.Enabled, GCDsaver.DefaultSettings.Enabled)
	if settings.Symbols == nil and settings.Icons ~= nil then settings.Symbols = settings.Icons end
	settings.Symbols = defaultIfNil(settings.Symbols, GCDsaver.DefaultSettings.Symbols)
	settings.ErrorMessages = defaultIfNil(settings.ErrorMessages, GCDsaver.DefaultSettings.ErrorMessages)
	if settings.Language == "es" and settings.UseSpanish == nil then settings.UseSpanish = true end
	settings.UseSpanish = defaultIfNil(settings.UseSpanish, GCDsaver.DefaultSettings.UseSpanish)
	settings.Language = settings.UseSpanish and "es" or "en"
	settings.AASyncEnabled = defaultIfNil(settings.AASyncEnabled, GCDsaver.DefaultSettings.AASyncEnabled)
	settings.ResourceLimitsEnabled = defaultIfNil(settings.ResourceLimitsEnabled, GCDsaver.DefaultSettings.ResourceLimitsEnabled)

	if type(settings.Abilities) ~= "table" then
		settings.Abilities = {}
		for actionId, condition in pairs(GCDsaver.DefaultSettings.Abilities) do
			settings.Abilities[actionId] = condition
		end
	end
	if type(settings.AASyncAbilities) ~= "table" then settings.AASyncAbilities = {} end
	if type(settings.ResourceRules) ~= "table" then settings.ResourceRules = {} end
	if type(settings.CareerMechanicRules) ~= "table" then settings.CareerMechanicRules = {} end
	if type(settings.TargetHealthRules) ~= "table" then settings.TargetHealthRules = {} end
	if type(settings.VirtualCooldowns) ~= "table" then settings.VirtualCooldowns = {} end
	if type(settings.EffectRefreshWindows) ~= "table" then settings.EffectRefreshWindows = {} end
	if type(settings.EffectRequirements) ~= "table" then settings.EffectRequirements = {} end

	for actionId, lead in pairs(settings.AASyncAbilities) do
		lead = tonumber(lead)
		if lead == nil or lead < AA_MIN_LEAD or lead > AA_MAX_LEAD then
			settings.AASyncAbilities[actionId] = nil
		else
			settings.AASyncAbilities[actionId] = roundToStep(lead, AA_LEAD_STEP)
		end
	end
	for actionId, rule in pairs(settings.ResourceRules) do
		settings.ResourceRules[actionId] = sanitizeResourceRule(rule)
	end
	for actionId, rule in pairs(settings.CareerMechanicRules) do
		settings.CareerMechanicRules[actionId] = sanitizeCareerMechanicRule(rule)
	end
	for actionId, rule in pairs(settings.TargetHealthRules) do
		settings.TargetHealthRules[actionId] = sanitizeTargetHealthRule(rule)
	end
	for actionId, duration in pairs(settings.VirtualCooldowns) do
		settings.VirtualCooldowns[actionId] = sanitizeVirtualCooldown(duration)
	end
	for actionId, refreshWindow in pairs(settings.EffectRefreshWindows) do
		settings.EffectRefreshWindows[actionId] = sanitizeEffectRefreshWindow(refreshWindow)
	end
	for actionId, requirement in pairs(settings.EffectRequirements) do
		settings.EffectRequirements[actionId] = sanitizeEffectRequirement(requirement)
	end
end

function GCDsaver.ImportPotsSaverSettings()
	local legacy = type(PotsSaver) == "table" and PotsSaver.Settings or nil
	if type(legacy) ~= "table" then return false end
	local rules = legacy.AbilityRules or legacy.Rules
	if type(rules) ~= "table" then return false end
	local imported = false
	for actionId, rule in pairs(rules) do
		if GCDsaver.Settings.ResourceRules[actionId] == nil then
			local normalized = sanitizeResourceRule(rule)
			if normalized then
				GCDsaver.Settings.ResourceRules[actionId] = normalized
				imported = true
			end
		end
	end
	if legacy.Enabled ~= nil then GCDsaver.Settings.ResourceLimitsEnabled = legacy.Enabled == true end
	return imported
end

function GCDsaver.Initialize()
	GCDsaver.NormalizeSettings()
	GCDsaver.ImportPotsSaverSettings()
	GCDsaver.NormalizeSettings()
	GCDsaver.EnsureActionButtonHook()
	GCDsaver.RunepriestZealotMechanic = getRunepriestZealotMechanic()

	LibSlash.RegisterSlashCmd("gcdsaver", function(input) GCDsaver_Config.Slash(input) end)
	LibSlash.RegisterSlashCmd("potssaver", function(input) GCDsaver_Config.Slash(input) end)
	LibSlash.RegisterSlashCmd("appotssaver", function(input) GCDsaver_Config.Slash(input) end)
	LibSlash.RegisterSlashCmd("hppotssaver", function(input) GCDsaver_Config.Slash(input) end)

	PotsSaver = PotsSaver or {}
	PotsSaver.OpenConfig = function() GCDsaver_Config.Slash("") end

	GCDsaver.RegisterEvents()
	GCDsaver.RebuildDynamicSlots()
	GCDsaver.UpdateButtonIcons()
	GCDsaver.UpdateButtonsEnabledStates()
	diagnosticLog("INITIALIZE version=" .. VERSION)
	TextLogAddEntry("Chat", 0, L"<icon57> GCDsaver v" .. towstring(GCDsaver.Settings.Version) .. T("loaded_suffix"))
	TextLogAddEntry("Chat", 0, T("credits"))
end
function GCDsaver.OnShutdown()
	GCDsaver.ResetActionGate()
	GCDsaver.UnregisterEvents()
end

function GCDsaver.RegisterEvents()
	if not eventsRegistered then
		RegisterEventHandler(SystemData.Events.PLAYER_TARGET_UPDATED, "GCDsaver.PLAYER_TARGET_UPDATED")
		RegisterEventHandler(SystemData.Events.PLAYER_TARGET_IS_IMMUNE_TO_MOVEMENT_IMPARING, "GCDsaver.PLAYER_TARGET_IS_IMMUNE_TO_MOVEMENT_IMPARING")
		RegisterEventHandler(SystemData.Events.PLAYER_TARGET_IS_IMMUNE_TO_DISABLES, "GCDsaver.PLAYER_TARGET_IS_IMMUNE_TO_DISABLES")
		RegisterEventHandler(SystemData.Events.PLAYER_EFFECTS_UPDATED, "GCDsaver.PLAYER_EFFECTS_UPDATED")
		RegisterEventHandler(SystemData.Events.PLAYER_TARGET_EFFECTS_UPDATED, "GCDsaver.PLAYER_TARGET_EFFECTS_UPDATED")
		RegisterEventHandler(SystemData.Events.PLAYER_HOT_BAR_UPDATED, "GCDsaver.PLAYER_HOT_BAR_UPDATED")
		RegisterEventHandler(SystemData.Events.PLAYER_HOT_BAR_PAGE_UPDATED, "GCDsaver.PLAYER_HOT_BAR_UPDATED")
		RegisterEventHandler(SystemData.Events.PLAYER_EQUIPMENT_SLOT_UPDATED, "GCDsaver.PLAYER_EQUIPMENT_SLOT_UPDATED")
		RegisterEventHandler(SystemData.Events.PLAYER_BEGIN_CAST, "GCDsaver.PLAYER_BEGIN_CAST")
		RegisterEventHandler(SystemData.Events.PLAYER_END_CAST, "GCDsaver.PLAYER_END_CAST")
		RegisterEventHandler(SystemData.Events.PLAYER_ABILITY_TOGGLED, "GCDsaver.PLAYER_ABILITY_TOGGLED")
		RegisterEventHandler(SystemData.Events.PLAYER_CAREER_RESOURCE_UPDATED, "GCDsaver.PLAYER_CAREER_RESOURCE_UPDATED")
		RegisterEventHandler(TextLogGetUpdateEventId("Combat"), "GCDsaver.COMBAT_LOG_UPDATED")
	end
	eventsRegistered = true
end

function GCDsaver.UnregisterEvents()
	if eventsRegistered then
		UnregisterEventHandler(SystemData.Events.PLAYER_TARGET_UPDATED, "GCDsaver.PLAYER_TARGET_UPDATED")
		UnregisterEventHandler(SystemData.Events.PLAYER_TARGET_IS_IMMUNE_TO_MOVEMENT_IMPARING, "GCDsaver.PLAYER_TARGET_IS_IMMUNE_TO_MOVEMENT_IMPARING")
		UnregisterEventHandler(SystemData.Events.PLAYER_TARGET_IS_IMMUNE_TO_DISABLES, "GCDsaver.PLAYER_TARGET_IS_IMMUNE_TO_DISABLES")
		UnregisterEventHandler(SystemData.Events.PLAYER_EFFECTS_UPDATED, "GCDsaver.PLAYER_EFFECTS_UPDATED")
		UnregisterEventHandler(SystemData.Events.PLAYER_TARGET_EFFECTS_UPDATED, "GCDsaver.PLAYER_TARGET_EFFECTS_UPDATED")
		UnregisterEventHandler(SystemData.Events.PLAYER_HOT_BAR_UPDATED, "GCDsaver.PLAYER_HOT_BAR_UPDATED")
		UnregisterEventHandler(SystemData.Events.PLAYER_HOT_BAR_PAGE_UPDATED, "GCDsaver.PLAYER_HOT_BAR_UPDATED")
		UnregisterEventHandler(SystemData.Events.PLAYER_EQUIPMENT_SLOT_UPDATED, "GCDsaver.PLAYER_EQUIPMENT_SLOT_UPDATED")
		UnregisterEventHandler(SystemData.Events.PLAYER_BEGIN_CAST, "GCDsaver.PLAYER_BEGIN_CAST")
		UnregisterEventHandler(SystemData.Events.PLAYER_END_CAST, "GCDsaver.PLAYER_END_CAST")
		UnregisterEventHandler(SystemData.Events.PLAYER_ABILITY_TOGGLED, "GCDsaver.PLAYER_ABILITY_TOGGLED")
		UnregisterEventHandler(SystemData.Events.PLAYER_CAREER_RESOURCE_UPDATED, "GCDsaver.PLAYER_CAREER_RESOURCE_UPDATED")
		UnregisterEventHandler(TextLogGetUpdateEventId("Combat"), "GCDsaver.COMBAT_LOG_UPDATED")
	end
	eventsRegistered = false
end

-- Event handlers
function GCDsaver.QueueVisualRefresh(category, actionId)
	if category then GCDsaver.DirtyCategories[category] = true end
	if actionId then GCDsaver.DirtyActions[actionId] = true end
end

function GCDsaver.PLAYER_TARGET_UPDATED(targetClassification, targetId, targetType)
	-- Ignore mouseover changes. Current-target health changes also arrive here.
	if targetClassification == TargetInfo.HOSTILE_TARGET then
		if GCDsaver.TargetID ~= targetId then
			GCDsaver.TargetID = targetId
			GCDsaver.TargetImmovable = false
			GCDsaver.TargetUnstoppable = false
		end
		GCDsaver.QueueVisualRefresh("Target")
	elseif targetClassification == TargetInfo.FRIENDLY_TARGET then
		GCDsaver.QueueVisualRefresh("Target")
	end
end

function GCDsaver.PLAYER_TARGET_IS_IMMUNE_TO_DISABLES(state)
	GCDsaver.SetUnstoppable(state)
	GCDsaver.QueueVisualRefresh("Immunity")
end

function GCDsaver.PLAYER_TARGET_IS_IMMUNE_TO_MOVEMENT_IMPARING(state)
	GCDsaver.SetImmovable(state)
	GCDsaver.QueueVisualRefresh("Immunity")
end

function GCDsaver.PLAYER_EFFECTS_UPDATED(updatedEffects, isFullList)
	GCDsaver.QueueVisualRefresh("Effects")
end

function GCDsaver.PLAYER_TARGET_EFFECTS_UPDATED(updateType, updatedEffects, isFullList)
	GCDsaver.QueueVisualRefresh("Effects")
end

function GCDsaver.PLAYER_CAREER_RESOURCE_UPDATED(oldValue, newValue)
	GCDsaver.QueueVisualRefresh("Mechanic")
end

function GCDsaver.PLAYER_HOT_BAR_UPDATED()
	GCDsaver.HotbarDirty = true
	GCDsaver.QueueVisualRefresh("All")
end

local function usesAutoAttackSync()
	return GCDsaver.Settings.Enabled and GCDsaver.Settings.AASyncEnabled
		and next(GCDsaver.Settings.AASyncAbilities) ~= nil
end

function GCDsaver.PLAYER_EQUIPMENT_SLOT_UPDATED()
	if usesAutoAttackSync() then GCDsaver.RefreshAutoAttackSpeed() end
end

function GCDsaver.StartVirtualCooldown(actionId)
	actionId = tonumber(actionId)
	if actionId == nil or actionId == 0 then return end
	local duration = sanitizeVirtualCooldown(GCDsaver.Settings.VirtualCooldowns[actionId])
	if duration == nil then return end
	if getVirtualCooldownRemaining(actionId) > 0 then return end
	GCDsaver.VirtualCooldownExpires[actionId] = GCDsaver.RuntimeTime + duration
	GCDsaver.PendingVirtualAttempts[actionId] = nil
	GCDsaver.QueueVisualRefresh(nil, actionId)
end

function GCDsaver.QueueVirtualCooldownAttempt(actionId, slot)
	actionId = tonumber(actionId)
	slot = tonumber(slot)
	if actionId == nil or actionId == 0 or slot == nil then return end
	local actionType = GetHotbarData(slot)
	if not isLimitedActionType(actionType) then return end
	if sanitizeVirtualCooldown(GCDsaver.Settings.VirtualCooldowns[actionId]) == nil then return end
	if GCDsaver.PendingVirtualCast == actionId or getVirtualCooldownRemaining(actionId) > 0 then return end

	local now = GCDsaver.RuntimeTime or 0
	GCDsaver.PendingVirtualAttempts[actionId] = {
		Slot = slot,
		CheckAt = now + VIRTUAL_ATTEMPT_CONFIRM_DELAY,
		ExpiresAt = now + VIRTUAL_ATTEMPT_TIMEOUT,
	}
end

function GCDsaver.UpdatePendingVirtualCooldownAttempts()
	local now = GCDsaver.RuntimeTime or 0
	for actionId, attempt in pairs(GCDsaver.PendingVirtualAttempts) do
		if getVirtualCooldownRemaining(actionId) > 0 then
			GCDsaver.PendingVirtualAttempts[actionId] = nil
		elseif now >= attempt.CheckAt then
			local actionType, currentActionId = GetHotbarData(attempt.Slot)
			local cooldown = isLimitedActionType(actionType) and getHotbarCooldownRemaining(attempt.Slot) or 0
			if not isLimitedActionType(actionType) then
				GCDsaver.PendingVirtualAttempts[actionId] = nil
			elseif cooldown > 0 or (currentActionId and currentActionId ~= 0 and currentActionId ~= actionId) then
				GCDsaver.StartVirtualCooldown(actionId)
			elseif now >= attempt.ExpiresAt then
				-- No GCD and no sequence advance: the activation was rejected.
				GCDsaver.PendingVirtualAttempts[actionId] = nil
			end
		end
	end
end

function GCDsaver.PLAYER_BEGIN_CAST(abilityId, isChanneledSpell, desiredCastTime, averageLatency)
	abilityId = tonumber(abilityId)
	if abilityId == nil or abilityId == 0 then return end
	GCDsaver.PendingVirtualAttempts[abilityId] = nil
	if isChanneledSpell or (tonumber(desiredCastTime) or 0) == 0 then
		GCDsaver.PendingVirtualCast = nil
		GCDsaver.StartVirtualCooldown(abilityId)
	else
		GCDsaver.PendingVirtualCast = abilityId
	end
end

function GCDsaver.PLAYER_END_CAST(fail)
	local abilityId = GCDsaver.PendingVirtualCast
	GCDsaver.PendingVirtualCast = nil
	if abilityId and not fail then GCDsaver.StartVirtualCooldown(abilityId) end
end

function GCDsaver.PLAYER_ABILITY_TOGGLED(abilityId, isActive)
	abilityId = tonumber(abilityId)
	if abilityId == RUNE_PRIEST_MECHANIC_ABILITY or abilityId == ZEALOT_MECHANIC_ABILITY then
		GCDsaver.RunepriestZealotMechanic = isActive and 1 or 0
		GCDsaver.QueueVisualRefresh("Mechanic")
	end
	if isActive then GCDsaver.StartVirtualCooldown(abilityId) end
end

function GCDsaver.COMBAT_LOG_UPDATED(updateType, filterType)
	if not usesAutoAttackSync() then return end
	if updateType ~= SystemData.TextLogUpdate.ADDED
	or filterType ~= SystemData.ChatLogFilters.YOUR_HITS
	then
		return
	end

	local count = TextLogGetNumEntries("Combat")
	if not count or count <= 0 then return end

	local _, _, text = TextLogGetEntry("Combat", count - 1)
	if not text then return end

	local lowerText = wstring.lower(text)
	if lowerText:find(L"attack")
	or lowerText:find(L"ability")
	or lowerText:find(L"ataque")
	or lowerText:find(L"habilidad")
	then
		GCDsaver.OnAutoAttackSwing()
	end
end

function GCDsaver.RefreshAutoAttackSpeed()
	local slot = getRightHand()
	if not slot or not slot.speed then
		GCDsaver.AABaseSpeed = 0
		return false
	end

	GCDsaver.AABaseSpeed = GetBonus(GameData.BonusTypes.EBONUS_AUTO_ATTACK_SPEED, slot.speed) or 0
	return GCDsaver.AABaseSpeed > 0
end

function GCDsaver.OnAutoAttackSwing()
	if not GCDsaver.RefreshAutoAttackSpeed() then
		GCDsaver.AASwingActive = false
		GCDsaver.AASwingRemaining = 0
		GCDsaver.AASwingDuration = 0
		return
	end

	GCDsaver.AASwingActive = true
	GCDsaver.AASwingDuration = GCDsaver.AABaseSpeed
	GCDsaver.AASwingRemaining = GCDsaver.AASwingDuration
	GCDsaver.LastDynamicSlotStates = {}
end

function GCDsaver.UpdateAutoAttackTimer(elapsed)
	local inCombat = (GameData.Player and GameData.Player.inCombat) or false
	if inCombat ~= GCDsaver.InCombat then
		GCDsaver.InCombat = inCombat
		if not inCombat then
			GCDsaver.AASwingActive = false
			GCDsaver.AASwingRemaining = 0
			GCDsaver.AASwingDuration = 0
			GCDsaver.LastDynamicSlotStates = {}
		end
	end

	if not inCombat or not GCDsaver.AASwingActive then
		return
	end

	GCDsaver.AASwingRemaining = GCDsaver.AASwingRemaining - elapsed
	if GCDsaver.AASwingRemaining <= 0 then
		GCDsaver.AASwingRemaining = 0
		GCDsaver.AASwingActive = false
		GCDsaver.LastDynamicSlotStates = {}
	end
end

-- Main update function
local function updateVisualState(elapsed)
	iconTimeLeft = iconTimeLeft - elapsed
	if GCDsaver.HotbarDirty or iconTimeLeft <= 0 then
		GCDsaver.HotbarDirty = false
		iconTimeLeft = ICON_UPDATE_DELAY
		-- Keep this fallback: server-side Sequencer can change a slot without
		-- a cast/hotbar event. Unchanged slots do not rebuild their markers.
		GCDsaver.RebuildDynamicSlots()
	end
	GCDsaver.FlushVisualRefresh()
	dynamicButtonTimeLeft = dynamicButtonTimeLeft - elapsed
	if dynamicButtonTimeLeft <= 0 then
		dynamicButtonTimeLeft = DYNAMIC_BUTTON_UPDATE_DELAY
		GCDsaver.UpdateDynamicButtonStates()
	end
end

function GCDsaver.OnUpdate(elapsed)
	GCDsaver.RuntimeTime = GCDsaver.RuntimeTime + elapsed
	if not GCDsaver.Settings.Enabled then return end
	GCDsaver.EnsureActionButtonHook()

	GCDsaver.UpdatePendingVirtualCooldownAttempts()
	if usesAutoAttackSync() then
		GCDsaver.UpdateAutoAttackTimer(elapsed)
	else
		GCDsaver.AASwingActive = false
		GCDsaver.AASwingRemaining = 0
	end
	if GCDsaver.HotbarDirty or iconTimeLeft <= elapsed or dynamicButtonTimeLeft <= elapsed
	or next(GCDsaver.DirtyCategories) ~= nil or next(GCDsaver.DirtyActions) ~= nil or next(GCDsaver.DirtySlots) ~= nil then
		withEvaluation(updateVisualState, elapsed)
	else
		iconTimeLeft = iconTimeLeft - elapsed
		dynamicButtonTimeLeft = dynamicButtonTimeLeft - elapsed
	end
end

function GCDsaver.UpdateSettings()
	if not GCDsaver.Settings.Enabled then GCDsaver.ResetActionGate() end
	GCDsaver.NormalizeSettings()
	if GCDsaver.Settings.Enabled and not eventsRegistered then
		GCDsaver.RegisterEvents()
	elseif not GCDsaver.Settings.Enabled and eventsRegistered then
		GCDsaver.UnregisterEvents()
	end
	GCDsaver.RebuildDynamicSlots()
	GCDsaver.LastDynamicSlotStates = {}
	GCDsaver.UpdateButtonIcons()
	GCDsaver.UpdateButtonsEnabledStates()

	TextLogAddEntry("Chat", 0, L"GCDsaver v" .. towstring(GCDsaver.Settings.Version) .. T("settings_suffix"))
	TextLogAddEntry("Chat", 0, GCDsaver.Settings.Enabled and T("status_enabled") or T("status_disabled"))
	TextLogAddEntry("Chat", 0, GCDsaver.Settings.Symbols and T("status_symbols_on") or T("status_symbols_off"))
	TextLogAddEntry("Chat", 0, GCDsaver.Settings.ErrorMessages and T("status_errors_on") or T("status_errors_off"))
	TextLogAddEntry("Chat", 0, GCDsaver.Settings.AASyncEnabled and T("status_aa_on") or T("status_aa_off"))
	TextLogAddEntry("Chat", 0, GCDsaver.Settings.ResourceLimitsEnabled and T("status_resource_on") or T("status_resource_off"))
end

function GCDsaver.SetImmovable(isImmovable)
	GCDsaver.TargetImmovable = isImmovable
end

function GCDsaver.SetUnstoppable(isUnstoppable)
	GCDsaver.TargetUnstoppable = isUnstoppable
end

function GCDsaver.GetAbilityConfiguration(actionId)
	return {
		Condition = GCDsaver.Settings.Abilities[actionId],
		AALead = GCDsaver.Settings.AASyncAbilities[actionId],
		ResourceRule = getResourceRule(actionId),
		CareerMechanicRule = getCareerMechanicRule(actionId),
		TargetHealthRule = getTargetHealthRule(actionId),
		VirtualCooldown = sanitizeVirtualCooldown(GCDsaver.Settings.VirtualCooldowns[actionId]),
		EffectRefreshWindow = getEffectRefreshWindow(actionId),
		EffectRequirement = sanitizeEffectRequirement(GCDsaver.Settings.EffectRequirements[actionId]),
	}
end

function GCDsaver.ConfigureAbility(actionId, configuration)
	if type(configuration) ~= "table" or not actionId or actionId == 0 then return end
	GCDsaver.Settings.Abilities[actionId] = configuration.Condition
	GCDsaver.Settings.AASyncAbilities[actionId] = configuration.AALead
	GCDsaver.Settings.ResourceRules[actionId] = configuration.ResourceRule
	GCDsaver.Settings.CareerMechanicRules[actionId] = configuration.CareerMechanicRule
	GCDsaver.Settings.TargetHealthRules[actionId] = configuration.TargetHealthRule
	GCDsaver.Settings.VirtualCooldowns[actionId] = configuration.VirtualCooldown
	GCDsaver.Settings.EffectRefreshWindows[actionId] = configuration.EffectRefreshWindow
	GCDsaver.Settings.EffectRequirements[actionId] = configuration.EffectRequirement
	GCDsaver.NormalizeSettings()
	GCDsaver.RebuildDynamicSlots()
	GCDsaver.LastDynamicSlotStates = {}
	setButtonIcon(actionId)
	GCDsaver.UpdateButtonsEnabledStates()
end

function GCDsaver.UpdateButtonIcons()
	for slot = 1, MAX_BUTTONS do
		local _, actionId = GetHotbarData(slot)
		local hbar, buttonid = ActionBars:BarAndButtonIdFromSlot(slot)
		if hbar and buttonid then applyButtonIcon(hbar.m_Buttons[buttonid], actionId or 0) end
	end
end

local function isDynamicAction(actionId)
	return (GCDsaver.Settings.AASyncEnabled and GCDsaver.Settings.AASyncAbilities[actionId] ~= nil)
		or (GCDsaver.Settings.ResourceLimitsEnabled and GCDsaver.Settings.ResourceRules[actionId] ~= nil)
		or GCDsaver.Settings.CareerMechanicRules[actionId] ~= nil
		or GCDsaver.Settings.TargetHealthRules[actionId] ~= nil
		or GCDsaver.Settings.VirtualCooldowns[actionId] ~= nil
		or GCDsaver.Settings.EffectRefreshWindows[actionId] ~= nil
end

function GCDsaver.RebuildDynamicSlots()
	for slot = 1, MAX_BUTTONS do
		local actionType, actionId = GetHotbarData(slot)
		local limited = isLimitedActionType(actionType) and actionId and actionId ~= 0
		local previousActionId = GCDsaver.DynamicSlots[slot]
		local currentActionId = limited and isDynamicAction(actionId) and actionId or nil
		GCDsaver.DynamicSlots[slot] = currentActionId
		GCDsaver.LimitedSlots[slot] = limited and (currentActionId
			or GCDsaver.Settings.Abilities[actionId] or GCDsaver.Settings.EffectRequirements[actionId]) and actionId or nil
		if previousActionId ~= currentActionId then
			GCDsaver.LastDynamicSlotStates[slot] = nil
			-- RoR server-side cast sequences may not emit PLAYER_BEGIN_CAST for
			-- instant abilities. A sequence advance during the GCD confirms that
			-- the previous configured ability was successfully used.
			if previousActionId
			and isLimitedActionType(actionType)
			and sanitizeVirtualCooldown(GCDsaver.Settings.VirtualCooldowns[previousActionId]) ~= nil
			and getHotbarCooldownRemaining(slot) > 0
			then
				GCDsaver.StartVirtualCooldown(previousActionId)
			end
		end
		local hbar, buttonid = ActionBars:BarAndButtonIdFromSlot(slot)
		local button = hbar and buttonid and hbar.m_Buttons[buttonid] or nil
		local buttonAction = button and button.m_ActionId or nil
		local buttonType = button and button.m_ActionType or nil
		local changed = GCDsaver.SlotActions[slot] ~= actionId
			or GCDsaver.SlotTypes[slot] ~= actionType or GCDsaver.SlotButtons[slot] ~= button
			or GCDsaver.SlotButtonActions[slot] ~= buttonAction or GCDsaver.SlotButtonTypes[slot] ~= buttonType
		GCDsaver.SlotActions[slot] = actionId
		GCDsaver.SlotTypes[slot] = actionType
		GCDsaver.SlotButtons[slot] = button
		GCDsaver.SlotButtonActions[slot] = buttonAction
		GCDsaver.SlotButtonTypes[slot] = buttonType
		if changed then
			GCDsaver.DirtySlots[slot] = true
			GCDsaver.LastDynamicSlotStates[slot] = nil
			if button then applyButtonIcon(button, actionId or 0) end
		elseif button then
			-- Recover an overlay recreated by a bar addon without rewriting
			-- unchanged labels on every periodic scan.
			local markerName = getButtonMarkerWindowName(button)
			if markerName and markerStates[markerName] and markerStates[markerName] ~= ""
			and not DoesWindowExist(markerName) then applyButtonIcon(button, actionId or 0) end
		end
	end
end

local function updateSlotState(slot, expectedActionId)
	local dispatched = evaluationContext and evaluationContext.dispatched
	if dispatched and dispatched[slot] then return end
	local actionType, actionId, isSlotEnabled, isTargetValid, isSlotBlocked = GetHotbarData(slot)
	if expectedActionId and (not isLimitedActionType(actionType) or actionId ~= expectedActionId) then
		GCDsaver.HotbarDirty = true
		return
	end
	if evaluationContext then
		if not dispatched then
			dispatched = {}
			evaluationContext.dispatched = dispatched
		end
		dispatched[slot] = true
	end
	local blocked = isLimitedActionType(actionType) and actionId and actionId ~= 0
		and isAbilityBlocked(actionId, false) or false
	-- Publish the authoritative values only for this nested dispatch. Our
	-- ActionBars hook can reuse them instead of reading the same slot twice.
	local previousSlotState = evaluationContext and evaluationContext.slotState
	if evaluationContext then
		evaluationContext.slotState = { Slot = slot, ActionType = actionType, ActionId = actionId }
	end
	local ok, err = pcall(ActionBars.UpdateSlotEnabledState,
		slot, isSlotEnabled, isTargetValid, isSlotBlocked)
	if evaluationContext then evaluationContext.slotState = previousSlotState end
	if not ok then error(err, 0) end
	-- A failed native dispatch must not be remembered as successfully painted.
	GCDsaver.LastDynamicSlotStates[slot] = blocked
end

local function updateDynamicButtonStates()
	for slot, actionId in pairs(GCDsaver.DynamicSlots) do
		local blocked = isAbilityBlocked(actionId, false)
		if GCDsaver.LastDynamicSlotStates[slot] ~= blocked then
			updateSlotState(slot, actionId)
		end
	end
end

function GCDsaver.UpdateDynamicButtonStates()
	withEvaluation(updateDynamicButtonStates)
end

local function affectedByEvent(actionId, categories)
	if categories.All then return true end
	local settings = GCDsaver.Settings
	local condition = settings.Abilities[actionId]
	if categories.Target and (condition or settings.EffectRequirements[actionId] or settings.TargetHealthRules[actionId]) then return true end
	if categories.Immunity and (condition == IMMOVABLE or condition == UNSTOPPABLE) then return true end
	if categories.Mechanic and settings.CareerMechanicRules[actionId] then return true end
	if categories.Effects then
		return settings.EffectRequirements[actionId] ~= nil
			or (type(condition) == "number" and ((condition >= 1 and condition <= 3)
				or (condition >= SELF_1 and condition <= SELF_3)))
	end
	return false
end

local function flushVisualRefresh()
	local categories, actions, slots = GCDsaver.DirtyCategories, GCDsaver.DirtyActions, GCDsaver.DirtySlots
	if next(categories) == nil and next(actions) == nil and next(slots) == nil then return end
	-- Detach the queue first so events re-entered by native/UI hooks survive.
	GCDsaver.DirtyCategories, GCDsaver.DirtyActions, GCDsaver.DirtySlots = {}, {}, {}
	for slot in pairs(slots) do updateSlotState(slot) end
	for slot, actionId in pairs(GCDsaver.LimitedSlots) do
		if actions[actionId] or affectedByEvent(actionId, categories) then
			updateSlotState(slot, actionId)
		end
	end
end

function GCDsaver.FlushVisualRefresh()
	withEvaluation(flushVisualRefresh)
end

local function updateButtonsEnabledStates()
	for slot = 1, MAX_BUTTONS do
		updateSlotState(slot)
	end
end

function GCDsaver.UpdateButtonsEnabledStates()
	withEvaluation(updateButtonsEnabledStates)
end
-- Hooked Functions
local orgActionButtonUpdateInventory = ActionButton.UpdateInventory
local orgActionBarsUpdateSlotEnabledState = ActionBars.UpdateSlotEnabledState

local function getInputAction(button)
	if not button then return nil, nil end
	-- EA_ActionBars:SetActionData uses GetHotbarData as its authoritative
	-- source. Read the same slot here: m_ActionType/m_ActionId can still name
	-- the previous ability while the engine already contains a macro.
	if button.m_HotBarSlot ~= nil and type(GetHotbarData) == "function" then
		local ok, actionType, actionId = pcall(GetHotbarData, button.m_HotBarSlot)
		if ok and actionType ~= nil then return actionType, actionId end
	end
	return getButtonActionType(button), button.m_ActionId
end

local function getLimitedInputAction(button)
	local actionType, actionId = getInputAction(button)
	if not isLimitedActionType(actionType) or actionId == nil or actionId == 0 then
		return nil, nil
	end
	return actionType, actionId
end

function GCDsaver.ResetActionGate()
	local actionGate = GCDsaver.ActionGate
	if actionGate and WindowGameAction == actionGate.Handler then
		WindowGameAction = actionGate.BaseHandler
	end
	GCDsaver.ActionGate = nil

	local itemGate = GCDsaver.ItemGate
	if itemGate and SendUseItem == itemGate.Handler then
		SendUseItem = itemGate.BaseHandler
	end
	GCDsaver.ItemGate = nil
end

-- Kept as a compatibility entry point for older integrations.
function GCDsaver.EnsureActionGate()
end

local function getActionWindowName(button)
	local active = SystemData and SystemData.ActiveWindow and SystemData.ActiveWindow.name
	if type(active) == "string" and active ~= "" then return active end

	local name = button and button.m_Name
	if button and type(button.GetName) == "function" then
		local ok, value = pcall(button.GetName, button)
		if ok and type(value) == "string" and value ~= "" then name = value end
	end
	if type(name) ~= "string" or name == "" then return nil end
	if string.sub(name, -6) == "Action" then return name end
	return name .. "Action"
end

local function installWindowActionGate(button, actionType, actionId, block, trackVirtual)
	local windowName = getActionWindowName(button)
	local baseHandler = WindowGameAction
	if windowName == nil or type(baseHandler) ~= "function" then return false end

	local gate = {
		WindowName = windowName,
		Button = button,
		ActionType = actionType,
		ActionId = actionId,
		Block = block == true,
		TrackVirtual = trackVirtual == true,
		BaseHandler = baseHandler,
	}
	gate.Handler = function(calledWindowName, ...)
		-- Other UI actions, including ASSIST_PLAYER and macros outside this
		-- exact hotbar window, always retain the native/external route.
		if calledWindowName ~= gate.WindowName then
			return gate.BaseHandler(calledWindowName, ...)
		end

		local currentType, currentId = getInputAction(gate.Button)
		local matches = currentType == gate.ActionType and currentId == gate.ActionId
		GCDsaver.ResetActionGate()
		if matches and gate.Block then
			diagnosticLog("GATE BLOCK action=" .. tostring(gate.ActionId))
			return
		end

		local result = gate.BaseHandler(calledWindowName, ...)
		if matches and gate.TrackVirtual then
			GCDsaver.QueueVirtualCooldownAttempt(gate.ActionId, gate.Button.m_HotBarSlot)
		end
		return result
	end

	GCDsaver.ActionGate = gate
	WindowGameAction = gate.Handler
	return true
end

local function installItemActionGate(button, actionType, actionId, block, trackVirtual)
	local baseHandler = SendUseItem
	if type(baseHandler) ~= "function" then return false end

	local expectedLoc, expectedSlot
	if DataUtils and type(DataUtils.FindItem) == "function" then
		local ok, _, itemLoc, itemSlot = pcall(DataUtils.FindItem, actionId)
		if ok then expectedLoc, expectedSlot = itemLoc, itemSlot end
	end

	local gate = {
		Button = button,
		ActionType = actionType,
		ActionId = actionId,
		ExpectedLoc = expectedLoc,
		ExpectedSlot = expectedSlot,
		Block = block == true,
		TrackVirtual = trackVirtual == true,
		BaseHandler = baseHandler,
	}
	gate.Handler = function(itemLoc, itemSlot, ...)
		if gate.ExpectedLoc ~= nil
		and (itemLoc ~= gate.ExpectedLoc or itemSlot ~= gate.ExpectedSlot) then
			return gate.BaseHandler(itemLoc, itemSlot, ...)
		end

		GCDsaver.ResetActionGate()
		if gate.Block then
			diagnosticLog("ITEM GATE BLOCK action=" .. tostring(gate.ActionId))
			return
		end

		local result = gate.BaseHandler(itemLoc, itemSlot, ...)
		if gate.TrackVirtual then
			GCDsaver.QueueVirtualCooldownAttempt(gate.ActionId, gate.Button.m_HotBarSlot)
		end
		return result
	end

	GCDsaver.ItemGate = gate
	SendUseItem = gate.Handler
	return true
end

local function installActivationGate(button, actionType, actionId, block, trackVirtual)
	local actions = GameData and GameData.PlayerActions
	if actions and actionType == actions.USE_ITEM then
		return installItemActionGate(button, actionType, actionId, block, trackVirtual)
	end
	return installWindowActionGate(button, actionType, actionId, block, trackVirtual)
end

local function hasButtonFlag(flags, expectedFlag)
	if flags == expectedFlag then return true end
	if flags ~= nil and type(BitAnd) == "function" then
		return BitAnd(flags, expectedFlag) ~= 0
	end
	return false
end

function ActionButton.UpdateInventory(self)
	orgActionButtonUpdateInventory(self)
	if self and self.m_Windows and self.m_Windows[7] then
		-- Older GCDsaver builds reused this label for markers. Restore its
		-- native appearance and leave its text/showing state to EA_ActionBars.
		self.m_Windows[7]:SetFont("font_chat_text", WindowUtils.FONT_DEFAULT_TEXT_LINESPACING)
		self.m_Windows[7]:SetTextColor(255, 255, 255)
	end
	if self and self.m_ActionId and self.m_ActionId ~= 0 then
		applyButtonIcon(self, self.m_ActionId)
	end
end

-- TexturedButtons 1.3.10 calls its saved OnLButtonDown without arguments.
-- Depending on load order that saved function is native or an earlier hook.
-- Keep the original event context and constrain the mouse lookup ONLY while
-- forwarding this press. Keyboard input must never start a mouse drag.
local downDispatchContext = nil

local function finishButtonDownDispatch(context, ok, ...)
	context.Active = false
	if context.Manager.GetMouseOverWindow == context.MouseOverGuard then
		context.Manager.GetMouseOverWindow = context.MouseOver
	end
	downDispatchContext = context.Previous
	if not ok then error((...), 0) end
	return ...
end

local function forwardButtonDown(nextHandler, self, flags, x, y)
	if type(TexturedButtons) ~= "table" or type(FrameManager) ~= "table"
	or type(FrameManager.GetMouseOverWindow) ~= "function" then
		return nextHandler(self, flags, x, y)
	end
	local context = {
		Previous = downDispatchContext,
		Button = self, Flags = flags, X = x, Y = y,
		Manager = FrameManager, MouseOver = FrameManager.GetMouseOverWindow,
		Active = true,
	}
	context.MouseOverGuard = function(manager)
		-- If another addon retains this temporary wrapper, it becomes a
		-- transparent forwarder as soon as the originating press finishes.
		if not context.Active then return context.MouseOver(manager) end
		if context.Flags == SystemData.ButtonFlags.GAME_ACTION then return nil end
		local button = context.MouseOver(manager)
		if button and type(button.GetSlot) == "function"
		and type(button.VerifySlotIsUserModifiable) == "function" then
			return button
		end
		return nil
	end
	downDispatchContext = context
	context.Manager.GetMouseOverWindow = context.MouseOverGuard
	return finishButtonDownDispatch(context, pcall(nextHandler, self, flags, x, y))
end

function GCDsaver.HandleActionButtonOnLButtonDown(nextHandler, self, flags, x, y)
	if self == nil and downDispatchContext then
		local context = downDispatchContext
		self, flags, x, y = context.Button, context.Flags, context.X, context.Y
	end
	-- A context-free call with no button is not a real activation. Do not
	-- guess one from the window under the mouse or pass nil into native code.
	if self == nil then return end
	-- This mirrors the proven 1.0.5 lifecycle: every new hotbar press clears
	-- the previous gate before classifying the concrete engine action.
	GCDsaver.ResetActionGate()
	-- Classify the action the engine is actually about to execute. A button can
	-- retain stale ability metadata after a macro or /assist is placed on it.
	local actionType, actionId = getLimitedInputAction(self)
	diagnosticAction("DOWN", self, flags, actionType, actionId)
	if actionType == nil then
		diagnosticLog("DOWN PASS NON_LIMITED")
		return forwardButtonDown(nextHandler, self, flags, x, y)
	end

	if hasButtonFlag(flags, SystemData.ButtonFlags.ALT) then
		installActivationGate(self, actionType, actionId, true, false)
		if GCDsaver_AbilityMenu and GCDsaver_AbilityMenu.Open then
			GCDsaver_AbilityMenu.Open(actionId)
		else
			TextLogAddEntry("Chat", 0, T("editor_unavailable"))
		end
		return
	end

	if hasButtonFlag(flags, SystemData.ButtonFlags.SHIFT) then
		installActivationGate(self, actionType, actionId, true, false)
		local current = GCDsaver.Settings.Abilities[actionId]
		if type(current) ~= "number" then
			GCDsaver.Settings.Abilities[actionId] = 1
		elseif current < SELF_3 then
			GCDsaver.Settings.Abilities[actionId] = current + 1
		else
			GCDsaver.Settings.Abilities[actionId] = nil
		end
		GCDsaver.RebuildDynamicSlots()
		setButtonIcon(actionId)
		GCDsaver.UpdateButtonsEnabledStates()
		chatInfo(actionId, GCDsaver.Settings.Abilities[actionId])
		return
	end

	if isAbilityBlocked(actionId, true) then
		installActivationGate(self, actionType, actionId, true, false)
		diagnosticLog("DOWN ARM BLOCK action=" .. tostring(actionId))
		return
	end

	local slot = self.m_HotBarSlot
	local trackVirtual = slot ~= nil
		and sanitizeVirtualCooldown(GCDsaver.Settings.VirtualCooldowns[actionId]) ~= nil
		and getHotbarCooldownRemaining(slot) <= 0
	if trackVirtual then
		installActivationGate(self, actionType, actionId, false, true)
	end

	-- The client retains its original OnLButtonUp method. For allowed actions
	-- this forwards only the drag/pickup phase; execution stays entirely native.
	return forwardButtonDown(nextHandler, self, flags, x, y)
end

function GCDsaver.EnsureActionButtonHook()
	if ActionButton.OnLButtonDown ~= GCDsaver.ActionButtonDownHook then
		local nextDownHandler = ActionButton.OnLButtonDown
		if type(nextDownHandler) == "function" then
			local downHook = function(self, flags, x, y)
				return GCDsaver.HandleActionButtonOnLButtonDown(nextDownHandler, self, flags, x, y)
			end
			GCDsaver.ActionButtonDownHook = downHook
			ActionButton.OnLButtonDown = downHook
			diagnosticLog("INSTALL DOWN HOOK")
		end
	end
end

function ActionBars.UpdateSlotEnabledState(slot, isSlotEnabled, isTargetValid, isSlotBlocked)
	-- Use the engine slot, exactly as EA_ActionBars:SetActionData does. Reading
	-- the button cache here can leave a newly placed macro (notably /assist)
	-- disabled because the frame still contains the previous ability ID.
	local slotState = evaluationContext and evaluationContext.slotState
	local actionType, actionId
	if slotState and slotState.Slot == slot then
		actionType, actionId = slotState.ActionType, slotState.ActionId
	else
		actionType, actionId = GetHotbarData(slot)
	end
	if isLimitedActionType(actionType) and actionId and actionId ~= 0
	and isAbilityBlocked(actionId, false) then
		isSlotEnabled = false
	end
	orgActionBarsUpdateSlotEnabledState(slot, isSlotEnabled, isTargetValid, isSlotBlocked)
end
