# GCDsaver 1.2.14

GCDsaver has evolved from a simple GCD/ability limiter into a configurable ability-control addon. Version 1.2.14 retains the integrated PotionSaver functionality, performance improvements and TexturedButtons compatibility, and replaces the remaining transient execution blocker.

## Assist execution fix in 1.2.14

- GCDsaver now keeps a type-aware execution filter installed while enabled instead of installing and removing a generic blocker around individual presses.
- Every execution is classified using the action data attached to the actual engine window. Only abilities, pet abilities and items can enter the configured limit checks; macros, assist actions and unrelated windows always continue to the previous handler.
- Engine window data takes priority over stale button metadata. A macro replacing a previously blocked ability in the same physical slot is therefore allowed immediately, even before an action-bar addon refreshes its cached button fields.
- A missing key-up event can no longer leave `/assist` dependent on stale blocker state. Configured abilities remain protected even when the engine invokes the action without a Lua button-down callback.
- Disabling or unloading GCDsaver restores the previous execution handler. Existing limits, TexturedButtons input compatibility, action-bar dragging and performance behavior remain intact.

Validation: 67 action/input regression cases pass, including 10 permanent-filter cases, the 29 earlier action-gate cases and 28 cases using the actual native/TexturedButtons input functions in both load orders. The 27 performance cases and 15,360 differential comparisons also pass. Client APIs remain simulated, so live `/assist` confirmation is still required.

## Assist compatibility fix in 1.2.13

- Handle TexturedButtons calling its previous button-down handler without the original arguments. This could interrupt `/assist` macros with a native `GetSlot` error when a keyboard shortcut was pressed over another UI frame.
- Preserve the originating button and keyboard/mouse context through chained handlers. Keyboard shortcuts no longer enter the mouse-pickup path because their flags were lost.
- Restore the temporary mouse-over guard when the press finishes, including on errors. Native dragging, modifier pickup and existing ability restrictions are preserved.
- No TexturedButtons files, macro contents or saved character settings are edited.

Validation: the same native `GetSlot` error was reproduced on 1.2.12 with both addon load orders. All 28 new cases using the actual native and TexturedButtons input functions pass, together with the previous 56 regressions and 15,360 differential comparisons. Client APIs remain mocked; in-game confirmation is still required. After updating, use `/reload`, confirm version 1.2.13 in chat and test the `/assist` macro with the pointer over a buff/target window and over the action bar.

## Performance improvements in 1.2.12

- Buff, target, immunity, mechanic and hotbar notifications arriving together are grouped into one visual refresh per frame.
- Event-driven refreshes update the affected limited slots instead of repeatedly scanning every button.
- Buff lists, ability data, normalized rules and block results are shared within each visual refresh and discarded afterwards.
- Unchanged button indicators are no longer rewritten periodically. Empty slots clear their old indicators, and replaced buttons or destroyed overlays are detected.
- Unused AA synchronization no longer parses combat text or advances its timer.
- Immediate press/release checks remain independent of visual snapshots. The periodic Sequencer and virtual-cooldown fallback is retained, as are the assist/macro compatibility fixes.

Validation: 56 Lua 5.1 regression tests and 15,360 old/new slot-state and activation comparisons passed using mocked game APIs. In a synthetic burst of 20 buff notifications with 60 slots and 10 effect-limited abilities, button refreshes fell from 1,200 to 10 and buff queries from 400 to 1. These are API-call counts, not measured in-game FPS; live combat testing is still recommended.

## What's new

- Per-ability configuration menu opened with **Alt + Left Click**.
- Optional unrestricted condition for abilities that should always remain usable.
- Potion/resource-saving limits integrated into GCDsaver.
- Auto-attack synchronization, with configurable lead/cast-time compensation.
- Per-ability career-mechanic limits: allow only at or above, at or below, or exactly at a configured value.
- Career-mechanic values can be typed directly instead of using only +/- buttons.
- Career-resource handling adapted from NerfedButtons, including signed Archmage/Shaman values and Rune Priest/Zealot toggle states.
- Per-ability effect-refresh window (0-30 seconds, in 0.5-second steps) for refreshing target or self HoTs/buffs before they expire.
- Existing matching effects block above the chosen window and become refreshable at or below it; permanent effects remain blocked.
- Configurable virtual cooldowns for abilities, including abilities with no native cooldown.
- Required buff/debuff checks using one or several effect IDs. Enter IDs separated by commas; any matching effect satisfies the requirement.
- Option to require that the effect was applied by the player.
- Target-health conditions for offensive targets, friendly targets or the player.
- Automatic fallback to the player's health when no valid target is available.
- English and Spanish localization. English is used by default.
- Reworked ability-limits window with separate main, effect-refresh, career-mechanic, advanced and target-health pages.

All enabled limits are combined: an ability is allowed only when every configured condition is satisfied. Leaving an ID empty or selecting **Disabled / No limit** removes that particular condition.

## Important fixes and changes in 1.2.11

- Fixed three cooldown conversions that could raise Lua errors and interrupt hotbar actions, including assist macros.
- Macros and assist actions now bypass ability limits, editor shortcuts, markers and virtual-cooldown tracking.
- Temporary execution blocking is restricted to the affected button; unrelated assist and targeting windows continue to work.
- Disabling or unloading GCDsaver restores the original execution handler.

- Fixed potion and item quantities being hidden by GCDsaver's button indicators. Item counts and GCDsaver markers now use separate labels.
- Restored the original GCDsaver 1.0.7 action-blocking method and extended it to every limiter.
- Fixed virtual cooldowns appearing active visually without stopping the actual ability.
- Fixed target-health limits displaying a blocked state without stopping the actual ability.
- Fixed auto-attack synchronization not preventing early activation.
- Blocking now covers both mouse clicks and keyboard activations.
- Alt/Shift configuration clicks no longer execute the underlying ability or item.
- Widened condition drop-downs and shortened labels to prevent overlapping or truncated text.
- Corrected Spanish localization and accented characters.
- Improved compatibility with action-bar addons that replace the standard button handlers.

## Controls

- **Alt + Left Click** an action-bar ability to open its limits editor, including the **Effect refresh** and **Career mechanic** tabs.
- **Shift + Left Click** to cycle the ability's quick condition, including the unrestricted option.
- Use **Save** to apply changes, **Cancel** to close without applying them, or **Revert** to restore the saved configuration.

## Updating

1. Replace the previous GCDsaver folder with the new version.
2. Disable or remove the separate PotionSaver addon to avoid duplicate handling.
3. Start the game or enter `/reload` if updating while the client is running.

Existing GCDsaver settings are preserved where compatible. Keeping a backup of the previous addon folder and character settings is recommended before updating.

## Testing and feedback

This performance update preserves the scoped action-execution gate from 1.2.11. Please report any ability that is visually blocked but still activates, or any indicator that stops updating, and include:

- ability name and ID;
- configured limits;
- whether it was activated by mouse or keyboard;
- the action-bar addons being used;
- offensive, friendly or no target;
- game language;
- career and current mechanic value when reporting a mechanic-rule problem.

---

# GCDsaver 1.2.14 — Notas en español

GCDsaver ha evolucionado de un limitador sencillo de GCD y habilidades a un sistema configurable de control por habilidad. La versión 1.2.14 conserva las funciones integradas de PotionSaver, las mejoras de rendimiento y la compatibilidad con TexturedButtons, y sustituye el bloqueo temporal de ejecución que aún quedaba.

## Corrección de la ejecución del assist en 1.2.14

- GCDsaver mantiene un filtro de ejecución que conoce el tipo de acción mientras está activo, en lugar de instalar y retirar un bloqueador genérico alrededor de cada pulsación.
- Cada ejecución se clasifica mediante los datos de la ventana real del motor. Solo las habilidades, habilidades de mascota y objetos pueden entrar en las comprobaciones configuradas; las macros, acciones de assist y ventanas ajenas continúan siempre hacia el controlador anterior.
- Los datos de la ventana del motor tienen prioridad sobre los datos atrasados del botón. Una macro que sustituya a una habilidad bloqueada en la misma casilla se permite inmediatamente, incluso antes de que otro addon actualice su caché.
- La ausencia de un evento de soltar tecla ya no puede dejar `/assist` dependiendo del estado antiguo del bloqueador. Las habilidades configuradas siguen protegidas aunque el motor invoque una acción sin pasar por la pulsación Lua.
- Al desactivar o descargar GCDsaver se restaura el controlador anterior. Se conservan los límites, la compatibilidad con TexturedButtons, el arrastre de la barra y las mejoras de rendimiento.

Validación: pasan 67 casos de acciones y entrada, incluidos 10 casos del filtro permanente, los 29 casos anteriores y 28 casos que utilizan las funciones reales de entrada nativa y TexturedButtons con ambos órdenes de carga. También pasan los 27 casos de rendimiento y 15.360 comparaciones diferenciales. Las APIs del cliente siguen simuladas, por lo que aún falta confirmar `/assist` dentro del juego.

## Corrección de compatibilidad del assist en 1.2.13

- Se contempla que TexturedButtons llame al controlador anterior de pulsaciones sin pasar sus argumentos originales. Esto podía interrumpir las macros `/assist` con un error nativo `GetSlot` al pulsar una tecla con el ratón sobre otra ventana de la interfaz.
- Se conserva el botón y el contexto de teclado/ratón a través de los controladores encadenados. Perder los argumentos ya no hace que una tecla entre en la ruta de arrastre del ratón.
- La protección temporal de la ventana bajo el cursor se restaura al terminar la pulsación, incluso si ocurre un error. Se mantienen el arrastre normal, el arrastre con modificador y los bloqueos existentes.
- No se modifican archivos de TexturedButtons, el contenido de las macros ni los ajustes guardados del personaje.

Validación: se ha reproducido el mismo error nativo `GetSlot` en 1.2.12 con ambos órdenes de carga. Pasan los 28 casos nuevos que utilizan las funciones reales de entrada del cliente y TexturedButtons, además de las 56 pruebas anteriores y 15.360 comparaciones diferenciales. Las APIs del cliente siguen simuladas; falta la confirmación dentro del juego. Tras actualizar, usa `/reload`, comprueba que aparece la versión 1.2.13 en el chat y prueba la macro `/assist` con el ratón sobre una ventana de buffs/objetivo y sobre la barra.

## Mejoras de rendimiento en 1.2.12

- Los avisos de buffs, objetivo, inmunidades, mecánica y barra que llegan juntos se agrupan en una sola actualización visual por fotograma.
- Los eventos actualizan las casillas con límites afectados, sin volver a recorrer todos los botones por cada aviso.
- Las listas de buffs, datos de habilidades, reglas normalizadas y resultados de bloqueo se comparten durante cada actualización visual y se descartan después.
- Los indicadores que no cambian ya no se reescriben periódicamente. Las casillas vacías limpian el indicador anterior y se detectan botones reemplazados o etiquetas destruidas.
- Si no se usa la sincronización con AA, no se analiza el texto de combate ni se actualiza su temporizador.
- Las comprobaciones al pulsar y soltar siguen siendo inmediatas e independientes de la información visual compartida. Se mantiene la revisión periódica para Sequencer y el CD virtual, junto con las correcciones de assist y macros.

Validación: superadas 56 pruebas de regresión en Lua 5.1 y 15.360 comparaciones de estados y activaciones entre versiones con APIs del juego simuladas. En una ráfaga sintética de 20 avisos de buffs, con 60 casillas y 10 habilidades limitadas por efectos, las actualizaciones de botones pasan de 1.200 a 10 y las consultas de buffs de 400 a 1. Son recuentos de llamadas, no mediciones de FPS dentro del juego; se recomienda probar en combate real.

## Novedades

- Menú de configuración por habilidad mediante **Alt + clic izquierdo**.
- Condición sin restricciones para las habilidades que deban estar siempre disponibles.
- Límites de pociones y recursos integrados en GCDsaver.
- Sincronización con el ataque automático, con compensación configurable por antelación y tiempo de casteo.
- Límites de mecánica de carrera por habilidad: permitir solo con un valor igual o superior, igual o inferior, o exactamente igual al configurado.
- Los valores de mecánica de carrera pueden escribirse directamente, sin depender de los botones +/-.
- Lectura de recursos adaptada de NerfedButtons, incluidos los valores con signo de Archmage/Shaman y el estado conmutable de Rune Priest/Zealot.
- Ventana de refresco por habilidad (0-30 segundos, en pasos de 0,5) para renovar HoTs o buffs del objetivo o propios antes de que terminen.
- Los efectos existentes bloquean por encima del margen elegido y permiten relanzar al alcanzarlo; los efectos permanentes siguen bloqueando.
- CD virtual configurable, incluso para habilidades sin tiempo de reutilización propio.
- Requisito de buff o debuff mediante una o varias IDs. Sepáralas con comas; basta con que coincida una.
- Opción para exigir que el efecto haya sido aplicado por el propio jugador.
- Condiciones de vida para objetivo ofensivo, objetivo amistoso o el propio jugador.
- Si no existe un objetivo válido, se utiliza automáticamente la vida del jugador.
- Interfaz en inglés y español. El inglés es el idioma predeterminado.
- Ventana reorganizada en límites principales, refresco del efecto, mecánica de carrera, límites avanzados y vida del objetivo.

Todos los límites activos se combinan: la habilidad solo se permite cuando se cumplen todas las condiciones configuradas. Una ID vacía o una opción **Desactivado / Sin límite** elimina ese requisito.

## Correcciones y cambios importantes de la versión 1.2.11

- Corregidas tres conversiones de cooldown que provocaban errores Lua e interrumpían acciones de la barra, incluidas las macros de assist.
- Las macros y acciones de assist quedan fuera de los límites de habilidades, atajos del editor, indicadores y seguimiento del CD virtual.
- El bloqueo temporal se limita al botón afectado; las otras ventanas de assist y selección de objetivo siguen funcionando.
- Desactivar o descargar GCDsaver restaura el manejador de ejecución original.

- Corregidos los números de las pociones y otros objetos que quedaban ocultos por los indicadores de GCDsaver. Las cantidades y los indicadores utilizan ahora etiquetas independientes.
- Recuperado el método de bloqueo del GCDsaver 1.0.7 original y ampliado a todos los limitadores.
- Corregido el CD virtual que se mostraba activo pero no impedía ejecutar la habilidad.
- Corregidos los límites de vida que mostraban el bloqueo sin impedir la ejecución.
- Corregida la sincronización con el ataque automático.
- El bloqueo funciona tanto con el ratón como con el teclado.
- Los clics de configuración con Alt o Shift ya no ejecutan la habilidad o el objeto asociado.
- Desplegables más anchos y textos abreviados para evitar solapamientos y recortes.
- Corregidos los caracteres acentuados de la traducción española.
- Mejorada la compatibilidad con addons que modifican las barras de acción.

## Controles

- **Alt + clic izquierdo** sobre una habilidad de la barra para abrir su editor, incluidas las pestañas **Refresco del efecto** y **Mecánica de carrera**.
- **Shift + clic izquierdo** para rotar su condición rápida, incluida la opción sin restricciones.
- **Guardar** aplica los cambios, **Cancelar** cierra sin aplicarlos y **Revertir** recupera la configuración guardada.

## Actualización

1. Sustituye la carpeta anterior de GCDsaver por la nueva versión.
2. Desactiva o elimina el addon PotionSaver independiente para evitar que ambos procesen las mismas acciones.
3. Inicia el juego o escribe `/reload` si has actualizado con el cliente abierto.

Las configuraciones anteriores se conservan cuando son compatibles. Se recomienda guardar una copia de la carpeta antigua y de los ajustes de los personajes antes de actualizar.

## Pruebas y comunicación de errores

Esta optimización conserva el bloqueo de ejecución limitado al botón de la versión 1.2.11. Si una habilidad aparece bloqueada pero llega a activarse, o si un indicador deja de actualizarse, indica:

- nombre e ID de la habilidad;
- límites configurados;
- si se utilizó mediante ratón o teclado;
- addons de barras de acción instalados;
- si había un objetivo ofensivo, amistoso o ningún objetivo;
- idioma del juego;
- carrera y valor actual de la mecánica si el problema afecta a esta condición.
