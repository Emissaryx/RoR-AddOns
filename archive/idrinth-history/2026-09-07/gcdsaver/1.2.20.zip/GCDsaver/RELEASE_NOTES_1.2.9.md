# GCDsaver 1.2.9

GCDsaver has evolved from a simple GCD/ability limiter into a configurable ability-control addon. Version 1.2.9 also integrates the former PotionSaver functionality, so both systems can now be managed from a single addon.

## What's new

- Per-ability configuration menu opened with **Alt + Left Click**.
- Optional unrestricted condition for abilities that should always remain usable.
- Potion/resource-saving limits integrated into GCDsaver.
- Auto-attack synchronization, with configurable lead/cast-time compensation.
- Per-ability career-mechanic limits: allow only at or above, at or below, or exactly at a configured value.
- Career-mechanic values can be typed directly instead of using only +/- buttons.
- Career-resource handling adapted from NerfedButtons, including signed Archmage/Shaman values and Rune Priest/Zealot toggle states.
- Per-ability effect-refresh window (0-30 seconds, in 0.5-second steps) for refreshing target or self HoTs/buffs before they expire.
- Existing matching effects block above the chosen window and become refreshable at or below it; permanent effects remain blocked.
- Configurable virtual cooldowns for abilities, including abilities with no native cooldown.
- Required buff/debuff checks by effect ID.
- Option to require that the effect was applied by the player.
- Target-health conditions for offensive targets, friendly targets or the player.
- Automatic fallback to the player's health when no valid target is available.
- English and Spanish localization. English is used by default.
- Reworked ability-limits window with separate main, effect-refresh, career-mechanic, advanced and target-health pages.

All enabled limits are combined: an ability is allowed only when every configured condition is satisfied. Leaving an ID empty or selecting **Disabled / No limit** removes that particular condition.

## Important fixes in 1.2.9

- Fixed potion and item quantities being hidden by GCDsaver's button indicators. Item counts and GCDsaver markers now use separate labels.
- Restored the original GCDsaver 1.0.7 action-blocking method and extended it to every limiter.
- Fixed virtual cooldowns appearing active visually without stopping the actual ability.
- Fixed target-health limits displaying a blocked state without stopping the actual ability.
- Fixed auto-attack synchronization not preventing early activation.
- Blocking now covers both mouse clicks and keyboard activations.
- Alt/Shift configuration clicks no longer execute the underlying ability or item.
- Widened condition drop-downs and shortened labels to prevent overlapping or truncated text.
- Corrected Spanish localization and accented characters.
- Improved compatibility with action-bar addons that replace the standard button handlers.

## Controls

- **Alt + Left Click** an action-bar ability to open its limits editor, including the **Effect refresh** and **Career mechanic** tabs.
- **Shift + Left Click** to cycle the ability's quick condition, including the unrestricted option.
- Use **Save** to apply changes, **Cancel** to close without applying them, or **Revert** to restore the saved configuration.

## Updating

1. Replace the previous GCDsaver folder with the new version.
2. Disable or remove the separate PotionSaver addon to avoid duplicate handling.
3. Start the game or enter `/reload` if updating while the client is running.

Existing GCDsaver settings are preserved where compatible. Keeping a backup of the previous addon folder and character settings is recommended before updating.

## Testing and feedback

This release changes the final action-execution gate. Please report any ability that is visually blocked but still activates, and include:

- ability name and ID;
- configured limits;
- whether it was activated by mouse or keyboard;
- the action-bar addons being used;
- offensive, friendly or no target;
- game language;
- career and current mechanic value when reporting a mechanic-rule problem.

---

# GCDsaver 1.2.9 — Notas en español

GCDsaver ha evolucionado de un limitador sencillo de GCD y habilidades a un sistema configurable de control por habilidad. La versión 1.2.9 también integra las funciones del antiguo PotionSaver, por lo que ambos sistemas se gestionan ahora desde un único addon.

## Novedades

- Menú de configuración por habilidad mediante **Alt + clic izquierdo**.
- Condición sin restricciones para las habilidades que deban estar siempre disponibles.
- Límites de pociones y recursos integrados en GCDsaver.
- Sincronización con el ataque automático, con compensación configurable por antelación y tiempo de casteo.
- Límites de mecánica de carrera por habilidad: permitir solo con un valor igual o superior, igual o inferior, o exactamente igual al configurado.
- Los valores de mecánica de carrera pueden escribirse directamente, sin depender de los botones +/-.
- Lectura de recursos adaptada de NerfedButtons, incluidos los valores con signo de Archmage/Shaman y el estado conmutable de Rune Priest/Zealot.
- Ventana de refresco por habilidad (0-30 segundos, en pasos de 0,5) para renovar HoTs o buffs del objetivo o propios antes de que terminen.
- Los efectos existentes bloquean por encima del margen elegido y permiten relanzar al alcanzarlo; los efectos permanentes siguen bloqueando.
- CD virtual configurable, incluso para habilidades sin tiempo de reutilización propio.
- Requisito de buff o debuff mediante la ID del efecto.
- Opción para exigir que el efecto haya sido aplicado por el propio jugador.
- Condiciones de vida para objetivo ofensivo, objetivo amistoso o el propio jugador.
- Si no existe un objetivo válido, se utiliza automáticamente la vida del jugador.
- Interfaz en inglés y español. El inglés es el idioma predeterminado.
- Ventana reorganizada en límites principales, refresco del efecto, mecánica de carrera, límites avanzados y vida del objetivo.

Todos los límites activos se combinan: la habilidad solo se permite cuando se cumplen todas las condiciones configuradas. Una ID vacía o una opción **Desactivado / Sin límite** elimina ese requisito.

## Correcciones importantes de la versión 1.2.9

- Corregidos los números de las pociones y otros objetos que quedaban ocultos por los indicadores de GCDsaver. Las cantidades y los indicadores utilizan ahora etiquetas independientes.
- Recuperado el método de bloqueo del GCDsaver 1.0.7 original y ampliado a todos los limitadores.
- Corregido el CD virtual que se mostraba activo pero no impedía ejecutar la habilidad.
- Corregidos los límites de vida que mostraban el bloqueo sin impedir la ejecución.
- Corregida la sincronización con el ataque automático.
- El bloqueo funciona tanto con el ratón como con el teclado.
- Los clics de configuración con Alt o Shift ya no ejecutan la habilidad o el objeto asociado.
- Desplegables más anchos y textos abreviados para evitar solapamientos y recortes.
- Corregidos los caracteres acentuados de la traducción española.
- Mejorada la compatibilidad con addons que modifican las barras de acción.

## Controles

- **Alt + clic izquierdo** sobre una habilidad de la barra para abrir su editor, incluidas las pestañas **Refresco del efecto** y **Mecánica de carrera**.
- **Shift + clic izquierdo** para rotar su condición rápida, incluida la opción sin restricciones.
- **Guardar** aplica los cambios, **Cancelar** cierra sin aplicarlos y **Revertir** recupera la configuración guardada.

## Actualización

1. Sustituye la carpeta anterior de GCDsaver por la nueva versión.
2. Desactiva o elimina el addon PotionSaver independiente para evitar que ambos procesen las mismas acciones.
3. Inicia el juego o escribe `/reload` si has actualizado con el cliente abierto.

Las configuraciones anteriores se conservan cuando son compatibles. Se recomienda guardar una copia de la carpeta antigua y de los ajustes de los personajes antes de actualizar.

## Pruebas y comunicación de errores

Esta versión modifica el bloqueo final que impide ejecutar una acción. Si una habilidad aparece bloqueada pero llega a activarse, indica:

- nombre e ID de la habilidad;
- límites configurados;
- si se utilizó mediante ratón o teclado;
- addons de barras de acción instalados;
- si había un objetivo ofensivo, amistoso o ningún objetivo;
- idioma del juego;
- carrera y valor actual de la mecánica si el problema afecta a esta condición.
