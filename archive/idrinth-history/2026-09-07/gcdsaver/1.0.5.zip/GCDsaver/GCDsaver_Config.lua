LibConfig = LibStub("LibConfig")

GCDsaver_Config = {}

local GUI

function GCDsaver_Config.Slash(input)
	if (not GUI) then
		-- parameters: title text, settings table, callback-function
		-- note that you need to have a settings table!
		GUI = LibConfig("GCDsaver v" .. tostring(GCDsaver.Settings.Version), GCDsaver.Settings, true, GCDsaver_Config.SettingsChanged)
		
		GUI:AddTab("Info")
		local infoText
		infoText = GUI("label", "GCDsaver can set a check for abilities that will be ineffective if the target is immune or when the target")
		infoText.label:Font("font_default_text_small")
		infoText.label:Align("left")

		infoText = GUI("label", "has enough stacks from you of the ability's effect. The check will be indicated with these symbols:")
		infoText.label:Font("font_default_text_small")
		infoText.label:Align("left")

		infoText = GUI("label", "1x - One stack")
		infoText.label:Font("font_default_text_small")
		infoText.label:Align("left")

		infoText = GUI("label", "2x - Two stacks")
		infoText.label:Font("font_default_text_small")
		infoText.label:Align("left")

		infoText = GUI("label", "3x - Three stacks")
		infoText.label:Font("font_default_text_small")
		infoText.label:Align("left")

		infoText = GUI("label", "<icon05007> - Immovable")
		infoText.label:Font("font_default_text_small")
		infoText.label:Align("left")

		infoText = GUI("label", "<icon05006> - Unstoppable")
		infoText.label:Font("font_default_text_small")
		infoText.label:Align("left")

		infoText = GUI("label", "When the ability's check is triggered the ability will be disabled (greyed out) on the hotbar.")
		infoText.label:Font("font_default_text_small")
		infoText.label:Align("left")


		infoText = GUI("label", "To toggle the check on an ability SHIFT-LEFT CLICK the ability on your hotbar.")
		infoText.label:Font("font_default_text_small")
		infoText.label:Align("left")

		infoText = GUI("label", "By default targeted abilities that Knock-down, Punt, Stagger, Silence or Disarm are configured accordingly.")
		infoText.label:Font("font_default_text_small")
		infoText.label:Align("left")


		GUI:AddTab("Settings")
		GUI("checkbox", "Enabled", "Enabled")
		GUI("checkbox", "Show Symbols", "Symbols")
		GUI("checkbox", "Show Combat Error messages", "ErrorMessages")

		-- GUI:AddTab("Info")
		-- local infoText
		-- infoText = GUI("label", "GCDsaver is an addon for the lazy or incompetent healer that needs automatic assistance to help decide which player to heal.")
		-- infoText.label:Font("font_default_text_small")
		-- infoText.label:Align("left")

		-- infoText = GUI("label",  "The addon creates a macro which you put on your hotbar. When the macro is clicked the party/scenario/warband-member most in need of heals will be targeted.")
		-- infoText.label:Font("font_default_text_small")
		-- infoText.label:Align("left")

		-- infoText = GUI("label",  "<icon20087> The macro icon will glow when there is a new player in need of heals. The glow will be more intense the more hurt the player is.")
		-- infoText.label:Font("font_default_text_small")
		-- infoText.label:Align("left")

		-- infoText = GUI("label",  "Only players within healing range will be selected and a limited line-of sight check will be performed.")
		-- infoText.label:Font("font_default_text_small")
		-- infoText.label:Align("left")

		-- infoText = GUI("label",  "On the Settings tab you can enable/disable features or the addon entirely. On the Priorities tab you can adjust the behaviour of the selection algorithm.")
		-- infoText.label:Font("font_default_text_small")
		-- infoText.label:Align("left")

		-- GUI:AddTab("Settings")
		-- GUI("checkbox", "Enabled", "enabled")
		-- GUI("checkbox", "Check Line-of-Sight", "losCheck")
		-- GUI("checkbox", "Check Range", "rangeCheck")
		-- --GUI("checkbox", "Favor own Party", "favorOwnParty")
		-- GUI("checkbox", "Own Party Only", "ownPartyOnly")
		-- GUI("checkbox", "Ignore Dead", "ignoreDead")
		-- --GUI("checkbox", "Screen Alerts", "screenAlerts")
		-- GUI("checkbox", "Glow Effects", "glowEffects")

		-- GUI:AddTab("Priorities")
		-- local textbox
		-- textbox = GUI("textbox", "Always prioritize self if health % below:", "selfTargetPct")
		-- textbox.label:Font("font_default_text_small")
		-- textbox.label:Align("left")
		-- textbox.edit:AnchorTo(textbox.label, "right", "right")
		-- textbox.edit:Resize(50)

		-- textbox = GUI("textbox", "Then alive healers with health % below:", "healerTargetPct")
		-- textbox.label:Font("font_default_text_small")
		-- textbox.label:Align("left")
		-- textbox.edit:AnchorTo(textbox.label, "right", "right")
		-- textbox.edit:Resize(50)

		-- textbox = GUI("textbox", "Then alive dps with health % below:", "dpsTargetPct")
		-- textbox.label:Font("font_default_text_small")
		-- textbox.label:Align("left")
		-- textbox.edit:AnchorTo(textbox.label, "right", "right")
		-- textbox.edit:Resize(50)

		-- textbox = GUI("textbox", "Then alive tanks with health % below:", "tankTargetPct")
		-- textbox.label:Font("font_default_text_small")
		-- textbox.label:Align("left")
		-- textbox.edit:AnchorTo(textbox.label, "right", "right")
		-- textbox.edit:Resize(50)

		-- textbox = GUI("textbox", "Otherwise dead players or with health % below:", "playerTargetPct")
		-- textbox.label:Font("font_default_text_small")
		-- textbox.label:Align("left")
		-- textbox.edit:AnchorTo(textbox.label, "right", "right")
		-- textbox.edit:Resize(50)
	end
	GUI:Show()
end

function GCDsaver_Config.SettingsChanged()
	GUI:Hide()
	GCDsaver.UpdateSettings()
end