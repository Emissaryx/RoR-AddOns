LibConfig = LibStub("LibConfig")

GCDsaver_AbilityMenu = GCDsaver_AbilityMenu or {}

local GUI
local BuiltLanguage
local Editor = {
	AbilityLabel = L"",
	Condition = L"",
	EffectRefreshWindow = 0,
	AASync = L"",
	ResourceMode = L"",
	ResourceThreshold = 0,
	MechanicMode = L"",
	MechanicThreshold = "0",
	TargetHealthTarget = L"",
	TargetHealthMode = L"",
	TargetHealthThreshold = 0,
	VirtualCooldown = 0,
	EffectTarget = L"",
	EffectId = "",
	EffectOnlyMine = false,
}

local function T(key)
	return GCDsaver_Lang.Get(key)
end

local function parseEffectIds(value)
	local effectIds = {}
	local seen = {}
	for candidate in string.gmatch(tostring(value or ""), "[^,]+") do
		candidate = string.match(candidate, "^%s*(.-)%s*$")
		local effectId = tonumber(candidate)
		if effectId and effectId > 0 then
			effectId = math.floor(effectId + 0.5)
			if not seen[effectId] then
				seen[effectId] = true
				table.insert(effectIds, effectId)
			end
		end
	end
	return effectIds
end

local function effectIdsText(requirement)
	if type(requirement) ~= "table" then return "" end
	local parts = {}
	for _, effectId in ipairs(requirement.EffectIds or {}) do
		table.insert(parts, tostring(effectId))
	end
	if #parts == 0 and requirement.EffectId then
		table.insert(parts, tostring(requirement.EffectId))
	end
	return table.concat(parts, ", ")
end

local function conditionItems()
	return {
		{ T("condition_none"), nil },
		{ T("condition_target_1"), 1 },
		{ T("condition_target_2"), 2 },
		{ T("condition_target_3"), 3 },
		{ T("condition_immovable"), 4 },
		{ T("condition_unstoppable"), 5 },
		{ T("condition_self_1"), 6 },
		{ T("condition_self_2"), 7 },
		{ T("condition_self_3"), 8 },
	}
end

local function aaItems()
	return {
		{ T("disabled"), nil },
		{ L"0.0 s", 0 },
		{ L"0.5 s", 0.5 },
		{ L"1.0 s", 1 },
		{ L"1.5 s", 1.5 },
		{ L"2.0 s", 2 },
		{ L"2.5 s", 2.5 },
		{ L"3.0 s", 3 },
	}
end

local function resourceItems()
	return {
		{ T("no_limit"), nil },
		{ L"AP", "AP" },
		{ L"HP", "HP" },
	}
end

local function mechanicModeItems()
	return {
		{ T("no_limit"), nil },
		{ T("mechanic_min"), "MIN" },
		{ T("mechanic_max"), "MAX" },
		{ T("mechanic_equal"), "EQUAL" },
	}
end

local function targetHealthTargetItems()
	return {
		{ T("effect_ability_target"), "ABILITY" },
		{ T("effect_friendly_target"), "FRIENDLY" },
		{ T("effect_hostile_target"), "HOSTILE" },
		{ T("effect_self"), "SELF" },
	}
end

local function targetHealthModeItems()
	return {
		{ T("no_limit"), nil },
		{ T("target_hp_min"), "MIN" },
		{ T("target_hp_max"), "MAX" },
	}
end

local function effectTargetItems()
	return {
		{ T("disabled"), nil },
		{ T("effect_ability_target"), "ABILITY" },
		{ T("effect_hostile_target"), "HOSTILE" },
		{ T("effect_friendly_target"), "FRIENDLY" },
		{ T("effect_self"), "SELF" },
	}
end

local function itemLabelForValue(items, value)
	for _, item in ipairs(items) do
		if item[2] == value then return item[1] end
	end
	return items[1][1]
end

local function itemValueForLabel(items, label)
	for _, item in ipairs(items) do
		if item[1] == label then return item[2] end
	end
	return nil
end

local function abilityName(actionId)
	local data = GetAbilityData(actionId)
	local value = data and data.name or T("ability_selected")
	return towstring(value) .. L"  (ID " .. towstring(actionId) .. L")"
end

local function formatSeconds(value)
	return string.format("%.1f s", tonumber(value) or 0)
end

local function formatPercent(value)
	return string.format("%.0f%%", tonumber(value) or 0)
end

local function placeElement(layer, element, y, height)
	element:ClearAnchors()
	element:Resize(layer.width, height)
	element:AnchorTo(layer, "topleft", "topleft", 0, y)
	return y + height
end

local function addCombo(label, path, items)
	local element = GUI("combobox", label, path)
	local comboWidth = 320
	if element.combo and element.combo.name then
		element.combo.width = comboWidth
		WindowSetDimensions(element.combo.name, comboWidth, element.combo.height)
	end
	for _, item in ipairs(items) do element.combo:Add(item[1]) end
	return element
end

local function ensureGUI()
	local language = GCDsaver_Lang.Code()
	if GUI and BuiltLanguage ~= language then
		GUI:Hide()
		GUI = nil
	end
	if GUI then return end
	BuiltLanguage = language
	GUI = LibConfig(T("editor_title"), Editor, true, nil)

	GUI:AddTab(T("tab_main"))
	local mainLayer = GUI.layers[GUI.currentTab]
	local y = 0
	local selected = GUI("label", T("ability_selected"), "AbilityLabel")
	y = placeElement(mainLayer, selected, y, 56)
	local condition = addCombo(T("condition_standard"), "Condition", conditionItems())
	y = placeElement(mainLayer, condition, y, 64)
	local aa = addCombo(T("aa_sync"), "AASync", aaItems())
	y = placeElement(mainLayer, aa, y, 64)
	local resource = addCombo(T("resource_limit"), "ResourceMode", resourceItems())
	y = placeElement(mainLayer, resource, y, 64)
	local threshold = GUI("stepper", T("resource_threshold"), "ResourceThreshold")
	threshold:SetRange(0, 200, 10)
	placeElement(mainLayer, threshold, y, 82)

	GUI:AddTab(T("tab_refresh"))
	local refreshLayer = GUI.layers[GUI.currentTab]
	y = 0
	local selectedRefresh = GUI("label", T("ability_selected"), "AbilityLabel")
	y = placeElement(refreshLayer, selectedRefresh, y, 56)
	local refreshWindow = GUI("stepper", T("effect_refresh_window"), "EffectRefreshWindow")
	refreshWindow:SetRange(0, 30, 0.5)
	refreshWindow:SetFormatter(formatSeconds)
	y = placeElement(refreshLayer, refreshWindow, y, 82)
	local refreshHelp = GUI("label", T("effect_refresh_help"))
	refreshHelp.label:Resize(refreshLayer.width, 116)
	refreshHelp.label:Font("font_default_text_small")
	refreshHelp.label:Align("left")
	placeElement(refreshLayer, refreshHelp, y, 116)

	GUI:AddTab(T("tab_mechanic"))
	local mechanicLayer = GUI.layers[GUI.currentTab]
	y = 0
	local selectedMechanic = GUI("label", T("ability_selected"), "AbilityLabel")
	y = placeElement(mechanicLayer, selectedMechanic, y, 56)
	local mechanicMode = addCombo(T("mechanic_condition"), "MechanicMode", mechanicModeItems())
	y = placeElement(mechanicLayer, mechanicMode, y, 64)
	local mechanicThreshold = GUI("textbox", T("mechanic_threshold"), "MechanicThreshold")
	y = placeElement(mechanicLayer, mechanicThreshold, y, 64)
	local mechanicHelp = GUI("label", T("mechanic_help"))
	mechanicHelp.label:Resize(mechanicLayer.width, 132)
	mechanicHelp.label:Font("font_default_text_small")
	mechanicHelp.label:Align("left")
	placeElement(mechanicLayer, mechanicHelp, y, 132)

	GUI:AddTab(T("tab_advanced"))
	local advancedLayer = GUI.layers[GUI.currentTab]
	y = 0
	local selectedAdvanced = GUI("label", T("ability_selected"), "AbilityLabel")
	y = placeElement(advancedLayer, selectedAdvanced, y, 56)
	local virtual = GUI("stepper", T("virtual_cd"), "VirtualCooldown")
	virtual:SetRange(0, 300, 0.5)
	virtual:SetFormatter(formatSeconds)
	y = placeElement(advancedLayer, virtual, y, 82)
	local effectTarget = addCombo(T("effect_target"), "EffectTarget", effectTargetItems())
	y = placeElement(advancedLayer, effectTarget, y, 64)
	local effectId = GUI("textbox", T("effect_id"), "EffectId")
	y = placeElement(advancedLayer, effectId, y, 64)
	local onlyMine = GUI("checkbox", T("effect_only_mine"), "EffectOnlyMine")
	y = placeElement(advancedLayer, onlyMine, y, 48)
	local help = GUI("label", T("help"))
	help.label:Resize(advancedLayer.width, 90)
	help.label:Font("font_default_text_small")
	help.label:Align("left")
	placeElement(advancedLayer, help, y, 90)

	GUI:AddTab(T("tab_target_hp"))
	local targetHealthLayer = GUI.layers[GUI.currentTab]
	y = 0
	local selectedTargetHealth = GUI("label", T("ability_selected"), "AbilityLabel")
	y = placeElement(targetHealthLayer, selectedTargetHealth, y, 56)
	local targetHealthTarget = addCombo(T("target_hp_target"), "TargetHealthTarget", targetHealthTargetItems())
	y = placeElement(targetHealthLayer, targetHealthTarget, y, 64)
	local targetHealthMode = addCombo(T("target_hp_condition"), "TargetHealthMode", targetHealthModeItems())
	y = placeElement(targetHealthLayer, targetHealthMode, y, 64)
	local targetHealthThreshold = GUI("stepper", T("target_hp_threshold"), "TargetHealthThreshold")
	targetHealthThreshold:SetRange(0, 100, 5)
	targetHealthThreshold:SetFormatter(formatPercent)
	y = placeElement(targetHealthLayer, targetHealthThreshold, y, 82)
	local targetHealthHelp = GUI("label", T("target_hp_help"))
	targetHealthHelp.label:Resize(targetHealthLayer.width, 90)
	targetHealthHelp.label:Font("font_default_text_small")
	targetHealthHelp.label:Align("left")
	placeElement(targetHealthLayer, targetHealthHelp, y, 90)

	GUI.window.saveButton:SetText(T("save"))
	GUI.window.cancelButton:SetText(T("cancel"))
	GUI.window.revertButton:SetText(T("revert"))
	GUI.window.saveButton.OnLButtonUp = function()
		GUI:Save()
		GCDsaver_AbilityMenu.Apply()
		GUI:Hide()
	end
end

function GCDsaver_AbilityMenu.Invalidate()
	if GUI then GUI:Hide() end
	GUI = nil
	BuiltLanguage = nil
end

function GCDsaver_AbilityMenu.Open(actionId)
	actionId = tonumber(actionId)
	if not actionId or actionId == 0 then return end
	ensureGUI()
	GCDsaver_AbilityMenu.ActionId = actionId

	local configuration = GCDsaver.GetAbilityConfiguration(actionId)
	Editor.AbilityLabel = abilityName(actionId)
	Editor.Condition = itemLabelForValue(conditionItems(), configuration.Condition)
	Editor.EffectRefreshWindow = configuration.EffectRefreshWindow or 0
	Editor.AASync = itemLabelForValue(aaItems(), configuration.AALead)

	local resourceRule = configuration.ResourceRule
	Editor.ResourceMode = itemLabelForValue(resourceItems(), resourceRule and resourceRule.Mode or nil)
	Editor.ResourceThreshold = resourceRule and resourceRule.Threshold or 0

	local mechanicRule = configuration.CareerMechanicRule
	Editor.MechanicMode = itemLabelForValue(mechanicModeItems(), mechanicRule and mechanicRule.Mode or nil)
	Editor.MechanicThreshold = mechanicRule and tostring(mechanicRule.Threshold) or "0"

	local targetHealthRule = configuration.TargetHealthRule
	Editor.TargetHealthTarget = itemLabelForValue(targetHealthTargetItems(), targetHealthRule and targetHealthRule.Target or "ABILITY")
	Editor.TargetHealthMode = itemLabelForValue(targetHealthModeItems(), targetHealthRule and targetHealthRule.Mode or nil)
	Editor.TargetHealthThreshold = targetHealthRule and targetHealthRule.Threshold or 0
	Editor.VirtualCooldown = configuration.VirtualCooldown or 0

	local requirement = configuration.EffectRequirement
	Editor.EffectTarget = itemLabelForValue(effectTargetItems(), requirement and requirement.Target or nil)
	Editor.EffectId = effectIdsText(requirement)
	Editor.EffectOnlyMine = requirement and requirement.OnlyMine == true or false
	GUI:Show()
end

function GCDsaver_AbilityMenu.Apply()
	local actionId = GCDsaver_AbilityMenu.ActionId
	if not actionId then return end

	local resourceMode = itemValueForLabel(resourceItems(), Editor.ResourceMode)
	local resourceRule = nil
	if resourceMode == "AP" or resourceMode == "HP" then
		resourceRule = { Mode = resourceMode, Threshold = tonumber(Editor.ResourceThreshold) or 0 }
	end

	local mechanicMode = itemValueForLabel(mechanicModeItems(), Editor.MechanicMode)
	local mechanicRule = nil
	if mechanicMode == "MIN" or mechanicMode == "MAX" or mechanicMode == "EQUAL" then
		mechanicRule = {
			Mode = mechanicMode,
			Threshold = tonumber(Editor.MechanicThreshold) or 0,
		}
	end
	local targetHealthMode = itemValueForLabel(targetHealthModeItems(), Editor.TargetHealthMode)
	local targetHealthRule = nil
	if targetHealthMode == "MIN" or targetHealthMode == "MAX" then
		targetHealthRule = {
			Target = itemValueForLabel(targetHealthTargetItems(), Editor.TargetHealthTarget) or "ABILITY",
			Mode = targetHealthMode,
			Threshold = tonumber(Editor.TargetHealthThreshold) or 0,
		}
	end

	local effectTarget = itemValueForLabel(effectTargetItems(), Editor.EffectTarget)
	local effectIds = parseEffectIds(Editor.EffectId)
	local effectRequirement = nil
	if effectTarget and #effectIds > 0 then
		effectRequirement = {
			Target = effectTarget,
			EffectIds = effectIds,
			EffectId = effectIds[1],
			OnlyMine = Editor.EffectOnlyMine == true,
		}
	end

	GCDsaver.ConfigureAbility(actionId, {
		Condition = itemValueForLabel(conditionItems(), Editor.Condition),
		EffectRefreshWindow = tonumber(Editor.EffectRefreshWindow),
		AALead = itemValueForLabel(aaItems(), Editor.AASync),
		ResourceRule = resourceRule,
		CareerMechanicRule = mechanicRule,
		TargetHealthRule = targetHealthRule,
		VirtualCooldown = tonumber(Editor.VirtualCooldown),
		EffectRequirement = effectRequirement,
	})
end