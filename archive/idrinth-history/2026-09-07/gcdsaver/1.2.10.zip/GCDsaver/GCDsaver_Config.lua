LibConfig = LibStub("LibConfig")

GCDsaver_Config = GCDsaver_Config or {}

local GUI

local function T(key)
	return GCDsaver_Lang.Get(key)
end

local function placeInfo(layer, element, y, height)
	element:ClearAnchors()
	element:Resize(layer.width, height)
	element:AnchorTo(layer, "topleft", "topleft", 0, y)
	element.label:Resize(layer.width, height)
	element.label:Font("font_default_text_small")
	element.label:Align("left")
	return y + height
end

local function addInfoPage(layer, keys)
	local y = 0
	for _, key in ipairs(keys) do
		local info = GUI("label", T(key))
		y = placeInfo(layer, info, y, 78)
	end
end

function GCDsaver_Config.Slash(input)
	if not GUI then
		GUI = LibConfig("GCDsaver v" .. tostring(GCDsaver.Settings.Version), GCDsaver.Settings, true, GCDsaver_Config.SettingsChanged)

		GUI:AddTab(T("info_tab"))
		local infoLayer = GUI.layers[GUI.currentTab]
		addInfoPage(infoLayer, { "info_1", "info_2", "info_3", "info_4", "info_5" })
		GUI("newpage")
		addInfoPage(infoLayer, { "info_6", "info_7", "info_8", "info_9" })

		GUI:AddTab(T("settings_tab"))
		GUI("checkbox", T("enabled"), "Enabled")
		GUI("checkbox", T("show_symbols"), "Symbols")
		GUI("checkbox", T("show_errors"), "ErrorMessages")
		GUI("checkbox", T("aa_enabled"), "AASyncEnabled")
		GUI("checkbox", T("resource_enabled"), "ResourceLimitsEnabled")
		GUI("checkbox", T("use_spanish"), "UseSpanish")
	end
	GUI:Show()
end

function GCDsaver_Config.SettingsChanged()
	GUI:Hide()
	GCDsaver.UpdateSettings()
	if GCDsaver_AbilityMenu and GCDsaver_AbilityMenu.Invalidate then
		GCDsaver_AbilityMenu.Invalidate()
	end
	GUI = nil
end