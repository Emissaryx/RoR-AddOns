-- Local data
local VERSION = "1.0.10"
local MAX_STACK = 3
local IMMOVABLE = 4
local UNSTOPPABLE = 5
local SELF_1 = 6
local SELF_2 = 7
local SELF_3 = 8
local MAX_BUTTONS = 60
local DEFAULT_IDLE_INTERVAL = 0.20
local DEFAULT_BURST_INTERVAL = 0.05
local DEFAULT_GCD_SLEEP_DURATION = 0.90
local DEFAULT_GCD_BURST_WINDOW = 0.35

local eventsRegistered = false
local loadingEnd = false
local currentTime = 0
local nextCheckAt = 0
local gcdSleepUntil = 0
local gcdBurstUntil = 0

-- Localized functions
local pairs = pairs
local tostring = tostring
local towstring = towstring
local type = type
local pcall = pcall
local GetBuffs = GetBuffs
local GetAbilityData = GetAbilityData
local GetHotbarData = GetHotbarData
local BroadcastEvent = BroadcastEvent
local TextLogAddEntry = TextLogAddEntry
local RegisterEventHandler = RegisterEventHandler
local UnregisterEventHandler = UnregisterEventHandler

local orgWindowGameAction
local orgActionButtonOnLButtonDown
local orgActionBarsUpdateSlotEnabledState
local orgActionButtonUpdateInventory

local function clamp(value, minValue, maxValue)
	if type(value) ~= "number" then return minValue end
	if value < minValue then return minValue end
	if value > maxValue then return maxValue end
	return value
end

local function sanitizeInterval(value, defaultValue)
	if type(value) ~= "number" then return defaultValue end
	return clamp(value, 0.02, 1.00)
end

local function sanitizeWindow(value, defaultValue)
	if type(value) ~= "number" then return defaultValue end
	return clamp(value, 0.00, 2.00)
end

local function sanitizeSleep(value, defaultValue)
	if type(value) ~= "number" then return defaultValue end
	return clamp(value, 0.00, 2.00)
end

local function boolDefault(value, defaultValue)
	if value == nil then return defaultValue end
	return value and true or false
end

local function copyAbilities(source)
	local copy = {}
	if type(source) == "table" then
		for actionId, state in pairs(source) do
			copy[actionId] = state
		end
	end
	return copy
end

local function hasFriendlyTarget()
	local target = TargetInfo.m_Units[TargetInfo.FRIENDLY_TARGET]
	if target and target.entityid ~= 0 then
		return true
	end
	return false
end

local function hasHostileTarget()
	local target = TargetInfo.m_Units[TargetInfo.HOSTILE_TARGET]
	if target and target.entityid ~= 0 then
		return true
	end
	return false
end

local function getTargetType(targetType)
	if targetType == 0 then
		return GameData.BuffTargetType.SELF
	elseif targetType == 1 and hasHostileTarget() then
		return GameData.BuffTargetType.TARGET_HOSTILE
	elseif targetType == 1 then
		return nil
	elseif targetType == 2 and hasFriendlyTarget() then
		return GameData.BuffTargetType.TARGET_FRIENDLY
	elseif targetType == 2 then
		return GameData.BuffTargetType.SELF
	else
		return GameData.BuffTargetType.SELF
	end
end

local function alertText(text)
	if SettingsWindowTabInterface.SavedMessageSettings.combat then
		SystemData.AlertText.VecType = {SystemData.AlertText.Types.COMBAT}
		SystemData.AlertText.VecText = {towstring(text)}
		BroadcastEvent(SystemData.Events.SHOW_ALERT_TEXT)
	end
end

local function chatInfo(actionId, state)
	local abilityData = GetAbilityData(actionId)
	if not abilityData then return end

	local name = tostring(abilityData.name)
	local icon = "<icon" .. tostring(abilityData.iconNum) .. ">"
	if not state then
		TextLogAddEntry("Chat", 0, towstring("GCDsaver: Clearing check for " .. icon .. " " .. name))
	elseif state >= 1 and state <= 3 then
		TextLogAddEntry("Chat", 0, towstring("GCDsaver: Setting (" .. state ..  "x) Stack check for " .. icon .. " " .. name))
	elseif state == IMMOVABLE then
		TextLogAddEntry("Chat", 0, towstring("GCDsaver: Setting <icon05007> Immovable check for " .. icon .. " " .. name))
	elseif state == UNSTOPPABLE then
		TextLogAddEntry("Chat", 0, towstring("GCDsaver: Setting <icon05006> Unstoppable check for " .. icon .. " " .. name))
	elseif state == SELF_1 then
		TextLogAddEntry("Chat", 0, towstring("GCDsaver: Setting (Self 1x) Stack check for " .. icon .. " " .. name))
	elseif state == SELF_2 then
		TextLogAddEntry("Chat", 0, towstring("GCDsaver: Setting (Self 2x) Stack check for " .. icon .. " " .. name))
	elseif state == SELF_3 then
		TextLogAddEntry("Chat", 0, towstring("GCDsaver: Setting (Self 3x) Stack check for " .. icon .. " " .. name))
	end
end

local function createEffectState()
	return {
		Slots = {},
		ByAbility = {},
		ByIcon = {},
		IsPrimed = false,
	}
end

local function clearEffectState(effectState)
	if not effectState then return end
	effectState.Slots = {}
	effectState.ByAbility = {}
	effectState.ByIcon = {}
	effectState.IsPrimed = false
end

local function rebuildEffectAggregates(effectState)
	if not effectState then return end

	local byAbility = {}
	local byIcon = {}
	for _, effect in pairs(effectState.Slots) do
		local abilityId = effect.abilityId
		local iconNum = effect.iconNum
		local stackCount = effect.stackCount or 1

		if abilityId and abilityId ~= 0 then
			byAbility[abilityId] = stackCount
		end
		if iconNum and iconNum ~= 0 then
			byIcon[iconNum] = stackCount
		end
	end

	effectState.ByAbility = byAbility
	effectState.ByIcon = byIcon
	effectState.IsPrimed = true
end

local function primeEffectState(effectState, targetType)
	if not effectState or effectState.IsPrimed or not targetType then
		return
	end

	local buffData = GetBuffs(targetType)
	effectState.Slots = {}
	if buffData then
		for effectId, buff in pairs(buffData) do
			if buff and buff.castByPlayer then
				effectState.Slots[effectId] = {
					abilityId = buff.abilityId,
					iconNum = buff.iconNum,
					stackCount = buff.stackCount or 1,
				}
			end
		end
	end
	rebuildEffectAggregates(effectState)
end

local function applyEffectUpdates(effectState, updatedEffects, isFullList)
	if not effectState or not updatedEffects then
		return false
	end

	local changed = false
	if isFullList then
		effectState.Slots = {}
		changed = true
	end

	for effectId, effectData in pairs(updatedEffects) do
		if effectData and effectData.castByPlayer and (effectData.abilityId or effectData.iconNum) then
			local newAbilityId = effectData.abilityId
			local newIconNum = effectData.iconNum
			local newStackCount = effectData.stackCount or 1
			local existing = effectState.Slots[effectId]

			if not existing
			or existing.abilityId ~= newAbilityId
			or existing.iconNum ~= newIconNum
			or existing.stackCount ~= newStackCount
			then
				effectState.Slots[effectId] = {
					abilityId = newAbilityId,
					iconNum = newIconNum,
					stackCount = newStackCount,
				}
				changed = true
			end
		elseif effectState.Slots[effectId] then
			effectState.Slots[effectId] = nil
			changed = true
		end
	end

	if changed then
		rebuildEffectAggregates(effectState)
	else
		effectState.IsPrimed = true
	end

	return changed
end

local function tryGetWindowGameActionData(windowName)
	if type(WindowGetGameActionData) ~= "function" then
		return nil
	end

	local ok, a, b, c, d = pcall(WindowGetGameActionData, windowName)
	if not ok then
		return nil
	end

	if type(a) == "table" then
		return a
	end

	return { a, b, c, d }
end

local function resolveActionIdFromWindow(windowName)
	if not windowName then
		return nil
	end

	local data = tryGetWindowGameActionData(windowName)
	if not data then
		return nil
	end

	if data.actionId then return data.actionId end
	if data.ActionId then return data.ActionId end
	if data.abilityId then return data.abilityId end
	if data.AbilityId then return data.AbilityId end
	if data.id then return data.id end
	if data.Id then return data.Id end

	local slot = data.hotbarSlot or data.HotbarSlot or data.slot or data.Slot or data[1]
	local maybeActionId = data[2]
	if type(maybeActionId) == "number" and maybeActionId ~= 0 then
		return maybeActionId
	end
	if type(slot) == "number" and slot >= 1 and slot <= MAX_BUTTONS then
		local _, actionId = GetHotbarData(slot)
		if type(actionId) == "number" and actionId ~= 0 then
			return actionId
		end
	end

	return nil
end

GCDsaver = GCDsaver or {}
GCDsaver.FriendlyTargetId = 0
GCDsaver.HostileTargetId = 0
GCDsaver.TargetImmovable = false
GCDsaver.TargetUnstoppable = false
GCDsaver.SelfTargetEffects = createEffectState()
GCDsaver.FriendlyTargetEffects = createEffectState()
GCDsaver.HostileTargetEffects = createEffectState()
GCDsaver.EnabledStatesNeedUpdate = true
GCDsaver.ButtonIconsNeedUpdate = true
GCDsaver.FullRefreshNeeded = true
GCDsaver.WatchedSlots = {}
GCDsaver.LastSlotStates = {}
GCDsaver.AbilityMetaCache = {}

GCDsaver.DefaultSettings = {
	Version = VERSION,
	Enabled = true,
	Symbols = true,
	ErrorMessages = true,
	UseSmartGCD = true,
	IdleInterval = DEFAULT_IDLE_INTERVAL,
	BurstInterval = DEFAULT_BURST_INTERVAL,
	GCDSleepDuration = DEFAULT_GCD_SLEEP_DURATION,
	GCDBurstWindow = DEFAULT_GCD_BURST_WINDOW,
	Abilities = {
		-- Ironbreaker
		[1384] = UNSTOPPABLE,	-- Cave-In
		[1369] = UNSTOPPABLE,	-- Shield of Reprisal
		[1365] = IMMOVABLE,		-- Away With Ye
		-- Slayer
		[1443] = UNSTOPPABLE,	-- Incapacitate
		-- Runepriest
		[1613] = UNSTOPPABLE,	-- Rune of Binding
		[1607] = UNSTOPPABLE,	-- Spellbinding Rune
		-- Engineer
		[1536] = UNSTOPPABLE,	-- Crack Shot
		[1531] = IMMOVABLE,		-- Concussion Grenade
		-- Black Orc
		[1688] = UNSTOPPABLE,	-- Down Ya Go
		[1683] = UNSTOPPABLE,	-- Shut Yer Face
		[1686] = IMMOVABLE,	-- Git Out
		-- Choppa
		[1755] = UNSTOPPABLE,	-- Sit Down!
		-- Shaman
		[1929] = IMMOVABLE,		-- Geddoff!
		[1917] = UNSTOPPABLE,	-- You Got Nuthin!
		-- Squig Herder
		[1839] = UNSTOPPABLE,	-- Choking Arrer
		[1837] = UNSTOPPABLE,	-- Drop That!!
		--[1835] = UNSTOPPABLE,	-- Not So Fast!
		-- Witch Hunter
		[8110] = UNSTOPPABLE,	-- Dragon Gun
		[8086] = UNSTOPPABLE,	-- Confess!
		[8115] = UNSTOPPABLE,	-- Pistol Whip
		[8100] = UNSTOPPABLE,	-- Silence The Heretic
		--[8094] = UNSTOPPABLE,	-- Declare Anathema
		-- Knight of the Blazing Sun
		[8018] = UNSTOPPABLE,	-- Smashing Counter
		[8017] = IMMOVABLE,		-- Repel Darkness
		-- Bright Wizard
		[8186] = UNSTOPPABLE,	-- Stop, Drop, and Roll
		[8174] = UNSTOPPABLE,	-- Choking Smoke
		-- Warrior Priest
		[8256] = UNSTOPPABLE,	-- Vow of Silence
		-- Chosen
		[8346] = UNSTOPPABLE,	-- Downfall
		[8329] = IMMOVABLE,		-- Repel
		-- Marauder
		[8412] = UNSTOPPABLE,	-- Mutated Energy
		[8405] = UNSTOPPABLE,	-- Death Grip
		[8410] = IMMOVABLE,		-- Terrible Embrace
		-- Zealot
		[8571] = UNSTOPPABLE,	-- Aethyric Shock
		[8565] = UNSTOPPABLE,	-- Tzeentch's Lash
		-- Magus
		[8495] = UNSTOPPABLE,	-- Perils of The Warp
		[8483] = IMMOVABLE,		-- Warping Blast
		-- Swordmaster
		--[9032] = IMMOVABLE,		-- Redirected Force
		[9024] = IMMOVABLE,		-- Mighty Gale
		[9028] = UNSTOPPABLE,	-- Chrashing Wave
		-- Shadow Warrior
		--[9096] = UNSTOPPABLE,	-- Eye Shot
		[9108] = UNSTOPPABLE,	-- Exploit Weakness
		[9098] = UNSTOPPABLE,	-- Opportunistic Strike
		-- White Lion
		[9193] = UNSTOPPABLE,	-- Brutal Pounce
		[9177] = UNSTOPPABLE,	-- Throat Bite
		[9178] = IMMOVABLE,		-- Fetch!
		-- Archmage
		[9266] = IMMOVABLE,		-- Cleansing Flare
		[9253] = UNSTOPPABLE,	-- Law of Gold
		-- Blackguard
		[2888] = UNSTOPPABLE,	-- Malignant Strike!
		[9321] = UNSTOPPABLE,	-- Spiteful Slam
		[9328] = IMMOVABLE,		-- Exile
		-- Witch Elf
		[9422] = UNSTOPPABLE,	-- On Your Knees!
		[9400] = UNSTOPPABLE,	-- Sever Limb
		[9427] = UNSTOPPABLE,	-- Heart Seeker
		[9409] = UNSTOPPABLE,	-- Throat Slitter
		--[9396] = UNSTOPPABLE,	-- Agile Escape
		-- Disciple of Khaine
		[9565] = UNSTOPPABLE,	-- Consume Thought
		-- Sorcerer
		[9482] = UNSTOPPABLE,	-- Frostbite
		[9489] = UNSTOPPABLE,	-- Stricken Voices
	},
}

local function getAbilityMeta(actionId)
	if actionId == nil or actionId == 0 then
		return nil
	end

	local cached = GCDsaver.AbilityMetaCache[actionId]
	if cached == nil then
		cached = GetAbilityData(actionId) or false
		GCDsaver.AbilityMetaCache[actionId] = cached
	end

	if cached == false then
		return nil
	end

	return cached
end

local function getEffectStateForTarget(targetType)
	if targetType == GameData.BuffTargetType.SELF then
		return GCDsaver.SelfTargetEffects
	elseif targetType == GameData.BuffTargetType.TARGET_HOSTILE then
		return GCDsaver.HostileTargetEffects
	elseif targetType == GameData.BuffTargetType.TARGET_FRIENDLY then
		return GCDsaver.FriendlyTargetEffects
	end
	return nil
end

local function hasBuff(targetType, actionId, abilityData, stackCount)
	if not targetType or not abilityData then
		return false
	end

	local effectState = getEffectStateForTarget(targetType)
	if not effectState then
		return false
	end

	primeEffectState(effectState, targetType)

	local abilityStack = effectState.ByAbility[actionId]
	if abilityStack and abilityStack == stackCount then
		return true
	end

	local iconStack = effectState.ByIcon[abilityData.iconNum]
	if iconStack and iconStack == stackCount then
		return true
	end

	return false
end

local function hasSelfBuff(actionId, abilityData, stackCount)
	return hasBuff(GameData.BuffTargetType.SELF, actionId, abilityData, stackCount)
end

local function evaluateAbilityBlock(actionId, showError)
	if not GCDsaver.Settings or not GCDsaver.Settings.Enabled then
		return false, nil
	end

	local check = GCDsaver.Settings.Abilities and GCDsaver.Settings.Abilities[actionId]
	if not check then
		return false, nil
	end

	if check == IMMOVABLE then
		if GCDsaver.TargetImmovable then
			if showError and GCDsaver.Settings.ErrorMessages then alertText("Target is Immovable") end
			return true, "immovable"
		end
		return false, nil
	elseif check == UNSTOPPABLE then
		if GCDsaver.TargetUnstoppable then
			if showError and GCDsaver.Settings.ErrorMessages then alertText("Target is Unstoppable") end
			return true, "unstoppable"
		end
		return false, nil
	end

	local abilityData = getAbilityMeta(actionId)
	if not abilityData then
		return false, nil
	end

	if check >= 1 and check <= 3 then
		if hasBuff(getTargetType(abilityData.targetType), actionId, abilityData, check) then
			if showError and GCDsaver.Settings.ErrorMessages then alertText("Target already has that effect") end
			return true, "targetstack" .. tostring(check)
		end
	elseif check >= SELF_1 and check <= SELF_3 then
		if hasSelfBuff(actionId, abilityData, check - 5) then
			if showError and GCDsaver.Settings.ErrorMessages then alertText("You already have that effect") end
			return true, "selfstack" .. tostring(check - 5)
		end
	end

	return false, nil
end

local function isAbilityBlocked(actionId, showError)
	local blocked = evaluateAbilityBlock(actionId, showError)
	return blocked
end

local function hasProgrammingModifier(flags)
	if flags == nil then return false end
	if flags == SystemData.ButtonFlags.SHIFT then return true end
	if type(BitAnd) == "function" then
		return BitAnd(flags, SystemData.ButtonFlags.SHIFT) ~= 0
	end
	return false
end

function GCDsaver.NormalizeSettings()
	if type(GCDsaver.Settings) ~= "table" then
		GCDsaver.Settings = {}
	end

	GCDsaver.Settings.Version = GCDsaver.DefaultSettings.Version
	GCDsaver.Settings.Enabled = boolDefault(GCDsaver.Settings.Enabled, GCDsaver.DefaultSettings.Enabled)
	GCDsaver.Settings.Symbols = boolDefault(GCDsaver.Settings.Symbols, GCDsaver.DefaultSettings.Symbols)
	GCDsaver.Settings.ErrorMessages = boolDefault(GCDsaver.Settings.ErrorMessages, GCDsaver.DefaultSettings.ErrorMessages)
	GCDsaver.Settings.UseSmartGCD = boolDefault(GCDsaver.Settings.UseSmartGCD, GCDsaver.DefaultSettings.UseSmartGCD)
	GCDsaver.Settings.IdleInterval = sanitizeInterval(GCDsaver.Settings.IdleInterval, GCDsaver.DefaultSettings.IdleInterval)
	GCDsaver.Settings.BurstInterval = sanitizeInterval(GCDsaver.Settings.BurstInterval, GCDsaver.DefaultSettings.BurstInterval)
	GCDsaver.Settings.GCDSleepDuration = sanitizeSleep(GCDsaver.Settings.GCDSleepDuration, GCDsaver.DefaultSettings.GCDSleepDuration)
	GCDsaver.Settings.GCDBurstWindow = sanitizeWindow(GCDsaver.Settings.GCDBurstWindow, GCDsaver.DefaultSettings.GCDBurstWindow)

	if type(GCDsaver.Settings.Abilities) ~= "table" then
		GCDsaver.Settings.Abilities = copyAbilities(GCDsaver.DefaultSettings.Abilities)
	end
end

function GCDsaver.ScheduleNextCheck(forceImmediate)
	if forceImmediate then
		nextCheckAt = currentTime
		return
	end

	if GCDsaver.Settings.UseSmartGCD and currentTime < gcdSleepUntil then
		nextCheckAt = gcdSleepUntil
		return
	end

	local interval = GCDsaver.Settings.IdleInterval
	if GCDsaver.Settings.UseSmartGCD and currentTime < gcdBurstUntil then
		interval = GCDsaver.Settings.BurstInterval
	end

	nextCheckAt = currentTime + interval
end

function GCDsaver.MarkDirty(forceImmediate, fullRefresh)
	GCDsaver.EnabledStatesNeedUpdate = true
	if fullRefresh then
		GCDsaver.FullRefreshNeeded = true
		GCDsaver.LastSlotStates = {}
	end
	GCDsaver.ScheduleNextCheck(forceImmediate)
end

function GCDsaver.MarkIconsDirty()
	GCDsaver.ButtonIconsNeedUpdate = true
end

function GCDsaver.RebuildWatchedSlots()
	local watched = {}
	for slot = 1, MAX_BUTTONS do
		local _, actionId = GetHotbarData(slot)
		if GCDsaver.Settings.Enabled and GCDsaver.Settings.Abilities[actionId] then
			watched[slot] = true
		end
	end
	GCDsaver.WatchedSlots = watched
end

function GCDsaver.NotifyPossibleGlobalCooldown(actionId)
	if not GCDsaver.Settings.Enabled then return end
	if not GCDsaver.Settings.UseSmartGCD then return end
	if not actionId or actionId == 0 then return end

	gcdSleepUntil = currentTime + GCDsaver.Settings.GCDSleepDuration
	gcdBurstUntil = gcdSleepUntil + GCDsaver.Settings.GCDBurstWindow
	if gcdBurstUntil < gcdSleepUntil then
		gcdBurstUntil = gcdSleepUntil
	end
	GCDsaver.ScheduleNextCheck(false)
end

function GCDsaver.BuildSlotStateSignature(actionId, isSlotEnabled, isTargetValid, isSlotBlocked, configuredCheck, blockedReason)
	return tostring(actionId) .. "|" .. tostring(isSlotEnabled) .. "|" .. tostring(isTargetValid) .. "|" .. tostring(isSlotBlocked) .. "|" .. tostring(configuredCheck or "") .. "|" .. tostring(blockedReason or "")
end

function GCDsaver.Initialize()
	GCDsaver.NormalizeSettings()
	GCDsaver.RebuildWatchedSlots()
	GCDsaver.MarkIconsDirty()
	GCDsaver.MarkDirty(true, true)

	LibSlash.RegisterSlashCmd("gcdsaver", function(input) GCDsaver_Config.Slash(input) end)

	if GCDsaver.Settings.Enabled then GCDsaver.RegisterEvents() end

	TextLogAddEntry("Chat", 0, towstring("<icon57> GCDsaver v" .. tostring(GCDsaver.Settings.Version) .. " loaded. Type /gcdsaver for settings."))
	TextLogAddEntry("Chat", 0, towstring("Credits: Talladego, SWF, Kpihuss"))
end

function GCDsaver.OnShutdown()
	GCDsaver.UnregisterEvents()
end

function GCDsaver.RegisterEvents()
	if not eventsRegistered then
		RegisterEventHandler(SystemData.Events.ENTER_WORLD, "GCDsaver.ENTER_WORLD")
		RegisterEventHandler(SystemData.Events.PLAYER_ZONE_CHANGED, "GCDsaver.PLAYER_ZONE_CHANGED")
		RegisterEventHandler(SystemData.Events.INTERFACE_RELOADED, "GCDsaver.INTERFACE_RELOADED")
		RegisterEventHandler(SystemData.Events.PLAYER_TARGET_UPDATED, "GCDsaver.PLAYER_TARGET_UPDATED")
		RegisterEventHandler(SystemData.Events.PLAYER_TARGET_IS_IMMUNE_TO_MOVEMENT_IMPARING, "GCDsaver.PLAYER_TARGET_IS_IMMUNE_TO_MOVEMENT_IMPARING")
		RegisterEventHandler(SystemData.Events.PLAYER_TARGET_IS_IMMUNE_TO_DISABLES, "GCDsaver.PLAYER_TARGET_IS_IMMUNE_TO_DISABLES")
		RegisterEventHandler(SystemData.Events.PLAYER_EFFECTS_UPDATED, "GCDsaver.PLAYER_EFFECTS_UPDATED")
		RegisterEventHandler(SystemData.Events.PLAYER_TARGET_EFFECTS_UPDATED, "GCDsaver.PLAYER_TARGET_EFFECTS_UPDATED")
		RegisterEventHandler(SystemData.Events.PLAYER_HOT_BAR_UPDATED, "GCDsaver.PLAYER_HOT_BAR_UPDATED")
	end
	eventsRegistered = true
end

function GCDsaver.UnregisterEvents()
	if eventsRegistered then
		UnregisterEventHandler(SystemData.Events.ENTER_WORLD, "GCDsaver.ENTER_WORLD")
		UnregisterEventHandler(SystemData.Events.PLAYER_ZONE_CHANGED, "GCDsaver.PLAYER_ZONE_CHANGED")
		UnregisterEventHandler(SystemData.Events.INTERFACE_RELOADED, "GCDsaver.INTERFACE_RELOADED")
		UnregisterEventHandler(SystemData.Events.PLAYER_TARGET_UPDATED, "GCDsaver.PLAYER_TARGET_UPDATED")
		UnregisterEventHandler(SystemData.Events.PLAYER_TARGET_IS_IMMUNE_TO_MOVEMENT_IMPARING, "GCDsaver.PLAYER_TARGET_IS_IMMUNE_TO_MOVEMENT_IMPARING")
		UnregisterEventHandler(SystemData.Events.PLAYER_TARGET_IS_IMMUNE_TO_DISABLES, "GCDsaver.PLAYER_TARGET_IS_IMMUNE_TO_DISABLES")
		UnregisterEventHandler(SystemData.Events.PLAYER_EFFECTS_UPDATED, "GCDsaver.PLAYER_EFFECTS_UPDATED")
		UnregisterEventHandler(SystemData.Events.PLAYER_TARGET_EFFECTS_UPDATED, "GCDsaver.PLAYER_TARGET_EFFECTS_UPDATED")
		UnregisterEventHandler(SystemData.Events.PLAYER_HOT_BAR_UPDATED, "GCDsaver.PLAYER_HOT_BAR_UPDATED")
	end
	eventsRegistered = false
end

function GCDsaver.ENTER_WORLD()
	loadingEnd = true
	GCDsaver.FriendlyTargetId = 0
	GCDsaver.HostileTargetId = 0
	GCDsaver.TargetImmovable = false
	GCDsaver.TargetUnstoppable = false
	clearEffectState(GCDsaver.SelfTargetEffects)
	clearEffectState(GCDsaver.FriendlyTargetEffects)
	clearEffectState(GCDsaver.HostileTargetEffects)
	GCDsaver.RebuildWatchedSlots()
	GCDsaver.MarkIconsDirty()
	GCDsaver.MarkDirty(true, true)
end

function GCDsaver.PLAYER_ZONE_CHANGED()
	loadingEnd = true
	GCDsaver.FriendlyTargetId = 0
	GCDsaver.HostileTargetId = 0
	GCDsaver.TargetImmovable = false
	GCDsaver.TargetUnstoppable = false
	clearEffectState(GCDsaver.SelfTargetEffects)
	clearEffectState(GCDsaver.FriendlyTargetEffects)
	clearEffectState(GCDsaver.HostileTargetEffects)
	GCDsaver.RebuildWatchedSlots()
	GCDsaver.MarkIconsDirty()
	GCDsaver.MarkDirty(true, true)
end

function GCDsaver.INTERFACE_RELOADED()
	loadingEnd = true
	GCDsaver.RebuildWatchedSlots()
	GCDsaver.MarkIconsDirty()
	GCDsaver.MarkDirty(true, true)
end

function GCDsaver.PLAYER_TARGET_UPDATED(targetClassification, targetId, targetType)
	if targetClassification == TargetInfo.FRIENDLY_TARGET and GCDsaver.FriendlyTargetId ~= targetId then
		GCDsaver.FriendlyTargetId = targetId
		clearEffectState(GCDsaver.FriendlyTargetEffects)
		GCDsaver.TargetImmovable = false
		GCDsaver.TargetUnstoppable = false
		GCDsaver.MarkDirty(true, false)
	elseif targetClassification == TargetInfo.HOSTILE_TARGET and GCDsaver.HostileTargetId ~= targetId then
		GCDsaver.HostileTargetId = targetId
		clearEffectState(GCDsaver.HostileTargetEffects)
		GCDsaver.TargetImmovable = false
		GCDsaver.TargetUnstoppable = false
		GCDsaver.MarkDirty(true, false)
	end
end

function GCDsaver.PLAYER_TARGET_IS_IMMUNE_TO_DISABLES(state)
	state = state and true or false
	if GCDsaver.TargetUnstoppable ~= state then
		GCDsaver.TargetUnstoppable = state
		GCDsaver.MarkDirty(true, false)
	end
end

function GCDsaver.PLAYER_TARGET_IS_IMMUNE_TO_MOVEMENT_IMPARING(state)
	state = state and true or false
	if GCDsaver.TargetImmovable ~= state then
		GCDsaver.TargetImmovable = state
		GCDsaver.MarkDirty(true, false)
	end
end

function GCDsaver.PLAYER_EFFECTS_UPDATED(updatedEffects, isFullList)
	if applyEffectUpdates(GCDsaver.SelfTargetEffects, updatedEffects, isFullList) then
		GCDsaver.MarkDirty(true, false)
	end
end

function GCDsaver.PLAYER_TARGET_EFFECTS_UPDATED(updateType, updatedEffects, isFullList)
	local effectState = nil
	if updateType == GameData.BuffTargetType.TARGET_HOSTILE then
		effectState = GCDsaver.HostileTargetEffects
	elseif updateType == GameData.BuffTargetType.TARGET_FRIENDLY then
		effectState = GCDsaver.FriendlyTargetEffects
	end

	if effectState and applyEffectUpdates(effectState, updatedEffects, isFullList) then
		GCDsaver.MarkDirty(true, false)
	end
end

function GCDsaver.PLAYER_HOT_BAR_UPDATED(slot, actionType, actionId)
	GCDsaver.RebuildWatchedSlots()
	GCDsaver.MarkIconsDirty()
	GCDsaver.MarkDirty(true, true)
end

function GCDsaver.OnUpdate(elapsed)
	currentTime = currentTime + elapsed

	if not loadingEnd then return end

	if GCDsaver.ButtonIconsNeedUpdate then
		GCDsaver.UpdateButtonIcons()
		GCDsaver.ButtonIconsNeedUpdate = false
	end

	if not GCDsaver.Settings.Enabled then
		return
	end

	if currentTime < nextCheckAt then
		return
	end

	if GCDsaver.FullRefreshNeeded then
		GCDsaver.UpdateButtonsEnabledStates(true)
		GCDsaver.FullRefreshNeeded = false
		GCDsaver.EnabledStatesNeedUpdate = false
		GCDsaver.ScheduleNextCheck(false)
		return
	end

	GCDsaver.UpdateButtonsEnabledStates(false)
	GCDsaver.EnabledStatesNeedUpdate = false
	GCDsaver.ScheduleNextCheck(false)
end

function GCDsaver.UpdateSettings()
	GCDsaver.NormalizeSettings()

	if GCDsaver.Settings.Enabled and not eventsRegistered then
		GCDsaver.RegisterEvents()
	elseif not GCDsaver.Settings.Enabled and eventsRegistered then
		GCDsaver.UnregisterEvents()
	end

	GCDsaver.RebuildWatchedSlots()
	GCDsaver.MarkIconsDirty()
	GCDsaver.MarkDirty(true, true)
	GCDsaver.UpdateButtonIcons()
	GCDsaver.UpdateButtonsEnabledStates(true)

	TextLogAddEntry("Chat", 0, towstring("GCDsaver v" .. tostring(GCDsaver.Settings.Version) .. " settings: /gcdsaver"))
	if GCDsaver.Settings.Enabled then
		TextLogAddEntry("Chat", 0, L"--- <icon57> Enabled")
	else
		TextLogAddEntry("Chat", 0, L"--- <icon58> Enabled")
	end
	if GCDsaver.Settings.Symbols then
		TextLogAddEntry("Chat", 0, L"--- <icon57> Show Symbols")
	else
		TextLogAddEntry("Chat", 0, L"--- <icon58> Show Symbols")
	end
	if GCDsaver.Settings.ErrorMessages then
		TextLogAddEntry("Chat", 0, L"--- <icon57> Show Combat Error Messages")
	else
		TextLogAddEntry("Chat", 0, L"--- <icon58> Show Combat Error Messages")
	end
	if GCDsaver.Settings.UseSmartGCD then
		TextLogAddEntry("Chat", 0, L"--- <icon57> Smart GCD Optimization")
	else
		TextLogAddEntry("Chat", 0, L"--- <icon58> Smart GCD Optimization")
	end
end

function GCDsaver.UpdateButtonIcons()
	for slot = 1, MAX_BUTTONS do
		local _, actionId = GetHotbarData(slot)
		if GCDsaver.Settings.Enabled and GCDsaver.Settings.Symbols then
			GCDsaver.UpdateButtonIcon(slot, GCDsaver.Settings.Abilities[actionId])
		else
			GCDsaver.UpdateButtonIcon(slot, 0)
		end
	end
end

function GCDsaver.UpdateButtonIcon(slot, check)
	local hbar, buttonid = ActionBars:BarAndButtonIdFromSlot(slot)
	if not hbar or not buttonid then
		return
	end

	local button = hbar.m_Buttons[buttonid]
	if not button or not button.m_Windows or not button.m_Windows[7] then
		return
	end

	if not check or check == 0 then
		button.m_Windows[7]:Show(false)
	elseif check == IMMOVABLE then
		button.m_Windows[7]:Show(true)
		button.m_Windows[7]:SetFont("font_default_war_heading", WindowUtils.FONT_DEFAULT_TEXT_LINESPACING)
		button.m_Windows[7]:SetTextColor(255, 255, 255)
		button.m_Windows[7]:SetText("<icon05007>")
	elseif check == UNSTOPPABLE then
		button.m_Windows[7]:Show(true)
		button.m_Windows[7]:SetFont("font_default_war_heading", WindowUtils.FONT_DEFAULT_TEXT_LINESPACING)
		button.m_Windows[7]:SetTextColor(255, 255, 255)
		button.m_Windows[7]:SetText("<icon05006>")
	elseif check >= 1 and check <= 3 then
		button.m_Windows[7]:Show(true)
		button.m_Windows[7]:SetFont("font_default_war_heading", WindowUtils.FONT_DEFAULT_TEXT_LINESPACING)
		button.m_Windows[7]:SetTextColor(255, 255, 0)
		button.m_Windows[7]:SetText(tostring(check) .. "x")
	elseif check >= SELF_1 and check <= SELF_3 then
		button.m_Windows[7]:Show(true)
		button.m_Windows[7]:SetFont("font_default_war_heading", WindowUtils.FONT_DEFAULT_TEXT_LINESPACING)
		button.m_Windows[7]:SetTextColor(0, 255, 255)
		button.m_Windows[7]:SetText("S" .. tostring(check - 5))
	else
		button.m_Windows[7]:Show(false)
	end
end

function GCDsaver.UpdateButtonsEnabledStates(forceAll)
	if forceAll then
		for slot = 1, MAX_BUTTONS do
			GCDsaver.UpdateButtonEnabledState(slot, true)
		end
		return
	end

	for slot, _ in pairs(GCDsaver.WatchedSlots) do
		GCDsaver.UpdateButtonEnabledState(slot, false)
	end
end

function GCDsaver.UpdateButtonEnabledState(slot, force)
	local actionType, actionId, isSlotEnabled, isTargetValid, isSlotBlocked = GetHotbarData(slot)
	local configuredCheck = GCDsaver.Settings.Abilities[actionId]
	local blocked = false
	local blockedReason = nil

	if GCDsaver.Settings.Enabled and configuredCheck then
		blocked, blockedReason = evaluateAbilityBlock(actionId, false)
		if blocked then
			isSlotEnabled = false
		end
	elseif not force then
		return
	end

	local signature = GCDsaver.BuildSlotStateSignature(actionId, isSlotEnabled, isTargetValid, isSlotBlocked, configuredCheck, blockedReason)
	if not force and GCDsaver.LastSlotStates[slot] == signature then
		return
	end

	GCDsaver.LastSlotStates[slot] = signature
	orgActionBarsUpdateSlotEnabledState(slot, isSlotEnabled, isTargetValid, isSlotBlocked)
end

orgWindowGameAction = WindowGameAction
orgActionButtonOnLButtonDown = ActionButton.OnLButtonDown
orgActionBarsUpdateSlotEnabledState = ActionBars.UpdateSlotEnabledState
orgActionButtonUpdateInventory = ActionButton.UpdateInventory

function ActionButton.OnLButtonDown(self, flags, x, y)
	if self and self.m_ActionId ~= 0 and hasProgrammingModifier(flags) then
		if not GCDsaver.Settings.Abilities[self.m_ActionId] then
			GCDsaver.Settings.Abilities[self.m_ActionId] = 1
		elseif GCDsaver.Settings.Abilities[self.m_ActionId] < SELF_3 then
			GCDsaver.Settings.Abilities[self.m_ActionId] = GCDsaver.Settings.Abilities[self.m_ActionId] + 1
		else
			GCDsaver.Settings.Abilities[self.m_ActionId] = nil
		end

		GCDsaver.RebuildWatchedSlots()
		GCDsaver.MarkIconsDirty()
		GCDsaver.MarkDirty(true, true)
		chatInfo(self.m_ActionId, GCDsaver.Settings.Abilities[self.m_ActionId])
		return
	end

	if self and self.m_ActionId ~= 0 and GCDsaver.Settings.Abilities[self.m_ActionId] and isAbilityBlocked(self.m_ActionId, true) then
		return
	end

	return orgActionButtonOnLButtonDown(self, flags, x, y)
end

function WindowGameAction(windowName, ...)
	local actionId = resolveActionIdFromWindow(windowName)
	local abilityMeta = getAbilityMeta(actionId)

	-- Only intercept real ability actions.
	-- This avoids touching macros/slash actions such as /assist,
	-- which can share the same WindowGameAction entry point.
	if not abilityMeta then
		return orgWindowGameAction(windowName, ...)
	end

	if GCDsaver.Settings and GCDsaver.Settings.Abilities[actionId] and isAbilityBlocked(actionId, true) then
		return
	end

	GCDsaver.NotifyPossibleGlobalCooldown(actionId)
	return orgWindowGameAction(windowName, ...)
end

function ActionBars.UpdateSlotEnabledState(slot, isSlotEnabled, isTargetValid, isSlotBlocked)
	if GCDsaver.Settings and GCDsaver.Settings.Enabled then
		local hbar, buttonid = ActionBars:BarAndButtonIdFromSlot(slot)
		if hbar and buttonid then
			local button = hbar.m_Buttons[buttonid]
			if button and button.m_ActionId and GCDsaver.Settings.Abilities[button.m_ActionId] then
				if evaluateAbilityBlock(button.m_ActionId, false) then
					isSlotEnabled = false
				end
			end
		end
	end
	orgActionBarsUpdateSlotEnabledState(slot, isSlotEnabled, isTargetValid, isSlotBlocked)
end

function ActionButton.UpdateInventory(self)
	if not GCDsaver.Settings or not GCDsaver.Settings.Enabled or not GCDsaver.Settings.Abilities[self.m_ActionId] then
		orgActionButtonUpdateInventory(self)
	end
end
