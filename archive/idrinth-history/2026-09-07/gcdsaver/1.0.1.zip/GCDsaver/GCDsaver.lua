local VERSION = 1.01
local TIME_DELAY = 0.5
local timeLeft = TIME_DELAY
local MAX_STACK = 3
local IMMOVABLE = 4
local UNSTOPPABLE = 5
local pairs = pairs

local function fixString (str)
	if (str == nil) then return nil end
	local str = str
	local pos = str:find (L"^", 1, true)
	if (pos) then str = str:sub (1, pos - 1) end
	return str
end

local function hasFriendlyTarget()
	TargetInfo:UpdateFromClient()
	local target = TargetInfo.m_Units[TargetInfo.FRIENDLY_TARGET]
	if target and target.entityid ~= 0 then
		return true
	end
	return false
end

local function hasBuffName(target, name, stackCount)
	TargetInfo:UpdateFromClient()
	local buffData = GetBuffs(target)
    if (buffData == nil)
    then
        return false
    end

	for _, b in pairs( buffData )
    do
		if fixString(b.name) == fixString(towstring(name)) and b.castByPlayer and b.stackCount == stackCount then
			return true
        end
    end
    return false
end

local function getTargetType(targetType)
	if targetType == 0 then
		return GameData.BuffTargetType.SELF
	elseif targetType == 1 then
		return GameData.BuffTargetType.TARGET_HOSTILE
	elseif targetType == 2 and hasFriendlyTarget() then
		return GameData.BuffTargetType.TARGET_FRIENDLY
	elseif targetType == 2 then
		return GameData.BuffTargetType.SELF
	else
		return GameData.BuffTargetType.SELF
	end
end

local function abilityUsable(id)
	local actionType, actionId, isSlotEnabled, isTargetValid, isSlotBlocked
	for i = 1, 60 do
		actionType, actionId, isSlotEnabled, isTargetValid, isSlotBlocked = GetHotbarData(i)
		if id == actionId
		and GetHotbarCooldown(i) == 0
		and isSlotEnabled
		and isTargetValid
		then
			return true
		end
	end
	return false
end

local function alertText(text)
	if SettingsWindowTabInterface.SavedMessageSettings.combat then
		SystemData.AlertText.VecType = {SystemData.AlertText.Types.COMBAT}
		SystemData.AlertText.VecText = {towstring(text)}
		BroadcastEvent(SystemData.Events.SHOW_ALERT_TEXT)
	end
end

local function chatInfo(actionId, state)
	if not state then
		TextLogAddEntry("Chat", 0, towstring("GCDsaver: Clearing check for " .. tostring(GetAbilityData(actionId).name)))
	elseif state >= 1 and state <= 3 then
		TextLogAddEntry("Chat", 0, towstring("GCDsaver: Setting Stack (" .. state ..  ") check for " .. tostring(GetAbilityData(actionId).name)))
	elseif state == IMMOVABLE then
		TextLogAddEntry("Chat", 0, towstring("GCDsaver: Setting Immovable check for " .. tostring(GetAbilityData(actionId).name)))
	elseif state == UNSTOPPABLE then
		TextLogAddEntry("Chat", 0, towstring("GCDsaver: Setting Unstoppable check for " .. tostring(GetAbilityData(actionId).name)))
	end
end

GCDsaver = GCDsaver or {}
GCDsaver.TargetID = 0
GCDsaver.TargetImmovable = false
GCDsaver.TargetUnstoppable = false

GCDsaver.DefaultSettings = {
	Abilities = {
		-- Ironbreaker
		[1384] = UNSTOPPABLE,	-- Cave-In
		[1369] = UNSTOPPABLE,	-- Shield of Reprisal
		[1365] = IMMOVABLE,		-- Away With Ye
		-- Slayer
		[1443] = UNSTOPPABLE,	-- Incapacitate
		-- Runepriest
		[1613] = UNSTOPPABLE,	-- Rune of Binding
		[1607] = UNSTOPPABLE,	-- Spellbinding Rune
		-- Engineer
		[1536] = UNSTOPPABLE,	-- Crack Shot
		[1531] = IMMOVABLE,		-- Concussion Grenade
		-- Black Orc
		[1688] = UNSTOPPABLE,	-- Down Ya Go
		[1683] = UNSTOPPABLE,	-- Shut Yer Face
		-- Choppa
		[1755] = UNSTOPPABLE,	-- Sit Down!
		-- Shaman
		[1929] = IMMOVABLE,		-- Geddoff!
		[1917] = UNSTOPPABLE,	-- You Got Nuthin!
		-- Squig Herder
		[1839] = UNSTOPPABLE,	-- Choking Arrer
		[1837] = UNSTOPPABLE,	-- Drop That!!
		[1835] = UNSTOPPABLE,	-- Not So Fast!
		-- Witch Hunter
		[8110] = UNSTOPPABLE,	-- Dragon Gun
		[8086] = UNSTOPPABLE,	-- Confess!
		[8115] = UNSTOPPABLE,	-- Pistol Whip
		[8100] = UNSTOPPABLE,	-- Silence The Heretic
		[8094] = UNSTOPPABLE,	-- Declare Anathema
		-- Knight of the Blazing Sun
		[8018] = UNSTOPPABLE,	-- Smashing Counter
		[8018] = IMMOVABLE,		-- Repel Darkness
		-- Bright Wizard
		[8186] = UNSTOPPABLE,	-- Stop, Drop, and Roll
		[8174] = UNSTOPPABLE,	-- Choking Smoke
		-- Warrior Priest
		[8256] = UNSTOPPABLE,	-- Vow of Silence
		-- Chosen
		[8346] = UNSTOPPABLE,	-- Downfall
		[8329] = IMMOVABLE,		-- Repel
		-- Marauder
		[8412] = UNSTOPPABLE,	-- Mutated Energy
		[8405] = UNSTOPPABLE,	-- Death Grip
		[8410] = IMMOVABLE,		-- Terrible Embrace
		-- Zealot
		[8571] = UNSTOPPABLE,	-- Aethyric Shock
		[8565] = UNSTOPPABLE,	-- Tzeentch's Lash
		-- Magus
		[8495] = UNSTOPPABLE,	-- Perils of The Warp
		[8483] = IMMOVABLE,		-- Warping Blast
		-- Swordmaster
		[9032] = IMMOVABLE,		-- Redirected Force
		-- [9030] = UNSTOPPABLE,	-- Whispering Window
		[9028] = UNSTOPPABLE,	-- Chrashing Wave
		-- Shadow Warrior
		[9096] = UNSTOPPABLE,	-- Eye Shot
		[9108] = UNSTOPPABLE,	-- Exploit Weakness
		[9098] = UNSTOPPABLE,	-- Opportunistic Strike
		-- White Lion
		[9193] = UNSTOPPABLE,	-- Brutal Pounce
		[9177] = UNSTOPPABLE,	-- Throat Bite
		[9178] = IMMOVABLE,		-- Fetch!
		-- Archmage
		[9266] = IMMOVABLE,		-- Cleansing Flare
		[9253] = UNSTOPPABLE,	-- Law of Gold
		-- Blackguard
		[2888] = UNSTOPPABLE,	-- Malignant Strike!
		[9321] = UNSTOPPABLE,	-- Spiteful Slam
		[9328] = IMMOVABLE,		-- Exile
		-- Witch Elf
		[9422] = UNSTOPPABLE,	-- On Your Knees!
		[9400] = UNSTOPPABLE,	-- Sever Limb
		[9427] = UNSTOPPABLE,	-- Heart Seeker
		[9409] = UNSTOPPABLE,	-- Throat Slitter
		[9396] = UNSTOPPABLE,	-- Agile Escape
		-- Disciple of Khaine
		[9565] = UNSTOPPABLE,	-- Consume Thought
		-- Sorcerer
		[9482] = UNSTOPPABLE,	-- Frostbite
		[9489] = UNSTOPPABLE,	-- Stricken Voices
	},
}

function GCDsaver.Initialize()
	if not GCDsaver.Settings then
		local defaultSettings = GCDsaver.DefaultSettings
		GCDsaver.Settings = defaultSettings
	end
	
	GCDsaver.UpdateButtonIcons()
	
	RegisterEventHandler(SystemData.Events.PLAYER_TARGET_UPDATED, "GCDsaver.ClearImmunities")
	RegisterEventHandler(SystemData.Events.PLAYER_TARGET_IS_IMMUNE_TO_DISABLES, "GCDsaver.SetUnstoppable")
	RegisterEventHandler(SystemData.Events.PLAYER_TARGET_IS_IMMUNE_TO_MOVEMENT_IMPARING, "GCDsaver.SetImmovable")
	
	RegisterEventHandler(SystemData.Events.PLAYER_EFFECTS_UPDATED, "GCDsaver.UpdateButtonsEnabledStates")
	RegisterEventHandler(SystemData.Events.PLAYER_TARGET_UPDATED, "GCDsaver.UpdateButtonsEnabledStates")
	RegisterEventHandler(SystemData.Events.PLAYER_TARGET_EFFECTS_UPDATED, "GCDsaver.UpdateButtonsEnabledStates")
	RegisterEventHandler(SystemData.Events.PLAYER_TARGET_IS_IMMUNE_TO_DISABLES, "GCDsaver.UpdateButtonsEnabledStates")
	RegisterEventHandler(SystemData.Events.PLAYER_TARGET_IS_IMMUNE_TO_MOVEMENT_IMPARING, "GCDsaver.UpdateButtonsEnabledStates")
	
	TextLogAddEntry("Chat", 0, towstring("<icon57> GCDsaver loaded. Shift-Click abilities to set check type."))
end

function GCDsaver.OnUpdate(elapsed)
	timeLeft = timeLeft - elapsed
    if timeLeft > 0 then
        return
    end
    timeLeft = TIME_DELAY
	GCDsaver.UpdateButtonIcons()
end

function GCDsaver.OnShutdown()
	UnregisterEventHandler(SystemData.Events.PLAYER_TARGET_UPDATED, "GCDsaver.ClearImmunities")
	UnregisterEventHandler(SystemData.Events.PLAYER_TARGET_IS_IMMUNE_TO_DISABLES, "GCDsaver.SetUnstoppable")
	UnregisterEventHandler(SystemData.Events.PLAYER_TARGET_IS_IMMUNE_TO_MOVEMENT_IMPARING, "GCDsaver.SetImmovable")

	UnregisterEventHandler(SystemData.Events.PLAYER_EFFECTS_UPDATED, "GCDsaver.UpdateButtonsEnabledStates")
	UnregisterEventHandler(SystemData.Events.PLAYER_TARGET_UPDATED, "GCDsaver.UpdateButtonsEnabledStates")
	UnregisterEventHandler(SystemData.Events.PLAYER_TARGET_EFFECTS_UPDATED, "GCDsaver.UpdateButtonsEnabledStates")
	UnregisterEventHandler(SystemData.Events.PLAYER_TARGET_IS_IMMUNE_TO_DISABLES, "GCDsaver.UpdateButtonsEnabledStates")
	UnregisterEventHandler(SystemData.Events.PLAYER_TARGET_IS_IMMUNE_TO_MOVEMENT_IMPARING, "GCDsaver.UpdateButtonsEnabledStates")
end

function GCDsaver.ClearImmunities(target, id)
	if target == TargetInfo.HOSTILE_TARGET and GCDsaver.TargetID ~= id then
		GCDsaver.TargetID = id
		GCDsaver.TargetImmovable = false
		GCDsaver.TargetUnstoppable = false
	end
end

function GCDsaver.SetImmovable(isImmovable)
	GCDsaver.TargetImmovable = isImmovable
end

function GCDsaver.SetUnstoppable(isUnstoppable)
	GCDsaver.TargetUnstoppable = isUnstoppable
end

local orgWindowGameAction = WindowGameAction
function WindowGameAction(windowName)
	local actionType, actionId, actionText = WindowGetGameActionData(windowName)
	local abilityData = GetAbilityData(actionId)
	
	if GCDsaver.TargetImmovable and GCDsaver.Settings.Abilities[actionId] and GCDsaver.Settings.Abilities[actionId] == IMMOVABLE then
		if abilityUsable(actionId) then alertText("Target is Immovable") end
	elseif GCDsaver.TargetUnstoppable and GCDsaver.Settings.Abilities[actionId] and GCDsaver.Settings.Abilities[actionId] == UNSTOPPABLE then
		if abilityUsable(actionId) then alertText("Target is Unstoppable") end
	elseif GCDsaver.Settings.Abilities[actionId] and hasBuffName(getTargetType(abilityData.targetType), abilityData.name, GCDsaver.Settings.Abilities[actionId]) then
		if abilityUsable(actionId) then alertText("Target already has that effect") end
	else
		orgWindowGameAction(windowName)
	end
end


local function setButtonIcon(actionId, state)
	local stackIcons = {"<icon20262>", "<icon20264>", "<icon20266>"}
	local hbar, buttonid, button
	local buttonActionId
	for i = 1, 60 do
		_, buttonActionId = GetHotbarData(i)
		if buttonActionId == actionId then
			hbar, buttonid = ActionBars:BarAndButtonIdFromSlot(i)
			if hbar and buttonid then
				button = hbar.m_Buttons[buttonid]
				if state == IMMOVABLE then
					button.m_Windows[7]:Show(true)
					button.m_Windows[7]:SetText("<icon05007>")
				elseif state == UNSTOPPABLE then
					button.m_Windows[7]:Show(true)
					button.m_Windows[7]:SetText("<icon05006>")
				elseif type(state) == "number" then
					
					button.m_Windows[7]:Show(true)
					button.m_Windows[7]:SetText(tostring(state)..stackIcons[state])
				else
					button.m_Windows[7]:Show(false)
				end
			end
		end
	end
end

function GCDsaver.UpdateButtonIcons()
	for abilityId, state in pairs(GCDsaver.Settings.Abilities) do
		setButtonIcon(abilityId, state)
	end
end

function GCDsaver.UpdateButtonsEnabledStates()
	local actionType, actionId, isSlotEnabled, isTargetValid, isSlotBlocked
	
	for i = 1, 60 do
		actionType, actionId, isSlotEnabled, isTargetValid, isSlotBlocked = GetHotbarData(i)
		ActionBars.UpdateSlotEnabledState(i, isSlotEnabled, isTargetValid, isSlotBlocked)
	end
end

local orgActionButtonOnLButtonUp = ActionButton.OnLButtonUp
function ActionButton.OnLButtonUp(self, flags, x, y)
	if flags ~= SystemData.ButtonFlags.SHIFT then
		orgActionButtonOnLButtonUp(self, flags, x, y)
	end
end

local orgActionButtonOnLButtonDown = ActionButton.OnLButtonDown
function ActionButton.OnLButtonDown(self, flags, x, y)
	if flags == SystemData.ButtonFlags.SHIFT and self.m_ActionId ~= 0 then
		if not GCDsaver.Settings.Abilities[self.m_ActionId] then
			GCDsaver.Settings.Abilities[self.m_ActionId] = 1
		elseif GCDsaver.Settings.Abilities[self.m_ActionId] < 5 then
			GCDsaver.Settings.Abilities[self.m_ActionId] = GCDsaver.Settings.Abilities[self.m_ActionId] + 1
		else
			GCDsaver.Settings.Abilities[self.m_ActionId] = nil
		end
		setButtonIcon(self.m_ActionId, GCDsaver.Settings.Abilities[self.m_ActionId])
		chatInfo(self.m_ActionId, GCDsaver.Settings.Abilities[self.m_ActionId])
		GCDsaver.UpdateButtonsEnabledStates()
	else
		orgActionButtonOnLButtonDown(self, flags, x, y)
	end
end

local orgActionBarsUpdateSlotEnabledState = ActionBars.UpdateSlotEnabledState
function ActionBars.UpdateSlotEnabledState(slot, isSlotEnabled, isTargetValid, isSlotBlocked)
	local hbar, buttonid = ActionBars:BarAndButtonIdFromSlot(slot)
	local button = hbar.m_Buttons[buttonid]
	local abilityData = GetAbilityData(button.m_ActionId)
	
	if GCDsaver.Settings.Abilities[button.m_ActionId]
	and GCDsaver.Settings.Abilities[button.m_ActionId] == IMMOVABLE
	and GCDsaver.TargetImmovable
	then
		isSlotEnabled = false

	elseif GCDsaver.Settings.Abilities[button.m_ActionId]
	and GCDsaver.Settings.Abilities[button.m_ActionId] == UNSTOPPABLE
	and GCDsaver.TargetUnstoppable
	then
		isSlotEnabled = false

	elseif GCDsaver.Settings.Abilities[button.m_ActionId]
	and hasBuffName(getTargetType(abilityData.targetType), abilityData.name, GCDsaver.Settings.Abilities[button.m_ActionId])
	then
		isSlotEnabled = false
	end
	
	orgActionBarsUpdateSlotEnabledState(slot, isSlotEnabled, isTargetValid, isSlotBlocked)
end