followTheLeader = {}

local SIMPLEBUTTON = true -- if it's just a simple button, we won't update the label with leaders name and targeting state

function followTheLeader.Initialize()
	-- INIT VARIABLES
	followTheLeader.leaderName = L""

	-- CREATE WINDOW
	CreateWindow ("followTheLeaderWindow", true)
	LayoutEditor.RegisterWindow( "followTheLeaderWindow",  
                                L"followTheLeaderWindow",
                                L"followTheLeaderWindow",
                                true, false,
                                true, nil )
	
	ButtonSetText ("followTheLeaderWindow", L"Follow the leader")
	

	-- REGISTER EVENT HANDLERS (we probably don't need this many)
	RegisterEventHandler( SystemData.Events.GROUP_SET_LEADER, "followTheLeader.Update")
	--RegisterEventHandler( SystemData.Events.GROUP_UPDATED, "followTheLeader.Update")
    --RegisterEventHandler( SystemData.Events.GROUP_STATUS_UPDATED, "followTheLeader.Update")
	RegisterEventHandler( SystemData.Events.GROUP_PLAYER_ADDED, "followTheLeader.Update")
	RegisterEventHandler( SystemData.Events.PLAYER_GROUP_LEADER_STATUS_UPDATED, "followTheLeader.Update")
	RegisterEventHandler( SystemData.Events.GROUP_ACCEPT_INVITATION, "followTheLeader.Update")
	RegisterEventHandler( SystemData.Events.BATTLEGROUP_ACCEPT_INVITATION, "followTheLeader.Update")
	--RegisterEventHandler( SystemData.Events.BATTLEGROUP_UPDATED, "followTheLeader.Update")
	RegisterEventHandler( SystemData.Events.GROUP_SETTINGS_UPDATED, "followTheLeader.Update")

	if not SIMPLEBUTTON then
		RegisterEventHandler( SystemData.Events.PLAYER_TARGET_UPDATED, "followTheLeader.OnTargetUpdated")
		-- RegisterEventHandler( SystemData.Events.SPELL_CAST_CANCEL, "followTheLeader.OnTargetUpdated")
	end
end

function followTheLeader.Update()
	if (IsWarBandActive() and GameData.Player.isInScenario == false) then
		-- followTheLeader.leaderIsTargeted = false
		followTheLeader.Show()
		local leadname = followTheLeader.FixName(PartyUtils.GetWarbandLeader().name)
		if leadname ~= followTheLeader.FixName(GameData.Player.name) then
			if leadname ~= followTheLeader.leaderName then
				TextLogAddEntry("Chat", SystemData.ChatLogFilters.BATTLEGROUP, L"<icon00044> Warband leader: "..leadname)
				followTheLeader.leaderName = leadname
				followTheLeader.SetLeaderName (followTheLeader.leaderName)
			end
		else
			followTheLeader.Hide()
		end
	else
		followTheLeader.Hide()
	end
end

function followTheLeader.Show()
	WindowSetShowing("followTheLeaderWindow", true)
end

function followTheLeader.Hide()
	WindowSetShowing("followTheLeaderWindow", false)
end

function followTheLeader.SetLeaderName (playerName)
	followTheLeader.leaderName = playerName
	WindowSetGameActionData ("followTheLeaderWindow", GameData.PlayerActions.SET_TARGET, 0, followTheLeader.leaderName or L"")
	-- if SIMPLEBUTTON then
	-- 	ButtonSetText ("followTheLeaderWindowButton", L"Follow "..followTheLeader.leaderName)
	-- end
end

function followTheLeader.OnTargetUpdated()
	followTheLeader.UpdateLabel()
end

function followTheLeader.UpdateLabel()

	TargetInfo:UpdateFromClient()
	local targetname = followTheLeader.FixName(TargetInfo:UnitName("selffriendlytarget"))
	d(targetname)

	local targetIsLeader = (targetname == followTheLeader.leaderName) and (targetname ~= followTheLeader.FixName(GameData.Player.name)) and targetname ~= L"" and targetname

	if targetIsLeader then
		ButtonSetText ("followTheLeaderWindow", L"Follow "..followTheLeader.leaderName)
	else 
		ButtonSetText ("followTheLeaderWindow", L"Target "..followTheLeader.leaderName)
		followTheLeader.leaderIsTargeted = false
	end

end


function followTheLeader.OnMouseOver()
	local anchor = { Point="right",  RelativeTo=SystemData.ActiveWindow.name, RelativePoint="left", XOffset=20, YOffset=0 }
	Tooltips.CreateTextOnlyTooltip( SystemData.ActiveWindow.name )
    Tooltips.SetTooltipText( 1, 1, L"LClick to target/follow the leader.\nRClick to follow current target.")
    Tooltips.Finalize();
    Tooltips.AnchorTooltip( anchor )
end

function followTheLeader.OnLButtonUp()
	followTheLeader.Update()

	local targetname = followTheLeader.FixName(TargetInfo:UnitName("selffriendlytarget"))
	local targetIsLeader = (targetname == followTheLeader.leaderName) and (targetname ~= followTheLeader.FixName(GameData.Player.name)) and targetname ~= L""

	if targetIsLeader then
		SendChatText( L"/follow ", L"" )
		followTheLeader.leaderIsTargeted = true
	end
end

function followTheLeader.OnRButtonUp()
	local targetname = followTheLeader.FixName(TargetInfo:UnitName("selffriendlytarget"))
	if (targetname ~= followTheLeader.FixName(GameData.Player.name)) and targetname ~= L"" then 
		SendChatText( L"/follow ", L"" )
	end
end

function followTheLeader.FixName (str)

	if (str == nil) then return nil end

	local str = str
	local pos = str:find (L"^", 1, true)
	if (pos) then str = str:sub (1, pos - 1) end
	
	return str
end