--[[
  followTheLeader Addon
  - LClick follows target when not in WB, otherwise targets/follows WB leader.
  - RClick follows current target.
--]]

followTheLeader = {}

local WINDOW_NAME = "followTheLeaderWindow"

-- Helper function to follow the current friendly target
function followTheLeader.FollowCurrentTarget()
    TargetInfo:UpdateFromClient()
    local targetname = followTheLeader.FixName(TargetInfo:UnitName("selffriendlytarget"))
    if targetname and targetname ~= L"" and targetname ~= followTheLeader.FixName(GameData.Player.name) then
        SendChatText( L"/follow ", L"" )
    end
    if followTheLeader.settings and followTheLeader.settings.trackstate then
        followTheLeader.TrackState()
    end
end


function followTheLeader.Initialize()
	followTheLeader.leaderName = L""
    followTheLeader.lastPrintedLeaderName = L""

	CreateWindow (WINDOW_NAME, true)
    WindowSetShowing(WINDOW_NAME, true)

	LayoutEditor.RegisterWindow( WINDOW_NAME,
                                L"followTheLeaderWindow",
                                L"followTheLeaderWindow",
                                true, false,
                                true, nil )
	ButtonSetText (WINDOW_NAME, L"Follow Target")

	-- saved variables
	if followTheLeader.settings == nil then
		followTheLeader.settings = {}
		followTheLeader.settings.version = "1.0.4"
		followTheLeader.settings.oneclickfollow = true
		followTheLeader.settings.trackstate = false
	end

	-- REGISTER EVENT HANDLERS
	RegisterEventHandler( SystemData.Events.GROUP_SET_LEADER,                    "followTheLeader.Update")
	RegisterEventHandler( SystemData.Events.GROUP_PLAYER_ADDED,                  "followTheLeader.Update")
	RegisterEventHandler( SystemData.Events.PLAYER_GROUP_LEADER_STATUS_UPDATED,  "followTheLeader.Update")
	RegisterEventHandler( SystemData.Events.GROUP_ACCEPT_INVITATION,             "followTheLeader.Update")
	RegisterEventHandler( SystemData.Events.BATTLEGROUP_ACCEPT_INVITATION,       "followTheLeader.Update")
	RegisterEventHandler( SystemData.Events.GROUP_SETTINGS_UPDATED,              "followTheLeader.Update")

	if followTheLeader.settings and followTheLeader.settings.trackstate then
		followTheLeader.StateTrackingSet(true)
	end

	LibSlash.RegisterSlashCmd("followtheleader", function(msg) followTheLeader.slash(msg) end)
	TextLogAddEntry("Chat", 0, L"<icon00044> followTheLeader initialized.")

    followTheLeader.Update()
end


function followTheLeader.slash(msg)
    if followTheLeader.settings == nil then followTheLeader.settings = {} end
	if msg == "oneclick" then
		followTheLeader.settings.oneclickfollow = not followTheLeader.settings.oneclickfollow
		TextLogAddEntry("Chat", 0, L"One click follow: "..towstring(tostring(followTheLeader.settings.oneclickfollow)))
        followTheLeader.Update()
	elseif msg == "trackstate" then
		followTheLeader.settings.trackstate = not followTheLeader.settings.trackstate
		followTheLeader.StateTrackingSet(followTheLeader.settings.trackstate)
        TextLogAddEntry("Chat", 0, L"Track follow state: "..towstring(tostring(followTheLeader.settings.trackstate)))
        followTheLeader.Update()
	else
		TextLogAddEntry("Chat", 0, L"Follow the leader status:")
		TextLogAddEntry("Chat", 0, L"One click follow: "..towstring(tostring(followTheLeader.settings.oneclickfollow)))
		TextLogAddEntry("Chat", 0, L"Track follow state: "..towstring(tostring(followTheLeader.settings.trackstate)))
		TextLogAddEntry("Chat", 0, L"Optional parameters: oneclick, trackstate.")
	end
end


function followTheLeader.StateTrackingSet(enable)
	if enable then
		RegisterEventHandler( SystemData.Events.PLAYER_TARGET_UPDATED, "followTheLeader.OnTargetUpdated")
        followTheLeader.TrackState()
	else
		UnregisterEventHandler( SystemData.Events.PLAYER_TARGET_UPDATED, "followTheLeader.OnTargetUpdated")
        followTheLeader.Update() -- Update to reset text based on non-tracking state
	end
end


function followTheLeader.Update()
	local isInWB = IsWarBandActive() and GameData.Player.isInScenario == false
	local currentLeaderName = L""

	if isInWB then
		local leaderInfo = PartyUtils.GetWarbandLeader()
		if leaderInfo and leaderInfo.name then
			local potentialLeaderName = followTheLeader.FixName(leaderInfo.name)
			-- Check if valid leader and not the player
			if potentialLeaderName ~= followTheLeader.FixName(GameData.Player.name) and potentialLeaderName ~= L"" then
				currentLeaderName = potentialLeaderName
			end
		end

		if currentLeaderName ~= followTheLeader.leaderName then
			-- Always Update internal state if different
			followTheLeader.leaderName = currentLeaderName
			followTheLeader.SetLeaderName (followTheLeader.leaderName)

			-- Check if we should PRINT
			if currentLeaderName ~= L"" and currentLeaderName ~= followTheLeader.lastPrintedLeaderName then
				TextLogAddEntry("Chat", SystemData.ChatLogFilters.BATTLEGROUP, L"<icon00044> Warband leader: "..currentLeaderName)
				followTheLeader.lastPrintedLeaderName = currentLeaderName
			end
		end

	else -- Not in WB
		-- Look for a party leader
        local party_data = PartyUtils.GetPartyData()
        local partyLeaderName = L""
        if party_data and type(party_data) == "table" and next(party_data) ~= nil then
            for i, memberData in ipairs(party_data) do
                if memberData and memberData.isGroupLeader and memberData.name then
                    local potentialLeaderName = followTheLeader.FixName(memberData.name)
                    if potentialLeaderName ~= followTheLeader.FixName(GameData.Player.name) and potentialLeaderName ~= L"" then
                        partyLeaderName = potentialLeaderName
                        break
                    end
                end
            end
        end
        currentLeaderName = partyLeaderName

        if currentLeaderName ~= followTheLeader.leaderName then
            followTheLeader.leaderName = currentLeaderName
            followTheLeader.SetLeaderName(followTheLeader.leaderName)

            if currentLeaderName ~= L"" and currentLeaderName ~= followTheLeader.lastPrintedLeaderName then
                TextLogAddEntry("Chat", SystemData.ChatLogFilters.BATTLEGROUP, L"<icon00044> Group leader: " .. currentLeaderName)
                followTheLeader.lastPrintedLeaderName = currentLeaderName
            elseif currentLeaderName == L"" then -- Clear last printed name if we left the group
                followTheLeader.lastPrintedLeaderName = L""
            end
        end
	end

	-- Update button text
	if followTheLeader.settings and followTheLeader.settings.trackstate then
		followTheLeader.TrackState()
	else
		-- Set default text based on if any leader exists
		if followTheLeader.leaderName ~= L"" then
			ButtonSetText(WINDOW_NAME, L"Follow "..followTheLeader.leaderName)
		else
			ButtonSetText(WINDOW_NAME, L"Follow Target")
		end
	end
end


function followTheLeader.SetLeaderName (playerName)
    local nameToSet = playerName or L""
	WindowSetGameActionData (WINDOW_NAME, GameData.PlayerActions.SET_TARGET, 0, nameToSet)
end

function followTheLeader.OnTargetUpdated()
    if followTheLeader.settings and followTheLeader.settings.trackstate then
	    followTheLeader.TrackState()
    end
end

function followTheLeader.TrackState()
    if not followTheLeader.settings then return end
    if followTheLeader.leaderName and followTheLeader.leaderName ~= L"" then
        TargetInfo:UpdateFromClient()
        local targetname = followTheLeader.FixName(TargetInfo:UnitName("selffriendlytarget"))
        local targetIsLeader = (targetname == followTheLeader.leaderName) and (targetname ~= L"")
        if targetIsLeader or followTheLeader.settings.oneclickfollow then
            ButtonSetText (WINDOW_NAME, L"Follow "..followTheLeader.leaderName)
        else
            ButtonSetText (WINDOW_NAME, L"Target "..followTheLeader.leaderName)
        end
    else
        ButtonSetText(WINDOW_NAME, L"Follow Target")
    end
end

function followTheLeader.OnMouseOver()
	local anchor = { Point="right", RelativeTo=SystemData.ActiveWindow.name, RelativePoint="left", XOffset=20, YOffset=0 }
	Tooltips.CreateTextOnlyTooltip( SystemData.ActiveWindow.name )

    local hasLeader = followTheLeader.leaderName and followTheLeader.leaderName ~= L""
	local tooltipText = L""

	if hasLeader then
		tooltipText = L"LClick to target/follow leader.\nRClick to follow current target."
	else
		tooltipText = L"LClick to follow current target.\nRClick to follow current target."
	end

	Tooltips.SetTooltipText( 1, 1, tooltipText)
	Tooltips.Finalize();
	Tooltips.AnchorTooltip( anchor )
end

function followTheLeader.OnLButtonUp()
    if followTheLeader.leaderName and followTheLeader.leaderName ~= L"" then
        if followTheLeader.settings and followTheLeader.settings.oneclickfollow then
            TargetInfo:UpdateFromClient()
        end
        local targetname = followTheLeader.FixName(TargetInfo:UnitName("selffriendlytarget"))
        local targetIsLeader = (targetname == followTheLeader.leaderName) and (targetname ~= L"")
        if targetIsLeader then
            SendChatText( L"/follow ", L"" )
        end
        if followTheLeader.settings and followTheLeader.settings.trackstate then
             followTheLeader.TrackState()
        end
    else
        followTheLeader.FollowCurrentTarget()
    end
end

function followTheLeader.OnRButtonUp()
    PlaySound(GameData.Sound.BUTTON_CLICK)
    followTheLeader.FollowCurrentTarget()
end

function followTheLeader.FixName(str)
    if (str == nil) then
        return L""
    end
    local normalStr = tostring(str)
    local pos = string.find(normalStr, "^", 1, true)
    if (pos) then
        normalStr = string.sub(normalStr, 1, pos - 1)
    end
    normalStr = normalStr:gsub("^%s+", ""):gsub("%s+$", "")
    return towstring(normalStr)
end
