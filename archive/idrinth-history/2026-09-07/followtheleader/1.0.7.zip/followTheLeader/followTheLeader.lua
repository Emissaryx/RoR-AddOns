--[[
    followTheLeader Addon
    - Left-click: Targets and follows the current effective leader (fixed > dynamic).
    - Right-click: Follows your current friendly player target (if valid).
    - Middle-click: Toggles fixed leader mode for current target.
    - Auto-updates in group, warband, or scenario context. Optional tracking/one-click follow.
--]]

followTheLeader = {}
followTheLeader.version = "1.0.7"
followTheLeader.isUpdatePending = false
followTheLeader.inScenarioMode = false

-- Helper function for conditional debug messages
local function DebugPrint(msg)
    if followTheLeader.settings and followTheLeader.settings.debug then
        TextLogAddEntry("Chat", 0, towstring("[FTL-Debug] " .. msg))
    end
end

-- Runs every frame via the mod's OnUpdate handler
function followTheLeader.OnFrameUpdate()
    if followTheLeader.isUpdatePending then
        followTheLeader.isUpdatePending = false
        followTheLeader.Update()
    end
end

-- Request a UI update on the next frame
function followTheLeader.RequestUpdate()
    followTheLeader.isUpdatePending = true
end

local WINDOW_NAME = "followTheLeaderWindow"

function followTheLeader.OnScenarioBegin()
    followTheLeader.inScenarioMode = true
    followTheLeader.RequestUpdate()
end

function followTheLeader.OnScenarioEnd()
    followTheLeader.inScenarioMode = false
    followTheLeader.RequestUpdate()
end

-- Capitalizes the first letter of a name, makes the rest lowercase
function followTheLeader.CapitalizeName(name)
    if not name or name == "" then return "" end
    return string.upper(string.sub(name, 1, 1)) .. string.lower(string.sub(name, 2))
end

function followTheLeader.IsPlayerTrulyInParty(partyData)
    if not partyData or not next(partyData) then
        return false
    end
    for _, memberData in ipairs(partyData) do
        if memberData and memberData.name and memberData.name ~= L"" then
            return true
        end
    end
    return false
end

function followTheLeader.GetFriendlyPlayerTargetObject()
    TargetInfo:UpdateFromClient()
    local target = TargetInfo.m_Units[TargetInfo.FRIENDLY_TARGET]

    -- A target is considered a player if it has a valid career ID (> 0). NPCs have a career ID of 0.
    if target and target.career and target.career > 0 and target.name and target.name ~= L"" then
        return target
    end

    return nil
end

-- Helper function to follow the current friendly target
function followTheLeader.FollowCurrentTarget()
    local friendlyPlayerTarget = followTheLeader.GetFriendlyPlayerTargetObject()
    if friendlyPlayerTarget and followTheLeader.FixName(friendlyPlayerTarget.name) ~= followTheLeader.FixName(GameData.Player.name) then
        SendChatText( L"/follow ", L"" )
    end
    if followTheLeader.settings and followTheLeader.settings.trackstate then
        followTheLeader.TrackState()
    end
end

function followTheLeader.Initialize()
    followTheLeader.leaderName = L""
    followTheLeader.lastPrintedLeaderName = L""
    followTheLeader.fixedLeaderName = L""
    followTheLeader.dynamicLeaderName = L""
    followTheLeader.dynamicLeaderNilCycles = 0
    followTheLeader.persistentLeaderName = L""

    CreateWindow (WINDOW_NAME, true)
    WindowSetShowing(WINDOW_NAME, true)

    LayoutEditor.RegisterWindow( WINDOW_NAME,
                                 L"followTheLeaderWindow",
                                 L"followTheLeaderWindow",
                                 true, false,
                                 true, nil )
    ButtonSetText (WINDOW_NAME, L"Follow Target")

    -- initialize settings
    if followTheLeader.settings == nil then
        followTheLeader.settings = {}
        followTheLeader.settings.version = followTheLeader.version
        followTheLeader.settings.oneclickfollow = true
        followTheLeader.settings.trackstate = false
        followTheLeader.settings.debug = false
    elseif followTheLeader.settings.debug == nil then
        followTheLeader.settings.debug = false
    end

    RegisterEventHandler( SystemData.Events.GROUP_SET_LEADER,                 "followTheLeader.RequestUpdate")
    RegisterEventHandler( SystemData.Events.GROUP_PLAYER_ADDED,               "followTheLeader.RequestUpdate")
    RegisterEventHandler( SystemData.Events.PLAYER_GROUP_LEADER_STATUS_UPDATED,  "followTheLeader.RequestUpdate")
    RegisterEventHandler( SystemData.Events.GROUP_ACCEPT_INVITATION,          "followTheLeader.RequestUpdate")
    RegisterEventHandler( SystemData.Events.BATTLEGROUP_ACCEPT_INVITATION,      "followTheLeader.RequestUpdate")
    RegisterEventHandler( SystemData.Events.GROUP_SETTINGS_UPDATED,           "followTheLeader.RequestUpdate")
    RegisterEventHandler( SystemData.Events.GROUP_LEAVE,                      "followTheLeader.RequestUpdate")
    RegisterEventHandler( SystemData.Events.SCENARIO_PLAYERS_LIST_UPDATED,    "followTheLeader.RequestUpdate")
    RegisterEventHandler( SystemData.Events.SCENARIO_BEGIN,                   "followTheLeader.OnScenarioBegin")
    RegisterEventHandler( SystemData.Events.SCENARIO_END,                     "followTheLeader.OnScenarioEnd")

    if followTheLeader.settings and followTheLeader.settings.trackstate then
        followTheLeader.StateTrackingSet(true)
    end

    local mainCmdSuccess = LibSlash.RegisterSlashCmd("followtheleader", function(msg) followTheLeader.slash(msg) end)
    DebugPrint("Registering '/followtheleader'... Success: " .. tostring(mainCmdSuccess))

    local aliasCmdSuccess = LibSlash.RegisterSlashCmd("ftl", function(msg) followTheLeader.slash(msg) end)
    DebugPrint("Registering '/ftl' as alias... Success: " .. tostring(aliasCmdSuccess))

    TextLogAddEntry("Chat", SystemData.ChatLogFilters.BATTLEGROUP, L"<icon00044> followTheLeader v" .. towstring(followTheLeader.version) .. L" initialized.")

    followTheLeader.Update()
end


function followTheLeader.slash(msg)
    DebugPrint("Main slash command '/followtheleader' EXECUTED with args: '" .. tostring(msg) .. "'")
    if followTheLeader.settings == nil then followTheLeader.settings = {} end

    local cmd, param = msg:match("^(%S+)%s*(.*)$")
    if not cmd then cmd = msg:lower() else cmd = cmd:lower() end
    if not param then param = "" end

    if cmd == "set" then
        local nameToSet = L""
        if param ~= "" then
            nameToSet = towstring(followTheLeader.CapitalizeName(param))
        else
            local friendlyPlayerTarget = followTheLeader.GetFriendlyPlayerTargetObject()
            if friendlyPlayerTarget and followTheLeader.FixName(friendlyPlayerTarget.name) ~= followTheLeader.FixName(GameData.Player.name) then
                nameToSet = followTheLeader.FixName(friendlyPlayerTarget.name)
            else
                followTheLeader.UnsetFixedLeader()
                return
            end
        end

        if nameToSet ~= L"" then
            followTheLeader.fixedLeaderName = nameToSet
            TextLogAddEntry("Chat", SystemData.ChatLogFilters.BATTLEGROUP, L"<icon00044> followTheLeader: Fixed leader set to: " .. nameToSet)
            followTheLeader.RequestUpdate()
        end
    elseif cmd == "unset" then
        followTheLeader.UnsetFixedLeader()
    elseif cmd == "oneclick" then
        followTheLeader.settings.oneclickfollow = not followTheLeader.settings.oneclickfollow
        TextLogAddEntry("Chat", SystemData.ChatLogFilters.BATTLEGROUP, L"One click follow: "..towstring(tostring(followTheLeader.settings.oneclickfollow)))
        followTheLeader.RequestUpdate()
    elseif cmd == "trackstate" then
        followTheLeader.settings.trackstate = not followTheLeader.settings.trackstate
        followTheLeader.StateTrackingSet(followTheLeader.settings.trackstate)
        TextLogAddEntry("Chat", SystemData.ChatLogFilters.BATTLEGROUP, L"Track follow state: "..towstring(tostring(followTheLeader.settings.trackstate)))
        followTheLeader.RequestUpdate()
    elseif cmd == "debug" then
        followTheLeader.settings.debug = not followTheLeader.settings.debug
        local status = followTheLeader.settings.debug and "enabled" or "disabled"
        TextLogAddEntry("Chat", 0, towstring("followTheLeader: Debug mode " .. status .. "."))
    else
        TextLogAddEntry("Chat", SystemData.ChatLogFilters.BATTLEGROUP, L"Follow the leader status:")
        if followTheLeader.fixedLeaderName and followTheLeader.fixedLeaderName ~= L"" then
            TextLogAddEntry("Chat", SystemData.ChatLogFilters.BATTLEGROUP, L"Fixed leader: " .. followTheLeader.fixedLeaderName)
        else
            TextLogAddEntry("Chat", SystemData.ChatLogFilters.BATTLEGROUP, L"Fixed leader: None")
        end
        TextLogAddEntry("Chat", SystemData.ChatLogFilters.BATTLEGROUP, L"One click follow: "..towstring(tostring(followTheLeader.settings.oneclickfollow)))
        TextLogAddEntry("Chat", SystemData.ChatLogFilters.BATTLEGROUP, L"Track follow state: "..towstring(tostring(followTheLeader.settings.trackstate)))
        TextLogAddEntry("Chat", SystemData.ChatLogFilters.BATTLEGROUP, L"Commands: set [name], unset, oneclick, trackstate, debug.")
    end
end


function followTheLeader.StateTrackingSet(enable)
    if enable then
        RegisterEventHandler( SystemData.Events.PLAYER_TARGET_UPDATED, "followTheLeader.OnTargetUpdated")
        followTheLeader.TrackState()
    else
        UnregisterEventHandler( SystemData.Events.PLAYER_TARGET_UPDATED, "followTheLeader.OnTargetUpdated")
        followTheLeader.Update()
    end
end

function followTheLeader.GetDynamicLeaderName()
    local isInWB = IsWarBandActive()
    local party_data = PartyUtils.GetPartyData()
    local isInParty = followTheLeader.IsPlayerTrulyInParty(party_data)

    if isInWB then
        local leaderInfo = PartyUtils.GetWarbandLeader()
        if leaderInfo and leaderInfo.name then
            local potentialLeaderName = followTheLeader.FixName(leaderInfo.name)
            if potentialLeaderName ~= L"" and potentialLeaderName ~= followTheLeader.FixName(GameData.Player.name) then
                return potentialLeaderName
            end
        end
    elseif isInParty then
        for _, memberData in ipairs(party_data) do
            if memberData and memberData.isGroupLeader and memberData.name and memberData.name ~= L"" then
                local potentialLeaderName = followTheLeader.FixName(memberData.name)
                if potentialLeaderName ~= followTheLeader.FixName(GameData.Player.name) then
                    return potentialLeaderName
                end
                break
            end
        end
    end

    return L""
end

function followTheLeader.GetScenarioLeader()
    if not followTheLeader.inScenarioMode then
        return L""
    end

    local persistent = followTheLeader.persistentLeaderName
    if not persistent or persistent == L"" then
        return L""
    end

    local scdata = GameData.GetScenarioPlayerGroups()
    if scdata == nil then
        return L""
    end

    for _, player in ipairs(scdata) do
        if player.name and followTheLeader.FixName(player.name) == persistent then
            return persistent
        end
    end

    return L""
end

-- Determines the effective leader and updates UI text and internal state accordingly
function followTheLeader.Update()
    local currentDynamicLeader = L""
    if followTheLeader.inScenarioMode then
        currentDynamicLeader = followTheLeader.GetScenarioLeader()
    else
        -- Persistently track the leader when not in a scenario
        currentDynamicLeader = followTheLeader.GetDynamicLeaderName()
        followTheLeader.persistentLeaderName = currentDynamicLeader
    end

    if currentDynamicLeader ~= L"" then
        followTheLeader.dynamicLeaderNilCycles = 0
        followTheLeader.dynamicLeaderName = currentDynamicLeader
    else
        local isInWB = IsWarBandActive()
        local party_data = PartyUtils.GetPartyData()
        local isInParty = followTheLeader.IsPlayerTrulyInParty(party_data)
        local isPlayerTheLeader = GameData.Player.isGroupLeader

        if (isInWB or isInParty or followTheLeader.inScenarioMode) and not isPlayerTheLeader then
            followTheLeader.dynamicLeaderNilCycles = followTheLeader.dynamicLeaderNilCycles + 1
        else
            followTheLeader.dynamicLeaderNilCycles = 3
        end

        if followTheLeader.dynamicLeaderNilCycles >= 3 then
            followTheLeader.dynamicLeaderName = L""
            if not followTheLeader.inScenarioMode then
                followTheLeader.persistentLeaderName = L""
            end
        end
    end

    -- Determine the effective leader. Fixed leader always takes priority.
    local effectiveLeader
    if followTheLeader.fixedLeaderName and followTheLeader.fixedLeaderName ~= L"" then
        effectiveLeader = followTheLeader.fixedLeaderName
    else
        effectiveLeader = followTheLeader.dynamicLeaderName
    end

    -- Update the leader name if it has changed. This allows for clearing the leader.
    if followTheLeader.leaderName ~= effectiveLeader then
        followTheLeader.leaderName = effectiveLeader
        followTheLeader.SetLeaderName(followTheLeader.leaderName)

        -- Announce new dynamic leader if there's no fixed leader override.
        if  effectiveLeader and effectiveLeader ~= L"" and
            followTheLeader.fixedLeaderName == L"" and
            effectiveLeader == followTheLeader.dynamicLeaderName and
            effectiveLeader ~= followTheLeader.lastPrintedLeaderName then
                local groupType = L"Group"
                if IsWarBandActive() then groupType = L"Warband" end
                if followTheLeader.inScenarioMode and followTheLeader.persistentLeaderName ~= L"" then groupType = L"Scenario" end
                TextLogAddEntry("Chat", SystemData.ChatLogFilters.BATTLEGROUP, L"<icon00044> " .. groupType .. L" leader: " .. effectiveLeader)
                followTheLeader.lastPrintedLeaderName = effectiveLeader
        end
    end

    -- Update the button text based on the current state and scenario status.
    if followTheLeader.settings.trackstate then
        followTheLeader.TrackState()
    else
        local leaderToDisplay = followTheLeader.leaderName

        if leaderToDisplay and leaderToDisplay ~= L"" then
             ButtonSetText(WINDOW_NAME, L"Follow " .. leaderToDisplay)
        else
            ButtonSetText(WINDOW_NAME, L"Follow Target")
        end
    end
end

function followTheLeader.SetLeaderName (playerName)
    local nameToSet = playerName or L""
    WindowSetGameActionData (WINDOW_NAME, GameData.PlayerActions.SET_TARGET, 0, nameToSet)
end

function followTheLeader.OnTargetUpdated()
    if followTheLeader.settings and followTheLeader.settings.trackstate then
        followTheLeader.TrackState()
    end
end

function followTheLeader.TrackState()
    if not followTheLeader.settings then return end
    if followTheLeader.leaderName and followTheLeader.leaderName ~= L"" then
        local friendlyPlayerTarget = followTheLeader.GetFriendlyPlayerTargetObject()
        local targetname = nil
        if friendlyPlayerTarget then
            targetname = followTheLeader.FixName(friendlyPlayerTarget.name)
        end
        local targetIsLeader = (targetname == followTheLeader.leaderName) and (targetname ~= L"")
        if targetIsLeader or followTheLeader.settings.oneclickfollow then
            ButtonSetText (WINDOW_NAME, L"Follow "..followTheLeader.leaderName)
        else
            ButtonSetText (WINDOW_NAME, L"Target "..followTheLeader.leaderName)
        end
    else
        ButtonSetText(WINDOW_NAME, L"Follow Target")
    end
end

function followTheLeader.OnMouseOver()
    local anchor = { Point="right", RelativeTo=SystemData.ActiveWindow.name, RelativePoint="left", XOffset=20, YOffset=0 }
    Tooltips.CreateTextOnlyTooltip( SystemData.ActiveWindow.name )

    local hasLeader = followTheLeader.leaderName and followTheLeader.leaderName ~= L""
    local isFixed = followTheLeader.fixedLeaderName and followTheLeader.fixedLeaderName ~= L""
    local tooltipText = L""

    local friendlyPlayerTarget = followTheLeader.GetFriendlyPlayerTargetObject()
    local targetName = nil
    local hasTarget = false

    if friendlyPlayerTarget then
        targetName = followTheLeader.FixName(friendlyPlayerTarget.name)
        if targetName ~= followTheLeader.FixName(GameData.Player.name) then
            hasTarget = true
        else
            targetName = nil
        end
    end
    local targetIsEffectiveLeader = hasTarget and (targetName == followTheLeader.leaderName)
    local fixedName = followTheLeader.fixedLeaderName or L""
    local dynamicLeaderName = followTheLeader.dynamicLeaderName
    local mClickText = L""
    local showMClick = false

    if hasTarget then
        local targetIsDynamicLeader = (dynamicLeaderName ~= L"" and targetName == dynamicLeaderName)
        if fixedName ~= L"" and (targetName == fixedName or targetIsDynamicLeader) then
            mClickText = L"MClick to unset " .. fixedName .. L" as fixed leader."
            showMClick = true
        elseif targetName ~= fixedName then
            mClickText = L"MClick to set " .. targetName .. L" as fixed leader."
            showMClick = true
        end
    elseif fixedName ~= L"" then
        mClickText = L"MClick to unset " .. fixedName .. L" as fixed leader."
        showMClick = true
    end

    if isFixed then
        tooltipText = L"LClick to target/follow " .. followTheLeader.leaderName .. L"."
        if hasTarget and not targetIsEffectiveLeader then
            tooltipText = tooltipText .. L"\n" .. L"RClick to follow current target."
        end
    elseif hasLeader then
        tooltipText = L"LClick to target/follow " .. followTheLeader.leaderName .. L"."
        if hasTarget and not targetIsEffectiveLeader then
            tooltipText = tooltipText .. L"\n" .. L"RClick to follow current target."
        end
    else
        if hasTarget then
            tooltipText = L"LClick/RClick to follow current target."
        else
            tooltipText = L"LClick to follow current target."
        end
    end

    if showMClick then
        tooltipText = tooltipText .. L"\n" .. mClickText
    end

    Tooltips.SetTooltipText( 1, 1, tooltipText)
    Tooltips.Finalize();
    Tooltips.AnchorTooltip( anchor )
end

function followTheLeader.OnLButtonUp()
    if followTheLeader.leaderName and followTheLeader.leaderName ~= L"" then
        local friendlyPlayerTarget = followTheLeader.GetFriendlyPlayerTargetObject()
        local targetname = nil
        if friendlyPlayerTarget then
            targetname = followTheLeader.FixName(friendlyPlayerTarget.name)
        end
        local targetIsLeader = (targetname == followTheLeader.leaderName) and (targetname ~= L"")

        if not targetIsLeader then
            SendChatText(L"/target " .. followTheLeader.leaderName, L"")
            if followTheLeader.settings and followTheLeader.settings.oneclickfollow then
                SendChatText(L"/follow", L"")
            end
        else
            SendChatText(L"/follow", L"")
        end

        if followTheLeader.settings and followTheLeader.settings.trackstate then
            followTheLeader.RequestUpdate()
        end
    else
        followTheLeader.FollowCurrentTarget()
    end
end

function followTheLeader.OnRButtonUp()
    PlaySound(GameData.Sound.BUTTON_CLICK)
    followTheLeader.FollowCurrentTarget()
end

function followTheLeader.UnsetFixedLeader()
    if followTheLeader.fixedLeaderName and followTheLeader.fixedLeaderName ~= L"" then
        TextLogAddEntry("Chat", SystemData.ChatLogFilters.BATTLEGROUP, L"<icon00044> followTheLeader: Fixed leader unset.")
        followTheLeader.fixedLeaderName = L""
        followTheLeader.lastPrintedLeaderName = L""
        followTheLeader.RequestUpdate()
    end
end

function followTheLeader.OnMButtonUp()
    PlaySound(GameData.Sound.BUTTON_CLICK)
    local friendlyPlayerTarget = followTheLeader.GetFriendlyPlayerTargetObject()
    local targetName = nil
    local hasTarget = false

    if friendlyPlayerTarget then
        targetName = followTheLeader.FixName(friendlyPlayerTarget.name)
        if targetName ~= followTheLeader.FixName(GameData.Player.name) then
            hasTarget = true
        end
    end
    local fixedName = followTheLeader.fixedLeaderName
    local dynamicLeaderName = followTheLeader.dynamicLeaderName

    if hasTarget and targetName ~= fixedName and not (fixedName ~= L"" and targetName == dynamicLeaderName) then
        followTheLeader.slash("set")
    else
        followTheLeader.UnsetFixedLeader()
    end
end

-- Normalizes a player name to towstring without trailing symbols or whitespace
function followTheLeader.FixName(str)
    if (str == nil) then
        return L""
    end
    local normalStr = tostring(str)
    local pos = string.find(normalStr, "^", 1, true)
    if (pos) then
        normalStr = string.sub(normalStr, 1, pos - 1)
    end
    normalStr = normalStr:gsub("^%s+", ""):gsub("%s+$", "")
    return towstring(normalStr)
end
