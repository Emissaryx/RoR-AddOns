-- CheckerByEgyptianKozi | Copyright (c) 2026 EgyptianKozi. All rights reserved.

CheckerByEgyptianKozi = CheckerByEgyptianKozi or {}
local CBK = CheckerByEgyptianKozi

local SLOTS = {
	HEAD      = 1,
	SHOULDERS = 2,
	CHEST     = 3,
	HANDS     = 4,
	BELT      = 5,
	BOOTS     = 6,
	BACK      = 7,
	RING      = 8,
	POCKET    = 9,
}
CBK.SLOTS = SLOTS

local SLOT_NAMES = {
	[SLOTS.HEAD]      = L"Helm",
	[SLOTS.SHOULDERS] = L"Shoulders",
	[SLOTS.CHEST]     = L"Chest",
	[SLOTS.HANDS]     = L"Gloves",
	[SLOTS.BELT]      = L"Belt",
	[SLOTS.BOOTS]     = L"Boots",
	[SLOTS.BACK]      = L"Cape",
	[SLOTS.RING]      = L"Ring",
	[SLOTS.POCKET]    = L"Pocket",
}
CBK.SLOT_NAMES = SLOT_NAMES

CBK.Wards = {
	{ id = 1,  name = L"Renown 1+",  sets = { "Decimator", "Braggart", "Carnage", "Havoc" },  slots = { SLOTS.BOOTS, SLOTS.HANDS, SLOTS.CHEST } },
	{ id = 2,  name = L"Level 1+",   sets = { "Hunter", "Tracker", "Protector" },             slots = { SLOTS.BOOTS, SLOTS.HANDS, SLOTS.CHEST } },
	{ id = 3,  name = L"Renown 10+", sets = { "Obliterator" },                                slots = { SLOTS.BOOTS, SLOTS.HANDS, SLOTS.CHEST } },
	{ id = 4,  name = L"Level 16+",  sets = { "Keeper" },                                     slots = { SLOTS.BOOTS, SLOTS.HANDS, SLOTS.SHOULDERS, SLOTS.HEAD, SLOTS.CHEST } },
	{ id = 5,  name = L"Renown 20+", sets = { "Devastator" },                                 slots = { SLOTS.BOOTS, SLOTS.HANDS, SLOTS.CHEST } },
	{ id = 6,  name = L"Level 21+",  sets = { "Mayhem", "Stalker", "Challenger" },            slots = { SLOTS.BOOTS, SLOTS.HANDS, SLOTS.SHOULDERS, SLOTS.HEAD, SLOTS.CHEST } },
	{ id = 7,  name = L"Renown 29+", sets = { "Duelist" },                                    slots = { SLOTS.BOOTS, SLOTS.HANDS, SLOTS.CHEST } },
	{ id = 8,  name = L"Renown 35+", sets = { "Annihilator" },                                slots = { SLOTS.BOOTS, SLOTS.HANDS, SLOTS.SHOULDERS, SLOTS.HEAD, SLOTS.CHEST } },
	{ id = 9,  name = L"Renown 38+", sets = { "Mercenary" },                                  slots = { SLOTS.BOOTS, SLOTS.HANDS, SLOTS.SHOULDERS, SLOTS.HEAD, SLOTS.CHEST } },
	{ id = 10, name = L"Level 40",   sets = { "Ruin" },                                       slots = { SLOTS.BOOTS, SLOTS.HANDS, SLOTS.SHOULDERS, SLOTS.HEAD, SLOTS.CHEST } },
	{ id = 11, name = L"Renown 45+", sets = { "Conqueror" },                                  slots = { SLOTS.BOOTS, SLOTS.HANDS, SLOTS.SHOULDERS, SLOTS.HEAD, SLOTS.CHEST } },
	{ id = 12, name = L"Level 40",   sets = { "Redeye" },                                     slots = { SLOTS.BOOTS, SLOTS.HANDS, SLOTS.SHOULDERS, SLOTS.HEAD, SLOTS.CHEST } },
	{ id = 13, name = L"Level 40",   sets = { "Beastlord" },                                  slots = { SLOTS.HEAD, SLOTS.SHOULDERS, SLOTS.CHEST, SLOTS.BACK, SLOTS.RING, SLOTS.POCKET } },
	{ id = 14, name = L"Renown 55+", sets = { "Vanquisher" },                                 slots = { SLOTS.BOOTS, SLOTS.HANDS, SLOTS.SHOULDERS, SLOTS.HEAD, SLOTS.CHEST, SLOTS.BACK } },
	{ id = 15, name = L"Level 40",   sets = { "Sentinel" },                                   slots = { SLOTS.BOOTS, SLOTS.HANDS, SLOTS.SHOULDERS, SLOTS.HEAD, SLOTS.CHEST, SLOTS.RING } },
	{ id = 16, name = L"Level 40",   sets = { "Vale-Walker" },                                slots = { SLOTS.BOOTS, SLOTS.HANDS, SLOTS.SHOULDERS, SLOTS.HEAD, SLOTS.CHEST } },
	{ id = 17, name = L"Renown 60+", sets = { "Oppressor" },                                  slots = { SLOTS.BOOTS, SLOTS.HANDS, SLOTS.SHOULDERS, SLOTS.HEAD, SLOTS.CHEST, SLOTS.RING } },
	{ id = 18, name = L"Renown 63+", sets = { "Dominator" },                                  slots = { SLOTS.BOOTS, SLOTS.HANDS, SLOTS.SHOULDERS, SLOTS.HEAD, SLOTS.CHEST, SLOTS.RING } },
	{ id = 19, name = L"Renown 65+", sets = { "Invader" },                                    slots = { SLOTS.BOOTS, SLOTS.HANDS, SLOTS.SHOULDERS, SLOTS.HEAD, SLOTS.CHEST, SLOTS.BACK, SLOTS.RING } },
	{ id = 20, name = L"Level 40",   sets = { "Bloodlord" },                                  slots = { SLOTS.BOOTS, SLOTS.HANDS, SLOTS.SHOULDERS, SLOTS.HEAD, SLOTS.CHEST, SLOTS.BACK } },
	{ id = 21, name = L"Renown 75+", sets = { "Warlord" },                                    slots = { SLOTS.BOOTS, SLOTS.HANDS, SLOTS.BELT, SLOTS.SHOULDERS, SLOTS.HEAD, SLOTS.CHEST, SLOTS.BACK, SLOTS.RING } },
	{ id = 22, name = L"Renown 80+", sets = { "Sovereign" },                                  slots = { SLOTS.BOOTS, SLOTS.HANDS, SLOTS.BELT, SLOTS.SHOULDERS, SLOTS.HEAD, SLOTS.CHEST, SLOTS.BACK, SLOTS.RING } },
	{ id = 23, name = L"Level 40",   sets = { "Darkpromise" },                                slots = { SLOTS.BOOTS, SLOTS.HANDS, SLOTS.BELT, SLOTS.SHOULDERS, SLOTS.HEAD, SLOTS.CHEST } },
	{ id = 24, name = L"Level 40",   sets = { "Tyrant" },                                     slots = { SLOTS.BOOTS, SLOTS.HANDS, SLOTS.BELT, SLOTS.SHOULDERS, SLOTS.HEAD, SLOTS.CHEST, SLOTS.BACK, SLOTS.RING } },
}

CBK.DungeonDrops = {
	{ dungeon = L"Dragonback Pass",      boss = L"Glump's Hoard",               set = L"Rare Unique Gear",      slot = L"Drop" },
	{ dungeon = L"Dragonback Pass",      boss = L"Custom Boss Loot",            set = L"Purple Weapons",        slot = L"Lvl 9-11" },
	{ dungeon = L"Dragonback Pass",      boss = L"Dungeon Quest",               set = L"Unique Faction Cloaks", slot = L"Drop" },
	{ dungeon = L"Sewers / Sacellum",    boss = L"All Bosses",                  set = L"Keeper's Boots",        slot = L"Drop" },
	{ dungeon = L"Sewers / Sacellum",    boss = L"All Bosses",                  set = L"Keeper's Gloves",       slot = L"Drop" },
	{ dungeon = L"Sewers / Sacellum",    boss = L"All Bosses",                  set = L"Keeper's Shoulders",    slot = L"Drop" },
	{ dungeon = L"Sewers / Sacellum",    boss = L"All Bosses",                  set = L"Keeper's Helm",         slot = L"Drop" },
	{ dungeon = L"Sewers / Sacellum",    boss = L"All Bosses",                  set = L"Keeper's Chest",        slot = L"Drop" },
	{ dungeon = L"Mount Gunbad",         boss = L"Gunbad PQ Gold Bags",         set = L"Redeye Boots",          slot = L"Drop" },
	{ dungeon = L"Mount Gunbad",         boss = L"Gunbad PQ Gold Bags",         set = L"Redeye Gloves",         slot = L"Drop" },
	{ dungeon = L"Mount Gunbad",         boss = L"Glomp da Squig Masta",        set = L"Redeye Shoulders",      slot = L"Drop" },
	{ dungeon = L"Mount Gunbad",         boss = L"Herald of Solithex/Mixa",     set = L"Redeye Helm",           slot = L"Drop" },
	{ dungeon = L"Mount Gunbad",         boss = L"Arathremia",                  set = L"Redeye Chest",          slot = L"Drop" },
	{ dungeon = L"Mount Gunbad",         boss = L"Dungeon Vendor/Quest",        set = L"Madcap Weapons",        slot = L"Drop" },
	{ dungeon = L"Warpblade / Bilerot",  boss = L"Wing 1",                      set = L"Sentinel Boots",        slot = L"Drop" },
	{ dungeon = L"Warpblade / Bilerot",  boss = L"Wing 1",                      set = L"Sentinel Gloves",       slot = L"Drop" },
	{ dungeon = L"Warpblade / Bilerot",  boss = L"Wing 2",                      set = L"Sentinel Shoulders",    slot = L"Drop" },
	{ dungeon = L"Warpblade / Bilerot",  boss = L"Wing 2",                      set = L"Sentinel Helm",         slot = L"Drop" },
	{ dungeon = L"Warpblade / Bilerot",  boss = L"Final Wing",                  set = L"Sentinel Chest",        slot = L"Drop" },
	{ dungeon = L"Warpblade / Bilerot",  boss = L"Dungeon Influence T1 & T2",   set = L"Sentinel Weapons",      slot = L"Drop" },
	{ dungeon = L"Warpblade / Bilerot",  boss = L"Dungeon Influence T3",        set = L"Sentinel Ring",         slot = L"Drop" },
	{ dungeon = L"Hunter's Vale",        boss = L"Early Aspect Bosses",         set = L"Vale-Walker Boots",     slot = L"Drop" },
	{ dungeon = L"Hunter's Vale",        boss = L"Early Aspect Bosses",         set = L"Vale-Walker Gloves",    slot = L"Drop" },
	{ dungeon = L"Hunter's Vale",        boss = L"Mid Aspect Bosses",           set = L"Vale-Walker Shoulders", slot = L"Drop" },
	{ dungeon = L"Hunter's Vale",        boss = L"Mid Aspect Bosses",           set = L"Vale-Walker Helm",      slot = L"Drop" },
	{ dungeon = L"Hunter's Vale",        boss = L"Great Stag / Final Spirit",   set = L"Vale-Walker Chest",     slot = L"Drop" },
	{ dungeon = L"Bastion Stair",        boss = L"Thar'Ignan",                  set = L"Bloodlord Boots",       slot = L"Drop" },
	{ dungeon = L"Bastion Stair",        boss = L"Trash/Mini-Bosses",           set = L"Bloodlord Gloves",      slot = L"Drop" },
	{ dungeon = L"Bastion Stair",        boss = L"Lord Slaurith",               set = L"Bloodlord Shoulders",   slot = L"Drop" },
	{ dungeon = L"Bastion Stair",        boss = L"Kaarn the Vanquisher",        set = L"Bloodlord Helm",        slot = L"Drop" },
	{ dungeon = L"Bastion Stair",        boss = L"Skull Lord Var'ithrok",       set = L"Bloodlord Chest",       slot = L"Drop" },
	{ dungeon = L"Bastion Stair",        boss = L"Dungeon Influence T1 & T2",   set = L"Bloodlord Weapons",     slot = L"Drop" },
	{ dungeon = L"Bastion Stair",        boss = L"Dungeon Influence T3",        set = L"Bloodlord Cape",        slot = L"Drop" },
	{ dungeon = L"Lost Vale",            boss = L"Dralel",                      set = L"Darkpromise Boots",     slot = L"Drop" },
	{ dungeon = L"Lost Vale",            boss = L"Trash/Mini-Bosses",           set = L"Darkpromise Gloves",    slot = L"Drop" },
	{ dungeon = L"Lost Vale",            boss = L"Trash/Mini-Bosses",           set = L"Darkpromise Belt",      slot = L"Drop" },
	{ dungeon = L"Lost Vale",            boss = L"Sarathaine",                  set = L"Darkpromise Shoulders", slot = L"Drop" },
	{ dungeon = L"Lost Vale",            boss = L"Sechar",                      set = L"Darkpromise Helm",      slot = L"Drop" },
	{ dungeon = L"Lost Vale",            boss = L"N'kari",                      set = L"Darkpromise Chest",     slot = L"Drop" },
	{ dungeon = L"Tomb of Vulture Lord", boss = L"Tomb Mini-Bosses",            set = L"Tyrant Boots",          slot = L"Drop" },
	{ dungeon = L"Tomb of Vulture Lord", boss = L"Tomb Mini-Bosses",            set = L"Tyrant Gloves",         slot = L"Drop" },
	{ dungeon = L"Tomb of Vulture Lord", boss = L"Hierophant Primates",         set = L"Tyrant Shoulders",      slot = L"Drop" },
	{ dungeon = L"Tomb of Vulture Lord", boss = L"Hand of Ualatp",              set = L"Tyrant Helm",           slot = L"Drop" },
	{ dungeon = L"Tomb of Vulture Lord", boss = L"King Akhenut",                set = L"Tyrant Chest",          slot = L"Drop" },
	{ dungeon = L"Tomb of Vulture Lord", boss = L"Tomb Urns & Coffins",         set = L"Unique Pocket Items",   slot = L"Drop" },
	{ dungeon = L"Tomb of Vulture Lord", boss = L"Tomb Urns & Coffins",         set = L"Cape Upgrades",         slot = L"Drop" },
}

local WINDOW      = "CheckerByEgyptianKoziWindow"
local RESCAN_DELAY = 0.25

local initialized   = false
local uiBuilt       = false
local scanPending   = false
local scanTimer     = 0
local searchQuery   = ""
local activeDungeon = "ALL"
local activeTab     = "player"

local playerRowCount = 0
local dropRowCount   = 0

local function ToString(value)
	if value == nil then return "" end
	local t = type(value)
	if t == "string" then return value end
	if t == "wstring" then
		local ok, str = pcall(WStringToString, value)
		if ok and str then return str end
	end
	return tostring(value)
end

local function CleanItemName(rawName)
	local s = ToString(rawName)
	s = string.match(s, "([^^]+)") or s
	return string.lower(s)
end

local function EscapePattern(s)
	return (string.gsub(s, "(%W)", "%%%1"))
end

local setPatterns = {}
local setToWard   = {}

local function BuildSetPattern(setName)
	local parts = {}
	for run in string.gmatch(string.lower(setName), "%w+") do
		parts[#parts + 1] = run
	end
	return "%f[%w]" .. table.concat(parts, "[%W]*") .. "%f[%W]"
end

for _, ward in ipairs(CBK.Wards) do
	for _, setName in ipairs(ward.sets) do
		setPatterns[setName] = BuildSetPattern(setName)
		setToWard[setName]   = ward
	end
end

local equipKeyToSlot = {
	HEAD = SLOTS.HEAD,           HELM = SLOTS.HEAD,
	SHOULDERS = SLOTS.SHOULDERS, SHOULDER = SLOTS.SHOULDERS,
	CHEST = SLOTS.CHEST,         BODY = SLOTS.CHEST,        TORSO = SLOTS.CHEST,
	HANDS = SLOTS.HANDS,         GLOVES = SLOTS.HANDS,
	BELT = SLOTS.BELT,           WAIST = SLOTS.BELT,
	BOOTS = SLOTS.BOOTS,         FEET = SLOTS.BOOTS,
	BACK = SLOTS.BACK,           CAPE = SLOTS.BACK,         CLOAK = SLOTS.BACK,
	RING1 = SLOTS.RING,          RING2 = SLOTS.RING,        RING = SLOTS.RING,
	LEFTRING = SLOTS.RING,       RIGHTRING = SLOTS.RING,
	JEWELLERYSLOT1 = SLOTS.RING, JEWELLERYSLOT2 = SLOTS.RING,
	JEWELLERYSLOT3 = SLOTS.RING, JEWELLERYSLOT4 = SLOTS.RING,
	POCKET1 = SLOTS.POCKET,      POCKET2 = SLOTS.POCKET,    POCKET = SLOTS.POCKET,
	LEFTPOCKET = SLOTS.POCKET,   RIGHTPOCKET = SLOTS.POCKET,
	POCKETITEM1 = SLOTS.POCKET,  POCKETITEM2 = SLOTS.POCKET,
}

local slotKeywordOrder = {
	{ slot = SLOTS.BACK,      words = { "cape", "cloak", "wrap", "back", "shroud", "drape", "mantling" } },
	{ slot = SLOTS.HEAD,      words = { "helm", "helmet", "crown", "hood", "cap", "coif", "visor", "mask", "circlet", "casque", "cowl", "sallet", "bascinet", "armet", "barbuta", "cabasset", "faceguard", "hat", "headguard", "headpiece", "headband", "vizard", "galea" } },
	{ slot = SLOTS.SHOULDERS, words = { "shoulders", "shoulderguards", "shoulderpads", "shoulder", "pauldrons", "pauldron", "spaulders", "spaulder", "epaulets", "epaulet", "amice", "mantle" } },
	{ slot = SLOTS.CHEST,     words = { "chest", "breastplate", "robe", "tunic", "cuirass", "coat", "chestplate", "jerkin", "vestment", "hauberk", "corset", "mail", "vest", "doublet", "brigandine", "gambeson", "garment", "harness", "jacket", "plate", "armor", "armour", "body", "torso" } },
	{ slot = SLOTS.HANDS,     words = { "gloves", "glove", "gauntlets", "gauntlet", "hands", "handguards", "fists", "mittens", "mitts", "grips", "cuffs", "bracers", "vambraces", "wristguards", "wristbands" } },
	{ slot = SLOTS.BELT,      words = { "belt", "girdle", "sash", "waistband", "cord", "cinch", "cincture", "waistguard" } },
	{ slot = SLOTS.BOOTS,     words = { "boots", "boot", "greaves", "greave", "sabatons", "sabaton", "shoes", "footguards", "sollerets", "treads", "stompers", "walkers" } },
	{ slot = SLOTS.RING,      words = { "ring", "band", "signet", "loop", "seal" } },
	{ slot = SLOTS.POCKET,    words = { "pocket", "fragment", "talisman", "insignia", "token", "trinket", "medallion", "guide", "book", "charm", "icon", "scroll", "vial", "flask", "idol", "effigy", "totem", "fetish", "horn" } },
}

for _, entry in ipairs(slotKeywordOrder) do
	local patterns = {}
	for i, word in ipairs(entry.words) do
		patterns[i] = EscapePattern(word) .. "%f[%W]"
	end
	entry.patterns = patterns
end

local function DetectSlotFromName(nameLower)
	for _, entry in ipairs(slotKeywordOrder) do
		for _, pattern in ipairs(entry.patterns) do
			if string.find(nameLower, pattern) then
				return entry.slot
			end
		end
	end
	return nil
end

local equipSlotIdToSlot = nil
local function GetEquipSlotIdMap()
	if equipSlotIdToSlot then return equipSlotIdToSlot end
	equipSlotIdToSlot = {}
	if GameData and GameData.EquipSlots then
		for slotKey, slotId in pairs(GameData.EquipSlots) do
			local cleanKey = string.gsub(string.upper(tostring(slotKey)), "[_%s]", "")
			local slot = equipKeyToSlot[cleanKey]
			if slot then
				equipSlotIdToSlot[slotId] = slot
			end
		end
	end
	return equipSlotIdToSlot
end

local function EnsureSettings()
	CBK.Settings = CBK.Settings or {}
	CBK.Settings.collected = CBK.Settings.collected or {}
	for _, ward in ipairs(CBK.Wards) do
		for _, setName in ipairs(ward.sets) do
			CBK.Settings.collected[setName] = CBK.Settings.collected[setName] or {}
		end
	end
end

local scanDebug = false
local debugLines = {}

local function TryMatchItem(rawName, knownSlot, item)
	local nameLower = CleanItemName(rawName)
	if nameLower == "" then return end

	for setName, pattern in pairs(setPatterns) do
		if string.find(nameLower, pattern) then
			local slot = knownSlot
			if not slot and item and item.equipSlot then
				slot = GetEquipSlotIdMap()[item.equipSlot]
			end
			if not slot then
				slot = DetectSlotFromName(nameLower)
			end

			local marked = false
			if slot then
				local ward = setToWard[setName]
				for _, wardSlot in ipairs(ward.slots) do
					if wardSlot == slot then
						CBK.Settings.collected[setName][slot] = true
						marked = true
						break
					end
				end
			end

			if scanDebug then
				local slotText = slot and ToString(SLOT_NAMES[slot]) or "UNRESOLVED"
				debugLines[#debugLines + 1] = string.format("%s -> set %s, slot %s%s",
					nameLower, setName, slotText, marked and "" or " (not counted)")
			end
		end
	end
end

local function ScanItemContainer(container)
	if type(container) ~= "table" then return end
	for _, v in pairs(container) do
		if type(v) == "table" then
			if v.name then
				TryMatchItem(v.name, nil, v)
			else
				for _, item in pairs(v) do
					if type(item) == "table" and item.name then
						TryMatchItem(item.name, nil, item)
					end
				end
			end
		end
	end
end

function CheckerByEgyptianKozi.ScanPlayerEquipment()
	EnsureSettings()

	if DataUtils and DataUtils.GetEquipmentData then
		local equipment = DataUtils.GetEquipmentData()
		if equipment and GameData.EquipSlots then
			for slotKey, slotId in pairs(GameData.EquipSlots) do
				local item = equipment[slotId]
				if item and item.name then
					local cleanKey = string.gsub(string.upper(tostring(slotKey)), "[_%s]", "")
					TryMatchItem(item.name, equipKeyToSlot[cleanKey], item)
				end
			end
		end
	end

	if DataUtils and DataUtils.GetItems then
		ScanItemContainer(DataUtils.GetItems())
	end

	if DataUtils and DataUtils.GetBankData then
		ScanItemContainer(DataUtils.GetBankData())
	end
end

function CheckerByEgyptianKozi.RequestRescan()
	scanPending = true
	scanTimer   = 0
end

function CheckerByEgyptianKozi.OnItemsChanged()
	CheckerByEgyptianKozi.RequestRescan()
end

local function WardPieceThreshold(numSlots)
	if numSlots <= 3 then return numSlots end
	if numSlots <= 5 then return 4 end
	return 5
end

function CheckerByEgyptianKozi.GetWardSummary()
	EnsureSettings()
	local bestWardId = 0
	local bestSet, bestPieces, bestTotal = nil, 0, 0

	for _, ward in ipairs(CBK.Wards) do
		local total = #ward.slots
		local threshold = WardPieceThreshold(total)
		for _, setName in ipairs(ward.sets) do
			local pieces = 0
			local collected = CBK.Settings.collected[setName]
			for _, slot in ipairs(ward.slots) do
				if collected[slot] then pieces = pieces + 1 end
			end
			if pieces >= threshold and ward.id > bestWardId then
				bestWardId = ward.id
			end
			if pieces > 0 and (bestSet == nil or (pieces / total) >= (bestPieces / bestTotal)) then
				bestSet, bestPieces, bestTotal = setName, pieces, total
			end
		end
	end
	return bestWardId, bestSet, bestPieces, bestTotal
end

local dungeonFilters = {
	{ suffix = "All",        label = L"All",        key = "ALL" },
	{ suffix = "Dragonback", label = L"Dragonback", key = "Dragonback Pass" },
	{ suffix = "Sewers",     label = L"Sewers",     key = "Sewers / Sacellum" },
	{ suffix = "Gunbad",     label = L"Gunbad",     key = "Mount Gunbad" },
	{ suffix = "Bilerot",    label = L"Bilerot",    key = "Warpblade / Bilerot" },
	{ suffix = "HV",         label = L"HV",         key = "Hunter's Vale" },
	{ suffix = "BS",         label = L"BS",         key = "Bastion Stair" },
	{ suffix = "LV",         label = L"LV",         key = "Lost Vale" },
	{ suffix = "Tomb",       label = L"Tomb",       key = "Tomb of Vulture Lord" },
}

local function BuildUI()
	if uiBuilt then return end

	CreateWindow(WINDOW, false)
	WindowSetDimensions(WINDOW, 740, 520)

	LayoutEditor.RegisterWindow(WINDOW,
		L"CheckerByEgyptianKozi",
		L"Gear and Ward progression tracker",
		false,
		true,
		true,
		nil)

	LabelSetText(WINDOW .. "TitleBarText", L"CheckerByEgyptianKozi")
	LabelSetText(WINDOW .. "TabPlayerText", L"My Progression")
	LabelSetText(WINDOW .. "TabDbText", L"Dungeon Drops")
	LabelSetText(WINDOW .. "SearchLabel", L"Search:")

	for _, filter in ipairs(dungeonFilters) do
		LabelSetText(WINDOW .. "DbTabFilter" .. filter.suffix .. "Text", filter.label)
	end

	local parent = WINDOW .. "PlayerTabScrollChild"
	local index, yOffset = 1, 10
	for _, ward in ipairs(CBK.Wards) do
		for _ = 1, #ward.sets do
			local rowName = parent .. "Set" .. index
			CreateWindowFromTemplate(rowName, "CheckerByEgyptianKoziSetTemplate", parent)
			WindowClearAnchors(rowName)
			WindowAddAnchor(rowName, "topleft", parent, "topleft", 10, yOffset)
			WindowSetTintColor(rowName .. "Bg", (index % 2 == 0) and 30 or 20, (index % 2 == 0) and 30 or 20, (index % 2 == 0) and 35 or 22)
			yOffset = yOffset + 75
			index = index + 1
		end
	end
	playerRowCount = index - 1
	WindowSetDimensions(parent, 650, yOffset + 20)
	ScrollWindowUpdateScrollRect(WINDOW .. "PlayerTab")

	uiBuilt = true
	CheckerByEgyptianKozi.SetActiveTab("player")
end

function CheckerByEgyptianKozi.RefreshUI()
	if not uiBuilt or not DoesWindowExist(WINDOW) then return end
	if not WindowGetShowing(WINDOW) then return end
	if activeTab == "player" then
		CheckerByEgyptianKozi.RefreshPlayerUI()
	else
		CheckerByEgyptianKozi.RefreshDatabaseUI()
	end
end

function CheckerByEgyptianKozi.RefreshPlayerUI()
	local parent = WINDOW .. "PlayerTabScrollChild"
	if not DoesWindowExist(parent) then return end
	EnsureSettings()

	local index = 1
	for _, ward in ipairs(CBK.Wards) do
		for _, setName in ipairs(ward.sets) do
			local rowName = parent .. "Set" .. index
			LabelSetText(rowName .. "Name", towstring(setName) .. L"  (" .. ward.name .. L")")

			local collected = CBK.Settings.collected[setName]
			local count, total = 0, #ward.slots

			for slotIdx = 1, 8 do
				local slotLabel = rowName .. "Slot" .. slotIdx
				local slotType = ward.slots[slotIdx]
				if slotType then
					WindowSetShowing(slotLabel, true)
					LabelSetText(slotLabel, SLOT_NAMES[slotType])
					if collected[slotType] then
						count = count + 1
						LabelSetTextColor(slotLabel, 50, 255, 50)
					else
						LabelSetTextColor(slotLabel, 180, 180, 180)
					end
				else
					WindowSetShowing(slotLabel, false)
				end
			end

			LabelSetText(rowName .. "ProgressText", towstring(count) .. L"/" .. towstring(total))
			if count >= total then
				LabelSetTextColor(rowName .. "ProgressText", 50, 255, 50)
			else
				LabelSetTextColor(rowName .. "ProgressText", 220, 220, 220)
			end

			index = index + 1
		end
	end
end

function CheckerByEgyptianKozi.RefreshDatabaseUI()
	local parent = WINDOW .. "DbTabListScrollChild"
	if not DoesWindowExist(parent) then return end

	local index, yOffset = 1, 5

	for _, drop in ipairs(CBK.DungeonDrops) do
		local dungeonStr = ToString(drop.dungeon)
		local matchesDungeon = (activeDungeon == "ALL") or (dungeonStr == activeDungeon)
		local matchesSearch = true
		if searchQuery ~= "" then
			matchesSearch =
				string.find(string.lower(ToString(drop.boss)),    searchQuery, 1, true) ~= nil or
				string.find(string.lower(ToString(drop.set)),     searchQuery, 1, true) ~= nil or
				string.find(string.lower(dungeonStr),             searchQuery, 1, true) ~= nil
		end

		if matchesDungeon and matchesSearch then
			local rowName = parent .. "Drop" .. index
			if index > dropRowCount then
				CreateWindowFromTemplate(rowName, "CheckerByEgyptianKoziDropTemplate", parent)
				dropRowCount = index
			end
			WindowClearAnchors(rowName)
			WindowAddAnchor(rowName, "topleft", parent, "topleft", 0, yOffset)
			WindowSetShowing(rowName, true)

			LabelSetText(rowName .. "Dungeon", drop.dungeon)
			LabelSetText(rowName .. "Boss", drop.boss)
			LabelSetText(rowName .. "Set", drop.set .. L"  (" .. drop.slot .. L")")

			local shade = (index % 2 == 0)
			WindowSetTintColor(rowName .. "Bg", shade and 30 or 20, shade and 30 or 20, shade and 35 or 22)

			yOffset = yOffset + 35
			index = index + 1
		end
	end

	for i = index, dropRowCount do
		WindowSetShowing(parent .. "Drop" .. i, false)
	end

	WindowSetDimensions(parent, 650, yOffset + 10)
	ScrollWindowUpdateScrollRect(WINDOW .. "DbTabList")

	for _, filter in ipairs(dungeonFilters) do
		local label = WINDOW .. "DbTabFilter" .. filter.suffix .. "Text"
		if filter.key == activeDungeon then
			LabelSetTextColor(label, 255, 218, 73)
		else
			LabelSetTextColor(label, 220, 220, 220)
		end
	end
end

function CheckerByEgyptianKozi.SetActiveTab(tab)
	activeTab = tab
	local onPlayer = (tab == "player")
	WindowSetShowing(WINDOW .. "PlayerTab", onPlayer)
	WindowSetShowing(WINDOW .. "DbTab", not onPlayer)
	WindowSetShowing(WINDOW .. "SearchLabel", not onPlayer)
	WindowSetShowing(WINDOW .. "SearchInput", not onPlayer)
	LabelSetTextColor(WINDOW .. "TabPlayerText", onPlayer and 255 or 160, onPlayer and 218 or 160, onPlayer and 73 or 160)
	LabelSetTextColor(WINDOW .. "TabDbText", onPlayer and 160 or 255, onPlayer and 160 or 218, onPlayer and 160 or 73)

	if onPlayer then
		CheckerByEgyptianKozi.RefreshPlayerUI()
	else
		CheckerByEgyptianKozi.RefreshDatabaseUI()
	end
end

function CheckerByEgyptianKozi.OnTabPlayerClick()
	CheckerByEgyptianKozi.SetActiveTab("player")
end

function CheckerByEgyptianKozi.OnTabDbClick()
	CheckerByEgyptianKozi.SetActiveTab("db")
end

function CheckerByEgyptianKozi.OnSearchTextChanged()
	local text = TextEditBoxGetText(WINDOW .. "SearchInput")
	searchQuery = string.lower(ToString(text))
	ScrollWindowSetOffset(WINDOW .. "DbTabList", 0)
	CheckerByEgyptianKozi.RefreshDatabaseUI()
end

function CheckerByEgyptianKozi.OnDungeonFilterClick()
	local clicked = SystemData.ActiveWindow.name
	for _, filter in ipairs(dungeonFilters) do
		if clicked == WINDOW .. "DbTabFilter" .. filter.suffix then
			activeDungeon = filter.key
			ScrollWindowSetOffset(WINDOW .. "DbTabList", 0)
			CheckerByEgyptianKozi.RefreshDatabaseUI()
			return
		end
	end
end

function CheckerByEgyptianKozi.HideUI()
	if DoesWindowExist(WINDOW) then
		WindowAssignFocus(WINDOW, false)
		WindowSetShowing(WINDOW, false)
	end
end

function CheckerByEgyptianKozi.ToggleUI()
	if not uiBuilt then return end
	if WindowGetShowing(WINDOW) then
		CheckerByEgyptianKozi.HideUI()
	else
		WindowSetShowing(WINDOW, true)
		CheckerByEgyptianKozi.ScanPlayerEquipment()
		if activeTab == "player" then
			CheckerByEgyptianKozi.RefreshPlayerUI()
		else
			CheckerByEgyptianKozi.RefreshDatabaseUI()
		end
	end
end

local function Print(msg)
	EA_ChatWindow.Print(towstring("[CheckerByEgyptianKozi] " .. msg))
end

function CheckerByEgyptianKozi.SlashCommand(args)
	local argStr = string.lower(ToString(args) or "")
	argStr = string.gsub(argStr, "^%s+", "")

	if argStr == "" then
		CheckerByEgyptianKozi.ToggleUI()

	elseif string.find(argStr, "^scan") then
		CheckerByEgyptianKozi.ScanPlayerEquipment()
		CheckerByEgyptianKozi.RefreshUI()
		Print("Gear, bag and bank scan completed.")

	elseif string.find(argStr, "^report") then
		CheckerByEgyptianKozi.ScanPlayerEquipment()
		local wardId, bestSet, pieces, total = CheckerByEgyptianKozi.GetWardSummary()
		local reply
		if bestSet then
			reply = towstring(string.format("[Checker] Ward Tier %d - best set: %s (%d/%d pieces)", wardId, bestSet, pieces, total))
		else
			reply = L"[Checker] Ward Tier 0 - no set pieces collected yet"
		end
		local pname = wstring.match(GameData.Player.name, L"([^%^]+)") or GameData.Player.name
		SendChatText(pname .. L": " .. reply, L"")

	elseif string.find(argStr, "^debug") then
		scanDebug = true
		debugLines = {}
		CheckerByEgyptianKozi.ScanPlayerEquipment()
		scanDebug = false
		Print("Scan diagnostics (" .. tostring(#debugLines) .. " set-item matches):")
		for _, line in ipairs(debugLines) do
			Print("  " .. line)
		end
		debugLines = {}
		CheckerByEgyptianKozi.RefreshUI()

	elseif string.find(argStr, "^reset") then
		CBK.Settings.collected = {}
		EnsureSettings()
		CheckerByEgyptianKozi.ScanPlayerEquipment()
		CheckerByEgyptianKozi.RefreshUI()
		Print("Saved progression cleared and rebuilt from a fresh scan.")

	else
		Print("Commands:")
		Print("  /checker          - toggle the tracker window")
		Print("  /checker scan     - rescan gear, bags and bank now")
		Print("  /checker report   - broadcast your ward tier to chat")
		Print("  /checker debug    - list every set item found and its resolved slot")
		Print("  /checker reset    - wipe saved progression and rescan")
	end
end

function CheckerByEgyptianKozi.Initialize()
	EnsureSettings()
	RegisterEventHandler(SystemData.Events.PLAYER_CAREER_LINE_UPDATED, "CheckerByEgyptianKozi.OnCareerReady")
	RegisterEventHandler(SystemData.Events.INTERFACE_RELOADED, "CheckerByEgyptianKozi.OnCareerReady")
	RegisterEventHandler(SystemData.Events.LOADING_END, "CheckerByEgyptianKozi.OnCareerReady")
end

function CheckerByEgyptianKozi.OnCareerReady()
	if initialized then return end
	if not GameData.Player.career or not GameData.Player.career.line or GameData.Player.career.line < 1 then
		return
	end
	initialized = true

	UnregisterEventHandler(SystemData.Events.PLAYER_CAREER_LINE_UPDATED, "CheckerByEgyptianKozi.OnCareerReady")
	UnregisterEventHandler(SystemData.Events.INTERFACE_RELOADED, "CheckerByEgyptianKozi.OnCareerReady")
	UnregisterEventHandler(SystemData.Events.LOADING_END, "CheckerByEgyptianKozi.OnCareerReady")

	BuildUI()

	if SystemData.Events.PLAYER_EQUIPMENT_SLOT_UPDATED then
		RegisterEventHandler(SystemData.Events.PLAYER_EQUIPMENT_SLOT_UPDATED, "CheckerByEgyptianKozi.OnItemsChanged")
	end
	if SystemData.Events.PLAYER_INVENTORY_SLOT_UPDATED then
		RegisterEventHandler(SystemData.Events.PLAYER_INVENTORY_SLOT_UPDATED, "CheckerByEgyptianKozi.OnItemsChanged")
	end
	if SystemData.Events.SYSTEM_DATA_ITEMS_CHANGED then
		RegisterEventHandler(SystemData.Events.SYSTEM_DATA_ITEMS_CHANGED, "CheckerByEgyptianKozi.OnItemsChanged")
	end

	if LibSlash then
		if not LibSlash.IsSlashCmdRegistered("checker") then
			LibSlash.RegisterSlashCmd("checker", CheckerByEgyptianKozi.SlashCommand)
		end
		if not LibSlash.IsSlashCmdRegistered("checkerbyegyptiankozi") then
			LibSlash.RegisterSlashCmd("checkerbyegyptiankozi", CheckerByEgyptianKozi.SlashCommand)
		end
	else
		Print("LibSlash not found - slash commands unavailable. Use the Layout Editor to place the window.")
	end

	CheckerByEgyptianKozi.ScanPlayerEquipment()
	Print("v1.0.0 loaded. /checker to open.")
end

function CheckerByEgyptianKozi.Update(elapsed)
	if not scanPending then return end
	scanTimer = scanTimer + (elapsed or 0)
	if scanTimer < RESCAN_DELAY then return end
	scanPending = false
	scanTimer = 0
	CheckerByEgyptianKozi.ScanPlayerEquipment()
	CheckerByEgyptianKozi.RefreshUI()
end

function CheckerByEgyptianKozi.Shutdown()
end
