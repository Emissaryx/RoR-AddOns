<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
	<UiMod name="CheckerByEgyptianKozi" version="1.0.0" date="16/07/2026">

		<Author name="EgyptianKozi" email="" />
		<Description text="Tracks endgame gear and Ward progression: scans equipped gear, bags and bank in real time, and shows a searchable dungeon-drop database." />

		<VersionSettings gameVersion="1.4.8" windowsVersion="1.0" savedVariablesVersion="1.0" />

		<Dependencies>
			<Dependency name="EATemplate_DefaultWindowSkin" />
			<Dependency name="EASystem_Utils" />
			<Dependency name="EASystem_WindowUtils" />
			<Dependency name="EASystem_LayoutEditor" />
			<Dependency name="EA_ChatWindow" />
			<Dependency name="LibSlash" optional="true" forceEnable="true" />
		</Dependencies>

		<Files>
			<File name="CheckerByEgyptianKozi.xml" />
			<File name="CheckerByEgyptianKozi.lua" />
		</Files>

		<SavedVariables>
			<SavedVariable name="CheckerByEgyptianKozi.Settings" />
		</SavedVariables>

		<OnInitialize>
			<CallFunction name="CheckerByEgyptianKozi.Initialize" />
		</OnInitialize>
		<OnUpdate>
			<CallFunction name="CheckerByEgyptianKozi.Update" />
		</OnUpdate>
		<OnShutdown>
			<CallFunction name="CheckerByEgyptianKozi.Shutdown" />
		</OnShutdown>

		<WARInfo>
			<Categories>
				<Category name="ITEMS_INVENTORY" />
				<Category name="SYSTEM" />
				<Category name="OTHER" />
			</Categories>
			<Careers>
				<Career name="BLACKGUARD" />
				<Career name="WITCH_ELF" />
				<Career name="DISCIPLE" />
				<Career name="SORCERER" />
				<Career name="IRON_BREAKER" />
				<Career name="SLAYER" />
				<Career name="RUNE_PRIEST" />
				<Career name="ENGINEER" />
				<Career name="BLACK_ORC" />
				<Career name="CHOPPA" />
				<Career name="SHAMAN" />
				<Career name="SQUIG_HERDER" />
				<Career name="WITCH_HUNTER" />
				<Career name="KNIGHT" />
				<Career name="BRIGHT_WIZARD" />
				<Career name="WARRIOR_PRIEST" />
				<Career name="CHOSEN" />
				<Career name="MARAUDER" />
				<Career name="ZEALOT" />
				<Career name="MAGUS" />
				<Career name="SWORDMASTER" />
				<Career name="SHADOW_WARRIOR" />
				<Career name="WHITE_LION" />
				<Career name="ARCHMAGE" />
			</Careers>
		</WARInfo>

	</UiMod>
</ModuleFile>
