# CheckerByEgyptianKozi

Gear & Ward progression tracker for **Warhammer Online: Return of Reckoning**.

Scans your equipped gear, inventory bags and bank vault in real time, matches
items against the 24 known progression sets (Decimator through Sovereign/Tyrant),
and shows:

- **My Progression** — every set with its pieces; obtained slots light up green.
- **Dungeon Drops** — a searchable, filterable database of which boss drops what.

## Installation

1. Copy the `CheckerByEgyptianKozi` folder into
   `<game folder>\Interface\AddOns\`
2. Log in (or `/reloadui`) and enable the addon in the addon list if needed.
3. For slash commands, the **LibSlash** addon must also be installed (optional
   but recommended).

## Usage

| Command | Effect |
|---|---|
| `/checker` | Toggle the tracker window |
| `/checker scan` | Rescan gear, bags and bank immediately |
| `/checker report` | Broadcast your ward tier to chat |
| `/checker debug` | List every detected set item and its resolved slot |
| `/checker reset` | Wipe saved progression and rescan from scratch |

Notes:
- Scanning is automatic — equipping, looting, buying or banking items updates
  the tracker instantly.
- Bank contents can only be read after you have opened the bank once per session.
- Progression is saved per character and survives `/reloadui` and logout.

## License

Copyright (c) 2026 EgyptianKozi. All rights reserved.
Redistribution or reuse of this code without the author's permission is not allowed.
