--[[
	CheckerByEgyptianKozi - Gear and Ward Progression Tracker
	Warhammer Online: Return of Reckoning Addon
--]]

CheckerByEgyptianKozi = CheckerByEgyptianKozi or {}
local CBK = CheckerByEgyptianKozi

-- Constants for slot indices
local SLOTS = {
    HEAD = 1,
    SHOULDERS = 2,
    CHEST = 3,
    HANDS = 4,
    BELT = 5,
    BOOTS = 6,
    BACK = 7,
    RING = 8,
    POCKET = 9
}
CBK.SLOTS = SLOTS

local SLOT_NAMES = {
    [SLOTS.HEAD] = L"Helm",
    [SLOTS.SHOULDERS] = L"Shoulders",
    [SLOTS.CHEST] = L"Chest",
    [SLOTS.HANDS] = L"Gloves",
    [SLOTS.BELT] = L"Belt",
    [SLOTS.BOOTS] = L"Boots",
    [SLOTS.BACK] = L"Cape",
    [SLOTS.RING] = L"Ring",
    [SLOTS.POCKET] = L"Pocket"
}
CBK.SLOT_NAMES = SLOT_NAMES

-- Set progression ordered by Renown Rank requirement.
-- Each ward group appears as "(GroupName)" after the set name in the UI row.
CBK.Wards = {
    -- Tier 1 to Tier 3 Sets (Early & Mid-Game Leveling)
    { id = 1,  name = L"Renown 1+",  sets = { "Decimator", "Braggart", "Carnage", "Havoc" }, slots = { SLOTS.BOOTS, SLOTS.HANDS, SLOTS.CHEST } },
    { id = 2,  name = L"Level 1+",   sets = { "Hunter", "Tracker", "Protector" }, slots = { SLOTS.BOOTS, SLOTS.HANDS, SLOTS.CHEST } },
    { id = 3,  name = L"Renown 10+", sets = { "Obliterator" }, slots = { SLOTS.BOOTS, SLOTS.HANDS, SLOTS.CHEST } },
    { id = 4,  name = L"Level 16+",  sets = { "Keeper" }, slots = { SLOTS.BOOTS, SLOTS.HANDS, SLOTS.SHOULDERS, SLOTS.HEAD, SLOTS.CHEST } },
    { id = 5,  name = L"Renown 20+", sets = { "Devastator" }, slots = { SLOTS.BOOTS, SLOTS.HANDS, SLOTS.CHEST } },
    { id = 6,  name = L"Level 21+",  sets = { "Mayhem", "Stalker", "Challenger" }, slots = { SLOTS.BOOTS, SLOTS.HANDS, SLOTS.SHOULDERS, SLOTS.HEAD, SLOTS.CHEST } },
    { id = 7,  name = L"Renown 29+", sets = { "Duelist" }, slots = { SLOTS.BOOTS, SLOTS.HANDS, SLOTS.CHEST } },
    
    -- Tier 4 Starter Sets (Fresh Rank 40)
    { id = 8,  name = L"Renown 35+", sets = { "Annihilator" }, slots = { SLOTS.BOOTS, SLOTS.HANDS, SLOTS.SHOULDERS, SLOTS.HEAD, SLOTS.CHEST } },
    { id = 9,  name = L"Renown 38+", sets = { "Mercenary" }, slots = { SLOTS.BOOTS, SLOTS.HANDS, SLOTS.SHOULDERS, SLOTS.HEAD, SLOTS.CHEST } },
    { id = 10, name = L"Level 40",   sets = { "Ruin" }, slots = { SLOTS.BOOTS, SLOTS.HANDS, SLOTS.SHOULDERS, SLOTS.HEAD, SLOTS.CHEST } },
    
    -- Tier 4 Progressive Sets
    { id = 11, name = L"Renown 45+", sets = { "Conqueror" }, slots = { SLOTS.BOOTS, SLOTS.HANDS, SLOTS.SHOULDERS, SLOTS.HEAD, SLOTS.CHEST } },
    { id = 12, name = L"Level 40",   sets = { "Redeye" }, slots = { SLOTS.BOOTS, SLOTS.HANDS, SLOTS.SHOULDERS, SLOTS.HEAD, SLOTS.CHEST } },
    { id = 13, name = L"Level 40",   sets = { "Beastlord" }, slots = { SLOTS.HEAD, SLOTS.SHOULDERS, SLOTS.CHEST, SLOTS.BACK, SLOTS.RING, SLOTS.POCKET } },
    
    -- Tier 4 Intermediate Sets
    { id = 14, name = L"Renown 55+", sets = { "Vanquisher" }, slots = { SLOTS.BOOTS, SLOTS.HANDS, SLOTS.SHOULDERS, SLOTS.HEAD, SLOTS.CHEST, SLOTS.BACK } },
    { id = 15, name = L"Level 40",   sets = { "Sentinel" }, slots = { SLOTS.BOOTS, SLOTS.HANDS, SLOTS.SHOULDERS, SLOTS.HEAD, SLOTS.CHEST, SLOTS.RING } },
    { id = 16, name = L"Level 40",   sets = { "Vale-Walker" }, slots = { SLOTS.BOOTS, SLOTS.HANDS, SLOTS.SHOULDERS, SLOTS.HEAD, SLOTS.CHEST } },
    
    -- Tier 4 Advanced Sets
    { id = 17, name = L"Renown 60+", sets = { "Oppressor" }, slots = { SLOTS.BOOTS, SLOTS.HANDS, SLOTS.SHOULDERS, SLOTS.HEAD, SLOTS.CHEST, SLOTS.RING } },
    { id = 18, name = L"Renown 63+", sets = { "Dominator" }, slots = { SLOTS.BOOTS, SLOTS.HANDS, SLOTS.SHOULDERS, SLOTS.HEAD, SLOTS.CHEST, SLOTS.RING } },
    { id = 19, name = L"Renown 65+", sets = { "Invader" }, slots = { SLOTS.BOOTS, SLOTS.HANDS, SLOTS.SHOULDERS, SLOTS.HEAD, SLOTS.CHEST, SLOTS.BACK, SLOTS.RING } },
    { id = 20, name = L"Level 40",   sets = { "Bloodlord" }, slots = { SLOTS.BOOTS, SLOTS.HANDS, SLOTS.SHOULDERS, SLOTS.HEAD, SLOTS.CHEST, SLOTS.BACK } },
    
    -- Tier 4 Ultimate Sets (Best-in-Slot Endgame)
    { id = 21, name = L"Renown 75+", sets = { "Warlord" }, slots = { SLOTS.BOOTS, SLOTS.HANDS, SLOTS.BELT, SLOTS.SHOULDERS, SLOTS.HEAD, SLOTS.CHEST, SLOTS.BACK, SLOTS.RING } },
    { id = 22, name = L"Renown 80+", sets = { "Sovereign" }, slots = { SLOTS.BOOTS, SLOTS.HANDS, SLOTS.BELT, SLOTS.SHOULDERS, SLOTS.HEAD, SLOTS.CHEST, SLOTS.BACK, SLOTS.RING } },
    { id = 23, name = L"Level 40",   sets = { "Darkpromise" }, slots = { SLOTS.BOOTS, SLOTS.HANDS, SLOTS.BELT, SLOTS.SHOULDERS, SLOTS.HEAD, SLOTS.CHEST } },
    { id = 24, name = L"Level 40",   sets = { "Tyrant" }, slots = { SLOTS.BOOTS, SLOTS.HANDS, SLOTS.BELT, SLOTS.SHOULDERS, SLOTS.HEAD, SLOTS.CHEST, SLOTS.BACK, SLOTS.RING } }
}

-- Predefined Dungeon Drop database
CBK.DungeonDrops = {
    -- 1. Dragonback Pass
    { dungeon = L"Dragonback Pass", boss = L"Glump's Hoard", set = L"Rare Unique Gear", slot = L"Drop" },
    { dungeon = L"Dragonback Pass", boss = L"Custom Boss Loot", set = L"Purple Weapons", slot = L"Lvl 9-11" },
    { dungeon = L"Dragonback Pass", boss = L"Dungeon Quest", set = L"Unique Faction Cloaks", slot = L"Drop" },

    -- 2. Sewers / Sacellum
    { dungeon = L"Sewers / Sacellum", boss = L"All Bosses", set = L"Keeper's Boots", slot = L"Drop" },
    { dungeon = L"Sewers / Sacellum", boss = L"All Bosses", set = L"Keeper's Gloves", slot = L"Drop" },
    { dungeon = L"Sewers / Sacellum", boss = L"All Bosses", set = L"Keeper's Shoulders", slot = L"Drop" },
    { dungeon = L"Sewers / Sacellum", boss = L"All Bosses", set = L"Keeper's Helm", slot = L"Drop" },
    { dungeon = L"Sewers / Sacellum", boss = L"All Bosses", set = L"Keeper's Chest", slot = L"Drop" },

    -- 3. Mount Gunbad
    { dungeon = L"Mount Gunbad", boss = L"Gunbad PQ Gold Bags", set = L"Redeye Boots", slot = L"Drop" },
    { dungeon = L"Mount Gunbad", boss = L"Gunbad PQ Gold Bags", set = L"Redeye Gloves", slot = L"Drop" },
    { dungeon = L"Mount Gunbad", boss = L"Glomp da Squig Masta", set = L"Redeye Shoulders", slot = L"Drop" },
    { dungeon = L"Mount Gunbad", boss = L"Herald of Solithex/Mixa", set = L"Redeye Helm", slot = L"Drop" },
    { dungeon = L"Mount Gunbad", boss = L"Arathremia", set = L"Redeye Chest", slot = L"Drop" },
    { dungeon = L"Mount Gunbad", boss = L"Dungeon Vendor/Quest", set = L"Madcap Weapons", slot = L"Drop" },

    -- 4. Warpblade / Bilerot
    { dungeon = L"Warpblade / Bilerot", boss = L"Wing 1 (Urhil/Morbidae)", set = L"Sentinel Boots", slot = L"Drop" },
    { dungeon = L"Warpblade / Bilerot", boss = L"Wing 1 (Urhil/Morbidae)", set = L"Sentinel Gloves", slot = L"Drop" },
    { dungeon = L"Warpblade / Bilerot", boss = L"Wing 2 (Bartholomeus/Pox)", set = L"Sentinel Shoulders", slot = L"Drop" },
    { dungeon = L"Warpblade / Bilerot", boss = L"Wing 2 (Bartholomeus/Pox)", set = L"Sentinel Helm", slot = L"Drop" },
    { dungeon = L"Warpblade / Bilerot", boss = L"Final Wing (Bile/Ekscremite)", set = L"Sentinel Chest", slot = L"Drop" },
    { dungeon = L"Warpblade / Bilerot", boss = L"Dungeon Influence T1 & T2", set = L"Sentinel Weapons", slot = L"Drop" },
    { dungeon = L"Warpblade / Bilerot", boss = L"Dungeon Influence T3", set = L"Sentinel Ring", slot = L"Drop" },

    -- 5. Hunter's Vale
    { dungeon = L"Hunter's Vale", boss = L"Early Aspect Bosses", set = L"Vale-Walker Boots", slot = L"Drop" },
    { dungeon = L"Hunter's Vale", boss = L"Early Aspect Bosses", set = L"Vale-Walker Gloves", slot = L"Drop" },
    { dungeon = L"Hunter's Vale", boss = L"Mid Aspect Bosses", set = L"Vale-Walker Shoulders", slot = L"Drop" },
    { dungeon = L"Hunter's Vale", boss = L"Mid Aspect Bosses", set = L"Vale-Walker Helm", slot = L"Drop" },
    { dungeon = L"Hunter's Vale", boss = L"Great Stag / Final Spirit", set = L"Vale-Walker Chest", slot = L"Drop" },

    -- 6. Bastion Stair
    { dungeon = L"Bastion Stair", boss = L"Thar'Ignan (Left Wing)", set = L"Bloodlord Boots", slot = L"Drop" },
    { dungeon = L"Bastion Stair", boss = L"Trash / Mini-Bosses", set = L"Bloodlord Gloves", slot = L"Drop" },
    { dungeon = L"Bastion Stair", boss = L"Lord Slaurith (Right Wing)", set = L"Bloodlord Shoulders", slot = L"Drop" },
    { dungeon = L"Bastion Stair", boss = L"Kaarn the Vanquisher (Mid)", set = L"Bloodlord Helm", slot = L"Drop" },
    { dungeon = L"Bastion Stair", boss = L"Skull Lord Var'ithrok (End)", set = L"Bloodlord Chest", slot = L"Drop" },
    { dungeon = L"Bastion Stair", boss = L"Dungeon Influence T1 & T2", set = L"Bloodlord Weapons", slot = L"Drop" },
    { dungeon = L"Bastion Stair", boss = L"Dungeon Influence T3", set = L"Bloodlord Cape", slot = L"Drop" },

    -- 7. Lost Vale
    { dungeon = L"Lost Vale", boss = L"Dralel (Left Wing)", set = L"Darkpromise Boots", slot = L"Drop" },
    { dungeon = L"Lost Vale", boss = L"Trash / Mini-Bosses", set = L"Darkpromise Gloves", slot = L"Drop" },
    { dungeon = L"Lost Vale", boss = L"Trash / Mini-Bosses", set = L"Darkpromise Belt", slot = L"Drop" },
    { dungeon = L"Lost Vale", boss = L"Sarathaine (Right Wing)", set = L"Darkpromise Shoulders", slot = L"Drop" },
    { dungeon = L"Lost Vale", boss = L"Sechar (Middle Wing)", set = L"Darkpromise Helm", slot = L"Drop" },
    { dungeon = L"Lost Vale", boss = L"N'kari (Final Boss)", set = L"Darkpromise Chest", slot = L"Drop" },

    -- 8. Tomb of Vulture Lord
    { dungeon = L"Tomb of Vulture Lord", boss = L"Tomb Mini-Bosses", set = L"Tyrant Boots", slot = L"Drop" },
    { dungeon = L"Tomb of Vulture Lord", boss = L"Tomb Mini-Bosses", set = L"Tyrant Gloves", slot = L"Drop" },
    { dungeon = L"Tomb of Vulture Lord", boss = L"Hierophant Primates", set = L"Tyrant Shoulders", slot = L"Drop" },
    { dungeon = L"Tomb of Vulture Lord", boss = L"Hand of Ualatp", set = L"Tyrant Helm", slot = L"Drop" },
    { dungeon = L"Tomb of Vulture Lord", boss = L"King Akhenut (Final Boss)", set = L"Tyrant Chest", slot = L"Drop" },
    { dungeon = L"Tomb of Vulture Lord", boss = L"Tomb Urns & Coffins", set = L"Unique Pocket Items", slot = L"Drop" },
    { dungeon = L"Tomb of Vulture Lord", boss = L"Tomb Urns & Coffins", set = L"Cape Upgrades", slot = L"Drop" },
}

-- State variables
local initialized = false
CBK.SearchQuery = ""
CBK.SelectedDungeon = "ALL"

-- Utility functions
local function SafeWStringToString(wstr)
    if not wstr then return "" end
    if type(wstr) == "string" then return wstr end
    if type(wstr) == "wstring" or type(wstr) == "userdata" then
        if WStringToString then
            local ok, str = pcall(WStringToString, wstr)
            if ok and str then return str end
        end
    end
    return tostring(wstr)
end
local WStringToString = SafeWStringToString

local function FixString(str)
	if (str == nil) then return nil end
	local s = SafeWStringToString(str)
	local match = string.match(s, "([^^]+)")
	return match or s
end

local function CleanName(name)
    return WStringToString(FixString(name))
end

-- Helper to detect slot from name/equipped slot ID
local function GetItemSlot(item, equippedSlotId)
    if not item or not item.name then return nil end
    local name = WStringToString(item.name):lower()
    
    -- Check equipped slot first
    if equippedSlotId then
        for slotName, id in pairs(GameData.EquipSlots) do
            if id == equippedSlotId then
                local sUpper = slotName:upper()
                if sUpper == "HEAD" or sUpper == "HELM" then return SLOTS.HEAD end
                if sUpper == "SHOULDERS" or sUpper == "SHOULDER" then return SLOTS.SHOULDERS end
                if sUpper == "CHEST" or sUpper == "BODY" or sUpper == "TORSO" then return SLOTS.CHEST end
                if sUpper == "HANDS" or sUpper == "GLOVES" then return SLOTS.HANDS end
                if sUpper == "BELT" or sUpper == "WAIST" then return SLOTS.BELT end
                if sUpper == "BOOTS" or sUpper == "FEET" or sUpper == "LEGS" then return SLOTS.BOOTS end
                if sUpper == "BACK" or sUpper == "CAPE" or sUpper == "CLOAK" then return SLOTS.BACK end
                if sUpper == "RING_1" or sUpper == "RING_2" or sUpper == "RING" then return SLOTS.RING end
                if sUpper == "POCKET_1" or sUpper == "POCKET_2" or sUpper == "POCKET" then return SLOTS.POCKET end
            end
        end
    end
    
    -- Pattern match slot based on item name
    if name:find("cape") or name:find("cloak") or name:find("wrap") or name:find("back") then
        return SLOTS.BACK
    elseif name:find("helm") or name:find("crown") or name:find("visor") or name:find("coif") or name:find("hood") or name:find("cap") then
        return SLOTS.HEAD
    elseif name:find("shoulder") or name:find("pauldron") or name:find("mantle") or name:find("spaulder") then
        return SLOTS.SHOULDERS
    elseif name:find("chest") or name:find("breastplate") or name:find("robe") or name:find("tunic") or name:find("cuirass") or name:find("coat") or name:find("plate") then
        return SLOTS.CHEST
    elseif name:find("glove") or name:find("gauntlet") or name:find("hand") then
        return SLOTS.HANDS
    elseif name:find("belt") or name:find("girdle") or name:find("sash") or name:find("waist") then
        return SLOTS.BELT
    elseif name:find("boot") or name:find("greave") or name:find("sabat") or name:find("shoe") or name:find("foot") or name:find("feet") then
        return SLOTS.BOOTS
    elseif name:find("ring") or name:find("band") or name:find("signet") or name:find("loop") then
        return SLOTS.RING
    elseif name:find("pocket") or name:find("fragment") or name:find("talisman") or name:find("insignia") or name:find("seal") or name:find("token") or name:find("trinket") or name:find("medallion") then
        return SLOTS.POCKET
    end
    
    return nil
end

-------------------------------------------------------------------------------
-- Initialization
-------------------------------------------------------------------------------
function CheckerByEgyptianKozi.Initialize()
    -- Initialize settings
    CBK.Settings = CheckerByEgyptianKozi.Settings or {}
    CBK.Settings.collected = CBK.Settings.collected or {}
    
    -- Register events
    RegisterEventHandler(SystemData.Events.PLAYER_CAREER_LINE_UPDATED, "CheckerByEgyptianKozi._OnCareerReady")
    RegisterEventHandler(SystemData.Events.INTERFACE_RELOADED, "CheckerByEgyptianKozi._OnCareerReady")
    RegisterEventHandler(SystemData.Events.LOADING_END, "CheckerByEgyptianKozi._OnCareerReady")
end

function CheckerByEgyptianKozi._OnCareerReady()
    if initialized then return end
    if not GameData.Player.career or not GameData.Player.career.line or GameData.Player.career.line < 1 then return end
    
    -- Create Window
    CreateWindow("CheckerByEgyptianKoziWindow", true)
    WindowSetDimensions("CheckerByEgyptianKoziWindow", 740, 520)
    WindowSetDimensions("CheckerByEgyptianKoziWindowPlayerTab", 672, 440)
    WindowSetDimensions("CheckerByEgyptianKoziWindowDbTab", 672, 440)
    WindowSetDimensions("CheckerByEgyptianKoziWindowDbTabList", 672, 330)
    WindowSetDimensions("CheckerByEgyptianKoziWindowPlayerTabScrollChild", 650, 440)
    WindowSetDimensions("CheckerByEgyptianKoziWindowDbTabListScrollChild", 650, 330)
    
    LayoutEditor.RegisterWindow(
        "CheckerByEgyptianKoziWindow",
        L"CheckerByEgyptianKozi",
        L"Gear and Ward progression tracker",
        false, -- canResize (lock window dimensions to match design layout)
        true,  -- canScale
        true,  -- canAlpha
        nil
    )
    
    LabelSetText("CheckerByEgyptianKoziWindowTitleBarText", L"CheckerByEgyptianKozi")
    WindowSetShowing("CheckerByEgyptianKoziWindow", false)
    
    -- Set tab and filter label texts
    LabelSetText("CheckerByEgyptianKoziWindowTabPlayerText", L"My Progression")
    LabelSetText("CheckerByEgyptianKoziWindowTabDbText", L"Dungeon Drops")
    
    LabelSetText("CheckerByEgyptianKoziWindowSearchLabel", L"Search:")
    LabelSetText("CheckerByEgyptianKoziWindowDbTabFilterAllText", L"All")
    LabelSetText("CheckerByEgyptianKoziWindowDbTabFilterDragonbackText", L"Dragonback")
    LabelSetText("CheckerByEgyptianKoziWindowDbTabFilterSewersText", L"Sewers / Sacellum")
    LabelSetText("CheckerByEgyptianKoziWindowDbTabFilterGunbadText", L"Mount Gunbad")
    LabelSetText("CheckerByEgyptianKoziWindowDbTabFilterBilerotText", L"Bilerot Burrows")
    LabelSetText("CheckerByEgyptianKoziWindowDbTabFilterHVText", L"Hunter's Vale")
    LabelSetText("CheckerByEgyptianKoziWindowDbTabFilterBSText", L"Bastion Stair")
    LabelSetText("CheckerByEgyptianKoziWindowDbTabFilterLVText", L"Lost Vale")
    LabelSetText("CheckerByEgyptianKoziWindowDbTabFilterTombText", L"Tomb of Vulture Lord")
    
    -- Register event hooks for dynamic updates
    RegisterEventHandler(SystemData.Events.PLAYER_INVENTORY_SLOT_UPDATED, "CheckerByEgyptianKozi.OnInventoryUpdated")
    RegisterEventHandler(SystemData.Events.PLAYER_ZONE_CHANGED, "CheckerByEgyptianKozi.OnInventoryUpdated")
    
    -- Register slash commands with LibSlash
    if LibSlash then
        LibSlash.RegisterSlashCmd("checker", function(args) CheckerByEgyptianKozi.SlashCommand(args) end)
        LibSlash.RegisterSlashCmd("checkerbyegyptiankozi", function(args) CheckerByEgyptianKozi.SlashCommand(args) end)
        LibSlash.RegisterSlashCmd("checkerdump", function() CheckerByEgyptianKozi.DebugDumpEquipment() end)
    end
    
    initialized = true
    
    -- First scan
    CheckerByEgyptianKozi.ScanPlayerEquipment()
    CheckerByEgyptianKozi.RefreshUI()
    
    UnregisterEventHandler(SystemData.Events.PLAYER_CAREER_LINE_UPDATED, "CheckerByEgyptianKozi._OnCareerReady")
    UnregisterEventHandler(SystemData.Events.INTERFACE_RELOADED, "CheckerByEgyptianKozi._OnCareerReady")
    UnregisterEventHandler(SystemData.Events.LOADING_END, "CheckerByEgyptianKozi._OnCareerReady")
end

-------------------------------------------------------------------------------
-- Scan Player Equipment & Bags
-------------------------------------------------------------------------------
function CheckerByEgyptianKozi.ScanPlayerEquipment()
    -- Clear current in-memory status, but preserve saved collections
    CBK.PlayerProgression = {}
    
    -- Initialize tracking lists and reset collected cache to false for fresh live scanning
    for _, ward in ipairs(CBK.Wards) do
        for _, set in ipairs(ward.sets) do
            CBK.PlayerProgression[set] = {}
            CBK.Settings.collected[set] = CBK.Settings.collected[set] or {}
            for _, slotType in ipairs(ward.slots) do
                CBK.PlayerProgression[set][slotType] = false
                CBK.Settings.collected[set][slotType] = false
            end
        end
    end

    local keyToSlot = {
        HEAD = SLOTS.HEAD,      HELM = SLOTS.HEAD,
        SHOULDERS = SLOTS.SHOULDERS, SHOULDER = SLOTS.SHOULDERS,
        CHEST = SLOTS.CHEST,    BODY = SLOTS.CHEST,   TORSO = SLOTS.CHEST,
        HANDS = SLOTS.HANDS,    GLOVES = SLOTS.HANDS,
        BELT  = SLOTS.BELT,     WAIST  = SLOTS.BELT,
        BOOTS = SLOTS.BOOTS,    FEET   = SLOTS.BOOTS, LEGS = SLOTS.BOOTS,
        BACK  = SLOTS.BACK,     CAPE   = SLOTS.BACK,  CLOAK = SLOTS.BACK,
        RING  = SLOTS.RING,     RING1 = SLOTS.RING,   RING2 = SLOTS.RING,
        LEFTRING = SLOTS.RING,  RIGHTRING = SLOTS.RING,
        POCKET = SLOTS.POCKET,  POCKET1 = SLOTS.POCKET, POCKET2 = SLOTS.POCKET,
        LEFTPOCKET = SLOTS.POCKET, RIGHTPOCKET = SLOTS.POCKET
    }

    -- Helper to normalize names for strict substring comparison (ignores spaces, hyphens, apostrophes)
    local function normalizeString(str)
        if not str then return "" end
        local normalized = str:lower()
        normalized = normalized:gsub("['`%-]", "") -- Strip apostrophes, hyphens, backticks
        normalized = normalized:gsub("%s+", "")    -- Strip all spaces
        return normalized
    end

    -- Name-based fallback slot detector with set-specific overrides to prevent collisions
    local function detectSlotFromName(nameLower, setName)
        local setLower = setName and setName:lower() or ""

        -- 1. BACK / CAPE
        if nameLower:find("cape") or nameLower:find("cloak") or nameLower:find("wrap") or nameLower:find("back") or nameLower:find("shroud") or nameLower:find("drape") or nameLower:find("greatcloak") then
            return SLOTS.BACK

        -- 2. HEAD / HELM
        elseif nameLower:find("helm") or nameLower:find("crown") or nameLower:find("hood") or nameLower:find("cap") or nameLower:find("coif") or nameLower:find("visor") or nameLower:find("mask") or nameLower:find("hardhat") or nameLower:find("galea") or nameLower:find("sallet") or nameLower:find("bascinet") or nameLower:find("vizard") or nameLower:find("armet") or nameLower:find("barbuta") or nameLower:find("cabasset") or nameLower:find("cowl") or nameLower:find("gorgoneion") or nameLower:find("circlet") or nameLower:find("casque") or nameLower:find("faceguard") or nameLower:find("hat") or nameLower:find("headguard") or nameLower:find("headpiece") then
            return SLOTS.HEAD

        -- 3. SHOULDERS
        elseif nameLower:find("shoulder") or nameLower:find("pauldron") or nameLower:find("spaulder") or nameLower:find("epaulet") or nameLower:find("amice") or nameLower:find("mantle") then
            -- For other sets, "mantle" is the shoulders
            return SLOTS.SHOULDERS

        -- 4. CHEST
        elseif nameLower:find("chest") or nameLower:find("breastplate") or nameLower:find("robe") or nameLower:find("tunic") or nameLower:find("cuirass") or nameLower:find("coat") or nameLower:find("plate") or nameLower:find("body") or nameLower:find("torso") or nameLower:find("jerkin") or nameLower:find("vestment") or nameLower:find("hauberk") or nameLower:find("corset") or nameLower:find("greatmail") or nameLower:find("mail") or nameLower:find("vest") or nameLower:find("doublet") or nameLower:find("brigandine") or nameLower:find("gambeson") or nameLower:find("garment") or nameLower:find("chestplate") or nameLower:find("harness") or nameLower:find("jacket") or nameLower:find("platemail") then
            return SLOTS.CHEST

        -- 5. HANDS / GLOVES
        elseif nameLower:find("glove") or nameLower:find("gauntlet") or nameLower:find("hand") or nameLower:find("wrist") or nameLower:find("cuff") or nameLower:find("bracer") or nameLower:find("vambrace") or nameLower:find("mitten") or nameLower:find("miton") or nameLower:find("wristband") or nameLower:find("wristguard") then
            return SLOTS.HANDS

        -- 6. BELT
        elseif nameLower:find("belt") or nameLower:find("girdle") or nameLower:find("sash") or nameLower:find("waist") or nameLower:find("cord") or nameLower:find("cinch") or nameLower:find("waistband") or nameLower:find("cincture") then
            return SLOTS.BELT

        -- 7. BOOTS
        elseif nameLower:find("boot") or nameLower:find("greave") or nameLower:find("sabaton") or nameLower:find("shoe") or nameLower:find("foot") or nameLower:find("feet") or nameLower:find("sabat") or nameLower:find("steeltoes") or nameLower:find("solleret") then
            return SLOTS.BOOTS

        -- 8. RING
        elseif nameLower:find("ring") or nameLower:find("band") or nameLower:find("signet") or nameLower:find("loop") then
            return SLOTS.RING

        -- 9. POCKET
        elseif nameLower:find("pocket") or nameLower:find("fragment") or nameLower:find("talisman") or nameLower:find("insignia") or nameLower:find("seal") or nameLower:find("token") or nameLower:find("trinket") or nameLower:find("medallion") or nameLower:find("guide") or nameLower:find("book") then
            return SLOTS.POCKET
        end
        return nil
    end

    -- Try to match an item name against all known sets and record the result
    local function tryMatchItem(rawName, slotType)
        local cleanName = rawName:match("([^^]+)") or rawName
        local normName = normalizeString(cleanName)
        for _, ward in ipairs(CBK.Wards) do
            for _, set in ipairs(ward.sets) do
                local normSet = normalizeString(set)
                if normName:find(normSet, 1, true) then
                    local slot = slotType or detectSlotFromName(cleanName:lower(), set)
                    if slot then
                        CBK.PlayerProgression[set][slot] = true
                        CBK.Settings.collected[set][slot] = true
                    end
                end
            end
        end
    end

    -- Helper to recursively scan inventory containers (handles flat and nested 2D bag structures)
    local function scanItemContainer(container)
        if not container then return end
        for k, v in pairs(container) do
            if type(v) == "table" then
                if v.name then
                    -- Flat structure: v is the item
                    tryMatchItem(WStringToString(v.name), nil)
                else
                    -- Nested 2D structure: loop inside the bag/tab
                    for _, item in pairs(v) do
                        if type(item) == "table" and item.name then
                            tryMatchItem(WStringToString(item.name), nil)
                        end
                    end
                end
            end
        end
    end

    -- 1. Scan equipped items — mirror TalismanAlerter exactly:
    --    iterate GameData.EquipSlots for slot IDs, look up equipment_data[slotId]
    local equipment_data = DataUtils.GetEquipmentData()
    if equipment_data then
        for slotKey, slotId in pairs(GameData.EquipSlots) do
            local item = equipment_data[slotId]
            if item and item.name then
                local cleanKey = tostring(slotKey):upper():gsub("[_%s]", "")
                local slotType = keyToSlot[cleanKey]
                tryMatchItem(WStringToString(item.name), slotType)
            end
        end
    end

    -- 2. Scan bags/inventory for collected-but-not-equipped pieces
    local bagItems = DataUtils and DataUtils.GetItems and DataUtils.GetItems()
    scanItemContainer(bagItems)

    -- 3. Scan bank/storage for collected pieces
    local bankItems = DataUtils and DataUtils.GetBankData and DataUtils.GetBankData()
    scanItemContainer(bankItems)
end

-- Debug: dump raw equipment data to chat (/checkerdump)
function CheckerByEgyptianKozi.DebugDumpEquipment()
    local equipment_data = DataUtils.GetEquipmentData()
    if not equipment_data then
        d(L"[CBK Debug] GetEquipmentData() = nil")
        return
    end
    d(L"[CBK Debug] Equipped items:")
    for slotKey, slotId in pairs(GameData.EquipSlots) do
        local item = equipment_data[slotId]
        if item and item.name then
            d(towstring("[CBK] " .. slotKey .. ": " .. WStringToString(item.name)))
        end
    end
    d(L"[CBK Debug] Done.")
end

function CheckerByEgyptianKozi.OnInventoryUpdated()
    CheckerByEgyptianKozi.ScanPlayerEquipment()
    CheckerByEgyptianKozi.RefreshUI()
end


function CheckerByEgyptianKozi.GetPlayerMaxWard()
    local maxWard = 0
    local totalPieces = 0
    local maxNumSlots = 6
    
    for _, ward in ipairs(CBK.Wards) do
        local completedSet = false
        local piecesForWard = 0
        local numSlots = #ward.slots
        for _, set in ipairs(ward.sets) do
            local pieces = 0
            for _, slotType in ipairs(ward.slots) do
                if CBK.Settings.collected[set] and CBK.Settings.collected[set][slotType] then
                    pieces = pieces + 1
                end
            end
            if pieces > piecesForWard then
                piecesForWard = pieces
            end
            
            local isSetDone = false
            if numSlots <= 3 then
                isSetDone = (pieces >= numSlots)
            elseif numSlots <= 5 then
                isSetDone = (pieces >= 4)
            else
                isSetDone = (pieces >= 5)
            end
            if isSetDone then
                completedSet = true
            end
        end
        
        if piecesForWard > 0 then
            totalPieces = piecesForWard
            maxNumSlots = numSlots
        end
        if completedSet then
            maxWard = ward.id
        end
    end
    return maxWard, totalPieces, maxNumSlots
end


-------------------------------------------------------------------------------
-- UI Rendering / Refreshes
-------------------------------------------------------------------------------
function CheckerByEgyptianKozi.RefreshUI()
    if not DoesWindowExist("CheckerByEgyptianKoziWindow") then return end
    CheckerByEgyptianKozi.RefreshPlayerUI()
    CheckerByEgyptianKozi.RefreshDatabaseUI()
end

function CheckerByEgyptianKozi.RefreshPlayerUI()
    local parent = "CheckerByEgyptianKoziWindowPlayerTabScrollChild"
    if not DoesWindowExist(parent) then return end
    
    -- Destroy old instances
    local i = 1
    while DoesWindowExist(parent .. "Set" .. i) do
        DestroyWindow(parent .. "Set" .. i)
        i = i + 1
    end
    
    local index = 1
    local yOffset = 10
    
    for _, ward in ipairs(CBK.Wards) do
        for _, set in ipairs(ward.sets) do
            local winName = parent .. "Set" .. index
            CreateWindowFromTemplate(winName, "CheckerByEgyptianKoziSetTemplate", parent)
            WindowClearAnchors(winName)
            WindowAddAnchor(winName, "topleft", parent, "topleft", 10, yOffset)
            
            -- Set Name
            LabelSetText(winName .. "Name", towstring(set) .. L" (" .. ward.name .. L")")
            
            -- Hide all 8 slots first
            for slotIdx = 1, 8 do
                WindowSetShowing(winName .. "Slot" .. slotIdx, false)
            end
            
            -- Scan collected pieces
            local collectedCount = 0
            local numSlots = #ward.slots
            for idx, slotType in ipairs(ward.slots) do
                local slotName = winName .. "Slot" .. idx
                WindowSetShowing(slotName, true)
                LabelSetText(slotName, SLOT_NAMES[slotType])
                
                local isCollected = CBK.Settings.collected[set] and CBK.Settings.collected[set][slotType]
                if isCollected then
                    collectedCount = collectedCount + 1
                    LabelSetTextColor(slotName, 50, 255, 50) -- Green
                else
                    LabelSetTextColor(slotName, 180, 180, 180) -- Gray
                end
            end
            
            -- Progress Bar & text
            LabelSetText(winName .. "ProgressText", wstring.format(L"%d/%d", collectedCount, numSlots))
            
            -- Alternating row colors
            if index % 2 == 0 then
                WindowSetTintColor(winName .. "Bg", 30, 30, 35)
            else
                WindowSetTintColor(winName .. "Bg", 20, 20, 22)
            end
            
            yOffset = yOffset + 75
            index = index + 1
        end
    end
    
    -- Set Scroll area height to match 650px scroll child
    WindowSetDimensions(parent, 650, yOffset + 20)
    ScrollWindowUpdateScrollRect("CheckerByEgyptianKoziWindowPlayerTab")
end

function CheckerByEgyptianKozi.RefreshDatabaseUI()
    -- The XML nests the scroll child as: $parentDbTab > $parentList > $parentScrollChild
    -- which resolves to: ...WindowDbTabListScrollChild (NOT ...WindowDbTabScrollChild)
    local parent = "CheckerByEgyptianKoziWindowDbTabListScrollChild"
    if not DoesWindowExist(parent) then return end
    
    -- Clear old list
    local i = 1
    while DoesWindowExist(parent .. "Drop" .. i) do
        DestroyWindow(parent .. "Drop" .. i)
        i = i + 1
    end
    
    local index = 1
    local yOffset = 5
    
    for _, drop in ipairs(CBK.DungeonDrops) do
        local matchesDungeon = (CBK.SelectedDungeon == "ALL" or WStringToString(drop.dungeon):lower() == CBK.SelectedDungeon:lower())
        local matchesSearch = (CBK.SearchQuery == "" or 
            WStringToString(drop.boss):lower():find(CBK.SearchQuery:lower()) or 
            WStringToString(drop.set):lower():find(CBK.SearchQuery:lower()) or
            WStringToString(drop.dungeon):lower():find(CBK.SearchQuery:lower()))
            
        if matchesDungeon and matchesSearch then
            local winName = parent .. "Drop" .. index
            CreateWindowFromTemplate(winName, "CheckerByEgyptianKoziDropTemplate", parent)
            WindowClearAnchors(winName)
            WindowAddAnchor(winName, "topleft", parent, "topleft", 0, yOffset)
            
            LabelSetText(winName .. "Dungeon", drop.dungeon)
            LabelSetText(winName .. "Boss", drop.boss)
            LabelSetText(winName .. "Set", drop.set .. L" (" .. drop.slot .. L")")
            
            if index % 2 == 0 then
                WindowSetTintColor(winName .. "Bg", 30, 30, 35)
            else
                WindowSetTintColor(winName .. "Bg", 20, 20, 22)
            end
            
            yOffset = yOffset + 35
            index = index + 1
        end
    end
    
    WindowSetDimensions(parent, 540, yOffset + 10)
    ScrollWindowUpdateScrollRect("CheckerByEgyptianKoziWindowDbTabList")
end


-------------------------------------------------------------------------------
-- Slash Commands and Input Actions
-------------------------------------------------------------------------------
function CheckerByEgyptianKozi.HideUI()
    WindowAssignFocus("CheckerByEgyptianKoziWindow", false)
    WindowSetShowing("CheckerByEgyptianKoziWindow", false)
end

function CheckerByEgyptianKozi.ToggleUI()
    local showing = not WindowGetShowing("CheckerByEgyptianKoziWindow")
    if showing then
        WindowSetShowing("CheckerByEgyptianKoziWindow", true)
        CheckerByEgyptianKozi.ScanPlayerEquipment()
        CheckerByEgyptianKozi.RefreshUI()
    else
        CheckerByEgyptianKozi.HideUI()
    end
end

function CheckerByEgyptianKozi.SlashCommand(args)
    -- LibSlash passes args as a plain Lua string (already converted from wstring).
    -- Must compare to "" not L"" — comparing string to wstring is always false.
    if not args or args == "" or args == L"" or #tostring(args) == 0 then
        CheckerByEgyptianKozi.ToggleUI()
        return
    end
    
    local argStr = WStringToString(args):lower()
    
    if argStr:find("^scan") then
        CheckerByEgyptianKozi.ScanPlayerEquipment()
        CheckerByEgyptianKozi.RefreshUI()
        d(L"[CheckerByEgyptianKozi] Inventory & gear scan completed.")
        
    elseif argStr:find("^report") then
        local tVal = argStr:match("report%s+(%d+)")
        local maxWard, totalPieces, numSlots = CheckerByEgyptianKozi.GetPlayerMaxWard()
        if tVal then
            local customTier = tonumber(tVal)
            local customSlots = 6
            for _, w in ipairs(CBK.Wards) do
                if w.id == customTier then
                    customSlots = #w.slots
                    break
                end
            end
            local reply = wstring.format(L"[CheckerByEgyptianKozi:Report] %s has Ward Tier %d (%d/%d pieces)", GameData.Player.name, customTier, customSlots, customSlots)
            SendChatText(reply, L"")
        else
            local reply = wstring.format(L"[CheckerByEgyptianKozi:Report] %s has Ward Tier %d (%d/%d pieces)", GameData.Player.name, maxWard, totalPieces, numSlots)
            SendChatText(reply, L"")
        end
        
    else
        d(L"[CheckerByEgyptianKozi] Commands:")
        d(L"  /checker              - Toggle main progression UI window")
        d(L"  /checker scan         - Run manual check of inventory/bags")
        d(L"  /checker report [t]   - Broadcast your ward tier (optional custom tier)")
    end
end

-------------------------------------------------------------------------------
-- Lifecycle hooks
-------------------------------------------------------------------------------
function CheckerByEgyptianKozi.Update(elapsed)
    -- Lightweight Redraws hook
end

function CheckerByEgyptianKozi.Shutdown()
    -- Save Settings
end

-------------------------------------------------------------------------------
-- UI Event Handlers (Called by XML interface bindings)
-------------------------------------------------------------------------------
function CheckerByEgyptianKozi.OnTabPlayerClick()
    WindowSetShowing("CheckerByEgyptianKoziWindowPlayerTab", true)
    WindowSetShowing("CheckerByEgyptianKoziWindowDbTab", false)
    -- Search lives in the tab row and only applies to the Dungeon Drops list.
    WindowSetShowing("CheckerByEgyptianKoziWindowSearchLabel", false)
    WindowSetShowing("CheckerByEgyptianKoziWindowSearchInput", false)
    CheckerByEgyptianKozi.RefreshPlayerUI()
end

function CheckerByEgyptianKozi.OnTabDbClick()
    WindowSetShowing("CheckerByEgyptianKoziWindowPlayerTab", false)
    WindowSetShowing("CheckerByEgyptianKoziWindowDbTab", true)
    WindowSetShowing("CheckerByEgyptianKoziWindowSearchLabel", true)
    WindowSetShowing("CheckerByEgyptianKoziWindowSearchInput", true)
    CheckerByEgyptianKozi.RefreshDatabaseUI()
end


function CheckerByEgyptianKozi.OnSearchTextChanged()
    local text = TextEditBoxGetText("CheckerByEgyptianKoziWindowSearchInput")
    CBK.SearchQuery = WStringToString(text)
    CheckerByEgyptianKozi.RefreshDatabaseUI()
end

function CheckerByEgyptianKozi.OnDungeonFilterClick(dungeonStr)
    CBK.SelectedDungeon = dungeonStr
    CheckerByEgyptianKozi.RefreshDatabaseUI()
end

function CheckerByEgyptianKozi.OnDungeonFilterAll()
    CheckerByEgyptianKozi.OnDungeonFilterClick("ALL")
end

function CheckerByEgyptianKozi.OnDungeonFilterDragonback()
    CheckerByEgyptianKozi.OnDungeonFilterClick("Dragonback Pass")
end

function CheckerByEgyptianKozi.OnDungeonFilterSewers()
    CheckerByEgyptianKozi.OnDungeonFilterClick("Sewers / Sacellum")
end

function CheckerByEgyptianKozi.OnDungeonFilterGunbad()
    CheckerByEgyptianKozi.OnDungeonFilterClick("Mount Gunbad")
end

function CheckerByEgyptianKozi.OnDungeonFilterBilerot()
    CheckerByEgyptianKozi.OnDungeonFilterClick("Warpblade / Bilerot")
end

function CheckerByEgyptianKozi.OnDungeonFilterHV()
    CheckerByEgyptianKozi.OnDungeonFilterClick("Hunter's Vale")
end

function CheckerByEgyptianKozi.OnDungeonFilterBS()
    CheckerByEgyptianKozi.OnDungeonFilterClick("Bastion Stair")
end

function CheckerByEgyptianKozi.OnDungeonFilterLV()
    CheckerByEgyptianKozi.OnDungeonFilterClick("Lost Vale")
end

function CheckerByEgyptianKozi.OnDungeonFilterTomb()
    CheckerByEgyptianKozi.OnDungeonFilterClick("Tomb of Vulture Lord")
end

-------------------------------------------------------------------------------
-- Required lifecycle callbacks declared in CheckerByEgyptianKozi.mod
-------------------------------------------------------------------------------

-- Called every frame by the engine via <OnUpdate> in the .mod manifest.
-- Keep this as a lightweight stub — do NOT add heavy logic here.
function CheckerByEgyptianKozi.Update()
    -- No per-frame work needed; all updates are event-driven.
end

-- Called on UI shutdown / reload via <OnShutdown> in the .mod manifest.
-- Persist any runtime state that should survive a /reloadui.
function CheckerByEgyptianKozi.Shutdown()
    if CBK.Settings and CheckerByEgyptianKozi.Settings then
        CheckerByEgyptianKozi.Settings = CBK.Settings
    end
end
