<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
	<UiMod name="CheckerByEgyptianKozi" version="1.0.1" date="07/15/2026" autoenabled="true">

		<VersionSettings gameVersion="1.4.8" windowsVersion="1.0" savedVariablesVersion="1.0" />

		<Author name="ByEgyptianKozi" email="" />
		<Description text="Gear and Ward progression tracker, including dungeon drop maps and group readiness checks." />

		<WARInfo>
			<Categories>
				<Category name="ITEMS" />
			</Categories>
			<Careers>
				<Career name="BLACKGUARD" />
				<Career name="WITCH_ELF" />
				<Career name="DISCIPLE" />
				<Career name="SORCERER" />
				<Career name="IRON_BREAKER" />
				<Career name="SLAYER" />
				<Career name="RUNE_PRIEST" />
				<Career name="ENGINEER" />
				<Career name="BLACK_ORC" />
				<Career name="CHOPPA" />
				<Career name="SHAMAN" />
				<Career name="SQUIG_HERDER" />
				<Career name="WITCH_HUNTER" />
				<Career name="KNIGHT" />
				<Career name="BRIGHT_WIZARD" />
				<Career name="WARRIOR_PRIEST" />
				<Career name="CHOSEN" />
				<Career name="MARAUDER" />
				<Career name="ZEALOT" />
				<Career name="MAGUS" />
				<Career name="SWORDMASTER" />
				<Career name="SHADOW_WARRIOR" />
				<Career name="WHITE_LION" />
				<Career name="ARCHMAGE" />
			</Careers>
		</WARInfo>

		<Files>
			<File name="CheckerByEgyptianKozi.lua" />
			<File name="CheckerByEgyptianKozi.xml" />
		</Files>

		<OnInitialize>
			<CallFunction name="CheckerByEgyptianKozi.Initialize" />
		</OnInitialize>

		<SavedVariables>
			<SavedVariable name="CheckerByEgyptianKozi.Settings" global="false" />
		</SavedVariables>

		<OnUpdate>
			<CallFunction name="CheckerByEgyptianKozi.Update" />
		</OnUpdate>

		<OnShutdown>
			<CallFunction name="CheckerByEgyptianKozi.Shutdown" />
		</OnShutdown>

	</UiMod>
</ModuleFile>
