<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
	<UiMod name="Info_Loot" version="1.0" date="14/12/2020" >
		<VersionSettings gameVersion="1.4.8" windowsVersion="1.0" savedVariablesVersion="1.0" />
		<Author name="Sullemunk"/>
		<Description text="Info_Loot, Displays recieved loot on InfoScroller" />
		<Files>
		<File name="Info_Loot.lua" />
		</Files>
			<Dependencies>
			<Dependency name="EASystem_Utils" />
            <Dependency name="EASystem_WindowUtils" />			
			<Dependency name="EA_ChatWindow" />
            <Dependency name="InfoScroller" optional="false" />
        </Dependencies>
		<OnInitialize>
			<CallFunction name="Info_Loot.OnInitialize" /> 
		</OnInitialize>
		   <OnUpdate>
		<CallFunction name="Info_Loot.Update" />
    	  </OnUpdate>
	</UiMod>
</ModuleFile>