Info_Loot = {}
local version = 1.0

function Info_Loot.OnInitialize()
RegisterEventHandler(TextLogGetUpdateEventId("Chat"), "Info_Loot.OnChatLogUpdated")
RegisterEventHandler(SystemData.Events.CHAT_TEXT_ARRIVED, "Info_Loot.TextArrived")

Info_LootStackTable = {}
LootListTimer = 0

Info_Loot.Colors={}
Info_Loot.Colors[1]=DefaultColor.GREY	
Info_Loot.Colors[2]=DefaultColor.WHITE
Info_Loot.Colors[3]=DefaultColor.GREEN
Info_Loot.Colors[4]=DefaultColor.BLUE
Info_Loot.Colors[5]=DefaultColor.PURPLE
Info_Loot.Colors[6]=DefaultColor.GOLD
	
Info_Loot.Bags = {special={icon=240,color=DefaultColor.BROWN},white={icon=555,color=DefaultColor.WHITE},green={icon=553,color=DefaultColor.GREEN},blue={icon=551,color=DefaultColor.BLUE},purple={icon=554,color=DefaultColor.PURPLE},gold={icon=552,color=DefaultColor.GOLD}}
Info_Loot.sackType = {"white","green","blue","purple","gold"}

--Setting up dynamic configs in InfoScroller
if not InfoScroller.Settings.Info_Loot then InfoScroller.Settings.Info_Loot = true end
if not InfoScroller.Settings.BagRolls then InfoScroller.Settings.BagRolls = true end

	local InfoLoot = {name="+Loot",[1]={name="checkbox",title="Show Loot",save="Info_Loot"},
									[2]={name="checkbox",title="Show BagRolls",save="BagRolls"},		
	}
	table.insert(InfoScroller.Register,InfoLoot)	
end

function Info_Loot.TextArrived()
if InfoScroller.Settings.BagRoll == false then return end
local lootbag = nil
if GameData.ChatData.type == 3 then
		lootbag = GameData.ChatData.text:match(L"You have won a ([%a]+) loot bag.")		
		if (lootbag and lootbag ~= L"") then
		local T_color = Info_Loot.Bags[tostring(lootbag)].color
		local T_Icon = Info_Loot.Bags[tostring(lootbag)].icon
		InfoScroller.TicketOnQue({[1]={text=L"Lootbag!",color={r=255,g=150,b=25},font="font_clear_small_bold"},[2]={icon=T_Icon,text=L"     You Have Won a "..towstring(CreateHyperLink(L"0",towstring(wstring.upper(lootbag)), {T_color.r,T_color.g,T_color.b},{}))..L" Lootbag!",color={r=255,g=255,b=255},font="font_clear_large_bold"}})
			d(lootbag)
		end
end
end

function Info_Loot.Update(TimeElapsed)
if InfoScroller.Settings.Info_Loot == false then return end
--As soon as something goes into the Stack-table, a timer starts to run because of Item-To-Bag lag

	if #Info_LootStackTable > 0 then
		LootListTimer = LootListTimer + 1
	end
	
	if LootListTimer > 50 then
		LootListTimer = 0
	
		for i=1 , #Info_LootStackTable do	
			if Info_LootStackTable[i].text ~= nil then
				Info_Loot.GetLoot(Info_LootStackTable[i].text,Info_LootStackTable[i].quantity,Info_LootStackTable[i].TimeStamp)
			else
				Info_LootStackTable[i] = nil
			end
		end
		Info_LootStackTable = {}
	end
	
		if (TimedStateMachineManager.GetCurrentState( PQData.stateMachineName ) == 5) and PQData.playerData.sackType then
			if DoBagRoll == true then
				DoBagRoll = false
						local lootbag = Info_Loot.sackType[PQData.playerData.sackType]
						local T_color = Info_Loot.Bags[tostring(lootbag)].color
						local T_Icon = Info_Loot.Bags[tostring(lootbag)].icon								
				InfoScroller.TicketOnQue({[1]={text=L"Lootbag!",color={r=255,g=150,b=25},font="font_clear_small_bold"},[2]={icon=T_Icon,text=L"     You Have Won a "..towstring(CreateHyperLink(L"0",wstring.upper(towstring(lootbag)), {T_color.r,T_color.g,T_color.b},{}))..L" Lootbag!",color={r=255,g=255,b=255},font="font_clear_medium_bold"}})			
			end
		else
		DoBagRoll = true
		end
end

function Info_Loot.OnChatLogUpdated(updateType, filterType)
	if( updateType == SystemData.TextLogUpdate.ADDED ) then --if something gets ADDED to the chatlog...
		local TimeStamp, filterId, text = TextLogGetEntry( "Chat", TextLogGetNumEntries("Chat") - 1 ) -- ..check the latest entry in chatlog and saves the entry in "text", aslo saves the time in label TimeSTamp
		if filterId == 30 then -- checks if it's from the "loot" filter, we only want loot to show up on the alert
			local text2 = text:match(L"You receive [%a]+ ([^%.]+)") -- matches the saved entry in "text" to this specific string, if it matches it saves the loot item name in "text2"
			local quantity = text:match(L"[^%.]+([%d]).") -- strip out the numbers at the end and save it in quantity string
			if text2 ~= nil or text2~= L"" then -- if the "text2" is NOT empty, then print out the content on the Alert stack	
	-- This will add the Loot to a Timer list. I had to do this because sometimes the function runs the bagcheck before the loot has gotten into the bag
			Info_LootStackTable[#Info_LootStackTable+1] = {}			
			Info_LootStackTable[#Info_LootStackTable].text = text2
			Info_LootStackTable[#Info_LootStackTable].quantity = quantity
			Info_LootStackTable[#Info_LootStackTable].TimeStamp = TimeStamp
				
			end
		else
			local BagType = text:match(L"You won a ([^%.]+) bag.")
			if BagType ~= nil
			then
				d(BagType)
			end
		end
	end
end

function Info_Loot.CheckLoot(CheckLootName,CheckLootQuant,TimeStamp)
	if CheckLootName == nil or CheckLootName == L"" then return end
	EA_Window_Backpack.UpdateBackpackSlots()
	local LootInput = tostring(CheckLootName)
	if string.match(LootInput,"%-") ~= nil then 
		LootInput = string.gsub (LootInput, "%-", "") -- need to check if the item name has an "-" in it and remove it, becase the matching doesnt like using "-" in the comparison
	end	
	if string.match(LootInput,"%s") ~= nil then 
		LootInput = string.gsub (LootInput, "%s", "") -- if the item name has an "space" in it and remove it because some item names has junk spaces after them (Blame Ryan for that!)
	end	
	local LootInput2 = string.sub(LootInput,2,-6) -- remove some extra letters at the end for easyer comparison (incase they have more junk characters)
	for i=1,4 do
		EA_Window_Backpack.UpdateBackpackSlots()
		local BagItems = EA_Window_Backpack.GetItemsFromBackpack(i) --2	
		for BagSlask, SlaskBag in pairs( BagItems ) do		
			local CheckName2 = tostring(SlaskBag.name)		
			if string.match(CheckName2,"%-") ~= nil then 
				CheckName2 = string.gsub (CheckName2, "%-", "") -- need to check if the item name has an "-" in it and remove it, becase the matching doesnt like using "-" in the comparison
			end
			if string.match(CheckName2,"%s") ~= nil then 
				CheckName2 = string.gsub (CheckName2, "%s", "") -- need to check if the item name has an "-" in it and remove it, becase the matching doesnt like using "-" in the comparison
			end
			if string.match(tostring(string.lower(CheckName2)),tostring(string.lower(LootInput2))) ~= nil then		
				return SlaskBag.iconNum,SlaskBag.rarity,SlaskBag.id
			end
		end   		
	end
end

function Info_Loot.GetLoot(text2,quantity,TimeStamp)
	TempIcon,TempRarity,TempID = Info_Loot.CheckLoot(text2,quantity,TimeStamp)				
	local Rarity_Color = Info_Loot.Colors[tonumber(TempRarity)]
			
	InfoScroller.TicketOnQue({[1]={text=L"Item(s) Accuired:",color={r=255,g=150,b=25},font="font_clear_small_bold"},[2]={text=L"     "..towstring(text2),color=Rarity_Color,font="font_clear_large_bold",icon=tonumber(TempIcon)}})
	PlaySound(GameData.Sound.AUCTION_HOUSE_CREATE_AUCTION) -- ...and play a nice sound
	return
end