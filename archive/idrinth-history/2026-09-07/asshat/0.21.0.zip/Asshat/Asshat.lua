Asshat = {}
Asshat.Version = 0.21
Asshat.ForceUpgrade = 0.2
Asshat.Temp = {}

local hostileWindow= "Asshat_Hostile"
local friendlyWindow = "Asshat_Friendly"

function Asshat.Init()
	--using a hook instead of PLAYER_TARGET_UPDATED event since we want the updated data
	--TargetWindow doesn't exist during Init(), so hooking after interface is loaded	
	RegisterEventHandler(SystemData.Events.LOADING_END, "Asshat.HookTargetWindow");	
 	RegisterEventHandler(SystemData.Events.INTERFACE_RELOADED, "Asshat.HookTargetWindow");	

	-- create hostile career label
	CreateWindow(hostileWindow, true)
	LabelSetText(hostileWindow.."Text", L"")
	WindowSetLayer(hostileWindow,  3)	

	-- create friendly career label	
	CreateWindow(friendlyWindow, true)
	LabelSetText(friendlyWindow.."Text", L"")	
	WindowSetLayer(friendlyWindow,  3)
	
	-- create ListedPrices if no saved settings
	if not Asshat_SavedData then 	
		Asshat_SavedData = { }
		Asshat_SavedData["version"] = Asshat.Version
	elseif not Asshat_SavedData["version"] then
		-- earlier release had a typo, so this should fix that problem
		Asshat_SavedData["version"] = Asshat.Version
	end	
		
	-- determine if default settings should be loaded
	if Asshat_SavedData["version"] < Asshat.ForceUpgrade then
		-- do new version stuff
		Asshat_SavedData["version"] = Asshat.Version
		TextLogAddEntry( "Chat", filter, towstring( "Asshat: New Version Detected") );	
	end

	-- determine server name for settings file
	Asshat.ServerName = WStringToString(GameData.Account.ServerName)
	if not Asshat_SavedData[Asshat.ServerName] then
		Asshat_SavedData[Asshat.ServerName] = { }
	end	
	
	-- register slash commands
	if LibSlash then
		LibSlash.RegisterSlashCmd( "asshat", function( args )Asshat.SlashCommand( args ) end )
		TextLogAddEntry( "Chat", filter, towstring( "Type /asshat for options.") );	
	else
		TextLogAddEntry( "Chat", filter, towstring( "Asshat: LibSlash not installed. Slash commands disabled.") );		
	end	
end	

local runOnce = true
function Asshat.HookTargetWindow()
	if runOnce then
		Asshat.HookedUpdateTarget = TargetWindow.UpdateTarget	
		TargetWindow.UpdateTarget = Asshat.OnUpdate
		runOnce = false
	end	
end

function Asshat.OnUpdate(...)
	local hostileText = L""
	local friendlyText = L""

	-- run the old function
	Asshat.HookedUpdateTarget(...)
	
	-- determine hostile note
	if TargetInfo.m_Units.selfhostiletarget ~= nil then
		if  TargetInfo.m_Units.selfhostiletarget.type == SystemData.TargetObjectType.ENEMY_PLAYER then
			hostileText = Asshat.Search(TargetInfo.m_Units.selfhostiletarget.name)
		end
	end
	
	-- determine friendly note
	if TargetInfo.m_Units.selffriendlytarget ~= nil then
		if TargetInfo.m_Units.selffriendlytarget.type == SystemData.TargetObjectType.ALLY_PLAYER then
			friendlyText = Asshat.Search(TargetInfo.m_Units.selffriendlytarget.name)
		end	
	end
	
	-- update text display
	LabelSetText(hostileWindow.."Text", hostileText)
	LabelSetText(friendlyWindow.."Text", friendlyText)	
end 
    
function Asshat.Search(playerName)
	playerName = string.upper(string.match(WStringToString(playerName), "(.+)(%^)(.+)"))
	if Asshat_SavedData[Asshat.ServerName][playerName] then
		return towstring(Asshat_SavedData[Asshat.ServerName][playerName])
	elseif Asshat.Temp[playerName] then
		return towstring(Asshat.Temp[playerName])
	end
	return L""
end
  
-- Slash command handler, requires LibSlash to be installed
function Asshat.SlashCommand(args)
	local opt, val = args:match( "([a-z0-9]+)[ ]?(.*)" )
	if opt == "temp" then
		Asshat.SetTemp(val)
	elseif opt == "perm" then
		Asshat.SetPerm(val)
	elseif opt == "reset" and (val == "temp" or val == "perm") then
		if val == "temp" then
			Asshat.Temp = {}
			EA_ChatWindow.Print(L"Asshat: Temp Notes Reset")	
		elseif val == "perm" then
			Asshat_SavedData[Asshat.ServerName] = {}
			EA_ChatWindow.Print(L"Asshat: Permanent Notes Reset")	
		end
	else
		EA_ChatWindow.Print(L"Usage: /asshat [temp|perm] [name] [note]")
		EA_ChatWindow.Print(L"Usage: /asshat [reset] [temp|perm]")		
	end	
end

function Asshat.SetTemp(args)
	local name, note = args:match( "([a-z0-9]+)[ ]?(.*)" )
	if name then
		name = name:upper()
		Asshat.Temp[name] = note
		EA_ChatWindow.Print(L"Asshat: The temp note for "..towstring(name)..L" has been set to: "..towstring(note))			
	end
end

function Asshat.SetPerm(args)
	local name, note = args:match( "([a-z0-9]+)[ ]?(.*)" )
	if name then
		name = name:upper()
		Asshat_SavedData[Asshat.ServerName][name] = note
		EA_ChatWindow.Print(L"Asshat: The perm note for "..towstring(name)..L" has been set to: "..towstring(note))			
	end
end

function Asshat.TargetNote(note, isFriendly, isPerm)
	local targetType = "selfhostiletarget"
	if isFriendly then
		targetType = "selffriendlytarget"
	end
	if TargetInfo.m_Units[targetType] ~= nil then
		if TargetInfo.m_Units[targetType].type == SystemData.TargetObjectType.ENEMY_PLAYER or TargetInfo.m_Units[targetType].type == SystemData.TargetObjectType.ALLY_PLAYER then
			local name = string.match(WStringToString(TargetInfo.m_Units[targetType].name), "(.+)(%^)(.+)")
			if isPerm then
				name = name:upper()
				Asshat_SavedData[Asshat.ServerName][name] = note
				EA_ChatWindow.Print(L"Asshat: The perm note for "..towstring(name)..L" has been set to: "..towstring(note))			
				return
			else
				name = name:upper()
				Asshat.Temp[name] = note
				EA_ChatWindow.Print(L"Asshat: The temp note for "..towstring(name)..L" has been set to: "..towstring(note))	
				return
			end
		end
	end
	EA_ChatWindow.Print(L"Asshat: Valid Target Not Selected")	
end

function Asshat.Shutdown()
	TargetWindow.UpdateTarget = Asshat.CareerTextHook
end
