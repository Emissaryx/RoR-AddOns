<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
	<UiMod name="Asshat" version="1.0" date="10/09/2008" >
		<Author name="sid67" email="none@private.com" />
		<Description text="Displays Large Note over Target Unit Frame." />
		<Files>
		  <File name="Asshat.xml" />		  
		</Files>
		<Dependencies>
		    <Dependency name="LibSlash" />
		</Dependencies>
		<SavedVariables>
			<SavedVariable name="Asshat_SavedData" />
		</SavedVariables>			
		<OnInitialize>
			<CallFunction name="Asshat.Init" />
		</OnInitialize>	
		<OnShutdown>
			<CallFunction name="Asshat.Shutdown" />
		</OnShutdown>		
	</UiMod>
</ModuleFile>