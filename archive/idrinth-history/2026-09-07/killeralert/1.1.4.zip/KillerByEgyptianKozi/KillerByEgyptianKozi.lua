--[[
	KillerByEgyptianKozi - On-screen kill/assist alert addon for Return of Reckoning
	
	Displays "You killed [EnemyName]" when you get the killing blow.
	Displays "You killed [EnemyName]" + "Final blow by [PlayerName]" when you
	assisted in a kill (the enemy was your recent target and someone else killed them).
	
	Supports stacking up to 7 simultaneous alert messages on screen.
	Each message fades out independently after the display duration.
	Sound plays on both kills and assists.
	
	Kill detection mirrors the Enemy addon's KillSpam parsing approach:
	  - Listens to the "Combat" text log for RVR kill messages
	  - Parses victim and killer from the localized kill message
	  - Compares killer to your own character name
	  - Tracks your recent hostile targets for assist detection
]]--

KillerByEgyptianKozi = KillerByEgyptianKozi or {}
KillerByEgyptianKozi.Settings = KillerByEgyptianKozi.Settings or {}

-- Locals for performance
local KA = KillerByEgyptianKozi
local d = EA_ChatWindow.Print
local tinsert = table.insert
local tremove = table.remove
local pairs = pairs
local towstring = towstring
local wsformat = wstring.format
local LabelSetText = LabelSetText
local LabelSetTextColor = LabelSetTextColor
local WindowSetShowing = WindowSetShowing
local WindowSetAlpha = WindowSetAlpha
local WindowStopAlphaAnimation = WindowStopAlphaAnimation
local WindowStartAlphaAnimation = WindowStartAlphaAnimation
local TextLogGetEntry = TextLogGetEntry
local TextLogGetNumEntries = TextLogGetNumEntries
local WindowClearAnchors = WindowClearAnchors
local WindowAddAnchor = WindowAddAnchor
local LabelGetTextDimensions = LabelGetTextDimensions
local WindowSetDimensions = WindowSetDimensions

-- Chat log filter constants for RVR kills
local ORDER = SystemData.ChatLogFilters.RVR_KILLS_ORDER
local DESTR = SystemData.ChatLogFilters.RVR_KILLS_DESTRUCTION

-- Internal state
local playerName = L""
local initialized = false
local updateElapsed = 0

-- Maximum number of visible alert slots
local MAX_SLOTS = 7

-- Message queue: ordered list of active messages (index 1 = newest/top)
-- Each entry: { killText = wstring, assistText = wstring, isAssist = bool, expireTime = number }
local messageQueue = {}

-- Slot state tracker: tracks the measurement state of slots 1-7
-- 0 = Needs text update (hidden)
-- 1 = Text updated, waiting 1 frame for measurement
-- 2 = Measured, positioned, and shown
local slotState = {}
for i = 1, 7 do
	slotState[i] = 0
end

local queueChanged = false

-- Track recent hostile targets (for assist detection)
-- Key = target name (wstring), Value = timestamp
local recentTargets = {}
local RECENT_TARGET_WINDOW = 15  -- seconds to keep a target as "recently targeted"


local function GetFormattedTime()
	local t = GetComputerTime() or 0
	local h = math.floor(t / 3600) % 24
	local m = math.floor(t / 60) % 60
	local s = math.floor(t) % 60
	return wsformat(L"%02d:%02d:%02d", h, m, s)
end

-------------------------------------------------------------------------------
-- Utility: strip career-line suffixes (the ^ character) from player names
-------------------------------------------------------------------------------
local function FixString(str)
	if (str == nil) then return nil end
	local match = wstring.match(str, L"([^%^]+)")
	return match or str
end


-------------------------------------------------------------------------------
-- Kill message parser (English - enUS)
-- Handles messages like:
--   "Denoto has been annihilated by Grikson's Hip Shot in Shadow Spire."
--   "Gogo has been killed by Darkaim in Unknown. Praag"
-------------------------------------------------------------------------------
local function ParseKillMessage(str)
	local victim, player, pre, tail = str:match(L"(%a+) has been .- by (%a+).* in ([^%.]+)%.%s*([^%.]*)")

	local location = pre
	if pre == L"Unknown" and tail ~= L"" then
		location = tail
	end

	return victim, player, location
end


-------------------------------------------------------------------------------
-- Get the window name for a slot index (1-7)
-------------------------------------------------------------------------------
local function SlotWindowName(index)
	return "KillerByEgyptianKoziSlot" .. index
end


-------------------------------------------------------------------------------
-- Refresh all 7 slot visuals from the message queue
-- Slot 1 = messageQueue[1] (newest), Slot 7 = messageQueue[7] (oldest)
-------------------------------------------------------------------------------
local function RefreshSlots()

	local playerRealm = (GameData.Player and GameData.Player.realm) or 1
	local fColor = (playerRealm == 1) and { r = 50, g = 180, b = 255 } or { r = 255, g = 70, b = 70 }
	local hColor = (playerRealm == 1) and { r = 255, g = 70, b = 70 } or { r = 50, g = 180, b = 255 }

	for i = 1, MAX_SLOTS do
		local slotName = SlotWindowName(i)
		local msg = messageQueue[i]

		if (msg) then
			-- Get label window names
			local killerLabel = slotName .. "KillerText"
			local actionLabel = slotName .. "ActionText"
			local victimLabel = slotName .. "VictimText"
			local prefixLabel = slotName .. "AssistPrefixText"
			local allyLabel = slotName .. "AssistKillerText"

			if (slotState[i] == 0) then
				-- Frame 1: Set text, visibility, and colors, but keep slot hidden to prevent jumpy/cropped render
				WindowSetShowing(slotName, false)
				WindowSetShowing(killerLabel, true)
				WindowSetShowing(actionLabel, true)
				WindowSetShowing(victimLabel, true)
				WindowSetShowing(prefixLabel, msg.isAssist)
				WindowSetShowing(allyLabel, msg.isAssist)

				LabelSetText(killerLabel, msg.killerName or L"")
				LabelSetText(victimLabel, msg.victimName or L"")

				if (msg.isAssist) then
					LabelSetText(actionLabel, L"assisted by")
					LabelSetText(prefixLabel, L"Final blow by")
					LabelSetText(allyLabel, msg.allyName or L"")
					LabelSetTextColor(prefixLabel, 200, 200, 200)
					LabelSetTextColor(allyLabel, fColor.r, fColor.g, fColor.b)
				else
					LabelSetText(actionLabel, L"killed")
				end

				LabelSetTextColor(killerLabel, fColor.r, fColor.g, fColor.b)
				LabelSetTextColor(actionLabel, 255, 255, 255)
				LabelSetTextColor(victimLabel, hColor.r, hColor.g, hColor.b)

				slotState[i] = 1

			elseif (slotState[i] == 1) then
				-- Frame 2: Query exact text dimensions after layout engine updates geometries
				local kw, kh = LabelGetTextDimensions(killerLabel)
				local aw, ah = LabelGetTextDimensions(actionLabel)
				local vw, vh = LabelGetTextDimensions(victimLabel)

				-- Add safety scaling and padding for bold fonts
				kw = (kw or 0) * 1.08 + 8
				kh = kh or 0
				aw = (aw or 0) * 1.08 + 8
				ah = ah or 0
				vw = (vw or 0) * 1.08 + 8
				vh = vh or 0

				WindowSetDimensions(killerLabel, kw, kh)
				WindowSetDimensions(actionLabel, aw, ah)
				WindowSetDimensions(victimLabel, vw, vh)

				local spacing = 2
				local totalMainWidth = kw + spacing + aw + spacing + vw
				local startX = (600 - totalMainWidth) / 2

				WindowClearAnchors(killerLabel)
				WindowClearAnchors(actionLabel)
				WindowClearAnchors(victimLabel)

				if (msg.isAssist) then
					WindowAddAnchor(victimLabel, "topleft", slotName, "topleft", startX, 0)
					WindowAddAnchor(actionLabel, "topleft", slotName, "topleft", startX + vw + spacing, 0)
					WindowAddAnchor(killerLabel, "topleft", slotName, "topleft", startX + vw + spacing + aw + spacing, 0)
				else
					WindowAddAnchor(killerLabel, "topleft", slotName, "topleft", startX, 0)
					WindowAddAnchor(actionLabel, "topleft", slotName, "topleft", startX + kw + spacing, 0)
					WindowAddAnchor(victimLabel, "topleft", slotName, "topleft", startX + kw + spacing + aw + spacing, 0)
				end

				if (msg.isAssist) then
					local pw, ph = LabelGetTextDimensions(prefixLabel)
					local lw, lh = LabelGetTextDimensions(allyLabel)

					pw = (pw or 0) * 1.08 + 8
					ph = ph or 0
					lw = (lw or 0) * 1.08 + 8
					lh = lh or 0

					WindowSetDimensions(prefixLabel, pw, ph)
					WindowSetDimensions(allyLabel, lw, lh)

					local totalSubWidth = pw + spacing + lw
					local subStartX = (600 - totalSubWidth) / 2

					WindowClearAnchors(prefixLabel)
					WindowClearAnchors(allyLabel)

					WindowAddAnchor(prefixLabel, "topleft", slotName, "topleft", subStartX, 28)
					WindowAddAnchor(allyLabel, "topleft", slotName, "topleft", subStartX + pw + spacing, 28)
				end

				slotState[i] = 2

				-- Fully positioned! Render the window.
				WindowSetShowing(slotName, true)

				-- Trigger fade-in animation if it's the top slot
				if (i == 1) then
					WindowStopAlphaAnimation(slotName)
					WindowStartAlphaAnimation(
						slotName,
						Window.AnimationType.SINGLE_NO_RESET,
						0, 1,    -- from alpha 0 to 1
						0.2,     -- duration 0.2s
						true,    -- setInitialAlpha
						0, 1     -- delay 0, loops 1
					)
				else
					-- Make sure shifting slots stay fully visible
					if (not msg.expired) then
						WindowStopAlphaAnimation(slotName)
						WindowSetAlpha(slotName, 1.0)
					end
				end
			end
		else
			-- Hide unused slots
			WindowSetShowing(slotName, false)
			slotState[i] = 0
		end
	end
end


-------------------------------------------------------------------------------
-- Fade out and remove a specific message from the queue by finding it
-------------------------------------------------------------------------------
local function ExpireMessage(msg)

	-- Find and remove from queue
	for i = #messageQueue, 1, -1 do
		if (messageQueue[i] == msg) then
			-- Start fade-out animation on the slot before removing
			local slotName = SlotWindowName(i)
			WindowStopAlphaAnimation(slotName)
			WindowStartAlphaAnimation(
				slotName,
				Window.AnimationType.SINGLE_NO_RESET,
				1, 0,    -- fade from 1 to 0
				0.8,     -- over 0.8 seconds
				true,    -- set initial alpha
				0, 1     -- no delay, 1 loop
			)

			-- Remove from queue after a short delay to let fade finish
			-- We mark it as expired so the update loop removes it
			msg.expired = true
			msg.fadeEndTime = GetComputerTime() + 0.85
			break
		end
	end
end


-------------------------------------------------------------------------------
-- Initialize
-------------------------------------------------------------------------------
function KillerByEgyptianKozi.Initialize()

	-- Get our player name
	playerName = FixString(GameData.Player.name)

	-- Default settings
	if (KA.Settings.enabled == nil) then
		KA.Settings.enabled = true
	end
	if (KA.Settings.showAssists == nil) then
		KA.Settings.showAssists = true
	end
	if (KA.Settings.displayDuration == nil) then
		KA.Settings.displayDuration = 4
	end
	if (KA.Settings.killSound == nil) then
		KA.Settings.killSound = GameData.Sound.QUEST_OBJECTIVES_COMPLETED
	end
	if (KA.Settings.assistSound == nil) then
		KA.Settings.assistSound = GameData.Sound.HELP_TIPS_NEW
	end
	if (KA.Settings.showTargetArrow == nil) then
		KA.Settings.showTargetArrow = true
	end
	if (KA.Settings.showHistoryWindow == nil) then
		KA.Settings.showHistoryWindow = true
	end

	-- Initialize history table
	KillerByEgyptianKozi.History = KillerByEgyptianKozi.History or {}

	-- Wait for career line data before full init
	RegisterEventHandler(SystemData.Events.PLAYER_CAREER_LINE_UPDATED, "KillerByEgyptianKozi._OnCareerReady")
	RegisterEventHandler(SystemData.Events.INTERFACE_RELOADED, "KillerByEgyptianKozi._OnCareerReady")
end


function KillerByEgyptianKozi._OnCareerReady()

	if (initialized) then return end
	if (not GameData.Player.career or not GameData.Player.career.line or GameData.Player.career.line < 1) then return end

	-- Get player name now that it is fully loaded
	playerName = FixString(GameData.Player.name)

	-- Create the alert window
	CreateWindow("KillerByEgyptianKoziWindow", true)
	LayoutEditor.RegisterWindow(
		"KillerByEgyptianKoziWindow",
		L"KillerByEgyptianKozi",
		L"Kill/Assist alert popup",
		true,   -- canResize
		true,   -- canScale
		true,   -- canAlpha
		nil
	)

	-- Create the history log window
	CreateWindow("KillerByEgyptianKoziHistoryWindow", true)
	LayoutEditor.RegisterWindow(
		"KillerByEgyptianKoziHistoryWindow",
		L"KillerByEgyptianKozi History",
		L"Displays a log of your recent kills and assists",
		true,   -- canResize
		true,   -- canScale
		true,   -- canAlpha
		nil
	)

	-- Set titlebar text
	LabelSetText("KillerByEgyptianKoziHistoryWindowTitleBarText", L"KillerByEgyptianKozi History")

	-- Parent is always shown; individual slots control their own visibility
	WindowSetShowing("KillerByEgyptianKoziWindow", true)

	-- Set showing status based on setting
	WindowSetShowing("KillerByEgyptianKoziHistoryWindow", KA.Settings.showHistoryWindow)

	-- Hide all slots initially
	for i = 1, MAX_SLOTS do
		WindowSetShowing(SlotWindowName(i), false)
	end

	-- Hide target arrow initially
	WindowSetShowing("KillerByEgyptianKoziTargetArrow", false)

	-- Register for combat log events
	if (KA.Settings.enabled) then
		KillerByEgyptianKozi._RegisterEvents()
	end

	-- Register for target tracking (for assists and visual arrow)
	RegisterEventHandler(SystemData.Events.PLAYER_TARGET_UPDATED, "KillerByEgyptianKozi._OnTargetUpdated")

	initialized = true

	UnregisterEventHandler(SystemData.Events.PLAYER_CAREER_LINE_UPDATED, "KillerByEgyptianKozi._OnCareerReady")

	-- Refresh history UI from saved variables
	KillerByEgyptianKozi.RefreshHistoryUI()

	-- If we already have a hostile target, show arrow
	TargetInfo:UpdateFromClient()
	local targetId = TargetInfo:UnitEntityId(TargetInfo.HOSTILE_TARGET)
	if (targetId and targetId ~= 0) then
		KillerByEgyptianKozi._OnTargetUpdated(TargetInfo.HOSTILE_TARGET, targetId)
	end
end


function KillerByEgyptianKozi._RegisterEvents()
	RegisterEventHandler(TextLogGetUpdateEventId("Combat"), "KillerByEgyptianKozi._OnCombatLog")
end


function KillerByEgyptianKozi._UnregisterEvents()
	UnregisterEventHandler(TextLogGetUpdateEventId("Combat"), "KillerByEgyptianKozi._OnCombatLog")
end


-------------------------------------------------------------------------------
-- Update (called every frame by the engine via OnUpdate)
-- Handles message expiration and cleanup
-------------------------------------------------------------------------------
function KillerByEgyptianKozi.Update(elapsed)

	local now = GetComputerTime()

	if (queueChanged) then
		queueChanged = false
	else
		-- Measure and position slots whose layout hasn't settled yet
		local needsPositioning = false
		for i = 1, MAX_SLOTS do
			if (slotState[i] == 1) then
				needsPositioning = true
				break
			end
		end

		if (needsPositioning) then
			RefreshSlots()
		end
	end

	local needsRefresh = false

	-- Check for expired messages
	for i = #messageQueue, 1, -1 do
		local msg = messageQueue[i]

		-- Message hasn't started fading yet - check if it should
		if (not msg.expired and now >= msg.expireTime) then
			ExpireMessage(msg)
		end

		-- Message has finished fading - remove it
		if (msg.expired and msg.fadeEndTime and now >= msg.fadeEndTime) then
			tremove(messageQueue, i)
			needsRefresh = true
		end
	end

	if (needsRefresh) then
		for j = 1, MAX_SLOTS do
			slotState[j] = 0
		end
		queueChanged = true
		RefreshSlots()
	end

	-- Clean up stale recent targets periodically
	updateElapsed = updateElapsed + (elapsed or 0)
	if (updateElapsed >= 5) then
		updateElapsed = 0
		KillerByEgyptianKozi._CleanRecentTargets()
	end
end


-------------------------------------------------------------------------------
-- Shutdown
-------------------------------------------------------------------------------
function KillerByEgyptianKozi.Shutdown()
	-- nothing critical to clean up
end


-------------------------------------------------------------------------------
-- History Log Window Helpers
-------------------------------------------------------------------------------
function KillerByEgyptianKozi.ToggleHistoryWindow()
	local show = not WindowGetShowing("KillerByEgyptianKoziHistoryWindow")
	WindowSetShowing("KillerByEgyptianKoziHistoryWindow", show)
	KA.Settings.showHistoryWindow = show
end

function KillerByEgyptianKozi.RefreshHistoryUI()
	if (not DoesWindowExist("KillerByEgyptianKoziHistoryWindow")) then return end

	local logText = L""
	for i = 1, #KillerByEgyptianKozi.History do
		if (i > 1) then
			logText = logText .. L"\n"
		end
		logText = logText .. KillerByEgyptianKozi.History[i]
	end

	LabelSetText("KillerByEgyptianKoziHistoryWindowContentScrollChildText", logText)

	-- 18px per line of font_clear_small
	local textHeight = #KillerByEgyptianKozi.History * 18
	if (textHeight < 270) then
		textHeight = 270
	end

	WindowSetDimensions("KillerByEgyptianKoziHistoryWindowContentScrollChild", 264, textHeight)
	WindowSetDimensions("KillerByEgyptianKoziHistoryWindowContentScrollChildText", 264, textHeight)
	ScrollWindowUpdateScrollRect("KillerByEgyptianKoziHistoryWindowContent")
end


-- Keep track of the currently attached hostile target world object ID
local currentAttachedTargetId = 0

-------------------------------------------------------------------------------
-- Target tracking for assist detection and visual arrow indicator
-------------------------------------------------------------------------------
function KillerByEgyptianKozi._OnTargetUpdated(targetClassification, targetId, targetType)

	TargetInfo:UpdateFromClient()

	-- 1. Track recent hostile targets for assists
	if (KA.Settings.showAssists) then
		local targetName = FixString(TargetInfo:UnitName(TargetInfo.HOSTILE_TARGET))
		if (targetName and targetName ~= L"") then
			recentTargets[targetName] = GetComputerTime()
		end
	end

	-- 2. Update visual target arrow indicator
	if (targetClassification == TargetInfo.HOSTILE_TARGET) then
		if (KA.Settings.showTargetArrow and targetId and targetId ~= 0) then
			if (currentAttachedTargetId ~= targetId) then
				if (DoesWindowExist("KillerByEgyptianKoziTargetArrowInstance")) then
					if (currentAttachedTargetId ~= 0) then
						DetachWindowFromWorldObject("KillerByEgyptianKoziTargetArrowInstance", currentAttachedTargetId)
					end
					DestroyWindow("KillerByEgyptianKoziTargetArrowInstance")
				end

				CreateWindowFromTemplate("KillerByEgyptianKoziTargetArrowInstance", "KillerByEgyptianKoziTargetArrow", "Root")
				WindowSetTintColor("KillerByEgyptianKoziTargetArrowInstanceContentArrow", 255, 0, 0)
				AttachWindowToWorldObject("KillerByEgyptianKoziTargetArrowInstance", targetId)
				WindowSetShowing("KillerByEgyptianKoziTargetArrowInstance", true)
				currentAttachedTargetId = targetId
			end
		else
			if (DoesWindowExist("KillerByEgyptianKoziTargetArrowInstance")) then
				if (currentAttachedTargetId ~= 0) then
					DetachWindowFromWorldObject("KillerByEgyptianKoziTargetArrowInstance", currentAttachedTargetId)
				end
				DestroyWindow("KillerByEgyptianKoziTargetArrowInstance")
				currentAttachedTargetId = 0
			end
		end
	end
end


function KillerByEgyptianKozi._CleanRecentTargets()
	local now = GetComputerTime()
	for name, timestamp in pairs(recentTargets) do
		if (now - timestamp > RECENT_TARGET_WINDOW) then
			recentTargets[name] = nil
		end
	end
end


-------------------------------------------------------------------------------
-- Combat log handler
-- Fires whenever a new entry is added to the "Combat" text log.
-------------------------------------------------------------------------------
function KillerByEgyptianKozi._OnCombatLog(updateType, filterType)

	-- Only process newly added RVR kill entries
	if (updateType ~= SystemData.TextLogUpdate.ADDED) then return end
	if (filterType ~= ORDER and filterType ~= DESTR) then return end

	local index = TextLogGetNumEntries("Combat") - 1
	local _, t, msg = TextLogGetEntry("Combat", index)
	if (t ~= ORDER and t ~= DESTR) then return end

	local victim, player, location = ParseKillMessage(msg)
	if (victim == nil or player == nil) then return end

	-- Ignore self-kills (lava, falling, etc.)
	if (victim == player) then return end
	if (player == L"falling" and msg:match(L" has been killed by falling in ") ~= nil) then return end

	-- Case 1: YOU got the killing blow
	if (player == playerName) then
		KillerByEgyptianKozi._ShowKillAlert(victim, nil)
		return
	end

	-- Case 2: Someone else killed a target you were recently fighting (assist)
	if (KA.Settings.showAssists and recentTargets[victim] ~= nil) then
		KillerByEgyptianKozi._ShowKillAlert(victim, player)
		-- Remove from recent targets so we don't double-alert
		recentTargets[victim] = nil
		return
	end
end


-------------------------------------------------------------------------------
-- Show the on-screen alert
--   victim:    name of the enemy who died (wstring)
--   killer:    name of the player who got final blow (wstring), or nil if YOU
-------------------------------------------------------------------------------
function KillerByEgyptianKozi._ShowKillAlert(victim, killer)

	local now = GetComputerTime()
	local duration = KA.Settings.displayDuration or 4
	local isAssist = (killer ~= nil)

	-- Play sound effect (repeated 8x for extra volume)
	if (not isAssist and KA.Settings.killSound) then
		PlaySound(KA.Settings.killSound)
		PlaySound(KA.Settings.killSound)
		PlaySound(KA.Settings.killSound)
		PlaySound(KA.Settings.killSound)
		PlaySound(KA.Settings.killSound)
		PlaySound(KA.Settings.killSound)
		PlaySound(KA.Settings.killSound)
		PlaySound(KA.Settings.killSound)
	elseif (isAssist and KA.Settings.assistSound) then
		PlaySound(KA.Settings.assistSound)
		PlaySound(KA.Settings.assistSound)
		PlaySound(KA.Settings.assistSound)
		PlaySound(KA.Settings.assistSound)
		PlaySound(KA.Settings.assistSound)
		PlaySound(KA.Settings.assistSound)
		PlaySound(KA.Settings.assistSound)
		PlaySound(KA.Settings.assistSound)
	end

	-- Add to persistent history
	local timeStr = GetFormattedTime()
	local logMsg
	if (isAssist) then
		logMsg = L"[" .. timeStr .. L"] Assisted: " .. victim .. L" (Final: " .. killer .. L")"
	else
		logMsg = L"[" .. timeStr .. L"] Killed: " .. victim
	end

	tinsert(KillerByEgyptianKozi.History, 1, logMsg)
	while (#KillerByEgyptianKozi.History > 50) do
		tremove(KillerByEgyptianKozi.History, 51)
	end

	KillerByEgyptianKozi.RefreshHistoryUI()

	-- Create the message entry
	local displayKiller = playerName
	if (not displayKiller or displayKiller == L"") then
		displayKiller = L"You"
	end

	local newMsg = {
		killerName = displayKiller,
		victimName = victim or L"Unknown",
		allyName = killer,
		isAssist = isAssist,
		expireTime = now + duration,
		expired = false,
		fadeEndTime = nil,
	}

	-- Insert at the top (position 1 = newest)
	tinsert(messageQueue, 1, newMsg)

	-- If we exceed MAX_SLOTS, remove the oldest (bottom)
	while (#messageQueue > MAX_SLOTS) do
		tremove(messageQueue, #messageQueue)
	end

	-- Reset all slot states so they undergo the 2-frame measurement cycle
	for i = 1, MAX_SLOTS do
		slotState[i] = 0
	end

	queueChanged = true

	-- Refresh all slot visuals
	RefreshSlots()
end


-------------------------------------------------------------------------------
-- Slash commands
-------------------------------------------------------------------------------
function KillerByEgyptianKozi.SlashCommand(args)

	local cmd = ""
	if (args) then
		if (type(args) == "wstring" and WStringToString) then
			local ok, res = pcall(WStringToString, args)
			if (ok and res) then cmd = res end
		else
			cmd = tostring(args)
		end
	end

	-- Trim leading/trailing whitespace and convert to lowercase
	cmd = cmd:match("^%s*(.-)%s*$") or ""
	cmd = string.lower(cmd)
	-- Normalize multiple spaces to a single space
	cmd = cmd:gsub("%s+", " ")

	if (cmd == "on" or cmd == "enable") then
		KA.Settings.enabled = true
		KillerByEgyptianKozi._RegisterEvents()
		d(L"[KillerByEgyptianKozi] Enabled")

	elseif (cmd == "off" or cmd == "disable") then
		KA.Settings.enabled = false
		KillerByEgyptianKozi._UnregisterEvents()
		d(L"[KillerByEgyptianKozi] Disabled")

	elseif (cmd == "assists on" or cmd == "assist on" or cmd == "assiston" or cmd == "assistson") then
		KA.Settings.showAssists = true
		d(L"[KillerByEgyptianKozi] Assist alerts enabled")

	elseif (cmd == "assists off" or cmd == "assist off" or cmd == "assistoff" or cmd == "assistsoff") then
		KA.Settings.showAssists = false
		recentTargets = {}
		d(L"[KillerByEgyptianKozi] Assist alerts disabled")

	elseif (cmd == "arrow on") then
		KA.Settings.showTargetArrow = true
		TargetInfo:UpdateFromClient()
		local targetId = TargetInfo:UnitEntityId(TargetInfo.HOSTILE_TARGET)
		if (targetId and targetId ~= 0) then
			KillerByEgyptianKozi._OnTargetUpdated(TargetInfo.HOSTILE_TARGET, targetId)
		end
		d(L"[KillerByEgyptianKozi] Target arrow indicator enabled")

	elseif (cmd == "arrow off") then
		KA.Settings.showTargetArrow = false
		if (DoesWindowExist("KillerByEgyptianKoziTargetArrowInstance")) then
			if (currentAttachedTargetId ~= 0) then
				DetachWindowFromWorldObject("KillerByEgyptianKoziTargetArrowInstance", currentAttachedTargetId)
			end
			DestroyWindow("KillerByEgyptianKoziTargetArrowInstance")
			currentAttachedTargetId = 0
		end
		d(L"[KillerByEgyptianKozi] Target arrow indicator disabled")

	elseif (cmd == "test") then
		KillerByEgyptianKozi._ShowKillAlert(L"TestEnemy", nil)

	elseif (cmd == "testassist") then
		KillerByEgyptianKozi._ShowKillAlert(L"TestEnemy", L"AlliedPlayer")

	elseif (cmd == "test7") then
		-- Rapid-fire 7 test messages to show stacking
		KillerByEgyptianKozi._ShowKillAlert(L"TargetOne", nil)
		KillerByEgyptianKozi._ShowKillAlert(L"TargetTwo", nil)
		KillerByEgyptianKozi._ShowKillAlert(L"TargetThree", L"AllyOne")
		KillerByEgyptianKozi._ShowKillAlert(L"TargetFour", nil)
		KillerByEgyptianKozi._ShowKillAlert(L"TargetFive", L"AllyTwo")
		KillerByEgyptianKozi._ShowKillAlert(L"TargetSix", nil)
		KillerByEgyptianKozi._ShowKillAlert(L"TargetSeven", L"AllyThree")

	elseif (cmd == "clear") then
		messageQueue = {}
		for i = 1, MAX_SLOTS do
			WindowSetShowing(SlotWindowName(i), false)
			slotState[i] = 0
		end
		d(L"[KillerByEgyptianKozi] Alerts cleared")

	elseif (cmd == "history" or cmd == "log") then
		KillerByEgyptianKozi.ToggleHistoryWindow()

	elseif (cmd == "reset") then
		recentTargets = {}
		KillerByEgyptianKozi.History = {}
		KillerByEgyptianKozi.RefreshHistoryUI()
		d(L"[KillerByEgyptianKozi] Recent targets and history cleared")

	else
		d(L"[KillerByEgyptianKozi] Commands:")
		d(L"  /killer on|off          - Enable/disable alerts")
		d(L"  /killer assist on|off   - Enable/disable assist alerts")
		d(L"  /killer arrow on|off    - Enable/disable hostile target arrow")
		d(L"  /killer history|log     - Toggle history log window")
		d(L"  /killer test            - Show a test kill alert")
		d(L"  /killer testassist      - Show a test assist alert")
		d(L"  /killer test7           - Show 7 stacked test alerts")
		d(L"  /killer clear           - Clear all visible alerts")
		d(L"  /killer reset           - Reset tracked targets & clear history")
	end
end

-- Register slash commands with LibSlash if available
if LibSlash and LibSlash.RegisterSlashCmd then
	pcall(LibSlash.RegisterSlashCmd, "killer", function(args) KillerByEgyptianKozi.SlashCommand(args) end)
	pcall(LibSlash.RegisterSlashCmd, "killerbyegyptiankozi", function(args) KillerByEgyptianKozi.SlashCommand(args) end)
end

-- Usage: type these directly in the game chat window:
--   /killer on
--   /killer off
--   /killer assists on
--   /killer assists off
--   /killer arrow on
--   /killer arrow off
--   /killer history
--   /killer test
--   /killer testassist
--   /killer test7
--   /killer clear
--   /killer reset
