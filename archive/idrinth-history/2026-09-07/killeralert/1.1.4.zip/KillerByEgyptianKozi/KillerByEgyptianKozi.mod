<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
	<UiMod name="KillerByEgyptianKozi" version="1.0.0" date="07/14/2026" autoenabled="true">

		<VersionSettings gameVersion="1.4.8" windowsVersion="1.0" savedVariablesVersion="1.0" />

		<Author name="Custom" email="" />
		<Description text="Displays an on-screen alert when you kill an enemy or assist in a kill." />

		<WARInfo>
		    <Categories>
		        <Category name="RVR" />
		    </Categories>
		    <Careers>
		        <Career name="BLACKGUARD" />
		        <Career name="WITCH_ELF" />
		        <Career name="DISCIPLE" />
		        <Career name="SORCERER" />
		        <Career name="IRON_BREAKER" />
		        <Career name="SLAYER" />
		        <Career name="RUNE_PRIEST" />
		        <Career name="ENGINEER" />
		        <Career name="BLACK_ORC" />
		        <Career name="CHOPPA" />
		        <Career name="SHAMAN" />
		        <Career name="SQUIG_HERDER" />
		        <Career name="WITCH_HUNTER" />
		        <Career name="KNIGHT" />
		        <Career name="BRIGHT_WIZARD" />
		        <Career name="WARRIOR_PRIEST" />
		        <Career name="CHOSEN" />
		        <Career name="MARAUDER" />
		        <Career name="ZEALOT" />
		        <Career name="MAGUS" />
		        <Career name="SWORDMASTER" />
		        <Career name="SHADOW_WARRIOR" />
		        <Career name="WHITE_LION" />
		        <Career name="ARCHMAGE" />
		    </Careers>
		</WARInfo>

		<Dependencies>
			<Dependency name="EA_ChatWindow" />
			<Dependency name="LibSlash" />
		</Dependencies>

		<Files>
			<File name="KillerByEgyptianKozi.lua" />
			<File name="KillerByEgyptianKozi.xml" />
		</Files>

		<OnInitialize>
			<CallFunction name="KillerByEgyptianKozi.Initialize" />
		</OnInitialize>

		<SavedVariables>
			<SavedVariable name="KillerByEgyptianKozi.Settings" global="false" />
			<SavedVariable name="KillerByEgyptianKozi.History" global="false" />
		</SavedVariables>

		<OnUpdate>
			<CallFunction name="KillerByEgyptianKozi.Update" />
		</OnUpdate>

		<OnShutdown>
			<CallFunction name="KillerByEgyptianKozi.Shutdown" />
		</OnShutdown>

	</UiMod>
</ModuleFile>
