--[[
	KillerByEgyptianKozi - On-screen kill/assist alert addon for Return of Reckoning

	Displays "[You] killed [EnemyName]" when you get the killing blow.
	Displays "[You] assisted [Ally] to kill [EnemyName]" when you assisted in a
	kill (the enemy was your recent target and someone else killed them).

	Supports stacking up to 7 simultaneous alert messages on screen.
	Each message fades out independently after the display duration.
	Sound plays on both kills and assists.

	Kill detection mirrors the Enemy addon's KillSpam parsing approach:
	  - Listens to the "Combat" text log for RVR kill messages
	  - Parses victim and killer from the localized kill message
	  - Compares killer to your own character name
	  - Tracks your recent hostile targets for assist detection

	v2.0 features:
	  - Kill Streak & Accolades system (Double Kill ... Godlike) with banner + sounds
	  - Renown/XP reward capture, correlated to kills and shown on alert slots
	  - Career icons next to victim names in alert slots (hidden if unknown)
	  - Graphical configuration panel (/killer config)
	  - Persistent stats HUD (/killer hud; click it to open the config panel)
	  - Red 3D target arrow, with optional health-percentage tinting
]]--

KillerByEgyptianKozi = KillerByEgyptianKozi or {}
KillerByEgyptianKozi.Settings = KillerByEgyptianKozi.Settings or {}
KillerByEgyptianKozi.Stats = KillerByEgyptianKozi.Stats or {}

-- Locals for performance
local KA = KillerByEgyptianKozi
local d = EA_ChatWindow.Print
local tinsert = table.insert
local tremove = table.remove
local pairs = pairs
local towstring = towstring
local wsformat = wstring.format
local LabelSetText = LabelSetText
local LabelSetTextColor = LabelSetTextColor
local WindowSetShowing = WindowSetShowing
local WindowSetAlpha = WindowSetAlpha
local WindowStopAlphaAnimation = WindowStopAlphaAnimation
local WindowStartAlphaAnimation = WindowStartAlphaAnimation
local TextLogGetEntry = TextLogGetEntry
local TextLogGetNumEntries = TextLogGetNumEntries
local WindowClearAnchors = WindowClearAnchors
local WindowAddAnchor = WindowAddAnchor
local LabelGetTextDimensions = LabelGetTextDimensions
local WindowSetDimensions = WindowSetDimensions
local WindowSetTintColor = WindowSetTintColor
local DoesWindowExist = DoesWindowExist
local PlaySound = PlaySound

-- Chat log filter constants for RVR kills
local ORDER = SystemData.ChatLogFilters.RVR_KILLS_ORDER
local DESTR = SystemData.ChatLogFilters.RVR_KILLS_DESTRUCTION

-- Internal state
local playerName = L""
local initialized = false
local updateElapsed = 0

-- Maximum number of visible alert slots
local MAX_SLOTS = 7

-- Layout constants for the alert slots
local SLOT_WIDTH = 600
local ICON_SIZE = 24
local ICON_PAD = 6

-- Message queue: ordered list of active messages (index 1 = newest/top)
-- Each entry: { killerName, victimName, allyName, isAssist, expireTime,
--               careerLine, victimRealm, rp, xp, iconShown, hasReward, ... }
local messageQueue = {}

-- Slot state tracker: tracks the measurement state of slots 1-7
-- 0 = Needs text update (hidden)
-- 1 = Text updated, waiting 1 frame for measurement
-- 2 = Measured, positioned, and shown
local slotState = {}
for i = 1, 7 do
	slotState[i] = 0
end

local queueChanged = false

-- Track recent hostile targets (for assist detection AND career icon lookup)
-- Key = target name (wstring), Value = { time = number, careerLine = number }
local recentTargets = {}
local RECENT_TARGET_WINDOW = 15  -- seconds to keep a target as "recently targeted"

-------------------------------------------------------------------------------
-- Death Recap: damage-taken tracking for the current life
--   damageTracker: keyed by attacker name (normal Lua string), holding the
--                  accumulated damage they've dealt to you this life.
--   attackerOrder: chronological list of unique attacker names (first-hit
--                  order), so we can report the last 10 that hit you.
-- Keys are normal Lua strings (converted from wstring) so table lookups work
-- reliably; wstring userdata do not compare/hash as table keys.
-------------------------------------------------------------------------------
local damageTracker = {}   -- [attackerName(string)] = { damage = number, display = wstring }
local attackerOrder = {}   -- ordered list of attacker names (string), first-seen order
local MAX_RECAP_ATTACKERS = 10

-- Highest Combat-log entry index already processed for damage, so the same
-- physical entry isn't counted twice if the update handler fires once per
-- filter the entry belongs to.
local lastDamageEntryIndex = -1

-------------------------------------------------------------------------------
-- Kill streak state
-------------------------------------------------------------------------------
local currentStreak = 0
local playerIsDead = false
-- Latch: set true once we've seen the player alive (HP>0) with real data this
-- life; required before a HP<=0 reading counts as a death. Prevents the recap
-- from firing on teleports/zoning, where HP momentarily reads 0.
local playerHasBeenAlive = false
-- Consecutive HP-poll ticks the player has read <= 0. A death must persist for
-- 2 ticks (~1s); a teleport/zoning blip clears within one, so it never counts.
local zeroHpPolls = 0
local deathPollElapsed = 0

local STREAK_MILESTONES = {
	[2]  = L"DOUBLE KILL!",
	[3]  = L"TRIPLE KILL!",
	[4]  = L"QUADRA KILL!",
	[5]  = L"PENTAKILL!",
	[10] = L"RAMPAGE!",
	[15] = L"GODLIKE!",
}

-- Streak banner animation state (nil when banner is idle/hidden)
local streakBanner = nil

-------------------------------------------------------------------------------
-- Reward (Renown/XP) correlation state
-------------------------------------------------------------------------------
local lastRenownEarned = nil
local lastXpEarned = nil
local REWARD_CORRELATION_WINDOW = 4  -- seconds after a kill to accept RP/XP deltas

-------------------------------------------------------------------------------
-- Target arrow health tinting state
-------------------------------------------------------------------------------
local arrowTintElapsed = 0
local ARROW_TINT_INTERVAL = 0.25

-- Currently attached hostile target world object ID (0 = no arrow attached)
local currentAttachedTargetId = 0

-------------------------------------------------------------------------------
-- Career icon mapping
--   Primary:  Icons.GetCareerIconIDFromCareerLine (default UI helper)
--   Fallback: manual table below (fill in icon IDs if the helper is missing
--             on your client build), then faction flags, then graceful hide.
-------------------------------------------------------------------------------
local CAREER_ICON_FALLBACK = {
	-- [GameData.CareerLine.XXX] = <iconID>,  -- customize if needed
}

-- Realm emblem icon IDs used when the victim's career is unknown.
-- Left empty by default so no wrong icon can ever display: with no entry the
-- icon space is simply hidden. To enable faction flags, fill in verified icon
-- IDs for your client, e.g. { [1] = <orderIconID>, [2] = <destroIconID> }.
local FACTION_ICON_IDS = {}

local GOLD = { r = 255, g = 215, b = 0 }


local function GetFormattedTime()
	local t = GetComputerTime() or 0
	local h = math.floor(t / 3600) % 24
	local m = math.floor(t / 60) % 60
	local s = math.floor(t) % 60
	return wsformat(L"%02d:%02d:%02d", h, m, s)
end

-------------------------------------------------------------------------------
-- Utility: strip career-line suffixes (the ^ character) from player names
-------------------------------------------------------------------------------
local function FixString(str)
	if (str == nil) then return nil end
	local match = wstring.match(str, L"([^%^]+)")
	return match or str
end


-------------------------------------------------------------------------------
-- Kill message parser (English - enUS)
-- Handles messages like:
--   "Denoto has been annihilated by Grikson's Hip Shot in Shadow Spire."
--   "Gogo has been killed by Darkaim in Unknown. Praag"
-------------------------------------------------------------------------------
local function ParseKillMessage(str)
	local victim, player, pre, tail = str:match(L"(%a+) has been .- by (%a+).* in ([^%.]+)%.%s*([^%.]*)")

	local location = pre
	if pre == L"Unknown" and tail ~= L"" then
		location = tail
	end

	return victim, player, location
end


-------------------------------------------------------------------------------
-- Death Recap: parse "damage taken" combat log entries (English - enUS)
--
-- Returns attacker (wstring) and damage amount (number), or nil if the line is
-- not a damage-taken event. Handles the three common phrasings:
--   Direct:   "Attacker hits you for 1234 Spirit damage."
--             "Attacker critical hits you for 1234 Spirit damage."
--   Ability:  "Attacker's Fireball hits you for 1234 Fire damage."
--             "Attacker's Fireball critical hits you for 1234 Fire damage."
--   DoT:      "You suffer 1234 Corporeal damage from Attacker's Rot."
--
-- Damage numbers may contain thousands separators (commas) on some clients, so
-- we strip non-digits before tonumber. Names may carry a career-line suffix
-- (the ^ char), stripped via FixString.
-------------------------------------------------------------------------------
local function ParseDamageTaken(str)
	if (str == nil) then return nil, nil end

	local attacker, amount

	-- Direct / ability hits: "<Attacker[...]> [critical ]hits you for <N> <Type> damage."
	-- The attacker chunk stops before " hits you" / " critical hits you". Any
	-- "'s Ability" portion is captured with the attacker, then trimmed below.
	attacker, amount = str:match(L"^(.-) hits you for ([%d,]+) ")
	if (attacker == nil) then
		-- DoT phrasing: "You suffer <N> <Type> damage from <Attacker>'s <Ability>."
		amount, attacker = str:match(L"^You suffer ([%d,]+) .- damage from (.-)%.%s*$")
	end

	if (attacker == nil or amount == nil) then return nil, nil end

	-- Trim a trailing " critical" that the direct-hit pattern leaves attached
	-- (matched "<Attacker[ critical]>" before " hits you")
	local trimmed = wstring.match(attacker, L"^(.-) critical$")
	if (trimmed) then attacker = trimmed end

	-- Strip an "'s <Ability>" suffix so only the attacker name remains.
	local baseName = wstring.match(attacker, L"^(.-)'s ")
	if (baseName) then attacker = baseName end

	-- Strip career-line suffix (^) and reject empty results
	attacker = FixString(attacker)
	if (attacker == nil or attacker == L"") then return nil, nil end

	-- Damage may include thousands separators ("1,234"). Convert the captured
	-- number to a normal Lua string, strip everything but digits, then tonumber.
	local amountStr = WStringToString(amount)
	if (amountStr == nil) then return nil, nil end
	amountStr = string.gsub(amountStr, "[^%d]", "")
	local dmg = tonumber(amountStr)
	if (dmg == nil or dmg <= 0) then return nil, nil end

	return attacker, dmg
end


-------------------------------------------------------------------------------
-- Death Recap: record damage taken from an attacker for the current life
-------------------------------------------------------------------------------
local function RecordDamageTaken(attackerWStr, amount)
	if (attackerWStr == nil or amount == nil or amount <= 0) then return end

	-- Use a normal Lua string as the table key (wstring userdata is unreliable
	-- as a key); keep the wstring around for display.
	local key = WStringToString(attackerWStr)
	if (key == nil or key == "") then return end

	-- Career line, if we captured it while this enemy was targeted (may be nil).
	-- recentTargets is keyed by the wstring name, populated in _OnTargetUpdated.
	local recent = recentTargets[attackerWStr]
	local careerLine = recent and recent.careerLine or nil

	local entry = damageTracker[key]
	if (entry) then
		entry.damage = entry.damage + amount
		-- Fill in the career line if it wasn't known on an earlier hit
		if (careerLine and not entry.careerLine) then
			entry.careerLine = careerLine
		end
	else
		damageTracker[key] = { damage = amount, display = attackerWStr, careerLine = careerLine }
		tinsert(attackerOrder, key)
	end
end


-------------------------------------------------------------------------------
-- Death Recap: clear all tracked damage (start fresh for the next life)
-------------------------------------------------------------------------------
local function ClearDamageTracker()
	damageTracker = {}
	attackerOrder = {}
end


-------------------------------------------------------------------------------
-- Get the window name for a slot index (1-7)
-------------------------------------------------------------------------------
local function SlotWindowName(index)
	return "KillerByEgyptianKoziSlot" .. index
end


-------------------------------------------------------------------------------
-- Career icon helpers
-------------------------------------------------------------------------------
local function GetCareerIconID(careerLine)
	if (not careerLine or careerLine <= 0) then return nil end

	if (Icons and Icons.GetCareerIconIDFromCareerLine) then
		local ok, id = pcall(Icons.GetCareerIconIDFromCareerLine, careerLine)
		if (ok and id and id > 0) then
			return id
		end
	end

	return CAREER_ICON_FALLBACK[careerLine]
end

-- Try to apply an icon to the slot's DynamicImage. Returns true on success.
local function ApplySlotIcon(iconWindow, iconId)
	if (not iconId) then return false end

	local ok, texture, texX, texY = pcall(GetIconData, iconId)
	if (not ok or not texture or texture == "") then
		return false
	end

	local ok2 = pcall(DynamicImageSetTexture, iconWindow, texture, texX or 0, texY or 0)
	return ok2 == true
end


-------------------------------------------------------------------------------
-- Build the gold reward suffix wstring for a message, or nil if none to show
-------------------------------------------------------------------------------
local function BuildRewardText(msg)
	if (not KA.Settings.showRewards) then return nil end

	local rp = msg.rp or 0
	local xp = msg.xp or 0
	if (rp <= 0 and xp <= 0) then return nil end

	if (rp > 0 and xp > 0) then
		return wsformat(L"+%d RP / +%d XP", rp, xp)
	elseif (rp > 0) then
		return wsformat(L"+%d RP", rp)
	else
		return wsformat(L"+%d XP", xp)
	end
end


-------------------------------------------------------------------------------
-- Refresh all 7 slot visuals from the message queue
-- Slot 1 = messageQueue[1] (newest), Slot 7 = messageQueue[7] (oldest)
--
-- 2-frame measurement cycle (DO NOT collapse into one frame; the engine
-- returns stale text geometry on the frame the text was set):
--   State 0: set text/textures/colors, keep hidden
--   State 1: one frame later, measure, position, show
--   State 2: fully rendered
-------------------------------------------------------------------------------
local function RefreshSlots()

	local playerRealm = (GameData.Player and GameData.Player.realm) or 1
	local fColor = (playerRealm == 1) and { r = 50, g = 180, b = 255 } or { r = 255, g = 70, b = 70 }
	local hColor = (playerRealm == 1) and { r = 255, g = 70, b = 70 } or { r = 50, g = 180, b = 255 }

	for i = 1, MAX_SLOTS do
		local slotName = SlotWindowName(i)
		local msg = messageQueue[i]

		if (msg) then
			-- Get label window names
			local killerLabel = slotName .. "KillerText"
			local actionLabel = slotName .. "ActionText"
			local victimLabel = slotName .. "VictimText"
			local prefixLabel = slotName .. "AssistPrefixText"
			local allyLabel = slotName .. "AssistKillerText"
			local rewardLabel = slotName .. "RewardText"
			local iconWindow = slotName .. "CareerIcon"

			if (slotState[i] == 0) then
				-- Frame 1: Set text, visibility, and colors, but keep slot hidden to prevent jumpy/cropped render
				-- Kill:   Killer  killed  [icon] Victim
				-- Assist: You(CharacterName)  assisted  Ally  to kill  [icon] Victim   -- single line
				WindowSetShowing(slotName, false)
				WindowSetShowing(killerLabel, true)
				WindowSetShowing(actionLabel, true)
				WindowSetShowing(victimLabel, true)
				WindowSetShowing(prefixLabel, msg.isAssist)
				WindowSetShowing(allyLabel, msg.isAssist)

				LabelSetText(killerLabel, msg.killerName or L"")
				LabelSetText(victimLabel, msg.victimName or L"")

				if (msg.isAssist) then
					LabelSetText(actionLabel, L"assisted")
					LabelSetText(allyLabel, msg.allyName or L"?")
					LabelSetTextColor(allyLabel, fColor.r, fColor.g, fColor.b)
					LabelSetText(prefixLabel, L"to kill")
					LabelSetTextColor(prefixLabel, 255, 255, 255)
				else
					LabelSetText(actionLabel, L"killed")
				end

				LabelSetTextColor(killerLabel, fColor.r, fColor.g, fColor.b)
				LabelSetTextColor(actionLabel, 255, 255, 255)
				LabelSetTextColor(victimLabel, hColor.r, hColor.g, hColor.b)

				-- Career / faction icon: resolve texture now, position next frame
				msg.iconShown = false
				local iconId = GetCareerIconID(msg.careerLine)
				if (not iconId) then
					iconId = FACTION_ICON_IDS[msg.victimRealm or 0]
				end
				if (iconId and ApplySlotIcon(iconWindow, iconId)) then
					msg.iconShown = true
				end
				WindowSetShowing(iconWindow, msg.iconShown)

				-- Reward subtitle text (gold)
				local rewardText = BuildRewardText(msg)
				msg.hasReward = (rewardText ~= nil)
				if (msg.hasReward) then
					LabelSetText(rewardLabel, rewardText)
					LabelSetTextColor(rewardLabel, GOLD.r, GOLD.g, GOLD.b)
				end
				WindowSetShowing(rewardLabel, msg.hasReward)

				slotState[i] = 1

			elseif (slotState[i] == 1) then
				-- Frame 2: Query exact text dimensions after layout engine updates geometries
				local kw, kh = LabelGetTextDimensions(killerLabel)
				local vw, vh = LabelGetTextDimensions(victimLabel)

				-- Add safety scaling and padding for bold fonts
				kw = (kw or 0) * 1.08 + 8
				kh = kh or 0
				vw = (vw or 0) * 1.08 + 8
				vh = vh or 0

				WindowSetDimensions(killerLabel, kw, kh)
				WindowSetDimensions(victimLabel, vw, vh)

				local spacing = 2

				-- Icon occupies fixed space directly before the victim's name
				local iconSpan = 0
				if (msg.iconShown) then
					iconSpan = ICON_SIZE + ICON_PAD
				end

				WindowClearAnchors(killerLabel)
				WindowClearAnchors(victimLabel)

				if (msg.isAssist) then
					-- You(CharacterName) assisted Ally to kill [icon] Victim
					local aw, ah = LabelGetTextDimensions(actionLabel)
					local lw, lh = LabelGetTextDimensions(allyLabel)
					local pw, ph = LabelGetTextDimensions(prefixLabel)

					aw = (aw or 0) * 1.08 + 8
					ah = ah or 0
					lw = (lw or 0) * 1.08 + 8
					lh = lh or 0
					pw = (pw or 0) * 1.08 + 8
					ph = ph or 0

					WindowSetDimensions(actionLabel, aw, ah)
					WindowSetDimensions(allyLabel, lw, lh)
					WindowSetDimensions(prefixLabel, pw, ph)

					local totalMainWidth = kw + spacing + aw + spacing + lw + spacing + pw + spacing + iconSpan + vw
					local startX = (SLOT_WIDTH - totalMainWidth) / 2
					local x = startX

					WindowAddAnchor(killerLabel, "topleft", slotName, "topleft", x, 0)
					x = x + kw + spacing

					WindowClearAnchors(actionLabel)
					WindowAddAnchor(actionLabel, "topleft", slotName, "topleft", x, 0)
					x = x + aw + spacing

					-- Ally name and "to kill" use the smaller bold font: nudge down
					-- for baseline alignment with the main line
					WindowClearAnchors(allyLabel)
					WindowAddAnchor(allyLabel, "topleft", slotName, "topleft", x, 4)
					x = x + lw + spacing

					WindowClearAnchors(prefixLabel)
					WindowAddAnchor(prefixLabel, "topleft", slotName, "topleft", x, 4)
					x = x + pw + spacing

					if (msg.iconShown) then
						WindowClearAnchors(iconWindow)
						WindowSetDimensions(iconWindow, ICON_SIZE, ICON_SIZE)
						WindowAddAnchor(iconWindow, "topleft", slotName, "topleft", x, 2)
					end
					WindowAddAnchor(victimLabel, "topleft", slotName, "topleft", x + iconSpan, 0)
				else
					-- Killer killed [icon] Victim
					local aw, ah = LabelGetTextDimensions(actionLabel)
					aw = (aw or 0) * 1.08 + 8
					ah = ah or 0
					WindowSetDimensions(actionLabel, aw, ah)

					local totalMainWidth = kw + spacing + aw + spacing + iconSpan + vw
					local startX = (SLOT_WIDTH - totalMainWidth) / 2

					WindowAddAnchor(killerLabel, "topleft", slotName, "topleft", startX, 0)
					WindowClearAnchors(actionLabel)
					WindowAddAnchor(actionLabel, "topleft", slotName, "topleft", startX + kw + spacing, 0)
					if (msg.iconShown) then
						WindowClearAnchors(iconWindow)
						WindowSetDimensions(iconWindow, ICON_SIZE, ICON_SIZE)
						WindowAddAnchor(iconWindow, "topleft", slotName, "topleft", startX + kw + spacing + aw + spacing, 2)
					end
					WindowAddAnchor(victimLabel, "topleft", slotName, "topleft", startX + kw + spacing + aw + spacing + iconSpan, 0)
				end

				-- Second line (y=28): reward text centered (kills and assists alike)
				if (msg.hasReward) then
					local rw, rh = LabelGetTextDimensions(rewardLabel)
					rw = (rw or 0) * 1.08 + 8
					rh = rh or 0

					WindowSetDimensions(rewardLabel, rw, rh)
					WindowClearAnchors(rewardLabel)
					WindowAddAnchor(rewardLabel, "topleft", slotName, "topleft", (SLOT_WIDTH - rw) / 2, 28)
				end

				slotState[i] = 2

				-- Fully positioned! Render the window.
				WindowSetShowing(slotName, true)

				-- Trigger fade-in animation if it's the top slot
				if (i == 1) then
					WindowStopAlphaAnimation(slotName)
					WindowStartAlphaAnimation(
						slotName,
						Window.AnimationType.SINGLE_NO_RESET,
						0, 1,    -- from alpha 0 to 1
						0.2,     -- duration 0.2s
						true,    -- setInitialAlpha
						0, 1     -- delay 0, loops 1
					)
				else
					-- Make sure shifting slots stay fully visible
					if (not msg.expired) then
						WindowStopAlphaAnimation(slotName)
						WindowSetAlpha(slotName, 1.0)
					end
				end
			end
		else
			-- Hide unused slots
			WindowSetShowing(slotName, false)
			slotState[i] = 0
		end
	end
end


-- Force every visible slot back through the 2-frame measurement cycle
local function RelayoutAllSlots()
	for i = 1, MAX_SLOTS do
		slotState[i] = 0
	end
	queueChanged = true
	RefreshSlots()
end


-------------------------------------------------------------------------------
-- Fade out and remove a specific message from the queue by finding it
-------------------------------------------------------------------------------
local function ExpireMessage(msg)

	-- Find and remove from queue
	for i = #messageQueue, 1, -1 do
		if (messageQueue[i] == msg) then
			-- Start fade-out animation on the slot before removing
			local slotName = SlotWindowName(i)
			WindowStopAlphaAnimation(slotName)
			WindowStartAlphaAnimation(
				slotName,
				Window.AnimationType.SINGLE_NO_RESET,
				1, 0,    -- fade from 1 to 0
				0.8,     -- over 0.8 seconds
				true,    -- set initial alpha
				0, 1     -- no delay, 1 loop
			)

			-- Remove from queue after a short delay to let fade finish
			-- We mark it as expired so the update loop removes it
			msg.expired = true
			msg.fadeEndTime = GetComputerTime() + 0.85
			break
		end
	end
end


-------------------------------------------------------------------------------
-- History helper
-------------------------------------------------------------------------------
local function AddHistoryEntry(logMsg)
	tinsert(KillerByEgyptianKozi.History, 1, logMsg)
	while (#KillerByEgyptianKozi.History > 50) do
		tremove(KillerByEgyptianKozi.History, 51)
	end
	KillerByEgyptianKozi.RefreshHistoryUI()
end


-------------------------------------------------------------------------------
-- Initialize
-------------------------------------------------------------------------------
function KillerByEgyptianKozi.Initialize()

	-- Get our player name
	playerName = FixString(GameData.Player.name)

	-- Default settings
	if (KA.Settings.enabled == nil) then
		KA.Settings.enabled = true
	end
	if (KA.Settings.showAssists == nil) then
		KA.Settings.showAssists = true
	end
	if (KA.Settings.displayDuration == nil) then
		KA.Settings.displayDuration = 4
	end
	if (KA.Settings.killSound == nil) then
		KA.Settings.killSound = GameData.Sound.QUEST_OBJECTIVES_COMPLETED
	end
	if (KA.Settings.assistSound == nil) then
		KA.Settings.assistSound = GameData.Sound.HELP_TIPS_NEW
	end
	if (KA.Settings.showTargetArrow == nil) then
		KA.Settings.showTargetArrow = true
	end
	if (KA.Settings.showHistoryWindow == nil) then
		KA.Settings.showHistoryWindow = true
	end
	if (KA.Settings.showRewards == nil) then
		KA.Settings.showRewards = true
	end
	if (KA.Settings.showStreaks == nil) then
		KA.Settings.showStreaks = true
	end
	-- Arrow is plain red by default; health-coloring is opt-in via the config
	-- panel. The one-time migration flips previously-saved settings to red.
	if (KA.Settings.arrowHealthColor == nil or not KA.Settings.arrowRedDefaultMigrated) then
		KA.Settings.arrowHealthColor = false
		KA.Settings.arrowRedDefaultMigrated = true
	end
	if (KA.Settings.soundRepeats == nil) then
		KA.Settings.soundRepeats = 8
	end
	if (KA.Settings.showHUD == nil) then
		KA.Settings.showHUD = true
	end
	if (KA.Settings.showDeathRecap == nil) then
		KA.Settings.showDeathRecap = true
	end

	-- Initialize history & stats tables
	KillerByEgyptianKozi.History = KillerByEgyptianKozi.History or {}
	KA.Stats.bestStreak = KA.Stats.bestStreak or 0
	KA.Stats.totalKills = KA.Stats.totalKills or 0
	KA.Stats.totalAssists = KA.Stats.totalAssists or 0
	KA.Stats.totalRP = KA.Stats.totalRP or 0
	KA.Stats.totalXP = KA.Stats.totalXP or 0

	-- Wait for career line data before full init
	RegisterEventHandler(SystemData.Events.PLAYER_CAREER_LINE_UPDATED, "KillerByEgyptianKozi._OnCareerReady")
	RegisterEventHandler(SystemData.Events.INTERFACE_RELOADED, "KillerByEgyptianKozi._OnCareerReady")
end


-- Create a window and register it with the LayoutEditor, reporting any engine
-- error to chat instead of silently aborting the whole init sequence.
local function SafeCreateWindow(windowName, show, displayName, description, canResize)
	local ok, err = pcall(CreateWindow, windowName, show)
	if (not ok or not DoesWindowExist(windowName)) then
		d(towstring("[KillerByEgyptianKozi] ERROR: failed to create window " .. windowName .. " - " .. tostring(err)))
		return false
	end

	pcall(LayoutEditor.RegisterWindow,
		windowName,
		displayName,
		description,
		canResize == true,
		true,   -- canScale
		true,   -- canAlpha
		nil
	)
	return true
end

function KillerByEgyptianKozi._OnCareerReady()

	if (initialized) then return end
	if (not GameData.Player.career or not GameData.Player.career.line or GameData.Player.career.line < 1) then return end

	-- Get player name now that it is fully loaded
	playerName = FixString(GameData.Player.name)

	-- Create the alert window
	SafeCreateWindow("KillerByEgyptianKoziWindow", true,
		L"KillerByEgyptianKozi", L"Kill/Assist alert popup", true)

	-- Create the history log window
	SafeCreateWindow("KillerByEgyptianKoziHistoryWindow", true,
		L"KillerByEgyptianKozi History", L"Displays a log of your recent kills and assists", true)

	-- Create the kill streak banner window (scaled up for banner effect)
	if (SafeCreateWindow("KillerByEgyptianKoziStreakWindow", false,
			L"KillerByEgyptianKozi Streak Banner", L"Large kill streak accolade banner")) then
		pcall(WindowSetScale, "KillerByEgyptianKoziStreakWindow", 1.5)
	end

	-- Create the configuration panel (hidden by default)
	SafeCreateWindow("KillerByEgyptianKoziConfigWindow", false,
		L"KillerByEgyptianKozi Config", L"KillerByEgyptianKozi configuration panel")

	-- Create the persistent stats HUD
	SafeCreateWindow("KillerByEgyptianKoziHUD", false,
		L"KillerByEgyptianKozi HUD", L"Live kill streak and statistics HUD")

	-- Create the Death Recap popup (hidden by default; shown on death)
	SafeCreateWindow("KillerByEgyptianKoziRecapWindow", false,
		L"KillerByEgyptianKozi Death Recap", L"Popup listing the last 10 enemies that damaged you before death", true)

	-- Set static texts (guarded: skip any window that failed to create)
	if (DoesWindowExist("KillerByEgyptianKoziHistoryWindow")) then
		LabelSetText("KillerByEgyptianKoziHistoryWindowTitleBarText", L"KillerByEgyptianKozi History")
	end
	if (DoesWindowExist("KillerByEgyptianKoziConfigWindow")) then
		-- XML text attrs only accept string-table IDs, so literals are set here
		LabelSetText("KillerByEgyptianKoziConfigWindowTitleBarText", L"KillerByEgyptianKozi Options")
		LabelSetText("KillerByEgyptianKoziConfigWindowEnabledLabel", L"Kill/Assist Alerts Enabled")
		LabelSetText("KillerByEgyptianKoziConfigWindowAssistsLabel", L"Show Assist Alerts")
		LabelSetText("KillerByEgyptianKoziConfigWindowArrowLabel", L"3D Target Arrow")
		LabelSetText("KillerByEgyptianKoziConfigWindowArrowHealthLabel", L"Arrow Health-Coloring")
		LabelSetText("KillerByEgyptianKoziConfigWindowRewardsLabel", L"Show Renown/XP Rewards")
		LabelSetText("KillerByEgyptianKoziConfigWindowStreaksLabel", L"Kill Streak Accolades")
		LabelSetText("KillerByEgyptianKoziConfigWindowHudLabel", L"Show Stats HUD")
		LabelSetText("KillerByEgyptianKoziConfigWindowRecapLabel", L"Death Recap Popup")
		LabelSetText("KillerByEgyptianKoziConfigWindowDurationLabel", L"Display Duration")
		LabelSetText("KillerByEgyptianKoziConfigWindowRepeatsLabel", L"Sound Volume (repeats)")
	end
	if (DoesWindowExist("KillerByEgyptianKoziHUD")) then
		LabelSetText("KillerByEgyptianKoziHUDTitle", L"Killer HUD")
		LabelSetTextColor("KillerByEgyptianKoziHUDTitle", GOLD.r, GOLD.g, GOLD.b)
		WindowSetShowing("KillerByEgyptianKoziHUD", KA.Settings.showHUD == true)
	end
	if (DoesWindowExist("KillerByEgyptianKoziRecapWindow")) then
		-- XML text attrs only accept string-table IDs, so literals are set here
		LabelSetText("KillerByEgyptianKoziRecapWindowTitleBarText", L"Death Recap")
		LabelSetText("KillerByEgyptianKoziRecapWindowColName", L"Attacker")
		LabelSetTextColor("KillerByEgyptianKoziRecapWindowColName", GOLD.r, GOLD.g, GOLD.b)
		LabelSetText("KillerByEgyptianKoziRecapWindowColDmg", L"Damage")
		LabelSetTextColor("KillerByEgyptianKoziRecapWindowColDmg", GOLD.r, GOLD.g, GOLD.b)
	end

	-- Parent is always shown; individual slots control their own visibility
	WindowSetShowing("KillerByEgyptianKoziWindow", true)

	-- Set showing status based on setting
	WindowSetShowing("KillerByEgyptianKoziHistoryWindow", KA.Settings.showHistoryWindow)

	-- Hide all slots initially
	for i = 1, MAX_SLOTS do
		WindowSetShowing(SlotWindowName(i), false)
	end

	-- Hide target arrow initially
	WindowSetShowing("KillerByEgyptianKoziTargetArrow", false)

	-- Register for combat log events
	if (KA.Settings.enabled) then
		KillerByEgyptianKozi._RegisterEvents()
	end

	-- Register for target tracking (for assists, career icons, and visual arrow)
	RegisterEventHandler(SystemData.Events.PLAYER_TARGET_UPDATED, "KillerByEgyptianKozi._OnTargetUpdated")

	-- Register for player death (streak reset). Event name varies between
	-- client builds, so try each candidate defensively; the Update loop also
	-- polls hit points as a guaranteed fallback.
	local deathEvents = { "PLAYER_DEATH", "PLAYER_KILLED", "PLAYER_DEAD" }
	for _, evName in pairs(deathEvents) do
		local ev = SystemData.Events[evName]
		if (ev) then
			pcall(RegisterEventHandler, ev, "KillerByEgyptianKozi._OnPlayerDeath")
		end
	end

	-- Register for reward tracking (Renown / XP deltas)
	if (SystemData.Events.PLAYER_RENOWN_UPDATED) then
		pcall(RegisterEventHandler, SystemData.Events.PLAYER_RENOWN_UPDATED, "KillerByEgyptianKozi._OnRenownUpdated")
	end
	local xpEvents = { "PLAYER_EXPERIENCE_UPDATED", "PLAYER_EXP_UPDATED", "PLAYER_XP_UPDATED" }
	for _, evName in pairs(xpEvents) do
		local ev = SystemData.Events[evName]
		if (ev) then
			pcall(RegisterEventHandler, ev, "KillerByEgyptianKozi._OnXpUpdated")
			break
		end
	end

	-- Snapshot current reward baselines
	KillerByEgyptianKozi._SyncRewardBaselines()

	initialized = true

	UnregisterEventHandler(SystemData.Events.PLAYER_CAREER_LINE_UPDATED, "KillerByEgyptianKozi._OnCareerReady")

	-- Refresh history UI from saved variables
	KillerByEgyptianKozi.RefreshHistoryUI()

	-- Sync config panel controls to current settings
	KillerByEgyptianKozi.SyncConfigUI()

	-- Populate the stats HUD
	KillerByEgyptianKozi.UpdateHUD()

	-- If we already have a hostile target, show arrow
	TargetInfo:UpdateFromClient()
	local targetId = TargetInfo:UnitEntityId(TargetInfo.HOSTILE_TARGET)
	if (targetId and targetId ~= 0) then
		KillerByEgyptianKozi._OnTargetUpdated(TargetInfo.HOSTILE_TARGET, targetId)
	end
end


function KillerByEgyptianKozi._RegisterEvents()
	RegisterEventHandler(TextLogGetUpdateEventId("Combat"), "KillerByEgyptianKozi._OnCombatLog")
end


function KillerByEgyptianKozi._UnregisterEvents()
	UnregisterEventHandler(TextLogGetUpdateEventId("Combat"), "KillerByEgyptianKozi._OnCombatLog")
end


-------------------------------------------------------------------------------
-- Reward (Renown / XP) tracking
-------------------------------------------------------------------------------
function KillerByEgyptianKozi._SyncRewardBaselines()
	local ok, val = pcall(function() return GameData.Player.Renown.curRenownEarned end)
	if (ok and type(val) == "number") then
		lastRenownEarned = val
	end
	local ok2, val2 = pcall(function() return GameData.Player.Experience.curXpEarned end)
	if (ok2 and type(val2) == "number") then
		lastXpEarned = val2
	end
end

-- Attach a reward delta ("rp" or "xp") to the most recent eligible kill/assist
local function AttachReward(kind, amount)
	if (amount == nil or amount <= 0) then return end

	if (kind == "rp") then
		KA.Stats.totalRP = (KA.Stats.totalRP or 0) + amount
	else
		KA.Stats.totalXP = (KA.Stats.totalXP or 0) + amount
	end

	if (not KA.Settings.showRewards) then return end

	local now = GetComputerTime()

	-- Newest message first; take the first still inside the correlation window
	for i = 1, #messageQueue do
		local msg = messageQueue[i]
		if (not msg.expired and msg.createTime and (now - msg.createTime) <= REWARD_CORRELATION_WINDOW) then
			if (kind == "rp") then
				msg.rp = (msg.rp or 0) + amount
			else
				msg.xp = (msg.xp or 0) + amount
			end
			-- Re-run the 2-frame layout so the reward label appears/updates
			RelayoutAllSlots()
			KillerByEgyptianKozi.UpdateHUD()
			return
		end
	end

	KillerByEgyptianKozi.UpdateHUD()
end

function KillerByEgyptianKozi._OnRenownUpdated()
	local ok, cur = pcall(function() return GameData.Player.Renown.curRenownEarned end)
	if (not ok or type(cur) ~= "number") then return end

	if (lastRenownEarned == nil) then
		lastRenownEarned = cur
		return
	end

	local delta = cur - lastRenownEarned
	lastRenownEarned = cur

	-- Negative delta = renown rank-up rollover; just resync the baseline
	if (delta > 0) then
		AttachReward("rp", delta)
	end
end

function KillerByEgyptianKozi._OnXpUpdated()
	local ok, cur = pcall(function() return GameData.Player.Experience.curXpEarned end)
	if (not ok or type(cur) ~= "number") then return end

	if (lastXpEarned == nil) then
		lastXpEarned = cur
		return
	end

	local delta = cur - lastXpEarned
	lastXpEarned = cur

	-- Negative delta = level-up rollover; just resync the baseline
	if (delta > 0) then
		AttachReward("xp", delta)
	end
end


-------------------------------------------------------------------------------
-- Kill Streak & Accolades
-------------------------------------------------------------------------------
local function PlayStreakSounds()
	-- Rapid dramatic cue: fire the kill sound and the assist chime alternately
	local a = KA.Settings.killSound
	local b = KA.Settings.assistSound
	for i = 1, 6 do
		if (a) then pcall(PlaySound, a) end
		if (b) then pcall(PlaySound, b) end
	end
end

function KillerByEgyptianKozi._ShowStreakBanner(accoladeText, streakCount)
	if (not DoesWindowExist("KillerByEgyptianKoziStreakWindow")) then return end

	LabelSetText("KillerByEgyptianKoziStreakWindowText", accoladeText)
	LabelSetTextColor("KillerByEgyptianKoziStreakWindowText", GOLD.r, GOLD.g, GOLD.b)

	LabelSetText("KillerByEgyptianKoziStreakWindowSubText", wsformat(L"%d Kill Streak", streakCount))
	LabelSetTextColor("KillerByEgyptianKoziStreakWindowSubText", 255, 255, 255)

	WindowSetShowing("KillerByEgyptianKoziStreakWindow", true)
	WindowStopAlphaAnimation("KillerByEgyptianKoziStreakWindow")
	WindowStartAlphaAnimation(
		"KillerByEgyptianKoziStreakWindow",
		Window.AnimationType.SINGLE_NO_RESET,
		0, 1,     -- pop in
		0.15,
		true,
		0, 1
	)

	local now = GetComputerTime()
	streakBanner = {
		flashEnd = now + 1.5,      -- color-flash phase
		hideTime = now + 3.2,      -- start fade-out
		removeTime = now + 3.8,    -- fully hidden
		nextFlash = now,
		flashOn = false,
		fading = false,
	}

	PlayStreakSounds()
end

-- Called every frame from Update to animate/expire the streak banner
local function UpdateStreakBanner(now)
	if (not streakBanner) then return end

	-- Gold/white color flashing for the first phase
	if (now < streakBanner.flashEnd) then
		if (now >= streakBanner.nextFlash) then
			streakBanner.flashOn = not streakBanner.flashOn
			streakBanner.nextFlash = now + 0.15
			if (streakBanner.flashOn) then
				LabelSetTextColor("KillerByEgyptianKoziStreakWindowText", 255, 255, 255)
			else
				LabelSetTextColor("KillerByEgyptianKoziStreakWindowText", GOLD.r, GOLD.g, GOLD.b)
			end
		end
	elseif (not streakBanner.settled) then
		streakBanner.settled = true
		LabelSetTextColor("KillerByEgyptianKoziStreakWindowText", GOLD.r, GOLD.g, GOLD.b)
	end

	-- Fade out and hide
	if (not streakBanner.fading and now >= streakBanner.hideTime) then
		streakBanner.fading = true
		WindowStopAlphaAnimation("KillerByEgyptianKoziStreakWindow")
		WindowStartAlphaAnimation(
			"KillerByEgyptianKoziStreakWindow",
			Window.AnimationType.SINGLE_NO_RESET,
			1, 0,
			0.6,
			true,
			0, 1
		)
	end

	if (now >= streakBanner.removeTime) then
		WindowSetShowing("KillerByEgyptianKoziStreakWindow", false)
		streakBanner = nil
	end
end

-- Register a direct kill toward the streak; fires accolades on milestones
local function AdvanceKillStreak()
	currentStreak = currentStreak + 1

	if (currentStreak > (KA.Stats.bestStreak or 0)) then
		KA.Stats.bestStreak = currentStreak
	end

	if (not KA.Settings.showStreaks) then return end

	local accolade = STREAK_MILESTONES[currentStreak]

	-- Past Godlike, celebrate every 5 additional kills
	if (not accolade and currentStreak > 15 and (currentStreak % 5) == 0) then
		accolade = L"GODLIKE!"
	end

	if (accolade) then
		KillerByEgyptianKozi._ShowStreakBanner(accolade, currentStreak)
		AddHistoryEntry(L"[" .. GetFormattedTime() .. L"] " .. accolade .. wsformat(L" (%d kill streak)", currentStreak))
	end
end

-------------------------------------------------------------------------------
-- Death Recap: format an integer with thousands separators ("2500" -> "2,500")
-------------------------------------------------------------------------------
local function FormatNumberWithCommas(n)
	-- Work on the plain-string form, then convert back to wstring for chat
	local s = tostring(math.floor(n or 0))
	-- Insert a comma every three digits from the right
	local formatted = s
	while true do
		local replaced
		formatted, replaced = string.gsub(formatted, "^(%d+)(%d%d%d)", "%1,%2")
		if (replaced == 0) then break end
	end
	return towstring(formatted)
end


local RECAP_WIN = "KillerByEgyptianKoziRecapWindow"

-- Hide every data row in the recap window (called before repopulating)
local function HideRecapRows()
	for i = 1, MAX_RECAP_ATTACKERS do
		WindowSetShowing(RECAP_WIN .. "Row" .. i .. "Icon", false)
		WindowSetShowing(RECAP_WIN .. "Row" .. i .. "Name", false)
		WindowSetShowing(RECAP_WIN .. "Row" .. i .. "Dmg", false)
	end
end

-- Build the list of attackers to display: the most recent MAX_RECAP_ATTACKERS
-- unique attackers (chronological tail of attackerOrder), then sorted by total
-- damage descending so the biggest threat is at the top.
local function BuildRecapList()
	local total = #attackerOrder
	local startIdx = total - MAX_RECAP_ATTACKERS + 1
	if (startIdx < 1) then startIdx = 1 end

	local list = {}
	for i = startIdx, total do
		local key = attackerOrder[i]
		local entry = damageTracker[key]
		if (entry) then
			tinsert(list, {
				name = entry.display or towstring(key),
				damage = entry.damage or 0,
				careerLine = entry.careerLine,
			})
		end
	end

	table.sort(list, function(a, b) return a.damage > b.damage end)
	return list
end

-------------------------------------------------------------------------------
-- Death Recap: populate and show the popup window with the last N unique
-- attackers and their total damage. Does NOT clear the tracker (the caller
-- does that after the snapshot is captured).
-------------------------------------------------------------------------------
function KillerByEgyptianKozi.ShowDeathRecap()
	if (not KA.Settings.showDeathRecap) then return end
	if (not DoesWindowExist(RECAP_WIN)) then
		-- Window failed to create; fall back to a one-line chat notice so the
		-- feature still signals rather than silently doing nothing.
		d(L"[KillerByEgyptianKozi] ERROR: Death Recap window was not created - check for load errors (/reloadui)")
		return
	end

	HideRecapRows()

	local list = BuildRecapList()

	-- Realm-tinted attacker names (enemies are the opposite realm)
	local playerRealm = (GameData.Player and GameData.Player.realm) or 1
	local enemyColor = (playerRealm == 1) and { r = 255, g = 70, b = 70 } or { r = 50, g = 180, b = 255 }

	if (#list == 0) then
		LabelSetText(RECAP_WIN .. "Header", L"No attackers recorded this life.")
		LabelSetTextColor(RECAP_WIN .. "Header", 255, 255, 255)
		LabelSetText(RECAP_WIN .. "EmptyText", L"Nothing damaged you before you died.")
		LabelSetTextColor(RECAP_WIN .. "EmptyText", 200, 200, 200)
		WindowSetShowing(RECAP_WIN .. "EmptyText", true)
		-- Hide the column headers when there is nothing to tabulate
		WindowSetShowing(RECAP_WIN .. "ColName", false)
		WindowSetShowing(RECAP_WIN .. "ColDmg", false)
	else
		WindowSetShowing(RECAP_WIN .. "EmptyText", false)
		WindowSetShowing(RECAP_WIN .. "ColName", true)
		WindowSetShowing(RECAP_WIN .. "ColDmg", true)
		LabelSetText(RECAP_WIN .. "Header", wsformat(L"You were killed by (last %d attackers):", #list))
		LabelSetTextColor(RECAP_WIN .. "Header", 255, 255, 255)

		for i = 1, #list do
			local iconWin = RECAP_WIN .. "Row" .. i .. "Icon"
			local nameWin = RECAP_WIN .. "Row" .. i .. "Name"
			local dmgWin = RECAP_WIN .. "Row" .. i .. "Dmg"

			-- Career icon (if we know this attacker's career line). Falls back to
			-- a realm emblem, then hides gracefully if neither resolves - the name
			-- column stays aligned either way (name anchors to the icon slot).
			local iconShown = false
			local iconId = GetCareerIconID(list[i].careerLine)
			if (iconId and ApplySlotIcon(iconWin, iconId)) then
				iconShown = true
			end
			WindowSetShowing(iconWin, iconShown)

			LabelSetText(nameWin, wsformat(L"%d.  ", i) .. list[i].name)
			LabelSetTextColor(nameWin, enemyColor.r, enemyColor.g, enemyColor.b)
			WindowSetShowing(nameWin, true)

			LabelSetText(dmgWin, FormatNumberWithCommas(list[i].damage))
			LabelSetTextColor(dmgWin, GOLD.r, GOLD.g, GOLD.b)
			WindowSetShowing(dmgWin, true)
		end
	end

	WindowSetShowing(RECAP_WIN, true)
end

-- Close button / slash handler for the recap window
function KillerByEgyptianKozi.CloseRecapWindow()
	if (DoesWindowExist(RECAP_WIN)) then
		WindowSetShowing(RECAP_WIN, false)
	end
end


function KillerByEgyptianKozi._OnPlayerDeath()
	-- Debounce: a real death can arrive via a death EVENT and the HP poll almost
	-- simultaneously. Process only the first; ignore repeats until the player is
	-- seen alive again (playerHasBeenAlive is re-armed by the poll on respawn).
	if (playerIsDead) then return end
	playerIsDead = true
	playerHasBeenAlive = false

	if (currentStreak >= 2) then
		AddHistoryEntry(L"[" .. GetFormattedTime() .. L"] " .. wsformat(L"Streak ended at %d", currentStreak))
	end
	currentStreak = 0

	-- Death Recap: pop up who killed you, then reset for the next life
	KillerByEgyptianKozi.ShowDeathRecap()
	ClearDamageTracker()

	KillerByEgyptianKozi.UpdateHUD()
end

-- Fallback death detection: poll hit points in case no death event exists.
--
-- IMPORTANT: hitPoints.current also reads 0 during zone changes / teleports,
-- when the player object is briefly unloaded. To avoid a false "death" (which
-- would wrongly pop the recap on every teleport), we only treat current<=0 as
-- a real death when the character is actually loaded: maximum HP must be > 0,
-- AND we must have previously observed the player alive with positive HP this
-- life. A teleport transition has max == 0 (or a stale/zero table), so it is
-- ignored and the "was alive" latch is preserved until real data returns.
local function PollPlayerDeath()
	local ok, hp = pcall(function() return GameData.Player.hitPoints.current end)
	if (not ok or type(hp) ~= "number") then return end

	-- Best-effort max-HP read (field name may vary by client build). If we CAN
	-- read it and it's 0, the character isn't loaded (teleport/zoning) - bail
	-- without firing a death or disturbing the "seen alive" latch. If we can't
	-- read it at all, we skip this guard and rely on the playerHasBeenAlive
	-- latch below, which alone still blocks the initial-load and post-death 0s.
	local okMax, maxHp = pcall(function() return GameData.Player.hitPoints.maximum end)
	if (okMax and type(maxHp) == "number" and maxHp <= 0) then
		return
	end

	if (hp > 0) then
		-- Alive with real data: clear the death latch and remember we saw life.
		playerIsDead = false
		playerHasBeenAlive = true
		zeroHpPolls = 0
	elseif (hp <= 0) then
		-- Require the player to have been seen alive this life (blocks the
		-- initial 0/0 load and the post-death respawn 0s), AND for HP to stay
		-- at 0 across two consecutive polls (~1s). A teleport/zoning blip clears
		-- within a single tick once the new zone loads, so it never reaches the
		-- threshold; a real death holds you at 0 until you release.
		zeroHpPolls = zeroHpPolls + 1
		if (not playerIsDead and playerHasBeenAlive and zeroHpPolls >= 2) then
			-- _OnPlayerDeath owns the playerIsDead / playerHasBeenAlive flags and
			-- debounces against the death event, so just delegate to it.
			KillerByEgyptianKozi._OnPlayerDeath()
		end
	end
end


-------------------------------------------------------------------------------
-- Enhanced 3D target arrow: health-based tinting
-------------------------------------------------------------------------------
local function GetHostileHealthPct()
	local ok, health = pcall(function() return TargetInfo:UnitHealth(TargetInfo.HOSTILE_TARGET) end)
	if (not ok or type(health) ~= "number") then return nil end

	-- Normalize: some builds return 0..1, others 0..100
	if (health <= 1) then
		health = health * 100
	end
	return health
end

local function TintArrowForHealth(healthPct)
	if (not DoesWindowExist("KillerByEgyptianKoziTargetArrowInstance")) then return end

	local r, g, b
	if (not KA.Settings.arrowHealthColor or healthPct == nil) then
		r, g, b = 255, 0, 0
	elseif (healthPct > 75) then
		r, g, b = 0, 255, 0
	elseif (healthPct >= 25) then
		r, g, b = 255, 200, 0
	else
		r, g, b = 255, 0, 0
	end

	WindowSetTintColor("KillerByEgyptianKoziTargetArrowInstanceContentArrow", r, g, b)
end

local function UpdateArrowTint(elapsed)
	if (currentAttachedTargetId == 0) then return end
	-- Static red arrow needs no periodic health polling
	if (not KA.Settings.arrowHealthColor) then return end

	arrowTintElapsed = arrowTintElapsed + (elapsed or 0)
	if (arrowTintElapsed < ARROW_TINT_INTERVAL) then return end
	arrowTintElapsed = 0

	if (not DoesWindowExist("KillerByEgyptianKoziTargetArrowInstance")) then return end

	TargetInfo:UpdateFromClient()
	TintArrowForHealth(GetHostileHealthPct())
end


-------------------------------------------------------------------------------
-- Update (called every frame by the engine via OnUpdate)
-- Handles message expiration, banner animation, arrow tint, and cleanup
-------------------------------------------------------------------------------
function KillerByEgyptianKozi.Update(elapsed)

	local now = GetComputerTime()

	if (queueChanged) then
		queueChanged = false
	else
		-- Measure and position slots whose layout hasn't settled yet
		local needsPositioning = false
		for i = 1, MAX_SLOTS do
			if (slotState[i] == 1) then
				needsPositioning = true
				break
			end
		end

		if (needsPositioning) then
			RefreshSlots()
		end
	end

	local needsRefresh = false

	-- Check for expired messages
	for i = #messageQueue, 1, -1 do
		local msg = messageQueue[i]

		-- Message hasn't started fading yet - check if it should
		if (not msg.expired and now >= msg.expireTime) then
			ExpireMessage(msg)
		end

		-- Message has finished fading - remove it
		if (msg.expired and msg.fadeEndTime and now >= msg.fadeEndTime) then
			tremove(messageQueue, i)
			needsRefresh = true
		end
	end

	if (needsRefresh) then
		for j = 1, MAX_SLOTS do
			slotState[j] = 0
		end
		queueChanged = true
		RefreshSlots()
	end

	-- Kill streak banner animation
	UpdateStreakBanner(now)

	-- Target arrow health tint (throttled)
	if (initialized and KA.Settings.showTargetArrow) then
		UpdateArrowTint(elapsed)
	end

	-- Fallback death detection poll (twice per second)
	deathPollElapsed = deathPollElapsed + (elapsed or 0)
	if (deathPollElapsed >= 0.5) then
		deathPollElapsed = 0
		if (initialized) then
			PollPlayerDeath()
		end
	end

	-- Clean up stale recent targets periodically
	updateElapsed = updateElapsed + (elapsed or 0)
	if (updateElapsed >= 5) then
		updateElapsed = 0
		KillerByEgyptianKozi._CleanRecentTargets()
	end
end


-------------------------------------------------------------------------------
-- Shutdown
-------------------------------------------------------------------------------
function KillerByEgyptianKozi.Shutdown()
	-- nothing critical to clean up
end


-------------------------------------------------------------------------------
-- History Log Window Helpers
-------------------------------------------------------------------------------
function KillerByEgyptianKozi.ToggleHistoryWindow()
	local show = not WindowGetShowing("KillerByEgyptianKoziHistoryWindow")
	WindowSetShowing("KillerByEgyptianKoziHistoryWindow", show)
	KA.Settings.showHistoryWindow = show
end

function KillerByEgyptianKozi.RefreshHistoryUI()
	if (not DoesWindowExist("KillerByEgyptianKoziHistoryWindow")) then return end

	local logText = L""
	for i = 1, #KillerByEgyptianKozi.History do
		if (i > 1) then
			logText = logText .. L"\n"
		end
		logText = logText .. KillerByEgyptianKozi.History[i]
	end

	LabelSetText("KillerByEgyptianKoziHistoryWindowContentScrollChildText", logText)

	-- 18px per line of font_clear_small
	local textHeight = #KillerByEgyptianKozi.History * 18
	if (textHeight < 270) then
		textHeight = 270
	end

	WindowSetDimensions("KillerByEgyptianKoziHistoryWindowContentScrollChild", 264, textHeight)
	WindowSetDimensions("KillerByEgyptianKoziHistoryWindowContentScrollChildText", 264, textHeight)
	ScrollWindowUpdateScrollRect("KillerByEgyptianKoziHistoryWindowContent")
end


-------------------------------------------------------------------------------
-- Remove the 3D target arrow instance if it exists
-------------------------------------------------------------------------------
local function RemoveTargetArrow()
	if (DoesWindowExist("KillerByEgyptianKoziTargetArrowInstance")) then
		if (currentAttachedTargetId ~= 0) then
			DetachWindowFromWorldObject("KillerByEgyptianKoziTargetArrowInstance", currentAttachedTargetId)
		end
		DestroyWindow("KillerByEgyptianKoziTargetArrowInstance")
	end
	currentAttachedTargetId = 0
end


-------------------------------------------------------------------------------
-- Target tracking for assist detection, career icons, and visual arrow
-------------------------------------------------------------------------------
function KillerByEgyptianKozi._OnTargetUpdated(targetClassification, targetId, targetType)

	TargetInfo:UpdateFromClient()

	-- 1. Track recent hostile targets (assist detection + career icon lookup)
	local targetName = FixString(TargetInfo:UnitName(TargetInfo.HOSTILE_TARGET))
	if (targetName and targetName ~= L"") then

		-- Capture career line while we have the unit targeted
		local careerLine = nil
		local ok, line = pcall(function() return TargetInfo:UnitCareerLine(TargetInfo.HOSTILE_TARGET) end)
		if (ok and type(line) == "number" and line > 0) then
			careerLine = line
		else
			local ok2, id = pcall(function() return TargetInfo:UnitCareerId(TargetInfo.HOSTILE_TARGET) end)
			if (ok2 and type(id) == "number" and id > 0) then
				careerLine = id
			end
		end

		local existing = recentTargets[targetName]
		if (existing) then
			existing.time = GetComputerTime()
			if (careerLine) then
				existing.careerLine = careerLine
			end
		else
			recentTargets[targetName] = {
				time = GetComputerTime(),
				careerLine = careerLine,
			}
		end
	end

	-- 2. Update visual target arrow indicator
	if (targetClassification == TargetInfo.HOSTILE_TARGET) then
		if (KA.Settings.showTargetArrow and targetId and targetId ~= 0) then
			if (currentAttachedTargetId ~= targetId) then
				RemoveTargetArrow()

				CreateWindowFromTemplate("KillerByEgyptianKoziTargetArrowInstance", "KillerByEgyptianKoziTargetArrow", "Root")
				AttachWindowToWorldObject("KillerByEgyptianKoziTargetArrowInstance", targetId)
				WindowSetShowing("KillerByEgyptianKoziTargetArrowInstance", true)
				currentAttachedTargetId = targetId
			end

			-- Tint immediately for the new/current target's health
			TintArrowForHealth(GetHostileHealthPct())
			arrowTintElapsed = 0
		else
			RemoveTargetArrow()
		end
	end
end


function KillerByEgyptianKozi._CleanRecentTargets()
	local now = GetComputerTime()
	for name, info in pairs(recentTargets) do
		if (now - info.time > RECENT_TARGET_WINDOW) then
			recentTargets[name] = nil
		end
	end
end


-------------------------------------------------------------------------------
-- Combat log handler
-- Fires whenever a new entry is added to the "Combat" text log.
-------------------------------------------------------------------------------
function KillerByEgyptianKozi._OnCombatLog(updateType, filterType)

	-- Only process newly added entries
	if (updateType ~= SystemData.TextLogUpdate.ADDED) then return end

	local numEntries = TextLogGetNumEntries("Combat")
	if (numEntries == nil or numEntries <= 0) then return end

	-- Index of the newest entry (0-based).
	local index = numEntries - 1
	local _, t, msg = TextLogGetEntry("Combat", index)
	if (msg == nil) then return end

	-- Death Recap damage tracking. Two rules working together:
	--  (a) Accumulate damage from EVERY entry added since we last ran, not just
	--      the newest - when many enemies hit you at once several combat entries
	--      get appended between handler calls, and reading only the newest would
	--      drop the rest (that made the recap empty with 10+ attackers).
	--  (b) Process only entries STRICTLY NEWER than the last one handled - the
	--      "Combat" update handler commonly re-fires for an entry we already
	--      counted (once per filter that entry belongs to). Re-reading those
	--      double/triple-counted damage and blew totals up to absurd numbers
	--      (the "271,817 damage" bug). `index <= lastDamageEntryIndex` guards it.
	-- Damage-taken lines are NOT in the RVR_KILLS filters, so this is independent
	-- of the kill/assist parsing below.
	if (KA.Settings.showDeathRecap) then
		if (index <= lastDamageEntryIndex) then
			-- index == last -> nothing new (duplicate re-fire); skip the scan.
			-- index <  last -> log wrapped/reset/reloaded: resync to the newest
			--                  WITHOUT rescanning (rescanning would re-count the
			--                  survivors). We accept losing a few entries across
			--                  the rare wrap rather than risk inflating totals.
			lastDamageEntryIndex = index
		else
			local from = lastDamageEntryIndex + 1

			-- Bound the back-scan so the first-ever call never walks the entire
			-- historical log in one frame. 200 entries is far more than a single
			-- death's worth of incoming hits.
			if (index - from > 200) then
				from = index - 200
			end

			for i = from, index do
				-- We already read `index` above; reuse it, fetch the rest. Guard
				-- each read: combat-log indices can shift under us, and an
				-- out-of-range read must not abort the whole handler.
				local emsg
				if (i == index) then
					emsg = msg
				else
					local ok, _, _, m = pcall(TextLogGetEntry, "Combat", i)
					if (ok) then emsg = m end
				end
				if (emsg ~= nil) then
					local attacker, dmg = ParseDamageTaken(emsg)
					if (attacker ~= nil and dmg ~= nil) then
						RecordDamageTaken(attacker, dmg)
					end
				end
			end

			lastDamageEntryIndex = index
		end
	end

	-- The remaining logic only concerns RVR kill entries (Order / Destruction).
	if (filterType ~= ORDER and filterType ~= DESTR) then return end
	if (t ~= ORDER and t ~= DESTR) then return end

	local victim, player, location = ParseKillMessage(msg)
	if (victim == nil or player == nil) then return end

	-- Ignore self-kills (lava, falling, etc.)
	if (victim == player) then return end
	if (player == L"falling" and msg:match(L" has been killed by falling in ") ~= nil) then return end

	-- Career info captured while the victim was targeted (may be nil)
	local targetInfo = recentTargets[victim]
	local careerLine = targetInfo and targetInfo.careerLine or nil

	-- Case 1: YOU got the killing blow
	if (player == playerName) then
		KillerByEgyptianKozi._ShowKillAlert(victim, nil, careerLine)
		recentTargets[victim] = nil
		return
	end

	-- Case 2: Someone else killed a target you were recently fighting (assist)
	if (KA.Settings.showAssists and targetInfo ~= nil) then
		KillerByEgyptianKozi._ShowKillAlert(victim, player, careerLine)
		-- Remove from recent targets so we don't double-alert
		recentTargets[victim] = nil
		return
	end
end


-------------------------------------------------------------------------------
-- Show the on-screen alert
--   victim:      name of the enemy who died (wstring)
--   killer:      name of the player who got final blow (wstring), or nil if YOU
--   careerLine:  victim's career line if known (number), or nil
-------------------------------------------------------------------------------
function KillerByEgyptianKozi._ShowKillAlert(victim, killer, careerLine)

	local now = GetComputerTime()
	local duration = KA.Settings.displayDuration or 4
	local isAssist = (killer ~= nil)

	-- Play sound effect (repeated for extra volume; count is configurable)
	local repeats = KA.Settings.soundRepeats or 8
	local sound = isAssist and KA.Settings.assistSound or KA.Settings.killSound
	if (sound) then
		for i = 1, repeats do
			PlaySound(sound)
		end
	end

	-- Add to persistent history
	local timeStr = GetFormattedTime()
	local logMsg
	if (isAssist) then
		logMsg = L"[" .. timeStr .. L"] Assisted: " .. victim .. L" (Final: " .. killer .. L")"
		KA.Stats.totalAssists = (KA.Stats.totalAssists or 0) + 1
	else
		logMsg = L"[" .. timeStr .. L"] Killed: " .. victim
		KA.Stats.totalKills = (KA.Stats.totalKills or 0) + 1
	end

	AddHistoryEntry(logMsg)

	-- Create the message entry
	local displayKiller = playerName
	if (not displayKiller or displayKiller == L"") then
		displayKiller = L"You"
	end

	-- Victim is always a member of the enemy realm
	local playerRealm = (GameData.Player and GameData.Player.realm) or 1
	local victimRealm = (playerRealm == 1) and 2 or 1

	local newMsg = {
		killerName = displayKiller,
		victimName = victim or L"Unknown",
		allyName = killer,
		isAssist = isAssist,
		careerLine = careerLine,
		victimRealm = victimRealm,
		rp = nil,
		xp = nil,
		createTime = now,
		expireTime = now + duration,
		expired = false,
		fadeEndTime = nil,
	}

	-- Insert at the top (position 1 = newest)
	tinsert(messageQueue, 1, newMsg)

	-- If we exceed MAX_SLOTS, remove the oldest (bottom)
	while (#messageQueue > MAX_SLOTS) do
		tremove(messageQueue, #messageQueue)
	end

	-- Reset all slot states so they undergo the 2-frame measurement cycle
	for i = 1, MAX_SLOTS do
		slotState[i] = 0
	end

	queueChanged = true

	-- Refresh all slot visuals
	RefreshSlots()

	-- Direct kills advance the kill streak
	if (not isAssist) then
		AdvanceKillStreak()
	end

	KillerByEgyptianKozi.UpdateHUD()
end


-------------------------------------------------------------------------------
-- Stats HUD
-------------------------------------------------------------------------------
function KillerByEgyptianKozi.UpdateHUD()
	if (not DoesWindowExist("KillerByEgyptianKoziHUD")) then return end

	LabelSetText("KillerByEgyptianKoziHUDStreakLine",
		wsformat(L"Streak: %d   Best: %d", currentStreak, KA.Stats.bestStreak or 0))
	LabelSetTextColor("KillerByEgyptianKoziHUDStreakLine", 255, 255, 255)

	LabelSetText("KillerByEgyptianKoziHUDKillsLine",
		wsformat(L"Kills: %d   Assists: %d", KA.Stats.totalKills or 0, KA.Stats.totalAssists or 0))
	LabelSetTextColor("KillerByEgyptianKoziHUDKillsLine", 255, 255, 255)

	LabelSetText("KillerByEgyptianKoziHUDRewardLine",
		wsformat(L"RP: %d   XP: %d", KA.Stats.totalRP or 0, KA.Stats.totalXP or 0))
	LabelSetTextColor("KillerByEgyptianKoziHUDRewardLine", GOLD.r, GOLD.g, GOLD.b)
end

function KillerByEgyptianKozi.ToggleHUD()
	if (not DoesWindowExist("KillerByEgyptianKoziHUD")) then return end
	local show = not WindowGetShowing("KillerByEgyptianKoziHUD")
	KA.Settings.showHUD = show
	WindowSetShowing("KillerByEgyptianKoziHUD", show)
	if (show) then
		KillerByEgyptianKozi.UpdateHUD()
	end
end

-- Left-clicking the HUD opens the configuration panel
function KillerByEgyptianKozi.OnHUDClick()
	KillerByEgyptianKozi.ToggleConfigWindow()
end


-------------------------------------------------------------------------------
-- Configuration Panel
-------------------------------------------------------------------------------
local CONFIG = "KillerByEgyptianKoziConfigWindow"

-- Checkbox window suffix -> Settings key
local CONFIG_CHECKBOXES = {
	[CONFIG .. "EnabledCheck"]      = "enabled",
	[CONFIG .. "AssistsCheck"]      = "showAssists",
	[CONFIG .. "ArrowCheck"]        = "showTargetArrow",
	[CONFIG .. "RewardsCheck"]      = "showRewards",
	[CONFIG .. "StreaksCheck"]      = "showStreaks",
	[CONFIG .. "ArrowHealthCheck"]  = "arrowHealthColor",
	[CONFIG .. "HudCheck"]          = "showHUD",
	[CONFIG .. "RecapCheck"]        = "showDeathRecap",
}

function KillerByEgyptianKozi.ToggleConfigWindow()
	if (not DoesWindowExist(CONFIG)) then return end
	local show = not WindowGetShowing(CONFIG)
	if (show) then
		KillerByEgyptianKozi.SyncConfigUI()
	end
	WindowSetShowing(CONFIG, show)
end

local function UpdateDurationLabel()
	LabelSetText(CONFIG .. "DurationValue", wsformat(L"%d s", KA.Settings.displayDuration or 4))
end

local function UpdateRepeatsLabel()
	LabelSetText(CONFIG .. "RepeatsValue", wsformat(L"%d x", KA.Settings.soundRepeats or 8))
end

-- Push current Settings values into the panel's controls
function KillerByEgyptianKozi.SyncConfigUI()
	if (not DoesWindowExist(CONFIG)) then return end

	for checkName, settingKey in pairs(CONFIG_CHECKBOXES) do
		pcall(ButtonSetPressedFlag, checkName, KA.Settings[settingKey] == true)
	end

	-- Duration slider: 2s..10s mapped onto 0..1
	local duration = KA.Settings.displayDuration or 4
	pcall(SliderBarSetCurrentPosition, CONFIG .. "DurationSlider", (duration - 2) / 8)
	UpdateDurationLabel()

	-- Sound repeats slider: 1..10 mapped onto 0..1
	local repeats = KA.Settings.soundRepeats or 8
	pcall(SliderBarSetCurrentPosition, CONFIG .. "RepeatsSlider", (repeats - 1) / 9)
	UpdateRepeatsLabel()
end

-- Shared OnLButtonUp handler for every checkbox in the panel
function KillerByEgyptianKozi.OnConfigCheckbox()
	local checkName = SystemData.ActiveWindow.name
	local settingKey = CONFIG_CHECKBOXES[checkName]
	if (not settingKey) then return end

	local newValue = not (KA.Settings[settingKey] == true)
	KA.Settings[settingKey] = newValue
	pcall(ButtonSetPressedFlag, checkName, newValue)

	-- Side effects for specific settings
	if (settingKey == "enabled") then
		if (newValue) then
			KillerByEgyptianKozi._RegisterEvents()
		else
			KillerByEgyptianKozi._UnregisterEvents()
		end

	elseif (settingKey == "showTargetArrow") then
		if (newValue) then
			TargetInfo:UpdateFromClient()
			local targetId = TargetInfo:UnitEntityId(TargetInfo.HOSTILE_TARGET)
			if (targetId and targetId ~= 0) then
				KillerByEgyptianKozi._OnTargetUpdated(TargetInfo.HOSTILE_TARGET, targetId)
			end
		else
			RemoveTargetArrow()
		end

	elseif (settingKey == "arrowHealthColor") then
		-- Re-tint immediately with the new mode
		TintArrowForHealth(GetHostileHealthPct())

	elseif (settingKey == "showRewards") then
		RelayoutAllSlots()

	elseif (settingKey == "showHUD") then
		if (DoesWindowExist("KillerByEgyptianKoziHUD")) then
			WindowSetShowing("KillerByEgyptianKoziHUD", newValue)
			if (newValue) then
				KillerByEgyptianKozi.UpdateHUD()
			end
		end

	elseif (settingKey == "showDeathRecap") then
		-- Turning the feature off should also dismiss any open recap popup
		if (not newValue) then
			KillerByEgyptianKozi.CloseRecapWindow()
		end
	end
end

function KillerByEgyptianKozi.OnDurationSlider(slidePos)
	local pos = slidePos
	if (type(pos) ~= "number") then
		local ok, p = pcall(SliderBarGetCurrentPosition, SystemData.ActiveWindow.name)
		if (ok and type(p) == "number") then pos = p end
	end
	if (type(pos) ~= "number") then return end

	if (pos < 0) then pos = 0 end
	if (pos > 1) then pos = 1 end

	KA.Settings.displayDuration = math.floor(2 + pos * 8 + 0.5)
	UpdateDurationLabel()
end

function KillerByEgyptianKozi.OnRepeatsSlider(slidePos)
	local pos = slidePos
	if (type(pos) ~= "number") then
		local ok, p = pcall(SliderBarGetCurrentPosition, SystemData.ActiveWindow.name)
		if (ok and type(p) == "number") then pos = p end
	end
	if (type(pos) ~= "number") then return end

	if (pos < 0) then pos = 0 end
	if (pos > 1) then pos = 1 end

	KA.Settings.soundRepeats = math.floor(1 + pos * 9 + 0.5)
	UpdateRepeatsLabel()
end


-------------------------------------------------------------------------------
-- Slash commands
-------------------------------------------------------------------------------
function KillerByEgyptianKozi.SlashCommand(args)

	local cmd = ""
	if (args) then
		if (type(args) == "wstring" and WStringToString) then
			local ok, res = pcall(WStringToString, args)
			if (ok and res) then cmd = res end
		else
			cmd = tostring(args)
		end
	end

	-- Trim leading/trailing whitespace and convert to lowercase
	cmd = cmd:match("^%s*(.-)%s*$") or ""
	cmd = string.lower(cmd)
	-- Normalize multiple spaces to a single space
	cmd = cmd:gsub("%s+", " ")

	if (cmd == "on" or cmd == "enable") then
		KA.Settings.enabled = true
		KillerByEgyptianKozi._RegisterEvents()
		d(L"[KillerByEgyptianKozi] Enabled")

	elseif (cmd == "off" or cmd == "disable") then
		KA.Settings.enabled = false
		KillerByEgyptianKozi._UnregisterEvents()
		d(L"[KillerByEgyptianKozi] Disabled")

	elseif (cmd == "config" or cmd == "menu" or cmd == "options") then
		KillerByEgyptianKozi.ToggleConfigWindow()

	elseif (cmd == "assists on" or cmd == "assist on" or cmd == "assiston" or cmd == "assistson") then
		KA.Settings.showAssists = true
		d(L"[KillerByEgyptianKozi] Assist alerts enabled")

	elseif (cmd == "assists off" or cmd == "assist off" or cmd == "assistoff" or cmd == "assistsoff") then
		KA.Settings.showAssists = false
		d(L"[KillerByEgyptianKozi] Assist alerts disabled")

	elseif (cmd == "arrow on") then
		KA.Settings.showTargetArrow = true
		TargetInfo:UpdateFromClient()
		local targetId = TargetInfo:UnitEntityId(TargetInfo.HOSTILE_TARGET)
		if (targetId and targetId ~= 0) then
			KillerByEgyptianKozi._OnTargetUpdated(TargetInfo.HOSTILE_TARGET, targetId)
		end
		d(L"[KillerByEgyptianKozi] Target arrow indicator enabled")

	elseif (cmd == "arrow off") then
		KA.Settings.showTargetArrow = false
		RemoveTargetArrow()
		d(L"[KillerByEgyptianKozi] Target arrow indicator disabled")

	elseif (cmd == "streaks on") then
		KA.Settings.showStreaks = true
		d(L"[KillerByEgyptianKozi] Kill streak accolades enabled")

	elseif (cmd == "streaks off") then
		KA.Settings.showStreaks = false
		d(L"[KillerByEgyptianKozi] Kill streak accolades disabled")

	elseif (cmd == "rewards on") then
		KA.Settings.showRewards = true
		d(L"[KillerByEgyptianKozi] Renown/XP display enabled")

	elseif (cmd == "rewards off") then
		KA.Settings.showRewards = false
		RelayoutAllSlots()
		d(L"[KillerByEgyptianKozi] Renown/XP display disabled")

	elseif (cmd == "recap show") then
		-- Show the recap popup for the CURRENT life's damage on demand
		local savedSetting = KA.Settings.showDeathRecap
		KA.Settings.showDeathRecap = true
		KillerByEgyptianKozi.ShowDeathRecap()
		KA.Settings.showDeathRecap = savedSetting

	elseif (cmd == "recap close" or cmd == "recap hide") then
		KillerByEgyptianKozi.CloseRecapWindow()

	elseif (cmd == "recap" or cmd == "recap on" or cmd == "recap off") then
		-- Plain "recap" toggles the auto-popup setting; "on"/"off" force it
		local enable
		if (cmd == "recap on") then
			enable = true
		elseif (cmd == "recap off") then
			enable = false
		else
			enable = not (KA.Settings.showDeathRecap == true)
		end
		KA.Settings.showDeathRecap = enable
		if (enable) then
			d(L"[KillerByEgyptianKozi] Death Recap popup enabled")
		else
			d(L"[KillerByEgyptianKozi] Death Recap popup disabled")
			KillerByEgyptianKozi.CloseRecapWindow()
		end

	elseif (cmd == "testrecap") then
		-- Seed a few fake attackers, show the recap popup, then clear
		RecordDamageTaken(L"Grikson", 2500)
		RecordDamageTaken(L"Darkaim", 1850)
		RecordDamageTaken(L"Grikson", 300)
		RecordDamageTaken(L"Zealotra", 920)
		-- Attach sample career lines so the class icons are exercised in the test
		-- (guarded: GameData.CareerLine entries vary by client build).
		local ok, cl = pcall(function() return GameData.CareerLine end)
		if (ok and type(cl) == "table") then
			if (damageTracker["Grikson"])  then damageTracker["Grikson"].careerLine  = cl.SQUIG_HERDER or cl.SHADOW_WARRIOR end
			if (damageTracker["Darkaim"])  then damageTracker["Darkaim"].careerLine  = cl.SORCERER or cl.BRIGHT_WIZARD end
			if (damageTracker["Zealotra"]) then damageTracker["Zealotra"].careerLine = cl.ZEALOT or cl.WARRIOR_PRIEST end
		end
		local savedSetting = KA.Settings.showDeathRecap
		KA.Settings.showDeathRecap = true
		KillerByEgyptianKozi.ShowDeathRecap()
		KA.Settings.showDeathRecap = savedSetting
		ClearDamageTracker()

	elseif (cmd == "test") then
		KillerByEgyptianKozi._ShowKillAlert(L"TestEnemy", nil)

	elseif (cmd == "testassist") then
		KillerByEgyptianKozi._ShowKillAlert(L"TestEnemy", L"AlliedPlayer")

	elseif (cmd == "testreward") then
		if (not KA.Settings.showRewards) then
			d(L"[KillerByEgyptianKozi] Note: Renown/XP display is disabled (/killer rewards on)")
		end
		KillerByEgyptianKozi._ShowKillAlert(L"TestEnemy", nil)
		AttachReward("rp", 145)
		AttachReward("xp", 230)

	elseif (cmd == "teststreak") then
		if (not DoesWindowExist("KillerByEgyptianKoziStreakWindow")) then
			d(L"[KillerByEgyptianKozi] ERROR: streak banner window was not created - check for load errors (/reloadui and watch chat)")
		else
			KillerByEgyptianKozi._ShowStreakBanner(L"TRIPLE KILL!", 3)
		end

	elseif (cmd == "hud" or cmd == "hud on" or cmd == "hud off") then
		-- Plain "hud" toggles; "hud on"/"hud off" force the state
		local show
		if (cmd == "hud on") then
			show = true
		elseif (cmd == "hud off") then
			show = false
		else
			show = not (KA.Settings.showHUD == true)
		end

		KA.Settings.showHUD = show
		if (DoesWindowExist("KillerByEgyptianKoziHUD")) then
			WindowSetShowing("KillerByEgyptianKoziHUD", show)
			if (show) then
				KillerByEgyptianKozi.UpdateHUD()
			end
		elseif (show) then
			d(L"[KillerByEgyptianKozi] ERROR: HUD window was not created - check for load errors")
		end
		if (show) then
			d(L"[KillerByEgyptianKozi] HUD enabled")
		else
			d(L"[KillerByEgyptianKozi] HUD disabled")
		end

	elseif (cmd == "test7") then
		-- Rapid-fire 7 test messages to show stacking
		KillerByEgyptianKozi._ShowKillAlert(L"TargetOne", nil)
		KillerByEgyptianKozi._ShowKillAlert(L"TargetTwo", nil)
		KillerByEgyptianKozi._ShowKillAlert(L"TargetThree", L"AllyOne")
		KillerByEgyptianKozi._ShowKillAlert(L"TargetFour", nil)
		KillerByEgyptianKozi._ShowKillAlert(L"TargetFive", L"AllyTwo")
		KillerByEgyptianKozi._ShowKillAlert(L"TargetSix", nil)
		KillerByEgyptianKozi._ShowKillAlert(L"TargetSeven", L"AllyThree")

	elseif (cmd == "clear") then
		messageQueue = {}
		for i = 1, MAX_SLOTS do
			WindowSetShowing(SlotWindowName(i), false)
			slotState[i] = 0
		end
		d(L"[KillerByEgyptianKozi] Alerts cleared")

	elseif (cmd == "history" or cmd == "log") then
		KillerByEgyptianKozi.ToggleHistoryWindow()

	elseif (cmd == "stats") then
		d(wsformat(L"[KillerByEgyptianKozi] Kills: %d | Assists: %d | Best streak: %d | RP: %d | XP: %d",
			KA.Stats.totalKills or 0, KA.Stats.totalAssists or 0, KA.Stats.bestStreak or 0,
			KA.Stats.totalRP or 0, KA.Stats.totalXP or 0))

	elseif (cmd == "reset") then
		recentTargets = {}
		currentStreak = 0
		ClearDamageTracker()
		KillerByEgyptianKozi.History = {}
		KillerByEgyptianKozi.RefreshHistoryUI()
		d(L"[KillerByEgyptianKozi] Recent targets, streak, damage tracker, and history cleared")

	else
		d(L"[KillerByEgyptianKozi] Commands:")
		d(L"  /killer config|menu     - Toggle the configuration panel")
		d(L"  /killer on|off          - Enable/disable alerts")
		d(L"  /killer assist on|off   - Enable/disable assist alerts")
		d(L"  /killer arrow on|off    - Enable/disable hostile target arrow")
		d(L"  /killer streaks on|off  - Enable/disable kill streak accolades")
		d(L"  /killer rewards on|off  - Enable/disable Renown/XP display")
		d(L"  /killer recap [on|off]  - Toggle the death recap popup (last 10 attackers)")
		d(L"  /killer recap show      - Open the recap popup for your current life")
		d(L"  /killer hud [on|off]    - Toggle the stats HUD (click it to open config)")
		d(L"  /killer history|log     - Toggle history log window")
		d(L"  /killer stats           - Print lifetime kill statistics")
		d(L"  /killer test            - Show a test kill alert")
		d(L"  /killer testassist      - Show a test assist alert")
		d(L"  /killer testreward      - Show a test alert with RP/XP rewards")
		d(L"  /killer testrecap       - Show a sample death recap popup")
		d(L"  /killer teststreak      - Show a test streak banner")
		d(L"  /killer test7           - Show 7 stacked test alerts")
		d(L"  /killer clear           - Clear all visible alerts")
		d(L"  /killer reset           - Reset tracked targets, streak & history")
	end
end

-- Register slash commands with LibSlash if available
if LibSlash and LibSlash.RegisterSlashCmd then
	pcall(LibSlash.RegisterSlashCmd, "killer", function(args) KillerByEgyptianKozi.SlashCommand(args) end)
	pcall(LibSlash.RegisterSlashCmd, "killerbyegyptiankozi", function(args) KillerByEgyptianKozi.SlashCommand(args) end)
end

-- Usage: type these directly in the game chat window:
--   /killer config
--   /killer on / off
--   /killer assists on / off
--   /killer arrow on / off
--   /killer streaks on / off
--   /killer rewards on / off
--   /killer history
--   /killer stats
--   /killer test / testassist / testreward / teststreak / test7
--   /killer clear
--   /killer reset
