<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
    <UiMod name="WarBoard_Tokens" version="0.5.3" date="08/09/2026">

        <Author name="Lizardry and Ninjas" email="xxx@xxx.com" />
        <Description text="A session War Tokens tracker mod for WarBoard." />
        <VersionSettings gameVersion="1.4.8" />

        <Dependencies>
            <Dependency name="WarBoard" />
        </Dependencies>

        <Files>
            <File name="WarBoard_Tokens.lua" />
            <File name="WarBoard_Tokens.xml" />
        </Files>

        <SavedVariables>
            <SavedVariable name="WarBoard_Tokens_Settings" />
        </SavedVariables>

        <OnInitialize>
            <CallFunction name="WarBoard_Tokens.Initialize" />
        </OnInitialize>

        <OnUpdate />
        <OnShutdown />
    </UiMod>
</ModuleFile>