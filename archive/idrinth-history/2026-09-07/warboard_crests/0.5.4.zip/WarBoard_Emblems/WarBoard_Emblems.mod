<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
    <UiMod name="WarBoard_Emblems" version="0.5.4" date="08/10/2026">

        <Author name="Lizardry and Ninjas" email="xxx@xxx.com" />
        <Description text="A session War Emblems tracker mod for WarBoard." />
        <VersionSettings gameVersion="1.4.8" />

        <Dependencies>
            <Dependency name="WarBoard" />
        </Dependencies>

        <Files>
            <File name="WarBoard_Emblems.lua" />
            <File name="WarBoard_Emblems.xml" />
        </Files>

        <SavedVariables>
            <SavedVariable name="WarBoard_Emblems_Settings" />
        </SavedVariables>

        <OnInitialize>
            <CallFunction name="WarBoard_Emblems.Initialize" />
        </OnInitialize>

        <OnUpdate />
        <OnShutdown />
    </UiMod>
</ModuleFile>