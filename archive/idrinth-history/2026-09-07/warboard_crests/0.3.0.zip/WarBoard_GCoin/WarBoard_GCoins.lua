WarBoard_GCoins = WarBoard_GCoins or {}
WarBoard_GCoins_Settings = WarBoard_GCoins_Settings or {}

local towstring, Tooltips = towstring, Tooltips

local defaults = {
	initialCrestCount = 0,
	currentCrestCount = 0,
	displayMode = 1, -- 1=current, 2=earned, 3=remaining
	crestId = 308,
	goalCount = 0,
	version = 1,
}

local settings = nil

local function applyDefaults(dst, src)
	for k, v in pairs(src) do
		if dst[k] == nil then
			dst[k] = v
		end
	end
end

local function getEarnedCount()
	return (settings.currentCrestCount or 0) - (settings.initialCrestCount or 0)
end

local function chat(msg)
	EA_ChatWindow.Print(L"[GCoins]: " .. msg)
end

-- Returns:
-- status = "none", "remaining", "met", "over"
-- value  = number or nil
local function getGoalStatus()
	local goal = tonumber(settings.goalCount) or 0
	local current = tonumber(settings.currentCrestCount) or 0

	if goal <= 0 then
		return "none", nil
	end

	local diff = goal - current

	if diff > 0 then
		return "remaining", diff
	elseif diff == 0 then
		return "met", 0
	else
		return "over", math.abs(diff)
	end
end

function WarBoard_GCoins.Initialize()
	if not WarBoard.AddMod("WarBoard_GCoins") then
		return
	end

	WarBoard_GCoins_Settings = WarBoard_GCoins_Settings or {}
	applyDefaults(WarBoard_GCoins_Settings, defaults)
	settings = WarBoard_GCoins_Settings

	local texture, x, y = GetIconData(25022)
	DynamicImageSetTexture("WarBoard_GCoinsIcon", texture, x, y)

	RegisterEventHandler(SystemData.Events.PLAYER_CURRENCY_SLOT_UPDATED, "WarBoard_GCoins.updateGCoins")

	if LibSlash and not LibSlash.IsSlashCmdRegistered("GCoins") then
		LibSlash.RegisterWSlashCmd("GCoins", WarBoard_GCoins.SlashHandler)
	end

	WarBoard_GCoins.updateGCoins()
	WarBoard_GCoins.updateLabel()
end

function WarBoard_GCoins.getGCoinsCount()
	local data = DataUtils.GetCurrencyItems()
	local GCoinsCount = 0

	for _, v in ipairs(data) do
		if v.uniqueID == settings.crestId then
			GCoinsCount = GCoinsCount + (tonumber(v.stackCount) or 0)
		end
	end

	return GCoinsCount
end

function WarBoard_GCoins.updateGCoins()
	settings.currentCrestCount = WarBoard_GCoins.getGCoinsCount()

	if settings.initialCrestCount == 0 and settings.currentCrestCount > 0 then
		settings.initialCrestCount = settings.currentCrestCount
	end

	WarBoard_GCoins.updateLabel()
end

function WarBoard_GCoins.updateLabel()
	local current = tonumber(settings.currentCrestCount) or 0
	local earned = getEarnedCount()
	local mode = settings.displayMode or 1

	if mode == 1 then
		LabelSetText("WarBoard_GCoinsText", towstring(current))
		LabelSetTextColor("WarBoard_GCoinsText", 255, 200, 0)
	elseif mode == 2 then
		LabelSetText("WarBoard_GCoinsText", towstring(earned))
		LabelSetTextColor("WarBoard_GCoinsText", 0, 180, 255)
	else
		local status, value = getGoalStatus()

		if status == "none" then
			LabelSetText("WarBoard_GCoinsText", L"-")
			LabelSetTextColor("WarBoard_GCoinsText", 255, 0, 0)
		elseif status == "remaining" then
			LabelSetText("WarBoard_GCoinsText", towstring(value))
			LabelSetTextColor("WarBoard_GCoinsText", 255, 0, 0)
		elseif status == "met" then
			LabelSetText("WarBoard_GCoinsText", L"0")
			LabelSetTextColor("WarBoard_GCoinsText", 0, 255, 0)
		elseif status == "over" then
			LabelSetText("WarBoard_GCoinsText", towstring(value))
			LabelSetTextColor("WarBoard_GCoinsText", 0, 255, 0)
		end
	end
end

function WarBoard_GCoins.OnUpdate()
end

function WarBoard_GCoins.OnLClick()
	settings.initialCrestCount = settings.currentCrestCount or 0
	WarBoard_GCoins.updateLabel()
	chat(L"earned baseline reset")
end

function WarBoard_GCoins.OnRClick()
	settings.displayMode = (settings.displayMode or 1) + 1
	if settings.displayMode > 3 then
		settings.displayMode = 1
	end

	WarBoard_GCoins.updateLabel()

	if settings.displayMode == 1 then
		chat(L"display mode: current")
	elseif settings.displayMode == 2 then
		chat(L"display mode: earned")
	else
		chat(L"display mode: remaining")
	end
end

function WarBoard_GCoins.OnMClick()
	settings.goalCount = 0
	WarBoard_GCoins.updateLabel()
	chat(L"goal cleared")
end

function WarBoard_GCoins.SlashHandler(input)
	local strInput = WStringToString(input or L"")
	local goal = tonumber(strInput)

	if not goal then
		chat(L"usage /GCoins 5000")
		return
	end

	if goal < 0 then
		goal = 0
	end

	settings.goalCount = goal
	WarBoard_GCoins.updateLabel()
	chat(L"goal set to " .. towstring(goal))
end

function WarBoard_GCoins.OnMouseOver()
	local earned = getEarnedCount()
	local current = settings.currentCrestCount or 0
	local goal = settings.goalCount or 0
	local mode = settings.displayMode or 1
	local modeText = L"Current"

	if mode == 2 then
		modeText = L"Earned"
	elseif mode == 3 then
		modeText = L"Remaining"
	end

	local status, value = getGoalStatus()

	Tooltips.CreateTextOnlyTooltip("WarBoard_GCoins", nil)
	Tooltips.AnchorTooltip(WarBoard.GetModToolTipAnchor("WarBoard_GCoins"))
	Tooltips.SetTooltipText(1, 1, L"Guild Coins")
	Tooltips.SetTooltipText(2, 1, L"Mode: " .. modeText)
	Tooltips.SetTooltipText(3, 1, L"Current: " .. towstring(current))
	Tooltips.SetTooltipText(4, 1, L"Earned: " .. towstring(earned))

	if status == "remaining" then
		Tooltips.SetTooltipText(5, 1, L"Remaining: " .. towstring(value))
		Tooltips.SetTooltipText(6, 1, L"Goal: " .. towstring(goal))
	elseif status == "met" then
		Tooltips.SetTooltipText(5, 1, L"Over Goal")
		Tooltips.SetTooltipText(6, 1, L"Goal: " .. towstring(goal))
	elseif status == "over" then
		Tooltips.SetTooltipText(5, 1, L"Over Goal: " .. towstring(value))
		Tooltips.SetTooltipText(6, 1, L"Goal: " .. towstring(goal))
	else
		Tooltips.SetTooltipText(5, 1, L"Goal: " .. towstring(goal))
	end

	Tooltips.SetTooltipText(7, 1, L"Left-click: reset session earned")
	Tooltips.SetTooltipText(8, 1, L"Right-click: cycle current/earned/remaining")
	Tooltips.SetTooltipText(9, 1, L"Middle-click: clear goal")
	Tooltips.SetTooltipText(10, 1, L"/GCoins <number>: set goal")
	Tooltips.Finalize()
end