----------------------------------------------------------------
-- Original addon by Talladego
-- Optimized update by Kpihuss
----------------------------------------------------------------

----------------------------------------------------------------
-- WarTriage.lua 
----------------------------------------------------------------

----------------------------------------------------------------
-- Local variables 
----------------------------------------------------------------

local VERSION = 10010
local VERSION_LABEL = "1.0.10"
local DEBUG_MODE = false
local WARTRIAGE_MACRO_NAME = "WarTriage"
local WARTRIAGE_MACRO_TEXT = "/script WarTriage.MacroFallback()"
local WARTRIAGE_MACRO_ICON = 20087
local LOCAL_PLAYER_NAME = GameData.Player.name
local MAX_HEAL_DISTANCE = 150
local MAX_RESS_DISTANCE = 100
local DISTANCE_FIX_COEFFICIENT = 1 / 1.06
local MAX_MAP_POINTS = 511
local TIME_DELAY = 0.5
local HEALER = L"HEALER"
local DPS = L"DPS"
local TANK = L"TANK"

-- Localized functions
local mathFloor = math.floor
local pairs = pairs
local ipairs = ipairs

local timeLeft = TIME_DELAY
local eventsRegistered = false
--local alertPlayer = L""

local MapPointTypeFilter = {
	[SystemData.MapPips.PLAYER] = true,
	[SystemData.MapPips.GROUP_MEMBER] = true,
	[SystemData.MapPips.WARBAND_MEMBER] = true,
	[SystemData.MapPips.DESTRUCTION_ARMY] = true,
	[SystemData.MapPips.ORDER_ARMY] = true
}

local ArcheType = {
	[GameData.CareerLine.ZEALOT] 			= HEALER,
	[GameData.CareerLine.ARCHMAGE] 			= HEALER,
	[GameData.CareerLine.SHAMAN] 			= HEALER,
	[GameData.CareerLine.RUNE_PRIEST] 		= HEALER,
	[GameData.CareerLine.WARRIOR_PRIEST] 	= HEALER,
	[GameData.CareerLine.DISCIPLE] 			= HEALER,
	[GameData.CareerLine.ENGINEER] 			= DPS,
	[GameData.CareerLine.SLAYER] 			= DPS,
	[GameData.CareerLine.MARAUDER] 			= DPS,
	[GameData.CareerLine.SHADOW_WARRIOR] 	= DPS,
	[GameData.CareerLine.CHOPPA] 			= DPS,
	[GameData.CareerLine.SQUIG_HERDER] 		= DPS,
	[GameData.CareerLine.WHITE_LION] 		= DPS,
	[GameData.CareerLine.WITCH_ELF] 		= DPS,
	[GameData.CareerLine.SORCERER] 			= DPS,
	[GameData.CareerLine.WITCH_HUNTER] 		= DPS,
	[GameData.CareerLine.MAGUS] 			= DPS,
	[GameData.CareerLine.BRIGHT_WIZARD] 	= DPS,
	[GameData.CareerLine.IRON_BREAKER] 		= TANK,
	[GameData.CareerLine.KNIGHT] 			= TANK,
	[GameData.CareerLine.SWORDMASTER] 		= TANK,
	[GameData.CareerLine.BLACKGUARD] 		= TANK,
	[GameData.CareerLine.CHOSEN] 			= TANK,
	[GameData.CareerLine.BLACK_ORC] 		= TANK,
}
local CareerIDsToLines = {
	[20]	= GameData.CareerLine.IRON_BREAKER,
	[100]	= GameData.CareerLine.SWORDMASTER,
	[64]	= GameData.CareerLine.CHOSEN,
	[24]	= GameData.CareerLine.BLACK_ORC,
	[60]	= GameData.CareerLine.WITCH_HUNTER,
	[102]	= GameData.CareerLine.WHITE_LION,
	[65]	= GameData.CareerLine.MARAUDER,
	[105]	= GameData.CareerLine.WITCH_ELF,
	[62]	= GameData.CareerLine.BRIGHT_WIZARD,
	[67]	= GameData.CareerLine.MAGUS,
	[107]	= GameData.CareerLine.SORCERER,
	[23]	= GameData.CareerLine.ENGINEER,
	[101]	= GameData.CareerLine.SHADOW_WARRIOR,
	[27]	= GameData.CareerLine.SQUIG_HERDER,
	[63]	= GameData.CareerLine.WARRIOR_PRIEST,
	[106]	= GameData.CareerLine.DISCIPLE,
	[103]	= GameData.CareerLine.ARCHMAGE,
	[26]	= GameData.CareerLine.SHAMAN,
	[22]	= GameData.CareerLine.RUNE_PRIEST,
	[66]	= GameData.CareerLine.ZEALOT,
	[104]	= GameData.CareerLine.BLACKGUARD,
	[61]	= GameData.CareerLine.KNIGHT,
	[25]	= GameData.CareerLine.CHOPPA,
	[21]	= GameData.CareerLine.SLAYER,
}

local LosCheckAbiliyId = {
	[GameData.CareerLine.SHAMAN]			= {healID = 1898, ressID = 1908}, -- Gork'll Fix It, Gedup!
	[GameData.CareerLine.RUNE_PRIEST]		= {healID = 1587, ressID = 1598}, -- Grungni's Gift, Rune of Life
	[GameData.CareerLine.DISCIPLE]			= {healID = 9548, ressID = 9558}, -- Restore Essence, Stand, Coward!
	[GameData.CareerLine.ARCHMAGE]			= {healID = 9236, ressID = 9246}, -- Healing Energy, Gift of Life
	[GameData.CareerLine.WARRIOR_PRIEST]	= {healID = 8238, ressID = 8248}, -- Divine Aid, Breath of Sigmar
	[GameData.CareerLine.ZEALOT]			= {healID = 8569, ressID = 8555}, -- Flash Of Chaos, Tzeentch Shall Remake You
}

local function fixString (str)
	if (str == nil) then return nil end
	local str = str
	local pos = str:find (L"^", 1, true)
	if (pos) then str = str:sub (1, pos - 1) end
	return str
end

local function hasBuff(target, id)
    local buffData = GetBuffs(target)
    if (buffData == nil)
    then
        return false
    end

    for _, b in pairs( buffData )
    do
        if (b.abilityId == id)
        then
            return true
        end
    end
    return false
end

local function debugToString(value)
	if value == nil then return "nil" end
	return tostring(value)
end

local function WTDebug(msg)
	if not DEBUG_MODE then return end
	TextLogAddEntry("Chat", 0, towstring("<icon20087> WTDBG: " .. tostring(msg)))
end

local function RegisterSlashCommandSafe(cmd, handler, reason)
	if not LibSlash or not LibSlash.RegisterSlashCmd then
		WTDebug("LibSlash missing while registering /" .. tostring(cmd) .. " (" .. tostring(reason) .. ")")
		return false
	end

	local alreadyRegistered = false
	if LibSlash.IsSlashCmdRegistered then
		local okState, resultState = pcall(function()
			return LibSlash.IsSlashCmdRegistered(cmd)
		end)
		if okState then
			alreadyRegistered = resultState and true or false
		else
			WTDebug("IsSlashCmdRegistered failed for /" .. tostring(cmd) .. ": " .. debugToString(resultState))
		end
	end

	if alreadyRegistered then
		return true
	end

	local okRegister, resultRegister = pcall(function()
		return LibSlash.RegisterSlashCmd(cmd, handler)
	end)

	if not okRegister then
		WTDebug("RegisterSlashCmd crashed for /" .. tostring(cmd) .. ": " .. debugToString(resultRegister))
		return false
	end

	WTDebug("Register /" .. tostring(cmd) .. " => " .. debugToString(resultRegister) .. " (" .. tostring(reason) .. ")")
	return resultRegister and true or false
end

-- local function HasAbility(id)
	-- local actionId
	-- for i = 1, 60 do
		-- _, actionId = GetHotbarData(i)
		-- if actionId == LosCheckAbiliyId[GameData.Player.career.line].healID then
			-- return true
		-- end
	-- end
	-- return false
-- end

----------------------------------------------------------------
-- WarTriage
----------------------------------------------------------------
WarTriage = {}
WarTriage.Player = {}
WarTriage.Players = {}
WarTriage.PlayerTarget = L""
WarTriage.MacroId = nil
WarTriage.LastMacroTarget = nil
WarTriage.LastGlowLevel = nil
WarTriage.DesiredMacroTarget = L""
WarTriage.DesiredGlowLevel = 0
WarTriage.NeedsMacroRebind = false
WarTriage.RebindAttemptsLeft = 0
WarTriage.RebindTimer = 0

function WarTriage.Initialize()
	WTDebug("Initialize start")

	if not WarTriage.Settings
	or not WarTriage.Settings.version
	or WarTriage.Settings.version ~= VERSION
	then
		WarTriage.Settings = WarTriage.DefaultSettings
		WTDebug("Settings reset to defaults for version " .. VERSION_LABEL)
	end

	RegisterSlashCommandSafe("wartriage", function(input) WarTriage_Config.Slash(input) end, "Initialize")
	RegisterSlashCommandSafe("wt", function(input) WarTriage_Config.Slash(input) end, "Initialize")
	RegisterSlashCommandSafe("WarTriage", function(input) WarTriage_Config.Slash(input) end, "Initialize")

	RegisterEventHandler(SystemData.Events.ENTER_WORLD, "WarTriage.OnEnterWorld")
	RegisterEventHandler(SystemData.Events.INTERFACE_RELOADED, "WarTriage.OnInterfaceReloaded")
	RegisterEventHandler(SystemData.Events.LOADING_END, "WarTriage.OnLoadingEnd")
	WTDebug("Lifecycle event handlers registered (no hotbar hook)")

	WarTriage.CheckCareer()
	WTDebug("isHealer=" .. tostring(WarTriage.Settings.isHealer))

	if WarTriage.Settings.isHealer then
		if not WarTriage.UpdateMacro(WARTRIAGE_MACRO_NAME, WARTRIAGE_MACRO_TEXT, WARTRIAGE_MACRO_ICON) then
			TextLogAddEntry("Chat", 0, towstring("<icon20087> WarTriage failed to create macro!"))
			WTDebug("UpdateMacro failed during Initialize")
		else
			TextLogAddEntry("Chat", 0, towstring("<icon20087> WarTriage macro created"))
			WTDebug("Macro created/updated during Initialize")
		end
		WarTriage.PrintSettings()
	end
end

function WarTriage.OnShutdown()
	UnregisterEventHandler(SystemData.Events.ENTER_WORLD, "WarTriage.OnEnterWorld")
	UnregisterEventHandler(SystemData.Events.INTERFACE_RELOADED, "WarTriage.OnInterfaceReloaded")
	UnregisterEventHandler(SystemData.Events.LOADING_END, "WarTriage.OnLoadingEnd")
	WTDebug("Shutdown")
end

function WarTriage.InvalidateMacroCache()
	WarTriage.MacroId = nil
	WarTriage.MacroSlots = nil
	WarTriage.LastMacroTarget = nil
	WarTriage.LastGlowLevel = nil
end

function WarTriage.RequestMacroRebind(reason)
	if WarTriage.NeedsMacroRebind and WarTriage.RebindAttemptsLeft and WarTriage.RebindAttemptsLeft > 0 then
		return
	end
	WarTriage.NeedsMacroRebind = true
	WarTriage.RebindAttemptsLeft = 5
	WarTriage.RebindTimer = 0
	WTDebug("RequestMacroRebind reason=" .. debugToString(reason))
end

function WarTriage.ProcessMacroRebind(elapsed)
	if not WarTriage.NeedsMacroRebind then
		return
	end

	WarTriage.RebindTimer = (WarTriage.RebindTimer or 0) - elapsed
	if WarTriage.RebindTimer > 0 then
		return
	end
	WarTriage.RebindTimer = 0.10

	if not WarTriage.Settings or not WarTriage.Settings.isHealer then
		WarTriage.NeedsMacroRebind = false
		WTDebug("ProcessMacroRebind abort: not healer")
		return
	end

	local macroId = WarTriage.GetMacroId(WARTRIAGE_MACRO_NAME)
	if not macroId then
		WTDebug("ProcessMacroRebind: macro missing, recreating")
		if not WarTriage.UpdateMacro(WARTRIAGE_MACRO_NAME, WARTRIAGE_MACRO_TEXT, WARTRIAGE_MACRO_ICON) then
			WarTriage.RebindAttemptsLeft = WarTriage.RebindAttemptsLeft - 1
			if WarTriage.RebindAttemptsLeft <= 0 then
				WarTriage.NeedsMacroRebind = false
				WTDebug("ProcessMacroRebind failed: macro could not be recreated")
			end
			return
		end
	end

	WarTriage.InvalidateMacroCache()
	WarTriage.SetMacroTarget(WARTRIAGE_MACRO_NAME, WarTriage.DesiredMacroTarget or L"", WarTriage.DesiredGlowLevel or 0, true)

	if WarTriage.MacroSlots and #WarTriage.MacroSlots > 0 then
		WarTriage.NeedsMacroRebind = false
		WTDebug("ProcessMacroRebind success")
	else
		WarTriage.RebindAttemptsLeft = WarTriage.RebindAttemptsLeft - 1
		if WarTriage.RebindAttemptsLeft <= 0 then
			WarTriage.NeedsMacroRebind = false
			WTDebug("ProcessMacroRebind gave up: macro not visible on any slot")
		end
	end
end

function WarTriage.OnEnterWorld()
	WTDebug("ENTER_WORLD")
	RegisterSlashCommandSafe("wartriage", function(input) WarTriage_Config.Slash(input) end, "ENTER_WORLD")
	RegisterSlashCommandSafe("wt", function(input) WarTriage_Config.Slash(input) end, "ENTER_WORLD")
	RegisterSlashCommandSafe("WarTriage", function(input) WarTriage_Config.Slash(input) end, "ENTER_WORLD")
	WarTriage.InvalidateMacroCache()
	WarTriage.RequestMacroRebind("ENTER_WORLD")
end

function WarTriage.OnInterfaceReloaded()
	WTDebug("INTERFACE_RELOADED")
	RegisterSlashCommandSafe("wartriage", function(input) WarTriage_Config.Slash(input) end, "INTERFACE_RELOADED")
	RegisterSlashCommandSafe("wt", function(input) WarTriage_Config.Slash(input) end, "INTERFACE_RELOADED")
	RegisterSlashCommandSafe("WarTriage", function(input) WarTriage_Config.Slash(input) end, "INTERFACE_RELOADED")
	WarTriage.InvalidateMacroCache()
	WarTriage.RequestMacroRebind("INTERFACE_RELOADED")
end

function WarTriage.OnLoadingEnd()
	WTDebug("LOADING_END")
	RegisterSlashCommandSafe("wartriage", function(input) WarTriage_Config.Slash(input) end, "LOADING_END")
	RegisterSlashCommandSafe("wt", function(input) WarTriage_Config.Slash(input) end, "LOADING_END")
	RegisterSlashCommandSafe("WarTriage", function(input) WarTriage_Config.Slash(input) end, "LOADING_END")
	WarTriage.InvalidateMacroCache()
	WarTriage.RequestMacroRebind("LOADING_END")
end

function WarTriage.MacroFallback()
	WTDebug("MacroFallback executed")
	RegisterSlashCommandSafe("wartriage", function(input) WarTriage_Config.Slash(input) end, "MacroFallback")
	RegisterSlashCommandSafe("wt", function(input) WarTriage_Config.Slash(input) end, "MacroFallback")
	RegisterSlashCommandSafe("WarTriage", function(input) WarTriage_Config.Slash(input) end, "MacroFallback")
	WarTriage.InvalidateMacroCache()
	WarTriage.RequestMacroRebind("MacroFallback")
	WarTriage.CheckCareer()

	if not WarTriage.Settings or not WarTriage.Settings.enabled then
		WTDebug("MacroFallback abort: addon disabled")
		return
	end

	if not WarTriage.Settings.isHealer then
		WTDebug("MacroFallback abort: current class is not healer")
		return
	end

	WarTriage.PlayerTarget = WarTriage.GetFriendlyTarget()
	WarTriage.Players = WarTriage.GetFriendlyPlayers()
	local player = WarTriage.GetHurtPlayer()
	if player and player.name and player.name ~= L"" then
		WarTriage.TargetPlayer(player)
	else
		WTDebug("Fallback found no valid candidate")
		WarTriage.SetMacroTarget(WARTRIAGE_MACRO_NAME, L"", 0)
	end
end


-- function WarTriage.RegisterEventHandlers(enabled)

	-- if not eventsRegistered and enabled then
		-- RegisterEventHandler(SystemData.Events.LOADING_END, "WarTriage.CheckCareer")
		-- RegisterEventHandler(SystemData.Events.PLAYER_TARGET_UPDATED, "WarTriage.GetFriendlyTarget")
		-- RegisterEventHandler(SystemData.Events.PLAYER_CUR_HIT_POINTS_UPDATED, "WarTriage.UpdatePlayers")
		-- RegisterEventHandler(SystemData.Events.GROUP_UPDATED, "WarTriage.UpdatePlayers")							-- Called continously when in Party
		-- RegisterEventHandler(SystemData.Events.GROUP_STATUS_UPDATED, "WarTriage.UpdatePlayers")						-- Called on party HP changes
		-- RegisterEventHandler(SystemData.Events.SCENARIO_GROUP_UPDATED, "WarTriage.UpdatePlayers")					-- Called on Scenario Group changes
		-- RegisterEventHandler(SystemData.Events.SCENARIO_PLAYER_HITS_UPDATED, "WarTriage.UpdatePlayers")				-- Called on Scenario HP changes
		-- RegisterEventHandler(SystemData.Events.BATTLEGROUP_UPDATED, "WarTriage.UpdatePlayers")						-- Called continously when in Warband
		-- RegisterEventHandler(SystemData.Events.BATTLEGROUP_MEMBER_UPDATED, "WarTriage.UpdatePlayers")				-- Called on on Warband HP changes
		-- eventsRegistered = true
		-- d("Events registered")
	-- elseif eventsRegistered and not enabled then
		-- UnregisterEventHandler(SystemData.Events.LOADING_END, "WarTriage.LOADING_END")
		-- UnregisterEventHandler(SystemData.Events.PLAYER_TARGET_UPDATED, "WarTriage.GetFriendlyTarget")
		-- UnregisterEventHandler(SystemData.Events.PLAYER_CUR_HIT_POINTS_UPDATED, "WarTriage.UpdatePlayers")
		-- UnregisterEventHandler(SystemData.Events.GROUP_UPDATED, "WarTriage.UpdatePlayers")
		-- UnregisterEventHandler(SystemData.Events.GROUP_STATUS_UPDATED, "WarTriage.UpdatePlayers")
		-- UnregisterEventHandler(SystemData.Events.SCENARIO_GROUP_UPDATED, "WarTriage.UpdatePlayers")
		-- UnregisterEventHandler(SystemData.Events.SCENARIO_PLAYER_HITS_UPDATED, "WarTriage.UpdatePlayers")
		-- UnregisterEventHandler(SystemData.Events.BATTLEGROUP_UPDATED, "WarTriage.UpdatePlayers")
		-- UnregisterEventHandler(SystemData.Events.BATTLEGROUP_MEMBER_UPDATED, "WarTriage.UpdatePlayers")
		-- UnregisterEventHandler(SystemData.Events.LOADING_END, "WarTriage.CheckCareer")
		-- eventsRegistered = false
		-- d("Events unregistered")
	-- end
-- end

WarTriage.DefaultSettings = {
		version = VERSION,
		enabled = true,
		--screenAlerts = false,
		ignoreDead = false,
		glowEffects = true,
		selfTargetPct = 75,
		healerTargetPct = 75,
		dpsTargetPct = 50,
		tankTargetPct = 25,
		playerTargetPct = 100,
		isHealer = false,
		macroCreated = false,
		losCheck = true,
		rangeCheck = true,
		ownPartyOnly = false,
}

function WarTriage.OnUpdate(elapsed)
	WarTriage.ProcessMacroRebind(elapsed)

    timeLeft = timeLeft - elapsed
	if timeLeft > 0 then
        return
    end
    timeLeft = TIME_DELAY
	
    --WarTriage.RegisterEventHandlers(WarTriage.Settings.enabled)

	if WarTriage.Settings.enabled and WarTriage.Settings.isHealer then
		WarTriage.PlayerTarget = WarTriage.GetFriendlyTarget()
		WarTriage.Players = WarTriage.GetFriendlyPlayers()
		WarTriage.TargetPlayer( WarTriage.GetHurtPlayer() )
	end
end

function WarTriage.CheckCareer()
	if ArcheType[CareerIDsToLines[GameData.Player.career.id]] == HEALER then
		WarTriage.Settings.isHealer = true
	else
		WarTriage.Settings.isHealer = false
	end
end

function WarTriage.PrintSettings()
	TextLogAddEntry("Chat", 0, towstring("<icon20087> WarTriage v" .. VERSION_LABEL .. " settings: /wartriage"))
	if WarTriage.Settings.enabled then
		TextLogAddEntry("Chat", 0, L"--- <icon57> Enabled")
	else
		TextLogAddEntry("Chat", 0, L"--- <icon58> Enabled")
	end

	if WarTriage.Settings.losCheck then
		TextLogAddEntry("Chat", 0, L"--- <icon57> Check LOS")
	else
		TextLogAddEntry("Chat", 0, L"--- <icon58> Check LOS")
	end

	if WarTriage.Settings.rangeCheck then
		TextLogAddEntry("Chat", 0, L"--- <icon57> Check Range")
	else
		TextLogAddEntry("Chat", 0, L"--- <icon58> Check Range")
	end

	if WarTriage.Settings.ownPartyOnly then
		TextLogAddEntry("Chat", 0, L"--- <icon57> Own Party Only")
	else
		TextLogAddEntry("Chat", 0, L"--- <icon58> Own Party Only")
	end

	if WarTriage.Settings.ignoreDead then
		TextLogAddEntry("Chat", 0, L"--- <icon57> Ignore Dead")
	else
		TextLogAddEntry("Chat", 0, L"--- <icon58> Ignore Dead")
	end

	-- if WarTriage.Settings.screenAlerts then
		-- TextLogAddEntry("Chat", 0, L"--- <icon57> Screen Alerts")
	-- else
		-- TextLogAddEntry("Chat", 0, L"--- <icon58> Screen Alerts")
	-- end

	if WarTriage.Settings.glowEffects then
		TextLogAddEntry("Chat", 0, L"--- <icon57> Glow Effects")
	else
		TextLogAddEntry("Chat", 0, L"--- <icon58> Glow Effects")
	end
end

function WarTriage.GetFriendlyTarget()
	TargetInfo:UpdateFromClient()
	local target = TargetInfo.m_Units[TargetInfo.FRIENDLY_TARGET]
	if target and not target.isNPC and target.name ~= L"" then
		return fixString(target.name)
	elseif target and target.entityid == 0 then -- Treat no target as self target
		return fixString(LOCAL_PLAYER_NAME)
	else
		return L""
	end
end

-- Event handlers
-- function WarTriage.LOADING_END()
	-- -- WarTriage.CheckCareer()
-- end

-- Updates all players, called from registered events
-- function WarTriage.UpdatePlayers()
	-- if WarTriage.Settings.enabled and WarTriage.Settings.isHealer then
		-- WarTriage.Players = WarTriage.GetFriendlyPlayers()
	-- end
-- end

-- Creates or updates the WarTriage Macro
function WarTriage.UpdateMacro(macroName, macroText, macroIcon)
	local macros = GetMacrosData()
	local macroSlot = nil
	
	-- Check for existing macro or free macro slot
	for i = 1, #macros do
		-- Macro exists?
		if macros[i].name == towstring(macroName) then
			macroSlot = i
			break
		-- Find first free slot
		elseif macros[i].iconNum == 0 and macroSlot == nil then
			macroSlot = i
		end
	end

	-- Update Macro
	if macroSlot ~= nil then 
		SetMacroData(towstring(macroName), towstring(macroText), macroIcon, macroSlot)
		WarTriage.Settings.macroCreated = true
		WTDebug("UpdateMacro success in slot " .. tostring(macroSlot))
		WarTriage.InvalidateMacroCache()
		return true
	else
		WarTriage.Settings.macroCreated = false
		WTDebug("UpdateMacro failed: no free slot")
		return false
	end
end

-- Get all players in party, warband or scenario
function WarTriage.GetFriendlyPlayers()
	local data = {}
	local players = {}
	
	-- Get self
	WarTriage.Player.name = fixString(LOCAL_PLAYER_NAME)
	WarTriage.Player.health = mathFloor(100 * GameData.Player.hitPoints.current / GameData.Player.hitPoints.maximum)
	WarTriage.Player.archeType = ArcheType[GameData.Player.career.line]
	WarTriage.Player.inMyParty = true

	local ownPartyOnly = WarTriage.Settings.ownPartyOnly

	-- In Scenario (includes self)
	if GameData.Player.isInScenario or GameData.Player.isInSiege then
		data = GameData.GetScenarioPlayerGroups()
		for _, player_data in ipairs (data) do
			local playerName = fixString(player_data.name)
			players[#players + 1] = {}
			players[#players].name = playerName
			players[#players].health = player_data.health
			players[#players].archeType = ArcheType[CareerIDsToLines[player_data.careerId]]
			players[#players].inMyParty = (not ownPartyOnly) or GroupWindow.IsPlayerInGroup(playerName)
			
		end
	-- In Warband (includes self)
	elseif IsWarBandActive() then
		data = PartyUtils.GetWarbandData()
		for group_index, group_data in ipairs (data) do
			for player_index, player_data in ipairs (group_data.players) do
				local playerName = fixString(player_data.name)
				players[#players + 1] = {}
				players[#players].name = playerName
				players[#players].health = player_data.healthPercent
				players[#players].archeType = ArcheType[player_data.careerLine]
				players[#players].inMyParty = (not ownPartyOnly) or GroupWindow.IsPlayerInGroup(playerName)
			end
		end
	-- Solo or in a group
	else
		players[#players + 1] = WarTriage.Player -- add self
		data = PartyUtils.GetPartyData()
		for player_index, player_data in ipairs (data) do
			if player_data.name ~= L"" then
				local playerName = fixString(player_data.name)
				players[#players + 1] = {}
				players[#players].name = playerName
				players[#players].health = player_data.healthPercent
				players[#players].archeType = ArcheType[player_data.careerLine]
				players[#players].inMyParty = true
			end
		end
	end

	-- Set distance
	players = WarTriage.SetPlayersDistance(players)
	
	-- Set LOS
	players = WarTriage.SetPlayersLOS(players)
	
	return players
end

-- Set the distance so we don't target a player that is out of range
function WarTriage.SetPlayersDistance(players)
	local defaultDistance = 999999
	local players = players

	if not WarTriage.Settings.rangeCheck then
		for i = 1, #players do
			players[i].distance = 0
		end
		return players
	end

	local playerDistances = {}
	
	-- build table of player distances
	for i = 1, MAX_MAP_POINTS do
		local mpd = GetMapPointData("EA_Window_OverheadMapMapDisplay", i)
		if (not mpd or not MapPointTypeFilter[mpd.pointType] or not mpd.name) then continue end
		playerDistances[fixString(mpd.name)] = mathFloor(mpd.distance * DISTANCE_FIX_COEFFICIENT)
	end
	
	-- look up and set distances
	for i = 1, #players do
		players[i].distance = playerDistances[players[i].name] or defaultDistance
	end

	return players	
end

-- Limited LOS check.
-- If a targeted player is out of LOS it will not be selected on the next macro click (but maybe on the click after)
function WarTriage.SetPlayersLOS(players)
	local players = players

	if not WarTriage.Settings.losCheck then
		for i = 1, #players do
			players[i].hasLOS = true
		end
		return players
	end

	local checkAbilityID = LosCheckAbiliyId[GameData.Player.career.line]

	local target = WarTriage.PlayerTarget
	
	if target == L"" then
		target = WarTriage.Player.name -- no friendly target, target is self.
	end
	
	for i = 1, #players do
		if target == players[i].name then
			if players[i].health > 0 then
				-- check LOS for heal ability
				players[i].hasLOS = IsTargetValid(checkAbilityID.healID)
				--players[i].hasLOS = IsAbilityEnabled(checkAbilityID.healID) and IsTargetValid(checkAbilityID.healID)
			else
				-- check LOS for ress ability instead
				--players[i].hasLOS = IsTargetValid(checkAbilityID.ressID)
				players[i].hasLOS = IsAbilityEnabled(checkAbilityID.ressID) and IsTargetValid(checkAbilityID.ressID)
			end
		else
			players[i].hasLOS = true -- assume we have LOS until we target the player and know for certain.
		end
	end
	return players
end

local function IsBetterCandidate(candidate, current)
	if current.name == L"" then
		return true
	elseif candidate.health < current.health then
		return true
	elseif candidate.health == current.health and candidate.distance < current.distance then
		return true
	end
	return false
end

-- Main function to select which player will be targeted when clicking the macro
function WarTriage.GetHurtPlayer()
	local players = WarTriage.Players
	local hurtPlayer = {
		name = L"",
		health = 100,
		distance = 999999,
		inMyParty = false
	}

	local foundHealer = false
	local foundDPS = false
	local foundTank = false
	local canRess = not WarTriage.Settings.ignoreDead
		and GameData.Player.level >= 10
		and not hasBuff(GameData.BuffTargetType.SELF, 5968)
	
	for i = 1, #players do
		
		if WarTriage.Settings.ownPartyOnly and not players[i].inMyParty then
			continue
		end
		
		-- Check Self
		if WarTriage.Player.health < WarTriage.Settings.selfTargetPct
		then
			hurtPlayer = WarTriage.Player
			break
		
		-- Check prio healer
		elseif players[i].archeType == HEALER									-- Healer found
		and players[i].name ~= WarTriage.Player.name							-- Exclude self from this check
		and players[i].hasLOS													-- in LOS
		and players[i].distance < MAX_HEAL_DISTANCE								-- in range
		and players[i].health < WarTriage.Settings.healerTargetPct				-- and is hurt
		and players[i].health > 0												-- but not dead
		and IsBetterCandidate(players[i], hurtPlayer)							-- and more hurt than previous target
		then
			foundHealer = true
			hurtPlayer = players[i]
		
		-- Check prio DPS
		elseif players[i].archeType == DPS										-- DPS found
		and not foundHealer														-- skip if found hurt healer
		and players[i].hasLOS													-- in LOS
		and players[i].distance < MAX_HEAL_DISTANCE								-- in range
		and players[i].health < WarTriage.Settings.dpsTargetPct					-- and is hurt
		and players[i].health > 0												-- but not dead
		and IsBetterCandidate(players[i], hurtPlayer)							-- and more hurt than previous target
		then
			foundDPS = true
			hurtPlayer = players[i]

		-- Check prio Tank
		elseif players[i].archeType == TANK										-- Tank found
		and not foundHealer														-- skip if found hurt healer
		and not foundDPS														-- skip if found hurt DPS
		and players[i].hasLOS													-- in LOS
		and players[i].distance < MAX_HEAL_DISTANCE								-- in range
		and players[i].health < WarTriage.Settings.tankTargetPct				-- and is hurt
		and players[i].health > 0												-- but not dead
		and IsBetterCandidate(players[i], hurtPlayer)							-- and more hurt than previous target
		then
			foundTank = true
			hurtPlayer = players[i]
		
		-- Check dead
		elseif canRess
		and not foundHealer
		and not foundDPS
		and not foundTank
		and players[i].hasLOS										-- in LOS
		and players[i].distance < MAX_RESS_DISTANCE					-- in range
		and players[i].health == 0									-- is dead
		and players[i].distance < hurtPlayer.distance
		then
			hurtPlayer = players[i]
			
		-- Check others
		elseif not foundHealer
		and not foundDPS
		and not foundTank
		and players[i].hasLOS										-- in LOS
		and players[i].distance < MAX_HEAL_DISTANCE					-- in range
		and players[i].health < WarTriage.Settings.playerTargetPct	-- and is hurt
		and players[i].health > 0									-- but not dead
		and players[i].health < hurtPlayer.health					-- and more hurt than previous target
		then
			hurtPlayer = players[i]
		end
	end
	
	return hurtPlayer
end

function WarTriage.TargetPlayer(player)
	if player.name ~= L"" -- we have a hurt player
	and player.name ~= WarTriage.PlayerTarget -- and it's not already targeted
	then
		WarTriage.SetMacroTarget(WARTRIAGE_MACRO_NAME, player.name, 4 - mathFloor(player.health / 25))
		
		-- if (player.name == WarTriage.Player.name and player.health < WarTriage.Settings.selfTargetPct)
		-- or (player.archeType == HEALER and player.health < WarTriage.Settings.healerTargetPct)
		-- or (player.archeType == DPS and player.health < WarTriage.Settings.dpsTargetPct)
		-- or (player.archeType == TANK and player.health < WarTriage.Settings.tankTargetPct)
		-- then
			-- if alertPlayer ~= player.name and player.health > 0 then
				-- alertPlayer = player.name
				-- WarTriage.AlertText(player.name .. L" needs heals: " .. towstring(player.health) .. L"%")
			-- elseif alertPlayer ~= player.name and player.health == 0 then
				-- alertPlayer = player.name
				-- WarTriage.AlertText(player.name .. L" needs rezz!")
			-- end
		-- end
	else
		WarTriage.SetMacroTarget(WARTRIAGE_MACRO_NAME, L"", 0)
		--alertPlayer = L""
	end
end

-- Macro functions to actually make clicking the macro target a player
function WarTriage.GetMacroSlots(macroId)
	local macroSlots = {}
	for i = 1, #ActionBars.m_Bars do
	   for j = 1, #ActionBars.m_Bars[i].m_Buttons do
		  if ActionBars.m_Bars[i].m_Buttons[j].m_ActionType == 4 then
			 if ActionBars.m_Bars[i].m_Buttons[j].m_ActionId == macroId then
				macroSlots[#macroSlots + 1] = ActionBars.m_Bars[i].m_Buttons[j].m_HotBarSlot
			 end
		  end
	   end
	end
	return macroSlots
end

function WarTriage.GetMacroId(macroName)
	local macros = GetMacrosData()
	macroName = towstring(macroName)
	for i = 1, #macros do
		if macros[i].name == macroName then
			return i
		end
	end
	return nil
end

function WarTriage.SetMacroTarget(macroName, playerName, glowLevel, force)
	WarTriage.DesiredMacroTarget = playerName
	WarTriage.DesiredGlowLevel = glowLevel

	if (not force) and WarTriage.LastMacroTarget == playerName and WarTriage.LastGlowLevel == glowLevel and WarTriage.MacroSlots and #WarTriage.MacroSlots > 0 then
		return
	end

	if not WarTriage.MacroId then
		WarTriage.MacroId = WarTriage.GetMacroId(macroName)
		WTDebug("Resolved MacroId=" .. debugToString(WarTriage.MacroId))
	end
	if not WarTriage.MacroId then
		WTDebug("SetMacroTarget aborted: MacroId not found")
		WarTriage.RequestMacroRebind("SetMacroTarget missing macro id")
		return
	end

	if not WarTriage.MacroSlots or #WarTriage.MacroSlots == 0 then
		WarTriage.MacroSlots = WarTriage.GetMacroSlots(WarTriage.MacroId)
		WTDebug("Resolved MacroSlots count=" .. debugToString(WarTriage.MacroSlots and #WarTriage.MacroSlots or 0))
	end

	local macroSlots = WarTriage.MacroSlots or {}
	if #macroSlots == 0 then
		WTDebug("SetMacroTarget aborted: macro is not placed on any visible action slot")
		WarTriage.RequestMacroRebind("SetMacroTarget no visible slots")
		return
	end

	for i = 1, #macroSlots do
		local hbar, buttonid = ActionBars:BarAndButtonIdFromSlot(macroSlots[i])
		if hbar and buttonid then
			local macroButton = hbar.m_Buttons[buttonid]
			if macroButton then
				WarTriage.SetButtonGlow(macroButton, glowLevel)
				WindowSetGameActionData(macroButton.m_Name.."Action", GameData.PlayerActions.SET_TARGET, 0, towstring(playerName))
			end
		end
	end

	WTDebug("SetMacroTarget player=" .. debugToString(playerName) .. ", glow=" .. debugToString(glowLevel) .. ", slots=" .. debugToString(#macroSlots))
	WarTriage.LastMacroTarget = playerName
	WarTriage.LastGlowLevel = glowLevel
end

-- function WarTriage.AlertText(text)
	-- if WarTriage.Settings.screenAlerts then
		-- AlertTextWindow.AddLine(12 , towstring(text))
	-- end
-- end

function WarTriage.SetButtonGlow(button, glowLevel)
	if not WarTriage.Settings.glowEffects or glowLevel == 0 then
		button.m_Windows[6]:StopAnimation (true)
	elseif WarTriage.Settings.glowEffects and glowLevel > 0 and glowLevel < 5 then
		button.m_Windows[6]:StopAnimation (true)
		button.m_Windows[6]:SetAnimationTexture ("anim_fury_" .. glowLevel)
		button.m_Windows[6]:StartAnimation (0, true, false, 0)
	end
end
