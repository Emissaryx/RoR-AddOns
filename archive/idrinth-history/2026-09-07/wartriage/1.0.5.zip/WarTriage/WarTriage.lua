----------------------------------------------------------------
-- WarTriage.lua 
----------------------------------------------------------------

----------------------------------------------------------------
-- Local variables 
----------------------------------------------------------------

local VERSION = 1.05
local WARTRIAGE_MACRO_NAME = "WarTriage"
local WARTRIAGE_MACRO_TEXT = "/wartriage"
local WARTRIAGE_MACRO_ICON = 20087
local LOCAL_PLAYER_NAME = GameData.Player.name
local MAX_HEAL_DISTANCE = 150
local MAX_RESS_DISTANCE = 100
local DISTANCE_FIX_COEFFICIENT = 1 / 1.06
local MAX_MAP_POINTS = 511
local TIME_DELAY = 0.5
local HEALER = L"HEALER"
local DPS = L"DPS"
local TANK = L"TANK"

-- Localized functions
local mathFloor = math.floor
local tableSort = table.sort

local timeLeft = TIME_DELAY
local eventsRegistered = false
local alertPlayer = L""

local MapPointTypeFilter = {
	[SystemData.MapPips.PLAYER] = true,
	[SystemData.MapPips.GROUP_MEMBER] = true,
	[SystemData.MapPips.WARBAND_MEMBER] = true,
	[SystemData.MapPips.DESTRUCTION_ARMY] = true,
	[SystemData.MapPips.ORDER_ARMY] = true
}

local ArcheType = {
	[GameData.CareerLine.ZEALOT] 			= HEALER,
	[GameData.CareerLine.ARCHMAGE] 			= HEALER,
	[GameData.CareerLine.SHAMAN] 			= HEALER,
	[GameData.CareerLine.RUNE_PRIEST] 		= HEALER,
	[GameData.CareerLine.WARRIOR_PRIEST] 	= HEALER,
	[GameData.CareerLine.DISCIPLE] 			= HEALER,
	[GameData.CareerLine.ENGINEER] 			= DPS,
	[GameData.CareerLine.SLAYER] 			= DPS,
	[GameData.CareerLine.MARAUDER] 			= DPS,
	[GameData.CareerLine.SHADOW_WARRIOR] 	= DPS,
	[GameData.CareerLine.CHOPPA] 			= DPS,
	[GameData.CareerLine.SQUIG_HERDER] 		= DPS,
	[GameData.CareerLine.WHITE_LION] 		= DPS,
	[GameData.CareerLine.WITCH_ELF] 		= DPS,
	[GameData.CareerLine.SORCERER] 			= DPS,
	[GameData.CareerLine.WITCH_HUNTER] 		= DPS,
	[GameData.CareerLine.MAGUS] 			= DPS,
	[GameData.CareerLine.BRIGHT_WIZARD] 	= DPS,
	[GameData.CareerLine.IRON_BREAKER] 		= TANK,
	[GameData.CareerLine.KNIGHT] 			= TANK,
	[GameData.CareerLine.SWORDMASTER] 		= TANK,
	[GameData.CareerLine.BLACKGUARD] 		= TANK,
	[GameData.CareerLine.CHOSEN] 			= TANK,
	[GameData.CareerLine.BLACK_ORC] 		= TANK,
}
local CareerIDsToLines = {
	[20]	= GameData.CareerLine.IRON_BREAKER,
	[100]	= GameData.CareerLine.SWORDMASTER,
	[64]	= GameData.CareerLine.CHOSEN,
	[24]	= GameData.CareerLine.BLACK_ORC,
	[60]	= GameData.CareerLine.WITCH_HUNTER,
	[102]	= GameData.CareerLine.WHITE_LION,
	[65]	= GameData.CareerLine.MARAUDER,
	[105]	= GameData.CareerLine.WITCH_ELF,
	[62]	= GameData.CareerLine.BRIGHT_WIZARD,
	[67]	= GameData.CareerLine.MAGUS,
	[107]	= GameData.CareerLine.SORCERER,
	[23]	= GameData.CareerLine.ENGINEER,
	[101]	= GameData.CareerLine.SHADOW_WARRIOR,
	[27]	= GameData.CareerLine.SQUIG_HERDER,
	[63]	= GameData.CareerLine.WARRIOR_PRIEST,
	[106]	= GameData.CareerLine.DISCIPLE,
	[103]	= GameData.CareerLine.ARCHMAGE,
	[26]	= GameData.CareerLine.SHAMAN,
	[22]	= GameData.CareerLine.RUNE_PRIEST,
	[66]	= GameData.CareerLine.ZEALOT,
	[104]	= GameData.CareerLine.BLACKGUARD,
	[61]	= GameData.CareerLine.KNIGHT,
	[25]	= GameData.CareerLine.CHOPPA,
	[21]	= GameData.CareerLine.SLAYER,
}

local LosCheckAbiliyId = {
	-- Verify IDs!
	[GameData.CareerLine.SHAMAN]			= 1898, -- Gork'll Fix It
	[GameData.CareerLine.RUNE_PRIEST]		= 1587, -- Grungni's Gift
	[GameData.CareerLine.DISCIPLE]			= 9548, -- Restore Essence
	[GameData.CareerLine.ARCHMAGE]			= 9236, -- Healing Energy
	[GameData.CareerLine.WARRIOR_PRIEST]	= 8238, -- Divine Aid
	[GameData.CareerLine.ZEALOT]			= 8569, -- Flash Of Chaos
}

local function fixString (str)
	if (str == nil) then return nil end
	local str = str
	local pos = str:find (L"^", 1, true)
	if (pos) then str = str:sub (1, pos - 1) end
	return str
end

----------------------------------------------------------------
-- WarTriage
----------------------------------------------------------------
WarTriage = {}
WarTriage.Player = {}
WarTriage.Players = {}
WarTriage.PlayerTarget = L""

function WarTriage.Initialize()
	if not WarTriage.Settings
	or not WarTriage.Settings.version
	or WarTriage.Settings.version ~= VERSION
	then
		WarTriage.Settings = WarTriage.DefaultSettings
	end
	
	LibSlash.RegisterSlashCmd("wartriage", function(input) WarTriage_Config.Slash(input) end)
	LibSlash.RegisterSlashCmd("wt", function(input) WarTriage_Config.Slash(input) end)
	
	WarTriage.CheckCareer()

	if WarTriage.Settings.isHealer then
		if not WarTriage.UpdateMacro(WARTRIAGE_MACRO_NAME, WARTRIAGE_MACRO_TEXT, WARTRIAGE_MACRO_ICON) then
			TextLogAddEntry("Chat", 0, towstring("<icon20087> WarTriage failed to create macro!"))
		else
			TextLogAddEntry("Chat", 0, towstring("<icon20087> WarTriage macro created"))
		end
	end

	WarTriage.PrintSettings()
end

function WarTriage.OnShutdown()
	WarTriage.RegisterEventHandlers(false)
end

function WarTriage.RegisterEventHandlers(enabled)

	if not eventsRegistered and enabled then
		RegisterEventHandler(SystemData.Events.LOADING_END, "WarTriage.LOADING_END")
		RegisterEventHandler(SystemData.Events.PLAYER_TARGET_UPDATED, "WarTriage.PLAYER_TARGET_UPDATED")
		RegisterEventHandler(SystemData.Events.PLAYER_CUR_HIT_POINTS_UPDATED, "WarTriage.PLAYER_CUR_HIT_POINTS_UPDATED")
		RegisterEventHandler(SystemData.Events.GROUP_UPDATED, "WarTriage.GROUP_UPDATED")									-- Called continously when in Party
		RegisterEventHandler(SystemData.Events.GROUP_STATUS_UPDATED, "WarTriage.GROUP_STATUS_UPDATED")						-- Called on party HP changes
		RegisterEventHandler(SystemData.Events.SCENARIO_GROUP_UPDATED, "WarTriage.SCENARIO_GROUP_UPDATED")					-- Called on Scenario Group changes
		RegisterEventHandler(SystemData.Events.SCENARIO_PLAYER_HITS_UPDATED, "WarTriage.SCENARIO_PLAYER_HITS_UPDATED")		-- Called on Scenario HP changes
		RegisterEventHandler(SystemData.Events.BATTLEGROUP_UPDATED, "WarTriage.BATTLEGROUP_UPDATED")						-- Called continously when in Warband
		RegisterEventHandler(SystemData.Events.BATTLEGROUP_MEMBER_UPDATED, "WarTriage.BATTLEGROUP_MEMBER_UPDATED")			-- Called on on Warband HP changes
		eventsRegistered = true
		d("Events registered")
	elseif eventsRegistered and not enabled then
		UnregisterEventHandler(SystemData.Events.LOADING_END, "WarTriage.LOADING_END")
		UnregisterEventHandler(SystemData.Events.PLAYER_TARGET_UPDATED, "WarTriage.PLAYER_TARGET_UPDATED")
		UnregisterEventHandler(SystemData.Events.PLAYER_CUR_HIT_POINTS_UPDATED, "WarTriage.PLAYER_CUR_HIT_POINTS_UPDATED")
		UnregisterEventHandler(SystemData.Events.GROUP_UPDATED, "WarTriage.GROUP_UPDATED")
		UnregisterEventHandler(SystemData.Events.GROUP_STATUS_UPDATED, "WarTriage.GROUP_STATUS_UPDATED")
		UnregisterEventHandler(SystemData.Events.SCENARIO_GROUP_UPDATED, "WarTriage.SCENARIO_GROUP_UPDATED")
		UnregisterEventHandler(SystemData.Events.SCENARIO_PLAYER_HITS_UPDATED, "WarTriage.SCENARIO_PLAYER_HITS_UPDATED")
		UnregisterEventHandler(SystemData.Events.BATTLEGROUP_UPDATED, "WarTriage.BATTLEGROUP_UPDATED")
		UnregisterEventHandler(SystemData.Events.BATTLEGROUP_MEMBER_UPDATED, "WarTriage.BATTLEGROUP_MEMBER_UPDATED")
		UnregisterEventHandler(SystemData.Events.LOADING_END, "WarTriage.CheckCareer")
		eventsRegistered = false
		d("Events unregistered")
	end
end

WarTriage.DefaultSettings = {
		version = VERSION,
		enabled = true,
		screenAlerts = false,
		ignoreDead = false,
		glowEffects = true,
		selfTargetPct = 75,
		healerTargetPct = 75,
		dpsTargetPct = 50,
		tankTargetPct = 25,
		playerTargetPct = 100,
		isHealer = false,
		macroCreated = false,
		losCheck = true
}

function WarTriage.OnUpdate(elapsed)
    timeLeft = timeLeft - elapsed
	if timeLeft > 0 then
        return
    end
    timeLeft = TIME_DELAY
	
    WarTriage.RegisterEventHandlers(WarTriage.Settings.enabled)

	if WarTriage.Settings.enabled and WarTriage.Settings.isHealer then
		WarTriage.TargetPlayer( WarTriage.GetHurtPlayer() )
	end
end

function WarTriage.CheckCareer()
	if ArcheType[ CareerIDsToLines[GameData.Player.career.id] ] == HEALER then
		WarTriage.Settings.isHealer = true
	else
		WarTriage.Settings.isHealer = false
	end
end

function WarTriage.PrintSettings()
	if WarTriage.Settings.isHealer then
		TextLogAddEntry("Chat", 0, towstring("<icon20087> WarTriage v" .. tostring(WarTriage.Settings.version) .. " settings: /wartriage"))
		if WarTriage.Settings.enabled then
			TextLogAddEntry("Chat", 0, L"--- <icon57> Enabled")
		else
			TextLogAddEntry("Chat", 0, L"--- <icon58> Enabled")
		end

		if WarTriage.Settings.losCheck then
			TextLogAddEntry("Chat", 0, L"--- <icon57> Check LOS")
		else
			TextLogAddEntry("Chat", 0, L"--- <icon58> Check LOS")
		end

		if WarTriage.Settings.ignoreDead then
			TextLogAddEntry("Chat", 0, L"--- <icon57> Ignore Dead")
		else
			TextLogAddEntry("Chat", 0, L"--- <icon58> Ignore Dead")
		end

		if WarTriage.Settings.screenAlerts then
			TextLogAddEntry("Chat", 0, L"--- <icon57> Screen Alerts")
		else
			TextLogAddEntry("Chat", 0, L"--- <icon58> Screen Alerts")
		end

		if WarTriage.Settings.glowEffects then
			TextLogAddEntry("Chat", 0, L"--- <icon57> Glow Effects")
		else
			TextLogAddEntry("Chat", 0, L"--- <icon58> Glow Effects")
		end
	end
end

function WarTriage.GetFriendlyTarget()
	TargetInfo:UpdateFromClient()
	local target = TargetInfo.m_Units[TargetInfo.FRIENDLY_TARGET]
	if target and not target.isNPC and target.name ~= L"" then
		return fixString(target.name)
	elseif target and target.entityid == 0 then -- Treat no target as self target
		return fixString(LOCAL_PLAYER_NAME)
	else
		return L""
	end
end

-- Event handlers
function WarTriage.LOADING_END()
	-- WarTriage.CheckCareer()
end

function WarTriage.PLAYER_TARGET_UPDATED()
	WarTriage.PlayerTarget = WarTriage.GetFriendlyTarget()
end

function WarTriage.PLAYER_CUR_HIT_POINTS_UPDATED()
	WarTriage.UpdatePlayers()
end

function WarTriage.PLAYER_TARGET_HIT_POINTS_UPDATED()
	WarTriage.UpdatePlayers()
end

function WarTriage.GROUP_UPDATED()
	WarTriage.UpdatePlayers()
end

function WarTriage.GROUP_STATUS_UPDATED()
	WarTriage.UpdatePlayers()
end

function WarTriage.SCENARIO_GROUP_UPDATED()
	WarTriage.UpdatePlayers()
end

function WarTriage.SCENARIO_PLAYER_HITS_UPDATED()
	WarTriage.UpdatePlayers()
end

function WarTriage.BATTLEGROUP_UPDATED()
	WarTriage.UpdatePlayers()
end

function WarTriage.BATTLEGROUP_MEMBER_UPDATED()
	WarTriage.UpdatePlayers()
end

-- Updates all players, called from registered events
function WarTriage.UpdatePlayers()
	WarTriage.Players = WarTriage.GetFriendlyPlayers()
end

-- Creates or updates the WarTriage Macro
function WarTriage.UpdateMacro(macroName, macroText, macroIcon)
	local macros = GetMacrosData()
	local macroSlot = nil
	
	-- Check for existing macro or free macro slot
	for i = 1, #macros do
		-- Macro exists?
		if macros[i].name == towstring(macroName) then
			macroSlot = i
			break
		-- Find first free slot
		elseif macros[i].iconNum == 0 and macroSlot == nil then
			macroSlot = i
		end
	end

	-- Update Macro
	if macroSlot ~= nil then 
		SetMacroData(towstring(macroName), towstring(macroText), macroIcon, macroSlot)
		WarTriage.Settings.macroCreated = true
		return true
	else
		WarTriage.Settings.macroCreated = false
		return false
	end
end

-- Get all players in party, warband or scenario
function WarTriage.GetFriendlyPlayers()
	local data = {}
	local players = {}
	
	-- Get self
	WarTriage.Player.name = fixString(LOCAL_PLAYER_NAME)
	WarTriage.Player.health = mathFloor(100 * GameData.Player.hitPoints.current / GameData.Player.hitPoints.maximum)
	WarTriage.Player.archeType = ArcheType[GameData.Player.career.line]

	-- In Scenario (includes self)
	if GameData.Player.isInScenario or GameData.Player.isInSiege then
		data = GameData.GetScenarioPlayerGroups()
		for _, player_data in ipairs (data) do
			players[#players + 1] = {}
			players[#players].name = fixString(player_data.name)
			players[#players].health = player_data.health
			players[#players].archeType = ArcheType[CareerIDsToLines[player_data.careerId]]
			
		end
	-- In Warband (includes self)
	elseif IsWarBandActive() then
		data = PartyUtils.GetWarbandData()
		for group_index, group_data in ipairs (data) do
			for player_index, player_data in ipairs (group_data.players) do
				players[#players + 1] = {}
				players[#players].name = fixString(player_data.name)
				players[#players].health = player_data.healthPercent
				players[#players].archeType = ArcheType[player_data.careerLine]
			end
		end
	-- Solo or in a group
	else
		players[#players + 1] = WarTriage.Player -- add self
		data = PartyUtils.GetPartyData()
		for player_index, player_data in ipairs (data) do
			if player_data.name ~= L"" then
				players[#players + 1] = {}
				players[#players].name = fixString(player_data.name)
				players[#players].health = player_data.healthPercent
				players[#players].archeType = ArcheType[player_data.careerLine]
			end
		end
	end

	-- Set distance
	players = WarTriage.SetPlayersDistance(players)
	
	-- Set LOS
	players = WarTriage.SetPlayersLOS(players)
	
	-- Sort players by health, distance
	local sortFunc = function (k1, k2)
		if k1.health < k2.health then
			return true
		elseif k1.health == k2.health
		and k1.distance < k2.distance
		then
			return true
		end
		return false
	end
	tableSort(players, sortFunc)

	return players
end

-- Set the distance so we don't target a player that is out of range
function WarTriage.SetPlayersDistance(players)
	local defaultDistance = 999999
	local players = players
	local playerDistances = {}
	
	-- build table of player distances
	for i = 1, MAX_MAP_POINTS do
		local mpd = GetMapPointData("EA_Window_OverheadMapMapDisplay", i)
		if (not mpd or not MapPointTypeFilter[mpd.pointType] or not mpd.name) then continue end
		playerDistances[fixString(mpd.name)] = mathFloor(mpd.distance * DISTANCE_FIX_COEFFICIENT)
	end
	
	-- look up and set distances
	for i = 1, #players do
		players[i].distance = playerDistances[players[i].name] or defaultDistance
	end

	return players	
end

-- Limited LOS check.
-- If a targeted player is out of LOS it will not be selected on the next macro click (but maybe on the click after)
function WarTriage.SetPlayersLOS(players)
	local players = players
	local checkAbilityID = LosCheckAbiliyId[GameData.Player.career.line]

	local target = WarTriage.PlayerTarget
	
	if target == L"" then
		target = WarTriage.Player.name -- no friendly target, target is self.
	end
	
	for i = 1, #players do
		if target == players[i].name and WarTriage.Settings.losCheck then
			players[i].hasLOS = IsTargetValid(checkAbilityID)
		else
			players[i].hasLOS = true -- assume we have LOS until we target the player and know for certain.
		end
	end
	return players
end

-- Main function to select which player will be targeted when clicking the macro
-- Called OnUpdate
function WarTriage.GetHurtPlayer()
	local players = WarTriage.Players
	local hurtPlayer = {
		name = L"",
		health = 100,
		distance = 999999
	}
	local foundHealer = false
	local foundDPS = false
	local foundTank = false
	
	for i = 1, #players do
		
		-- Check Self
		if WarTriage.Player.health < WarTriage.Settings.selfTargetPct
		then
			--d("Self hurt")
			hurtPlayer = WarTriage.Player
			break
		
		-- Check prio healer
		elseif players[i].archeType == HEALER						-- Healer found
		and players[i].name ~= WarTriage.Player.name				-- Exclude self from this check
		and players[i].hasLOS										-- in LOS
		and players[i].distance < MAX_HEAL_DISTANCE					-- in range
		and players[i].health < WarTriage.Settings.healerTargetPct	-- and is hurt
		and players[i].health > 0									-- but not dead
		and players[i].health < hurtPlayer.health					-- and more hurt than previous target

		then
			--d("Healer hurt")
			foundHealer = true
			hurtPlayer = players[i]
		
		-- Check prio DPS
		elseif players[i].archeType == DPS							-- DPS found
		and not foundHealer											-- skip if found hurt healer
		and players[i].hasLOS										-- in LOS
		and players[i].distance < MAX_HEAL_DISTANCE					-- in range
		and players[i].health < WarTriage.Settings.dpsTargetPct		-- and is hurt
		and players[i].health > 0									-- but not dead
		and players[i].health < hurtPlayer.health					-- and more hurt than previous target
		then
			--d("DPS hurt")
			foundDPS = true
			hurtPlayer = players[i]

		-- Check prio Tank
		elseif players[i].archeType == TANK							-- Tank found
		and not foundHealer											-- skip if found hurt healer
		and not foundDPS											-- skip if found hurt DPS
		and players[i].hasLOS										-- in LOS
		and players[i].distance < MAX_HEAL_DISTANCE					-- in range
		and players[i].health < WarTriage.Settings.tankTargetPct	-- and is hurt
		and players[i].health > 0									-- but not dead
		and players[i].health < hurtPlayer.health					-- and more hurt than previous target
		then
			--d("Tank hurt")
			foundTank = true
			hurtPlayer = players[i]
		
		-- Check dead
		elseif not WarTriage.Settings.ignoreDead
		and not foundHealer
		and not foundDPS
		and not foundTank
		and players[i].hasLOS										-- in LOS
		and players[i].distance < MAX_RESS_DISTANCE					-- in range
		and players[i].health == 0									-- but not dead
		and players[i].distance < hurtPlayer.distance
		then
			--d("Player dead")
			hurtPlayer = players[i]
			
		-- Check others
		elseif not foundHealer
		and not foundDPS
		and not foundTank
		and players[i].hasLOS										-- in LOS
		and players[i].distance < MAX_HEAL_DISTANCE					-- in range
		and players[i].health < WarTriage.Settings.playerTargetPct	-- and is hurt
		and players[i].health > 0									-- but not dead
		and players[i].health < hurtPlayer.health					-- and more hurt than previous target
		then
			--d("Player hurt")
			hurtPlayer = players[i]
		end
		
	end
	
	return hurtPlayer
end

function WarTriage.TargetPlayer(player)
	if not WarTriage.Settings.enabled then return end
	
	if player.name ~= L"" -- we have a hurt player
	and player.name ~= WarTriage.PlayerTarget -- and it's not already targeted
	then
		WarTriage.SetMacroTarget(WARTRIAGE_MACRO_NAME, player.name, 4 - mathFloor(player.health / 25))
		
		if (player.name == WarTriage.Player.name and player.health < WarTriage.Settings.selfTargetPct)
		or (player.archeType == HEALER and player.health < WarTriage.Settings.healerTargetPct)
		or (player.archeType == DPS and player.health < WarTriage.Settings.dpsTargetPct)
		or (player.archeType == TANK and player.health < WarTriage.Settings.tankTargetPct)
		then
			if alertPlayer ~= player.name and player.health > 0 then
				alertPlayer = player.name
				WarTriage.AlertText(player.name .. L" needs heals: " .. towstring(player.health) .. L"%")
			elseif alertPlayer ~= player.name and player.health == 0 then
				alertPlayer = player.name
				WarTriage.AlertText(player.name .. L" needs rezz!")
			end
		end
	else
		WarTriage.SetMacroTarget(WARTRIAGE_MACRO_NAME, L"", 0)
		alertPlayer = L""
	end
end

-- Macro functions to actually make clicking the macro target a player
function WarTriage.GetMacroSlots(macroId)
	local macroSlots = {}
	for i = 1, #ActionBars.m_Bars do
	   for j = 1, #ActionBars.m_Bars[i].m_Buttons do
		  if ActionBars.m_Bars[i].m_Buttons[j].m_ActionType == 4 then
			 if ActionBars.m_Bars[i].m_Buttons[j].m_ActionId == macroId then
				macroSlots[#macroSlots + 1] = ActionBars.m_Bars[i].m_Buttons[j].m_HotBarSlot
			 end
		  end
	   end
	end
	return macroSlots
end

function WarTriage.GetMacroId(macroName)
	local macros = GetMacrosData()
	macroName = towstring(macroName)
	for i = 1, #macros do
		if macros[i].name == macroName then
			return i
		end
	end
	return nil
end

function WarTriage.SetMacroTarget(macroName, playerName, glowLevel)
	local macroSlots = WarTriage.GetMacroSlots( WarTriage.GetMacroId(macroName) )
	if #macroSlots == 0 then return end
	for i = 1, #macroSlots do
		local hbar, buttonid = ActionBars:BarAndButtonIdFromSlot(macroSlots[i])
		local macroButton = hbar.m_Buttons[buttonid]
		
		WarTriage.SetButtonGlow(macroButton, glowLevel)
		WindowSetGameActionData(macroButton.m_Name.."Action", GameData.PlayerActions.SET_TARGET, 0, towstring(playerName))
	end
end

function WarTriage.AlertText(text)
	if WarTriage.Settings.screenAlerts then
		AlertTextWindow.AddLine(12 , towstring(text))
	end
end

function WarTriage.SetButtonGlow(button, glowLevel)
	if not WarTriage.Settings.glowEffects or glowLevel == 0 then
		button.m_Windows[6]:StopAnimation (true)
	elseif WarTriage.Settings.glowEffects and glowLevel > 0 and glowLevel < 5 then
		button.m_Windows[6]:StopAnimation (true)
		button.m_Windows[6]:SetAnimationTexture ("anim_fury_" .. glowLevel)
		button.m_Windows[6]:StartAnimation (0, true, false, 0)
	end
end
