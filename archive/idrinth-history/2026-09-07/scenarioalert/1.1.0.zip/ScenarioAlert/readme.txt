1) Install ScenarioAlert addon
2) place contents of folder Sirena to Warhammer Online - Age of Reckoning/logs
3) run game, make sure addon is enabled
4) run sirena.exe