GuildRosterFix = {};

local VERSION = "1.0.2";
local RETRY_INTERVAL = 2.0;
local MAX_RETRY_SECONDS = 60;

local retryTimer = 0;
local retryElapsed = 0;
local pendingRefresh = true;
local registeredEvents = {};
local hooksInstalled = false;

local function DebugPrint(text)
    if (type(d) == "function") then
        pcall(d, tostring(text));
    end
end

local function ChatPrint(text)
    local message = tostring(text);

    DebugPrint(message);

    if (not EA_ChatWindow or not ChatSettings or not SystemData) then return end
    EA_ChatWindow.Print(
        towstring(message),
        ChatSettings.Channels[SystemData.ChatLogFilters.SAY].id
    );
end

local function PrintChunks(prefix, text)
    local line = tostring(prefix) .. tostring(text);
    local maxLength = 180;

    while (string.len(line) > maxLength) do
        ChatPrint(string.sub(line, 1, maxLength));
        line = "  " .. string.sub(line, maxLength + 1);
    end

    ChatPrint(line);
end

local function RegisterEvent(eventId, handlerName)
    if (eventId) then
        RegisterEventHandler(eventId, handlerName);
        table.insert(registeredEvents, { eventId = eventId, handlerName = handlerName });
    end
end

local function GetGuildData()
    if (not GetGuildMemberData) then return nil, 0 end

    local ok, members = pcall(GetGuildMemberData);
    if (not ok or type(members) ~= "table") then return nil, 0 end

    return members, #members;
end

local function ReadNumber(value)
    local numberValue = tonumber(value);
    if (numberValue) then return numberValue end
    return 0;
end

local function GetMemberName(member)
    if (not member) then return "?" end
    return member.name
        or member.Name
        or member.m_name
        or member.memberName
        or member.m_memberName
        or "?";
end

local function GetMemberZone(member)
    if (not member) then return 0 end
    return ReadNumber(
        member.zoneID
        or member.zoneId
        or member.ZoneID
        or member.zone
        or member.Zone
        or member.m_zoneID
        or member.m_zoneId
        or 0
    );
end

local function HasOnlineFlag(member)
    if (not member) then return false end

    return member.online == true
        or member.isOnline == true
        or member.Online == true
        or member.IsOnline == true
        or member.m_online == true
        or member.m_isOnline == true;
end

local function IsMemberOnline(member)
    if (HasOnlineFlag(member)) then return true end
    return GetMemberZone(member) ~= 0;
end

local function CallIfExists(owner, methodName)
    if (owner and type(owner[methodName]) == "function") then
        return pcall(owner[methodName]);
    end
    return false;
end

local function NudgeRosterFunctions()
    local called = false;
    local roster = GuildWindowTabRoster;

    local methodNames =
    {
        "OnRosterInit",
        "UpdateMemberList",
        "UpdateMemberWindow",
        "UpdateSortButtons",
        "UpdatePermissions",
        "RefreshRosterList",
        "UpdateRosterList",
        "PopulateRosterList",
        "RefreshRoster",
        "UpdateRoster",
        "PopulateRoster",
        "RefreshList",
        "UpdateList",
        "PopulateList",
        "RefreshDisplay",
        "UpdateDisplay",
        "Refresh",
        "Update",
        "OnShown",
        "OnShow",
    };

    for _, methodName in ipairs(methodNames) do
        local ok = CallIfExists(roster, methodName);
        if (ok) then
            called = true;
        end
    end

    if (GuildWindow and type(GuildWindow.Update) == "function") then
        local ok = pcall(GuildWindow.Update);
        if (ok) then
            called = true;
        end
    end

    if (GuildWindow and type(GuildWindow.UpdatePlayerCache) == "function") then
        local ok = pcall(GuildWindow.UpdatePlayerCache);
        if (ok) then
            called = true;
        end
    end

    return called;
end

local function HookFunction(owner, methodName)
    if (type(owner) ~= "table" or type(owner[methodName]) ~= "function") then
        return false;
    end

    local hookFlag = "__GuildRosterFixHooked_" .. methodName;
    if (owner[hookFlag]) then
        return false;
    end

    local original = owner[methodName];
    owner[methodName] = function(...)
        local results = { original(...) };
        GuildRosterFix.ScheduleRefresh();
        return unpack(results);
    end

    owner[hookFlag] = true;
    return true;
end

local function InstallHooks()
    local installed = false;

    installed = HookFunction(GuildWindow, "OnShown") or installed;
    installed = HookFunction(GuildWindow, "OnLButtonUpTab") or installed;
    installed = HookFunction(GuildWindow, "SetTab") or installed;
    installed = HookFunction(GuildWindowTabRoster, "OnShown") or installed;
    installed = HookFunction(GuildWindowTabRoster, "OnRosterInit") or installed;

    if (installed) then
        hooksInstalled = true;
    end

    return installed;
end

local function CollectFunctionNames(owner)
    local names = {};

    if (type(owner) ~= "table") then
        return "(not a table)";
    end

    for key, value in pairs(owner) do
        if (type(value) == "function") then
            table.insert(names, tostring(key));
        end
    end

    table.sort(names);

    if (#names == 0) then
        return "(none)";
    end

    return table.concat(names, ", ");
end

function GuildRosterFix.Status()
    local members, count = GetGuildData();
    local onlineCount = 0;
    local onlineSamples = {};
    local firstSamples = {};

    for idx = 1, count do
        local member = members[idx];
        local name = tostring(GetMemberName(member));
        local zone = GetMemberZone(member);
        local flag = HasOnlineFlag(member);

        if (#firstSamples < 5) then
            table.insert(firstSamples, name .. ":z" .. tostring(zone) .. ":f" .. tostring(flag));
        end

        if (IsMemberOnline(member)) then
            onlineCount = onlineCount + 1;
            if (#onlineSamples < 10) then
                table.insert(onlineSamples, name .. ":z" .. tostring(zone));
            end
        end
    end

    ChatPrint("GuildRosterFix status: total=" .. tostring(count) .. ", online=" .. tostring(onlineCount) .. ", version=" .. VERSION .. ".");
    PrintChunks("GuildRosterFix online: ", table.concat(onlineSamples, ", "));
    PrintChunks("GuildRosterFix first: ", table.concat(firstSamples, ", "));

    return onlineCount, count;
end

function GuildRosterFix.Inspect()
    PrintChunks("GuildRosterFix GuildWindowTabRoster funcs: ", CollectFunctionNames(GuildWindowTabRoster));
    PrintChunks("GuildRosterFix GuildWindow funcs: ", CollectFunctionNames(GuildWindow));
end

function GuildRosterFix.Refresh(verbose)
    local members, count = GetGuildData();
    if (count <= 1) then
        if (verbose) then
            ChatPrint("GuildRosterFix: waiting for guild data, count=" .. tostring(count) .. ".");
        end
        return false;
    end

    InstallHooks();

    local calledRoster = NudgeRosterFunctions();

    if (verbose) then
        local onlineCount = 0;
        for idx = 1, count do
            if (IsMemberOnline(members[idx])) then
                onlineCount = onlineCount + 1;
            end
        end
        ChatPrint("GuildRosterFix: guild count=" .. tostring(count) .. ", online=" .. tostring(onlineCount) .. ", rosterCalls=" .. tostring(calledRoster) .. ".");
    end

    return calledRoster;
end

function GuildRosterFix.ScheduleRefresh()
    pendingRefresh = true;
    retryTimer = 0.25;
    retryElapsed = 0;
end

function GuildRosterFix.Initialize()
    RegisterEvent(SystemData.Events.GUILD_REFRESH, "GuildRosterFix.ScheduleRefresh");
    RegisterEvent(SystemData.Events.GUILD_INFO_UPDATED, "GuildRosterFix.ScheduleRefresh");
    RegisterEvent(SystemData.Events.GUILD_ROSTER_INIT, "GuildRosterFix.ScheduleRefresh");
    RegisterEvent(SystemData.Events.GUILD_MEMBER_UPDATED, "GuildRosterFix.ScheduleRefresh");
    RegisterEvent(SystemData.Events.GUILD_MEMBER_ADDED, "GuildRosterFix.ScheduleRefresh");
    RegisterEvent(SystemData.Events.GUILD_MEMBER_REMOVED, "GuildRosterFix.ScheduleRefresh");

    InstallHooks();
    GuildRosterFix.ScheduleRefresh();
end

function GuildRosterFix.Shutdown()
    for _, ev in ipairs(registeredEvents) do
        UnregisterEventHandler(ev.eventId, ev.handlerName);
    end
    registeredEvents = {};
end

function GuildRosterFix.OnUpdate(elapsed)
    if (not pendingRefresh) then return end

    if (not hooksInstalled) then
        InstallHooks();
    end

    retryTimer = retryTimer - elapsed;
    retryElapsed = retryElapsed + elapsed;

    if (retryTimer > 0) then return end

    if (GuildRosterFix.Refresh(false)) then
        pendingRefresh = false;
        return;
    end

    if (retryElapsed >= MAX_RETRY_SECONDS) then
        pendingRefresh = false;
        return;
    end

    retryTimer = RETRY_INTERVAL;
end

function GuildRosterFix.Debug()
    GuildRosterFix.Refresh(true);
end
