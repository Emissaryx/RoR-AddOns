GuildRosterFix README
=====================

GuildRosterFix is a small helper addon for investigating a cold-login guild
roster issue where the stock guild roster only shows your own character until
/reloadui.

What It Does
------------

On login and on guild roster events, the addon waits until GetGuildMemberData()
contains more than one entry. It then nudges the real stock roster refresh
functions exposed at runtime, including UpdateMemberList, UpdateMemberWindow,
UpdateSortButtons, and OnRosterInit where available.

It also hooks the guild window being shown/tabbed so opening the roster after a
cold login schedules another refresh.

It does not edit guild data and it does not directly rewrite GWRosterList rows.

Manual Tests
------------

Run these after a fresh login, before using /reloadui:

    /script GuildRosterFix.Status()

This prints:

    total   - number of entries returned by GetGuildMemberData()
    online  - number that look online by online flag or non-zero zone
    online  - sample online names and zones
    first   - sample first entries, with zone and online flag

Also run:

    /script GuildRosterFix.Inspect()

This prints the runtime functions exposed by GuildWindowTabRoster and
GuildWindow, so we can target the real stock refresh function if one exists.

You can still run:

    /script GuildRosterFix.Refresh(true)
    /script GuildRosterFix.Debug()

Those print total guild count, detected online count, and whether any guessed
stock roster refresh function was called.
