<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
    <UiMod name="GuildRosterFix" version="1.0.0" date="27/06/2026">
        <Author name="TUP" email="" />
        <Description text="Delayed guild roster UI refresh for cold login roster list issues." />
        <VersionSettings gameVersion="1.4.8" windowsVersion="1.0" savedVariablesVersion="1.0" />

        <Dependencies>
            <Dependency name="EA_GuildWindow" />
        </Dependencies>

        <Files>
            <File name="Core.lua" />
        </Files>

        <OnInitialize>
            <CallFunction name="GuildRosterFix.Initialize" />
        </OnInitialize>

        <OnUpdate>
            <CallFunction name="GuildRosterFix.OnUpdate" />
        </OnUpdate>

        <OnShutdown>
            <CallFunction name="GuildRosterFix.Shutdown" />
        </OnShutdown>
    </UiMod>
</ModuleFile>
