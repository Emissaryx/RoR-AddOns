<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
    <UiMod name="LiveEventLedger" version="0.3.1" date="2026-06-12">
        <Author name="Wholdar" />
        <Description text="Tracks live-event overall progress across characters in a global ledger and shows a compact progress summary." />
        <VersionSettings gameVersion="1.4.8" windowsVersion="0.1" savedVariablesVersion="1.0" />
        <Dependencies>
            <Dependency name="EA_TomeOfKnowledge" />
            <Dependency name="EA_ContextMenu" />
            <Dependency name="EATemplate_DefaultWindowSkin" />
            <Dependency name="EATemplate_Icons" />
            <Dependency name="LibSlash" optional="true" forceEnable="true" />
        </Dependencies>
        <SavedVariables>
            <SavedVariable name="LiveEventLedger.ledger" global="true" />
        </SavedVariables>
        <Files>
            <File name="LiveEventLedger.xml" />
            <File name="LiveEventLedger.lua" />
        </Files>
        <OnInitialize>
            <CallFunction name="LiveEventLedger.LiveEventLedger_Initialize" />
        </OnInitialize>
    </UiMod>
</ModuleFile>
