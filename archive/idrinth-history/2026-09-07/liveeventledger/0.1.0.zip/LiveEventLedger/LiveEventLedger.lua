LiveEventLedger = LiveEventLedger or {}

local Ledger = LiveEventLedger

Ledger.VERSION = "0.1.0"
Ledger.WINDOW_NAME = "LiveEventLedgerWindow"
Ledger.ROW_TEMPLATE_NAME = "LiveEventLedgerWindowRowTemplate"
Ledger.MAX_ROWS = 10
Ledger.WINDOW_WIDTH = 720
Ledger.WINDOW_HEIGHT = 480
Ledger.BAR_WIDTH = 290
Ledger.RECENT_EVENT_RETENTION_SECONDS = 14 * 24 * 60 * 60
Ledger.RECENT_CHARACTER_RETENTION_SECONDS = 30 * 24 * 60 * 60
Ledger.DEFERRED_OPEN_REFRESH_SECONDS = 0.75
Ledger.OPEN_SCAN_TARGET_COUNT = 2
Ledger.CHAT_PREFIX_COLOR = "200,200,200"

Ledger.ledger = Ledger.ledger or nil
Ledger.uiRows = Ledger.uiRows or {}
Ledger._eventChoices = Ledger._eventChoices or {}
Ledger._slashRegistered = Ledger._slashRegistered or false
Ledger._slashMissingReported = Ledger._slashMissingReported or false
Ledger._eventsRegistered = Ledger._eventsRegistered or false
Ledger._windowInitialized = Ledger._windowInitialized or false
Ledger._windowCreated = Ledger._windowCreated or false
Ledger._syncingCombo = Ledger._syncingCombo or false
Ledger._sortMode = Ledger._sortMode or "name"
Ledger._sortDescending = type(Ledger._sortDescending) == "boolean" and Ledger._sortDescending or false
Ledger._tomeBookmarkContextRegistered = Ledger._tomeBookmarkContextRegistered or false
Ledger._deferredOpenRefreshRegistered = Ledger._deferredOpenRefreshRegistered or false
Ledger._deferredOpenRefreshRemaining = Ledger._deferredOpenRefreshRemaining or 0
Ledger._windowDataReady = Ledger._windowDataReady or false
Ledger._windowCanShowCachedData = type(Ledger._windowCanShowCachedData) == "boolean" and Ledger._windowCanShowCachedData or false
Ledger._openScanCount = Ledger._openScanCount or 0
Ledger._suppressNextOpenRefresh = false
Ledger._demoEventKey = nil
Ledger._demoRows = nil

local ACTION_LABEL_NORMAL = { r = 255, g = 218, b = 73 }
local ACTION_LABEL_HOVER = { r = 255, g = 255, b = 180 }
local HEADER_LABEL_NORMAL = { r = 235, g = 205, b = 145 }
local HEADER_LABEL_ACTIVE = { r = 255, g = 218, b = 73 }
local STATUS_LABEL_MUTED = { r = 155, g = 155, b = 145 }
local SORT_MODE_NAME = "name"
local SORT_MODE_SCORE = "score"
local SORT_MODE_CAREER_RANK = "careerRank"
local TOME_LIVE_EVENT_BOOKMARK = "TomeWindowLiveEventBookmark"
local TOME_LEDGER_CONTEXT_LABEL = "Open Live Event Ledger"
local INCLUDE_ENDED_TOOLTIP = "Include ended events"
local DEFERRED_OPEN_REFRESH_HANDLER = "LiveEventLedger.LiveEventLedger_OnUpdateProcessed"

local function isWString(value)
    return type(value) == "wstring" or type(value) == "userdata"
end

local function toWString(value)
    if isWString(value) then
        return value
    end

    if type(towstring) == "function" then
        local ok, result = pcall(towstring, value or "")
        if ok and result ~= nil then
            return result
        end
    end

    return value or ""
end

local function toString(value)
    if value == nil then
        return ""
    end

    local valueType = type(value)
    if valueType == "string" then
        return value
    end

    if valueType == "number" or valueType == "boolean" then
        local okNumber, textNumber = pcall(tostring, value)
        if okNumber and type(textNumber) == "string" then
            return textNumber
        end
        return ""
    end

    if isWString(value) and type(WStringToString) == "function" then
        local okWide, textWide = pcall(WStringToString, value)
        if okWide and type(textWide) == "string" then
            return textWide
        end
    end

    local okText, text = pcall(tostring, value)
    if okText and type(text) == "string" then
        return text
    end

    return ""
end

local function trim(value)
    local text = toString(value)
    text = string.gsub(text, "^%s+", "")
    text = string.gsub(text, "%s+$", "")
    return text
end

local function compactText(value, maxLength)
    local text = trim(value)
    text = string.gsub(text, "%s+", " ")

    local limit = tonumber(maxLength) or 0
    if limit <= 0 or string.len(text) <= limit then
        return text
    end

    if limit <= 3 then
        return string.sub(text, 1, limit)
    end

    return string.sub(text, 1, limit - 3) .. "..."
end

local function chatLink(text, color)
    return "<LINK data=\"\" text=\""
        .. toString(text)
        .. "\" color=\""
        .. toString(color)
        .. "\">"
end

local function chatPrint(text)
    local prefix = chatLink("[LiveEventLedger]:", Ledger.CHAT_PREFIX_COLOR) .. " "
    local line = toWString(prefix .. trim(text))
    if type(EA_ChatWindow) == "table" and type(EA_ChatWindow.Print) == "function" then
        EA_ChatWindow.Print(line)
    elseif type(TextLogAddEntry) == "function" then
        TextLogAddEntry("Chat", 0, line)
    elseif type(d) == "function" then
        d(line)
    end
end

local function getNowSeconds()
    if type(GetEpochTime) == "function" then
        local ok, value = pcall(GetEpochTime)
        local number = ok and tonumber(value) or nil
        if number ~= nil then
            return number
        end
    end

    return 0
end

local function ensureLedger()
    if type(Ledger.ledger) ~= "table" then
        Ledger.ledger = {}
    end

    Ledger.ledger.schemaVersion = 1

    if type(Ledger.ledger.events) ~= "table" then
        Ledger.ledger.events = {}
    end

    if type(Ledger.ledger.characters) ~= "table" then
        Ledger.ledger.characters = {}
    end

    if type(Ledger.ledger.includeEndedEvents) ~= "boolean" then
        Ledger.ledger.includeEndedEvents = true
    end

    return Ledger.ledger
end

function Ledger.LiveEventLedger_EnsureLedger()
    return ensureLedger()
end

local function normalizeEventTitle(title)
    local text = string.lower(trim(title))
    text = string.gsub(text, "%s+", " ")
    text = string.gsub(text, "[^%w%s%-_]", "")
    text = string.gsub(text, "%s+", "_")
    if text == "" then
        text = "event"
    end
    return text
end

local function buildEventKey(eventId, title)
    return tostring(eventId or 0) .. ":" .. normalizeEventTitle(title)
end

local function getCharacterSlot()
    if type(GameData) == "table" and type(GameData.Account) == "table" then
        local slot = tonumber(GameData.Account.SelectedCharacterSlot)
        if slot ~= nil then
            return slot
        end
    end

    return 0
end

local function getServerName()
    if type(GameData) == "table" and type(GameData.Account) == "table" then
        local serverName = trim(GameData.Account.ServerName)
        if serverName ~= "" then
            return serverName
        end
    end

    return "unknown"
end

local function getCurrentCharacterName(slot)
    if type(GameData) == "table"
        and type(GameData.Account) == "table"
        and type(GameData.Account.CharacterSlot) == "table"
        and type(GameData.Account.CharacterSlot[slot]) == "table" then
        local slotName = trim(GameData.Account.CharacterSlot[slot].Name)
        if slotName ~= "" then
            return slotName
        end
    end

    if type(GameData) == "table" and type(GameData.Player) == "table" then
        local playerName = trim(GameData.Player.name)
        if playerName ~= "" then
            return playerName
        end
    end

    if slot ~= nil and slot > 0 then
        return "Slot " .. tostring(slot)
    end

    return "Current character"
end

local function getCharacterKey(serverName, slot)
    return serverName .. ":" .. tostring(slot or 0)
end

local function getCareerIconId(careerId, careerLine)
    local id = tonumber(careerId)
    if id ~= nil and type(Icons) == "table" and type(Icons.GetCareerIconIDFromCareerNamesID) == "function" then
        local ok, iconId = pcall(Icons.GetCareerIconIDFromCareerNamesID, id)
        iconId = ok and tonumber(iconId) or nil
        if iconId ~= nil and iconId > 0 then
            return iconId
        end
    end

    if id ~= nil and type(Icons) == "table" and type(Icons.careers) == "table" then
        local iconId = tonumber(Icons.careers[id])
        if iconId ~= nil and iconId > 0 then
            return iconId
        end
    end

    local line = tonumber(careerLine)
    if line ~= nil and type(Icons) == "table" and type(Icons.GetCareerIconIDFromCareerLine) == "function" then
        local ok, iconId = pcall(Icons.GetCareerIconIDFromCareerLine, line)
        iconId = ok and tonumber(iconId) or nil
        if iconId ~= nil and iconId > 0 then
            return iconId
        end
    end

    if line ~= nil and type(Icons) == "table" and type(Icons.careerLines) == "table" then
        local iconId = tonumber(Icons.careerLines[line])
        if iconId ~= nil and iconId > 0 then
            return iconId
        end
    end

    return nil
end

local function getCareerLineValue(careerLineName)
    if type(GameData) ~= "table" or type(GameData.CareerLine) ~= "table" then
        return nil
    end

    return tonumber(GameData.CareerLine[careerLineName])
end

local function getCareerIconToken(careerIconId)
    local iconId = tonumber(careerIconId)
    if iconId == nil or iconId <= 0 then
        return ""
    end

    return "<icon" .. tostring(iconId) .. ">"
end

local function formatCareerRank(level)
    local value = tonumber(level)
    if value == nil or value <= 0 then
        return ""
    end

    return tostring(math.floor(value + 0.5))
end

local function refreshAccountCharacterNames()
    if type(GameData) ~= "table"
        or type(GameData.Account) ~= "table"
        or type(GameData.Account.CharacterSlot) ~= "table" then
        return
    end

    local ledger = ensureLedger()
    local serverName = getServerName()
    for slot, slotData in pairs(GameData.Account.CharacterSlot) do
        if type(slotData) == "table" then
            local slotName = trim(slotData.Name)
            local slotNumber = tonumber(slot)
            if slotName ~= "" and slotNumber ~= nil then
                local character = ledger.characters[getCharacterKey(serverName, slotNumber)]
                if type(character) == "table" then
                    character.name = slotName
                end
            end
        end
    end
end

local function ensureCurrentCharacter()
    local ledger = ensureLedger()
    local slot = getCharacterSlot()
    local serverName = getServerName()
    local characterKey = getCharacterKey(serverName, slot)
    local character = ledger.characters[characterKey]
    if type(character) ~= "table" then
        character = {}
        ledger.characters[characterKey] = character
    end

    character.key = characterKey
    character.slot = slot
    character.server = serverName
    character.name = getCurrentCharacterName(slot)
    character.lastSeen = getNowSeconds()

    if type(GameData) == "table" and type(GameData.Player) == "table" then
        character.level = tonumber(GameData.Player.level) or character.level
        character.realm = tonumber(GameData.Player.realm) or character.realm
        if type(GameData.Player.career) == "table" then
            character.careerId = tonumber(GameData.Player.career.id) or character.careerId
            character.careerLine = tonumber(GameData.Player.career.line)
                or tonumber(GameData.Player.career.careerLine)
                or tonumber(GameData.Player.career.careerLineId)
                or character.careerLine
            character.careerName = trim(GameData.Player.career.name)
            character.careerIconId = getCareerIconId(character.careerId, character.careerLine) or character.careerIconId
        end
    end

    if type(character.events) ~= "table" then
        character.events = {}
    end

    return character
end

local function fetchLiveEventData(eventId, eventHint)
    local eventData = {}
    if type(eventHint) == "table" then
        for key, value in pairs(eventHint) do
            eventData[key] = value
        end
    end

    if trim(eventData.title) == "" and type(GetLiveEventData) == "function" then
        local okData, apiData = pcall(GetLiveEventData, eventId)
        if okData and type(apiData) == "table" then
            for key, value in pairs(apiData) do
                eventData[key] = value
            end
        end
    end

    eventData.id = eventData.id or eventId
    eventData.title = eventData.title or eventData.name or ("Live Event " .. tostring(eventId))
    return eventData
end

local function countTasks(taskList, accumulator)
    if type(taskList) ~= "table" then
        return accumulator
    end

    for _, task in ipairs(taskList) do
        if type(task) == "table" then
            local maxValue = tonumber(task.maxValue) or 0
            local currentValue = tonumber(task.currentValue) or 0
            if task.isOnlyText ~= true and maxValue > 0 then
                accumulator.total = accumulator.total + 1
                if currentValue >= maxValue then
                    accumulator.completed = accumulator.completed + 1
                end
            end

            if type(task.subtasks) == "table" then
                countTasks(task.subtasks, accumulator)
            end
        end
    end

    return accumulator
end

local function getRewardThresholds(tasks)
    local thresholds = {}
    if type(tasks) ~= "table" or type(tasks.rewards) ~= "table" then
        return thresholds
    end

    for level = 1, 3 do
        local reward = tasks.rewards[level]
        local threshold = tonumber(reward and reward.threshold)
        if threshold ~= nil and threshold > 0 then
            thresholds[#thresholds + 1] = threshold
        end
    end

    return thresholds
end

local function clampPercent(value)
    local number = tonumber(value) or 0
    if number < 0 then
        return 0
    end
    if number > 1 then
        return 1
    end
    return number
end

local function calculateRewardProgress(currentValue, thresholds)
    local current = tonumber(currentValue) or 0
    if type(thresholds) ~= "table" or thresholds[1] == nil then
        return 0
    end

    local lastThreshold = 0
    local statusPercent = 0
    local visibleLevels = 3

    for level = 1, visibleLevels do
        local threshold = thresholds[level]
        if threshold ~= nil then
            local segment = 0
            if threshold - lastThreshold > 0 then
                segment = (current - lastThreshold) / (threshold - lastThreshold)
            end
            statusPercent = statusPercent + (1 / visibleLevels) * clampPercent(segment)
            lastThreshold = threshold
        end
    end

    return clampPercent(statusPercent)
end

function Ledger.LiveEventLedger_CalculateRewardProgress(currentValue, thresholds)
    return calculateRewardProgress(currentValue, thresholds)
end

local markEventEnded
local updateWindow

local function buildSnapshot(eventData, tasks)
    local thresholds = getRewardThresholds(tasks)
    local overallCurrent = tonumber(tasks and tasks.overallCurrentValue) or 0
    local overallMax = thresholds[#thresholds] or 0
    local counted = { total = 0, completed = 0 }
    local progressPercent = 0

    if overallMax > 0 then
        progressPercent = calculateRewardProgress(overallCurrent, thresholds)
    else
        counted = countTasks(tasks, counted)
        if counted.total > 0 then
            progressPercent = counted.completed / counted.total
        end
    end

    return {
        eventId = tonumber(eventData.id) or 0,
        eventKey = buildEventKey(eventData.id, eventData.title),
        title = compactText(eventData.title, 160),
        eligible = eventData.eligible ~= false and (type(tasks) ~= "table" or tasks.eligible ~= false),
        ended = eventData.ended == true,
        active = eventData.ended ~= true,
        lastSeen = getNowSeconds(),
        overallCurrentValue = overallCurrent,
        overallMaxValue = overallMax,
        overallPercent = clampPercent(progressPercent),
        completedTaskCount = counted.completed,
        taskCount = counted.total,
        rewardThresholds = thresholds,
    }
end

local function rememberEvent(snapshot)
    local ledger = ensureLedger()
    local event = ledger.events[snapshot.eventKey]
    if type(event) ~= "table" then
        event = {}
        ledger.events[snapshot.eventKey] = event
    end

    local knownEnded = event.ended == true or snapshot.ended == true
    if knownEnded then
        snapshot.ended = true
        snapshot.active = false
    end

    event.eventKey = snapshot.eventKey
    event.eventId = snapshot.eventId
    event.title = snapshot.title
    event.eligible = snapshot.eligible
    event.ended = knownEnded
    event.active = knownEnded ~= true and snapshot.active == true
    event.lastSeen = snapshot.lastSeen

    if knownEnded then
        markEventEnded(snapshot.eventId)
    end
end

local function captureLiveEvent(eventId, eventHint)
    if eventId == nil then
        return nil
    end

    local eventData = fetchLiveEventData(eventId, eventHint)
    local tasks = {}
    if type(GetLiveEventTasks) == "function" then
        local okTasks, apiTasks = pcall(GetLiveEventTasks, eventId)
        if okTasks and type(apiTasks) == "table" then
            tasks = apiTasks
        end
    end

    local snapshot = buildSnapshot(eventData, tasks)
    local character = ensureCurrentCharacter()
    character.events[snapshot.eventKey] = snapshot
    rememberEvent(snapshot)
    return snapshot
end

function Ledger.LiveEventLedger_CaptureLiveEvent(eventId, eventHint)
    return captureLiveEvent(eventId, eventHint)
end

markEventEnded = function(eventId)
    local eventIdNumber = tonumber(eventId)
    if eventIdNumber == nil then
        return
    end

    local ledger = ensureLedger()
    local now = getNowSeconds()
    for _, event in pairs(ledger.events) do
        if tonumber(event.eventId) == eventIdNumber then
            event.active = false
            event.ended = true
            event.lastSeen = now
        end
    end

    for _, character in pairs(ledger.characters) do
        if type(character) == "table" and type(character.events) == "table" then
            for _, snapshot in pairs(character.events) do
                if type(snapshot) == "table" and tonumber(snapshot.eventId) == eventIdNumber then
                    snapshot.active = false
                    snapshot.ended = true
                    snapshot.lastSeen = now
                end
            end
        end
    end
end

local function pruneOldCharacters()
    local ledger = ensureLedger()
    local now = getNowSeconds()
    if now <= 0 then
        return
    end

    for characterKey, character in pairs(ledger.characters) do
        local lastSeen = tonumber(character and character.lastSeen) or 0
        if lastSeen > 0 and now - lastSeen > Ledger.RECENT_CHARACTER_RETENTION_SECONDS then
            ledger.characters[characterKey] = nil
        end
    end
end

local function eventHasRecentCharacterData(ledger, eventKey, now)
    if now <= 0 then
        return true
    end

    for _, character in pairs(ledger.characters) do
        if type(character) == "table" and type(character.events) == "table" then
            local snapshot = character.events[eventKey]
            local lastSeen = tonumber(snapshot and snapshot.lastSeen) or 0
            if lastSeen > 0 and now - lastSeen <= Ledger.RECENT_EVENT_RETENTION_SECONDS then
                return true
            end
        end
    end

    return false
end

local function pruneOldEvents()
    local ledger = ensureLedger()
    local now = getNowSeconds()
    if now <= 0 then
        return
    end

    for eventKey, _ in pairs(ledger.events) do
        if not eventHasRecentCharacterData(ledger, eventKey, now) then
            ledger.events[eventKey] = nil
            for _, character in pairs(ledger.characters) do
                if type(character) == "table" and type(character.events) == "table" then
                    character.events[eventKey] = nil
                end
            end
        end
    end
end

local function captureAllLiveEvents()
    ensureCurrentCharacter()
    refreshAccountCharacterNames()
    pruneOldCharacters()

    if type(GetLiveEventList) ~= "function" then
        return false
    end

    local okList, liveEventList = pcall(GetLiveEventList)
    if not okList or type(liveEventList) ~= "table" then
        return false
    end

    for _, event in ipairs(liveEventList) do
        if type(event) == "table" and event.id ~= nil then
            captureLiveEvent(event.id, event)
        end
    end

    pruneOldEvents()
    return true
end

local function beginOpenScanGate(canShowCachedData)
    Ledger._windowDataReady = false
    Ledger._windowCanShowCachedData = canShowCachedData == true
    Ledger._openScanCount = 0
end

local function recordOpenScan()
    local ok = captureAllLiveEvents()
    if ok then
        Ledger._openScanCount = (tonumber(Ledger._openScanCount) or 0) + 1
    end
    if Ledger._openScanCount >= Ledger.OPEN_SCAN_TARGET_COUNT then
        Ledger._windowDataReady = true
        Ledger._windowCanShowCachedData = true
    end
    return ok
end

local function getIncludeEndedEvents()
    local ledger = ensureLedger()
    return ledger.includeEndedEvents ~= false
end

local function setIncludeEndedEvents(includeEnded)
    local ledger = ensureLedger()
    ledger.includeEndedEvents = includeEnded == true
end

function Ledger.LiveEventLedger_GetIncludeEndedEvents()
    return getIncludeEndedEvents()
end

function Ledger.LiveEventLedger_CaptureAllLiveEvents()
    return captureAllLiveEvents()
end

local function selectedEventStillExists(selectedKey)
    local ledger = ensureLedger()
    local event = selectedKey ~= nil and ledger.events[selectedKey] or nil
    return type(event) == "table"
        and eventHasRecentCharacterData(ledger, selectedKey, getNowSeconds())
        and (getIncludeEndedEvents() or event.ended ~= true)
end

local function formatEventChoiceTitle(title, ended)
    local text = tostring(title or "")
    if ended == true then
        return text .. " - ended"
    end
    return text
end

local function getEventChoices()
    local ledger = ensureLedger()
    local choices = {}
    local now = getNowSeconds()
    local includeEnded = getIncludeEndedEvents()

    for eventKey, event in pairs(ledger.events) do
        if type(event) == "table"
            and eventHasRecentCharacterData(ledger, eventKey, now)
            and (includeEnded or event.ended ~= true) then
            local title = event.title or ("Live Event " .. tostring(event.eventId or ""))
            choices[#choices + 1] = {
                key = eventKey,
                eventId = tonumber(event.eventId) or 0,
                title = title,
                displayTitle = formatEventChoiceTitle(title, event.ended == true),
                active = event.active == true and event.ended ~= true,
                ended = event.ended == true,
                lastSeen = tonumber(event.lastSeen) or 0,
            }
        end
    end

    table.sort(
        choices,
        function(left, right)
            local leftTitle = string.lower(tostring(left.title or ""))
            local rightTitle = string.lower(tostring(right.title or ""))
            if leftTitle ~= rightTitle then
                return leftTitle < rightTitle
            end
            if left.eventId ~= right.eventId then
                return left.eventId < right.eventId
            end
            return tostring(left.key) < tostring(right.key)
        end
    )

    return choices
end

local function hasCachedRecentEventData()
    local ledger = ensureLedger()
    local now = getNowSeconds()

    for eventKey, event in pairs(ledger.events) do
        if type(event) == "table" and eventHasRecentCharacterData(ledger, eventKey, now) then
            return true
        end
    end

    return false
end

function Ledger.LiveEventLedger_GetEventChoices()
    return getEventChoices()
end

local function setSelectedEventKey(eventKey)
    local ledger = ensureLedger()
    if not selectedEventStillExists(eventKey) then
        return false
    end

    ledger.selectedEventKey = eventKey
    return true
end

function Ledger.LiveEventLedger_SetSelectedEventKey(eventKey)
    return setSelectedEventKey(eventKey)
end

local function getSelectedEventKey()
    local ledger = ensureLedger()
    if selectedEventStillExists(ledger.selectedEventKey) then
        return ledger.selectedEventKey
    end

    local choices = getEventChoices()
    if choices[1] ~= nil then
        ledger.selectedEventKey = choices[1].key
        return choices[1].key
    end

    ledger.selectedEventKey = nil
    return nil
end

function Ledger.LiveEventLedger_GetSelectedEventKey()
    return getSelectedEventKey()
end

local function normalizeSortMode(mode)
    if mode == SORT_MODE_SCORE then
        return SORT_MODE_SCORE
    end
    if mode == SORT_MODE_CAREER_RANK then
        return SORT_MODE_CAREER_RANK
    end
    return SORT_MODE_NAME
end

local function defaultSortDescending(mode)
    return mode == SORT_MODE_SCORE or mode == SORT_MODE_CAREER_RANK
end

local function getSortMode()
    local normalized = normalizeSortMode(Ledger._sortMode)
    if normalized ~= Ledger._sortMode then
        Ledger._sortDescending = defaultSortDescending(normalized)
    end
    Ledger._sortMode = normalized
    if type(Ledger._sortDescending) ~= "boolean" then
        Ledger._sortDescending = defaultSortDescending(Ledger._sortMode)
    end
    return Ledger._sortMode
end

function Ledger.LiveEventLedger_GetSortMode()
    return getSortMode()
end

local function getSortDescending()
    getSortMode()
    return Ledger._sortDescending == true
end

function Ledger.LiveEventLedger_GetSortDescending()
    return getSortDescending()
end

local function setSortMode(mode, toggleIfActive)
    local normalized = normalizeSortMode(mode)
    if toggleIfActive == true and normalized == getSortMode() then
        Ledger._sortDescending = not getSortDescending()
    else
        Ledger._sortMode = normalized
        Ledger._sortDescending = defaultSortDescending(normalized)
    end
    return Ledger._sortMode
end

function Ledger.LiveEventLedger_SetSortMode(mode)
    return setSortMode(mode)
end

local function compareRowsByNameDirection(left, right, descending)
    local leftName = string.lower(tostring(left.name or ""))
    local rightName = string.lower(tostring(right.name or ""))
    if leftName ~= rightName then
        if descending == true then
            return leftName > rightName
        end
        return leftName < rightName
    end
    if left.server ~= right.server then
        if descending == true then
            return tostring(left.server or "") > tostring(right.server or "")
        end
        return tostring(left.server or "") < tostring(right.server or "")
    end
    if descending == true then
        return (tonumber(left.slot) or 0) > (tonumber(right.slot) or 0)
    end
    return (tonumber(left.slot) or 0) < (tonumber(right.slot) or 0)
end

local function compareRowsByName(left, right)
    return compareRowsByNameDirection(left, right, false)
end

local function getSnapshotSortScore(snapshot)
    if type(snapshot) ~= "table" then
        return 0
    end

    local percent = tonumber(snapshot.overallPercent)
    if percent ~= nil then
        return clampPercent(percent)
    end

    local overallCurrent = tonumber(snapshot.overallCurrentValue) or 0
    local overallMaximum = tonumber(snapshot.overallMaxValue) or 0
    if overallMaximum > 0 then
        return overallCurrent / overallMaximum
    end

    return overallCurrent
end

local function compareRowsByScore(left, right, descending)
    local leftScore = getSnapshotSortScore(left.snapshot)
    local rightScore = getSnapshotSortScore(right.snapshot)
    if leftScore ~= rightScore then
        if descending == false then
            return leftScore < rightScore
        end
        return leftScore > rightScore
    end
    return compareRowsByName(left, right)
end

local function compareRowsByCareerRank(left, right, descending)
    local leftLevel = tonumber(left.level) or 0
    local rightLevel = tonumber(right.level) or 0
    if leftLevel ~= rightLevel then
        if descending == false then
            return leftLevel < rightLevel
        end
        return leftLevel > rightLevel
    end
    return compareRowsByName(left, right)
end

local function compareRows(left, right)
    local mode = getSortMode()
    local descending = getSortDescending()
    if mode == SORT_MODE_SCORE then
        return compareRowsByScore(left, right, descending)
    end
    if mode == SORT_MODE_CAREER_RANK then
        return compareRowsByCareerRank(left, right, descending)
    end
    return compareRowsByNameDirection(left, right, descending)
end

local DEMO_REWARD_MAX = 75
local DEMO_ORDER_ROWS = {
    { name = "Baragor", careerId = 20, careerLine = "IRON_BREAKER", level = 40, percent = 0.96 },
    { name = "Skalli", careerId = 21, careerLine = "SLAYER", level = 40, percent = 0.72 },
    { name = "Dorrik", careerId = 23, careerLine = "ENGINEER", level = 39, percent = 0.44 },
    { name = "Vala", careerId = 22, careerLine = "RUNE_PRIEST", level = 40, percent = 0.88 },
    { name = "Konrad", careerId = 61, careerLine = "KNIGHT", level = 40, percent = 0.61 },
    { name = "Magda", careerId = 62, careerLine = "BRIGHT_WIZARD", level = 38, percent = 0.27 },
    { name = "Elspeth", careerId = 63, careerLine = "WARRIOR_PRIEST", level = 40, percent = 1 },
    { name = "Adelmar", careerId = 60, careerLine = "WITCH_HUNTER", level = 37, percent = 0.15 },
    { name = "Itharion", careerId = 100, careerLine = "SWORDMASTER", level = 40, percent = 0.79 },
    { name = "Lirael", careerId = 101, careerLine = "SHADOW_WARRIOR", level = 39, percent = 0.53 },
    { name = "Caranthir", careerId = 102, careerLine = "WHITE_LION", level = 40, percent = 0.35 },
    { name = "Thalara", careerId = 103, careerLine = "ARCHMAGE", level = 40, percent = 0.68 },
}
local DEMO_DESTRUCTION_ROWS = {
    { name = "Ruzgob", careerId = 24, careerLine = "BLACK_ORC", level = 40, percent = 0.91 },
    { name = "Gitznak", careerId = 25, careerLine = "CHOPPA", level = 39, percent = 0.48 },
    { name = "Zogrek", careerId = 26, careerLine = "SHAMAN", level = 40, percent = 0.77 },
    { name = "Snikkit", careerId = 27, careerLine = "SQUIG_HERDER", level = 38, percent = 0.22 },
    { name = "Varkhul", careerId = 64, careerLine = "CHOSEN", level = 40, percent = 1 },
    { name = "Kharzak", careerId = 65, careerLine = "MARAUDER", level = 40, percent = 0.57 },
    { name = "Mordrek", careerId = 66, careerLine = "ZEALOT", level = 39, percent = 0.84 },
    { name = "Azhrak", careerId = 67, careerLine = "MAGUS", level = 37, percent = 0.31 },
    { name = "Malekir", careerId = 104, careerLine = "BLACKGUARD", level = 40, percent = 0.69 },
    { name = "Nythara", careerId = 105, careerLine = "WITCH_ELF", level = 40, percent = 0.42 },
    { name = "Varesh", careerId = 106, careerLine = "DISCIPLE", level = 39, percent = 0.63 },
    { name = "Syraeth", careerId = 107, careerLine = "SORCERER", level = 40, percent = 0.18 },
}

local function clearDemoRows()
    Ledger._demoEventKey = nil
    Ledger._demoRows = nil
end

local function buildDemoSnapshot(eventKey, event, percent)
    local progress = clampPercent(percent)
    local completed = math.floor((progress * 3) + 0.0001)
    if completed > 3 then
        completed = 3
    end

    return {
        eventId = tonumber(event.eventId) or 0,
        eventKey = eventKey,
        title = compactText(event.title, 160),
        eligible = true,
        ended = event.ended == true,
        active = event.ended ~= true,
        lastSeen = getNowSeconds(),
        overallCurrentValue = math.floor((DEMO_REWARD_MAX * progress) + 0.5),
        overallMaxValue = DEMO_REWARD_MAX,
        overallPercent = progress,
        completedTaskCount = completed,
        taskCount = 3,
        rewardThresholds = { 25, 50, DEMO_REWARD_MAX },
    }
end

local function createDemoRows(eventKey, realmName, specs)
    local event = ensureLedger().events[eventKey]
    if type(event) ~= "table" then
        return nil
    end

    local rows = {}
    for index, spec in ipairs(specs) do
        local careerLine = getCareerLineValue(spec.careerLine)
        rows[#rows + 1] = {
            characterKey = "demo:" .. realmName .. ":" .. tostring(index),
            name = spec.name,
            slot = 100 + index,
            server = "Demo " .. realmName,
            level = tonumber(spec.level) or 40,
            careerIconId = getCareerIconId(spec.careerId, careerLine),
            self = false,
            snapshot = buildDemoSnapshot(eventKey, event, spec.percent),
        }
    end

    return rows
end

local function setDemoRows(eventKey, realmName)
    local specs = realmName == "destruction" and DEMO_DESTRUCTION_ROWS or DEMO_ORDER_ROWS
    local rows = createDemoRows(eventKey, realmName, specs)
    if type(rows) ~= "table" then
        clearDemoRows()
        return false
    end

    Ledger._demoEventKey = eventKey
    Ledger._demoRows = rows
    return true
end

local function getRowsForEvent(eventKey)
    local ledger = ensureLedger()
    local rows = {}
    if eventKey == nil then
        return rows
    end

    local demoRows = Ledger._demoEventKey == eventKey and Ledger._demoRows or nil
    if type(demoRows) == "table" then
        for _, row in ipairs(demoRows) do
            rows[#rows + 1] = row
        end
        table.sort(rows, compareRows)
        return rows
    end

    for _, character in pairs(ledger.characters) do
        if type(character) == "table"
            and type(character.events) == "table"
            and type(character.events[eventKey]) == "table" then
            local snapshot = character.events[eventKey]
            rows[#rows + 1] = {
                characterKey = character.key,
                name = character.name or "Unknown",
                slot = tonumber(character.slot) or 0,
                server = character.server or "",
                level = tonumber(character.level) or 0,
                careerIconId = tonumber(character.careerIconId) or getCareerIconId(character.careerId, character.careerLine),
                self = character.key == getCharacterKey(getServerName(), getCharacterSlot()),
                snapshot = snapshot,
            }
        end
    end

    table.sort(rows, compareRows)

    return rows
end

function Ledger.LiveEventLedger_GetRowsForEvent(eventKey)
    return getRowsForEvent(eventKey)
end

local function formatProgressText(snapshot)
    if type(snapshot) ~= "table" then
        return "not tracked"
    end

    if snapshot.eligible == false then
        return "ineligible"
    end

    local overallMaximum = tonumber(snapshot.overallMaxValue) or 0
    local taskCount = tonumber(snapshot.taskCount) or 0
    if overallMaximum > 0 or taskCount > 0 then
        local percent = clampPercent(tonumber(snapshot.overallPercent) or 0)
        return tostring(math.floor((percent * 100) + 0.5)) .. "%"
    end

    return "tracked"
end

function Ledger.LiveEventLedger_FormatProgressText(snapshot)
    return formatProgressText(snapshot)
end

local function addComboBoxItem(windowName, text)
    if type(ComboBoxAddMenuItem) == "function" then
        pcall(ComboBoxAddMenuItem, windowName, toWString(text or ""))
    end
end

local function clearComboBoxItems(windowName)
    if type(ComboBoxClearMenuItems) == "function" then
        pcall(ComboBoxClearMenuItems, windowName)
    end
end

local function setComboBoxSelection(windowName, index)
    if type(ComboBoxSetSelectedMenuItem) == "function" then
        pcall(ComboBoxSetSelectedMenuItem, windowName, index)
    end
end

local function getComboBoxSelection(windowName)
    if type(ComboBoxGetSelectedMenuItem) ~= "function" then
        return nil
    end

    local ok, selected = pcall(ComboBoxGetSelectedMenuItem, windowName)
    return ok and tonumber(selected) or nil
end

local function windowExists(windowName)
    if type(DoesWindowExist) ~= "function" then
        return true
    end

    local ok, exists = pcall(DoesWindowExist, windowName)
    return ok and exists == true
end

local function ledgerRootExists()
    if Ledger._windowCreated then
        return true
    end

    Ledger._windowCreated = windowExists(Ledger.WINDOW_NAME)
    return Ledger._windowCreated
end

local function canTouchLedgerWindow(windowName)
    if type(windowName) == "string"
        and string.sub(windowName, 1, string.len(Ledger.WINDOW_NAME)) == Ledger.WINDOW_NAME
    then
        if windowName == Ledger.WINDOW_NAME then
            return ledgerRootExists()
        end
        return ledgerRootExists() and windowExists(windowName)
    end

    return windowExists(windowName)
end

local function setLabelText(windowName, text)
    if type(LabelSetText) == "function" and canTouchLedgerWindow(windowName) then
        pcall(LabelSetText, windowName, toWString(text or ""))
    end
end

local function setLabelTextColor(windowName, r, g, b)
    if type(LabelSetTextColor) == "function" and canTouchLedgerWindow(windowName) then
        pcall(LabelSetTextColor, windowName, r, g, b)
    end
end

local function setButtonPressedFlag(windowName, pressed)
    if type(ButtonSetPressedFlag) == "function" and canTouchLedgerWindow(windowName) then
        pcall(ButtonSetPressedFlag, windowName, pressed == true)
    end
end

local function showTextTooltip(windowName, text)
    if type(Tooltips) ~= "table" or type(Tooltips.CreateTextOnlyTooltip) ~= "function" then
        return false
    end

    local ok = pcall(Tooltips.CreateTextOnlyTooltip, windowName, nil)
    if not ok then
        return false
    end

    if type(Tooltips.SetTooltipText) == "function" then
        pcall(Tooltips.SetTooltipText, 1, 1, toWString(text or ""))
    end
    if type(Tooltips.Finalize) == "function" then
        pcall(Tooltips.Finalize)
    end
    if type(Tooltips.AnchorTooltip) == "function" then
        pcall(Tooltips.AnchorTooltip, Tooltips.ANCHOR_WINDOW_RIGHT or Tooltips.ANCHOR_CURSOR)
    end

    return true
end

local function clearTooltip()
    if type(Tooltips) == "table" and type(Tooltips.ClearTooltip) == "function" then
        pcall(Tooltips.ClearTooltip)
    end
end

local function setActionLabelHover(windowName, hover)
    local color = hover and ACTION_LABEL_HOVER or ACTION_LABEL_NORMAL
    setLabelTextColor(windowName, color.r, color.g, color.b)
end

local function setSortHeaderColors()
    local nameColor = getSortMode() == SORT_MODE_NAME and HEADER_LABEL_ACTIVE or HEADER_LABEL_NORMAL
    local scoreColor = getSortMode() == SORT_MODE_SCORE and HEADER_LABEL_ACTIVE or HEADER_LABEL_NORMAL
    local careerRankColor = getSortMode() == SORT_MODE_CAREER_RANK and HEADER_LABEL_ACTIVE or HEADER_LABEL_NORMAL
    setLabelTextColor(Ledger.WINDOW_NAME .. "CareerRankHeader", careerRankColor.r, careerRankColor.g, careerRankColor.b)
    setLabelTextColor(Ledger.WINDOW_NAME .. "NameHeader", nameColor.r, nameColor.g, nameColor.b)
    setLabelTextColor(Ledger.WINDOW_NAME .. "BasicHeader", scoreColor.r, scoreColor.g, scoreColor.b)
    setLabelTextColor(Ledger.WINDOW_NAME .. "AdvancedHeader", scoreColor.r, scoreColor.g, scoreColor.b)
    setLabelTextColor(Ledger.WINDOW_NAME .. "ValueHeader", scoreColor.r, scoreColor.g, scoreColor.b)
end

local function formatTrackedCharacterStatus(rowCount)
    local count = tonumber(rowCount) or 0
    if count == 1 then
        return "Tracking 1 character"
    end
    return "Tracking " .. tostring(count) .. " characters"
end

local function playUiSound(soundName)
    local soundId = nil
    if type(Sound) == "table" then
        soundId = Sound[soundName]
        if soundId ~= nil and type(Sound.Play) == "function" then
            pcall(Sound.Play, soundId)
            return
        end
    end

    if type(GameData) == "table" and type(GameData.Sound) == "table" then
        soundId = GameData.Sound[soundName]
    end

    if soundId ~= nil and type(PlaySound) == "function" then
        pcall(PlaySound, soundId)
    end
end

local function getActiveWindowName(fallback)
    if type(SystemData) == "table" then
        if type(SystemData.ActiveWindow) == "table"
            and type(SystemData.ActiveWindow.name) == "string"
            and SystemData.ActiveWindow.name ~= "" then
            return SystemData.ActiveWindow.name
        end

        if type(SystemData.MouseOverWindow) == "table"
            and type(SystemData.MouseOverWindow.name) == "string"
            and SystemData.MouseOverWindow.name ~= "" then
            return SystemData.MouseOverWindow.name
        end
    end

    return fallback
end

local function openLedgerFromTomeContextMenu()
    Ledger.LiveEventLedger_Show()
end

local function showTomeLiveEventBookmarkContextMenu()
    if type(EA_Window_ContextMenu) ~= "table"
        or type(EA_Window_ContextMenu.CreateContextMenu) ~= "function"
        or type(EA_Window_ContextMenu.AddMenuItem) ~= "function"
        or type(EA_Window_ContextMenu.Finalize) ~= "function" then
        return false
    end

    local menuId = EA_Window_ContextMenu.CONTEXT_MENU_1 or 1
    local anchorWindow = getActiveWindowName(TOME_LIVE_EVENT_BOOKMARK)
    local ok = pcall(EA_Window_ContextMenu.CreateContextMenu, anchorWindow, menuId, nil)
    if not ok then
        return false
    end

    local okAdd = pcall(
        EA_Window_ContextMenu.AddMenuItem,
        toWString(TOME_LEDGER_CONTEXT_LABEL),
        openLedgerFromTomeContextMenu,
        false,
        true,
        menuId
    )
    if not okAdd then
        return false
    end

    pcall(EA_Window_ContextMenu.Finalize, menuId)
    return true
end

local function tryRegisterTomeBookmarkContextMenu()
    if Ledger._tomeBookmarkContextRegistered then
        return true
    end

    if type(WindowRegisterCoreEventHandler) ~= "function" then
        return false
    end

    if type(DoesWindowExist) == "function" then
        local okExists, exists = pcall(DoesWindowExist, TOME_LIVE_EVENT_BOOKMARK)
        if okExists and exists ~= true then
            return false
        end
    end

    local ok = pcall(
        WindowRegisterCoreEventHandler,
        TOME_LIVE_EVENT_BOOKMARK,
        "OnRButtonUp",
        "LiveEventLedger.LiveEventLedger_OnTomeLiveEventBookmarkRButtonUp"
    )
    if ok then
        Ledger._tomeBookmarkContextRegistered = true
    end
    return ok
end

local function setWindowShowing(windowName, showing)
    if type(WindowSetShowing) == "function" and canTouchLedgerWindow(windowName) then
        pcall(WindowSetShowing, windowName, showing == true)
    end
end

local function setWindowDimensions(windowName, width, height)
    if type(WindowSetDimensions) == "function" and canTouchLedgerWindow(windowName) then
        pcall(WindowSetDimensions, windowName, width, height)
    end
end

local function syncWindowDimensions()
    setWindowDimensions(Ledger.WINDOW_NAME, Ledger.WINDOW_WIDTH, Ledger.WINDOW_HEIGHT)
end

local function isWindowShowing(windowName)
    if type(WindowGetShowing) ~= "function" then
        return false
    end
    if not windowExists(windowName) then
        return false
    end

    local ok, showing = pcall(WindowGetShowing, windowName)
    return ok and showing == true
end

local function unregisterDeferredOpenRefresh()
    if not Ledger._deferredOpenRefreshRegistered then
        return
    end
    Ledger._deferredOpenRefreshRegistered = false
    Ledger._deferredOpenRefreshRemaining = 0

    if type(SystemData) ~= "table"
        or type(SystemData.Events) ~= "table"
        or SystemData.Events.UPDATE_PROCESSED == nil
        or type(UnregisterEventHandler) ~= "function" then
        return
    end

    pcall(UnregisterEventHandler, SystemData.Events.UPDATE_PROCESSED, DEFERRED_OPEN_REFRESH_HANDLER)
end

local function registerDeferredOpenRefresh()
    if Ledger._windowDataReady then
        return false
    end

    if type(SystemData) ~= "table"
        or type(SystemData.Events) ~= "table"
        or SystemData.Events.UPDATE_PROCESSED == nil
        or type(RegisterEventHandler) ~= "function" then
        return false
    end

    Ledger._deferredOpenRefreshRemaining = Ledger.DEFERRED_OPEN_REFRESH_SECONDS
    if Ledger._deferredOpenRefreshRegistered then
        return true
    end

    local ok = pcall(RegisterEventHandler, SystemData.Events.UPDATE_PROCESSED, DEFERRED_OPEN_REFRESH_HANDLER)
    Ledger._deferredOpenRefreshRegistered = ok == true
    return Ledger._deferredOpenRefreshRegistered
end

local function runDeferredOpenRefresh()
    if not isWindowShowing(Ledger.WINDOW_NAME) then
        unregisterDeferredOpenRefresh()
        return
    end

    recordOpenScan()
    if Ledger._windowDataReady then
        unregisterDeferredOpenRefresh()
        updateWindow()
    else
        Ledger._deferredOpenRefreshRemaining = Ledger.DEFERRED_OPEN_REFRESH_SECONDS
    end
end

local function startOpenRefresh()
    syncWindowDimensions()
    beginOpenScanGate(hasCachedRecentEventData())
    recordOpenScan()
    registerDeferredOpenRefresh()
    return updateWindow()
end

local function ensureWindowCreated()
    if ledgerRootExists() then
        return true
    end

    if type(CreateWindow) ~= "function" then
        return false
    end

    local ok = pcall(CreateWindow, Ledger.WINDOW_NAME, false)
    if not ok or not ledgerRootExists() then
        return false
    end

    return true
end

local function getComboName()
    return Ledger.WINDOW_NAME .. "EventComboBox"
end

local function getIncludeEndedCheckBoxName()
    return Ledger.WINDOW_NAME .. "IncludeEndedCheckBox"
end

local function getListName()
    return Ledger.WINDOW_NAME .. "List"
end

local function getVisibleRowWindowName(visibleIndex)
    return getListName() .. "Row" .. tostring(visibleIndex)
end

local function getListDataIndex(visibleIndex)
    if type(ListBoxGetDataIndex) == "function" then
        local ok, dataIndex = pcall(ListBoxGetDataIndex, getListName(), visibleIndex)
        local index = ok and tonumber(dataIndex) or nil
        if index ~= nil and index > 0 then
            return index
        end
    end

    return visibleIndex
end

local function setListDisplayOrder(rowCount)
    if type(ListBoxSetDisplayOrder) ~= "function" then
        return
    end

    local count = tonumber(rowCount) or 0
    local order = {}
    for index = 1, count do
        order[index] = index
    end
    pcall(ListBoxSetDisplayOrder, getListName(), order)
end

local function setVisibleRowProgress(visibleIndex)
    local rowName = getVisibleRowWindowName(visibleIndex)
    local dataIndex = getListDataIndex(visibleIndex)
    local row = Ledger.uiRows[dataIndex]
    local snapshot = type(row) == "table" and row.snapshot or nil
    local isSelf = type(row) == "table" and row.self == true
    local percent = clampPercent(snapshot and snapshot.overallPercent or 0)
    local fillWidth = math.floor((Ledger.BAR_WIDTH * percent) + 0.5)
    if fillWidth < 1 then
        fillWidth = 1
    end

    if isSelf then
        setLabelTextColor(rowName .. "CareerRank", 0, 200, 0)
        setLabelTextColor(rowName .. "Name", 0, 200, 0)
        setLabelTextColor(rowName .. "Value", 0, 200, 0)
    else
        setLabelTextColor(rowName .. "CareerRank", 210, 210, 210)
        setLabelTextColor(rowName .. "Name", 245, 245, 245)
        setLabelTextColor(rowName .. "Value", 210, 210, 210)
    end

    setWindowDimensions(rowName .. "BarFill", fillWidth, 10)
    setWindowShowing(rowName .. "BarFill", percent > 0)
    setWindowShowing(rowName .. "BasicMarker", snapshot ~= nil and (tonumber(snapshot.overallMaxValue) or 0) > 0)
    setWindowShowing(rowName .. "AdvancedMarker", snapshot ~= nil and (tonumber(snapshot.overallMaxValue) or 0) > 0)
end

local function updateVisibleRowProgress()
    for index = 1, Ledger.MAX_ROWS do
        setVisibleRowProgress(index)
    end
end

function Ledger.LiveEventLedger_UpdateListRow()
    local list = _G and _G[getListName()] or nil
    local populatorIndices = type(list) == "table" and list.PopulatorIndices or nil
    if type(populatorIndices) ~= "table" then
        updateVisibleRowProgress()
        return
    end

    for rowIndex, _ in ipairs(populatorIndices) do
        setVisibleRowProgress(rowIndex)
    end
end

local function buildUiRows(rows)
    local uiRows = {}
    for _, row in ipairs(rows) do
        local snapshot = row.snapshot
        uiRows[#uiRows + 1] = {
            characterKey = row.characterKey,
            careerIconText = toWString(getCareerIconToken(row.careerIconId)),
            careerRankText = toWString(formatCareerRank(row.level)),
            nameText = toWString(compactText(row.name, 24)),
            valueText = toWString(formatProgressText(snapshot)),
            self = row.self == true,
            snapshot = snapshot,
        }
    end
    return uiRows
end

local function syncEventComboBox()
    local comboName = getComboName()
    local choices = getEventChoices()
    local ledger = ensureLedger()
    local selectedKey = ledger.selectedEventKey
    local selectedIndex = nil
    Ledger._eventChoices = choices
    Ledger._syncingCombo = true

    clearComboBoxItems(comboName)

    if choices[1] == nil then
        if getIncludeEndedEvents() then
            addComboBoxItem(comboName, "No live events tracked")
        else
            addComboBoxItem(comboName, "No active live events tracked")
        end
        ledger.selectedEventKey = nil
        setComboBoxSelection(comboName, 1)
        Ledger._syncingCombo = false
        return nil
    end

    for index, choice in ipairs(choices) do
        addComboBoxItem(comboName, choice.displayTitle or choice.title)
        if choice.key == selectedKey then
            selectedIndex = index
        end
    end

    if selectedIndex == nil then
        selectedIndex = 1
        selectedKey = choices[1].key
        ledger.selectedEventKey = selectedKey
    end

    setComboBoxSelection(comboName, selectedIndex)
    Ledger._syncingCombo = false
    return selectedKey
end

local function syncIncludeEndedCheckBox()
    setButtonPressedFlag(getIncludeEndedCheckBoxName(), getIncludeEndedEvents())
end

local function showLoadingWindow()
    local comboName = getComboName()
    syncIncludeEndedCheckBox()
    Ledger._eventChoices = {}
    Ledger._syncingCombo = true
    clearComboBoxItems(comboName)
    addComboBoxItem(comboName, "Loading live events...")
    setComboBoxSelection(comboName, 1)
    Ledger._syncingCombo = false

    Ledger.uiRows = {}
    setListDisplayOrder(0)
    setSortHeaderColors()
    updateVisibleRowProgress()
    setLabelTextColor(Ledger.WINDOW_NAME .. "Status", STATUS_LABEL_MUTED.r, STATUS_LABEL_MUTED.g, STATUS_LABEL_MUTED.b)
    setLabelText(Ledger.WINDOW_NAME .. "Status", "Loading live events...")
    setLabelText(Ledger.WINDOW_NAME .. "Footer", "Refreshing live-event data...")
end

updateWindow = function()
    if not ledgerRootExists() then
        return false
    end

    if not Ledger._windowDataReady and not Ledger._windowCanShowCachedData then
        showLoadingWindow()
        return true
    end

    syncIncludeEndedCheckBox()
    local selectedKey = syncEventComboBox()
    local rows = getRowsForEvent(selectedKey)
    Ledger.uiRows = buildUiRows(rows)
    setListDisplayOrder(#Ledger.uiRows)
    setSortHeaderColors()
    updateVisibleRowProgress()

    local ledger = ensureLedger()
    local event = selectedKey and ledger.events[selectedKey] or nil
    if type(event) ~= "table" then
        setLabelText(Ledger.WINDOW_NAME .. "Status", "No event selected")
        if getIncludeEndedEvents() then
            setLabelText(Ledger.WINDOW_NAME .. "Footer", "Log into characters with this addon enabled to populate the ledger.")
        else
            setLabelText(Ledger.WINDOW_NAME .. "Footer", "Ended events are hidden.")
        end
        return
    end

    setLabelTextColor(Ledger.WINDOW_NAME .. "Status", STATUS_LABEL_MUTED.r, STATUS_LABEL_MUTED.g, STATUS_LABEL_MUTED.b)
    setLabelText(Ledger.WINDOW_NAME .. "Status", formatTrackedCharacterStatus(#rows))
    setLabelText(Ledger.WINDOW_NAME .. "Footer", "Use Open ToK for task details.")
    return true
end

function Ledger.LiveEventLedger_UpdateWindow()
    return updateWindow()
end

function Ledger.LiveEventLedger_OnListRowShown(flags, rowId)
    local _ = flags
    local index = tonumber(rowId)
    if index == nil
        and type(SystemData) == "table"
        and type(SystemData.ActiveWindow) == "table"
        and type(WindowGetId) == "function" then
        local ok, value = pcall(WindowGetId, SystemData.ActiveWindow.name)
        index = ok and tonumber(value) or nil
    end
    if index == nil then
        return
    end

    setVisibleRowProgress(index)
end

function Ledger.LiveEventLedger_OnWindowInitialize()
    if Ledger._windowInitialized then
        return
    end
    if not ledgerRootExists() then
        return
    end

    Ledger._windowInitialized = true
    syncWindowDimensions()
    setLabelText(Ledger.WINDOW_NAME .. "TitleBarText", "Live Event Ledger")
    setLabelText(Ledger.WINDOW_NAME .. "EventLabel", "Event")
    setLabelText(Ledger.WINDOW_NAME .. "CareerRankHeader", "CR")
    setLabelText(Ledger.WINDOW_NAME .. "NameHeader", "Character")
    setLabelText(Ledger.WINDOW_NAME .. "BasicHeader", "Basic")
    setLabelText(Ledger.WINDOW_NAME .. "AdvancedHeader", "Advanced")
    setLabelText(Ledger.WINDOW_NAME .. "ValueHeader", "")
    setLabelText(Ledger.WINDOW_NAME .. "OpenTomeLabel", "Open ToK")
    setLabelText(Ledger.WINDOW_NAME .. "ActionSeparator", "|")
    setLabelText(Ledger.WINDOW_NAME .. "RefreshLabel", "Refresh")
    setLabelTextColor(Ledger.WINDOW_NAME .. "Status", STATUS_LABEL_MUTED.r, STATUS_LABEL_MUTED.g, STATUS_LABEL_MUTED.b)
    setActionLabelHover(Ledger.WINDOW_NAME .. "OpenTomeLabel", false)
    setActionLabelHover(Ledger.WINDOW_NAME .. "RefreshLabel", false)
    setSortHeaderColors()
end

function Ledger.LiveEventLedger_OnWindowShown()
    if Ledger._suppressNextOpenRefresh == true then
        Ledger._suppressNextOpenRefresh = false
        return true
    end

    return startOpenRefresh()
end

local function showWindowWithoutOpenRefresh()
    if not ensureWindowCreated() then
        chatPrint("Unable to open live-event ledger window in this client.")
        return false
    end

    Ledger.LiveEventLedger_OnWindowInitialize()
    if not isWindowShowing(Ledger.WINDOW_NAME) then
        Ledger._suppressNextOpenRefresh = true
        setWindowShowing(Ledger.WINDOW_NAME, true)
    end
    return true
end

function Ledger.LiveEventLedger_Show()
    if not ensureWindowCreated() then
        chatPrint("Unable to open live-event ledger window in this client.")
        return false
    end

    Ledger.LiveEventLedger_OnWindowInitialize()
    if isWindowShowing(Ledger.WINDOW_NAME) then
        return startOpenRefresh()
    end

    setWindowShowing(Ledger.WINDOW_NAME, true)
    return true
end

function Ledger.LiveEventLedger_Hide()
    clearDemoRows()
    unregisterDeferredOpenRefresh()
    setWindowShowing(Ledger.WINDOW_NAME, false)
end

function Ledger.LiveEventLedger_RefreshButton()
    clearDemoRows()
    unregisterDeferredOpenRefresh()
    captureAllLiveEvents()
    Ledger._windowDataReady = true
    updateWindow()
end

function Ledger.LiveEventLedger_OpenTomeLabel()
    playUiSound("BUTTON_CLICK")
    return Ledger.LiveEventLedger_OpenSelectedTomeEntry()
end

function Ledger.LiveEventLedger_RefreshLabel()
    playUiSound("BUTTON_CLICK")
    return Ledger.LiveEventLedger_RefreshButton()
end

function Ledger.LiveEventLedger_OnTomeLiveEventBookmarkRButtonUp()
    return showTomeLiveEventBookmarkContextMenu()
end

function Ledger.LiveEventLedger_TryRegisterTomeBookmarkContextMenu()
    return tryRegisterTomeBookmarkContextMenu()
end

function Ledger.LiveEventLedger_OnNameSortHeader()
    playUiSound("BUTTON_CLICK")
    setSortMode(SORT_MODE_NAME, true)
    updateWindow()
end

function Ledger.LiveEventLedger_OnCareerRankSortHeader()
    playUiSound("BUTTON_CLICK")
    setSortMode(SORT_MODE_CAREER_RANK, true)
    updateWindow()
end

function Ledger.LiveEventLedger_OnScoreSortHeader()
    playUiSound("BUTTON_CLICK")
    setSortMode(SORT_MODE_SCORE, true)
    updateWindow()
end

function Ledger.LiveEventLedger_OnOpenTomeMouseOver()
    setActionLabelHover(Ledger.WINDOW_NAME .. "OpenTomeLabel", true)
end

function Ledger.LiveEventLedger_OnOpenTomeMouseOverEnd()
    setActionLabelHover(Ledger.WINDOW_NAME .. "OpenTomeLabel", false)
end

function Ledger.LiveEventLedger_OnRefreshMouseOver()
    setActionLabelHover(Ledger.WINDOW_NAME .. "RefreshLabel", true)
end

function Ledger.LiveEventLedger_OnRefreshMouseOverEnd()
    setActionLabelHover(Ledger.WINDOW_NAME .. "RefreshLabel", false)
end

function Ledger.LiveEventLedger_OnUpdateProcessed(timePassed)
    if not Ledger._deferredOpenRefreshRegistered then
        return
    end
    if not isWindowShowing(Ledger.WINDOW_NAME) then
        unregisterDeferredOpenRefresh()
        return
    end

    local elapsed = tonumber(timePassed) or 0
    if elapsed <= 0 then
        elapsed = 0.1
    end

    Ledger._deferredOpenRefreshRemaining = (tonumber(Ledger._deferredOpenRefreshRemaining) or 0) - elapsed
    if Ledger._deferredOpenRefreshRemaining <= 0 then
        runDeferredOpenRefresh()
    end
end

function Ledger.LiveEventLedger_OnEventComboBoxSelChanged()
    if Ledger._syncingCombo then
        return
    end

    local selectedIndex = getComboBoxSelection(getComboName())
    local choice = selectedIndex and Ledger._eventChoices[selectedIndex] or nil
    if type(choice) ~= "table" then
        return
    end

    setSelectedEventKey(choice.key)
    updateWindow()
end

function Ledger.LiveEventLedger_OnIncludeEndedChanged()
    setIncludeEndedEvents(not getIncludeEndedEvents())
    updateWindow()
end

function Ledger.LiveEventLedger_OnIncludeEndedMouseOver()
    return showTextTooltip(getIncludeEndedCheckBoxName(), INCLUDE_ENDED_TOOLTIP)
end

function Ledger.LiveEventLedger_OnIncludeEndedMouseOverEnd()
    clearTooltip()
end

function Ledger.LiveEventLedger_OpenSelectedTomeEntry()
    local selectedKey = getSelectedEventKey()
    local event = selectedKey and ensureLedger().events[selectedKey] or nil
    if type(event) ~= "table" or event.eventId == nil then
        chatPrint("No live event selected.")
        return false
    end

    local eventId = tonumber(event.eventId) or event.eventId
    if type(TomeWindow) == "table" and type(TomeWindow.OpenTomeToEntry) == "function" then
        local section = GameData and GameData.Tome and GameData.Tome.SECTION_LIVE_EVENT
        local ok = pcall(TomeWindow.OpenTomeToEntry, section, eventId)
        if ok then
            return true
        end
    end

    if type(TomeWindow) == "table"
        and type(TomeWindow.SetState) == "function"
        and TomeWindow.PAGE_LIVE_EVENT ~= nil then
        if type(WindowSetShowing) == "function" then
            pcall(WindowSetShowing, "TomeWindow", true)
        end
        local ok = pcall(TomeWindow.SetState, TomeWindow.PAGE_LIVE_EVENT, { eventId })
        if ok then
            return true
        end
    end

    chatPrint("Tome live-event page is not available yet.")
    return false
end

function Ledger.LiveEventLedger_ShowDemo(realmName)
    clearDemoRows()
    if not showWindowWithoutOpenRefresh() then
        return false
    end

    local selectedKey = getSelectedEventKey()
    if selectedKey == nil then
        Ledger._windowDataReady = true
        Ledger._windowCanShowCachedData = true
        updateWindow()
        chatPrint("No live event selected.")
        return false
    end

    local normalizedRealm = realmName == "destruction" and "destruction" or "order"
    if not setDemoRows(selectedKey, normalizedRealm) then
        chatPrint("No live event selected.")
        return false
    end

    Ledger._windowDataReady = true
    Ledger._windowCanShowCachedData = true
    updateWindow()
    return true
end

local function printHelp()
    chatPrint("Commands: /lel, /lel refresh, /lel help")
    chatPrint("You can also right-click the Tome Live Events tab and choose Open Live Event Ledger.")
end

function Ledger.LiveEventLedger_HandleSlash(input)
    local command = string.lower(trim(input))
    local first = string.match(command, "^(%S+)") or ""

    if first == "" then
        Ledger.LiveEventLedger_Show()
        return
    end

    if first == "refresh" then
        clearDemoRows()
        unregisterDeferredOpenRefresh()
        captureAllLiveEvents()
        Ledger._windowDataReady = true
        updateWindow()
        chatPrint("Live-event ledger refreshed.")
        return
    end

    if first == "demoorder" then
        Ledger.LiveEventLedger_ShowDemo("order")
        return
    end

    if first == "demodestro" then
        Ledger.LiveEventLedger_ShowDemo("destruction")
        return
    end

    if first == "help" then
        printHelp()
        return
    end

    chatPrint("Unknown command: " .. first)
    printHelp()
end

function Ledger.LiveEventLedger_TryRegisterSlash()
    if Ledger._slashRegistered then
        return true
    end

    if type(LibSlash) ~= "table" then
        if not Ledger._slashMissingReported then
            chatPrint("LibSlash not found; /lel is unavailable.")
            Ledger._slashMissingReported = true
        end
        return false
    end

    local register = LibSlash.RegisterWSlashCmd
    if type(register) ~= "function" then
        register = LibSlash.RegisterSlashCmd
    end

    if type(register) ~= "function" then
        return false
    end

    register("lel", function(input) Ledger.LiveEventLedger_HandleSlash(input) end)

    Ledger._slashRegistered = true
    return true
end

local function registerEvent(eventId, handlerName)
    if eventId == nil or type(RegisterEventHandler) ~= "function" then
        return false
    end

    local ok = pcall(RegisterEventHandler, eventId, handlerName)
    return ok == true
end

function Ledger.LiveEventLedger_TryRegisterEvents()
    if Ledger._eventsRegistered then
        return true
    end

    if type(SystemData) ~= "table" or type(SystemData.Events) ~= "table" then
        return false
    end

    local registeredAny = false
    local handler = "LiveEventLedger.LiveEventLedger_OnLiveEventChanged"
    registeredAny = registerEvent(SystemData.Events.TOME_LIVE_EVENT_LOADED, handler) or registeredAny
    registeredAny = registerEvent(SystemData.Events.TOME_LIVE_EVENT_TASKS_UPDATED, handler) or registeredAny
    registeredAny = registerEvent(SystemData.Events.TOME_LIVE_EVENT_TASK_COUNTER_UPDATED, "LiveEventLedger.LiveEventLedger_OnTaskCounterUpdated") or registeredAny
    registeredAny = registerEvent(SystemData.Events.TOME_LIVE_EVENT_OVERALL_COUNTER_UPDATED, "LiveEventLedger.LiveEventLedger_OnOverallCounterUpdated") or registeredAny
    registeredAny = registerEvent(SystemData.Events.TOME_LIVE_EVENT_ENDED, "LiveEventLedger.LiveEventLedger_OnLiveEventEnded") or registeredAny
    registeredAny = registerEvent(SystemData.Events.ENTER_WORLD, handler) or registeredAny
    registeredAny = registerEvent(SystemData.Events.INTERFACE_RELOADED, handler) or registeredAny

    Ledger._eventsRegistered = registeredAny
    return registeredAny
end

function Ledger.LiveEventLedger_OnLiveEventChanged(eventId)
    if eventId ~= nil then
        captureLiveEvent(eventId)
    else
        captureAllLiveEvents()
    end
    if isWindowShowing(Ledger.WINDOW_NAME) then
        updateWindow()
    end
end

function Ledger.LiveEventLedger_OnTaskCounterUpdated(eventId)
    Ledger.LiveEventLedger_OnLiveEventChanged(eventId)
end

function Ledger.LiveEventLedger_OnOverallCounterUpdated(eventId)
    Ledger.LiveEventLedger_OnLiveEventChanged(eventId)
end

function Ledger.LiveEventLedger_OnLiveEventEnded(eventId)
    if eventId ~= nil then
        captureLiveEvent(eventId)
    else
        captureAllLiveEvents()
    end
    if isWindowShowing(Ledger.WINDOW_NAME) then
        updateWindow()
    end
end

function Ledger.LiveEventLedger_Initialize()
    ensureLedger()
    Ledger.LiveEventLedger_TryRegisterSlash()
    Ledger.LiveEventLedger_TryRegisterEvents()
    tryRegisterTomeBookmarkContextMenu()
    captureAllLiveEvents()
end

return Ledger
