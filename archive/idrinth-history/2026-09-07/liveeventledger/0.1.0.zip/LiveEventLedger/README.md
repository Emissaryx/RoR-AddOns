# LiveEventLedger

LiveEventLedger shows Tome live-event progress across your characters in one small account-wide window.

## Usage

- Open the ledger with `/lel`, or right-click the Tome Live Events tab and choose `Open Live Event Ledger`.
- Click a column header to sort; click the active header again to reverse it.
- Use `Open ToK` for the selected event's task details.
- Use `Refresh` to rescan the current character.

Only characters that have logged in with the addon enabled can appear. The dropdown shows events seen within the last 14 days; ended events are marked with ` - ended` once the game reports them ended. The box beside the dropdown is checked by default and controls whether ended events are shown.

## Slash Commands

- `/lel` opens the ledger.
- `/lel refresh` rescans current live-event data.
- `/lel help` shows the command list.

## Requirements

The stock Tome of Knowledge live-event UI is required. `LibSlash` is optional but required for slash commands.

## Changelog

### 0.1.0 - 2026-05-31 - Wholdar

- Initial release.
