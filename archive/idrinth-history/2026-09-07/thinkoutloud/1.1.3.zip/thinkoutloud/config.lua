-- Until I create some sort of GUI to configure these, you have to make do
-- with setting up your phrases in this file.
--
-- vim:ts=4:sw=4:sts=4:et:
--
--
-- Skill name must match exactly.
-- speakChance: (optional) override the main speakChance setting.
-- isUrgent: skill will always be spoken. Use only for spells cast rarely.
-- phrases: a set of phrases to randomly choose from.
--    channel: CMD_SAY, CMD_PARTY, CMD_TELL, CMD_EMOTE, CMD_SHOUT
--    text:    the text to be spoken
--    sayself: if false, then whenever you have yourself as your friendly
--             target, or no friendly target, this phrase will not be spoken.
--             (Except for heals, you'll probably want to leave this out)
--
-- Don't forget the commas.
-- Remember that skill names and phrase text strings must be prefixed with an L
-- String replacements:
--   %T - hostile target
--   %F - friendly target
--
-- [L"<skill  name>"] = {
--     speakChance = <chance>,
--     isUrgent = <true|false>,
--     phrases = {
--         {channel=<channel>, text=L"<text1>", sayself=<true|false>},
--         {channel=<channel>, text=L"<text2>", sayself=<true|false>},
--         {channel=<channel>, text=L"<text3>", sayself=<true|false>},
--     }
-- },
--
-- example:
--
-- [1] = {
--     name = L"'Ey, Quit Bleedin'",
--     isUrgent = false,
--     phrases = {
--         {channel=CMD_SAY, text=L"Quit bleedin', %F!", sayself=false},
--     }
-- },
--
--

TOL_CONFIGS = {}

local CMD_SAY = ThinkOutLoud.CMD_SAY
local CMD_TELL = ThinkOutLoud.CMD_TELL
local CMD_PARTY = ThinkOutLoud.CMD_PARTY
local CMD_EMOTE = ThinkOutLoud.CMD_EMOTE
local CMD_SHOUT = ThinkOutLoud.CMD_SHOUT


--------------------------------------------------------------------------
--  Edit below this line.
--------------------------------------------------------------------------

TOL_CONFIGS["DEFAULT"] = {}
TOL_CONFIGS["DEFAULT"].speakChance = 0.05
TOL_CONFIGS["DEFAULT"].skills = {

-- 50% chance of saying Aiiyeeeee! when fleeing.
[1] = {
    name = L"Flee",
    speakChance = 0.50,
    isUrgent = false,
    phrases = {
        {channel=CMD_SAY, text=L"Aiiyeeeee!"},
    }
},


} -- end of TOL_CONFIGS["DEFAULT"].skills, don't delete this bracket. :P

--------------------------------------------------------------------------
-- Stop Editing here
--------------------------------------------------------------------------


-- The profile I use for my shaman.

TOL_CONFIGS["thanners-shaman"] = {}
TOL_CONFIGS["thanners-shaman"].speakChance = 0.05
TOL_CONFIGS["thanners-shaman"].skills = {

[1] = {
    name = L"'Ey, Quit Bleedin'",
    isUrgent = false,
    phrases = {
        {channel=CMD_SAY, text=L"'Ey! Quit yer bleedin'!", sayself=false},
        {channel=CMD_SAY, text=L"Quit yer bleedin', %F!", sayself=false},
    },
},

[2] = {
    name = L"Gork'll Fix It",
    isUrgent = false,
    phrases = {
        {channel=CMD_SAY, text=L"I'll fix ya right up!", sayself=false},
        {channel=CMD_SAY, text=L"Gork'll fix ya, %F!", sayself=false},
        {channel=CMD_SAY, text=L"Gork'll fix it!"},
    }
},

[3] = {
    name = L"'Ere We Go!",
    speakChance = 0.20,
    isUrgent = false,
    phrases = {
        {channel=CMD_SAY, text=L"'Ere we go!"},
    }
},

[4] = {
    name = L"Bunch o' Waaagh",
    speakChance = 0.15,
    isUrgent = false,
    phrases = {
        {channel=CMD_SAY, text=L"Zzzzaaap!"},
        {channel=CMD_SAY, text=L"Imma give %T a bunch o' Waaagh!"},
    }
},

[5] = {
    name = L"Bigger, Better, An' Greener",
    speakChance = 0.20,
    isUrgent = false,
    phrases = {
        {channel=CMD_SAY, text=L"%F, youz gonna be bigga and greena in no time!", sayself=false},
        {channel=CMD_SAY, text=L"%F, I'z gonna make you moar green!", sayself=false},
    }
},

-- Always announce when rezzing someone.
[6] = {
    name = L"Gedup!",
    speakChance = 1.00,
    isUrgent = true,
    phrases = {
        {channel=CMD_SAY, text=L"Gedup, %F! Youze still got werk ta do!", sayself=false},
        {channel=CMD_SAY, text=L"Oi, gedup, %F!", sayself=false},
    }
},

-- 50% chance of screaming like a little.. goblin when fleeing.
[7] = {
    name = L"Flee",
    speakChance = 0.50,
    isUrgent = false,
    phrases = {
        {channel=CMD_SAY, text=L"Aiiyeeeee!"},
    }
},


} -- end of TOL_CONFIGS["thanners-shaman"].skills

