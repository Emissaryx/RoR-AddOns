<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">

	<UiMod name="CNC" version="1.0" date="12/22/08">
		<Author name="ChaosInc" email="Not Given" />		
		<Description text="Hides " />
		
		<Dependencies/>
		
		<Files>
			<File name="CNC.lua"/>
		</Files>
		
		<OnInitialize>
			<CallFunction name="CNC.OnInit"/>
		</OnInitialize>
		
	</UiMod>
</ModuleFile>
		