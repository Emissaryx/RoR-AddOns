--[[
	This application is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    The applications is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with the applications.  If not, see <http://www.gnu.org/licenses/>.
--]]

if not WCDP then WCDP = {} end

local debug = false
--[===[@debug@
debug = true
--@end-debug@]===]

local alpha = false
--[===[@alpha@
alpha = true
--@end-alpha@]===]

local T					= LibStub( "WAR-AceLocale-3.0" ) : GetLocale( "wcdp", debug )
local LSA				= LibStub( "LibSharedAssets" )

WCDP.db					= nil
local db				= nil

local VERSION 			= { MAJOR = 2, MINOR = 2, REV = 6 }
local DisplayVersion 	= string.format( "%d.%d.%d", VERSION.MAJOR, VERSION.MINOR, VERSION.REV )
WCDP.DisplayVersion		= DisplayVersion

if( debug ) then
	DisplayVersion 			= DisplayVersion .. " Dev Build"
else
	DisplayVersion 			= DisplayVersion .. " r" .. ( tonumber( "73" ) or 0 )

	if( alpha ) then
		DisplayVersion = DisplayVersion .. "-alpha"
	end
end

local firstLoad 				= true
local blackList					= {}
local whiteList					= {}

local upgradeProfile

-- ============================================================
-- CHANTIER 1 (2.2.0): 4 independent pulse anchors.
-- Each ability category routes to its own runtime frame and
-- Layout Editor anchor.  Alpha/speed settings stay global
-- (shared across all windows) so the UX stays simple.
-- ============================================================

local CATEGORY_WINDOWS = {
	abilities = { runtime = "WCDPFrame",        layout = "WCDPLayoutFrame"        },
	morale    = { runtime = "WCDPMoraleFrame",   layout = "WCDPMoraleLayoutFrame"  },
	pet       = { runtime = "WCDPPetFrame",      layout = "WCDPPetLayoutFrame"     },
	health    = { runtime = "WCDPHealthFrame",   layout = "WCDPHealthLayoutFrame"  },
}

local function defaultAnchor( xOff, yOff )
	return {
		point    = "center",
		relwin   = "Root",
		relpoint = "center",
		scale    = 0.75,
		x        = xOff or 0,
		y        = yOff or 0,
		dx       = 192,
		dy       = 192,
	}
end

WCDP.DefaultSettings =
{
	general =
	{
		debug					= false,
		version					= VERSION,
		testmode				= false,
		enablewhitelist			= false,
		enableblacklist			= false,
		sound					= true,
		soundKey				= "HELP_TIPS_NEW",
		showMinimapButton		= true,
	},

	-- Original abilities anchor (key kept as "anchor" for backward compatibility —
	-- players who moved it in 2.1.x will keep their saved position).
	anchor = defaultAnchor( 0, 0 ),

	-- Per-category anchors (new in 2.2.0).  Default positions are spread out so
	-- they do not stack on top of each other at first load.
	moraleAnchor  = defaultAnchor( 210, 0   ),
	petAnchor     = defaultAnchor( 0,   210 ),
	healthAnchor  = defaultAnchor( 210, 210 ),

	alpha =
	{
		start						= .2,
		finish						= .6,
		speed						= .2,
	},

	blacklist						= {},
	whitelist						= {},

	abilities =
	{
		actions	= {
			enabled					= true,
			mincooldown				= 4,
			sound					= true,
		},
		morale	= {
			enabled					= true,
			mincooldown				= 4,
			onavailable				= true,
			sound					= true,
		},
		pet	= {
			enabled					= true,
			mincooldown				= 4,
			sound					= true,
		},
	},

	-- CHANTIER 3 (2.2.0): low-health pulse.
	-- Data source: GameData.Player.hitPoints.current / .maximum
	-- Confirmed in Game\ROR: pure/Source/PurePlayer.lua l278,
	-- BuffHead/Libraries/LibGroup/LibGroup.lua l493,
	-- MiracleGrowLight/MiracleGrowLight.lua l159,
	-- Enemy/Code/Core/Groups/EnemyPlayer.lua l439.
	-- Polled via OnUpdate(timePassed) — no PLAYER_HEALTH_UPDATED event for the
	-- player's own HP was found in any Game\ROR addon.
	lowhealth =
	{
		enabled        = true,
		threshold      = 10,    -- % HP at or below which the alert fires
		repeatInterval = 1.5,   -- seconds between repeat pulses while below threshold
		sound          = true,  -- play the global soundKey alongside each health pulse
	},

}

local _lastMoraleAbilityCast		= -1
local _lastAbilityPulsed      		= 0
--
-- FIX (2.0.5): peak-cooldown tracking so we survive client overwrites of m_MaxCooldown.
--
local activeCooldowns				= {}
local abilityTypeCache				= {}
--
-- FEATURE (2.0.7): morale-available tracking (rank 1-4).
--
local _moraleReady					= {}
--
-- FIX (2.2.0 / CHANTIER 4): time-based sound queue.
--
-- ROOT CAUSE of the 2.1.3 failure:
--   _soundCooldown was a "hook-call counter" decremented once per call to
--   OnAbilityUpdate().  OnAbilityUpdate is hooked onto ActionButton.UpdateCooldownAnimation
--   and is invoked once per *visible action button* per frame — typically 10-30 times
--   per frame on a normal setup.  "30 hook calls" therefore collapsed in only 1-3 real
--   frames, making the inter-sound delay far too short (often firing both sounds on the
--   same audio tick).  Worse, when a player has no action buttons visible (e.g. only
--   morale or pet frames active that frame), OnAbilityUpdate is never called and queued
--   sounds are stuck indefinitely.
--
-- FIX:
--   _soundCooldown is now a float (seconds), decremented by the real elapsed time
--   supplied by OnUpdate(timePassed).  OnUpdate is called exactly once per rendered
--   frame via the WCDPTimerFrame window (pattern from TidyQueue in Game\ROR).
--   SOUND_COOLDOWN_SECS = 0.15 s (~4-5 frames at 30 fps) is long enough for the
--   client's audio slot to reset, and imperceptibly short for the player.
--
local _soundQueue    				= {}
local _soundCooldown 				= 0

local SOUND_COOLDOWN_SECS			= 0.15

--
-- CHANTIER 3 (2.2.0): low-health state.
--
local _lowHealthActive				= false
local _lowHealthTimer				= 0
local _playerDead					= false

local cooldownLookup				= {}
local GENERAL_GCD					= 1.61

--
-- FEATURE (2.1.2): selectable pulse sounds.
--
WCDP.SoundList = {
	{ key = "NONE",          label = "None (disabled)"     },
	{ key = "HELP_TIPS_NEW", label = "Help Tips (default)" },
}

function WCDP.GetVersion() return DisplayVersion end

function WCDP.OnInitialize()
	RegisterEventHandler( SystemData.Events.RELOAD_INTERFACE, "WCDP.OnLoad" )
	RegisterEventHandler( SystemData.Events.LOADING_END, "WCDP.OnLoad" )
end

function WCDP.OnLoad()
	if( firstLoad ) then
		WCDP.InitProfiles()

		local profileIdx, _ = WCDP.GetCurrentProfile()

		WCDP.db = WCDP.GetProfileDataForUse( profileIdx )
		db = WCDP.db

		upgradeProfile()

		WCDP.Debug( "Registering slash commands" )

		WCDPConfig.OnLoad()

		WCDP.UpdateAllLayoutWindows()
		WCDP.UpdateAllRuntimeWindows()

		for cat, wins in pairs( CATEGORY_WINDOWS ) do
			WindowSetAlpha( wins.runtime, 0 )
			WindowSetShowing( wins.runtime, true )
		end

		table.insert( LayoutEditor.EventHandlers, WCDP.OnLayoutEditorFinished )

		RegisterEventHandler( SystemData.Events.CUSTOM_UI_SCALE_CHANGED, "WCDP.OnUIScaleChange" )
		RegisterEventHandler( SystemData.Events.PLAYER_BEGIN_CAST, "WCDP.OnPlayerBeginCast" )
		RegisterEventHandler( SystemData.Events.PLAYER_MORALE_UPDATED, "WCDP.OnPlayerMoraleUpdated" )

		WCDP.__ActionButton_UpdateCooldownAnimation					= ActionButton.UpdateCooldownAnimation
		ActionButton.UpdateCooldownAnimation 						= WCDP.OnAbilityUpdate

		WCDP.__MoraleButton_Update									= MoraleButton.Update
		MoraleButton.Update					 						= WCDP.OnMoraleUpdate

		local init = WStringToString( T["Wikki's Cooldown Pulse %s initialized."] )
		WCDP.Print( init:format( DisplayVersion ) )

		if( LibSlash ~= nil and type( LibSlash.RegisterSlashCmd ) == "function" ) then
			LibSlash.RegisterSlashCmd( "wcdp", WCDP.Slash )
			LibSlash.RegisterSlashCmd( "wcdpconfig", WCDP.Slash )
			LibSlash.RegisterSlashCmd( "showwcdp", WCDP.Slash )
			WCDP.Print( T["(Wikki's Cooldown Pulse) use /wcdp to bring up the configuration window."] )
		end

		d( "Wikki's Cooldown Pulse loaded." )

		if( LayoutEditor ~= nil and DoesWindowExist( "WCDPMinimapButton" ) ) then
			LayoutEditor.RegisterWindow( "WCDPMinimapButton", L"WCDP Icon", L"Wikki's Cooldown Pulse minimap icon", false, false, true, nil )
		end

		if( DoesWindowExist( "WCDPMinimapButton" ) ) then
			WindowSetShowing( "WCDPMinimapButton", db.general.showMinimapButton ~= false )
		end

		firstLoad = false
	end

	WCDP.Reinitialize()
end

function WCDP.Reinitialize()
	blackList = {}
	if( db.general.enableblacklist ) then
		for idx, ability in ipairs( db.blacklist ) do
			blackList[ability] = true
		end
	end

	whiteList = {}
	if( db.general.enablewhitelist ) then
		for idx, ability in ipairs( db.whitelist ) do
			whiteList[ability] = true
		end
	end

	cooldownLookup = {}
	cooldownLookup[Player.AbilityType.ABILITY] 	= db.abilities.actions.mincooldown
	cooldownLookup[Player.AbilityType.MORALE] 	= db.abilities.morale.mincooldown
	cooldownLookup[Player.AbilityType.PET] 		= db.abilities.pet.mincooldown

	activeCooldowns		= {}
	abilityTypeCache	= {}
	_moraleReady		= {}
	_soundQueue			= {}
	_soundCooldown		= 0
	_lowHealthActive	= false
	_lowHealthTimer		= 0
	_playerDead			= false
end

function WCDP.OnProfileChanged()
	local profileIdx, currentProfileName = WCDP.GetCurrentProfile()

	WCDP.db = WCDP.GetProfileDataForUse( profileIdx )
	db = WCDP.db

	upgradeProfile()

	WCDP.UpdateAllLayoutWindows()
	WCDP.UpdateAllRuntimeWindows()

	WCDP.Reinitialize()

	if( DoesWindowExist( "WCDPMinimapButton" ) ) then
		WindowSetShowing( "WCDPMinimapButton", db.general.showMinimapButton ~= false )
	end

	WCDP.Print( L"(WCDP) " .. T["Active Profile:"] .. L" '" .. currentProfileName .. L"'" )
end

-- ============================================================
-- Window management (generalized for all categories)
-- ============================================================

local function getAnchorData( category )
	if category == "abilities" then return db.anchor end
	if category == "morale"    then return db.moraleAnchor end
	if category == "pet"       then return db.petAnchor end
	if category == "health"    then return db.healthAnchor end
	return db.anchor
end

function WCDP.UpdateLayoutWindowForCategory( category )
	local wins = CATEGORY_WINDOWS[category]
	if wins == nil then return end
	local anc = getAnchorData( category )
	local layoutWin = wins.layout

	local label, desc
	if     category == "abilities" then
		label = L"WCDP Anchor"
		desc  = L"Wikki's Cooldown Pulse Anchor"
	elseif category == "morale" then
		label = L"WCDP Anchor - Morale"
		desc  = L"Wikki's Cooldown Pulse Anchor (Morale)"
	elseif category == "pet" then
		label = L"WCDP Anchor - Pet"
		desc  = L"Wikki's Cooldown Pulse Anchor (Pet)"
	elseif category == "health" then
		label = L"WCDP Anchor - Low Health"
		desc  = L"Wikki's Cooldown Pulse Anchor (Low Health Alert)"
	end

	LayoutEditor.UnregisterWindow( layoutWin )
	WindowClearAnchors( layoutWin )
	WindowAddAnchor( layoutWin, anc.point, anc.relwin, anc.relpoint, anc.x, anc.y )
	WindowSetScale( layoutWin, anc.scale )
	WindowSetDimensions( layoutWin, anc.dx, anc.dy )
	LayoutEditor.RegisterWindow( layoutWin, label, desc, true, true, false, nil )
end

function WCDP.UpdateRuntimeWindowForCategory( category )
	local wins = CATEGORY_WINDOWS[category]
	if wins == nil then return end

	-- FIX (2.2.6 r66): anchor the runtime frame TO the layout frame rather than to Root.
	-- The previous approach copied anc.x / anc.y from db and re-anchored to Root, which
	-- broke as soon as the user moved the LE anchor (the layout frame moved but the runtime
	-- frame stayed at the old Root-relative position until the next reload).
	-- By anchoring topleft→topleft / bottomright→bottomright to the layout frame, the
	-- runtime frame tracks the LE anchor automatically — exactly like WCDPFrameImageSquare
	-- tracks $parent in Templates.xml.
	WindowClearAnchors( wins.runtime )
	WindowAddAnchor( wins.runtime, "topleft",     wins.layout, "topleft",     0, 0 )
	WindowAddAnchor( wins.runtime, "bottomright", wins.layout, "bottomright", 0, 0 )
end

function WCDP.UpdateAllLayoutWindows()
	for cat, _ in pairs( CATEGORY_WINDOWS ) do
		WCDP.UpdateLayoutWindowForCategory( cat )
	end
end

function WCDP.UpdateAllRuntimeWindows()
	for cat, _ in pairs( CATEGORY_WINDOWS ) do
		WCDP.UpdateRuntimeWindowForCategory( cat )
	end
end

-- Legacy single-category wrappers kept for config Apply compatibility.
function WCDP.UpdateLayoutWindow()
	WCDP.UpdateLayoutWindowForCategory( "abilities" )
end

function WCDP.UpdateRuntimeWindow()
	WCDP.UpdateRuntimeWindowForCategory( "abilities" )
end

function WCDP.OnLayoutEditorFinished( editorCode )
	-- FIX (2.2.6 r65): use LayoutEditor.EDITING_END; fallback to 2 if nil.
	local editingEnd = (LayoutEditor and LayoutEditor.EDITING_END) or 2
	if( editorCode == editingEnd ) then
		for cat, wins in pairs( CATEGORY_WINDOWS ) do
			local anc = getAnchorData( cat )
			-- FIX (2.2.6 r73): WindowGetAnchor returns (point, relativePoint, relativeWindow, x, y).
			-- Previous code stored them as (point, relwin, relpoint, x, y) which SWAPPED relwin and
			-- relpoint.  WindowAddAnchor expects (win, point, relativeWindow, relativePoint, x, y),
			-- so passing "center" as relativeWindow caused the frame to land at top-left (no window
			-- named "center" exists).  Swap fixed here: _rpt=2nd return, _rwin=3rd return.
			local _pt, _rpt, _rwin, _x, _y = WindowGetAnchor( wins.layout, 1 )
			anc.point    = _pt
			anc.relwin   = _rwin   -- relativeWindow (e.g. "Root")
			anc.relpoint = _rpt    -- relativePoint  (e.g. "center", "left")
			anc.x        = _x
			anc.y        = _y
			anc.dx, anc.dy = WindowGetDimensions( wins.layout )
			anc.scale       = WindowGetScale( wins.layout )
		end
		WCDP.UpdateAllRuntimeWindows()
	end
end

function WCDP.OnUIScaleChange()
	WCDP.UpdateAllLayoutWindows()
	WCDP.UpdateAllRuntimeWindows()
	WCDP.OnLayoutEditorFinished( LayoutEditor.EDITING_END )
end

-- ============================================================
-- Ability hooks
-- ============================================================

function WCDP.OnPlayerBeginCast( abilityId, isChannel, desiredCastTime, averageLatency )
	if( desiredCastTime == 0 ) then
		local ok, abilityData = pcall( Player.GetAbilityData, abilityId )
		if ok and abilityData ~= nil and abilityData.abilityType == Player.AbilityType.MORALE then
			WCDP.Debug( "Storing morale ability id: " .. tostring( abilityId ) )
			_lastMoraleAbilityCast = abilityId
		end
	end
end

function WCDP.OnAbilityUpdate( ... )
	local self = ...
	local initialMaxCooldown = self.m_MaxCooldown
	WCDP.__ActionButton_UpdateCooldownAnimation( ... )
	WCDP.PerformAbilityUpdate( self.m_ActionId, self.m_Cooldown, initialMaxCooldown, self.m_MaxCooldown )
end

function WCDP.OnMoraleUpdate( ... )
	local self = ...
	local initialMaxCooldown = self.m_MaxCooldown
	WCDP.__MoraleButton_Update( ... )
	if( _lastMoraleAbilityCast ~= self.m_AbilityId ) then return end
	WCDP.PerformAbilityUpdate( self.m_AbilityId, self.m_Cooldown, initialMaxCooldown, self.m_MaxCooldown )
end

-- ============================================================
-- Morale helpers
-- ============================================================

function WCDP.MoraleAllowed( abilityId )
	if( abilityId == nil ) then return false end
	if( not db.abilities.morale.enabled ) then return false end

	if( db.general.enablewhitelist ) then
		return whiteList[abilityId] ~= nil
	end

	if( db.general.enableblacklist and blackList[abilityId] ~= nil ) then
		return false
	end

	return true
end

function WCDP.PulseMoraleRank( rank )
	local _, slotted = GetMoraleBarData( rank )
	if( slotted == nil ) then return end

	local abilityData = GetAbilityData( slotted )
	if( abilityData == nil or abilityData.id == nil ) then return end

	if( not WCDP.MoraleAllowed( abilityData.id ) ) then return end

	WCDP.Debug( "Morale rank " .. tostring( rank ) .. " available (abilityId " .. tostring( abilityData.id ) .. ") - pulsing." )
	WCDP.FirePulse( abilityData.id, "morale" )
end

function WCDP.OnPlayerMoraleUpdated( moralePercent, moraleLevel )
	if( db == nil ) then return end
	if( not db.abilities.morale.enabled ) then return end
	if( not db.abilities.morale.onavailable ) then return end

	local perc = math.abs( moralePercent or 0 )

	for rank = 1, 4 do
		local threshold = GetMoralePercentForLevel( rank )

		if( threshold ~= nil and threshold > 0 ) then
			local cooldown = GetMoraleCooldown( rank )
			local calc = ( perc / threshold ) * 100
			local gcd = ActionButton.GLOBAL_COOLDOWN or GENERAL_GCD

			local ready = ( calc >= 99 ) and ( cooldown ~= nil and cooldown <= gcd )

			if( ready and not _moraleReady[rank] ) then
				WCDP.PulseMoraleRank( rank )
			end

			_moraleReady[rank] = ready
		else
			_moraleReady[rank] = false
		end
	end
end

-- ============================================================
-- Core update logic
-- ============================================================

function WCDP.PerformAbilityUpdate( abilityId, cooldown, initialMaxCooldown, currentMaxCooldown )
	-- FIX (2.2.0-debug): log buttons that have a cooldown but no abilityId (item slots?).
	if( abilityId == nil ) then
		if( cooldown ~= nil and cooldown > GENERAL_GCD ) then
			WCDP.Debug( "PerformAbilityUpdate: nil abilityId with cooldown=" .. tostring( cooldown ) .. " maxCd=" .. tostring( initialMaxCooldown ) )
		end
		return
	end
	if( cooldown == nil ) then return end

	if( blackList[abilityId] ~= nil ) then return end

	local abilityType = abilityTypeCache[abilityId]
	if( abilityType == nil ) then
		local ok, abilityData = pcall( Player.GetAbilityData, abilityId )

		if not ok or abilityData == nil or abilityData.abilityType == nil then
			return  -- FIX (2.1.1): transient nil; retry next frame
		end

		abilityType = abilityData.abilityType
		abilityTypeCache[abilityId] = abilityType
	end

	if cooldownLookup[abilityType] == nil then
		-- FIX (2.2.0-debug): log unknown type once, then blacklist to silence future calls.
		-- Enables discovery of item/potion abilityType constants in-game.
		WCDP.Debug( "Unknown abilityType " .. tostring( abilityType ) .. " for abilityId " .. tostring( abilityId ) .. " (cd=" .. tostring( cooldown ) .. " maxCd=" .. tostring( initialMaxCooldown ) .. ") -- blacklisting." )
		blackList[abilityId] = true
		return
	end

	if( whiteList[abilityId] == nil ) then
		if( db.general.enablewhitelist ) then
			return
		else
			if( ( abilityType == Player.AbilityType.ABILITY and not db.abilities.actions.enabled ) or
				( abilityType == Player.AbilityType.MORALE  and not db.abilities.morale.enabled  ) or
				( abilityType == Player.AbilityType.PET     and not db.abilities.pet.enabled     ) ) then
				blackList[abilityId] = true
				return
			end
			whiteList[abilityId] = true
		end
	end

	-- FIX (2.0.6): morale abilities handled separately.
	if( abilityType == Player.AbilityType.MORALE ) then
		if( db.abilities.morale.onavailable ) then return end

		if( initialMaxCooldown ~= nil
			and initialMaxCooldown > GENERAL_GCD
			and initialMaxCooldown >= cooldownLookup[abilityType]
			and cooldown <= 0 ) then

			if( _lastAbilityPulsed == _lastMoraleAbilityCast and cooldown < GENERAL_GCD ) then
				return
			end

			WCDP.Debug( "Morale AbilityId:  " .. tostring( abilityId ) .. " available.  Max: " .. tostring( initialMaxCooldown ) )
			WCDP.FirePulse( abilityId, "morale" )
		end
		return
	end

	-- FIX (2.0.5): peak-cooldown tracking for abilities and pets.
	if( cooldown > 0 ) then
		local peak = activeCooldowns[abilityId] or 0
		if( cooldown > peak ) then peak = cooldown end
		if( initialMaxCooldown ~= nil and initialMaxCooldown > peak ) then peak = initialMaxCooldown end
		if( currentMaxCooldown ~= nil and currentMaxCooldown > peak ) then peak = currentMaxCooldown end
		activeCooldowns[abilityId] = peak
		return
	end

	local peak = activeCooldowns[abilityId]
	if( peak == nil ) then return end

	activeCooldowns[abilityId] = nil

	if( peak <= GENERAL_GCD or peak < cooldownLookup[abilityType] ) then return end

	WCDP.Debug( "AbilityId:  " .. tostring( abilityId ) .. " finished cooldown.  Peak: " .. tostring( peak ) )

	-- CHANTIER 1 (2.2.0): route pet abilities to the Pet window.
	local category = "abilities"
	if( abilityType == Player.AbilityType.PET ) then
		category = "pet"
	end

	WCDP.FirePulse( abilityId, category )
end

-- ============================================================
-- CHANTIER 1 (2.2.0): FirePulse routes to the correct window.
-- ============================================================

function WCDP.FirePulse( abilityId, category )
	category = category or "abilities"
	local wins = CATEGORY_WINDOWS[category]
	if wins == nil then return end

	local runtimeWin = wins.runtime

	-- Health alert: no ability icon, just animate the frame.
	if category == "health" then
		if type( WindowStopAlphaAnimation ) == "function" then WindowStopAlphaAnimation( runtimeWin ) end
		WindowStartAlphaAnimation( runtimeWin, Window.AnimationType.LOOP, db.alpha.start, db.alpha.finish, db.alpha.speed, true, 0, 1 )
		if db.lowhealth.sound ~= false then
			WCDP.PlayPulseSound()
		end
		return
	end

	local ok, abilityData = pcall( Player.GetAbilityData, abilityId )
	if not ok or abilityData == nil then return end

	local ok2, displayTexture = pcall( GetIconData, abilityData.iconNum )
	if not ok2 or displayTexture == nil then return end

	pcall( DynamicImageSetTexture, runtimeWin .. "ImageSquare", displayTexture, 0, 0 )
	if type( WindowStopAlphaAnimation ) == "function" then WindowStopAlphaAnimation( runtimeWin ) end
	WindowStartAlphaAnimation( runtimeWin, Window.AnimationType.LOOP, db.alpha.start, db.alpha.finish, db.alpha.speed, true, 0, 1 )
	local playSound = true
	if category == "morale" then
		playSound = db.abilities.morale.sound ~= false
	elseif category == "abilities" then
		playSound = db.abilities.actions.sound ~= false
	elseif category == "pet" then
		playSound = db.abilities.pet.sound ~= false
	end
	if playSound then
		WCDP.PlayPulseSound()
	end
	_lastAbilityPulsed = abilityId
end

-- ============================================================
-- CHANTIER 3 (2.2.0): Low-health pulse (polled via OnUpdate).
-- ============================================================

function WCDP.CheckLowHealthPulse( dt )
	if db == nil then return end
	if not db.lowhealth.enabled then return end

	local hp = GameData and GameData.Player and GameData.Player.hitPoints
	if hp == nil then return end

	local current = hp.current
	local maximum = hp.maximum
	if current == nil or maximum == nil or maximum <= 0 then return end

	-- Stop pulse when player is dead (hp.current == 0).
	if current <= 0 then
		if not _playerDead then
			_playerDead      = true
			_lowHealthActive = false
			_lowHealthTimer  = 0
			WindowSetShowing( CATEGORY_WINDOWS.health.runtime, false )
		end
		return
	end

	-- Player just resurrected: restore the health frame visibility.
	if _playerDead then
		_playerDead = false
		WindowSetShowing( CATEGORY_WINDOWS.health.runtime, true )
	end

	local pct = ( current / maximum ) * 100
	local threshold = db.lowhealth.threshold or 10

	if pct <= threshold then
		if not _lowHealthActive then
			_lowHealthActive = true
			_lowHealthTimer  = 0
		end
		_lowHealthTimer = _lowHealthTimer - dt
		if _lowHealthTimer <= 0 then
			_lowHealthTimer = db.lowhealth.repeatInterval or 1.5
			WCDP.FirePulse( nil, "health" )
		end
	else
		_lowHealthActive = false
		_lowHealthTimer  = 0
	end
end

-- ============================================================
-- CHANTIER 5 (2.2.0): Potion cooldown pulse.
-- Detection: DataUtils.GetItems() → itemData.bonus[n].cooldownTimeLeft.
-- API confirmed in references/PotionBar (Game\ROR) — Main.lua l483-527.
-- ============================================================

-- ============================================================
-- CHANTIER 4 (2.2.0): Time-based sound queue via OnUpdate.
-- ============================================================

function WCDP.TickSoundQueue( dt )
	if dt ~= nil and dt > 0 then
		_soundCooldown = math.max( 0, _soundCooldown - dt )
	end
	if _soundCooldown <= 0 and #_soundQueue > 0 then
		local key = table.remove( _soundQueue, 1 )
		WCDP.PlayPulseSoundDirect( key )
	end
end

-- Called exactly once per rendered frame by WCDPTimerFrame OnUpdate handler.
function WCDP.OnUpdate( timePassed )
	WCDP.TickSoundQueue( timePassed )
	WCDP.CheckLowHealthPulse( timePassed )
end

function WCDP.GetSoundQueueState()
	return _soundCooldown, _soundQueue
end

function WCDP.GetPotionTrackingState()
	return _potionTracked, _potionScanPending
end

function WCDP.PlayPulseSoundDirect( key )
	pcall( function()
		if( type( PlaySound ) == "function" and GameData ~= nil and GameData.Sound ~= nil ) then
			local soundId = GameData.Sound[key]
			if( soundId ~= nil ) then
				PlaySound( soundId )
			end
		elseif( Sound ~= nil and type( Sound.Play ) == "function" ) then
			local soundId = GameData.Sound[key]
			if( soundId ~= nil ) then
				Sound.Play( soundId )
			end
		end
	end )
	_soundCooldown = SOUND_COOLDOWN_SECS
end

function WCDP.PlayPulseSound()
	if( db == nil or not db.general.sound ) then return end

	local key = db.general.soundKey or "HELP_TIPS_NEW"
	if( key == "NONE" ) then return end

	if( _soundCooldown > 0 ) then
		table.insert( _soundQueue, key )
		return
	end

	WCDP.PlayPulseSoundDirect( key )
end

-- ============================================================
-- Slash / config / minimap
-- ============================================================

function WCDP.Slash( input )
	if( input ~= nil ) then
		local arg = WStringToString( towstring( input ) )
		arg = string.lower( arg or "" )
		arg = string.gsub( arg, "%s", "" )

		if( arg == "debug" ) then
			if( WCDP.db ~= nil ) then
				WCDP.db.general.debug = not WCDP.db.general.debug
				WCDP.Print( L"(WCDP) Debug messages " .. ( WCDP.db.general.debug and L"ENABLED" or L"DISABLED" ) .. L"." )
			end
			return
		end

	end

	WCDP.ToggleConfig()
end

function WCDP.ToggleConfig()
	if( DoesWindowExist( WCDPConfig.GetWindowName() ) ) then
		local configName = WCDPConfig.GetWindowName()
		-- FIX 2.2.0: savesettings may restore a pre-2.2.0 window height of 500px.
		-- Check on every open so the fix works regardless of savesettings timing.
		local _cw, _ch = WindowGetDimensions( configName )
		if _ch < 540 then
			WindowSetDimensions( configName, math.max( _cw, 800 ), 540 )
			WCDPConfig.OnResizeEnd()
		end
		local nowShowing = WindowGetShowing( configName )
		-- FIX 2.2.3: refresh UI from db every time the config opens so that
		-- (a) changes made but not Applied are discarded, and
		-- (b) settings written directly to db outside the config UI
		--     (e.g. HideMinimapButton) are immediately reflected.
		if not nowShowing then
			WCDPConfig.RevertDialog()
		end
		WindowSetShowing( configName, not nowShowing )
	end
end

function WCDP.UI_Icon_OnLButtonUp()
	WCDP.ToggleConfig()
end

function WCDP.UI_Icon_OnRButtonUp()
	EA_Window_ContextMenu.CreateContextMenu( "WCDPMinimapButton" )
	EA_Window_ContextMenu.AddMenuItem( T["Configuration"], WCDP.ToggleConfig, false, true )
	EA_Window_ContextMenu.AddMenuDivider()
	EA_Window_ContextMenu.AddMenuItem( T["Hide Minimap Icon"], WCDP.HideMinimapButton, false, true )
	EA_Window_ContextMenu.Finalize()
end

function WCDP.HideMinimapButton()
	if( db ~= nil ) then
		db.general.showMinimapButton = false
	end
	WindowSetShowing( "WCDPMinimapButton", false )
end

function WCDP.UI_Icon_OnMouseOver()
	if( Tooltips == nil ) then return end
	Tooltips.CreateTextOnlyTooltip( "WCDPMinimapButton" )
	Tooltips.SetTooltipText( 1, 1, L"Wikki's Cooldown Pulse" )
	Tooltips.SetTooltipText( 2, 1, L"Click to open the configuration." )
	Tooltips.AnchorTooltip( Tooltips.ANCHOR_CURSOR )
	Tooltips.Finalize()
end

function WCDP.Print( str )
	EA_ChatWindow.Print( towstring( tostring( str ) ), ChatSettings.Channels[SystemData.ChatLogFilters.SAY].id );
end

function WCDP.Debug(str)
	if( db ~= nil and db.general.debug ) then
		EA_ChatWindow.Print( towstring( "(WCDP Debug) " .. tostring( str ) ), ChatSettings.Channels[SystemData.ChatLogFilters.SAY].id );
	end
end

function upgradeProfile()
	local oldVersion = db.general.version
	db.general.version = VERSION
end
