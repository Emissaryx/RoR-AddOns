--[[
	This application is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    The applications is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with the applications.  If not, see <http://www.gnu.org/licenses/>.
--]]

--
-- The localization information present within this file is automatically
-- packaged by the CurseForge packager.
--
-- Incorrect or missing translations can be updated here:
-- http://war.curseforge.com/projects/wcdb/localization/
--

local debug = false
--[===[@debug@
debug = true
--@end-debug@]===]

local T = LibStub( "WAR-AceLocale-3.0" ):NewLocale( "wcdp", "enUS", true, debug )

T["(Wikki's Cooldown Pulse) use /wcdp to bring up the configuration window."] = L"(Wikki's Cooldown Pulse) use /wcdp to bring up the configuration window."
T["Actions"] = L"Actions"
T["Add Ability"] = L"Add Ability"
T["Apply"] = L"Apply"
T["Are you sure?"] = L"Are you sure?"
T["Close"] = L"Close"
T["Create"] = L"Create"
T["Create New Profile:"] = L"Create New Profile:"
T["Delete"] = L"Delete"
T["Drag and drop abilities below and click 'Add Ability' to add them to the current filter."] = L"Drag and drop abilities below and click 'Add Ability' to add them to the current filter."
T["Enable Action Pulsing"] = L"Enable Action Pulsing"
T["Enable Blacklist"] = L"Enable Blacklist"
T["Enable Debug Messages"] = L"Enable Debug Messages"
T["Enable Filtering:"] = L"Enable Filtering:"
T["Enable Morale Pulsing"] = L"Enable Morale Pulsing"
T["Enable Pet Ability Pulsing"] = L"Enable Pet Ability Pulsing"
T["Configuration"] = L"Configuration"
T["Enable Sound With Pulse"] = L"Enable Sound With Pulse"
T["Enable Pulse Sound"] = L"Enable Pulse Sound"
T["Hide Minimap Icon"] = L"Hide Minimap Icon"
T["Show Minimap Button"] = L"Show Minimap Button"
T["Enable Whitelist"] = L"Enable Whitelist"
T["Filter"] = L"Filter"
T["Filtered Abilities:"] = L"Filtered Abilities:"
T["Minimum Cooldown (sec):"] = L"Minimum Cooldown (sec):"
T["Morale"] = L"Morale"
T["NOTE: Profile changes take effect immediately!"] = L"NOTE: Profile changes take effect immediately!"
T["Pet Abilities"] = L"Pet Abilities"
T["Pulse End Alpha (0 to 1):"] = L"Pulse End Alpha (0 to 1):"
T["Pulse Speed (sec):"] = L"Pulse Speed (sec):"
T["Pulse Start Alpha (0 to 1):"] = L"Pulse Start Alpha (0 to 1):"
T["Pulse When Morale Available"] = L"Pulse When Morale Available"
T["Reset Profile"] = L"Reset Profile"
T["Select Pulse Sound:"] = L"Select Pulse Sound:"
T["Revert"] = L"Revert"
T["WARNING: Clicking this button will restore the current profile back to default values!"] = L"WARNING: Clicking this button will restore the current profile back to default values!"
T["Wikki's Cooldown Pulse %s initialized."] = L"Wikki's Cooldown Pulse %s initialized."
T["Wikki's Cooldown Pulse - Configuration"] = L"Wikki's Cooldown Pulse - Configuration"
T["Active Profile:"] = L"Active Profile:"
T["Low Health Alert"] = L"Low Health Alert"
T["Enable Low Health Pulse"] = L"Enable Low Health Pulse"
T["Low Health Threshold (%):"] = L"Low Health Threshold (%):"
T["Repeat Interval (sec):"] = L"Repeat Interval (sec):"
T["Enable Sound With Low Health Pulse"] = L"Enable Sound With Low Health Pulse"
T["General"] = L"General"
T["Filters"] = L"Filters"
T["Profiles"] = L"Profiles"
T["None"] = L"None"
T["Set Active Profile:"] = L"Set Active Profile:"
T["Copy Settings From:"] = L"Copy Settings From:"
T["Enable Sound With Morale Pulse"] = L"Enable Sound With Morale Pulse"
T["desc_start_alpha"] = L"Starting opacity (0 = transparent, 1 = opaque). The animation begins at this value."
T["desc_end_alpha"] = L"Peak opacity. The icon pulses between Start and End values in a loop."
T["desc_pulse_speed"] = L"Half-cycle duration (Start to End). Lower = faster blink. At 0.40s one cycle lasts ~0.8s."
T["desc_min_cooldown_actions"] = L"Only pulse if the total cooldown was at least this long. The GCD (1.61s) is always excluded."
T["desc_min_cooldown_morale"] = L"Fallback mode only: applies when 'Pulse When Morale Available' is disabled."
T["desc_min_cooldown_pet"] = L"Only pulse if the pet ability cooldown was at least this long."
T["desc_on_available"] = L"Pulse when the morale bar reaches the required rank, not when the cooldown expires."
T["desc_lh_threshold"] = L"HP percentage below which the pulse fires (1-99)."
T["desc_lh_interval"] = L"Seconds between repeated pulses while HP stays below the threshold (0.5-10)."
T["Help"] = L"Help"
T["help_title"] = L"Wikki's Cooldown Pulse"
T["help_version_label"] = L"Version:"
T["help_intro"] = L"Flashes an animated icon when an ability, morale, or pet skill finishes its cooldown - giving you an instant visual cue without watching the action bar."
T["help_section_how"] = L"How It Works"
T["help_abilities"] = L"Actions & Pet - The icon pulses when the cooldown exceeds the configured minimum and reaches zero. The global GCD (1.61s) is always filtered out."
T["help_morale"] = L"Morale - With 'Pulse When Morale Available' on, pulses as soon as the bar reaches the required rank. With it off, uses the cooldown path (minimum cooldown applies)."
T["help_lowhealth"] = L"Low Health - Repeating pulse while your HP stays at or below the threshold. Sound follows the 'Enable Sound With Low Health Pulse' toggle."
T["help_section_tips"] = L"Tips"
T["help_tip_filters"] = L"Use the Filters page to whitelist or blacklist specific abilities by dragging their icons."
T["help_tip_profiles"] = L"Profiles let you save independent settings per character or role."
T["help_tip_anchor"] = L"Move each pulse anchor independently via Controls > Windows in the main menu."
T["help_section_slash"] = L"Slash Commands"
T["help_slash_open"] = L"/wcdp - Open the configuration window."
T["help_slash_debug"] = L"/wcdp debug - Toggle debug messages in chat."
T["help_section_credits"] = L"Credits"
T["help_credits"] = L"Original author: Wikki (2.0.4, 2011). Community maintained since 2.0.5."
