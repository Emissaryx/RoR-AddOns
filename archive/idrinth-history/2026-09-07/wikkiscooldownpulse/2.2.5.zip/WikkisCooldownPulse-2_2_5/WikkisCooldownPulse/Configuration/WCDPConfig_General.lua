--[[
	This application is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
--]]

if not WCDPConfig then return end

local debug = false
--[===[@debug@
debug = true
--@end-debug@]===]

local T      = LibStub( "WAR-AceLocale-3.0" ) : GetLocale( "wcdp", debug )
local LibGUI = LibStub( "LibGUI" )

local db
local initialized = false

-- Radio-group save/restore state (WAR/RoR makes same-parent checkboxes mutually exclusive)
local _moEnabled, _moOnAvail, _moSoundEnabled = false, false, false
local _lhEnabled, _lhSoundEnabled             = false, false
local _acEnabled, _acSoundEnabled             = false, false
local _petEnabled, _petSoundEnabled           = false, false

-- ============================================================
-- Navigation pages (registered separately)
-- ============================================================
local window = {
    Name = T["General"], display = {}, W = {},
}
local actionsConfig = {
    Name = T["Actions"], display = {}, W = {},
}
local moraleConfig = {
    Name = T["Morale"], display = {}, W = {},
}
local petConfig = {
    Name = T["Pet Abilities"], display = {}, W = {},
}
local lhConfig = {
    Name = T["Low Health Alert"], display = {}, W = {},
}
local helpConfig = {
    Name = T["Help"], display = {}, W = {},
}

-- ============================================================
-- Helper: standard numeric input field (template + size + anchor)
-- width defaults to NUMERIC_FIELD_WIDTH (50) — pass NUMERIC_FIELD_WIDTH_WIDE
-- (60) for fields that display up to 4 characters (e.g. "0.40", "60.0").
-- ============================================================
local NUMERIC_FIELD_WIDTH      = 50   -- Pet Abilities, Low Health Alert
local NUMERIC_FIELD_WIDTH_WIDE = 60   -- General, Actions, Morale
local function makeNumericField( parentWindow, anchorTarget, width )
    local e = parentWindow( "Textbox", nil, "WCDPEditBoxNumeric" )
    e:Resize( width or NUMERIC_FIELD_WIDTH )
    e:Show( true )
    e:AnchorTo( anchorTarget, "right", "left", 10, 0 )
    return e
end

-- ============================================================
-- InitializeAll — shared, runs only once
-- ============================================================
local function InitializeAll()
    if initialized then return end
    db = WCDP.db

    local w, e

    -- ──────────────────────────────────────────────────────────
    -- GENERAL sub-window  (360px — 305 + room for Test Pulse button)
    -- ──────────────────────────────────────────────────────────
    w = LibGUI( "window", nil, "WCDPWindowDefault" )
    w:ClearAnchors()
    w:Resize( 400, 463 )
    w:Show( true )
    window.W.General = w
    table.insert( window.display, w )

    e = window.W.General( "Label" )
    e:Resize( 450 )
    e:Align( "leftcenter" )
    e:AnchorTo( window.W.General, "topleft", "topleft", 15, 10 )
    e:Font( "font_clear_medium_bold" )
    e:SetText( T["General"] )
    window.W.General.Title_Label = e

    e = window.W.General( "Checkbox" )
    e:AnchorTo( window.W.General.Title_Label, "bottomleft", "topleft", 10, 8 )
    window.W.General.EnableSound_Checkbox = e

    e = window.W.General( "Label" )
    e:Resize( 450 )
    e:Align( "leftcenter" )
    e:AnchorTo( window.W.General.EnableSound_Checkbox, "right", "left", 10, 0 )
    e:Font( "font_chat_text" )
    e:SetText( T["Enable Sound With Pulse"] )
    window.W.General.EnableSound_Label = e

    e = window.W.General( "Label" )
    e:Resize( 215 )
    e:AnchorTo( window.W.General.EnableSound_Checkbox, "bottomleft", "topleft", 0, 8 )
    e:Font( "font_chat_text" )
    e:Align( "leftcenter" )
    e:SetText( T["Select Pulse Sound:"] )
    window.W.General.SoundSelect_Label = e

    e = window.W.General( "combobox", nil, "WCDPComboBox" )
    e:AnchorTo( window.W.General.SoundSelect_Label, "bottomleft", "topleft", 10, 3 )
    for _, opt in ipairs( WCDP.SoundList ) do
        e:Add( towstring( opt.label ) )
    end
    window.W.General.Sound_Combo = e

    e = window.W.General( "Label" )
    e:AnchorTo( window.W.General.Sound_Combo, "bottomleft", "topleft", 0, 8 )
    e:Font( "font_chat_text" )
    e:Align( "leftcenter" )
    e:SetText( T["Pulse Start Alpha (0 to 1):"] )
    e:Resize( 200, 30 )
    window.W.General.StartAlpha_Label = e

    window.W.General.StartAlpha_TextBox = makeNumericField( window.W.General, window.W.General.StartAlpha_Label, NUMERIC_FIELD_WIDTH_WIDE )

    e = window.W.General( "Label" )
    e:Resize( 350, 36 )
    e:AnchorTo( window.W.General.StartAlpha_Label, "bottomleft", "topleft", 0, 5 )
    e:Font( "font_chat_text" )
    e:Align( "leftcenter" )
    e:SetText( T["desc_start_alpha"] )
    e:WordWrap( true )
    LabelSetTextColor( e.name, 170, 170, 170 )
    window.W.General.StartAlpha_Desc = e

    e = window.W.General( "Label" )
    e:AnchorTo( window.W.General.StartAlpha_Desc, "bottomleft", "topleft", 0, 8 )
    e:Font( "font_chat_text" )
    e:Align( "leftcenter" )
    e:SetText( T["Pulse End Alpha (0 to 1):"] )
    e:Resize( 200, 30 )
    window.W.General.EndAlpha_Label = e

    window.W.General.EndAlpha_TextBox = makeNumericField( window.W.General, window.W.General.EndAlpha_Label, NUMERIC_FIELD_WIDTH_WIDE )

    e = window.W.General( "Label" )
    e:Resize( 350, 36 )
    e:AnchorTo( window.W.General.EndAlpha_Label, "bottomleft", "topleft", 0, 5 )
    e:Font( "font_chat_text" )
    e:Align( "leftcenter" )
    e:SetText( T["desc_end_alpha"] )
    e:WordWrap( true )
    LabelSetTextColor( e.name, 170, 170, 170 )
    window.W.General.EndAlpha_Desc = e

    e = window.W.General( "Label" )
    e:AnchorTo( window.W.General.EndAlpha_Desc, "bottomleft", "topleft", 0, 8 )
    e:Font( "font_chat_text" )
    e:Align( "leftcenter" )
    e:SetText( T["Pulse Speed (sec):"] )
    e:Resize( 200, 30 )
    window.W.General.PulseSpeed_Label = e

    window.W.General.PulseSpeed_TextBox = makeNumericField( window.W.General, window.W.General.PulseSpeed_Label, NUMERIC_FIELD_WIDTH_WIDE )

    e = window.W.General( "Label" )
    e:Resize( 350, 36 )
    e:AnchorTo( window.W.General.PulseSpeed_Label, "bottomleft", "topleft", 0, 5 )
    e:Font( "font_chat_text" )
    e:Align( "leftcenter" )
    e:SetText( T["desc_pulse_speed"] )
    e:WordWrap( true )
    LabelSetTextColor( e.name, 170, 170, 170 )
    window.W.General.PulseSpeed_Desc = e

    e = window.W.General( "Checkbox" )
    e:AnchorTo( window.W.General.PulseSpeed_Desc, "bottomleft", "topleft", 0, 12 )
    window.W.General.EnableDebug_Checkbox = e

    e = window.W.General( "Label" )
    e:Resize( 450 )
    e:Align( "leftcenter" )
    e:AnchorTo( window.W.General.EnableDebug_Checkbox, "right", "left", 10, 0 )
    e:Font( "font_chat_text" )
    e:SetText( T["Enable Debug Messages"] )
    window.W.General.EnableDebug_Label = e

    e = window.W.General( "Checkbox" )
    e:AnchorTo( window.W.General.EnableDebug_Checkbox, "bottomleft", "topleft", 0, 10 )
    window.W.General.ShowMinimapButton_Checkbox = e

    e = window.W.General( "Label" )
    e:Resize( 450 )
    e:Align( "leftcenter" )
    e:AnchorTo( window.W.General.ShowMinimapButton_Checkbox, "right", "left", 10, 0 )
    e:Font( "font_chat_text" )
    e:SetText( T["Show Minimap Button"] )
    window.W.General.ShowMinimapButton_Label = e

    -- ──────────────────────────────────────────────────────────
    -- ACTIONS window (independent nav page)
    -- ──────────────────────────────────────────────────────────
    w = LibGUI( "window", nil, "WCDPWindowDefault" )
    w:Resize( 400, 220 )
    w:Show( true )
    actionsConfig.W.Main = w
    table.insert( actionsConfig.display, w )

    e = actionsConfig.W.Main( "Label" )
    e:Resize( 450 )
    e:Align( "leftcenter" )
    e:AnchorTo( actionsConfig.W.Main, "topleft", "topleft", 15, 10 )
    e:Font( "font_clear_medium_bold" )
    e:SetText( T["Actions"] )
    actionsConfig.W.Main.Title_Label = e

    e = actionsConfig.W.Main( "Checkbox" )
    e:AnchorTo( actionsConfig.W.Main.Title_Label, "bottomleft", "topleft", 10, 8 )
    actionsConfig.W.Main.EnableAction_Checkbox = e

    e = actionsConfig.W.Main( "Label" )
    e:Resize( 450 )
    e:Align( "leftcenter" )
    e:AnchorTo( actionsConfig.W.Main.EnableAction_Checkbox, "right", "left", 10, 0 )
    e:Font( "font_chat_text" )
    e:SetText( T["Enable Action Pulsing"] )
    actionsConfig.W.Main.EnableAction_Label = e

    e = actionsConfig.W.Main( "Label" )
    e:AnchorTo( actionsConfig.W.Main.EnableAction_Checkbox, "bottomleft", "topleft", 10, 10 )
    e:Font( "font_chat_text" )
    e:Align( "leftcenter" )
    e:SetText( T["Minimum Cooldown (sec):"] )
    e:Resize( 200, 30 )
    actionsConfig.W.Main.MinimumCooldown_Label = e

    actionsConfig.W.Main.MinimumCooldown_TextBox = makeNumericField( actionsConfig.W.Main, actionsConfig.W.Main.MinimumCooldown_Label, NUMERIC_FIELD_WIDTH_WIDE )

    e = actionsConfig.W.Main( "Label" )
    e:Resize( 350, 54 )
    e:AnchorTo( actionsConfig.W.Main.MinimumCooldown_Label, "bottomleft", "topleft", 0, 5 )
    e:Font( "font_chat_text" )
    e:Align( "leftcenter" )
    e:SetText( T["desc_min_cooldown_actions"] )
    e:WordWrap( true )
    LabelSetTextColor( e.name, 170, 170, 170 )
    actionsConfig.W.Main.MinimumCooldown_Desc = e

    e = actionsConfig.W.Main( "Checkbox" )
    e:AnchorTo( actionsConfig.W.Main.MinimumCooldown_Desc, "bottomleft", "topleft", 0, 10 )
    WindowSetDimensions( e.name, 20, 24 )
    actionsConfig.W.Main.Sound_Checkbox = e

    e = actionsConfig.W.Main( "Label" )
    e:Resize( 450 )
    e:Align( "leftcenter" )
    e:AnchorTo( actionsConfig.W.Main.Sound_Checkbox, "right", "left", 10, 0 )
    e:Font( "font_chat_text" )
    e:SetText( T["Enable Pulse Sound"] )
    actionsConfig.W.Main.Sound_Label = e

    -- Radio-group fix (2 checkboxes: Enable, Sound)
    do
        local en_cb = actionsConfig.W.Main.EnableAction_Checkbox
        local sn_cb = actionsConfig.W.Main.Sound_Checkbox
        en_cb.OnLButtonDown = function() _acSoundEnabled = sn_cb:GetValue() end
        en_cb.OnLButtonUp   = function() _acEnabled = en_cb:GetValue(); sn_cb:SetValue( _acSoundEnabled ) end
        sn_cb.OnLButtonDown = function() _acEnabled = en_cb:GetValue() end
        sn_cb.OnLButtonUp   = function() _acSoundEnabled = sn_cb:GetValue(); en_cb:SetValue( _acEnabled ) end
    end

    -- ──────────────────────────────────────────────────────────
    -- MORALE window (175px)
    -- ──────────────────────────────────────────────────────────
    w = LibGUI( "window", nil, "WCDPWindowDefault" )
    w:Resize( 400, 285 )
    w:Show( true )
    moraleConfig.W.Main = w
    table.insert( moraleConfig.display, w )

    e = moraleConfig.W.Main( "Label" )
    e:Resize( 450 )
    e:Align( "leftcenter" )
    e:AnchorTo( moraleConfig.W.Main, "topleft", "topleft", 15, 10 )
    e:Font( "font_clear_medium_bold" )
    e:SetText( T["Morale"] )
    moraleConfig.W.Main.Title_Label = e

    e = moraleConfig.W.Main( "Checkbox" )
    e:AnchorTo( moraleConfig.W.Main.Title_Label, "bottomleft", "topleft", 10, 8 )
    moraleConfig.W.Main.EnableMorale_Checkbox = e

    e = moraleConfig.W.Main( "Label" )
    e:Resize( 450 )
    e:Align( "leftcenter" )
    e:AnchorTo( moraleConfig.W.Main.EnableMorale_Checkbox, "right", "left", 10, 0 )
    e:Font( "font_chat_text" )
    e:SetText( T["Enable Morale Pulsing"] )
    moraleConfig.W.Main.EnableMorale_Label = e

    e = moraleConfig.W.Main( "Label" )
    e:AnchorTo( moraleConfig.W.Main.EnableMorale_Checkbox, "bottomleft", "topleft", 10, 10 )
    e:Font( "font_chat_text" )
    e:Align( "leftcenter" )
    e:SetText( T["Minimum Cooldown (sec):"] )
    e:Resize( 200, 30 )
    moraleConfig.W.Main.MinimumCooldown_Label = e

    moraleConfig.W.Main.MinimumCooldown_TextBox = makeNumericField( moraleConfig.W.Main, moraleConfig.W.Main.MinimumCooldown_Label, NUMERIC_FIELD_WIDTH_WIDE )

    e = moraleConfig.W.Main( "Label" )
    e:Resize( 350, 36 )
    e:AnchorTo( moraleConfig.W.Main.MinimumCooldown_Label, "bottomleft", "topleft", 0, 5 )
    e:Font( "font_chat_text" )
    e:Align( "leftcenter" )
    e:SetText( T["desc_min_cooldown_morale"] )
    e:WordWrap( true )
    LabelSetTextColor( e.name, 170, 170, 170 )
    moraleConfig.W.Main.MinimumCooldown_Desc = e

    e = moraleConfig.W.Main( "Checkbox" )
    e:AnchorTo( moraleConfig.W.Main.MinimumCooldown_Desc, "bottomleft", "topleft", 0, 10 )
    moraleConfig.W.Main.OnAvailable_Checkbox = e

    e = moraleConfig.W.Main( "Label" )
    e:Resize( 450 )
    e:Align( "leftcenter" )
    e:AnchorTo( moraleConfig.W.Main.OnAvailable_Checkbox, "right", "left", 10, 0 )
    e:Font( "font_chat_text" )
    e:SetText( T["Pulse When Morale Available"] )
    moraleConfig.W.Main.OnAvailable_Label = e

    e = moraleConfig.W.Main( "Label" )
    e:Resize( 350, 36 )
    e:AnchorTo( moraleConfig.W.Main.OnAvailable_Checkbox, "bottomleft", "topleft", 0, 5 )
    e:Font( "font_chat_text" )
    e:Align( "leftcenter" )
    e:SetText( T["desc_on_available"] )
    e:WordWrap( true )
    LabelSetTextColor( e.name, 170, 170, 170 )
    moraleConfig.W.Main.OnAvailable_Desc = e

    e = moraleConfig.W.Main( "Checkbox" )
    e:AnchorTo( moraleConfig.W.Main.OnAvailable_Desc, "bottomleft", "topleft", 0, 10 )
    WindowSetDimensions( e.name, 20, 24 )
    moraleConfig.W.Main.Sound_Checkbox = e

    e = moraleConfig.W.Main( "Label" )
    e:Resize( 450 )
    e:Align( "leftcenter" )
    e:AnchorTo( moraleConfig.W.Main.Sound_Checkbox, "right", "left", 10, 0 )
    e:Font( "font_chat_text" )
    e:SetText( T["Enable Pulse Sound"] )
    moraleConfig.W.Main.Sound_Label = e

    -- Radio-group fix (3 checkboxes: Enable, OnAvailable, Sound)
    do
        local en = moraleConfig.W.Main.EnableMorale_Checkbox
        local av = moraleConfig.W.Main.OnAvailable_Checkbox
        local sn = moraleConfig.W.Main.Sound_Checkbox
        en.OnLButtonDown = function() _moOnAvail = av:GetValue(); _moSoundEnabled = sn:GetValue() end
        en.OnLButtonUp   = function() _moEnabled = en:GetValue(); av:SetValue( _moOnAvail ); sn:SetValue( _moSoundEnabled ) end
        av.OnLButtonDown = function() _moEnabled = en:GetValue(); _moSoundEnabled = sn:GetValue() end
        av.OnLButtonUp   = function() _moOnAvail = av:GetValue(); en:SetValue( _moEnabled ); sn:SetValue( _moSoundEnabled ) end
        sn.OnLButtonDown = function() _moEnabled = en:GetValue(); _moOnAvail = av:GetValue() end
        sn.OnLButtonUp   = function() _moSoundEnabled = sn:GetValue(); en:SetValue( _moEnabled ); av:SetValue( _moOnAvail ) end
    end

    -- ──────────────────────────────────────────────────────────
    -- PET ABILITIES window (110px)
    -- ──────────────────────────────────────────────────────────
    w = LibGUI( "window", nil, "WCDPWindowDefault" )
    w:Resize( 400, 215 )
    w:Show( true )
    petConfig.W.Main = w
    table.insert( petConfig.display, w )

    e = petConfig.W.Main( "Label" )
    e:Resize( 450 )
    e:Align( "leftcenter" )
    e:AnchorTo( petConfig.W.Main, "topleft", "topleft", 15, 10 )
    e:Font( "font_clear_medium_bold" )
    e:SetText( T["Pet Abilities"] )
    petConfig.W.Main.Title_Label = e

    e = petConfig.W.Main( "Checkbox" )
    e:AnchorTo( petConfig.W.Main.Title_Label, "bottomleft", "topleft", 10, 8 )
    petConfig.W.Main.EnablePet_Checkbox = e

    e = petConfig.W.Main( "Label" )
    e:Resize( 450 )
    e:Align( "leftcenter" )
    e:AnchorTo( petConfig.W.Main.EnablePet_Checkbox, "right", "left", 10, 0 )
    e:Font( "font_chat_text" )
    e:SetText( T["Enable Pet Ability Pulsing"] )
    petConfig.W.Main.EnablePet_Label = e

    e = petConfig.W.Main( "Label" )
    e:AnchorTo( petConfig.W.Main.EnablePet_Checkbox, "bottomleft", "topleft", 10, 10 )
    e:Font( "font_chat_text" )
    e:Align( "leftcenter" )
    e:SetText( T["Minimum Cooldown (sec):"] )
    e:Resize( 200, 30 )
    petConfig.W.Main.MinimumCooldown_Label = e

    petConfig.W.Main.MinimumCooldown_TextBox = makeNumericField( petConfig.W.Main, petConfig.W.Main.MinimumCooldown_Label )

    e = petConfig.W.Main( "Label" )
    e:Resize( 350, 36 )
    e:AnchorTo( petConfig.W.Main.MinimumCooldown_Label, "bottomleft", "topleft", 0, 5 )
    e:Font( "font_chat_text" )
    e:Align( "leftcenter" )
    e:SetText( T["desc_min_cooldown_pet"] )
    e:WordWrap( true )
    LabelSetTextColor( e.name, 170, 170, 170 )
    petConfig.W.Main.MinimumCooldown_Desc = e

    e = petConfig.W.Main( "Checkbox" )
    e:AnchorTo( petConfig.W.Main.MinimumCooldown_Desc, "bottomleft", "topleft", 0, 10 )
    WindowSetDimensions( e.name, 20, 24 )
    petConfig.W.Main.Sound_Checkbox = e

    e = petConfig.W.Main( "Label" )
    e:Resize( 450 )
    e:Align( "leftcenter" )
    e:AnchorTo( petConfig.W.Main.Sound_Checkbox, "right", "left", 10, 0 )
    e:Font( "font_chat_text" )
    e:SetText( T["Enable Pulse Sound"] )
    petConfig.W.Main.Sound_Label = e

    -- Radio-group fix (2 checkboxes: Enable, Sound)
    do
        local en_cb = petConfig.W.Main.EnablePet_Checkbox
        local sn_cb = petConfig.W.Main.Sound_Checkbox
        en_cb.OnLButtonDown = function() _petSoundEnabled = sn_cb:GetValue() end
        en_cb.OnLButtonUp   = function() _petEnabled = en_cb:GetValue(); sn_cb:SetValue( _petSoundEnabled ) end
        sn_cb.OnLButtonDown = function() _petEnabled = en_cb:GetValue() end
        sn_cb.OnLButtonUp   = function() _petSoundEnabled = sn_cb:GetValue(); en_cb:SetValue( _petEnabled ) end
    end

    -- ──────────────────────────────────────────────────────────
    -- LOW HEALTH ALERT window (220px)
    -- ──────────────────────────────────────────────────────────
    w = LibGUI( "window", nil, "WCDPWindowDefault" )
    w:Resize( 400, 300 )
    w:Show( true )
    lhConfig.W.Main = w
    table.insert( lhConfig.display, w )

    e = lhConfig.W.Main( "Label" )
    e:Resize( 450 )
    e:Align( "leftcenter" )
    e:AnchorTo( lhConfig.W.Main, "topleft", "topleft", 15, 10 )
    e:Font( "font_clear_medium_bold" )
    e:SetText( T["Low Health Alert"] )
    lhConfig.W.Main.Title_Label = e

    e = lhConfig.W.Main( "Checkbox" )
    e:AnchorTo( lhConfig.W.Main.Title_Label, "bottomleft", "topleft", 10, 8 )
    lhConfig.W.Main.Enable_Checkbox = e

    e = lhConfig.W.Main( "Label" )
    e:Resize( 450 )
    e:Align( "leftcenter" )
    e:AnchorTo( lhConfig.W.Main.Enable_Checkbox, "right", "left", 10, 0 )
    e:Font( "font_chat_text" )
    e:SetText( T["Enable Low Health Pulse"] )
    lhConfig.W.Main.Enable_Label = e

    e = lhConfig.W.Main( "Label" )
    e:AnchorTo( lhConfig.W.Main.Enable_Checkbox, "bottomleft", "topleft", 10, 10 )
    e:Font( "font_chat_text" )
    e:Align( "leftcenter" )
    e:SetText( T["Low Health Threshold (%):"] )
    e:Resize( 200, 30 )
    lhConfig.W.Main.Threshold_Label = e

    lhConfig.W.Main.Threshold_Textbox = makeNumericField( lhConfig.W.Main, lhConfig.W.Main.Threshold_Label )

    e = lhConfig.W.Main( "Label" )
    e:Resize( 350, 36 )
    e:AnchorTo( lhConfig.W.Main.Threshold_Label, "bottomleft", "topleft", 0, 5 )
    e:Font( "font_chat_text" )
    e:Align( "leftcenter" )
    e:SetText( T["desc_lh_threshold"] )
    e:WordWrap( true )
    LabelSetTextColor( e.name, 170, 170, 170 )
    lhConfig.W.Main.Threshold_Desc = e

    e = lhConfig.W.Main( "Label" )
    e:AnchorTo( lhConfig.W.Main.Threshold_Desc, "bottomleft", "topleft", 0, 8 )
    e:Font( "font_chat_text" )
    e:Align( "leftcenter" )
    e:SetText( T["Repeat Interval (sec):"] )
    e:Resize( 200, 30 )
    lhConfig.W.Main.Interval_Label = e

    lhConfig.W.Main.Interval_Textbox = makeNumericField( lhConfig.W.Main, lhConfig.W.Main.Interval_Label )

    e = lhConfig.W.Main( "Label" )
    e:Resize( 350, 36 )
    e:AnchorTo( lhConfig.W.Main.Interval_Label, "bottomleft", "topleft", 0, 5 )
    e:Font( "font_chat_text" )
    e:Align( "leftcenter" )
    e:SetText( T["desc_lh_interval"] )
    e:WordWrap( true )
    LabelSetTextColor( e.name, 170, 170, 170 )
    lhConfig.W.Main.Interval_Desc = e

    e = lhConfig.W.Main( "Checkbox" )
    e:AnchorTo( lhConfig.W.Main.Interval_Desc, "bottomleft", "topleft", 0, 10 )
    WindowSetDimensions( e.name, 20, 24 )
    lhConfig.W.Main.Sound_Checkbox = e

    e = lhConfig.W.Main( "Label" )
    e:Resize( 450 )
    e:Align( "leftcenter" )
    e:AnchorTo( lhConfig.W.Main.Sound_Checkbox, "right", "left", 10, 0 )
    e:Font( "font_chat_text" )
    e:SetText( T["Enable Sound With Low Health Pulse"] )
    lhConfig.W.Main.Sound_Label = e

    -- Radio-group fix (2 checkboxes: Enable, Sound)
    do
        local en_cb = lhConfig.W.Main.Enable_Checkbox
        local sn_cb = lhConfig.W.Main.Sound_Checkbox
        en_cb.OnLButtonDown = function() _lhSoundEnabled = sn_cb:GetValue() end
        en_cb.OnLButtonUp   = function() _lhEnabled = en_cb:GetValue(); sn_cb:SetValue( _lhSoundEnabled ) end
        sn_cb.OnLButtonDown = function() _lhEnabled = en_cb:GetValue() end
        sn_cb.OnLButtonUp   = function() _lhSoundEnabled = sn_cb:GetValue(); en_cb:SetValue( _lhEnabled ) end
    end

    -- ──────────────────────────────────────────────────────────
    -- HELP window (static — no controls, no Apply/Revert)
    -- ──────────────────────────────────────────────────────────
    w = LibGUI( "window", nil, "WCDPWindowDefault" )
    w:ClearAnchors()
    w:Resize( 400, 800 )
    w:Show( true )
    helpConfig.W.Main = w
    table.insert( helpConfig.display, w )

    -- Title
    e = helpConfig.W.Main( "Label" )
    e:Resize( 370, 30 )
    e:AnchorTo( helpConfig.W.Main, "topleft", "topleft", 15, 12 )
    e:Font( "font_clear_medium_bold" )
    e:Align( "leftcenter" )
    e:SetText( T["help_title"] )
    helpConfig.W.Main.Title = e

    -- Intro paragraph
    e = helpConfig.W.Main( "Label" )
    e:Resize( 370, 80 )
    e:AnchorTo( helpConfig.W.Main.Title, "bottomleft", "topleft", 0, 10 )
    e:Font( "font_chat_text" )
    e:Align( "leftcenter" )
    e:SetText( T["help_intro"] )
    e:WordWrap( true )
    helpConfig.W.Main.Intro = e

    -- Section: How It Works
    e = helpConfig.W.Main( "Label" )
    e:Resize( 370, 28 )
    e:AnchorTo( helpConfig.W.Main.Intro, "bottomleft", "topleft", 0, 12 )
    e:Font( "font_clear_medium_bold" )
    e:Align( "leftcenter" )
    e:SetText( T["help_section_how"] )
    helpConfig.W.Main.SectionHow = e

    e = helpConfig.W.Main( "Label" )
    e:Resize( 370, 72 )
    e:AnchorTo( helpConfig.W.Main.SectionHow, "bottomleft", "topleft", 0, 5 )
    e:Font( "font_chat_text" )
    e:Align( "leftcenter" )
    e:SetText( T["help_abilities"] )
    e:WordWrap( true )
    LabelSetTextColor( e.name, 210, 210, 210 )
    helpConfig.W.Main.HowAbilities = e

    e = helpConfig.W.Main( "Label" )
    e:Resize( 370, 72 )
    e:AnchorTo( helpConfig.W.Main.HowAbilities, "bottomleft", "topleft", 0, 6 )
    e:Font( "font_chat_text" )
    e:Align( "leftcenter" )
    e:SetText( T["help_morale"] )
    e:WordWrap( true )
    LabelSetTextColor( e.name, 210, 210, 210 )
    helpConfig.W.Main.HowMorale = e

    e = helpConfig.W.Main( "Label" )
    e:Resize( 370, 72 )
    e:AnchorTo( helpConfig.W.Main.HowMorale, "bottomleft", "topleft", 0, 6 )
    e:Font( "font_chat_text" )
    e:Align( "leftcenter" )
    e:SetText( T["help_lowhealth"] )
    e:WordWrap( true )
    LabelSetTextColor( e.name, 210, 210, 210 )
    helpConfig.W.Main.HowLowHealth = e

    -- Section: Tips
    e = helpConfig.W.Main( "Label" )
    e:Resize( 370, 28 )
    e:AnchorTo( helpConfig.W.Main.HowLowHealth, "bottomleft", "topleft", 0, 12 )
    e:Font( "font_clear_medium_bold" )
    e:Align( "leftcenter" )
    e:SetText( T["help_section_tips"] )
    helpConfig.W.Main.SectionTips = e

    e = helpConfig.W.Main( "Label" )
    e:Resize( 370, 36 )
    e:AnchorTo( helpConfig.W.Main.SectionTips, "bottomleft", "topleft", 0, 5 )
    e:Font( "font_chat_text" )
    e:Align( "leftcenter" )
    e:SetText( T["help_tip_filters"] )
    e:WordWrap( true )
    LabelSetTextColor( e.name, 210, 210, 210 )
    helpConfig.W.Main.Tip1 = e

    e = helpConfig.W.Main( "Label" )
    e:Resize( 370, 36 )
    e:AnchorTo( helpConfig.W.Main.Tip1, "bottomleft", "topleft", 0, 5 )
    e:Font( "font_chat_text" )
    e:Align( "leftcenter" )
    e:SetText( T["help_tip_profiles"] )
    e:WordWrap( true )
    LabelSetTextColor( e.name, 210, 210, 210 )
    helpConfig.W.Main.Tip2 = e

    e = helpConfig.W.Main( "Label" )
    e:Resize( 370, 36 )
    e:AnchorTo( helpConfig.W.Main.Tip2, "bottomleft", "topleft", 0, 5 )
    e:Font( "font_chat_text" )
    e:Align( "leftcenter" )
    e:SetText( T["help_tip_anchor"] )
    e:WordWrap( true )
    LabelSetTextColor( e.name, 210, 210, 210 )
    helpConfig.W.Main.Tip3 = e

    -- Section: Slash Commands
    e = helpConfig.W.Main( "Label" )
    e:Resize( 370, 28 )
    e:AnchorTo( helpConfig.W.Main.Tip3, "bottomleft", "topleft", 0, 12 )
    e:Font( "font_clear_medium_bold" )
    e:Align( "leftcenter" )
    e:SetText( T["help_section_slash"] )
    helpConfig.W.Main.SectionSlash = e

    e = helpConfig.W.Main( "Label" )
    e:Resize( 370, 22 )
    e:AnchorTo( helpConfig.W.Main.SectionSlash, "bottomleft", "topleft", 0, 5 )
    e:Font( "font_chat_text" )
    e:Align( "leftcenter" )
    e:SetText( T["help_slash_open"] )
    LabelSetTextColor( e.name, 210, 210, 210 )
    helpConfig.W.Main.Slash1 = e

    e = helpConfig.W.Main( "Label" )
    e:Resize( 370, 36 )
    e:AnchorTo( helpConfig.W.Main.Slash1, "bottomleft", "topleft", 0, 4 )
    e:Font( "font_chat_text" )
    e:Align( "leftcenter" )
    e:SetText( T["help_slash_debug"] )
    e:WordWrap( true )
    LabelSetTextColor( e.name, 210, 210, 210 )
    helpConfig.W.Main.Slash2 = e

    -- Section: Credits
    e = helpConfig.W.Main( "Label" )
    e:Resize( 370, 28 )
    e:AnchorTo( helpConfig.W.Main.Slash2, "bottomleft", "topleft", 0, 12 )
    e:Font( "font_clear_medium_bold" )
    e:Align( "leftcenter" )
    e:SetText( T["help_section_credits"] )
    helpConfig.W.Main.SectionCredits = e

    e = helpConfig.W.Main( "Label" )
    e:Resize( 370, 36 )
    e:AnchorTo( helpConfig.W.Main.SectionCredits, "bottomleft", "topleft", 0, 5 )
    e:Font( "font_chat_text" )
    e:Align( "leftcenter" )
    e:SetText( T["help_credits"] )
    e:WordWrap( true )
    LabelSetTextColor( e.name, 170, 170, 170 )
    helpConfig.W.Main.Credits = e

    initialized = true
end

-- ============================================================
-- Page 1: General + Actions — Apply / Revert
-- ============================================================
local function ApplyGeneral()
    db = WCDP.db

    db.general.sound             = window.W.General.EnableSound_Checkbox:GetValue()
    db.general.debug             = window.W.General.EnableDebug_Checkbox:GetValue()
    db.general.showMinimapButton = window.W.General.ShowMinimapButton_Checkbox:GetValue()
    if( DoesWindowExist( "WCDPMinimapButton" ) ) then
        WindowSetShowing( "WCDPMinimapButton", db.general.showMinimapButton )
    end

    local selectedLabel = window.W.General.Sound_Combo:Selected()
    if( selectedLabel ~= nil ) then
        for _, opt in ipairs( WCDP.SoundList ) do
            if( towstring( opt.label ) == selectedLabel ) then
                db.general.soundKey = opt.key
                break
            end
        end
    end

    local temp
    temp = tonumber( window.W.General.StartAlpha_TextBox:GetText() ) or WCDP.DefaultSettings.alpha.start
    if( temp < 0 ) then temp = 0 end
    if( temp > 1 ) then temp = 1 end
    db.alpha.start = temp

    temp = tonumber( window.W.General.EndAlpha_TextBox:GetText() ) or WCDP.DefaultSettings.alpha.finish
    if( temp < 0 ) then temp = 0 end
    if( temp > 1 ) then temp = 1 end
    db.alpha.finish = temp

    temp = tonumber( window.W.General.PulseSpeed_TextBox:GetText() ) or WCDP.DefaultSettings.alpha.speed
    if( temp < 0 ) then temp = 0 end
    if( temp > 2 ) then temp = 2 end
    db.alpha.speed = temp

end

local function RevertGeneral()
    db = WCDP.db

    window.W.General.EnableSound_Checkbox:SetValue( db.general.sound )
    window.W.General.EnableDebug_Checkbox:SetValue( db.general.debug )
    window.W.General.ShowMinimapButton_Checkbox:SetValue( db.general.showMinimapButton ~= false )

    local currentKey = db.general.soundKey or "HELP_TIPS_NEW"
    for i, opt in ipairs( WCDP.SoundList ) do
        if( opt.key == currentKey ) then
            window.W.General.Sound_Combo:SelectIndex( i )
            break
        end
    end

    window.W.General.StartAlpha_TextBox:SetText( wstring.format( L"%.2f", towstring( db.alpha.start  ) ) )
    window.W.General.EndAlpha_TextBox:SetText(   wstring.format( L"%.2f", towstring( db.alpha.finish ) ) )
    window.W.General.PulseSpeed_TextBox:SetText( wstring.format( L"%.2f", towstring( db.alpha.speed  ) ) )

end

-- ============================================================
-- Page 2: Actions — Apply / Revert
-- ============================================================
local function ApplyActions()
    db = WCDP.db
    db.abilities.actions.enabled     = actionsConfig.W.Main.EnableAction_Checkbox:GetValue()
    local mc = tonumber( actionsConfig.W.Main.MinimumCooldown_TextBox:GetText() ) or WCDP.DefaultSettings.abilities.actions.mincooldown
    if( mc < 0   ) then mc = 0   end
    if( mc > 300 ) then mc = 300 end
    db.abilities.actions.mincooldown = mc
    db.abilities.actions.sound       = actionsConfig.W.Main.Sound_Checkbox:GetValue()
end

local function RevertActions()
    db = WCDP.db
    local ac = db.abilities.actions
    _acEnabled      = ac.enabled
    _acSoundEnabled = ac.sound ~= false
    actionsConfig.W.Main.EnableAction_Checkbox:SetValue( _acEnabled )
    actionsConfig.W.Main.MinimumCooldown_TextBox:SetText( wstring.format( L"%.1f", towstring( ac.mincooldown ) ) )
    actionsConfig.W.Main.Sound_Checkbox:SetValue( _acSoundEnabled )
end

-- ============================================================
-- Page 3: Morale — Apply / Revert
-- ============================================================
local function ApplyMorale()
    db = WCDP.db
    db.abilities.morale.enabled     = moraleConfig.W.Main.EnableMorale_Checkbox:GetValue()
    local mcm = tonumber( moraleConfig.W.Main.MinimumCooldown_TextBox:GetText() ) or WCDP.DefaultSettings.abilities.morale.mincooldown
    if( mcm < 0   ) then mcm = 0   end
    if( mcm > 300 ) then mcm = 300 end
    db.abilities.morale.mincooldown = mcm
    db.abilities.morale.onavailable = moraleConfig.W.Main.OnAvailable_Checkbox:GetValue()
    db.abilities.morale.sound       = moraleConfig.W.Main.Sound_Checkbox:GetValue()
end

local function RevertMorale()
    db = WCDP.db
    local mo = db.abilities.morale
    _moEnabled      = mo.enabled
    _moOnAvail      = mo.onavailable
    _moSoundEnabled = mo.sound ~= false
    moraleConfig.W.Main.EnableMorale_Checkbox:SetValue( _moEnabled )
    moraleConfig.W.Main.MinimumCooldown_TextBox:SetText( wstring.format( L"%.1f", towstring( mo.mincooldown ) ) )
    moraleConfig.W.Main.OnAvailable_Checkbox:SetValue( _moOnAvail )
    moraleConfig.W.Main.Sound_Checkbox:SetValue( _moSoundEnabled )
end

-- ============================================================
-- Page 4: Pet Abilities — Apply / Revert
-- ============================================================
local function ApplyPet()
    db = WCDP.db
    db.abilities.pet.enabled     = petConfig.W.Main.EnablePet_Checkbox:GetValue()
    local mcp = tonumber( petConfig.W.Main.MinimumCooldown_TextBox:GetText() ) or WCDP.DefaultSettings.abilities.pet.mincooldown
    if( mcp < 0   ) then mcp = 0   end
    if( mcp > 300 ) then mcp = 300 end
    db.abilities.pet.mincooldown = mcp
    db.abilities.pet.sound       = petConfig.W.Main.Sound_Checkbox:GetValue()
end

local function RevertPet()
    db = WCDP.db
    local pt = db.abilities.pet
    _petEnabled      = pt.enabled
    _petSoundEnabled = pt.sound ~= false
    petConfig.W.Main.EnablePet_Checkbox:SetValue( _petEnabled )
    petConfig.W.Main.MinimumCooldown_TextBox:SetText( wstring.format( L"%.1f", towstring( pt.mincooldown ) ) )
    petConfig.W.Main.Sound_Checkbox:SetValue( _petSoundEnabled )
end

-- ============================================================
-- Page 5: Low Health Alert — Apply / Revert
-- ============================================================
local function ApplyLowHealth()
    db = WCDP.db
    if( db.lowhealth == nil ) then db.lowhealth = WCDP.DefaultSettings.lowhealth end

    db.lowhealth.enabled = lhConfig.W.Main.Enable_Checkbox:GetValue()
    db.lowhealth.sound   = lhConfig.W.Main.Sound_Checkbox:GetValue()

    local temp
    temp = tonumber( lhConfig.W.Main.Threshold_Textbox:GetText() ) or WCDP.DefaultSettings.lowhealth.threshold
    if( temp < 1  ) then temp = 1  end
    if( temp > 99 ) then temp = 99 end
    db.lowhealth.threshold = temp

    temp = tonumber( lhConfig.W.Main.Interval_Textbox:GetText() ) or WCDP.DefaultSettings.lowhealth.repeatInterval
    if( temp < 0.5 ) then temp = 0.5 end
    if( temp > 10  ) then temp = 10  end
    db.lowhealth.repeatInterval = temp
end

local function RevertLowHealth()
    db = WCDP.db
    local lh = db.lowhealth or WCDP.DefaultSettings.lowhealth
    _lhEnabled      = lh.enabled
    _lhSoundEnabled = lh.sound ~= false
    lhConfig.W.Main.Enable_Checkbox:SetValue( _lhEnabled )
    lhConfig.W.Main.Sound_Checkbox:SetValue( _lhSoundEnabled )
    lhConfig.W.Main.Threshold_Textbox:SetText( towstring( lh.threshold ) )
    lhConfig.W.Main.Interval_Textbox:SetText( wstring.format( L"%.1f", towstring( lh.repeatInterval ) ) )
end

-- ============================================================
-- Wire up and register all four pages
-- ============================================================
window.Initialize       = InitializeAll
window.Apply            = ApplyGeneral
window.Revert           = RevertGeneral
window.Index            = WCDPConfig.RegisterWindow( window )

actionsConfig.Initialize = InitializeAll
actionsConfig.Apply      = ApplyActions
actionsConfig.Revert     = RevertActions
actionsConfig.Index      = WCDPConfig.RegisterWindow( actionsConfig )

moraleConfig.Initialize = InitializeAll
moraleConfig.Apply      = ApplyMorale
moraleConfig.Revert     = RevertMorale
moraleConfig.Index      = WCDPConfig.RegisterWindow( moraleConfig )

petConfig.Initialize    = InitializeAll
petConfig.Apply         = ApplyPet
petConfig.Revert        = RevertPet
petConfig.Index         = WCDPConfig.RegisterWindow( petConfig )

lhConfig.Initialize     = InitializeAll
lhConfig.Apply          = ApplyLowHealth
lhConfig.Revert         = RevertLowHealth
lhConfig.Index          = WCDPConfig.RegisterWindow( lhConfig )

helpConfig.Initialize   = InitializeAll
helpConfig.Apply        = function() end
helpConfig.Revert       = function() end
-- Registration deferred to after Profiles so Help appears last in sidebar
WCDPConfig.pendingHelpConfig = helpConfig
