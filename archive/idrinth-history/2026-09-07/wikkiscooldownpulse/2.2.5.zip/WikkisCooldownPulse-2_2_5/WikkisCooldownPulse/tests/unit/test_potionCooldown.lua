-- Tests for WCDP potion cooldown detection (CHANTIER 5 — 2.2.0).
-- API: DataUtils.GetItems() → itemData.bonus[n].cooldownTimeLeft / .totalCooldownTime
-- Confirmed in references/PotionBar (Game\ROR).

local pulsedIconNum = nil

local function makePotion(slotNum, cdLeft, cdTotal, iconNum)
    return {
        [slotNum] = {
            type   = GameData.ItemTypes.POTION,
            iconNum = iconNum or 488,
            bonus  = {
                { type = GameDefs.ITEMBONUS_USE,
                  cooldownTimeLeft  = cdLeft,
                  totalCooldownTime = cdTotal },
            },
        },
    }
end

local function reset()
    pulsedIconNum = nil
    WCDP.db.potions = { enabled = true, mincooldown = 30 }
    DataUtils.GetItems = function() return {} end
    -- Intercept FirePotionPulse to capture icon without needing full window stack
    WCDP._origFirePotionPulse = WCDP._origFirePotionPulse or WCDP.FirePotionPulse
    WCDP.FirePotionPulse = function(iconNum) pulsedIconNum = iconNum end
    WCDP.Reinitialize()
end

local function teardown()
    -- Restore real FirePotionPulse after each suite
    if WCDP._origFirePotionPulse then
        WCDP.FirePotionPulse = WCDP._origFirePotionPulse
    end
end

-- ----------------------------------------------------------------

it("potionCooldown: potions disabled — scan does nothing", function()
    reset()
    WCDP.db.potions.enabled = false
    DataUtils.GetItems = function() return makePotion(1, 0, 180, 488) end
    WCDP.ScanPotionCooldowns()
    assert(pulsedIconNum == nil, "no pulse when potions disabled")
end)

it("potionCooldown: empty inventory — no pulse", function()
    reset()
    DataUtils.GetItems = function() return {} end
    WCDP.ScanPotionCooldowns()
    assert(pulsedIconNum == nil, "no pulse on empty inventory")
end)

it("potionCooldown: potion not on cooldown on first scan — no pulse, not tracked", function()
    reset()
    DataUtils.GetItems = function() return makePotion(1, 0, 180, 488) end
    WCDP.ScanPotionCooldowns()
    assert(pulsedIconNum == nil, "no pulse if potion was never on cooldown")
    local cd, _ = WCDP.GetPotionTrackingState()
    assert(cd[1] == nil, "slot not tracked when not on cooldown")
end)

it("potionCooldown: potion on cooldown — tracked, no pulse yet", function()
    reset()
    DataUtils.GetItems = function() return makePotion(1, 120, 180, 488) end
    WCDP.ScanPotionCooldowns()
    assert(pulsedIconNum == nil, "no pulse while still on cooldown")
    local tracked, _ = WCDP.GetPotionTrackingState()
    assert(tracked[1] ~= nil,           "slot 1 should be tracked")
    assert(tracked[1].onCooldown,       "onCooldown flag set")
    assert(tracked[1].timeLeft == 120,  "timeLeft matches cdLeft")
end)

it("potionCooldown: cooldown transitions to 0 — pulse fires", function()
    reset()
    -- First scan: put potion on cooldown
    DataUtils.GetItems = function() return makePotion(1, 120, 180, 488) end
    WCDP.ScanPotionCooldowns()
    assert(pulsedIconNum == nil, "no pulse on first scan (still on cooldown)")
    -- Second scan: cooldown expired
    DataUtils.GetItems = function() return makePotion(1, 0, 180, 488) end
    WCDP.ScanPotionCooldowns()
    assert(pulsedIconNum == 488, "pulse fires when cooldown reaches 0")
end)

it("potionCooldown: mincooldown filter — totalCooldown < mincooldown → no pulse", function()
    reset()
    WCDP.db.potions.mincooldown = 60
    -- totalCooldownTime = 10 s < mincooldown = 60 s
    DataUtils.GetItems = function() return makePotion(1, 10, 10, 488) end
    WCDP.ScanPotionCooldowns()
    DataUtils.GetItems = function() return makePotion(1, 0, 10, 488) end
    WCDP.ScanPotionCooldowns()
    assert(pulsedIconNum == nil, "no pulse when totalCooldown < mincooldown")
end)

it("potionCooldown: mincooldown filter — totalCooldown >= mincooldown → pulse", function()
    reset()
    WCDP.db.potions.mincooldown = 60
    DataUtils.GetItems = function() return makePotion(1, 180, 180, 488) end
    WCDP.ScanPotionCooldowns()
    DataUtils.GetItems = function() return makePotion(1, 0, 180, 488) end
    WCDP.ScanPotionCooldowns()
    assert(pulsedIconNum == 488, "pulse fires when totalCooldown >= mincooldown")
end)

it("potionCooldown: Reinitialize clears tracking", function()
    reset()
    DataUtils.GetItems = function() return makePotion(1, 120, 180, 488) end
    WCDP.ScanPotionCooldowns()
    WCDP.Reinitialize()
    local tracked, pending = WCDP.GetPotionTrackingState()
    assert(next(tracked) == nil, "Reinitialize clears _potionTracked")
    assert(pending == false,     "Reinitialize clears _potionScanPending")
end)

it("potionCooldown: CheckPotionCooldowns decrements timeLeft", function()
    reset()
    DataUtils.GetItems = function() return makePotion(1, 120, 180, 488) end
    WCDP.ScanPotionCooldowns()
    WCDP.CheckPotionCooldowns( 30 )   -- advance 30 s
    local tracked, _ = WCDP.GetPotionTrackingState()
    assert(tracked[1] ~= nil,          "slot still tracked")
    assert(tracked[1].timeLeft == 90,  "timeLeft decremented by dt=30")
end)

it("potionCooldown: CheckPotionCooldowns triggers scan when timeLeft reaches 0", function()
    reset()
    DataUtils.GetItems = function() return makePotion(1, 10, 180, 488) end
    WCDP.ScanPotionCooldowns()
    -- Advance past the cooldown; second scan returns cdLeft=0
    DataUtils.GetItems = function() return makePotion(1, 0, 180, 488) end
    WCDP.CheckPotionCooldowns( 15 )   -- 15 > 10 → expired
    assert(pulsedIconNum == 488, "pulse fires via CheckPotionCooldowns when timer expires")
end)

it("potionCooldown: OnInventorySlotUpdated sets pending flag", function()
    reset()
    local _, pending0 = WCDP.GetPotionTrackingState()
    assert(pending0 == false, "pending starts false")
    WCDP.OnInventorySlotUpdated()
    local _, pending1 = WCDP.GetPotionTrackingState()
    assert(pending1 == true, "pending set after OnInventorySlotUpdated")
end)

it("potionCooldown: pending flag cleared after CheckPotionCooldowns", function()
    reset()
    WCDP.OnInventorySlotUpdated()
    WCDP.CheckPotionCooldowns( 0.016 )
    local _, pending = WCDP.GetPotionTrackingState()
    assert(pending == false, "pending cleared after scan runs")
end)

it("potionCooldown: two potions tracked independently — only expired one pulses", function()
    reset()
    -- slot 1: 120 s cooldown; slot 2: 10 s cooldown
    DataUtils.GetItems = function()
        local t = makePotion(1, 120, 180, 488)
        t[2] = {
            type   = GameData.ItemTypes.POTION,
            iconNum = 500,
            bonus  = { { type = GameDefs.ITEMBONUS_USE,
                         cooldownTimeLeft  = 10,
                         totalCooldownTime = 180 } },
        }
        return t
    end
    WCDP.ScanPotionCooldowns()
    -- slot 2 expires, slot 1 still active
    DataUtils.GetItems = function()
        local t = makePotion(1, 120, 180, 488)
        t[2] = {
            type   = GameData.ItemTypes.POTION,
            iconNum = 500,
            bonus  = { { type = GameDefs.ITEMBONUS_USE,
                         cooldownTimeLeft  = 0,
                         totalCooldownTime = 180 } },
        }
        return t
    end
    WCDP.ScanPotionCooldowns()
    assert(pulsedIconNum == 500, "only the expired potion (slot 2, icon=500) pulses")
    local tracked, _ = WCDP.GetPotionTrackingState()
    assert(tracked[1] ~= nil, "slot 1 still tracked")
    assert(tracked[2] == nil, "slot 2 no longer tracked after expiry")
end)

teardown()
