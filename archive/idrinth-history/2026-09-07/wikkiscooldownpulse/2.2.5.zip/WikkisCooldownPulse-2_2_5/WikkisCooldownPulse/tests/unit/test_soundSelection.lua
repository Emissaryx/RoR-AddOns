-- Tests for WCDP.PlayPulseSound (sound key selection, 2.1.2) and the
-- time-based sound queue (FIX 2.2.0 — replaces the hook-call counter of 2.1.3).

local lastSoundPlayed = nil

local function reset()
    lastSoundPlayed = nil
    WCDP.db.general.sound    = true
    WCDP.db.general.soundKey = "HELP_TIPS_NEW"
    PlaySound = function(id) lastSoundPlayed = id end
    WCDP.Reinitialize()
end

it("soundSelection: sound disabled skips playback", function()
    reset()
    WCDP.db.general.sound = false
    WCDP.PlayPulseSound()
    assert(lastSoundPlayed == nil, "no sound played when general.sound=false")
end)

it("soundSelection: soundKey NONE skips playback even when sound enabled", function()
    reset()
    WCDP.db.general.soundKey = "NONE"
    WCDP.PlayPulseSound()
    assert(lastSoundPlayed == nil, "no sound played for key NONE")
end)

it("soundSelection: HELP_TIPS_NEW plays correct GameData.Sound id", function()
    reset()
    WCDP.db.general.soundKey = "HELP_TIPS_NEW"
    WCDP.PlayPulseSound()
    assert(lastSoundPlayed == GameData.Sound.HELP_TIPS_NEW,
           "should play HELP_TIPS_NEW (id=" .. tostring(GameData.Sound.HELP_TIPS_NEW) .. ")")
end)

it("soundSelection: QUEST_OBJECTIVES_COMPLETED plays correct id", function()
    reset()
    WCDP.db.general.soundKey = "QUEST_OBJECTIVES_COMPLETED"
    WCDP.PlayPulseSound()
    assert(lastSoundPlayed == GameData.Sound.QUEST_OBJECTIVES_COMPLETED,
           "should play QUEST_OBJECTIVES_COMPLETED")
end)

it("soundSelection: TOME_CLOSE plays correct id", function()
    reset()
    WCDP.db.general.soundKey = "TOME_CLOSE"
    WCDP.PlayPulseSound()
    assert(lastSoundPlayed == GameData.Sound.TOME_CLOSE, "should play TOME_CLOSE")
end)

it("soundSelection: QUEST_COMPLETED plays correct id", function()
    reset()
    WCDP.db.general.soundKey = "QUEST_COMPLETED"
    WCDP.PlayPulseSound()
    assert(lastSoundPlayed == GameData.Sound.QUEST_COMPLETED, "should play QUEST_COMPLETED")
end)

it("soundSelection: QUEST_ACCEPTED plays correct id", function()
    reset()
    WCDP.db.general.soundKey = "QUEST_ACCEPTED"
    WCDP.PlayPulseSound()
    assert(lastSoundPlayed == GameData.Sound.QUEST_ACCEPTED, "should play QUEST_ACCEPTED")
end)

it("soundSelection: missing soundKey falls back to HELP_TIPS_NEW", function()
    reset()
    WCDP.db.general.soundKey = nil
    WCDP.PlayPulseSound()
    assert(lastSoundPlayed == GameData.Sound.HELP_TIPS_NEW,
           "nil soundKey must fall back to HELP_TIPS_NEW")
end)

it("soundSelection: unknown soundKey plays nothing (GameData.Sound[key]=nil)", function()
    reset()
    WCDP.db.general.soundKey = "SOME_NONEXISTENT_SOUND"
    WCDP.PlayPulseSound()
    assert(lastSoundPlayed == nil, "no sound played for unknown key")
end)

it("soundSelection: Sound.Play fallback used when PlaySound absent", function()
    reset()
    WCDP.db.general.soundKey = "HELP_TIPS_NEW"
    PlaySound = nil
    local fallbackCalled = nil
    Sound = { Play = function(id) fallbackCalled = id end }
    WCDP.PlayPulseSound()
    assert(fallbackCalled == GameData.Sound.HELP_TIPS_NEW, "Sound.Play fallback should fire")
    Sound = nil
    PlaySound = function(id) lastSoundPlayed = id end
end)

it("soundSelection: WCDP.SoundList contains exactly 2 entries (NONE + HELP_TIPS_NEW)", function()
    local keys = {}
    for _, opt in ipairs(WCDP.SoundList) do keys[opt.key] = true end
    assert(keys["NONE"],          "NONE entry expected")
    assert(keys["HELP_TIPS_NEW"], "HELP_TIPS_NEW entry expected")
    assert(#WCDP.SoundList == 2,  "exactly 2 entries in SoundList")
end)

-- ============================================================
-- FIX (2.2.0 / CHANTIER 4): time-based sound queue tests.
--
-- The 2.1.3 fix used a hook-call counter (_soundCooldown = 30) decremented
-- in OnAbilityUpdate.  This broke because OnAbilityUpdate fires once per
-- *visible action button* per frame (10-30x/frame), so "30 hook calls"
-- expired in 1-3 real frames — far too fast.  With no action buttons visible
-- (morale-only frame), the counter never decremented and sounds were stuck.
--
-- The 2.2.0 fix: _soundCooldown is a float (seconds), decremented by real
-- elapsed time via OnUpdate(timePassed) from WCDPTimerFrame.  Tests pass
-- explicit time deltas to TickSoundQueue() to advance the clock.
-- ============================================================

it("soundQueue: second PlayPulseSound is queued, not played immediately", function()
    reset()
    WCDP.PlayPulseSound()   -- first: plays immediately, starts cooldown
    assert(lastSoundPlayed == GameData.Sound.HELP_TIPS_NEW, "first sound plays immediately")

    lastSoundPlayed = nil
    WCDP.PlayPulseSound()   -- second: cooldown > 0, must queue
    assert(lastSoundPlayed == nil, "second sound must not play while cooldown > 0")

    local cooldown, queue = WCDP.GetSoundQueueState()
    assert(cooldown > 0,                  "cooldown must be > 0 after first play (time-based)")
    assert(#queue == 1,                   "one sound in queue")
    assert(queue[1] == "HELP_TIPS_NEW",   "queued key is correct")
end)

it("soundQueue: queued sound plays after cooldown drains via TickSoundQueue(dt)", function()
    reset()
    WCDP.PlayPulseSound()   -- plays, starts cooldown
    lastSoundPlayed = nil
    WCDP.PlayPulseSound()   -- queued

    local cooldown, _ = WCDP.GetSoundQueueState()
    assert(cooldown > 0, "cooldown must be > 0 after first play")

    -- Advance clock past the cooldown in one step (0.2 s > SOUND_COOLDOWN_SECS = 0.15 s)
    WCDP.TickSoundQueue( 0.2 )

    assert(lastSoundPlayed == GameData.Sound.HELP_TIPS_NEW,
           "queued sound must play once cooldown reaches zero")

    local cooldown2, queue2 = WCDP.GetSoundQueueState()
    assert(#queue2 == 0,   "queue empty after drain")
    assert(cooldown2 > 0,  "new cooldown started after queued sound played")
end)

it("soundQueue: partial advance does not drain queue early", function()
    reset()
    WCDP.PlayPulseSound()   -- plays, cooldown = 0.15 s
    lastSoundPlayed = nil
    WCDP.PlayPulseSound()   -- queued

    -- Advance only 0.05 s — still within cooldown window
    WCDP.TickSoundQueue( 0.05 )
    assert(lastSoundPlayed == nil, "queue must not drain while cooldown > 0")

    local cooldown, queue = WCDP.GetSoundQueueState()
    assert(cooldown > 0, "cooldown must still be > 0 after partial advance")
    assert(#queue == 1,  "sound still queued")
end)

it("soundQueue: OnUpdate drives both tick and drain end-to-end", function()
    -- This test simulates the actual in-game path: OnUpdate(timePassed) calls
    -- TickSoundQueue.  In 2.1.3 this path went through OnAbilityUpdate (broken).
    reset()
    WCDP.PlayPulseSound()   -- plays
    lastSoundPlayed = nil
    WCDP.PlayPulseSound()   -- queued

    -- Simulate two rendered frames at 30 fps (~33 ms each)
    WCDP.OnUpdate( 0.033 )
    WCDP.OnUpdate( 0.033 )
    WCDP.OnUpdate( 0.033 )
    WCDP.OnUpdate( 0.033 )
    WCDP.OnUpdate( 0.033 )
    -- After 5 * 33ms = 165 ms > 150 ms = SOUND_COOLDOWN_SECS, queue must drain
    assert(lastSoundPlayed == GameData.Sound.HELP_TIPS_NEW,
           "queued sound must play after sufficient OnUpdate ticks")
end)

it("soundQueue: Reinitialize clears queue and cooldown", function()
    reset()
    WCDP.PlayPulseSound()   -- plays, cooldown > 0
    WCDP.PlayPulseSound()   -- queued
    WCDP.Reinitialize()
    local cooldown, queue = WCDP.GetSoundQueueState()
    assert(cooldown == 0, "Reinitialize must reset _soundCooldown to 0")
    assert(#queue   == 0, "Reinitialize must clear _soundQueue")
end)
