--
-- WCDP test runner.
-- Run from the tests/ directory:
--   lua run_tests.lua
--
-- Or from the addon root:
--   lua tests/run_tests.lua
--

local tests_passed = 0
local tests_failed = 0

function it(name, fn)
    local ok, err = pcall(fn)
    if ok then
        tests_passed = tests_passed + 1
        print("[PASS] " .. name)
    else
        tests_failed = tests_failed + 1
        print("[FAIL] " .. name)
        print("       " .. tostring(err))
    end
end

-- Determine base path relative to this file
local base = (arg and arg[0]) and arg[0]:match("^(.*[/\\])") or ""
local function src(rel)
    return base .. rel
end

-- Load stubs first
dofile(src("stubs/api_stubs.lua"))

-- Load source files
WCDP = {}
WCDPConfig = {}  -- prevents config files from early-return

-- Profiles.lua must be loaded before wcdp.lua
dofile(src("../Source/Profiles.lua"))
dofile(src("../Source/wcdp.lua"))

-- Initialize a minimal WCDP state so the internal 'db' local is set.
-- The profile includes all keys from DefaultSettings (including 2.2.0 additions)
-- so updateSettings migration is also exercised by the test run.
WCDP.Profiles = {
    active  = 1,
    names   = { [1] = "TestDefault" },
    data    = { [1] = {
        general = {
            debug             = false,
            version           = { MAJOR=2, MINOR=1, REV=3 },  -- intentionally old to test upgrade
            testmode          = false,
            enablewhitelist   = false,
            enableblacklist   = false,
            sound             = true,
            soundKey          = "HELP_TIPS_NEW",
            showMinimapButton = true,
        },
        anchor = {
            point    = "center", relwin = "Root", relpoint = "center",
            scale    = 0.75, x = 0, y = 0, dx = 192, dy = 192,
        },
        alpha       = { start = 0.2, finish = 0.6, speed = 0.2 },
        blacklist   = {},
        whitelist   = {},
        abilities   = {
            actions = { enabled = true,  mincooldown = 4 },
            morale  = { enabled = true,  mincooldown = 4, onavailable = true },
            pet     = { enabled = true,  mincooldown = 4 },
        },
        -- lowhealth intentionally omitted here to test updateSettings migration
    }},
    perchar = {},
}
-- ActivateProfile(source, force=true) bypasses the early-return guard "active == source"
-- and runs OnProfileChanged(), which sets the internal 'db' local inside wcdp.lua.
-- updateSettings() will fill in moraleAnchor/petAnchor/healthAnchor/lowhealth from
-- DefaultSettings automatically.
WCDP.ActivateProfile( 1, true )

print("\n=== WCDP Unit Tests ===\n")

-- Run each test suite
dofile(src("unit/test_updateSettings.lua"))
dofile(src("unit/test_peakTracking.lua"))
dofile(src("unit/test_moraleAllowed.lua"))
dofile(src("unit/test_moraleAvailable.lua"))
dofile(src("unit/test_soundSelection.lua"))
dofile(src("unit/test_firePulseRouting.lua"))
dofile(src("unit/test_lowHealth.lua"))

print(string.format("\n=== Results: %d passed, %d failed ===",
      tests_passed, tests_failed))
os.exit(tests_failed > 0 and 1 or 0)
