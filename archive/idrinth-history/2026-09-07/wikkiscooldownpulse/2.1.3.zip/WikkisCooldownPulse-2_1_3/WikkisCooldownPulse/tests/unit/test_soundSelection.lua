-- Tests for WCDP.PlayPulseSound with sound key selection (2.1.2) and
-- sound queue debounce mechanism (2.1.3).

local lastSoundPlayed = nil

local function reset()
    lastSoundPlayed = nil
    WCDP.db.general.sound    = true
    WCDP.db.general.soundKey = "HELP_TIPS_NEW"
    PlaySound = function(id) lastSoundPlayed = id end
    -- FIX (2.1.3): reset sound queue state so each test starts with a clean slate.
    -- Without this, PlayPulseSoundDirect sets _soundCooldown=30, and the next
    -- test's PlayPulseSound() would queue instead of playing immediately.
    WCDP.Reinitialize()
end

it("soundSelection: sound disabled skips playback", function()
    reset()
    WCDP.db.general.sound = false
    WCDP.PlayPulseSound()
    assert(lastSoundPlayed == nil, "no sound played when general.sound=false")
end)

it("soundSelection: soundKey NONE skips playback even when sound enabled", function()
    reset()
    WCDP.db.general.soundKey = "NONE"
    WCDP.PlayPulseSound()
    assert(lastSoundPlayed == nil, "no sound played for key NONE")
end)

it("soundSelection: HELP_TIPS_NEW plays correct GameData.Sound id", function()
    reset()
    WCDP.db.general.soundKey = "HELP_TIPS_NEW"
    WCDP.PlayPulseSound()
    assert(lastSoundPlayed == GameData.Sound.HELP_TIPS_NEW,
           "should play HELP_TIPS_NEW (id=" .. tostring(GameData.Sound.HELP_TIPS_NEW) .. ")")
end)

it("soundSelection: QUEST_OBJECTIVES_COMPLETED plays correct id", function()
    reset()
    WCDP.db.general.soundKey = "QUEST_OBJECTIVES_COMPLETED"
    WCDP.PlayPulseSound()
    assert(lastSoundPlayed == GameData.Sound.QUEST_OBJECTIVES_COMPLETED,
           "should play QUEST_OBJECTIVES_COMPLETED")
end)

it("soundSelection: TOME_CLOSE plays correct id", function()
    reset()
    WCDP.db.general.soundKey = "TOME_CLOSE"
    WCDP.PlayPulseSound()
    assert(lastSoundPlayed == GameData.Sound.TOME_CLOSE, "should play TOME_CLOSE")
end)

it("soundSelection: QUEST_COMPLETED plays correct id", function()
    reset()
    WCDP.db.general.soundKey = "QUEST_COMPLETED"
    WCDP.PlayPulseSound()
    assert(lastSoundPlayed == GameData.Sound.QUEST_COMPLETED, "should play QUEST_COMPLETED")
end)

it("soundSelection: QUEST_ACCEPTED plays correct id", function()
    reset()
    WCDP.db.general.soundKey = "QUEST_ACCEPTED"
    WCDP.PlayPulseSound()
    assert(lastSoundPlayed == GameData.Sound.QUEST_ACCEPTED, "should play QUEST_ACCEPTED")
end)

it("soundSelection: missing soundKey falls back to HELP_TIPS_NEW", function()
    reset()
    WCDP.db.general.soundKey = nil
    WCDP.PlayPulseSound()
    assert(lastSoundPlayed == GameData.Sound.HELP_TIPS_NEW,
           "nil soundKey must fall back to HELP_TIPS_NEW")
end)

it("soundSelection: unknown soundKey plays nothing (GameData.Sound[key]=nil)", function()
    reset()
    WCDP.db.general.soundKey = "SOME_NONEXISTENT_SOUND"
    WCDP.PlayPulseSound()
    assert(lastSoundPlayed == nil, "no sound played for unknown key")
end)

it("soundSelection: Sound.Play fallback used when PlaySound absent", function()
    reset()
    WCDP.db.general.soundKey = "HELP_TIPS_NEW"
    PlaySound = nil  -- remove the primary API
    local fallbackCalled = nil
    Sound = { Play = function(id) fallbackCalled = id end }
    WCDP.PlayPulseSound()
    assert(fallbackCalled == GameData.Sound.HELP_TIPS_NEW, "Sound.Play fallback should fire")
    Sound = nil  -- clean up
    PlaySound = function(id) lastSoundPlayed = id end   -- restore
end)

it("soundSelection: WCDP.SoundList contains all 6 expected entries", function()
    local keys = {}
    for _, opt in ipairs(WCDP.SoundList) do keys[opt.key] = true end
    assert(keys["NONE"],                       "NONE entry expected")
    assert(keys["HELP_TIPS_NEW"],              "HELP_TIPS_NEW entry expected")
    assert(keys["QUEST_OBJECTIVES_COMPLETED"], "QUEST_OBJECTIVES_COMPLETED entry expected")
    assert(keys["QUEST_COMPLETED"],            "QUEST_COMPLETED entry expected")
    assert(keys["QUEST_ACCEPTED"],             "QUEST_ACCEPTED entry expected")
    assert(keys["TOME_CLOSE"],                 "TOME_CLOSE entry expected")
    assert(#WCDP.SoundList == 6,               "exactly 6 entries in SoundList")
end)

-- FIX (2.1.3): sound queue debounce tests.
-- When two pulses fire in the same frame, PlaySound is called twice in rapid
-- succession and the client silently drops the second call.  The queue mechanism
-- delays the second sound by ~30 hook invocations (≈ 1 rendered frame) so both
-- sounds are audible.

it("soundQueue: second PlayPulseSound is queued, not played immediately", function()
    reset()
    -- First call: plays immediately, starts cooldown
    WCDP.PlayPulseSound()
    assert(lastSoundPlayed == GameData.Sound.HELP_TIPS_NEW, "first sound plays immediately")
    -- Second call while cooldown active: must be queued
    lastSoundPlayed = nil
    WCDP.PlayPulseSound()
    assert(lastSoundPlayed == nil, "second sound must not play while cooldown > 0")
    local _, queue = WCDP.GetSoundQueueState()
    assert(#queue == 1,                    "one sound in queue")
    assert(queue[1] == "HELP_TIPS_NEW",    "queued key is correct")
end)

it("soundQueue: queued sound plays after cooldown drains via TickSoundQueue", function()
    reset()
    WCDP.PlayPulseSound()           -- first sound plays, cooldown set to 30
    lastSoundPlayed = nil
    WCDP.PlayPulseSound()           -- second sound queued
    local cooldown, _ = WCDP.GetSoundQueueState()
    assert(cooldown == 30, "cooldown should be 30 after first play")
    -- Drain the counter one tick at a time
    for _ = 1, cooldown do WCDP.TickSoundQueue() end
    assert(lastSoundPlayed == GameData.Sound.HELP_TIPS_NEW,
           "queued sound must play once cooldown reaches zero")
    local cooldown2, queue2 = WCDP.GetSoundQueueState()
    assert(#queue2 == 0, "queue empty after drain")
    assert(cooldown2 == 30, "new cooldown started after queued sound played")
end)

it("soundQueue: Reinitialize clears queue and cooldown", function()
    reset()
    WCDP.PlayPulseSound()   -- plays, cooldown = 30
    WCDP.PlayPulseSound()   -- queued
    WCDP.Reinitialize()
    local cooldown, queue = WCDP.GetSoundQueueState()
    assert(cooldown == 0, "Reinitialize must reset _soundCooldown to 0")
    assert(#queue   == 0, "Reinitialize must clear _soundQueue")
end)
