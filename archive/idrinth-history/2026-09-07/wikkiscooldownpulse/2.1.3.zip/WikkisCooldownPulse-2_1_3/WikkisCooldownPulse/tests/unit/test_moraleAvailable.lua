-- Tests for WCDP.OnPlayerMoraleUpdated (onavailable=true path).
-- Readiness rule: calc = (perc/threshold)*100 >= 99  AND  cooldown <= gcd

local pulsedRanks = {}

-- Spy: capture PulseMoraleRank calls instead of running real API calls.
local origPulseMoraleRank = WCDP.PulseMoraleRank
WCDP.PulseMoraleRank = function(rank) pulsedRanks[rank] = true end

local function reset()
    pulsedRanks = {}
    WCDP.db.abilities.morale.enabled     = true
    WCDP.db.abilities.morale.onavailable = true
    WCDP.Reinitialize()   -- clears _moraleReady table
    -- Default stubs: GetMoralePercentForLevel(r) = 25*r, GetMoraleCooldown(r) = 0, 60
end

it("moraleAvailable: onavailable=false causes early return", function()
    reset()
    WCDP.db.abilities.morale.onavailable = false
    WCDP.OnPlayerMoraleUpdated(10.0, 1)
    assert(next(pulsedRanks) == nil, "no pulse when onavailable is false")
    WCDP.db.abilities.morale.onavailable = true
end)

it("moraleAvailable: morale disabled causes early return", function()
    reset()
    WCDP.db.abilities.morale.enabled = false
    WCDP.Reinitialize()
    WCDP.OnPlayerMoraleUpdated(25.0, 1)
    assert(next(pulsedRanks) == nil, "no pulse when morale disabled")
end)

it("moraleAvailable: rank 1 at exactly 100% threshold triggers pulse", function()
    -- threshold(1) = 25, so moralePercent = 25 => calc = 100 >= 99
    -- cooldown = 0 <= gcd(1.61)
    reset()
    GetMoraleCooldown = function() return 0, 60 end
    WCDP.OnPlayerMoraleUpdated(25.0, 1)
    assert(pulsedRanks[1] == true, "rank 1 should pulse at moralePercent=25 (=threshold)")
end)

it("moraleAvailable: rank 1 at 98% of threshold does not trigger pulse", function()
    -- threshold(1)=25, moralePercent=24.5 => calc = 98 < 99
    reset()
    GetMoraleCooldown = function() return 0, 60 end
    WCDP.OnPlayerMoraleUpdated(24.5, 1)
    assert(pulsedRanks[1] == nil, "no pulse: calc(98) < 99")
end)

it("moraleAvailable: rank 1 full but on cooldown does not trigger pulse", function()
    -- calc >= 99 but cooldown > gcd
    reset()
    GetMoraleCooldown = function() return 5.0, 60 end   -- cooldown=5 > gcd(1.61)
    WCDP.OnPlayerMoraleUpdated(25.0, 1)
    assert(pulsedRanks[1] == nil, "no pulse: cooldown(5.0) > gcd(1.61)")
    GetMoraleCooldown = function() return 0, 60 end   -- restore
end)

it("moraleAvailable: pulse only fires on not-ready -> ready transition", function()
    reset()
    GetMoraleCooldown = function() return 0, 60 end
    -- First call at full: should pulse
    WCDP.OnPlayerMoraleUpdated(25.0, 1)
    assert(pulsedRanks[1] == true, "first call: pulse expected")
    pulsedRanks = {}
    -- Second call still full: _moraleReady[1] is now true, no pulse
    WCDP.OnPlayerMoraleUpdated(25.0, 1)
    assert(pulsedRanks[1] == nil, "second call: no pulse (already ready)")
end)

it("moraleAvailable: dropping below threshold and recovering triggers pulse again", function()
    reset()
    GetMoraleCooldown = function() return 0, 60 end
    WCDP.OnPlayerMoraleUpdated(25.0, 1)   -- becomes ready
    pulsedRanks = {}
    WCDP.OnPlayerMoraleUpdated(20.0, 1)   -- drops below (calc=80 < 99), _moraleReady[1] = false
    assert(pulsedRanks[1] == nil, "no pulse on drop")
    pulsedRanks = {}
    WCDP.OnPlayerMoraleUpdated(25.0, 1)   -- becomes ready again
    assert(pulsedRanks[1] == true, "pulse on re-reaching threshold")
end)

it("moraleAvailable: Reinitialize clears _moraleReady so rank pulses again", function()
    reset()
    GetMoraleCooldown = function() return 0, 60 end
    WCDP.OnPlayerMoraleUpdated(25.0, 1)   -- sets _moraleReady[1] = true
    pulsedRanks = {}
    WCDP.Reinitialize()                   -- clears _moraleReady
    WCDP.OnPlayerMoraleUpdated(25.0, 1)   -- should pulse again (ready state forgotten)
    assert(pulsedRanks[1] == true, "pulse after Reinitialize clears _moraleReady")
end)

it("moraleAvailable: ranks are independent (rank 2 full does not pulse rank 1)", function()
    reset()
    GetMoraleCooldown = function() return 0, 60 end
    -- threshold(1)=25, threshold(2)=50, threshold(3)=75, threshold(4)=100
    -- moralePercent=50 => rank1 calc=200>=99 (pulses), rank2 calc=100>=99 (pulses),
    --                      rank3 calc=66<99, rank4 calc=50<99
    WCDP.OnPlayerMoraleUpdated(50.0, 2)
    assert(pulsedRanks[3] == nil, "rank 3 should not pulse (calc=66)")
    assert(pulsedRanks[4] == nil, "rank 4 should not pulse (calc=50)")
end)

-- Restore PulseMoraleRank
WCDP.PulseMoraleRank = origPulseMoraleRank
