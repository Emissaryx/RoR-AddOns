-- Tests for WCDP.PerformAbilityUpdate: peak tracking + pulse decision.
-- ABILITY type = Player.AbilityType.ABILITY = 1, cooldownLookup[1] = 4 sec.
-- GENERAL_GCD = 1.61 sec.

local ID = 42   -- test ability id
local pulseFired

-- Replace FirePulse with a spy so we can detect calls without running UI code.
local origFirePulse = WCDP.FirePulse
WCDP.FirePulse = function(id) pulseFired = id end

local function reset()
    pulseFired = nil
    WCDP.db.general.enablewhitelist = false
    WCDP.db.general.enableblacklist = false
    WCDP.db.blacklist                = {}
    WCDP.db.whitelist                = {}
    WCDP.db.abilities.actions.enabled = true
    WCDP.db.abilities.actions.mincooldown = 4
    WCDP.Reinitialize()
end

it("peakTracking: cooldown > 0 records peak and does not pulse", function()
    reset()
    WCDP.PerformAbilityUpdate(ID, 5.0, 6.0, 5.0)
    assert(pulseFired == nil, "no pulse expected while cooldown > 0")
end)

it("peakTracking: cooldown 0 after real peak fires pulse", function()
    reset()
    WCDP.PerformAbilityUpdate(ID, 5.0, 6.0, 5.0)  -- record peak 6.0
    WCDP.PerformAbilityUpdate(ID, 0,   nil, nil)   -- expire
    assert(pulseFired == ID, "pulse expected after cooldown expires (peak=6.0 >= mincooldown=4)")
end)

it("peakTracking: peak at exactly mincooldown fires pulse", function()
    reset()
    WCDP.PerformAbilityUpdate(ID, 4.0, 4.0, 4.0)
    WCDP.PerformAbilityUpdate(ID, 0, nil, nil)
    assert(pulseFired == ID, "pulse expected: peak(4.0) >= mincooldown(4.0)")
end)

it("peakTracking: peak below mincooldown suppresses pulse", function()
    reset()
    WCDP.PerformAbilityUpdate(ID, 3.0, 3.0, 3.0)
    WCDP.PerformAbilityUpdate(ID, 0, nil, nil)
    assert(pulseFired == nil, "no pulse: peak(3.0) < mincooldown(4.0)")
end)

it("peakTracking: peak at GCD suppresses pulse", function()
    reset()
    WCDP.PerformAbilityUpdate(ID, 1.61, 1.61, 1.61)
    WCDP.PerformAbilityUpdate(ID, 0, nil, nil)
    assert(pulseFired == nil, "no pulse: peak(1.61) <= GENERAL_GCD(1.61)")
end)

it("peakTracking: peak below GCD suppresses pulse", function()
    reset()
    WCDP.PerformAbilityUpdate(ID, 1.0, 1.5, 1.5)
    WCDP.PerformAbilityUpdate(ID, 0, nil, nil)
    assert(pulseFired == nil, "no pulse: peak(1.5) <= GENERAL_GCD(1.61)")
end)

it("peakTracking: cooldown 0 with no prior tracking is ignored", function()
    reset()
    WCDP.PerformAbilityUpdate(ID, 0, nil, nil)
    assert(pulseFired == nil, "no pulse: ability was never tracked in this cycle")
end)

it("peakTracking: blacklisted ability is skipped entirely", function()
    reset()
    WCDP.db.general.enableblacklist = true
    WCDP.db.blacklist = { 999 }
    WCDP.Reinitialize()
    WCDP.PerformAbilityUpdate(999, 5.0, 6.0, 5.0)
    WCDP.PerformAbilityUpdate(999, 0, nil, nil)
    assert(pulseFired == nil, "no pulse: ability 999 is blacklisted")
end)

it("peakTracking: whitelist-exclusive mode skips ability not in list", function()
    reset()
    WCDP.db.general.enablewhitelist = true
    WCDP.db.whitelist = {}   -- empty: nothing whitelisted
    WCDP.Reinitialize()
    WCDP.PerformAbilityUpdate(77, 5.0, 6.0, 5.0)
    WCDP.PerformAbilityUpdate(77, 0, nil, nil)
    assert(pulseFired == nil, "no pulse: ability 77 absent from whitelist")
end)

it("peakTracking: disabled action type adds to blacklist and suppresses pulse", function()
    reset()
    WCDP.db.abilities.actions.enabled = false
    WCDP.Reinitialize()
    WCDP.PerformAbilityUpdate(ID, 5.0, 6.0, 5.0)
    WCDP.PerformAbilityUpdate(ID, 0, nil, nil)
    assert(pulseFired == nil, "no pulse: action type is disabled")
end)

it("peakTracking: nil abilityId returns without error", function()
    reset()
    WCDP.PerformAbilityUpdate(nil, 5.0, 6.0, 5.0)
    assert(pulseFired == nil, "no pulse on nil abilityId")
end)

it("peakTracking: nil cooldown returns without error", function()
    reset()
    WCDP.PerformAbilityUpdate(ID, nil, 6.0, 5.0)
    assert(pulseFired == nil, "no pulse on nil cooldown")
end)

it("peakTracking: peak is highest of cooldown / initialMax / currentMax", function()
    reset()
    -- initialMaxCooldown (8.0) is the highest value; peak should be 8.0
    WCDP.PerformAbilityUpdate(ID, 5.0, 8.0, 3.0)
    WCDP.PerformAbilityUpdate(ID, 0, nil, nil)
    assert(pulseFired == ID, "pulse expected: peak driven by initialMaxCooldown=8.0 >= mincooldown(4)")
end)

-- Restore original FirePulse
WCDP.FirePulse = origFirePulse
