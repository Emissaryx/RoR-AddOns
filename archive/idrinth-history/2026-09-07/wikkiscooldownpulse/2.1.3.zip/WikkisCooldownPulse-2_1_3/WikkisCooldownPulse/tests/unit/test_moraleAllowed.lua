-- Tests for WCDP.MoraleAllowed(abilityId).
-- Controls whether a morale ability can produce a pulse.

local function reset()
    WCDP.db.general.enablewhitelist = false
    WCDP.db.general.enableblacklist = false
    WCDP.db.blacklist = {}
    WCDP.db.whitelist = {}
    WCDP.db.abilities.morale.enabled = true
    WCDP.Reinitialize()
end

it("moraleAllowed: nil abilityId returns false", function()
    reset()
    assert(WCDP.MoraleAllowed(nil) == false, "nil id must return false")
end)

it("moraleAllowed: morale disabled returns false", function()
    reset()
    WCDP.db.abilities.morale.enabled = false
    WCDP.Reinitialize()
    assert(WCDP.MoraleAllowed(5) == false, "false when morale disabled")
end)

it("moraleAllowed: no filters, enabled returns true", function()
    reset()
    assert(WCDP.MoraleAllowed(5) == true, "true with morale enabled and no filters")
end)

it("moraleAllowed: whitelist mode, ability present returns true", function()
    reset()
    WCDP.db.general.enablewhitelist = true
    WCDP.db.whitelist = {}
    WCDP.Reinitialize()
    -- Manually add to whiteList by calling PerformAbilityUpdate as MORALE type,
    -- but that's complex. Instead: re-read the code — MoraleAllowed checks
    -- 'whiteList[abilityId] ~= nil' directly.
    -- We need whiteList populated. In whitelist mode, PerformAbilityUpdate adds to
    -- whiteList when enablewhitelist=false (the else branch). With enablewhitelist=true
    -- it just returns. So whiteList can only be pre-populated via db.whitelist.
    WCDP.db.whitelist = { 5 }
    WCDP.Reinitialize()
    assert(WCDP.MoraleAllowed(5) == true, "true: id 5 is in whitelist")
end)

it("moraleAllowed: whitelist mode, ability absent returns false", function()
    reset()
    WCDP.db.general.enablewhitelist = true
    WCDP.db.whitelist = {}
    WCDP.Reinitialize()
    assert(WCDP.MoraleAllowed(99) == false, "false: id 99 not in empty whitelist")
end)

it("moraleAllowed: blacklist mode, ability present returns false", function()
    reset()
    WCDP.db.general.enableblacklist = true
    WCDP.db.blacklist = { 5 }
    WCDP.Reinitialize()
    assert(WCDP.MoraleAllowed(5) == false, "false: id 5 is blacklisted")
end)

it("moraleAllowed: blacklist mode, ability absent returns true", function()
    reset()
    WCDP.db.general.enableblacklist = true
    WCDP.db.blacklist = {}
    WCDP.Reinitialize()
    assert(WCDP.MoraleAllowed(99) == true, "true: id 99 not blacklisted")
end)
