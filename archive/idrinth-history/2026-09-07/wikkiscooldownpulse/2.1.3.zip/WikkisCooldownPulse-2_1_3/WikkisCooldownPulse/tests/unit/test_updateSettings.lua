-- Tests for Profiles.lua updateSettings (recursive default-fill migration).
-- updateSettings is a local function accessed indirectly through ActivateProfile.

it("updateSettings: existing values are not overwritten", function()
    local p = WCDP.Profiles.data[1]
    p.general.debug = true
    WCDP.ActivateProfile(1, true)
    assert(WCDP.db.general.debug == true, "debug should remain true")
    p.general.debug = false  -- restore
    WCDP.ActivateProfile(1, true)
end)

it("updateSettings: missing key is filled from DefaultSettings", function()
    local p = WCDP.Profiles.data[1]
    p.general.soundKey = nil
    WCDP.ActivateProfile(1, true)
    assert(WCDP.db.general.soundKey == WCDP.DefaultSettings.general.soundKey,
           "missing soundKey should be filled with default")
    -- Restore
    p.general.soundKey = "HELP_TIPS_NEW"
    WCDP.ActivateProfile(1, true)
end)

it("updateSettings: missing nested key is filled recursively", function()
    local p = WCDP.Profiles.data[1]
    p.abilities.pet.mincooldown = nil
    WCDP.ActivateProfile(1, true)
    assert(WCDP.db.abilities.pet.mincooldown == WCDP.DefaultSettings.abilities.pet.mincooldown,
           "missing nested key should be filled with default")
    -- Restore
    p.abilities.pet.mincooldown = 4
    WCDP.ActivateProfile(1, true)
end)

it("updateSettings: missing sub-table is created and filled", function()
    local p = WCDP.Profiles.data[1]
    local saved = p.alpha
    p.alpha = nil
    WCDP.ActivateProfile(1, true)
    assert(type(WCDP.db.alpha) == "table", "missing alpha table should be created")
    assert(WCDP.db.alpha.start == WCDP.DefaultSettings.alpha.start,
           "missing alpha.start should be filled with default")
    -- Restore
    p.alpha = saved
    WCDP.ActivateProfile(1, true)
end)
