--[[
	This application is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
--]]

if not WCDPConfig then return end

local debug = false
--[===[@debug@
debug = true
--@end-debug@]===]

local T      = LibStub( "WAR-AceLocale-3.0" ) : GetLocale( "wcdp", debug )
local LibGUI = LibStub( "LibGUI" )

local db
local initialized = false

-- Radio-group save/restore state (WAR/RoR makes same-parent checkboxes mutually exclusive)
local _genSoundEnabled, _genDebugEnabled, _genMinimapEnabled = false, false, false
local _moEnabled, _moOnAvail, _moSoundEnabled = false, false, false
local _lhEnabled, _lhSoundEnabled             = false, false
local _acEnabled, _acSoundEnabled             = false, false
local _petEnabled, _petSoundEnabled           = false, false

-- ============================================================
-- Navigation pages (registered separately)
-- ============================================================
local window = {
    Name = T["General"], display = {}, W = {},
}
-- P1 (2.3.1): Actions + Morale + Pet merged into one "Abilities" page
local abilitiesConfig = {
    Name = T["Abilities"], display = {}, W = {},
}
local lhConfig = {
    Name = T["Low Health Alert"], display = {}, W = {},
}
local helpConfig = {
    Name = T["Help"], display = {}, W = {},
}

-- ============================================================
-- Helper: standard numeric input field (template + size + anchor)
-- width defaults to NUMERIC_FIELD_WIDTH (50) — pass NUMERIC_FIELD_WIDTH_WIDE
-- (60) for fields that display up to 4 characters (e.g. "0.40", "60.0").
-- ============================================================
local NUMERIC_FIELD_WIDTH = 60   -- all numeric input fields
local DESC_H   = 54   -- UI-4 (2.3.2): standard description height (~3 lines at font_chat_text)
local DESC_H_L = 72   -- extended description height (~4 lines)
local function makeNumericField( parentWindow, anchorTarget, width )
    local e = parentWindow( "Textbox", nil, "WCDPEditBoxNumeric" )
    e:Resize( width or NUMERIC_FIELD_WIDTH )
    e:Show( true )
    e:AnchorTo( anchorTarget, "right", "left", 10, 0 )
    return e
end

-- ============================================================
-- InitializeAll — shared, runs only once
-- ============================================================
local function InitializeAll()
    if initialized then return end
    db = WCDP.db

    local w, e

    -- ──────────────────────────────────────────────────────────
    -- GENERAL sub-window  (360px — 305 + room for Test Pulse button)
    -- ──────────────────────────────────────────────────────────
    w = LibGUI( "window", nil, "WCDPWindowPlain" )
    w:ClearAnchors()
    w:Resize( 400, 830 )
    w:Show( true )
    window.W.General = w
    table.insert( window.display, w )

    e = window.W.General( "Label" )
    e:Resize( 450 )
    e:Align( "leftcenter" )
    e:AnchorTo( window.W.General, "topleft", "topleft", 15, 10 )
    e:Font( "font_clear_medium_bold" )
    e:SetText( T["General"] )
    window.W.General.Title_Label = e

    -- ── Sound ────────────────────────────────────────────────
    e = window.W.General( "Label" )
    e:Resize( 450 )
    e:Align( "leftcenter" )
    e:AnchorTo( window.W.General.Title_Label, "bottomleft", "topleft", 0, 10 )
    e:Font( "font_clear_small_bold" )
    e:SetText( T["Sound"] )
    window.W.General.Sound_SubTitle = e

    e = window.W.General( "Checkbox" )
    e:AnchorTo( window.W.General.Sound_SubTitle, "bottomleft", "topleft", 10, 6 )
    window.W.General.EnableSound_Checkbox = e

    e = window.W.General( "Label" )
    e:Resize( 450 )
    e:Align( "leftcenter" )
    e:AnchorTo( window.W.General.EnableSound_Checkbox, "right", "left", 10, 0 )
    e:Font( "font_chat_text" )
    e:SetText( T["Enable Sound With Pulse"] )
    window.W.General.EnableSound_Label = e

    e = window.W.General( "Label" )
    e:Resize( 215 )
    e:AnchorTo( window.W.General.EnableSound_Checkbox, "bottomleft", "topleft", 0, 8 )
    e:Font( "font_chat_text" )
    e:Align( "leftcenter" )
    e:SetText( T["Select Pulse Sound:"] )
    window.W.General.SoundSelect_Label = e

    e = window.W.General( "combobox", nil, "WCDPComboBox" )
    e:AnchorTo( window.W.General.SoundSelect_Label, "bottomleft", "topleft", 10, 3 )
    for _, opt in ipairs( WCDP.SoundList ) do
        e:Add( towstring( opt.label ) )
    end
    window.W.General.Sound_Combo = e

    -- ── Animation ────────────────────────────────────────────
    e = window.W.General( "Label" )
    e:Resize( 450 )
    e:Align( "leftcenter" )
    e:AnchorTo( window.W.General.Sound_Combo, "bottomleft", "topleft", -20, 12 )
    e:Font( "font_clear_small_bold" )
    e:SetText( T["Animation"] )
    window.W.General.Animation_SubTitle = e

    e = window.W.General( "Label" )
    e:AnchorTo( window.W.General.Animation_SubTitle, "bottomleft", "topleft", 10, 6 )
    e:Font( "font_chat_text" )
    e:Align( "leftcenter" )
    e:SetText( T["Pulse Start Alpha (0 to 1):"] )
    e:Resize( 200, 30 )
    window.W.General.StartAlpha_Label = e

    window.W.General.StartAlpha_TextBox = makeNumericField( window.W.General, window.W.General.StartAlpha_Label )

    e = window.W.General( "Label" )
    e:Resize( 350, DESC_H )
    e:AnchorTo( window.W.General.StartAlpha_Label, "bottomleft", "topleft", 0, 5 )
    e:Font( "font_chat_text" )
    e:Align( "leftcenter" )
    e:SetText( T["desc_start_alpha"] )
    e:WordWrap( true )
    LabelSetTextColor( e.name, 170, 170, 170 )
    window.W.General.StartAlpha_Desc = e

    e = window.W.General( "Label" )
    e:AnchorTo( window.W.General.StartAlpha_Desc, "bottomleft", "topleft", 0, 8 )
    e:Font( "font_chat_text" )
    e:Align( "leftcenter" )
    e:SetText( T["Pulse End Alpha (0 to 1):"] )
    e:Resize( 200, 30 )
    window.W.General.EndAlpha_Label = e

    window.W.General.EndAlpha_TextBox = makeNumericField( window.W.General, window.W.General.EndAlpha_Label )

    e = window.W.General( "Label" )
    e:Resize( 350, DESC_H )
    e:AnchorTo( window.W.General.EndAlpha_Label, "bottomleft", "topleft", 0, 5 )
    e:Font( "font_chat_text" )
    e:Align( "leftcenter" )
    e:SetText( T["desc_end_alpha"] )
    e:WordWrap( true )
    LabelSetTextColor( e.name, 170, 170, 170 )
    window.W.General.EndAlpha_Desc = e

    e = window.W.General( "Label" )
    e:AnchorTo( window.W.General.EndAlpha_Desc, "bottomleft", "topleft", 0, 8 )
    e:Font( "font_chat_text" )
    e:Align( "leftcenter" )
    e:SetText( T["Pulse Speed (sec):"] )
    e:Resize( 200, 30 )
    window.W.General.PulseSpeed_Label = e

    window.W.General.PulseSpeed_TextBox = makeNumericField( window.W.General, window.W.General.PulseSpeed_Label )

    e = window.W.General( "Label" )
    e:Resize( 350, DESC_H_L )
    e:AnchorTo( window.W.General.PulseSpeed_Label, "bottomleft", "topleft", 0, 5 )
    e:Font( "font_chat_text" )
    e:Align( "leftcenter" )
    e:SetText( T["desc_pulse_speed"] )
    e:WordWrap( true )
    LabelSetTextColor( e.name, 170, 170, 170 )
    window.W.General.PulseSpeed_Desc = e

    -- ── Test Pulse button (P11) ──────────────────────────────
    e = window.W.General( "Button", nil, "EA_Button_DefaultResizeable" )
    e:Resize( 130 )
    e:Show( true )
    e:AnchorTo( window.W.General.PulseSpeed_Desc, "bottomleft", "topleft", 0, 10 )
    e:SetText( T["Test Pulse"] )
    e.OnLButtonUp = function()
        local a0 = tonumber( window.W.General.StartAlpha_TextBox:GetText() )
        local a1 = tonumber( window.W.General.EndAlpha_TextBox:GetText() )
        local sp = tonumber( window.W.General.PulseSpeed_TextBox:GetText() )
        WCDP.TestPulse( a0, a1, sp )
    end
    window.W.General.TestPulse_Button = e

    -- ── Display ──────────────────────────────────────────────
    e = window.W.General( "Label" )
    e:Resize( 450 )
    e:Align( "leftcenter" )
    e:AnchorTo( window.W.General.TestPulse_Button, "bottomleft", "topleft", -10, 15 )
    e:Font( "font_clear_small_bold" )
    e:SetText( T["Display"] )
    window.W.General.Display_SubTitle = e

    e = window.W.General( "Checkbox" )
    e:AnchorTo( window.W.General.Display_SubTitle, "bottomleft", "topleft", 10, 8 )
    window.W.General.EnableDebug_Checkbox = e

    e = window.W.General( "Label" )
    e:Resize( 450 )
    e:Align( "leftcenter" )
    e:AnchorTo( window.W.General.EnableDebug_Checkbox, "right", "left", 10, 0 )
    e:Font( "font_chat_text" )
    e:SetText( T["Enable Debug Messages"] )
    window.W.General.EnableDebug_Label = e

    e = window.W.General( "Checkbox" )
    e:AnchorTo( window.W.General.EnableDebug_Checkbox, "bottomleft", "topleft", 0, 10 )
    window.W.General.ShowMinimapButton_Checkbox = e

    e = window.W.General( "Label" )
    e:Resize( 450 )
    e:Align( "leftcenter" )
    e:AnchorTo( window.W.General.ShowMinimapButton_Checkbox, "right", "left", 10, 0 )
    e:Font( "font_chat_text" )
    e:SetText( T["Show Minimap Button"] )
    window.W.General.ShowMinimapButton_Label = e

    -- BUG-B (2.3.3): radio-group fix for the 3 General checkboxes.
    -- UI-C (2.3.4): label click passthrough + CaptureInput on checkboxes.
    -- WAR/RoR makes same-parent checkboxes mutually exclusive; save/restore
    -- the other two states around each click so they are not cleared.
    -- The EA_Button_DefaultCheckBox hit area can be smaller than the visual icon;
    -- making the adjacent text label also handle input extends the clickable zone.
    do
        local sn     = window.W.General.EnableSound_Checkbox
        local sn_lbl = window.W.General.EnableSound_Label
        local db_    = window.W.General.EnableDebug_Checkbox
        local db_lbl = window.W.General.EnableDebug_Label
        local mm     = window.W.General.ShowMinimapButton_Checkbox
        local mm_lbl = window.W.General.ShowMinimapButton_Label

        -- Named functions so labels can share the same logic as checkboxes.
        local function snDown()  _genDebugEnabled = db_:GetValue(); _genMinimapEnabled = mm:GetValue() end
        local function snUp()    _genSoundEnabled = sn:GetValue(); db_:SetValue( _genDebugEnabled ); mm:SetValue( _genMinimapEnabled ) end
        local function dbDown()  _genSoundEnabled = sn:GetValue(); _genMinimapEnabled = mm:GetValue() end
        local function dbUp()    _genDebugEnabled = db_:GetValue(); sn:SetValue( _genSoundEnabled ); mm:SetValue( _genMinimapEnabled ) end
        local function mmDown()  _genSoundEnabled = sn:GetValue(); _genDebugEnabled = db_:GetValue() end
        local function mmUp()    _genMinimapEnabled = mm:GetValue(); sn:SetValue( _genSoundEnabled ); db_:SetValue( _genDebugEnabled ) end

        -- Checkbox click handlers.
        sn:CaptureInput()  ; sn.OnLButtonDown  = snDown ; sn.OnLButtonUp  = snUp
        db_:CaptureInput() ; db_.OnLButtonDown = dbDown ; db_.OnLButtonUp = dbUp
        mm:CaptureInput()  ; mm.OnLButtonDown  = mmDown ; mm.OnLButtonUp  = mmUp

        -- Label click passthrough: clicking the text also toggles the checkbox.
        sn_lbl:CaptureInput()
        sn_lbl.OnLButtonDown = snDown
        sn_lbl.OnLButtonUp   = function() sn:Toggle(); snUp() end
        db_lbl:CaptureInput()
        db_lbl.OnLButtonDown = dbDown
        db_lbl.OnLButtonUp   = function() db_:Toggle(); dbUp() end
        mm_lbl:CaptureInput()
        mm_lbl.OnLButtonDown = mmDown
        mm_lbl.OnLButtonUp   = function() mm:Toggle(); mmUp() end
    end

    -- ──────────────────────────────────────────────────────────
    -- ABILITIES window — Actions + Morale + Pet (merged, P1 v2.3.1)
    -- Three visually-separated sub-sections inside a single nav page.
    -- ──────────────────────────────────────────────────────────
    w = LibGUI( "window", nil, "WCDPWindowPlain" )
    w:ClearAnchors()
    w:Resize( 400, 830 )
    w:Show( true )
    abilitiesConfig.W.Main = w
    table.insert( abilitiesConfig.display, w )

    local ab = abilitiesConfig.W.Main   -- shorthand

    -- ── Section title: Abilities ──────────────────────────────
    e = ab( "Label" )
    e:Resize( 450 )
    e:Align( "leftcenter" )
    e:AnchorTo( ab, "topleft", "topleft", 15, 10 )
    e:Font( "font_clear_medium_bold" )
    e:SetText( T["Abilities"] )
    ab.Title_Label = e

    -- ── Sub-section: Actions ──────────────────────────────────
    e = ab( "Label" )
    e:Resize( 450 )
    e:Align( "leftcenter" )
    e:AnchorTo( ab.Title_Label, "bottomleft", "topleft", 0, 10 )
    e:Font( "font_clear_small_bold" )
    e:SetText( T["Actions"] )
    ab.ActionsTitle_Label = e

    e = ab( "Checkbox" )
    e:AnchorTo( ab.ActionsTitle_Label, "bottomleft", "topleft", 10, 6 )
    ab.EnableAction_Checkbox = e

    e = ab( "Label" )
    e:Resize( 450 )
    e:Align( "leftcenter" )
    e:AnchorTo( ab.EnableAction_Checkbox, "right", "left", 10, 0 )
    e:Font( "font_chat_text" )
    e:SetText( T["Enable Action Pulsing"] )
    ab.EnableAction_Label = e

    e = ab( "Label" )
    e:AnchorTo( ab.EnableAction_Checkbox, "bottomleft", "topleft", 0, 10 )
    e:Font( "font_chat_text" )
    e:Align( "leftcenter" )
    e:SetText( T["Minimum Cooldown (sec):"] )
    e:Resize( 200, 30 )
    ab.ActionMinCD_Label = e

    ab.ActionMinCD_TextBox = makeNumericField( ab, ab.ActionMinCD_Label )

    e = ab( "Label" )
    e:Resize( 350, DESC_H )
    e:AnchorTo( ab.ActionMinCD_Label, "bottomleft", "topleft", 0, 5 )
    e:Font( "font_chat_text" )
    e:Align( "leftcenter" )
    e:SetText( T["desc_min_cooldown_actions"] )
    e:WordWrap( true )
    LabelSetTextColor( e.name, 170, 170, 170 )
    ab.ActionMinCD_Desc = e

    e = ab( "Checkbox" )
    e:AnchorTo( ab.ActionMinCD_Desc, "bottomleft", "topleft", 0, 8 )
    WindowSetDimensions( e.name, 20, 24 )
    ab.ActionSound_Checkbox = e

    e = ab( "Label" )
    e:Resize( 450 )
    e:Align( "leftcenter" )
    e:AnchorTo( ab.ActionSound_Checkbox, "right", "left", 10, 0 )
    e:Font( "font_chat_text" )
    e:SetText( T["Enable Pulse Sound"] )
    ab.ActionSound_Label = e

    -- Radio-group fix: Actions (Enable, Sound)
    do
        local en_cb = ab.EnableAction_Checkbox
        local sn_cb = ab.ActionSound_Checkbox
        en_cb.OnLButtonDown = function() _acSoundEnabled = sn_cb:GetValue() end
        en_cb.OnLButtonUp   = function() _acEnabled = en_cb:GetValue(); sn_cb:SetValue( _acSoundEnabled ) end
        sn_cb.OnLButtonDown = function() _acEnabled = en_cb:GetValue() end
        sn_cb.OnLButtonUp   = function() _acSoundEnabled = sn_cb:GetValue(); en_cb:SetValue( _acEnabled ) end
    end

    -- ── Sub-section: Morale ───────────────────────────────────
    e = ab( "Label" )
    e:Resize( 450 )
    e:Align( "leftcenter" )
    e:AnchorTo( ab.ActionSound_Checkbox, "bottomleft", "topleft", -10, 18 )
    e:Font( "font_clear_small_bold" )
    e:SetText( T["Morale"] )
    ab.MoraleTitle_Label = e

    e = ab( "Checkbox" )
    e:AnchorTo( ab.MoraleTitle_Label, "bottomleft", "topleft", 10, 6 )
    ab.EnableMorale_Checkbox = e

    e = ab( "Label" )
    e:Resize( 450 )
    e:Align( "leftcenter" )
    e:AnchorTo( ab.EnableMorale_Checkbox, "right", "left", 10, 0 )
    e:Font( "font_chat_text" )
    e:SetText( T["Enable Morale Pulsing"] )
    ab.EnableMorale_Label = e

    e = ab( "Label" )
    e:AnchorTo( ab.EnableMorale_Checkbox, "bottomleft", "topleft", 0, 10 )
    e:Font( "font_chat_text" )
    e:Align( "leftcenter" )
    e:SetText( T["Minimum Cooldown (sec):"] )
    e:Resize( 200, 30 )
    ab.MoraleMinCD_Label = e

    ab.MoraleMinCD_TextBox = makeNumericField( ab, ab.MoraleMinCD_Label )

    e = ab( "Label" )
    e:Resize( 350, DESC_H_L )
    e:AnchorTo( ab.MoraleMinCD_Label, "bottomleft", "topleft", 0, 5 )
    e:Font( "font_chat_text" )
    e:Align( "leftcenter" )
    e:SetText( T["desc_min_cooldown_morale"] )
    e:WordWrap( true )
    LabelSetTextColor( e.name, 170, 170, 170 )
    ab.MoraleMinCD_Desc = e

    e = ab( "Checkbox" )
    e:AnchorTo( ab.MoraleMinCD_Desc, "bottomleft", "topleft", 0, 8 )
    ab.OnAvailable_Checkbox = e

    e = ab( "Label" )
    e:Resize( 450 )
    e:Align( "leftcenter" )
    e:AnchorTo( ab.OnAvailable_Checkbox, "right", "left", 10, 0 )
    e:Font( "font_chat_text" )
    e:SetText( T["Pulse When Morale Available"] )
    ab.OnAvailable_Label = e

    e = ab( "Label" )
    e:Resize( 350, DESC_H )
    e:AnchorTo( ab.OnAvailable_Checkbox, "bottomleft", "topleft", 0, 5 )
    e:Font( "font_chat_text" )
    e:Align( "leftcenter" )
    e:SetText( T["desc_on_available"] )
    e:WordWrap( true )
    LabelSetTextColor( e.name, 170, 170, 170 )
    ab.OnAvailable_Desc = e

    e = ab( "Checkbox" )
    e:AnchorTo( ab.OnAvailable_Desc, "bottomleft", "topleft", 0, 8 )
    WindowSetDimensions( e.name, 20, 24 )
    ab.MoraleSound_Checkbox = e

    e = ab( "Label" )
    e:Resize( 450 )
    e:Align( "leftcenter" )
    e:AnchorTo( ab.MoraleSound_Checkbox, "right", "left", 10, 0 )
    e:Font( "font_chat_text" )
    e:SetText( T["Enable Sound With Morale Pulse"] )
    ab.MoraleSound_Label = e

    -- Radio-group fix: Morale (Enable, OnAvailable, Sound)
    do
        local en = ab.EnableMorale_Checkbox
        local av = ab.OnAvailable_Checkbox
        local sn = ab.MoraleSound_Checkbox
        en.OnLButtonDown = function() _moOnAvail = av:GetValue(); _moSoundEnabled = sn:GetValue() end
        en.OnLButtonUp   = function() _moEnabled = en:GetValue(); av:SetValue( _moOnAvail ); sn:SetValue( _moSoundEnabled ) end
        av.OnLButtonDown = function() _moEnabled = en:GetValue(); _moSoundEnabled = sn:GetValue() end
        av.OnLButtonUp   = function() _moOnAvail = av:GetValue(); en:SetValue( _moEnabled ); sn:SetValue( _moSoundEnabled ) end
        sn.OnLButtonDown = function() _moEnabled = en:GetValue(); _moOnAvail = av:GetValue() end
        sn.OnLButtonUp   = function() _moSoundEnabled = sn:GetValue(); en:SetValue( _moEnabled ); av:SetValue( _moOnAvail ) end
    end

    -- ── Sub-section: Pet Abilities ────────────────────────────
    e = ab( "Label" )
    e:Resize( 450 )
    e:Align( "leftcenter" )
    e:AnchorTo( ab.MoraleSound_Checkbox, "bottomleft", "topleft", -10, 18 )
    e:Font( "font_clear_small_bold" )
    e:SetText( T["Pet Abilities"] )
    ab.PetTitle_Label = e

    e = ab( "Checkbox" )
    e:AnchorTo( ab.PetTitle_Label, "bottomleft", "topleft", 10, 6 )
    ab.EnablePet_Checkbox = e

    e = ab( "Label" )
    e:Resize( 450 )
    e:Align( "leftcenter" )
    e:AnchorTo( ab.EnablePet_Checkbox, "right", "left", 10, 0 )
    e:Font( "font_chat_text" )
    e:SetText( T["Enable Pet Ability Pulsing"] )
    ab.EnablePet_Label = e

    e = ab( "Label" )
    e:AnchorTo( ab.EnablePet_Checkbox, "bottomleft", "topleft", 0, 10 )
    e:Font( "font_chat_text" )
    e:Align( "leftcenter" )
    e:SetText( T["Minimum Cooldown (sec):"] )
    e:Resize( 200, 30 )
    ab.PetMinCD_Label = e

    ab.PetMinCD_TextBox = makeNumericField( ab, ab.PetMinCD_Label )

    e = ab( "Label" )
    e:Resize( 350, DESC_H )
    e:AnchorTo( ab.PetMinCD_Label, "bottomleft", "topleft", 0, 5 )
    e:Font( "font_chat_text" )
    e:Align( "leftcenter" )
    e:SetText( T["desc_min_cooldown_pet"] )
    e:WordWrap( true )
    LabelSetTextColor( e.name, 170, 170, 170 )
    ab.PetMinCD_Desc = e

    e = ab( "Checkbox" )
    e:AnchorTo( ab.PetMinCD_Desc, "bottomleft", "topleft", 0, 8 )
    WindowSetDimensions( e.name, 20, 24 )
    ab.PetSound_Checkbox = e

    e = ab( "Label" )
    e:Resize( 450 )
    e:Align( "leftcenter" )
    e:AnchorTo( ab.PetSound_Checkbox, "right", "left", 10, 0 )
    e:Font( "font_chat_text" )
    e:SetText( T["Enable Pulse Sound"] )
    ab.PetSound_Label = e

    -- Radio-group fix: Pet (Enable, Sound)
    do
        local en_cb = ab.EnablePet_Checkbox
        local sn_cb = ab.PetSound_Checkbox
        en_cb.OnLButtonDown = function() _petSoundEnabled = sn_cb:GetValue() end
        en_cb.OnLButtonUp   = function() _petEnabled = en_cb:GetValue(); sn_cb:SetValue( _petSoundEnabled ) end
        sn_cb.OnLButtonDown = function() _petEnabled = en_cb:GetValue() end
        sn_cb.OnLButtonUp   = function() _petSoundEnabled = sn_cb:GetValue(); en_cb:SetValue( _petEnabled ) end
    end

    -- ──────────────────────────────────────────────────────────
    -- LOW HEALTH ALERT window (220px)
    -- ──────────────────────────────────────────────────────────
    w = LibGUI( "window", nil, "WCDPWindowPlain" )
    w:Resize( 400, 830 )
    w:Show( true )
    lhConfig.W.Main = w
    table.insert( lhConfig.display, w )

    e = lhConfig.W.Main( "Label" )
    e:Resize( 450 )
    e:Align( "leftcenter" )
    e:AnchorTo( lhConfig.W.Main, "topleft", "topleft", 15, 10 )
    e:Font( "font_clear_medium_bold" )
    e:SetText( T["Low Health Alert"] )
    lhConfig.W.Main.Title_Label = e

    e = lhConfig.W.Main( "Checkbox" )
    e:AnchorTo( lhConfig.W.Main.Title_Label, "bottomleft", "topleft", 10, 8 )
    lhConfig.W.Main.Enable_Checkbox = e

    e = lhConfig.W.Main( "Label" )
    e:Resize( 450 )
    e:Align( "leftcenter" )
    e:AnchorTo( lhConfig.W.Main.Enable_Checkbox, "right", "left", 10, 0 )
    e:Font( "font_chat_text" )
    e:SetText( T["Enable Low Health Pulse"] )
    lhConfig.W.Main.Enable_Label = e

    e = lhConfig.W.Main( "Label" )
    e:AnchorTo( lhConfig.W.Main.Enable_Checkbox, "bottomleft", "topleft", 0, 10 )
    e:Font( "font_chat_text" )
    e:Align( "leftcenter" )
    e:SetText( T["Low Health Threshold (%):"] )
    e:Resize( 200, 30 )
    lhConfig.W.Main.Threshold_Label = e

    lhConfig.W.Main.Threshold_Textbox = makeNumericField( lhConfig.W.Main, lhConfig.W.Main.Threshold_Label )

    e = lhConfig.W.Main( "Label" )
    e:Resize( 350, DESC_H )
    e:AnchorTo( lhConfig.W.Main.Threshold_Label, "bottomleft", "topleft", 0, 5 )
    e:Font( "font_chat_text" )
    e:Align( "leftcenter" )
    e:SetText( T["desc_lh_threshold"] )
    e:WordWrap( true )
    LabelSetTextColor( e.name, 170, 170, 170 )
    lhConfig.W.Main.Threshold_Desc = e

    e = lhConfig.W.Main( "Label" )
    e:AnchorTo( lhConfig.W.Main.Threshold_Desc, "bottomleft", "topleft", 0, 8 )
    e:Font( "font_chat_text" )
    e:Align( "leftcenter" )
    e:SetText( T["Repeat Interval (sec):"] )
    e:Resize( 200, 30 )
    lhConfig.W.Main.Interval_Label = e

    lhConfig.W.Main.Interval_Textbox = makeNumericField( lhConfig.W.Main, lhConfig.W.Main.Interval_Label )

    e = lhConfig.W.Main( "Label" )
    e:Resize( 350, DESC_H )
    e:AnchorTo( lhConfig.W.Main.Interval_Label, "bottomleft", "topleft", 0, 5 )
    e:Font( "font_chat_text" )
    e:Align( "leftcenter" )
    e:SetText( T["desc_lh_interval"] )
    e:WordWrap( true )
    LabelSetTextColor( e.name, 170, 170, 170 )
    lhConfig.W.Main.Interval_Desc = e

    e = lhConfig.W.Main( "Checkbox" )
    e:AnchorTo( lhConfig.W.Main.Interval_Desc, "bottomleft", "topleft", 0, 10 )
    WindowSetDimensions( e.name, 20, 24 )
    lhConfig.W.Main.Sound_Checkbox = e

    e = lhConfig.W.Main( "Label" )
    e:Resize( 450 )
    e:Align( "leftcenter" )
    e:AnchorTo( lhConfig.W.Main.Sound_Checkbox, "right", "left", 10, 0 )
    e:Font( "font_chat_text" )
    e:SetText( T["Enable Sound With Low Health Pulse"] )
    lhConfig.W.Main.Sound_Label = e

    -- Radio-group fix (2 checkboxes: Enable, Sound)
    do
        local en_cb = lhConfig.W.Main.Enable_Checkbox
        local sn_cb = lhConfig.W.Main.Sound_Checkbox
        en_cb.OnLButtonDown = function() _lhSoundEnabled = sn_cb:GetValue() end
        en_cb.OnLButtonUp   = function() _lhEnabled = en_cb:GetValue(); sn_cb:SetValue( _lhSoundEnabled ) end
        sn_cb.OnLButtonDown = function() _lhEnabled = en_cb:GetValue() end
        sn_cb.OnLButtonUp   = function() _lhSoundEnabled = sn_cb:GetValue(); en_cb:SetValue( _lhEnabled ) end
    end

    -- ──────────────────────────────────────────────────────────
    -- HELP window (static — no controls, no Apply/Revert)
    -- UI-1 (2.3.2): WCDPWindowPlain required for windows > 500 px (CLAUDE.md §5.0).
    -- ──────────────────────────────────────────────────────────
    w = LibGUI( "window", nil, "WCDPWindowPlain" )
    w:ClearAnchors()
    w:Resize( 400, 960 )
    w:Show( true )
    helpConfig.W.Main = w
    table.insert( helpConfig.display, w )

    -- Title
    e = helpConfig.W.Main( "Label" )
    e:Resize( 370, 30 )
    e:AnchorTo( helpConfig.W.Main, "topleft", "topleft", 15, 12 )
    e:Font( "font_clear_medium_bold" )
    e:Align( "leftcenter" )
    e:SetText( T["help_title"] )
    helpConfig.W.Main.Title = e

    -- Intro paragraph
    e = helpConfig.W.Main( "Label" )
    e:Resize( 370, 80 )
    e:AnchorTo( helpConfig.W.Main.Title, "bottomleft", "topleft", 0, 10 )
    e:Font( "font_chat_text" )
    e:Align( "leftcenter" )
    e:SetText( T["help_intro"] )
    e:WordWrap( true )
    helpConfig.W.Main.Intro = e

    -- Section: How It Works
    e = helpConfig.W.Main( "Label" )
    e:Resize( 370, 28 )
    e:AnchorTo( helpConfig.W.Main.Intro, "bottomleft", "topleft", 0, 12 )
    e:Font( "font_clear_medium_bold" )
    e:Align( "leftcenter" )
    e:SetText( T["help_section_how"] )
    helpConfig.W.Main.SectionHow = e

    e = helpConfig.W.Main( "Label" )
    e:Resize( 370, 72 )
    e:AnchorTo( helpConfig.W.Main.SectionHow, "bottomleft", "topleft", 0, 5 )
    e:Font( "font_chat_text" )
    e:Align( "leftcenter" )
    e:SetText( T["help_abilities"] )
    e:WordWrap( true )
    LabelSetTextColor( e.name, 210, 210, 210 )
    helpConfig.W.Main.HowAbilities = e

    e = helpConfig.W.Main( "Label" )
    e:Resize( 370, 72 )
    e:AnchorTo( helpConfig.W.Main.HowAbilities, "bottomleft", "topleft", 0, 6 )
    e:Font( "font_chat_text" )
    e:Align( "leftcenter" )
    e:SetText( T["help_morale"] )
    e:WordWrap( true )
    LabelSetTextColor( e.name, 210, 210, 210 )
    helpConfig.W.Main.HowMorale = e

    e = helpConfig.W.Main( "Label" )
    e:Resize( 370, 72 )
    e:AnchorTo( helpConfig.W.Main.HowMorale, "bottomleft", "topleft", 0, 6 )
    e:Font( "font_chat_text" )
    e:Align( "leftcenter" )
    e:SetText( T["help_lowhealth"] )
    e:WordWrap( true )
    LabelSetTextColor( e.name, 210, 210, 210 )
    helpConfig.W.Main.HowLowHealth = e

    -- Section: Tips
    e = helpConfig.W.Main( "Label" )
    e:Resize( 370, 28 )
    e:AnchorTo( helpConfig.W.Main.HowLowHealth, "bottomleft", "topleft", 0, 12 )
    e:Font( "font_clear_medium_bold" )
    e:Align( "leftcenter" )
    e:SetText( T["help_section_tips"] )
    helpConfig.W.Main.SectionTips = e

    e = helpConfig.W.Main( "Label" )
    e:Resize( 370, DESC_H )
    e:AnchorTo( helpConfig.W.Main.SectionTips, "bottomleft", "topleft", 0, 5 )
    e:Font( "font_chat_text" )
    e:Align( "leftcenter" )
    e:SetText( T["help_tip_filters"] )
    e:WordWrap( true )
    LabelSetTextColor( e.name, 210, 210, 210 )
    helpConfig.W.Main.Tip1 = e

    e = helpConfig.W.Main( "Label" )
    e:Resize( 370, DESC_H )
    e:AnchorTo( helpConfig.W.Main.Tip1, "bottomleft", "topleft", 0, 5 )
    e:Font( "font_chat_text" )
    e:Align( "leftcenter" )
    e:SetText( T["help_tip_profiles"] )
    e:WordWrap( true )
    LabelSetTextColor( e.name, 210, 210, 210 )
    helpConfig.W.Main.Tip2 = e

    e = helpConfig.W.Main( "Label" )
    e:Resize( 370, DESC_H )
    e:AnchorTo( helpConfig.W.Main.Tip2, "bottomleft", "topleft", 0, 5 )
    e:Font( "font_chat_text" )
    e:Align( "leftcenter" )
    e:SetText( T["help_tip_anchor"] )
    e:WordWrap( true )
    LabelSetTextColor( e.name, 210, 210, 210 )
    helpConfig.W.Main.Tip3 = e

    e = helpConfig.W.Main( "Label" )
    e:Resize( 370, DESC_H )
    e:AnchorTo( helpConfig.W.Main.Tip3, "bottomleft", "topleft", 0, 5 )
    e:Font( "font_chat_text" )
    e:Align( "leftcenter" )
    e:SetText( T["help_tip_testpulse"] )
    e:WordWrap( true )
    LabelSetTextColor( e.name, 210, 210, 210 )
    helpConfig.W.Main.Tip4 = e

    -- Section: Slash Commands
    e = helpConfig.W.Main( "Label" )
    e:Resize( 370, 28 )
    e:AnchorTo( helpConfig.W.Main.Tip4, "bottomleft", "topleft", 0, 12 )
    e:Font( "font_clear_medium_bold" )
    e:Align( "leftcenter" )
    e:SetText( T["help_section_slash"] )
    helpConfig.W.Main.SectionSlash = e

    e = helpConfig.W.Main( "Label" )
    e:Resize( 370, 22 )
    e:AnchorTo( helpConfig.W.Main.SectionSlash, "bottomleft", "topleft", 0, 5 )
    e:Font( "font_chat_text" )
    e:Align( "leftcenter" )
    e:SetText( T["help_slash_open"] )
    LabelSetTextColor( e.name, 210, 210, 210 )
    helpConfig.W.Main.Slash1 = e

    e = helpConfig.W.Main( "Label" )
    e:Resize( 370, DESC_H )
    e:AnchorTo( helpConfig.W.Main.Slash1, "bottomleft", "topleft", 0, 4 )
    e:Font( "font_chat_text" )
    e:Align( "leftcenter" )
    e:SetText( T["help_slash_debug"] )
    e:WordWrap( true )
    LabelSetTextColor( e.name, 210, 210, 210 )
    helpConfig.W.Main.Slash2 = e

    -- Section: Credits
    e = helpConfig.W.Main( "Label" )
    e:Resize( 370, 28 )
    e:AnchorTo( helpConfig.W.Main.Slash2, "bottomleft", "topleft", 0, 12 )
    e:Font( "font_clear_medium_bold" )
    e:Align( "leftcenter" )
    e:SetText( T["help_section_credits"] )
    helpConfig.W.Main.SectionCredits = e

    e = helpConfig.W.Main( "Label" )
    e:Resize( 370, DESC_H )
    e:AnchorTo( helpConfig.W.Main.SectionCredits, "bottomleft", "topleft", 0, 5 )
    e:Font( "font_chat_text" )
    e:Align( "leftcenter" )
    e:SetText( T["help_credits"] )
    e:WordWrap( true )
    LabelSetTextColor( e.name, 170, 170, 170 )
    helpConfig.W.Main.Credits = e

    initialized = true
end

-- ============================================================
-- Page 1: General + Actions — Apply / Revert
-- ============================================================
local function ApplyGeneral()
    db = WCDP.db

    db.general.sound             = window.W.General.EnableSound_Checkbox:GetValue()
    db.general.debug             = window.W.General.EnableDebug_Checkbox:GetValue()
    db.general.showMinimapButton = window.W.General.ShowMinimapButton_Checkbox:GetValue()
    if( DoesWindowExist( "WCDPMinimapButton" ) ) then
        WindowSetShowing( "WCDPMinimapButton", db.general.showMinimapButton )
    end

    local selectedLabel = window.W.General.Sound_Combo:Selected()
    if( selectedLabel ~= nil ) then
        for _, opt in ipairs( WCDP.SoundList ) do
            if( towstring( opt.label ) == selectedLabel ) then
                db.general.soundKey = opt.key
                break
            end
        end
    end

    local temp
    temp = tonumber( window.W.General.StartAlpha_TextBox:GetText() ) or WCDP.DefaultSettings.alpha.start
    if( temp < 0 ) then temp = 0 end
    if( temp > 1 ) then temp = 1 end
    db.alpha.start = temp

    temp = tonumber( window.W.General.EndAlpha_TextBox:GetText() ) or WCDP.DefaultSettings.alpha.finish
    if( temp < 0 ) then temp = 0 end
    if( temp > 1 ) then temp = 1 end
    db.alpha.finish = temp

    temp = tonumber( window.W.General.PulseSpeed_TextBox:GetText() ) or WCDP.DefaultSettings.alpha.speed
    if( temp < 0 ) then temp = 0 end
    if( temp > 2 ) then temp = 2 end
    db.alpha.speed = temp

end

local function RevertGeneral()
    db = WCDP.db

    _genSoundEnabled   = db.general.sound
    _genDebugEnabled   = db.general.debug
    _genMinimapEnabled = db.general.showMinimapButton ~= false
    window.W.General.EnableSound_Checkbox:SetValue( _genSoundEnabled )
    window.W.General.EnableDebug_Checkbox:SetValue( _genDebugEnabled )
    window.W.General.ShowMinimapButton_Checkbox:SetValue( _genMinimapEnabled )

    local currentKey = db.general.soundKey or "HELP_TIPS_NEW"
    for i, opt in ipairs( WCDP.SoundList ) do
        if( opt.key == currentKey ) then
            window.W.General.Sound_Combo:SelectIndex( i )
            break
        end
    end

    window.W.General.StartAlpha_TextBox:SetText( wstring.format( L"%.2f", towstring( db.alpha.start  ) ) )
    window.W.General.EndAlpha_TextBox:SetText(   wstring.format( L"%.2f", towstring( db.alpha.finish ) ) )
    window.W.General.PulseSpeed_TextBox:SetText( wstring.format( L"%.2f", towstring( db.alpha.speed  ) ) )

end

-- ============================================================
-- Page 2: Abilities (Actions + Morale + Pet) — Apply / Revert
-- ============================================================
local function ApplyAbilities()
    db = WCDP.db
    local ab = abilitiesConfig.W.Main

    -- Actions
    db.abilities.actions.enabled = ab.EnableAction_Checkbox:GetValue()
    local mc = tonumber( ab.ActionMinCD_TextBox:GetText() ) or WCDP.DefaultSettings.abilities.actions.mincooldown
    if( mc < 0   ) then mc = 0   end
    if( mc > 300 ) then mc = 300 end
    db.abilities.actions.mincooldown = mc
    db.abilities.actions.sound       = ab.ActionSound_Checkbox:GetValue()

    -- Morale
    db.abilities.morale.enabled = ab.EnableMorale_Checkbox:GetValue()
    local mcm = tonumber( ab.MoraleMinCD_TextBox:GetText() ) or WCDP.DefaultSettings.abilities.morale.mincooldown
    if( mcm < 0   ) then mcm = 0   end
    if( mcm > 300 ) then mcm = 300 end
    db.abilities.morale.mincooldown = mcm
    db.abilities.morale.onavailable = ab.OnAvailable_Checkbox:GetValue()
    db.abilities.morale.sound       = ab.MoraleSound_Checkbox:GetValue()

    -- Pet
    db.abilities.pet.enabled = ab.EnablePet_Checkbox:GetValue()
    local mcp = tonumber( ab.PetMinCD_TextBox:GetText() ) or WCDP.DefaultSettings.abilities.pet.mincooldown
    if( mcp < 0   ) then mcp = 0   end
    if( mcp > 300 ) then mcp = 300 end
    db.abilities.pet.mincooldown = mcp
    db.abilities.pet.sound       = ab.PetSound_Checkbox:GetValue()
end

local function RevertAbilities()
    db = WCDP.db
    local ab = abilitiesConfig.W.Main

    -- Actions
    local ac = db.abilities.actions
    _acEnabled      = ac.enabled
    _acSoundEnabled = ac.sound ~= false
    ab.EnableAction_Checkbox:SetValue( _acEnabled )
    ab.ActionMinCD_TextBox:SetText( wstring.format( L"%.1f", towstring( ac.mincooldown ) ) )
    ab.ActionSound_Checkbox:SetValue( _acSoundEnabled )

    -- Morale
    local mo = db.abilities.morale
    _moEnabled      = mo.enabled
    _moOnAvail      = mo.onavailable
    _moSoundEnabled = mo.sound ~= false
    ab.EnableMorale_Checkbox:SetValue( _moEnabled )
    ab.MoraleMinCD_TextBox:SetText( wstring.format( L"%.1f", towstring( mo.mincooldown ) ) )
    ab.OnAvailable_Checkbox:SetValue( _moOnAvail )
    ab.MoraleSound_Checkbox:SetValue( _moSoundEnabled )

    -- Pet
    local pt = db.abilities.pet
    _petEnabled      = pt.enabled
    _petSoundEnabled = pt.sound ~= false
    ab.EnablePet_Checkbox:SetValue( _petEnabled )
    ab.PetMinCD_TextBox:SetText( wstring.format( L"%.1f", towstring( pt.mincooldown ) ) )
    ab.PetSound_Checkbox:SetValue( _petSoundEnabled )
end

-- ============================================================
-- Page 3: Low Health Alert — Apply / Revert
-- ============================================================
local function ApplyLowHealth()
    db = WCDP.db
    if( db.lowhealth == nil ) then db.lowhealth = WCDP.DefaultSettings.lowhealth end

    db.lowhealth.enabled = lhConfig.W.Main.Enable_Checkbox:GetValue()
    db.lowhealth.sound   = lhConfig.W.Main.Sound_Checkbox:GetValue()

    local temp
    temp = tonumber( lhConfig.W.Main.Threshold_Textbox:GetText() ) or WCDP.DefaultSettings.lowhealth.threshold
    if( temp < 1  ) then temp = 1  end
    if( temp > 99 ) then temp = 99 end
    db.lowhealth.threshold = temp

    temp = tonumber( lhConfig.W.Main.Interval_Textbox:GetText() ) or WCDP.DefaultSettings.lowhealth.repeatInterval
    if( temp < 0.5 ) then temp = 0.5 end
    if( temp > 10  ) then temp = 10  end
    db.lowhealth.repeatInterval = temp
end

local function RevertLowHealth()
    db = WCDP.db
    local lh = db.lowhealth or WCDP.DefaultSettings.lowhealth
    _lhEnabled      = lh.enabled
    _lhSoundEnabled = lh.sound ~= false
    lhConfig.W.Main.Enable_Checkbox:SetValue( _lhEnabled )
    lhConfig.W.Main.Sound_Checkbox:SetValue( _lhSoundEnabled )
    lhConfig.W.Main.Threshold_Textbox:SetText( towstring( lh.threshold ) )
    lhConfig.W.Main.Interval_Textbox:SetText( wstring.format( L"%.1f", towstring( lh.repeatInterval ) ) )
end

-- ============================================================
-- Wire up and register all pages (P1 2.3.1: 3 pages → 2)
-- ============================================================
window.Initialize       = InitializeAll
window.Apply            = ApplyGeneral
window.Revert           = RevertGeneral
window.Index            = WCDPConfig.RegisterWindow( window )

abilitiesConfig.Initialize = InitializeAll
abilitiesConfig.Apply      = ApplyAbilities
abilitiesConfig.Revert     = RevertAbilities
abilitiesConfig.Index      = WCDPConfig.RegisterWindow( abilitiesConfig )

lhConfig.Initialize     = InitializeAll
lhConfig.Apply          = ApplyLowHealth
lhConfig.Revert         = RevertLowHealth
lhConfig.Index          = WCDPConfig.RegisterWindow( lhConfig )

helpConfig.Initialize   = InitializeAll
helpConfig.Apply        = function() end
helpConfig.Revert       = function() end
-- Registration deferred to after Profiles so Help appears last in sidebar
WCDPConfig.pendingHelpConfig = helpConfig
