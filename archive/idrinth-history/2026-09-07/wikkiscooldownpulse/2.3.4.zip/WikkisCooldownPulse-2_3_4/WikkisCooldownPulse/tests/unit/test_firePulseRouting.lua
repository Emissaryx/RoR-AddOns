-- Tests for CHANTIER 1 (2.2.0): FirePulse routes to the correct window
-- per ability category (abilities, morale, pet) and that pet pulses are no
-- longer mixed with action pulses.

local lastWindowAnimated = nil
local lastIconWindow     = nil

local function reset()
    lastWindowAnimated = nil
    lastIconWindow     = nil
    WindowStartAlphaAnimation = function(win, ...) lastWindowAnimated = win end
    DynamicImageSetTexture    = function(win, ...) lastIconWindow     = win end
    WCDP.Reinitialize()
end

-- Helper: run PerformAbilityUpdate through a full cooldown cycle for a given type.
local function runCycle( abilityId, abilityType, peak )
    -- Inject ability type into cache so GetAbilityData stub is not needed for type.
    Player.GetAbilityData = function(id)
        return { abilityType = abilityType, iconNum = 100, id = id }
    end
    -- Cooldown on
    WCDP.PerformAbilityUpdate( abilityId, peak, peak, peak )
    -- Cooldown expires
    WCDP.PerformAbilityUpdate( abilityId, 0, peak, 0 )
end

it("routing: ability type routes to WCDPFrame (abilities window)", function()
    reset()
    runCycle( 1001, Player.AbilityType.ABILITY, 6 )
    assert(lastWindowAnimated == "WCDPFrame",
           "abilities must animate WCDPFrame, got: " .. tostring(lastWindowAnimated))
    assert(lastIconWindow == "WCDPFrameImageSquare",
           "icon must be set on WCDPFrameImageSquare, got: " .. tostring(lastIconWindow))
end)

it("routing: pet type routes to WCDPPetFrame (pet window)", function()
    reset()
    runCycle( 2001, Player.AbilityType.PET, 6 )
    assert(lastWindowAnimated == "WCDPPetFrame",
           "pet must animate WCDPPetFrame, got: " .. tostring(lastWindowAnimated))
    assert(lastIconWindow == "WCDPPetFrameImageSquare",
           "icon must be set on WCDPPetFrameImageSquare, got: " .. tostring(lastIconWindow))
end)

it("routing: pet does NOT animate WCDPFrame (no more mixing)", function()
    reset()
    runCycle( 3001, Player.AbilityType.PET, 8 )
    assert(lastWindowAnimated ~= "WCDPFrame",
           "pet must NOT animate the abilities frame WCDPFrame")
end)

it("routing: FirePulse morale routes to WCDPMoraleFrame", function()
    reset()
    WCDP.FirePulse( 1001, "morale" )
    assert(lastWindowAnimated == "WCDPMoraleFrame",
           "morale pulse must animate WCDPMoraleFrame, got: " .. tostring(lastWindowAnimated))
    assert(lastIconWindow == "WCDPMoraleFrameImageSquare",
           "icon must be set on WCDPMoraleFrameImageSquare")
end)

it("routing: FirePulse abilities routes to WCDPFrame", function()
    reset()
    WCDP.FirePulse( 1001, "abilities" )
    assert(lastWindowAnimated == "WCDPFrame",
           "abilities pulse must animate WCDPFrame, got: " .. tostring(lastWindowAnimated))
end)

it("routing: FirePulse pet routes to WCDPPetFrame", function()
    reset()
    WCDP.FirePulse( 1001, "pet" )
    assert(lastWindowAnimated == "WCDPPetFrame",
           "pet pulse must animate WCDPPetFrame, got: " .. tostring(lastWindowAnimated))
end)

it("routing: FirePulse health routes to WCDPHealthFrame", function()
    reset()
    -- Health pulse skips ability lookup entirely, so GetAbilityData should not be called.
    -- BUG-5A (2.3.2): health now loads the heart icon on demand via DynamicImageSetTexture,
    -- so lastIconWindow must be WCDPHealthFrameImageSquare (not nil).
    local abilityDataCalled = false
    Player.GetAbilityData = function(id)
        abilityDataCalled = true
        return { abilityType = Player.AbilityType.ABILITY, iconNum = 100, id = id }
    end
    WCDP.db.lowhealth.sound = false   -- suppress sound for isolation
    WCDP.FirePulse( nil, "health" )
    assert(lastWindowAnimated == "WCDPHealthFrame",
           "health pulse must animate WCDPHealthFrame, got: " .. tostring(lastWindowAnimated))
    assert(lastIconWindow == "WCDPHealthFrameImageSquare",
           "health pulse must set heart icon on WCDPHealthFrameImageSquare, got: " .. tostring(lastIconWindow))
    assert(not abilityDataCalled,
           "health pulse must not call Player.GetAbilityData")
end)

it("routing: morale onavailable path calls FirePulse with category=morale", function()
    reset()
    -- Confirm PulseMoraleRank (the onavailable code path) reaches the morale window.
    GetMoraleBarData = function(rank) return nil, 9999 end
    GetAbilityData   = function(slotId)
        return { id = slotId, iconNum = 1, name = "TestMorale" }
    end
    -- MoraleAllowed = true (morale enabled, no whitelist/blacklist)
    WCDP.PulseMoraleRank( 1 )
    assert(lastWindowAnimated == "WCDPMoraleFrame",
           "PulseMoraleRank must animate WCDPMoraleFrame, got: " .. tostring(lastWindowAnimated))
    -- Restore stubs
    GetMoraleBarData = function(rank) return nil, nil end
    GetAbilityData   = function(slotId) return { id = slotId, iconNum = 1, name = "TestAbility" } end
end)

-- TEST-A (2.3.3): per-category sound gate in FirePulse.

it("sound gate: actions.sound=false suppresses PlayPulseSound", function()
    reset()
    local soundPlayed = false
    PlaySound = function() soundPlayed = true end
    WCDP.db.general.sound        = true
    WCDP.db.general.soundKey     = "HELP_TIPS_NEW"
    WCDP.db.abilities.actions.sound = false
    WCDP.FirePulse( 1001, "abilities" )
    assert(not soundPlayed, "actions.sound=false must not play sound")
    PlaySound = function() end
end)

it("sound gate: morale.sound=false suppresses PlayPulseSound", function()
    reset()
    local soundPlayed = false
    PlaySound = function() soundPlayed = true end
    WCDP.db.general.sound        = true
    WCDP.db.general.soundKey     = "HELP_TIPS_NEW"
    WCDP.db.abilities.morale.sound = false
    WCDP.FirePulse( 1001, "morale" )
    assert(not soundPlayed, "morale.sound=false must not play sound")
    PlaySound = function() end
end)

it("sound gate: pet.sound=false suppresses PlayPulseSound", function()
    reset()
    local soundPlayed = false
    PlaySound = function() soundPlayed = true end
    WCDP.db.general.sound      = true
    WCDP.db.general.soundKey   = "HELP_TIPS_NEW"
    WCDP.db.abilities.pet.sound = false
    WCDP.FirePulse( 1001, "pet" )
    assert(not soundPlayed, "pet.sound=false must not play sound")
    PlaySound = function() end
end)
