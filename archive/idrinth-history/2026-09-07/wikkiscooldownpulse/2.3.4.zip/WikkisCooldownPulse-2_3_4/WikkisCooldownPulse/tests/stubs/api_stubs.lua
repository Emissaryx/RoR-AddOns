--
-- Stubs for all WAR/RoR client globals absent from standard Lua.
-- Load this file first in every test runner.
--

-- wstring literals: in the RoR client, L"string" is syntax for a wstring literal.
-- In standard Lua, L"string" is parsed as L("string") because Lua allows omitting
-- parentheses when calling a function with a single string argument.
-- Defining L = tostring makes all L"..." usages return plain Lua strings.
L          = tostring
towstring  = tostring
WStringToString = tostring

-- wstring table: the RoR client exposes wstring.format and wstring.sub.
wstring = { sub = string.sub, format = string.format }

-- Event system
RegisterEventHandler   = function() end
UnregisterEventHandler = function() end

-- ActionButton
ActionButton = {
    GLOBAL_COOLDOWN = 1.61,
    UpdateCooldownAnimation = function() end,
}

-- MoraleButton
MoraleButton = { Update = function() end }

-- Player API
Player = {
    AbilityType = { ABILITY = 1, MORALE = 2, PET = 3 },
    GetAbilityData = function(id)
        return { abilityType = Player.AbilityType.ABILITY, iconNum = 100, id = id }
    end,
}

-- GameData / Sound  (five confirmed constants from Game\ROR addons)
GameData = {
    Sound = {
        HELP_TIPS_NEW              = 10,
        QUEST_OBJECTIVES_COMPLETED = 11,
        QUEST_COMPLETED            = 12,
        QUEST_ACCEPTED             = 13,
        TOME_CLOSE                 = 14,
    },
    Account = {
        CharacterSlot = {},   -- empty: no character slots in tests
    },
    Player = {
        name = "TestChar",
        -- hitPoints confirmed in pure, BuffHead, MiracleGrowLight, Enemy (Game\ROR)
        hitPoints = { current = 5000, maximum = 5000 },
    },
}

-- Helper to set player HP percent for low-health tests
function SetPlayerHP( current, maximum )
    GameData.Player.hitPoints.current = current
    GameData.Player.hitPoints.maximum = maximum
end

-- Morale API
GetMoraleBarData         = function(rank) return nil, nil end
GetMoraleCooldown        = function(rank) return 0, 60   end
GetMoralePercentForLevel = function(rank) return 25 * rank end
GetAbilityData           = function(slotId)
    return { id = slotId, iconNum = 1, name = "TestAbility" }
end

-- Icon / display
GetIconData               = function(iconNum) return "icon_test", 0, 0, nil end
DynamicImageSetTexture    = function() end
WindowStartAlphaAnimation = function() end
WindowSetAlpha            = function() end
WindowSetShowing          = function() end
WindowSetDimensions       = function() end
WindowSetScale            = function() end
WindowClearAnchors        = function() end
WindowAddAnchor           = function() end
-- FIX (2.3.0): real API returns (point, relativePoint, relativeWindow, x, y).
-- Previous stub had relativePoint and relativeWindow swapped (same bug as r73 in wcdp.lua).
WindowGetAnchor           = function() return "center", "center", "Root", 0, 0 end
WindowGetDimensions       = function() return 192, 192 end
WindowGetScale            = function() return 0.75 end
DoesWindowExist           = function() return true end
CreateWindow              = function() end
InterfaceCore             = { GetScale = function() return 1 end }
Window                    = { AnimationType = { LOOP = 1 } }

-- Chat / sound
EA_ChatWindow = { Print = function() end }
ChatSettings  = { Channels = { [1] = { id = 1 } } }
SystemData    = {
    Events = {
        RELOAD_INTERFACE              = 1,
        LOADING_END                   = 2,
        PLAYER_MORALE_UPDATED         = 3,
        PLAYER_BEGIN_CAST             = 4,
        CUSTOM_UI_SCALE_CHANGED       = 5,
    },
    ChatLogFilters = { SAY = 1 },
    ActiveWindow   = { name = "" },
}
PlaySound = function() end

-- Context menu (minimap right-click)
EA_Window_ContextMenu = {
    CreateContextMenu = function() end,
    AddMenuItem       = function() end,
    AddMenuDivider    = function() end,
    Finalize          = function() end,
}

-- Tooltips (minimap hover)
Tooltips = {
    CreateTextOnlyTooltip = function() end,
    SetTooltipText        = function() end,
    AnchorTooltip         = function() end,
    ANCHOR_CURSOR         = 1,
    Finalize              = function() end,
}

-- Layout Editor
LayoutEditor = {
    RegisterWindow   = function() end,
    UnregisterWindow = function() end,
    EventHandlers    = {},
}

-- LibStub: returns a usable locale table (T["key"] returns "key") and
-- a no-op table for all other libraries.
LibStub = setmetatable({}, {
    __call = function(self, name, ...)
        if name == "WAR-AceLocale-3.0" then
            local ace = {}
            function ace:GetLocale()
                return setmetatable({}, { __index = function(_, k) return k end })
            end
            function ace:NewLocale(_, _, isPrimary)
                if isPrimary then
                    return setmetatable({}, { __newindex = function() end })
                end
                return nil
            end
            return ace
        end
        -- Generic stub: any method returns a no-op function or empty table
        return setmetatable({}, {
            __index = function() return function() return {} end end,
            __call  = function(s, ...) return s end,
        })
    end,
})

-- Slash command library stub
if not LibSlash then
    LibSlash = { RegisterSlashCmd = function() end }
end
