-- Integration tests for WCDP.OnAbilityUpdate and WCDP.OnMoraleUpdate.
-- These hooks capture m_MaxCooldown *before* calling the original function,
-- then pass the pre/post values to PerformAbilityUpdate.
-- The tests mock the original (pre-hook) functions and verify routing.

local pulseCount = nil
local lastPulsedId = nil

local function reset()
    pulseCount   = 0
    lastPulsedId = nil
    -- Stub the original (pre-hook) functions that WCDP replaces.
    WCDP.__ActionButton_UpdateCooldownAnimation = function(self) end
    WCDP.__MoraleButton_Update                 = function(self) end
    -- Track pulses via FirePulse
    WindowStartAlphaAnimation = function(win, ...) end
    DynamicImageSetTexture    = function(win, tex, ...)
        pulseCount   = pulseCount + 1
        lastPulsedId = win
    end
    Player.GetAbilityData = function(id)
        return { abilityType = Player.AbilityType.ABILITY, iconNum = 100, id = id }
    end
    WCDP.Reinitialize()
    WCDP.db.abilities.actions.mincooldown = 4
end

it("hooks: OnAbilityUpdate fires pulse after cooldown completes", function()
    reset()
    -- Simulate button on cooldown (initialMaxCooldown captured pre-hook as 8)
    local btn = { m_ActionId = 500, m_Cooldown = 8, m_MaxCooldown = 8 }
    -- The hook captures m_MaxCooldown before calling original, then reads current.
    -- Simulate: pre-hook max=8, after original the cooldown is still 8 (active).
    WCDP.OnAbilityUpdate( btn )
    assert(pulseCount == 0, "no pulse while cooldown > 0")

    -- Now cooldown expires: pre-hook max=8, after original max resets to 0.
    btn.m_Cooldown    = 0
    btn.m_MaxCooldown = 0
    WCDP.OnAbilityUpdate( btn )
    assert(pulseCount == 1, "pulse must fire when cooldown reaches 0 after being > mincooldown")
end)

it("hooks: OnMoraleUpdate only routes the last-cast moral ability", function()
    reset()
    Player.GetAbilityData = function(id)
        return { abilityType = Player.AbilityType.MORALE, iconNum = 200, id = id }
    end
    -- Pretend ability 300 is the last moral cast.
    -- Access the internal via PerformAbilityUpdate path — set via a direct cast.
    -- We test the guard: if m_AbilityId != _lastMoraleAbilityCast, skip.
    local btn = { m_AbilityId = 300, m_Cooldown = 0, m_MaxCooldown = 0 }
    -- _lastMoraleAbilityCast starts nil → guard fires → no pulse.
    WCDP.OnMoraleUpdate( btn )
    assert(pulseCount == 0, "morale hook must skip if ability was not the last one cast")
end)

it("hooks: OnAbilityUpdate passes pre-hook maxCooldown correctly", function()
    reset()
    -- The peak-tracking logic uses the maximum of the 4 cooldown values.
    -- If pre-hook max was large and post-hook max reset to 0, the peak is still captured.
    local btn = { m_ActionId = 501, m_Cooldown = 10, m_MaxCooldown = 10 }
    WCDP.OnAbilityUpdate( btn )   -- active, peak=10

    -- Simulate the client resetting m_MaxCooldown to 0 before calling the hook again.
    btn.m_Cooldown    = 0
    btn.m_MaxCooldown = 0
    -- OnAbilityUpdate captures old max (0 now) but initialMaxCooldown was 10 at prev frame.
    -- At expiry frame, m_MaxCooldown is already 0 — the hook captures pre=0, post=0.
    -- Peak from prior frames (10) should trigger the pulse.
    WCDP.OnAbilityUpdate( btn )
    assert(pulseCount == 1, "pre-hook max captured on active frame must produce pulse on expiry")
end)
