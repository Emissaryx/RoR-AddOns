-- UI-4/UI-5 (2.3.2): Regression tests for description label heights and
-- anchor alignment in the config UI.
-- Verifies that the DESC_H / DESC_H_L constants are correctly defined and that
-- no legacy small literal heights or misaligned anchor offsets slipped back in.
--
-- Layout rules enforced:
--   1. DESC_H  >= 54  (standard 3-line description)
--   2. DESC_H_L >= 54  (extended 4-line description, expected 72)
--   3. No e:Resize( 350, N ) literal where N < 54  (all should use DESC_H/DESC_H_L)
--   4. No e:Resize( 370, N ) literal where N is in (30, 54)  (Help body labels)
--   5. The 4 page windows have the expected heights {830, 830, 830, 960}
--   6. General page: first Animation label uses +10 indent (not legacy +20)
--   7. General page: Display_SubTitle uses -10 correction (not legacy -20)
--   8. General page: EnableDebug_Checkbox uses +10 indent (not legacy +20)
--   9. Low Health page: Threshold_Label uses +0 from Enable_Checkbox (not legacy +10)

local function readfile(path)
    local f, err = io.open(path, "r")
    assert(f, "cannot open " .. path .. ": " .. tostring(err))
    local c = f:read("*a")
    f:close()
    return c
end

it("layout: DESC_H constant is >= 54px (standard description height)", function()
    local content = readfile(src("../Configuration/WCDPConfig_General.lua"))
    local val = content:match("local DESC_H%s*=%s*(%d+)")
    assert(val ~= nil, "DESC_H constant not found in WCDPConfig_General.lua")
    assert(tonumber(val) >= 54,
           "DESC_H = " .. val .. "px is below minimum 54px")
end)

it("layout: DESC_H_L constant is >= 54px (extended description height)", function()
    local content = readfile(src("../Configuration/WCDPConfig_General.lua"))
    -- Match DESC_H_L specifically (not DESC_H which is a prefix of DESC_H_L)
    local val = content:match("local DESC_H_L%s*=%s*(%d+)")
    assert(val ~= nil, "DESC_H_L constant not found in WCDPConfig_General.lua")
    assert(tonumber(val) >= 54,
           "DESC_H_L = " .. val .. "px is below minimum 54px")
end)

it("layout: no 350px description label uses a literal height < 54px", function()
    -- After UI-4, all Resize(350, …) calls must use DESC_H or DESC_H_L constants.
    -- This detects any literal number < 54 that snuck back in.
    local content = readfile(src("../Configuration/WCDPConfig_General.lua"))
    local bad = {}
    for h in content:gmatch("e:Resize%( 350, (%d+) %)") do
        if tonumber(h) < 54 then
            table.insert(bad, h)
        end
    end
    assert(#bad == 0,
           "Found " .. #bad .. " Resize(350, N<54) literal(s): " ..
           table.concat(bad, ", ") .. " — use DESC_H or DESC_H_L instead")
end)

it("layout: no 370px Help body label uses a literal height in range (30, 54)", function()
    -- Help section titles use 28px and the page title uses 30px — both exempt.
    -- Body content labels must be >= 54px after UI-4.
    local content = readfile(src("../Configuration/WCDPConfig_General.lua"))
    local EXEMPT_MAX = 30  -- heights <= 30 are single-line titles, intentionally small
    local bad = {}
    for h in content:gmatch("e:Resize%( 370, (%d+) %)") do
        local height = tonumber(h)
        if height > EXEMPT_MAX and height < 54 then
            table.insert(bad, h)
        end
    end
    assert(#bad == 0,
           "Found " .. #bad .. " Help body label(s) with height in (30, 54): " ..
           table.concat(bad, ", ") .. " — use DESC_H")
end)

it("layout: General Animation/Display alignment uses +10 indent matching Abilities", function()
    -- Abilities uses x=+10 from section subtitle for first checkbox/label.
    -- General previously used x=+20 (drift), causing elements to appear at x=35
    -- instead of x=25. Rules verified by text pattern matching:
    --   Animation: StartAlpha_Label anchored +10 from Animation_SubTitle
    --   Display: EnableDebug_Checkbox anchored +10 from Display_SubTitle
    --   Display subtile correction: Display_SubTitle anchored -10 from TestPulse_Button
    local content = readfile(src("../Configuration/WCDPConfig_General.lua"))
    assert(
        content:find('Animation_SubTitle, "bottomleft", "topleft", 10,', 1, true),
        "StartAlpha_Label must use x=+10 from Animation_SubTitle (Abilities alignment)")
    assert(
        content:find('Display_SubTitle, "bottomleft", "topleft", 10,', 1, true),
        "EnableDebug_Checkbox must use x=+10 from Display_SubTitle (Abilities alignment)")
    assert(
        content:find('TestPulse_Button, "bottomleft", "topleft", -10,', 1, true),
        "Display_SubTitle must use x=-10 correction from TestPulse_Button")
    -- Verify the legacy +20 indent is gone
    assert(
        not content:find('Animation_SubTitle, "bottomleft", "topleft", 20,', 1, true),
        "Legacy x=+20 indent from Animation_SubTitle still present — must be +10")
    assert(
        not content:find('Display_SubTitle, "bottomleft", "topleft", 20,', 1, true),
        "Legacy x=+20 indent from Display_SubTitle still present — must be +10")
end)

it("layout: Low Health Threshold_Label uses +0 from Enable_Checkbox (no x drift)", function()
    -- Abilities uses x=+0 from the section's Enable checkbox for MinCD label.
    -- Low Health previously used x=+10, shifting Threshold_Label to x=35.
    local content = readfile(src("../Configuration/WCDPConfig_General.lua"))
    assert(
        content:find('Enable_Checkbox, "bottomleft", "topleft", 0,', 1, true),
        "Threshold_Label must use x=+0 from Enable_Checkbox (Abilities alignment)")
    assert(
        not content:find('Enable_Checkbox, "bottomleft", "topleft", 10,', 1, true),
        "Legacy x=+10 offset from Enable_Checkbox still present — must be 0")
end)

it("layout: page window heights match expected values after UI-4", function()
    local content = readfile(src("../Configuration/WCDPConfig_General.lua"))
    local heights = {}
    for h in content:gmatch("w:Resize%( 400, (%d+) %)") do
        table.insert(heights, tonumber(h))
    end
    assert(#heights == 4, "Expected 4 w:Resize(400,N) calls, found " .. #heights)
    table.sort(heights)
    local expected = { 830, 830, 830, 960 }
    for i, exp in ipairs(expected) do
        assert(heights[i] == exp,
               "Window height mismatch at index " .. i ..
               ": expected " .. exp .. ", got " .. tostring(heights[i]))
    end
end)
