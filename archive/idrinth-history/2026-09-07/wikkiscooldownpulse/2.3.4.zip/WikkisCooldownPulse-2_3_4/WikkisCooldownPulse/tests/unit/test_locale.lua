-- Regression test for enUS.lua locale loading.
-- Verifies that AceLocale keys return their translated strings,
-- NOT the raw key name (which happens when a NewLocale proxy read-back
-- alias T[x]=T[y] silently stores nil and breaks subsequent assignments).
--
-- Uses a self-contained AceLocale stub that properly stores and retrieves
-- values, simulating the real WAR/RoR NewLocale behavior.

local locale_data = {}

-- Override LibStub for this test with a proper read/write proxy.
local saved_libstub = LibStub
LibStub = function(name)
    if name == "WAR-AceLocale-3.0" then
        return {
            NewLocale = function(self, modname, locale, isDefault, dbg)
                locale_data = {}
                return setmetatable({}, {
                    __newindex = function(t, k, v) locale_data[k] = v end,
                    -- __index intentionally returns nil to simulate the real
                    -- AceLocale proxy that does NOT allow reading back during
                    -- NewLocale (this is the condition that caused the regression).
                    __index = function(t, k) return nil end,
                })
            end,
        }
    end
    return saved_libstub(name)
end

-- Load the locale file under test with our stub active.
dofile(src("../Localization/enUS.lua"))

-- Restore original LibStub.
LibStub = saved_libstub

-- Helper: assert key is registered with a non-nil, non-key-name value.
local function check(key, expected_fragment)
    local val = locale_data[key]
    assert(val ~= nil,
           "locale key '" .. key .. "' must be registered (got nil)")
    assert(val ~= key,
           "locale key '" .. key .. "' must not return the key name itself (AceLocale aliasing bug)")
    if expected_fragment then
        assert(type(val) == "string" and val:find(expected_fragment, 1, true),
               "locale key '" .. key .. "' expected to contain '" .. expected_fragment ..
               "', got: " .. tostring(val))
    end
end

it("locale: help_title returns translated value", function()
    check("help_title", "Wikki")
end)

it("locale: help_intro returns translated value", function()
    check("help_intro", "Flashes")
end)

it("locale: help_section_how returns translated value", function()
    check("help_section_how", "How It Works")
end)

it("locale: Enable Sound returns translated value (not nil)", function()
    -- The key "Enable Sound" legitimately translates to "Enable Sound" (same string),
    -- so the val~=key check does not apply here. We only verify it is not nil.
    local val = locale_data["Enable Sound"]
    assert(val ~= nil, "Enable Sound key must be registered")
    assert(val == "Enable Sound", "Enable Sound must map to 'Enable Sound', got: " .. tostring(val))
end)

it("locale: Enable Sound alias keys return translated value (not nil)", function()
    -- These keys were previously set via T[x]=T[y] aliasing which silently
    -- stored nil and broke all subsequent locale assignments (regression r83).
    check("Enable Sound With Pulse",            "Enable Sound")
    check("Enable Pulse Sound",                 "Enable Sound")
    check("Enable Sound With Low Health Pulse", "Enable Sound")
    check("Enable Sound With Morale Pulse",     "Enable Sound")
end)

it("locale: late keys after Enable Sound aliases are not broken", function()
    -- If aliasing caused an error during NewLocale, all keys defined after
    -- line 52 would be nil. Verify a selection of them are present.
    check("desc_start_alpha",    "opacity")
    check("help_section_tips",   "Tips")
    check("help_tip_testpulse",  "Test Pulse")
    check("help_section_credits","Credits")
end)
