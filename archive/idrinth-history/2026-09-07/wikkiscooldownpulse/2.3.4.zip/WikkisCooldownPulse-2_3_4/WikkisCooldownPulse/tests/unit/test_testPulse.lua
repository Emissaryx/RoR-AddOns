-- Tests for WCDP.TestPulse(startAlpha, endAlpha, speed) added in r80/P11.
-- Verifies: clamp 0-1 on alphas, clamp >=0 on speed, nil fallback to db.alpha.*,
-- and guard when db is nil.

local lastAnimWin = nil
local lastAnimArgs = nil

local function reset()
    lastAnimWin  = nil
    lastAnimArgs = nil
    WindowStartAlphaAnimation = function(win, animType, a0, a1, sp, ...)
        lastAnimWin  = win
        lastAnimArgs = { a0 = a0, a1 = a1, sp = sp }
    end
    WindowStopAlphaAnimation = function(win) end
    WCDP.Reinitialize()
    -- Set known db values so nil-fallback tests are deterministic.
    WCDP.db.alpha.start  = 0.2
    WCDP.db.alpha.finish = 0.6
    WCDP.db.alpha.speed  = 0.3
end

it("testPulse: valid values pass through unchanged", function()
    reset()
    WCDP.TestPulse( 0.1, 0.8, 0.25 )
    assert(lastAnimWin == "WCDPFrame",
           "TestPulse must animate WCDPFrame, got: " .. tostring(lastAnimWin))
    assert(lastAnimArgs.a0 == 0.1, "start alpha must be 0.1")
    assert(lastAnimArgs.a1 == 0.8, "end alpha must be 0.8")
    assert(lastAnimArgs.sp == 0.25, "speed must be 0.25")
end)

it("testPulse: nil args fall back to db.alpha values", function()
    reset()
    WCDP.TestPulse( nil, nil, nil )
    assert(lastAnimArgs ~= nil, "animation must have fired")
    assert(lastAnimArgs.a0 == 0.2, "nil start falls back to db.alpha.start=0.2")
    assert(lastAnimArgs.a1 == 0.6, "nil end falls back to db.alpha.finish=0.6")
    assert(lastAnimArgs.sp == 0.3, "nil speed falls back to db.alpha.speed=0.3")
end)

it("testPulse: out-of-range alphas are clamped to [0, 1]", function()
    reset()
    WCDP.TestPulse( -0.5, 1.5, 0.2 )
    assert(lastAnimArgs.a0 == 0,   "negative start alpha clamped to 0")
    assert(lastAnimArgs.a1 == 1,   "start alpha > 1 clamped to 1")
end)

it("testPulse: negative speed is clamped to 0", function()
    reset()
    WCDP.TestPulse( 0.2, 0.6, -1.0 )
    assert(lastAnimArgs.sp == 0, "negative speed clamped to 0")
end)

it("testPulse: sets WCDPFrameImageSquare texture without requiring a prior pulse", function()
    -- BUG (2.3.2): TestPulse was invisible on first use because DynamicImageSetTexture
    -- was never called — the frame had no texture until a real ability pulse fired.
    -- Force the fallback path by making ability lookups return nil.
    reset()
    local savedGetAbilityData = Player.GetAbilityData
    Player.GetAbilityData = function() return nil end
    local lastTexWin, lastTexName = nil, nil
    DynamicImageSetTexture = function(win, tex, x, y)
        lastTexWin  = win
        lastTexName = tex
    end
    WCDP.TestPulse( 0.2, 0.6, 0.3 )
    Player.GetAbilityData = savedGetAbilityData
    assert(lastTexWin == "WCDPFrameImageSquare",
           "TestPulse must call DynamicImageSetTexture on WCDPFrameImageSquare, got: " ..
           tostring(lastTexWin))
    assert(lastTexName == "wcdp_heart",
           "TestPulse must use wcdp_heart as fallback texture, got: " ..
           tostring(lastTexName))
end)

it("testPulse: uses real ability icon when one is available in cache", function()
    reset()
    -- Simulate a cached ability by triggering a cooldown cycle
    WCDP.PerformAbilityUpdate( 42, 5, 5, 5 )
    WCDP.PerformAbilityUpdate( 42, 0, 5, 0 )
    local lastTexWin, lastTexName = nil, nil
    DynamicImageSetTexture = function(win, tex, x, y)
        lastTexWin  = win
        lastTexName = tex
    end
    WCDP.TestPulse( 0.2, 0.6, 0.3 )
    assert(lastTexWin == "WCDPFrameImageSquare",
           "TestPulse must call DynamicImageSetTexture on WCDPFrameImageSquare")
    assert(lastTexName ~= nil and lastTexName ~= "wcdp_heart",
           "TestPulse must use a real ability icon when cache is populated, got: " ..
           tostring(lastTexName))
end)
