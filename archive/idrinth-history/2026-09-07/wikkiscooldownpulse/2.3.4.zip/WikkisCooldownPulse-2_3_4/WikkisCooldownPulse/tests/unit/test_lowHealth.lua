-- Tests for CHANTIER 3 (2.2.0): low-health pulse.
-- Source: GameData.Player.hitPoints.current / .maximum
-- (confirmed in pure, BuffHead, MiracleGrowLight, Enemy — Game\ROR)

local healthPulseCount = nil
local lastWindowAnimated = nil

local function reset()
    healthPulseCount = 0
    lastWindowAnimated = nil
    WindowStartAlphaAnimation = function(win, ...)
        lastWindowAnimated = win
        if win == "WCDPHealthFrame" then
            healthPulseCount = healthPulseCount + 1
        end
    end
    SetPlayerHP( 5000, 5000 )  -- full health
    WCDP.db.lowhealth.enabled        = true
    WCDP.db.lowhealth.threshold      = 10
    WCDP.db.lowhealth.repeatInterval = 1.5
    WCDP.db.lowhealth.sound          = false   -- suppress sound side-effects
    WCDP.Reinitialize()
    -- BUG-5B (2.3.2): Reinitialize now sets a 3-second startup grace period to prevent
    -- false pulses at login. Drain it here at full HP so test cases can exercise
    -- CheckLowHealthPulse behavior without waiting 3 real seconds.
    WCDP.CheckLowHealthPulse( 3.1 )
    healthPulseCount = 0  -- reset after drain (no pulses at full HP)
end

it("lowHealth: no pulse when health above threshold", function()
    reset()
    SetPlayerHP( 5000, 5000 )  -- 100% HP
    WCDP.CheckLowHealthPulse( 0.1 )
    assert(healthPulseCount == 0, "no pulse at full health")
end)

it("lowHealth: no pulse when feature disabled", function()
    reset()
    WCDP.db.lowhealth.enabled = false
    SetPlayerHP( 100, 5000 )   -- 2% HP — but feature is off
    WCDP.CheckLowHealthPulse( 0.1 )
    assert(healthPulseCount == 0, "no pulse when lowhealth.enabled=false")
end)

it("lowHealth: pulse fires immediately when dropping below threshold", function()
    reset()
    SetPlayerHP( 490, 5000 )   -- 9.8% — below 10% threshold
    WCDP.CheckLowHealthPulse( 0.1 )
    assert(healthPulseCount == 1, "pulse must fire on first below-threshold check")
    assert(lastWindowAnimated == "WCDPHealthFrame",
           "health pulse must target WCDPHealthFrame, got: " .. tostring(lastWindowAnimated))
end)

it("lowHealth: pulse does not repeat before interval expires", function()
    reset()
    SetPlayerHP( 490, 5000 )
    WCDP.CheckLowHealthPulse( 0.1 )    -- fires immediately (timer set to 1.5)
    assert(healthPulseCount == 1, "one pulse on entry")
    WCDP.CheckLowHealthPulse( 0.5 )    -- 0.5 s elapsed — interval not expired
    assert(healthPulseCount == 1, "no second pulse before interval")
end)

it("lowHealth: pulse repeats after interval", function()
    reset()
    SetPlayerHP( 490, 5000 )
    WCDP.CheckLowHealthPulse( 0.1 )    -- fires, timer = 1.5
    assert(healthPulseCount == 1, "one pulse on entry")
    WCDP.CheckLowHealthPulse( 0.8 )    -- 0.8 s: total elapsed 0.9 < 1.5
    assert(healthPulseCount == 1, "still one pulse at 0.9 s")
    WCDP.CheckLowHealthPulse( 0.8 )    -- 0.8 s: total elapsed 1.7 > 1.5 → fires again
    assert(healthPulseCount == 2, "second pulse must fire after interval")
end)

it("lowHealth: stops pulsing when health recovers above threshold", function()
    reset()
    SetPlayerHP( 490, 5000 )
    WCDP.CheckLowHealthPulse( 0.1 )    -- fires
    assert(healthPulseCount == 1, "pulse fired below threshold")
    SetPlayerHP( 5000, 5000 )          -- healed
    WCDP.CheckLowHealthPulse( 2.0 )    -- well past interval, but HP is fine now
    assert(healthPulseCount == 1, "no pulse after health recovers")
end)

it("lowHealth: re-triggers immediately on next drop after recovery", function()
    reset()
    -- Drop → pulse → recover → drop again
    SetPlayerHP( 490, 5000 )
    WCDP.CheckLowHealthPulse( 0.1 )
    assert(healthPulseCount == 1, "first drop fires")
    SetPlayerHP( 5000, 5000 )
    WCDP.CheckLowHealthPulse( 0.1 )    -- recovery
    SetPlayerHP( 200, 5000 )           -- drop again
    WCDP.CheckLowHealthPulse( 0.1 )    -- must fire immediately again
    assert(healthPulseCount == 2, "re-entry below threshold must pulse immediately")
end)

it("lowHealth: exactly at threshold fires (pct <= threshold)", function()
    reset()
    -- 10% exactly: 500/5000
    SetPlayerHP( 500, 5000 )
    WCDP.CheckLowHealthPulse( 0.1 )
    assert(healthPulseCount == 1, "pulse must fire at exactly the threshold value")
end)

it("lowHealth: one point above threshold does not fire", function()
    reset()
    -- 10.02% HP — just above 10% threshold
    SetPlayerHP( 501, 5000 )
    WCDP.CheckLowHealthPulse( 0.1 )
    assert(healthPulseCount == 0, "no pulse just above threshold")
end)

it("lowHealth: Reinitialize resets active flag and timer", function()
    reset()
    SetPlayerHP( 490, 5000 )
    WCDP.CheckLowHealthPulse( 0.1 )    -- fires, marks active (count=1)
    WCDP.Reinitialize()
    -- BUG-5B (2.3.2): Reinitialize resets the 3-second startup grace period.
    -- Drain it at full HP before testing re-entry behavior.
    SetPlayerHP( 5000, 5000 )
    WCDP.CheckLowHealthPulse( 3.1 )
    healthPulseCount = 0
    -- After reinitialize + grace drain, dropping below threshold must fire immediately
    SetPlayerHP( 490, 5000 )
    WCDP.CheckLowHealthPulse( 0.1 )
    assert(healthPulseCount == 1, "reinitialize must reset state so next check fires fresh")
end)

it("lowHealth: no pulse when player is dead (hp=0)", function()
    reset()
    SetPlayerHP( 490, 5000 )               -- 9.8% — below threshold
    WCDP.CheckLowHealthPulse( 0.1 )        -- fires immediately
    assert(healthPulseCount == 1, "initial pulse below threshold")
    SetPlayerHP( 0, 5000 )                 -- player dies
    WCDP.CheckLowHealthPulse( 2.0 )        -- well past interval, still dead
    assert(healthPulseCount == 1, "no pulse while dead")
end)

it("lowHealth: pulse resumes immediately after resurrection", function()
    reset()
    SetPlayerHP( 490, 5000 )
    WCDP.CheckLowHealthPulse( 0.1 )        -- fires
    SetPlayerHP( 0, 5000 )                 -- die
    WCDP.CheckLowHealthPulse( 0.1 )        -- dead, no new pulse
    assert(healthPulseCount == 1, "no pulse while dead")
    SetPlayerHP( 490, 5000 )               -- resurrected but still low HP
    WCDP.CheckLowHealthPulse( 0.1 )        -- must fire immediately on re-entry
    assert(healthPulseCount == 2, "pulse fires immediately after resurrection")
end)
