whatsPugSc = {}
whatsPugSc.SavedVariables = {}

whatsPugSc.ScenarioInfo = 
-- this is for other languages
{
	-- tier 1
	["Gates of Ekrund"] 		= {name = GetScenarioName(2000), id = 2000},
	["Nordenwatch"] 			= {name = GetScenarioName(2100), id = 2100},
	["Khaine's Embrace"] 		= {name = GetScenarioName(2200), id = 2200},

	-- tier 2
	["Mourkain Temple"] 		= {name = GetScenarioName(2001), id = 2001},
	["Phoenix Gate"] 			= {name = GetScenarioName(2201), id = 2201},
	["Stonetroll Crossing"] 	= {name = GetScenarioName(2101), id = 2101},

	-- tier 3
	["Black Fire Basin"] 		= {name = GetScenarioName(2002), id = 2002},
	["Doomfist Crater"] 		= {name = GetScenarioName(2011), id = 2011},
	["Talabec Dam"] 			= {name = GetScenarioName(2102), id = 2102},
	["Highpass Cemetery"] 		= {name = GetScenarioName(2103), id = 2103},
	["Tor Anroc"] 				= {name = GetScenarioName(2202), id = 2202},
	["Lost Temple of Isha"] 	= {name = GetScenarioName(2203), id = 2203},
		
	-- tier 4
	["Thunder Valley"] 			= {name = GetScenarioName(2005), id = 2005},
	["Logrin's Forge"] 			= {name = GetScenarioName(2006), id = 2006},
	["Battle for Praag"] 		= {name = GetScenarioName(2106), id = 2106},
	["Grovod Caverns"] 			= {name = GetScenarioName(2107), id = 2107},
	["Serpent's Passage"] 		= {name = GetScenarioName(2204), id = 2204},
	["Dragon's Bane"] 			= {name = GetScenarioName(2205), id = 2205},

	-- tier 4, special
	["Altdorf War Quarters"]	= {name = GetScenarioName(2012), id = 2012},
	["The Undercroft"]			= {name = GetScenarioName(2013), id = 2013},
	["Maw of Madness"]			= {name = GetScenarioName(2104), id = 2104},
	["Reikland Hills"]			= {name = GetScenarioName(2109), id = 2109},

	-- tier 4, special
	["Kadrin Valley Pass"]		= {name = GetScenarioName(2003), id = 2003},
	["Gromril Crossing"]		= {name = GetScenarioName(2004), id = 2004},
	["Black Crag Keep"]			= {name = GetScenarioName(2007), id = 2007},
	["Howling Gorge"]			= {name = GetScenarioName(2008), id = 2008},
	["Karaz-a-Karak Gates"]		= {name = GetScenarioName(2009), id = 2009},
	["Eight Peaks Gates"]		= {name = GetScenarioName(2010), id = 2010},
	["Twisting Tower"]			= {name = GetScenarioName(2105), id = 2105},
	["Castle Fragendorf"]		= {name = GetScenarioName(2108), id = 2108},
	["Altdorf"]					= {name = GetScenarioName(2111), id = 2111},
	["Blood of the Black Cairn"]= {name = GetScenarioName(2206), id = 2206},
	["Caledor Woods"]			= {name = GetScenarioName(2207), id = 2207},
	["The Eternal Citadel"] 	= {name = GetScenarioName(2123), id = 2123},
	
}

local showPickupScenarioFirst = true

function whatsPugSc.OnInitialize()
	TextLogAddEntry("Chat", 0, L"whatsPugSc started")
	RegisterEventHandler(SystemData.Events.CHAT_TEXT_ARRIVED, "whatsPugSc.OnChat")
	LibSlash.RegisterSlashCmd("whatsPugSc", function(input) whatsPugSc.HandleSlashCmd(input) end)
	
end

function whatsPugSc.HandleSlashCmd(input)
end

function whatsPugSc.OnShutdown()
	UnregisterEventHandler(SystemData.Events.CHAT_TEXT_ARRIVED, "whatsPugSc.OnChat")
end

function whatsPugSc.OnChat()
	local type = GameData.ChatData.type
	if (type == SystemData.ChatLogFilters.SCENARIO) then
		whatsPugSc.ChatHandler()
	end
end

function whatsPugSc.ChatHandler()
	
	local msg = GameData.ChatData.text
	if (wstring.sub(msg, 1, 31) == L"The current pickup scenario is ") then
		local nn = wstring.sub(msg, 32, -2) 
		--L"The current pickup scenario is Nordenwatch."

		whatsPugSc.SavedVariables.PickupScenario = {}
		whatsPugSc.SavedVariables.PickupScenario.name = nn
		whatsPugSc.SavedVariables.PickupScenario.id = whatsPugSc.getScenarioId(nn)

		if whatsPugSc.SavedVariables.PickupScenario.id == 1 then
			EA_ChatWindow.Print("whatspugsc: sorry i tried")
		else
			EA_ChatWindow.Print("whatspugsc: gotcha! current pug scenario is "..tostring(whatsPugSc.SavedVariables.PickupScenario.name))
			if showPickupScenarioFirst then
				EA_Window_ScenarioLobby.UpdateQueueList = whatsPugSc.UpdateQueueList
			end
			--EA_ChatWindow.Print(tostring(whatsPugSc.SavedVariables.PickupScenario.id))
		end
		UnregisterEventHandler(SystemData.Events.CHAT_TEXT_ARRIVED, "whatsPugSc.OnChat")
	end

end

function whatsPugSc.getScenarioId(scname)
	return (whatsPugSc.ScenarioInfo[tostring(whatsPugSc.SavedVariables.PickupScenario.name)].id or 1)
end

function whatsPugSc.UpdateQueueList()
	WindowSetShowing("EA_Window_ScenarioLobby", GameData.ScenarioQueueData[1].id ~= 0 )
	EA_Window_ScenarioLobby.ShowScenario( 1 )
	
	for i, sc in ipairs(GameData.ScenarioQueueData) do
		if (GetScenarioName(sc.id) == whatsPugSc.SavedVariables.PickupScenario.name) or (sc.id == whatsPugSc.SavedVariables.PickupScenario.id) then
			EA_Window_ScenarioLobby.ShowScenario( i )
		end
	end

	-- Hide the Prev/Next Buttons when we only have one scenario
	local showButtons = GameData.ScenarioQueueData[2].id ~= 0
	
    WindowSetShowing("EA_Window_ScenarioLobbyPreviousScenarioButton", showButtons )
	WindowSetShowing("EA_Window_ScenarioLobbyNextScenarioButton", showButtons )	
end