if not WarBoard_Friend then WarBoard_Friend = {} end
local WarBoard_Friend = WarBoard_Friend
local LabelSetText, tinsert, Tooltips, ipairs, tostring, towstring, format, GetFriendsList =
	  LabelSetText, table.insert, Tooltips, ipairs, tostring, towstring, string.format, GetFriendsList

local ICON_BY_CAREER_ID = {
    -- Order - High Elves
    [20] = "<icon=20189>",   -- Swordmaster
    [21] = "<icon=20188>",   -- White Lion
    [22] = "<icon=20193>",   -- Shadow Warrior
    [23] = "<icon=20187>",   -- Archmage
    -- Destruction - Greenskins
    [24] = "<icon=20182>",   -- Black Orc
    [25] = "<icon=20184>",   -- Choppa
    [26] = "<icon=20195>",   -- Squig Herder
    [27] = "<icon=20197>",   -- Shaman
    -- Order - Dwarfs & KotBS
    [60] = "<icon=20202>",   -- Slayer
    [61] = "<icon=20190>",   -- Knight of the Blazing Sun
    [62] = "<icon=20183>",   -- Ironbreaker
    [63] = "<icon=20199>",   -- Rune Priest
    -- Destruction - Dark Elves
    [64] = "<icon=20185>",   -- Black Guard
    [65] = "<icon=20192>",   -- Witch Elf
    [66] = "<icon=20203>",   -- Sorceress
    [67] = "<icon=20191>",   -- Disciple of Khaine
    -- Order - Empire
    [100] = "<icon=20198>",  -- Bright Wizard
    [101] = "<icon=20194>",  -- Warrior Priest
    [102] = "<icon=20200>",  -- Witch Hunter
    [103] = "<icon=20180>",  -- Engineer
    -- Destruction - Chaos
    [104] = "<icon=20181>",  -- Chosen
    [105] = "<icon=20201>",  -- Zealot
    [106] = "<icon=20186>",  -- Magus
    [107] = "<icon=20196>",  -- Marauder
    -- Fallback
    default = "<icon=43>",
}

function WarBoard_Friend.Initialize()
	if (WarBoard.AddMod("WarBoard_Friend")) then
		WarBoard_Friend.SetIcon("WarBoard_FriendIcon", 00162)
		RegisterEventHandler(SystemData.Events.SOCIAL_FRIENDS_UPDATED, "WarBoard_Friend.OnSocialFriendsUpdated")
		RegisterEventHandler(SystemData.Events.TARGET_SELF, "WarBoard_Friend.OnSocialFriendsUpdated")
		WarBoard_Friend.OnSocialFriendsUpdated()
	end
end

function WarBoard_Friend.OnSocialFriendsUpdated()
	local fr_list, online = GetFriendsList(), 0
	local total = #fr_list
	for ndx = 1, total do
		if (fr_list[ndx].zoneID ~= 0) then online = online+1 end 
	end
	LabelSetText("WarBoard_FriendLabel", towstring(format(online.."/"..total)))
end

function WarBoard_Friend.OnClick()
	SocialWindow.ToggleShowing()
end


function WarBoard_Friend.OnMouseOver()
	local friends, friendsOn, line = GetFriendsList(), {}, 1
	for i = 1, #friends do
		if friends[ i ].zoneID ~= 0 then
		tinsert(friendsOn, friends[ i ])
		end
	end
	Tooltips.CreateTextOnlyTooltip("WarBoard_Friend", nil)
	Tooltips.AnchorTooltip(WarBoard.GetModToolTipAnchor("WarBoard_Friend"))
	Tooltips.SetTooltipColor(1, 1, 0, 255, 255)
	Tooltips.SetTooltipText(1, 1, L"Friends Online")
	for k, v in ipairs(friendsOn) do
		line = line + 1
		local friend = friendsOn[k]
		local rank = friend.rank
		local careerIcon = ICON_BY_CAREER_ID[friend.careerID] or ICON_BY_CAREER_ID.default
		Tooltips.SetTooltipColor(line, 1, 54, 176, 255)
		Tooltips.SetTooltipText(line, 1, towstring(careerIcon .. " ["..tostring(rank).."] "..tostring(friend.name)))
		Tooltips.SetTooltipText(line, 3, GetZoneName(friend.zoneID))
	end
	Tooltips.Finalize()
end

function WarBoard_Friend.SetIcon(dynamicImageTitle, icon)
	local texture, x, y = GetIconData(icon)
	DynamicImageSetTexture(dynamicImageTitle, texture, x, y)
end
