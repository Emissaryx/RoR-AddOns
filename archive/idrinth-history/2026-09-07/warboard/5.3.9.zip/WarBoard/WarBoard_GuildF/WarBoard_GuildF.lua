if not WarBoard_GuildF then WarBoard_GuildF = {} end
local WarBoard_GuildF = WarBoard_GuildF
local tinsert, format, LabelSetText, WindowSetShowing, Tooltips, ipairs, tostring, towstring, unpack, GetGuildMemberData =
	  table.insert, string.format, LabelSetText, WindowSetShowing, Tooltips, ipairs, tostring, towstring, unpack, GetGuildMemberData

local ICON_BY_CAREER_ID = {
    -- Order - High Elves
    [20] = "<icon=20189>",   -- Swordmaster
    [21] = "<icon=20188>",   -- White Lion
    [22] = "<icon=20193>",   -- Shadow Warrior
    [23] = "<icon=20187>",   -- Archmage
    -- Destruction - Greenskins
    [24] = "<icon=20182>",   -- Black Orc
    [25] = "<icon=20184>",   -- Choppa
    [26] = "<icon=20195>",   -- Squig Herder
    [27] = "<icon=20197>",   -- Shaman
    -- Order - Dwarfs & KotBS
    [60] = "<icon=20202>",   -- Slayer
    [61] = "<icon=20190>",   -- Knight of the Blazing Sun
    [62] = "<icon=20183>",   -- Ironbreaker
    [63] = "<icon=20199>",   -- Rune Priest
    -- Destruction - Dark Elves
    [64] = "<icon=20185>",   -- Black Guard
    [65] = "<icon=20192>",   -- Witch Elf
    [66] = "<icon=20203>",   -- Sorceress
    [67] = "<icon=20191>",   -- Disciple of Khaine
    -- Order - Empire
    [100] = "<icon=20198>",  -- Bright Wizard
    [101] = "<icon=20194>",  -- Warrior Priest
    [102] = "<icon=20200>",  -- Witch Hunter
    [103] = "<icon=20180>",  -- Engineer
    -- Destruction - Chaos
    [104] = "<icon=20181>",  -- Chosen
    [105] = "<icon=20201>",  -- Zealot
    [106] = "<icon=20186>",  -- Magus
    [107] = "<icon=20196>",  -- Marauder
    -- Fallback
    default = "<icon=43>",
}

function WarBoard_GuildF.Initialize()
	if WarBoard.AddMod("WarBoard_GuildF") then
		WarBoard_GuildF.SetIcon("WarBoard_GuildFIcon", 00166)
		RegisterEventHandler(SystemData.Events.GUILD_MEMBER_UPDATED, "WarBoard_GuildF.OnGuildMemberUpdated")
		WarBoard_GuildF.OnGuildMemberUpdated()
	end
end

function WarBoard_GuildF.OnGuildMemberUpdated()
	local members, online = GetGuildMemberData(), 0
	local total = #members
	for i = 1, total do if (members[i].zoneID ~= 0) then online = online+1 end end
	LabelSetText("WarBoard_GuildFLabel", towstring(format(online.."/"..total)))
end

function WarBoard_GuildF.OnClick()
	GuildWindow.ToggleShowing()
end

function WarBoard_GuildF.OnMouseOver()
	local members, membersOn, line, lvl_col = GetGuildMemberData(), {}, 1
	for i = 1, #members do
		if members[i].zoneID ~= 0 then
			tinsert(membersOn, members[i])
		end
	end
	Tooltips.CreateTextOnlyTooltip("WarBoard_GuildF", nil)
	Tooltips.AnchorTooltip(WarBoard.GetModToolTipAnchor("WarBoard_GuildF"))
	Tooltips.SetTooltipText(1, 1, GameData.Guild.m_GuildName)
	for k, v in ipairs(membersOn) do
		line = line + 1
		local rank = membersOn[k].rank
		local careerIcon = ICON_BY_CAREER_ID[membersOn[k].careerID] or ICON_BY_CAREER_ID.default
		local loc = GetZoneName(membersOn[ k ].zoneID)
		if rank > GameData.Player.level + 5 then lvl_col = {255,200,150}
		elseif rank < GameData.Player.level - 5 then lvl_col = {150,250,100}
		else lvl_col = {250,250,20} end
		Tooltips.SetTooltipColor(line, 1, unpack(lvl_col))
		Tooltips.SetTooltipText(line, 1, towstring(careerIcon.." ["..tostring(rank).."] "..tostring(membersOn[k].name)))
		Tooltips.SetTooltipText(line, 3, towstring(tostring(loc)))
	end
	Tooltips.Finalize()
end

function WarBoard_GuildF.SetIcon(dynamicImageTitle, icon)
	local texture, x, y = GetIconData(icon)
	DynamicImageSetTexture(dynamicImageTitle, texture, x, y)
end
