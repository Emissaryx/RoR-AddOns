<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
	<UiMod name="WarBoard_ZonePOP" version="rev39" date="13/03/2021" >
		<Author name="Caffeine"/>
		<Description text="Warboard module for ZonepopLite addon." />
		<VersionSettings gameVersion="1.3.5" windowsVersion="1.0" />
		<Dependencies>
			<Dependency name="WarBoard" />
			<Dependency name="LibWBToggler" />
			<Dependency name="ZonepopLite" />
		</Dependencies>
		<Files>
			<File name="WarBoard_ZonePOP.xml" />
			<File name="WarBoard_ZonePOP.lua" />
		</Files>
		<OnInitialize>
			<CallFunction name="WarBoard_ZonePOP.Initialize" />
		</OnInitialize>
	</UiMod>
</ModuleFile>