WarBoard_ZonePOP = WarBoard_ZonePOP or {};

local modName = "WarBoard_ZonePOP";
local modLabel = "ZonePOP";

local LabelSetText = LabelSetText;
local getTimerWstring = ZonepopLite.GetTimerWstring;
local getPairingName = ZonepopLite.GetPairingName;
local ToRgbWstring = ZonepopLite.ToRgbWstring;
local COLOR_WHITE = ZonepopLite.COLOR_WHITE;
local COLOR_TOTAL_POP = ZonepopLite.COLOR_TOTAL_POP;
local COLOR_GRAY = ZonepopLite.COLOR_GRAY;
local COLOR_ORDER = ZonepopLite.COLOR_ORDER;
local COLOR_DESTR = ZonepopLite.COLOR_DESTR;

local COLOR_SHORTHAND = {r=54,g=176,b=255}; -- {r=54,g=176,b=255}; blue {r=0,g=200,b=0}; green
local COLOR_MENU = {r=247,g=194,b=88}; -- {r=247,g=194,b=88} orange

local zonePairs = {
	[1]=7,
	[2]=8,
	[6]=11,
	[7]=1,
	[8]=2,
	[11]=6,
	[100]=106,
	[101]=107,
	[102]=108,
	[106]=100,
	[107]=101,
	[108]=102,
	[200]=206,
	[201]=207,
	[202]=208,
	[206]=200,
	[207]=201,
	[208]=202
}

local pairedZones = {
	[1]={1,7},
	[2]={2,8},
	[6]={6,11},
	[7]={1,7},
	[8]={2,8},
	[11]={6,11},
	[100]={100,106},
	[101]={101,107},
	[102]={102,108},
	[106]={100,106},
	[107]={101,107},
	[108]={102,108},
	[200]={200,206},
	[201]={201,207},
	[202]={202,208},
	[206]={200,206},
	[207]={201,207},
	[208]={202,208}
}


local function GetPairedZoneName(zoneId)
	local zoneId = tonumber(zoneId);
	if not zoneId then return nil end
	-- forts
	if ZonepopLite.FortOwner[zoneId] then
		local prefix = L"[F]";
		if (ZonepopLite.FortOwner[zoneId] == 1) then
			return ToRgbWstring(COLOR_ORDER, prefix) .. L" " .. ToRgbWstring(COLOR_WHITE, GetZoneName(zoneId));
		else
			return ToRgbWstring(COLOR_DESTR, prefix) .. L" " .. ToRgbWstring(COLOR_WHITE, GetZoneName(zoneId));
		end	
	-- tier 1
	elseif (zoneId == 100) or (zoneId == 106) then
		return ToRgbWstring(COLOR_WHITE,L"T1 Empire");
	elseif (zoneId == 200) or (zoneId == 206) then
		return ToRgbWstring(COLOR_WHITE,L"T1 Elf");
	elseif (zoneId == 6) or (zoneId == 11) then
		return ToRgbWstring(COLOR_WHITE,L"T1 Dwarf");
		
	--  tier 2
	elseif (zoneId == 101) or (zoneId == 107) then
		return ToRgbWstring(COLOR_WHITE, L"T2 Empire");
	elseif (zoneId == 201) or (zoneId == 207) then
		return ToRgbWstring(COLOR_WHITE, L"T2 Elf");
	elseif (zoneId == 1) or (zoneId == 7) then
		return ToRgbWstring(COLOR_WHITE, L"T2 Dwarf");
		
	-- tier 3
	elseif (zoneId == 108) or (zoneId == 102) then
		return ToRgbWstring(COLOR_WHITE,L"T3 Empire");
	elseif (zoneId == 202) or (zoneId == 208) then
		return ToRgbWstring(COLOR_WHITE,L"T3 Elf");
	elseif (zoneId == 2) or (zoneId == 8) then
		return ToRgbWstring(COLOR_WHITE,L"T3 Dwarf");
		
	-- single instance zone
	else
		return ToRgbWstring(COLOR_WHITE,GetZoneName(zoneId));
	end
end


local function isPlayerInsidePairing(zoneId)
    if not pairedZones[zoneId] then return false end
    local localZone = tonumber(GameData.Player.zone);
    local pairing = pairedZones[zoneId];
    for i=1, #pairing do
        local targetId = pairing[i];
        if localZone == targetId then return true end
    end
    return false;
end

function WarBoard_ZonePOP.Initialize()
	-- registger this module with warboard manager
	if WarBoard.AddMod(modName) then
		WindowSetDimensions(modName, 100, 30);
		WarBoard_ZonePOP.resetPopulationLabels();
		LibWBToggler.RegisterEvent(modName, "OnMouseOver", "WarBoard_ZonePOP.showTooltip");
    	RegisterEventHandler( SystemData.Events.LOADING_END, "WarBoard_ZonePOP.resetPopulationLabels");
    end
    
end

function WarBoard_ZonePOP.updatePopulationLabels(zoneId)

	zoneId = tonumber(zoneId)
	local localZone = tonumber(GameData.Player.zone)

	if (localZone == zoneId) or (isPlayerInsidePairing(zoneId) == true) then

		local status = ZonepopLite.zoneStatus[zoneId]
		local population = status.population

		local des
		local ord

		if status.isFort and status.isFort == true then 
			des = population.destr
			ord = population.order
		else
			des = ZonepopLite.GetDestrPopString(population)
			ord = ZonepopLite.GetOrderPopString(population)
		end

		LabelSetTextColor("WarBoard_ZonePOPDestro",255,69,0);
		LabelSetTextColor("WarBoard_ZonePOPOrder",0,205,255);
		LabelSetText("WarBoard_ZonePOPDestro", (towstring(des)));
		LabelSetText("WarBoard_ZonePOPAnon", (towstring("/")));
		LabelSetText("WarBoard_ZonePOPOrder", (towstring(ord)));
	end
	
end

function WarBoard_ZonePOP.resetPopulationLabels()
	LabelSetTextColor("WarBoard_ZonePOPDestro",255,69,0);
	LabelSetTextColor("WarBoard_ZonePOPOrder",0,205,255);
	LabelSetText("WarBoard_ZonePOPDestro", L"---");
	LabelSetText("WarBoard_ZonePOPAnon", L"/");
	LabelSetText("WarBoard_ZonePOPOrder", L"---");
end


function WarBoard_ZonePOP.reportStatusToChat()
    local zoneId = GameData.Player.zone;
	local secondZoneId = zonePairs[zoneId];

	local chatReport;
	
    -- reporting city status
    if ZonepopLite.cityStatus and (ZonepopLite.cityStatus.zoneId == zoneId) then
        local city = ZonepopLite.cityStatus;
        chatReport = L"Status in " .. city.tier.prefix .. L" " .. city.zoneName .. L" - " .. city.report;
        if (city.timeLeft) then
            local timer = getTimerWstring(city.timeLeft) 
            chatReport = chatReport .. L" for ~" .. timer;
        end
    -- reporting a regular zone
    else
		local status = ZonepopLite.zoneStatus[zoneId] or ZonepopLite.zoneStatus[secondZoneId];
		if (not status) or (not status.report) then
			EA_ChatWindow.Print(L"No status data to report for your current zone.");
			return;
		end

        local zoneName;
        if status.tier and status.tier.prefix then
            zoneName = status.tier.prefix .. L" " .. status.zoneName;
        else
            zoneName = getPairingName(zoneId);
		end
		chatReport = L"Status in " .. zoneName .. L" - " .. status.report;
	end  
	
    if (chatReport) then
    	EA_ChatWindow.InsertText(chatReport);
    else 
        EA_ChatWindow.Print(L"No status data to report for your current zone.");
    end

end

function WarBoard_ZonePOP.reportPopulationToChat()

    local zoneId = GameData.Player.zone;
	local secondZoneId = zonePairs[zoneId];

    local chatReport

    -- in a city siege
    if ZonepopLite.cityStatus and (ZonepopLite.cityStatus.zoneId == zoneId) then
		EA_ChatWindow.Print(L"No population data to report for your current zone.");
		return;
    -- reporting a regular zone
    else

		local zone;
		local status = ZonepopLite.zoneStatus[zoneId] or ZonepopLite.zoneStatus[secondZoneId];

		if not status or not status.population then	
			EA_ChatWindow.Print(L"No population data to report for your current zone.");
			return;
		end

		local population = status['population'] or nil;

		zone = status.tier.prefix .. L" " .. status.zoneName;

		local ord
		local des
		-- fort status updates still include hard pop data as of 2020-12-04
		if status.isFort and status.isFort == true then 
			des = population.destr
			ord = population.order
		else
			des = ZonepopLite.GetDestrPopString(population)
			ord = ZonepopLite.GetOrderPopString(population)
		end

		local pop = ToRgbWstring(COLOR_WHITE, L"[ Destr ") .. ToRgbWstring(COLOR_DESTR, des) .. ToRgbWstring(COLOR_WHITE," / ") .. ToRgbWstring(COLOR_ORDER, ord) .. ToRgbWstring(COLOR_WHITE, L" Order ]");
		chatReport = L"Pop in " .. zone .. L" - " .. pop;

	end  
	
    if chatReport then
    	EA_ChatWindow.InsertText(chatReport);
    else 
        EA_ChatWindow.Print(L"No population data to report for your current zone.");
    end
end

function WarBoard_ZonePOP.OnMButtonDown()
	ZonepopLite.toggleOverviewWindow();
end

function WarBoard_ZonePOP.showTooltip()
	Tooltips.CreateTextOnlyTooltip(modName, nil)
	Tooltips.AnchorTooltip(WarBoard.GetModToolTipAnchor(modName))
	Tooltips.SetTooltipText(1, 1, L"ZonepopLite")

	Tooltips.SetTooltipText(2, 1, L"Rank: Name")
	Tooltips.SetTooltipColor(2, 1, COLOR_MENU.r, COLOR_MENU.g, COLOR_MENU.b)
	Tooltips.SetTooltipText(2, 3, L"Range")
	Tooltips.SetTooltipColor(2, 3, COLOR_MENU.r, COLOR_MENU.g, COLOR_MENU.b)

	Tooltips.SetTooltipText(3, 1, L"R1: Scouts")
	Tooltips.SetTooltipColor(3, 3, COLOR_SHORTHAND.r, COLOR_SHORTHAND.g, COLOR_SHORTHAND.b)
	Tooltips.SetTooltipText(3, 3, L"0-9")

	Tooltips.SetTooltipText(4, 1, L"R2: Parties")
	Tooltips.SetTooltipColor(4, 3, COLOR_SHORTHAND.r, COLOR_SHORTHAND.g, COLOR_SHORTHAND.b)
	Tooltips.SetTooltipText(4, 3, L"10-24")

	Tooltips.SetTooltipText(5, 1, L"R3: Warbands")
	Tooltips.SetTooltipColor(5, 3, COLOR_SHORTHAND.r, COLOR_SHORTHAND.g, COLOR_SHORTHAND.b)
	Tooltips.SetTooltipText(5, 3, L"25-99")

	Tooltips.SetTooltipText(6, 1, L"R4: Vanguard")
	Tooltips.SetTooltipColor(6, 3, COLOR_SHORTHAND.r, COLOR_SHORTHAND.g, COLOR_SHORTHAND.b)
	Tooltips.SetTooltipText(6, 3, L"100-199")

	Tooltips.SetTooltipText(7, 1, L"R5: Battlehost")
	Tooltips.SetTooltipColor(7, 3, COLOR_SHORTHAND.r, COLOR_SHORTHAND.g, COLOR_SHORTHAND.b)
	Tooltips.SetTooltipText(7, 3, L"200-299")

	Tooltips.SetTooltipText(8, 1, L"R6: Warhost")
	Tooltips.SetTooltipColor(8, 3, COLOR_SHORTHAND.r, COLOR_SHORTHAND.g, COLOR_SHORTHAND.b)
	Tooltips.SetTooltipText(8, 3, L"300+")

	Tooltips.SetTooltipText(9, 1, L"Trigger")
	Tooltips.SetTooltipColor(9, 1, COLOR_MENU.r, COLOR_MENU.g, COLOR_MENU.b)
	Tooltips.SetTooltipText(9, 3, L"Action")
	Tooltips.SetTooltipColor(9, 3, COLOR_MENU.r, COLOR_MENU.g, COLOR_MENU.b)

	Tooltips.SetTooltipText(10, 1, L"R-Click")
	Tooltips.SetTooltipText(10, 3, L"Report local pop")
	Tooltips.SetTooltipText(11, 1, L"M-Click")
	Tooltips.SetTooltipText(11, 3, L"Toggle ZonepopLite")
	Tooltips.SetTooltipText(12, 1, L"L-Click")
	Tooltips.SetTooltipText(12, 3, L"Report local status")

	Tooltips.Finalize()
end











