WarBoard_LuaMemory = WarBoard_LuaMemory or {}

local LabelSetText = LabelSetText
local LabelSetTextColor = LabelSetTextColor
local collectgarbage = collectgarbage

local COLOR_GREEN = {r = 109, g = 179, b = 124} -- green	#6db37c rgb(109, 179, 124) 76BA89 also nice
local COLOR_YELLOW = {r = 200, g = 208, b = 121} -- yellow 	#c8d079 rgb(200, 208, 121)
local COLOR_RED = {r = 188, g = 154, b = 111} -- "red"		#bc9a6f	rgb(188, 154, 111)

-- runtime
local peak = 0

local function toRGBWstring(str, color)
    return towstring(CreateHyperLink(L"", towstring(str), {color.r, color.g, color.b}, {}))
end

local function getColorByThreshold(value)
    if (value < 35) then
        return COLOR_GREEN
    elseif (value < 45) then
        return COLOR_YELLOW
    else
        return COLOR_RED
    end
end

local function setMemoryLabel(value)
    local color = getColorByThreshold(value)
    LabelSetText("WarBoard_LuaMemoryValue", towstring(value)) -- this label is 5 characters max
    LabelSetTextColor("WarBoard_LuaMemoryValue", color.r, color.g, color.b)
end

local function peakValueToWstring(peak)
    local color = getColorByThreshold(peak)
    peak = string.sub(tostring(peak), 0, 5)
    return toRGBWstring(peak, color)
end

function WarBoard_LuaMemory.Initialize()
    if WarBoard.AddMod("WarBoard_LuaMemory") then
        LabelSetText("WarBoard_LuaMemoryUnit", L" MB")
		RegisterEventHandler(SystemData.Events.ALL_MODULES_INITIALIZED, "WarBoard_LuaMemory.resetPeak")
    end
end

local timer = 0
function WarBoard_LuaMemory.OnUpdate(elapsedTime)
    timer = timer + elapsedTime
    if timer >= 2 then
        local memory = collectgarbage("count") / 1024
        if (memory > peak) then
            peak = memory
        end
        setMemoryLabel(memory)
        timer = 0
    end
end

function WarBoard_LuaMemory.collectGarbage()
    local oldMemory = collectgarbage("count") / 1024
    collectgarbage()
    local newMemory = collectgarbage("count") / 1024
    setMemoryLabel(newMemory)
    local net = oldMemory - newMemory
    net = string.sub(tostring(net), 0, 5)
    net = toRGBWstring(net, COLOR_GREEN)
    EA_ChatWindow.Print(towstring(L"[LuaMemory] forced garbage collector to free up: " .. net .. L" MB"))
end

function WarBoard_LuaMemory.reportPeak()
    local memory = peakValueToWstring(peak)
    EA_ChatWindow.Print(towstring(L"[LuaMemory] peak memory usage this session is: " .. memory .. L" MB"))
end

function WarBoard_LuaMemory.drawMouseoverTooltip()
    Tooltips.CreateTextOnlyTooltip("WarBoard_LuaMemory", nil)
    Tooltips.AnchorTooltip(WarBoard.GetModToolTipAnchor("WarBoard_LuaMemory"))
    Tooltips.SetTooltipText(1, 1, L"LuaMemory")
    
    local color = getColorByThreshold(peak)
    Tooltips.SetTooltipColor(2, 3, color.r, color.g, color.b)
    Tooltips.SetTooltipText(2, 1, L"Session peak:")
    Tooltips.SetTooltipText(2, 3, towstring(string.sub(tostring(peak), 0, 5)) .. L" MB")
    
    Tooltips.SetTooltipText(3, 1, L"R-Click: reset peak")
    --Tooltips.SetTooltipText(4, 1, L"R-Click: report peak")
    Tooltips.SetTooltipText(4, 1, L"L-Click: collect garbage")
    
    Tooltips.Finalize()
end

function WarBoard_LuaMemory.resetPeak()
    peak = 0;
	WarBoard_LuaMemory.drawMouseoverTooltip() -- update tooltip
end