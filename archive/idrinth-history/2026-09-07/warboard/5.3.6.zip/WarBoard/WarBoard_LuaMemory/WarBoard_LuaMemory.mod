<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
	<UiMod name="WarBoard_LuaMemory" version="0.2" date="05/25/2020" >
		<Author name="Caffeine" email="" />
		<Description text="A module for WarBoard that tracks LUA memory." />
		<VersionSettings gameVersion="1.3.5" windowsVersion="1.1" savedVariablesVersion="1.0" />
		<Dependencies>
			<Dependency name="WarBoard" />
			<Dependency name="EA_ChatWindow" />
		</Dependencies>
		<Files>
			<File name="WarBoard_LuaMemory.lua" />
			<File name="WarBoard_LuaMemory.xml" />
		</Files>
		<OnInitialize>
			<CallFunction name="WarBoard_LuaMemory.Initialize" />
		</OnInitialize>
		<OnUpdate>
			<CallFunction name="WarBoard_LuaMemory.OnUpdate" />
		</OnUpdate>
		<WARInfo>
			<Categories>
				<Category name="SYSTEM" />
				<Category name="OTHER" />
			</Categories>
			<Careers>
				<Career name="BLACKGUARD" />
				<Career name="WITCH_ELF" />
				<Career name="DISCIPLE" />
				<Career name="SORCERER" />
				<Career name="IRON_BREAKER" />
				<Career name="SLAYER" />
				<Career name="RUNE_PRIEST" />
				<Career name="ENGINEER" />
				<Career name="BLACK_ORC" />
				<Career name="CHOPPA" />
				<Career name="SHAMAN" />
				<Career name="SQUIG_HERDER" />
				<Career name="WITCH_HUNTER" />
				<Career name="KNIGHT" />
				<Career name="BRIGHT_WIZARD" />
				<Career name="WARRIOR_PRIEST" />
				<Career name="CHOSEN" />
				<Career name= "MARAUDER" />
				<Career name="ZEALOT" />
				<Career name="MAGUS" />
				<Career name="SWORDMASTER" />
				<Career name="SHADOW_WARRIOR" />
				<Career name="WHITE_LION" />
				<Career name="ARCHMAGE" />
			</Careers>
		</WARInfo>
	</UiMod>
</ModuleFile>