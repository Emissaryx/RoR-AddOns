<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
    <UiMod name="WarBoard_Session" version="0.6" date="06/24/2009" >
        
        <Author name="Lyb" email="lybe86@gmail.com" />
        <Description text="A session stats mod for WarBoard, borrowed heavily from waaghbar ranktimer. Thanks Computerpunk for all the tips so far" />
        <VersionSettings gameVersion="1.4.8" windowsVersion="1.0" savedVariablesVersion="1.0" />
        <Dependencies>
	    	<Dependency name="WarBoard" />
        </Dependencies>
        
        <Files>
            <File name="WarBoard_Session.lua" />
			<File name="WarBoard_Session.xml" />
        </Files>
        
        <OnInitialize>
			<CallFunction name="WarBoard_Session.Initialize" />
        </OnInitialize>

		<OnUpdate/>
        <OnShutdown/>
    </UiMod>
</ModuleFile>
