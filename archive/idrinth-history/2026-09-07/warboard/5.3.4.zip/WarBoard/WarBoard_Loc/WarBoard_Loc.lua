WarBoard_Loc = {}

local TIME_DELAY = 1
local timeleft = TIME_DELAY 

function WarBoard_Loc.Initialize()
	if ( WarBoard.AddMod( "WarBoard_Loc" ) ) then
		d( "WarBoard_Location Module Loaded" )
		
		RegisterEventHandler( SystemData.Events.PLAYER_POSITION_UPDATED, "WarBoard_Loc.OnPlayerPositionUpdated" )

		WindowSetShowing("WarBoard_Loc_lblHidden", false)

		WarBoard_Loc.OnPlayerPositionUpdated(1)

		LabelSetTextColor("WarBoard_Loc_lblLocation2", 0, 185, 174)
	end
end

function WarBoard_Loc.Convert(num)
	if num == nil then
    	return nil
	end
	num = num / 1000
	return towstring(tostring(string.format("%.2f", num)))
end

function WarBoard_Loc.OnPlayerPositionUpdated(elapsed)
	timeleft = timeleft - elapsed
	if timeleft > 0 then
		return
	end
	timeleft = TIME_DELAY

	-- Ensure LibSurveyor and coords are available (zoning protection)
	if not LibSurveyor or not LibSurveyor.PlayerLocation 
	   or not LibSurveyor.PlayerLocation.zoneX 
	   or not LibSurveyor.PlayerLocation.zoneY then
		return
	end

	local pxRaw, pyRaw = LibSurveyor.PlayerLocation.zoneX, LibSurveyor.PlayerLocation.zoneY
	local px, py = WarBoard_Loc.Convert(pxRaw), WarBoard_Loc.Convert(pyRaw)

	-- If conversion failed, bail
	if not px or not py then
		return
	end

	if (pxRaw == 0) or (pyRaw == 0) then
		LabelSetText( "WarBoard_Loc_lblHidden", towstring( GetZoneName( GameData.Player.zone ) ) )
		local xwidth, xheight = LabelGetTextDimensions("WarBoard_Loc_lblHidden")
		WindowSetDimensions("WarBoard_Loc", 200, 30)
		WindowSetDimensions("WarBoard_Loc_lblLocation" , 200, 30)
		WindowSetDimensions("WarBoard_Loc_lblLocation3", 200, 30)
		WindowSetDimensions("WarBoard_Loc_lblLocation2", 200, 30)	
		LabelSetText( "WarBoard_Loc_lblLocation" , L"" )
		LabelSetText( "WarBoard_Loc_lblLocation2", L"" )
		LabelSetText( "WarBoard_Loc_lblLocation3", towstring( GetZoneName( GameData.Player.zone ) ) )
	else
		LabelSetText( "WarBoard_Loc_lblHidden", towstring( GetZoneName( GameData.Player.zone ) ) )
		local xwidth, xheight = LabelGetTextDimensions("WarBoard_Loc_lblHidden")
		WindowSetDimensions("WarBoard_Loc", 200, 30)
		WindowSetDimensions("WarBoard_Loc_lblLocation" , 200, 30)
		WindowSetDimensions("WarBoard_Loc_lblLocation2", 200, 30)
		WindowSetDimensions("WarBoard_Loc_lblLocation3", 200, 30)
		LabelSetText( "WarBoard_Loc_lblLocation" , towstring( GetZoneName( GameData.Player.zone ) ) )
		LabelSetText( "WarBoard_Loc_lblLocation2", px..L", "..py )
		LabelSetText( "WarBoard_Loc_lblLocation3", L"" )
	end
end

function WarBoard_Loc.OnLButtonUp()
	EA_Window_ContextMenu.CreateContextMenu("Chat Menu")
	EA_Window_ContextMenu.AddMenuItem(L"Send my position to Region.", WarBoard_Loc.Broadcast1, false, true)
	EA_Window_ContextMenu.AddMenuItem(L"Send my position to RvR.",   WarBoard_Loc.Broadcast2, false, true)
	EA_Window_ContextMenu.AddMenuItem(L"Send my position to Guild.", WarBoard_Loc.BroadcastG, false, true)
	EA_Window_ContextMenu.AddMenuItem(L"Send my position to Alliance.", WarBoard_Loc.BroadcastA, false, true)
	if IsWarBandActive() then
		EA_Window_ContextMenu.AddMenuItem(L"Send my position to Warband.", WarBoard_Loc.BroadcastW, false, true);
	else
		EA_Window_ContextMenu.AddMenuItem(L"Send my position to Party.", WarBoard_Loc.BroadcastP, false, true);
	end
	EA_Window_ContextMenu.Finalize() 
end

function WarBoard_Loc.OnSetWidth()
	WindowClearAnchors( "WarBoard_Loc_SetWidthWindow" )
	WindowAddAnchor( "WarBoard_Loc_SetWidthWindow", "bottom", "WarBoard_Loc", "top", 0, 0 )
	WindowSetShowing( "WarBoard_Loc_SetWidthWindow", true )
end

function WarBoard_Loc.CloseSetWidthWindow()
	WindowSetShowing( "WarBoard_Loc_SetWidthWindow", false )
end

function WarBoard_Loc.OnMouseOver()
	local pxRaw = LibSurveyor and LibSurveyor.PlayerLocation and LibSurveyor.PlayerLocation.zoneX
	local pyRaw = LibSurveyor and LibSurveyor.PlayerLocation and LibSurveyor.PlayerLocation.zoneY

	if not pxRaw or not pyRaw or (pxRaw == 0) or (pyRaw == 0) then
		return
	end

	Tooltips.CreateTextOnlyTooltip ("WarBoard_Loc")
	Tooltips.AnchorTooltip(Tooltips.ANCHOR_WINDOW_BOTTOM)

	Tooltips.SetTooltipText(1, 1,  L"Location Info")
	Tooltips.SetTooltipColorDef(1, 1, Tooltips.COLOR_HEADING)
	Tooltips.SetTooltipText(2, 1,  L"X:")
	Tooltips.SetTooltipText(2, 2,  towstring(tostring(string.format("%.2f", pxRaw / 1000))))
	Tooltips.SetTooltipText(3, 1,  L"Y: ")
	Tooltips.SetTooltipText(3, 2,  towstring(tostring(string.format("%.2f", pyRaw / 1000))))

	Tooltips.Finalize()
end

-- Broadcast helpers
local function locStrings()
	local px, py   = LibSurveyor.PlayerLocation.zoneX, LibSurveyor.PlayerLocation.zoneY
	local zoneName = towstring(GetZoneName(GameData.Player.zone))
	local areaName = tostring(GameData.Player.area.name or "")
	if (px == 0) or (py == 0) then
		return L"", zoneName, areaName, false
	end
	local xs = towstring(string.format("%.2f", px / 1000))
	local ys = towstring(string.format("%.2f", py / 1000))
	return xs, ys, zoneName, (areaName ~= "")
end

function WarBoard_Loc.Broadcast1()
	local xs, ys, zoneName, hasArea = locStrings()
	if xs == L"" then
		SendChatText(L"/1 I am in " .. zoneName .. L".", L"")
		return
	end
	if not hasArea then
		SendChatText(L"/1 I am in " .. zoneName .. L" @ ["..xs..L", "..ys..L"].", L"")
	else
		SendChatText(L"/1 I am at " .. towstring(GameData.Player.area.name) .. L" in " .. zoneName .. L" ["..xs..L", "..ys..L"].", L"")
	end
end

function WarBoard_Loc.Broadcast2()
	local xs, ys, zoneName, hasArea = locStrings()
	if xs == L"" then
		SendChatText(L"/2 I am in " .. zoneName .. L".", L"")
		return
	end
	if not hasArea then
		SendChatText(L"/2 I am in " .. zoneName .. L" @ ["..xs..L", "..ys..L"].", L"")
	else
		SendChatText(L"/2 I am at " .. towstring(GameData.Player.area.name) .. L" in " .. zoneName .. L" ["..xs..L", "..ys..L"].", L"")
	end
end

function WarBoard_Loc.BroadcastG()
	local xs, ys, zoneName, hasArea = locStrings()
	if xs == L"" then
		SendChatText(L"/g I am in " .. zoneName .. L".", L"")
		return
	end
	if not hasArea then
		SendChatText(L"/g I am in " .. zoneName .. L" @ ["..xs..L", "..ys..L"].", L"")
	else
		SendChatText(L"/g I am at " .. towstring(GameData.Player.area.name) .. L" in " .. zoneName .. L" ["..xs..L", "..ys..L"].", L"")
	end
end

function WarBoard_Loc.BroadcastA()
	local xs, ys, zoneName, hasArea = locStrings()
	if xs == L"" then
		SendChatText(L"/a I am in " .. zoneName .. L".", L"")
		return
	end
	if not hasArea then
		SendChatText(L"/a I am in " .. zoneName .. L" @ ["..xs..L", "..ys..L"].", L"")
	else
		SendChatText(L"/a I am at " .. towstring(GameData.Player.area.name) .. L" in " .. zoneName .. L" ["..xs..L", "..ys..L"].", L"")
	end
end

function WarBoard_Loc.BroadcastP()
	local xs, ys, zoneName, hasArea = locStrings()
	if xs == L"" then
		SendChatText(L"/war I am in " .. zoneName .. L".", L"")
		return
	end
	if not hasArea then
		SendChatText(L"/p I am in " .. zoneName .. L" @ ["..xs..L", "..ys..L"].", L"")
	else
		SendChatText(L"/p I am at " .. towstring(GameData.Player.area.name) .. L" in " .. zoneName .. L" ["..xs..L", "..ys..L"].", L"")
	end
end

function WarBoard_Loc.BroadcastW()
	local xs, ys, zoneName, hasArea = locStrings()
	if xs == L"" then
		SendChatText(L"/wb I am in " .. zoneName .. L".", L"")
		return
	end
	if not hasArea then
		SendChatText(L"/wb I am in " .. zoneName .. L" @ ["..xs..L", "..ys..L"].", L"")
	else
		SendChatText(L"/wb I am at " .. towstring(GameData.Player.area.name) .. L" in " .. zoneName .. L" ["..xs..L", "..ys..L"].", L"")
	end
end

----------------------------------------------------------------
-- Layout Mode Functions, argument is the name of the window.
----------------------------------------------------------------
function WarBoard_Loc.OnDisable()
	WarBoard.DisableMod("WarBoard_Loc")
end

function WarBoard_Loc.MoveRight()
	WarBoard.MoveModRight("WarBoard_Loc")
end

function WarBoard_Loc.MoveLeft()
	WarBoard.MoveModLeft("WarBoard_Loc")
end
