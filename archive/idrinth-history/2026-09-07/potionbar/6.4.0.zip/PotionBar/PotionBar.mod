<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" >
  <UiMod name="PotionBar" version="6.4" date="08/12/2009" autoenabled="true">
    <Author name="Sihirbaz" email="PotionBar@nusi.de"/>
    <Description text="Potion bar that automatically updates itself."/>
    <VersionSettings gameVersion="1.9.9" windowsVersion="1.0" savedVariablesVersion="1.0"/>
    <Dependencies>
      <Dependency name="EASystem_Utils"/>
      <Dependency name="LibSlash"/>
    </Dependencies>
    <Files>
      <File name="Data.lua"/>
      <File name="EN.lua"/>
      <File name="FR.lua"/>
      <File name="DE.lua"/>
      <File name="IT.lua"/>
      <File name="SP.lua"/>
      <File name="Floating.lua"/>
      <File name="Settings.lua"/>
      <File name="Floating.xml"/>
      <File name="Settings.xml"/>
      <File name="Main.lua"/>
    </Files>
    <OnInitialize>
      <CallFunction name="PotionBar.Initialize"/>
    </OnInitialize>
    <OnUpdate>
      <CallFunction name="PotionBar.UpdateCooldowns"/>
      <CallFunction name="PotionBarFloating.RefreshButtons"/>
    </OnUpdate>
    <OnShutdown>
      <CallFunction name="PotionBar.Shutdown"/>
    </OnShutdown>
    <SavedVariables>
      <SavedVariable name="PotionBar.Settings"/>
    </SavedVariables>
  </UiMod>
</ModuleFile>