if not PotionBar then PotionBar = {} end

PotionBar.Inventory = {}

function PotionBar.getValues(id, level, name)
    name = WStringToString(name)
    local description = WStringToString(GetAbilityDescription(id, level))
    if SystemData.Settings.Language.active == SystemData.Settings.Language.GERMAN then
        return PotionBar.getValuesDE(name, description)
    elseif SystemData.Settings.Language.active == SystemData.Settings.Language.FRENCH then
        return PotionBar.getValuesFR(name, description)
    elseif SystemData.Settings.Language.active == SystemData.Settings.Language.SPANISH then
        return PotionBar.getValuesSP(name, description)
    elseif SystemData.Settings.Language.active == SystemData.Settings.Language.ITALIAN then
        return PotionBar.getValuesIT(name, description)
    else
        -- SystemData.Settings.Language.active == SystemData.Settings.Language.ENGLISH
        -- Language unknown or using english (sorry for this arrogance)
        return PotionBar.getValuesEN(name, description)
    end
end

-- parses a string for its numbers and returns each consecutive number (might give multiple returns)
function PotionBar.getNumbers(string, count)
    if not count then return end
    local x, y, f = 0, 0, false
    local results = {}
    for i = 1, count do
        if i > 1 then y = y + 1 end
        x, y = string.find(string, '%d+', y)
        results[i] = tonumber(string.sub(string, x, y))
    end
    return unpack(results)
end

-- returns the first number which it finds in the window under the cursor
function PotionBar.getNumberFromWindowName()
    local windowname = SystemData.MouseOverWindow.name
    local windownumber = tonumber(string.sub(windowname, string.find(windowname, '%d+')))
    return windownumber
end

function PotionBar.Use(args)
    if type(args) == "wstring" then
        args = WStringToString(args)
    end
    if type(args) ~= "string" then return false end
    return PotionBar.LibSlashHandler("use " .. args)
end

function PotionBar.LibSlashHandler(args)
    local bUsedPotion = false
    if not args then return bUsedPotion end

    local command = PotionBar.LibSlashCommand
    if command == nil then
        command = "PotionBar"
    end

    -- accept params like this:
    -- /potionbar help
    -- /potionbar config
    -- /potionbar reset
    -- /potionbar use AP
    -- /potionbar use HEAL
    -- ...
    -- /potionbar use UNKNOWN 'Name Of Potion'

    local invalidparams = true
    local argv = StringSplit(args)

    if argv ~= nil and #argv >= 1 then
        if string.lower(argv[1]) == "config" then
            WindowSetShowing("PotionBarWindowConfig", true)
            invalidparams = false
        elseif string.lower(argv[1]) == "reset" then
            PotionBar.Defaults()
            invalidparams = false
        elseif string.lower(argv[1]) == "use" and #argv >= 2 and argv[2] ~= nil then
            local useType = nil
            local useName = nil
            argv[2] = string.upper(argv[2])
            for index, Type in ipairs(PotionBar.Type) do
                if Type.Name == argv[2] then
                    useType = index
                    break
                end
            end
            if useType == PotionBar.Type.UNKNOWNS and #argv >= 3 and argv[3] ~= nil then
                useName = string.match(args, "'.*'")
                if useName == nil then
                    useName = string.match(args, "\".*\"") -- for compatibility
                end
                if useName ~= nil and #useName >= 2 then
                    useName = string.sub(useName, 2, #useName-1)
                end
            end
            invalidparams = useType == nil or (useType == PotionBar.Type.UNKNOWNS and useName == nil)
            if not invalidparams then
                bUsedPotion = PotionBarFloating.UsePotion(useType, useName)
                PotionBar.UpdateButtons(true)
            end
        end
    end

    if invalidparams then
        TextLogAddEntry("Chat", SystemData.ChatLogFilters.SAY, L"")
        TextLogAddEntry("Chat", SystemData.ChatLogFilters.SAY, L"")
        TextLogAddEntry("Chat", SystemData.ChatLogFilters.SAY, PotionBar.LocalizableStrings.HelpTitle)
        TextLogAddEntry("Chat", SystemData.ChatLogFilters.SAY, L"")
        TextLogAddEntry("Chat", SystemData.ChatLogFilters.SAY, StringToWString("/" .. command .. " help"))
        TextLogAddEntry("Chat", SystemData.ChatLogFilters.SAY, StringToWString("/" .. command .. " config"))
        for Type = 1, #PotionBar.Type do
            if Type ~= PotionBar.Type.UNKNOWNS then
                TextLogAddEntry("Chat", SystemData.ChatLogFilters.SAY, StringToWString("/" .. command .. " use " .. PotionBar.Type[Type].Name))
            end
        end
        TextLogAddEntry("Chat", SystemData.ChatLogFilters.SAY, L"")
        TextLogAddEntry("Chat", SystemData.ChatLogFilters.SAY, PotionBar.LocalizableStrings.HelpForUnknown)
        TextLogAddEntry("Chat", SystemData.ChatLogFilters.SAY, StringToWString("/" .. command .. " use " .. PotionBar.Type[PotionBar.Type.UNKNOWNS].Name .. " '" .. PotionBar.LocalizableStrings.HelpNameOfPotion .. "'"))
        TextLogAddEntry("Chat", SystemData.ChatLogFilters.SAY, L"")
        TextLogAddEntry("Chat", SystemData.ChatLogFilters.SAY, PotionBar.LocalizableStrings.HelpForMacros)
        TextLogAddEntry("Chat", SystemData.ChatLogFilters.SAY, StringToWString("/script PotionBar.Use(\"" .. PotionBar.Type[PotionBar.Type.HEAL].Name .. "\")"))
        TextLogAddEntry("Chat", SystemData.ChatLogFilters.SAY, StringToWString("/script PotionBar.Use(\"" .. PotionBar.Type[PotionBar.Type.UNKNOWNS].Name .. " '" .. PotionBar.LocalizableStrings.HelpNameOfPotion .. "'\")"))
        TextLogAddEntry("Chat", SystemData.ChatLogFilters.SAY, L"")
    end
    return bUsedPotion
end

function PotionBar.Initialize()
    if PotionBar.Settings == nil then PotionBar.Defaults() end
    if PotionBar.Settings.Version ~= PotionBar.CurrentMajorVersion then PotionBar.Defaults() end

    local I18N = {}
    if SystemData.Settings.Language.active == SystemData.Settings.Language.GERMAN then
        I18N = PotionBar.German
    elseif SystemData.Settings.Language.active == SystemData.Settings.Language.FRENCH then
        I18N = PotionBar.French
    elseif SystemData.Settings.Language.active == SystemData.Settings.Language.SPANISH then
        I18N = PotionBar.Spanish
    elseif SystemData.Settings.Language.active == SystemData.Settings.Language.ITALIAN then
        I18N = PotionBar.Italian
    else
        -- SystemData.Settings.Language.active == SystemData.Settings.Language.ENGLISH
        -- Language Unknown or English, please excuse my arrogance
        I18N = PotionBar.English
    end

    -- I18N = PotionBar.English -- uncomment for screen shots

    if I18N ~= nil then
        for i = 1, #PotionBar.Priorities do
            if I18N.Priorities == nil then
                break
            end
            if I18N.Priorities[i] ~= nil then
                PotionBar.Priorities[i].Desc = I18N.Priorities[i].Desc
            end
        end
        for i = 1, #PotionBar.Build do
            if I18N.Build == nil then
                break
            end
            if I18N.Build[i] ~= nil then
                PotionBar.Build[i].Desc = I18N.Build[i].Desc
            end
        end
        for i = 1, #PotionBar.ActivatorModes do
            if I18N.ActivatorModes == nil then
                break
            end
            if I18N.ActivatorModes[i] ~= nil then
                PotionBar.ActivatorModes[i].Desc = I18N.ActivatorModes[i].Desc
            end
        end
        for i = 1, #PotionBar.Type do
            if I18N.Type == nil then
                break
            end
            if I18N.Type[i] ~= nil then
                PotionBar.Type[i].Desc = I18N.Type[i].Desc
            end
        end
        for i = 1, #PotionBar.StackCountInfoType do
            if I18N.StackCountInfoType == nil then
                break
            end
            if I18N.StackCountInfoType[i] ~= nil then
                PotionBar.StackCountInfoType[i].Desc = I18N.StackCountInfoType[i].Desc
            end
        end
        for key, value in pairs(PotionBar.LocalizableStrings) do
            if I18N.Strings == nil then
                break
            end
            if I18N.Strings[key] ~= nil then
                PotionBar.LocalizableStrings[key] = I18N.Strings[key]
            end
        end
    end

    CreateWindow("PotionBarFloatingActivator", false)
    CreateWindow("PotionBar", false)
    CreateWindow("PotionBarWindowConfig", false)

    if LibSlash ~= nil and LibSlash.RegisterSlashCmd ~= nil then
        if LibSlash.RegisterSlashCmd("PotionBar", function(args) PotionBar.LibSlashHandler(args) end) then
            PotionBar.LibSlashCommand = "PotionBar"
        end
    end

    WindowClearAnchors("PotionBarFloatingActivator")
    if PotionBar.Settings.lastAnchor ~= nil and PotionBar.Settings.lastAnchor.x ~= nil and PotionBar.Settings.lastAnchor.y ~= nil then
        WindowAddAnchor("PotionBarFloatingActivator", "topleft", "Root", "topleft", PotionBar.Settings.lastAnchor.x, PotionBar.Settings.lastAnchor.y)
    else
        WindowAddAnchor("PotionBarFloatingActivator", "center", "Root", "center", 0, 0)
    end

    RegisterEventHandler(SystemData.Events.PLAYER_INVENTORY_SLOT_UPDATED, "PotionBar.InventorySlotUpdated")
    RegisterEventHandler(SystemData.Events.PLAYER_MAX_HIT_POINTS_UPDATED, "PotionBar.InventorySlotUpdated")
    PotionBar.UpdateButtons(true)
end

function PotionBar.Shutdown()
    if LibSlash ~= nil and LibSlash.UnregisterSlashCmd ~= nil and PotionBar.LibSlashCommand ~= nil then
        LibSlash.UnregisterSlashCmd(PotionBar.LibSlashCommand)
    end
    PotionBar.LibSlashCommand = nil
    PotionBar.Name = {}
    PotionBar.Description = {}
    PotionBar.Potions = {}
    PotionBar.Inventory = {}
    PotionBarFloating.Buttons = {}

    local x, y = WindowGetOffsetFromParent("PotionBarFloatingActivator")
    local windowscale = WindowGetScale("PotionBarFloatingActivator") / InterfaceCore.GetScale()
    PotionBar.Settings.lastAnchor = {}
    PotionBar.Settings.lastAnchor.x = x * windowscale
    PotionBar.Settings.lastAnchor.y = y * windowscale

    DestroyWindow("PotionBarFloatingActivator")
    DestroyWindow("PotionBar")
    DestroyWindow("PotionBarWindowConfig")
end

function PotionBar.Show()
    WindowSetShowing("PotionBarButtons", true)
end

function PotionBar.Hide()
    WindowSetShowing("PotionBarButtons", false)
end

function PotionBar.InventorySlotUpdated(updatedSlots)
    PotionBar.UpdateButtons(true)
end

function PotionBar.UpdateButtons(bDoUpdateInventory)
    if bDoUpdateInventory == true then
        PotionBar.UpdatePotionInventory()
    end
    PotionBarFloating.Buttons = {}
    -- inventory is sorted, so we only need to take the first of it's potionBarType
    local alreadyAdded = {}
    for settingsIndex=1, #PotionBar.Settings.Buttons do
        if PotionBar.Settings.Buttons[settingsIndex].Use == true then
            local currentButtonType = PotionBar.Settings.Buttons[settingsIndex].Type
            local joinDifferentNamed = currentButtonType ~= PotionBar.Type.UNKNOWNS and not PotionBar.Settings.Buttons[settingsIndex].SplitName == true
            for inventoryindex = 1, #PotionBar.Inventory do
                local potion = PotionBar.Inventory[inventoryindex]
                if (currentButtonType == potion.potionBarType and alreadyAdded[potion.itemData.name] == nil)
                   or (currentButtonType == PotionBar.Type.SINGLES and potion.itemData.stackCount == 1) then
                    local countOfThatType = 0
                    local totalCooldownTime, cooldownTimeLeft = potion.totalCooldownTime, potion.cooldownTimeLeft
                    local isOnCooldown = totalCooldownTime ~= nil and cooldownTimeLeft ~= nil
                    local allAreOnCooldown = isOnCooldown
                    for _, otherpotion in ipairs(PotionBar.Inventory) do
                        local typematches = currentButtonType == otherpotion.potionBarType or currentButtonType == PotionBar.Type.SINGLES
                        local stacksizematches = currentButtonType ~= PotionBar.Type.SINGLES or otherpotion.itemData.stackCount == 1
                        if (not joinDifferentNamed and stacksizematches and otherpotion.itemData.name ~= nil and 0 == WStringsCompare(potion.itemData.name, otherpotion.itemData.name))
                           or (joinDifferentNamed and stacksizematches and typematches) then
                            countOfThatType = countOfThatType + otherpotion.itemData.stackCount
                            if allAreOnCooldown then
                                local totalCooldownTime, cooldownTimeLeft = otherpotion.totalCooldownTime, otherpotion.cooldownTimeLeft
                                allAreOnCooldown = totalCooldownTime ~= nil and cooldownTimeLeft ~= nil
                            end
                        end
                    end
                    potion.totalTypeCount = countOfThatType
                    if not isOnCooldown or (isOnCooldown and allAreOnCooldown) then
                        PotionBarFloating.AddButton(potion)
                        if currentButtonType ~= PotionBar.Type.SINGLES then
                            alreadyAdded[potion.itemData.name] = potion.slotNum
                        end
                        if joinDifferentNamed then
                            break
                        end
                    end
                end
            end
        end
    end
    PotionBarFloating.ReflowButtons()
end

function PotionBar.CalcPowerByDuration(potionBarType, potion)
    if potion.value == nil or potion.value == 0 then return 0 end
    if potion.duration == nil or potion.duration == 0 then return potion.value end
    if potionBarType == PotionBar.Type.SHIELD then
        return potion.duration / potion.value
    end
    if potionBarType == PotionBar.Type.REGEN
       or potionBarType == PotionBar.Type.DOT
       or potionBarType == PotionBar.Type.AOEDOT
       or potionBarType == PotionBar.Type.FIREBREATH
    then
        return potion.value / potion.duration
    end
    return potion.value
end

function PotionBar.DurationPrecalculatedIntoPower(potionBarType)
    return potionBarType == PotionBar.Type.SHIELD
           or potionBarType == PotionBar.Type.REGEN
           or potionBarType == PotionBar.Type.DOT
           or potionBarType == PotionBar.Type.AOEDOT
           or potionBarType == PotionBar.Type.FIREBREATH
end

-- comparision function for quicksort
function PotionBar.IsBackPackItemLessThan(leftItem, rightItem)
    if leftItem.potionBarType ~= rightItem.potionBarType then
        return leftItem.buttonPosition < rightItem.buttonPosition
    end

    local itemtype = leftItem.potionBarType
    
    if itemtype == PotionBar.Type.UNKNOWNS then
        local strcmpresult = WStringsCompare(leftItem.name, rightItem.name)
        if strcmpresult ~= 0 then
            return leftItem.name < rightItem.name
        end
    end

    local preference = leftItem.preference

    if preference == PotionBar.Priorities.BigStack then
        if leftItem.itemData.stackCount == rightItem.itemData.stackCount then
            return leftItem.slotNum < rightItem.slotNum
        end
        return leftItem.itemData.stackCount > rightItem.itemData.stackCount
    end

    if preference == PotionBar.Priorities.LessStack then
        if leftItem.itemData.stackCount == rightItem.itemData.stackCount then
            return leftItem.slotNum < rightItem.slotNum
        end
        return leftItem.itemData.stackCount < rightItem.itemData.stackCount
    end

    local leftPower = PotionBar.CalcPowerByDuration(leftItem.potionBarType, leftItem)
    local rightPower = PotionBar.CalcPowerByDuration(rightItem.potionBarType, rightItem)
    local durationMatters = leftItem.duration ~= nil and rightItem.duration ~= nil and leftPower == rightPower and not PotionBar.DurationPrecalculatedIntoPower(itemtype)

    if preference == PotionBar.Priorities.Weakest then
        if leftPower < rightPower then
            return true
        end
        if durationMatters and leftItem.duration < rightItem.duration then
            return true
        end
    end

    if preference == PotionBar.Priorities.Strongest then
        if leftPower > rightPower then
            return true
        end
        if durationMatters and leftItem.duration > rightItem.duration then
            return true
        end
    end

    if leftPower == rightPower and (not durationMatters or leftItem.duration == rightItem.duration) then
        if leftItem.itemData.stackCount < rightItem.itemData.stackCount then
            return true
        end
        if leftItem.itemData.stackCount == rightItem.itemData.stackCount then
            return leftItem.slotNum < rightItem.slotNum
        end
    end

    return false
end

-- from http://code.google.com/p/luainterface/source/browse/trunk/lua-5.1.2/test/sort.lua?spec=svn2&r=2
function PotionBar.quicksort(x, l, u)
    if l >= u then return end
    local m = math.random(u - (l - 1)) + l - 1
    x[l], x[m] = x[m], x[l]
    local t = x[l]
    m = l
    local i = l + 1
    while i <= u do
        if PotionBar.IsBackPackItemLessThan(x[i], t) then
            m = m + 1
            x[m], x[i] = x[i], x[m]
        end
        i = i + 1
    end
    x[l], x[m] = x[m], x[l]
    PotionBar.quicksort(x, l, m-1)
    PotionBar.quicksort(x, m+1, u)
end

-- update the cool down timers
-- if we set PotionBar.Inventory.needsUIRefresh to true then PotionBarFloating.RefreshButtons will update the buttons on OnUpdate-event
local refreshTimer = 0
local refreshDelay = 1
function PotionBar.UpdateCooldowns(timeElapsed)
    if not timeElapsed then return end
    if PotionBar.Inventory == nil or PotionBar.Inventory.countOfPotionsWithCooldown == nil or PotionBar.Inventory.countOfPotionsWithCooldown  <= 0 then return end

    refreshTimer = refreshTimer + timeElapsed

    for _, potion in ipairs(PotionBar.Inventory) do
        if potion ~= nil and potion.cooldownTimeLeft ~= nil and potion.totalCooldownTime ~= nil then
            potion.cooldownTimeLeft = potion.cooldownTimeLeft - timeElapsed
            if potion.cooldownTimeLeft <= 0 then
                potion.cooldownTimeLeft = nil
                potion.totalCooldownTime = nil
                PotionBar.Inventory.countOfPotionsWithCooldown = PotionBar.Inventory.countOfPotionsWithCooldown - 1
                PotionBar.Inventory.needsUIRefresh = true
            end
        end
    end

    PotionBar.Inventory.needsUIRefresh = (PotionBar.Inventory.needsUIRefresh
                                          or PotionBar.Inventory.countOfPotionsWithCooldown == 0
                                          or refreshTimer >= refreshDelay)

    if PotionBar.Inventory.needsUIRefresh then
        refreshTimer = 0
    end
end

function PotionBar.UpdatePotionInventory()
    PotionBar.Inventory = {}
    local preferences = {}
    local buttonpositions = {}
    for index, button in ipairs(PotionBar.Settings.Buttons) do
        preferences[button.Type] = button.Preference
        buttonpositions[button.Type] = index
    end
    PotionBar.Inventory.countOfPotionsWithCooldown = 0
    PotionBar.Inventory.needsUIRefresh = true
    for slotNum, itemData in pairs(DataUtils.GetItems()) do
        if itemData ~= nil and itemData.name ~= nil
           and itemData.type ~= nil and itemData.type == GameData.ItemTypes.POTION
           and itemData.bonus ~= nil and #itemData.bonus >= 1 and itemData.bonus[1].type == 3
           and (itemData.level == nil or itemData.level < (GameData.Player.battleLevel + 1))
        then
            local potion = {}
            potion.slotNum = slotNum
            potion.itemData = itemData
            potion.cooldownTimeLeft = nil
            potion.totalCooldownTime = nil
            for _, bonusData in ipairs(itemData.bonus) do
                if bonusData.type == GameDefs.ITEMBONUS_USE then
                    if bonusData.cooldownTimeLeft and bonusData.cooldownTimeLeft > 0 and bonusData.totalCooldownTime and bonusData.totalCooldownTime > 0 then
                        potion.cooldownTimeLeft = bonusData.cooldownTimeLeft
                        potion.totalCooldownTime = bonusData.totalCooldownTime
                        PotionBar.Inventory.countOfPotionsWithCooldown = PotionBar.Inventory.countOfPotionsWithCooldown + 1
                    end
                    break
                end
            end
            potion.value, potion.duration, potion.potionBarType = PotionBar.getValues(itemData.bonus[1].reference, itemData.iLevel, itemData.name)
            if potion.potionBarType == 0 or potion.potionBarType == nil then
                potion.potionBarType = PotionBar.Type.UNKNOWNS
            end
            potion.preference = preferences[potion.potionBarType]
            potion.buttonPosition = buttonpositions[potion.potionBarType]
            PotionBar.Inventory[#PotionBar.Inventory + 1] = potion
        end
    end
    -- sort inventory
    PotionBar.quicksort(PotionBar.Inventory, 1, #PotionBar.Inventory)
end

-- for debugging purposes, and for those who want to extend the support for other languages
function PotionBar.ListUnknowns()
    TextLogAddEntry("Chat", SystemData.ChatLogFilters.SAY, L"PotionBars list of unknown potions:")
    local count = 0
    for _, itemData in pairs(DataUtils.GetItems()) do
        if itemData ~= nil and itemData.name ~= nil
           and itemData.type ~= nil and itemData.type == GameData.ItemTypes.POTION
           and itemData.bonus ~= nil and #itemData.bonus >= 1 and itemData.bonus[1].type == 3
           and (itemData.level == nil or itemData.level < (GameData.Player.battleLevel + 1))
        then
            local value, duration, potionBarType = PotionBar.getValues(itemData.bonus[1].reference, itemData.iLevel, itemData.name)
            if potionBarType == 0 or potionBarType == nil then
                potionBarType = PotionBar.Type.UNKNOWNS
            end
            if potionBarType == PotionBar.Type.UNKNOWNS then
                TextLogAddEntry("Chat", SystemData.ChatLogFilters.SAY, itemData.name)
                count = count + 1
            end
        end
    end
    if count == 0 then
        TextLogAddEntry("Chat", SystemData.ChatLogFilters.SAY, L"Your inventory has no unkown potions.")
    end
end
