if not PotionBar then PotionBar = {} end
if not PotionBarData then PotionBarData = {} end
if not PotionBarSettings then PotionBarSettings = {} end

PotionBar.CurrentMajorVersion = 6
PotionBar.CurrentMinorVersion = 4

PotionBar.LibSlashCommand = nil

PotionBar.Type = {}
PotionBar.Type =
{
    AP = 1,
    HEAL = 2,
    REGEN = 3,
    SHIELD = 4,
    STRENGTH = 5,
    INTELLIGENCE = 6,
    WILLPOWER = 7,
    BALLISTIC = 8,
    ARMOR = 9,
    TOUGHNESS = 10,
    THORNS = 11,
    SPIRIT = 12,
    ELEMENTAL = 13,
    CORPOREAL = 14,
    DOT = 15,
    AOEDOT = 16,
    FIREBREATH = 17,
    SNARE = 18,

    INSPIRATIONALWINDS = 19,
    SAVAGEVIGOR = 20,
    UNFETTEREDZEAL = 21,
    WARBLOOD = 22,
    WARDEMISE = 23,
    WARFERVOR = 24,
    WARGENIUS = 25,
    WARHUNGER = 26,
    WARMERCY = 27,
    ETERNALHUNT = 28,
    INEVITABLETEMPEST = 29,
    TOLLINGBELL = 30,

    NEPENTHEANTONIC = 31,

    UNKNOWNS = 32,

    SINGLES = 33,

    [1] = { Name = "AP", Desc = L"AP Potions" },
    [2] = { Name = "HEAL", Desc = L"Heal Potions" },
    [3] = { Name = "REGEN", Desc = L"Regen Potions"},
    [4] = { Name = "SHIELD", Desc = L"Damage Shield"},
    [5] = { Name = "STRENGTH", Desc = L"Strength" },
    [6] = { Name = "INTELLIGENCE", Desc = L"Intelligence" },
    [7] = { Name = "WILLPOWER", Desc = L"Willpower" },
    [8] = { Name = "BALLISTIC", Desc = L"Ballistic" },
    [9] = { Name = "ARMOR", Desc = L"Armor" },
    [10] = { Name = "TOUGHNESS", Desc = L"Toughness" },
    [11] = { Name = "THORNS", Desc = L"Thorns" },
    [12] = { Name = "SPIRIT", Desc = L"Spiritual" },
    [13] = { Name = "ELEMENTAL", Desc = L"Elemental" },
    [14] = { Name = "CORPOREAL", Desc = L"Corporeal" },
    [15] = { Name = "DOT", Desc = L"Burning" },
    [16] = { Name = "AOEDOT", Desc = L"Explosive" },
    [17] = { Name = "FIREBREATH", Desc = L"Firebreath" },
    [18] = { Name = "SNARE", Desc = L"Snaring" },
    [19] = { Name = "INSPIRATIONALWINDS", Desc = L"Willpower + Healing Power" }, -- Liniment: Inspirational Winds
    [20] = { Name = "SAVAGEVIGOR", Desc = L"Toughness + Melee Crit" }, -- Liniment: Savage Vigor
    [21] = { Name = "UNFETTEREDZEAL", Desc = L"Strength + Healing Power" }, -- Liniment: Unfettered Zeal
    [22] = { Name = "WARBLOOD", Desc = L"Wounds + Melee Crit" }, -- Liniment: War Blood
    [23] = { Name = "WARDEMISE", Desc = L"Wounds + Melee Power" }, -- Liniment: War Demise
    [24] = { Name = "WARFERVOR", Desc = L"Wounds + Ranged Crit" }, -- Liniment: War Fervor
    [25] = { Name = "WARGENIUS", Desc = L"Wounds + Magic Crit" }, -- Liniment: War Genius
    [26] = { Name = "WARHUNGER", Desc = L"Wounds + Strength" }, -- Liniment: War Hunger
    [27] = { Name = "WARMERCY", Desc = L"Wounds + Healing Power" }, -- Liniment: War Mercy
    [28] = { Name = "ETERNALHUNT", Desc = L"Ballistic + Ranged Crit" }, -- Liniment: Eternal Hunt
    [29] = { Name = "INEVITABLETEMPEST", Desc = L"Strength + Melee Power" }, -- Liniment: Inevitable Tempest
    [30] = { Name = "TOLLINGBELL", Desc = L"Intelligence + Magic Crit" }, -- Liniment: Tolling Bell
    [31] = { Name = "NEPENTHEANTONIC", Desc = L"Nepenthean Tonic" },
    [32] = { Name = "UNKNOWNS", Desc = L"All other" },
    [33] = { Name = "SINGLES", Desc = L"Singles" },
}

PotionBar.Priorities = {}
PotionBar.Priorities =
{
    BigStack = 1,
    LessStack = 2,
    Weakest = 3,
    Strongest = 4,

    [1] = { Desc = L"Biggest stack" },
    [2] = { Desc = L"Smallest stack" },
    [3] = { Desc = L"Weakest potion" },
    [4] = { Desc = L"Strongest potion" },
}

PotionBar.Build = {}
PotionBar.Build =
{
    Right = 1,
    Left = 2,
    Up = 3,
    Down = 4,

    [1] = { Desc = L"Right" },
    [2] = { Desc = L"Left" },
    [3] = { Desc = L"Up" },
    [4] = { Desc = L"Down" },
}

PotionBar.StackCountInfoType =
{
    Hide = 1,
    Single = 2,
    Total = 3,

    [1] = { Desc = L"Don't show stackcount" },
    [2] = { Desc = L"Show stack count" },
    [3] = { Desc = L"Show total count" },
}

PotionBar.ActivatorModes = 
{
    LeftOrUpper = 1,
    RightOrBottom = 2,
    Hide = 3,

    [1] = { Desc = L"Show activator" },
    [2] = { Desc = L"Other side" },
    [3] = { Desc = L"Hide activator" },
}

PotionBar.LocalizableStrings = {}
PotionBar.LocalizableStrings =
{
    Config = L"Configuration...",
    FloatHint1 = L"Left click and drag to move.",
    FloatHint2 = L"Right click for options.",

    TitleBarText = L"PotionBar Config Window",
    RightPaneTitle = L"Build Order and Priority",
    LeftTopPaneTitle = L"Bar Settings",
    BuildLabel = L"Build Direction",
    AutohideLabel = L"Autohide",
    ScaleLabel = L"Scale",
    OpacityLabel = L"Opacity",
    OkButton = L"Ok",
    ResetButton = L"Defaults",
    AboutButton = L"About...",
    InfoTopRight = L"Top Right Count",
    InfoBottomRight = L"Bottom Right Count",
    Show1Label = L"Show count of 1",
    ShowLastLabel = L"Show last stack",
    DontSplitNameLabel = L"Stack all variants",
    ActivatorLabel = L"Floating activator position",

    BuildHint = L"Choose the direction of the bar.",
    AutoHideHint = L"Check this box to make the bar automatically hide.",
    MoveUpHint = L"Click here to move this item upwards in creation order.",
    MoveDownHint = L"Click here to move this item downwards in creation order.",
    UseHint = L"Check this box to show potions of this kind in PotionBar.",
    MethodHint = L"Choose which potions of this type PotionBar should give priority to.",
    InfoTopRightHint = L"Choose the count you want to see in the top right corner of the potion button.",
    InfoBottomRightHint = L"Choose the count you want to see in the bottom right corner of the potion button.",
    Show1Hint = L"Check this box to show stack count even it is 1.",
    ShowLastHint = L"Check this box to show the total stack count, even it is the last stack.",
    DontSplitNameHint = L"Check this box if you want all potions of this type as one button",
    ActivatorHint = L"Choose the position of the small round button of PotionBar",

    HelpTitle = L"PotionBar knows following commands:",
    HelpForUnknown = L"Use this command to drink a specific potion:",
    HelpNameOfPotion = "Name of Potion",
    HelpForMacros = L"If you want to use them from within macros, your macro must look like this:",

    MacroPotionFound1 = "PotionBar is using ",
    MacroPotionFound2 = " out of inventory slot ",
    MacroPotionFound3 = ".",

    MacroNoPotionFound1 = L"PotionBar 'use' command error",
    MacroNoPotionFound2 = "Could not find: ",
    MacroNoPotionFound3 = "",

    MacroPotionOnCoolDown1 = "PotionBar could not use '",
    MacroPotionOnCoolDown2 = "' because it is still on cool down.",
}

function PotionBar.Defaults()
    PotionBar.Settings = {}
    PotionBar.Settings.Buttons = {}
    PotionBar.Settings.Autohide = false
    PotionBar.Settings.Build = PotionBar.Build.Right
    PotionBar.Settings.Opacity = 1
    PotionBar.Settings.Scale = .5
    PotionBar.Settings.TopRight = PotionBar.StackCountInfoType.Total
    PotionBar.Settings.BottomRight = PotionBar.StackCountInfoType.Hide
    PotionBar.Settings.ShowStackSizeEvenIf1 = false
    PotionBar.Settings.ShowStackSizeEvenIfLast = false
    PotionBar.Settings.Activator = PotionBar.ActivatorModes.LeftOrUpper

    for potionBarType = 1, #PotionBar.Type do
        PotionBar.Settings.Buttons[potionBarType] = {}
        PotionBar.Settings.Buttons[potionBarType].Preference = PotionBar.Priorities.Strongest
        PotionBar.Settings.Buttons[potionBarType].Use = true
        PotionBar.Settings.Buttons[potionBarType].Type = potionBarType
        PotionBar.Settings.Buttons[potionBarType].SplitName = false
    end

    PotionBar.Settings.Buttons[PotionBar.Type.INSPIRATIONALWINDS].Preference = PotionBar.Priorities.LessStack
    PotionBar.Settings.Buttons[PotionBar.Type.SAVAGEVIGOR].Preference = PotionBar.Priorities.LessStack
    PotionBar.Settings.Buttons[PotionBar.Type.UNFETTEREDZEAL].Preference = PotionBar.Priorities.LessStack
    PotionBar.Settings.Buttons[PotionBar.Type.WARBLOOD].Preference = PotionBar.Priorities.LessStack
    PotionBar.Settings.Buttons[PotionBar.Type.WARDEMISE].Preference = PotionBar.Priorities.LessStack
    PotionBar.Settings.Buttons[PotionBar.Type.WARFERVOR].Preference = PotionBar.Priorities.LessStack
    PotionBar.Settings.Buttons[PotionBar.Type.WARGENIUS].Preference = PotionBar.Priorities.LessStack
    PotionBar.Settings.Buttons[PotionBar.Type.WARHUNGER].Preference = PotionBar.Priorities.LessStack
    PotionBar.Settings.Buttons[PotionBar.Type.WARMERCY].Preference = PotionBar.Priorities.LessStack
    PotionBar.Settings.Buttons[PotionBar.Type.ETERNALHUNT].Preference = PotionBar.Priorities.LessStack
    PotionBar.Settings.Buttons[PotionBar.Type.INEVITABLETEMPEST].Preference = PotionBar.Priorities.LessStack
    PotionBar.Settings.Buttons[PotionBar.Type.TOLLINGBELL].Preference = PotionBar.Priorities.LessStack
    PotionBar.Settings.Buttons[PotionBar.Type.NEPENTHEANTONIC].Preference = PotionBar.Priorities.LessStack
    PotionBar.Settings.Buttons[PotionBar.Type.UNKNOWNS].Preference = PotionBar.Priorities.LessStack
    PotionBar.Settings.Buttons[PotionBar.Type.UNKNOWNS].SplitName = true
    PotionBar.Settings.Buttons[PotionBar.Type.SINGLES].Use = false
    PotionBar.Settings.Buttons[PotionBar.Type.SINGLES].SplitName = true

    PotionBar.Settings.Version = PotionBar.CurrentMajorVersion
end
