local version 		= 1.0
Info_DeathBlow = {}
Info_DeathBlow.groupMembers = {}
local PlayerName = wstring.sub(GameData.Player.name,1,-3)
local PlayerRealm = GameData.Player.realm


function Info_DeathBlow.OnInitialize()

if not InfoScroller.Settings.Deathblow then InfoScroller.Settings.Deathblow = true end
if not InfoScroller.Settings.Deathblow_Self then InfoScroller.Settings.Deathblow_Self = true end
if not InfoScroller.Settings.Deathblow_Party then InfoScroller.Settings.Deathblow_Party = true end

--DeathBlow Option tab
	local DeathBlow = {name="+DeathBlow",[1]={name="checkbox",title="Show DeathBlow",save="Deathblow"},
									[2]={name="checkbox",title="Show Your Kills/death",save="Deathblow_Self"},
									[3]={name="checkbox",title="Show Your Kills/death",save="Deathblow_Party"}
		}
	table.insert(InfoScroller.Register,DeathBlow)


	RegisterEventHandler(SystemData.Events.GROUP_UPDATED			, "Info_DeathBlow.GROUP_UPDATED");
    RegisterEventHandler(SystemData.Events.GROUP_STATUS_UPDATED		, "Info_DeathBlow.GROUP_UPDATED");
	RegisterEventHandler(SystemData.Events.GROUP_LEAVE           	, "Info_DeathBlow.GROUP_UPDATED");	

	RegisterEventHandler(SystemData.Events.SCENARIO_GROUP_UPDATED, "Info_DeathBlow.GROUP_UPDATED")
	RegisterEventHandler(SystemData.Events.SCENARIO_PLAYERS_LIST_GROUPS_UPDATED, "Info_DeathBlow.GROUP_UPDATED")
	RegisterEventHandler(SystemData.Events.SCENARIO_PLAYERS_LIST_UPDATED, "Info_DeathBlow.GROUP_UPDATED")
	RegisterEventHandler(SystemData.Events.SCENARIO_BEGIN, "Info_DeathBlow.GROUP_UPDATED")
	RegisterEventHandler(SystemData.Events.SCENARIO_GROUP_JOIN, "Info_DeathBlow.GROUP_UPDATED")
	RegisterEventHandler(SystemData.Events.SCENARIO_GROUP_LEAVE, "Info_DeathBlow.GROUP_UPDATED")
	RegisterEventHandler(SystemData.Events.SCENARIO_STARTING_SCENARIO_UPDATED, "Info_DeathBlow.GROUP_UPDATED")
	RegisterEventHandler(TextLogGetUpdateEventId("Combat"), "Info_DeathBlow.OnCombatLogUpdated")
	
	PlayerName = wstring.sub(GameData.Player.name,1,-3)
	PlayerRealm = GameData.Player.realm
end

function Info_DeathBlow.OnShutdown()	
	UnregisterEventHandler(TextLogGetUpdateEventId("Combat"), "Info_DeathBlow.OnCombatLogUpdated")
end

function Info_DeathBlow.GROUP_UPDATED()
	local groupMembers = {}

    local partyData = PartyUtils.GetPartyData();
	if (not partyData) then return end

	for index, partyMember in pairs (partyData) do	
		local name = Info_DeathBlow.FixString(towstring(partyMember.name))
		if name and (name ~= L"") then
			groupMembers[name] = true
		end
	end

	groupMembers[PlayerName] = true
	Info_DeathBlow.groupMembers = groupMembers
	
end


function Info_DeathBlow.OnCombatLogUpdated(updateType, filterType) 
	if( updateType == SystemData.TextLogUpdate.ADDED ) then 
	local currenttime, filterId, text = TextLogGetEntry( "Combat", TextLogGetNumEntries("Combat") - 1 )

		if ( filterType == SystemData.ChatLogFilters.RVR_KILLS_ORDER or filterType == SystemData.ChatLogFilters.RVR_KILLS_DESTRUCTION ) and (InfoScroller.Settings.Deathblow == true) then
			local Victim, Verb, Killer, Weapon, Location = text:match(L"([%a]+) has been ([%a]+) by ([%a]+)'s (.+) in (.+).")
			local IndexType = 0
			local EnemyName = L""
			if tostring(Killer) == tostring(PlayerName) and InfoScroller.Settings.Deathblow_Self == true then
				IndexType = 1 -- is a kill
				EnemyName = Victim
				PlaySound(215)
			elseif tostring(Victim) == tostring(PlayerName) and InfoScroller.Settings.Deathblow_Self == true then 
				IndexType = 2 -- is a death
				EnemyName = Killer
				PlaySound(218)
			end
			
			if Info_DeathBlow.groupMembers[Killer] and Killer ~= PlayerName and InfoScroller.Settings.Deathblow_Party == true  then
				IndexType = 3 -- someone in my group died			
			
			elseif Info_DeathBlow.groupMembers[Victim] and Victim ~= PlayerName and InfoScroller.Settings.Deathblow_Party == true then
				IndexType = 4 -- someone in my group kills		
			end
							
			if IndexType ~= 0 then				
				Info_DeathBlow.ShowDBTicker(IndexType,EnemyName,Victim, Verb, Killer, Weapon, Location) --calls the Alert ticker				
			end
		end
	
	end
end

function Info_DeathBlow.ShowDBTicker(IndexType, EnemyName,Victim, Verb, Killer, Weapon, Location)
local Color = InfoScroller.Color[PlayerRealm]
local InvColor = InfoScroller.InvColor[PlayerRealm]

local AlertColor = InfoScroller.Color[PlayerRealm]
local InvAlertColor = InfoScroller.InvColor[PlayerRealm]

	if IndexType == 1 or IndexType == 2 then
		if IndexType == 1 then --Own kill
		
		local Alignment = {left={"bottomleft",true,145},center={"bottom",false,290},right={"bottomright",false,145,}}				
		local BGAlignment = Alignment[InfoScroller.Settings.Alignment] --setting up dynamic background based on Ticket alignment; Anchor,mirror,width

			InfoScroller.TicketOnQue({
			BGColor={r=DefaultColor.YELLOW.r,g=DefaultColor.YELLOW.g,b=DefaultColor.YELLOW.b},
			Image={name="TestFlame", width=BGAlignment[3], height=52, alpha=0.8, scale=1, y=-2, mirror=BGAlignment[2], anchor=BGAlignment[1]},		--	background image of ticket
			[1]={text=L"DeathBlow:",color={r=255,g=150,b=25},font="font_clear_small_bold"},
			[2]={texture={name="EA_ScenarioSummary01_d5",slice="single-skull",width=28,height=32,scale=0.75,x=0,y=-3,align="right"},texture2={name="EA_ScenarioSummary01_d5",slice="single-skull",width=28,height=32,scale=0.75,x=2,y=-3,align="left"},text=L"      "..towstring(CreateHyperLink(L"PlayerName",L"You", {tonumber(DefaultColor.YELLOW.r),tonumber(DefaultColor.YELLOW.g),tonumber(DefaultColor.YELLOW.b)},{}))..L"  "..towstring(Verb)..L"  "..towstring(CreateHyperLink(L"EnemyName",towstring(EnemyName), InvColor,{}))..L"      ",color={r=255,g=255,b=255},font="font_clear_medium_bold"},			
			[3]={text=L"with "..towstring(CreateHyperLink(L"0",towstring(Weapon), {255,255,75},{})),color={r=255,g=255,b=255},font="font_clear_small_bold"},
			[4]={text=L"in "..towstring(CreateHyperLink(L"Location",towstring(Location), {175,175,175},{})),color={r=255,g=255,b=255},font="font_clear_small_bold"}		
		})
		
		
		
		elseif IndexType == 2 then --own death

			InfoScroller.TicketOnQue({
			BGColor={r=DefaultColor.ORANGE.r,g=DefaultColor.ORANGE.g,b=DefaultColor.ORANGE.b},
			Image={name="EA_ScenarioSummary01_d5",slice="single-skull",width=28,height=32,scale=1.3,alpha=0.5},			
			[1]={text=L"DeathBlow:",color={r=255,g=150,b=25},font="font_clear_small_bold"},							
			[2]={texture={name="EA_ScenarioSummary01_d5",slice="single-skull",width=28,height=32,scale=0.75,x=0,y=-3,align="right"},texture2={name="EA_ScenarioSummary01_d5",slice="single-skull",width=28,height=32,scale=0.75,x=2,y=-3,align="left"},text=L"      "..towstring(CreateHyperLink(L"EnemyName",towstring(EnemyName), InvColor,{}))..L"  "..towstring(Verb)..L"  "..towstring(CreateHyperLink(L"PlayerName",L"You", {tonumber(DefaultColor.YELLOW.r),tonumber(DefaultColor.YELLOW.g),tonumber(DefaultColor.YELLOW.b)},{}))..L"      ",color={r=255,g=255,b=255},font="font_clear_medium_bold"},
			[3]={text=L"with "..towstring(CreateHyperLink(L"0",towstring(Weapon), {255,255,75},{})),color={r=255,g=255,b=255},font="font_clear_small_bold"},
			[4]={text=L"in "..towstring(CreateHyperLink(L"Location",towstring(Location), {175,175,175},{})),color={r=255,g=255,b=255},font="font_clear_small_bold"}
			})			
		
		end
	end

	if IndexType == 3 or IndexType == 4 then
		if IndexType == 3 then --friendly kill

			InfoScroller.TicketOnQue({
			BGColor={r=Color[1],g=Color[2],b=Color[3]},
			Image={name="map_markers01",slice="RvR-Hotspot",width=28,height=32,scale=1.3,alpha=0.5},
			[1]={text=L"DeathBlow:",color={r=255,g=255,b=255},font="font_clear_small_bold"},			
			[2]={texture={name="map_markers01",slice="RvR-Hotspot",width=30,height=32,scale=0.9,x=0,y=-4,align="right"},texture2={name="map_markers01",slice="RvR-Hotspot",width=30,height=32,scale=0.9,x=2,y=-4,align="left"},text=L"      "..towstring(CreateHyperLink(L"KillerName",towstring(Killer), Color,{}))..L"  "..towstring(Verb)..L"  "..towstring(CreateHyperLink(L"VictimName",towstring(Victim), InvColor,{}))..L"       ",color={r=255,g=255,b=255},font="font_clear_medium_bold"}			
			})	
			
		elseif IndexType == 4 then-- enemy kill

			InfoScroller.TicketOnQue({
			BGColor={r=InvColor[1],g=InvColor[2],b=InvColor[3]},
			Image={name="EA_ScenarioSummary01_d5",slice="single-skull",width=28,height=32,scale=1.3,alpha=0.5},			
			[1]={text=L"DeathBlow:",color={r=255,g=255,b=255},font="font_clear_small_bold"},			
			[2]={texture={name="EA_ScenarioSummary01_d5",slice="single-skull",width=28,height=32,scale=0.75,x=0,y=-3,align="right"},texture2={name="EA_ScenarioSummary01_d5",slice="single-skull",width=28,height=32,scale=0.75,x=2,y=-3,align="left"},text=L"      "..towstring(CreateHyperLink(L"KillerName",towstring(Killer), InvColor,{}))..L"  "..towstring(Verb)..L"  "..towstring(CreateHyperLink(L"VictimName",towstring(Victim), Color,{}))..L"       ",color={r=255,g=255,b=255},font="font_clear_medium_bold"}			
			})			
		end
	end
return
end


function Info_DeathBlow.FixString(str)
	if (str == nil) then return nil end	
	local str = str	
	local pos = str:find (L"^", 1, true)
	if (pos) then str = str:sub (1, pos - 1) end	
	pos = str:find (L" ", 1, true)
	if (pos) then str = str:sub (1, pos - 1) end	
	return str
end
	