<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
    <UiMod name="Info_DeathBlow" version="1.0" date="11/12/2020">
        <Author name="Sullemunk" />
        <Description text="Info_DeathBlow, DeathBlows for Yourself and Players on InfoScroller" />
         <Dependencies>
            <Dependency name="InfoScroller" optional="false" />
			<Dependency name="EA_ChatWindow" />		
		</Dependencies>
        <Files>
				<File name="Info_DeathBlow.lua" />
        </Files>
        <OnInitialize>
            <CallFunction name="Info_DeathBlow.OnInitialize" />
        </OnInitialize>
		
		<SavedVariables>		
		</SavedVariables>
        <OnUpdate>
    	 </OnUpdate>	
        <OnShutdown>
			<CallFunction name="Info_DeathBlow.OnShutdown" />
		</OnShutdown>
    </UiMod>
</ModuleFile>