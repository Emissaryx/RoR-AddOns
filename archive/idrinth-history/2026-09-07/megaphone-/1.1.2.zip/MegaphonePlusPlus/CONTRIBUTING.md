## How to contribute

#### **Did you find a bug?**

* **Ensure the bug was not already reported** by searching on GitHub under [Issues](https://github.com/timneill/megaphoneplusplus/issues).

* If you're unable to find an open issue addressing the problem, [open a new one](https://github.com/timneill/megaphoneplusplus/issues/new). Be sure to include a **title and clear description**, as much relevant information as possible, including what happened and what you were doing when it happened. A screenshot also helps.

#### **Did you write a patch that fixes a bug?**

* Open a new GitHub pull request with the patch.

* Ensure the PR description clearly describes the problem and solution. Include the relevant issue number if applicable.

#### **Did you fix whitespace, format code, or make a purely cosmetic patch?**

Changes that are cosmetic in nature and do not add anything substantial to the stability, functionality, or will not be accepted.
