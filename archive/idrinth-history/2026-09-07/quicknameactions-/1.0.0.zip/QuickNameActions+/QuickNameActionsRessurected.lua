local firstLoad = true
local oldEA_ChatWindowOnPlayerLinkLButtonUp = nil
local oldEA_ChatWindowOnPlayerLinkRButtonUp = nil

if not QuickNameActionsRessurected then QuickNameActionsRessurected = {} end


function QuickNameActionsRessurected.Initialize()
  RegisterEventHandler(SystemData.Events.LOADING_END, "QuickNameActionsRessurected.OnLoad")
  RegisterEventHandler(SystemData.Events.RELOAD_INTERFACE, "QuickNameActionsRessurected.OnLoad")
end

function QuickNameActionsRessurected.OnLoad()
  if firstLoad == true then
    firstLoad = false
    QuickNameActionsRessurected.setHook()
  end
end


function QuickNameActionsRessurected.setHook()
  if oldEA_ChatWindowOnPlayerLinkLButtonUp == nil then
    oldEA_ChatWindowOnPlayerLinkLButtonUp = EA_ChatWindow.OnPlayerLinkLButtonUp
    oldEA_ChatWindowOnPlayerLinkRButtonUp = EA_ChatWindow.OnPlayerLinkRButtonUp
    EA_ChatWindow.OnPlayerLinkLButtonUp = QuickNameActionsRessurected.newEA_ChatWindowOnPlayerLinkLButtonUp
    EA_ChatWindow.OnPlayerLinkRButtonUp = QuickNameActionsRessurected.newEA_ChatWindowOnPlayerLinkRButtonUp
    --p("HOOK SET")
  end
end

function QuickNameActionsRessurected.newEA_ChatWindowOnPlayerLinkLButtonUp(playerName, flags, x, y )
  local shiftPressed = (flags == SystemData.ButtonFlags.SHIFT)
  local controlPressed = (flags == SystemData.ButtonFlags.CONTROL)
  local altPressed = (flags == SystemData.ButtonFlags.ALT)
  if shiftPressed then
    --SendChatText( L"/who "..playerName, L"" )
    local tableSub = { - 1}
    QuickNameActionsRessurected.SocialSearcher(playerName)
    --p("test hook work")
  elseif controlPressed then
    SendChatText(L"/invite "..playerName, L"")
    --p("test invite work")
  elseif altPressed then
    SendChatText(L"/friend "..playerName, L"")
    --p("friend test")
  else
    oldEA_ChatWindowOnPlayerLinkLButtonUp(playerName, flags, x, y )
  end
end

function QuickNameActionsRessurected.newEA_ChatWindowOnPlayerLinkRButtonUp(playerName, flags, x, y, wndGroupId)
  local shiftPressed = (flags == SystemData.ButtonFlags.SHIFT)
  local controlPressed = (flags == SystemData.ButtonFlags.CONTROL)
  local altPressed = (flags == SystemData.ButtonFlags.ALT)
  if controlPressed then
    SendChatText(L"/join "..playerName, L"")
    --p("test join")
  elseif shiftPressed then
    SendChatText(L"/tell "..playerName..L" x", L"")
    --p("x tell")
  else
    oldEA_ChatWindowOnPlayerLinkRButtonUp(playerName, flags, x, y, wndGroupId)
  end
end


function QuickNameActionsRessurected.SocialSearcher(playerName)
  local tableSub = { - 1}
  return SendPlayerSearchRequest(L""..playerName, L"", L"", tableSub, 0, 40, false)
end
