<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">

    <UiMod name="QuickNameActions+" version="1.0" date="06/06/21">
    	<VersionSettings gameVersion="1.4.8" windowsVersion="1.0" savedVariablesVersion="1.0" />
     <Author name="xyeppp" />
        <Description text="QuickNameActions+" />
        <Dependencies>
        </Dependencies>

        <Files>
            <File name="QuickNameActionsRessurected.lua" />
          </Files>
        <OnInitialize>
            <CallFunction name="QuickNameActionsRessurected.Initialize" />
        </OnInitialize>
    </UiMod>
</ModuleFile>
