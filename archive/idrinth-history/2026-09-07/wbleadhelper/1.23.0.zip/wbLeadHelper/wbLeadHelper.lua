if not wbLeadHelper then wbLeadHelper = {} end

-- TODO: maybe add a moral build + dump button
-- TODO: Shortcuts for buttons, maybe

local activeTemplate = wbLeadHelper.Templates[1];
local towstring = towstring
local DoesWindowExist = DoesWindowExist
local table_insert = table.insert;
local wbLeadHelperWindowName = "wbLeadHelperWindow";
local showingAlternateTitle = false;
local inLoadingScreen = false;
local timerActive = 0;
local activeChatChannel = "";
local subMenuActive = false;
local zoneMenuActive = false;
local boMenuActive = false;
local lfmMenuActive = false;
local countdownMenuActive = false;
local clickedMainMenuMessageId = 0;
local tmpMessageActive = "";
local tmpColorActive = "";
local hookOnKeyEnter;
local chatHookActive = false;
local string_lower = string.lower;

wbLeadHelper.activeSettings = {};

local function Print(str)
	EA_ChatWindow.Print(towstring(str));
end

local function copySettingsTable(source)
	if type(source) ~= "table" then
		return source
	end

	local copy = {}
	for key, value in pairs(source) do
		copy[key] = copySettingsTable(value)
	end

	return copy
end

local function normalizeSettingsTable(settings)
    local defaults = wbLeadHelper.DefaultSettings

    if type(settings) ~= "table" then
        return copySettingsTable(defaults)
    end

    for key, value in pairs(defaults) do
        if settings[key] == nil then
            settings[key] = copySettingsTable(value)
        end
    end

    if type(settings.messages) ~= "table" then
        settings.messages = copySettingsTable(defaults.messages)
    end

    if type(settings.settingsVersion) ~= "number"
        or settings.settingsVersion < defaults.settingsVersion
    then
        settings.settingsVersion = defaults.settingsVersion
    end

    return settings
end

local function getSettingsMessagesCount(settings)
	if not settings or type(settings.messages) ~= "table" then
		return 0
	end

	return #settings.messages
end

local function settingsMessagesMatchDefaults(settings)
	if not settings or type(settings.messages) ~= "table" then
		return false
	end

	local savedMessages = settings.messages
	local defaultMessages = wbLeadHelper.DefaultSettings and wbLeadHelper.DefaultSettings.messages or {}

	if #savedMessages ~= #defaultMessages then
		return false
	end

	for i = 1, #defaultMessages do
		local saved = savedMessages[i]
		local default = defaultMessages[i]

		if type(saved) ~= "table" or type(default) ~= "table" then
			return false
		end

		local savedSubmenu = saved.submenu or "None"
		local defaultSubmenu = default.submenu or "None"
		local savedDisabled = saved.isNotEnabled and true or false
		local defaultDisabled = default.isNotEnabled and true or false
		local savedAnnouncement = saved.isAnnouncement and true or false
		local defaultAnnouncement = default.isAnnouncement and true or false

		if tostring(saved.label or "") ~= tostring(default.label or "")
			or tostring(saved.message or "") ~= tostring(default.message or "")
			or tostring(saved.type or "") ~= tostring(default.type or "")
			or tostring(savedSubmenu) ~= tostring(defaultSubmenu)
			or savedDisabled ~= defaultDisabled
			or savedAnnouncement ~= defaultAnnouncement
		then
			return false
		end
	end

	return true
end

function wbLeadHelper.GetSettingsDebugSummary()
	local settings = wbLeadHelper.GlobalSettings
	local effectiveSettings = settings or wbLeadHelper.activeSettings
	local messageCount = getSettingsMessagesCount(effectiveSettings)
	local matchesDefaults = settingsMessagesMatchDefaults(effectiveSettings)
	local source = wbLeadHelper.settingsLoadSource or "saved/custom"

	if not settings then
		source = "missing"
	elseif wbLeadHelper.settingsLoadSource then
		source = wbLeadHelper.settingsLoadSource
	elseif settings == wbLeadHelper.DefaultSettings then
		source = "default-fallback"
	elseif messageCount == 0 then
		source = "saved/no-messages"
	elseif matchesDefaults then
		source = "saved/default-like"
	end

	local version = "nil"
	if effectiveSettings and effectiveSettings.settingsVersion ~= nil then
		version = tostring(effectiveSettings.settingsVersion)
	end

	local resetNeeded = "no"
	if settings
		and (type(settings.settingsVersion) ~= "number"
		or settings.settingsVersion < wbLeadHelper.DefaultSettings.settingsVersion
		)
	then
		resetNeeded = "yes"
	end

	return "source=" .. source
		.. ", messages=" .. tostring(messageCount)
		.. ", defaultLike=" .. (matchesDefaults and "yes" or "no")
		.. ", settingsVersion=" .. version
		.. ", resetNeeded=" .. resetNeeded
end

function wbLeadHelper.PrintSettingsDebugSummary(context)
	local suffix = ""
	if context and context ~= "" then
		suffix = " [" .. tostring(context) .. "]"
	end

	Print("<LINK data=\"0\" text=\"[wbLeadHelper]\" color=\"180,220,255\"> Settings debug" .. suffix .. ": " .. wbLeadHelper.GetSettingsDebugSummary())
end

function wbLeadHelper.OnInitialize()

	-- Load account-wide settings. On the first run after this was introduced,
	-- seed them from the current character's old settings so existing configs are kept.
	local characterSettings = wbLeadHelper.Settings
	if type(wbLeadHelper.GlobalSettings) ~= "table" then
		if type(characterSettings) == "table" then
			wbLeadHelper.settingsLoadSource = "migrated/character"
			wbLeadHelper.GlobalSettings = normalizeSettingsTable(characterSettings)
		else
			wbLeadHelper.settingsLoadSource = "generated/defaults"
			wbLeadHelper.GlobalSettings = normalizeSettingsTable(nil)
		end
	else
		wbLeadHelper.settingsLoadSource = "saved/global"
		normalizeSettingsTable(wbLeadHelper.GlobalSettings)
	end

	-- Clear the legacy per-character value; all live configuration now uses GlobalSettings.
	wbLeadHelper.Settings = nil
	wbLeadHelper.setActiveSettings(wbLeadHelper.GlobalSettings)
	wbLeadHelper.PrintSettingsDebugSummary("init")

	hookOnKeyEnter = EA_ChatWindow.OnKeyEnter;
	EA_ChatWindow.OnKeyEnter = wbLeadHelper.OnKeyEnter;
	chatHookActive = false

	if (DoesWindowExist(wbLeadHelperWindowName) == false) then
		wbLeadHelper.createWbLeadHelperWindow();
	end
	
	RegisterEventHandler( SystemData.Events.LOADING_BEGIN, "wbLeadHelper.LOADING_START");
	RegisterEventHandler( SystemData.Events.LOADING_END, "wbLeadHelper.LOADING_END");
	
	if LibSlash then
		-- register LibSlash command "/wbLeadHelper" and tries "/wlh"
		LibSlash.RegisterSlashCmd("wbLeadHelper", function(args) wbLeadHelper.SlashCmd(args) end);
		if (not LibSlash.IsSlashCmdRegistered("wlh")) then
			LibSlash.RegisterSlashCmd("wlh", function(args) wbLeadHelper.SlashCmd(args) end);
		end
		if (not LibSlash.IsSlashCmdRegistered("an")) then
			LibSlash.RegisterSlashCmd("an", function(args) wbLeadHelper.AnnouncementSlashCmd(args) end);
		else
			Print("<LINK data=\"0\" text=\"[wbLeadHelper]\" color=\"255,170,70\"> Could not register /an because another addon already uses it.");
		end
		Print("<LINK data=\"0\" text=\"[wbLeadHelper]\" color=\"50,255,10\"> Addon initialized. Use /wlh or /wbLeadHelper to show options.");
	else
		Print("<LINK data=\"0\" text=\"[wbLeadHelper]\" color=\"50,255,10\"> Addon initialized.");
	end
	
end

function wbLeadHelper.OnShutdown()
	EA_ChatWindow.OnKeyEnter = hookOnKeyEnter;
	chatHookActive = false
end

function wbLeadHelper.LOADING_START()
	inLoadingScreen = true;
end

function wbLeadHelper.LOADING_END()
	inLoadingScreen = false;
end

function wbLeadHelper.buildAnnouncementCommand(message)
	message = wbLeadHelper.trim(tostring(message or ""));
	if message == "" then return nil end
	return "]readycheck abort " .. message .. ":14";
end

function wbLeadHelper.sendAnnouncement(message, previewOnlyWhileConfigOpen)
	local command = wbLeadHelper.buildAnnouncementCommand(message)
	if not command then return false end

	if previewOnlyWhileConfigOpen and WindowGetShowing(wbLeadHelperConfigWindow.name) then
		Print("<LINK data=\"0\" text=\"[wbLeadHelper]\" color=\"50,255,10\"> " .. command);
	else
		SendChatText(towstring(command), L"");
	end

	return true
end

function wbLeadHelper.AnnouncementSlashCmd(args)
	if not wbLeadHelper.sendAnnouncement(args, false) then
		Print("<LINK data=\"0\" text=\"[wbLeadHelper]\" color=\"50,255,10\"> Usage: /an <message>");
	end
end


function wbLeadHelper.SlashCmd(args)

	local command;
	local separator = string.find(args," ");
	
	if separator then
		command = string.sub(args, 0, separator - 1);
	else
		command = args;
	end
	

	if ( command == "show"or command == "s" or command == "toggle" or command == "t") then
		wbLeadHelper.toggleWbLeadHelperWindow();
	elseif ( command == "config" or command == "cfg" or command == "c") then
		wbLeadHelperConfigWindow.Show();
	else
		Print("<LINK data=\"0\" text=\"[wbLeadHelper]\" color=\"50,255,10\"> /wlh show - toggle the main window.");
		Print("<LINK data=\"0\" text=\"[wbLeadHelper]\" color=\"50,255,10\"> /wlh config - open the configuration window.");
		Print("<LINK data=\"0\" text=\"[wbLeadHelper]\" color=\"50,255,10\"> /an <message> - send an announcement.");
	end
	
end

function wbLeadHelper.createWbLeadHelperWindow()

	if (DoesWindowExist(wbLeadHelperWindowName) == false) then 
		CreateWindow(wbLeadHelperWindowName, false);
	end
	showingAlternateTitle = false;
		
	-- title label background
	WindowSetTintColor(wbLeadHelperWindowName .. "TitleBackground", 0, 0, 0);
	WindowSetAlpha(wbLeadHelperWindowName .. "TitleBackground", 0.55);

	WindowSetDimensions( wbLeadHelperWindowName .. "Title", activeTemplate.titleWidth, 30);
	WindowSetDimensions( wbLeadHelperWindowName .. "TitleLabel", activeTemplate.titleWidth, 30);

	ButtonSetText (wbLeadHelperWindowName .."CloseButton", L"X");
	ButtonSetText (wbLeadHelperWindowName .."ChatButton", L"CM");

	WindowSetScale( wbLeadHelperWindowName, wbLeadHelper.activeSettings.windowSize );

	wbLeadHelper.draw();
	
end

local TIME_DELAY2 = 1;
local timeLeft2 = 1;
local timerDelay = 5;
function wbLeadHelper.timerUpdate(elapsed)

	if (inLoadingScreen == true) then return end

	timeLeft2 = timeLeft2 - elapsed;
    if (timeLeft2 > 0) then
        return;
    end
	
	if (timerActive > 10) then
		if (timerDelay == 1 ) then
			--d(timerActive);
			--d(activeChatChannel);
			wbLeadHelper.chat(timerActive, activeChatChannel, tmpColorActive);
			timerDelay = 5;
		else
			timerDelay = timerDelay -1;
		end
		--d("delay: " .. tostring(timerDelay));
	elseif (timerActive > 0) then
		--d(timerActive);
		--d(activeChatChannel);
		wbLeadHelper.chat(timerActive, activeChatChannel, tmpColorActive);
		timerDelay = 5;
	end
	if (timerActive > 0) then
		timerActive = timerActive -1;
	end
	
	timeLeft2 = TIME_DELAY2;
end

function wbLeadHelper.draw(toggle)

	if ( zoneMenuActive == true) then return end
	if ( boMenuActive == true) then return end
	if ( lfmMenuActive == true) then return end
	if ( countdownMenuActive == true) then return end
	
	wbLeadHelper.drawWindows(wbLeadHelper.activeSettings.messages, toggle);

end

function wbLeadHelper.drawCountdownMenu(countdowns)
	wbLeadHelper.drawWindows(countdowns);
end

function wbLeadHelper.drawZoneMenu(zoneNames)
    wbLeadHelper._zoneMenuFlat = zoneNames

    local old = activeTemplate.buttonsPerRow
    activeTemplate.buttonsPerRow = 10
    wbLeadHelper.drawWindows(zoneNames)
    activeTemplate.buttonsPerRow = old
end

function wbLeadHelper.drawBoMenu(bos, miscBos)
	if not bos then return end

	local showMisc = wbLeadHelper.activeSettings
		and wbLeadHelper.activeSettings.showMiscBoColumn
		and miscBos and #miscBos > 0

	-- Left column = BOs only; remove misc names if they appear in bos
	local left = bos
	if showMisc then
		local mset = {}
		local function norm(s) return string.lower((tostring(s) or ""):gsub("<[^>]->","")):gsub("^%s+",""):gsub("%s+$","") end
		for i=1, #miscBos do mset[norm(miscBos[i])] = true end
		local filtered = {}
		for i=1, #bos do if not mset[norm(bos[i])] then table_insert(filtered, bos[i]) end end
		left = filtered
	end

	local flat = {}
	local rowsPerCol

	if showMisc then
		rowsPerCol = math.min(10, math.max(#left, #miscBos))
		if rowsPerCol < 1 then rowsPerCol = 1 end
		for i=1, #left do table_insert(flat, left[i]) end
		for i=#left+1, rowsPerCol do table_insert(flat, { __spacer = true, label = "" }) end
		for i=1, #miscBos do table_insert(flat, miscBos[i]) end
	else
		rowsPerCol = 10
		flat = left
	end

	wbLeadHelper._boMenuFlat = flat

	local old = activeTemplate.buttonsPerRow
	activeTemplate.buttonsPerRow = rowsPerCol
	wbLeadHelper.drawWindows(flat)
	activeTemplate.buttonsPerRow = old
end

function wbLeadHelper.drawLfmMenu(lfm)
	wbLeadHelper.drawWindows(lfm);
end

function wbLeadHelper.drawWindows(items, toggle)

	if ( not items ) then return end

	local isVisible = WindowGetShowing(wbLeadHelperWindowName);
	if (toggle) then
		WindowSetShowing(wbLeadHelperWindowName, not isVisible);
	end

	wbLeadHelper.destroyWindows(100);

	-- draw windows for all messages
	local xOffset = 0;
	local bottomWindow = "wbLeadHelperWindowTitle";
	local j = 1;
	for i=1, #items do
		repeat

			if type(items[i]) == "table" and not items[i].submenu then 
				items[i].submenu = "None";
			end

			if items[i].isNotEnabled then
				do break end
			end

			if not subMenuActive and items[i].submenu ~= "None" then 
				do break end
			end 

			local label = items[i].label or items[i];
			local color = wbLeadHelper.Colors[items[i].labelColor] or wbLeadHelper.Colors["white"];

			-- replace linebreaks for text formatting
			label = label:gsub("<br>", "\n", 1); --for backwards compatibility
			label = label:gsub("<nl>", "\n", 1);

			-- remove remaining tags so they are not shown in the label
			label = label:gsub("<", "");
			label = label:gsub(">", "");

			local messageWindow = "wbLeadHelper_Message_" .. tostring(i);	
			if (DoesWindowExist(messageWindow) == false) then
				CreateWindowFromTemplate( messageWindow, "wbLeadHelper_Message_Template", "Root");
			end
			
			WindowSetShowing( messageWindow, isVisible);
			WindowSetTintColor(messageWindow .. "Background", 0, 0, 0);
			-- Hide spacer rows (advance grid without drawing a button)
			if (type(items[i]) == "table" and items[i].__spacer) then
				WindowSetShowing(messageWindow, false);
			else

			WindowSetAlpha(messageWindow .. "Background", 0.5);
			end

			LabelSetText( messageWindow .. "Label", towstring(label));
			LabelSetTextColor(messageWindow .. "Label", color[1], color[2], color[3])

			WindowSetDimensions( messageWindow .. "Label", activeTemplate.buttonWidth, activeTemplate.buttonHeight);
			WindowClearAnchors( messageWindow );
			WindowSetDimensions( messageWindow, activeTemplate.buttonWidth, activeTemplate.buttonHeight);

			WindowAddAnchor( messageWindow , "bottomleft", bottomWindow, "topleft", (xOffset / InterfaceCore.GetScale()) * wbLeadHelper.activeSettings.windowSize, (2 / InterfaceCore.GetScale()) * wbLeadHelper.activeSettings.windowSize );
			WindowSetScale( messageWindow, wbLeadHelper.activeSettings.windowSize );
					
			if (type(items[i]) == "table" and items[i].__spacer) then
			WindowSetShowing(messageWindow, false);
		elseif (toggle) then
			WindowSetShowing( messageWindow, not isVisible);
		else
			WindowSetShowing( messageWindow, isVisible);
		end

			bottomWindow = messageWindow;

			if (j % activeTemplate.buttonsPerRow == 0) then
				xOffset = xOffset + (activeTemplate.buttonWidth + 2) * (j / activeTemplate.buttonsPerRow);
				bottomWindow = "wbLeadHelperWindowTitle";
			else 
				xOffset = 0;
			end

			j = j +1 ;

		until true
	end

	if (showingAlternateTitle == false) then
		wbLeadHelper.showNormalTitle();
	end
end

function wbLeadHelper.destroyWindows(number)

	if ( not number ) then return end

	for i=1, number do
		local messageWindow = "wbLeadHelper_Message_" .. tostring(i);	
		if (DoesWindowExist(messageWindow) == true) then
			DestroyWindow(messageWindow);
		end
	end	
end

function wbLeadHelper.toggleWbLeadHelperWindow()
	wbLeadHelper.draw(true);	
end

function wbLeadHelper.onLMB()
	wbLeadHelper.toChat("lmb");
end

function wbLeadHelper.onRMB()
	wbLeadHelper.toChat("rmb");
end

local function getMessageIdFromWindowName(windowName)
	if not windowName then return nil end

	local match = towstring(windowName):match(L"wbLeadHelper_Message_(%d+)")
	if match then
		return tonumber(match)
	end
end

function wbLeadHelper.getHoveredMessageId()
	local messageId = getMessageIdFromWindowName(SystemData.MouseOverWindow and SystemData.MouseOverWindow.name)
	if messageId then
		return messageId
	end

	return getMessageIdFromWindowName(SystemData.ActiveWindow and SystemData.ActiveWindow.name)
end

function wbLeadHelper.getSelectedMessageData(messageId)

	if not messageId then return nil, "", wbLeadHelper.Colors["white"] end

	local item = wbLeadHelper.activeSettings.messages[messageId]
	local message = ""

	if ( zoneMenuActive ) then
		local zoneNames = wbLeadHelper._zoneMenuFlat or wbLeadHelper.getAllZoneNames()
		message = zoneNames[messageId]
	elseif ( boMenuActive ) then
		local selected = wbLeadHelper._boMenuFlat and wbLeadHelper._boMenuFlat[messageId]
		if type(selected) == "table" then
			message = selected.label or ""
		else
			message = selected or ""
		end
	elseif ( lfmMenuActive ) then
		local lfm = wbLeadHelper.getSubmenuMessages()
		message = lfm[messageId]
	elseif ( countdownMenuActive ) then
		local countdowns = wbLeadHelper.getCountDowns()
		message = countdowns[messageId]
	elseif item then
		message = item.message or ""
	end

	local color = wbLeadHelper.Colors["white"]
	if item and item.messageColor then
		color = wbLeadHelper.Colors[item.messageColor] or color
	end

	return item, message or "", color
end

function wbLeadHelper.stripChatPrefix(message)
	if not message then return "" end
	return message:gsub("^/%w+ ", "")
end

function wbLeadHelper.replaceGroupLeaderTag(message)

	if not message then return "" end

	if (message:match("<GL>")) then
		local groupLeader = "me";
		local checkLeader = wbLeadHelper.getWbLeader();
		if( checkLeader ~= nil and checkLeader ~= '') then 
			groupLeader = "@" .. checkLeader;
		end
		message = message:gsub("<GL>", groupLeader);
	end

	return message
end

function wbLeadHelper.buildPreviewChatMessage(message, channel, includeChannel)
	local startTag = wbLeadHelper.activeSettings and wbLeadHelper.activeSettings.messageStart or ""
	local endTag = wbLeadHelper.activeSettings and wbLeadHelper.activeSettings.messageEnd or ""
	local decorated = wbLeadHelper.trim((startTag or "") .. " " .. (message or "") .. " " .. (endTag or ""))
	if includeChannel == false then
		return decorated
	end
	return (channel or "") .. decorated
end

function wbLeadHelper.getButtonActionPreview(mouseButton, messageId, includeChannel)
	local item, message = wbLeadHelper.getSelectedMessageData(messageId)

	if not message or message == "" then return nil end
	if not subMenuActive and item and item.isAnnouncement then
		return wbLeadHelper.buildAnnouncementCommand(message)
	end

	local chat
	if (lfmMenuActive and mouseButton == "lmb") then
		chat = "/5 "
	else
		chat = wbLeadHelper.setChatChannel(mouseButton, message);
	end
	message = wbLeadHelper.stripChatPrefix(message)
	message = wbLeadHelper.replaceGroupLeaderTag(message)

	if(countdownMenuActive) then
		if(message:match("- BACK -")) then
			return "Back to the main menu."
		end

		return wbLeadHelper.buildPreviewChatMessage(tostring(message) .. " sec countdown started!", chat, includeChannel)
	elseif (zoneMenuActive) then
		if(message:match("- BACK -")) then
			return "Back to the main menu."
		end

		local newMessage = tostring(message):upper();
		newMessage = tmpMessageActive:gsub("<Z>", newMessage);
		return wbLeadHelper.buildPreviewChatMessage(newMessage, chat, includeChannel)
	elseif (boMenuActive) then
		if(message:match("- BACK -")) then
			return "Back to the main menu."
		end

		local selected = wbLeadHelper._boMenuFlat and wbLeadHelper._boMenuFlat[messageId] or message
		local newMessage = tostring(selected):upper();
		newMessage = tmpMessageActive:gsub("<B>", newMessage);
		return wbLeadHelper.buildPreviewChatMessage(newMessage, chat, includeChannel)
	elseif (lfmMenuActive) then
		if(message:match("- BACK -")) then
			return "Back to the main menu."
		end

		local newMessage = message;
		local match = message:match("<autoRoles(%d+)>");
		if (match) then
			match = tonumber(match);
			newMessage = wbLeadHelper.AutoLookingForPlayers(match);
			if newMessage == "2" then
				return "Warband full."
			elseif not newMessage then
				return "Please join a party or warband before using the auto search feature."
			end
		end

		newMessage = tmpMessageActive:gsub("<LFM>", newMessage);
		local zone = GetZoneName(wbLeadHelper.getCurrentZone());
		newMessage = newMessage:gsub("<LFMZ>", tostring(zone));
		newMessage = wbLeadHelper.addCareerIcons(newMessage);

		return wbLeadHelper.buildPreviewChatMessage(newMessage, chat, includeChannel)
	end

	if not item then return nil end

	if (item.type == "Countdown") then
		if(timerActive ~= 0) then
			return wbLeadHelper.buildPreviewChatMessage("Countdown aborted!", chat, includeChannel)
		end

		return "Opens the countdown submenu."
	elseif (item.type == "Zones") then
		return "Opens the zone submenu."
	elseif (item.type == "LFM") then
		return "Opens the LFM submenu."
	elseif (item.type == "Bos") then
		return "Opens the BO submenu."
	end

	return wbLeadHelper.buildPreviewChatMessage(message, chat, includeChannel)
end

function wbLeadHelper.getLfmStatsTooltipText(messageId)

	if subMenuActive then return nil end
	if not messageId then return nil end

	local item = wbLeadHelper.activeSettings.messages[messageId];

	if not item or item.type ~= "LFM" then return nil end

	-- Use the first contiguous AUTO parent entry after the hovered LFM button.
	local groupCount = 8;
	for i=messageId+1, #wbLeadHelper.activeSettings.messages do
		if wbLeadHelper.activeSettings.messages[i].submenu == "Parent" then
			local match = wbLeadHelper.activeSettings.messages[i].message:match("<autoRoles(%d+)>");
			if (match) then
				groupCount = tonumber(match);
				break;
			end
		end
		-- Stop once the contiguous submenu block ends.
		if wbLeadHelper.activeSettings.messages[i].submenu == "None" or not wbLeadHelper.activeSettings.messages[i].submenu then
			break
		end
	end

	local stats = wbLeadHelper.AutoLookingForPlayers(groupCount);

	if not stats or stats == "2" then return nil end

	stats = wbLeadHelper.addCareerIcons(stats);

	return "Missing roles\n" .. stats
end

function wbLeadHelper.toChat(mouseButton)

	local mouseoverMessageId = wbLeadHelper.getHoveredMessageId()
	local item, message, color = wbLeadHelper.getSelectedMessageData(mouseoverMessageId)
	if not subMenuActive and item and item.isAnnouncement then
		wbLeadHelper.sendAnnouncement(message, true)
		return
	end

	-- Resolve the chat channel; LFM submenu left-clicks always go to /5.
	local chat;
	if (lfmMenuActive and mouseButton == "lmb") then
		chat = "/5 ";
	else
		chat = wbLeadHelper.setChatChannel(mouseButton, message);
	end
	message = wbLeadHelper.stripChatPrefix(message)
	message = wbLeadHelper.replaceGroupLeaderTag(message)


	--
	--
	-- When a sub menu is active or no more menus follow
	--
	--
	if(countdownMenuActive) then
		wbLeadHelper.destroyWindows(100);

		if(message:match("- BACK -")) then
		else
			local timerVal = tonumber(message);
			timerActive = timerVal -1; -- this value is monitored by the game update function.
			activeChatChannel = chat;
			wbLeadHelper.chat( timerVal .. " sec countdown started!", chat, tmpColorActive); -- timerUpdate handles the remaining ticks.
		end
		countdownMenuActive = false;
		subMenuActive = false;
		wbLeadHelper.draw(); -- draw here just to avoid a delay in the messages showing up again

	-- Zone menu is active.
	elseif (zoneMenuActive) then

		wbLeadHelper.destroyWindows(100);

		if(message:match("- BACK -")) then
		else
			local newMessage = message:upper();
			newMessage = tmpMessageActive:gsub("<Z>", newMessage);
			wbLeadHelper.chat(newMessage, chat, tmpColorActive);
		end
		zoneMenuActive = false;
		subMenuActive = false;
		tmpMessageActive = "";
		tmpColorActive = "";

		wbLeadHelper.draw(); -- draw here just to avoid a delay in the messages showing up again

	
	-- BO menu is active.
	elseif (boMenuActive) then

		wbLeadHelper.destroyWindows(100);

		if(message:match("- BACK -")) then
		else
			local idx = mouseoverMessageId
			local selected = wbLeadHelper._boMenuFlat and wbLeadHelper._boMenuFlat[idx] or message
			local newMessage = tostring(selected):upper();
			newMessage = tmpMessageActive:gsub("<B>", newMessage);
			wbLeadHelper.chat(newMessage, chat, tmpColorActive);
		end
		boMenuActive = false;
		subMenuActive = false;
		tmpMessageActive = "";
		tmpColorActive = "";

		wbLeadHelper.draw(); -- draw here just to avoid a delay in the messages showing up again

	elseif (lfmMenuActive) then

		wbLeadHelper.destroyWindows(100);

		if(message:match("- BACK -")) then
		else
			local newMessage = message;
			local match = message:match("<autoRoles(%d+)>");
			if (match) then
				match = tonumber(match);
				newMessage = wbLeadHelper.AutoLookingForPlayers(match);
				if newMessage == "2" then
					Print("<LINK data=\"0\" text=\"[wbLeadHelper]\" color=\"255,50,50\"> Warband full.");
				elseif not newMessage then
					Print("<LINK data=\"0\" text=\"[wbLeadHelper]\" color=\"255,50,50\"> Please join a party or warband before using the auto search feature.");
				end
			end

			if (newMessage and newMessage ~= "2") then
				newMessage = tmpMessageActive:gsub("<LFM>", newMessage);
				local zone = GetZoneName(wbLeadHelper.getCurrentZone());
				newMessage = newMessage:gsub("<LFMZ>", tostring(zone));

				newMessage = wbLeadHelper.addCareerIcons(newMessage);
	
				wbLeadHelper.chat(newMessage, chat, tmpColorActive);
			end
		end
		lfmMenuActive = false;
		subMenuActive = false;
		tmpMessageActive = "";
		tmpColorActive = "";

		wbLeadHelper.draw(); -- draw here just to avoid a delay in the messages showing up again


	--
	--
	-- When a first level menu is active (e.g. the initial messages are shown)
	--
	--
	elseif (item.type == "Countdown") then

		if(timerActive ~= 0) then
			timerActive = 0;
			wbLeadHelper.chat("Countdown aborted!", chat, color);
		else
			countdownMenuActive = true;
			subMenuActive = true;
			local countdowns = wbLeadHelper.getCountDowns();
			wbLeadHelper.drawCountdownMenu(countdowns);
			tmpColorActive = color;
		end

	elseif (item.type == "Zones") then

		zoneMenuActive = true;
		subMenuActive = true;
		tmpMessageActive = message;
		tmpColorActive = color;

		local zoneNames = wbLeadHelper.getAllZoneNames();

		wbLeadHelper.drawZoneMenu(zoneNames);
	elseif (item.type == "LFM") then

		lfmMenuActive = true;
		subMenuActive = true;
		tmpMessageActive = message;
		tmpColorActive = color;
		clickedMainMenuMessageId = mouseoverMessageId;

		local lfmNames = wbLeadHelper.getSubmenuMessages("label");

		wbLeadHelper.drawLfmMenu(lfmNames);

	
elseif (item.type == "Bos") then

	local bos, miscBos = wbLeadHelper.getBObyZoneId(wbLeadHelper.getCurrentZone());

	boMenuActive = true;
	subMenuActive = true;
	tmpMessageActive = message;
	tmpColorActive = color;

	wbLeadHelper.drawBoMenu(bos, miscBos);

	else
		wbLeadHelper.chat(message, chat, color);	
	end
end

function wbLeadHelper.chat(message, channel, color)

	local message = wbLeadHelper.activeSettings.messageStart .. " " .. message .. " " .. wbLeadHelper.activeSettings.messageEnd;
	local message = wbLeadHelper.ColorText(message, color);
	message = channel .. message;

	--EA_ChatWindow.InsertText( towstring(message), towstring(channel) );
	if( WindowGetShowing(wbLeadHelperConfigWindow.name)) then
		Print("<LINK data=\"0\" text=\"[wbLeadHelper]\" color=\"50,255,10\"> " .. message);
	else
		SendChatText( towstring(message), L"" );
	end
end

function wbLeadHelper.GetAutoBandIntegrationState(settings)
	settings = settings or wbLeadHelper.activeSettings
	if not settings or settings.autoBandIntegrationEnabled ~= true then
		return { active = false, reason = "off" }
	end

	local autoBand = AutoBand
	if type(autoBand) ~= "table" then
		return { active = false, reason = "no AutoBand" }
	end

	if type(autoBand.saved) ~= "table" then
		return { active = false, reason = "AB not ready" }
	end

	local saved = autoBand.saved
	if type(autoBand.is_warband_enabled) == "function" then
		local okEnabled, enabled = pcall(autoBand.is_warband_enabled)
		if not okEnabled or enabled == false then
			return { active = false, reason = "AB WB off" }
		end
	elseif saved.warband_enabled == false then
		return { active = false, reason = "AB WB off" }
	end

	local leaderCheck = autoBand.is_wb_leader
	if type(leaderCheck) ~= "function" then
		leaderCheck = autoBand.has_permission
	end
	if type(leaderCheck) ~= "function" then
		return { active = false, reason = "no lead check" }
	end

	local okLeader, isLeader = pcall(leaderCheck)
	if not okLeader or isLeader ~= true then
		return { active = false, reason = "not WB lead" }
	end

	local roleCapsEnabled = saved.autokick_enabled == true
	local dpsWeightingEnabled = roleCapsEnabled and saved.dps_weighting_enabled == true
	local stealthRestrictionEnabled = saved.autokick_we_wh_enabled == true
	local raceRestrictionEnabled = saved.restrict_same_race == true and autoBand.raceDetermined == true

	if not roleCapsEnabled and not stealthRestrictionEnabled and not raceRestrictionEnabled then
		if saved.restrict_same_race == true then
			return { active = false, reason = "race unknown" }
		end
		return { active = false, reason = "no AB toggles" }
	end

	return {
		active = true,
		reason = "active",
		autoBand = autoBand,
		saved = saved,
		roleCapsEnabled = roleCapsEnabled,
		dpsWeightingEnabled = dpsWeightingEnabled,
		stealthRestrictionEnabled = stealthRestrictionEnabled,
		raceRestrictionEnabled = raceRestrictionEnabled,
	}
end

function wbLeadHelper.GetAutoBandIntegrationStatus(settings)
	local status = wbLeadHelper.GetAutoBandIntegrationState(settings)
	if status and status.active == true then
		return status
	end

	return nil
end

function wbLeadHelper.GetAutoBandRoleIcons(roleKey, status)
	status = status or wbLeadHelper.GetAutoBandIntegrationStatus()
	if not status or not status.raceRestrictionEnabled then
		return nil
	end

	local autoBand = status.autoBand
	if type(autoBand.GetRoleIcons) ~= "function" then
		return nil
	end

	local okIcons, icons = pcall(autoBand.GetRoleIcons, roleKey, false)
	if okIcons and type(icons) == "string" and icons ~= "" then
		return icons
	end

	return nil
end

function wbLeadHelper.ShouldAutoBandHideStealthCareer(careerLine, status)
	if not status or status.stealthRestrictionEnabled ~= true then
		return false
	end

	if not GameData or not GameData.CareerLine then
		return false
	end

	return careerLine == GameData.CareerLine.WITCH_HUNTER
		or careerLine == GameData.CareerLine.WITCH_ELF
end

function wbLeadHelper.GetOwnFactionCareerIconsDetailed(status)
	local tankIcons = "";
	local healerIcons = "";
	local mdpsIcons = "";
	local rdpsIcons = "";

	for i=1, #wbLeadHelper.CareerLineById do
		local career = wbLeadHelper.CareerLineById[i];
		if career.faction == GameData.Player.realm and not wbLeadHelper.ShouldAutoBandHideStealthCareer(i, status) then
			local roleType = career.type
			if status
				and status.saved
				and status.saved.bw_sorc_as_mdps == true
				and (i == GameData.CareerLine.BRIGHT_WIZARD or i == GameData.CareerLine.SORCERER)
			then
				roleType = "mdps"
			end

			if (roleType == "tank") then
				tankIcons = tankIcons .. career.icon .. "";
			elseif (roleType == "healer") then
				healerIcons = healerIcons .. career.icon .. "";
			elseif (roleType == "mdps") then
				mdpsIcons = mdpsIcons .. career.icon .. "";
			else
				rdpsIcons = rdpsIcons .. career.icon .. "";
			end
		end
	end

	return tankIcons, healerIcons, mdpsIcons .. rdpsIcons, mdpsIcons, rdpsIcons;
end

function wbLeadHelper.addCareerIcons(newMessage)
	local tankIcons = "<icon22702>";
	local healerIcons = "<icon22706>";
	local dpsIcons = "<icon22701>"; 
	local mdpsIcons = "<icon22701>";
	local rdpsIcons = "<icon22703>";
	local autoBandStatus = wbLeadHelper.GetAutoBandIntegrationStatus()

	if(wbLeadHelper.activeSettings.showLfgIcons) then
		if autoBandStatus and autoBandStatus.raceRestrictionEnabled then
			tankIcons = wbLeadHelper.GetAutoBandRoleIcons("tank", autoBandStatus) or tankIcons
			healerIcons = wbLeadHelper.GetAutoBandRoleIcons("healer", autoBandStatus) or healerIcons
			dpsIcons = wbLeadHelper.GetAutoBandRoleIcons("dps", autoBandStatus) or dpsIcons
			mdpsIcons = wbLeadHelper.GetAutoBandRoleIcons("mdps", autoBandStatus) or mdpsIcons
			rdpsIcons = wbLeadHelper.GetAutoBandRoleIcons("rdps", autoBandStatus) or rdpsIcons
		else
			tankIcons, healerIcons, dpsIcons, mdpsIcons, rdpsIcons = wbLeadHelper.GetOwnFactionCareerIconsDetailed(autoBandStatus);
		end
	end

	newMessage = newMessage:gsub("<mdps>", mdpsIcons.." mdps");
	newMessage = newMessage:gsub("<rdps>", rdpsIcons.." rdps");
	newMessage = newMessage:gsub("<healer>", healerIcons.." healer");
	newMessage = newMessage:gsub("<tank>", tankIcons.." tank");
	newMessage = newMessage:gsub("<dps>", dpsIcons.." dps");

	return newMessage;
end

function wbLeadHelper.setChatChannel(mb, text)
    local pref = (type(text) == "string") and text:match("^/%w+%s")
    if pref then return pref end

    if mb == "lmb" then
        if IsWarBandActive and IsWarBandActive() then
            return "/wb "
        else
            return "/p "
        end
    end

    return "/1 "
end

function wbLeadHelper.onMouseOver()
	wbLeadHelper.onZoneMouseOver();
	wbLeadHelper.OnMouseOverCreateTooltip();

	local hoverWindow = tostring(SystemData.MouseOverWindow.name);
	local color = wbLeadHelper.Colors["grey"];
	WindowSetTintColor(hoverWindow, color[1], color[2], color[3]);
end

function wbLeadHelper.onMouseOut()
	wbLeadHelper.showNormalTitle();

	local hoverWindow = tostring(SystemData.MouseOverWindow.name);
	local color = wbLeadHelper.Colors["black"];	
	WindowSetTintColor(hoverWindow, color[1], color[2], color[3]);		
end

function wbLeadHelper.onZoneMouseOver()
    local label

    local mouseoverMessageId = wbLeadHelper.getHoveredMessageId()

    local isLFM = false
    if lfmMenuActive then
        isLFM = true
    elseif mouseoverMessageId
        and wbLeadHelper.activeSettings
        and wbLeadHelper.activeSettings.messages
        and wbLeadHelper.activeSettings.messages[mouseoverMessageId]
        and wbLeadHelper.activeSettings.messages[mouseoverMessageId].type == "LFM"
    then
        isLFM = true
    end

    if isLFM then
        label = L"LFG <icon00092> / <icon00093> Region"
    elseif IsWarBandActive and IsWarBandActive() then
        label = L"WB <icon00092> / <icon00093> Region"
    else
        label = L"Party <icon00092> / <icon00093> Region"
    end

    LabelSetText("wbLeadHelperWindowTitleLabel", label)
    showingAlternateTitle = true
end

function wbLeadHelper.showNormalTitle()
	LabelSetText("wbLeadHelperWindowTitleLabel", L"wbLeadHelper");
end

function wbLeadHelper.OnMouseOverCreateTooltip()

	local mouseoverMessageId = wbLeadHelper.getHoveredMessageId()
	if not mouseoverMessageId then return end

	local preview = wbLeadHelper.getButtonActionPreview("lmb", mouseoverMessageId, false)
	local stats = wbLeadHelper.getLfmStatsTooltipText(mouseoverMessageId)
	local tooltipText = ""

	if preview then
		tooltipText = preview
	end

	if stats then
		if tooltipText ~= "" then
			tooltipText = tooltipText .. "\n\n"
		end
		tooltipText = tooltipText .. stats
	end

	if tooltipText == "" then return end

	Tooltips.CreateTextOnlyTooltip( SystemData.ActiveWindow.name )
    Tooltips.SetTooltipText( 1, 1, towstring(" " .. tooltipText .. " "))
    Tooltips.AnchorTooltip (Tooltips.ANCHOR_CURSOR)
    Tooltips.Finalize();
end

function wbLeadHelper.trim(s)
   return (s:gsub("^%s*(.-)%s*$", "%1"))
end

function wbLeadHelper.getAllZoneNames()
    local zoneNames = {}
    table_insert(zoneNames, 1, "- BACK -")

    local src = wbLeadHelper.MoveTo or wbLeadHelper.ZoneIds
    for i = 1, #src do
        local zoneId = src[i]
        local zoneName = tostring(GetZoneName(zoneId))
        table_insert(zoneNames, zoneName)
    end

    return zoneNames
end

function wbLeadHelper.getCountDowns()
	local countdowns = {}; 
	table_insert(countdowns, 1, "- BACK -");

	for i=1, #wbLeadHelper.CountdownSteps do
		table_insert(countdowns, tostring(wbLeadHelper.CountdownSteps[i]));
	end

	return countdowns;
end

function wbLeadHelper.getCurrentZone()
	return GameData.Player.zone;
end


function wbLeadHelper.getBObyZoneId(id)

	local bos = {};
	table_insert(bos, 1, "- BACK -");

	for i=1, #wbLeadHelper.BosByZoneId[id] do
		table_insert(bos, wbLeadHelper.BosByZoneId[id][i]);
	end

	-- don't merge misc into main; return as separate list (whitelisted by zone)
	local misc = wbLeadHelper.GetMiscBoNamesForZone(id)

	return bos, misc;
end

function wbLeadHelper.getSubmenuMessages(messageType)

	if clickedMainMenuMessageId < 1 then return end
	if not messageType then messageType = "message" end

	local messages = {}; 
	table_insert(messages, 1, "- BACK -");

	local clickedMessageType = wbLeadHelper.activeSettings.messages[clickedMainMenuMessageId].type;

	-- Add contiguous submenu-parent entries that belong to this top-level message.
	for i=clickedMainMenuMessageId+1, #wbLeadHelper.activeSettings.messages do
		if wbLeadHelper.activeSettings.messages[i].submenu == "Parent" then
			table_insert(messages, wbLeadHelper.activeSettings.messages[i][messageType]);
		end
		-- Stop once the contiguous submenu block ends.
		if wbLeadHelper.activeSettings.messages[i].submenu == "None" or not wbLeadHelper.activeSettings.messages[i].submenu then
			break
		end
	end
	
	-- add messages with the same type, no matter where they are located
	for i=1, #wbLeadHelper.activeSettings.messages do
		if wbLeadHelper.activeSettings.messages[i].submenu == clickedMessageType then
			table_insert(messages, wbLeadHelper.activeSettings.messages[i][messageType]);
		end
	end

	return messages;
end

function wbLeadHelper.toggleColoredChat()
	if not chatHookActive then
		Print("<LINK data=\"0\" text=\"[wbLeadHelper]\" color=\"50,255,10\"> Permanent colored chat enabled.");
		chatHookActive = true;
	else
		Print("<LINK data=\"0\" text=\"[wbLeadHelper]\" color=\"50,255,10\"> Permanent colored chat disabled.");
		chatHookActive = false;
	end
end

function wbLeadHelper.OnKeyEnter(...)
	if not chatHookActive then
		return hookOnKeyEnter(...)
	end

	local message = wbLeadHelper.trim(tostring(EA_TextEntryGroupEntryBoxTextInput.Text));
	message = wbLeadHelper.activeSettings.messageStart .. " " .. message .. " " .. wbLeadHelper.activeSettings.messageEnd;	
	message = wbLeadHelper.ColorText(message, wbLeadHelper.Colors[wbLeadHelper.activeSettings.textColor]);

	EA_TextEntryGroupEntryBoxTextInput.Text = towstring(message);

	return hookOnKeyEnter(...);
end

function wbLeadHelper.ColorText(text, color)

	if ( not text ) then return end
	if ( not color ) then color = wbLeadHelper.Colors["white"] end

	local function flushColored(out, buffer)
		if buffer ~= "" then
			table_insert(out, "<LINK data=\"0\" color=\"" .. color[1] .. "," .. color[2] .. "," .. color[3] .. "\" text=\"" .. buffer .. "\">")
		end
		return ""
	end

	local out = {}
	local coloredBuffer = ""
	local i = 1
	local textLength = string.len(text)

	while i <= textLength do
		local ch = text:sub(i, i)

		if string.find(ch, "%s") then
			local spaceStart = i
			repeat
				i = i + 1
				ch = text:sub(i, i)
			until i > textLength or not string.find(ch, "%s")

			local spaces = text:sub(spaceStart, i - 1)
			if coloredBuffer ~= "" then
				coloredBuffer = coloredBuffer .. spaces
			else
				table_insert(out, spaces)
			end
		elseif ch == "<" then
			local closeIndex = string.find(text, ">", i, true)
			coloredBuffer = flushColored(out, coloredBuffer)

			if closeIndex then
				table_insert(out, text:sub(i, closeIndex))
				i = closeIndex + 1
			else
				table_insert(out, text:sub(i))
				break
			end
		else
			local tokenStart = i
			repeat
				i = i + 1
				ch = text:sub(i, i)
			until i > textLength or ch == "<" or string.find(ch, "%s")

			local token = text:sub(tokenStart, i - 1)
			local first = token:sub(1,1)
			if first == "/" or first == "." or first == "]" or first == "*" or first == "@" then
				coloredBuffer = flushColored(out, coloredBuffer)
				table_insert(out, token)
			else
				coloredBuffer = coloredBuffer .. token
			end
		end
	end

	flushColored(out, coloredBuffer)

	return table.concat(out)
end

function wbLeadHelper.mysplit(inputstr, sep)
        if sep == nil then
                sep = "%s"
        end
        local t={}
        for str in string.gmatch(inputstr, "([^"..sep.."]+)") do
                table.insert(t, str)
        end
        return t
end

function wbLeadHelper.IsAutoBandRoleName(role)
	return role == "tank" or role == "healer" or role == "mdps" or role == "rdps"
end

function wbLeadHelper.GetAutoBandRoleForPlayer(player, status)
	if not player then
		return nil
	end

	local saved = status and status.saved or nil
	if saved and type(saved.custom_roles) == "table" then
		local nameKey = wbLeadHelper.normalizeNameKey(player.name)
		local override = nameKey and saved.custom_roles[nameKey]
		if wbLeadHelper.IsAutoBandRoleName(override) then
			return override
		end
	end

	local role = player.role
	if not wbLeadHelper.IsAutoBandRoleName(role) then
		role = wbLeadHelper.getPlayerRole(player, nil)
	end

	if saved
		and saved.bw_sorc_as_mdps == true
		and GameData
		and GameData.CareerLine
	then
		local career = player.careerLine or player.career
		if career == GameData.CareerLine.BRIGHT_WIZARD or career == GameData.CareerLine.SORCERER then
			return "mdps"
		end
	end

	return role
end

function wbLeadHelper.CountPlayerRole(counts, role)
	if role == "tank" then
		counts.tanks = counts.tanks + 1
	elseif role == "healer" then
		counts.healers = counts.healers + 1
	elseif role == "mdps" then
		counts.mdps = counts.mdps + 1
		counts.dps = counts.dps + 1
	elseif role == "rdps" then
		counts.rdps = counts.rdps + 1
		counts.dps = counts.dps + 1
	end
end

function wbLeadHelper.GetAutoBandRoleCounts(status)
	if not status or not status.autoBand or type(status.autoBand.get_wb) ~= "function" then
		return nil
	end

	local okWb, wb = pcall(status.autoBand.get_wb)
	if not okWb or not wb or type(wb.foreach_player) ~= "function" then
		return nil
	end

	local counts = {
		tanks = 0,
		healers = 0,
		dps = 0,
		mdps = 0,
		rdps = 0,
		total = 0,
	}

	local okIterate = pcall(function()
		wb:foreach_player(function(_, player)
			local role = wbLeadHelper.GetAutoBandRoleForPlayer(player, status)
			wbLeadHelper.CountPlayerRole(counts, role)
			if wbLeadHelper.IsAutoBandRoleName(role) then
				counts.total = counts.total + 1
			end
		end)
	end)

	if not okIterate or counts.total == 0 then
		return nil
	end

	return counts
end

function wbLeadHelper.CountGroupedRoles(groups, status)
	if not groups then
		return nil
	end

	local counts = {
		tanks = 0,
		healers = 0,
		dps = 0,
		mdps = 0,
		rdps = 0,
		total = 0,
	}

	for i=1, #groups do
		local grp = groups[i]
		for j=1, #grp do
			local player = grp[j]
			local role = player and player.role
			if status then
				role = wbLeadHelper.GetAutoBandRoleForPlayer(player, status)
			end
			wbLeadHelper.CountPlayerRole(counts, role)
			if wbLeadHelper.IsAutoBandRoleName(role) then
				counts.total = counts.total + 1
			end
		end
	end

	if counts.total == 0 then
		return nil
	end

	return counts
end

function wbLeadHelper.BuildNeededRoleText(counts, caps, useDpsWeighting, clampToOpenSlots)
	if not counts or not caps then
		return nil
	end

	local total = counts.total or 0
	local openSlots = 24 - total
	if openSlots < 0 then
		openSlots = 0
	end

	local neededHeals = math.max(0, (caps.healers or 0) - (counts.healers or 0))
	local neededTanks = math.max(0, (caps.tanks or 0) - (counts.tanks or 0))
	local neededDps = math.max(0, (caps.dps or 0) - (counts.dps or 0))
	local neededMdps = math.max(0, (caps.mdps or 0) - (counts.mdps or 0))
	local neededRdps = math.max(0, (caps.rdps or 0) - (counts.rdps or 0))
	local parts = {}

	local function addNeed(needed, token)
		if needed <= 0 then
			return
		end

		if clampToOpenSlots then
			if openSlots <= 0 then
				return
			end
			if needed > openSlots then
				needed = openSlots
			end
			openSlots = openSlots - needed
		end

		if needed > 0 then
			table.insert(parts, tostring(needed) .. " " .. token)
		end
	end

	addNeed(neededHeals, "<healer>")
	addNeed(neededTanks, "<tank>")
	if useDpsWeighting then
		addNeed(neededMdps, "<mdps>")
		addNeed(neededRdps, "<rdps>")
	else
		addNeed(neededDps, "<dps>")
	end

	if #parts == 0 then
		return nil
	end

	return table.concat(parts, " / ")
end

function wbLeadHelper.GetAutoBandRoleCaps(roleCount, status)
	if status and status.roleCapsEnabled and status.saved then
		local saved = status.saved
		return {
			tanks = tonumber(saved.max_tanks) or roleCount,
			healers = tonumber(saved.max_healers) or roleCount,
			dps = tonumber(saved.max_dps) or roleCount,
			mdps = tonumber(saved.max_mdps) or 0,
			rdps = tonumber(saved.max_rdps) or 0,
		}
	end

	return {
		tanks = roleCount,
		healers = roleCount,
		dps = roleCount,
		mdps = 0,
		rdps = 0,
	}
end

function wbLeadHelper.AutoLookingForPlayers(roleCount)

	if not roleCount then roleCount = 8 end
	local autoBandStatus = wbLeadHelper.GetAutoBandIntegrationStatus()

	local groups = {};
	if wbLeadHelper.inWarBand() then
		groups = wbLeadHelper.gatherWarbandPlayers();
	else
		groups = wbLeadHelper.gatherGroupPlayers();
	end

	--d(DUMP_TABLE(groups))

	if not groups then return end

	local roleCountingStatus = nil
	if autoBandStatus and autoBandStatus.roleCapsEnabled then
		roleCountingStatus = autoBandStatus
	end

	local counts = nil
	if roleCountingStatus then
		counts = wbLeadHelper.GetAutoBandRoleCounts(roleCountingStatus)
	end
	counts = counts or wbLeadHelper.CountGroupedRoles(groups, roleCountingStatus)
	if not counts then return end

	if counts.total == 24 and (not autoBandStatus or not autoBandStatus.roleCapsEnabled) then
		return "2"
	end

	local caps = wbLeadHelper.GetAutoBandRoleCaps(roleCount, autoBandStatus)
	local newMessage = wbLeadHelper.BuildNeededRoleText(
		counts,
		caps,
		autoBandStatus and autoBandStatus.dpsWeightingEnabled,
		not (autoBandStatus and autoBandStatus.roleCapsEnabled)
	)

	if newMessage then
		return newMessage
	end

	if counts.total == 24 then
		return "2"
	end
end

function wbLeadHelper.gatherWarbandPlayers()
	local group = {};
	local wbdata = GetBattlegroupMemberData();
	local altSpecDpsSet = wbLeadHelper.getAltSpecDpsSet();

	for i in ipairs(wbdata) do
		group[i] = {};
	end

	for gid, grp in ipairs(wbdata) do
		for pid, player in ipairs(grp.players) do
			player.role = wbLeadHelper.getPlayerRole(player, altSpecDpsSet);
			table.insert(group[gid], player);
		end
	end

	return group;
end

function wbLeadHelper.gatherGroupPlayers()
	local group = {{}};
	local gData = PartyUtils.GetPartyData();
	local altSpecDpsSet = wbLeadHelper.getAltSpecDpsSet();
	local me = {
		["name"] = GameData.Player.name,
		["careerLine"] = GameData.Player.career.line,
		["role"] = wbLeadHelper.getPlayerRole({
			name = GameData.Player.name,
			careerLine = GameData.Player.career.line,
		}, altSpecDpsSet);
		["isGroupLeader"] = GameData.Player.isGroupLeader,
	}
	table.insert(group[1], me);

	for pid, player in ipairs(gData) do
		if player.online and me.name ~= player.name then
			player.role = wbLeadHelper.getPlayerRole(player, altSpecDpsSet);
			table.insert(group[1], player);
		end
	end

	return group;
end

function wbLeadHelper.getWbLeader()
	local groups;
	if wbLeadHelper.inWarBand() then
		groups = wbLeadHelper.gatherWarbandPlayers();
	else 
		groups = wbLeadHelper.gatherGroupPlayers();
	end

	local leader = "";
	for i=1, #groups do
		local grp = groups[i];
		for i=1, #grp do
			local player = grp[i];
			if (player.isGroupLeader) then
				leader = tostring(player.name);
			end
		end
	end

	return leader;
end

function wbLeadHelper.getPlayerRoleByCareer(id)
	local career = wbLeadHelper.CareerLineById[id];
	if career then
		return career.type;
	end
end

function wbLeadHelper.toNameString(name)
	if not name then return nil end

	if type(name) ~= "string" and WStringToString then
		name = WStringToString(name)
	end

	if type(name) ~= "string" then
		name = tostring(name)
	end

	return name
end

function wbLeadHelper.normalizeNameKey(name)
	local asString = wbLeadHelper.toNameString(name)
	if not asString then return nil end
	return string_lower(asString)
end

function wbLeadHelper.isRunePriestOrZealot(career)
	if not career or not GameData or not GameData.CareerLine then
		return false
	end

	return career == GameData.CareerLine.RUNE_PRIEST or career == GameData.CareerLine.ZEALOT
end

function wbLeadHelper.shouldIgnoreAltSpecForCareer(career)
	local settings = wbLeadHelper.activeSettings
	if not settings then
		return false
	end

	if settings.disableAltSpecCheck then
		return true
	end

	if settings.disableAltSpecCheckForRunePriestZealot and wbLeadHelper.isRunePriestOrZealot(career) then
		return true
	end

	return false
end

function wbLeadHelper.getScoreboardSource()
	local inScenario = GameData and GameData.Player and (GameData.Player.isInScenario or GameData.Player.isInSiege)

	if inScenario and ScenarioSummaryWindow and ScenarioSummaryWindow.playersData then
		return ScenarioSummaryWindow.playersData
	end

	if RoRGroupScoreboard and RoRGroupScoreboard.playersDataRaw then
		return RoRGroupScoreboard.playersDataRaw
	end

	return nil
end

function wbLeadHelper.getAltSpecDpsSet()
	if wbLeadHelper.activeSettings and wbLeadHelper.activeSettings.disableAltSpecCheck then
		return nil
	end

	local playersData = wbLeadHelper.getScoreboardSource()
	if not playersData then
		return nil
	end

	local set = {}
	for _, pdata in pairs(playersData) do
		local archetype = pdata and (pdata.archtype or pdata.archetype)
		archetype = tonumber(archetype)
		if archetype and archetype > 0 and pdata.name then
			local key = wbLeadHelper.normalizeNameKey(pdata.name)
			if key then
				set[key] = true
			end
		end
	end

	if next(set) == nil then
		return nil
	end

	return set
end

function wbLeadHelper.getPlayerRole(player, altSpecDpsSet)
	if not player then
		return nil
	end

	local career = player.careerLine or player.career
	local role = wbLeadHelper.getPlayerRoleByCareer(career)
	if role ~= "tank" and altSpecDpsSet and not wbLeadHelper.shouldIgnoreAltSpecForCareer(career) then
		local nameKey = wbLeadHelper.normalizeNameKey(player.name)
		if nameKey and altSpecDpsSet[nameKey] then
			return "rdps"
		end
	end

	return role
end

function wbLeadHelper.getOwnFactionCareerIconsByType()
	local tankIcons, healerIcons, dpsIcons = wbLeadHelper.GetOwnFactionCareerIconsDetailed(wbLeadHelper.GetAutoBandIntegrationStatus())
	return tankIcons, healerIcons, dpsIcons;
end

function wbLeadHelper.EnsureSettingsTable()
	if type(wbLeadHelper.GlobalSettings) ~= "table" then
		if wbLeadHelper.activeSettings and type(wbLeadHelper.activeSettings) == "table" then
			wbLeadHelper.GlobalSettings = copySettingsTable(wbLeadHelper.activeSettings)
		else
			wbLeadHelper.GlobalSettings = copySettingsTable(wbLeadHelper.DefaultSettings)
		end
	end

	normalizeSettingsTable(wbLeadHelper.GlobalSettings)
	return wbLeadHelper.GlobalSettings
end

function wbLeadHelper.setActiveSettings(settings)
	settings = normalizeSettingsTable(settings)
	wbLeadHelper.activeSettings = settings;
end 

function wbLeadHelper.DefaultSettingsChangedDialog ()
	DialogManager.MakeTwoButtonDialog (
	L"wbLeadHelper has to be reset to it's default settings to function properly. This will reset all custom messages you created!\n\nDo it now?",
	L"Yes",
	function ()
		wbLeadHelper.GlobalSettings = copySettingsTable(wbLeadHelper.DefaultSettings);
		wbLeadHelper.setActiveSettings(wbLeadHelper.GlobalSettings)
		
		wbLeadHelper.createWbLeadHelperWindow()
		ModulesSaveSettings() -- Write SavedVariables.lua to disk
	end,
	L"No")
end

function wbLeadHelper.isNil (value, nilReturnValue)
	if (value == nil) then return nilReturnValue end
	return value
end

function wbLeadHelper.isEmpty (value, emptyReturnValue)
	if (not value or value:len() < 1) then return emptyReturnValue end
	return value
end

function wbLeadHelper.indexOf(array, value)
    for i, v in ipairs(array) do
        if v == value then
            return i
        end
    end
    return nil
end

function wbLeadHelper.inWarBand()
    return IsWarBandActive()
end

function wbLeadHelper.inAParty()
    return GetNumGroupmates() > 0
end
