A simple warhammer online addon which makes it easier for warband and siege leaders to communicate with their followers by broadcasting text sequences into chat. 

## Custom changes added in August 2026

- Added an "Annoucement" checkbox to the Button config screen.
- An announcement button runs the command `]readycheck abort <message>:14`, replacing `<message>` with the text configured for that button.
- Announcement buttons do not add `/wb`, `/p`, `/1`, message colors, or the normal start/end decorations.
- Added `/an <message>` as a quick way to run the same announcement command without creating a button.
- Addon configuration is now saved globally, so every character uses the same messages and settings.
- Existing settings are migrated from the first character loaded after this update. Load the character whose configuration you want to keep first.
- Moved the Annoucement checkbox below the Submenu row so the controls do not overlap.

## How to create and use an announcement button

1. Type `/wlh config`.
2. Open the Messages tab.
3. Add a new button or select an existing button and choose Edit.
4. Enter the text to display on the button in Label.
5. Enter the announcement text in Message. Enter only the message itself, not the `]readycheck` command.
6. Tick the "Annoucement" checkbox. Using Type `Normal` and Submenu `None` is recommended.
7. Select OK, then save the Messages configuration.
8. Close the configuration window and type `/wlh show` if the button window is not already visible.
9. Click the button. For example, a Message of `Push in 10 seconds` runs `]readycheck abort Push in 10 seconds:14`.

## How to use the slash command

- Type `/an Push in 10 seconds` to run `]readycheck abort Push in 10 seconds:14`.
- Type `/an` without a message to display the usage reminder.
- While the configuration window is open, clicking an announcement button only prints a preview of the command. It does not run it.

Functionality:

	* type /wlh show to toggle the addon window
	* type /wlh config to open the addons configuration dialog
	
	* Leftclick on a normal message label to broadcast the message to the warband (/wb) channel, or the party (/p) channel when you are not in a warband
	* Rightclick on a normal message label to broadcast the message to the region (/1) channel
	* Click on a "LFM" message to open its submenu. Leftclick on an LFM submenu entry to post it to the LFG (/5) channel, or rightclick it to post it to the region (/1) channel

	* Click on a countdown label to open the countdown submenu. Choosing a time starts the countdown, and clicking the top-level countdown button again while one is active aborts it.

	* Click on a "ZONE" or BO message label to dynamically select a zone or BO. <Z> and <B> in a message text will be replaced with the selected value.

	* Choose AUTO in an LFM submenu to search for missing roles based on your current warband or party automatically, using the current alt-spec settings.
	* Optionally enable AutoBand integration in config. When AutoBand is loaded, WB features are enabled, AutoBand sees you as WB leader, and relevant AutoBand enforcement toggles are active, AUTO LFM follows AutoBand role caps and accepted class icon filters without requiring AutoBand as a dependency. The config tooltip shows a short current status.
	* Hover any button to preview the resolved output or submenu action. Hovering a top-level LFM button also shows the current missing-role summary.

----------------

Installation:

	* Get it from here: https://tools.idrinth.de/addons/wbleadhelper/

-----------------
1.1.0 - Updated as of 8/22/2026
* Added configurable announcement buttons and the `/an <message>` shortcut.
* Announcement commands bypass normal chat channels, colors, and message decorations.
* Changed addon configuration to account-wide global storage with migration from the first loaded character.
* Moved the Annoucement checkbox below the Submenu row and added usage documentation.
* Fixed the Button config OK button failing because its empty-text helper was missing.

1.0.9 - Updated as of 4/26/2026
* Added hover previews on buttons and submenu entries so you can see the resolved chat output or submenu action before clicking.
* LFM hover previews now show the expanded result, including AUTO role text, icons, zone replacement, and leader tag replacement.
* Top-level LFM hover now combines the new preview text with the existing missing-role summary.
* Fixed permanent colored chat mangling `@name` mentions and prelinked `<LINK ...>` chat tokens.
* Fixed the config tab separator extending past the right edge of the window.
* Added optional AutoBand integration for AUTO LFM.

1.0.8 - Updated as of 4/17/2026
* Fixed saved settings not loading reliably by declaring the saved-variables version in addon metadata.
* Prevented fallback sessions from overwriting existing saved settings on logout before a real settings table is loaded.

1.0.7 - Updated as of 4/15/2026
* Cleaned up the leftover middle-click hook from the 1.0.6 LFM /5 changes.
* Added AUTO LFM alt-spec detection so missing-role counts can treat flagged hybrid healers as DPS when appropriate.
* Added config options to disable alt-spec detection entirely or ignore RP/Zealot alt-spec flags only.

1.0.6 - Updated as of 11/25/2025
* Removed middle click and fixed /5 for LFM messages.

1.0.5 - Updated as of 11/5/2025
* Added middle click to send to /5 for LFM message.

1.0.4 - Updated as of 9/19/2025
* Added a Clone button to the Messages tab so existing messages can be duplicated quickly.
* Cloned entries auto-increment their label suffix to keep names unique.

1.0.3 - Updated as of 9/18/2025
* Fixed some move to zones not sending to chat (Thanks Sedetra for reporting that)

1.0.2 - Updated as of 9/17/2025
* Added smart channels so it can be used in party as well as warband

1.0.1 - Updated as of 9/16/2025
* Fixed small alignment issue with header

1.0.0 - Updated as of 9/16/2025
* Added BOs for T1-3 zones that are linked together (see pics)
* Added all but T1 zones to "Move to" zone button
* Organized BOs a little (go top to bottom or left to right depending on the zone)
* Moved keeps and posterns to their own column to clean up the UI.
* Changed height and width slightly to make a little more room for the longer names.


0.9.9 - Updated as of 9/14/2025
* Fixed my "fix" on the way zones are excluded from getting common BOs like keep and postern

0.9.8 - Updated as of 9/14/2025
* Added LotD BOs, changed the way zones are excluded from getting common BOs like keep and postern

0.9.7 - Updated as of 7/05/2022
* Fixed 2/2/2 auto search

0.9.6 - Updated as of 5/26/2022
* Chat channels can now be set in each message
* Bugfixes

0.9.5
* The LFG submenu is now editable as well.
* The AUTO group scan feature got more flexible. You can now define the number of missing roles you are looking for (Good for none warbands).
* Added help tooltips in more places.

0.9.1
* A tooltip with needed roles is now shown when hovering the *LFM* button.
* Line breaks in message labels are now done with <nl> not <br> anymore
* Some smaller bug fixes

0.9 - Updated as of 5/06/2022.
* A full config UI was added. Messages can now be added and changed from withing the game.
* Added AUTO looking for players search. It scans your warband and puts out a message with missing roles (healers, tanks, dps)
* Messages are in different colors now
* Reorderd the message labels to make them more intuitive to use
* Some small adjustments

0.7 - Updated as of 7/22/2020.
* Added "Color Mode", to be able to chat colored all the time.

0.6.5 - Updated as of 7/16/2020.
* Button text can now be colored
* Added "back" button to submenus
* Realigned text in buttons to better fit
* Submenus are now better recognizable

0.6 - Updated as of 7/13/2020.
* Added button to shout out a BO 
* Added a "Looking for Members" button which post to the /5 LFG channel on left click. Or to /1 on right click.
* Some bug fixes and code optimizations

0.5 - Updated as of 6/24/2020.
* Reworked countdown functionality

0.4 - Updated as of 6/24/2020.
* Improved window scaling
* Added more messages
* Added a new layout (two button rows) 
* Added mouse over button color change 

0.3 - Updated as of 6/06/2020.
* Added a Zone announcement message

0.2.3 - Updated as of 6/04/2020.
* Added a variable at the top of the document to make it possible to change the size of the window

0.2.2 - Updated as of 6/03/2020.
* Added a variable at the top of the document to make changing the text color easier

0.2 - Updated as of 6/02/2020.
* Initial Release
