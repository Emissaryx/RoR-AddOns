local tinsert = table.insert
local tsort = table.sort
local ipairs = ipairs
local pairs = pairs

--WbLeadHelperMessage class
WbLeadHelperMessage = {}
WbLeadHelperMessage.__index = WbLeadHelperMessage

function WbLeadHelperMessage.New (data)
	local obj = {}
	setmetatable (obj, WbLeadHelperMessage)

	-- defaults
	obj.label = nil
	obj.labelColor = 1
	obj.message = nil
	obj.messageColor = 1
	obj.type = 1
	obj.isNotEnabled = false
	
	if (data)
	then
		obj:Load (data)
	end

	return obj
end


function WbLeadHelperMessage:Load (data)

	self.label = data.label
	self.labelColor = data.labelColor
	self.message = data.message
	self.messageColor = data.messageColor
	self.type = data.type
	self.isNotEnabled = data.isNotEnabled

end


function WbLeadHelperMessage:Edit (onOkCallback)
	WbLeadHelperMessage.MessageDialogOpen (self, self.id, function (old, new)
		old:Load (new)
		if (onOkCallback) then
			onOkCallback (self)
		end
	end)
end


function WbLeadHelperMessage:Remove ()
end

----------------------------------------------------------------- UI: Click casting dialog
local message_dlg = {
	isInitialized = false,
	colors = {}
}

function WbLeadHelperMessage.MessageDialogIsOpen ()
	return WindowGetShowing ("WbLeadHelperMessage")
end

function  WbLeadHelperMessage.MessageDialogHide ()
	WindowSetShowing ("WbLeadHelperMessage", false)
end

function WbLeadHelperMessage.MessageDialogOpen (data, ignoreId, onOkCallback)

	message_dlg.isLoading = true

	if (not message_dlg.isInitialized) then
		-- initialize dialog UI
		CreateWindow ("WbLeadHelperMessage", false)

		LabelSetText ("WbLeadHelperMessageTitleBarText", L"Button config")
		ButtonSetText ("WbLeadHelperMessageOkButton", L"OK")
		ButtonSetText ("WbLeadHelperMessageCancelButton", L"Cancel")

		LabelSetText ("WbLeadHelperMessageContentScrollChildLabelLabel", L"Label:")
		LabelSetText ("WbLeadHelperMessageContentScrollChildLabelColor", L"Label color:")
		local i = 1
		for k,v in pairs(wbLeadHelper.Colors) do
			ComboBoxAddMenuItem ("WbLeadHelperMessageContentScrollChildLabelColorCombobox", towstring(k))
			message_dlg.colors[i] = k
			i = i + 1
		end

		LabelSetText ("WbLeadHelperMessageContentScrollChildMessageLabel", L"Message:")
		LabelSetText ("WbLeadHelperMessageContentScrollChildMessageColor", L"Message color:")
		for k,v in pairs(wbLeadHelper.Colors) do
			ComboBoxAddMenuItem ("WbLeadHelperMessageContentScrollChildMessageColorCombobox", towstring(k))
		end

		LabelSetText ("WbLeadHelperMessageContentScrollChildTypeLabel", L"Type:")
		for i=1, #wbLeadHelper.messageTypes do
			ComboBoxAddMenuItem ("WbLeadHelperMessageContentScrollChildTypeCombobox", towstring(wbLeadHelper.messageTypes[i]))
		end

		message_dlg.isInitialized = true
	end

	-- proceed parameters
	message_dlg.oldData = data
	message_dlg.onOkCallback = onOkCallback

	message_dlg.data = WbLeadHelperMessage.New (data)

	-- fill form with existing data if available
	TextEditBoxSetText ("WbLeadHelperMessageContentScrollChildLabelText",towstring( wbLeadHelper.isNil( message_dlg.data.label, L"")))
	if type(message_dlg.data.labelColor) ~= "number" then
		message_dlg.data.labelColor = wbLeadHelper.indexOf(message_dlg.colors, message_dlg.data.labelColor)
	end
	ComboBoxSetSelectedMenuItem ("WbLeadHelperMessageContentScrollChildLabelColorCombobox", message_dlg.data.labelColor)

	TextEditBoxSetText ("WbLeadHelperMessageContentScrollChildMessageText",towstring( wbLeadHelper.isNil( message_dlg.data.message, L"")))
	if type(message_dlg.data.messageColor) ~= "number" then
		message_dlg.data.messageColor = wbLeadHelper.indexOf(message_dlg.colors, message_dlg.data.messageColor)
	end
	ComboBoxSetSelectedMenuItem ("WbLeadHelperMessageContentScrollChildMessageColorCombobox", message_dlg.data.messageColor)

	if type(message_dlg.data.type) ~= "number" then
		message_dlg.data.type = wbLeadHelper.indexOf(wbLeadHelper.messageTypes, message_dlg.data.type)
	end
	ComboBoxSetSelectedMenuItem ("WbLeadHelperMessageContentScrollChildTypeCombobox", message_dlg.data.type)


	message_dlg.isLoading = false
	WindowSetShowing ("WbLeadHelperMessage", true)

	ScrollWindowSetOffset ("WbLeadHelperMessageContent", 0)
	ScrollWindowUpdateScrollRect ("WbLeadHelperMessageContent")
end

function WbLeadHelperMessage.OnOk ()

	if (message_dlg.isLoading or not WbLeadHelperMessage.MessageDialogIsOpen()) then return end

	message_dlg.data.label = wbLeadHelper.isEmpty (TextEditBoxGetText ("WbLeadHelperMessageContentScrollChildLabelText"), nil)
	message_dlg.data.label = tostring( message_dlg.data.label )
	message_dlg.data.labelColor = ComboBoxGetSelectedMenuItem ("WbLeadHelperMessageContentScrollChildLabelColorCombobox")
	message_dlg.data.labelColor = message_dlg.colors[message_dlg.data.labelColor]
	message_dlg.data.labelColor = tostring( message_dlg.data.labelColor )
	message_dlg.data.message = wbLeadHelper.isEmpty (TextEditBoxGetText ("WbLeadHelperMessageContentScrollChildMessageText"), nil)
	message_dlg.data.message = tostring( message_dlg.data.message )
	message_dlg.data.messageColor = ComboBoxGetSelectedMenuItem ("WbLeadHelperMessageContentScrollChildMessageColorCombobox")
	message_dlg.data.messageColor = message_dlg.colors[message_dlg.data.messageColor]
	message_dlg.data.messageColor = tostring( message_dlg.data.messageColor )	
	message_dlg.data.type = ComboBoxGetSelectedMenuItem ("WbLeadHelperMessageContentScrollChildTypeCombobox")
	message_dlg.data.type = wbLeadHelper.messageTypes[message_dlg.data.type]
	message_dlg.data.type = tostring( message_dlg.data.type )

	if (not message_dlg.data.label) then
		DialogManager.MakeOneButtonDialog (L"You must enter a label.", L"Ok")
		return
	end

	if (message_dlg.onOkCallback) then
		message_dlg.onOkCallback (message_dlg.oldData, message_dlg.data)
	end

	WbLeadHelperMessage.MessageDialogHide()
end