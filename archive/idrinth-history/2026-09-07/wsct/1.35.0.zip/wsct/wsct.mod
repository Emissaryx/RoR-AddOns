<?xml version="1.0" encoding="UTF-8"?>

<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" >

	<UiMod name="WSCT" version="1.35" date="10/13/2008" >

		<Author name="Grayhoof" email="" />
		
		<VersionSettings gameVersion="1.3.3" windowsVersion="1.0" savedVariablesVersion="1.0" />

		<Description text="Warhammer Scrolling Combat Text" />

		<Dependencies>
			<Dependency name="EASystem_Utils" />
			<Dependency name="EASystem_EventText" />
			<Dependency name="EA_SiegeWeaponWindow" />
			<Dependency name="EA_ChatWindow" />
			<Dependency name="EA_CareerResourcesWindow" />
		</Dependencies>

		<Files>
			<File name="wsct.xml" />
			<File name="wsct.lua" />
			<File name="wsct_config.lua" />
			<File name="locals/localization.lua" />
			<File name="wsct_animation.lua" />
			<File name="wsct_options/wsct_options.xml" />
			<File name="wsct_options/locals/localization.lua" />
			<File name="wsct_options/wsct_options_setup.lua" />
			<File name="wsct_options/wsct_options.lua" />
		</Files>

		<OnInitialize>
		  <CreateWindow name="WSCTContainer" show="true" />
			<CallFunction name="WSCT.OnInitialize" />
		</OnInitialize>

		<OnUpdate>
			<CallFunction name="WSCT.UpdateAnimation" />
		</OnUpdate>

		<OnShutdown>
			<CallFunction name="WSCT.OnShutdown" />
		</OnShutdown>

		<SavedVariables>
			<SavedVariable name="WSCT_CONFIG" />
		</SavedVariables>
	<WARInfo>
			<Categories>
				<Category name="SYSTEM" />
			</Categories>
			<Careers>
				<Career name="BLACKGUARD" />
				<Career name="WITCH_ELF" />
				<Career name="DISCIPLE" />
				<Career name="SORCERER" />
				<Career name="IRON_BREAKER" />
				<Career name="SLAYER" />
				<Career name="RUNE_PRIEST" />
				<Career name="ENGINEER" />
				<Career name="BLACK_ORC" />
				<Career name="CHOPPA" />
				<Career name="SHAMAN" />
				<Career name="SQUIG_HERDER" />
				<Career name="WITCH_HUNTER" />
				<Career name="KNIGHT" />
				<Career name="BRIGHT_WIZARD" />
				<Career name="WARRIOR_PRIEST" />
				<Career name="CHOSEN" />
				<Career name= "MARAUDER" />
				<Career name="ZEALOT" />
				<Career name="MAGUS" />
				<Career name="SWORDMASTER" />
				<Career name="SHADOW_WARRIOR" />
				<Career name="WHITE_LION" />
				<Career name="ARCHMAGE" />
			</Careers>
	</WARInfo>

	</UiMod>

</ModuleFile>