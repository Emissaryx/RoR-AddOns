<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
	<UiMod name="TheSeeker" version="0.15.5" date="31/05/2009" >
		<Author name="Computerpunk" email="teromario@yahoo.com" />
		<Description text="The seeker searches targets based on a string and notifies you when it is found." />
		<VersionSettings gameVersion="1.3.3" windowsVersion="1.2" savedVariablesVersion="1.2" />
		<Dependencies>
		  <Dependency name="LibSlash"/>
		</Dependencies>
		<Files>
			<File name="theseekr.xml" />
			<File name="TargetInfoFix.lua" />
			<File name="TheSeeker.lua" />
		</Files>
		<SavedVariables>
			<SavedVariable name="SeekerData"/>
		</SavedVariables>
		<OnInitialize>
			<CallFunction name="Seeker.Initialize" />
		</OnInitialize>
		<OnUpdate>
			<CallFunction name="Seeker.UpdateMarkers"/>
		</OnUpdate>

		<WARInfo>
	<Categories>
		<Category name="RVR" />
		<Category name="COMBAT" />
		<Category name="QUESTS" />
		<Category name="MAP" />
		<Category name="OTHER" />
	</Categories>
	<Careers>
		<Career name="BLACKGUARD" />
		<Career name="WITCH_ELF" />
		<Career name="DISCIPLE" />
		<Career name="SORCERER" />
		<Career name="IRON_BREAKER" />
		<Career name="SLAYER" />
		<Career name="RUNE_PRIEST" />
		<Career name="ENGINEER" />
		<Career name="BLACK_ORC" />
		<Career name="CHOPPA" />
		<Career name="SHAMAN" />
		<Career name="SQUIG_HERDER" />
		<Career name="WITCH_HUNTER" />
		<Career name="KNIGHT" />
		<Career name="BRIGHT_WIZARD" />
		<Career name="WARRIOR_PRIEST" />
		<Career name="CHOSEN" />
		<Career name= "MARAUDER" />
		<Career name="ZEALOT" />
		<Career name="MAGUS" />
		<Career name="SWORDMASTER" />
		<Career name="SHADOW_WARRIOR" />
		<Career name="WHITE_LION" />
		<Career name="ARCHMAGE" />
	</Careers>
		</WARInfo>
	</UiMod>
</ModuleFile>