if not Seeker then Seeker = {} end
local Seeker, version = Seeker, "0.15 Beta"
local SeekerWindow = "TheSeekerWindow"
local GetScenarioPlayers, ipairs, tostring, upper, find, gsub, towstring, DetachWindowFromWorldObject,
	  setmetatable, tonumber, MoveWindowToWorldObject, WindowGetAlpha, DoesWindowExist, PlaySound,
	  CreateWindowFromTemplate, AnimatedImageStartAnimation, WindowStopAlphaAnimation, DynamicImageSetTexture,
	  WindowSetShowing, WindowSetAlpha, WindowStartAlphaAnimation, match = 
	  GameData.GetScenarioPlayers, ipairs, tostring, string.upper, string.find, string.gsub, towstring, DetachWindowFromWorldObject,
	  setmetatable, tonumber, MoveWindowToWorldObject, WindowGetAlpha, DoesWindowExist, PlaySound,
	  CreateWindowFromTemplate, AnimatedImageStartAnimation, WindowStopAlphaAnimation, DynamicImageSetTexture,
	  WindowSetShowing, WindowSetAlpha, WindowStartAlphaAnimation, string.match

-- Thanks to randomage for the gmatch function in PlanB
local gmatch = function(str, pattern)
	local init = 1
	local function gmatch_it()
		if init <= str:len() then
			local s, e = str:find(pattern, init)
			if s then
				local res = { str:match(pattern, init) }
				init = e+1
				return unpack(res)
			end
		end
	end
	return gmatch_it
end

local function SetDefaults()
	SeekerData = {DATA_VER = 6, TERM = nil , ON = true, ACHAT = true, ASOUND = true, ASCREEN = true, AHOVER = true,
				  FADE = true, FADE_VAL = 10, AONCE = false, MAX_TAGS = 1, SELF = false, ALLIES = false, COMBAT = true}
end

--Ripped from BlackBook.  I was using this thinking it was part of the global lua
--defined by WAR I didn't realize it was from an addon.. bad addon...bad me.
local function trim(s)
	if not s then return "" end
	return (gsub(s, "^%s*(.-)%s*$", "%1"))
end

local function print(msg)
	EA_ChatWindow.Print(towstring(msg))
end

local function ConvertData()
	if not SeekerData.DATA_VER or SeekerData.DATA_VER ~= 7 then
		print("Seeker is updating your save format.")
	end
	--First beta data, or corrupted
	if not SeekerData.DATA_VER then
		if not SeekerData.TERM then 
			print("Resetting Seeker to default.")
			SetDefaults()
		end
		SeekerData.DATA_VER = 1
		SeekerData.ON = true
		SeekerData.ASOUND = true
		SeekerData.ACHAT = true
		SeekerData.ASCREEN = true
	end

	if SeekerData.DATA_VER == 1 then
		SeekerData.DATA_VER = 2
		SeekerData.AHOVER = true
	end

	if SeekerData.DATA_VER == 2 then
		SeekerData.DATA_VER = 3
		SeekerData.FADE = true
		SeekerData.FADE_VAL = 10
	end

	if SeekerData.DATA_VER == 3 then
		SeekerData.DATA_VER = 4
		SeekerData.AONCE = false
	end

	if SeekerData.DATA_VER == 4 then
		SeekerData.DATA_VER = 5
		SeekerData.MAX_TAGS = 1
	end

	if SeekerData.DATA_VER == 5 then
		SeekerData.DATA_VER = 6
		SeekerData.SELF = false
		SeekerData.ALLIES = false
	end

	if SeekerData.DATA_VER == 6 then
		SeekerData.DATA_VER = 7
		SeekerData.COMBAT = true
	end
end

local CareerToArchtype = 
{	["Ironbreaker"] = "tank", ["Knight of the Blazing Sun"] = "tank", ["Swordmaster"] = "tank",
	["Blackguard"] = "tank", ["Chosen"] = "tank", ["Black Orc"] = "tank",

	["Rune Priest"] = "heal", ["Archmage"] = "heal", ["Warrior Priest"] = "heal",
	["Zealot"] = "heal", ["Shaman"] = "heal", ["Disciple of Khaine"] = "heal",

	["Engineer"] = "rdps", ["Bright Wizard"] = "rdps", ["Shadow Warrior"] = "rdps",
	["Magus"] = "rdps", ["Sorcerer"] = "rdps", ["Sorceress"] = "rdps", ["Squig Herder"] = "rdps",

	["Witch Hunter"] = "mdps", ["White Lion"] = "mdps", ["Choppa"] = "mdps",
	["Witch Elf"] = "mdps", ["Marauder"] = "mdps", ["Slayer"] = "mdps", }

Seeker.playersIdData = {}
function Seeker.UpdatePlayerData()   
	local interimPlayerData = GetScenarioPlayers()
	if (interimPlayerData ~= nil) then
		for key, value in ipairs(interimPlayerData) do
			--setup or update player data
			local pTable
			local name = tostring(value.name):match("([^^]+)^?([^^]*)") 
			if Seeker.playersIdData[name] then
				pTable = Seeker.playersIdData[name]
			else
				pTable = {}
			end
			pTable.name = name
			pTable.career = value.career
			pTable.rank = value.rank
			pTable.realm = value.realm
			pTable.solokills = value.solokills
			pTable.groupkills= value.groupkills
			pTable.renown = value.renown
			pTable.deaths = value.deaths
			pTable.damagedealt = value.damagedealt
			pTable.deathblows = value.deathblows
			pTable.healingdealt = value.healingdealt
			pTable.renownbonus = value.renownbonus
			pTable.experience = value.experience
			pTable.careerIcon = Icons.GetCareerIconIDFromCareerNamesID(value.careerId)
			local sstring = tostring(GetCareerName(value.careerId, 1)):match("([^^]+)^?([^^]*)")
			local career = sstring:match("([^^]+)^?([^^]*)")
			sstring = sstring..CareerToArchtype[career]
			sstring = sstring..name
			pTable.sstring = upper(sstring) 
			--Shouldn't have to update the PlayersIdData id map because pTable would
			--be the same if it already exists...saving time by just assigning vs
			--checking..about the same time.
			Seeker.playersIdData[name] = pTable
		end
	end
end

if not SeekerData then
	SetDefaults()
end

function Seeker.AnnounceWarn()
	if not SeekerData.AHOVER and not SeekerData.ACHAT and not SeekerData.ASCREEN and not SeekerData.ASOUND then
		print("Seeker has all announcing methods disabled")
	end
end

function Seeker.Toggle()
	local status = "ON"
	SeekerData.ON = not SeekerData.ON
	if not SeekerData.ON then
		WindowSetShowing(SeekerWindow, false)
		if Seeker.OldTarget then DetachWindowFromWorldObject(SeekerWindow, Seeker.OldTarget) end
		Seeker.OldTarget = nil
		status = "OFF"
	end
	print("Seeker is now "..status)
end

function Seeker.AnnounceSetting(setting)
	if setting == "OFF" then 
		print("Seeker is turning all announcements OFF")
		SeekerData.ACHAT = false
		SeekerData.ASCREEN = false
		SeekerData.ASOUND = false
		SeekerData.AHOVER = false
	elseif setting == "ON" then 
		print("Seeker is turning all announcements ON")
		SeekerData.ACHAT = true
		SeekerData.ASCREEN = true
		SeekerData.ASOUND = true
		SeekerData.AHOVER = true
	elseif setting == "CHAT" then
		SeekerData.ACHAT = not SeekerData.ACHAT
		print("Seeker is now announcing to CHAT: "..tostring(SeekerData.ACHAT))
	elseif setting == "SCREEN" then
		SeekerData.ASCREEN = not SeekerData.ASCREEN
		print("Seeker is now announcing to SCREEN: "..tostring(SeekerData.ASCREEN))
	elseif setting == "SOUND" then
		SeekerData.ASOUND = not SeekerData.ASOUND
		print("Seeker is now announcing with SOUND: "..tostring(SeekerData.ASOUND))
	elseif setting == "HOVER" then
		SeekerData.AHOVER = not SeekerData.AHOVER
		print("Seeker is now announcing with HOVER: "..tostring(SeekerData.AHOVER))
		-- We want this false no matter what when the setting is toggled.
		Seeker.Cleanup()
	elseif setting == "ONCE" then
		SeekerData.AONCE = not SeekerData.AONCE
		print("Seeker is now announcing only once: "..tostring(SeekerData.AONCE))
		-- We want this false no matter what when the setting is toggled.
		Seeker.Cleanup()
	elseif setting == "FADE" then
		SeekerData.FADE = not SeekerData.FADE
		print("Seeker FADE: "..tostring(SeekerData.FADE))
		-- We want this false no matter what when the setting is toggled.
		Seeker.Cleanup()
	elseif setting == "SELF" then
		SeekerData.SELF = not SeekerData.SELF
		print("Seeker SELF: "..tostring(SeekerData.SELF))
		-- We want this false no matter what when the setting is toggled.
		Seeker.Cleanup()
	elseif setting == "ALLIES" then
		SeekerData.ALLIES = not SeekerData.ALLIES
		print("Seeker ALLIES: "..tostring(SeekerData.ALLIES))
		-- We want this false no matter what when the setting is toggled.
		Seeker.Cleanup()
	elseif setting == "COMBAT" then
		SeekerData.COMBAT = not SeekerData.COMBAT
		print("Seeker COMBAT: "..tostring(SeekerData.COMBAT))
		-- We want this false no matter what when the setting is toggled.
		Seeker.Cleanup()
	end
	Seeker.AnnounceWarn()
end
--Terms with a meta table.
Seeker.Terms = {}
Seeker.TermsMeta = 
{__index = function (t, str) 
	local term2, term1
	term1, term2 = match(str, "^(.*)|(.*)")

	if term1 and term2 then
		t[upper(str)] = {upper(term1), unpack(t[term2])}
	elseif term1 ~= nil then
		t[upper(str)] = {upper(term1)}
	else
		t[upper(str)] = {upper(str)}
	end

	return t[upper(str)]
end}
setmetatable(Seeker.Terms, Seeker.TermsMeta)

function Seeker.SetTerm(term)
	SeekerData.TERM = trim(term)
	if SeekerData.TERM == "" then 
		SeekerData.TERM = 0
		print("Must supply a term; searching is disabled")
		return
	end
	if not SeekerData.ON then
		Seeker.Toggle()
	end
	print("Seeker is searching for: "..term)
end

function Seeker.ShowSettings(long)
	print("Seeker v"..version.." loaded")
	if SeekerData.TERM then 
		if SeekerData.ON then print("Seeker is enabled; searching for: "..SeekerData.TERM) 
		else print("Seeker is disabled; current search term: "..SeekerData.TERM) end
	elseif not SeekerData.ON then
		print("Seeker is OFF.")
	else
		print("Seeker is ON, but disabled due to no search term, use /seekfor <term>") 
	end
	Seeker.AnnounceWarn()

	print("Seeker Help: /seek")
	if not long then return end
	print("Announce CHAT: "..tostring(SeekerData.ACHAT))
	print("Announce SCREEN: "..tostring(SeekerData.ASCREEN))
	print("Announce SOUND: "..tostring(SeekerData.ASOUND))
	print("Announce HOVER: "..tostring(SeekerData.AHOVER))
	print("Announce ONCE: "..tostring(SeekerData.AONCE))
	print("TAG FADE: "..tostring(SeekerData.FADE))
	print("TAG FADE DELAY: "..SeekerData.FADE_VAL.."s")
	print("TAGS: "..SeekerData.MAX_TAGS)
	print("ALLIES: "..tostring(SeekerData.ALLIES))
	print("SELF: "..tostring(SeekerData.SELF))
	print("COMBAT: "..tostring(SeekerData.COMBAT))
end

function Seeker.PrintHelp()
	print("Seeker v"..version.." commands:")
	print("/seekfor <term>: Searches for <term>, toggle Seeker if disabled")
	print("/seek: Shows this help")
	print("/seek defaults: Resets to defaults: announce = ALL, term = nil, and ON")
	print("/seek toggle: Toggles the Seeker on/off.")
	print("/seek announce chat: Toggles announcing in chat")
	print("/seek announce screen: Toggles announcing on screen")
	print("/seek announce sound: Toggles sound on announcing")
	print("/seek announce hover: Toggles firey hover on announcing")
	print("/seek announce once: Only announces once per entity if true")
	print("/seek announce ALL: Announcing with everything")
	print("/seek announce OFF: Sets all announcing types off")
	print("/seek announce ON: Sets all announcing types on")
	print("/seek TAG FADE: Toggles tag fading on delay")
	print("/seek TAG <num>: How many seconds need to pass before the tags fade")
	print("/seek TAGS <num>: How many targets to tag at once")
	print("/seek SELF: Include self in search")
	print("/seek ALLIES: Include allied players")
	print("/seek COMBAT: Toggles seeking in combat")
	print("/seek show: Shows the current settings")
end

function Seeker.CallOption(val)
	if not val or val == "" then
		Seeker.PrintHelp()
		return
	end
	local i, args = 1, {}

	for w in gmatch(val, "%w+") do 
		args[i] = upper(w)
		i = i + 1
	end 
	i = i - 1

	if i == 1 then
		if args[1] == "DEFAULTS" then
			SetDefaults()
			print("Seeker settings have been set to defaults")
		elseif args[1] == "TOGGLE" then
			Seeker.Toggle()
		elseif args[1] == "SHOW" then
			Seeker.ShowSettings(true)
		elseif args[1] == "SELF" or args[1] == "ALLIES" or args[1] == "COMBAT" then
			Seeker.AnnounceSetting(args[1])
		end
	elseif i == 2 then
		if args[1] == "ANNOUNCE" then
			if args[2] == "ONCE" or args[2] == "HOVER" or args[2] == "CHAT" or args[2] == "SCREEN" 
			or args[2] == "SOUND" or args[2] == "ON" or args[2] == "OFF" then
				Seeker.AnnounceSetting(args[2])
			end
		elseif args[1] == "TAG" then
			if args[2] == "FADE" then
				Seeker.AnnounceSetting(args[2])
			else
				local val = tonumber(args[2])
				if val and val > 0 then
					SeekerData.FADE_VAL = val
					print("Seeker TAG fade delay set to "..(args[2]).." seconds")
				end
			end
		elseif args[1] == "TAGS" then
			local val = tonumber(args[2])
			if val and val > -1 then
				SeekerData.MAX_TAGS = val
				print("Seeker amount of tags is now set to "..(args[2]))
			end
		end
	else
		print("Unknown command, to see a list use /seek.")
	end
end

Seeker.tagWindows = {}
local tagLoc = 0
local threadSafe2 = true
--attach to window is funky sometimes, move to is much more reliable in my testing
function Seeker.UpdateMarkers()
	for key, val in ipairs(Seeker.tagWindows) do
		MoveWindowToWorldObject(SeekerWindow..key, val, 1.0)
	end
end

function Seeker.Announce(name, targetId, type_, isPlayer)
--[[If the seeker is continously seeking we don't want to announce something selected already
	If Target exists
	Window exists
	Window is still showing]]
	if not SeekerData.AONCE and Seeker.tagWindows["T"..targetId] and DoesWindowExist(SeekerWindow..Seeker.tagWindows["T"..targetId])
	and WindowGetAlpha(SeekerWindow..Seeker.tagWindows["T"..targetId]) ~= 0 then return --else we should clean up because an option is changed
	elseif Seeker.tagWindows["T"..targetId]  and SeekerData.MAX_TAGS ~= 0 and Seeker.tagWindows["T"..targetId] > SeekerData.MAX_TAGS then
		local tag = Seeker.tagWindows["T"..targetId]
		Seeker.tagWindows[tag] = nil
		Seeker.tagWindows["T"..targetId] = nil
	end

	if SeekerData.AONCE then SeekerData.ON = false end
	if not SeekerData.SELF and SystemData.TargetObjectType.SELF == type_ then return end
	if not SeekerData.ALLIES and SystemData.TargetObjectType.ALLY_PLAYER == type_ then return end
	local announce = "*** SEEKER FOUND: "..name.." ***"
	if SeekerData.ACHAT then print(announce) end
	if SeekerData.ASOUND then PlaySound(GameData.Sound.QUEST_ABANDONED) end
	if SeekerData.ASCREEN then 
		local alert = { alertTypes = {}, alertTexts = {} }
		alert.alertTypes[1] = SystemData.AlertText.Types.QUEST_END
		alert.alertTexts[1] = towstring(announce)
		AlertTextWindow.SetAlertData (alert.alertTypes, alert.alertTexts)
	end
	--If we should be generating a tag or not
	if SeekerData.AHOVER and  SystemData.TargetObjectType.STATIC_ATTACKABLE ~= type_ and SystemData.TargetObjectType.STATIC ~= type_ 
	then --Not static
		tagLoc = tagLoc + 1 --Increase our marker value.
		if SeekerData.MAX_TAGS < tagLoc and SeekerData.MAX_TAGS ~= 0 then tagLoc = 1 end --If we exceeded the limit, return to the beginning
		if not DoesWindowExist(SeekerWindow..tagLoc) then
			CreateWindowFromTemplate(SeekerWindow..tagLoc, SeekerWindow, "Root")
			AnimatedImageStartAnimation(SeekerWindow..tagLoc.."Anim", 0, true, false, 0.0)
		end
		if Seeker.tagWindows[tagLoc] then
			Seeker.tagWindows["T"..Seeker.tagWindows[tagLoc]] = nil
			Seeker.tagWindows[tagLoc] = nil
		end
		--Setup lookup table for tag
		Seeker.tagWindows[tagLoc] = targetId
		Seeker.tagWindows["T"..targetId] = tagLoc
		WindowStopAlphaAnimation(SeekerWindow..tagLoc)
		MoveWindowToWorldObject(SeekerWindow..tagLoc, targetId, 1.0)
		if isPlayer then --If it is a player setup class icon
			local texture, x, y = GetIconData(Seeker.playersIdData[name].careerIcon)
			DynamicImageSetTexture(SeekerWindow..tagLoc.."Icon", texture, x, y)
			WindowSetShowing(SeekerWindow..tagLoc.."Anim", false)
			WindowSetShowing(SeekerWindow..tagLoc.."Icon", true)
		else --Setup ring of fire
			WindowSetShowing(SeekerWindow..tagLoc.."Anim", true)
			WindowSetShowing(SeekerWindow..tagLoc.."Icon", false)      
		end
		Seeker.FadeIcon(SeekerWindow..tagLoc, false) --Fade the icon over time, but not now
	end
end

function Seeker.OnTargetChange(classification, targetId, type_)
	TargetInfo:UpdateFromClient() --Must call this to guarantee targets are updated; got broken up but now works with Aiiane's fix
	if type_ == 0 or not Seeker.COMBAT and GameData.Player.inCombat or not SeekerData.ON or not SeekerData.TERM then return end
	-- If type is 0 or disabled setting + in combat or isn't enabled or no term

	name = tostring(TargetInfo:UnitName(classification)):match("([^^]+)^?([^^]*)")
	if not name then return end
	local found = false
	--- All this to support the | in the regexp.
	for key, val in ipairs(Seeker.Terms[SeekerData.TERM]) do
		if not found then
			if Seeker.playersIdData[name] and find(Seeker.playersIdData[name].sstring, ".*"..(val)..".*") then
				found = true
			elseif find(upper(name), ".*"..val..".*") then
				found = true
			end
		end
	end
	if found then return Seeker.Announce(name, targetId, type_, Seeker.playersIdData[name]~= nil) end
end

function Seeker.FadeIcon(window, now)
	if now == nil or now then
		WindowSetAlpha(window, 0)
	else
		WindowSetAlpha(window, 1)
		if SeekerData.FADE then
			WindowStartAlphaAnimation(window, Window.AnimationType.EASE_OUT, 1, 0, 1, true, SeekerData.FADE_VAL, 1)
		end
	end
end

function Seeker.Cleanup()
	tagLoc = 0
	for key, value in ipairs(Seeker.tagWindows) do
		local window = SeekerWindow..key
		WindowStopAlphaAnimation(window)
		WindowSetAlpha(window, 0)
	end
	Seeker.tagWindows = {}
end

function Seeker.Initialize()
	ConvertData()
	LibSlash.RegisterSlashCmd("seekfor", Seeker.SetTerm)
	LibSlash.RegisterSlashCmd("seek", Seeker.CallOption)
	Seeker.ShowSettings(false)
	RegisterEventHandler(SystemData.Events.PLAYER_TARGET_UPDATED, "Seeker.OnTargetChange")
	CreateWindow(SeekerWindow, true)
	WindowSetShowing(SeekerWindow, true)
	WindowSetShowing(SeekerWindow.."Anim", false)
	RegisterEventHandler(SystemData.Events.INTERACT_FLIGHT_TRAVEL, "Seeker.Cleanup")
	AnimatedImageStartAnimation(SeekerWindow.."Anim", 0, true, false, 0.0)
	--Register handlers for scenarios
	RegisterEventHandler(SystemData.Events.SCENARIO_BEGIN,"Seeker.UpdatePlayerData")
	RegisterEventHandler(SystemData.Events.SCENARIO_BEGIN,"Seeker.Cleanup")
	RegisterEventHandler(SystemData.Events.SCENARIO_UPDATE_POINTS, "Seeker.UpdatePlayerData")
	RegisterEventHandler(SystemData.Events.SCENARIO_PLAYERS_LIST_UPDATED, "Seeker.UpdatePlayerData")
	RegisterEventHandler(SystemData.Events.PLAYER_DEATH_CLEARED, "Seeker.Cleanup")
	--Dont really need this one until I support more stats
	--WindowRegisterEventHandler("ScenarioSummaryWindow", SystemData.Events.SCENARIO_PLAYERS_LIST_STATS_UPDATED, "Seeker.UpdatePlayerData")
	RegisterEventHandler("ScenarioSummaryWindow", SystemData.Events.SCENARIO_END, "Seeker.Cleanup")
	d("Seeker loaded")
end
