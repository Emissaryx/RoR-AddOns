ZoneLegends = {
    [161] = { -- The Inevitable City
    {
        label = Atlas.Strings.UndercroftLabel,
        description = Atlas.Strings.UndercroftDescription
    }, {
        label = Atlas.Strings.VipersPitLabel,
        description = Atlas.Strings.VipersPitDescription
    }, {
        label = Atlas.Strings.TheApexLabel,
        description = Atlas.Strings.TheApexDescription
    }, {
        label = Atlas.Strings.CitadelLabel,
        description = Atlas.Strings.CitadelDescription
    }, {
        label = Atlas.Strings.MonolithLabel,
        description = Atlas.Strings.MonolithDescription
    }, {
        label = Atlas.Strings.StablesLabel,
        description = Atlas.Strings.StablesDescription
    }}
    -- Add more zones and their legends as needed
}

ZoneDetails = {
    [1] = {
        name = Atlas.Strings.MarshesOfMadness,
        adjacentZones = {
            north = 2,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 12,
        maxRank = 13
    },
    [2] = {
        name = Atlas.Strings.TheBadlands,
        adjacentZones = {
            north = 3,
            east = nil,
            south = 1,
            west = nil
        },
        minRank = 22,
        maxRank = 23
    },
    [3] = {
        name = Atlas.Strings.BlackCrag,
        adjacentZones = {
            north = 4,
            east = nil,
            south = 2,
            west = nil
        },
        minRank = 30,
        maxRank = 33
    },
    [4] = {
        name = Atlas.Strings.ButchersPass,
        adjacentZones = {
            north = 5,
            east = nil,
            south = 3,
            west = nil
        },
        minRank = 37,
        maxRank = 40
    },
    [5] = {
        name = Atlas.Strings.ThunderMountain,
        adjacentZones = {
            north = nil,
            east = nil,
            south = 4,
            west = nil
        },
        minRank = 34,
        maxRank = 37
    },
    [6] = {
        name = Atlas.Strings.Ekrund,
        adjacentZones = {
            north = nil,
            east = 11,
            south = nil,
            west = 7
        },
        minRank = 1,
        maxRank = 8
    },
    [7] = {
        name = Atlas.Strings.BarakVarr,
        adjacentZones = {
            north = 8,
            east = nil,
            south = 1,
            west = 6
        },
        minRank = 10,
        maxRank = 19
    },
    [8] = {
        name = Atlas.Strings.BlackFirePass,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 20,
        maxRank = 29
    },
    [9] = {
        name = Atlas.Strings.KadrinValley,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 38,
        maxRank = 40
    },
    [10] = {
        name = Atlas.Strings.Stonewatch,
        adjacentZones = {
            north = nil,
            east = nil,
            south = 9,
            west = nil
        },
        minRank = 37,
        maxRank = 40
    },
    [11] = {
        name = Atlas.Strings.MountBloodhorn,
        adjacentZones = {
            north = nil,
            east = 1,
            south = nil,
            west = 6
        },
        minRank = 1,
        maxRank = 7
    },
    [26] = {
        name = Atlas.Strings.Cinderfall,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 34,
        maxRank = 37
    },
    [27] = {
        name = Atlas.Strings.DeathPeak,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 34,
        maxRank = 37
    },
    [30] = {
        name = Atlas.Strings.GatesOfEkrund,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 31,
        maxRank = 40
    },
    [31] = {
        name = Atlas.Strings.MourkainTemple,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 41,
        maxRank = 50
    },
    [32] = {
        name = Atlas.Strings.TheIronclad,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 1,
        maxRank = 10
    },
    [33] = {
        name = Atlas.Strings.DoomfistCrater,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 11,
        maxRank = 20
    },
    [34] = {
        name = Atlas.Strings.ThunderValley,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 21,
        maxRank = 30
    },
    [36] = {
        name = Atlas.Strings.DragonbackPass,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 31,
        maxRank = 40
    },
    [37] = {
        name = Atlas.Strings.BlackCragKeep,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 41,
        maxRank = 50
    },
    [38] = {
        name = Atlas.Strings.BlackFireBasin,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 1,
        maxRank = 10
    },
    [39] = {
        name = Atlas.Strings.LogrinsForge,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 11,
        maxRank = 20
    },
    [41] = {
        name = Atlas.Strings.AltdorfWarQuarters,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 21,
        maxRank = 30
    },
    [42] = {
        name = Atlas.Strings.TheUndercroft,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 31,
        maxRank = 40
    },
    [43] = {
        name = Atlas.Strings.GromrilCrossing,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 41,
        maxRank = 50
    },
    [44] = {
        name = Atlas.Strings.HowlingGorge,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 1,
        maxRank = 10
    },
    [47] = {
        name = Atlas.Strings.TheOldDwarfRoad,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 11,
        maxRank = 20
    },
    [50] = {
        name = Atlas.Strings.HuntersVale,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 21,
        maxRank = 30
    },
    [60] = {
        name = Atlas.Strings.MountGunbad,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 31,
        maxRank = 40
    },
    [61] = {
        name = Atlas.Strings.KarakEightPeaks,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 37,
        maxRank = 40
    },
    [62] = {
        name = Atlas.Strings.KarazAKarak,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 37,
        maxRank = 40
    },
    [63] = {
        name = Atlas.Strings.GunbadNursery,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 11,
        maxRank = 20
    },
    [64] = {
        name = Atlas.Strings.GunbadLab,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 21,
        maxRank = 30
    },
    [65] = {
        name = Atlas.Strings.SquigBoss,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 31,
        maxRank = 40
    },
    [66] = {
        name = Atlas.Strings.GunbadBarracks,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 41,
        maxRank = 50
    },
    [96] = {
        name = Atlas.Strings.KarakEightPeaksDaDeeps,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 1,
        maxRank = 10
    },
    [97] = {
        name = Atlas.Strings.KarazAKarakMiddleDeeps,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 11,
        maxRank = 20
    },
    [100] = {
        name = Atlas.Strings.Norsca,
        adjacentZones = {
            north = nil,
            east = 101,
            south = 106,
            west = nil
        },
        minRank = 1,
        maxRank = 4
    },
    [101] = {
        name = Atlas.Strings.TrollCountry,
        adjacentZones = {
            north = nil,
            east = 108,
            south = 107,
            west = 100
        },
        minRank = 12,
        maxRank = 19
    },
    [102] = {
        name = Atlas.Strings.HighPass,
        adjacentZones = {
            north = nil,
            east = 103,
            south = 108,
            west = 107
        },
        minRank = 26,
        maxRank = 29
    },
    [103] = {
        name = Atlas.Strings.ChaosWastes,
        adjacentZones = {
            north = 104,
            east = nil,
            south = 105,
            west = 102
        },
        minRank = 30,
        maxRank = 33
    },
    [104] = {
        name = Atlas.Strings.TheMaw,
        adjacentZones = {
            north = 161,
            east = nil,
            south = 103,
            west = nil
        },
        minRank = 37,
        maxRank = 40
    },
    [105] = {
        name = Atlas.Strings.Praag,
        adjacentZones = {
            north = 103,
            east = nil,
            south = 109,
            west = 120
        },
        minRank = 34,
        maxRank = 37
    },
    [106] = {
        name = Atlas.Strings.Nordland,
        adjacentZones = {
            north = 100,
            east = 107,
            south = nil,
            west = nil
        },
        minRank = 5,
        maxRank = 9
    },
    [107] = {
        name = Atlas.Strings.Ostland,
        adjacentZones = {
            north = 101,
            east = nil,
            south = 102,
            west = 106
        },
        minRank = 10,
        maxRank = 15
    },
    [108] = {
        name = Atlas.Strings.Talabecland,
        adjacentZones = {
            north = 102,
            east = 109,
            south = nil,
            west = 101
        },
        minRank = 20,
        maxRank = 25
    },
    [109] = {
        name = Atlas.Strings.Reikland,
        adjacentZones = {
            north = 105,
            east = nil,
            south = 110,
            west = 108
        },
        minRank = 38,
        maxRank = 40
    },
    [110] = {
        name = Atlas.Strings.Reikwald,
        adjacentZones = {
            north = 109,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 21,
        maxRank = 30
    },
    [118] = {
        name = Atlas.Strings.TheKrakenSea,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 31,
        maxRank = 40
    },
    [120] = {
        name = Atlas.Strings.WestPraag,
        adjacentZones = {
            north = nil,
            east = 105,
            south = nil,
            west = nil
        },
        minRank = 34,
        maxRank = 37
    },
    [130] = {
        name = Atlas.Strings.Nordenwatch,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 1,
        maxRank = 10
    },
    [131] = {
        name = Atlas.Strings.StonetrollCrossing,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 11,
        maxRank = 20
    },
    [132] = {
        name = Atlas.Strings.TalabecDam,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 21,
        maxRank = 30
    },
    [133] = {
        name = Atlas.Strings.MawOfMadness,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 31,
        maxRank = 40
    },
    [134] = {
        name = Atlas.Strings.ReiklandHills,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 41,
        maxRank = 50
    },
    [135] = {
        name = Atlas.Strings.TwistingTower,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 1,
        maxRank = 10
    },
    [136] = {
        name = Atlas.Strings.BattleForPraag,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 11,
        maxRank = 20
    },
    [137] = {
        name = Atlas.Strings.GrovodCaverns,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 21,
        maxRank = 30
    },
    [138] = {
        name = Atlas.Strings.ReiklandFactory,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 31,
        maxRank = 40
    },
    [139] = {
        name = Atlas.Strings.HighPassCemetery,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 41,
        maxRank = 50
    },
    [141] = {
        name = Atlas.Strings.SacellumArena,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 1,
        maxRank = 10
    },
    [144] = {
        name = Atlas.Strings.OuterDark,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 11,
        maxRank = 20
    },
    [152] = {
        name = Atlas.Strings.TheSewersOfAltdorf,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 21,
        maxRank = 30
    },
    [153] = {
        name = Atlas.Strings.TheSewersOfAltdorf,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 31,
        maxRank = 40
    },
    [154] = {
        name = Atlas.Strings.WarpbladeTunnels,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 41,
        maxRank = 50
    },
    [155] = {
        name = Atlas.Strings.SacellumDungeons,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 1,
        maxRank = 10
    },
    [156] = {
        name = Atlas.Strings.SacellumDungeons,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 11,
        maxRank = 20
    },
    [157] = {
        name = Atlas.Strings.TempleOfSigmar,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 21,
        maxRank = 30
    },
    [158] = {
        name = Atlas.Strings.TheMonolith,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 31,
        maxRank = 40
    },
    [159] = {
        name = Atlas.Strings.TheSacellum,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 41,
        maxRank = 50
    },
    [160] = {
        name = Atlas.Strings.BastionStair,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 1,
        maxRank = 10
    },
    [161] = {
        name = Atlas.Strings.TheInevitableCity,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 1,
        maxRank = 40
    },
    [162] = {
        name = Atlas.Strings.Altdorf,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 21,
        maxRank = 30
    },
    [163] = {
        name = Atlas.Strings.TharIgnan,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 31,
        maxRank = 40
    },
    [164] = {
        name = Atlas.Strings.LordSlaurith,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 41,
        maxRank = 50
    },
    [165] = {
        name = Atlas.Strings.KaarnTheVanquisher,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 1,
        maxRank = 10
    },
    [166] = {
        name = Atlas.Strings.SkullLordVarIthrok,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 11,
        maxRank = 20
    },
    [170] = {
        name = Atlas.Strings.AltdorfPalace,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 21,
        maxRank = 30
    },
    [171] = {
        name = Atlas.Strings.TheScreamingCat,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 31,
        maxRank = 40
    },
    [172] = {
        name = Atlas.Strings.TheEternalCitadel,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 41,
        maxRank = 50
    },
    [174] = {
        name = Atlas.Strings.TheElysium,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 1,
        maxRank = 10
    },
    [175] = {
        name = Atlas.Strings.WindsOfChaos,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 11,
        maxRank = 20
    },
    [176] = {
        name = Atlas.Strings.SigmarsCrypts,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 21,
        maxRank = 30
    },
    [177] = {
        name = Atlas.Strings.WarpbladeTunnels,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 31,
        maxRank = 40
    },
    [178] = {
        name = Atlas.Strings.TheViperPit,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 41,
        maxRank = 50
    },
    [179] = {
        name = Atlas.Strings.TombOfTheVultureLord,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 1,
        maxRank = 10
    },
    [189] = {
        name = Atlas.Strings.BrightWizardCollege,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 11,
        maxRank = 20
    },
    [190] = {
        name = Atlas.Strings.BrightWizardCollege,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 21,
        maxRank = 30
    },
    [191] = {
        name = Atlas.Strings.NecropolisOfZandri,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 31,
        maxRank = 40
    },
    [195] = {
        name = Atlas.Strings.BloodwroughtEnclave,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 41,
        maxRank = 50
    },
    [196] = {
        name = Atlas.Strings.BilerotBurrow,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 1,
        maxRank = 10
    },
    [197] = {
        name = Atlas.Strings.TheBrightWizardCollege,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 11,
        maxRank = 20
    },
    [198] = {
        name = Atlas.Strings.SigmarsHammer,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 21,
        maxRank = 30
    },
    [200] = {
        name = Atlas.Strings.TheBlightedIsle,
        adjacentZones = {
            north = nil,
            east = nil,
            south = 206,
            west = nil
        },
        minRank = 1,
        maxRank = 7
    },
    [201] = {
        name = Atlas.Strings.TheShadowlands,
        adjacentZones = {
            north = 206,
            east = 206,
            south = 207,
            west = nil
        },
        minRank = 10,
        maxRank = 15
    },
    [202] = {
        name = Atlas.Strings.Avelorn,
        adjacentZones = {
            north = 207,
            east = nil,
            south = 208,
            west = 207
        },
        minRank = 20,
        maxRank = 25
    },
    [203] = {
        name = Atlas.Strings.Caledor,
        adjacentZones = {
            north = nil,
            east = 205,
            south = nil,
            west = {208, 204}
        },
        minRank = 30,
        maxRank = 33
    },
    [204] = {
        name = Atlas.Strings.FellLanding,
        adjacentZones = {
            north = nil,
            east = 203,
            south = nil,
            west = nil
        },
        minRank = 37,
        maxRank = 40
    },
    [205] = {
        name = Atlas.Strings.Dragonwake,
        adjacentZones = {
            north = 220,
            east = 209,
            south = nil,
            west = 203
        },
        minRank = 34,
        maxRank = 37
    },
    [206] = {
        name = Atlas.Strings.Chrace,
        adjacentZones = {
            north = 200,
            east = nil,
            south = 201,
            west = 201
        },
        minRank = 8,
        maxRank = 9
    },
    [207] = {
        name = Atlas.Strings.Ellyrion,
        adjacentZones = {
            north = 201,
            east = nil,
            south = 202,
            west = nil
        },
        minRank = 16,
        maxRank = 19
    },
    [208] = {
        name = Atlas.Strings.Saphery,
        adjacentZones = {
            north = 202,
            east = 209,
            south = 203,
            west = nil
        },
        minRank = 26,
        maxRank = 29
    },
    [209] = {
        name = Atlas.Strings.Eataine,
        adjacentZones = {
            north = 208,
            east = 210,
            south = nil,
            west = 205
        },
        minRank = 38,
        maxRank = 40
    },
    [210] = {
        name = Atlas.Strings.ShiningWay,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 37,
        maxRank = 40
    },
    [220] = {
        name = Atlas.Strings.IsleOfTheDead,
        adjacentZones = {
            north = nil,
            east = nil,
            south = 205,
            west = nil
        },
        minRank = 34,
        maxRank = 37
    },
    [230] = {
        name = Atlas.Strings.KhainesEmbrace,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 1,
        maxRank = 10
    },
    [231] = {
        name = Atlas.Strings.PhoenixGate,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 11,
        maxRank = 20
    },
    [232] = {
        name = Atlas.Strings.TorAnroc,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 21,
        maxRank = 30
    },
    [234] = {
        name = Atlas.Strings.SerpentsPassage,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 31,
        maxRank = 40
    },
    [235] = {
        name = Atlas.Strings.DragonsBane,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 41,
        maxRank = 50
    },
    [236] = {
        name = Atlas.Strings.LostTempleOfIsha,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 1,
        maxRank = 10
    },
    [237] = {
        name = Atlas.Strings.CaledorWoods,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 11,
        maxRank = 20
    },
    [238] = {
        name = Atlas.Strings.BloodOfTheBlackCairn,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 21,
        maxRank = 30
    },
    [241] = {
        name = Atlas.Strings.TombOfTheStars,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 31,
        maxRank = 40
    },
    [242] = {
        name = Atlas.Strings.TombOfTheMoon,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 41,
        maxRank = 50
    },
    [243] = {
        name = Atlas.Strings.TombOfTheSky,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 1,
        maxRank = 10
    },
    [244] = {
        name = Atlas.Strings.TombOfTheSun,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 11,
        maxRank = 20
    },
    [252] = {
        name = Atlas.Strings.Altdorf,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 1,
        maxRank = 40
    },
    [253] = {
        name = Atlas.Strings.TheInevitableCity,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 31,
        maxRank = 40
    },
    [260] = {
        name = Atlas.Strings.TheLostVale,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 41,
        maxRank = 50
    },
    [261] = {
        name = Atlas.Strings.FistOfMalekith,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 1,
        maxRank = 10
    },
    [262] = {
        name = Atlas.Strings.Lothern,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 11,
        maxRank = 20
    },
    [274] = {
        name = Atlas.Strings.PyramidOfSettra,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 21,
        maxRank = 30
    }
}
