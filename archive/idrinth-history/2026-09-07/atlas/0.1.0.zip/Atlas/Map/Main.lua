AtlasMap = AtlasMap or {}

local MapSettings = {}

local currentMapZone = GameData.Player.zone

local lastPlayerPosition = {
    x = 0,
    y = 0
}
local isPlayerMoving = false
local isPlayerInCombat = false -- Tracks if the map was visible before combat

local stopMovementTimer = nil -- Timer to reset transparency
local timeSinceLastMovement = 0 -- Tracks time since the last movement

local dynamicDirectionButtons = {} -- Track dynamically created buttons

local wasMapShowing = false -- Tracks if the map was visible before combat

local function GetMapSettings()
    MapSettings = Atlas.Settings and Atlas.Settings.MapWindow
end

local function RegisterEventHandlers()
    RegisterEventHandler(SystemData.Events.PLAYER_ZONE_CHANGED, "AtlasMap.OnZoneChanged")
    RegisterEventHandler(SystemData.Events.LOADING_END, "AtlasMap.OnLoadingEnd")
    RegisterEventHandler(SystemData.Events.RELOAD_INTERFACE, "AtlasMap.OnReloadInterface")
    RegisterEventHandler(SystemData.Events.PLAYER_POSITION_UPDATED, "AtlasMap.OnPlayerPositionUpdated")
    RegisterEventHandler(SystemData.Events.PLAYER_COMBAT_FLAG_UPDATED, "AtlasMap.OnCombatStateChanged")

    WindowRegisterEventHandler("AtlasFrame", SystemData.Events.UPDATE_PROCESSED, "AtlasMap.OnUpdate")
end

local function SetTitleBarText()
    LabelSetText("AtlasFrameTitleBarText", Atlas.Strings.TitleBarText)
end

local function UpdateZoneName()
    Atlas.Utilities.Debug("Updating zone name...")
    local zoneName = (ZoneDetails[currentMapZone] and ZoneDetails[currentMapZone].name) or "Unknown Zone"

    if not DoesWindowExist("AtlasFrameZoneNameLabel") then
        Atlas.Utilities.Debug("AtlasFrameZoneNameLabel does not exist.")
        return
    else
        Atlas.Utilities.Debug("AtlasFrameZoneNameLabel exists.")
        Atlas.Utilities.Debug("Zone name: " .. tostring(zoneName))
    end

    LabelSetText("AtlasFrameZoneNameLabel", towstring(zoneName))
end

local function UpdateLegend()
    Atlas.Utilities.Debug("Updating legend...")
    local legendData = ZoneLegends[currentMapZone]

    if legendData then
        Atlas.Utilities.Debug("Updating legend for zone: " .. tostring(currentZone))

        -- Show the legend frame
        WindowSetShowing("AtlasFrameLegend", true)
        local mapScale = WindowGetScale("AtlasFrame") or 1.0
        WindowSetScale("AtlasFrameLegend", mapScale)

        if DoesWindowExist("AtlasFrameLegendBackground") then
            -- Set the background color to semi-transparent black
            WindowSetTintColor("AtlasFrameLegendBackground", 0, 0, 0) -- RGB values (0, 0, 0 for black)
            WindowSetAlpha("AtlasFrameLegendBackground", 0) -- Alpha value (0.5 for 50% transparency)
        else
            Atlas.Utilities.Debug("AtlasFrameLegendBackground does not exist.")
        end

        -- Clear existing legend items
        for i = 1, #legendData do
            local labelName = "AtlasFrameLegendContentItem" .. i
            if DoesWindowExist(labelName) then
                DestroyWindow(labelName)
            end
        end

        -- Add new legend items
        local startY = 0 -- Starting Y position for the first item
        local spacing = 28 -- Spacing between items
        for i, item in ipairs(legendData) do
            local labelName = "AtlasFrameLegendContentItem" .. i
            CreateWindowFromTemplate(labelName, "DefaultLabel", "AtlasFrameLegendContent")

            -- Set the text for the label
            LabelSetText(labelName, item.label)

            -- Position the label
            WindowClearAnchors(labelName)
            WindowSetScale(labelName, mapScale)
            WindowAddAnchor(labelName, "topleft", "AtlasFrameLegendContent", "topleft", 0, startY)

            -- Attach a unique ID to the label
            WindowSetId(labelName, i)

            -- Update the Y position for the next item
            startY = startY + spacing
        end

        -- Store the legend data for tooltips
        AtlasMap.CurrentLegendData = legendData
    else
        Atlas.Utilities.Debug("No legend data for zone: " .. tostring(currentZone))

        -- Hide the legend frame if no legend data exists
        WindowSetShowing("AtlasFrameLegend", false)
    end
end

local function RegisterMapPins()
    Atlas.mapPinFilters = {{
        label = Atlas.Strings.ObjectivesLabel,
        slice = "FlagNeutral",
        scale = 1.0,
        pins = {SystemData.MapPips.OBJECTIVE}
    }, {
        label = Atlas.Strings.KeepsLabel,
        slice = "Keep-Grayed",
        scale = 0.75,
        pins = {SystemData.MapPips.KEEP}
    }, {
        label = Atlas.Strings.GroupMembersLabel,
        slice = "PlayerCircleGroupmate",
        scale = 1.75,
        pins = {SystemData.MapPips.GROUP_MEMBER}
    }, {
        label = Atlas.Strings.GroupLeaderLabel,
        slice = "PlayerCircleGroupLeader",
        scale = 1.75,
        pins = {SystemData.MapPips.GROUP_LEADER}
    }}

    Atlas.mapPinGutters = {{
        label = Atlas.Strings.ImportantMonstersLabel,
        slice = "BombNeutral",
        scale = 1.0,
        pins = {SystemData.MapPips.IMPORTANT_MONSTER}
    }}
end

local function SetMapTransparency(alpha)
    -- Ensure alpha is set to 1 for Map before setting to the desired value.
    WindowSetAlpha("AtlasFrameMapContainerMapDisplay", 1.0)

    -- Set transparency for the main map components
    WindowSetAlpha("AtlasFrame", alpha)
    WindowSetAlpha("AtlasFrameTitleBar", alpha)
    WindowSetAlpha("AtlasFrameMapContainerMapDisplay", alpha)
    WindowSetAlpha("AtlasFrameLegend", alpha)
    WindowSetAlpha("AtlasFrameLegendContent", alpha)

    WindowSetFontAlpha("AtlasFrameTitleBar", alpha)
    WindowSetFontAlpha("AtlasFrameZoneNameLabel", alpha)

    -- Dynamically set alpha for all directional buttons
    for _, buttonName in ipairs(dynamicDirectionButtons) do
        if DoesWindowExist(buttonName) then
            WindowSetAlpha(buttonName, alpha)
        end
    end
    
    -- Atlas.Utilities.Debug("Current transparency after change: " .. tostring(MapSettings.Transparency))
end

local function InitializeMapDisplay()
    RemoveMapInstance("AtlasFrameMapContainerMapDisplay")
    CreateMapInstance("AtlasFrameMapContainerMapDisplay", SystemData.MapTypes.NORMAL)
end

local function ApplyMapWindowSettings()
    local zoneId = GameData.Player.zone

    Atlas.Utilities.Debug("Zone ID: " .. tostring(zoneId))

    WindowSetMovable("AtlasFrame", true)
end

local function UpdateMap()
    Atlas.Utilities.Debug("Updating map...")
    Atlas.Utilities.Debug("Current map zone: " .. tostring(currentMapZone))
    MapSetMapView("AtlasFrameMapContainerMapDisplay", GameDefs.MapLevel.ZONE_MAP, currentMapZone)
    UpdateZoneName()
    UpdateLegend()

    -- Update directional buttons
    AtlasMap.UpdateDirectionalButtons()

    -- Restore the transparency level
    SetMapTransparency(MapSettings.Transparency)

    Atlas.Utilities.Debug("Map updated with zone: " .. tostring(currentMapZone))
end

local function UpdateMapView()
    -- Update MapDisplay reference
    UpdateMap()
    ApplyMapWindowSettings()
end

local function GenerateTooltip(zone)
    Atlas.Utilities.Debug("Generating tooltip for zone: " .. tostring(zone.name))
    local zoneName = tostring(zone.name)
    local minRank = zone.minRank or 1
    local maxRank = zone.maxRank or 4
    local zoneStatus = "<ZoneStatus>"

    tooltipString = string.format("%s \nRanks: %0d-%0d\n %s", zoneName, minRank, maxRank, zoneStatus)
    Atlas.Utilities.Debug("Tooltip string: " .. tooltipString)

    return towstring(tooltipString)
end

local function LayoutEditorRegistrations()
    LayoutEditor.RegisterWindow("AtlasFrame", Atlas.Strings.AtlasFrameTitle, Atlas.Strings.AtlasFrameDescription, false,
        false, true, nil)
end

local function ShowCoordinatesOnMouseOver()
    WindowSetShowing("AtlasFrameCoordinatesLabel", true)

    -- Ensure the coordinates label exists before updating it
    if not DoesWindowExist("AtlasFrameCoordinatesLabel") then
        Atlas.Utilities.Debug("AtlasFrameCoordinatesLabel does not exist.")
        return
    end

    local mapPositionX, mapPositionY = WindowGetScreenPosition("AtlasFrameMapContainerMapDisplay")
    -- Get the current scale of the map display
    local mapScale = WindowGetScale("AtlasFrame") or 1.0

    -- Adjust mouse position for scale
    local localMouseX = (SystemData.MousePosition.x - mapPositionX) / mapScale
    local localMouseY = (SystemData.MousePosition.y - mapPositionY) / mapScale

    local xc, yc = MapGetCoordinatesForPoint("AtlasFrameMapContainerMapDisplay", localMouseX, localMouseY)

    if (xc == nil) then
        xc = towstring("-")
    else
        xc = math.ceil(xc / 1000)
    end

    if (yc == nil) then
        yc = towstring("-")
    else
        yc = math.ceil(yc / 1000)
    end

    -- Atlas.Utilities.Debug("Mouse coordinates: " .. tostring(xc) .. ", " .. tostring(yc))
    LabelSetText("AtlasFrameCoordinatesLabel", towstring("") .. xc .. towstring("k,") .. yc .. towstring("k"))
end

function AtlasMap.OnPlayerPositionUpdated(x, y)
    -- Atlas.Utilities.Debug("AtlasMap.OnPlayerPositionUpdated called. Player Position: " .. tostring(x) .. ", " .. tostring(y))

    -- Check if the player's position has changed
    if not isMouseOverMap then
        if x ~= lastPlayerPosition.x or y ~= lastPlayerPosition.y then
            -- Player is moving
            -- Atlas.Utilities.Debug("Player is moving. Current Position: " .. tostring(x) .. ", " .. tostring(y))
            if not isPlayerMoving then
                -- Atlas.Utilities.Debug("Player started moving. Setting transparency to 0.25.")
                isPlayerMoving = true
                SetMapTransparency(MapSettings.TransparencyOnMovement)
            end

            -- Reset the movement timer
            timeSinceLastMovement = 0
        end
    end
    lastPlayerPosition.x = x
    lastPlayerPosition.y = y
end

function AtlasMap.OnUpdate(elapsed)
    if isPlayerMoving then
        timeSinceLastMovement = timeSinceLastMovement + elapsed
        -- Atlas.Utilities.Debug("Time since last movement: " .. tostring(timeSinceLastMovement))
        if timeSinceLastMovement >= MapSettings.MovementTimeout then
            -- Atlas.Utilities.Debug("Player stopped moving. Resetting transparency to 1.0.")
            isPlayerMoving = false
            SetMapTransparency(MapSettings.Transparency)
        end
    end

    if isMouseOverMap then
        ShowCoordinatesOnMouseOver()
    end
end

function AtlasMap.OnMouseLeaveMap()
    Atlas.Utilities.Debug("Mouse left the map.")
    -- Optionally, you can reset transparency here if needed.
end

function AtlasMap.OnEnterCombat()
    Atlas.Utilities.Debug("Entering combat. Hiding map.")

    wasMapShowing = WindowGetShowing("AtlasFrame")

    if wasMapShowing then
        Atlas.Utilities.Debug("Map was visible before combat.")
        AtlasMap.Toggle() -- Hide the map
    end
end

function AtlasMap.OnExitCombat()
    Atlas.Utilities.Debug("Exiting combat. Restoring map visibility.")

    if wasMapShowing then
        AtlasMap.Toggle() -- Show the map again
    end
end

function AtlasMap.OnCombatStateChanged()
    Atlas.Utilities.Debug("Combat state changed called.")

    -- No need to process if the setting is off or the state hasn't changed
    if not MapSettings.HideMapInCombat or (isPlayerInCombat == GameData.Player.inCombat) then
        return
    end

    isPlayerInCombat = GameData.Player.inCombat

    if isPlayerInCombat then
        AtlasMap.OnEnterCombat()
    else
        AtlasMap.OnExitCombat()
    end
end

function AtlasMap.Initialize()
    Atlas.Utilities.Debug("Initializing Map Window...")

    GetMapSettings()

    -- Register Map Window-related event handlers, UI setup, etc.
    ApplyMapWindowSettings()
    SetTitleBarText()
    InitializeMapDisplay()
    RegisterMapPins()

    LayoutEditorRegistrations()
    RegisterEventHandlers()
end

function AtlasMap.OnZoneChanged()
    Atlas.Utilities.Debug("OnZoneChanged called. Current zone: " .. tostring(currentMapZone))
    if MapSettings.ResetZoneOnChange and not (currentMapZone == GameData.Player.zone) then
        Atlas.Utilities.Debug("Zone changed. Resetting map zone to player's current zone.")
        currentMapZone = GameData.Player.zone
    end

    UpdateMap()
end

function AtlasMap.OnReloadInterface()
    Atlas.Utilities.Debug("AtlasMap.OnReloadInterface called.")

    AtlasMap.OnLoadingEnd()
end

function AtlasMap.OnLoadingEnd()
    Atlas.Utilities.Debug("AtlasMap.OnLoadingEnd called.")

    UpdateMapView()
end

function AtlasMap.Toggle()
    WindowSetShowing("AtlasFrame", not WindowGetShowing("AtlasFrame"))

    if WindowGetShowing("AtlasFrame") and MapSettings.ResetZoneOnOpen then
        Atlas.Utilities.Debug("Resetting map zone to player's current zone on toggle.")
        currentMapZone = GameData.Player.zone
        UpdateMap()
    end
end

function AtlasMap.OnMapRBU()
    Atlas.Utilities.Debug("AtlasMap.OnRButtonUp called.")

    -- Handle right-click events here
    if MapSettings.RightClickToClose and WindowGetShowing("AtlasFrame") then
        AtlasMap.Toggle()
    end
end

function AtlasMap.Shutdown()
    Atlas.Utilities.Debug("Shutting down Map Window...")

    -- Cleanup Map Window-related resources
    LayoutEditor.UnregisterWindow("AtlasFrame")
    WindowUnregisterEventHandler("AtlasFrame", SystemData.Events.UPDATE_PROCESSED)
end

-- Legend Item functions
function AtlasMap.OnLegendItemMouseOver()
    AtlasMap.OnMouseOver()

    if not MapSettings.EnableTooltips then
        return
    end

    local labelName = SystemData.ActiveWindow.name -- Get the name of the window that triggered the event
    -- Atlas.Utilities.Debug("Mouse over legend item: " .. labelName)

    local id = WindowGetId(labelName)
    -- Atlas.Utilities.Debug("Legend item ID: " .. tostring(id))
    if id and AtlasMap.CurrentLegendData and AtlasMap.CurrentLegendData[id] then
        -- Atlas.Utilities.Debug("Legend item data found for ID: " .. tostring(id))
        local description = AtlasMap.CurrentLegendData[id].description
        -- Atlas.Utilities.Debug("Legend item description: " .. tostring(description))

        -- Create a tooltip for the legend item
        Tooltips.CreateTextOnlyTooltip(labelName)
        Tooltips.SetTooltipText(1, 1, description)
        Tooltips.AnchorTooltip(Tooltips.ANCHOR_CURSOR)
        Tooltips.Finalize()
    else
        Atlas.Utilities.Debug("ERROR: No data found for label: " .. labelName)
    end
end

function AtlasMap.OnLegendItemMouseLeave()
    Tooltips.ClearTooltip()
end

function AtlasMap.UpdateDirectionalButtons()
    -- Get the current scale of the AtlasFrame
    local atlasFrameScale = WindowGetScale("AtlasFrame")
    Atlas.Utilities.Debug("AtlasFrame scale: " .. tostring(atlasFrameScale))

    -- Clear existing dynamic buttons
    for _, buttonName in ipairs(dynamicDirectionButtons) do
        if DoesWindowExist(buttonName) then
            DestroyWindow(buttonName)
        end
    end
    dynamicDirectionButtons = {} -- Reset the tracking table

    local adjacentZones = ZoneDetails[currentMapZone] and ZoneDetails[currentMapZone].adjacentZones or {}
    local texSlices = {
        north = {
            normal = "NextZoneArrow-North",
            rollover = "NextZoneArrow-North-ROLLOVER"
        },
        east = {
            normal = "NextZoneArrow-East",
            rollover = "NextZoneArrow-East-ROLLOVER"
        },
        south = {
            normal = "NextZoneArrow-South",
            rollover = "NextZoneArrow-South-ROLLOVER"
        },
        west = {
            normal = "NextZoneArrow-West",
            rollover = "NextZoneArrow-West-ROLLOVER"
        }
    }
    local anchorPoints = {
        north = {
            point = "top",
            relativePoint = "top",
            offsetX = 0,
            offsetY = 50,
            xSpacing = 75,
            ySpacing = 0
        },
        east = {
            point = "right",
            relativePoint = "right",
            offsetX = -10,
            offsetY = 0,
            xSpacing = 0,
            ySpacing = 75
        },
        south = {
            point = "bottom",
            relativePoint = "bottom",
            offsetX = 0,
            offsetY = -10,
            xSpacing = 75,
            ySpacing = 0
        },
        west = {
            point = "left",
            relativePoint = "left",
            offsetX = 10,
            offsetY = 0,
            xSpacing = 0,
            ySpacing = 75
        }
    }

    for direction, zones in pairs(adjacentZones) do
        if type(zones) ~= "table" then
            zones = {zones}
        end

        for i, zone in ipairs(zones) do
            local buttonName = "AtlasFrameDynamicDirectionButton" .. direction .. i
            CreateWindowFromTemplate(buttonName, "TAtlasDirectionButton", "AtlasFrame")
            table.insert(dynamicDirectionButtons, buttonName) -- Track the button

            -- Assign TexSlices based on direction
            ButtonSetTextureSlice(buttonName, Button.ButtonState.NORMAL, "EA_BigMap01_d5", texSlices[direction].normal)
            ButtonSetTextureSlice(buttonName, Button.ButtonState.HIGHLIGHTED, "EA_BigMap01_d5",
                texSlices[direction].rollover)

            -- Position the button dynamically
            local anchor = anchorPoints[direction]
            local offsetX = anchor.offsetX + (i - 1) * anchor.xSpacing
            local offsetY = anchor.offsetY + (i - 1) * anchor.ySpacing

            WindowClearAnchors(buttonName)
            WindowAddAnchor(buttonName, anchor.point, "AtlasFrame", anchor.relativePoint, offsetX, offsetY)

            -- Attach the zone ID to the button
            WindowSetId(buttonName, zone)

            -- Apply the AtlasFrame scale to the button
            WindowSetScale(buttonName, atlasFrameScale)
            -- Atlas.Utilities.Debug("Set scale for button: " .. buttonName .. " | Scale: " .. tostring(atlasFrameScale))
        end
    end
end

function AtlasMap.OnDynamicDirectionButtonClicked()
    local buttonName = SystemData.ActiveWindow.name
    local zoneId = WindowGetId(buttonName)

    if zoneId and zoneId ~= currentMapZone then
        currentMapZone = zoneId
        UpdateMap()
    end
end

function AtlasMap.OnDynamicDirectionButtonMouseOver()
    if not MapSettings.EnableTooltips then
        return
    end

    -- Ensure the MapContainer's OnMouseOver event is still recognized
    AtlasMap.OnMouseOver()

    local buttonName = SystemData.ActiveWindow.name
    local zoneId = WindowGetId(buttonName)
    local zoneDetails = ZoneDetails[zoneId]

    if zoneDetails then
        local tooltip = GenerateTooltip(zoneDetails)
        Tooltips.CreateTextOnlyTooltip(buttonName)
        Tooltips.SetTooltipText(1, 1, tooltip)
        Tooltips.AnchorTooltip(Tooltips.ANCHOR_CURSOR)
        Tooltips.Finalize()
    end
end

function AtlasMap.OnDynamicDirectionButtonMouseLeave()
    Tooltips.ClearTooltip()
end

-- Map Pin functions
function AtlasMap.OnMouseOver()
    -- Ensure the map is not transparent even if the player is moving
    isMouseOverMap = true

    -- Atlas.Utilities.Debug("Mouse is over the map. Resetting transparency.")
    SetMapTransparency(MapSettings.TransparencyOnMouseOver)
    isPlayerMoving = false
end

function AtlasMap.OnMouseOverEnd()
    -- Reset the transparency if the mouse leaves the map
    isMouseOverMap = false

    SetMapTransparency(MapSettings.Transparency)
    WindowSetShowing("AtlasFrameCoordinatesLabel", false)
end

-- Map Pin functions
function AtlasMap.OnMouseOverPoint()
    if not MapSettings.EnableTooltips then
        return
    end

    Tooltips.CreateMapPointTooltip("AtlasFrameMapContainerMapDisplay", AtlasFrameMapContainerMapDisplay.MouseoverPoints,
        Tooltips.ANCHOR_CURSOR)
end

function AtlasMap.OnMouseLeaveMapPin()
    Tooltips.ClearTooltip()
end
