Atlas.Configuration = Atlas.Configuration or {}
Atlas.Settings = Atlas.Settings or {}

local Utils = Atlas.Utilities

local DefaultSettings = {
    debug = true,
    MapWindow = {
        EnableTooltips = true,
        MovementTimeout = 0.1,
        ResetZoneOnOpen = true,
        ResetZoneOnChange = true,
        RightClickToClose = true,
        WindowScale = 1.0,
        WindowTransparency = 0.5,
        WindowTransparencyOnCharacterMovement = 0.25,
        WindowTransparencyOnMouseOver = 0.75
    }
}

local checkboxSettings = {{
    key = "EnableTooltips",
    name = "AtlasConfigurationFrameContentMapSettingsEnableTooltipsCheckbox",
    label = Atlas.Strings.EnableTooltipsLabel
}, {
    key = "ResetZoneOnOpen",
    name = "AtlasConfigurationFrameContentMapSettingsResetZoneOnOpenCheckbox",
    label = Atlas.Strings.ResetZoneOnOpenLabel
}, {
    key = "ResetZoneOnChange",
    name = "AtlasConfigurationFrameContentMapSettingsResetZoneOnChangeCheckbox",
    label = Atlas.Strings.ResetZoneOnChangeLabel
}, {
    key = "RightClickToClose",
    name = "AtlasConfigurationFrameContentMapSettingsRightClickToCloseCheckbox",
    label = Atlas.Strings.RightClickToCloseLabel
}}

local function MergeDefaults(defaults, settings)
    for key, value in pairs(defaults) do
        if type(value) == "table" then
            settings[key] = settings[key] or {}
            MergeDefaults(value, settings[key])
        else
            if settings[key] == nil then
                settings[key] = value
            end
        end
    end
end

local function EnsureSettingsExist()
    MergeDefaults(DefaultSettings, Atlas.Settings)
end

local function RegisterSlashCommands()
    LibSlash.RegisterSlashCmd("atlas", Atlas.Configuration.Toggle)
end

local function SetTitleBarText()
    LabelSetText("AtlasConfigurationFrameTitleBarText", Atlas.Strings.SettingsTitleBarText)
end

local function UpdateCheckbox(name, value)
    local buttonName = name .. "Button" -- Reference the button inside the checkbox window
    if DoesWindowExist(buttonName) then
        ButtonSetPressedFlag(buttonName, value)
    else
        Utils.Debug("Checkbox does not exist: " .. tostring(buttonName))
    end
end

local function UpdateSlider(name, value, multiplier)
    if DoesWindowExist(name) then
        SliderBarSetCurrentPosition(name, value * multiplier)
    else
        Utils.Debug("Slider does not exist: " .. tostring(name))
    end
end

local function PopulateInterface()
    Utils.Debug("Populating Atlas settings UI...")

    -- Set the text for the Map Settings tab dynamically
    if DoesWindowExist("AtlasConfigurationFrameContentTabMapSettingsLabel") then
        Atlas.Utilities.Debug("Tab Map Settings Label exists.")
        LabelSetText("AtlasConfigurationFrameContentTabMapSettingsLabel", L"Map")
    else
        Utils.Debug("Tab Map Settings does not exist.")
    end

    -- Populate MapWindow settings
    local mapWindowSettings = Atlas.Settings.MapWindow

    for _, setting in ipairs(checkboxSettings) do
        local checkboxName = setting.name
        -- Utils.Debug("Checking existence of: " .. checkboxName)

        if DoesWindowExist(checkboxName) then
            UpdateCheckbox(checkboxName, mapWindowSettings[setting.key])

            WindowSetShowing(checkboxName, true) -- Ensure the checkbox is visible

            local labelName = checkboxName .. "Label"
            if DoesWindowExist(labelName) then
                LabelSetText(labelName, setting.label)
                -- Utils.Debug("Label set for: " .. labelName)
            else
                -- Utils.Debug("Label does not exist: " .. labelName)
            end
            -- Utils.Debug("Checkbox visibility set: " .. checkboxName)
        else
            -- Utils.Debug("Checkbox does not exist: " .. checkboxName)
        end
    end

    -- Float settings (sliders)
    -- local floatSettings = {
    --     { key = "WindowScale", label = "Window Scale", multiplier = 100 },
    --     { key = "WindowTransparency", label = "Window Transparency", multiplier = 100 },
    --     { key = "WindowTransparencyOnCharacterMovement", label = "Transparency On Movement", multiplier = 100 },
    --     { key = "WindowTransparencyOnMouseOver", label = "Transparency On Mouse Over", multiplier = 100 },
    -- }

    -- for _, setting in ipairs(floatSettings) do
    --     local sliderName = "AtlasConfigurationFrameContentMapWindowSettings" .. setting.key .. "Slider"
    --     Utils.Debug("Checking existence of: " .. sliderName)
    --     if DoesWindowExist(sliderName) then
    --         UpdateSlider(sliderName, mapWindowSettings[setting.key], setting.multiplier)
    --         WindowSetShowing(sliderName, true) -- Ensure the slider is visible
    --         Utils.Debug("Slider visibility set: " .. sliderName)
    --     else
    --         Utils.Debug("Slider does not exist: " .. sliderName)
    --     end
    -- end
end

local function ApplySettingsWindowSettings()
    SetTitleBarText()
    PopulateInterface()

    -- TODO: Select default tab.
end

local function LayoutEditorRegistrations()
    LayoutEditor.RegisterWindow("AtlasConfigurationFrame", Atlas.Strings.AtlasConfigurationFrameTitle,
        Atlas.Strings.AtlasConfigurationFrameDescription, false, false, true, nil)
end

function Atlas.Configuration.Initialize()
    Utils.Debug("Initializing Settings Window...")

    -- Register Settings Window-related event handlers, UI setup, etc.
    EnsureSettingsExist()

    ApplySettingsWindowSettings()

    LayoutEditorRegistrations()

    RegisterSlashCommands()
end

function Atlas.Configuration.Toggle()
    local isVisible = WindowGetShowing("AtlasConfigurationFrame")

    if not isVisible then
        Atlas.Configuration.Open()
    else
        Atlas.Configuration.Close()
    end
end

function Atlas.Configuration.Open()
    Utils.Debug("Opening Atlas settings window.")

    -- Populate UI elements with current settings
    PopulateInterface()

    WindowSetShowing("AtlasConfigurationFrame", true)
end

function Atlas.Configuration.Close()
    Utils.Debug("Closing Atlas settings window.")
    WindowSetShowing("AtlasConfigurationFrame", false)
end

function Atlas.Configuration.Shutdown()
    Utils.Debug("Shutting down Settings Window...")
    -- Cleanup Settings Window-related resources
end

function Atlas.Configuration.OnElementLoaded(elementName)
    if elementName then
        Utils.Debug("Element loaded: " .. tostring(elementName))
    else
        Utils.Debug("OnElementLoaded called, but no element name provided.")
    end
end

function Atlas.Configuration.OnCheckboxLBU()
    Utils.Debug("--------------------------======================--------------------------")
    Utils.Debug("OnCheckboxLBU function triggered.")
    Utils.Debug("--------------------------======================--------------------------")
	local checkboxName = SystemData.MouseOverWindow.name .. "Button"
	
	-- if( ButtonGetDisabledFlag(checkboxName) ) then return end
	
	ButtonSetPressedFlag(checkboxName, not ButtonGetPressedFlag(checkboxName))

    Utils.Debug("SystemData.MouseOverWindow.id: " .. tostring(SystemData.MouseOverWindow.id))
    Utils.Debug("SystemData.MouseOverWindow.name: " .. tostring(SystemData.MouseOverWindow.name))
    -- Parse the name of the element to get the settingsKey
    local settingsKey = string.match(checkboxName, "AtlasConfigurationFrameContentMapSettings(.*)Checkbox")
    
    Atlas.Settings.MapWindow[settingsKey] = ButtonGetPressedFlag(checkboxName)
end
