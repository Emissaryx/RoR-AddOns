Atlas = Atlas or {}

function Atlas.Initialize()
    Atlas.Utilities.Debug("Atlas initializing...")

    -- Initialize Atlas.Utilities
    Atlas.Utilities.Initialize()

    -- Initialize settings
    Atlas.Configuration.Initialize()

    -- Initialize Map Window
    AtlasMap.Initialize()

    Atlas.Utilities.Debug("Atlas initialized.")
end

function Atlas.Shutdown()
    Atlas.Utilities.Debug("Atlas shutting down...")
    AtlasMap.Shutdown()
    Atlas.Configuration.Shutdown()
    -- Atlas.Utilities.Shutdown()
end