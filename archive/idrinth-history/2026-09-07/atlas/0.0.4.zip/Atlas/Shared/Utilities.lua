Atlas.Utilities = Atlas.Utilities or {}
local ATLAS_MACRO_NAME = "Atlas"
local ATLAS_MACRO_TEXT = "/script AtlasMap.Toggle()"
local ATLAS_MACRO_ICON = 10951
local SetMacroData = SetMacroData

function Atlas.Utilities.Debug(message)
    if not Atlas.Settings or Atlas.Settings.debug then
        DEBUG(towstring(message))
    end
end

local function GetMacroId(macroName)
    Atlas.Utilities.Debug("Searching for macro: " .. tostring(macroName))

    local macros = DataUtils.GetMacros() -- Retrieve all macros

    for slot = 1, EA_Window_Macro.NUM_MACROS do
        if macros[slot] then
            -- Atlas.Utilities.Debug("Checking macro in slot " .. tostring(slot) .. ": Name=" .. tostring(macros[slot].name) .. ", Text=" .. tostring(macros[slot].text))
            if tostring(macros[slot].name) == tostring(macroName) then
                Atlas.Utilities.Debug("Macro found in slot " .. tostring(slot))

                return slot -- Return the slot if the macro is found
            end
        end
    end

    Atlas.Utilities.Debug("Macro not found.")
    return nil -- Return nil if the macro is not found
end

local function CreateMacro(name, text, iconId)
    Atlas.Utilities.Debug("Creating macro: " .. tostring(name) .. ", Text: " .. tostring(text) .. ", IconId: " .. tostring(iconId))

    local slot = GetMacroId(name)

    if slot then
        Atlas.Utilities.Debug("Macro already exists in slot " .. tostring(slot))
        SetMacroData(towstring(name), towstring(text), iconId, slot)

        return slot
    end

    local macros = DataUtils.GetMacros()

    for slot = 1, EA_Window_Macro.NUM_MACROS do
        if tostring(macros[slot].text) == "" then
            Atlas.Utilities.Debug("Macro slot " .. tostring(slot) .. " is empty. Setting macro data.")
            SetMacroData(towstring(name), towstring(text), iconId, slot) -- Convert name and text to wide strings
            
 			EA_Window_Macro.UpdateMacros()

            return slot
        end
    end

    Atlas.Utilities.Debug("No empty macro slots available.")
    return nil
end

local function RegisterEventHandlers()
    -- RegisterEventHandler(SystemData.Events.MACROS_LOADED, "Atlas.Utilities.OnMacrosLoaded")
	-- RegisterEventHandler(SystemData.Events.MACRO_UPDATED, "Atlas.Utilities.OnMacrosLoaded")
end

function Atlas.Utilities.OnMacrosLoaded()
    -- Create or update the macro 
    Atlas.Utilities.Debug("On Macros Loaded event fired. Creating/Updating macros.")
    CreateMacro(ATLAS_MACRO_NAME, ATLAS_MACRO_TEXT, ATLAS_MACRO_ICON)
end

function Atlas.Utilities.Initialize()
    Atlas.Utilities.Debug("Initializing Atlas...")

    CreateMacro(ATLAS_MACRO_NAME, ATLAS_MACRO_TEXT, ATLAS_MACRO_ICON)

    Atlas.Utilities.Debug("Atlas initialized.")
end

function Atlas.Utilities.DumpTable(table, indent)
    indent = indent or ""
    for key, value in pairs(table) do
        if type(value) == "table" then
            d(indent .. tostring(key) .. ":")
            Atlas.Utilities.DumpTable(value, indent .. "  ")
        else
            d(indent .. tostring(key) .. ": " .. tostring(value))
        end
    end
end