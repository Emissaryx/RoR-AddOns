Atlas.Configuration = Atlas.Configuration or {}
Atlas.Settings = Atlas.Settings or {}

local Utils = Atlas.Utilities

local DefaultSettings = {
    debug = true,
    MapWindow = {
        EnableTooltips = true,
        MovementTimeout = 0.5,
        ResetZoneOnOpen = true,
        ResetZoneOnChange = true,
        RightClickToClose = true,
        Transparency = 0.5,
        TransparencyOnMovement = 0.25,
        TransparencyOnMouseOver = 0.75,
        HideMapInCombat = true -- New setting to toggle hiding the map in combat
    }
}

local checkboxSettings = {{
    key = "EnableTooltips",
    name = "AtlasConfigurationFrameContentMapSettingsEnableTooltipsCheckbox",
    label = Atlas.Strings.EnableTooltipsLabel
}, {
    key = "ResetZoneOnOpen",
    name = "AtlasConfigurationFrameContentMapSettingsResetZoneOnOpenCheckbox",
    label = Atlas.Strings.ResetZoneOnOpenLabel
}, {
    key = "ResetZoneOnChange",
    name = "AtlasConfigurationFrameContentMapSettingsResetZoneOnChangeCheckbox",
    label = Atlas.Strings.ResetZoneOnChangeLabel
}, {
    key = "RightClickToClose",
    name = "AtlasConfigurationFrameContentMapSettingsRightClickToCloseCheckbox",
    label = Atlas.Strings.RightClickToCloseLabel
}, {
    key = "HideMapInCombat",
    name = "AtlasConfigurationFrameContentMapSettingsHideMapInCombatCheckbox",
    label = Atlas.Strings.HideMapInCombatLabel
}}

local sliderSettings = {{
    key = "Transparency",
    name = "AtlasConfigurationFrameContentMapSettingsTransparencySlider",
    label = Atlas.Strings.TransparencyLabel
}, {
    key = "TransparencyOnMovement",
    name = "AtlasConfigurationFrameContentMapSettingsTransparencyOnMovementSlider",
    label = Atlas.Strings.TransparencyOnMovementLabel
}, {
    key = "TransparencyOnMouseOver",
    name = "AtlasConfigurationFrameContentMapSettingsTransparencyOnMouseOverSlider",
    label = Atlas.Strings.TransparencyOnMouseOverLabel
}}

local function MergeDefaults(defaults, settings)
    for key, value in pairs(defaults) do
        if type(value) == "table" then
            settings[key] = settings[key] or {}
            MergeDefaults(value, settings[key])
        else
            if settings[key] == nil then
                settings[key] = value
            end
        end
    end
end

local function EnsureSettingsExist()
    MergeDefaults(DefaultSettings, Atlas.Settings)
end

local function RegisterSlashCommands()
    LibSlash.RegisterSlashCmd("atlas", Atlas.Configuration.Toggle)
end

local function SetTitleBarText()
    LabelSetText("AtlasConfigurationFrameTitleBarText", Atlas.Strings.SettingsTitleBarText)
end

local function UpdateCheckbox(name, value)
    local buttonName = name .. "Button" -- Reference the button inside the checkbox window
    if DoesWindowExist(buttonName) then
        ButtonSetPressedFlag(buttonName, value)
    else
        Utils.Debug("Checkbox does not exist: " .. tostring(buttonName))
    end
end

local function UpdateSlider(name, value)
    if DoesWindowExist(name) then
        Utils.Debug("Updating slider: " .. name .. " with value: " .. value)
        SliderBarSetCurrentPosition(name, value)
    else
        Utils.Debug("Slider does not exist: " .. tostring(name))
    end
end

local function PopulateInterface()
    Utils.Debug("Populating Atlas settings UI...")

    WindowSetScale("AtlasConfigurationFrame", 1.0)
    WindowSetDimensions("AtlasConfigurationFrame", 500, 425)

    -- Set the text for the Map Settings tab dynamically
    if DoesWindowExist("AtlasConfigurationFrameContentTabMapSettingsLabel") then
        -- Utils.Debug("Tab Map Settings Label exists.")
        LabelSetText("AtlasConfigurationFrameContentTabMapSettingsLabel", L "Map")
    else
        Utils.Debug("Tab Map Settings does not exist.")
    end

    -- Populate MapWindow settings
    local mapWindowSettings = Atlas.Settings.MapWindow

    for _, setting in ipairs(checkboxSettings) do
        local checkboxName = setting.name
        -- Utils.Debug("Checking existence of: " .. checkboxName)

        if DoesWindowExist(checkboxName) then
            UpdateCheckbox(checkboxName, mapWindowSettings[setting.key])

            WindowSetShowing(checkboxName, true) -- Ensure the checkbox is visible

            local labelName = checkboxName .. "Label"
            if DoesWindowExist(labelName) then
                LabelSetText(labelName, setting.label)
                -- Utils.Debug("Label set for: " .. labelName)
            else
                -- Utils.Debug("Label does not exist: " .. labelName)
            end
            -- Utils.Debug("Checkbox visibility set: " .. checkboxName)
        else
            -- Utils.Debug("Checkbox does not exist: " .. checkboxName)
        end
    end

    -- Float settings (sliders)
    for _, setting in ipairs(sliderSettings) do
        local sliderName = setting.name
        -- Utils.Debug("Checking existence of: " .. sliderName)

        if DoesWindowExist(sliderName) then
            UpdateSlider(sliderName, mapWindowSettings[setting.key])
            LabelSetText(sliderName .. "Label", setting.label)

            LabelSetText(sliderName .. "MinLabel", towstring("0%"))
            LabelSetText(sliderName .. "MidLabel", towstring("50%"))
            LabelSetText(sliderName .. "MaxLabel", towstring("100%"))

            WindowSetShowing(sliderName, true) -- Ensure the slider is visible
            -- Utils.Debug("Slider visibility set: " .. sliderName)
        else
            Utils.Debug("Slider does not exist: " .. sliderName)
        end
    end
end

local function ApplySettingsWindowSettings()
    SetTitleBarText()
    PopulateInterface()

    -- TODO: Select default tab.
end

local function LayoutEditorRegistrations()
    LayoutEditor.RegisterWindow("AtlasConfigurationFrame", Atlas.Strings.AtlasConfigurationFrameTitle,
        Atlas.Strings.AtlasConfigurationFrameDescription, false, false, true, nil)
end

function Atlas.Configuration.Initialize()
    Utils.Debug("Initializing Settings Window...")

    -- Register Settings Window-related event handlers, UI setup, etc.
    EnsureSettingsExist()

    ApplySettingsWindowSettings()

    LayoutEditorRegistrations()

    RegisterSlashCommands()

    -- Dynamically set the version label text
    if DoesWindowExist("AtlasConfigurationFrameVersionLabel") then
        LabelSetText("AtlasConfigurationFrameVersionLabel", L"Version: " .. Atlas.Version)
    else
        Utils.Debug("Version label does not exist.")
    end
end

function Atlas.Configuration.Toggle()
    local isVisible = WindowGetShowing("AtlasConfigurationFrame")

    if not isVisible then
        Atlas.Configuration.Open()
    else
        Atlas.Configuration.Close()
    end
end

function Atlas.Configuration.Open()
    Utils.Debug("Opening Atlas settings window.")

    -- Populate UI elements with current settings
    PopulateInterface()

    WindowSetShowing("AtlasConfigurationFrame", true)
end

function Atlas.Configuration.Close()
    Utils.Debug("Closing Atlas settings window.")
    WindowSetShowing("AtlasConfigurationFrame", false)
end

function Atlas.Configuration.Shutdown()
    Utils.Debug("Shutting down Settings Window...")
    -- Cleanup Settings Window-related resources
end

function Atlas.Configuration.OnElementLoaded(elementName)
    if elementName then
        Utils.Debug("Element loaded: " .. tostring(elementName))
    else
        Utils.Debug("OnElementLoaded called, but no element name provided.")
    end
end

function Atlas.Configuration.OnCheckboxLBU()
    Utils.Debug("--------------------------======================--------------------------")
    Utils.Debug("OnCheckboxLBU function triggered.")
    Utils.Debug("--------------------------======================--------------------------")
    local checkboxName = SystemData.MouseOverWindow.name .. "Button"

    -- if( ButtonGetDisabledFlag(checkboxName) ) then return end

    ButtonSetPressedFlag(checkboxName, not ButtonGetPressedFlag(checkboxName))

    Utils.Debug("SystemData.MouseOverWindow.id: " .. tostring(SystemData.MouseOverWindow.id))
    Utils.Debug("SystemData.MouseOverWindow.name: " .. tostring(SystemData.MouseOverWindow.name))
    -- Parse the name of the element to get the settingsKey
    local settingsKey = string.match(checkboxName, "AtlasConfigurationFrameContentMapSettings(.*)Checkbox")

    Atlas.Settings.MapWindow[settingsKey] = ButtonGetPressedFlag(checkboxName)
end

function Atlas.Configuration.OnSlide(slidePosition)
    local sliderName = SystemData.ActiveWindow.name
    -- Utils.Debug("OnSlide triggered for: " .. tostring(sliderName) .. " with position: " .. tostring(slidePosition))

    -- Find the corresponding settings key using sliderSettings
    local settingsKey = nil
    for _, setting in ipairs(sliderSettings) do
        if setting.name == sliderName then
            settingsKey = setting.key
            break
        end
    end

    if settingsKey then
        Atlas.Settings.MapWindow[settingsKey] = slidePosition

        Utils.Debug("Updated " .. settingsKey .. " to value: " .. tostring(slidePosition))
    else
        Utils.Debug("Could not find settings key for sliderName: " .. tostring(sliderName))
    end
end
