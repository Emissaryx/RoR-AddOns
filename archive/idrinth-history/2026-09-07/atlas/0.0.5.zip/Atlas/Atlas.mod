<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
    <UiMod name="Atlas" version="0.0.5" date="2025-04-05">
        <Author name="Saiba Samurai" email="saiba.samurai@gmail.com" />
        <Description text="Creates a resizable world map." />

        <VersionSettings gameVersion="1.4.8" windowsVersion="1.0" savedVariablesVersion="1.0" />

        <Dependencies>
            <Dependency name="LibSlash" optional="false" forceEnable="true" />
        </Dependencies>

        <Files>
            <File name="Main.lua" />

            <File name="Shared/Localization.lua" />
            <File name="Shared/Zone_Info.lua" />
            <File name="Shared/Utilities.lua" />
            <File name="Shared/Templates.xml" />

            <File name="Configuration/Main.lua" />
            <File name="Configuration/Main.xml" />

            <File name="Map/Main.lua" />
            <File name="Map/Main.xml" />
        </Files>

        <SavedVariables>
            <SavedVariable name="Atlas.Settings" />
        </SavedVariables>

        <OnInitialize>
            <CreateWindow name="AtlasFrame" show="false" />
            <CreateWindow name="AtlasConfigurationFrame" show="false" />
            
            <CallFunction name="Atlas.Initialize" />
        </OnInitialize>

        <OnUpdate>
        </OnUpdate>

        <OnShutdown>
        </OnShutdown>
    </UiMod>
</ModuleFile>