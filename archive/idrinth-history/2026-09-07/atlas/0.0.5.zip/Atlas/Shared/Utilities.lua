Atlas.Utilities = Atlas.Utilities or {}
local ATLAS_MACRO_NAME = "Atlas"
local ATLAS_MACRO_TEXT = "/script AtlasMap.Toggle()"
local ATLAS_MACRO_ICON = 10951
local SetMacroData = SetMacroData

function Atlas.Utilities.Debug(message)
    if not Atlas.Settings or Atlas.Settings.debug then
        DEBUG(towstring(message))
    end
end

local function GetMacroId(macroName)
    Atlas.Utilities.Debug("Searching for macro: " .. tostring(macroName))

    local macros = DataUtils.GetMacros() -- Retrieve all macros

    for slot = 1, EA_Window_Macro.NUM_MACROS do
        if macros[slot] then
            -- Atlas.Utilities.Debug("Checking macro in slot " .. tostring(slot) .. ": Name=" .. tostring(macros[slot].name) .. ", Text=" .. tostring(macros[slot].text))
            if tostring(macros[slot].name) == tostring(macroName) then
                Atlas.Utilities.Debug("Macro found in slot " .. tostring(slot))

                return slot -- Return the slot if the macro is found
            end
        end
    end

    Atlas.Utilities.Debug("Macro not found.")
    return nil -- Return nil if the macro is not found
end

local function CreateMacro(name, text, iconId)
    Atlas.Utilities.Debug("Creating macro: " .. tostring(name) .. ", Text: " .. tostring(text) .. ", IconId: " .. tostring(iconId))

    local slot = GetMacroId(name)

    if slot then
        Atlas.Utilities.Debug("Macro already exists in slot " .. tostring(slot))
        SetMacroData(towstring(name), towstring(text), iconId, slot)

        return slot
    end

    local macros = DataUtils.GetMacros()

    for slot = 1, EA_Window_Macro.NUM_MACROS do
        if tostring(macros[slot].text) == "" then
            Atlas.Utilities.Debug("Macro slot " .. tostring(slot) .. " is empty. Setting macro data.")
            SetMacroData(towstring(name), towstring(text), iconId, slot) -- Convert name and text to wide strings
            
 			EA_Window_Macro.UpdateMacros()

            return slot
        end
    end

    Atlas.Utilities.Debug("No empty macro slots available.")
    return nil
end

local function RegisterEventHandlers()
    -- RegisterEventHandler(SystemData.Events.MACROS_LOADED, "Atlas.Utilities.OnMacrosLoaded")
	-- RegisterEventHandler(SystemData.Events.MACRO_UPDATED, "Atlas.Utilities.OnMacrosLoaded")
end

function Atlas.Utilities.OnMacrosLoaded()
    -- Create or update the macro 
    Atlas.Utilities.Debug("On Macros Loaded event fired. Creating/Updating macros.")
    CreateMacro(ATLAS_MACRO_NAME, ATLAS_MACRO_TEXT, ATLAS_MACRO_ICON)
end

function Atlas.Utilities.Initialize()
    Atlas.Utilities.Debug("Initializing Atlas...")

    CreateMacro(ATLAS_MACRO_NAME, ATLAS_MACRO_TEXT, ATLAS_MACRO_ICON)

    Atlas.Utilities.Debug("Atlas initialized.")
end

function Atlas.Utilities.DumpTable(tbl, maxDepth, filter)
    maxDepth = maxDepth or math.huge -- Default to no depth limit if not specified

    -- Resolve nested tables from a string representation
    if type(tbl) == "string" then
        d("Dumping table: " .. tbl) -- Debug statement using the string representation
        local path = tbl
        tbl = _G -- Start with the global table
        for segment in string.gmatch(path, "[^%.]+") do
            tbl = tbl[segment]
            if not tbl then
                d("Error: Table '" .. path .. "' does not exist.")
                return
            end
        end
    end

    local function Dump(tbl, currentDepth, indent)
        currentDepth = currentDepth or 0
        indent = indent or ""

        if currentDepth >= maxDepth then
            return -- Stop recursion silently
        end

        for key, value in pairs(tbl) do
            local keyString = tostring(key)
            if not filter or string.find(keyString, filter) then
                if type(value) == "table" then
                    -- Print the key and indicate it's a nested table
                    d(indent .. "  " .. keyString .. " (table):")
                    -- Recursively dump the child table
                    Dump(value, currentDepth + 1, indent .. "  ")
                else
                    -- Print key-value pairs
                    d(indent .. "  " .. keyString .. ": " .. tostring(value))
                end
            end
        end
    end

    Dump(tbl, 0, "") -- Start with depth 0 and no indentation
end

-- /script Atlas.Utilities.DumpFunctionSiblings(MapSetMapView, "Window")
function Atlas.Utilities.DumpFunctionSiblings(func, filter)
    -- Iterate over all global tables to find the parent table of the function
    for globalKey, globalValue in pairs(_G) do
        if type(globalValue) == "table" then
            for key, value in pairs(globalValue) do
                if value == func then
                    -- Found the parent table
                    d("Parent Table: " .. tostring(globalKey))
                    d("Function siblings of '" .. tostring(key) .. "':")
                    
                    -- List all function siblings (keys in the parent table)
                    for siblingKey, siblingValue in pairs(globalValue) do
                        if type(siblingValue) == "function" then
                            local siblingKeyString = tostring(siblingKey)

                            -- Apply the filter if provided
                            if not filter or string.find(siblingKeyString, filter) then
                                d("  " .. siblingKeyString .. " (function): " .. tostring(siblingValue))
                            end
                        end
                    end
                    return
                end
            end
        end
    end

    -- If the function is not found
    d("Function not found in any global table.")
end