SamuraiAtlasUtils = SamuraiAtlasUtils or {}
local SAMURAI_ATLAS_MACRO_NAME = "SamuraiAtlas"
local SAMURAI_ATLAS_MACRO_TEXT = "/script SamuraiAtlasMap.Toggle()"
local SAMURAI_ATLAS_MACRO_ICON = 10951
local SetMacroData = SetMacroData

function SamuraiAtlasUtils.Debug(message)
    if not SamuraiAtlas.Settings or SamuraiAtlas.Settings.debug then
        DEBUG(towstring(message))
    end
end

local function GetMacroId(macroName)
    SamuraiAtlasUtils.Debug("Searching for macro: " .. tostring(macroName))

    local macros = DataUtils.GetMacros() -- Retrieve all macros

    for slot = 1, EA_Window_Macro.NUM_MACROS do
        if macros[slot] then
            -- SamuraiAtlasUtils.Debug("Checking macro in slot " .. tostring(slot) .. ": Name=" .. tostring(macros[slot].name) .. ", Text=" .. tostring(macros[slot].text))
            if tostring(macros[slot].name) == tostring(macroName) then
                SamuraiAtlasUtils.Debug("Macro found in slot " .. tostring(slot))

                return slot -- Return the slot if the macro is found
            end
        end
    end

    SamuraiAtlasUtils.Debug("Macro not found.")
    return nil -- Return nil if the macro is not found
end

local function CreateMacro(name, text, iconId)
    SamuraiAtlasUtils.Debug("Creating macro: " .. tostring(name) .. ", Text: " .. tostring(text) .. ", IconId: " .. tostring(iconId))

    local slot = GetMacroId(name)

    if slot then
        SamuraiAtlasUtils.Debug("Macro already exists in slot " .. tostring(slot))
        SetMacroData(towstring(name), towstring(text), iconId, slot)

        return slot
    end

    local macros = DataUtils.GetMacros()

    for slot = 1, EA_Window_Macro.NUM_MACROS do
        if tostring(macros[slot].text) == "" then
            SamuraiAtlasUtils.Debug("Macro slot " .. tostring(slot) .. " is empty. Setting macro data.")
            SetMacroData(towstring(name), towstring(text), iconId, slot) -- Convert name and text to wide strings
            
 			EA_Window_Macro.UpdateMacros()

            return slot
        end
    end

    SamuraiAtlasUtils.Debug("No empty macro slots available.")
    return nil
end

local function RegisterEventHandlers()
    -- RegisterEventHandler(SystemData.Events.MACROS_LOADED, "SamuraiAtlasUtils.OnMacrosLoaded")
	-- RegisterEventHandler(SystemData.Events.MACRO_UPDATED, "SamuraiAtlasUtils.OnMacrosLoaded")
end

function SamuraiAtlasUtils.OnMacrosLoaded()
    -- Create or update the macro 
    SamuraiAtlasUtils.Debug("On Macros Loaded event fired. Creating/Updating macros.")
    CreateMacro(SAMURAI_ATLAS_MACRO_NAME, SAMURAI_ATLAS_MACRO_TEXT, SAMURAI_ATLAS_MACRO_ICON)
end

function SamuraiAtlasUtils.Initialize()
    SamuraiAtlasUtils.Debug("Initializing Samurai Atlas...")

    CreateMacro(SAMURAI_ATLAS_MACRO_NAME, SAMURAI_ATLAS_MACRO_TEXT, SAMURAI_ATLAS_MACRO_ICON)

    SamuraiAtlasUtils.Debug("Samurai Atlas initialized.")
end