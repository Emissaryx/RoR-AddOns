SamuraiAtlasSettings = SamuraiAtlasSettings or {}

local Utils = SamuraiAtlasUtils

local DefaultSettings = {
    debug = true,
    MapWindow = {
        EnableTooltips = true,
        MovementTimeout = 0.1,
        ResetZoneOnOpen = true,
        ResetZoneOnChange = true,
        RightClickToClose = true,
        WindowScale = 1.0,
        WindowTransparency = 0.5,
        WindowTransparencyOnCharacterMovement = 0.25,
        WindowTransparencyOnMouseOver = 0.75
    }
}

local checkboxSettings = {{
    key = "EnableTooltips",
    name = "SamuraiAtlasSettingsFrameContentMapSettingsEnableTooltipsCheckbox",
    label = SamuraiAtlasStrings.EnableTooltipsLabel
}, {
    key = "ResetZoneOnOpen",
    name = "SamuraiAtlasSettingsFrameContentMapSettingsResetZoneOnOpenCheckbox",
    label = SamuraiAtlasStrings.ResetZoneOnOpenLabel
}, {
    key = "ResetZoneOnChange",
    name = "SamuraiAtlasSettingsFrameContentMapSettingsResetZoneOnChangeCheckbox",
    label = SamuraiAtlasStrings.ResetZoneOnChangeLabel
}, {
    key = "RightClickToClose",
    name = "SamuraiAtlasSettingsFrameContentMapSettingsRightClickToCloseCheckbox",
    label = SamuraiAtlasStrings.RightClickToCloseLabel
}}

local function MergeDefaults(defaults, settings)
    for key, value in pairs(defaults) do
        if type(value) == "table" then
            settings[key] = settings[key] or {}
            MergeDefaults(value, settings[key])
        else
            if settings[key] == nil then
                settings[key] = value
            end
        end
    end
end

local function EnsureSettingsExist()
    MergeDefaults(DefaultSettings, SamuraiAtlas.Settings)
end

local function RegisterSlashCommands()
    LibSlash.RegisterSlashCmd("atlas", SamuraiAtlasSettings.Toggle)
end

local function SetTitleBarText()
    LabelSetText("SamuraiAtlasSettingsFrameTitleBarText", SamuraiAtlasStrings.SettingsTitleBarText)
end

local function UpdateCheckbox(name, value)
    local buttonName = name .. "Button" -- Reference the button inside the checkbox window
    if DoesWindowExist(buttonName) then
        ButtonSetPressedFlag(buttonName, value)
    else
        Utils.Debug("Checkbox does not exist: " .. tostring(buttonName))
    end
end

local function UpdateSlider(name, value, multiplier)
    if DoesWindowExist(name) then
        SliderBarSetCurrentPosition(name, value * multiplier)
    else
        Utils.Debug("Slider does not exist: " .. tostring(name))
    end
end

local function PopulateInterface()
    Utils.Debug("Populating SamuraiAtlas settings UI...")

    -- Set the text for the Map Settings tab dynamically
    if DoesWindowExist("SamuraiAtlasSettingsFrameContentTabMapSettingsLabel") then
        SamuraiAtlasUtils.Debug("Tab Map Settings Label exists.")
        LabelSetText("SamuraiAtlasSettingsFrameContentTabMapSettingsLabel", L"Map")
    else
        Utils.Debug("Tab Map Settings does not exist.")
    end

    -- Populate MapWindow settings
    local mapWindowSettings = SamuraiAtlas.Settings.MapWindow

    for _, setting in ipairs(checkboxSettings) do
        local checkboxName = setting.name
        -- Utils.Debug("Checking existence of: " .. checkboxName)

        if DoesWindowExist(checkboxName) then
            UpdateCheckbox(checkboxName, mapWindowSettings[setting.key])

            WindowSetShowing(checkboxName, true) -- Ensure the checkbox is visible

            local labelName = checkboxName .. "Label"
            if DoesWindowExist(labelName) then
                LabelSetText(labelName, setting.label)
                -- Utils.Debug("Label set for: " .. labelName)
            else
                -- Utils.Debug("Label does not exist: " .. labelName)
            end
            -- Utils.Debug("Checkbox visibility set: " .. checkboxName)
        else
            -- Utils.Debug("Checkbox does not exist: " .. checkboxName)
        end
    end

    -- Float settings (sliders)
    -- local floatSettings = {
    --     { key = "WindowScale", label = "Window Scale", multiplier = 100 },
    --     { key = "WindowTransparency", label = "Window Transparency", multiplier = 100 },
    --     { key = "WindowTransparencyOnCharacterMovement", label = "Transparency On Movement", multiplier = 100 },
    --     { key = "WindowTransparencyOnMouseOver", label = "Transparency On Mouse Over", multiplier = 100 },
    -- }

    -- for _, setting in ipairs(floatSettings) do
    --     local sliderName = "SamuraiAtlasSettingsFrameContentMapWindowSettings" .. setting.key .. "Slider"
    --     Utils.Debug("Checking existence of: " .. sliderName)
    --     if DoesWindowExist(sliderName) then
    --         UpdateSlider(sliderName, mapWindowSettings[setting.key], setting.multiplier)
    --         WindowSetShowing(sliderName, true) -- Ensure the slider is visible
    --         Utils.Debug("Slider visibility set: " .. sliderName)
    --     else
    --         Utils.Debug("Slider does not exist: " .. sliderName)
    --     end
    -- end
end

local function ApplySettingsWindowSettings()
    SetTitleBarText()
    PopulateInterface()

    -- TODO: Select default tab.
end

local function LayoutEditorRegistrations()
    LayoutEditor.RegisterWindow("SamuraiAtlasSettingsFrame", SamuraiAtlasStrings.SamuraiAtlasSettingsFrameTitle,
        SamuraiAtlasStrings.SamuraiAtlasSettingsFrameDescription, false, false, true, nil)
end

function SamuraiAtlasSettings.Initialize()
    Utils.Debug("Initializing Settings Window...")

    -- Register Settings Window-related event handlers, UI setup, etc.
    EnsureSettingsExist()

    ApplySettingsWindowSettings()

    LayoutEditorRegistrations()

    RegisterSlashCommands()
end

function SamuraiAtlasSettings.Toggle()
    local isVisible = WindowGetShowing("SamuraiAtlasSettingsFrame")

    if not isVisible then
        SamuraiAtlasSettings.Open()
    else
        SamuraiAtlasSettings.Close()
    end
end

function SamuraiAtlasSettings.Open()
    Utils.Debug("Opening SamuraiAtlas settings window.")

    -- Populate UI elements with current settings
    PopulateInterface()

    WindowSetShowing("SamuraiAtlasSettingsFrame", true)
end

function SamuraiAtlasSettings.Close()
    Utils.Debug("Closing SamuraiAtlas settings window.")
    WindowSetShowing("SamuraiAtlasSettingsFrame", false)
end

function SamuraiAtlasSettings.Shutdown()
    Utils.Debug("Shutting down Settings Window...")
    -- Cleanup Settings Window-related resources
end

function SamuraiAtlasSettings.OnElementLoaded(elementName)
    if elementName then
        Utils.Debug("Element loaded: " .. tostring(elementName))
    else
        Utils.Debug("OnElementLoaded called, but no element name provided.")
    end
end

function SamuraiAtlasSettings.OnCheckboxLBU()
    Utils.Debug("--------------------------======================--------------------------")
    Utils.Debug("OnCheckboxLBU function triggered.")
    Utils.Debug("--------------------------======================--------------------------")
	local checkboxName = SystemData.MouseOverWindow.name .. "Button"
	
	-- if( ButtonGetDisabledFlag(checkboxName) ) then return end
	
	ButtonSetPressedFlag(checkboxName, not ButtonGetPressedFlag(checkboxName))

    Utils.Debug("SystemData.MouseOverWindow.id: " .. tostring(SystemData.MouseOverWindow.id))
    Utils.Debug("SystemData.MouseOverWindow.name: " .. tostring(SystemData.MouseOverWindow.name))
    -- Parse the name of the element to get the settingsKey
    local settingsKey = string.match(checkboxName, "SamuraiAtlasSettingsFrameContentMapSettings(.*)Checkbox")
    
    SamuraiAtlas.Settings.MapWindow[settingsKey] = ButtonGetPressedFlag(checkboxName)
end
