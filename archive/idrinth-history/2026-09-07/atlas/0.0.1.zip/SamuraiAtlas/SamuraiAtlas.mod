<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
    <UiMod name="Samurai Atlas" version="1" date="2025-03-26">
        <Author name="Saiba Samurai" email="saiba.samurai@gmail.com" />
        <Description text="Creates a resizable world map." />

        <VersionSettings gameVersion="1.4.8" windowsVersion="1.0" savedVariablesVersion="1.0" />

        <Dependencies>
            <Dependency name="LibSlash" optional="false" forceEnable="true" />
        </Dependencies>

        <Files>
            <File name="SamuraiAtlas.lua" />
            <File name="Localization.lua" />
            <File name="ZoneInfo.lua" />
            <File name="SamuraiAtlasUtils.lua" />
            <File name="SamuraiAtlasSettings.lua" />
            <File name="SamuraiAtlasMap.lua" />
            
            <File name="SamuraiAtlasTemplates.xml" /> 
            <File name="SamuraiAtlasMap.xml" />
            <File name="SamuraiAtlasSettings.xml" />
        </Files>

        <SavedVariables>
            <SavedVariable name="SamuraiAtlas.Settings" />
        </SavedVariables>

        <OnInitialize>
            <CreateWindow name="SamuraiAtlasFrame" show="false" />
            <CreateWindow name="SamuraiAtlasSettingsFrame" show="false" />
            <CallFunction name="SamuraiAtlas.Initialize" />
        </OnInitialize>

        <OnUpdate>
        </OnUpdate>

        <OnShutdown>
        </OnShutdown>
    </UiMod>
</ModuleFile>