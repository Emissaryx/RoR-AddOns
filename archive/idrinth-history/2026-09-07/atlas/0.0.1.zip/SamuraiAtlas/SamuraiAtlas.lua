SamuraiAtlas = SamuraiAtlas or {}

function SamuraiAtlas.Initialize()
    SamuraiAtlasUtils.Debug("Samurai Atlas initializing...")

    -- Initialize SamuraiAtlasUtils
    SamuraiAtlasUtils.Initialize()

    -- Initialize settings
    SamuraiAtlasSettings.Initialize()

    -- Initialize Map Window
    SamuraiAtlasMap.Initialize()

    SamuraiAtlasUtils.Debug("Samurai Atlas initialized.")
end

function SamuraiAtlas.Shutdown()
    SamuraiAtlasUtils.Debug("Samurai Atlas shutting down...")
    SamuraiAtlasMap.Shutdown()
    SamuraiAtlasSettings.Shutdown()
    -- SamuraiAtlasUtils.Shutdown()
end