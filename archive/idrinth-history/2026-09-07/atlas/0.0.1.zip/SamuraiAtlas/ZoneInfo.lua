DEBUG(L"ZoneInfo.lua loaded successfully.")

ZoneLegends = {
    [161] = { -- The Inevitable City
    {
        label = SamuraiAtlasStrings.UndercroftLabel,
        description = SamuraiAtlasStrings.UndercroftDescription
    }, {
        label = SamuraiAtlasStrings.VipersPitLabel,
        description = SamuraiAtlasStrings.VipersPitDescription
    }, {
        label = SamuraiAtlasStrings.TheApexLabel,
        description = SamuraiAtlasStrings.TheApexDescription
    }, {
        label = SamuraiAtlasStrings.CitadelLabel,
        description = SamuraiAtlasStrings.CitadelDescription
    }, {
        label = SamuraiAtlasStrings.MonolithLabel,
        description = SamuraiAtlasStrings.MonolithDescription
    }, {
        label = SamuraiAtlasStrings.StablesLabel,
        description = SamuraiAtlasStrings.StablesDescription
    }}
    -- Add more zones and their legends as needed
}

ZoneDetails = {
    [1] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.MarshesOfMadness,
        adjacentZones = {
            north = 2,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 12,
        maxRank = 13
    },
    [2] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.TheBadlands,
        adjacentZones = {
            north = 3,
            east = nil,
            south = 1,
            west = nil
        },
        minRank = 22,
        maxRank = 23
    },
    [3] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.BlackCrag,
        adjacentZones = {
            north = 4,
            east = nil,
            south = 2,
            west = nil
        },
        minRank = 30,
        maxRank = 33
    },
    [4] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.ButchersPass,
        adjacentZones = {
            north = 5,
            east = nil,
            south = 3,
            west = nil
        },
        minRank = 37,
        maxRank = 40
    },
    [5] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.ThunderMountain,
        adjacentZones = {
            north = nil,
            east = nil,
            south = 4,
            west = nil
        },
        minRank = 34,
        maxRank = 37
    },
    [6] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.Ekrund,
        adjacentZones = {
            north = nil,
            east = 11,
            south = nil,
            west = 7
        },
        minRank = 1,
        maxRank = 8
    },
    [7] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.BarakVarr,
        adjacentZones = {
            north = 8,
            east = nil,
            south = 1,
            west = 6
        },
        minRank = 10,
        maxRank = 19
    },
    [8] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.BlackFirePass,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 20,
        maxRank = 29
    },
    [9] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.KadrinValley,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 38,
        maxRank = 40
    },
    [10] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.Stonewatch,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 37,
        maxRank = 40
    },
    [11] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.MountBloodhorn,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 1,
        maxRank = 7
    },
    [26] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.Cinderfall,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 34,
        maxRank = 37
    },
    [27] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.DeathPeak,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 34,
        maxRank = 37
    },
    [30] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.GatesOfEkrund,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 31,
        maxRank = 40
    },
    [31] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.MourkainTemple,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 41,
        maxRank = 50
    },
    [32] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.TheIronclad,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 1,
        maxRank = 10
    },
    [33] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.DoomfistCrater,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 11,
        maxRank = 20
    },
    [34] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.ThunderValley,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 21,
        maxRank = 30
    },
    [36] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.DragonbackPass,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 31,
        maxRank = 40
    },
    [37] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.BlackCragKeep,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 41,
        maxRank = 50
    },
    [38] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.BlackFireBasin,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 1,
        maxRank = 10
    },
    [39] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.LogrinsForge,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 11,
        maxRank = 20
    },
    [41] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.AltdorfWarQuarters,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 21,
        maxRank = 30
    },
    [42] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.TheUndercroft,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 31,
        maxRank = 40
    },
    [43] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.GromrilCrossing,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 41,
        maxRank = 50
    },
    [44] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.HowlingGorge,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 1,
        maxRank = 10
    },
    [47] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.TheOldDwarfRoad,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 11,
        maxRank = 20
    },
    [50] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.HuntersVale,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 21,
        maxRank = 30
    },
    [60] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.MountGunbad,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 31,
        maxRank = 40
    },
    [61] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.KarakEightPeaks,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 37,
        maxRank = 40
    },
    [62] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.KarazAKarak,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 37,
        maxRank = 40
    },
    [63] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.GunbadNursery,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 11,
        maxRank = 20
    },
    [64] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.GunbadLab,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 21,
        maxRank = 30
    },
    [65] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.SquigBoss,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 31,
        maxRank = 40
    },
    [66] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.GunbadBarracks,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 41,
        maxRank = 50
    },
    [96] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.KarakEightPeaksDaDeeps,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 1,
        maxRank = 10
    },
    [97] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.KarazAKarakMiddleDeeps,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 11,
        maxRank = 20
    },
    [100] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.Norsca,
        adjacentZones = {
            north = nil,
            east = 101,
            south = 106,
            west = nil
        },
        minRank = 1,
        maxRank = 4
    },
    [101] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.TrollCountry,
        adjacentZones = {
            north = nil,
            east = 108,
            south = 107,
            west = 100
        },
        minRank = 12,
        maxRank = 19
    },
    [102] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.HighPass,
        adjacentZones = {
            north = nil,
            east = 103,
            south = 108,
            west = 107
        },
        minRank = 26,
        maxRank = 29
    },
    [103] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.ChaosWastes,
        adjacentZones = {
            north = 104,
            east = nil,
            south = 105,
            west = 102
        },
        minRank = 30,
        maxRank = 33
    },
    [104] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.TheMaw,
        adjacentZones = {
            north = 161,
            east = nil,
            south = 103,
            west = nil
        },
        minRank = 37,
        maxRank = 40
    },
    [105] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.Praag,
        adjacentZones = {
            north = 103,
            east = nil,
            south = 109,
            west = 120
        },
        minRank = 34,
        maxRank = 37
    },
    [106] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.Nordland,
        adjacentZones = {
            north = 100,
            east = 107,
            south = nil,
            west = nil
        },
        minRank = 5,
        maxRank = 9
    },
    [107] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.Ostland,
        adjacentZones = {
            north = 101,
            east = nil,
            south = 102,
            west = 106
        },
        minRank = 10,
        maxRank = 15
    },
    [108] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.Talabecland,
        adjacentZones = {
            north = 102,
            east = 109,
            south = nil,
            west = 101
        },
        minRank = 20,
        maxRank = 25
    },
    [109] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.Reikland,
        adjacentZones = {
            north = 105,
            east = nil,
            south = 110,
            west = 108
        },
        minRank = 38,
        maxRank = 40
    },
    [110] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.Reikwald,
        adjacentZones = {
            north = 109,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 21,
        maxRank = 30
    },
    [118] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.TheKrakenSea,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 31,
        maxRank = 40
    },
    [120] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.WestPraag,
        adjacentZones = {
            north = nil,
            east = 105,
            south = nil,
            west = nil
        },
        minRank = 34,
        maxRank = 37
    },
    [130] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.Nordenwatch,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 1,
        maxRank = 10
    },
    [131] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.StonetrollCrossing,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 11,
        maxRank = 20
    },
    [132] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.TalabecDam,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 21,
        maxRank = 30
    },
    [133] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.MawOfMadness,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 31,
        maxRank = 40
    },
    [134] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.ReiklandHills,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 41,
        maxRank = 50
    },
    [135] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.TwistingTower,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 1,
        maxRank = 10
    },
    [136] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.BattleForPraag,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 11,
        maxRank = 20
    },
    [137] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.GrovodCaverns,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 21,
        maxRank = 30
    },
    [138] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.ReiklandFactory,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 31,
        maxRank = 40
    },
    [139] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.HighPassCemetery,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 41,
        maxRank = 50
    },
    [141] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.SacellumArena,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 1,
        maxRank = 10
    },
    [144] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.OuterDark,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 11,
        maxRank = 20
    },
    [152] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.TheSewersOfAltdorf,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 21,
        maxRank = 30
    },
    [153] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.TheSewersOfAltdorf,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 31,
        maxRank = 40
    },
    [154] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.WarpbladeTunnels,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 41,
        maxRank = 50
    },
    [155] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.SacellumDungeons,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 1,
        maxRank = 10
    },
    [156] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.SacellumDungeons,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 11,
        maxRank = 20
    },
    [157] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.TempleOfSigmar,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 21,
        maxRank = 30
    },
    [158] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.TheMonolith,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 31,
        maxRank = 40
    },
    [159] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.TheSacellum,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 41,
        maxRank = 50
    },
    [160] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.BastionStair,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 1,
        maxRank = 10
    },
    [161] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.TheInevitableCity,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 1,
        maxRank = 40
    },
    [162] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.Altdorf,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 21,
        maxRank = 30
    },
    [163] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.TharIgnan,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 31,
        maxRank = 40
    },
    [164] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.LordSlaurith,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 41,
        maxRank = 50
    },
    [165] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.KaarnTheVanquisher,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 1,
        maxRank = 10
    },
    [166] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.SkullLordVarIthrok,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 11,
        maxRank = 20
    },
    [170] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.AltdorfPalace,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 21,
        maxRank = 30
    },
    [171] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.TheScreamingCat,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 31,
        maxRank = 40
    },
    [172] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.TheEternalCitadel,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 41,
        maxRank = 50
    },
    [174] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.TheElysium,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 1,
        maxRank = 10
    },
    [175] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.WindsOfChaos,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 11,
        maxRank = 20
    },
    [176] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.SigmarsCrypts,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 21,
        maxRank = 30
    },
    [177] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.WarpbladeTunnels,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 31,
        maxRank = 40
    },
    [178] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.TheViperPit,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 41,
        maxRank = 50
    },
    [179] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.TombOfTheVultureLord,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 1,
        maxRank = 10
    },
    [189] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.BrightWizardCollege,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 11,
        maxRank = 20
    },
    [190] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.BrightWizardCollege,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 21,
        maxRank = 30
    },
    [191] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.NecropolisOfZandri,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 31,
        maxRank = 40
    },
    [195] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.BloodwroughtEnclave,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 41,
        maxRank = 50
    },
    [196] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.BilerotBurrow,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 1,
        maxRank = 10
    },
    [197] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.TheBrightWizardCollege,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 11,
        maxRank = 20
    },
    [198] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.SigmarsHammer,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 21,
        maxRank = 30
    },
    [200] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.TheBlightedIsle,
        adjacentZones = {
            north = nil,
            east = nil,
            south = 206,
            west = nil
        },
        minRank = 1,
        maxRank = 7
    },
    [201] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.TheShadowlands,
        adjacentZones = {
            north = 206,
            east = 206,
            south = 207,
            west = nil
        },
        minRank = 10,
        maxRank = 15
    },
    [202] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.Avelorn,
        adjacentZones = {
            north = 207,
            east = nil,
            south = 208,
            west = 207
        },
        minRank = 20,
        maxRank = 25
    },
    [203] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.Caledor,
        adjacentZones = {
            north = nil,
            east = 205,
            south = nil,
            west = {208, 204}
        },
        minRank = 30,
        maxRank = 33
    },
    [204] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.FellLanding,
        adjacentZones = {
            north = nil,
            east = 203,
            south = nil,
            west = nil
        },
        minRank = 37,
        maxRank = 40
    },
    [205] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.Dragonwake,
        adjacentZones = {
            north = 220,
            east = 209,
            south = nil,
            west = 203
        },
        minRank = 34,
        maxRank = 37
    },
    [206] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.Chrace,
        adjacentZones = {
            north = 200,
            east = nil,
            south = 201,
            west = 201
        },
        minRank = 8,
        maxRank = 9
    },
    [207] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.Ellyrion,
        adjacentZones = {
            north = 201,
            east = nil,
            south = 202,
            west = nil
        },
        minRank = 16,
        maxRank = 19
    },
    [208] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.Saphery,
        adjacentZones = {
            north = 202,
            east = 209,
            south = 203,
            west = nil
        },
        minRank = 26,
        maxRank = 29
    },
    [209] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.Eataine,
        adjacentZones = {
            north = 208,
            east = 210,
            south = nil,
            west = 205
        },
        minRank = 38,
        maxRank = 40
    },
    [210] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.ShiningWay,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 37,
        maxRank = 40
    },
    [220] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.IsleOfTheDead,
        adjacentZones = {
            north = nil,
            east = nil,
            south = 205,
            west = nil
        },
        minRank = 34,
        maxRank = 37
    },
    [230] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.KhainesEmbrace,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 1,
        maxRank = 10
    },
    [231] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.PhoenixGate,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 11,
        maxRank = 20
    },
    [232] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.TorAnroc,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 21,
        maxRank = 30
    },
    [234] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.SerpentsPassage,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 31,
        maxRank = 40
    },
    [235] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.DragonsBane,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 41,
        maxRank = 50
    },
    [236] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.LostTempleOfIsha,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 1,
        maxRank = 10
    },
    [237] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.CaledorWoods,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 11,
        maxRank = 20
    },
    [238] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.BloodOfTheBlackCairn,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 21,
        maxRank = 30
    },
    [241] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.TombOfTheStars,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 31,
        maxRank = 40
    },
    [242] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.TombOfTheMoon,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 41,
        maxRank = 50
    },
    [243] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.TombOfTheSky,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 1,
        maxRank = 10
    },
    [244] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.TombOfTheSun,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 11,
        maxRank = 20
    },
    [252] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.Altdorf,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 1,
        maxRank = 40
    },
    [253] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.TheInevitableCity,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 31,
        maxRank = 40
    },
    [260] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.TheLostVale,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 41,
        maxRank = 50
    },
    [261] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.FistOfMalekith,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 1,
        maxRank = 10
    },
    [262] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.Lothern,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 11,
        maxRank = 20
    },
    [274] = {
        width = 800,
        height = 840,
        name = SamuraiAtlasStrings.PyramidOfSettra,
        adjacentZones = {
            north = nil,
            east = nil,
            south = nil,
            west = nil
        },
        minRank = 21,
        maxRank = 30
    }
}
