SamuraiAtlasMap = SamuraiAtlasMap or {}

local MapSettings = {}

local currentMapZone = GameData.Player.zone

local lastPlayerPosition = {
    x = 0,
    y = 0
}
local isPlayerMoving = false
local stopMovementTimer = nil -- Timer to reset transparency
local movementTimeout = 0.1 -- Time in seconds to wait before resetting transparency
local timeSinceLastMovement = 0 -- Tracks time since the last movement
local currentTransparency = 1.0 -- Default transparency

local dynamicDirectionButtons = {} -- Track dynamically created buttons

local function GetMapSettings()
    MapSettings = SamuraiAtlas.Settings and SamuraiAtlas.Settings.MapWindow
end

local function RegisterEventHandlers()
    RegisterEventHandler(SystemData.Events.PLAYER_ZONE_CHANGED, "SamuraiAtlasMap.OnZoneChanged")
    RegisterEventHandler(SystemData.Events.LOADING_END, "SamuraiAtlasMap.OnLoadingEnd")
    RegisterEventHandler(SystemData.Events.RELOAD_INTERFACE, "SamuraiAtlasMap.OnReloadInterface")
    RegisterEventHandler(SystemData.Events.PLAYER_POSITION_UPDATED, "SamuraiAtlasMap.OnPlayerPositionUpdated")

    WindowRegisterEventHandler("SamuraiAtlasFrame", SystemData.Events.UPDATE_PROCESSED, "SamuraiAtlasMap.OnUpdate")
end

local function SetTitleBarText()
    LabelSetText("SamuraiAtlasFrameTitleBarText", SamuraiAtlasStrings.TitleBarText)
end

local function UpdateZoneName()
    SamuraiAtlasUtils.Debug("Updating zone name...")
    local zoneName = (ZoneDetails[currentMapZone] and ZoneDetails[currentMapZone].name) or "Unknown Zone"
    
    if not DoesWindowExist("SamuraiAtlasFrameZoneNameLabel") then
        SamuraiAtlasUtils.Debug("SamuraiAtlasFrameZoneNameLabel does not exist.")
        return
    else
        SamuraiAtlasUtils.Debug("SamuraiAtlasFrameZoneNameLabel exists.")
        SamuraiAtlasUtils.Debug("Zone name: " .. tostring(zoneName))
    end

    LabelSetText("SamuraiAtlasFrameZoneNameLabel", towstring(zoneName))
end

local function UpdateLegend()
    SamuraiAtlasUtils.Debug("Updating legend...")
    local legendData = ZoneLegends[currentMapZone]

    if legendData then
        SamuraiAtlasUtils.Debug("Updating legend for zone: " .. tostring(currentZone))

        -- Show the legend frame
        WindowSetShowing("SamuraiAtlasFrameLegend", true)

        if DoesWindowExist("SamuraiAtlasFrameLegendBackground") then
            -- Set the background color to semi-transparent black
            WindowSetTintColor("SamuraiAtlasFrameLegendBackground", 0, 0, 0) -- RGB values (0, 0, 0 for black)
            WindowSetAlpha("SamuraiAtlasFrameLegendBackground", 0) -- Alpha value (0.5 for 50% transparency)
        else
            SamuraiAtlasUtils.Debug("SamuraiAtlasFrameLegendBackground does not exist.")
        end

        -- Clear existing legend items
        for i = 1, #legendData do
            local labelName = "SamuraiAtlasFrameLegendContentItem" .. i
            if DoesWindowExist(labelName) then
                DestroyWindow(labelName)
            end
        end

        -- Add new legend items
        local startY = 0 -- Starting Y position for the first item
        local spacing = 28 -- Spacing between items
        for i, item in ipairs(legendData) do
            local labelName = "SamuraiAtlasFrameLegendContentItem" .. i
            CreateWindowFromTemplate(labelName, "DefaultLabel", "SamuraiAtlasFrameLegendContent")

            -- Set the text for the label
            LabelSetText(labelName, item.label)

            -- Position the label
            WindowClearAnchors(labelName)
            WindowAddAnchor(labelName, "topleft", "SamuraiAtlasFrameLegendContent", "topleft", 0, startY)

            -- Attach a unique ID to the label
            WindowSetId(labelName, i)

            -- Update the Y position for the next item
            startY = startY + spacing
        end

        -- Store the legend data for tooltips
        SamuraiAtlasMap.CurrentLegendData = legendData
    else
        SamuraiAtlasUtils.Debug("No legend data for zone: " .. tostring(currentZone))

        -- Hide the legend frame if no legend data exists
        WindowSetShowing("SamuraiAtlasFrameLegend", false)
    end
end

local function RegisterMapPins()
    SamuraiAtlas.mapPinFilters = {{
        label = SamuraiAtlasStrings.ObjectivesLabel,
        slice = "FlagNeutral",
        scale = 1.0,
        pins = {SystemData.MapPips.OBJECTIVE}
    }, {
        label = SamuraiAtlasStrings.KeepsLabel,
        slice = "Keep-Grayed",
        scale = 0.75,
        pins = {SystemData.MapPips.KEEP}
    }, {
        label = SamuraiAtlasStrings.GroupMembersLabel,
        slice = "PlayerCircleGroupmate",
        scale = 1.75,
        pins = {SystemData.MapPips.GROUP_MEMBER}
    }, {
        label = SamuraiAtlasStrings.GroupLeaderLabel,
        slice = "PlayerCircleGroupLeader",
        scale = 1.75,
        pins = {SystemData.MapPips.GROUP_LEADER}
    }}

    SamuraiAtlas.mapPinGutters = {{
        label = SamuraiAtlasStrings.ImportantMonstersLabel,
        slice = "BombNeutral",
        scale = 1.0,
        pins = {SystemData.MapPips.IMPORTANT_MONSTER}
    }}
end

local function SetMapTransparency(alpha)
    -- Ensure alpha is set to 1 for Map before setting to the desired value.
    WindowSetAlpha("SamuraiAtlasFrameMapContainerMapDisplay", 1.0)

    WindowSetAlpha("SamuraiAtlasFrame", alpha)
    WindowSetAlpha("SamuraiAtlasFrameTitleBar", alpha)
    WindowSetAlpha("SamuraiAtlasFrameMapContainerMapDisplay", alpha)
    WindowSetAlpha("SamuraiAtlasFrameLegend", alpha)
    WindowSetAlpha("SamuraiAtlasFrameLegendContent", alpha)

    -- Dynamically set alpha for all directional buttons
    for _, buttonName in ipairs(dynamicDirectionButtons) do
        if DoesWindowExist(buttonName) then
            WindowSetAlpha(buttonName, alpha)
        end
    end

    currentTransparency = alpha
    SamuraiAtlasUtils.Debug("Current transparency after change: " .. tostring(currentTransparency))
end

local function InitializeMapDisplay()
    RemoveMapInstance("SamuraiAtlasFrameMapContainerMapDisplay")
    CreateMapInstance("SamuraiAtlasFrameMapContainerMapDisplay", SystemData.MapTypes.NORMAL)
end

local function ApplyMapWindowSettings()
    local zoneId = GameData.Player.zone
    local dimensions = ZoneDetails[zoneId]

    SamuraiAtlasUtils.Debug("Zone ID: " .. tostring(zoneId))

    if dimensions then
        SamuraiAtlasUtils.Debug("Map Dimensions: Width=" .. tostring(dimensions.width) .. ", Height=" ..
                                    tostring(dimensions.height))
        WindowSetDimensions("SamuraiAtlasFrame", dimensions.width, dimensions.height)
    else
        SamuraiAtlasUtils.Debug("No dimensions found for Zone ID: " .. tostring(zoneId))
        WindowSetDimensions("SamuraiAtlasFrame", 800, 840)
    end

    WindowSetMovable("SamuraiAtlasFrame", true)

    -- Ensure WindowScale is valid before applying it
    if MapSettings.WindowScale then
        WindowSetScale("SamuraiAtlasFrame", MapSettings.WindowScale)
    else
        SamuraiAtlasUtils.Debug("Invalid or missing WindowScale. Using default scale of 1.0.")
        WindowSetScale("SamuraiAtlasFrame", 1.0) -- Default scale
    end
end

local function UpdateMap()
    SamuraiAtlasUtils.Debug("Updating map...")
    SamuraiAtlasUtils.Debug("Current map zone: " .. tostring(currentMapZone))
    MapSetMapView("SamuraiAtlasFrameMapContainerMapDisplay", GameDefs.MapLevel.ZONE_MAP, currentMapZone)
    UpdateZoneName()
    UpdateLegend()

    -- Update directional buttons
    SamuraiAtlasMap.UpdateDirectionalButtons()

    -- Restore the transparency level
    SetMapTransparency(currentTransparency)

    SamuraiAtlasUtils.Debug("Map updated with zone: " .. tostring(currentMapZone))
end

local function UpdateMapView()
    -- Update MapDisplay reference
    UpdateMap()
    ApplyMapWindowSettings()
end

local function GenerateTooltip(zone)
    SamuraiAtlasUtils.Debug("Generating tooltip for zone: " .. tostring(zone.name))
    local zoneName = tostring(zone.name)
    local minRank = zone.minRank or 1
    local maxRank = zone.maxRank or 4
    local zoneStatus = "<ZoneStatus>"

    tooltipString = string.format("%s \nRanks: %0d-%0d\n %s", zoneName, minRank, maxRank, zoneStatus)
    SamuraiAtlasUtils.Debug("Tooltip string: " .. tooltipString)

    return towstring(tooltipString)
end

local function LayoutEditorRegistrations()
    LayoutEditor.RegisterWindow("SamuraiAtlasFrame", SamuraiAtlasStrings.SamuraiAtlasFrameTitle,
        SamuraiAtlasStrings.SamuraiAtlasFrameDescription, false, false, true, nil)
end

function SamuraiAtlasMap.OnPlayerPositionUpdated(x, y)
    -- SamuraiAtlasUtils.Debug("SamuraiAtlasMap.OnPlayerPositionUpdated called. Player Position: " .. tostring(x) .. ", " .. tostring(y))

    -- Check if the player's position has changed
    if not isMouseOverMap then
        if x ~= lastPlayerPosition.x or y ~= lastPlayerPosition.y then
            -- Player is moving
            -- SamuraiAtlasUtils.Debug("Player is moving. Current Position: " .. tostring(x) .. ", " .. tostring(y))
            if not isPlayerMoving then
                -- SamuraiAtlasUtils.Debug("Player started moving. Setting transparency to 0.25.")
                isPlayerMoving = true
                SetMapTransparency(0.25)
            end

            -- Reset the movement timer
            timeSinceLastMovement = 0
        end
    end
    lastPlayerPosition.x = x
    lastPlayerPosition.y = y
end

function SamuraiAtlasMap.OnUpdate(elapsed)
    if isPlayerMoving then
        timeSinceLastMovement = timeSinceLastMovement + elapsed
        -- SamuraiAtlasUtils.Debug("Time since last movement: " .. tostring(timeSinceLastMovement))
        if timeSinceLastMovement >= movementTimeout then
            -- SamuraiAtlasUtils.Debug("Player stopped moving. Resetting transparency to 1.0.")
            isPlayerMoving = false
            SetMapTransparency(1.0)
        end
    end
end

function SamuraiAtlasMap.OnMouseLeaveMap()
    SamuraiAtlasUtils.Debug("Mouse left the map.")
    -- Optionally, you can reset transparency here if needed.
end

function SamuraiAtlasMap.Initialize()
    SamuraiAtlasUtils.Debug("Initializing Map Window...")

    GetMapSettings()

    -- Register Map Window-related event handlers, UI setup, etc.
    ApplyMapWindowSettings()
    SetTitleBarText()
    InitializeMapDisplay()
    RegisterMapPins()

    LayoutEditorRegistrations()
    RegisterEventHandlers()
end

function SamuraiAtlasMap.OnZoneChanged()
    SamuraiAtlasUtils.Debug("OnZoneChanged called. Current zone: " .. tostring(currentMapZone))
    if MapSettings.ResetZoneOnChange and not (currentMapZone == GameData.Player.zone) then
        SamuraiAtlasUtils.Debug("Zone changed. Resetting map zone to player's current zone.")
        currentMapZone = GameData.Player.zone
    end

    UpdateMap()
end

function SamuraiAtlasMap.OnReloadInterface()
    SamuraiAtlasUtils.Debug("SamuraiAtlasMap.OnReloadInterface called.")

    SamuraiAtlasMap.OnLoadingEnd()
end

function SamuraiAtlasMap.OnLoadingEnd()
    SamuraiAtlasUtils.Debug("SamuraiAtlasMap.OnLoadingEnd called.")

    UpdateMapView()
end

function SamuraiAtlasMap.Toggle()
    WindowSetShowing("SamuraiAtlasFrame", not WindowGetShowing("SamuraiAtlasFrame"))

    if WindowGetShowing("SamuraiAtlasFrame") and  MapSettings.ResetZoneOnOpen then
        SamuraiAtlasUtils.Debug("Resetting map zone to player's current zone on toggle.")
        currentMapZone = GameData.Player.zone
        UpdateMap()
    end
end

function SamuraiAtlasMap.OnMapRBU()
    SamuraiAtlasUtils.Debug("SamuraiAtlasMap.OnRButtonUp called.")

    -- Handle right-click events here
    if MapSettings.RightClickToClose and WindowGetShowing("SamuraiAtlasFrame") then
        SamuraiAtlasMap.Toggle()
    end
end

function SamuraiAtlasMap.Shutdown()
    SamuraiAtlasUtils.Debug("Shutting down Map Window...")

    -- Cleanup Map Window-related resources
    LayoutEditor.UnregisterWindow("SamuraiAtlasFrame")
    WindowUnregisterEventHandler("SamuraiAtlasFrame", SystemData.Events.UPDATE_PROCESSED)
end

-- Legend Item functions
function SamuraiAtlasMap.OnLegendItemMouseOver()
    SamuraiAtlasMap.OnMouseOver()

    if not MapSettings.EnableTooltips then return end

    local labelName = SystemData.ActiveWindow.name -- Get the name of the window that triggered the event
    -- SamuraiAtlasUtils.Debug("Mouse over legend item: " .. labelName)

    local id = WindowGetId(labelName)
    -- SamuraiAtlasUtils.Debug("Legend item ID: " .. tostring(id))
    if id and SamuraiAtlasMap.CurrentLegendData and SamuraiAtlasMap.CurrentLegendData[id] then
        -- SamuraiAtlasUtils.Debug("Legend item data found for ID: " .. tostring(id))
        local description = SamuraiAtlasMap.CurrentLegendData[id].description
        -- SamuraiAtlasUtils.Debug("Legend item description: " .. tostring(description))

        -- Create a tooltip for the legend item
        Tooltips.CreateTextOnlyTooltip(labelName)
        Tooltips.SetTooltipText(1, 1, description)
        Tooltips.AnchorTooltip(Tooltips.ANCHOR_CURSOR)
        Tooltips.Finalize()
    else
        SamuraiAtlasUtils.Debug("ERROR: No data found for label: " .. labelName)
    end
end

function SamuraiAtlasMap.OnLegendItemMouseLeave()
    Tooltips.ClearTooltip()
end

function SamuraiAtlasMap.UpdateDirectionalButtons()
    -- Clear existing dynamic buttons
    for _, buttonName in ipairs(dynamicDirectionButtons) do
        if DoesWindowExist(buttonName) then
            DestroyWindow(buttonName)
        end
    end
    dynamicDirectionButtons = {} -- Reset the tracking table

    local adjacentZones = ZoneDetails[currentMapZone] and ZoneDetails[currentMapZone].adjacentZones or {}
    local texSlices = {
        north = { normal = "NextZoneArrow-North", rollover = "NextZoneArrow-North-ROLLOVER" },
        east = { normal = "NextZoneArrow-East", rollover = "NextZoneArrow-East-ROLLOVER" },
        south = { normal = "NextZoneArrow-South", rollover = "NextZoneArrow-South-ROLLOVER" },
        west = { normal = "NextZoneArrow-West", rollover = "NextZoneArrow-West-ROLLOVER" }
    }
    local anchorPoints = {
        north = { point = "top", relativePoint = "top", offsetX = 0, offsetY = 50, xSpacing = 75, ySpacing = 0 },
        east = { point = "right", relativePoint = "right", offsetX = -10, offsetY = 0, xSpacing = 0, ySpacing = 75 },
        south = { point = "bottom", relativePoint = "bottom", offsetX = 0, offsetY = -10, xSpacing = 75, ySpacing = 0 },
        west = { point = "left", relativePoint = "left", offsetX = 10, offsetY = 0, xSpacing = 0, ySpacing = 75 }
    }

    for direction, zones in pairs(adjacentZones) do
        if type(zones) ~= "table" then zones = { zones } end

        for i, zone in ipairs(zones) do
            local buttonName = "SamuraiAtlasFrameDynamicDirectionButton" .. direction .. i
            CreateWindowFromTemplate(buttonName, "TSamuraiAtlasDirectionButton", "SamuraiAtlasFrame")
            table.insert(dynamicDirectionButtons, buttonName) -- Track the button

            -- Assign TexSlices based on direction
            ButtonSetTextureSlice(buttonName, Button.ButtonState.NORMAL, "EA_BigMap01_d5", texSlices[direction].normal)
            ButtonSetTextureSlice(buttonName, Button.ButtonState.HIGHLIGHTED, "EA_BigMap01_d5", texSlices[direction].rollover)

            -- Position the button dynamically
            local anchor = anchorPoints[direction]
            local offsetX = anchor.offsetX + (i - 1) * anchor.xSpacing
            local offsetY = anchor.offsetY + (i - 1) * anchor.ySpacing

            WindowClearAnchors(buttonName)
            WindowAddAnchor(buttonName, anchor.point, "SamuraiAtlasFrame", anchor.relativePoint, offsetX, offsetY)

            -- Attach the zone ID to the button
            WindowSetId(buttonName, zone)
        end
    end
end

function SamuraiAtlasMap.OnDynamicDirectionButtonClicked()
    local buttonName = SystemData.ActiveWindow.name
    local zoneId = WindowGetId(buttonName)

    if zoneId and zoneId ~= currentMapZone then
        currentMapZone = zoneId
        UpdateMap()
    end
end

function SamuraiAtlasMap.OnDynamicDirectionButtonMouseOver()
    if not MapSettings.EnableTooltips then return end

    -- Ensure the MapContainer's OnMouseOver event is still recognized
    SamuraiAtlasMap.OnMouseOver()

    local buttonName = SystemData.ActiveWindow.name
    local zoneId = WindowGetId(buttonName)
    local zoneDetails = ZoneDetails[zoneId]

    if zoneDetails then
        local tooltip = GenerateTooltip(zoneDetails)
        Tooltips.CreateTextOnlyTooltip(buttonName)
        Tooltips.SetTooltipText(1, 1, tooltip)
        Tooltips.AnchorTooltip(Tooltips.ANCHOR_CURSOR)
        Tooltips.Finalize()
    end
end

function SamuraiAtlasMap.OnDynamicDirectionButtonMouseLeave()
    Tooltips.ClearTooltip()
end

-- Map Pin functions
function SamuraiAtlasMap.OnMouseOver()
    -- Ensure the map is not transparent even if the player is moving
    isMouseOverMap = true

    if isPlayerMoving then
        SamuraiAtlasUtils.Debug("Mouse is over the map. Resetting transparency.")
        SetMapTransparency(1.0)
        isPlayerMoving = false
    end
end

function SamuraiAtlasMap.OnMouseOverEnd()
    -- Reset the transparency if the mouse leaves the map
    isMouseOverMap = false
end

-- Map Pin functions
function SamuraiAtlasMap.OnMouseOverPoint()
    if not MapSettings.EnableTooltips then return end

    Tooltips.CreateMapPointTooltip("SamuraiAtlasFrameMapContainerMapDisplay",
        SamuraiAtlasFrameMapContainerMapDisplay.MouseoverPoints, Tooltips.ANCHOR_CURSOR)
end

function SamuraiAtlasMap.OnMouseLeaveMapPin()
    Tooltips.ClearTooltip()
end
