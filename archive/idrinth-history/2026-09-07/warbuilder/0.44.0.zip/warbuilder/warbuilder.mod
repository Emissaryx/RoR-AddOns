<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
    <UiMod name="warbuilder" version="0.44" date="1/5/2016">
		<VersionSettings gameVersion="1.4.8" windowsVersion="1.0" savedVariablesVersion="1.0" /> 
		<Author name="Sullemunk" />
        <Description text=" Plan, Build and Share Speccs addon made by Sullemunk for RoR" />
         <Dependencies>         
      <Dependency name="EA_ChatWindow" />         
      <Dependency name="LibSlash" />      
    </Dependencies>             
        <Files>
		
            <File name="warbuilder.lua" />
		  <File name="warbuilder.xml" />
        </Files>
    <SavedVariables>         
		<SavedVariable name="WarBuilderSave"  global="true"/>
		<SavedVariable name="WarBuilderSettings"  global="true"/>    	  
	  
    </SavedVariables>              
	<OnInitialize>
             <CallFunction name="Initilize" />
        </OnInitialize>
        <OnUpdate>
  
    	  </OnUpdate>
        <OnShutdown />
    </UiMod>
</ModuleFile>