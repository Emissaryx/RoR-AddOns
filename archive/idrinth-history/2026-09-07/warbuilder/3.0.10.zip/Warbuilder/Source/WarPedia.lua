WarPedia = {}

WarPedia.data = nil           -- data we receive from C
WarPedia.orderTable = {}
WarPedia.listBoxData = {}     -- same data, but organized in such a way that ListBox can display it.
WarPedia.rowToEntryMap = {}   -- map used to go from the # of the row to the entry in WarPedia.data
WarPedia.numTotalRows = 0                -- this value is used to count how many rows are currently visible in the listbox
WarPedia.lastPressedButtonId = 0


--[[
WarPedia.FakeTable = {
[1]={
	name=L" <icon"..towstring(Icons.GetCareerIconIDFromCareerLine(1))..L"> Iron Breaker",
	id=1,
	expanded=false,
	parentEntryId=0,
	childEntries={
	[1]={name=L"Core",id=100,expanded=false,parentEntryId=1,childEntries={}},
	[2]={name=L"Path of Vengence",id=101,expanded=false,parentEntryId=101,childEntries={
			[1]={name=L"Binding Grudge",id=1010,expanded=false,parentEntryId=101,childEntries={}},
			[2]={name=L"Heavy Blow",id=1011,expanded=false,parentEntryId=101,childEntries={}},
			[3]={name=L"Stone Breaker",id=1012,expanded=false,parentEntryId=101,childEntries={}},
	}},
	[3]={name=L"Path of Stone",id=102,expanded=false,parentEntryId=1,childEntries={
			[1]={name=L"Grudging Blow",id=1020,expanded=false,parentEntryId=101,childEntries={}},
			[2]={name=L"Vengeful Strike",id=1021,expanded=false,parentEntryId=101,childEntries={}},
			[3]={name=L"Shield of Reprisal",id=1022,expanded=false,parentEntryId=101,childEntries={}},
	}},
	[4]={name=L"Path of Brootherhood",id=103,expanded=false,parentEntryId=1,childEntries={}},
	}
	},
[2]={
	name=L" <icon"..towstring(Icons.GetCareerIconIDFromCareerLine(2))..L"> Slayer",
	id=2,
	expanded=false,
	parentEntryId=0,
	childEntries={
	[1]={name=L"Path of The Trollslayer",id=104,expanded=false,parentEntryId=2,childEntries={}},
	[2]={name=L"Path of The Giantslayer",id=105,expanded=false,parentEntryId=2,childEntries={}},
	[3]={name=L"Path of The Skavenslayer",id=106,expanded=false,parentEntryId=2,childEntries={}},
	}
	},	
}



	for k,v in pairs(Warbuilder.Career[1].Core) do 
	for a,b in pairs(Warbuilder.Career[1].Core[k]) do 
	
		if b.ID ~= nil then			
				--table.insert(SearchTable,{ID=b.ID,Path=0,BuffType=b.BuffType,MinLevel=b.MinLevel,Line=h,CareerName=GetCareerLine(h),AbilityName=GetAbilityName(b.ID),Type=b.Type,Icon=b.Icon,Rank=(b.Rank or 0)})			
			table.insert(WarPedia.FakeTable[1]["childEntries"][1]["childEntries"],{id=b.ID,expandable=false,parentEntryId=100,name=L" <icon"..towstring(b.Icon)..L">"..GetAbilityName(b.ID),childEntries={}})			
	end 
	end
	end

--]]


function WarPedia.Build()
WarPedia.FakeTable = {}

	for h = 1,24 do
	
	WarPedia.FakeTable[h] = {	name=L" <icon"..towstring(Icons.GetCareerIconIDFromCareerLine(h))..L"> "..towstring(GetCareerLine(h)),
	id=h,
	expanded=false,
	parentEntryId=0,
	childEntries={name=L"Core",id=h*100,expanded=false,parentEntryId=h,childEntries={}}
	}
	
	for i=1,3 do	
	table.insert(WarPedia.FakeTable[h]["childEntries"],{id=(h*100)+(i*20),expanded=false,parentEntryId=h*100,name=GetSpecializationPathName((3*h-(3-i))),childEntries={}})			

	for k,v in pairs(Warbuilder.Career[h].Path[i].Core) do  if type(Warbuilder.Career[h].Path[i].Core[k])== "table" then 
	
		if v.ID ~= nil then
			
			table.insert(WarPedia.FakeTable[h]["childEntries"][i]["childEntries"],{id=(h*100)+(i*20)+k,expanded=false,parentEntryId=(h*100)+(i*20),name=towstring(v.MinLevel or L"  ")..L"  <icon"..towstring(v.Icon)..L"> "..GetAbilityName(v.ID),childEntries={},type=v.Type,EntryData=v})			
			
			--	table.insert(WarPedia.FakeTable,{ID=v.ID,Path=v.Path,BuffType=v.BuffType,MinLevel=v.MinLevel,Line=h,CareerName=GetCareerLine(h),AbilityName=GetAbilityName(v.ID),Type=v.Type,Icon=v.Icon,Rank=(v.Rank or 0)})
			
	end 
	end
	end


	for k,v in pairs(Warbuilder.Career[h].Path[i]) do
	if Warbuilder.Career[h].Path[i][k].ID ~= nil then
			
			--	table.insert(WarPedia.FakeTable,{ID=v.ID,Path=v.Path,BuffType=v.BuffType,MinLevel=v.MinLevel,Line=h,CareerName=GetCareerLine(h),AbilityName=GetAbilityName(v.ID),Type=v.Type,Icon=v.Icon,Rank=(v.Rank or 0)})
			table.insert(WarPedia.FakeTable[h]["childEntries"][i]["childEntries"],{id=(h*100)+(i*20)+k,expanded=false,parentEntryId=(h*100)+(i*20),name=towstring(v.MinLevel or L"  ")..L"  <icon"..towstring(v.Icon)..L"> "..GetAbilityName(v.ID),childEntries={},type=v.Type,EntryData=v})			

	end
	end

	end

	for k,v in pairs(Warbuilder.Career[h].Core) do 
	for a,b in pairs(Warbuilder.Career[h].Core[k]) do 
	
		if b.ID ~= nil then
			table.insert(WarPedia.FakeTable[h]["childEntries"],{id=(h*100)+a,expanded=false,parentEntryId=h*100,name=towstring(b.MinLevel or L"  ")..L"  <icon"..towstring(b.Icon)..L"> "..GetAbilityName(b.ID),childEntries={},type=b.Type,EntryData=b})			
			
				--table.insert(WarPedia.FakeTable,{ID=b.ID,Path=0,BuffType=b.BuffType,MinLevel=b.MinLevel,Line=h,CareerName=GetCareerLine(h),AbilityName=GetAbilityName(b.ID),Type=b.Type,Icon=b.Icon,Rank=(b.Rank or 0)})
			
	end 
	end
	end

end
return
end


function WarPedia.Search(SearchInput)
WarPedia.SearchTable = {}
local Search_Name = wstring.lower(towstring(SearchInput))

	for h = 1,24 do
	for i=1,3 do
	for k,v in pairs(Warbuilder.Career[h].Path[i]) do
		if Warbuilder.Career[h].Path[i][k].ID ~= nil then
				if wstring.find(wstring.lower(wstring.sub(GetAbilityName(Warbuilder.Career[h].Path[i][k].ID),1,-3)),Search_Name) then
				table.insert(WarPedia.SearchTable,{[h]={[i]={ID=v.ID,Path=v.Path,BuffType=v.BuffType,MinLevel=v.MinLevel,Line=h,CareerName=GetCareerLine(h),AbilityName=GetAbilityName(v.ID),Type=v.Type,Icon=v.Icon,Rank=(v.Rank or 0)}}})											
				end
		
		end
	end
--[[
	for k,v in pairs(Warbuilder.Career[h].Path[i].Core) do  if type(Warbuilder.Career[h].Path[i].Core[k])== "table" then 
	
		if v.ID ~= nil then
			if wstring.find(wstring.lower(wstring.sub(GetAbilityName(v.ID),1,-3)),Search_Name) then
				table.insert(WarPedia.SearchTable,{ID=v.ID,Path=v.Path,BuffType=v.BuffType,MinLevel=v.MinLevel,Line=h,CareerName=GetCareerLine(h),AbilityName=GetAbilityName(v.ID),Type=v.Type,Icon=v.Icon,Rank=(v.Rank or 0)})
			end
	end 
	end
	end
	--]]
	end
--[[

	for k,v in pairs(Warbuilder.Career[h].Core) do 
	for a,b in pairs(Warbuilder.Career[h].Core[k]) do 
	
		if b.ID ~= nil then
			if wstring.find(wstring.lower(wstring.sub(GetAbilityName(b.ID),1,-3)),Search_Name) then
				table.insert(WarPedia.SearchTable,{ID=b.ID,Path=0,BuffType=b.BuffType,MinLevel=b.MinLevel,Line=h,CareerName=GetCareerLine(h),AbilityName=GetAbilityName(b.ID),Type=b.Type,Icon=b.Icon,Rank=(b.Rank or 0)})
			end
	end 
	end
	end
--]]
end
end



function WarPedia.Initialize()
    LabelSetText( "WarPediaTitleBarText", L"" )
    LabelSetText( "WarPediaHeaderText", L"Warbuilder Encyclopedia" )

	ButtonSetText("WarPediaBackButton", GetHelpString( StringTables.Help.BUTTON_BACK))
    
    -- disable "Back" button for Korean build. Because for Korean build when click on help button,
    -- it will go directly to this WarPedia, so there is no "back" functionality for Korean build.
    if ( SystemData.Territory.KOREA )
    then        
        WindowSetShowing( "WarPediaBackButton", false )
    end
	WarPedia.Build()
	
end

function WarPedia.OnShown()
    -- lazy load the manual data as this window is almost never opened
    if not WarPedia.data
    then
        --WarPedia.data = EA_Window_HelpGetTopicList()
		WarPedia.data = WarPedia.FakeTable
        WarPedia.PrepareData()
        WarPedia.UpdateWarPediaRow()
        
        -- setting up a default message
        LabelSetText( "WarPediaTopicLabel", L"" )
        LabelSetText( "WarPediaMainText", L"")
        WarPedia.SetListRowTints()

    end
end

function WarPedia.ToggleShowing()
    WindowUtils.ToggleShowing("WarPedia")
end

function WarPedia.Show()
    WindowSetShowing("WarPedia", true)
end

function WarPedia.Hide()
    WindowSetShowing("WarPedia", false)
end

function WarPedia.Shutdown()
end

function WarPedia.UpdateWarPediaRow()
    for row = 1, WarPediaList.numVisibleRows do
        local rowWindow = "WarPediaListRow"..row
        local index = ListBoxGetDataIndex("WarPediaList", row)
        local data = WarPedia.rowToEntryMap[index]
        
        if (data ~= nil)
        then
            if (WarPedia.lastPressedButtonId == data.id )
            then
                ButtonSetPressedFlag(rowWindow.."Name", true ) -- set newly selected entry as pressed
            else
                ButtonSetPressedFlag(rowWindow.."Name", false )
            end
            
			if data.type then
			local FrameColor = Warbuilder.GetColorFromType(data.type)
				ButtonSetTextColor("WarPediaListRow"..row.."Name",Button.ButtonState.NORMAL,FrameColor.r,FrameColor.g,FrameColor.b)
			else
				ButtonSetTextColor("WarPediaListRow"..row.."Name",Button.ButtonState.NORMAL,255,255,255)
			end
			
            local hasChildEntries = #data.childEntries > 0
            WindowSetShowing(rowWindow.."PlusButton",  hasChildEntries and not data.expanded)
            WindowSetShowing(rowWindow.."MinusButton", hasChildEntries and data.expanded)
        
            local depth = WarPedia.listBoxData[index].depth
            WindowClearAnchors(rowWindow.."Name")
            WindowAddAnchor(rowWindow.."Name", "left", rowWindow, "left", 30 + (15 * depth), 6)
        end
    end
end

function WarPedia.OnRButtonUpRow()
    -- currently unused
end

-- function not yet applied anywhere.
-- Figure out why can't do SetTintColor on just a label instead of the entire folder..
function WarPedia.MouseOverRow()
    local row = WindowGetId( SystemData.ActiveWindow.name )
    local targetRowWindow = "WarPediaListRow"..row
    DefaultColor.SetLabelColor(targetRowWindow.."Name", DefaultColor.MAGENTA)
end

-- Processes the information stored in WarPedia.data in order to display it in the listbox.
function WarPedia.PrepareData()
    -- reset tables and counters that are going to be used later on
    WarPedia.orderTable = {}
    WarPedia.listBoxData = {}
    WarPedia.numTotalRows = 1                -- more of an index than row counter
    WarPedia.rowToEntryMap = {}
    
    if( not WarPedia.data ) then 
        return -- quit if we have no data to work on.
    end
    
    local function AddEntryAsRow(entryIndex, entryData, depth)
        local entryTable = {name = entryData.name, depth = depth}
        table.insert( WarPedia.listBoxData, WarPedia.numTotalRows, entryTable )
        table.insert( WarPedia.orderTable, WarPedia.numTotalRows)
        table.insert( WarPedia.rowToEntryMap, WarPedia.numTotalRows, entryData )
        
        WarPedia.numTotalRows = WarPedia.numTotalRows + 1
        
        if entryData.expanded
        then
            -- entry is expanded so add children as rows, recursively
            for childEntryIndex, childEntryData in ipairs( entryData.childEntries ) do 
                AddEntryAsRow(childEntryIndex, childEntryData, depth+1)
            end
        end
    end
    
    for entryIndex, entryData in ipairs( WarPedia.data ) do  
        AddEntryAsRow(entryIndex, entryData, 0)
    end
    
    ListBoxSetDisplayOrder("WarPediaList", WarPedia.orderTable )
    WarPedia.SetListRowTints()
end

-- function that colors the background of the Manual sections
function WarPedia.SetListRowTints()
    for row = 1, WarPediaList.numVisibleRows do
        local row_mod = math.mod(row, 2)
        color = DataUtils.GetAlternatingRowColor( row_mod )
        
        local targetRowWindow = "WarPediaListRow"..row
        WindowSetTintColor(targetRowWindow.."RowBackground", color.r, color.g, color.b )
        WindowSetAlpha(targetRowWindow.."RowBackground", color.a )
    end
end

-- function that gets called on left click on an entry
function WarPedia.OnLButtonUpRow()
    local row = WindowGetId( SystemData.ActiveWindow.name )
    WarPedia.DisplayRow(row)
end

-- resets last entry selection
function WarPedia.ResetPressedButton()
    WarPedia.SetEntrySelectedById( WarPedia.lastPressedButtonId, false )
end

-- displays the entry information for a certain row
function WarPedia.DisplayRow( rowIndex )
    local dataIndex = ListBoxGetDataIndex("WarPediaList", rowIndex)
    local entryData = WarPedia.rowToEntryMap[dataIndex]   -- get the index in WarPedia.data from the row
    entryData.expanded = not entryData.expanded

    WarPedia.ResetPressedButton()
    WarPedia.lastPressedButtonId = entryData.id
    ButtonSetPressedFlag("WarPediaListRow"..rowIndex.."Name", true ) -- set newly selected entry as pressed
    WarPedia.DisplayManualEntry( entryData ) -- display text for the just selected entry

	

        
    WarPedia.PrepareData()
end

function WarPedia.SetEntrySelectedById( id, selected )
    for row = 1, WarPediaList.numVisibleRows do
        local index = ListBoxGetDataIndex("WarPediaList", row)
        local data = WarPedia.rowToEntryMap[index]
        if( data and data.id == WarPedia.lastPressedButtonId ) then
            ButtonSetPressedFlag("WarPediaListRow"..row.."Name", selected ) -- set newly selected entry as pressed
        end
    end
end

function WarPedia.DisplayManualEntry( entryData )
    local entryText = EA_Window_HelpGetEntryData( entryData.id )
    LabelSetText( "WarPediaTopicLabel", entryData.name )        -- display the title for the entry
--    LabelSetText( "WarPediaMainText", entryText.text )-- display the entry's text
    ScrollWindowSetOffset( "WarPediaMain", 0 )        -- reset the scroll bar.
    ScrollWindowUpdateScrollRect("WarPediaMain")      -- reset the scroll bar.  
end

function WarPedia.OnLButtonUpBackButton()
	WarPedia.Hide()
	EA_Window_Help.OnShown()
end
