<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
    <UiMod name="test" version="0.1B" date="27/2/2016">
		<VersionSettings gameVersion="1.4.8" windowsVersion="1.0" savedVariablesVersion="1.0" /> 
		<Author name="Sullemunk" />
        <Description text="Build and share mastery speccs addon made by Sullemunk for RoR" />
        <Dependencies />
        <Files>
		
            <File name="test.lua" />
		  <File name="test.xml" />
        </Files>
        <OnInitialize>
             <CallFunction name="Initilize" />
        </OnInitialize>
        <OnUpdate>
  
    	  </OnUpdate>
        <OnShutdown />
    </UiMod>
</ModuleFile>