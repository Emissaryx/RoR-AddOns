MoraleCircle = {}
local version = "1.0.3"

function MoraleCircle.init()
CreateWindow("MoraleCircleRangeWindow1", true)

CreateWindowFromTemplate ("MoraleCircleRangeWindow2", "MoraleCircleRangeWindow1", "Root")
CreateWindowFromTemplate ("MoraleCircleRangeWindow3", "MoraleCircleRangeWindow1", "Root")
CreateWindowFromTemplate ("MoraleCircleRangeWindow4", "MoraleCircleRangeWindow1", "Root")


LayoutEditor.RegisterWindow( "MoraleCircleRangeWindow1", L"Morale 1", L"Morale 1", true, true, true, nil )
LayoutEditor.RegisterWindow( "MoraleCircleRangeWindow2", L"Morale 2", L"Morale 2", true, true, true, nil )
LayoutEditor.RegisterWindow( "MoraleCircleRangeWindow3", L"Morale 3", L"Morale 3", true, true, true, nil )
LayoutEditor.RegisterWindow( "MoraleCircleRangeWindow4", L"Morale 4", L"Morale 4", true, true, true, nil )

RegisterEventHandler (SystemData.Events.PLAYER_MORALE_UPDATED,          "MoraleCircle.OnMoraleUpdated")
MoralePerC = 0
WindowSetTintColor( "MoraleCircleRangeWindow1BuildUp", 120,255,155 )
WindowSetTintColor( "MoraleCircleRangeWindow1BuildUpBG", 0,0,0 )
WindowSetTintColor( "MoraleCircleRangeWindow1Needle", 155,20,20 )
WindowSetTintColor( "MoraleCircleRangeWindow2BuildUp", 120,255,155 )
WindowSetTintColor( "MoraleCircleRangeWindow2BuildUpBG", 0,0,0 )
WindowSetTintColor( "MoraleCircleRangeWindow2Needle", 155,20,20 )
WindowSetTintColor( "MoraleCircleRangeWindow3BuildUp", 120,255,155 )
WindowSetTintColor( "MoraleCircleRangeWindow3BuildUpBG", 0,0,0 )
WindowSetTintColor( "MoraleCircleRangeWindow3Needle", 155,20,20 )
WindowSetTintColor( "MoraleCircleRangeWindow4BuildUp", 120,255,155 )
WindowSetTintColor( "MoraleCircleRangeWindow4BuildUpBG", 0,0,0 )
WindowSetTintColor( "MoraleCircleRangeWindow4Needle", 155,20,20 )

AnimatedImageStartAnimation ("MoraleCircleRangeWindow1Flash", 0, true, true, 0)
AnimatedImageStartAnimation ("MoraleCircleRangeWindow2Flash", 0, true, true, 0)
AnimatedImageStartAnimation ("MoraleCircleRangeWindow3Flash", 0, true, true, 0)
AnimatedImageStartAnimation ("MoraleCircleRangeWindow4Flash", 0, true, true, 0)


TextLogAddEntry("Chat", 0, L"<icon57> MoraleCircle "..towstring(version)..L" Loaded.")
end

function MoraleCircle.update()

------------------------------- Morale Circle 1
CooldownDisplaySetCooldown( "MoraleCircleRangeWindow1BuildUp", MoralePerC, GetMoralePercentForLevel (1) )

CooldownDisplaySetCooldown( "MoraleCircleRangeWindow1BuildUpBG", (MoralePerC*10)+1.5, 100 )
local _, currentlySlottedMoraleAbilityId = GetMoraleBarData (1)
local AbilityIcon = GetAbilityData(currentlySlottedMoraleAbilityId).iconNum
local abilityId = GetAbilityData(currentlySlottedMoraleAbilityId).id
local texture, x, y, disabledTexture = GetIconData (AbilityIcon)

WindowSetAlpha("MoraleCircleRangeWindow1AbilityCooldown",0.7)
WindowSetTintColor( "MoraleCircleRangeWindow1AbilityCooldown", 50,0,0 )

CircleImageSetTexture ("MoraleCircleRangeWindow1MoraleImage", texture, 32, 32)
WindowSetGameActionData ("MoraleCircleRangeWindow1Click", GameData.PlayerActions.DO_ABILITY, abilityId, L"")

if texture == nil or texture == "icon000000" then WindowSetShowing("MoraleCircleRangeWindow1",false)
else
WindowSetShowing("MoraleCircleRangeWindow1",true)
end
------------------------------- Morale Circle 2 
CooldownDisplaySetCooldown( "MoraleCircleRangeWindow2BuildUp", MoralePerC, GetMoralePercentForLevel (2) )
CooldownDisplaySetCooldown( "MoraleCircleRangeWindow2BuildUpBG", (MoralePerC*5)+1.5, 100 )
local _, currentlySlottedMoraleAbilityId2 = GetMoraleBarData (2)
local AbilityIcon2 = GetAbilityData(currentlySlottedMoraleAbilityId2).iconNum
local abilityId2 = GetAbilityData(currentlySlottedMoraleAbilityId2).id
local texture2, x, y, disabledTexture = GetIconData (AbilityIcon2)
WindowSetAlpha("MoraleCircleRangeWindow2AbilityCooldown",0.7)
WindowSetTintColor( "MoraleCircleRangeWindow2AbilityCooldown", 50,0,0 )


WindowSetTintColor( "MoraleCircleRangeWindow2BuildUp",  55,255,55 )
CircleImageSetTexture ("MoraleCircleRangeWindow2MoraleImage", texture2, 32, 32)
WindowSetGameActionData ("MoraleCircleRangeWindow2Click", GameData.PlayerActions.DO_ABILITY, abilityId2, L"")

if texture2 == nil or texture2 == "icon000000" then WindowSetShowing("MoraleCircleRangeWindow2",false)
else
WindowSetShowing("MoraleCircleRangeWindow2",true)
end
------------------------------- Morale Circle 3

CooldownDisplaySetCooldown( "MoraleCircleRangeWindow3BuildUp", MoralePerC, GetMoralePercentForLevel (3) )
CooldownDisplaySetCooldown( "MoraleCircleRangeWindow3BuildUpBG", (MoralePerC*2)+1.5, 100 )
local _, currentlySlottedMoraleAbilityId3 = GetMoraleBarData (3)
local AbilityIcon3 = GetAbilityData(currentlySlottedMoraleAbilityId3).iconNum
local abilityId3 = GetAbilityData(currentlySlottedMoraleAbilityId3).id
local texture3, x, y, disabledTexture = GetIconData (AbilityIcon3)

WindowSetAlpha("MoraleCircleRangeWindow3AbilityCooldown",0.7)
WindowSetTintColor( "MoraleCircleRangeWindow3AbilityCooldown", 50,0,0 )


WindowSetTintColor( "MoraleCircleRangeWindow3BuildUp",  55,255,55 )
CircleImageSetTexture ("MoraleCircleRangeWindow3MoraleImage", texture3, 32, 32)
WindowSetGameActionData ("MoraleCircleRangeWindow3Click", GameData.PlayerActions.DO_ABILITY, abilityId3, L"")

if texture3 == nil or texture3 == "icon000000" then WindowSetShowing("MoraleCircleRangeWindow3",false)
else
WindowSetShowing("MoraleCircleRangeWindow3",true)
end
------------------------------- Morale Circle 4

CooldownDisplaySetCooldown( "MoraleCircleRangeWindow4BuildUp", MoralePerC, GetMoralePercentForLevel (4) )
CooldownDisplaySetCooldown( "MoraleCircleRangeWindow4BuildUpBG", (MoralePerC)+1.5, 100 )
local _, currentlySlottedMoraleAbilityId4 = GetMoraleBarData (4)
local AbilityIcon4 = GetAbilityData(currentlySlottedMoraleAbilityId4).iconNum
local abilityId4 = GetAbilityData(currentlySlottedMoraleAbilityId4).id
local texture4, x, y, disabledTexture = GetIconData (AbilityIcon4)

WindowSetAlpha("MoraleCircleRangeWindow4AbilityCooldown",0.7)
WindowSetTintColor( "MoraleCircleRangeWindow4AbilityCooldown", 50,0,0 )


WindowSetTintColor( "MoraleCircleRangeWindow4BuildUp",  55,255,55 )
CircleImageSetTexture ("MoraleCircleRangeWindow4MoraleImage", texture4, 32, 32)
WindowSetGameActionData ("MoraleCircleRangeWindow4Click", GameData.PlayerActions.DO_ABILITY, abilityId4, L"")

if texture4 == nil or texture4 == "icon000000" then WindowSetShowing("MoraleCircleRangeWindow4",false)
else
WindowSetShowing("MoraleCircleRangeWindow4",true)
end
----------------------------------------------------

--copys a morale ability to a temp hotbar slot so i can grab it's Cooldown timer, since all morale share same cooldown
SetHotbarData(72, GameData.PlayerActions.DO_ABILITY, abilityId) 

    M_Cdown, M_MaxCdown = GetMoraleCooldown (1)


if GetHotbarCooldown(72) >= ActionButton.GLOBAL_COOLDOWN then
CooldownDisplaySetCooldown( "MoraleCircleRangeWindow1AbilityCooldown", GetHotbarCooldown(72),60)
CooldownDisplaySetCooldown( "MoraleCircleRangeWindow2AbilityCooldown", GetHotbarCooldown(72),60)
CooldownDisplaySetCooldown( "MoraleCircleRangeWindow3AbilityCooldown", GetHotbarCooldown(72),60)
CooldownDisplaySetCooldown( "MoraleCircleRangeWindow4AbilityCooldown", GetHotbarCooldown(72),60)


LabelSetText("MoraleCircleRangeWindow1CooldownLabel",towstring(TimeUtils.FormatSeconds(GetHotbarCooldown(72), true)))
LabelSetText("MoraleCircleRangeWindow2CooldownLabel",towstring(TimeUtils.FormatSeconds(GetHotbarCooldown(72), true)))
LabelSetText("MoraleCircleRangeWindow3CooldownLabel",towstring(TimeUtils.FormatSeconds(GetHotbarCooldown(72), true)))
LabelSetText("MoraleCircleRangeWindow4CooldownLabel",towstring(TimeUtils.FormatSeconds(GetHotbarCooldown(72), true)))
else

CooldownDisplaySetCooldown( "MoraleCircleRangeWindow1AbilityCooldown", M_Cdown, M_MaxCdown)
CooldownDisplaySetCooldown( "MoraleCircleRangeWindow2AbilityCooldown", M_Cdown, M_MaxCdown)
CooldownDisplaySetCooldown( "MoraleCircleRangeWindow3AbilityCooldown", M_Cdown, M_MaxCdown)
CooldownDisplaySetCooldown( "MoraleCircleRangeWindow4AbilityCooldown", M_Cdown, M_MaxCdown)


LabelSetText("MoraleCircleRangeWindow1CooldownLabel",L"")
LabelSetText("MoraleCircleRangeWindow2CooldownLabel",L"")
LabelSetText("MoraleCircleRangeWindow3CooldownLabel",L"")
LabelSetText("MoraleCircleRangeWindow4CooldownLabel",L"")
end

if MoralePerC >= 10 then
LabelSetTextColor("MoraleCircleRangeWindow1RangeLabel",155,155,255)
LabelSetText("MoraleCircleRangeWindow1RangeLabel",L"100%")
LabelSetText("MoraleCircleRangeWindow1RangeLabelBG",L"100%")
--WindowSetTintColor( "MoraleCircleRangeWindow1MoraleImage", 255,255,255 )
WindowSetAlpha("MoraleCircleRangeWindow1Flash",1)
WindowSetTintColor( "MoraleCircleRangeWindow1BuildUp", 0,255,0 )
		local isBlocked = Player.IsAbilityBlocked( abilityId, GameData.AbilityType.MORALE )
        local isTargetValid, hasRequiredUnitTypeTargeted = IsTargetValid (abilityId)        
        local isTargetValid = (isTargetValid or (hasRequiredUnitTypeTargeted == false))
            if (isTargetValid and not isBlocked)
            then
                WindowSetTintColor( "MoraleCircleRangeWindow1MoraleImage", 255,255,255 )
            else
                WindowSetTintColor( "MoraleCircleRangeWindow1MoraleImage", 255,0,0 )
            end
      
elseif MoralePerC <= 10 then
LabelSetTextColor("MoraleCircleRangeWindow1RangeLabel",255,255,255)
LabelSetText("MoraleCircleRangeWindow1RangeLabel",towstring(math.abs(MoralePerC/GetMoralePercentForLevel (1))*100)..L"%")
LabelSetText("MoraleCircleRangeWindow1RangeLabelBG",towstring(math.abs(MoralePerC/GetMoralePercentForLevel (1))*100)..L"%")
--WindowSetTintColor( "MoraleCircleRangeWindow1MoraleImage", 100,100,100 )
WindowSetAlpha("MoraleCircleRangeWindow1Flash",0)
WindowSetTintColor( "MoraleCircleRangeWindow1BuildUp",  100,100,255 )
		local isBlocked = Player.IsAbilityBlocked( abilityId, GameData.AbilityType.MORALE )
        local isTargetValid, hasRequiredUnitTypeTargeted = IsTargetValid (abilityId)        
        local isTargetValid = (isTargetValid or (hasRequiredUnitTypeTargeted == false))
            if (isTargetValid and not isBlocked)
            then
                WindowSetTintColor( "MoraleCircleRangeWindow1MoraleImage", 100,100,100 )
            else
                WindowSetTintColor( "MoraleCircleRangeWindow1MoraleImage", 150,0,0 )
            end
end

if MoralePerC >= 20 then
LabelSetTextColor("MoraleCircleRangeWindow2RangeLabel",155,155,255)
LabelSetText("MoraleCircleRangeWindow2RangeLabel",L"100%")
LabelSetText("MoraleCircleRangeWindow2RangeLabelBG",L"100%")
--WindowSetTintColor( "MoraleCircleRangeWindow2MoraleImage", 255,255,255 )
WindowSetAlpha("MoraleCircleRangeWindow2Flash",1)
WindowSetTintColor( "MoraleCircleRangeWindow2BuildUp", 0,255,0 )
		local isBlocked = Player.IsAbilityBlocked( abilityId2, GameData.AbilityType.MORALE )
        local isTargetValid, hasRequiredUnitTypeTargeted = IsTargetValid (abilityId2)        
        local isTargetValid = (isTargetValid or (hasRequiredUnitTypeTargeted == false))
            if (isTargetValid and not isBlocked)
            then
                WindowSetTintColor( "MoraleCircleRangeWindow2MoraleImage", 255,255,255 )
            else
                WindowSetTintColor( "MoraleCircleRangeWindow2MoraleImage", 255,0,0 )
            end
elseif MoralePerC <= 20 then
LabelSetTextColor("MoraleCircleRangeWindow2RangeLabel",255,255,255)
LabelSetText("MoraleCircleRangeWindow2RangeLabel",towstring(math.abs((MoralePerC/GetMoralePercentForLevel (2))*100))..L"%")
LabelSetText("MoraleCircleRangeWindow2RangeLabelBG",towstring(math.abs((MoralePerC/GetMoralePercentForLevel (2))*100))..L"%")
--WindowSetTintColor( "MoraleCircleRangeWindow2MoraleImage", 100,100,100 )
WindowSetAlpha("MoraleCircleRangeWindow2Flash",0)
WindowSetTintColor( "MoraleCircleRangeWindow2BuildUp", 100,100,255  )
		local isBlocked = Player.IsAbilityBlocked( abilityId2, GameData.AbilityType.MORALE )
        local isTargetValid, hasRequiredUnitTypeTargeted = IsTargetValid (abilityId2)        
        local isTargetValid = (isTargetValid or (hasRequiredUnitTypeTargeted == false))
            if (isTargetValid and not isBlocked)
            then
                WindowSetTintColor( "MoraleCircleRangeWindow2MoraleImage", 100,100,100 )
            else
                WindowSetTintColor( "MoraleCircleRangeWindow2MoraleImage", 150,0,0 )
            end
end

if MoralePerC >= 50 then
LabelSetTextColor("MoraleCircleRangeWindow3RangeLabel",155,155,255)
LabelSetText("MoraleCircleRangeWindow3RangeLabel",L"100%")
LabelSetText("MoraleCircleRangeWindow3RangeLabelBG",L"100%")
WindowSetTintColor( "MoraleCircleRangeWindow3MoraleImage", 255,255,255 )
WindowSetAlpha("MoraleCircleRangeWindow3Flash",1)
WindowSetTintColor( "MoraleCircleRangeWindow3BuildUp", 0,255,0 )
		local isBlocked = Player.IsAbilityBlocked( abilityId3, GameData.AbilityType.MORALE )
        local isTargetValid, hasRequiredUnitTypeTargeted = IsTargetValid (abilityId3)        
        local isTargetValid = (isTargetValid or (hasRequiredUnitTypeTargeted == false))
            if (isTargetValid and not isBlocked)
            then
                WindowSetTintColor( "MoraleCircleRangeWindow3MoraleImage", 255,255,255 )
            else
                WindowSetTintColor( "MoraleCircleRangeWindow3MoraleImage", 255,0,0 )
            end
elseif MoralePerC <= 50 then
LabelSetTextColor("MoraleCircleRangeWindow3RangeLabel",255,255,255)
LabelSetText("MoraleCircleRangeWindow3RangeLabel",towstring(math.abs((MoralePerC/GetMoralePercentForLevel (3))*100))..L"%")
LabelSetText("MoraleCircleRangeWindow3RangeLabelBG",towstring(math.abs((MoralePerC/GetMoralePercentForLevel (3))*100))..L"%")
WindowSetTintColor( "MoraleCircleRangeWindow3MoraleImage", 100,100,100 )
WindowSetAlpha("MoraleCircleRangeWindow3Flash",0)
WindowSetTintColor( "MoraleCircleRangeWindow3BuildUp",  100,100,255  )
		local isBlocked = Player.IsAbilityBlocked( abilityId3, GameData.AbilityType.MORALE )
        local isTargetValid, hasRequiredUnitTypeTargeted = IsTargetValid (abilityId3)        
        local isTargetValid = (isTargetValid or (hasRequiredUnitTypeTargeted == false))
            if (isTargetValid and not isBlocked)
            then
                WindowSetTintColor( "MoraleCircleRangeWindow3MoraleImage", 100,100,100 )
            else
                WindowSetTintColor( "MoraleCircleRangeWindow3MoraleImage", 150,0,0 )
            end
end

if MoralePerC >= 100 then
LabelSetTextColor("MoraleCircleRangeWindow4RangeLabel",155,155,255)
LabelSetText("MoraleCircleRangeWindow4RangeLabel",L"100%")
LabelSetText("MoraleCircleRangeWindow4RangeLabelBG",L"100%")
WindowSetTintColor( "MoraleCircleRangeWindow4MoraleImage", 255,255,255 )
WindowSetAlpha("MoraleCircleRangeWindow4Flash",1)
WindowSetTintColor( "MoraleCircleRangeWindow4BuildUp", 0,255,0 )
		local isBlocked = Player.IsAbilityBlocked( abilityId4, GameData.AbilityType.MORALE )
        local isTargetValid, hasRequiredUnitTypeTargeted = IsTargetValid (abilityId4)        
        local isTargetValid = (isTargetValid or (hasRequiredUnitTypeTargeted == false))
            if (isTargetValid and not isBlocked)
            then
                WindowSetTintColor( "MoraleCircleRangeWindow4MoraleImage", 255,255,255 )
            else
                WindowSetTintColor( "MoraleCircleRangeWindow4MoraleImage", 255,0,0 )
            end
elseif MoralePerC <= 100 then
LabelSetTextColor("MoraleCircleRangeWindow4RangeLabel",255,255,255)
WindowSetTintColor( "MoraleCircleRangeWindow4BuildUp",  100,100,255  )
LabelSetText("MoraleCircleRangeWindow4RangeLabel",towstring(math.abs((MoralePerC/GetMoralePercentForLevel (4))*100))..L"%")
LabelSetText("MoraleCircleRangeWindow4RangeLabelBG",towstring(math.abs((MoralePerC/GetMoralePercentForLevel (4))*100))..L"%")
WindowSetTintColor( "MoraleCircleRangeWindow4MoraleImage", 100,100,100 )
WindowSetAlpha("MoraleCircleRangeWindow4Flash",0)
		local isBlocked = Player.IsAbilityBlocked( abilityId4, GameData.AbilityType.MORALE )
        local isTargetValid, hasRequiredUnitTypeTargeted = IsTargetValid (abilityId4)        
        local isTargetValid = (isTargetValid or (hasRequiredUnitTypeTargeted == false))
            if (isTargetValid and not isBlocked)
            then
                WindowSetTintColor( "MoraleCircleRangeWindow4MoraleImage", 100,100,100 )
            else
                WindowSetTintColor( "MoraleCircleRangeWindow4MoraleImage", 150,0,0 )
            end

end

for i = 1,4 do
if MoralePerC <= 0 then
WindowSetAlpha( "MoraleCircleRangeWindow"..i.."BuildUpBG", 0)
else
WindowSetAlpha( "MoraleCircleRangeWindow"..i.."BuildUpBG", 1)
end
end



end

function MoraleCircle.OnMouseOverStart()
local WinParent = WindowGetParent(SystemData.MouseOverWindow.name)
local MouseOverWindowName = SystemData.MouseOverWindow.name

    local anchor = nil
    if  DoesWindowExist( "MouseOverTargetWindow" )
        and ( SystemData.Settings.GamePlay.staticAbilityTooltipPlacement or SystemData.Settings.GamePlay.staticTooltipPlacement )
    then
        anchor = Tooltips.ANCHOR_MOUSE_OVER_TARGET_WINDOW
    else
        anchor = topleft
    end


for i=1,4 do
if MouseOverWindowName == "MoraleCircleRangeWindow"..i.."Click" then

local _, currentlySlottedMoraleAbilityId = GetMoraleBarData (i)
local abilityId = GetAbilityData(currentlySlottedMoraleAbilityId).id

local MData = Player.GetAbilityData (GetAbilityData(currentlySlottedMoraleAbilityId).id, Player.AbilityType.MORALE)
Tooltips.CreateAbilityTooltip( MData, SystemData.MouseOverWindow.name, anchor,L"<icon49>MoraleCircle",{ r = 50, g = 150, b =255 }) 


end

end

end


function MoraleCircle.Click()

end

function MoraleCircle.RightClick()
local WinParent = WindowGetParent(SystemData.MouseOverWindow.name)
local MouseOverWindowName = SystemData.MouseOverWindow.name

for i=1,4 do
if MouseOverWindowName == "MoraleCircleRangeWindow"..i.."Click" then
d(L"Right clicking "..towstring(i))

local _, currentlySlottedMoraleAbilityId = GetMoraleBarData (i)
local abilityId = GetAbilityData(currentlySlottedMoraleAbilityId).id

local MData = Player.GetAbilityData (GetAbilityData(currentlySlottedMoraleAbilityId).id, Player.AbilityType.MORALE)

local MoraleCalc = (tonumber(MoralePerC)/tonumber(GetMoralePercentForLevel(i)))*100
local SmartChannel = MoraleCircle.GetSmartChannel()
--local SmartChannel = L"/say "
local LinkName = L"[Morale "..towstring(i)..L": "..towstring(MData.name)..L"]"
local DoneLink = CreateHyperLink(L"0",LinkName, {229, 77, 255}, {} )

if (MoraleCalc >= 99) and (GetHotbarCooldown(72) <= ActionButton.GLOBAL_COOLDOWN ) then
SendChatText(towstring(SmartChannel)..towstring(DoneLink)..L" - <LINK data=\"0\" text=\"READY!\" color=\"50,255,50\">", L"")
else
if GetHotbarCooldown(72) > ActionButton.GLOBAL_COOLDOWN then MoraleCD = L" - "..towstring("<LINK data=\"0\" text=\"")..towstring(math.modf(GetHotbarCooldown(72)))..L"s\" color=\"255,50,50\">"else MoraleCD = L"" end
if MoraleCalc <= 99 then MoralePercent = L" - <LINK data=\"0\" text=\""..towstring(math.modf(MoraleCalc))..L"%\" color=\"255,255,50\">" else MoralePercent = L"" end
SendChatText(towstring(SmartChannel)..towstring(DoneLink)..towstring(MoralePercent)..towstring(MoraleCD), L"")		
end
end
end
end

function MoraleCircle.GetSmartChannel()
    local switcher = L"/say "
    local groupData = GetGroupData()
    for k,v in pairs(groupData) do
        if v and v.name and v.name ~= L"" then
            switcher = L"/party "
        end
    end
    if IsWarBandActive() then
        switcher = L"/warband "
    end
    if GameData.Player.isInScenario and GameData.Player.isInSiege then
        switcher = L"/warband "
    end
    if GameData.Player.isInScenario and not GameData.Player.isInSiege then
        switcher = L"/sp "
    end    
    return switcher
end

function MoraleCircle.OnMoraleUpdated(moralePercent, moraleLevel)
--d(moralePercent)
MoralePerC = math.abs(moralePercent)


end