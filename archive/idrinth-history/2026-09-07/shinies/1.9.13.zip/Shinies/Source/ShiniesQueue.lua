--[[
	This application is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.
--]]

ShiniesQueue = {}
ShiniesQueue.__index = ShiniesQueue

local pcall = pcall
local d = d
local ShiniesAPI

--------------------------------------------------
-- Safe call helpers
--------------------------------------------------

local function errorchecker(success, result)
	if not success then
		d(result)
		return ShiniesAPI.STATE_FAILURE
	end
	return result
end

local function safecall(func, ...)
	return errorchecker(pcall(func, ...))
end

--------------------------------------------------
-- Queue creation
--------------------------------------------------

function ShiniesQueue:Create(target, executeFunction, resultsCheckFunction, successCallback, failureCallback, timeoutCallback)
	local queue = {}

	-- Cache API once
	ShiniesAPI = ShiniesAPI or _G.Shinies:GetModule("Shinies-API-Core")

	setmetatable(queue, ShiniesQueue)

	queue.m_first  = 0
	queue.m_last   = -1
	queue.m_count  = 0

	queue.m_executing    = false
	queue.m_executeTime  = 0
	queue.m_throttleRate = 0.3
	queue.m_timeout      = 5

	-- Store target and method names instead of closures
	queue.m_target        = target
	queue.m_executeMethod = executeFunction
	queue.m_resultsMethod = resultsCheckFunction

	queue.m_successCallback = successCallback
	queue.m_failureCallback = failureCallback
	queue.m_timeoutCallback = timeoutCallback

	return queue
end

--------------------------------------------------
-- Execution state
--------------------------------------------------

function ShiniesQueue:GetExecuting()
	return self.m_executing
end

function ShiniesQueue:SetExecuting(executing)
	self.m_executing = executing
	self.m_executeTime = 0
end

function ShiniesQueue:IncrementExecuteTime(elapsed)
	self.m_executeTime = self.m_executeTime + elapsed
end

function ShiniesQueue:IsTimedOut()
	return self.m_executeTime > self.m_timeout
end

function ShiniesQueue:GetThrottleRate()
	return self.m_throttleRate
end

function ShiniesQueue:SetThrottleRate(rate)
	self.m_throttleRate = rate
end

function ShiniesQueue:GetTimeout()
	return self.m_timeout
end

function ShiniesQueue:SetTimeout(time)
	self.m_timeout = time
end

--------------------------------------------------
-- Accessors
--------------------------------------------------

function ShiniesQueue:Back()
	return self[self.m_last]
end

function ShiniesQueue:Front()
	return self[self.m_first]
end

function ShiniesQueue:Begin()
	return self.m_first
end

function ShiniesQueue:End()
	return self.m_last
end

function ShiniesQueue:IsEmpty()
	return self.m_first > self.m_last
end

function ShiniesQueue:GetCount()
	return self.m_count
end

function ShiniesQueue:GetSuccessCallback()
	return self.m_successCallback
end

function ShiniesQueue:GetFailureCallback()
	return self.m_failureCallback
end

function ShiniesQueue:GetTimeoutCallback()
	return self.m_timeoutCallback
end

--------------------------------------------------
-- Execution calls
--------------------------------------------------

function ShiniesQueue:CallExecuteFunction(...)
	if not self.m_executeMethod then
		return ShiniesAPI.STATE_FAILURE
	end
	return safecall(self.m_target[self.m_executeMethod], self.m_target, ...)
end

function ShiniesQueue:CallResultsCheckFunction(...)
	if not self.m_resultsMethod then
		return ShiniesAPI.STATE_FAILURE
	end
	return safecall(self.m_target[self.m_resultsMethod], self.m_target, ...)
end

--------------------------------------------------
-- Queue operations
--------------------------------------------------

function ShiniesQueue:Clear()
	for i = self.m_first, self.m_last do
		self[i] = nil
	end

	self.m_first = 0
	self.m_last  = -1
	self.m_count = 0
	self:SetExecuting(false)
end

function ShiniesQueue:PushBack(val)
	if val ~= nil then
		self.m_last = self.m_last + 1
		self[self.m_last] = val
		self.m_count = self.m_count + 1
	end
end

function ShiniesQueue:PushFront(val)
	if val ~= nil then
		self.m_first = self.m_first - 1
		self[self.m_first] = val
		self.m_count = self.m_count + 1
	end
end

--------------------------------------------------
-- Internal pop helper
--------------------------------------------------

local function PopAt(queue, index)
	if queue:IsEmpty() then
		return nil
	end

	local val = queue[index]
	queue[index] = nil
	return val
end

function ShiniesQueue:PopBack()
	local val = PopAt(self, self.m_last)

	if val ~= nil then
		self.m_last = self.m_last - 1
		self.m_count = self.m_count - 1
		if self:IsEmpty() then
			self:Clear()
		end
	end

	return val
end

function ShiniesQueue:PopFront()
	local val = PopAt(self, self.m_first)

	if val ~= nil then
		self.m_first = self.m_first + 1
		self.m_count = self.m_count - 1
		if self:IsEmpty() then
			self:Clear()
		end
	end

	if self:IsEmpty() then
		self:SetExecuting(false)
	end

	return val
end
