--[[
	This application is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    The applications is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with the applications.  If not, see <http://www.gnu.org/licenses/>.
--]]

local Shinies 		= _G.Shinies
local T		    	= Shinies.T
local MODNAME 		= "Shinies-Data-Inventory"
local mod	 		= Shinies : NewModule( MODNAME, "WAR-AceTimer-3.0" )
ShiniesDataInventory	= mod
mod:SetModuleType( "Data" )
mod:SetName( T["Shinies Item Data Store"] )
mod:SetDescription( T["Provides a method of storing and retrieving current inventory and bank information."] )
mod:SetDefaults(
{
	factionrealm =
	{
		chars =
		{
			["**"] =									-- char slot
			{
				locs =
				{
					["**"] =							-- item loc
					{
						["**"] =						-- slot
						{
							uniqueID	= 0,
							stackCount	= 0,
						},
					},
				},
				items =
				{
					["**"] =							-- item id
					{
						["**"] = 						-- item loc
						{
							["**"] = false				-- slot
						},

					},
				},
				totals 		=
				{
					["**"] = 							-- itemLoc
					{
						["**"] =						-- item id
						{
							count		= 0,
						},
					},
				},
			},
		},
	},
} )

ShiniesDataInventory.callbacks = LibStub : GetLibrary( "WAR-CallbackHandler-1.0", true ) : New( ShiniesDataInventory )

local new, del, wipe = Shinies.new, Shinies.del, Shinies.wipe

local pairs 				= pairs
local ipairs				= ipairs
local rawget				= rawget
local tinsert				= table.insert
local tsort					= table.sort
local tonumber				= tonumber
local tostring				= tostring
local type					= type
local string_sub			= string.sub
local string_format			= string.format

local ShiniesAPI		= Shinies : GetModule( "Shinies-API-Core" )

local BANK_STORAGE_PREFIX = "BANK:"
local BANK_STORAGE_PREFIX_LENGTH = 5
local MAIN_BANK_ZONE_IDS = {
	[161] = true, -- The Inevitable City
	[162] = true, -- Altdorf
}

local allItemSets = {}
allItemSets[GameData.ItemLocs.INVENTORY] 		= { data = DataUtils.GetItems }						-- 3
allItemSets[GameData.ItemLocs.BANK] 			= { data = DataUtils.GetBankData }					-- 4
allItemSets[GameData.ItemLocs.CRAFTING_ITEM] 	= { data = DataUtils.GetCraftingItems }				-- 30
allItemSets[GameData.ItemLocs.CURRENCY_ITEM] 	= { data = DataUtils.GetCurrencyItems }				-- 31

--
-- These are the items on the player, and do not require a specific location to access.
-- Bank items are stored separately by zone so multiple banks do not overwrite each other.
--
local playerSets = {}
playerSets[GameData.ItemLocs.INVENTORY]			= allItemSets[GameData.ItemLocs.INVENTORY]
playerSets[GameData.ItemLocs.CRAFTING_ITEM]		= allItemSets[GameData.ItemLocs.CRAFTING_ITEM]
playerSets[GameData.ItemLocs.CURRENCY_ITEM]		= allItemSets[GameData.ItemLocs.CURRENCY_ITEM]

local processItemSlotUpdated, processItemLoc, clearItemLoc

local pendingProcessing		= new()

local pendingTime			= 0.5
local moneyUpdateDelay		= 0.5
local currentBankItemLoc	= nil
local pendingMoneyUpdateTimer = nil

local function GetCurrentBankItemLoc()
	if GameData ~= nil and GameData.Player ~= nil and GameData.Player.zone ~= nil then
		return BANK_STORAGE_PREFIX .. tostring(GameData.Player.zone)
	end

	return GameData.ItemLocs.BANK
end

local function IsBankStorageItemLoc( itemLoc )
	return type(itemLoc) == "string" and string_sub( itemLoc, 1, BANK_STORAGE_PREFIX_LENGTH ) == BANK_STORAGE_PREFIX
end

local function IsMainBankStorageItemLoc( itemLoc )
	local zoneId = tonumber( string_sub( itemLoc, BANK_STORAGE_PREFIX_LENGTH + 1 ) )
	return zoneId ~= nil and MAIN_BANK_ZONE_IDS[zoneId] == true
end

local function GetLocationSummary(charData, itemLoc)
	local slots = 0
	local uniqueItems = 0
	local stackCount = 0

	if charData ~= nil and charData.locs ~= nil and charData.locs[itemLoc] ~= nil then
		for _ in pairs( charData.locs[itemLoc] )
		do
			slots = slots + 1
		end
	end

	if charData ~= nil and charData.totals ~= nil and charData.totals[itemLoc] ~= nil then
		for _, total in pairs( charData.totals[itemLoc] )
		do
			uniqueItems = uniqueItems + 1
			stackCount = stackCount + ( total.count or 0 )
		end
	end

	return slots, uniqueItems, stackCount
end

local function EnsureCharacterData(charSlot)
	if charSlot == nil then
		return nil
	end

	local chars = mod.db and mod.db.factionrealm and mod.db.factionrealm.chars
	if chars == nil then
		return nil
	end

	local charData = chars[charSlot]
	if charData == nil then
		charData = {}
		chars[charSlot] = charData
	end

	if charData.locs == nil then
		charData.locs = {}
	end

	if charData.items == nil then
		charData.items = {}
	end

	if charData.totals == nil then
		charData.totals = {}
	end

	return charData
end

local function EnsureMoneyBySlot()
	local factionrealm = mod.db and mod.db.factionrealm
	if factionrealm == nil then
		return nil
	end

	local moneyBySlot = rawget( factionrealm, "moneyBySlot" )
	if moneyBySlot == nil then
		moneyBySlot = {}
		factionrealm.moneyBySlot = moneyBySlot
	end

	return moneyBySlot
end

local function GetMoneyBySlot()
	local factionrealm = mod.db and mod.db.factionrealm
	if factionrealm == nil then
		return nil
	end

	return rawget( factionrealm, "moneyBySlot" )
end

local function EnsureCurrentCharacterData()
	return EnsureCharacterData(GameData.Account.SelectedCharacterSlot)
end

local function EnsureItemLocationData(itemLoc)
	local charData = EnsureCurrentCharacterData()
	if charData == nil then
		return nil
	end

	if charData.locs[itemLoc] == nil then
		charData.locs[itemLoc] = {}
	end

	if charData.totals[itemLoc] == nil then
		charData.totals[itemLoc] = {}
	end

	return charData
end

local function EnsureItemEntry(charData, itemLoc, uniqueID)
	if charData.items[uniqueID] == nil then
		charData.items[uniqueID] = {}
	end

	if charData.items[uniqueID][itemLoc] == nil then
		charData.items[uniqueID][itemLoc] = {}
	end

	if charData.totals[itemLoc][uniqueID] == nil then
		charData.totals[itemLoc][uniqueID] = { count = 0 }
	end
end

local function GetStoredItemCount(charData, itemLoc, itemId)
	if charData == nil or charData.totals == nil then
		return 0
	end

	local locationTotals = charData.totals[itemLoc]
	if locationTotals == nil then
		return 0
	end

	local itemTotals = locationTotals[itemId]
	if itemTotals == nil or itemTotals.count == nil then
		return 0
	end

	return itemTotals.count
end

local function GetStoredBankItemCounts(charData, itemId)
	local mainCount = 0
	local otherCount = 0
	local hasZoneBankData = false

	if charData == nil or charData.totals == nil then
		return 0, 0, false
	end

	for itemLoc, _ in pairs( charData.totals )
	do
		if IsBankStorageItemLoc( itemLoc ) then
			hasZoneBankData = true
			if IsMainBankStorageItemLoc( itemLoc ) then
				mainCount = mainCount + GetStoredItemCount( charData, itemLoc, itemId )
			else
				otherCount = otherCount + GetStoredItemCount( charData, itemLoc, itemId )
			end
		end
	end

	if not hasZoneBankData then
		mainCount = mainCount + GetStoredItemCount( charData, GameData.ItemLocs.BANK, itemId )
	end

	return mainCount, otherCount, hasZoneBankData
end

function mod:GetCharacterItemInfo( charSlot, itemId )
	local characterInventoryCount = 0
	local totalInventoryCount = 0
	local mainBankCount
	local otherBankCount
	local hasZoneBankData

	-- Select the given characters database
	local chardb = EnsureCharacterData(charSlot)
	if chardb == nil then
		return 0, 0, 0, 0, false
	end

	-- Count items carried by the character.
	for itemLoc, _ in pairs( playerSets )
	do
		characterInventoryCount = characterInventoryCount + GetStoredItemCount(chardb, itemLoc, itemId)
	end

	-- Add known bank counts to get the total known count.
	mainBankCount, otherBankCount, hasZoneBankData = GetStoredBankItemCounts(chardb, itemId)
	totalInventoryCount = characterInventoryCount
	totalInventoryCount = totalInventoryCount + mainBankCount + otherBankCount

	return characterInventoryCount, totalInventoryCount, mainBankCount, otherBankCount, hasZoneBankData
end

local function GetCurrentMoneyAmount()
	if Player ~= nil and Player.GetMoney ~= nil then
		return Player.GetMoney() or 0
	end

	if GameData ~= nil and GameData.Player ~= nil and GameData.Player.money ~= nil then
		return GameData.Player.money or 0
	end

	return 0
end

function mod:UpdatePlayerMoney()
	local selectedSlot = GameData and GameData.Account and GameData.Account.SelectedCharacterSlot
	local moneyBySlot = EnsureMoneyBySlot()
	if selectedSlot == nil or moneyBySlot == nil then
		return
	end

	moneyBySlot[selectedSlot] = GetCurrentMoneyAmount()
end

function mod:GetCharacterMoneyInfo( charSlot )
	local moneyBySlot = GetMoneyBySlot()
	if moneyBySlot == nil then
		return 0, false
	end

	local money = rawget( moneyBySlot, charSlot )
	if money == nil then
		return 0, false
	end

	return tonumber(money) or 0, true
end

function mod:GetBankStatusLines()
	local lines = new()
	local bankRows = new()
	local charData = EnsureCurrentCharacterData()
	local currentBucket = GetCurrentBankItemLoc()

	tinsert( lines, "Shinies bank buckets for this character:" )
	tinsert( lines, "current zone bucket: " .. currentBucket )

	local slots, uniqueItems, stackCount = GetLocationSummary( charData, GameData.ItemLocs.BANK )
	tinsert( bankRows, {
		name = "legacy BANK",
		text = string_format( "legacy BANK slots=%d unique=%d stacks=%d", slots, uniqueItems, stackCount ),
	} )

	if charData ~= nil and charData.totals ~= nil then
		for itemLoc, _ in pairs( charData.totals )
		do
			if IsBankStorageItemLoc( itemLoc ) then
				slots, uniqueItems, stackCount = GetLocationSummary( charData, itemLoc )
				tinsert( bankRows, {
					name = itemLoc,
					text = string_format( "%s slots=%d unique=%d stacks=%d", itemLoc, slots, uniqueItems, stackCount ),
				} )
			end
		end
	end

	tsort( bankRows, function(a, b) return a.name < b.name end )

	for _, row in ipairs( bankRows )
	do
		tinsert( lines, row.text )
	end

	del( bankRows )

	return lines
end

function mod:OnInitialize()
end

function mod:OnEnable()
	RegisterEventHandler( SystemData.Events.INTERACT_OPEN_BANK, 				"ShiniesDataInventory.OnInteractBankOpen" )
	RegisterEventHandler( SystemData.Events.PLAYER_BANK_SLOT_UPDATED, 			"ShiniesDataInventory.OnPlayerBankSlotUpdated" )
	RegisterEventHandler( SystemData.Events.PLAYER_INVENTORY_SLOT_UPDATED, 		"ShiniesDataInventory.OnPlayerInventorySlotUpdated" )
	RegisterEventHandler( SystemData.Events.PLAYER_CRAFTING_SLOT_UPDATED, 		"ShiniesDataInventory.OnPlayerCraftingSlotUpdated" )
	RegisterEventHandler( SystemData.Events.PLAYER_CURRENCY_SLOT_UPDATED, 		"ShiniesDataInventory.OnPlayerCurrencySlotUpdated" )
	RegisterEventHandler( SystemData.Events.PLAYER_MONEY_UPDATED, 				"ShiniesDataInventory.OnPlayerMoneyUpdated" )

	-- Create the basic pending processing tables we need
	for k, _ in pairs( allItemSets )
	do
		pendingProcessing[k] = new()
	end

	-- Update our database for easy access
	EnsureCurrentCharacterData()
	if not ( Shinies and Shinies.IsActivityPaused and Shinies:IsActivityPaused() ) then
		ShiniesDataInventory:UpdatePlayerMoney()
	end

	-- Schedule a player data update
	ShiniesDataInventory:ScheduleTimer( "UpdatePlayerData", 1 )
end

function mod:OnDisable()
	UnregisterEventHandler( SystemData.Events.INTERACT_OPEN_BANK, 				"ShiniesDataInventory.OnInteractBankOpen" )
	UnregisterEventHandler( SystemData.Events.PLAYER_BANK_SLOT_UPDATED, 		"ShiniesDataInventory.OnPlayerBankSlotUpdated" )
	UnregisterEventHandler( SystemData.Events.PLAYER_INVENTORY_SLOT_UPDATED, 	"ShiniesDataInventory.OnPlayerInventorySlotUpdated" )
	UnregisterEventHandler( SystemData.Events.PLAYER_CRAFTING_SLOT_UPDATED, 	"ShiniesDataInventory.OnPlayerCraftingSlotUpdated" )
	UnregisterEventHandler( SystemData.Events.PLAYER_CURRENCY_SLOT_UPDATED, 	"ShiniesDataInventory.OnPlayerCurrencySlotUpdated" )
	UnregisterEventHandler( SystemData.Events.PLAYER_MONEY_UPDATED, 			"ShiniesDataInventory.OnPlayerMoneyUpdated" )

	if pendingMoneyUpdateTimer ~= nil then
		ShiniesDataInventory:CancelTimer( pendingMoneyUpdateTimer, true )
		pendingMoneyUpdateTimer = nil
	end
end

function ShiniesDataInventory.OnInteractBankOpen()
	-- Respect activity gating
	if Shinies and Shinies.IsActivityPaused and Shinies:IsActivityPaused() then return end

	currentBankItemLoc = GetCurrentBankItemLoc()

	-- Clear old pre-zone bank data. It is ambiguous, so repopulate the opened bank from live data.
	clearItemLoc( GameData.ItemLocs.BANK )

	-- We only clear the items we have stored for this bank, as
	-- we will receive slot updates for all of the items in the bank
	-- right after this event which will handle the updates
	clearItemLoc( currentBankItemLoc )
end

function ShiniesDataInventory.OnPlayerBankSlotUpdated( updatedSlots )
	-- Respect activity gating
	if Shinies and Shinies.IsActivityPaused and Shinies:IsActivityPaused() then return end

	if currentBankItemLoc == nil then
		currentBankItemLoc = GetCurrentBankItemLoc()
	end

	-- Add the updated slots to the processing queue
	tinsert( pendingProcessing[GameData.ItemLocs.BANK], { itemLoc = currentBankItemLoc, slots = updatedSlots } )

	ShiniesDataInventory:ScheduleTimer( "OnProcessingTimer", pendingTime )
end

function ShiniesDataInventory.OnPlayerInventorySlotUpdated( updatedSlots )
	-- Respect activity gating
	if Shinies and Shinies.IsActivityPaused and Shinies:IsActivityPaused() then return end
	-- Add the updated slots to the processing queue
	tinsert( pendingProcessing[GameData.ItemLocs.INVENTORY], updatedSlots )

	ShiniesDataInventory:ScheduleTimer( "OnProcessingTimer", pendingTime )
end

function ShiniesDataInventory.OnPlayerCraftingSlotUpdated( updatedSlots )
	-- Respect activity gating
	if Shinies and Shinies.IsActivityPaused and Shinies:IsActivityPaused() then return end
	-- Add the updated slots to the processing queue
	tinsert( pendingProcessing[GameData.ItemLocs.CRAFTING_ITEM], updatedSlots )

	ShiniesDataInventory:ScheduleTimer( "OnProcessingTimer", pendingTime )
end

function ShiniesDataInventory.OnPlayerCurrencySlotUpdated( updatedSlots )
	-- Respect activity gating
	if Shinies and Shinies.IsActivityPaused and Shinies:IsActivityPaused() then return end
	-- Add the updated slots to the processing queue
	tinsert( pendingProcessing[GameData.ItemLocs.CURRENCY_ITEM], updatedSlots )

	ShiniesDataInventory:ScheduleTimer( "OnProcessingTimer", pendingTime )
end

function ShiniesDataInventory.OnPlayerMoneyUpdated()
	-- Respect activity gating
	if Shinies and Shinies.IsActivityPaused and Shinies:IsActivityPaused() then return end

	-- The event argument can be stale during character transitions; read live money after the UI settles.
	if pendingMoneyUpdateTimer ~= nil then
		ShiniesDataInventory:CancelTimer( pendingMoneyUpdateTimer, true )
	end
	pendingMoneyUpdateTimer = ShiniesDataInventory:ScheduleTimer( "OnMoneyUpdateTimer", moneyUpdateDelay )
end

function mod:OnMoneyUpdateTimer()
	pendingMoneyUpdateTimer = nil
	-- Respect activity gating
	if Shinies and Shinies.IsActivityPaused and Shinies:IsActivityPaused() then return end

	ShiniesDataInventory:UpdatePlayerMoney()
end

function mod:OnProcessingTimer()
	-- Respect activity gating
	if Shinies and Shinies.IsActivityPaused and Shinies:IsActivityPaused() then return end
	for itemLoc, locData in pairs( pendingProcessing )
	do
		for _, data in ipairs( locData )
		do
			if itemLoc == GameData.ItemLocs.BANK then
				processItemSlotUpdated( data.itemLoc or GetCurrentBankItemLoc(), data.slots, GameData.ItemLocs.BANK )
			else
				processItemSlotUpdated( itemLoc, data )
			end
		end
		wipe(locData)
	end
end

function mod:UpdatePlayerData()
	-- Respect activity gating
	if Shinies and Shinies.IsActivityPaused and Shinies:IsActivityPaused() then return end
	ShiniesDataInventory:UpdatePlayerMoney()
	for itemLoc, _ in pairs( playerSets )
	do
		processItemLoc( itemLoc )
	end
end

---------------------------------------------------------
-- LOCAL FUNCTIONS
---------------------------------------------------------

function clearItemLoc( itemLoc )
	local charData = EnsureItemLocationData(itemLoc)
	if charData == nil then
		return
	end

	-- Clear all tables for this item loc
	charData.totals[itemLoc] 	= {}
	charData.locs[itemLoc]		= {}
	for id, item in pairs( charData.items )
	do
		item[itemLoc] = nil
	end
end

function processItemLoc( itemLoc )
	-- Clear the info for this item loc
	clearItemLoc( itemLoc )

	-- Attempt to retrieve our data
	local data = allItemSets[itemLoc].data()
	if( data ~= nil ) then
		-- Iterate the data we received and process accordingly
		for slot, item in ipairs( data )
		do
			processItemSlotUpdated( itemLoc, {slot} )
		end
	end
end

function processItemSlotUpdated( itemLoc, updatedSlots, sourceItemLoc )
	local oldItem
	local newItem
	local charData = EnsureItemLocationData(itemLoc)
	sourceItemLoc = sourceItemLoc or itemLoc

	if charData == nil then
		return
	end

	-- Iterate the updated slots
	for idx, slot in ipairs( updatedSlots )
	do
		-- Get the old item id in the updated inventory slot
		oldItem = charData.locs[itemLoc][slot]

		-- Get the current item in the slot
		newItem = DataUtils.GetItemData( sourceItemLoc, slot )

		local isOldValid = oldItem ~= nil and ShiniesAPI:Item_IsValid( oldItem )
		local isNewValid = newItem ~= nil and ShiniesAPI:Item_IsValid( newItem )

		-- If the old item is valid, remove the information for it
		if( isOldValid ) then
			-- Remove the old slot information
			charData.locs[itemLoc][slot] = nil
			if charData.items[oldItem.uniqueID] ~= nil and charData.items[oldItem.uniqueID][itemLoc] ~= nil then
				charData.items[oldItem.uniqueID][itemLoc][slot] = nil
			end
			if charData.totals[itemLoc][oldItem.uniqueID] ~= nil then
				charData.totals[itemLoc][oldItem.uniqueID].count = charData.totals[itemLoc][oldItem.uniqueID].count - oldItem.stackCount
				if charData.totals[itemLoc][oldItem.uniqueID].count <= 0 then
					charData.totals[itemLoc][oldItem.uniqueID] = nil
				end
			end
		end

		-- If the new item is valid, add its slot information
		if( isNewValid ) then
			EnsureItemEntry(charData, itemLoc, newItem.uniqueID)
			if charData.locs[itemLoc][slot] == nil then
				charData.locs[itemLoc][slot] = {}
			end

			-- Update our location map
			charData.locs[itemLoc][slot].uniqueID 	= newItem.uniqueID
			charData.locs[itemLoc][slot].stackCount	= newItem.stackCount

			-- Update the item map
			charData.items[newItem.uniqueID][itemLoc][slot] = true

			-- Update the totals for each location
			charData.totals[itemLoc][newItem.uniqueID].count = charData.totals[itemLoc][newItem.uniqueID].count + newItem.stackCount
		end

	end
end
