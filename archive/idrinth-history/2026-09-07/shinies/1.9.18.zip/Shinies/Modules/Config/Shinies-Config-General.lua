--[[
	This application is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    The applications is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with the applications.  If not, see <http://www.gnu.org/licenses/>.

    Portions of this class are from: http://lua-users.org/wiki/SortedIteration
--]]

local LibGUI = LibStub( "LibGUI" )
if (not LibGUI) then return end

local Shinies 				= _G.Shinies
local T		    			= Shinies.T
local MODNAME 				= "Shinies-Config-General"
local ShiniesConfigGeneral	= Shinies : NewModule( MODNAME )
_G.ShiniesConfigGeneral 	= ShiniesConfigGeneral
ShiniesConfigGeneral:SetModuleType( "Config" )
ShiniesConfigGeneral:SetName( T["Shinies General Configuration"] )
ShiniesConfigGeneral:SetDescription(T["Provides a user interface for modifying general Shinies configuration settings."])
ShiniesConfigGeneral:SetDefaults( {} )

local new, del, wipe = Shinies.new, Shinies.del, Shinies.wipe
local tinsert, tsort = table.insert, table.sort

local config				= nil

local windowGeneral

local MIN_SCALE				= 0.4
local MAX_SCALE				= 1.2

local initializeUI
local bindCheckboxLabel
local bindOptionPreview
local showOptionPreview
local getPreviewCharacterName
local getPreviewBankNames
local getBankLabelsOnPreviewText
local getSplitBankCountsOffPreviewText
local getSplitBankCountsOnPreviewText
local getSplitBankCountsNoteText
local getOptionPreviewText

-----------------------------------------
-- MODULE FUNCTIONS
-----------------------------------------

function ShiniesConfigGeneral:Apply( window )
	for k, v in pairs( window.E )
	do
		if( v.Apply ~= nil and type( v.Apply ) == "function" ) then
			v.Apply( window )
		end
	end

	-- If the API module is loaded, refresh its update timer state based on any new gating settings
	local api = Shinies : GetModule( "Shinies-API-Core" )
	if api and api.RefreshUpdateTimer then
		api:RefreshUpdateTimer()
	end
end

function ShiniesConfigGeneral:GetUserInterface()
	-- If our config already exists, return that one
	if( config ~= nil ) then return config end

	config =
	{
		name 		= T["General"],
		windows		= new(),
	}

	-- Create our base window
	windowGeneral = initializeUI()
	tinsert( config.windows, windowGeneral )

	return config
end

function ShiniesConfigGeneral:OnDisable()
	if( config ~= nil ) then
		for k, v in pairs( config.windows )
		do
			v:Destroy()
		end
		config = nil
	end
end

function ShiniesConfigGeneral.OnSlide_UIScale()
	local tick = windowGeneral.E.UIScale_Slider:GetValue()
	windowGeneral.E.UIScale_Textbox:SetText( wstring.format( L"%.2f", towstring( tick ) ) )
end

function ShiniesConfigGeneral:Revert( window )
	for k, v in pairs( window.E )
	do
		if( v.Revert ~= nil and type( v.Revert ) == "function" ) then
			v.Revert( window )
		end
	end
end

-----------------------------------------
-- LOCAL FUNCTIONS
-----------------------------------------

function bindCheckboxLabel( label, checkbox )
	label:CaptureInput()
	label:RegisterEvent( "OnLButtonUp" )
	label.OnLButtonUp =
		function()
			checkbox:Toggle()
		end
end

function getPreviewCharacterName()
	if GameData ~= nil
		and GameData.Player ~= nil
		and GameData.Player.name ~= nil
	then
		return wstring.match( GameData.Player.name, L"([^%^]+).*" ) or GameData.Player.name
	end

	return L"Character"
end

function getPreviewBankNames()
	if GameData ~= nil and GameData.Player ~= nil and GameData.Realm ~= nil then
		if( GameData.Player.realm == GameData.Realm.ORDER ) then
			return L"Altdorf", L"KaK", T["Inventory (Altdorf, KaK)"]
		elseif( GameData.Player.realm == GameData.Realm.DESTRUCTION ) then
			return L"IC", L"K8P", T["Inventory (IC, K8P)"]
		end
	end

	return L"Altdorf/IC", L"KaK/K8P", T["Inv (Altdorf/IC, KaK/K8P)"]
end

function getBankLabelsOnPreviewText()
	local _, _, headerText = getPreviewBankNames()
	return L"On: " .. headerText
end

function getSplitBankCountsOffPreviewText()
	return L"Off: " .. getPreviewCharacterName() .. L" 5 (12)"
end

function getSplitBankCountsOnPreviewText()
	return L"On: " .. getPreviewCharacterName() .. L" 5 (3, 4) = 12"
end

function getSplitBankCountsNoteText()
	local mainBank, otherBank = getPreviewBankNames()
	return L"Off: legacy (12) is total; On: (3, 4) is " .. mainBank .. L", " .. otherBank .. L"."
end

function getOptionPreviewText( text )
	if( type( text ) == "function" ) then
		return text()
	end

	return text
end

function showOptionPreview( anchorWindow, title, offText, onText, noteText )
	Tooltips.CreateTextOnlyTooltip( anchorWindow, nil )
	Tooltips.SetTooltipText( 1, 1, getOptionPreviewText( title ) )
	Tooltips.SetTooltipText( 2, 1, getOptionPreviewText( offText ) )
	Tooltips.SetTooltipText( 3, 1, getOptionPreviewText( onText ) )
	if noteText ~= nil then
		Tooltips.SetTooltipText( 4, 1, getOptionPreviewText( noteText ) )
	end
	Tooltips.Finalize()
	Tooltips.AnchorTooltip( Tooltips.ANCHOR_WINDOW_RIGHT )
end

function bindOptionPreview( element, title, offText, onText, noteText )
	element:RegisterEvent( "OnMouseOver" )
	element:RegisterEvent( "OnMouseOverEnd" )
	element.OnMouseOver =
		function()
			showOptionPreview( element.name, title, offText, onText, noteText )
		end
	element.OnMouseOverEnd =
		function()
			Tooltips.ClearTooltip()
		end
end

function initializeUI()
	local w
	local e

	-- Create our general window
	w = LibGUI( "window" , nil, "ShiniesWindowDefault" )
	w:Resize( 741, 340 )
	w:Hide()
	w.E = new()
	w.module = self
	w.Apply =
		function( window )
			ShiniesConfigGeneral:Apply( window )
		end
	w.Revert =
		function( window )
			ShiniesConfigGeneral:Revert( window )
		end

	e = w( "label", nil, "Shinies_Default_Label_ClearLargeFont" )
    e:Resize( 450, 25 )
    e:Align( "leftcenter" )
    e:AnchorTo( w, "topleft", "topleft", 15, 10 )
    e:SetText( T["General"] )
    w.E.Title_Label = e

    -- Disable Default AH Checkbox
    e = w( "Checkbox" )
    e:AnchorTo( w.E.Title_Label, "bottomleft", "topleft", 10, 10 )
	e.Apply =
		function( window )
			Shinies.db.profile.general.disable_auction_house = window.E.DisableDefaultAH_Checkbox:GetValue()
			Shinies:UpdateDefaultAuctionHouseDisable()
		end
	e.Revert =
		function( window )
			window.E.DisableDefaultAH_Checkbox:SetValue( Shinies.db.profile.general.disable_auction_house )
		end
    w.E.DisableDefaultAH_Checkbox = e

    -- Disable Default AH Label
    e = w( "Label" )
    e:Resize( 250 )
    e:Align( "leftcenter" )
    e:WordWrap( false )
    e:AnchorTo( w.E.DisableDefaultAH_Checkbox, "right", "left", 10, 0 )
    e:Font( "font_chat_text" )
    e:SetText( T["Disable Default Auction House"] )
    bindCheckboxLabel( e, w.E.DisableDefaultAH_Checkbox )
    w.E.DisableDefaultAH_Label = e

    -- Disable Shinies activity While In Combat Checkbox
    e = w( "Checkbox" )
    -- Align under the first checkbox to keep checkboxes in a neat column
    e:AnchorTo( w.E.DisableDefaultAH_Checkbox, "bottomleft", "topleft", 0, 10 )
    e.Apply =
        function( window )
            Shinies.db.profile.general.disable_in_combat = window.E.DisableInCombat_Checkbox:GetValue()
        end
    e.Revert =
        function( window )
            window.E.DisableInCombat_Checkbox:SetValue( Shinies.db.profile.general.disable_in_combat )
        end
    w.E.DisableInCombat_Checkbox = e

    -- Disable Shinies activity While In Combat Label
    e = w( "Label" )
    e:Resize( 350 )
    e:Align( "leftcenter" )
    e:WordWrap( false )
    e:AnchorTo( w.E.DisableInCombat_Checkbox, "right", "left", 10, 0 )
    e:Font( "font_chat_text" )
    e:SetText( T["Disable Shinies activity while in combat"] )
    bindCheckboxLabel( e, w.E.DisableInCombat_Checkbox )
    w.E.DisableInCombat_Label = e

    -- Disable Shinies activity While RvR-Flagged Checkbox
    e = w( "Checkbox" )
    -- Align under the combat checkbox
    e:AnchorTo( w.E.DisableInCombat_Checkbox, "bottomleft", "topleft", 0, 10 )
    e.Apply =
        function( window )
            Shinies.db.profile.general.disable_rvr_flagged = window.E.DisableRvR_Checkbox:GetValue()
        end
    e.Revert =
        function( window )
            window.E.DisableRvR_Checkbox:SetValue( Shinies.db.profile.general.disable_rvr_flagged )
        end
    w.E.DisableRvR_Checkbox = e

    -- Disable Shinies activity While RvR-Flagged Label
    e = w( "Label" )
    e:Resize( 350 )
    e:Align( "leftcenter" )
    e:WordWrap( false )
    e:AnchorTo( w.E.DisableRvR_Checkbox, "right", "left", 10, 0 )
    e:Font( "font_chat_text" )
    e:SetText( T["Disable Shinies activity when RvR-flagged"] )
    bindCheckboxLabel( e, w.E.DisableRvR_Checkbox )
    w.E.DisableRvR_Label = e

    -- Split Bank Counts Checkbox
    e = w( "Checkbox" )
    e:AnchorTo( w.E.DisableRvR_Checkbox, "bottomleft", "topleft", 0, 10 )
    e.Apply =
        function( window )
            Shinies.db.profile.general.inventory_tooltip_split_bank_counts = window.E.InventoryTooltipSplitBankCounts_Checkbox:GetValue()
        end
    e.Revert =
        function( window )
            window.E.InventoryTooltipSplitBankCounts_Checkbox:SetValue( Shinies.db.profile.general.inventory_tooltip_split_bank_counts == true )
        end
    w.E.InventoryTooltipSplitBankCounts_Checkbox = e

    -- Split Bank Counts Label
    e = w( "Label" )
    e:Resize( 420 )
    e:Align( "leftcenter" )
    e:WordWrap( false )
    e:AnchorTo( w.E.InventoryTooltipSplitBankCounts_Checkbox, "right", "left", 10, 0 )
    e:Font( "font_chat_text" )
    e:SetText( T["Show split bank counts in inventory tooltips"] )
    bindCheckboxLabel( e, w.E.InventoryTooltipSplitBankCounts_Checkbox )
    bindOptionPreview( e, T["Split bank counts"], getSplitBankCountsOffPreviewText, getSplitBankCountsOnPreviewText, getSplitBankCountsNoteText )
    bindOptionPreview( w.E.InventoryTooltipSplitBankCounts_Checkbox, T["Split bank counts"], getSplitBankCountsOffPreviewText, getSplitBankCountsOnPreviewText, getSplitBankCountsNoteText )
    w.E.InventoryTooltipSplitBankCounts_Label = e

    -- Bank Labels Checkbox
    e = w( "Checkbox" )
    e:AnchorTo( w.E.InventoryTooltipSplitBankCounts_Checkbox, "bottomleft", "topleft", 0, 10 )
    e.Apply =
        function( window )
            Shinies.db.profile.general.inventory_tooltip_show_bank_labels = window.E.InventoryTooltipBankLabels_Checkbox:GetValue()
        end
    e.Revert =
        function( window )
            window.E.InventoryTooltipBankLabels_Checkbox:SetValue( Shinies.db.profile.general.inventory_tooltip_show_bank_labels == true )
        end
    w.E.InventoryTooltipBankLabels_Checkbox = e

    -- Bank Labels Label
    e = w( "Label" )
    e:Resize( 420 )
    e:Align( "leftcenter" )
    e:WordWrap( false )
    e:AnchorTo( w.E.InventoryTooltipBankLabels_Checkbox, "right", "left", 10, 0 )
    e:Font( "font_chat_text" )
    e:SetText( T["Show bank names in inventory tooltip headers"] )
    bindCheckboxLabel( e, w.E.InventoryTooltipBankLabels_Checkbox )
    bindOptionPreview( e, T["Bank names"], T["Off: Inventory"], getBankLabelsOnPreviewText, T["Requires split bank counts and only appears when the item has bank counts."] )
    bindOptionPreview( w.E.InventoryTooltipBankLabels_Checkbox, T["Bank names"], T["Off: Inventory"], getBankLabelsOnPreviewText, T["Requires split bank counts and only appears when the item has bank counts."] )
    w.E.InventoryTooltipBankLabels_Label = e

    -- UI Scale Label
    e = w( "Label" )
    e:Resize( 450 )
    e:Align( "center" )
    e:AnchorTo( w.E.InventoryTooltipBankLabels_Label, "bottom", "top", 0, 25 )
    e:Font( "font_chat_text" )
    e:SetText( T["Shinies UI Scale"] )
    w.E.UIScale_Label = e

    -- UI Scale Slider
    e = w( "Slider", nil, "ShiniesConfigGeneralUIScaleSlider" )
    e:AnchorTo( w.E.UIScale_Label, "bottom", "top", 0, 5 )
    e:SetRange( MIN_SCALE, MAX_SCALE )
    e.Apply =
	function( window )
		Shinies:UpdateUIScale( window.E.UIScale_Slider:GetValue() )
	end
    e.Revert =
	function( window )
		w.E.UIScale_Slider:SetValue( Shinies.db.profile.general.uiscale )
		w.E.UIScale_Textbox:SetText( wstring.format( L"%.2f", towstring( Shinies.db.profile.general.uiscale ) ) )
	end
    w.E.UIScale_Slider = e

    --UI Scale Label
    e = w( "Label" )
    e:Resize( 200 )
    e:AnchorTo( w.E.UIScale_Slider, "left", "right", -15, 0)
    e:Font( "font_chat_text" )
    e:Align( "rightcenter" )
    e:SetText( T["Scale"] )
    w.E.UIScale_Label = e

    -- UI Scale Textbox
    e = w( "Textbox" )
    e:Resize( 65 )
    e:AnchorTo( w.E.UIScale_Slider, "right", "left", 10, 0 )
    e:SetText( 255 )
    e:UnregisterDefaultEvents()
    e:IgnoreInput()
    w.E.UIScale_Textbox = e

    -- Revert our settings to get them initialized
    w.Revert( w )

    return w
end
