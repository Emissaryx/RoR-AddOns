--[[
	This application is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    The applications is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with the applications.  If not, see <http://www.gnu.org/licenses/>.
--]]

local Shinies 		= _G.Shinies
local T		    	= Shinies.T
local MODNAME 		= "Shinies-Aggregator-CoinTooltip"
local mod	 		= Shinies : NewModule( MODNAME )
ShiniesCoinTooltip	= mod
_G.ShiniesCoinTooltip = ShiniesCoinTooltip
mod:SetModuleType( "Aggregator" )
mod:SetName( T["Shinies Coin Tooltip"] )
mod:SetDescription( T["Provides character coin totals on the backpack money tooltip."] )
mod:SetDefaults( {} )

local new, del, wipe = Shinies.new, Shinies.del, Shinies.wipe

local pairs 				= pairs
local ipairs				= ipairs
local tinsert				= table.insert
local wstring_match			= wstring.match

local ShiniesAPI
local SDI

local MONEY_WINDOW_ROOT = "EA_Window_BackpackMoney"
local TITLE_ROW = 2
local TOOLTIP_MIN_WIDTH = 300
local MONEY_WINDOW_SUFFIXES =
{
	"",
	"GoldText",
	"GoldFrame",
	"GoldFrameImage",
	"SilverText",
	"SilverFrame",
	"SilverFrameImage",
	"BrassText",
	"BrassFrame",
	"BrassFrameImage",
}

local attachedWindows = {}
local hook_EA_Window_Backpack_UpdateMoney

local HEADER_COLOR = { r = 222, g = 92, b = 50 }
local SELF_COLOR = { r = 0, g = 200, b = 0 }

local function IsActivityPaused()
	return Shinies and Shinies.IsActivityPaused and Shinies:IsActivityPaused()
end

local function GetCharacterName( char )
	return wstring_match( char.Name, L"([^%^]+).*" ) or char.Name
end

local function IsCurrentCharacter( char )
	return GameData ~= nil
		and GameData.Player ~= nil
		and GameData.Player.name ~= nil
		and WStringsCompare( char.Name, GameData.Player.name ) == 0
end

local function GetMouseOverWindow()
	if SystemData ~= nil and SystemData.MouseOverWindow ~= nil and SystemData.MouseOverWindow.name ~= nil then
		return SystemData.MouseOverWindow.name
	end

	if SystemData ~= nil and SystemData.ActiveWindow ~= nil and SystemData.ActiveWindow.name ~= nil then
		return SystemData.ActiveWindow.name
	end

	return MONEY_WINDOW_ROOT
end

local function GetMaxTooltipRows()
	if Tooltips ~= nil and Tooltips.NUM_ROWS ~= nil then
		return Tooltips.NUM_ROWS
	end

	return 17
end

local function SetTooltipRowText(row, leftText, rightText, color)
	Tooltips.SetTooltipText( row, 1, leftText )
	Tooltips.SetTooltipText( row, 3, rightText )

	if color ~= nil then
		Tooltips.SetTooltipColor( row, 1, color.r, color.g, color.b )
		Tooltips.SetTooltipColor( row, 3, color.r, color.g, color.b )
	end
end

local function AttachWindow(windowName)
	if DoesWindowExist == nil or not DoesWindowExist( windowName ) then
		return
	end

	if attachedWindows[windowName] ~= nil then
		return
	end

	attachedWindows[windowName] = WindowGetHandleInput( windowName )
	WindowSetHandleInput( windowName, true )
	WindowRegisterCoreEventHandler( windowName, "OnMouseOver", "ShiniesCoinTooltip.OnMouseOver" )
	WindowRegisterCoreEventHandler( windowName, "OnMouseOverEnd", "ShiniesCoinTooltip.OnMouseOverEnd" )
end

function mod.AttachMoneyFrame()
	for _, suffix in ipairs( MONEY_WINDOW_SUFFIXES )
	do
		AttachWindow( MONEY_WINDOW_ROOT .. suffix )
	end
end

function mod.GetCoinTooltipRows()
	local rows = new()
	local totalMoney = 0

	if SDI == nil or GameData == nil or GameData.Account == nil or GameData.Account.CharacterSlot == nil then
		return rows, totalMoney
	end

	for slot, char in ipairs( GameData.Account.CharacterSlot )
	do
		if( char.Level > 0 ) then
			local isSelf = IsCurrentCharacter( char )
			local money, hasMoneyData = SDI:GetCharacterMoneyInfo( slot )

			if isSelf or hasMoneyData then
				totalMoney = totalMoney + money
				tinsert( rows,
				{
					name = GetCharacterName( char ),
					money = money,
					self = isSelf,
				} )
			end
		end
	end

	return rows, totalMoney
end

function ShiniesCoinTooltip.OnMouseOver()
	if IsActivityPaused() then
		Tooltips.ClearTooltip()
		return
	end

	if ShiniesAPI == nil then
		Tooltips.ClearTooltip()
		return
	end

	if SDI ~= nil and SDI.UpdatePlayerMoney ~= nil then
		SDI:UpdatePlayerMoney()
	end

	local rows, totalMoney = ShiniesCoinTooltip:GetCoinTooltipRows()
	if( rows == nil or #rows == 0 ) then
		if rows ~= nil then
			del( rows )
		end
		Tooltips.ClearTooltip()
		return
	end

	Tooltips.CreateTextOnlyTooltip( GetMouseOverWindow(), nil )

	Tooltips.SetTooltipText( TITLE_ROW, 2, T["Coin Inventory"] )
	Tooltips.SetTooltipColor( TITLE_ROW, 2, HEADER_COLOR.r, HEADER_COLOR.g, HEADER_COLOR.b )

	local row = TITLE_ROW + 1
	local maxRows = GetMaxTooltipRows()
	local showTotal = totalMoney > 0 and #rows > 1
	local maxCharacterRows = maxRows - TITLE_ROW
	if showTotal then
		maxCharacterRows = maxCharacterRows - 1
	end

	for idx, char in ipairs( rows )
	do
		if( idx <= maxCharacterRows ) then
			local color
			if char.self then
				color = SELF_COLOR
			end

			SetTooltipRowText( row, char.name, ShiniesAPI:Display_GetFormattedMoney( char.money, true, true ), color )
			row = row + 1
		end
	end

	if showTotal and row <= maxRows then
		SetTooltipRowText( row, T["Total"], ShiniesAPI:Display_GetFormattedMoney( totalMoney, true, true ), HEADER_COLOR )
	end

	Tooltips.Finalize()
	local tooltipWidth, tooltipHeight = WindowGetDimensions( "DefaultTooltip" )
	if tooltipWidth < TOOLTIP_MIN_WIDTH then
		WindowSetDimensions( "DefaultTooltip", TOOLTIP_MIN_WIDTH, tooltipHeight )
	end
	Tooltips.AnchorTooltip( Tooltips.ANCHOR_CURSOR_LEFT, true )

	del( rows )
end

function ShiniesCoinTooltip.OnMouseOverEnd()
	Tooltips.ClearTooltip()
end

function ShiniesCoinTooltip.UpdateMoney( ... )
	if hook_EA_Window_Backpack_UpdateMoney ~= nil then
		hook_EA_Window_Backpack_UpdateMoney( ... )
	end

	ShiniesCoinTooltip:AttachMoneyFrame()
end

function mod.OnInitialize()
end

function mod.OnEnable()
	if EA_Window_Backpack ~= nil
		and EA_Window_Backpack.UpdateMoney ~= nil
		and EA_Window_Backpack.UpdateMoney ~= ShiniesCoinTooltip.UpdateMoney
	then
		hook_EA_Window_Backpack_UpdateMoney = EA_Window_Backpack.UpdateMoney
		EA_Window_Backpack.UpdateMoney = ShiniesCoinTooltip.UpdateMoney
	end

	ShiniesCoinTooltip:AttachMoneyFrame()
end

function mod.OnDisable()
	if EA_Window_Backpack ~= nil and EA_Window_Backpack.UpdateMoney == ShiniesCoinTooltip.UpdateMoney then
		EA_Window_Backpack.UpdateMoney = hook_EA_Window_Backpack_UpdateMoney
	end

	hook_EA_Window_Backpack_UpdateMoney = nil

	for windowName, handleInput in pairs( attachedWindows )
	do
		if DoesWindowExist ~= nil and DoesWindowExist( windowName ) then
			WindowUnregisterCoreEventHandler( windowName, "OnMouseOver" )
			WindowUnregisterCoreEventHandler( windowName, "OnMouseOverEnd" )
			WindowSetHandleInput( windowName, handleInput == true )
		end
	end

	wipe( attachedWindows )
end

function mod.OnAllModulesEnabled()
	ShiniesAPI	= Shinies : GetModule( "Shinies-API-Core" )
	SDI			= Shinies : GetModule( "Shinies-Data-Inventory" )
end
