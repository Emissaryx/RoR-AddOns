--[[
	This application is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.
--]]

if not ShiniesConstants then ShiniesConstants = {} end

local ShiniesConstants = ShiniesConstants
local towstring        = towstring
local pairs            = pairs
local ipairs           = ipairs
local tsort            = table.sort
local tinsert          = table.insert
local string_format    = string.format

local T = LibStub("WAR-AceLocale-3.0"):GetLocale("Shinies")

-- guard against double initialization
local initialized = false

-- shared sort helper (DEFINE ONCE)
local function TextSort(a, b)
	return towstring(a.text) < towstring(b.text)
end

function ShiniesConstants.Initialize()
	if initialized then
		return
	end
	initialized = true

	--------------------------------------------------
	-- Basic limits
	--------------------------------------------------

	ShiniesConstants.MIN_ITEM_LEVEL        = 1
	ShiniesConstants.MAX_ITEM_LEVEL        = 40
	ShiniesConstants.MIN_TRADE_SKILL_LEVEL = 0
	ShiniesConstants.MAX_TRADE_SKILL_LEVEL = 200

	--------------------------------------------------
	-- Icons
	--------------------------------------------------

	ShiniesConstants.ICON_CHECKED   = L"<icon57>"
	ShiniesConstants.ICON_UNCHECKED = L"<icon58>"

	--------------------------------------------------
	-- Item location → backpack mapping
	--------------------------------------------------

	ShiniesConstants.AUCTION_ITEMLOC_TO_BACKPACK =
	{
		[GameData.ItemLocs.INVENTORY]     = EA_Window_Backpack.TYPE_INVENTORY,
		[GameData.ItemLocs.CRAFTING_ITEM] = EA_Window_Backpack.TYPE_CRAFTING,
	}

	--------------------------------------------------
	-- Auction durations
	--------------------------------------------------

	ShiniesConstants.AUCTION_DURATIONS =
	{
		[0] = { text = L"2h"  },
		[1] = { text = L"8h"  },
		[2] = { text = L"24h" },
		[3] = { text = L"48h" },
		[4] = { text = L"72h" },
	}

	--------------------------------------------------
	-- Auction restrictions
	--------------------------------------------------

	ShiniesConstants.AUCTION_RESTRICTIONS =
	{
		{
			text  = GetStringFromTable(
				"AuctionHouseStrings",
				StringTables.AuctionHouse.CONTEXT_MENU_ADDITIONAL_FILTERS_UNRESTRICTED
			),
			value = GameData.Auction.RESTRICTION_NONE,
		},
		{
			text  = GetStringFromTable(
				"AuctionHouseStrings",
				StringTables.AuctionHouse.CONTEXT_MENU_ADDITIONAL_FILTERS_ALLIANCE
			),
			value = GameData.Auction.RESTRICTION_GUILD_ALLIANCE_ONLY,
		},
		{
			text  = GetStringFromTable(
				"AuctionHouseStrings",
				StringTables.AuctionHouse.CONTEXT_MENU_ADDITIONAL_FILTERS_GUILD
			),
			value = GameData.Auction.RESTRICTION_GUILD_ONLY,
		},
	}

	ShiniesConstants.AUCTION_RESTRICTIONS_LOOKUP = {}
	for _, v in pairs(ShiniesConstants.AUCTION_RESTRICTIONS) do
		ShiniesConstants.AUCTION_RESTRICTIONS_LOOKUP[v.value] = v.text
	end

	--------------------------------------------------
	-- Auction results
	--------------------------------------------------

	ShiniesConstants.AUCTION_RESULTS =
	{
		[GameData.Auction.BID_SUCCESS]                = { success = true,  text = T["Auction bid:  successful"] },
		[GameData.Auction.BUYOUT_SUCCESS]             = { success = true,  text = T["Auction buyout:  successful"] },
		[GameData.Auction.CANCEL_SUCCESS]             = { success = true,  text = T["Auction cancel:  successful"] },
		[GameData.Auction.BID_FAIL_BAD_BUY_OUT_PRICE] = { success = false, text = T["Auction buyout failed:  bad buyout price"] },
		[GameData.Auction.CANCEL_FAIL_BIDDER_EXISTS]  = { success = false, text = T["Auction cancel failed:  auction has a bidder"] },
		[GameData.Auction.CANCEL_FAIL_NOT_OWNER]      = { success = false, text = T["Auction cancel failed:  not the owner of the auction"] },
		[GameData.Auction.UNKNOWN_REASON]             = { success = false, text = T["Unknown reason"] },
		[GameData.Auction.CANCEL_FAIL_UNKNOWN_REASON] = { success = false, text = T["Auction cancel failed:  unknown reason"] },
		[GameData.Auction.BID_FAIL_MISSING_ITEM]      = { success = false, text = T["Auction bid failed:  missing item"] },
		[GameData.Auction.BID_FAIL_ITEM_SOLD]         = { success = false, text = T["Auction bid failed:  item was sold"] },
		[GameData.Auction.CANCEL_FAIL_ITEM_SOLD]      = { success = false, text = T["Auction cancel failed:  item was sold"] },
		[GameData.Auction.SERVER_UNAVAILABLE]         = { success = false, text = T["The auction house is not currently available in your region."] },
		[GameData.Auction.CREATE_AUCTION_FAILED]      = { success = false, text = T["Auction create failed:  unknown reason"] },
	}

	--------------------------------------------------
	-- Item rarity
	--------------------------------------------------

	ShiniesConstants.RARITY =
	{
		{ text = T["-Any Rarity-"],                                     value = SystemData.ItemRarity.UTILITY },
		{ text = GameDefs.ItemRarity[SystemData.ItemRarity.COMMON].desc,    value = SystemData.ItemRarity.COMMON },
		{ text = GameDefs.ItemRarity[SystemData.ItemRarity.UNCOMMON].desc,  value = SystemData.ItemRarity.UNCOMMON },
		{ text = GameDefs.ItemRarity[SystemData.ItemRarity.RARE].desc,      value = SystemData.ItemRarity.RARE },
		{ text = GameDefs.ItemRarity[SystemData.ItemRarity.VERY_RARE].desc, value = SystemData.ItemRarity.VERY_RARE },
		{ text = GameDefs.ItemRarity[SystemData.ItemRarity.ARTIFACT].desc,  value = SystemData.ItemRarity.ARTIFACT },
	}

	ShiniesConstants.RARITY_LOOKUP = {}
	for _, v in pairs(ShiniesConstants.RARITY) do
		ShiniesConstants.RARITY_LOOKUP[v.value] = v.text
	end


--------------------------------------------------
	-- Careers (Order / Destruction)
	--------------------------------------------------

	ShiniesConstants.CAREERS_ORDER =
	{
		{ text = T["-Any Career-"],                                    value = 0 },
		{ text = CareerNames[GameData.CareerLine.IRON_BREAKER].name,   value = GameData.CareerLine.IRON_BREAKER },
		{ text = CareerNames[GameData.CareerLine.RUNE_PRIEST].name,    value = GameData.CareerLine.RUNE_PRIEST },
		{ text = CareerNames[GameData.CareerLine.ENGINEER].name,       value = GameData.CareerLine.ENGINEER },
		{ text = CareerNames[GameData.CareerLine.KNIGHT].name,         value = GameData.CareerLine.KNIGHT },
		{ text = CareerNames[GameData.CareerLine.WITCH_HUNTER].name,   value = GameData.CareerLine.WITCH_HUNTER },
		{ text = CareerNames[GameData.CareerLine.BRIGHT_WIZARD].name,  value = GameData.CareerLine.BRIGHT_WIZARD },
		{ text = CareerNames[GameData.CareerLine.WARRIOR_PRIEST].name, value = GameData.CareerLine.WARRIOR_PRIEST },
		{ text = CareerNames[GameData.CareerLine.SWORDMASTER].name,    value = GameData.CareerLine.SWORDMASTER },
		{ text = CareerNames[GameData.CareerLine.SHADOW_WARRIOR].name, value = GameData.CareerLine.SHADOW_WARRIOR },
		{ text = CareerNames[GameData.CareerLine.ARCHMAGE].name,       value = GameData.CareerLine.ARCHMAGE },
		{ text = CareerNames[GameData.CareerLine.WHITE_LION].name,     value = GameData.CareerLine.WHITE_LION },
		{ text = CareerNames[GameData.CareerLine.SLAYER].name,         value = GameData.CareerLine.SLAYER },
	}
	tsort(ShiniesConstants.CAREERS_ORDER, TextSort)

	ShiniesConstants.CAREERS_ORDER_LOOKUP = {}
	for _, v in pairs(ShiniesConstants.CAREERS_ORDER) do
		ShiniesConstants.CAREERS_ORDER_LOOKUP[v.value] = v.text
	end

	ShiniesConstants.CAREERS_DESTRUCTION =
	{
		{ text = T["-Any Career-"],                                 value = 0 },
		{ text = CareerNames[GameData.CareerLine.BLACK_ORC].name,   value = GameData.CareerLine.BLACK_ORC },
		{ text = CareerNames[GameData.CareerLine.SHAMAN].name,      value = GameData.CareerLine.SHAMAN },
		{ text = CareerNames[GameData.CareerLine.SQUIG_HERDER].name, value = GameData.CareerLine.SQUIG_HERDER },
		{ text = CareerNames[GameData.CareerLine.MARAUDER].name,    value = GameData.CareerLine.MARAUDER },
		{ text = CareerNames[GameData.CareerLine.CHOSEN].name,      value = GameData.CareerLine.CHOSEN },
		{ text = CareerNames[GameData.CareerLine.ZEALOT].name,      value = GameData.CareerLine.ZEALOT },
		{ text = CareerNames[GameData.CareerLine.WITCH_ELF].name,   value = GameData.CareerLine.WITCH_ELF },
		{ text = CareerNames[GameData.CareerLine.DISCIPLE].name,    value = GameData.CareerLine.DISCIPLE },
		{ text = CareerNames[GameData.CareerLine.SORCERER].name,    value = GameData.CareerLine.SORCERER },
		{ text = CareerNames[GameData.CareerLine.MAGUS].name,       value = GameData.CareerLine.MAGUS },
		{ text = CareerNames[GameData.CareerLine.BLACKGUARD].name,  value = GameData.CareerLine.BLACKGUARD },
		{ text = CareerNames[GameData.CareerLine.CHOPPA].name,      value = GameData.CareerLine.CHOPPA },
	}
	tsort(ShiniesConstants.CAREERS_DESTRUCTION, TextSort)

	ShiniesConstants.CAREERS_DESTRUCTION_LOOKUP = {}
	for _, v in pairs(ShiniesConstants.CAREERS_DESTRUCTION) do
		ShiniesConstants.CAREERS_DESTRUCTION_LOOKUP[v.value] = v.text
	end

	--------------------------------------------------
	-- Modifiers / Item Types / Item Slots
	--------------------------------------------------

	ShiniesConstants.MODIFIERS = {}
	for k, v in pairs(BonusTypes) do
		tinsert(ShiniesConstants.MODIFIERS, {
			text  = (k == 0 and T["-Any Modifier-"] or v.name),
			value = k
		})
	end
	tsort(ShiniesConstants.MODIFIERS, TextSort)

	ShiniesConstants.ITEM_TYPES = { { text = T["-Any Item Type-"], value = 0 } }
	for k, v in pairs(ItemTypes) do
		tinsert(ShiniesConstants.ITEM_TYPES, { text = v.name, value = k })
	end
	tsort(ShiniesConstants.ITEM_TYPES, TextSort)

	ShiniesConstants.ITEM_SLOTS = { { text = T["-Any Item Slot-"], value = 0 } }
	for k, v in pairs(ItemSlots) do
		tinsert(ShiniesConstants.ITEM_SLOTS, { text = v.name, value = k })
	end
	tsort(ShiniesConstants.ITEM_SLOTS, TextSort)
end