CCTV = {}
local SnareID = {2,1358,1387,1509,1542,1670,1692,1727,1825,1831,1878,1914,1927,3012,3248,3262,3280,3289,3302,3311,3319,3438,3465,3468,3500,3963,3981,8012,8080,8154,8255,8324,8377,8396,8484,8499,8527,9004,9057,9092,9251,9255,9318,9348,9387,9394,9479,9549,10533,10544,10555,10566,10715,14430}
local KDID = {3082,3,6,237,1369,1384,1443,1494,1525,1688,1755,1804,3482,3581,3601,3959,4997,8018,8115,8186,8346,8412,8423,8456,8481,9028,9108,9427}
local StaggerID = {3027,3028,3029,3030,3031,3032,3033,3035,3168,3630,3707}
local SilenceID = {1607,1683,1722,1839,3218,3616,3762,3958,8100,8174,8256,8565,8607,9030,9095,9253,9304,9388,9489,9543,9565,}
local DisarmID = {1536,1837,3628,8086,8405,8495,9098,9482,9543}
local RootID = {1370,1418,1519,1681,8024,8069,8168,8336,8449,8480,9018,9224,9334,9477,9544,608,8579}
local KDTable = {}
local SnareTable = {}
local StaggerTable = {}
local SilenceTable = {}
local DisarmTable = {}
local RootTable = {}
--3082, eyeshot KD

CCTV.STAGGER_BUFF = {}
CCTV.STAGGER_TIMER = {}
CCTV.STAGGER_TIMER_MAX = {}

CCTV.SILENCE_BUFF = {}
CCTV.SILENCE_TIMER = {}
CCTV.SILENCE_TIMER_MAX = {}

CCTV.DISARM_BUFF = {}
CCTV.DISARM_TIMER = {}
CCTV.DISARM_TIMER_MAX = {}

CCTV.KD_BUFF = {}
CCTV.KD_TIMER = {}
CCTV.KD_TIMER_MAX = {}

CCTV.SNARE_BUFF = {}
CCTV.SNARE_TIMER = {}
CCTV.SNARE_TIMER_MAX = {}

CCTV.ROOT_BUFF = {}
CCTV.ROOT_TIMER = {}
CCTV.ROOT_TIMER_MAX = {}

--CCTV.SNARE_TIMER = nil


if CCTV.Scale == nil then
CCTV.Scale = 0.5
SliderBarSetCurrentPosition("CCTVSettingsSliderBar1",CCTV.Scale)
end
if CCTV.Alpha == nil then
CCTV.Alpha = 1
SliderBarSetCurrentPosition("CCTVSettingsSliderBar2",CCTV.Alpha)
end

if CCTV.USE_GENERIC_ICONS == nil then
CCTV.USE_GENERIC_ICONS = true
end



function CCTV.Initialize()

CCTV.COOLDOWN_COLOR = { r = 20, g = 20, b = 20, a = .60 }
Language=SystemData.Settings.Language.active
--because the WORD is indeed the Bird
if Language == 2 then
CCTV.WORD_STAGGERED = L"Chanceler "
CCTV.WORD_KNOCKDOWN = L"Assomer "
CCTV.WORD_SILENCED = L"Silence "
CCTV.WORD_DISARMED = L"D�sarmer "
CCTV.WORD_ROOTED = L"Enraciner "
CCTV.WORD_SNARED = L"Pi�ger "
else
CCTV.WORD_STAGGERED = L"Staggered "
CCTV.WORD_KNOCKDOWN = L"Knocked Down "
CCTV.WORD_SILENCED = L"Silenced "
CCTV.WORD_DISARMED = L"Disarmed "
CCTV.WORD_ROOTED = L"Rooted "
CCTV.WORD_SNARED = L"Snared "
end

	for i=1,27 do
	KDTable[i] = KDID[i]--CCTV.FixString(towstring(GetAbilityName(KDID[i])))
	CCTV.KD_BUFF[KDTable[i]] = false
	CCTV.KD_TIMER[KDTable[i]] = nil
	CCTV.KD_TIMER_MAX[KDTable[i]] = nil
	end
	for i=1,54 do
	SnareTable[i] = SnareID[i] --CCTV.FixString(towstring(GetAbilityName(SnareID[i])))
	CCTV.SNARE_BUFF[SnareTable[i]] = false
	CCTV.SNARE_TIMER[SnareTable[i]] = nil
	CCTV.SNARE_TIMER_MAX[SnareTable[i]] = nil
	end
	for i=1,11 do
	StaggerTable[i] = StaggerID[i] -- CCTV.FixString(towstring(GetAbilityName(StaggerID[i])))
	CCTV.STAGGER_BUFF[StaggerTable[i]] = false
	CCTV.STAGGER_TIMER[StaggerTable[i]] = nil
	CCTV.STAGGER_TIMER_MAX[StaggerTable[i]] = nil
	end	
	for i=1,21 do
	SilenceTable[i] = SilenceID[i] --CCTV.FixString(towstring(GetAbilityName(SilenceID[i])))
	CCTV.SILENCE_BUFF[SilenceTable[i]] = false
	CCTV.SILENCE_TIMER[SilenceTable[i]] = nil
	CCTV.SILENCE_TIMER_MAX[SilenceTable[i]] = nil
	end	
	for i=1,9 do
	DisarmTable[i] = DisarmID[i] --CCTV.FixString(towstring(GetAbilityName(DisarmID[i])))
	CCTV.DISARM_BUFF[DisarmTable[i]] = false
	CCTV.DISARM_TIMER[DisarmTable[i]] = nil
	CCTV.DISARM_TIMER_MAX[DisarmTable[i]] = nil
	end		
	for i=1,17 do
	RootTable[i] = RootID[i]--CCTV.FixString(towstring(GetAbilityName(RootID[i])))
	CCTV.ROOT_BUFF[RootTable[i]] = false
	CCTV.ROOT_TIMER[RootTable[i]] = nil
	CCTV.ROOT_TIMER_MAX[RootTable[i]] = nil	
	end		
	
		RegisterEventHandler(SystemData.Events.PLAYER_IS_UNABLE_TO_MOVE,"CCTV.Movement")
		RegisterEventHandler(SystemData.Events.PLAYER_IS_SILENCED,"CCTV.Cast")	
		RegisterEventHandler(SystemData.Events.PLAYER_IS_DISARMED,"CCTV.Attack")
--		RegisterEventHandler(SystemData.Events.PLAYER_IS_BEING_THROWN,"CCTV.Throw")
		
		
		
--		RegisterEventHandler(SystemData.Events.PLAYER_EFFECTS_UPDATED,"CCTV.Update")		
	
	
	

		LibSlash.RegisterSlashCmd("CCTV", function(input) CCTV.Slash(input) end)	
--Announce that the addon is loaded
	TextLogAddEntry("Chat", 0, L"<icon=57> CCTV v0.5 Loaded." )

--Make the main window/bar

		CreateWindow("CCTVStaggerWindow", true)
		CreateWindow("CCTVRootWindow", true)
		CreateWindow("CCTVSettings", true)	

	DynamicImageSetTexture("CCTVStaggerWindowBorderIcon", "icon004671", 64, 64) 
	DynamicImageSetTexture("CCTVRootWindowBorderIcon", "icon000629", 64, 64) 
			 
	StatusBarSetMaximumValue("CCTVStaggerWindowTimerBarBar", 6  )
    StatusBarSetForegroundTint( "CCTVStaggerWindowTimerBarBar", DefaultColor.GREEN.r, DefaultColor.GREEN.g, DefaultColor.GREEN.b )
    StatusBarSetBackgroundTint( "CCTVStaggerWindowTimerBarBar", DefaultColor.BLACK.r, DefaultColor.BLACK.g, DefaultColor.BLACK.b )
	StatusBarSetCurrentValue("CCTVStaggerWindowTimerBarBar", 6  )

	StatusBarSetMaximumValue("CCTVStaggerWindowBar", 6  )
    StatusBarSetForegroundTint( "CCTVStaggerWindowBar", DefaultColor.GREEN.r, DefaultColor.GREEN.g, DefaultColor.GREEN.b )
    StatusBarSetBackgroundTint( "CCTVStaggerWindowBar", DefaultColor.BLACK.r, DefaultColor.BLACK.g, DefaultColor.BLACK.b )
	StatusBarSetCurrentValue("CCTVStaggerWindowBar", 6  )
	
	StatusBarSetMaximumValue("CCTVRootWindowBar", 10  )
    StatusBarSetForegroundTint( "CCTVRootWindowBar", DefaultColor.GREEN.r, DefaultColor.GREEN.g, DefaultColor.GREEN.b )
    StatusBarSetBackgroundTint( "CCTVRootWindowBar", DefaultColor.BLACK.r, DefaultColor.BLACK.g, DefaultColor.BLACK.b )	
	StatusBarSetCurrentValue("CCTVRootWindowBar", 10  )

	LabelSetText("CCTVStaggerWindowStaggerText",towstring(CCTV.WORD_KNOCKDOWN))
	LabelSetText("CCTVRootWindowRootText",towstring(CCTV.WORD_ROOTED))
	LabelSetText("CCTVRootWindowRootTime",L"10s")
	LabelSetText("CCTVStaggerWindowStaggerTime",L"10s")
	LabelSetText("CCTVStaggerWindowStaggerName",L"Effect Name")
	LabelSetText("CCTVRootWindowRootName",L"Effect Name")
	LabelSetText("CCTVSettingsScaleText",L"Scale")
	LabelSetText("CCTVSettingsAlphaText",L"Alpha")	
	ButtonSetText("CCTVSettingsCloseButton",L"Close")
	LabelSetText("CCTVSettingsIconText",L"Generic CC Icons")
	
	LabelSetTextColor("CCTVStaggerWindowStaggerText",DefaultColor.GOLD.r,DefaultColor.GOLD.g,DefaultColor.GOLD.b)
	LabelSetTextColor("CCTVRootWindowRootText",DefaultColor.GOLD.r,DefaultColor.GOLD.g,DefaultColor.GOLD.b)
	
	
CCTV.Layout = false
CCTV.CanMove = true
CCTV.CanCast = true
CCTV.CanAttack = true

AnimatedImageStartAnimation ("CCTVRootWindowGlow", 0, true, true, 0)
AnimatedImageStartAnimation ("CCTVStaggerWindowGlow", 0, true, true, 0)

SliderBarSetCurrentPosition("CCTVSettingsSliderBar1",CCTV.Scale)
SliderBarSetCurrentPosition("CCTVSettingsSliderBar2",CCTV.Alpha)

DefaultColor.SetWindowTint( "CCTVRootWindowBorderAbilityCooldown", CCTV.COOLDOWN_COLOR )
CooldownDisplaySetCooldown( "CCTVRootWindowBorderAbilityCooldown", 100, 100 )
WindowSetShowing( "CCTVRootWindowBorderAbilityCooldown", true )

DefaultColor.SetWindowTint( "CCTVStaggerWindowBorderAbilityCooldown", CCTV.COOLDOWN_COLOR )
CooldownDisplaySetCooldown( "CCTVStaggerWindowBorderAbilityCooldown", 100, 100 )
WindowSetShowing( "CCTVStaggerWindowBorderAbilityCooldown", true )


end


function CCTV.Movement()
if CCTV.CanMove == true then
CCTV.CanMove = false
else
CCTV.CanMove = true
end
end

function CCTV.Cast()
if CCTV.CanCast == true then
CCTV.CanCast = false
else
CCTV.CanCast = true
end
end

function CCTV.Attack()
if CCTV.CanAttack == true then
CCTV.CanAttack = false
else
CCTV.CanAttack = true
end
end



function CCTV.Update(timeElapsed)

if CCTV.USE_GENERIC_ICONS == true then ButtonSetPressedFlag( "CCTVSettingsCheckBox1",true) else ButtonSetPressedFlag( "CCTVSettingsCheckBox1",false) end


CCTV.Scale = SliderBarGetCurrentPosition("CCTVSettingsSliderBar1")
CCTV.Alpha = SliderBarGetCurrentPosition("CCTVSettingsSliderBar2")

--DefaultColor.SetWindowTint( "CCTVStaggerWindowBorderAbilityCooldown", CCTV.COOLDOWN_COLOR )
--DefaultColor.SetWindowTint( "CCTVRootWindowBorderAbilityCooldown", CCTV.COOLDOWN_COLOR )

WindowSetTintColor( "CCTVStaggerWindowBorderAbilityCooldown", 20,20,20 )
WindowSetTintColor( "CCTVRootWindowBorderAbilityCooldown", 20,20,20 )

LabelSetText("CCTVSettingsScaleText",L"CCTV Scale: "..wstring.format(L"%.01f",(CCTV.Scale)))	
LabelSetText("CCTVSettingsAlphaText",L"BG Alpha: "..wstring.format(L"%.01f",(CCTV.Alpha)))

WindowSetScale("CCTVStaggerWindow",tonumber(CCTV.Scale)+0.1)
WindowSetScale("CCTVRootWindow",WindowGetScale("CCTVStaggerWindow"))

WindowSetAlpha("CCTVStaggerWindowBackground",tonumber(CCTV.Alpha))
WindowSetAlpha("CCTVRootWindowBackground",WindowGetAlpha("CCTVStaggerWindowBackground"))
	
	
if WindowGetShowing("CCTVStaggerWindow") == false then
WindowSetDimensions("CCTVStaggerWindow", 220,64)

WindowClearAnchors( "CCTVRootWindow" )
WindowAddAnchor( "CCTVRootWindow" , "top", "CCTVStaggerWindow", "top",0,0)
else
WindowSetDimensions("CCTVStaggerWindow", 220,64)

WindowClearAnchors( "CCTVRootWindow" )
WindowAddAnchor( "CCTVRootWindow" , "bottom", "CCTVStaggerWindow", "top",0,5)
end

if CCTV.Layout == true then
WindowSetHandleInput("CCTVStaggerWindow",true)
WindowSetShowing("CCTVSettings",true)
WindowSetShowing("CCTVStaggerWindow",true)
WindowSetShowing("CCTVRootWindow",true)
WindowSetAlpha("CCTVStaggerWindow",1)
WindowSetAlpha("CCTVStaggerWindowStaggerText",1)
WindowSetAlpha("CCTVRootWindow",1)
WindowSetAlpha("CCTVRootWindowRootText",1)
else
WindowSetHandleInput("CCTVStaggerWindow",false)
WindowSetHandleInput("CCTVRootWindow",false)
SliderBarSetCurrentPosition("CCTVSettingsSliderBar2",CCTV.Alpha)
SliderBarSetCurrentPosition("CCTVSettingsSliderBar1",CCTV.Scale)
WindowSetShowing("CCTVSettings",false)
WindowSetShowing("CCTVStaggerWindow",false)
WindowSetShowing("CCTVRootWindow",false)
end

local myBuffs = GetBuffs(GameData.BuffTargetType.SELF)
	--if( myBuffs == nil ) then return end

	for myBuffId, myBuff in pairs( myBuffs ) do	
		
	local myCurrentBuff = myBuffs[myBuffId]
	local windowName = "CCTVBuffWnd"..myBuffId


local StaggerText = myCurrentBuff.effectText
local StaggerName = myCurrentBuff.name
local StaggerID = myCurrentBuff.abilityId
local CCTV_IconTEXTURE,CCTV_IconX,CCTV_IconY = GetIconData(myCurrentBuff.iconNum)

CCTV.Red = 255
CCTV.Green = 255
CCTV.Blue = 255

if myCurrentBuff.typeColorRed then
CCTV.Red = myCurrentBuff.typeColorRed
end
if myCurrentBuff.typeColorGreen then
CCTV.Green = myCurrentBuff.typeColorGreen
end
if myCurrentBuff.typeColorBlue then
CCTV.Blue = myCurrentBuff.typeColorBlue
end

--KnockDown
for i=1,27 do
if StaggerID == KDTable[i] and CCTV.CanMove == false  then
if myCurrentBuff.isBuff == false then


if CCTV.KD_TIMER[KDTable[i]] == nil then 
CCTV.KD_TIMER_MAX[KDTable[i]] = (math.ceil(myCurrentBuff.duration))+1
CCTV.KD_TIMER[KDTable[i]] = (math.ceil(myCurrentBuff.duration))+1
elseif CCTV.KD_TIMER[KDTable[i]] >= 0.1 then	
CCTV.KD_TIMER[KDTable[i]] = CCTV.KD_TIMER[KDTable[i]]-timeElapsed	
--WindowStartAlphaAnimation ( "CCTVRootWindow", Window.AnimationType.SINGLE_NO_RESET, 1.0, 0.0, 2.0, false, 0, 0 )
end

CCTV.KD_BUFF[KDTable[i]] = true

WindowSetTintColor("CCTVStaggerWindowBorder", CCTV.Red, CCTV.Green, CCTV.Blue)
WindowSetTintColor("CCTVStaggerWindowBorderIcon", 255, 255, 255)
WindowSetShowing("CCTVStaggerWindow",true)
DynamicImageSetTexture("CCTVStaggerWindowBorderIcon", "icon002643", 64, 64) 
LabelSetText("CCTVStaggerWindowStaggerText",towstring(CCTV.WORD_KNOCKDOWN))
LabelSetText("CCTVStaggerWindowStaggerName",towstring(StaggerName))
LabelSetText("CCTVStaggerWindowStaggerTime",wstring.format(L"%.01f",(CCTV.KD_TIMER[KDTable[i]]))..L"s")
WindowSetTintColor( "CCTVStaggerWindowBorderAbilityCooldown", 20,20,20 )
CooldownDisplaySetCooldown( "CCTVStaggerWindowBorderAbilityCooldown", CCTV.KD_TIMER[KDTable[i]], CCTV.KD_TIMER_MAX[KDTable[i]] )
StatusBarSetMaximumValue("CCTVStaggerWindowBar", CCTV.KD_TIMER_MAX[KDTable[i]])
StatusBarSetCurrentValue("CCTVStaggerWindowBar", CCTV.KD_TIMER[KDTable[i]])
end	
end
end		
--Stagger
for i=1,11 do
if StaggerID == StaggerTable[i] and CCTV.CanMove == false then
if myCurrentBuff.isBuff == false then

if CCTV.STAGGER_TIMER[StaggerTable[i]] == nil then 
CCTV.STAGGER_TIMER_MAX[StaggerTable[i]] = (math.ceil(myCurrentBuff.duration))+1
CCTV.STAGGER_TIMER[StaggerTable[i]] = (math.ceil(myCurrentBuff.duration))+1
elseif CCTV.STAGGER_TIMER[StaggerTable[i]] >= 0.1 then	
CCTV.STAGGER_TIMER[StaggerTable[i]] = CCTV.STAGGER_TIMER[StaggerTable[i]]-timeElapsed	
--WindowStartAlphaAnimation ( "CCTVRootWindow", Window.AnimationType.SINGLE_NO_RESET, 1.0, 0.0, 2.0, false, 0, 0 )
end

CCTV.STAGGER_BUFF[StaggerTable[i]] = true

WindowSetTintColor("CCTVStaggerWindowBorder",  CCTV.Red, CCTV.Green, CCTV.Blue)
WindowSetTintColor("CCTVStaggerWindowBorderIcon", 255, 255, 255)
WindowSetShowing("CCTVStaggerWindow",true)
if CCTV.USE_GENERIC_ICONS == true then DynamicImageSetTexture("CCTVStaggerWindowBorderIcon", "icon004671", 64, 64)  else DynamicImageSetTexture("CCTVStaggerWindowBorderIcon", CCTV_IconTEXTURE, CCTV_IconX, CCTV_IconY) end
LabelSetText("CCTVStaggerWindowStaggerText",towstring(CCTV.WORD_STAGGERED))
LabelSetText("CCTVStaggerWindowStaggerName",towstring(StaggerName))
LabelSetText("CCTVStaggerWindowStaggerTime",wstring.format(L"%.01f",(CCTV.STAGGER_TIMER[StaggerTable[i]]))..L"s")
WindowSetTintColor( "CCTVStaggerWindowBorderAbilityCooldown", 20,20,20 )
CooldownDisplaySetCooldown( "CCTVStaggerWindowBorderAbilityCooldown", CCTV.STAGGER_TIMER[StaggerTable[i]], CCTV.STAGGER_TIMER_MAX[StaggerTable[i]] )
StatusBarSetMaximumValue("CCTVStaggerWindowBar", CCTV.STAGGER_TIMER_MAX[StaggerTable[i]])
StatusBarSetCurrentValue("CCTVStaggerWindowBar", CCTV.STAGGER_TIMER[StaggerTable[i]])

end	
end
end		

--Silence
for i=1,21 do
if StaggerID == SilenceTable[i] and CCTV.CanCast == false then
if myCurrentBuff.isBuff == false then

if CCTV.SILENCE_TIMER[SilenceTable[i]] == nil then 
CCTV.SILENCE_TIMER_MAX[SilenceTable[i]] = (math.ceil(myCurrentBuff.duration))+1
CCTV.SILENCE_TIMER[SilenceTable[i]] = (math.ceil(myCurrentBuff.duration))+1
elseif CCTV.SILENCE_TIMER[SilenceTable[i]] >= 0.1 then	
CCTV.SILENCE_TIMER[SilenceTable[i]] = CCTV.SILENCE_TIMER[SilenceTable[i]]-timeElapsed	
--WindowStartAlphaAnimation ( "CCTVRootWindow", Window.AnimationType.SINGLE_NO_RESET, 1.0, 0.0, 2.0, false, 0, 0 )
end

CCTV.SILENCE_BUFF[SilenceTable[i]] = true


WindowSetTintColor("CCTVStaggerWindowBorder", CCTV.Red, CCTV.Green, CCTV.Blue)
WindowSetTintColor("CCTVStaggerWindowBorderIcon", 255, 255, 255)
WindowSetShowing("CCTVStaggerWindow",true)
if CCTV.USE_GENERIC_ICONS == true then DynamicImageSetTexture("CCTVStaggerWindowBorderIcon", "icon008037", 64, 64)  else DynamicImageSetTexture("CCTVStaggerWindowBorderIcon", CCTV_IconTEXTURE, CCTV_IconX, CCTV_IconY) end
LabelSetText("CCTVStaggerWindowStaggerText",towstring(CCTV.WORD_SILENCED))
LabelSetText("CCTVStaggerWindowStaggerName",towstring(StaggerName))
LabelSetText("CCTVStaggerWindowStaggerTime",wstring.format(L"%.01f",(CCTV.SILENCE_TIMER[SilenceTable[i]]))..L"s")
WindowSetTintColor( "CCTVStaggerWindowBorderAbilityCooldown", 20,20,20 )
CooldownDisplaySetCooldown( "CCTVStaggerWindowBorderAbilityCooldown", CCTV.SILENCE_TIMER[SilenceTable[i]], CCTV.SILENCE_TIMER_MAX[SilenceTable[i]] )
StatusBarSetMaximumValue("CCTVStaggerWindowBar", CCTV.SILENCE_TIMER_MAX[SilenceTable[i]])
StatusBarSetCurrentValue("CCTVStaggerWindowBar", CCTV.SILENCE_TIMER[SilenceTable[i]])
end	
end
end		

--Disarmed
for i=1,9 do
if StaggerID == DisarmTable[i] and CCTV.CanAttack == false then
if myCurrentBuff.isBuff == false then



if CCTV.DISARM_TIMER[DisarmTable[i]] == nil then 
CCTV.DISARM_TIMER_MAX[DisarmTable[i]] = (math.ceil(myCurrentBuff.duration))+1
CCTV.DISARM_TIMER[DisarmTable[i]] = (math.ceil(myCurrentBuff.duration))+1
elseif CCTV.DISARM_TIMER[DisarmTable[i]] >= 0.1 then	
CCTV.DISARM_TIMER[DisarmTable[i]] = CCTV.DISARM_TIMER[DisarmTable[i]]-timeElapsed	
--WindowStartAlphaAnimation ( "CCTVRootWindow", Window.AnimationType.SINGLE_NO_RESET, 1.0, 0.0, 2.0, false, 0, 0 )
end

CCTV.DISARM_BUFF[DisarmTable[i]] = true

WindowSetTintColor("CCTVStaggerWindowBorder", CCTV.Red, CCTV.Green, CCTV.Blue)
WindowSetTintColor("CCTVStaggerWindowBorderIcon", 255, 255, 255)
WindowSetShowing("CCTVStaggerWindow",true)
if CCTV.USE_GENERIC_ICONS == true then DynamicImageSetTexture("CCTVStaggerWindowBorderIcon", "icon002644", 64, 64)  else DynamicImageSetTexture("CCTVStaggerWindowBorderIcon", CCTV_IconTEXTURE, CCTV_IconX, CCTV_IconY) end
LabelSetText("CCTVStaggerWindowStaggerText",towstring(CCTV.WORD_DISARMED))
LabelSetText("CCTVStaggerWindowStaggerName",towstring(StaggerName))
LabelSetText("CCTVStaggerWindowStaggerTime",wstring.format(L"%.01f",(CCTV.DISARM_TIMER[DisarmTable[i]]))..L"s")
WindowSetTintColor( "CCTVStaggerWindowBorderAbilityCooldown", 20,20,20 )
CooldownDisplaySetCooldown( "CCTVStaggerWindowBorderAbilityCooldown", CCTV.DISARM_TIMER[DisarmTable[i]], CCTV.DISARM_TIMER_MAX[DisarmTable[i]] )
StatusBarSetMaximumValue("CCTVStaggerWindowBar", CCTV.DISARM_TIMER_MAX[DisarmTable[i]])
StatusBarSetCurrentValue("CCTVStaggerWindowBar", CCTV.DISARM_TIMER[DisarmTable[i]])
end	
end
end		
--Snared
for i=1,54 do

if StaggerID == SnareTable[i] then
if myCurrentBuff.isBuff == false or SnareTable[7] then
_,RedSpeed = StaggerText:match(L"([^%.]+) (%d+)/%")
if RedSpeed == "" or RedSpeed == nil then
RedSpeed = 40
end

if CCTV.SNARE_TIMER[SnareTable[i]] == nil then 
CCTV.SNARE_TIMER_MAX[SnareTable[i]] = (math.ceil(myCurrentBuff.duration))+1
CCTV.SNARE_TIMER[SnareTable[i]] = (math.ceil(myCurrentBuff.duration))+1
elseif CCTV.SNARE_TIMER[SnareTable[i]] >= 0.1 then	
CCTV.SNARE_TIMER[SnareTable[i]] = CCTV.SNARE_TIMER[SnareTable[i]]-timeElapsed	
--WindowStartAlphaAnimation ( "CCTVRootWindow", Window.AnimationType.SINGLE_NO_RESET, 1.0, 0.0, 2.0, false, 0, 0 )
end

CCTV.SNARE_BUFF[SnareTable[i]] = true

WindowSetTintColor("CCTVRootWindowBorder",  CCTV.Red, CCTV.Green, CCTV.Blue)
WindowSetTintColor("CCTVRootWindowBorderIcon", 255, 255, 255)
WindowSetShowing("CCTVRootWindow",true)
WindowSetShowing("CCTVRootWindowRootText",true)
if CCTV.USE_GENERIC_ICONS == true then DynamicImageSetTexture("CCTVRootWindowBorderIcon", "icon002410", 64, 64) else DynamicImageSetTexture("CCTVRootWindowBorderIcon", CCTV_IconTEXTURE, CCTV_IconX, CCTV_IconY) end
LabelSetText("CCTVRootWindowRootText",towstring(CCTV.WORD_SNARED)..towstring(RedSpeed)..L"% ")
LabelSetText("CCTVRootWindowRootName",towstring(StaggerName))
LabelSetText("CCTVRootWindowRootTime",wstring.format(L"%.01f",(CCTV.SNARE_TIMER[SnareTable[i]]))..L"s")
WindowSetTintColor( "CCTVRootWindowBorderAbilityCooldown",20,20,20 )
CooldownDisplaySetCooldown( "CCTVRootWindowBorderAbilityCooldown", CCTV.SNARE_TIMER[SnareTable[i]], CCTV.SNARE_TIMER_MAX[SnareTable[i]] )
StatusBarSetMaximumValue("CCTVRootWindowBar", CCTV.SNARE_TIMER_MAX[SnareTable[i]])
StatusBarSetCurrentValue("CCTVRootWindowBar", CCTV.SNARE_TIMER[SnareTable[i]])
end	
end
end		

--Rooted
for i=1,17 do
if (StaggerID == RootTable[i] and CCTV.CanMove == false) or (StaggerID == RootTable[17]) then --exeption with Wind of insanity
if myCurrentBuff.isBuff == false or RootTable[17] then


if CCTV.ROOT_TIMER[RootTable[i]] == nil then 
CCTV.ROOT_TIMER_MAX[RootTable[i]] = (math.ceil(myCurrentBuff.duration))+1
CCTV.ROOT_TIMER[RootTable[i]] = (math.ceil(myCurrentBuff.duration))+1
elseif CCTV.ROOT_TIMER[RootTable[i]] >= 0.1 then
CCTV.ROOT_TIMER[RootTable[i]] = CCTV.ROOT_TIMER[RootTable[i]]-timeElapsed	
end

CCTV.ROOT_BUFF[RootTable[i]] = true

WindowSetTintColor("CCTVRootWindowBorder",  CCTV.Red, CCTV.Green, CCTV.Blue)
WindowSetTintColor("CCTVRootWindowBorderIcon", 255, 255, 255)
WindowSetShowing("CCTVRootWindow",true)
if CCTV.USE_GENERIC_ICONS == true then DynamicImageSetTexture("CCTVRootWindowBorderIcon", "icon000629", 64, 64) else DynamicImageSetTexture("CCTVRootWindowBorderIcon", CCTV_IconTEXTURE, CCTV_IconX, CCTV_IconY) end
LabelSetText("CCTVRootWindowRootText",towstring(CCTV.WORD_ROOTED))
LabelSetText("CCTVRootWindowRootName",towstring(StaggerName))
LabelSetText("CCTVRootWindowRootTime",wstring.format(L"%.01f",(CCTV.ROOT_TIMER[RootTable[i]]))..L"s")
WindowSetTintColor( "CCTVRootWindowBorderAbilityCooldown",20,20,20 )
CooldownDisplaySetCooldown( "CCTVRootWindowBorderAbilityCooldown", CCTV.ROOT_TIMER[RootTable[i]], CCTV.ROOT_TIMER_MAX[RootTable[i]])
StatusBarSetMaximumValue("CCTVRootWindowBar", CCTV.ROOT_TIMER_MAX[RootTable[i]])
StatusBarSetCurrentValue("CCTVRootWindowBar", CCTV.ROOT_TIMER[RootTable[i]])
end	
end
end		



end -- end of the buff search


for i=1,27 do
if WindowGetShowing("CCTVStaggerWindow") == false or CCTV.KD_BUFF[KDTable[i]] == false then
CCTV.KD_TIMER[KDTable[i]] = nil
CCTV.KD_TIMER_MAX[KDTable[i]] = nil
elseif CCTV.KD_BUFF[KDTable[i]] == true then
CCTV.KD_BUFF[KDTable[i]] = false
end
end

for i=1,21 do
if WindowGetShowing("CCTVStaggerWindow") == false or CCTV.SILENCE_BUFF[SilenceTable[i]] == false then
CCTV.SILENCE_TIMER[SilenceTable[i]] = nil
CCTV.SILENCE_TIMER_MAX[SilenceTable[i]] = nil
elseif CCTV.SILENCE_BUFF[SilenceTable[i]] == true then
CCTV.SILENCE_BUFF[SilenceTable[i]] = false
end
end

for i=1,9 do
if WindowGetShowing("CCTVStaggerWindow") == false or CCTV.DISARM_BUFF[DisarmTable[i]] == false then
CCTV.DISARM_TIMER[DisarmTable[i]] = nil
CCTV.DISARM_TIMER_MAX[DisarmTable[i]] = nil
elseif CCTV.DISARM_BUFF[DisarmTable[i]] == true then
CCTV.DISARM_BUFF[DisarmTable[i]] = false
end
end


for i=1,11 do
if WindowGetShowing("CCTVStaggerWindow") == false or CCTV.STAGGER_BUFF[StaggerTable[i]] == false then
CCTV.STAGGER_TIMER[StaggerTable[i]] = nil
CCTV.STAGGER_TIMER_MAX[StaggerTable[i]] = nil
elseif CCTV.STAGGER_BUFF[StaggerTable[i]] == true then
CCTV.STAGGER_BUFF[StaggerTable[i]] = false
end
end


for i=1,54 do
if WindowGetShowing("CCTVRootWindow") == false or CCTV.SNARE_BUFF[SnareTable[i]] == false then
CCTV.SNARE_TIMER[SnareTable[i]] = nil
CCTV.SNARE_TIMER_MAX[SnareTable[i]] = nil
elseif CCTV.SNARE_BUFF[SnareTable[i]] == true then
CCTV.SNARE_BUFF[SnareTable[i]] = false
end
end

for i=1,17 do
if WindowGetShowing("CCTVRootWindow") == false or CCTV.ROOT_BUFF[RootTable[i]] == false then
CCTV.ROOT_TIMER[RootTable[i]] = nil
CCTV.ROOT_TIMER_MAX[RootTable[i]] = nil
elseif CCTV.ROOT_BUFF[RootTable[i]] == true then
CCTV.ROOT_BUFF[RootTable[i]] = false
end
end


end

function CCTV.FixString (str)

	if (str == nil) then return nil end

	local str = str
	local pos = str:find (L"^", 1, true)
	if (pos) then str = str:sub (1, pos - 1) end
	
	return str
end


function CCTV.Slash(input)
if (input == "") then
	 if CCTV.Layout == false then
	 CCTV.Layout = true
	 elseif CCTV.Layout == true then
	 CCTV.Layout = false
	 end
end
end

function CCTV.Close()
 CCTV.Layout = false	
end


function CCTV.ICONCHANGE()
local tabNumber	= WindowGetId (SystemData.ActiveWindow.name)
	if(tabNumber == 1) then 
	if CCTV.USE_GENERIC_ICONS == false then 
		TextLogAddEntry("Chat", 0, L"CCTV: Use Generic CC Icons")	
		CCTV.USE_GENERIC_ICONS = true
	else
		CCTV.USE_GENERIC_ICONS = false 
		TextLogAddEntry("Chat", 0, L"CCTV: Use Ability Effect Icons")
	end

end
end

    
