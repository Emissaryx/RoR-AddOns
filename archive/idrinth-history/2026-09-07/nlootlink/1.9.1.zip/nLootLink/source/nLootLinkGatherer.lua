nLootLinkGatherer = {}

-- local variables
local doDebug = false


--
-- initialisation functions
--

-- initialise function for nLootLinkGatherer
function nLootLinkGatherer.init()
	doDebug = nLootLink.DEBUG
	if doDebug then d("nLootLinkGatherer.init START") end

	nLootLinkGatherer.initEvents()
	nLootLinkGatherer.initHooks()

	-- update items we can see now
	nLootLinkGatherer.scanBags()
	nLootLinkGatherer.scanEquipment()
	nLootLinkGatherer.scanArmory()

	if doDebug then d("nLootLinkGatherer.init END") end
end

-- register for events
function nLootLinkGatherer.initEvents()
	RegisterEventHandler(SystemData.Events.PLAYER_INVENTORY_SLOT_UPDATED, "nLootLinkGatherer.PLAYER_INVENTORY_SLOT_UPDATED")
	RegisterEventHandler(SystemData.Events.PLAYER_CRAFTING_SLOT_UPDATED, "nLootLinkGatherer.PLAYER_CRAFTING_SLOT_UPDATED")
	RegisterEventHandler(SystemData.Events.PLAYER_CURRENCY_SLOT_UPDATED, "nLootLinkGatherer.PLAYER_CURRENCY_SLOT_UPDATED")
    RegisterEventHandler(SystemData.Events.PLAYER_EQUIPMENT_SLOT_UPDATED, "nLootLinkGatherer.PLAYER_EQUIPMENT_SLOT_UPDATED")
    RegisterEventHandler(SystemData.Events.PLAYER_TROPHY_SLOT_UPDATED, "nLootLinkGatherer.PLAYER_TROPHY_SLOT_UPDATED")
    RegisterEventHandler(SystemData.Events.SOCIAL_INSPECTION_UPDATED, "nLootLinkGatherer.SOCIAL_INSPECTION_UPDATED")
    RegisterEventHandler(SystemData.Events.AUCTION_SEARCH_RESULT_RECEIVED, "nLootLinkGatherer.AUCTION_SEARCH_RESULT_RECEIVED")
    RegisterEventHandler(SystemData.Events.PLAYER_BANK_SLOT_UPDATED, "nLootLinkGatherer.PLAYER_BANK_SLOT_UPDATED")
    RegisterEventHandler(SystemData.Events.INTERACT_GUILD_VAULT_OPEN, "nLootLinkGatherer.INTERACT_GUILD_VAULT_OPEN")
    RegisterEventHandler(SystemData.Events.INTERACT_SHOW_QUEST, "nLootLinkGatherer.INTERACT_SHOW_QUEST")
    RegisterEventHandler(SystemData.Events.INTERACT_SHOW_STORE, "nLootLinkGatherer.INTERACT_SHOW_STORE")
    RegisterEventHandler(SystemData.Events.INTERACT_SHOW_LOOT, "nLootLinkGatherer.INTERACT_SHOW_LOOT")
    RegisterEventHandler(SystemData.Events.INTERACT_SHOW_LOOT_ROLL_DATA, "nLootLinkGatherer.INTERACT_SHOW_LOOT_ROLL_DATA")
    RegisterEventHandler(SystemData.Events.PLAYER_OFFER_ITEMS_UPDATED, "nLootLinkGatherer.PLAYER_OFFER_ITEMS_UPDATED")
    RegisterEventHandler(SystemData.Events.TOME_OLD_WORLD_ARMORY_TOC_UPDATED, "nLootLinkGatherer.TOME_OLD_WORLD_ARMORY_TOC_UPDATED")
end

-- hook external functions
function nLootLinkGatherer.initHooks()
	nLootLinkGatherer.hooked = {}

	nLootLinkGatherer.hooked.TomeWindow_UpdateActiveWarstoryEntryRewards = TomeWindow.UpdateActiveWarstoryEntryRewards
	TomeWindow.UpdateActiveWarstoryEntryRewards = nLootLinkGatherer.TomeWindow_UpdateActiveWarstoryEntryRewards

	nLootLinkGatherer.hooked.TomeWindow_SelectQuest = TomeWindow.SelectQuest
	TomeWindow.SelectQuest = nLootLinkGatherer.TomeWindow_SelectQuest

	nLootLinkGatherer.hooked.TomeWindow_OpenToQuest = TomeWindow.OpenToQuest
	TomeWindow.OpenToQuest = nLootLinkGatherer.TomeWindow_OpenToQuest
end


--
-- events
--

-- bag item updated
function nLootLinkGatherer.PLAYER_INVENTORY_SLOT_UPDATED(updatedSlots)
	if doDebug then d("nLootLinkGatherer.PLAYER_INVENTORY_SLOT_UPDATED START") end

	local itemData
	local bagList = DataUtils.GetItems()

	-- process all updated slots
	for _, slot in pairs(updatedSlots) do
		if slot ~= 0 then
			nLootLinkData.upsertItem(bagList[slot])
		end
	end

	if doDebug then d("nLootLinkGatherer.PLAYER_INVENTORY_SLOT_UPDATED END") end
end

-- crafting item updated
function nLootLinkGatherer.PLAYER_CRAFTING_SLOT_UPDATED(updatedSlots)
	if doDebug then d("nLootLinkGatherer.PLAYER_CRAFTING_SLOT_UPDATED START") end

	local itemData
	local bagList = DataUtils.GetCraftingItems()

	-- process all updated slots
	for _, slot in pairs(updatedSlots) do
		if slot ~= 0 then
			nLootLinkData.upsertItem(bagList[slot])
		end
	end

	if doDebug then d("nLootLinkGatherer.PLAYER_CRAFTING_SLOT_UPDATED END") end
end

-- currency item updated
function nLootLinkGatherer.PLAYER_CURRENCY_SLOT_UPDATED(updatedSlots)
	if doDebug then d("nLootLinkGatherer.PLAYER_CURRENCY_SLOT_UPDATED START") end

	local itemData
	local bagList = DataUtils.GetCurrencyItems()

	-- process all updated slots
	for _, slot in pairs(updatedSlots) do
		if slot ~= 0 then
			nLootLinkData.upsertItem(bagList[slot])
		end
	end

	if doDebug then d("nLootLinkGatherer.PLAYER_CURRENCY_SLOT_UPDATED END") end
end

-- equipped item updated
function nLootLinkGatherer.PLAYER_EQUIPMENT_SLOT_UPDATED(updatedSlots)
	if doDebug then d("nLootLinkGatherer.PLAYER_EQUIPMENT_SLOT_UPDATED START") end

	local itemData
	local equipmentList = DataUtils.GetEquipmentData()

	-- process all updated slots
	for _, slot in pairs(updatedSlots) do
		if slot ~= 0 then
			nLootLinkData.upsertItem(equipmentList[slot])
		end
	end

	if doDebug then d("nLootLinkGatherer.PLAYER_EQUIPMENT_SLOT_UPDATED END") end
end

-- equipped trophy updated
function nLootLinkGatherer.PLAYER_TROPHY_SLOT_UPDATED(updatedSlots)
	if doDebug then d("nLootLinkGatherer.PLAYER_TROPHY_SLOT_UPDATED START") end

	local itemData
	local equipmentList = DataUtils.GetTrophyData()

	-- process all updated slots
	for _, slot in pairs(updatedSlots) do
		if slot ~= 0 then
			nLootLinkData.upsertItem(equipmentList[slot])
		end
	end

	if doDebug then d("nLootLinkGatherer.PLAYER_TROPHY_SLOT_UPDATED END") end
end

-- inspecting a character
function nLootLinkGatherer.SOCIAL_INSPECTION_UPDATED()

	local inspectionData = GetInspectionData()

	-- add every item that the player is showing
	for _, itemData in pairs(inspectionData) do
		nLootLinkData.upsertItem(itemData)
	end
end

-- auction search completed
function nLootLinkGatherer.AUCTION_SEARCH_RESULT_RECEIVED(searchResultsTable)

	-- add all results
	if searchResultsTable then
		for _, result in pairs(searchResultsTable) do
			if result.itemData then
				nLootLinkData.upsertItem(result.itemData)
			end
		end
	end
end

-- bank item updated / added
function nLootLinkGatherer.PLAYER_BANK_SLOT_UPDATED(updatedSlots)

	local itemData
	local bankList = DataUtils.GetBankData()

	-- process all updated slots
	for _, slot in pairs(updatedSlots) do
		if slot ~= 0 then
			nLootLinkData.upsertItem(bankList[slot])
		end
	end
end

-- vault item updated / added
function nLootLinkGatherer.INTERACT_GUILD_VAULT_OPEN(vaultDataTable)
	if doDebug then d("nLootLinkGatherer.INTERACT_GUILD_VAULT_OPEN START") end

	if vaultDataTable then
		for _, vaultTab in pairs(vaultDataTable) do
			if type(vaultTab) == "table" and vaultTab.itemsAttached then
				for _, itemData in pairs(vaultTab.itemsAttached) do
					nLootLinkData.upsertItem(itemData)
				end
			end
		end
	end

	if doDebug then d("nLootLinkGatherer.INTERACT_GUILD_VAULT_OPEN END") end
end

-- quest giver conversation
function nLootLinkGatherer.INTERACT_SHOW_QUEST()
	if doDebug then d("nLootLinkGatherer.INTERACT_SHOW_QUEST START") end

	-- choice rewards
	local rewards = GetChoiceRewardsData()
	if rewards and type(rewards) == "table" then
		for _, itemData in pairs(rewards) do
			nLootLinkData.upsertItem(itemData)
		end
	end

	-- given rewards
	rewards = GetGivenRewardsData()
	if rewards and type(rewards) == "table" then
		for _, itemData in pairs(rewards) do
			nLootLinkData.upsertItem(itemData)
		end
	end

	if doDebug then d("nLootLinkGatherer.INTERACT_SHOW_QUEST END") end
end

-- merchant
function nLootLinkGatherer.INTERACT_SHOW_STORE()
	if doDebug then d("nLootLinkGatherer.INTERACT_SHOW_STORE START") end
	
	local storeData = GetStoreData()

	for _, itemData in pairs(storeData) do
		if type(itemData) == "table" then
			nLootLinkData.upsertItem(itemData)
		end
	end

	if doDebug then d("nLootLinkGatherer.INTERACT_SHOW_STORE END") end
end

-- loot (normal)
function nLootLinkGatherer.INTERACT_SHOW_LOOT()
	if doDebug then d("nLootLinkGatherer.INTERACT_SHOW_LOOT START") end

	local lootData = GameData.InteractData.GetLootList()

	for _, itemData in pairs(lootData) do
		if type(itemData) == "table" then
			nLootLinkData.upsertItem(itemData)
		end
	end

	if doDebug then d("nLootLinkGatherer.INTERACT_SHOW_LOOT END") end
end

-- loot (roll)
function nLootLinkGatherer.INTERACT_SHOW_LOOT_ROLL_DATA()
	if doDebug then d("nLootLinkGatherer.INTERACT_SHOW_LOOT_ROLL_DATA START") end

	local lootData = GetLootRollData()

	for _, lootRollData in pairs(lootData) do
		if type(lootRollData) == "table" and type(lootRollData.itemData) == "table" then
			nLootLinkData.upsertItem(lootRollData.itemData)
		end
	end

	if doDebug then d("nLootLinkGatherer.INTERACT_SHOW_LOOT_ROLL_DATA END") end
end

-- trade items updated from other player
function nLootLinkGatherer.PLAYER_OFFER_ITEMS_UPDATED()
	if doDebug then d("nLootLinkGatherer.PLAYER_OFFER_ITEMS_UPDATED START") end

	local tradeData = GetTradeItemData(EA_Window_Trade.OTHER_OFFER_UPDATED)

	for _, itemData in pairs(tradeData) do
		nLootLinkData.upsertItem(itemData)
	end

	if doDebug then d("nLootLinkGatherer.PLAYER_OFFER_ITEMS_UPDATED END") end
end

-- armory sets updated
function nLootLinkGatherer.TOME_OLD_WORLD_ARMORY_TOC_UPDATED()
	if doDebug then d("nLootLinkGatherer.TOME_OLD_WORLD_ARMORY_TOC_UPDATED START") end

	nLootLinkGatherer.scanArmory()

	if doDebug then d("nLootLinkGatherer.TOME_OLD_WORLD_ARMORY_TOC_UPDATED END") end
end


--
-- hooked functions
--

-- tome opened to PQ chapter
function nLootLinkGatherer.TomeWindow_UpdateActiveWarstoryEntryRewards(...)
	if doDebug then d("nLootLinkGatherer.TomeWindow_UpdateActiveWarstoryEntryRewards START") end
	nLootLinkGatherer.hooked.TomeWindow_UpdateActiveWarstoryEntryRewards(...)

	if TomeWindow.WarJournal and TomeWindow.WarJournal.CurEntryData then
		local influenceRewards = GameData.GetInfluenceRewards(TomeWindow.WarJournal.CurEntryData.influenceId)
		if influenceRewards then
			for level, rewards in pairs(influenceRewards) do
				if type(rewards) == "table" then
					for _, itemData in pairs(rewards) do
						nLootLinkData.upsertItem(itemData)
					end
				end
			end
		end
	end

	if doDebug then d("nLootLinkGatherer.TomeWindow_UpdateActiveWarstoryEntryRewards END") end
end

-- tome opened to quest
function nLootLinkGatherer.TomeWindow_SelectQuest(...)
	if doDebug then d("nLootLinkGatherer.TomeWindow_SelectQuest START") end
	nLootLinkGatherer.hooked.TomeWindow_SelectQuest(...)

	nLootLinkGatherer.scanQuestRewards()

	if doDebug then d("nLootLinkGatherer.TomeWindow_SelectQuest END") end
end

-- quest opened via tracker
function nLootLinkGatherer.TomeWindow_OpenToQuest(...)
	if doDebug then d("nLootLinkGatherer.TomeWindow_OpenToQuest START") end
	nLootLinkGatherer.hooked.TomeWindow_OpenToQuest(...)

	nLootLinkGatherer.scanQuestRewards()

	if doDebug then d("nLootLinkGatherer.TomeWindow_OpenToQuest END") end
end



--
-- utility functions
--

-- scan all bag items and add them to the database
function nLootLinkGatherer.scanBags()
	if doDebug then d("nLootLinkGatherer.scanBags START") end
	
	nLootLinkGatherer.scanBagType(EA_Window_Backpack.TYPE_INVENTORY, nLootLinkGatherer.PLAYER_INVENTORY_SLOT_UPDATED)
	nLootLinkGatherer.scanBagType(EA_Window_Backpack.TYPE_CRAFTING, nLootLinkGatherer.PLAYER_CRAFTING_SLOT_UPDATED)
	nLootLinkGatherer.scanBagType(EA_Window_Backpack.TYPE_CURRENCY, nLootLinkGatherer.PLAYER_CURRENCY_SLOT_UPDATED)

	if doDebug then d("nLootLinkGatherer.scanBags END") end
end

-- scan bag items of a particular type
function nLootLinkGatherer.scanBagType(type, callback)
	if doDebug then d("nLootLinkGatherer.scanBagType START type="..tostring(type)) end

	local updatedSlots = {}

	-- build a list of all slots
	for slot = 1, EA_Window_Backpack.numberOfSlots[type] do
		table.insert(updatedSlots, slot)
	end

	-- call the update method on all slots
	callback(updatedSlots)
	if doDebug then d("nLootLinkGatherer.scanBagType END") end
end

-- scan all equipped items and add them to the database
function nLootLinkGatherer.scanEquipment()
	if doDebug then d("nLootLinkGatherer.scanEquipment START") end

	local updatedSlots = {}

	-- build a list of all slots
	for slot = 1, 20 + GameData.Player.c_NUM_TROPHIES do
		table.insert(updatedSlots, slot)
	end

	-- call the update method on all slots
	nLootLinkGatherer.PLAYER_EQUIPMENT_SLOT_UPDATED(updatedSlots)

	if doDebug then d("nLootLinkGatherer.scanEquipment END") end
end

-- scan armor sets that are unlocked by this toon
function nLootLinkGatherer.scanArmory()
	if doDebug then d("nLootLinkGatherer.scanArmory START") end

	local armorSet

	local tocData = TomeGetOldWorldArmoryTOC()

	for _, setData in pairs(tocData) do
		armorSet = TomeGetOldWorldArmoryArmorSet(setData.id)
		if armorSet and armorSet.pieces then
			for _, piece in pairs(armorSet.pieces) do
				if piece.itemData then
					nLootLinkData.upsertItem(piece.itemData)
				end
			end
		end
	end

	if doDebug then d("nLootLinkGatherer.scanArmory END") end
end

-- get the quest rewards
function nLootLinkGatherer.scanQuestRewards()
	if TomeWindow.QuestJournal then
		if TomeWindow.QuestJournal.visibleQuestRewardItems then
			if TomeWindow.QuestJournal.visibleQuestRewardItems.given then
				for _, itemData in pairs(TomeWindow.QuestJournal.visibleQuestRewardItems.given) do
					nLootLinkData.upsertItem(itemData)
				end
			end
			if TomeWindow.QuestJournal.visibleQuestRewardItems.choice then
				for _, itemData in pairs(TomeWindow.QuestJournal.visibleQuestRewardItems.choice) do
					nLootLinkData.upsertItem(itemData)
				end
			end			
		end
	end
end
