nLootLinkOptions = {}

-- libraries
local T = LibStub("WAR-AceLocale-3.0"):GetLocale("nLootLink")

-- local member aliases
local optionDB = false

-- constants
local WINDOW_NAME = "nLootLinkOptions"
local WINDOW_TITLE = T["nLootLink Options"]

-- local variables
local doDebug = false
local choiceRarity = {}


--
-- initialisation functions
--

-- initialise the entire GUI; assumes nLootLinkOptions.initDB already called
function nLootLinkOptions.init()
	doDebug = nLootLink.DEBUG
	if doDebug then d("nLootLinkOptions.init START") end

	nLootLinkOptions.initWindow()
	nLootLinkOptions.initLabels()
	nLootLinkOptions.initCombos()

	ButtonSetPressedFlag("nLootLinkOptionsCheckBagButtonButton", optionDB.bagButton)
	ButtonSetPressedFlag("nLootLinkOptionsCheckCharButtonButton", optionDB.charButton)
	ButtonSetPressedFlag("nLootLinkOptionsCheckPrintNewButton", optionDB.printNew)

	nLootLinkOptions.apply()

	if doDebug then d("nLootLinkOptions.init END") end
end

-- initialise the options DB
function nLootLinkOptions.initDB()

	-- create the DB
	if not nLootLinkData.optionDB then
		nLootLinkData.optionDB = {}
	end
	optionDB = nLootLinkData.optionDB

	-- set defaults or load the options
	if type(optionDB.minRarity) ~= "number" then
		optionDB.minRarity = nLootLink.DEFAULT_MIN_RARITY
	end
	if type(optionDB.bagButton) ~= "boolean" then
		optionDB.bagButton = false
	end
	if type(optionDB.charButton) ~= "boolean" then
		optionDB.charButton = false
	end
	if type(optionDB.printNew) ~= "boolean" then
		optionDB.printNew = true
	end
end

-- initialise the options window
function nLootLinkOptions.initWindow()

	-- create the window, but don't show it
	CreateWindow(WINDOW_NAME, false)
	WindowSetMovable(WINDOW_NAME, true)
	LabelSetText(WINDOW_NAME.."TitleBarText", WINDOW_TITLE)
end

-- create any static labels
function nLootLinkOptions.initLabels()
	LabelSetText(WINDOW_NAME.."LabelVersion", towstring(nLootLink.VERSION))
	LabelSetText(WINDOW_NAME.."CheckBagButtonLabel", T["Show backpack button"])
	LabelSetText(WINDOW_NAME.."CheckCharButtonLabel", T["Show character screen button"])
	LabelSetText(WINDOW_NAME.."CheckPrintNewLabel", T["Print new items to chat"])
	LabelSetText(WINDOW_NAME.."LabelRarity", T["Minimum Rarity"])
	LabelSetText(WINDOW_NAME.."CheckRarityConfirmLabel", T["Yes, I want to change the rarity threshold. On checking this box, the UI will reload and any items lower than the rarity above will be lost."])
	WindowSetShowing(WINDOW_NAME.."CheckRarityConfirm", false)
end

-- fill the combos
function nLootLinkOptions.initCombos()

	-- load all rarity choices
	choiceRarity = {}
	for _, rarity in pairs(SystemData.ItemRarity) do
		table.insert(choiceRarity, { text = GameDefs.ItemRarity[rarity].desc, value = rarity, isSelected = nil, })
	end
	table.sort(choiceRarity, function(a, b) return a.value < b.value end)
	nLootLinkUtil.setComboBoxChoices(WINDOW_NAME.."ComboRarity", choiceRarity)

	-- set the rarity to the currently selected minimum
	for comboIndex, data in ipairs(choiceRarity) do
		if data.value == optionDB.minRarity then
			ComboBoxSetSelectedMenuItem(WINDOW_NAME.."ComboRarity", comboIndex)
			break
		end
	end
end


--
-- accessors
--
function nLootLinkOptions.getBagButton()
	return optionDB.bagButton
end

function nLootLinkOptions.getCharButton()
	return optionDB.charButton
end

function nLootLinkOptions.getPrintNew()
	return optionDB.printNew
end

function nLootLinkOptions.getMinRarity()
	return optionDB.minRarity
end


--
-- GUI event functions
--

-- toggle loot link window visibility
function nLootLinkOptions.toggleShowing()
	WindowUtils.ToggleShowing(WINDOW_NAME)
end

-- window shown
function nLootLinkOptions.onShown()
	WindowUtils.OnShown(function() end, WindowUtils.Cascade.MODE_AUTOMATIC)
end

-- window hidden
function nLootLinkOptions.onHidden()
	WindowUtils.OnHidden()
end

-- right click on window
function nLootLinkOptions.onRButtonUp()
	EA_Window_ContextMenu.CreateDefaultContextMenu(WINDOW_NAME)
end

-- bag button check box changed
function nLootLinkOptions.onToggleBagButton()
	EA_LabelCheckButton.Toggle()
	optionDB.bagButton = ButtonGetPressedFlag("nLootLinkOptionsCheckBagButtonButton")
	nLootLinkOptions.apply()
end

-- char button check box changed
function nLootLinkOptions.onToggleCharButton()
	EA_LabelCheckButton.Toggle()
	optionDB.charButton = ButtonGetPressedFlag("nLootLinkOptionsCheckCharButtonButton")
	nLootLinkOptions.apply()
end

-- print new check box changed
function nLootLinkOptions.onTogglePrintNew()
	EA_LabelCheckButton.Toggle()
	optionDB.printNew = ButtonGetPressedFlag("nLootLinkOptionsCheckPrintNewButton")
end

-- rarity changed
function nLootLinkOptions.onRaritySelected(choiceIndex)
	if choiceRarity[choiceIndex] and choiceRarity[choiceIndex].value ~= optionDB.minRarity then
		WindowSetShowing(WINDOW_NAME.."CheckRarityConfirm", true)
	else
		WindowSetShowing(WINDOW_NAME.."CheckRarityConfirm", false)
	end
end

-- rarity warning ticked
function nLootLinkOptions.onToggleRarityConfirm()
	local choiceIndex = ComboBoxGetSelectedMenuItem(WINDOW_NAME.."ComboRarity")

	if choiceIndex and choiceRarity[choiceIndex] and choiceRarity[choiceIndex].value then
		optionDB.minRarity = choiceRarity[choiceIndex].value
		InterfaceCore.ReloadUI()
	end
end


--
-- private functions
--

-- apply the options to the other nLootLink components
function nLootLinkOptions.apply()

	nLootLinkGUIIntegration.bagButton(optionDB.bagButton)
	nLootLinkGUIIntegration.charButton(optionDB.charButton)
end
