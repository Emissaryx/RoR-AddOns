nLootLink = {}

-- version and revision
nLootLink.VERSION = "nLootLink 1.9"
if nLootLink.VERSION == "@".."project-version".."@" then
	nLootLink.VERSION = "1.5-devel"
end
nLootLink.VERSION_MAJOR = tonumber(nLootLink.VERSION:match("^(%d+)%."))
nLootLink.VERSION_MINOR = tonumber(nLootLink.VERSION:match("^%d+%.(%d+)"))
nLootLink.VERSION_POINT = tonumber(nLootLink.VERSION:match("^%d+%.%d+%.(%d+)"))
nLootLink.QUALITY = nLootLink.VERSION:match("-(.+)$")
nLootLink.DEBUG = nLootLink.QUALITY == "devel"

-- libraries
local T = LibStub("WAR-AceLocale-3.0"):GetLocale("nLootLink")


nLootLink.SLASH_TOGGLE = {
	L"^/ll",
	L"^/nll",
	L"^/lootlink",
	L"^/nlootlink",
}

-- sometimes the auction house returns weird items with large IDs - ignore those
nLootLink.MAX_UNIQUE_ID = 2000000

nLootLink.DEFAULT_MIN_RARITY = SystemData.ItemRarity.UTILITY

nLootLink.ITEMS_PER_UPDATE = 25

nLootLink.WINDOW_NAME = "nLootLinkGUI"
nLootLink.WINDOW_TITLE = L"nLootLink"

nLootLink.CHOICE_ANY_VALUE = 0

nLootLink.DEFAULT_FIELDS = {
	type = true,
	slot = true,
	stat = true,
	career = true,
	usable = true,
	setItem = true,
	rank = true,
	renown = true,
}

nLootLink.CATEGORIES = {
	{
		name = T["Weapons"],
		types = {
			GameData.ItemTypes.AXE,
			GameData.ItemTypes.BOW,
			GameData.ItemTypes.DAGGER,
			GameData.ItemTypes.GUN,
			GameData.ItemTypes.HAMMER,
			GameData.ItemTypes.PISTOL,
			GameData.ItemTypes.SPEAR,
			GameData.ItemTypes.STAFF,
			GameData.ItemTypes.SWORD,
		},
		typeText = T["Any Weapon Type"],
		slots = {
		                    GameData.EquipSlots.RIGHT_HAND,
												GameData.EquipSlots.EITHER_HAND,
		                    GameData.EquipSlots.LEFT_HAND,
		                    GameData.EquipSlots.RANGED,
										},
		slotText = T["Any Weapon Slot"],
		fields = {
			type = true,
			slot = true,
			stat = true,
			career = true,
			usable = true,
			rank = true,
			renown = true,
		},
		sorts = {
			name = true,
			type = true,
			rarity = true,
			rank = true,
			renown = true,
		},
	},
	{
		name = T["Armor"],
		types = {
			GameData.ItemTypes.ROBE,
			GameData.ItemTypes.MEDIUMROBE,
			GameData.ItemTypes.LIGHTARMOR,
			GameData.ItemTypes.MEDIUMARMOR,
			GameData.ItemTypes.HEAVYARMOR,
			GameData.ItemTypes.SHIELD,
			GameData.ItemTypes.CHARM,
		},
		typeText = T["Any Armor Type"],
		slots = {
		GameData.EquipSlots.BODY,
		GameData.EquipSlots.GLOVES,
		GameData.EquipSlots.BOOTS,
		GameData.EquipSlots.HELM,
		GameData.EquipSlots.SHOULDERS,
	},
		slotText = T["Any Armor Slot"],
		fields = {
			type = true,
			slot = true,
			stat = true,
			career = true,
			usable = true,
			setItem = true,
			rank = true,
			renown = true,
		},
		sorts = {
			name = true,
			type = true,
			rarity = true,
			rank = true,
			renown = true,
		},
	},
	{
		name = T["Accessories"],
		types = {
			GameData.ItemTypes.ACCESSORY,
		},
		slots = {
			GameData.EquipSlots.BACK,
			GameData.EquipSlots.BELT,
			GameData.EquipSlots.ACCESSORY1,
		},
		slotText = T["Any Accessory Slot"],
		fields = {
			slot = true,
			stat = true,
			career = true,
			usable = true,
			rank = true,
			renown = true,
		},
		sorts = {
			name = true,
			type = true,
			rarity = true,
			rank = true,
			renown = true,
		},
	},
	{
		name = T["Misc"],
		types = {
			GameData.ItemTypes.DYE,
			GameData.ItemTypes.POTION,
			GameData.ItemTypes.ENHANCEMENT,
			GameData.ItemTypes.TROPHY,
		},
		typeText = T["Any Misc Type"],
		fields = {
			type = true,
			stat = true,
			rank = true,
		},
		sorts = {
			name = true,
			type = true,
			rarity = true,
			rank = true,
			renown = true,
		},
	},
	{
		name = T["Apothecary"],
		types = {},
		crafting = {
			GameData.CraftingItemType.CONTAINER,
			GameData.CraftingItemType.CONTAINER_DYE,
			GameData.CraftingItemType.MAIN_INGREDIENT,
			GameData.CraftingItemType.STABILIZER,
			GameData.CraftingItemType.EXTENDER,
			GameData.CraftingItemType.MULTIPLIER,
			GameData.CraftingItemType.STIMULANT,
			GameData.CraftingItemType.FIXER,
		},
		craftingText = T["Any Apothecary Type"],
		craftingSkill = GameData.TradeSkills.APOTHECARY,
		fields = {
			crafting = true,
			craftingLevel = true,
		},
		sorts = {
			name = true,
			type = true,
			rarity = true,
		},
	},
	{
		name = T["Cultivation"],
		types = {},
		crafting = {
			GameData.CultivationTypes.SEED,
			GameData.CultivationTypes.SOIL,
			GameData.CultivationTypes.WATERCAN,
			GameData.CultivationTypes.NUTRIENT,
			GameData.CultivationTypes.SPORE,
		},
		craftingText = T["Any Cultivation Type"],
		craftingSkill = GameData.TradeSkills.CULTIVATION,
		fields = {
			crafting = true,
			craftingLevel = true,
		},
		sorts = {
			name = true,
			type = true,
			rarity = true,
		},
	},
	{
		name = T["Talisman Making"],
		types = {},
		crafting = {
			GameData.CraftingItemType.TALISMAN_CONTAINER,
			GameData.CraftingItemType.FRAGMENT,
			GameData.CraftingItemType.GOLD_ESSENCE,
			GameData.CraftingItemType.CURIOS,
			GameData.CraftingItemType.MAGIC_ESSENCE,
		},
		craftingText = T["Any Talisman Making Type"],
		craftingSkill = GameData.TradeSkills.TALISMAN,
		fields = {
			crafting = true,
			craftingLevel = true,
		},
		sorts = {
			name = true,
			type = true,
			rarity = true,
		},
	},
}

nLootLink.STATS = {
	GameData.BonusTypes.EBONUS_STRENGTH,
	GameData.BonusTypes.EBONUS_WEAPONSKILL,
	GameData.BonusTypes.EBONUS_BALLISTICSKILL,
	GameData.BonusTypes.EBONUS_INITIATIVE,
	GameData.BonusTypes.EBONUS_INTELLIGENCE,
	GameData.BonusTypes.EBONUS_WILLPOWER,
	GameData.BonusTypes.EBONUS_TOUGHNESS,
	GameData.BonusTypes.EBONUS_WOUNDS,
	GameData.BonusTypes.EBONUS_SPIRIT_RESIST,
	GameData.BonusTypes.EBONUS_CORPOREAL_RESIST,
	GameData.BonusTypes.EBONUS_ELEMENTAL_RESIST,
	GameData.BonusTypes.EBONUS_BLOCK,
	GameData.BonusTypes.EBONUS_DISRUPT,
	GameData.BonusTypes.EBONUS_EVADE,
	GameData.BonusTypes.EBONUS_PARRY,
	GameData.BonusTypes.EBONUS_HATE_CAUSED,
	GameData.BonusTypes.EBONUS_HATE_RECEIVED,
	GameData.BonusTypes.EBONUS_HEALING_POWER,
	GameData.BonusTypes.EBONUS_DAMAGE_MELEE,
	GameData.BonusTypes.EBONUS_CRITICAL_HIT_RATE_HEALING,
	GameData.BonusTypes.EBONUS_CRITICAL_HIT_RATE_RANGED,
	GameData.BonusTypes.EBONUS_CRITICAL_HIT_RATE_MAGIC,
	GameData.BonusTypes.EBONUS_CRITICAL_HIT_RATE_MELEE,
	GameData.BonusTypes.EBONUS_AP_REGEN,
	GameData.BonusTypes.EBONUS_HEALTH_REGEN,
	GameData.BonusTypes.EBONUS_MORALE_REGEN,
}

nLootLink.CAREERS_ORDER = {
	GameData.CareerLine.IRON_BREAKER,
	GameData.CareerLine.SLAYER,
	GameData.CareerLine.RUNE_PRIEST,
	GameData.CareerLine.ENGINEER,
	GameData.CareerLine.KNIGHT,
	GameData.CareerLine.WITCH_HUNTER,
	GameData.CareerLine.BRIGHT_WIZARD,
	GameData.CareerLine.WARRIOR_PRIEST,
	GameData.CareerLine.SWORDMASTER,
	GameData.CareerLine.SHADOW_WARRIOR,
	GameData.CareerLine.ARCHMAGE,
	GameData.CareerLine.WHITE_LION,
}

nLootLink.CAREERS_DESTRUCTION = {
	GameData.CareerLine.BLACK_ORC,
	GameData.CareerLine.CHOPPA,
	GameData.CareerLine.SHAMAN,
	GameData.CareerLine.SQUIG_HERDER,
	GameData.CareerLine.MARAUDER,
	GameData.CareerLine.CHOSEN,
	GameData.CareerLine.ZEALOT,
	GameData.CareerLine.MAGUS,
	GameData.CareerLine.WITCH_ELF,
	GameData.CareerLine.DISCIPLE,
	GameData.CareerLine.SORCERER,
	GameData.CareerLine.BLACKGUARD,
}

nLootLink.CAREER_RACES = {
	[GameData.CareerLine.IRON_BREAKER] = GameData.Races.DWARF,
	[GameData.CareerLine.SLAYER] = GameData.Races.DWARF,
	[GameData.CareerLine.RUNE_PRIEST] = GameData.Races.DWARF,
	[GameData.CareerLine.ENGINEER] = GameData.Races.DWARF,
	[GameData.CareerLine.KNIGHT] = GameData.Races.EMPIRE,
	[GameData.CareerLine.WITCH_HUNTER] = GameData.Races.EMPIRE,
	[GameData.CareerLine.BRIGHT_WIZARD] = GameData.Races.EMPIRE,
	[GameData.CareerLine.WARRIOR_PRIEST] = GameData.Races.EMPIRE,
	[GameData.CareerLine.SWORDMASTER] = GameData.Races.HIGH_ELF,
	[GameData.CareerLine.SHADOW_WARRIOR] = GameData.Races.HIGH_ELF,
	[GameData.CareerLine.ARCHMAGE] = GameData.Races.HIGH_ELF,
	[GameData.CareerLine.WHITE_LION] = GameData.Races.HIGH_ELF,
	[GameData.CareerLine.BLACK_ORC] = GameData.Races.ORC,
	[GameData.CareerLine.CHOPPA] = GameData.Races.ORC,
	[GameData.CareerLine.SHAMAN] = GameData.Races.GOBLIN,
	[GameData.CareerLine.SQUIG_HERDER] = GameData.Races.GOBLIN,
	[GameData.CareerLine.BLACKGUARD] = GameData.Races.CHAOS,
	[GameData.CareerLine.CHOSEN] = GameData.Races.CHAOS,
	[GameData.CareerLine.ZEALOT] = GameData.Races.CHAOS,
	[GameData.CareerLine.MAGUS] = GameData.Races.CHAOS,
	[GameData.CareerLine.MARAUDER] = GameData.Races.DARK_ELF,
	[GameData.CareerLine.DISCIPLE] = GameData.Races.DARK_ELF,
	[GameData.CareerLine.SORCERER] = GameData.Races.DARK_ELF,
	[GameData.CareerLine.WITCH_ELF] = GameData.Races.DARK_ELF,
}

local SKILL_TEMPLATE = {}
for i = 1, GameData.SkillType.TOTAL_SKILLS do
	table.insert(SKILL_TEMPLATE, false)
end

nLootLink.CAREER_SKILLS = {}
nLootLink.CAREER_SKILLS[GameData.CareerLine.IRON_BREAKER] = DataUtils.CopyTable(SKILL_TEMPLATE)	-- ironbreaker
nLootLink.CAREER_SKILLS[GameData.CareerLine.IRON_BREAKER][GameData.SkillType.AXE] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.IRON_BREAKER][GameData.SkillType.BASIC_SHIELD] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.IRON_BREAKER][GameData.SkillType.EXPERT_SHIELD] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.IRON_BREAKER][GameData.SkillType.GREAT_WEAPONS] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.IRON_BREAKER][GameData.SkillType.HAMMER] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.IRON_BREAKER][GameData.SkillType.HEAVY_ARMOR] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.IRON_BREAKER][GameData.SkillType.ADVANCED_SHIELD] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.IRON_BREAKER][GameData.SkillType.THROWN] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.SLAYER] = DataUtils.CopyTable(SKILL_TEMPLATE)	-- slayer
nLootLink.CAREER_SKILLS[GameData.CareerLine.SLAYER][GameData.SkillType.AXE] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.SLAYER][GameData.SkillType.DUAL_WIELD] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.SLAYER][GameData.SkillType.GREAT_WEAPONS] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.SLAYER][GameData.SkillType.HAMMER] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.SLAYER][GameData.SkillType.MEDIUM_ARMOR] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.RUNE_PRIEST] = DataUtils.CopyTable(SKILL_TEMPLATE)	-- runepriest
nLootLink.CAREER_SKILLS[GameData.CareerLine.RUNE_PRIEST][GameData.SkillType.STAFF] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.RUNE_PRIEST][GameData.SkillType.ROBE] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.ENGINEER] = DataUtils.CopyTable(SKILL_TEMPLATE)	-- engineer
nLootLink.CAREER_SKILLS[GameData.CareerLine.ENGINEER][GameData.SkillType.GUN] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.ENGINEER][GameData.SkillType.HAMMER] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.ENGINEER][GameData.SkillType.LIGHT_ARMOR] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.ENGINEER][GameData.SkillType.PISTOL] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.KNIGHT] = DataUtils.CopyTable(SKILL_TEMPLATE)	-- knight of the blazing sun
nLootLink.CAREER_SKILLS[GameData.CareerLine.KNIGHT][GameData.SkillType.BASIC_SHIELD] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.KNIGHT][GameData.SkillType.EXPERT_SHIELD] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.KNIGHT][GameData.SkillType.GREAT_WEAPONS] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.KNIGHT][GameData.SkillType.HEAVY_ARMOR] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.KNIGHT][GameData.SkillType.ADVANCED_SHIELD] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.KNIGHT][GameData.SkillType.SWORD] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.WITCH_HUNTER] = DataUtils.CopyTable(SKILL_TEMPLATE)	-- witch hunter
nLootLink.CAREER_SKILLS[GameData.CareerLine.WITCH_HUNTER][GameData.SkillType.DUAL_WIELD] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.WITCH_HUNTER][GameData.SkillType.LIGHT_ARMOR] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.WITCH_HUNTER][GameData.SkillType.PISTOL] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.WITCH_HUNTER][GameData.SkillType.SWORD] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.BRIGHT_WIZARD] = DataUtils.CopyTable(SKILL_TEMPLATE)	-- bright wizard
nLootLink.CAREER_SKILLS[GameData.CareerLine.BRIGHT_WIZARD][GameData.SkillType.ROBE] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.BRIGHT_WIZARD][GameData.SkillType.STAFF] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.WARRIOR_PRIEST] = DataUtils.CopyTable(SKILL_TEMPLATE)	-- warrior priest
nLootLink.CAREER_SKILLS[GameData.CareerLine.WARRIOR_PRIEST][GameData.SkillType.CHARM] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.WARRIOR_PRIEST][GameData.SkillType.GREAT_WEAPONS] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.WARRIOR_PRIEST][GameData.SkillType.HAMMER] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.WARRIOR_PRIEST][GameData.SkillType.MEDIUM_ROBE] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.SWORDMASTER] = DataUtils.CopyTable(SKILL_TEMPLATE)	-- swordmaster
nLootLink.CAREER_SKILLS[GameData.CareerLine.SWORDMASTER][GameData.SkillType.BASIC_SHIELD] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.SWORDMASTER][GameData.SkillType.EXPERT_SHIELD] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.SWORDMASTER][GameData.SkillType.GREAT_WEAPONS] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.SWORDMASTER][GameData.SkillType.HEAVY_ARMOR] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.SWORDMASTER][GameData.SkillType.ADVANCED_SHIELD] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.SWORDMASTER][GameData.SkillType.SWORD] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.SHADOW_WARRIOR] = DataUtils.CopyTable(SKILL_TEMPLATE)	-- shadow warrior
nLootLink.CAREER_SKILLS[GameData.CareerLine.SHADOW_WARRIOR][GameData.SkillType.BOW] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.SHADOW_WARRIOR][GameData.SkillType.LIGHT_ARMOR] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.SHADOW_WARRIOR][GameData.SkillType.SWORD] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.ARCHMAGE] = DataUtils.CopyTable(SKILL_TEMPLATE)	-- archmage
nLootLink.CAREER_SKILLS[GameData.CareerLine.ARCHMAGE][GameData.SkillType.ROBE] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.ARCHMAGE][GameData.SkillType.STAFF] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.WHITE_LION] = DataUtils.CopyTable(SKILL_TEMPLATE)	-- lionfucker
nLootLink.CAREER_SKILLS[GameData.CareerLine.WHITE_LION][GameData.SkillType.AXE] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.WHITE_LION][GameData.SkillType.GREAT_WEAPONS] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.WHITE_LION][GameData.SkillType.MEDIUM_ARMOR] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.BLACK_ORC] = DataUtils.CopyTable(SKILL_TEMPLATE)	-- black orc
nLootLink.CAREER_SKILLS[GameData.CareerLine.BLACK_ORC][GameData.SkillType.AXE] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.BLACK_ORC][GameData.SkillType.BASIC_SHIELD] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.BLACK_ORC][GameData.SkillType.EXPERT_SHIELD] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.BLACK_ORC][GameData.SkillType.GREAT_WEAPONS] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.BLACK_ORC][GameData.SkillType.HAMMER] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.BLACK_ORC][GameData.SkillType.HEAVY_ARMOR] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.BLACK_ORC][GameData.SkillType.SWORD] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.BLACK_ORC][GameData.SkillType.ADVANCED_SHIELD] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.SHAMAN] = DataUtils.CopyTable(SKILL_TEMPLATE)	-- shaman
nLootLink.CAREER_SKILLS[GameData.CareerLine.SHAMAN][GameData.SkillType.ROBE] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.SHAMAN][GameData.SkillType.STAFF] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.SQUIG_HERDER] = DataUtils.CopyTable(SKILL_TEMPLATE)	-- squig herder
nLootLink.CAREER_SKILLS[GameData.CareerLine.SQUIG_HERDER][GameData.SkillType.BOW] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.SQUIG_HERDER][GameData.SkillType.LIGHT_ARMOR] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.SQUIG_HERDER][GameData.SkillType.SPEAR] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.MARAUDER] = DataUtils.CopyTable(SKILL_TEMPLATE)	-- marauder
nLootLink.CAREER_SKILLS[GameData.CareerLine.MARAUDER][GameData.SkillType.AXE] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.MARAUDER][GameData.SkillType.HAMMER] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.MARAUDER][GameData.SkillType.MEDIUM_ARMOR] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.MARAUDER][GameData.SkillType.DUAL_WIELD] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.CHOSEN] = DataUtils.CopyTable(SKILL_TEMPLATE)	-- chosen
nLootLink.CAREER_SKILLS[GameData.CareerLine.CHOSEN][GameData.SkillType.AXE] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.CHOSEN][GameData.SkillType.BASIC_SHIELD] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.CHOSEN][GameData.SkillType.GREAT_WEAPONS] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.CHOSEN][GameData.SkillType.HEAVY_ARMOR] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.CHOSEN][GameData.SkillType.ADVANCED_SHIELD] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.CHOSEN][GameData.SkillType.SWORD] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.ZEALOT] = DataUtils.CopyTable(SKILL_TEMPLATE)	-- zealot
nLootLink.CAREER_SKILLS[GameData.CareerLine.ZEALOT][GameData.SkillType.CHARM] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.ZEALOT][GameData.SkillType.DAGGER] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.ZEALOT][GameData.SkillType.ROBE] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.MAGUS] = DataUtils.CopyTable(SKILL_TEMPLATE)	-- magus
nLootLink.CAREER_SKILLS[GameData.CareerLine.MAGUS][GameData.SkillType.ROBE] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.MAGUS][GameData.SkillType.STAFF] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.WITCH_ELF] = DataUtils.CopyTable(SKILL_TEMPLATE)	-- witch elf
nLootLink.CAREER_SKILLS[GameData.CareerLine.WITCH_ELF][GameData.SkillType.DUAL_WIELD] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.WITCH_ELF][GameData.SkillType.DAGGER] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.WITCH_ELF][GameData.SkillType.LIGHT_ARMOR] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.DISCIPLE] = DataUtils.CopyTable(SKILL_TEMPLATE)	-- disciple of khaine
nLootLink.CAREER_SKILLS[GameData.CareerLine.DISCIPLE][GameData.SkillType.SWORD] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.DISCIPLE][GameData.SkillType.MEDIUM_ROBE] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.DISCIPLE][GameData.SkillType.CHARM] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.DISCIPLE][GameData.SkillType.DUAL_WIELD] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.SORCERER] = DataUtils.CopyTable(SKILL_TEMPLATE)	-- sorcerer
nLootLink.CAREER_SKILLS[GameData.CareerLine.SORCERER][GameData.SkillType.STAFF] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.SORCERER][GameData.SkillType.ROBE] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.BLACKGUARD] = DataUtils.CopyTable(SKILL_TEMPLATE)	-- blackguard
nLootLink.CAREER_SKILLS[GameData.CareerLine.BLACKGUARD][GameData.SkillType.BASIC_SHIELD] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.BLACKGUARD][GameData.SkillType.EXPERT_SHIELD] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.BLACKGUARD][GameData.SkillType.GREAT_WEAPONS] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.BLACKGUARD][GameData.SkillType.HEAVY_ARMOR] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.BLACKGUARD][GameData.SkillType.ADVANCED_SHIELD] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.BLACKGUARD][GameData.SkillType.SPEAR] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.BLACKGUARD][GameData.SkillType.SWORD] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.CHOPPA] = DataUtils.CopyTable(SKILL_TEMPLATE)	-- choppa
nLootLink.CAREER_SKILLS[GameData.CareerLine.CHOPPA][GameData.SkillType.AXE] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.CHOPPA][GameData.SkillType.DUAL_WIELD] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.CHOPPA][GameData.SkillType.GREAT_WEAPONS] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.CHOPPA][GameData.SkillType.SWORD] = true
nLootLink.CAREER_SKILLS[GameData.CareerLine.CHOPPA][GameData.SkillType.MEDIUM_ARMOR] = true
