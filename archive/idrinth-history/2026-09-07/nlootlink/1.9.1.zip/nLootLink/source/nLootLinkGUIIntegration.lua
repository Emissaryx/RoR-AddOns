nLootLinkGUIIntegration = {}

-- constants
local MENU_WINDOW_NAME = "nLootLinkMenuBarWindow"
local MENU_BUTTON_WINDOW_NAME = MENU_WINDOW_NAME.."TogglenLootLinkWindow"
local BAG_BUTTON_NAME = "NLootLinkButtonBag"
local CHAR_BUTTON_NAME = "NLootLinkButtonChar"

-- local variables
local doDebug = false


--
-- initialisation functions
--

-- initialise the GUI elements that integrate with the default UI
function nLootLinkGUIIntegration.init()
	doDebug = nLootLink.DEBUG
	if doDebug then d("nLootLinkGUIIntegration.init START") end

	nLootLinkGUIIntegration.initMenu()
	nLootLinkGUIIntegration.initButtons()

	if doDebug then d("nLootLinkGUIIntegration.init END") end
end

-- create buttons
function nLootLinkGUIIntegration.initButtons()

	-- backpack launcher
	CreateWindowFromTemplate(BAG_BUTTON_NAME, "NLootLinkButtonTemplate", "EA_Window_Backpack")
	WindowAddAnchor(BAG_BUTTON_NAME, "topright", "EA_Window_BackpackTitleBar", "topright", -35, -10)
	ButtonSetText(BAG_BUTTON_NAME, nLootLink.WINDOW_TITLE)
	WindowSetShowing(BAG_BUTTON_NAME, false)

	-- character window launcher
	CreateWindowFromTemplate(CHAR_BUTTON_NAME, "NLootLinkButtonTemplate", "CharacterWindow")
	WindowAddAnchor(CHAR_BUTTON_NAME, "topright", "CharacterWindowTitleBar", "topright", -35, -10)
	ButtonSetText(CHAR_BUTTON_NAME, nLootLink.WINDOW_TITLE)
	WindowSetShowing(CHAR_BUTTON_NAME, false)
end

-- initialise the little nLootLink menu bar
function nLootLinkGUIIntegration.initMenu()

	-- register menu with the layout editor
	local name = nLootLink.WINDOW_TITLE..L" "..GetStringFromTable("HUDStrings", StringTables.HUD.LABEL_HUD_EDIT_MENU_BAR_NAME)
	LayoutEditor.RegisterWindow(MENU_WINDOW_NAME, name, name, false, false, true, nil)

	-- create the button
	CreateWindowFromTemplate(MENU_BUTTON_WINDOW_NAME, "EA_Window_HUDnLootLinkTogglenLootLinkWindowTemplate", MENU_WINDOW_NAME)
	ButtonSetStayDownFlag(MENU_BUTTON_WINDOW_NAME.."Button", true)
	WindowUtils.AddWindowStateButton(MENU_BUTTON_WINDOW_NAME.."Button", nLootLink.WINDOW_NAME)
	WindowSetScale(MENU_BUTTON_WINDOW_NAME, WindowGetScale(MENU_WINDOW_NAME))
	WindowAddAnchor(MENU_BUTTON_WINDOW_NAME, "topleft", MENU_WINDOW_NAME, "topleft", 0, 0)
end


--
-- mutators
--

-- show/hide bag button
function nLootLinkGUIIntegration.bagButton(show)
	WindowSetShowing(BAG_BUTTON_NAME, show)
end

-- show/hide char button
function nLootLinkGUIIntegration.charButton(show)
	WindowSetShowing(CHAR_BUTTON_NAME, show)
end


--
-- GUI event functions
--

-- menu button moused over
function nLootLinkGUIIntegration.onMouseoverMenuButton()
	WindowUtils.OnMouseOverButton(nLootLink.WINDOW_TITLE)
end
