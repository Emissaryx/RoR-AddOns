nLootLinkUtil = {}

-- libraries
local T = LibStub("WAR-AceLocale-3.0"):GetLocale("nLootLink")

-- constants
local CHECK_BOX_CHECKED = L"<icon57> "
local CHECK_BOX_UNCHECKED = L"<icon58> "

-- global constants
local CHOICE_ANY_VALUE = nLootLink.CHOICE_ANY_VALUE

-- print a string to the chat box
function nLootLinkUtil.printToChat(str)
	EA_ChatWindow.Print(str)
end

-- toggle the GUI, if it's ready
function nLootLinkUtil.toggleShowing()
	if nLootLink.initComplete then
		if nLootLinkGUI and nLootLinkGUI.toggleShowing then
			nLootLinkGUI.toggleShowing()
		end
	else
		if type(nLootLinkData.getNumItemsUnpacked()) ~= "number" or type(nLootLinkData.getNumItems()) ~= "number" then
			nLootLinkUtil.printToChat(T["error loading nLootLinkData"])
		else
			nLootLinkUtil.printToChat(T["nLootLink has unpacked %d/%d items, please be patient..."]:format(nLootLinkData.getNumItemsUnpacked(), nLootLinkData.getNumItems()))
		end
	end
end

-- enable or disable a combo box
function nLootLinkUtil.enableCombo(comboName, enabled)
	ComboBoxSetDisabledFlag(comboName, not enabled)
	if not enabled then
		ComboBoxSetSelectedMenuItem(comboName, 1)
	end
end

-- enable or disable a check box
function nLootLinkUtil.enableCheck(checkName, enabled)

	-- local needed as WindowSetShowing doesn't take nil as a valid argument
	local checkEnabled = false
	if enabled then
		checkEnabled = true
	end

	WindowSetShowing(checkName, checkEnabled)
	if not enabled then
		ButtonSetPressedFlag(checkName.."Button", false)
	end
end

-- initialise a combo box
function nLootLinkUtil.setComboBoxChoices(comboBoxName, choices)

	for index, data in ipairs(choices) do
		if data.isSelected == true then
			ComboBoxAddMenuItem(comboBoxName, CHECK_BOX_CHECKED..data.text)
		elseif data.isSelected == false then
			ComboBoxAddMenuItem(comboBoxName, CHECK_BOX_UNCHECKED..data.text)
		else
			ComboBoxAddMenuItem(comboBoxName, data.text)
		end
	end
end

-- generate a name for the combo box, from one or multiple choices selected - adapted from auctionsearchwindow.lua
function nLootLinkUtil.setMultiComboBoxName(comboBoxName, choiceDataTable, default)

	local name = L""
	for _, data in ipairs(choiceDataTable) do
		if data.isSelected then
			if name == L"" then
				name = data.text
			else
				name = name..L", "..data.text
			end
		end
	end 

	if name == L"" then
		-- if no choices selected, then use the default value, which is always in the first index
		name = default
	end

	ButtonSetText(comboBoxName.."SelectedButton", name)
end

-- set the values on a multiselection combo box - adapted from auctionsearchwindow.lua
function nLootLinkUtil.setMultiComboBoxValue(choiceIndex, comboBoxName, choiceDataTable)

	local choiceData = choiceDataTable[choiceIndex]
	if choiceData == nil then
		return
	end

	local val = choiceData.value
	if val == CHOICE_ANY_VALUE then
		for _, data in ipairs(choiceDataTable) do
			if data.value ~= CHOICE_ANY_VALUE then
				data.isSelected = false
			end
		end
	else
		choiceData.isSelected = not choiceData.isSelected
	end

	ComboBoxClearMenuItems(comboBoxName)
	nLootLinkUtil.setComboBoxChoices(comboBoxName, choiceDataTable)

	nLootLinkUtil.setMultiComboBoxName(comboBoxName, choiceDataTable, choiceDataTable[1].text)
end
