LibItemCompressTest = {}

-- libraries
local LibItemCompress = LibStub:GetLibrary("LibItemCompress-1.1")

-- run all tests
function LibItemCompressTest.all()
	LibItemCompressTest.lengths = {}

	local success = LibItemCompressTest.sampleData()
		and LibItemCompressTest.failData()
		and LibItemCompressTest.getDatabaseItemData()
		and LibItemCompressTest.nLootLink()

	local totalLength = 0
	for _, length in ipairs(LibItemCompressTest.lengths) do
		totalLength = totalLength + length
	end
	avgLength = totalLength / #LibItemCompressTest.lengths
	if success then
		d("LibItemCompressTest.all: ALL TESTS PASSED, average compressed length = "..tostring(avgLength))
	end

	LibItemCompressTest.lengths = {}

	return success
end

-- test each of the items in sampleItemData
function LibItemCompressTest.sampleData()
	local numTests = 0
	for _, itemData in ipairs(LibItemCompressTest.sampleItemData) do
		numTests = numTests + 1
		if not LibItemCompressTest.testCompression(itemData) then
			d("LibItemCompressTest.sampleData: failed at item "..(numTests))
			return false
		end
	end
	d("LibItemCompressTest.sampleData: "..tostring(numTests).." tests passed")
	return true
end

-- test each of the items in the game's item database cache
function LibItemCompressTest.getDatabaseItemData()
	local itemData, getDatabaseItemDataFn
	local numTests = 0
	if nLootLinkChat.hooked.getDatabaseItemData then
		getDatabaseItemDataFn = nLootLinkChat.hooked.getDatabaseItemData
	else
		getDatabaseItemDataFn = getDatabaseItemData
	end
	for i = 1, 2000000 do
		itemData = getDatabaseItemDataFn(i)
		if itemData then
			numTests = numTests + 1
			if not LibItemCompressTest.testCompression(itemData) then
				d("LibItemCompressTest.getDatabaseItemData: failed for uniqueID = "..tostring(itemData.uniqueID))
				return false
			end
		end
	end
	d("LibItemCompressTest.getDatabaseItemData: "..tostring(numTests).." tests passed")
	return true
end 

-- test each of the fail items - we don't want errors here
function LibItemCompressTest.failData()
	local success, err, itemDataComp, itemDataUnComp, missingBitsTable

	success, err = pcall(LibItemCompress.compressItemData, nil)
	if not success then
		d("LibItemCompressTest.failData: failed on nil table with err = "..tostring(err))
		return false
	end
	itemDataComp = LibItemCompress.compressItemData(nil)
	itemDataUnComp = LibItemCompress.uncompressItemData(itemDataComp)
	if not LibItemCompressTest.compareTables(itemDataUnComp, LibItemCompressTest.skeletonItemData) then
		d("LibItemCompressTest.failData: failed for skeleton table against nil")
		return false
	end

	success, err = pcall(LibItemCompress.compressItemData, {})
	if not success then
		d("LibItemCompressTest.failData: failed on empty table with err = "..tostring(err))
		return false
	end
	itemDataComp = LibItemCompress.compressItemData({})
	itemDataUnComp = LibItemCompress.uncompressItemData(itemDataComp)
	if not LibItemCompressTest.compareTables(itemDataUnComp, LibItemCompressTest.skeletonItemData) then
		d("LibItemCompressTest.failData: failed for skeleton table against {}")
		return false
	end

	success, err = pcall(LibItemCompress.uncompressItemData, nil)
	if not success then
		d("LibItemCompressTest.failData: failed on uncompressing nil "..tostring(err))
		return false
	end

	missingBitsTable = DataUtils.CopyTable(LibItemCompressTest.sampleItemData[2])
	missingBitsTable.name = nil
	success, err = pcall(LibItemCompress.compressItemData, missingBitsTable)
	if not success then
		d("LibItemCompressTest.failData: failed on missing name with err = "..tostring(err))
		return false
	end
	itemDataComp = LibItemCompress.compressItemData(missingBitsTable)
	itemDataUnComp = LibItemCompress.uncompressItemData(itemDataComp)
	missingBitsTable.name = L""
	if not LibItemCompressTest.compareTables(itemDataUnComp, missingBitsTable) then
		d("LibItemCompressTest.failData: failed for missing name")
		return false
	end

	missingBitsTable = DataUtils.CopyTable(LibItemCompressTest.sampleItemData[2])
	missingBitsTable.description = nil
	success, err = pcall(LibItemCompress.compressItemData, missingBitsTable)
	if not success then
		d("LibItemCompressTest.failData: failed on missing description with err = "..tostring(err))
		return false
	end
	itemDataComp = LibItemCompress.compressItemData(missingBitsTable)
	itemDataUnComp = LibItemCompress.uncompressItemData(itemDataComp)
	missingBitsTable.description = L""
	if not LibItemCompressTest.compareTables(itemDataUnComp, missingBitsTable) then
		d("LibItemCompressTest.failData: failed for missing description")
		return false
	end

	missingBitsTable = DataUtils.CopyTable(LibItemCompressTest.sampleItemData[2])
	missingBitsTable.iconNum = nil
	success, err = pcall(LibItemCompress.compressItemData, missingBitsTable)
	if not success then
		d("LibItemCompressTest.failData: failed on missing iconNum with err = "..tostring(err))
		return false
	end
	itemDataComp = LibItemCompress.compressItemData(missingBitsTable)
	itemDataUnComp = LibItemCompress.uncompressItemData(itemDataComp)
	missingBitsTable.iconNum = 0
	if not LibItemCompressTest.compareTables(itemDataUnComp, missingBitsTable) then
		d("LibItemCompressTest.failData: failed for missing iconNum")
		return false
	end

	missingBitsTable = DataUtils.CopyTable(LibItemCompressTest.sampleItemData[2])
	missingBitsTable.bonus = nil
	success, err = pcall(LibItemCompress.compressItemData, missingBitsTable)
	if not success then
		d("LibItemCompressTest.failData: failed on missing bonus table with err = "..tostring(err))
		return false
	end
	itemDataComp = LibItemCompress.compressItemData(missingBitsTable)
	itemDataUnComp = LibItemCompress.uncompressItemData(itemDataComp)
	missingBitsTable.bonus = {}
	if not LibItemCompressTest.compareTables(itemDataUnComp, missingBitsTable) then
		d("LibItemCompressTest.failData: failed for missing bonus table")
		return false
	end

	missingBitsTable = DataUtils.CopyTable(LibItemCompressTest.sampleItemData[2])
	missingBitsTable.flags = nil
	success, err = pcall(LibItemCompress.compressItemData, missingBitsTable)
	if not success then
		d("LibItemCompressTest.failData: failed on missing flags table with err = "..tostring(err))
		return false
	end
	itemDataComp = LibItemCompress.compressItemData(missingBitsTable)
	itemDataUnComp = LibItemCompress.uncompressItemData(itemDataComp)
	missingBitsTable.flags = {}
	for i = 0, 16 do
		missingBitsTable.flags[i] = false
	end
	if not LibItemCompressTest.compareTables(itemDataUnComp, missingBitsTable) then
		d("LibItemCompressTest.failData: failed for missing flags table")
		return false
	end

	missingBitsTable = DataUtils.CopyTable(LibItemCompressTest.sampleItemData[2])
	missingBitsTable.flags = {}
	success, err = pcall(LibItemCompress.compressItemData, missingBitsTable)
	if not success then
		d("LibItemCompressTest.failData: failed on empty flags table with err = "..tostring(err))
		return false
	end
	itemDataComp = LibItemCompress.compressItemData(missingBitsTable)
	itemDataUnComp = LibItemCompress.uncompressItemData(itemDataComp)
	for i = 0, 16 do
		missingBitsTable.flags[i] = false
	end
	if not LibItemCompressTest.compareTables(itemDataUnComp, missingBitsTable) then
		d("LibItemCompressTest.failData: failed for empty flags table")
		return false
	end

	missingBitsTable = DataUtils.CopyTable(LibItemCompressTest.sampleItemData[2])
	itemDataComp = LibItemCompress.compressItemData(missingBitsTable)
	itemDataComp = itemDataComp..L"*1*2**"
	success, err = pcall(LibItemCompress.uncompressItemData, itemDataComp)
	if not success then
		d("LibItemCompressTest.failData: failed on extra number fields with err = "..tostring(err))
		return false
	end
	itemDataUnComp = LibItemCompress.uncompressItemData(itemDataComp)
	if not LibItemCompressTest.compareTables(itemDataUnComp, missingBitsTable) then
		d("LibItemCompressTest.failData: failed for extra number fields")
		return false
	end

	missingBitsTable = DataUtils.CopyTable(LibItemCompressTest.sampleItemData[2])
	itemDataComp = LibItemCompress.compressItemData(missingBitsTable)
	itemDataComp = itemDataComp..L"bleh,"
	success, err = pcall(LibItemCompress.uncompressItemData, itemDataComp)
	if not success then
		d("LibItemCompressTest.failData: failed on extra wstring fields with err = "..tostring(err))
		return false
	end
	itemDataUnComp = LibItemCompress.uncompressItemData(itemDataComp)
	if not LibItemCompressTest.compareTables(itemDataUnComp, missingBitsTable) then
		d("LibItemCompressTest.failData: failed for extra wstring fields")
		return false
	end

	missingBitsTable = DataUtils.CopyTable(LibItemCompressTest.sampleItemData[2])
	itemDataComp = LibItemCompress.compressItemData(missingBitsTable)
	itemDataComp = itemDataComp..L"1|2|3|&"
	success, err = pcall(LibItemCompress.uncompressItemData, itemDataComp)
	if not success then
		d("LibItemCompressTest.failData: failed on extra bonus table fields with err = "..tostring(err))
		return false
	end
	itemDataUnComp = LibItemCompress.uncompressItemData(itemDataComp)
	if not LibItemCompressTest.compareTables(itemDataUnComp, missingBitsTable) then
		d("LibItemCompressTest.failData: failed for extra bonus table fields")
		return false
	end

	missingBitsTable = DataUtils.CopyTable(LibItemCompressTest.sampleItemData[2])
	itemDataComp = LibItemCompress.compressItemData(missingBitsTable)
	itemDataComp = itemDataComp..L"1|2|3|#"
	success, err = pcall(LibItemCompress.uncompressItemData, itemDataComp)
	if not success then
		d("LibItemCompressTest.failData: failed on extra integer table fields with err = "..tostring(err))
		return false
	end
	itemDataUnComp = LibItemCompress.uncompressItemData(itemDataComp)
	if not LibItemCompressTest.compareTables(itemDataUnComp, missingBitsTable) then
		d("LibItemCompressTest.failData: failed for extra integer table fields")
		return false
	end

	missingBitsTable = DataUtils.CopyTable(LibItemCompressTest.sampleItemData[2])
	itemDataComp = LibItemCompress.compressItemData(missingBitsTable)
	itemDataComp = itemDataComp:gsub(L",,", L",", 1)
	success, err = pcall(LibItemCompress.uncompressItemData, itemDataComp)
	if not success then
		d("LibItemCompressTest.failData: failed on missing wstring fields with err = "..tostring(err))
		return false
	end	
	itemDataUnComp = LibItemCompress.uncompressItemData(itemDataComp)
	if not LibItemCompressTest.compareTables(itemDataUnComp, missingBitsTable) then
		d("LibItemCompressTest.failData: failed for wstring wstr fields")
		return false
	end

	missingBitsTable = DataUtils.CopyTable(LibItemCompressTest.sampleItemData[2])
	itemDataComp = LibItemCompress.compressItemData(missingBitsTable)
	itemDataComp = itemDataComp:gsub(L"%*%*%*%*$", L"", 1)
	success, err = pcall(LibItemCompress.uncompressItemData, itemDataComp)
	if not success then
		d("LibItemCompressTest.failData: failed on missing numeric fields with err = "..tostring(err))
		return false
	end	
	itemDataUnComp = LibItemCompress.uncompressItemData(itemDataComp)
	if not LibItemCompressTest.compareTables(itemDataUnComp, missingBitsTable) then
		d("LibItemCompressTest.failData: failed for missing numeric fields")
		return false
	end

	missingBitsTable = DataUtils.CopyTable(LibItemCompressTest.sampleItemData[2])
	itemDataComp = LibItemCompress.compressItemData(missingBitsTable)
	itemDataComp = itemDataComp:gsub(L"%&%&", L"%&", 1)
	success, err = pcall(LibItemCompress.uncompressItemData, itemDataComp)
	if not success then
		d("LibItemCompressTest.failData: failed on missing bonus table fields with err = "..tostring(err))
		return false
	end	
	itemDataUnComp = LibItemCompress.uncompressItemData(itemDataComp)
	if not LibItemCompressTest.compareTables(itemDataUnComp, missingBitsTable) then
		d("LibItemCompressTest.failData: failed for missing bonus table fields")
		return false
	end

	missingBitsTable = DataUtils.CopyTable(LibItemCompressTest.sampleItemData[2])
	itemDataComp = LibItemCompress.compressItemData(missingBitsTable)
	itemDataComp = itemDataComp:gsub(L"%#%#", L"%#", 1)
	success, err = pcall(LibItemCompress.uncompressItemData, itemDataComp)
	if not success then
		d("LibItemCompressTest.failData: failed on missing integer table fields with err = "..tostring(err))
		return false
	end	
	itemDataUnComp = LibItemCompress.uncompressItemData(itemDataComp)
	if not LibItemCompressTest.compareTables(itemDataUnComp, missingBitsTable) then
		d("LibItemCompressTest.failData: failed for missing integer table fields")
		return false
	end

	d("LibItemCompressTest.failData: ALL tests passed")
	return true
end

-- test each of the items in the nLootLink item DB
function LibItemCompressTest.nLootLink()
	local itemData
	local numTests = 0
	if nLootLinkData.itemDB then
		for uniqueID, _ in pairs(nLootLinkData.itemDB) do
			numTests = numTests + 1
			itemData = nLootLinkData.getItemData(uniqueID)

			itemData.cooldownTimeLeft = nil
			itemData.slots = {}
			itemData.enhSlot = {}
			if itemData.flags[0] == nil then
				itemData.flags[0] = false
			end
			if itemData.flags[16] == nil then
				itemData.flags[16] = false
			end
			if itemData.isRefinable == nil then
				itemData.isRefinable = false
			end
			itemData.selected = nil
			itemData.canbuy = nil
			itemData.slotid = nil
			itemData.cost = nil
			itemData.pageid = nil
			itemData.repairPrice = nil
			itemData.brokenTimeRemaining = nil
			itemData.repairedName = nil
			itemData.repairedIconNum = nil
			itemData.brokenName = nil
			itemData.brokenIconNum = nil
			itemData.decayed = nil

			if not LibItemCompressTest.testCompression(itemData) then
				d("LibItemCompressTest.nLootLink: failed for uniqueID = "..tostring(uniqueID))
				return false
			end
		end
		d("LibItemCompressTest.nLootLink: "..tostring(numTests).." tests passed")
		return true
	else
		d("LibItemCompressTest.nLootLink: not found, skipping test")
		return true
	end
end

-- perform a compress/uncompress test on an itemData object, returning true if successful
function LibItemCompressTest.testCompression(itemData)
	local itemDataComp = LibItemCompress.compressItemData(itemData)
	if LibItemCompressTest.lengths then
		table.insert(LibItemCompressTest.lengths, itemDataComp:len())
	end
	local itemDataUnComp = LibItemCompress.uncompressItemData(itemDataComp)
	for _, key in pairs(LibItemCompress.getUnstoredNumberKeys()) do
		itemDataUnComp[key] = itemData[key]
	end
	for _, key in pairs(LibItemCompress.getUnstoredTableKeys()) do
		itemDataUnComp[key] = itemData[key]
	end
	for _, key in pairs(LibItemCompress.getUnstoredFlagKeys()) do
		itemDataUnComp[key] = itemData[key]
	end
	return LibItemCompressTest.compareTables(itemDataUnComp, itemData)
end

-- compare two tables, returning true if they exactly match
local function compareTablesOrdered(a, b, stack)
	for k, _ in pairs(a) do
		if a[k] == nil or b[k] == nil then
			d(stack.."."..tostring(k).." missing")
			return false
		end
		if type(a[k]) ~= type(b[k]) then
			d(stack.."."..tostring(k).." type mismatch")
			return false
		end
		if type(a[k]) == "table" then
			local result = compareTablesOrdered(a[k], b[k], stack.."."..tostring(k))
			if not result then
				return false
			end
		elseif type(a[k]) == "number" then
			if tostring(a[k]) ~= tostring(b[k]) then
				d(stack.."."..tostring(k).." number value mismatch")
				return false
			end
		elseif a[k] ~= b[k] then
			d(stack.."."..tostring(k).." value mismatch")
			return false
		end
	end
	return true
end
function LibItemCompressTest.compareTables(a, b)
	return compareTablesOrdered(a, b, "itemData") and compareTablesOrdered(b, a, "itemData")
end 

LibItemCompressTest.skeletonItemData = {
	description = L"",
	renown = 0,
	maxEquip = 0,
	isNew = false,
	equipSlot = 0,
	races = 
	{
	},
	tintB = 0,
	speed = 0,
	cultivationType = 0,
	craftingSkillRequirement = 0,
	iconNum = 0,
	rarity = 0,
	marketingVariation = 0,
	flags = 
	{
		false,
		false,
		false,
		false,
		false,
		false,
		false,
		false,
		false,
		false,
		false,
		false,
		false,
		false,
		false, 
		false, 
		[0] = false,
	},
	name = L"",
	broken = false,
	skills = 
	{
	},
	marketingIndex = 0,
	uniqueID = 0,
	blockRating = 0,
	sellPrice = 0,
	slots = 
	{
	},
	level = 0,
	armor = 0,
	dyeTintB = 0,
	currChargesRemaining = 0,
	trophyLocation = 0,
	dyeTintA = 0,
	iLevel = 0,
	bonus = 
	{
	},
	enhSlot = 
	{
	},
	type = 0,
	boundToPlayer = false,
	numEnhancementSlots = 0,
	id = 0,
	dps = 0,
	craftingBonus = 
	{
	},
	trophyLocIndex = 0,
	careers = 
	{
	},
	bop = false,
	itemSet = 0,
	noChargeLeftDontDelete = 0,
	stackCount = 0,
	isRefinable = false,
	tintA = 0,
	timeLeftBeforeDecay = 0,
	timestamp = 0,
	decayPaused = false,
}

LibItemCompressTest.sampleItemData = 
{
	{
		description = L"",
		renown = 33,
		maxEquip = 0,
		isNew = false,
		equipSlot = 9,
		races = 
		{
		},
		tintB = 0,
		speed = 0,
		cultivationType = 0,
		craftingSkillRequirement = 0,
		iconNum = 3501,
		rarity = 5,
		marketingVariation = 0,
		flags = 
		{
			false,
			true,
			false,
			false,
			false,
			false,
			false,
			true,
			true,
			false,
			false,
			false,
			false,
			false,
			false, 
			false, 
			[0] = false,
		},
		name = L"Annih&ilator B#arb|ut,e",
		broken = false,
		skills = 
		{
			[1] = 6,
		},
		marketingIndex = 0,
		uniqueID = 434187,
		blockRating = 0,
		sellPrice = 3023,
		slots = 
		{
		},
		level = 36,
		armor = 216,
		dyeTintB = 0,
		currChargesRemaining = 0,
		trophyLocation = 0,
		dyeTintA = 0,
		iLevel = 48,
		bonus = 
		{
			
			{
				value = 16,
				type = 2,
				reference = 5,
				duration = 0,
			},
			
			{
				value = 13,
				type = 2,
				reference = 6,
				duration = 0,
			},
			
			{
				value = 29,
				type = 2,
				reference = 9,
				duration = 0,
			},
			
			{
				value = 2,
				type = 2,
				reference = 88,
				duration = 0,
			},
			
			{
				value = 0,
				type = 5,
				reference = 12958,
			},
		},
		enhSlot = 
		{
		},
		type = 6,
		boundToPlayer = false,
		numEnhancementSlots = 1,
		id = 5939,
		dps = 0,
		craftingBonus = 
		{
		},
		trophyLocIndex = 1,
		careers = 
		{
			[1] = 16,
		},
		bop = true,
		itemSet = 4091,
		noChargeLeftDontDelete = 0,
		stackCount = 1,
		--cooldownTimeLeft = 0,
		isRefinable = false,
		tintA = 0,
		timeLeftBeforeDecay = 0,
		timestamp = 0,
		decayPaused = false,
	},
	
	{
		description = L"",
		renown = 0,
		maxEquip = 0,
		isNew = false,
		equipSlot = 0,
		races = 
		{
		},
		tintB = 0,
		speed = 0,
		cultivationType = 0,
		craftingSkillRequirement = 0,
		iconNum = 398,
		rarity = 5,
		marketingVariation = 0,
		flags = 
		{
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false, 
			false, 
			[0] = false,
		},
		name = L"Major Talisman of the Polymath",
		broken = false,
		skills = 
		{
		},
		marketingIndex = 0,
		uniqueID = 907317,
		blockRating = 0,
		sellPrice = 100,
		slots = 
		{
		},
		level = 0,
		armor = 0,
		dyeTintB = 0,
		currChargesRemaining = 0,
		trophyLocation = 0,
		dyeTintA = 0,
		iLevel = 0,
		bonus = 
		{
			[1] = 
			{
				value = 17,
				type = 2,
				reference = 9,
				duration = 0,
			},
		},
		enhSlot = 
		{
		},
		type = 23,
		boundToPlayer = false,
		numEnhancementSlots = 0,
		id = 951,
		dps = 0,
		craftingBonus = 
		{
		},
		trophyLocIndex = 1,
		careers = 
		{
		},
		bop = false,
		itemSet = 0,
		noChargeLeftDontDelete = 0,
		stackCount = 1,
		--cooldownTimeLeft = 0,
		isRefinable = false,
		tintA = 0,
		timeLeftBeforeDecay = 0,
		timestamp = 0,
		decayPaused = false,
	},
	
	{
		isRefinable = false,
		description = L"",
		renown = 0,
		maxEquip = 0,
		isNew = false,
		equipSlot = 0,
		races = 
		{
		},
		tintB = 0,
		speed = 0,
		cultivationType = 0,
		craftingSkillRequirement = 0,
		iconNum = 478,
		rarity = 3,
		marketingVariation = 0,
		flags = 
		{
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			[0] = false,
		},
		name = L"Enduring Elixir of Respite",
		broken = false,
		skills = 
		{
		},
		marketingIndex = 0,
		uniqueID = 157894,
		dyeTintA = 0,
		blockRating = 0,
		trophyLocation = 0,
		level = 15,
		tintA = 0,
		currChargesRemaining = 0,
		dyeTintB = 0,
		bop = false,
		sellPrice = 40,
		bonus = 
		{
			[1] = 
			{
				type = 3,
				value = 1,
				cooldownTimeLeft = 0,
				reference = 7882,
				totalCooldownTime = 180,
			},
		},
		iLevel = 15,
		type = 31,
		boundToPlayer = false,
		numEnhancementSlots = 0,
		id = 716,
		dps = 0,
		craftingBonus = 
		{
		},
		trophyLocIndex = 1,
		careers = 
		{
		},
		itemSet = 0,
		enhSlot = 
		{
		},
		noChargeLeftDontDelete = 0,
		slots = 
		{
		},
		armor = 0,
		stackCount = 1,
		--cooldownTimeLeft = 0,
		timeLeftBeforeDecay = 0,
		timestamp = 0,
		decayPaused = false,
	},
	
	{
		description = L"",
		renown = 0,
		maxEquip = 0,
		isNew = false,
		equipSlot = 0,
		races = 
		{
			2,
			3,
			5,
			7,
		},
		tintB = 0,
		speed = 0,
		cultivationType = 0,
		craftingSkillRequirement = 0,
		iconNum = 370,
		rarity = 4,
		marketingVariation = 0,
		flags = 
		{
			false,
			true,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false, 
			false, 
			[0] = false,
		},
		name = L"Screaming Skul",
		broken = false,
		skills = 
		{
		},
		marketingIndex = 0,
		uniqueID = 207104,
		blockRating = 0,
		sellPrice = 0,
		slots = 
		{
		},
		level = 0,
		armor = 0,
		dyeTintB = 0,
		currChargesRemaining = 0,
		trophyLocation = 1,
		dyeTintA = 0,
		iLevel = 0,
		bonus = 
		{
		},
		enhSlot = 
		{
		},
		type = 24,
		boundToPlayer = false,
		numEnhancementSlots = 0,
		id = 7341,
		dps = 0,
		craftingBonus = 
		{
		},
		trophyLocIndex = 1,
		careers = 
		{
		},
		bop = true,
		itemSet = 0,
		noChargeLeftDontDelete = 0,
		stackCount = 1,
		--cooldownTimeLeft = 0,
		isRefinable = false,
		tintA = 0,
		timeLeftBeforeDecay = 0,
		timestamp = 0,
		decayPaused = false,
	},
	
	{
		description = L"",
		renown = 0,
		maxEquip = 0,
		isNew = false,
		equipSlot = 0,
		races = 
		{
		},
		tintB = 0,
		speed = 0,
		cultivationType = 0,
		craftingSkillRequirement = 0,
		iconNum = 475,
		rarity = 4,
		marketingVariation = 0,
		flags = 
		{
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false, 
			false, 
			[0] = false,
		},
		name = L"Blazing Orange Dye",
		broken = false,
		skills = 
		{
		},
		marketingIndex = 0,
		uniqueID = 188920,
		blockRating = 0,
		sellPrice = 20000,
		slots = 
		{
		},
		level = 0,
		armor = 0,
		dyeTintB = 0,
		currChargesRemaining = 0,
		trophyLocation = 0,
		dyeTintA = 0,
		iLevel = 1,
		bonus = 
		{
		},
		enhSlot = 
		{
		},
		type = 27,
		boundToPlayer = false,
		numEnhancementSlots = 0,
		id = 713,
		dps = 0,
		craftingBonus = 
		{
		},
		trophyLocIndex = 1,
		careers = 
		{
		},
		bop = false,
		itemSet = 0,
		noChargeLeftDontDelete = 0,
		stackCount = 1,
		--cooldownTimeLeft = 0,
		isRefinable = false,
		tintA = 0,
		timeLeftBeforeDecay = 0,
		timestamp = 0,
		decayPaused = false,
	},
	
	{
		description = L"This very special ingredient can be used to create hybrid potions.",
		renown = 0,
		maxEquip = 0,
		isNew = false,
		equipSlot = 0,
		races = 
		{
		},
		tintB = 0,
		speed = 0,
		cultivationType = 0,
		craftingSkillRequirement = 200,
		iconNum = 20391,
		rarity = 4,
		marketingVariation = 0,
		flags = 
		{
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			true,
			false,
			false, 
			false, 
			[0] = false,
		},
		name = L"Black Hellebore",
		broken = false,
		skills = 
		{
		},
		marketingIndex = 0,
		uniqueID = 199851,
		blockRating = 0,
		sellPrice = 0,
		slots = 
		{
		},
		level = 0,
		armor = 0,
		dyeTintB = 0,
		currChargesRemaining = 0,
		trophyLocation = 0,
		dyeTintA = 0,
		iLevel = 39,
		bonus = 
		{
		},
		enhSlot = 
		{
		},
		type = 0,
		boundToPlayer = false,
		numEnhancementSlots = 0,
		id = 4739,
		dps = 0,
		craftingBonus = 
		{
			
			{
				bonusValue = 4,
				bonusReference = 5,
				bonusType = 6,
			},
			
			{
				bonusValue = 2,
				bonusReference = 8,
				bonusType = 6,
			},
			
			{
				bonusValue = 200,
				bonusReference = 9,
				bonusType = 6,
			},
			
			{
				bonusValue = 21,
				bonusReference = 6,
				bonusType = 6,
			},
			
			{
				bonusValue = 65511,
				bonusReference = 1,
				bonusType = 6,
			},
			
			{
				bonusValue = 1,
				bonusReference = 2,
				bonusType = 6,
			},
			
			{
				bonusValue = 1,
				bonusReference = 15,
				bonusType = 6,
			},
		},
		trophyLocIndex = 1,
		careers = 
		{
		},
		bop = false,
		itemSet = 0,
		noChargeLeftDontDelete = 0,
		stackCount = 1,
		--cooldownTimeLeft = 0,
		isRefinable = false,
		tintA = 0,
		timeLeftBeforeDecay = 0,
		timestamp = 0,
		decayPaused = false,
	},
	
	{
		description = L"A magically-imbued watering can, used to enhance the cultivation process.",
		renown = 0,
		maxEquip = 0,
		isNew = false,
		equipSlot = 0,
		races = 
		{
		},
		tintB = 0,
		speed = 0,
		cultivationType = 3,
		craftingSkillRequirement = 200,
		iconNum = 20472,
		rarity = 5,
		marketingVariation = 0,
		flags = 
		{
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			[0] = false,
		},
		name = L"Charm-Laden, Watering | Can",
		broken = false,
		skills = 
		{
		},
		marketingIndex = 0,
		uniqueID = 184957,
		dyeTintA = 0,
		blockRating = 0,
		trophyLocation = 0,
		level = 0,
		tintA = 0,
		currChargesRemaining = 0,
		dyeTintB = 0,
		bop = false,
		sellPrice = 682,
		bonus = 
		{
		},
		iLevel = 39,
		type = 34,
		boundToPlayer = false,
		numEnhancementSlots = 0,
		id = 5168,
		dps = 0,
		craftingBonus = 
		{
			
			{
				bonusValue = 50,
				bonusReference = 10,
				bonusType = 6,
			},
			
			{
				bonusValue = 1,
				bonusReference = 11,
				bonusType = 6,
			},
			
			{
				bonusValue = 35,
				bonusReference = 12,
				bonusType = 6,
			},
			
			{
				bonusValue = 0,
				bonusReference = 13,
				bonusType = 6,
			},
			
			{
				bonusValue = 9,
				bonusReference = 14,
				bonusType = 6,
			},
			
			{
				bonusValue = 200,
				bonusReference = 9,
				bonusType = 6,
			},
		},
		trophyLocIndex = 1,
		careers = 
		{
		},
		itemSet = 0,
		enhSlot = 
		{
		},
		noChargeLeftDontDelete = 0,
		slots = 
		{
		},
		armor = 0,
		stackCount = 1,
		--cooldownTimeLeft = 0,
		isRefinable = false,
		timeLeftBeforeDecay = 0,
		timestamp = 0,
		decayPaused = false,
	},
	
	{
		isRefinable = false,
		description = L"It looks as if this item may yet retain some power- perhaps it could be used in a charm, that improves Strength.",
		renown = 0,
		maxEquip = 0,
		isNew = false,
		equipSlot = 0,
		races = 
		{
		},
		tintB = 0,
		speed = 0,
		cultivationType = 0,
		craftingSkillRequirement = 200,
		iconNum = 602,
		rarity = 4,
		marketingVariation = 0,
		flags = 
		{
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			[0] = false,
		},
		name = L"Fierce Mighty Wreck",
		broken = false,
		skills = 
		{
		},
		marketingIndex = 0,
		uniqueID = 908795,
		dyeTintA = 0,
		blockRating = 0,
		trophyLocation = 0,
		level = 0,
		tintA = 0,
		currChargesRemaining = 0,
		dyeTintB = 0,
		bop = false,
		sellPrice = 100,
		bonus = 
		{
		},
		iLevel = 0,
		type = 34,
		boundToPlayer = false,
		numEnhancementSlots = 0,
		id = 3896,
		dps = 0,
		craftingBonus = 
		{
			
			{
				bonusValue = 5,
				bonusReference = 5,
				bonusType = 6,
			},
			
			{
				bonusValue = 14,
				bonusReference = 8,
				bonusType = 6,
			},
			
			{
				bonusValue = 200,
				bonusReference = 9,
				bonusType = 6,
			},
			
			{
				bonusValue = 36,
				bonusReference = 2,
				bonusType = 6,
			},
			
			{
				bonusValue = 39,
				bonusReference = 6,
				bonusType = 6,
			},
		},
		trophyLocIndex = 1,
		careers = 
		{
		},
		itemSet = 0,
		enhSlot = 
		{
		},
		noChargeLeftDontDelete = 0,
		slots = 
		{
		},
		armor = 0,
		stackCount = 1,
		--cooldownTimeLeft = 0,
		timeLeftBeforeDecay = 0,
		timestamp = 0,
		decayPaused = false,
	},
	
	{
		description = L"Use to return to your rally point. You can set your rally point by talking to the Rally Master in any chapter area.",
		renown = 0,
		maxEquip = 1,
		isNew = false,
		equipSlot = 0,
		races = 
		{
		},
		tintB = 0,
		speed = 0,
		cultivationType = 0,
		craftingSkillRequirement = 0,
		iconNum = 327,
		rarity = 6,
		marketingVariation = 0,
		flags = 
		{
			false,
			true,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			true,
			true,
			false, 
			false, 
			[0] = false,
		},
		name = L"Book of Binding",
		broken = false,
		skills = 
		{
		},
		marketingIndex = 0,
		uniqueID = 11919,
		blockRating = 0,
		sellPrice = 0,
		slots = 
		{
		},
		level = 0,
		armor = 0,
		dyeTintB = 0,
		currChargesRemaining = 0,
		trophyLocation = 0,
		dyeTintA = 0,
		iLevel = 0,
		bonus = 
		{
			[1] = 
			{
				type = 3,
				value = 0,
				cooldownTimeLeft = 0,
				reference = 246,
				totalCooldownTime = 3600,
			},
		},
		enhSlot = 
		{
		},
		type = 0,
		boundToPlayer = false,
		numEnhancementSlots = 0,
		id = 531,
		dps = 0,
		craftingBonus = 
		{
		},
		trophyLocIndex = 1,
		careers = 
		{
		},
		bop = true,
		itemSet = 0,
		noChargeLeftDontDelete = 0,
		stackCount = 1,
		--cooldownTimeLeft = 0,
		isRefinable = false,
		tintA = 0,
		timeLeftBeforeDecay = 0,
		timestamp = 0,
		decayPaused = false,
	},
	
	{
		description = L"This item will summon your mighty steed. To dismount, activate the item.",
		renown = 0,
		maxEquip = 0,
		isNew = false,
		equipSlot = 0,
		races = 
		{
		},
		tintB = 0,
		speed = 0,
		cultivationType = 0,
		craftingSkillRequirement = 0,
		iconNum = 20216,
		rarity = 2,
		marketingVariation = 0,
		flags = 
		{
			false,
			true,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			true,
			false, 
			false, 
			[0] = false,
		},
		name = L"Black Marked Steed",
		broken = false,
		skills = 
		{
		},
		marketingIndex = 0,
		uniqueID = 186825,
		blockRating = 0,
		sellPrice = 60000,
		slots = 
		{
		},
		level = 20,
		armor = 0,
		dyeTintB = 0,
		currChargesRemaining = 0,
		trophyLocation = 0,
		dyeTintA = 0,
		iLevel = 1,
		bonus = 
		{
			[1] = 
			{
				type = 3,
				value = 0,
				cooldownTimeLeft = 0,
				reference = 14624,
				totalCooldownTime = 0,
			},
		},
		enhSlot = 
		{
		},
		type = 0,
		boundToPlayer = false,
		numEnhancementSlots = 0,
		id = 5662,
		dps = 0,
		craftingBonus = 
		{
		},
		trophyLocIndex = 1,
		careers = 
		{
			13,
			14,
			15,
		},
		bop = true,
		itemSet = 0,
		noChargeLeftDontDelete = 0,
		stackCount = 1,
		--cooldownTimeLeft = 0,
		isRefinable = false,
		tintA = 0,
		timeLeftBeforeDecay = 0,
		timestamp = 0,
		decayPaused = false,
	},
}
