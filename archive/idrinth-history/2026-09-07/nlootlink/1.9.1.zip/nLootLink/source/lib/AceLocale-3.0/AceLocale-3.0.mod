<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
	<UiMod name="AceLocale-3.0" version="3.0">

		<VersionSettings gameVersion="1.3.0" windowsVersion="1.0" savedVariablesVersion="1.0" />

		<Dependencies/>

		<Files>
			<File name="../LibStub/LibStub.lua" />
			<File name="AceLocale-3.0.lua" />
		</Files>

		<OnInitialize/>

		<OnUpdate/>

		<OnShutdown/>

		<SavedVariables/>

	</UiMod>
</ModuleFile>
