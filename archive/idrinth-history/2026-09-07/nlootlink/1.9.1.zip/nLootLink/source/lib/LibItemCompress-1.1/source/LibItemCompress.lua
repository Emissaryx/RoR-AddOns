-- library creation
local MAJOR, MINOR = "LibItemCompress-1.1", 1
local LibItemCompress, oldminor = LibStub:NewLibrary(MAJOR, MINOR)
if not LibItemCompress then return end

local specialPlaceholders = {
	[L"&"] = L"%^1%^",
	[L"#"] = L"%^2%^",
	[L"|"] = L"%^3%^",
	[L","] = L"%^4%^",
}
local numberKeys = {
	"flagsComp",
	"miscFlagsComp",
	"uniqueID",
	"id",
	"iconNum",
	"sellPrice",
	"itemSet",
	"rarity",
	"type",
	"level",
	"renown",
	"iLevel",
	"equipSlot",
	"maxEquip",
	"tintA",
	"tintB",
	"dyeTintA",
	"dyeTintB",
	"dps",
	"speed",
	"armor",
	"blockRating",
	"trophyLocIndex",
	"stackCount",
	"craftingSkillRequirement",
	"cultivationType",
	"marketingIndex",
	"marketingVariation",
	"numEnhancementSlots",
	"noChargeLeftDontDelete",
	"trophyLocation",
	"currChargesRemaining",
}
local unstoredNumberKeys = {
	"timeLeftBeforeDecay",
	"timestamp",
}
local wstrKeys = {
	"name",
	"description",
}
local intTableKeys = {
	"races",
	"skills",
	"careers",
}
local unstoredTableKeys = {
	"slots",
	"enhSlot",
}
local bonusTables = {
	{
		name = "bonus",
		keys = {
			"type",
			"duration",
			"value",
			"cooldownTimeLeft",
			"reference",
			"totalCooldownTime",
		},
	},
	{
		name = "craftingBonus",
		keys = {
			"bonusValue",
			"bonusReference",
			"bonusType",
		},
	},
}
local unstoredFlagKeys = {
	"decayPaused",
}

-- compress a flags table, returning an integer
local function compressFlags(flags)
	if type(flags) ~= "table" then
		return 0
	end
	local val, pow = 0, 1
	for i = 0, 15 do
		if flags[i] then
			val = val + pow
		end
		pow = pow * 2
	end
	return val
end

-- uncompress a flags value, returning a table
local function uncompressFlags(valStr)
	local flags = {}
	local val = tonumber(valStr)
	if type(val) ~= "number" then
		val = 0
	end
	for i = 0, 16 do
		flags[i] = val%2 == 1
		val = math.floor(val/2)
	end
	return flags
end

-- compress miscellaneous itemData flags, returning an integer
local function compressMiscFlags(itemData)
	local val = 0
	if type(itemData) ~= "table" then
		return 0
	end
	if itemData.isNew then
		val = val + 1
	end
	if itemData.broken then
		val = val + 2
	end
	if itemData.bop then
		val = val + 4
	end
	if itemData.boundToPlayer then
		val = val + 8
	end
	if itemData.isRefinable then
		val = val + 16
	end
	return val
end

-- uncompress miscellaneous itemData flags, setting the values in itemData
local function uncompressMiscFlags(valStr, itemData)
	local val = tonumber(valStr)
	if type(val) ~= "number" then
		val = 0
	end
	if type(itemData) == "table" then
		itemData.isNew = val%2 == 1
		val = math.floor(val/2)
		itemData.broken = val%2 == 1
		val = math.floor(val/2)
		itemData.bop = val%2 == 1
		val = math.floor(val/2)
		itemData.boundToPlayer = val%2 == 1
		val = math.floor(val/2)
		itemData.isRefinable = val%2 == 1
	end
end

-- compress an itemData table, returning a wstring
function LibItemCompress.compressItemData(itemData)
	if type(itemData) ~= "table" then
		itemData = {}
	end

	local subTableCompressed, val
	local itemDataCompressed = L""

	-- compress the binary attributes, storing in placeholders
	itemData.flagsComp = compressFlags(itemData.flags)
	itemData.miscFlagsComp = compressMiscFlags(itemData)

	-- concatenate wstring values, replacing any commas
	for _, key in ipairs(wstrKeys) do
		val = itemData[key]
		if val then
			if val:len() > 0 then
				for specialChar, placeholder in pairs(specialPlaceholders) do
					val = val:gsub(specialChar, placeholder)
				end
			end
			itemDataCompressed = itemDataCompressed..val..L","
		else
			itemDataCompressed = itemDataCompressed..L","
		end	
	end

	-- concatenate encoded integer tables
	for i, key in ipairs(intTableKeys) do
		subTableCompressed = L""
		subTableName = intTableKeys[i]
		if itemData[subTableName] then
			for key, val in pairs(itemData[subTableName]) do
				subTableCompressed = subTableCompressed..towstring(key)..L"|"..towstring(val)..L"|"
			end
			itemDataCompressed = itemDataCompressed..subTableCompressed..L"#"
		else
			itemDataCompressed = itemDataCompressed..L"#"
		end
	end

	-- concatenate bonus and craftingBonus tables
	for _, bonusTable in ipairs(bonusTables) do
		if itemData[bonusTable.name] then
			for i, bonus in pairs(itemData[bonusTable.name]) do
				itemDataCompressed = itemDataCompressed..tonumber(i)..L"|"
				for _, key in ipairs(bonusTable.keys) do
					if bonus[key] then
						itemDataCompressed = itemDataCompressed..tonumber(bonus[key])..L"|"
					else
						itemDataCompressed = itemDataCompressed..L"|"
					end
				end
			end
		end
		itemDataCompressed = itemDataCompressed..L"&"
	end

	-- concatenate number values
	for _, key in ipairs(numberKeys) do
		val = itemData[key]
		if val == 0 or val == nil then
			itemDataCompressed = itemDataCompressed..L"*"
		else
			itemDataCompressed = itemDataCompressed..towstring(val)..L"*"
		end
	end

	-- delete the binary attribute placeholders
	itemData.flagsComp = nil
	itemData.miscFlagsComp = nil

	return itemDataCompressed
end

-- uncompress a wstring, returning an itemData table
function LibItemCompress.uncompressItemData(itemDataComp)
	local i, j, subTableName, bonusComp, bonus, bonusTable, bonusTableKey
	local itemData = {}

	if type(itemDataComp) ~= "wstring" then
		itemDataComp = L""
	end

	-- retrieve wstring values, replacing any special character placeholders
	i = 1
	for val in itemDataComp:gmatch(L"([^,]-),") do
		if val:len() > 0 then
			for specialChar, placeholder in pairs(specialPlaceholders) do
				val = val:gsub(placeholder, specialChar)
			end
		end
		if wstrKeys[i] then
			itemData[wstrKeys[i]] = val
		end
		i = i + 1
	end
	for _, key in ipairs(wstrKeys) do
		if itemData[key] == nil then
			itemData[key] = L""
		end
	end

	-- retrieve integer tables
	i = 1
	for subTableComp in itemDataComp:gmatch(L"([%d|]-)#") do
		subTableName = intTableKeys[i]
		if subTableName then
			itemData[subTableName] = {}
			for key, val in subTableComp:gmatch(L"(%d+)|(%d+)|") do
				itemData[subTableName][tonumber(key)] = tonumber(val)
			end
		end
		i = i + 1
	end
	for _, tableName in ipairs(intTableKeys) do
		if itemData[tableName] == nil then
			itemData[tableName] = {}
		end
	end

	-- retrieve bonus and craftingBonus tables
	i = 1
	for bonusComp in itemDataComp:gmatch(L"([%d|]-)&") do
		bonusTable = bonusTables[i]
		if bonusTable then
			itemData[bonusTable.name] = {}
			j = 0
			for val in bonusComp:gmatch(L"([%d]-)|") do
				if j == 0 then
					bonus = {}
					bonusTableKey = tonumber(val)
				elseif val ~= L"" then
					bonus[bonusTable.keys[j]] = tonumber(val)
				end
				j = j + 1
				if j > #(bonusTable.keys) then
					itemData[bonusTable.name][bonusTableKey] = bonus
					j = 0
				end
			end
		end
		i = i + 1
	end
	for _, bonusTable in ipairs(bonusTables) do
		if itemData[bonusTable.name] == nil then
			itemData[bonusTable.name] = {}
		end
	end

	-- retrieve number values
	i = 1
	for val in itemDataComp:gmatch(L"([%d%.]-)*") do
		if numberKeys[i] then
			if val == L"" then
				itemData[numberKeys[i]] = 0
			else
				itemData[numberKeys[i]] = tonumber(val)
			end
		end
		i = i + 1
	end
	for _, key in ipairs(numberKeys) do
		if itemData[key] == nil then
			itemData[key] = 0
		end
	end
	
	-- set any zero number values
	for _, key in ipairs(unstoredNumberKeys) do
		itemData[key] = 0
	end

	-- instantiate empty tables
	for _, key in ipairs(unstoredTableKeys) do
		itemData[key] = {}
	end

	-- uncompress binary values
	itemData.flags = uncompressFlags(itemData.flagsComp)
	uncompressMiscFlags(itemData.miscFlagsComp, itemData)
	
	-- set any unstored flags
	for _, key in ipairs(unstoredFlagKeys) do
		itemData[key] = false
	end

	-- delete the placeholders
	itemData.flagsComp = nil
	itemData.miscFlagsComp = nil

	return itemData
end

-- get unused number keys
function LibItemCompress.getUnstoredNumberKeys()
	return unstoredNumberKeys
end

-- get unused table keys
function LibItemCompress.getUnstoredTableKeys()
	return unstoredTableKeys
end

-- get unused number keys
function LibItemCompress.getUnstoredFlagKeys()
	return unstoredFlagKeys
end
