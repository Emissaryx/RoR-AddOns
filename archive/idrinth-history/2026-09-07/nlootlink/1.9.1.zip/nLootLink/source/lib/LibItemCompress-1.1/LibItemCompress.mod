<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
	<UiMod name="LibItemCompress-1.1" version="1.1.1-release">

		<Author name="nemes" />

		<Description text="Library to compress an itemData table into a wstring" />

		<VersionSettings gameVersion="1.3.0" windowsVersion="1.0" savedVariablesVersion="1.0" />

		<Dependencies/>

		<Files>
			<File name="source/lib/LibStub.lua" />
			<File name="source/LibItemCompress.lua" />
			<!-- <File name="source/LibItemCompressTest.lua" /> -->
		</Files>

		<OnInitialize/>

		<OnUpdate/>

		<OnShutdown/>

		<SavedVariables/>

	</UiMod>
</ModuleFile>
