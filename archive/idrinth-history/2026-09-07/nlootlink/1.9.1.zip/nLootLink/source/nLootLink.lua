-- members
nLootLink.initComplete = false

-- local variables
local doDebug = false


--
-- initialisation functions
--

-- called by nLootLinkData when it is ready
function nLootLink.init()
	if doDebug then d("nLootLink.init START") end

	nLootLinkGUI.init()
	nLootLinkGatherer.init()
	nLootLinkComm.init()

	nLootLink.initComplete = true

	if doDebug then d("nLootLink.init END") end
end
