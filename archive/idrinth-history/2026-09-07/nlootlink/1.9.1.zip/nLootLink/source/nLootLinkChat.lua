nLootLinkChat = {}

-- libraries
local T = LibStub("WAR-AceLocale-3.0"):GetLocale("nLootLink")

-- local constants
local ITEM_TAG = L"ITEM:" -- from chathyperlinking.lua
local PLAYER_TAG = L"PLAYER:" -- from chathyperlinking.lua

-- global constants
local SLASH_TOGGLE = nLootLink.SLASH_TOGGLE

-- local variables
local doDebug = false


--
-- initialisation functions
--

-- initialise function for the entire addon
function nLootLinkChat.init()
	doDebug = nLootLink.DEBUG
	if doDebug then d("nLootLinkChat.init START") end

	nLootLinkChat.initEvents()
	nLootLinkChat.initHooks()

	if doDebug then d("nLootLinkChat.init END") end
end

-- register for events
function nLootLinkChat.initEvents()
	RegisterEventHandler(SystemData.Events.CHAT_TEXT_ARRIVED, "nLootLinkChat.CHAT_TEXT_ARRIVED")
end

-- hook external functions
function nLootLinkChat.initHooks()
	nLootLinkChat.hooked = {}

	-- hook chat entry box enter
    nLootLinkChat.hooked.EA_ChatWindow_OnKeyEnter = EA_ChatWindow.OnKeyEnter
    EA_ChatWindow.OnKeyEnter = nLootLinkChat.EA_ChatWindow_OnKeyEnter

	-- game's internal item DB
	nLootLinkChat.hooked.getDatabaseItemData = GetDatabaseItemData
	GetDatabaseItemData = nLootLinkChat.getDatabaseItemData
end


--
-- events
--

-- chat message arrived
function nLootLinkChat.CHAT_TEXT_ARRIVED()

	if nLootLink.initComplete then
		local linkID = GameData.ChatData.text:match(L"\""..ITEM_TAG..L"(%d+)\"")
		linkID = tonumber(linkID)
	
		-- message contains a link - do we know about it?
		if type(linkID) == "number" then
	
			-- try to get the itemdata from the game's cache
			local itemData = nLootLinkChat.hooked.getDatabaseItemData(linkID)
			if itemData then
	
				-- update the data
				nLootLinkData.upsertItem(itemData)
				if doDebug then d("nLootLinkChat.CHAT_TEXT_ARRIVED found the item in the game cache") end
	
			-- removed, as links we don't know about are from other nLootLink users, who will publish it anyway
			--[[-- try to get the itemdata from nLootLink
		elseif not nLootLinkData.getItemDataComp(linkID) then

			-- request the item data from the public channel
			nLootLinkComm.request(linkID)
			if doDebug then d("nLootLinkChat.CHAT_TEXT_ARRIVED couldn't find the item; requesting") end]]--
			end
	
		end
	end
end


--
-- hooked functions
--

-- pre-hook for chat entry box
function nLootLinkChat.EA_ChatWindow_OnKeyEnter(...)
	local input = EA_TextEntryGroupEntryBoxTextInput.Text:lower()

	if input:sub(1, 1) == L"/" then
		for _, cmd in ipairs(SLASH_TOGGLE) do 
			if input:match(cmd) then
				nLootLinkUtil.toggleShowing()
				EA_TextEntryGroupEntryBoxTextInput.Text = L""
			end
		end
	end

	return nLootLinkChat.hooked.EA_ChatWindow_OnKeyEnter(...)
end

-- retrieve from the nLootLinkDB if the game's database doesn't have the item
function nLootLinkChat.getDatabaseItemData(uniqueID)

	-- attempt to retrieve from the game engine
	local itemData = nLootLinkChat.hooked.getDatabaseItemData(uniqueID)

	if nLootLink.initComplete then
		if not itemData then

			-- retrieve from the nLootLink database
			itemData = nLootLinkData.getItemData(uniqueID)
		end
	end

	return itemData
end


--
-- utility functions
--

-- create an item link
function nLootLinkChat.createItemLink(itemData)
	local colour = DataUtils.GetItemRarityColor(itemData)
	return CreateHyperLink(ITEM_TAG..itemData.uniqueID, L"["..itemData.name..L"]", {colour.r, colour.g, colour.b}, {})
end

-- create a player link
function nLootLinkChat.createPlayerLink(playerName)
	return CreateHyperLink(PLAYER_TAG..playerName, L"["..playerName..L"]", {}, {})
end
