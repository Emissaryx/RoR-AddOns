nLootLinkGUI = {}

-- libraries
local T = LibStub("WAR-AceLocale-3.0"):GetLocale("nLootLink")

-- local constants
local FORMAT_RESULT_COUNT = L"%d / %d"
local FORMAT_RESULT_DEN = L"%d+$"
local SORT_TYPE_BUTTON_NAME = "nLootLinkGUIHeaderType"
local SORT_TYPE_DEFAULT = T["Type"]
local SORT_TYPE_CRAFTING_LEVEL = T["Skill"]

-- global constants
local DEFAULT_FIELDS = nLootLink.DEFAULT_FIELDS
local CATEGORIES = nLootLink.CATEGORIES
local STATS = nLootLink.STATS
local CAREERS_ORDER = nLootLink.CAREERS_ORDER
local CAREERS_DESTRUCTION = nLootLink.CAREERS_DESTRUCTION
local CAREER_RACES = nLootLink.CAREER_RACES
local CAREER_SKILLS = nLootLink.CAREER_SKILLS
local WINDOW_NAME = nLootLink.WINDOW_NAME
local WINDOW_TITLE = nLootLink.WINDOW_TITLE
local CHOICE_ANY_VALUE = nLootLink.CHOICE_ANY_VALUE

-- local member aliases
local listData = false

-- local variables
local doDebug = false
local sortOrder = false
local choiceRarity = {}
local choiceCategory = {}
local choiceType = {}
local choiceSlot = {}
local choiceStat = {}
local choiceCareer = {}
local choiceCrafting = {}

local sortTypes = {
	{
		name = "name",
		button = "nLootLinkGUIHeaderName",
		desc = T["Name"],
		func = function(a, b) return WStringsCompare(a.name, b.name) end,
	},
	{
		name = "type",
		button = SORT_TYPE_BUTTON_NAME,
		desc = SORT_TYPE_DEFAULT,
		func = function(a, b)
			return WStringsCompare(a.typeTextCraftingSortable or a.typeText, b.typeTextCraftingSortable or b.typeText)
		end,
	},
	{
		name = "rarity",
		button = "nLootLinkGUIHeaderRarity",
		desc = T["Rarity"],
		func = function(a, b)
			if a.rarity == b.rarity then
				return 0
			elseif a.rarity > b.rarity then
				return 1
			else
				return -1
			end
		end,
	},
	{
		name = "rank",
		button = "nLootLinkGUIHeaderRank",
		desc = T["Rank"],
		func = function(a, b)
			if a.level == b.level then
				return 0
			elseif a.level > b.level then
				return 1
			else
				return -1
			end
		end,
	},
	{
		name = "renown",
		button = "nLootLinkGUIHeaderRenown",
		desc = T["Renown"],
		func = function(a, b)
			if a.renown == b.renown then
				return 0
			elseif a.renown > b.renown then
				return 1
			else
				return -1
			end
		end,
	},
}


--
-- initialisation functions
--

-- initialise the entire GUI
function nLootLinkGUI.init()
	doDebug = nLootLink.DEBUG
	if doDebug then d("nLootLinkGUI.init START") end

	listData = nLootLinkData.listData

	nLootLinkGUI.initWindow()
	nLootLinkGUI.initLabels()
	nLootLinkGUI.initButtons()
	nLootLinkGUI.initSort()
	nLootLinkGUI.initSearchFields()
	nLootLinkGUI.initList()

	nLootLinkGUI.resetSearchFields()

	if nRarity and nRarity.nLL then
		nRarity.nLL:init()
	end

	if doDebug then d("nLootLinkGUI.init END") end
end

-- initialise the main window
function nLootLinkGUI.initWindow()

	-- create the window, but don't show it
	CreateWindow(WINDOW_NAME, false)
	WindowSetMovable(WINDOW_NAME, true)
	LabelSetText(WINDOW_NAME.."TitleBarText", WINDOW_TITLE)
end

-- create any static labels
function nLootLinkGUI.initLabels()
	LabelSetText(WINDOW_NAME.."Version", towstring(nLootLink.VERSION))
	nLootLinkGUI.setCount(0, #listData)
	LabelSetText(WINDOW_NAME.."FilterUsableLabel", T["Usable"])
	LabelSetText(WINDOW_NAME.."FilterSetItemLabel", T["Set Items"])
	LabelSetText(WINDOW_NAME.."FilterRankHeader", T["Rank"])
	LabelSetText(WINDOW_NAME.."FilterRankSeparator", L"-")
	LabelSetText(WINDOW_NAME.."FilterRenownHeader", T["Renown"])
	LabelSetText(WINDOW_NAME.."FilterRenownSeparator", L"-")
	LabelSetText(WINDOW_NAME.."FilterCraftingLevelHeader", T["Crafting Level"])
	LabelSetText(WINDOW_NAME.."FilterCraftingLevelSeparator", L"-")

	for row = 1, nLootLinkGUIList.numVisibleRows do
		EA_Window_Backpack.ColorLabelIfMeetsRequirements(WINDOW_NAME.."ListRow"..row.."ItemSubType", true, true)
	end
end

-- create buttons
function nLootLinkGUI.initButtons()

	-- search
	ButtonSetText(WINDOW_NAME.."FilterSearchButton", T["Search"])

	-- options
	ButtonSetText(WINDOW_NAME.."FilterOptionsButton", T["Options"])

	-- reset
	ButtonSetText(WINDOW_NAME.."FilterResetButton", T["Reset"])

	-- bind radio butons
	LabelSetText(WINDOW_NAME.."FilterBindAnyLabel", T["All"])
	LabelSetText(WINDOW_NAME.."FilterBindOnPickupLabel", T["BOP"])
	LabelSetText(WINDOW_NAME.."FilterBindOnEquipLabel", T["BOE"])
	ButtonSetCheckButtonFlag(WINDOW_NAME.."FilterBindAnyButton", true)
	ButtonSetCheckButtonFlag(WINDOW_NAME.."FilterBindOnPickupButton", true)
	ButtonSetCheckButtonFlag(WINDOW_NAME.."FilterBindOnEquipButton", true)
end

-- initialise sorting GUI and order
function nLootLinkGUI.initSort()

	for _, sort in ipairs(sortTypes) do
		ButtonSetText(sort.button, sort.desc)
	end

	nLootLinkGUI.enableSorts()
end

-- initialise any search criteria
function nLootLinkGUI.initSearchFields()

	-- rarity
	choiceRarity = {}
	for _, rarity in pairs(SystemData.ItemRarity) do
		if rarity >= nLootLinkOptions.getMinRarity() then
			table.insert(choiceRarity, { text = GameDefs.ItemRarity[rarity].desc, value = rarity, isSelected = false, })
		end
	end
	table.sort(choiceRarity, function(a, b) return a.value < b.value end)
	table.insert(choiceRarity, 1, { text = T["Any Rarity"], value = CHOICE_ANY_VALUE, isSelected = nil, })
	nLootLinkUtil.setComboBoxChoices(WINDOW_NAME.."FilterRarity", choiceRarity)

	-- category
	choiceCategory = {}
	table.insert(choiceCategory, { text = T["Any Category"], value = CHOICE_ANY_VALUE, isSelected = nil, })
	for i, category in ipairs(CATEGORIES) do
		table.insert(choiceCategory, { text = category.name, value = i, isSelected = nil, })
	end
	nLootLinkUtil.setComboBoxChoices(WINDOW_NAME.."FilterCategory", choiceCategory)

	-- type
	nLootLinkGUI.populateTypeCombo()

	-- slot
	nLootLinkGUI.populateSlotCombo()

	-- stat
	choiceStat = {}
	table.insert(choiceStat, { text = T["Any Stat"], value = CHOICE_ANY_VALUE, isSelected = nil, })
	for i, stat in ipairs(STATS) do
		table.insert(choiceStat, { text = BonusTypes[stat].name, value = stat, isSelected = false })
	end
	nLootLinkUtil.setComboBoxChoices(WINDOW_NAME.."FilterStat", choiceStat)

	-- career
	local choiceCareerOrder = {}
	for _, career in ipairs(CAREERS_ORDER) do
		table.insert(choiceCareerOrder, { text = CareerNames[career].name, value = career, isSelected = false })
	end
	table.sort(choiceCareerOrder, function(a, b) return a.text < b.text end)
	local choiceCareerDestro = {}
	for _, career in ipairs(CAREERS_DESTRUCTION) do
		table.insert(choiceCareerDestro, { text = CareerNames[career].name, value = career, isSelected = false })
	end
	table.sort(choiceCareerDestro, function(a, b) return a.text < b.text end)
	choiceCareer = {}
	table.insert(choiceCareer, { text = T["Any Career"], value = CHOICE_ANY_VALUE, isSelected = nil, })
	if GameData.Player.realm == 1 then
		for i, v in ipairs(choiceCareerOrder) do
			table.insert(choiceCareer, DataUtils.CopyTable(v))
		end
		for i, v in ipairs(choiceCareerDestro) do
			table.insert(choiceCareer, DataUtils.CopyTable(v))
		end
	else
		for i, v in ipairs(choiceCareerDestro) do
			table.insert(choiceCareer, DataUtils.CopyTable(v))
		end
		for i, v in ipairs(choiceCareerOrder) do
			table.insert(choiceCareer, DataUtils.CopyTable(v))
		end
	end
	nLootLinkUtil.setComboBoxChoices(WINDOW_NAME.."FilterCareer", choiceCareer)

	-- type
	nLootLinkGUI.populateCraftingCombo()
end

-- initialise the result list
function nLootLinkGUI.initList()
	local colour, rowBackground

	-- set even rows to background colour, odd to greyish
	for row = 1, nLootLinkGUIList.numVisibleRows do
		colour = GameDefs.RowColors[math.mod(row, 2)]
		rowBackground = WINDOW_NAME.."ListRow"..row.."Background"

		WindowSetTintColor(rowBackground, colour.r, colour.g, colour.b)
        WindowSetAlpha(rowBackground, colour.a)
	end

	-- empty the list
	ListBoxSetDisplayOrder(WINDOW_NAME.."List", {})
end


--
-- GUI event functions
--

-- toggle loot link window visibility
function nLootLinkGUI.toggleShowing()
	WindowUtils.ToggleShowing(WINDOW_NAME)
end

-- window shown
function nLootLinkGUI.onShown()
	WindowUtils.OnShown(function() end, WindowUtils.Cascade.MODE_AUTOMATIC)

	-- update the list size as it might have changed since last showing
	nLootLinkGUI.updateCountTotal(#listData)
end

-- window hidden
function nLootLinkGUI.onHidden()
	WindowUtils.OnHidden()
end

-- right click on window
function nLootLinkGUI.onRButtonUp()
	EA_Window_ContextMenu.CreateDefaultContextMenu(WINDOW_NAME)
end

-- click an icon
function nLootLinkGUI.itemMouseDownL(flags)
	if flags == SystemData.ButtonFlags.SHIFT then
		local activeWindowName = SystemData.ActiveWindow.name
		if activeWindowName then
			local rowIdx = WindowGetId(activeWindowName)
			if rowIdx then
				local dataIdx = ListBoxGetDataIndex(WINDOW_NAME.."List", rowIdx)
				if dataIdx then
					local partialItemData = listData[dataIdx]
					if partialItemData then
						local uniqueID = partialItemData.uniqueID
						if uniqueID then
							local itemData = nLootLinkData.getItemData(uniqueID)
							local itemDataComp = nLootLinkData.getItemDataComp(uniqueID)

							if itemData and itemData.id ~= 0 then
								nLootLinkComm.advertise(itemDataComp)
								itemData.name = itemData.name
								EA_ChatWindow.InsertItemLink(itemData)
							end
						end
					end
				end
			end
		end
	end
end

-- mouse over an icon
local tooltipItemData = false

function nLootLinkGUI.itemMouseOver()
	local activeWindowName = SystemData.ActiveWindow.name
	if activeWindowName then
		local rowIdx = WindowGetId(activeWindowName)
		if rowIdx then
			local dataIdx = ListBoxGetDataIndex(WINDOW_NAME.."List", rowIdx)
			if dataIdx then
				local partialItemData = listData[dataIdx]
				if partialItemData then
					local uniqueID = partialItemData.uniqueID
					if uniqueID then
						tooltipItemData = nLootLinkData.getItemData(uniqueID)

						if not tooltipItemData or tooltipItemData.id == 0 then
							Tooltips.ClearTooltip()
						else
							tooltipItemData.customizedIconNum=0
							Tooltips.CreateItemTooltip(tooltipItemData, activeWindowName, Tooltips.ANCHOR_WINDOW_RIGHT, Tooltips.ENABLE_COMPARISON)
							--LabelSetText( "ItemTooltipAppearanceState", L"" )
						end
					end
				end
			end
		end
	end
end

-- search button pressed
function nLootLinkGUI.search()
	if doDebug then d("nLootLinkGUI.search START") end

	-- create the display order list
	ListBoxSetDisplayOrder("nLootLinkGUIList", nLootLinkGUI.createListDataOrder())

	if doDebug then d("nLootLinkGUI.search END") end
end

-- reset button pressed
function nLootLinkGUI.reset()
	if doDebug then d("nLootLinkGUI.reset START") end

	nLootLinkGUI.resetSearchFields()
	nLootLinkGUI.enableSorts()

	-- empty the results
	ListBoxSetDisplayOrder("nLootLinkGUIList", {})
	nLootLinkGUI.setCount(0, #listData)

	if doDebug then d("nLootLinkGUI.reset END") end
end

-- rarity filter selected
function nLootLinkGUI.onRaritySelected(choiceIndex)
	if doDebug then d("nLootLinkGUI.onRaritySelected choiceIndex = "..tostring(choiceIndex)) end

	nLootLinkUtil.setMultiComboBoxValue(choiceIndex, WINDOW_NAME.."FilterRarity", choiceRarity)
end

-- type filter selected
function nLootLinkGUI.onTypeSelected(choiceIndex)
	if doDebug then d("nLootLinkGUI.onTypeSelected choiceIndex = "..tostring(choiceIndex)) end

	nLootLinkUtil.setMultiComboBoxValue(choiceIndex, WINDOW_NAME.."FilterType", choiceType)
end

-- slot filter selected
function nLootLinkGUI.onSlotSelected(choiceIndex)
	if doDebug then d("nLootLinkGUI.onSlotSelected choiceIndex = "..tostring(choiceIndex)) end

	nLootLinkUtil.setMultiComboBoxValue(choiceIndex, WINDOW_NAME.."FilterSlot", choiceSlot)
end

-- stat filter selected
function nLootLinkGUI.onStatSelected(choiceIndex)
	if doDebug then d("nLootLinkGUI.onStatSelected choiceIndex = "..tostring(choiceIndex)) end

	nLootLinkUtil.setMultiComboBoxValue(choiceIndex, WINDOW_NAME.."FilterStat", choiceStat)
end

-- career filter selected
function nLootLinkGUI.onCareerSelected(choiceIndex)
	if doDebug then d("nLootLinkGUI.onCareerSelected choiceIndex = "..tostring(choiceIndex)) end

	nLootLinkUtil.setMultiComboBoxValue(choiceIndex, WINDOW_NAME.."FilterCareer", choiceCareer)
end

-- category filter selected
function nLootLinkGUI.onCategorySelected(choiceIndex)
	if doDebug then d("nLootLinkGUI.onCategorySelected choiceIndex = "..tostring(choiceIndex)) end

	local choiceData = choiceCategory[choiceIndex]
	if choiceData == nil then
		return
	end

	local val = choiceData.value
	local fields = DEFAULT_FIELDS
	local sorts = false
	local craftingCategory = false
	if doDebug then d("nLootLinkGUI.onCategorySelected val = "..tostring(val)) end
	if val == CHOICE_ANY_VALUE then
		nLootLinkGUI.populateTypeCombo()
		nLootLinkGUI.populateSlotCombo()
		nLootLinkGUI.populateCraftingCombo()
	else
		nLootLinkGUI.populateTypeCombo(val)
		nLootLinkGUI.populateSlotCombo(val)
		nLootLinkGUI.populateCraftingCombo(val)

		for i, category in ipairs(CATEGORIES) do
			if i == val then
				fields = category.fields
				sorts = category.sorts
				if category.craftingSkill then
					craftingCategory = true
				end
			end
		end
	end

	nLootLinkUtil.enableCombo(WINDOW_NAME.."FilterType", fields.type)
	nLootLinkUtil.enableCombo(WINDOW_NAME.."FilterSlot", fields.slot)
	nLootLinkUtil.enableCombo(WINDOW_NAME.."FilterStat", fields.stat)
	nLootLinkUtil.enableCombo(WINDOW_NAME.."FilterCareer", fields.career)
	nLootLinkUtil.enableCheck(WINDOW_NAME.."FilterUsable", fields.usable)
	nLootLinkUtil.enableCheck(WINDOW_NAME.."FilterSetItem", fields.setItem)
	nLootLinkGUI.enableRank(fields.rank)
	nLootLinkGUI.enableRenown(fields.renown)

	nLootLinkGUI.enableCraftingLevel(fields.craftingLevel)
	nLootLinkUtil.enableCombo(WINDOW_NAME.."FilterCrafting", fields.crafting)

	nLootLinkGUI.enableSorts(sorts)
	if craftingCategory then
		nLootLinkGUI.useSortTypeCraftingLevel()
	else
		nLootLinkGUI.useSortTypeDefault()
	end
end

-- sort header pressed
function nLootLinkGUI.changeSorting()
	local headerName = SystemData.ActiveWindow.name
	local rev = false

	if headerName then

		-- none -> down -> up -> down
		if WindowGetShowing(headerName.."DownArrow") then
			nLootLinkGUI.clearSortHeaders()
			WindowSetShowing(headerName.."DownArrow", false)
			WindowSetShowing(headerName.."UpArrow", true)
			rev = true
		elseif WindowGetShowing(headerName.."UpArrow") then
			nLootLinkGUI.clearSortHeaders()
			WindowSetShowing(headerName.."DownArrow", true)
			WindowSetShowing(headerName.."UpArrow", false)
		else
			nLootLinkGUI.clearSortHeaders()
			WindowSetShowing(headerName.."DownArrow", true)
			WindowSetShowing(headerName.."UpArrow", false)
		end

		-- setup the sort ordring
		for _, sort in ipairs(sortTypes) do
			if sort.button == headerName then
				nLootLinkGUI.setSort(sort, rev)
				break
			end
		end

		-- search again to resort the results... kludgey but practical
		if nLootLinkGUIList.PopulatorIndices then
			nLootLinkGUI.search()
		end
	end
end

-- bind any picked
function nLootLinkGUI.onBindAny()

	ButtonSetPressedFlag(WINDOW_NAME.."FilterBindAnyButton", true)
	ButtonSetPressedFlag(WINDOW_NAME.."FilterBindOnPickupButton", false)
	ButtonSetPressedFlag(WINDOW_NAME.."FilterBindOnEquipButton", false)
end

-- bind on equip picked
function nLootLinkGUI.onBindOnEquip()

	ButtonSetPressedFlag(WINDOW_NAME.."FilterBindAnyButton", false)
	ButtonSetPressedFlag(WINDOW_NAME.."FilterBindOnPickupButton", false)
	ButtonSetPressedFlag(WINDOW_NAME.."FilterBindOnEquipButton", true)
end

-- bind on pickup picked
function nLootLinkGUI.onBindOnPickup()

	ButtonSetPressedFlag(WINDOW_NAME.."FilterBindAnyButton", false)
	ButtonSetPressedFlag(WINDOW_NAME.."FilterBindOnPickupButton", true)
	ButtonSetPressedFlag(WINDOW_NAME.."FilterBindOnEquipButton", false)
end

--
-- private functions
--

-- compare items, for sorting purposes, based on sortOrder
local result = false
local function itemComparator(a, b)
	for _, v in ipairs(sortOrder) do
		result = v.func(a, b)
		if result == -1 then
			return not v.rev
		elseif result == 1 then
			return v.rev
		end
	end
	return false
end

-- create the list for the results window; indexes could be used, however the "full tablescan" method is very quick so there is no need
function nLootLinkGUI.createListDataOrder()
	if doDebug then d("nLootLinkGUI.createListDataOrder START") end

	local listDataOrder = {}

	-- sort data according to sortOrder
	table.sort(listData, itemComparator)

	-- item name filter, trimmed
	local nameFilter = TextEditBoxGetText(WINDOW_NAME.."FilterName")
	if nameFilter == "" or nameFilter == L"" or nameFilter == T["Item Name"] then
		nameFilter = nil
	else
		nameFilter = nameFilter:lower():match(L"^[ ]*(.-)[ ]*$")
	end

	-- item rank filter
	local minRankFilter = tonumber(TextEditBoxGetText(WINDOW_NAME.."FilterRankMin"):match(L"%d+"))
	local maxRankFilter = tonumber(TextEditBoxGetText(WINDOW_NAME.."FilterRankMax"):match(L"%d+"))

	-- item renown filter
	local minRenownFilter = tonumber(TextEditBoxGetText(WINDOW_NAME.."FilterRenownMin"):match(L"%d+"))
	local maxRenownFilter = tonumber(TextEditBoxGetText(WINDOW_NAME.."FilterRenownMax"):match(L"%d+"))

	-- crafting level filter
	local minCraftingLevelFilter = tonumber(TextEditBoxGetText(WINDOW_NAME.."FilterCraftingLevelMin"):match(L"%d+"))
	local maxCraftingLevelFilter = tonumber(TextEditBoxGetText(WINDOW_NAME.."FilterCraftingLevelMax"):match(L"%d+"))

	-- bind filters
	local bopFilter = ButtonGetPressedFlag(WINDOW_NAME.."FilterBindOnPickupButton")
	local boeFilter = ButtonGetPressedFlag(WINDOW_NAME.."FilterBindOnEquipButton")

	-- rarity filter
	local rarityFilter = nLootLinkGUI.buildFilterTable(choiceRarity)

	-- category filter
	local comboIndex = ComboBoxGetSelectedMenuItem(WINDOW_NAME.."FilterCategory")
	local categoryIndex = 0
	local categoryFilter = false
	local categoryFilterFn = false
	if comboIndex and choiceCategory[comboIndex] then
		categoryIndex = choiceCategory[comboIndex].value
		if categoryIndex and categoryIndex ~= CHOICE_ANY_VALUE and CATEGORIES[categoryIndex] then
			if CATEGORIES[categoryIndex].craftingSkill then
				categoryFilterFn = function(partialItemData)
					return partialItemData.craftingSkill == CATEGORIES[categoryIndex].craftingSkill
				end
			else
				categoryFilter = {}
				for _, type in ipairs(CATEGORIES[categoryIndex].types) do
					categoryFilter[type] = true
				end
				categoryFilterFn = function(partialItemData)
					return categoryFilter[partialItemData.type]
				end
			end
		end
	end

	-- type filter
	local typeFilter = nLootLinkGUI.buildFilterTable(choiceType)

	-- slot filter
	local slotFilter = nLootLinkGUI.buildFilterTable(choiceSlot)

	-- stat filter
	local statFilter = nLootLinkGUI.buildFilterTable(choiceStat)
	local statFilterFn = false
	if statFilter then
		statFilterFn = function(bonus)
			for _, v in pairs(bonus) do
				if statFilter[v.reference] and v.value ~= 0 then
					return true
				end
			end
			return false
		end
	end

	-- career filter
	local careerFilter = nLootLinkGUI.buildFilterTable(choiceCareer)
	local careerFilterFn = false
	if careerFilter then
		careerFilterFn = function(partialItemData)
			for career, _ in pairs(careerFilter) do
				if DataUtils.CareerIsAllowedForItem(career, partialItemData) and
				   DataUtils.RaceIsAllowedForItem(CAREER_RACES[career], partialItemData) and
				   DataUtils.SkillIsEnoughForItem(CAREER_SKILLS[career], partialItemData) then
					return true
				end
			end
			return false
		end
	end

	-- crafting filter
	comboIndex = ComboBoxGetSelectedMenuItem(WINDOW_NAME.."FilterCrafting")
	local craftingFilter = false
	local craftingFilterFn = false
	if comboIndex and choiceCrafting[comboIndex] and choiceCrafting[comboIndex].value and choiceCrafting[comboIndex].value ~= CHOICE_ANY_VALUE then
		if CATEGORIES[categoryIndex] and CATEGORIES[categoryIndex].craftingSkill == GameData.TradeSkills.CULTIVATION then
			craftingFilter = choiceCrafting[comboIndex].value
			craftingFilterFn = function(partialItemData)
				return partialItemData.cultivationType == craftingFilter
			end
		else
			craftingFilter = CraftingSystem.GetResourceTypeName(choiceCrafting[comboIndex].value)
			craftingFilterFn = function(partialItemData)
				return CraftingSystem.GetResourceTypeName(partialItemData.craftingType) == craftingFilter
			end
		end
	end

	-- usable filter
	local usableFilter = ButtonGetPressedFlag(WINDOW_NAME.."FilterUsableButton")

	-- set item filter
	local setItemFilter = ButtonGetPressedFlag(WINDOW_NAME.."FilterSetItemButton")

	-- put items in the list, applying filters as needed
	nLootLinkList = {}
	for i, partialItemData in ipairs(listData) do
		if (not nameFilter or partialItemData.name:lower():find(nameFilter, 1, true)) and
		   (not minRankFilter or partialItemData.level >= minRankFilter or partialItemData.level == 0) and
		   (not maxRankFilter or partialItemData.level <= maxRankFilter or partialItemData.level == 0) and
		   (not minRenownFilter or partialItemData.renown >= minRenownFilter or partialItemData.renown == 0) and
		   (not maxRenownFilter or partialItemData.renown <= maxRenownFilter or partialItemData.renown == 0) and
		   (not minCraftingLevelFilter or partialItemData.craftingSkillRequirement >= minCraftingLevelFilter) and
		   (not maxCraftingLevelFilter or partialItemData.craftingSkillRequirement <= maxCraftingLevelFilter) and
		   (not bopFilter or partialItemData.bop == true) and
		   (not boeFilter or partialItemData.bop == false) and
		   (not rarityFilter or rarityFilter[partialItemData.rarity]) and
		   (not usableFilter or partialItemData.usable) and
		   (not setItemFilter or partialItemData.itemSet > 0) and
		   (not categoryFilterFn or categoryFilterFn(partialItemData)) and
		   (not typeFilter or typeFilter[partialItemData.type]) and
		   (not slotFilter or slotFilter[partialItemData.equipSlot]) and
		   (not careerFilterFn or careerFilterFn(partialItemData)) and
		   (not craftingFilterFn or craftingFilterFn(partialItemData)) and
		   (not statFilterFn or statFilterFn(partialItemData.bonus)) then
			table.insert(listDataOrder, i)
			table.insert(nLootLinkList, partialItemData.name)
		end
	end

	-- set the result count
	nLootLinkGUI.setCount(#listDataOrder, #listData)

	if doDebug then d("nLootLinkGUI.createListDataOrder RETURNING") end

	return listDataOrder
end

-- build a table containing selected choice values
function nLootLinkGUI.buildFilterTable(choiceData)
	local filter = nil
	for _, data in ipairs(choiceData) do
		if data.value ~= CHOICE_ANY_VALUE and data.isSelected then
			if not filter then
				filter = {}
			end
			filter[data.value] = true
		end
	end
	return filter
end

-- update the row with the item data
function nLootLinkGUI.populateListDisplayData()
	local colour, partialItemData

	for row, rowIndex in ipairs(nLootLinkGUIList.PopulatorIndices) do

		-- retrieve the partial and full item data
		partialItemData = listData[rowIndex]

		-- display name in color of rarity
		colour = DataUtils.GetItemRarityColor(partialItemData)
		LabelSetTextColor(WINDOW_NAME.."ListRow"..row.."ItemName", colour.r, colour.g, colour.b )

		if partialItemData.craftingSkill then
			-- display trade skill type in red if player doesn't meet skill requirement
			if GameData.TradeSkillLevels[partialItemData.craftingSkill] then
				EA_Window_Backpack.ColorLabelIfMeetsRequirements(WINDOW_NAME.."ListRow"..row.."ItemType", true, GameData.TradeSkillLevels[partialItemData.craftingSkill] >= partialItemData.craftingSkillRequirement)
			else
				EA_Window_Backpack.ColorLabelIfMeetsRequirements(WINDOW_NAME.."ListRow"..row.."ItemType", true, false)
			end
		else
			-- display itemtype in red if player doesn't meet skill requirement
			EA_Window_Backpack.ColorLabelIfMeetsRequirements(WINDOW_NAME.."ListRow"..row.."ItemType", true, partialItemData.reqFlags.skills)
		end

		-- display rank requirements in red if player doesn't meet requirement
		EA_Window_Backpack.ColorLabelIfMeetsRequirements(WINDOW_NAME.."ListRow"..row.."ItemRank", true, partialItemData.reqFlags.level)

		-- display renown requirements in red if player doesn't meet requirement
		EA_Window_Backpack.ColorLabelIfMeetsRequirements(WINDOW_NAME.."ListRow"..row.."ItemRenown", true, partialItemData.reqFlags.renown)
	end
end

-- reset the search fields to default
function nLootLinkGUI.resetSearchFields()

	ComboBoxSetSelectedMenuItem(WINDOW_NAME.."FilterRarity", 1)
	nLootLinkGUI.onRaritySelected(1)

	ComboBoxSetSelectedMenuItem(WINDOW_NAME.."FilterCategory", 1)
	nLootLinkGUI.onCategorySelected(1)

	nLootLinkGUI.populateTypeCombo()

	nLootLinkGUI.populateSlotCombo()

	nLootLinkGUI.onStatSelected(1)

	nLootLinkGUI.onCareerSelected(1)

	nLootLinkGUI.populateCraftingCombo()

	TextEditBoxSetText(WINDOW_NAME.."FilterName", T["Item Name"])

	ButtonSetPressedFlag(WINDOW_NAME.."FilterUsableButton", false)
	WindowSetShowing(WINDOW_NAME.."FilterUsable", true)

	ButtonSetPressedFlag(WINDOW_NAME.."FilterSetItemButton", false)
	WindowSetShowing(WINDOW_NAME.."FilterSetItem", true)

	nLootLinkGUI.enableRank(DEFAULT_FIELDS.rank, true)
	nLootLinkGUI.enableRenown(DEFAULT_FIELDS.renown, true)
	nLootLinkGUI.enableCraftingLevel(DEFAULT_FIELDS.craftingLevel, true)

	nLootLinkGUI.onBindAny()
end

-- clear the sort headers
function nLootLinkGUI.clearSortHeaders()
	for _, sort in ipairs(sortTypes) do
		if sort.enabled then
			WindowSetShowing(sort.button.."UpArrow", false)
			WindowSetShowing(sort.button.."DownArrow", false)
		end
	end
end

-- apply the sorting order according to default and enabled flags
function nLootLinkGUI.applySort()
	if doDebug then d("nLootLinkGUI.applySort") end

	sortOrder = {}
	for _, sort in ipairs(sortTypes) do
		if sort.enabled then
			table.insert(sortOrder, sort)
			WindowSetShowing(sort.button, true)
		else
			WindowSetShowing(sort.button, false)
		end
	end

	nLootLinkGUI.clearSortHeaders()
	WindowSetShowing(sortOrder[1].button.."DownArrow", true)

	if doDebug then d(sortOrder) end
end

-- promote sort to the head of sortOrder
function nLootLinkGUI.setSort(sort, rev)
	if doDebug then d("nLootLinkGUI.setSort") end

	-- remove sort from sortOrder
	for i, v in ipairs(sortOrder) do
		if v.name == sort.name then
			v.rev = rev
			table.remove(sortOrder, i)
			break
		end
	end

	-- insert it at the start
	table.insert(sortOrder, 1, sort)

	if doDebug then d(sortOrder) end
end

-- set the result count
function nLootLinkGUI.setCount(num, den)
	LabelSetText(WINDOW_NAME.."Count", FORMAT_RESULT_COUNT:format(num, den))
end

-- update the total for the result count
function nLootLinkGUI.updateCountTotal(den)
	local countText = LabelGetText(WINDOW_NAME.."Count")
	countText = countText:gsub(FORMAT_RESULT_DEN, den)
	LabelSetText(WINDOW_NAME.."Count", countText)
end

-- populate the type combo with the category passed, or any if none passed
function nLootLinkGUI.populateTypeCombo(categoryIndex)
	ComboBoxClearMenuItems(WINDOW_NAME.."FilterType")
	choiceType = {}
	typesInserted = {}

	for i, category in ipairs(CATEGORIES) do
		if not categoryIndex or i == categoryIndex then
			if category.types then
				for _, type in ipairs(category.types) do
					if ItemTypes[type] and not typesInserted[type] then
						table.insert(choiceType, { text = ItemTypes[type].name, value = type, isSelected = false, })
						typesInserted[type] = true
					end
				end
			end
		end
	end

	local textAny = T["Any Item Type"]
	if categoryIndex and CATEGORIES[categoryIndex].typeText then
		textAny = CATEGORIES[categoryIndex].typeText
	end
	table.insert(choiceType, 1, { text = textAny, value = CHOICE_ANY_VALUE, isSelected = nil, })

	nLootLinkUtil.setComboBoxChoices(WINDOW_NAME.."FilterType", choiceType)
	ComboBoxSetSelectedMenuItem(WINDOW_NAME.."FilterType", 1)
	nLootLinkGUI.onTypeSelected(1)
end

-- populate the slot combo with the category passed, or any if none passed
function nLootLinkGUI.populateSlotCombo(categoryIndex)
	ComboBoxClearMenuItems(WINDOW_NAME.."FilterSlot")
	choiceSlot = {}

	for i, category in ipairs(CATEGORIES) do
		if not categoryIndex or i == categoryIndex then
			if category.slots then
				for _, slot in ipairs(category.slots) do
					if ItemSlots[slot] then
						table.insert(choiceSlot, { text = ItemSlots[slot].name, value = slot, isSelected = false, })
					end
				end
			end
		end
	end

	local textAny = T["Any Slot"]
	if categoryIndex and CATEGORIES[categoryIndex].slotText then
		textAny = CATEGORIES[categoryIndex].slotText
	end
	table.insert(choiceSlot, 1, { text = textAny, value = CHOICE_ANY_VALUE, isSelected = nil, })

	nLootLinkUtil.setComboBoxChoices(WINDOW_NAME.."FilterSlot", choiceSlot)
	ComboBoxSetSelectedMenuItem(WINDOW_NAME.."FilterSlot", 1)
	nLootLinkGUI.onSlotSelected(1)
end

-- populate the crafting combo with the crafting type passed, or any if none passed
function nLootLinkGUI.populateCraftingCombo(categoryIndex)
	ComboBoxClearMenuItems(WINDOW_NAME.."FilterCrafting")
	choiceCrafting = {}
	local typeText = false

	for i, category in ipairs(CATEGORIES) do
		if not categoryIndex or i == categoryIndex then
			if category.crafting then
				for _, type in ipairs(category.crafting) do
					if category.craftingSkill == GameData.TradeSkills.CULTIVATION then
						typeText = CultivationWindow.typeNames[type]
					else
						typeText = CraftingSystem.GetResourceTypeName(type)
					end
					if typeText then
						table.insert(choiceCrafting, { text = typeText, value = type, isSelected = nil, })
					end
				end
			end
		end
	end

	local textAny = T["Any Crafting Item Type"]
	if categoryIndex and CATEGORIES[categoryIndex].craftingText then
		textAny = CATEGORIES[categoryIndex].craftingText
	end
	table.insert(choiceCrafting, 1, { text = textAny, value = CHOICE_ANY_VALUE, isSelected = nil, })

	nLootLinkUtil.setComboBoxChoices(WINDOW_NAME.."FilterCrafting", choiceCrafting)
	ComboBoxSetSelectedMenuItem(WINDOW_NAME.."FilterCrafting", 1)
end

-- enable or disable rank selectors
function nLootLinkGUI.enableRank(enabled, clear)
	if enabled then
		if not WindowGetShowing(WINDOW_NAME.."FilterRankHeader") or clear then
			TextEditBoxSetText(WINDOW_NAME.."FilterRankMin", L"")
			TextEditBoxSetText(WINDOW_NAME.."FilterRankMax", L"")
			WindowSetShowing(WINDOW_NAME.."FilterRankHeader", true)
			WindowSetShowing(WINDOW_NAME.."FilterRankMin", true)
			WindowSetShowing(WINDOW_NAME.."FilterRankSeparator", true)
			WindowSetShowing(WINDOW_NAME.."FilterRankMax", true)
		end
	else
		TextEditBoxSetText(WINDOW_NAME.."FilterRankMin", L"")
		TextEditBoxSetText(WINDOW_NAME.."FilterRankMax", L"")
		WindowSetShowing(WINDOW_NAME.."FilterRankHeader", false)
		WindowSetShowing(WINDOW_NAME.."FilterRankMin", false)
		WindowSetShowing(WINDOW_NAME.."FilterRankSeparator", false)
		WindowSetShowing(WINDOW_NAME.."FilterRankMax", false)
	end
end

-- enable or disable renown selectors
function nLootLinkGUI.enableRenown(enabled, clear)
	if enabled then
		if not WindowGetShowing(WINDOW_NAME.."FilterRenownHeader") or clear then
			TextEditBoxSetText(WINDOW_NAME.."FilterRenownMin", L"")
			TextEditBoxSetText(WINDOW_NAME.."FilterRenownMax", L"")
			WindowSetShowing(WINDOW_NAME.."FilterRenownHeader", true)
			WindowSetShowing(WINDOW_NAME.."FilterRenownMin", true)
			WindowSetShowing(WINDOW_NAME.."FilterRenownSeparator", true)
			WindowSetShowing(WINDOW_NAME.."FilterRenownMax", true)
		end
	else
		TextEditBoxSetText(WINDOW_NAME.."FilterRenownMin", L"")
		TextEditBoxSetText(WINDOW_NAME.."FilterRenownMax", L"")
		WindowSetShowing(WINDOW_NAME.."FilterRenownHeader", false)
		WindowSetShowing(WINDOW_NAME.."FilterRenownMin", false)
		WindowSetShowing(WINDOW_NAME.."FilterRenownSeparator", false)
		WindowSetShowing(WINDOW_NAME.."FilterRenownMax", false)
	end
end

-- enable or disable crafting level selectors
function nLootLinkGUI.enableCraftingLevel(enabled, clear)
	if enabled then
		if not WindowGetShowing(WINDOW_NAME.."FilterRenownHeader") or clear then
			TextEditBoxSetText(WINDOW_NAME.."FilterCraftingLevelMin", L"")
			TextEditBoxSetText(WINDOW_NAME.."FilterCraftingLevelMax", L"")
			WindowSetShowing(WINDOW_NAME.."FilterCraftingLevelHeader", true)
			WindowSetShowing(WINDOW_NAME.."FilterCraftingLevelMin", true)
			WindowSetShowing(WINDOW_NAME.."FilterCraftingLevelSeparator", true)
			WindowSetShowing(WINDOW_NAME.."FilterCraftingLevelMax", true)
		end
	else
		TextEditBoxSetText(WINDOW_NAME.."FilterCraftingLevelMin", L"")
		TextEditBoxSetText(WINDOW_NAME.."FilterCraftingLevelMax", L"")
		WindowSetShowing(WINDOW_NAME.."FilterCraftingLevelHeader", false)
		WindowSetShowing(WINDOW_NAME.."FilterCraftingLevelMin", false)
		WindowSetShowing(WINDOW_NAME.."FilterCraftingLevelSeparator", false)
		WindowSetShowing(WINDOW_NAME.."FilterCraftingLevelMax", false)
	end
end

-- enable or disable sort headers, if sortsEnabled is nil or false, enable all
function nLootLinkGUI.enableSorts(sortsEnabled)
	if sortsEnabled then
		for _, sort in ipairs(sortTypes) do
			sort.enabled = sortsEnabled[sort.name]
			sort.rev = false
		end
	else
		for _, sort in ipairs(sortTypes) do
			sort.enabled = true
			sort.rev = false
		end
	end
	nLootLinkGUI.applySort()
end

-- use the default sort type header
function nLootLinkGUI.useSortTypeDefault()
	ButtonSetText(SORT_TYPE_BUTTON_NAME, SORT_TYPE_DEFAULT)
end

-- use the skill sort type header
function nLootLinkGUI.useSortTypeCraftingLevel()
	ButtonSetText(SORT_TYPE_BUTTON_NAME, SORT_TYPE_CRAFTING_LEVEL)
end
