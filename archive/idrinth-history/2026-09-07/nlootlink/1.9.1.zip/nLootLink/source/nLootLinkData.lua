nLootLinkData = {}

-- libraries
local LibItemCompress = LibStub:GetLibrary("LibItemCompress-1.1")
local T = LibStub("WAR-AceLocale-3.0"):GetLocale("nLootLink")

-- local function aliases
local compressItemData = LibItemCompress.compressItemData
local uncompressItemData = LibItemCompress.uncompressItemData
local copyTable = DataUtils.CopyTable

-- local member aliases
local itemDB = false
local listData = false

-- global constants
local MAX_UNIQUE_ID = nLootLink.MAX_UNIQUE_ID
local DEFAULT_MIN_RARITY = nLootLink.DEFAULT_MIN_RARITY
local ITEMS_PER_UPDATE = nLootLink.ITEMS_PER_UPDATE
local STRING_COMPRESSION = nLootLink.STRING_COMPRESSION

-- local variables
local doDebug = true
local initComplete = false
local listDataBuildCount = 0
local initialSize = 0
local buildUniqueID
local badSavedItemData = {}
local initInProgress = false


--
-- initialisation functions
--

-- initialise function for nLootLinkData
function nLootLinkData.init()
	doDebug = nLootLink.DEBUG
	if doDebug then d("nLootLinkData.init START") end

	-- don't init yet - GameData.Player may not yet be initialised
	RegisterEventHandler(SystemData.Events.LOADING_END, "nLootLinkData.LOADING_END")
	RegisterEventHandler(SystemData.Events.RELOAD_INTERFACE, "nLootLinkData.LOADING_END")

	if doDebug then d("nLootLinkData.init END") end
end

-- initialise function for nLootLinkData
function nLootLinkData.startInit()
	doDebug = nLootLink.DEBUG
	if doDebug then d("nLootLinkData.startInit START") end

	nLootLinkOptions.initDB()
	nLootLinkData.initDB()
	nLootLinkData.checkVersion()

	nLootLinkChat.init()
	nLootLinkGUIIntegration.init()
	nLootLinkOptions.init()

	initInProgress = true

	if doDebug then d("nLootLinkData.startInit END") end
end

-- initialise the database and local aliases
function nLootLinkData.initDB()
	if doDebug then d("nLootLinkData.initDB START") end

	if not nLootLinkData.itemDB then
		nLootLinkData.itemDB = {}
	end
	itemDB = nLootLinkData.itemDB

	for _, _ in pairs(itemDB) do
		initialSize = initialSize + 1
	end

	if doDebug then d("nLootLinkData.initDB END") end
end

-- initialise version information
function nLootLinkData.checkVersion()
	if doDebug then d("nLootLinkData.checkVersion START") end

	-- create the version DB if it doesn't exist
	if not nLootLinkData.versionDB then
		nLootLinkData.versionDB = {}
	end

	-- store the version info
	nLootLinkData.versionDB.major = nLootLink.VERSION_MAJOR
	nLootLinkData.versionDB.minor = nLootLink.VERSION_MINOR
	nLootLinkData.versionDB.point = nLootLink.VERSION_POINT

	if doDebug then d("nLootLinkData.checkVersion END") end
end

-- initialisation is done
function nLootLinkData.initComplete()
	for _, uniqueID in ipairs(badSavedItemData) do
		itemDB[uniqueID] = nil
	end
	initComplete = true
	listDataBuildCount = nil
	initialSize = nil
	badSavedItemData = nil
	buildUniqueID = nil
	initInProgress = false

	nLootLinkUtil.printToChat(T["nLootLink ready: %d items"]:format(#listData))

	nLootLink.init()
end


--
-- accessors
--

-- itemData
function nLootLinkData.getItemData(uniqueID)
	local itemDataComp = itemDB[uniqueID]
	if itemDataComp then
		return uncompressItemData(itemDataComp)
	else
		return nil
	end
end

-- itemDataComp
function nLootLinkData.getItemDataComp(uniqueID)
	return itemDB[uniqueID]
end

-- number of items in the database
function nLootLinkData.getNumItems()
	if initComplete then
		return #listData
	else
		return initialSize
	end
end

-- number of items unpacked
function nLootLinkData.getNumItemsUnpacked()
	return listDataBuildCount or 0
end

-- retrieve a random compressed item to advertise
local advertiseUniqueID = nil
function nLootLinkData.getAdvertisement()
	local itemDataComp

	-- start at a random spot in the list
	if advertiseUniqueID == nil then
		local index = math.floor(math.random(0, #listData))
		if doDebug then d("nLootLinkData.getAdvertisement starting at "..tostring(index)) end
		if index > 0 then
			for i = 1, index do
				advertiseUniqueID = next(itemDB, advertiseUniqueID)
			end
		end
	end

	-- retrieve the compressed item data, wrapping around if necessary
	advertiseUniqueID, itemDataComp = next(itemDB, advertiseUniqueID)
	if advertiseUniqueID == nil or itemDataComp == nil then
		advertiseUniqueID, itemDataComp = next(itemDB, nil)
	end

	return itemDataComp
end


--
-- callbacks from the game engine
--

-- onUpdate handler used to initialise list data slowly
function nLootLinkData.onUpdate(elapsed)

	if initInProgress then
		-- call the listData initialise until it's finished
		if not initComplete then
			nLootLinkData.updateListData()
		end
	end
end


--
-- events
--

-- interface loaded
function nLootLinkData.LOADING_END()
	d("nLootLinkData.LOADING_END()")

	-- unregister both handlers
	UnregisterEventHandler(SystemData.Events.LOADING_END, "nLootLinkData.LOADING_END")
	UnregisterEventHandler(SystemData.Events.RELOAD_INTERFACE, "nLootLinkData.LOADING_END")

	-- start the init
	nLootLinkData.startInit()
end


--
-- private functions
--

-- compress an item and add it to the database
local function updateDB(uniqueID, itemData)
	itemDB[uniqueID] = compressItemData(itemData)
end

-- add an item to the abridged list data
local function addListData(itemData)

	-- record the first bit of player data we get - it doesn't appear to be accurate at first
	if doDebug and not nLootLinkData.initialPlayerData then
		nLootLinkData.initialPlayerData = GameData.Player
	end

	-- don't attempt to add until the list has been created
	if not listData then return end

	-- create the partial item data
	local partialItemData = {}
	partialItemData.uniqueID = itemData.uniqueID
	partialItemData.iconNum = itemData.iconNum
	partialItemData.name = itemData.name
	partialItemData.level = itemData.level
	partialItemData.renown = itemData.renown
	partialItemData.bop = itemData.bop
	partialItemData.type = itemData.type
	partialItemData.rarity = itemData.rarity
	partialItemData.itemSet = itemData.itemSet
	partialItemData.customizedIconName=itemData.customizedIconName
	partialItemData.customizedIconNum=itemData.customizedIconNum
	partialItemData.reqFlags = DataUtils.PlayerMeetsReqs(itemData)
	partialItemData.usable = DataUtils.PlayerCanUseItem(itemData)
	partialItemData.equipSlotID = itemData.equipSlotID
	partialItemData.equipSlot = itemData.equipSlot
	partialItemData.bonus = copyTable(itemData.bonus)
	partialItemData.careers = copyTable(itemData.careers)
	partialItemData.races = copyTable(itemData.races)
	partialItemData.skills = copyTable(itemData.skills)


	if DataUtils.IsTradeSkillItem(itemData) then
		local typeText
		if CultivationWindow.IsCultivatingItem(itemData) then
			typeText = GetString( StringTables.Default.LABEL_SKILL_CULTIVATION )
			partialItemData.subTypeText = CultivationWindow.GetCultivationTypeName( itemData )
			partialItemData.craftingSkill = GameData.TradeSkills.CULTIVATION
			partialItemData.cultivationType = itemData.cultivationType
			partialItemData.craftingSkillRequirement = itemData.craftingSkillRequirement
			elseif CraftingSystem.IsCraftingItem(itemData) then
				local craftingSkill, craftingType, craftingLevel = CraftingSystem.GetCraftingData(itemData)
				if craftingSkill and type(craftingSkill) == "table" then
					partialItemData.craftingSkill = craftingSkill[1]
					partialItemData.craftingType = craftingType
					partialItemData.craftingSkillRequirement = craftingLevel
				end
				typeText, partialItemData.subTypeText = CraftingSystem.GetCraftingDataStrings(itemData)
		end
		partialItemData.typeText = typeText..L" : "..itemData.craftingSkillRequirement
		partialItemData.typeTextCraftingSortable = typeText..(L"%.3d"):format(itemData.craftingSkillRequirement)
	else
		if itemData.level > 1 then
			partialItemData.levelText = T["Rank"]..L" : "..itemData.level
		else
			partialItemData.levelText = L""
		end
		if itemData.renown > 1 then
			partialItemData.renownText = T["Renown"]..L" : "..itemData.renown
		else
			partialItemData.renownText = L""
		end
		partialItemData.typeText = DataUtils.GetItemTypeName(itemData.type)
		partialItemData.subTypeText = DataUtils.GetItemEquipSlotName(itemData)

	end

	-- add to the end of the list - sorting will be done later
	table.insert(listData, partialItemData)
end

-- add ITEMS_PER_UPDATE to listData
local itemDataUnComp = false
local function uncompressItem(itemDataComp)
	itemDataUnComp = uncompressItemData(itemDataComp)
end
function nLootLinkData.updateListData()

	local success, err

	if not nLootLinkData.listData then
		nLootLinkData.listData = {}
		listData = nLootLinkData.listData
		nLootLinkUtil.printToChat(T["nLootLink unpacking DB..."])
	end

	local builtThisIteration = 0
	local itemDataComp
	while builtThisIteration < ITEMS_PER_UPDATE do
		buildUniqueID, itemDataComp = next(itemDB, buildUniqueID)
		if buildUniqueID == nil then
			break
		end
		success, err = pcall(uncompressItem, itemDataComp)
		if not success then
			d("nLootLinkData.updateListData failed, error = "..tostring(err).." itemDataComp = ")
			d(itemDataComp)
			table.insert(badSavedItemData, buildUniqueID)
		else
			if itemDataUnComp and itemDataUnComp.rarity < nLootLinkOptions.getMinRarity() then
				table.insert(badSavedItemData, buildUniqueID)
			else
				success, err = pcall(addListData, itemDataUnComp)
				if not success then
					d("nLootLinkData.updateListData failed, error = "..tostring(err).." itemDataUnComp = ")
					d(itemDataUnComp)
					table.insert(badSavedItemData, buildUniqueID)
				end
			end
		end
		listDataBuildCount = listDataBuildCount + 1
		builtThisIteration = builtThisIteration + 1
	end

	--if doDebug then d("nLootLinkData.updateListData listDataBuildCount = "..tostring(listDataBuildCount).."/"..tostring(initialSize)) end

	if not buildUniqueID then
		nLootLinkData.initComplete()
	end
end


--
-- mutators
--
-- add or overwrite an item in the database
function nLootLinkData.upsertItem(itemData, sender)

	if itemData and itemData.uniqueID then
		local uniqueID = itemData.uniqueID

		if uniqueID > 0 and uniqueID < MAX_UNIQUE_ID and itemData.rarity and itemData.rarity >= nLootLinkOptions.getMinRarity() then

			local newItem
			if itemDB[uniqueID] then
				newItem = false
				if doDebug then d("nLootLink updating "..tostring(uniqueID)) end
			else
				newItem = true
				if doDebug then d("nLootLink adding "..tostring(uniqueID)) end
			end

			-- deep copy the item data
			local itemCopy = copyTable(itemData)

			-- remove player-specific information
			itemCopy.boundToPlayer = false
			itemCopy.broken = false
			itemCopy.currChargesRemaining = 0
			itemCopy.dyeTintB = 0
			itemCopy.dyeTintA = 0
			itemCopy.enhSlot = {}
			itemCopy.isNew = false
			itemCopy.noChargeLeftDontDelete = 0
			itemCopy.stackCount = 1
			itemCopy.tintA = 0
			itemCopy.tintB = 0
			itemCopy.cooldownTimeLeft = 0




			-- update the DB
			local success, err = pcall(updateDB, uniqueID, itemCopy)
			if not success then
				d("nLootLinkData.upsertItem failed, error = "..tostring(err).." itemData = ")
				d(itemData)
				return
			end

			-- create the list view if this is new
			if newItem then
				local success, err = pcall(addListData, itemCopy)
				if not success then
					d("nLootLinkData.upsertItem failed, error = "..tostring(err).." itemData = ")
					d(itemData)
					itemDB[uniqueID] = nil
					return
				end
			end

			if newItem and nLootLinkOptions.getPrintNew() then
				if sender then
					nLootLinkUtil.printToChat(T["nLootLink received "]..nLootLinkChat.createItemLink(itemCopy)..T[" from "]..nLootLinkChat.createPlayerLink(sender))
				else
					nLootLinkUtil.printToChat(T["nLootLink adding "]..nLootLinkChat.createItemLink(itemCopy))
				end
			end
		end
	end
end

-- receive an advertised item from another player
function nLootLinkData.receiveAdvertisement(itemDataComp, sender)

	local success, err = pcall(uncompressItem, itemDataComp)
	if success and type(itemDataUnComp) == "table" and type(itemDataUnComp.uniqueID) == "number" and itemDataUnComp.uniqueID > 0 then
		if itemDB[itemDataUnComp.uniqueID] then
			if doDebug then d("nLootLink.receiveAdvertisement itemDB already contains "..tostring(itemDataUnComp.uniqueID)..", ignoring") end
		else
			nLootLinkData.upsertItem(itemDataUnComp, sender)
		end
	else
		if type(err) == "string" then
			d(L"nLootLinkData.receiveAdvertisement received bad data from "..sender..L", error = "..towstring(err)..L", itemDataComp = ")
			d(itemDataComp)
		else
			d(L"nLootLinkData.receiveAdvertisement received bad data from "..sender..L", itemDataUnComp = ")
			d(itemDataUnComp)
		end
	end
end
