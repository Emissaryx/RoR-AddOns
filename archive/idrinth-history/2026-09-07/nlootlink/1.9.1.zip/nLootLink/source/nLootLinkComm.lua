nLootLinkComm = {}

-- libraries
local T = LibStub("WAR-AceLocale-3.0"):GetLocale("nLootLink")

-- local constants
local CHAN_COMM = L"nLootLink"
local CHAT_SEND_DELAY = 3
local CHAT_ADVERTISEMENT_WAIT = 10 -- multiplied by CHAT_SEND_DELAY, must be less than CHAT_BACKOFF
local CHAT_BACKOFF = 20 -- multiplied by CHAT_SEND_DELAY
local KEYWORD_ADVERTISE = L"Sha4oovu"
local KEYWORD_REQUEST = L"aW0SeVoo"


-- local variables
local doDebug = false
local initialised = false
local joinedChannel = false

local channelNumber = false
local channelType = false
local channelSlash = false
local sendQueue = {}
local updateTimer = CHAT_SEND_DELAY
local updateDelay = CHAT_SEND_DELAY
local lastTalker = L""
local unacknowledgedMessage = false
local updatesSinceSend = CHAT_BACKOFF


--
-- initialisation functions
--

-- initialise function for nLootLinkComm
function nLootLinkComm.init()
	doDebug = nLootLink.DEBUG
	if doDebug then d("nLootLinkComm.init START") end

	nLootLinkComm.initEvents()

	updateTimer = 0
	initialised = true

	if doDebug then d("nLootLinkComm.init END") end
end

-- register for events
function nLootLinkComm.initEvents()
	RegisterEventHandler(SystemData.Events.CHANNEL_NAMES_UPDATED, "nLootLinkComm.CHANNEL_NAMES_UPDATED")
	RegisterEventHandler(SystemData.Events.CHAT_TEXT_ARRIVED, "nLootLinkComm.CHAT_TEXT_ARRIVED")
end

-- join the chat channel
function nLootLinkComm.initChannel()
	if doDebug then d("nLootLinkComm.initChannel START") end

	local channelName = nLootLinkComm.getChannelName()

	-- see if we are in an old channel - leave it
	for _, channelData in pairs(GetChatChannelNames()) do
		if channelData.name:match(CHAN_COMM) and channelData.name ~= channelName then
			if doDebug then d(L"nLootLinkComm.initChannel leaving old channel "..channelData.name) end

			nLootLinkComm.sendChatMessage({ text = channelData.name, channel = L"/channelleave", })
		end
	end

	-- are we in the channel already?
	channelNumber = nLootLinkChat.getChannelNumber(channelName)

	if channelNumber then

		-- update the channel names
		BroadcastEvent(SystemData.Events.CHANNEL_NAMES_UPDATED)
	else
		if doDebug then d("nLootLinkComm.initChannel joining hidden channel") end

		-- attempt join the channel
		nLootLinkComm.sendChatMessage({ text = channelName, channel = L"/channeljoin", })
	end

	if doDebug then d("nLootLinkComm.initChannel END") end
end


--
-- public functions
--

-- request an item by uniqueID from public or a known recipient
function nLootLinkComm.request(uniqueID)
	if doDebug then d(L"nLootLinkComm.request uniqueID = "..towstring(uniqueID)) end
	table.insert(sendQueue, { text = KEYWORD_REQUEST..towstring(uniqueID), channel = channelSlash, })
end

-- advertise a compressed item
function nLootLinkComm.advertise(itemDataComp)
	if doDebug then d(L"nLootLinkComm.advertise") end
	if type(itemDataComp) == "wstring" then
		table.insert(sendQueue, { text = KEYWORD_ADVERTISE..itemDataComp, channel = channelSlash, })
	end
end


--
-- events
--

-- channel list updated
function nLootLinkComm.CHANNEL_NAMES_UPDATED()
	if doDebug then d("nLootLinkComm.CHANNEL_NAMES_UPDATED START") end

	channelType = false
	channelSlash = false

	-- retrieve the channel number
	channelNumber = nLootLinkChat.getChannelNumber(nLootLinkComm.getChannelName())
	if channelNumber then
		channelType = nLootLinkChat.getChannelType(channelNumber)
		channelSlash = nLootLinkChat.getChannelSlash(channelNumber)

		-- hide that channel from all windows
		if channelType then
			for _, tab in pairs(EA_ChatTabManager.Tabs) do
				if DoesWindowExist(tab.name.."TextLog") then
					LogDisplaySetFilterState(tab.name.."TextLog", "Chat", channelType, false)
				end
			end
		end
	end

	if doDebug then d("nLootLinkComm.CHANNEL_NAMES_UPDATED END") end
end

-- chat message arrived
function nLootLinkComm.CHAT_TEXT_ARRIVED()

	local chatData = GameData.ChatData

	-- filter on the nLootLink channel
	if initialised and channelType and chatData.type == channelType then

		lastTalker = chatData.name

		-- mark the last sent message as received
		if unacknowledgedMessage and chatData.name == GameData.Player.name and chatData.text == unacknowledgedMessage.text then
			unacknowledgedMessage = false
		end

		-- determine message type
		if chatData.text:match(KEYWORD_ADVERTISE) then

			-- advertisement
			local itemDataComp = chatData.text:match(KEYWORD_ADVERTISE..L"(.*)$")
			nLootLinkComm.receiveAdvertisement(itemDataComp, chatData.name)

		elseif chatData.text:match(KEYWORD_REQUEST) then

			-- request
			local uniqueID = tonumber(chatData.text:match(KEYWORD_REQUEST..L"(.*)$"))
			if type(uniqueID) == "number" then
				nLootLinkComm.receiveRequest(uniqueID, chatData.name)
			end

		end
	end
end


--
-- callbacks from the game engine
--

-- throttled message sender
function nLootLinkComm.onUpdate(elapsed)

	if initialised then
		updateTimer = updateTimer + elapsed
		if updateTimer > updateDelay then
			updateTimer = 0
			updateDelay = math.random(CHAT_SEND_DELAY * 0.5, CHAT_SEND_DELAY * 1.5)

			-- send the message if the user isn't currently typing something
			if not WindowGetShowing("EA_TextEntryGroupEntryBox") then

				if not joinedChannel then

					-- attempt to join the channel, but only once
					nLootLinkComm.initChannel()
					joinedChannel = true

				-- server has sent channel membership confirmation
				elseif channelType then

					updatesSinceSend = updatesSinceSend + 1

					-- back off if we haven't received our last message sent and nobody else has spoken in the channel since
					if updatesSinceSend < CHAT_BACKOFF and (unacknowledgedMessage or lastTalker == GameData.Player.name) then
						if doDebug then d("nLootLinkComm.onUpdate backing off "..tostring(updatesSinceSend)) end
						--if doDebug then nLootLinkUtil.printToChat(L"nLL backing off "..towstring(updatesSinceSend)) end
					else

						-- re-send the last message, the next on the queue, or an advertisement
						local message = unacknowledgedMessage or table.remove(sendQueue)
						if not message or not message.txt or not message.channel then
							if updatesSinceSend < CHAT_ADVERTISEMENT_WAIT then
								if doDebug then d("nLootLinkComm.onUpdate waiting for message "..tostring(updatesSinceSend)) end
								--if doDebug then nLootLinkUtil.printToChat(L"nLL waiting for message "..towstring(updatesSinceSend)) end
							else
								local advertisement = nLootLinkData.getAdvertisement()
								if type(advertisement) == "wstring" then
									message = { text = KEYWORD_ADVERTISE..advertisement, channel = channelSlash, }
								end
							end
						end

						if type(message) == "table" then

							-- send it
							nLootLinkComm.sendChatMessage(message)

							-- save the message, so that we can acknowledge its receipt
							unacknowledgedMessage = message

							-- reset the backoff count
							updatesSinceSend = 0
						end
					end
				end
			end
		end
	end
end


--
-- private
--

-- send a chat message: message.channel and message.text must be wstring
function nLootLinkComm.sendChatMessage(message)
	SystemData.UserInput.ChatChannel = message.channel
	SystemData.UserInput.ChatText = message.text
	BroadcastEvent(SystemData.Events.SEND_CHAT_TEXT)
end

-- get the number of the specified chat channel, returning nil if the user isn't in that channel
function nLootLinkChat.getChannelNumber(channelName)

	for _, channelData in pairs(GetChatChannelNames()) do
		if channelData.name == channelName then
			return channelData.number
		end
	end

	return nil
end

-- calculate the comm channel name
function nLootLinkComm.getChannelName()

	local date = GetTodaysDate()

	return tostring(nLootLink.VERSION_MAJOR)..tostring(nLootLink.VERSION_MINOR)..tostring(CHAN_COMM)..
		tostring(date.todaysYear)..tostring(date.todaysMonth)..tostring(date.todaysDay)
end

-- get the type id of the channel number
function nLootLinkChat.getChannelType(channelNumber)
	return SystemData.ChatLogFilters["CHANNEL_"..tostring(channelNumber)]
end

-- get the channel slash alias
function nLootLinkChat.getChannelSlash(channelNumber)
	return L"/"..towstring(channelNumber)
end

-- receive an advertisement
function nLootLinkComm.receiveAdvertisement(itemDataComp, advertiser)
	if doDebug then d(L"nLootLinkComm.receiveAdvertisement "..itemDataComp..L" from "..advertiser) end
	--if doDebug then nLootLinkUtil.printToChat(L"nLL ADV "..itemDataComp..L" from "..advertiser) end

	-- is the advertisement from another player
	if advertiser ~= GameData.Player.name then

		-- add the item if we don't have it
		nLootLinkData.receiveAdvertisement(itemDataComp, advertiser)
	end
end

-- receive an request
function nLootLinkComm.receiveRequest(uniqueID, requestor)
	if doDebug then d(L"nLootLinkComm.receiveRequest "..towstring(uniqueID)..L" from "..requestor) end
	--if doDebug then nLootLinkUtil.printToChat(L"nLL REQ "..towstring(uniqueID)..L" from "..requestor) end

	if requestor ~= GameData.Player.name then

		local itemDataComp = nLootLinkData.getItemDataComp(uniqueID)

		-- we have the item
		if itemDataComp then

			-- publish the compressed data
			nLootLinkComm.advertise(itemDataComp)
		end
	end
end
