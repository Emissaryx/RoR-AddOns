local FILE_OUTPUT = "SavedVariables.lua"

local function tableSize(tab)
    local size = 0
    if type(tab) == "table" then
        for _, _ in pairs(tab) do
            size = size + 1
        end
    end
    return size
end

-- check the input files
local filePrimary, fileSecondary
if arg[1] then
    filePrimary = io.open(arg[1])
end
if arg[2] then
    fileSecondary = io.open(arg[2])
end
if #arg ~= 2 or filePrimary == nil or fileSecondary == nil or arg[1] == arg[2] then
    print("Usage: nLootLinkMerge.lua <primary> <secondary>")
    return
end
if arg[1] == FILE_OUTPUT or arg[2] == FILE_OUTPUT then
	print("Input files may not be named SavedVariables.lua, exiting")
	return
end
filePrimary:close()
fileSecondary:close()

-- read the primary
nLootLinkData = {}
loadfile(arg[1])()
local nLootLinkDataPrimary = nLootLinkData

-- read the secondary
nLootLinkData = {}
loadfile(arg[2])()
local nLootLinkDataSecondary = nLootLinkData

-- check the versions
if nLootLinkDataPrimary.versionDB.major ~= nLootLinkDataSecondary.versionDB.major or
   nLootLinkDataPrimary.versionDB.minor ~= nLootLinkDataSecondary.versionDB.minor then
    print("version mismatch, exiting")
    return
end

-- output stats
print()
print(arg[1].." contains "..tostring(tableSize(nLootLinkDataPrimary.itemDB)).." items")
print(arg[2].." contains "..tostring(tableSize(nLootLinkDataSecondary.itemDB)).." items")

-- merge the data
mergeCount = 0
skipCount = 0
for uniqueID, itemDataComp in pairs(nLootLinkDataSecondary.itemDB) do
    if nLootLinkDataPrimary.itemDB[uniqueID] then
        skipCount = skipCount + 1
    else
        mergeCount = mergeCount + 1
        nLootLinkDataPrimary.itemDB[uniqueID] = itemDataComp
    end
end

-- more stats
print()
print(tostring(mergeCount).." items merged from "..arg[2])
print(tostring(skipCount).." items skipped as they were already present in "..arg[1])

-- output the merged data
LuaDumpObject(FILE_OUTPUT, "nLootLinkData.itemDB", nLootLinkDataPrimary.itemDB)
local fileOutput = io.open(FILE_OUTPUT, "a+")
fileOutput:write("nLootLinkData.versionDB = \n{\n")
for k, v in pairs(nLootLinkDataPrimary.versionDB) do
    fileOutput:write("\t"..k.." = "..v..",\n")
end
fileOutput:write("}\n")

fileOutput:write("nLootLinkData.optionDB = \n{\n")
for k, v in pairs(nLootLinkDataPrimary.optionDB) do
    fileOutput:write("\t"..k.." = "..tostring(v)..",\n")
end
fileOutput:write("}\n")
fileOutput:close()

print()
print(FILE_OUTPUT.." contains "..tostring(tableSize(nLootLinkDataPrimary.itemDB)).." items")
