<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
	<UiMod name="nLootLink" version="1.9">

		<Author name="nemes" />

		<Description text="Item database" />

		<VersionSettings gameVersion="1.4.8" windowsVersion="1.0" savedVariablesVersion="1.0" />

		<Dependencies>
			<!-- libraries -->
			<Dependency name="LibItemCompress-1.1" />
			<Dependency name="AceLocale-3.0" />

			<!-- core addons -->
			<Dependency name="EASystem_Utils" />
			<Dependency name="EASystem_WindowUtils" />
			<Dependency name="EA_MenuBarWindow" />

			<!-- launch buttons attached to these -->
			<Dependency name="EA_BackpackWindow" />
			<Dependency name="EA_CharacterWindow" />

			<!-- used by DataUtils.getItemTypeText, but dependency is missing from EASystem_Utils  -->
			<Dependency name="EA_CultivationWindow" />
			<Dependency name="EA_CraftingSystem" />

			<!-- hooked addons -->
			<Dependency name="EA_TomeOfKnowledge" />
		</Dependencies>

		<Files>
			<File name="locale/deDE.lua" />
			<File name="locale/enUS.lua" />
			<File name="locale/esES.lua" />
			<!--<File name="locale/frFR.lua" />-->
			<File name="locale/itIT.lua" />
			<File name="locale/jaJP.lua" />
			<File name="locale/koKR.lua" />
			<File name="locale/ruRU.lua" />
			<File name="locale/zhCN.lua" />
			<File name="locale/zhTW.lua" />

			<File name="source/nLootLinkConstants.lua" />
			<File name="source/nLootLinkUtil.lua" />
			<File name="source/nLootLinkData.lua" />
			<File name="source/nLootLinkGUIIntegration.lua" />
			<File name="source/nLootLinkOptions.lua" />
			<File name="source/nLootLinkChat.lua" />

			<File name="source/nLootLinkTemplates.xml" />
			<File name="source/nLootLinkGUIIntegration.xml" />
			<File name="source/nLootLinkOptions.xml" />

			<File name="source/nLootLink.lua" />
			<File name="source/nLootLinkGatherer.lua" />
			<File name="source/nLootLinkGUI.lua" />
			<File name="source/nLootLinkComm.lua" />

			<File name="source/nLootLinkGUI.xml" />
		</Files>

		<OnInitialize>
			<CreateWindow name="nLootLinkMenuBarWindow" show="true" />
			<CallFunction name="nLootLinkData.init" />
		</OnInitialize>

		<OnUpdate>
			<CallFunction name="nLootLinkData.onUpdate" />
			<CallFunction name="nLootLinkComm.onUpdate" />
		</OnUpdate>

		<OnShutdown/>

		<SavedVariables>
			<SavedVariable name="nLootLinkData.itemDB" global="true" />
			<SavedVariable name="nLootLinkData.versionDB" global="true" />
			<SavedVariable name="nLootLinkData.optionDB" global="true" />
		</SavedVariables>
	</UiMod>
</ModuleFile>
