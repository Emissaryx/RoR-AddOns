--
-- The localization information present within this file is automatically
-- packaged by the CurseForge packager.
--
-- Incorrect or missing translations can be updated here:
-- http://war.curseforge.com/projects/nlootlink/localization/
--

local T = LibStub("WAR-AceLocale-3.0"):NewLocale("nLootLink", "frFR")
if not T then return end

T["Accessories"] = L"Accessories" -- Needs review
T["All"] = L"All" -- Needs review
T["Any Accessory Slot"] = L"Any Accessory Slot" -- Needs review
T["Any Apothecary Type"] = L"Any Apothecary Type" -- Needs review
T["Any Armor Slot"] = L"Any Armor Slot" -- Needs review
T["Any Armor Type"] = L"Any Armor Type" -- Needs review
T["Any Career"] = L"Any Career" -- Needs review
T["Any Category"] = L"Any Category" -- Needs review
T["Any Crafting Item Type"] = L"Any Crafting Item Type" -- Needs review
T["Any Cultivation Type"] = L"Any Cultivation Type" -- Needs review
T["Any Item Type"] = L"Any Item Type" -- Needs review
T["Any Misc Type"] = L"Any Misc Type" -- Needs review
T["Any Rarity"] = L"Any Rarity" -- Needs review
T["Any Slot"] = L"Any Slot" -- Needs review
T["Any Stat"] = L"Any Stat" -- Needs review
T["Any Talisman Making Type"] = L"Any Talisman Making Type" -- Needs review
T["Any Weapon Slot"] = L"Any Weapon Slot" -- Needs review
T["Any Weapon Type"] = L"Any Weapon Type" -- Needs review
T["Apothecary"] = L"Apothecary" -- Needs review
T["Armor"] = L"Armor" -- Needs review
T["BOE"] = L"BOE" -- Needs review
T["BOP"] = L"BOP" -- Needs review
T["Crafting Level"] = L"Crafting Level" -- Needs review
T["Cultivation"] = L"Cultivation" -- Needs review
T["error loading nLootLinkData"] = L"error loading nLootLinkData" -- Needs review
T[" from "] = L" from " -- Needs review
T["Item Name"] = L"Item Name" -- Needs review
T["Minimum Rarity"] = L"Minimum Rarity" -- Needs review
T["Misc"] = L"Misc" -- Needs review
T["Name"] = L"Name" -- Needs review
T["nLootLink adding "] = L"nLootLink adding " -- Needs review
T["nLootLink DB upgrade complete"] = L"nLootLink DB upgrade complete" -- Needs review
T["nLootLink has unpacked %d/%d items, please be patient..."] = L"nLootLink has unpacked %d/%d items, please be patient..." -- Needs review
T["nLootLink Options"] = L"nLootLink Options" -- Needs review
T["nLootLink ready: %d items"] = L"nLootLink ready: %d items" -- Needs review
T["nLootLink received "] = L"nLootLink received " -- Needs review
T["nLootLink received invalid item data from "] = L"nLootLink received invalid item data from " -- Needs review
T["nLootLink unpacking DB..."] = L"nLootLink unpacking DB..." -- Needs review
T["nLootLink upgrading DB to version "] = L"nLootLink upgrading DB to version " -- Needs review
T["Options"] = L"Options" -- Needs review
T["Print new items to chat"] = L"Print new items to chat" -- Needs review
T["Rank"] = L"Rank" -- Needs review
T["Rarity"] = L"Rarity" -- Needs review
T["Renown"] = L"Renown" -- Needs review
T["Reset"] = L"Reset" -- Needs review
T["Search"] = L"Search" -- Needs review
T["Set Items"] = L"Set Items" -- Needs review
T["Show backpack button"] = L"Show backpack button" -- Needs review
T["Show character screen button"] = L"Show character screen button" -- Needs review
T["Skill"] = L"Skill" -- Needs review
T["Talisman Making"] = L"Talisman Making" -- Needs review
T["Type"] = L"Type" -- Needs review
T["Usable"] = L"Usable" -- Needs review
T["Weapons"] = L"Weapons" -- Needs review
T["Yes, I want to change the rarity threshold. On checking this box, the UI will reload and any items lower than the rarity above will be lost."] = L"Yes, I want to change the rarity threshold. On checking this box, the UI will reload and any items lower than the rarity above will be lost." -- Needs review

