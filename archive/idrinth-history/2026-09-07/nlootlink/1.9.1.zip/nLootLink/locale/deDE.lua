--
-- The localization information present within this file is automatically
-- packaged by the CurseForge packager.
--
-- Incorrect or missing translations can be updated here:
-- http://war.curseforge.com/projects/nlootlink/localization/
--

local T = LibStub("WAR-AceLocale-3.0"):NewLocale("nLootLink", "deDE")
if not T then return end

T["Accessories"] = L"Zubeh�r/Schmuck"
T["All"] = L"Alles"
T["Any Accessory Slot"] = L"Jeder Zubeh�rplatz"
T["Any Apothecary Type"] = L"Jeder Pharmaziegegenstand"
T["Any Armor Slot"] = L"Jeder R�stungsplatz"
T["Any Armor Type"] = L"Jede R�stungsart"
T["Any Career"] = L"Jeder Charaktertyp"
T["Any Category"] = L"Jede Kategorie"
T["Any Crafting Item Type"] = L"Jeder Handwerksgegenstand"
T["Any Cultivation Type"] = L"Jedes Anpflanzzubeh�r"
T["Any Item Type"] = L"Jede Gegenstandsart"
T["Any Misc Type"] = L"Verschiedenes"
T["Any Rarity"] = L"Jeder Seltenheitsgrad"
T["Any Slot"] = L"Jeder Platz"
T["Any Stat"] = L"Alle Werte" -- Needs review
T["Any Talisman Making Type"] = L"Jedes Talismanzubeh�r"
T["Any Weapon Slot"] = L"Jede Waffenposition"
T["Any Weapon Type"] = L"Jede Waffenart"
T["Apothecary"] = L"Pharmazie"
T["Armor"] = L"R�stung"
T["BOE"] = L"BOE"
T["BOP"] = L"BOP"
T["Crafting Level"] = L"Handwerksstufe"
T["Cultivation"] = L"Anpflanzen"
T["error loading nLootLinkData"] = L"Fehler beim Laden von nLootLink Daten"
T[" from "] = L"von"
T["Item Name"] = L"Gegenstandsname"
T["Minimum Rarity"] = L"Minimaler Seltenheitsgrad"
T["Misc"] = L"Verschiedenes"
T["Name"] = L"Name"
T["nLootLink adding "] = L"nLootLink f�gt hinzu"
T["nLootLink DB upgrade complete"] = L"nLootLink DB upgrade ist abgeschlossen"
T["nLootLink has unpacked %d/%d items, please be patient..."] = L"nLootLink hat %d/%d Gegenst�nde entpackt. Bitte etwas Geduld..."
T["nLootLink Options"] = L"nLootLink Optionen"
T["nLootLink ready: %d items"] = L"nLootLink ist bereit: %d Gegenst�nde"
T["nLootLink received "] = L"nLootLink hat den folgenden Gegenstand erhalten: " -- Needs review
T["nLootLink received invalid item data from "] = L"nLootLink hat ung�ltige Daten erhalten von"
T["nLootLink unpacking DB..."] = L"nLootLink entpackt die Datenbank..."
T["nLootLink upgrading DB to version "] = L"nLootLink macht einen Datenbankupgrade zu version"
T["Options"] = L"Optionen"
T["Print new items to chat"] = L"Neue Gegenst�nde im Chatfenster ausgeben"
T["Rank"] = L"Rang"
T["Rarity"] = L"Seltenheit"
T["Renown"] = L"Rufrang"
T["Reset"] = L"Zur�cksetzen"
T["Search"] = L"Suchen"
T["Set Items"] = L"Setgegenst�nde"
T["Show backpack button"] = L"Button f�r Rucksack anzeigen" -- Needs review
T["Show character screen button"] = L"Button im Charakterfenster anzeigen"
T["Skill"] = L"F�higkeitslevel"
T["Talisman Making"] = L"Talisman Erstellung"
T["Type"] = L"Typ"
T["Usable"] = L"Verwendbar"
T["Weapons"] = L"Waffen"
T["Yes, I want to change the rarity threshold. On checking this box, the UI will reload and any items lower than the rarity above will be lost."] = L"Ja, ich will den minimalen Seltenheitsgrad �ndern. Durch Auswahl dieser Option wird die Oberfl�che neu geladen und alle Gegenst�nde mit geringerem Seltenheitsgrad gehen verloren."

