<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <UiMod name="xHUD" version="1.0" date="10/25/2008" >

    <Author name="Talvinen" email="redefiance@gmx.de" />
    <Description text="Extended HUD" />
    
    <Dependencies>
      <Dependency name="EA_TargetWindow" />
      <Dependency name="EA_PlayerStatusWindow" />
      <Dependency name="LibSlash" />
    </Dependencies>

    <Files>
      <File name="LibStub.lua" />
      <File name="LibGUI.lua" />
      <File name="xHUD.lua" />
      <File name="xHUDGUI.lua" />
      <File name="xHUDBuffs.lua" />
      <File name="xHUDTexts.lua" />
      <File name="xHUD.xml" />
      <File name="Textures\Textures.xml" />
    </Files>

    <SavedVariables>
      <SavedVariable name="xHUD.Settings" />
      <SavedVariable name="xHUD.Profiles" />
    </SavedVariables>

    <OnInitialize>
      <CallFunction name="xHUD.Initialize" />
    </OnInitialize>
    <OnUpdate>
      <CallFunction name="xHUD.OnUpdate" />
    </OnUpdate>

  </UiMod>
</ModuleFile>
