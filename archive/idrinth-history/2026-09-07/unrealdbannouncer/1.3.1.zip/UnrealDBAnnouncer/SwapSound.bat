@echo off
rem Double-click to put your own WAV files on UnrealDBAnnouncer's sounds.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0SwapSound.ps1"
if errorlevel 1 pause
