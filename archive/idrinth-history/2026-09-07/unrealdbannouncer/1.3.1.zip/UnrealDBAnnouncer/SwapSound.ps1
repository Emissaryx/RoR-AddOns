# SwapSound.ps1 - put your own WAV files on UnrealDBAnnouncer's sound slots.
# Run via SwapSound.bat (double-click). No installation, no admin rights.
#
# What it does:
#   1. Shows every sound slot and what triggers it.
#   2. Opens a file picker for your replacement WAV.
#   3. Checks the file is a plain PCM WAV (anything else plays as silence).
#   4. Backs up the original to files\backup\ (first swap only).
#   5. Copies your file into place under the slot's name.
# Restore originals any time with the R option.
#
# If a copy reports the file is in use, the announcer is usually holding
# it: close it, retry the swap, and start it again afterwards.

$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms | Out-Null

$addonDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$filesDir = Join-Path $addonDir 'files'
$backupDir = Join-Path $filesDir 'backup'

$slots = @(
    @{ Keyword = 'firstblood';          When = 'First kill in a streak' }
    @{ Keyword = 'doublekill';          When = 'Second kill within 5s' }
    @{ Keyword = 'annihilation';        When = 'Kill pool (after >5s since last kill)' }
    @{ Keyword = 'erradication';        When = 'Kill pool (after >5s since last kill)' }
    @{ Keyword = 'extermination';       When = 'Kill pool (after >5s since last kill)' }
    @{ Keyword = 'godlike';             When = 'Kill pool (after >5s since last kill)' }
    @{ Keyword = 'headshot';            When = 'Kill pool (after >5s since last kill)' }
    @{ Keyword = 'dominating';          When = 'Kill pool (after >5s since last kill)' }
    @{ Keyword = 'denied';              When = 'Kill pool (after >5s since last kill)' }
    @{ Keyword = 'wickedsick';          When = 'Kill pool (after >5s since last kill)' }
    @{ Keyword = 'bloodbath';           When = 'Multi-kill pool (3rd+ within 5s)' }
    @{ Keyword = 'holyshit';            When = 'Multi-kill pool (3rd+ within 5s)' }
    @{ Keyword = 'killingspree';        When = 'Multi-kill pool (3rd+ within 5s)' }
    @{ Keyword = 'ludicrous';           When = 'Multi-kill pool (3rd+ within 5s)' }
    @{ Keyword = 'megakill';            When = 'Multi-kill pool (3rd+ within 5s)' }
    @{ Keyword = 'monsterkill1';        When = 'Multi-kill pool (3rd+ within 5s)' }
    @{ Keyword = 'monsterkill2';        When = 'Multi-kill pool (3rd+ within 5s)' }
    @{ Keyword = 'multikill';           When = 'Multi-kill pool (3rd+ within 5s)' }
    @{ Keyword = 'rampage';             When = 'Multi-kill pool (3rd+ within 5s)' }
    @{ Keyword = 'slaughter';           When = 'Multi-kill pool (3rd+ within 5s)' }
    @{ Keyword = 'unstoppable';         When = 'Multi-kill pool (3rd+ within 5s)' }
    @{ Keyword = 'readycheck';          When = 'Ready check / bio prompt' }
    @{ Keyword = 'notify';              When = 'Scenario pop (plus window flash)' }
    @{ Keyword = 'fortressreservation'; When = 'Fortress reservation pop' }
    @{ Keyword = 'lotdticket';          When = 'Land of the Dead ticket pop' }
    @{ Keyword = 'defeat';              When = 'Player death pool (off by default)' }
    @{ Keyword = 'defeat2';             When = 'Player death pool (off by default)' }
    @{ Keyword = 'defeat3';             When = 'Player death pool (off by default)' }
    @{ Keyword = 'defeat4';             When = 'Player death pool (off by default)' }
    @{ Keyword = 'defeat5';             When = 'Player death pool (off by default)' }
    @{ Keyword = 'defeat6';             When = 'Player death pool (off by default)' }
    @{ Keyword = 'defeat7';             When = 'Player death pool (off by default)' }
    @{ Keyword = 'getoverhere';         When = 'Pull alerts: Terrible Embrace / Fetch! (off by default)' }
    @{ Keyword = 'gettothechoppa';      When = 'Pull alert: Git to da Choppa (off by default)' }
    @{ Keyword = 'triplekill';          When = 'Manual play only (/udba play)' }
    @{ Keyword = 'ultrakill';           When = 'Manual play only (/udba play)' }
)

function Test-PcmWav([string]$path) {
    # Walks the RIFF chunks and requires format tag 1 (plain PCM).
    try {
        $bytes = [System.IO.File]::ReadAllBytes($path)
        if ($bytes.Length -lt 44) { return $false }
        $ascii = [System.Text.Encoding]::ASCII
        if ($ascii.GetString($bytes, 0, 4) -ne 'RIFF') { return $false }
        if ($ascii.GetString($bytes, 8, 4) -ne 'WAVE') { return $false }
        $pos = 12
        while ($pos + 8 -le $bytes.Length) {
            $chunkId = $ascii.GetString($bytes, $pos, 4)
            $chunkSize = [BitConverter]::ToUInt32($bytes, $pos + 4)
            if ($chunkId -eq 'fmt ') {
                return ([BitConverter]::ToUInt16($bytes, $pos + 8) -eq 1)
            }
            $pos += 8 + $chunkSize + ($chunkSize % 2)
        }
        return $false
    } catch {
        return $false
    }
}

function Show-Slots {
    Write-Host ''
    Write-Host 'Sound slots:' -ForegroundColor Cyan
    for ($i = 0; $i -lt $slots.Count; $i++) {
        $slot = $slots[$i]
        $marker = ' '
        if (Test-Path -LiteralPath (Join-Path $backupDir ($slot.Keyword + '.wav'))) { $marker = '*' }
        Write-Host ('{0,3}{1} {2,-20} {3}' -f ($i + 1), $marker, $slot.Keyword, $slot.When)
    }
    Write-Host ''
    Write-Host '  * = slot has been swapped (original saved in files\backup)'
}

function Pick-WavFile {
    $dialog = New-Object System.Windows.Forms.OpenFileDialog
    $dialog.Title = 'Pick your replacement WAV'
    $dialog.Filter = 'WAV files (*.wav)|*.wav'
    if ($dialog.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
        return $dialog.FileName
    }
    return $null
}

function Copy-WithRetry([string]$from, [string]$to) {
    for ($attempt = 1; $attempt -le 5; $attempt++) {
        try {
            Copy-Item -LiteralPath $from -Destination $to -Force
            return $true
        } catch [System.IO.IOException] {
            if ($attempt -eq 5) { throw }
            Write-Host ('File is in use - retrying in 1s... [{0}/5]' -f $attempt) -ForegroundColor Yellow
            if ($attempt -eq 1) {
                Write-Host 'If this keeps failing, close the announcer, retry, then start it again.' -ForegroundColor Yellow
            }
            Start-Sleep -Seconds 1
        }
    }
}

function Swap-Slot([hashtable]$slot) {
    $source = Pick-WavFile
    if (-not $source) {
        Write-Host 'Cancelled.' -ForegroundColor Yellow
        return
    }

    if (-not (Test-PcmWav $source)) {
        Write-Host ''
        Write-Host 'That file is not a plain PCM WAV, so the game helper would play SILENCE.' -ForegroundColor Red
        Write-Host 'Convert it first (free option: Audacity -> File -> Export -> WAV, 16-bit PCM).'
        return
    }

    $target = Join-Path $filesDir ($slot.Keyword + '.wav')
    $backup = Join-Path $backupDir ($slot.Keyword + '.wav')

    if ((Test-Path -LiteralPath $target) -and -not (Test-Path -LiteralPath $backup)) {
        New-Item -ItemType Directory -Force -Path $backupDir | Out-Null
        Copy-Item -LiteralPath $target -Destination $backup
        Write-Host ('Original saved to files\backup\{0}.wav' -f $slot.Keyword)
    }

    Copy-WithRetry $source $target | Out-Null

    # Trust nothing: only report success if the slot file now matches the pick.
    $sourceHash = (Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash
    $targetHash = (Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash
    if ($sourceHash -ne $targetHash) {
        Write-Host 'Copy verification FAILED - the slot file does not match your pick.' -ForegroundColor Red
        return
    }
    Write-Host ('Done: {0} now plays {1}' -f $slot.Keyword, (Split-Path $source -Leaf)) -ForegroundColor Green

    $preview = Read-Host 'Preview it now? (y/n)'
    if ($preview -eq 'y') {
        # Play from memory so this window never keeps a lock on the slot file.
        $bytes = [System.IO.File]::ReadAllBytes($target)
        $stream = New-Object System.IO.MemoryStream(,$bytes)
        $player = New-Object System.Media.SoundPlayer $stream
        try { $player.PlaySync() } finally { $player.Dispose(); $stream.Dispose() }
    }
    Write-Host ('In game, test it with: /udba play {0}' -f $slot.Keyword)
}

function Restore-Slots {
    if (-not (Test-Path $backupDir)) {
        Write-Host 'Nothing to restore - no sounds have been swapped yet.' -ForegroundColor Yellow
        return
    }
    $backups = Get-ChildItem $backupDir -Filter '*.wav'
    if ($backups.Count -eq 0) {
        Write-Host 'Nothing to restore - no sounds have been swapped yet.' -ForegroundColor Yellow
        return
    }
    Write-Host ''
    Write-Host 'Swapped slots:' -ForegroundColor Cyan
    $backups | ForEach-Object { Write-Host ('  ' + $_.BaseName) }
    $answer = Read-Host 'Type a slot name to restore it, or ALL to restore everything'
    if ($answer -eq 'ALL') {
        foreach ($file in $backups) {
            Copy-WithRetry $file.FullName (Join-Path $filesDir $file.Name) | Out-Null
            Remove-Item -LiteralPath $file.FullName
        }
        Write-Host 'All originals restored.' -ForegroundColor Green
        return
    }
    $backup = Join-Path $backupDir ($answer + '.wav')
    if (Test-Path -LiteralPath $backup) {
        Copy-WithRetry $backup (Join-Path $filesDir ($answer + '.wav')) | Out-Null
        Remove-Item -LiteralPath $backup
        Write-Host ('Original {0} restored.' -f $answer) -ForegroundColor Green
    } else {
        Write-Host ('No backup found for "{0}".' -f $answer) -ForegroundColor Yellow
    }
}

if (-not (Test-Path $filesDir)) {
    Write-Host 'Cannot find the files folder next to this script - run it from the addon folder.' -ForegroundColor Red
    Read-Host 'Press Enter to close'
    exit 1
}

Write-Host 'UnrealDBAnnouncer sound swapper' -ForegroundColor Cyan
Write-Host 'Puts your own WAV files on the addon''s sound slots. Originals are backed up.'

try {
    while ($true) {
        Show-Slots
        $answer = Read-Host 'Slot number to swap, R to restore originals, Q to quit'
        if ($answer -eq 'q' -or $answer -eq 'Q' -or $answer -eq '') { break }
        if ($answer -eq 'r' -or $answer -eq 'R') {
            Restore-Slots
            continue
        }
        $index = 0
        if ([int]::TryParse($answer, [ref]$index) -and $index -ge 1 -and $index -le $slots.Count) {
            Swap-Slot $slots[$index - 1]
        } else {
            Write-Host 'Not a valid slot number.' -ForegroundColor Yellow
        }
    }
} catch {
    Write-Host ''
    Write-Host ('ERROR: ' + $_.Exception.Message) -ForegroundColor Red
    Write-Host ($_.ScriptStackTrace)
    Read-Host 'Press Enter to close'
}
