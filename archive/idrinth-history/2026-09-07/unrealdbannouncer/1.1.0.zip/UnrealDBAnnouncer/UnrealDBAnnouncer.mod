<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
    <UiMod name="UnrealDBAnnouncer" version="1.1" date="2025-12-26">
        <VersionSettings gameVersion="1.4.8" windowsVersion="1.0" savedVariablesVersion="1.0" />
        <Author name="Ztil, Wholdar" email="" />
        <Description text="Plays sound effects from UT99 or UT03 every time you get a killing blow on another player. Kill two under 5 seconds to trigger a double kill and kill another after that under 5 seconds to trigger a random multi kill sound effect. Just remember that you need to have the UnrealDBAnnouncer.exe running in the background for this addon to work. Also notifies if a Scenario/Fortress or LOTD pops. Optional defeat alert is available (off by default)." />
        <WARInfo>
            <Categories>
                <Category name="RVR" />
                <Category name="GROUPING" />
            </Categories>
            <Careers>
                <Career name="BLACKGUARD" />
                <Career name="WITCH_ELF" />
                <Career name="DISCIPLE" />
                <Career name="SORCERER" />
                <Career name="IRON_BREAKER" />
                <Career name="SLAYER" />
                <Career name="RUNE_PRIEST" />
                <Career name="ENGINEER" />
                <Career name="BLACK_ORC" />
                <Career name="CHOPPA" />
                <Career name="SHAMAN" />
                <Career name="SQUIG_HERDER" />
                <Career name="WITCH_HUNTER" />
                <Career name="KNIGHT" />
                <Career name="BRIGHT_WIZARD" />
                <Career name="WARRIOR_PRIEST" />
                <Career name="CHOSEN" />
                <Career name="MARAUDER" />
                <Career name="ZEALOT" />
                <Career name="MAGUS" />
                <Career name="SWORDMASTER" />
                <Career name="SHADOW_WARRIOR" />
                <Career name="WHITE_LION" />
                <Career name="ARCHMAGE" />
            </Careers>
        </WARInfo>
        <Files>
                <File name="UnrealDBAnnouncer.lua" />
        </Files>
        <SavedVariables>
            <SavedVariable name="UnrealDBAnnouncer.settings" />
        </SavedVariables>
        <OnInitialize>
            <callFunction name="UnrealDBAnnouncer.Initialize"/>
        </OnInitialize>
        <OnShutdown>
            <CallFunction name="UnrealDBAnnouncer.clearLogFile" />
        </OnShutdown>
    </UiMod>
</ModuleFile>
