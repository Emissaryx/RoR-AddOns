UnrealDBAnnouncer = UnrealDBAnnouncer or {}
UnrealDBAnnouncer.settings = UnrealDBAnnouncer.settings or {}
UnrealDBAnnouncer.logFileName = "UnrealDBAnnouncer"
UnrealDBAnnouncer.VERSION = "1.2"
UnrealDBAnnouncer.prefixName = "UnrealDBAnnouncer"
UnrealDBAnnouncer.prefixColor = { 255, 0, 0 }
UnrealDBAnnouncer.helpHeaderColor = { 255, 220, 120 }
UnrealDBAnnouncer.helpCommandColor = { 160, 220, 255 }
UnrealDBAnnouncer.defeatSoundKeywords = {
    "defeat",
    "defeat2",
    "defeat3",
    "defeat4",
    "defeat5",
    "defeat6",
    "defeat7",
}
PlayerName = wstring.sub( GameData.Player.name,1,-3 )
KillSpree = 0
FirstBloodTime = 0

function UnrealDBAnnouncer.Initialize()
    local version = UnrealDBAnnouncer.VERSION or "?"
    EA_ChatWindow.Print(L"----UnrealDBAnnouncer v" .. towstring(version) .. L" loaded----")

    TextLogCreate(UnrealDBAnnouncer.logFileName, 18000)
    TextLogSetEnabled(UnrealDBAnnouncer.logFileName, true)
    TextLogSetIncrementalSaving(UnrealDBAnnouncer.logFileName, true, StringToWString("logs/"..UnrealDBAnnouncer.logFileName..".log"))

    RegisterEventHandler(TextLogGetUpdateEventId("Combat"), "UnrealDBAnnouncer.OnCombatHappened");
    RegisterEventHandler(SystemData.Events.SCENARIO_SHOW_JOIN_PROMPT, "UnrealDBAnnouncer.AnnounceScenarioPop")

    if SystemData and SystemData.Events then
        if SystemData.Events.CITY_CAPTURE_SHOW_JOIN_PROMPT then
            RegisterEventHandler(SystemData.Events.CITY_CAPTURE_SHOW_JOIN_PROMPT, "UnrealDBAnnouncer.AnnounceScenarioPop")
        end
        if SystemData.Events.CITY_CAPTURE_SHOW_LOW_LEVEL_JOIN_PROMPT then
            RegisterEventHandler(SystemData.Events.CITY_CAPTURE_SHOW_LOW_LEVEL_JOIN_PROMPT, "UnrealDBAnnouncer.AnnounceScenarioPop")
        end
        if SystemData.Events.INFO_ALERT then
            RegisterEventHandler(SystemData.Events.INFO_ALERT, "UnrealDBAnnouncer.OnInfoAlertEvent")
        end
        if SystemData.Events.APPLICATION_ONE_BUTTON_DIALOG then
            RegisterEventHandler(SystemData.Events.APPLICATION_ONE_BUTTON_DIALOG, "UnrealDBAnnouncer.OnApplicationOneButtonDialogEvent")
        end
        if SystemData.Events.APPLICATION_TWO_BUTTON_DIALOG then
            RegisterEventHandler(SystemData.Events.APPLICATION_TWO_BUTTON_DIALOG, "UnrealDBAnnouncer.OnApplicationTwoButtonDialogEvent")
        end
        if SystemData.Events.ALL_MODULES_INITIALIZED then
            RegisterEventHandler(SystemData.Events.ALL_MODULES_INITIALIZED, "UnrealDBAnnouncer.OnModulesInitialized")
        end
    end

    UnrealDBAnnouncer.TryHookDialogManager()
    UnrealDBAnnouncer.TryRegisterReadyCheckPacket()
    UnrealDBAnnouncer.RegisterSlashCommands()
    UnrealDBAnnouncer.printAlertSettings()
end

function UnrealDBAnnouncer.OnCombatHappened(updateType, filterType)
    if not ( filterType == SystemData.ChatLogFilters.RVR_KILLS_ORDER or filterType == SystemData.ChatLogFilters.RVR_KILLS_DESTRUCTION )
    then
        return
    end
    if ( updateType ~= SystemData.TextLogUpdate.ADDED ) then
        return
    end

   local msg
   local currenttime
   local num = TextLogGetNumEntries("Combat") - 1
    currenttime, _, msg = TextLogGetEntry("Combat", num);
    --TIMESTAMP
    local hours,mins,secs = currenttime:match(L"([0-9]+):([0-9]+):([0-9]+)")
    local victim, killer = msg:match(L"([%a]+) has been [%a]+ by ([%a]+)'s [%a%d%p ]+ in [^%.]+.")

    if (victim == killer)
    then
        return
    end

    local normalKillTable = { L"annihilation", L"erradication", L"extermination", L"godlike",L"headshot",L"dominating",L"denied",L"wickedsick" }
    local multiKillTable = { L"bloodbath", L"holyshit", L"killingspree", L"ludicrous",L"megakill",L"monsterkill1",L"monsterkill2",L"multikill",L"rampage",L"slaughter",L"unstoppable" }

    if (victim == PlayerName)
    then
        if UnrealDBAnnouncer.getDefeatAlertsEnabled() then
            UnrealDBAnnouncer.logPlaybackKeyword("defeat");
        end
        return
    end


    if (killer==PlayerName) then
        if (KillSpree <1) then
            KillSpree = KillSpree + 1;
            FirstBloodTime=currenttime;
            UnrealDBAnnouncer.logDeathBlow(L"firstblood");
        else
            local fbhours, fbmins, fbsecs = FirstBloodTime:match(L"([0-9]+):([0-9]+):([0-9]+)");
            local fbhoursinsec = tonumber(fbhours) * 3600;
            local fbminutesinsec = tonumber(fbmins) * 60;
            local fbsecsnum = tonumber(fbsecs) or 0;
            local fbtotalsec = fbhoursinsec + fbminutesinsec + fbsecsnum;
            local choursinsec = tonumber(hours) * 3600;
            local cminutesinsec = tonumber(mins) * 60;
            local secsnum = tonumber(secs) or 0;
            local ctotalinsec = choursinsec + cminutesinsec + secsnum;

            local diffsecs = ctotalinsec-fbtotalsec;

            if (diffsecs <5) then
                KillSpree = KillSpree + 1;
                if (KillSpree ==2) then
                    FirstBloodTime=currenttime;
                    UnrealDBAnnouncer.logDeathBlow(L"doublekill");
                    return
                end

                if (KillSpree >2) then
                    FirstBloodTime=currenttime;
                    local killType = multiKillTable[math.random(#multiKillTable)]
                    UnrealDBAnnouncer.logDeathBlow(killType);
                    return
                end

            else
                KillSpree = 1
                FirstBloodTime=currenttime;
                local killType = normalKillTable[math.random(#normalKillTable)]
                UnrealDBAnnouncer.logDeathBlow(killType);
            end
        end
    end
end

function UnrealDBAnnouncer.logDeathBlow(killType)
    TextLogAddEntry(UnrealDBAnnouncer.logFileName, 0, towstring(killType))
    TextLogSaveLog(UnrealDBAnnouncer.logFileName,towstring(""))
end

function UnrealDBAnnouncer.resolvePlaybackKeyword(keyword)
    local name = string.lower(UnrealDBAnnouncer.trim(keyword))
    if name == "defeat" then
        local pool = UnrealDBAnnouncer.defeatSoundKeywords
        return pool[math.random(#pool)]
    end
    return name
end

function UnrealDBAnnouncer.logPlaybackKeyword(keyword)
    local resolved = UnrealDBAnnouncer.resolvePlaybackKeyword(keyword)
    UnrealDBAnnouncer.logDeathBlow(resolved)
    return resolved
end

function UnrealDBAnnouncer.clearLogFile()
    TextLogDestroy("UnrealDBAnnouncer")
    TextLogCreate(UnrealDBAnnouncer.logFileName, 18000)
    TextLogSetEnabled(UnrealDBAnnouncer.logFileName, true)
    TextLogSetIncrementalSaving(UnrealDBAnnouncer.logFileName, true, StringToWString("logs/"..UnrealDBAnnouncer.logFileName..".log"))
end

function UnrealDBAnnouncer.toLowerW(value)
    if not value then
        return L""
    end

    if wstring and wstring.lower then
        return wstring.lower(value)
    end

    local asString = value
    if WStringToString then
        asString = WStringToString(value)
    end

    return towstring(string.lower(tostring(asString)))
end

function UnrealDBAnnouncer.containsAny(haystackW, needles)
    if not haystackW or not needles then
        return false
    end

    for _, needle in ipairs(needles) do
        if needle and wstring.find(haystackW, needle, 1, true) then
            return true
        end
    end

    return false
end

local fortressNeedles = { L"fortress", L"fotress" }
local fortressJoinNeedles = {
    L"reservation",
    L"reserved",
    L"invite",
    L"invitation",
    L"invited",
    L"eligible",
    L"selected",
    L"join",
    L"queue",
    L"queued",
    L"assault",
    L"siege",
    L"instance",
    L"ready",
}
local fortressContextNeedles = {
    L"defender",
    L"attacker",
    L"battle",
    L"siege",
    L"assault",
}
local lotdNeedles = { L"land of the dead", L"lotd" }
local reservationNeedles = { L"reservation", L"reserved" }
local ticketNeedles = { L"ticket", L"invitation", L"permit" }

function UnrealDBAnnouncer.shouldAnnounceFortress(textLower)
    if UnrealDBAnnouncer.containsAny(textLower, fortressNeedles) and UnrealDBAnnouncer.containsAny(textLower, fortressJoinNeedles) then
        return true
    end

    return UnrealDBAnnouncer.containsAny(textLower, reservationNeedles) and UnrealDBAnnouncer.containsAny(textLower, fortressContextNeedles)
end

function UnrealDBAnnouncer.shouldAnnounceLotd(textLower)
    return UnrealDBAnnouncer.containsAny(textLower, lotdNeedles)
        and (UnrealDBAnnouncer.containsAny(textLower, ticketNeedles) or UnrealDBAnnouncer.containsAny(textLower, reservationNeedles))
end

function UnrealDBAnnouncer.combineTextLower(textList)
    local combinedLower = L""
    for _, alertText in pairs(textList) do
        local textLower = UnrealDBAnnouncer.toLowerW(alertText)
        if textLower ~= L"" then
            if combinedLower ~= L"" then
                combinedLower = combinedLower .. L" "
            end
            combinedLower = combinedLower .. textLower
        end
    end
    return combinedLower
end

function UnrealDBAnnouncer.announceFromTextList(textList)
    if not textList then
        return false
    end

    local combinedLower = UnrealDBAnnouncer.combineTextLower(textList)
    if combinedLower ~= L"" then
        if UnrealDBAnnouncer.shouldAnnounceFortress(combinedLower) then
            if UnrealDBAnnouncer.getFortressAlertsEnabled() then
                UnrealDBAnnouncer.logDeathBlow(L"fortressreservation")
                return true
            end
        end

        if UnrealDBAnnouncer.shouldAnnounceLotd(combinedLower) then
            if UnrealDBAnnouncer.getLotdAlertsEnabled() then
                UnrealDBAnnouncer.logDeathBlow(L"lotdticket")
                return true
            end
        end
    end

    return false
end

function UnrealDBAnnouncer.extractDialogText(dialogText)
    if dialogText == nil then
        return nil
    end

    if type(dialogText) == "table" then
        if dialogText.text ~= nil then
            return dialogText.text
        end
        if dialogText[1] ~= nil then
            return dialogText[1]
        end
    end

    return dialogText
end

function UnrealDBAnnouncer.OnDialogText(dialogText)
    local text = UnrealDBAnnouncer.extractDialogText(dialogText)
    if text == nil or text == L"" then
        return
    end

    UnrealDBAnnouncer.announceFromTextList({ text })
end

function UnrealDBAnnouncer.OnInfoAlertEvent()
    if UnrealDBAnnouncer._dialogUseHook then
        return
    end

    if SystemData and SystemData.Dialogs and SystemData.Dialogs.InfoAlert then
        UnrealDBAnnouncer.OnDialogText(SystemData.Dialogs.InfoAlert)
    end
end

function UnrealDBAnnouncer.OnApplicationOneButtonDialogEvent()
    if UnrealDBAnnouncer._dialogUseHook then
        return
    end

    if SystemData and SystemData.Dialogs and SystemData.Dialogs.AppDlg then
        UnrealDBAnnouncer.OnDialogText(SystemData.Dialogs.AppDlg)
    end
end

function UnrealDBAnnouncer.OnApplicationTwoButtonDialogEvent()
    if UnrealDBAnnouncer._dialogUseHook then
        return
    end

    if SystemData and SystemData.Dialogs and SystemData.Dialogs.AppDlg then
        UnrealDBAnnouncer.OnDialogText(SystemData.Dialogs.AppDlg)
    end
end

function UnrealDBAnnouncer.TryHookDialogManager()
    if UnrealDBAnnouncer._dialogHooked then
        return true
    end

    if DialogManager and type(DialogManager.MakeOneButtonDialog) == "function" then
        UnrealDBAnnouncer._dialogHooked = true
        UnrealDBAnnouncer._dialogUseHook = true
        UnrealDBAnnouncer._dialogMakeOneButtonDialog = DialogManager.MakeOneButtonDialog

        DialogManager.MakeOneButtonDialog = function(dialogText, ...)
            local result = UnrealDBAnnouncer._dialogMakeOneButtonDialog(dialogText, ...)
            UnrealDBAnnouncer.OnDialogText(dialogText)
            return result
        end

        if type(DialogManager.MakeTwoButtonDialog) == "function" then
            UnrealDBAnnouncer._dialogMakeTwoButtonDialog = DialogManager.MakeTwoButtonDialog
            DialogManager.MakeTwoButtonDialog = function(dialogText, ...)
                local result = UnrealDBAnnouncer._dialogMakeTwoButtonDialog(dialogText, ...)
                UnrealDBAnnouncer.OnDialogText(dialogText)
                return result
            end
        end

        if type(DialogManager.MakeThreeButtonDialog) == "function" then
            UnrealDBAnnouncer._dialogMakeThreeButtonDialog = DialogManager.MakeThreeButtonDialog
            DialogManager.MakeThreeButtonDialog = function(dialogText, ...)
                local result = UnrealDBAnnouncer._dialogMakeThreeButtonDialog(dialogText, ...)
                UnrealDBAnnouncer.OnDialogText(dialogText)
                return result
            end
        end

        return true
    end

    return false
end

function UnrealDBAnnouncer.OnModulesInitialized()
    UnrealDBAnnouncer.TryHookDialogManager()
    UnrealDBAnnouncer.TryRegisterReadyCheckPacket()
end

function UnrealDBAnnouncer.TryRegisterReadyCheckPacket()
    if UnrealDBAnnouncer._readyCheckPacketRegistered then
        return true
    end

    if not ror_PacketHandling or type(ror_PacketHandling.Register) ~= "function" then
        return false
    end

    local ok = pcall(ror_PacketHandling.Register, "ReadyCheck:", UnrealDBAnnouncer.OnReadyCheckPacket)
    if not ok then
        return false
    end

    UnrealDBAnnouncer._readyCheckPacketRegistered = true
    return true
end

function UnrealDBAnnouncer.extractReadyCheckTitle(packetText)
    local text = UnrealDBAnnouncer.toNarrow(packetText)
    local title = string.match(text, "^ReadyCheck:Start:([^:]*)") or ""
    title = string.gsub(title, "|bool", "")
    return UnrealDBAnnouncer.trim(title)
end

function UnrealDBAnnouncer.OnReadyCheckPacket(packetText)
    if not UnrealDBAnnouncer.getReadyCheckAlertsEnabled() then
        return
    end

    local text = UnrealDBAnnouncer.toNarrow(packetText)
    if string.find(text, "ReadyCheck:Start:", 1, true) ~= 1 then
        return
    end

    UnrealDBAnnouncer.lastReadyCheckTitle = UnrealDBAnnouncer.extractReadyCheckTitle(text)
    UnrealDBAnnouncer.logDeathBlow(L"readycheck")
end

function UnrealDBAnnouncer.AnnounceScenarioPop()
    local scenarioId = GameData and GameData.ScenarioData and GameData.ScenarioData.startingScenario
    if scenarioId and scenarioId ~= 0 and GetScenarioName then
        local ok, scenarioName = pcall(GetScenarioName, scenarioId)
        if ok and scenarioName and scenarioName ~= L"" then
            if UnrealDBAnnouncer.containsAny(UnrealDBAnnouncer.toLowerW(scenarioName), fortressNeedles) then
                if UnrealDBAnnouncer.getFortressAlertsEnabled() then
                    UnrealDBAnnouncer.logDeathBlow(L"fortressreservation")
                end
                return
            end
        end
    end

    if UnrealDBAnnouncer.getScenarioPopAlertsEnabled() then
        UnrealDBAnnouncer.logDeathBlow(L"scenariopop")
    end
end

function UnrealDBAnnouncer.toNarrow(value)
    if value == nil then
        return ""
    end

    if type(value) == "wstring" and WStringToString then
        local ok, narrowed = pcall(WStringToString, value)
        if ok and narrowed then
            return narrowed
        end
    end

    return tostring(value)
end

function UnrealDBAnnouncer.toWide(value)
    if value == nil then
        return L""
    end

    if type(value) == "wstring" then
        return value
    end

    if towstring then
        local ok, widened = pcall(towstring, tostring(value))
        if ok and widened then
            return widened
        end
    end

    return L""
end

function UnrealDBAnnouncer.makeColorLink(text, color)
    local label = UnrealDBAnnouncer.toNarrow(text)
    local red, green, blue = 255, 255, 255
    if type(color) == "table" then
        red = tonumber(color[1]) or red
        green = tonumber(color[2]) or green
        blue = tonumber(color[3]) or blue
    end
    return string.format("<LINK data=\"0\" color=\"%d,%d,%d\" text=\"%s\">", red, green, blue, label)
end

function UnrealDBAnnouncer.getChatPrefix()
    if UnrealDBAnnouncer._chatPrefixCache then
        return UnrealDBAnnouncer._chatPrefixCache
    end

    local name = UnrealDBAnnouncer.prefixName or "UnrealDBAnnouncer"
    local colored = UnrealDBAnnouncer.makeColorLink(name, UnrealDBAnnouncer.prefixColor)
    UnrealDBAnnouncer._chatPrefixCache = towstring("[" .. colored .. "] ")
    return UnrealDBAnnouncer._chatPrefixCache
end

function UnrealDBAnnouncer.formatHelpHeader(label)
    return UnrealDBAnnouncer.makeColorLink(label, UnrealDBAnnouncer.helpHeaderColor)
end

function UnrealDBAnnouncer.getHelpCommandPrefix()
    return UnrealDBAnnouncer.makeColorLink("/udba", UnrealDBAnnouncer.helpCommandColor)
end

function UnrealDBAnnouncer.chatPrint(message)
    local output = UnrealDBAnnouncer.getChatPrefix() .. UnrealDBAnnouncer.toWide(message)
    if TextLogAddEntry then
        TextLogAddEntry("Chat", 0, output)
        return
    end
    if EA_ChatWindow and EA_ChatWindow.Print then
        EA_ChatWindow.Print(output)
    end
end

function UnrealDBAnnouncer.trim(value)
    local str = UnrealDBAnnouncer.toNarrow(value)
    str = string.gsub(str, "^%s+", "")
    str = string.gsub(str, "%s+$", "")
    return str
end

function UnrealDBAnnouncer.ensureSettings()
    if type(UnrealDBAnnouncer.settings) ~= "table" then
        UnrealDBAnnouncer.settings = {}
    end
end

function UnrealDBAnnouncer.getSettingBool(settingKey, defaultValue)
    UnrealDBAnnouncer.ensureSettings()
    local value = UnrealDBAnnouncer.settings[settingKey]
    if value == nil then
        value = defaultValue and true or false
        UnrealDBAnnouncer.settings[settingKey] = value
    end
    return value and true or false
end

function UnrealDBAnnouncer.setSettingBool(settingKey, enabled)
    UnrealDBAnnouncer.ensureSettings()
    local value = enabled and true or false
    UnrealDBAnnouncer.settings[settingKey] = value
    return value
end

function UnrealDBAnnouncer.getScenarioPopAlertsEnabled()
    return UnrealDBAnnouncer.getSettingBool("scenarioPopAlertsEnabled", true)
end

function UnrealDBAnnouncer.getReadyCheckAlertsEnabled()
    return UnrealDBAnnouncer.getSettingBool("readyCheckAlertsEnabled", true)
end

function UnrealDBAnnouncer.setReadyCheckAlertsEnabled(enabled, announce)
    local value = UnrealDBAnnouncer.setSettingBool("readyCheckAlertsEnabled", enabled)
    if announce then
        UnrealDBAnnouncer.chatPrint("Ready check alerts: " .. (value and "ON" or "OFF"))
    end
end

function UnrealDBAnnouncer.setScenarioPopAlertsEnabled(enabled, announce)
    local value = UnrealDBAnnouncer.setSettingBool("scenarioPopAlertsEnabled", enabled)
    if announce then
        UnrealDBAnnouncer.chatPrint("Scenario pop alerts: " .. (value and "ON" or "OFF"))
    end
end

function UnrealDBAnnouncer.getFortressAlertsEnabled()
    return UnrealDBAnnouncer.getSettingBool("fortressReservationAlertsEnabled", true)
end

function UnrealDBAnnouncer.setFortressAlertsEnabled(enabled, announce)
    local value = UnrealDBAnnouncer.setSettingBool("fortressReservationAlertsEnabled", enabled)
    if announce then
        UnrealDBAnnouncer.chatPrint("Fortress reservation alerts: " .. (value and "ON" or "OFF"))
    end
end

function UnrealDBAnnouncer.getLotdAlertsEnabled()
    return UnrealDBAnnouncer.getSettingBool("lotdTicketAlertsEnabled", true)
end

function UnrealDBAnnouncer.setLotdAlertsEnabled(enabled, announce)
    local value = UnrealDBAnnouncer.setSettingBool("lotdTicketAlertsEnabled", enabled)
    if announce then
        UnrealDBAnnouncer.chatPrint("LotD ticket alerts: " .. (value and "ON" or "OFF"))
    end
end

function UnrealDBAnnouncer.getDefeatAlertsEnabled()
    return UnrealDBAnnouncer.getSettingBool("defeatAlertsEnabled", false)
end

function UnrealDBAnnouncer.setDefeatAlertsEnabled(enabled, announce)
    local value = UnrealDBAnnouncer.setSettingBool("defeatAlertsEnabled", enabled)
    if announce then
        UnrealDBAnnouncer.chatPrint("Defeat alerts: " .. (value and "ON" or "OFF"))
    end
end

function UnrealDBAnnouncer.printScenarioPopStatus()
    local enabled = UnrealDBAnnouncer.getScenarioPopAlertsEnabled()
    UnrealDBAnnouncer.chatPrint("Scenario pop alerts: " .. (enabled and "ON" or "OFF"))
end

function UnrealDBAnnouncer.printReadyCheckStatus()
    local enabled = UnrealDBAnnouncer.getReadyCheckAlertsEnabled()
    UnrealDBAnnouncer.chatPrint("Ready check alerts: " .. (enabled and "ON" or "OFF"))
end

function UnrealDBAnnouncer.printFortressStatus()
    local enabled = UnrealDBAnnouncer.getFortressAlertsEnabled()
    UnrealDBAnnouncer.chatPrint("Fortress reservation alerts: " .. (enabled and "ON" or "OFF"))
end

function UnrealDBAnnouncer.printLotdStatus()
    local enabled = UnrealDBAnnouncer.getLotdAlertsEnabled()
    UnrealDBAnnouncer.chatPrint("LotD ticket alerts: " .. (enabled and "ON" or "OFF"))
end

function UnrealDBAnnouncer.printDefeatStatus()
    local enabled = UnrealDBAnnouncer.getDefeatAlertsEnabled()
    UnrealDBAnnouncer.chatPrint("Defeat alerts: " .. (enabled and "ON" or "OFF"))
end

function UnrealDBAnnouncer.printAlertSettings()
    UnrealDBAnnouncer.printReadyCheckStatus()
    UnrealDBAnnouncer.printScenarioPopStatus()
    UnrealDBAnnouncer.printFortressStatus()
    UnrealDBAnnouncer.printLotdStatus()
    UnrealDBAnnouncer.printDefeatStatus()
end

function UnrealDBAnnouncer.printStatus()
    UnrealDBAnnouncer.chatPrint("Version: " .. (UnrealDBAnnouncer.VERSION or "?"))
    UnrealDBAnnouncer.printAlertSettings()
end

function UnrealDBAnnouncer.applyAlertOption(option, getter, setter, label)
    local normalized = string.lower(UnrealDBAnnouncer.trim(option))
    if normalized == "" or normalized == "status" then
        UnrealDBAnnouncer.chatPrint(label .. ": " .. (getter() and "ON" or "OFF"))
        return true
    end

    if normalized == "on" or normalized == "enable" or normalized == "enabled" then
        setter(true, true)
        return true
    end

    if normalized == "off" or normalized == "disable" or normalized == "disabled" then
        setter(false, true)
        return true
    end

    if normalized == "toggle" then
        setter(not getter(), true)
        return true
    end

    return false
end

function UnrealDBAnnouncer.normalizeAlertKey(name)
    if name == "readycheck" or name == "ready" or name == "bio" then
        return "readycheck"
    end
    if name == "scenario" or name == "scenariopop" or name == "scen" or name == "pop" then
        return "scenario"
    end
    if name == "fortress" or name == "fortressreservation" then
        return "fortress"
    end
    if name == "lotd" or name == "lotdticket" then
        return "lotd"
    end
    if name == "defeat" or name == "death" then
        return "defeat"
    end
    return ""
end

function UnrealDBAnnouncer.handleAlertCommand(rest)
    local nameRaw, optionRaw = string.match(rest or "", "^(%S+)%s*(.*)$")
    local name = string.lower(UnrealDBAnnouncer.trim(nameRaw))
    local option = UnrealDBAnnouncer.trim(optionRaw)

    if name == "" or name == "status" or name == "list" or name == "show" then
        UnrealDBAnnouncer.printAlertSettings()
        return
    end

    local key = UnrealDBAnnouncer.normalizeAlertKey(name)
    if key == "" then
        UnrealDBAnnouncer.chatPrint("Usage: /udba alerts [readycheck|scenario|fortress|lotd|defeat] [on|off|toggle]")
        return
    end

    local ok = false
    if key == "readycheck" then
        ok = UnrealDBAnnouncer.applyAlertOption(option, UnrealDBAnnouncer.getReadyCheckAlertsEnabled, UnrealDBAnnouncer.setReadyCheckAlertsEnabled, "Ready check alerts")
    elseif key == "scenario" then
        ok = UnrealDBAnnouncer.applyAlertOption(option, UnrealDBAnnouncer.getScenarioPopAlertsEnabled, UnrealDBAnnouncer.setScenarioPopAlertsEnabled, "Scenario pop alerts")
    elseif key == "fortress" then
        ok = UnrealDBAnnouncer.applyAlertOption(option, UnrealDBAnnouncer.getFortressAlertsEnabled, UnrealDBAnnouncer.setFortressAlertsEnabled, "Fortress reservation alerts")
    elseif key == "lotd" then
        ok = UnrealDBAnnouncer.applyAlertOption(option, UnrealDBAnnouncer.getLotdAlertsEnabled, UnrealDBAnnouncer.setLotdAlertsEnabled, "LotD ticket alerts")
    elseif key == "defeat" then
        ok = UnrealDBAnnouncer.applyAlertOption(option, UnrealDBAnnouncer.getDefeatAlertsEnabled, UnrealDBAnnouncer.setDefeatAlertsEnabled, "Defeat alerts")
    end

    if not ok then
        UnrealDBAnnouncer.chatPrint("Usage: /udba alerts [readycheck|scenario|fortress|lotd|defeat] [on|off|toggle]")
    end
end

local slashAliases = {
    ready = "readycheck",
    bio = "readycheck",
    scenario = "scenariopop",
    scen = "scenariopop",
    pop = "scenariopop",
    fortress = "fortressreservation",
    lotd = "lotdticket",
}

local slashKeywords = {
    "firstblood",
    "doublekill",
    "triplekill",
    "ultrakill",
    "killingspree",
    "multikill",
    "monsterkill1",
    "monsterkill2",
    "wickedsick",
    "godlike",
    "annihilation",
    "erradication",
    "extermination",
    "dominating",
    "denied",
    "headshot",
    "holyshit",
    "bloodbath",
    "megakill",
    "ludicrous",
    "rampage",
    "slaughter",
    "unstoppable",
    "defeat",
    "defeat2",
    "defeat3",
    "defeat4",
    "defeat5",
    "defeat6",
    "defeat7",
    "readycheck",
    "scenariopop",
    "fortressreservation",
    "lotdticket",
    "notify",
}

local slashKeywordLookup = {}
for _, keyword in ipairs(slashKeywords) do
    slashKeywordLookup[keyword] = true
end

function UnrealDBAnnouncer.printSlashUsage()
    local cmd = UnrealDBAnnouncer.getHelpCommandPrefix()
    UnrealDBAnnouncer.chatPrint(UnrealDBAnnouncer.formatHelpHeader("Commands"))
    UnrealDBAnnouncer.chatPrint(cmd .. " play <keyword> -- play a known sound keyword (known keywords can omit 'play')")
    UnrealDBAnnouncer.chatPrint(cmd .. " list -- list known keywords and aliases")
    UnrealDBAnnouncer.chatPrint(cmd .. " alerts [readycheck|scenario|fortress|lotd|defeat] [on|off|toggle] -- show or change alert toggles")
end

function UnrealDBAnnouncer.printSlashKeywords()
    local cmd = UnrealDBAnnouncer.getHelpCommandPrefix()
    UnrealDBAnnouncer.chatPrint(UnrealDBAnnouncer.formatHelpHeader("Sound Keywords"))
    UnrealDBAnnouncer.printKeywordList(slashKeywords, "Known: ", 8)
    UnrealDBAnnouncer.chatPrint(UnrealDBAnnouncer.formatHelpHeader("Aliases"))
    UnrealDBAnnouncer.chatPrint("ready/bio -> readycheck")
    UnrealDBAnnouncer.chatPrint("scenario/scen/pop -> scenariopop")
    UnrealDBAnnouncer.chatPrint("fortress -> fortressreservation; lotd -> lotdticket")
end

function UnrealDBAnnouncer.printKeywordList(list, label, chunkSize)
    if type(list) ~= "table" or #list == 0 then
        return
    end

    local size = tonumber(chunkSize) or 8
    local prefix = label or ""
    local total = #list
    local index = 1
    while index <= total do
        local segment = {}
        local stopAt = math.min(total, index + size - 1)
        for i = index, stopAt do
            segment[#segment + 1] = list[i]
        end
        UnrealDBAnnouncer.chatPrint(prefix .. table.concat(segment, ", "))
        prefix = ""
        index = stopAt + 1
    end
end

function UnrealDBAnnouncer.applySlashAlias(keyword)
    local aliased = slashAliases[keyword]
    if aliased then
        return aliased
    end
    return keyword
end

function UnrealDBAnnouncer.resolveKnownKeyword(rawKeyword)
    local keyword = string.lower(UnrealDBAnnouncer.trim(rawKeyword))
    if keyword == "" then
        return nil
    end

    keyword = UnrealDBAnnouncer.applySlashAlias(keyword)
    if slashKeywordLookup[keyword] then
        return keyword
    end

    return nil
end

function UnrealDBAnnouncer.playKeyword(keyword)
    local resolved = UnrealDBAnnouncer.logPlaybackKeyword(keyword)
    UnrealDBAnnouncer.chatPrint("Triggered alert: " .. resolved)
end

function UnrealDBAnnouncer.handlePlayCommand(rest)
    local keyword = string.match(rest or "", "^(%S+)")
    keyword = string.lower(UnrealDBAnnouncer.trim(keyword))
    if keyword == "" then
        UnrealDBAnnouncer.chatPrint("Usage: /udba play <keyword> (use /udba list for known keywords)")
        return
    end

    local resolved = UnrealDBAnnouncer.resolveKnownKeyword(keyword)
    if not resolved then
        UnrealDBAnnouncer.chatPrint("Unknown keyword. Use /udba list.")
        return
    end

    UnrealDBAnnouncer.playKeyword(resolved)
end

function UnrealDBAnnouncer.OnSlashCommand(input)
    local asString = string.lower(UnrealDBAnnouncer.trim(input))
    if asString == "" then
        UnrealDBAnnouncer.printSlashUsage()
        return
    end

    local actionRaw, restRaw = string.match(asString, "^(%S+)%s*(.*)$")
    local action = string.lower(actionRaw or "")
    local rest = UnrealDBAnnouncer.trim(restRaw)

    if action == "help" or action == "?" then
        UnrealDBAnnouncer.printSlashUsage()
        return
    end

    if action == "list" or action == "keywords" or action == "sounds" then
        UnrealDBAnnouncer.printSlashKeywords()
        return
    end

    if action == "alerts" or action == "alert" then
        UnrealDBAnnouncer.handleAlertCommand(rest)
        return
    end

    if action == "status" then
        UnrealDBAnnouncer.printStatus()
        return
    end

    if action == "play" or action == "trigger" or action == "test" then
        UnrealDBAnnouncer.handlePlayCommand(rest)
        return
    end

    local keyword = UnrealDBAnnouncer.resolveKnownKeyword(action)
    if keyword then
        UnrealDBAnnouncer.playKeyword(keyword)
        return
    end

    UnrealDBAnnouncer.chatPrint("Unknown command or keyword. Use /udba help or /udba list.")
end

-- Registers slash commands when LibSlash is available.
function UnrealDBAnnouncer.RegisterSlashCommands()
    if LibSlash and LibSlash.RegisterSlashCmd then
        local registered = {}
        local okShort = pcall(LibSlash.RegisterSlashCmd, "udba", UnrealDBAnnouncer.OnSlashCommand)
        if okShort then
            registered[#registered + 1] = "/udba"
        end

        local okLong = pcall(LibSlash.RegisterSlashCmd, "unrealdbannouncer", UnrealDBAnnouncer.OnSlashCommand)
        if okLong then
            registered[#registered + 1] = "/unrealdbannouncer"
        end

        if #registered > 0 then
            UnrealDBAnnouncer.chatPrint("LibSlash detected; commands: " .. table.concat(registered, ", ") .. ".")
        else
            UnrealDBAnnouncer.chatPrint(L"LibSlash detected but slash commands could not be registered.")
        end
        return
    end

    UnrealDBAnnouncer.chatPrint(L"LibSlash not found; slash commands unavailable.")
end
