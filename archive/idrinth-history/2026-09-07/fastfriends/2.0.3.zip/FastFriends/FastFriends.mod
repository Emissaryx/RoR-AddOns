<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
	<UiMod name="FastFriends" version="2.03" date="2025-09-20">
		<Author name="Wholdar" email="" />
		<Description text="Allows you to keep track of friends (and foes) across characters. Originally by shammus." />
		<VersionSettings gameVersion="1.4.8" windowsVersion="1.0" savedVariablesVersion="1.0" />
		<Dependencies>
			<Dependency name="FastFriendsChar" />
			<Dependency name="LibSlash" />
			<Dependency name="EASystem_WindowUtils"/>
		</Dependencies>
		<Files>
			<File name="FastFriends.lua" />
			<File name="FastFriends_ConfigUI.xml" />
			<File name="FastFriends_ConfigUI.lua" />
		</Files>
		<OnInitialize>
			<CallFunction name="FastFriends.OnInitialize" />
		</OnInitialize>
        <OnUpdate>
            <CallFunction name="FastFriends.OnUpdate" />
        </OnUpdate>
		<OnShutdown>
			<CallFunction name="FastFriends.OnShutdown" />
		</OnShutdown>
		<SavedVariables>
			<SavedVariable name="FastFriendsDB" global="true" />
		</SavedVariables>
	</UiMod>
</ModuleFile>
