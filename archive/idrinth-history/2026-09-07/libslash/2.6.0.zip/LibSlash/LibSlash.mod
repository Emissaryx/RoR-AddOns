<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
	<UiMod name="LibSlash" version="2.6" date="03/2/2009" >

		<Author name="Aiiane" email="aiiane@aiiane.net" />
		<Description text="Simple library for registering handlers for slash commands." />
		
    <Dependencies>
        <Dependency name="EASystem_LayoutEditor" />
        <Dependency name="EA_ChatWindow" />
        <Dependency name="EA_UiModWindow" />
    </Dependencies>
        
		<Files>
			<File name="LibSlash.lua" />
		</Files>
		
		<OnInitialize>
			<CallFunction name="LibSlash.Initialize" />
		</OnInitialize>
		<OnUpdate/>
		<OnShutdown/>
		
	</UiMod>
</ModuleFile>
