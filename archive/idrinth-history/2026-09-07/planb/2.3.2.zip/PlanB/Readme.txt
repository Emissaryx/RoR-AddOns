Planned Balance, AKA PlanB

This mod will automatically switch the page displayed in a hotbar when a Swordmaster's Balance or a Black Orc's Plan changes.  By default, the first hotbar is swapped as follows:

No Plan / Normal Balance = Hotbar page 1
Good Plan / Improved Balance = Hotbar page 2
Best Plan / Perfect Balance = Hotbar page 3

Slash Commands for PlanB:

/planb			toggle the mod on or off
/planb hotbar=#		set the hotbar the mod will swap to # (1 through 4)
/planb pages=#,#,#	set the hotbar pages to use for each plan/balance state to # (1 through 5)
/planb pagemax=#	set the maximum number of pages you can scroll to on your hotbars
/planb settings		show the settings the mod is using, and whether it is compatible with your career
/planb silent		on/off toggle for chat window spam when the /planb command is used
/planb usage		see help on slash commands for PlanB

To toggle PlanB on and off in a macro, set the macro text to: /script slash("planb")

This mod requires the LibSlash mod by Aiiane, version 2.1 or later!

Have fun!

~FuriousGuy

Version 2.3b changes
- Quickfix for 1.3.1, replaced string.gmatch with a locally defined function

Version 2.3 changes
- PlanB will no longer remain active when you log out and into an incompatible career

Version 2.2 changes
- Added a handler for /reloadui so you don't have to toggle the mod off and on again

Version 2.1 changes
- Added slash command /planb pagemax=#, for setting the maximum number of pages shown on a hotbar
- Pages 1 through 9 are now allowed when using /planb pages=#,#,#

Version 2.0 Changes
- Several new slash commands added (see above)
- PlanB will now save your settings from session to session; no more editing the settings file manually!
- PlanB will no longer give spam after a loading screen; use /planb status to check if it's on
- Code overhaul by Dorgudurk (thanks man!)

Version 1.4 Changes
- Fixed a problem introduced by the WAR 1.01 patch (ChatWindow => EA_ChatWindow)

Version 1.3 Changes
- Changed from checking career string to the career line number to determine class compatibility (avoids localization issues)
- Added an event handler for player death in order to reset hotbar to normal balance
- Added an event handler for loading to make sure the mod turns on properly for SMs and BOs.

Version 1.2 Changes
- Added a settings file & function to allow easy modification of mod settings by users
- Settings allow user to choose which hotbar page to display for each balance state
- Settings allow user to choose which hotbar to swap when balance state changes
- The /planb command will no longer enable the mod unless playing Swordmaster or Black Orc

Version 1.1 Changes
- The mod now only enables itself at login for Swordmasters and Black Orcs.
- Streamlined some coding.
