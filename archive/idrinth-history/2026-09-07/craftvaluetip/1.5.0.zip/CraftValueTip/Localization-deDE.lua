--[[
  Crafting Info Tooltip v1.40

  Crafting Info Tooltip (CraftValueTip) is an addon for Warhammer: Age of 
  Reckoning which displays the hidden stats on crafting items as part of the 
  tooltip.

  This file, Localization.lua, contains all of the text so that it can be
  translated and replaced easily.
]]--

--d("Local")

CraftValueTip.T[SystemData.Settings.Language.GERMAN]={
	Bonuses = {
		bonus1 = L"Stabilit�t",
		bonus10 = L"Wachstumszeit (Abschnitt)",
		bonus11 = L"Pflanzenanzahl",
		bonus12 = L"Kritischer Erfolg",
		bonus13 = L"Kritischer Fehlschlag",
		bonus14 = L"Spezieller Moment",
		bonus15 = L"Zerbrechlich",
		bonus2 = L"Kraft",
		bonus3 = L"Dauer",
		bonus4 = L"Multiplikator",
		bonus5 = L"Tradeskill", -- Requires localization
		bonus6 = L"Effekt",
		bonus7 = L"Pl�tze",
		bonus8 = L"Item Type", -- Requires localization
		bonus9 = L"Requires Level", -- Requires localization
	},
	EffectNames = {
		acc = L"Genauigkeit",
		ap = L"Ausdauerpunkte",
		apdrain = L"AP Drain on Your Damage", -- Requires localization
		arm = L"R�stung",
		autoheal = L"Reactive Heal", -- Requires localization
		crit = L"Melee Crit", -- Requires localization
		dmg = L"Feurig",
		dmgaoe = L"Feurige Explosion",
		dmgcone = L"Feueratem",
		dyeblue = L"Seegardisten-Blau",
		dyebrown = L"Branntbraun",
		dyegreen = L"Goblingr�n",
		dyepurple = L"Lichlila",
		dyered = L"Wundrot",
		dyeyellow = L"Goldgelb",
		freecast = L"Free Cast Chance", -- Requires localization
		hcrit = L"Healing Crit", -- Requires localization
		heal = L"Heilung",
		hpower = L"Healing Power", -- Requires localization
		hyaccrcrit = L"Ballistik und kritische Fernkampftreffer",
		hyintmcrit = L"Intelligenz und kritische Magietreffer",
		hystrheal = L"St�rke und Heilungsbonus",
		hystrmelee = L"St�rke und Nahkampfbonus",
		hytoucrit = L"Widerstand und kritische Nahkampftreffer",
		hywillheal = L"Willenskraft und Heilungsbonus",
		hywoucrit = L"Leben und kritische Nahkampftreffer",
		hywouheal = L"Leben und Heilung",
		hywoumcrit = L"Leben und kritische Magietreffer",
		hywoumelee = L"Leben und Nahkampfbonus",
		hywourcrit = L"Leben und kritische Fernkampftreffer",
		hywoustr = L"Leben und St�rke",
		ini = L"Initiative",
		int = L"Intelligenz",
		mgcrit = L"Magic Crit", -- Requires localization
		mgpower = L"Magic Power", -- Requires localization
		morale = L"Moralgewinn",
		movespeed = L"Move Speed", -- Requires localization
		mpower = L"Melee Power", -- Requires localization
		mskill = L"Kampfgeschick",
		pet = L"Summon Pet", -- Requires localization
		rcorp = L"K�rperresistenz",
		rcrit = L"Ranged Crit", -- Requires localization
		reactspd = L"Move Speed on Enemy Damage", -- Requires localization
		regen = L"Regeneration",
		rele = L"Elementarresistenz",
		rez = L"Wiederbelebung",
		rpower = L"Ranged Power", -- Requires localization
		rskill = L"Ballistik",
		rspi = L"Geistresistenz",
		shabs = L"Absorbtion",
		shdmg = L"Dornenschild",
		snare = L"Verlangsamung",
		str = L"St�rke",
		tou = L"Widerstand",
		trapoth = L"Pharmazie",
		trcult = L"Anpflanzen",
		trsalv = L"Magisches Verwerten",
		trtal = L"Talismanherstellung",
		wil = L"Willenskraft",
		wou = L"Leben",
	},
	EffectTiers = {
		tier0 = L"{1} (Tier 0)", -- Requires localization
		tier1 = L"{1} (Tier 1)", -- Requires localization
		tier2 = L"{1} (Tier 2)", -- Requires localization
		tier3 = L"{1} (Tier 3)", -- Requires localization
		tier4 = L"{1} (Tier 4)", -- Requires localization
		tier5 = L"{1} (Tier 5)", -- Requires localization
	},
	Format = {
		bonus = L"Bonus {1}", -- Requires localization
		effect = L"Effect={1}", -- Requires localization
		grows = L"Grows {1}", -- Requires localization
	},
	ItemTypes = {
		cult1 = L"Samen", -- Needs review
		cult2 = L"Erde", -- Needs review
		cult3 = L"Gie�kanne", -- Needs review
		cult4 = L"N�hrstoff", -- Needs review
		cult5 = L"Spore", -- Needs review
		item1 = L"Stabilisierer", -- Needs review
		item13 = L"Beh�ltnis", -- Needs review
		item14 = L"Fragment", -- Needs review
		item15 = L"Gold", -- Needs review
		item16 = L"Kuriosit�t", -- Needs review
		item17 = L"Magieessenz", -- Needs review
		item18 = L"Anreger", -- Needs review
		item2 = L"Hauptzutat", -- Needs review
		item3 = L"Verl�ngerer", -- Needs review
		item4 = L"Multiplikator", -- Needs review
		item5 = L"Beh�ltnis", -- Needs review
		item6 = L"Farbenbeh�ltnis", -- Needs review
		item8 = L"Pigment", -- Needs review
		item9 = L"Fixierer", -- Needs review
	},
	Messages = {
		DebugOff = L"CraftValueTip: Entwickler-Modus deaktiviert",
		DebugOn = L"CraftValueTip: Entwickler-Modus aktiviert",
		Greeting = L"Crafting Info Tooltip von Irinia of Volkmar geladen.  Benutze /craftvaluetip help f�r die Befehlsliste",
		List0 = L"/craftvaluetip -- �ffnet das Konfigurations-Fenster",
		List1 = L"/craftvaluetip off -- Zeigt nur normale Kurzinfos an",
		List2 = L"/craftvaluetip on -- Zeigt die erweiterten Kurzinfos an",
		List3 = L"/craftvaluetip dev off -- Verbirgt f�r Entwickler interessante Werte",
		List4 = L"/craftvaluetip dev on -- Zeigt f�r Entwickler interessante Werte an",
		List5 = L"/craftvaluetip dump -- Zeigt die gesamten Objektdaten der zuletzt gesehenen Kurzinfo an",
		List6 = L"/craftvaluetip digest -- Zeigt die wichtigsten Objektdaten der zuletzt gesehenen Kurzinfo an",
		List7 = L"/craftvaluetip seed {off|plant|pigment|both} -- Bestimmt die gew�nschten Informationen in Kurzinfos f�r Samen und Sporen",
		SeedDyeOff = L"CraftValueTip: Kurzinfos von Samen und Sporen zeigen keine m�glichen Pigmentfarben",
		SeedDyeOn = L"Kurzinfos von Samen und Sporen zeigen die m�glichen Pigmentfarben",
		SeedPlantOff = L"CraftValueTip: Kurzinfos von Samen und Sporen zeigen keine Boni daraus wachsender Pflanzen",
		SeedPlantOn = L"CraftValueTip: Kurzinfos von Samen und Sporen zeigen die Boni daraus wachsender Pflanzen",
		TipOff = L"CraftValueTip: Normale Kurzinfos werden angezeigt",
		TipOn = L"CraftValueTip: Erweiterte Kurzinfos werden angezeigt",
	},
	Prof = {
		prof3 = L"Anpflanzen",
		prof4 = L"Pharmazie",
		prof5 = L"Talisman-Herstellung",
		prof6 = L"Verwerten", -- Needs review
	},
	SeedClasses = {
		purch = L"Gekauft",
		quest = L"Quest",
		rare = L"Selten",
		std = L"Standard",
	},
	config = {
		langdefault = L"Benutze standardm��ige Sprache",
		langthis = L"Deutsch",
		language = L"Sprache",
		showdev = L"Zeige Entwicklungs-Infos",
		showinfo = L"Zeige handwerkliche Stats",
		tabtip = L"Crafting Info Tooltip",
		version = L"Crafting Info Tooltip von Irinia of Volkmar v{1}",
	},
}
