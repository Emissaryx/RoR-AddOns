# TuffAlert (RoR addon)

TuffAlert is a Return of Reckoning (WAR) UI addon that shows a small icon popup (up to 4 simultaneous icons) and optionally plays a sound when specific combat abilities hit your character.

This folder is named `TuffAlert` on disk and the addon/module name is `TuffAlert` (see `TuffAlert.mod`).

## Quick start (in game)

1. Reload the UI to ensure the addon is loaded: `/reloadui`
2. Open the config window: `/tuffalert`
3. Ensure the addon is enabled:
  - In the config window, toggle the **Enabled:** checkbox on (or run `/tuffalert on`).
4. Add an ability:
  - Enter an **Ability ID** (the numeric ability ID that appears in combat events).
  - Enter a **Name** (just for display in the list).
  - Click **+ Add**.
5. Test the alert:
  - `/tuffalert test` (triggers the lowest enabled ability ID), or
  - `/tuffalert test <abilityId>`
6. Tune behavior in the list:
  - **On** toggles showing the icon
  - **Duration** changes how long the icon stays visible
  - **Sound** toggles sound (sound effect is always ID **500**)
  - **Image** chooses the icon texture
7. If you edit XML/Lua files, use `/reloadui` to apply changes.

## File structure

```
TuffAlert/
  TuffAlert.mod              # Addon manifest/entrypoint
  LICENSE.md
  README.md

  Source/
    TuffAlert.xml            # Main alert window + texture asset declarations
    TuffAlert.lua            # Runtime logic: events, triggers, rendering, slash commands

    TuffAlert_Config.xml     # Config window + row template + import/export popup dialog
    TuffAlert_Config.lua     # Config behaviors: list management, handlers, import/export

  Textures/
    Alert.tga
    BringItOn.tga
    Retribution.tga
    Sigmar.tga
    Tzeentch.tga
```

## How it works (high-level code flow)

### 1) Addon initialization

Initialization is declared in `TuffAlert.mod`:

- Loads XML first (creates templates/windows).
- Loads Lua (runtime + config code).
- Calls `TuffAlert_OnInitialize()` and `TuffAlert_Config_OnInitialize()`.
- Declares a SavedVariable: `TuffAlert_Settings`.

At runtime:

- `TuffAlert_OnInitialize()` (in `Source/TuffAlert.lua`):
  - Seeds defaults for `TuffAlert_Settings` when missing.
  - Registers `/tuffalert` via `LibSlash.RegisterSlashCmd`.
  - Creates the main alert window and registers it with the Layout Editor.
  - Enables the addon’s event handlers by default.

### 2) Listening for combat events

TuffAlert listens to:

- `SystemData.Events.WORLD_OBJ_COMBAT_EVENT`

Handler:

- `TuffAlert_OnWorldObjCombatEvent(world_object_id, ability_value, ability_type, ability_id)`
  - Ignores events not targeting the local player (`world_object_id ~= GameData.Player.worldObjNum`).
  - Looks up `TuffAlert_Settings.abilities[ability_id]`.
  - If the ability exists and is enabled, calls `TuffAlert_Trigger(ability_id)`.

### 3) Triggering and display

`TuffAlert_Trigger(ability_id)`:

- Tracks active alerts in:
  - `active_alerts[ability_id] = { expires_at }`
  - `active_order` (most-recent-first ordering)
- Shows up to 4 icons (see `MAX_SIMULTANEOUS_ICONS = 4`):
  - Newly triggered abilities are inserted at the front of `active_order`.
  - If more than 4 are active, the oldest is evicted.
- Marks `ui_dirty = true` so the next update will render.
- Sound:
  - The sound ID is hard-coded to **500** (`MAIN_SOUND_ID = 500`).
  - Per-ability sound is controlled by `sound_enabled`.

Rendering:

- `TuffAlert_OnUpdate(time_delta)`:
  - Advances a local timer (`now_seconds`).
  - Removes expired alerts.
  - Calls `TuffAlert_RenderIcons()` when dirty.

- `TuffAlert_RenderIcons()`:
  - Updates up to 4 DynamicImages (`TuffAlert_MainIcon1..4`).
  - Applies `TuffAlert_Settings.window_alpha` (clamped).

### 4) Layout editor integration

The window is registered with `LayoutEditor.RegisterWindow`.

When the layout editor begins editing:

- `TuffAlert_LayoutEditor_Callback(LayoutEditor.EDITING_BEGIN)` shows a stable preview (Alert icons) so the user can position the window.

When editing ends:

- The window alpha is stored back into `TuffAlert_Settings.window_alpha`.

## Settings and data model

All persistent data is stored in `TuffAlert_Settings` (SavedVariables). The addon migrates older formats on startup.

### Texture normalization

- Textures are defined in `Source/TuffAlert.xml` as assets: `TuffAlert_Sigmar`, `TuffAlert_Alert`, etc.
- The code accepts a few legacy forms (short names like `"Sigmar"` or file paths like `"Textures\\Sigmar.tga"`) and resolves them into the asset names.

Texture are 256 x 256 pixels and TGAs.  

Only the following texture TGAs are shipped in this addon:

- `Alert.tga`
- `BringItOn.tga`
- `Retribution.tga`
- `Sigmar.tga`
- `Tzeentch.tga`

## Configuration UI

### Window and layout

The configuration UI is defined in `Source/TuffAlert_Config.xml` and controlled by `Source/TuffAlert_Config.lua`.

It provides:

- Add new ability (ID + Name)
- Enabled toggle
- Duration edit
- Sound toggle
- Image/texture picker
- Delete ability
- Import / Export popup dialog

Note: Some WAR UI templates do not reliably render XML `text="..."` attributes for certain controls, so key label/button text is also set explicitly in Lua during `TuffAlert_Config_OnInitialize()`.

### Enabling/disabling the addon

The “Enabled” checkbox in the config window toggles whether the runtime registers for combat events:

- `TuffAlert_Config_OnToggleAddonEnabled()` calls `TuffAlert_SetEnabled(true|false)`.

## Import / Export

Import/Export uses a compact single-line string format (copy/paste).

- Export replaces line breaks with a single-line payload.
- Import **replaces your entire ability list** (`TuffAlert_Settings.abilities`).

### Format

Prefix:

- `AAE1|`

Entries:

- Separated by `;`

Each entry:

```
abilityId,enabled(0/1),sound(0/1),duration,texLen:texture,nameLen:name
```

Texture and name are length-prefixed so they don’t need escaping.

Limits:

- Maximum import size: 1 MiB
- Maximum number of abilities per import: 500

## Slash commands

Registered as `/tuffalert`.

- `/tuffalert`
  - Opens the config window.

- `/tuffalert help`
  - Prints available commands.

- `/tuffalert on` / `/tuffalert off`
  - Enables/disables event listening + alert rendering.

- `/tuffalert duration <seconds>`
  - Sets the duration for **all** configured abilities.

- `/tuffalert layer <background|default|overlay|popup|secondary>`
  - Changes the UI layer for the alert window.

- `/tuffalert sound on|off`
  - Enables/disables sound for **all** configured abilities.
  - Sound effect is always ID **500**.

- `/tuffalert test [abilityId]`
  - Triggers the alert for testing.

- `/tuffalert debug on|off`
  - Toggles debug chat output.

## Notes for maintainers

- This addon intentionally avoids filesystem enumeration (WAR UI doesn’t provide a general API for it). The texture list is seeded with known textures and any additional texture names found in saved settings.
- Runtime and config are decoupled: the config window edits `TuffAlert_Settings` directly, and the runtime reads from it when combat events arrive.

## Troubleshooting

- If the config window fails to open, check the chat log for:
  - `TuffAlert: config window failed to load (check TuffAlert_Config.xml).`
- After changing XML/Lua, use `/reloadui`.
