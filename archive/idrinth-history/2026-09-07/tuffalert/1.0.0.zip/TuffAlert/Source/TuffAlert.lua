local WINDOW_NAME = "TuffAlert_Main"
local tuffalert_is_enabled = false

local MAIN_SOUND_ID = 500

local MAX_SIMULTANEOUS_ICONS = 4

-- Active alerts keyed by ability_id.
-- Each entry: { expires_at = number }
local active_alerts = {}
local active_order = {}
local now_seconds = 0
local ui_dirty = true
local layout_editor_active = false

local function TuffAlert_ClampAlpha(a)
  if type(a) ~= "number" then
    return 1.0
  end
  if a < 0.05 then
    return 0.05
  end
  if a > 1.0 then
    return 1.0
  end
  return a
end

local function TuffAlert_ResolveTexture(texture)
  if type(texture) ~= "string" or texture == "" then
    return "TuffAlert_Alert"
  end

  if texture == "Alert" then
    return "TuffAlert_Alert"
  end
  if texture == "BringItOn" then
    return "TuffAlert_BringItOn"
  end
  if texture == "Retribution" then
    return "TuffAlert_Retribution"
  end
  if texture == "Sigmar" then
    return "TuffAlert_Sigmar"
  end
  if texture == "Tzeentch" then
    return "TuffAlert_Tzeentch"
  end

  if texture == "TuffAlert_Alert" or texture == "TuffAlert_BringItOn" or texture == "TuffAlert_Retribution" or texture == "TuffAlert_Sigmar" or texture == "TuffAlert_Tzeentch" then
    return texture
  end

  local normalized = texture:gsub("/", "\\")
  if normalized == "Textures\\Alert.tga" then
    return "TuffAlert_Alert"
  end
  if normalized == "Textures\\BringItOn.tga" then
    return "TuffAlert_BringItOn"
  end
  if normalized == "Textures\\Retribution.tga" then
    return "TuffAlert_Retribution"
  end
  if normalized == "Textures\\Sigmar.tga" then
    return "TuffAlert_Sigmar"
  end
  if normalized == "Textures\\Tzeentch.tga" then
    return "TuffAlert_Tzeentch"
  end
  return texture
end

local function TuffAlert_EnsureWindow()
  if DoesWindowExist(WINDOW_NAME) then
    return
  end
  CreateWindow(WINDOW_NAME, true)
  WindowSetAlpha(WINDOW_NAME, 0.0)
  WindowSetLayer(WINDOW_NAME, TuffAlert_Settings.window_layer)
end

local function TuffAlert_IconWindowName(index)
  return WINDOW_NAME .. "Icon" .. tostring(index)
end

local last_layout_w = nil
local last_layout_h = nil

local function TuffAlert_LayoutIconsIfNeeded()
  if not (WindowGetDimensions and WindowSetDimensions and WindowClearAnchors and WindowAddAnchor) then
    return
  end

  if not DoesWindowExist(WINDOW_NAME) then
    return
  end

  local w, h = WindowGetDimensions(WINDOW_NAME)
  if type(w) ~= "number" or type(h) ~= "number" then
    return
  end

  if w < 2 or h < 2 then
    return
  end

  if w == last_layout_w and h == last_layout_h then
    return
  end

  last_layout_w = w
  last_layout_h = h

  local icon_w = math.max(1, math.floor(w / 2))
  local icon_h = math.max(1, math.floor(h / 2))

  for i = 1, MAX_SIMULTANEOUS_ICONS do
    local icon_window = TuffAlert_IconWindowName(i)
    if DoesWindowExist(icon_window) then
      WindowSetDimensions(icon_window, icon_w, icon_h)
      WindowClearAnchors(icon_window)

      local x = 0
      local y = 0
      if i == 2 or i == 4 then x = icon_w end
      if i == 3 or i == 4 then y = icon_h end

      WindowAddAnchor(icon_window, "topleft", WINDOW_NAME, "topleft", x, y)
    end
  end
end


local function TuffAlert_HideAllIcons()
  for i = 1, MAX_SIMULTANEOUS_ICONS do
    local icon_window = TuffAlert_IconWindowName(i)
    if DoesWindowExist(icon_window) then
      WindowSetAlpha(icon_window, 0.0)
    end
  end
end

local function TuffAlert_RenderIcons()
  TuffAlert_EnsureWindow()

  if layout_editor_active then
    return
  end

  TuffAlert_LayoutIconsIfNeeded()

  local visible_count = #active_order
  if visible_count > MAX_SIMULTANEOUS_ICONS then
    visible_count = MAX_SIMULTANEOUS_ICONS
  end

  if visible_count <= 0 then
    TuffAlert_HideAllIcons()
    WindowSetAlpha(WINDOW_NAME, 0.0)
    return
  end

  local alpha = TuffAlert_ClampAlpha(TuffAlert_Settings.window_alpha)
  -- Parent is only a movable container; keep it fully opaque to avoid any
  -- engine-specific parent/child alpha multiplication.
  WindowSetAlpha(WINDOW_NAME, 1.0)

  for i = 1, MAX_SIMULTANEOUS_ICONS do
    local icon_window = TuffAlert_IconWindowName(i)
    if i <= visible_count then
      local ability_id = active_order[i]
      local cfg = TuffAlert_Settings.abilities and TuffAlert_Settings.abilities[ability_id]
      if cfg then
        DynamicImageSetTexture(icon_window, TuffAlert_ResolveTexture(cfg.texture), 0, 0)
        DynamicImageSetTextureDimensions(icon_window, 256, 256)
      end
      WindowSetAlpha(icon_window, alpha)
    else
      WindowSetAlpha(icon_window, 0.0)
    end
  end
end

-- ADDON SETTINGS (SAVED BY THE CLIENT)

-- IMPORTANT: SavedVariables are loaded by the client before addon init.
-- Do NOT overwrite them here, only seed defaults when missing.
if type(TuffAlert_Settings) ~= "table" then
  TuffAlert_Settings = {
    version = 1.0,
    window_alpha = 1.0,
    window_layer = Window.Layers.POPUP,
    debug = false,
    abilities = {
      [1450] = { enabled = true, duration = 1.5, sound_enabled = true, texture = "Retribution", name = "Retribution" },
      [1762] = { enabled = true, duration = 1.5, sound_enabled = true, texture = "BringItOn", name = "Bring It On" },
      [1851] = { enabled = true, duration = 1.5, sound_enabled = true, texture = "Alert", name = "Big Bouncin!" },
      [6021] = { enabled = true, duration = 1.5, sound_enabled = true, texture = "Retribution", name = "Retribution Reflect" },
      [6022] = { enabled = true, duration = 1.5, sound_enabled = true, texture = "BringItOn", name = "Bring It On Reflect" },
      [8425] = { enabled = true, duration = 1.5, sound_enabled = true, texture = "Tzeentch", name = "Wrecking Ball" }      
    }
  }
end

function TuffAlert_Debug(message)
  if not TuffAlert_Settings or not TuffAlert_Settings.debug then
    return
  end
  if type(message) == "string" then
    message = towstring(message)
  end
  TextLogAddEntry("Chat", 0, message)
end

--------------------------------------------------------------------------------
-- CORE FUNCTIONS
--------------------------------------------------------------------------------

local function TuffAlert_Disable ()

  if not tuffalert_is_enabled then
    return
  end

  active_alerts = {}
  active_order = {}
  now_seconds = 0
  ui_dirty = true
  WindowSetAlpha (WINDOW_NAME, 0.0)
  TuffAlert_HideAllIcons()

  UnregisterEventHandler (SystemData.Events.UPDATE_PROCESSED, "TuffAlert_OnUpdate")
  UnregisterEventHandler (SystemData.Events.WORLD_OBJ_COMBAT_EVENT, "TuffAlert_OnWorldObjCombatEvent")

  tuffalert_is_enabled = false

end

local function TuffAlert_Enable ()

  if tuffalert_is_enabled then
    return
  end

  active_alerts = {}
  active_order = {}
  now_seconds = 0
  ui_dirty = true
  WindowSetAlpha (WINDOW_NAME, 0.0)
  TuffAlert_HideAllIcons()

  RegisterEventHandler (SystemData.Events.UPDATE_PROCESSED, "TuffAlert_OnUpdate")
  RegisterEventHandler (SystemData.Events.WORLD_OBJ_COMBAT_EVENT, "TuffAlert_OnWorldObjCombatEvent")

  tuffalert_is_enabled = true

end

-- Exposed for UI/config.
function TuffAlert_IsEnabled()
  return tuffalert_is_enabled == true
end

function TuffAlert_SetEnabled(enabled)
  if enabled == true then
    TuffAlert_Enable()
  else
    TuffAlert_Disable()
  end
end

local function TuffAlert_LayoutEditor_Callback (edit_mode)

  if (edit_mode == LayoutEditor.EDITING_BEGIN)
  then

    layout_editor_active = true

    TuffAlert_EnsureWindow()
    TuffAlert_LayoutIconsIfNeeded()
    -- Show a stable preview while the user is positioning/resizing the parent.
    local alpha = TuffAlert_ClampAlpha(TuffAlert_Settings.window_alpha)
    WindowSetAlpha(WINDOW_NAME, alpha)
    for i = 1, MAX_SIMULTANEOUS_ICONS do
      local icon_window = TuffAlert_IconWindowName(i)
      DynamicImageSetTexture(icon_window, "TuffAlert_Alert", 0, 0)
      DynamicImageSetTextureDimensions(icon_window, 256, 256)
      WindowSetAlpha(icon_window, 1.0)
    end

  elseif (edit_mode == LayoutEditor.EDITING_END)
  then

    layout_editor_active = false

    -- Save the current alpha of the parent window as the desired alpha.
    local raw_alpha = WindowGetAlpha(WINDOW_NAME)
    if type(raw_alpha) == "number" and raw_alpha > 0 then
      TuffAlert_Settings.window_alpha = TuffAlert_ClampAlpha(raw_alpha)
    end
    
    active_alerts = {}
    active_order = {}
    ui_dirty = true
    WindowSetAlpha (WINDOW_NAME, 0.0)
    TuffAlert_HideAllIcons()

  end

end

local function TuffAlert_Trigger (ability_id)

  local ability_config = TuffAlert_Settings.abilities[ability_id]
  if not ability_config then
    return
  end

  TuffAlert_EnsureWindow()

  local duration = ability_config.duration or 1.5

  if active_alerts[ability_id] then
    -- Refresh timer without changing the icon's current slot.
    active_alerts[ability_id].expires_at = now_seconds + duration
  else
    active_alerts[ability_id] = {
      expires_at = now_seconds + duration,
    }

    table.insert(active_order, 1, ability_id)
    if #active_order > MAX_SIMULTANEOUS_ICONS then
      local evicted_id = table.remove(active_order)
      active_alerts[evicted_id] = nil
    end
  end

  ui_dirty = true

  -- If the addon is disabled (e.g. via config toggle), do not emit sound.
  if tuffalert_is_enabled and ability_config.sound_enabled == true then
    PlaySound(MAIN_SOUND_ID)
  end

end

-- Exposed for the config UI (preview/test).
function TuffAlert_TriggerAbility(ability_id)
  TuffAlert_Trigger(ability_id)
end

--------------------------------------------------------------------------------
-- EVENTS
--------------------------------------------------------------------------------

function TuffAlert_OnInitialize ()

  if LibSlash and type(LibSlash.RegisterSlashCmd) == "function" then
    LibSlash.RegisterSlashCmd ("tuffalert", TuffAlert_OnSlashCmd)
  else
    TextLogAddEntry("Chat", 0, L"TuffAlert: LibSlash not available; slash commands disabled.")
  end

  CreateWindow (WINDOW_NAME, true)
  WindowSetAlpha (WINDOW_NAME, 0.0)
  WindowSetLayer (WINDOW_NAME, TuffAlert_Settings.window_layer)

  TuffAlert_HideAllIcons()

  -- Internal window name, display name, description, allow resizing X, allow resizing Y, allow hiding, on-hide call-back.
  if LayoutEditor and type(LayoutEditor.RegisterWindow) == "function" and type(LayoutEditor.RegisterEditCallback) == "function" then
    LayoutEditor.RegisterWindow (WINDOW_NAME, L"TuffAlert", L"TuffAlert", true, true, true, nil)
    LayoutEditor.RegisterEditCallback (TuffAlert_LayoutEditor_Callback)
  else
    TextLogAddEntry("Chat", 0, L"TuffAlert: LayoutEditor not available; move/resize preview disabled.")
  end

  TuffAlert_Enable ()

end

function TuffAlert_OnSlashCmd (text)

  -- If no parameters, open the config window
  if text == "" or text == nil then
    if TuffAlert_Config_ToggleWindow then
      TuffAlert_Config_ToggleWindow()
    else
      TextLogAddEntry("Chat", 0, L"TuffAlert: config window is not loaded.")
    end
    return
  end

  local params = {}

  -- Build a list of each word in the slash text. The initial "tuffalert" is already removed by LibSlash.
  for param in text:gmatch ("%S+")
  do
    table.insert (params, param)
  end

  ----------------------------------------------------------------------------
  -- Duration
  ----------------------------------------------------------------------------

  if (params[1] == "duration")
  then
      
    local duration = tonumber (params[2])

    if (type (duration) ~= "number") or (duration < 0)
    then
      TextLogAddEntry ("Chat", 0, L"TuffAlert: invalid value for alert duration: " .. towstring (params[2]))
      return
    end

    for _, cfg in pairs(TuffAlert_Settings.abilities) do
      cfg.duration = duration
    end
    TextLogAddEntry ("Chat", 0, L"TuffAlert: set duration for all abilities to " .. towstring (duration) .. L" seconds.")

  ----------------------------------------------------------------------------
  -- Help
  ----------------------------------------------------------------------------

  elseif (params[1] == "help")
  then

    TextLogAddEntry ("Chat", 0, L"---------------------------------------------")
    TextLogAddEntry ("Chat", 0, L"/tuffalert")
    TextLogAddEntry ("Chat", 0, L"- Opens the TuffAlert configuration window.")
    TextLogAddEntry ("Chat", 0, L"")
    TextLogAddEntry ("Chat", 0, L"/tuffalert duration #")
    TextLogAddEntry ("Chat", 0, L"- Sets the duration for ALL configured abilities (seconds).")
    TextLogAddEntry ("Chat", 0, L"")
    TextLogAddEntry ("Chat", 0, L"/tuffalert help")
    TextLogAddEntry ("Chat", 0, L"- Displays a list of all TuffAlert chat commands.")
    TextLogAddEntry ("Chat", 0, L"")
    TextLogAddEntry ("Chat", 0, L"/tuffalert debug on|off")
    TextLogAddEntry ("Chat", 0, L"- Enables/disables TuffAlert debug messages.")
    TextLogAddEntry ("Chat", 0, L"")
    TextLogAddEntry ("Chat", 0, L"/tuffalert layer #")
    TextLogAddEntry ("Chat", 0, L"- Sets which UI layer to show the alert window on. # can be: background, default, overlay, popup or secondary.")
    TextLogAddEntry ("Chat", 0, L"")
    TextLogAddEntry ("Chat", 0, L"/tuffalert off")
    TextLogAddEntry ("Chat", 0, L"- Disables the alert.")
    TextLogAddEntry ("Chat", 0, L"")
    TextLogAddEntry ("Chat", 0, L"/tuffalert on")
    TextLogAddEntry ("Chat", 0, L"- Enables the alert.")
    TextLogAddEntry ("Chat", 0, L"")
    TextLogAddEntry ("Chat", 0, L"/tuffalert sound on|off")
    TextLogAddEntry ("Chat", 0, L"- Enables/disables sound for ALL configured abilities (main sound ID is 500).")
    TextLogAddEntry ("Chat", 0, L"")
    TextLogAddEntry ("Chat", 0, L"/tuffalert test")
    TextLogAddEntry ("Chat", 0, L"- Trigger the alert. For testing purposes.")
    TextLogAddEntry ("Chat", 0, L"---------------------------------------------")

  ----------------------------------------------------------------------------
  -- Layer
  ----------------------------------------------------------------------------

  elseif (params[1] == "layer")
  then

    local layer = params[2]

        if (layer == "background") then TuffAlert_Settings.window_layer = Window.Layers.BACKGROUND
    elseif (layer == "default")    then TuffAlert_Settings.window_layer = Window.Layers.DEFAULT
    elseif (layer == "overlay")    then TuffAlert_Settings.window_layer = Window.Layers.OVERLAY
    elseif (layer == "popup")      then TuffAlert_Settings.window_layer = Window.Layers.POPUP
    elseif (layer == "secondary")  then TuffAlert_Settings.window_layer = Window.Layers.SECONDARY
    else
      TextLogAddEntry ("Chat", 0, L"TuffAlert: invalid window layer. Valid options are: background, default, overlay, popup and secondary.")
    end

    WindowSetLayer (WINDOW_NAME, TuffAlert_Settings.window_layer)
    TextLogAddEntry ("Chat", 0, L"TuffAlert: alert window layer changed to: " .. towstring (layer))

  ----------------------------------------------------------------------------
  -- Off
  ----------------------------------------------------------------------------

  elseif (params[1] == "off")
  then

    TuffAlert_Disable ()
    TextLogAddEntry ("Chat", 0, L"TuffAlert: the alert is turned off.")

  ----------------------------------------------------------------------------
  -- On
  ----------------------------------------------------------------------------

  elseif (params[1] == "on")
  then

    TuffAlert_Enable ()
    TextLogAddEntry ("Chat", 0, L"TuffAlert: the alert is turned on.")

  ----------------------------------------------------------------------------
  -- Sound
  ----------------------------------------------------------------------------

  elseif (params[1] == "sound")
  then

    local arg = params[2]
    if not arg or arg == "" then
      TextLogAddEntry("Chat", 0, L"TuffAlert: usage: /tuffalert sound on|off (main sound ID is 500)")
      return
    end

    local enable = nil
    if arg == "on" then
      enable = true
    elseif arg == "off" then
      enable = false
    else
      TextLogAddEntry("Chat", 0, L"TuffAlert: invalid value. Usage: /tuffalert sound on|off")
      return
    end

    for _, cfg in pairs(TuffAlert_Settings.abilities) do
      cfg.sound_enabled = enable
    end

    if enable then
      TextLogAddEntry("Chat", 0, L"TuffAlert: enabled sound for all abilities (sound ID 500)")
    else
      TextLogAddEntry("Chat", 0, L"TuffAlert: disabled sound for all abilities")
    end

  ----------------------------------------------------------------------------
  -- Debug
  ----------------------------------------------------------------------------

  elseif (params[1] == "debug")
  then

    local v = (params[2] or "")
    if v == "on" then
      TuffAlert_Settings.debug = true
      TextLogAddEntry("Chat", 0, L"TuffAlert: debug enabled.")
    elseif v == "off" then
      TuffAlert_Settings.debug = false
      TextLogAddEntry("Chat", 0, L"TuffAlert: debug disabled.")
    else
      TextLogAddEntry("Chat", 0, L"TuffAlert: usage: /tuffalert debug on|off")
    end

  ----------------------------------------------------------------------------
  -- Test
  ----------------------------------------------------------------------------

  elseif (params[1] == "test")
  then

    -- Optional: /tuffalert test <ability_id>
    local requested_id = tonumber(params[2])
    local test_ability_id = nil

    if requested_id and TuffAlert_Settings.abilities[requested_id] then
      test_ability_id = requested_id
    else
      -- Find the lowest enabled ability for deterministic testing
      for ability_id, config in pairs(TuffAlert_Settings.abilities) do
        if config and config.enabled then
          if (not test_ability_id) or (ability_id < test_ability_id) then
            test_ability_id = ability_id
          end
        end
      end
    end

    if test_ability_id then
      local cfg = TuffAlert_Settings.abilities[test_ability_id]
      TuffAlert_Trigger (test_ability_id)

      local tex = ""
      if cfg and cfg.texture then
        tex = tostring(cfg.texture)
      end
      TextLogAddEntry("Chat", 0,
        L"TuffAlert: manually triggered ability " .. towstring(test_ability_id) ..
        L" (image=" .. towstring(TuffAlert_ResolveTexture(tex)) .. L")")
    else
      TextLogAddEntry ("Chat", 0, L"TuffAlert: no abilities are enabled. Enable an ability in /tuffalert config first.")
    end

  ----------------------------------------------------------------------------
  -- ???
  ----------------------------------------------------------------------------

  else

    TextLogAddEntry ("Chat", 0, L"TuffAlert: missing or unknown command. Valid options are: duration, help, layer, off, on, sound and test.")

  end

end

function TuffAlert_OnShutdown ()
end

function TuffAlert_OnUpdate (time_delta)

  if layout_editor_active then
    return
  end

  now_seconds = now_seconds + (time_delta or 0)

  if #active_order <= 0 then
    if ui_dirty then
      TuffAlert_RenderIcons()
      ui_dirty = false
    end
    return
  end

  local did_expire = false
  for i = #active_order, 1, -1 do
    local ability_id = active_order[i]
    local entry = active_alerts[ability_id]
    if (not entry) or (entry.expires_at <= now_seconds) then
      table.remove(active_order, i)
      active_alerts[ability_id] = nil
      did_expire = true
    end
  end

  if did_expire then
    ui_dirty = true
  end

  if ui_dirty then
    TuffAlert_RenderIcons()
    ui_dirty = false
  end

end

function TuffAlert_OnWorldObjCombatEvent (world_object_id, ability_value, ability_type, ability_id)

  -- Only check combat events that happen to the player.
  if (world_object_id ~= GameData.Player.worldObjNum)
  then
    return
  end

  -- Check if this ability is in our config and enabled
  local ability_config = TuffAlert_Settings.abilities[ability_id]
  if ability_config and ability_config.enabled then
    TuffAlert_Trigger (ability_id)
  end

end
