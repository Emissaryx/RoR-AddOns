-- TuffAlert Configuration Window
--------------------------------------------------------------------------------

if type(WindowUtils) ~= "table" then
  WindowUtils = {}
end
if type(WindowUtils.OnShown) ~= "function" then
  function WindowUtils.OnShown() end
end
if type(WindowUtils.OnHidden) ~= "function" then
  function WindowUtils.OnHidden() end
end

local WINDOW_NAME = "TuffAlert_ConfigWindow"
local SCROLL_CHILD = "TuffAlert_ConfigWindowAbilityListScrollChild"
local ROW_TEMPLATE = "TuffAlert_AbilityRowTemplate"
local ROW_HEIGHT = 35

local ability_rows = {}
local available_textures = {}
local suppress_texture_changed = false
local last_texture_combo_name = nil

local ADDON_ENABLED_CHECKBOX = "TuffAlert_ConfigWindowAddSectionAddonEnabled"

-- Import/Export text-entry dialog state
local text_entry_dialogs = {}
local next_text_entry_dialog_id = 1

local function AA_ToWStringOrEmpty(v)
  if v == nil then
    return L""
  end
  if type(v) == "wstring" then
    return v
  end
  if type(v) == "string" then
    return towstring(v)
  end
  return towstring(tostring(v))
end

local function AA_ClampNumber(n, min_v, max_v, default_v)
  if type(n) ~= "number" then
    n = tonumber(n)
  end
  if type(n) ~= "number" then
    return default_v
  end
  if n < min_v then
    return min_v
  end
  if n > max_v then
    return max_v
  end
  return n
end

-- Import/Export payload format:
--   AAE1|<entry>;<entry>;...
-- Each entry:
--   abilityId,enabled(0/1),sound(0/1),duration,texLen:texture,nameLen:name
-- Texture/name are length-prefixed (no escaping needed).
local EXPORT_PREFIX = "AAE1|"
local MAX_IMPORT_BYTES = 1024 * 1024
local MAX_IMPORT_ABILITIES = 500

local function AA_WStringToStringSafe(v)
  if v == nil then
    return ""
  end
  if type(v) == "string" then
    return v
  end
  if type(v) == "wstring" then
    if type(WStringToString) == "function" then
      local s = WStringToString(v)
      if s ~= nil then
        return s
      end
    end
    return tostring(v)
  end
  return tostring(v)
end

local function AA_TrimString(s)
  if type(s) ~= "string" then
    return ""
  end
  return (s:gsub("^%s+", ""):gsub("%s+$", ""))
end

local function AA_SanitizeOneLineString(v, max_len, default)
  local s = AA_WStringToStringSafe(v)
  -- Keep spaces (names often contain them), but remove line breaks/tabs.
  s = s:gsub("\r", " "):gsub("\n", " "):gsub("\t", " ")
  if default and (not s or s == "") then
    s = default
  end
  if type(max_len) == "number" and max_len > 0 and #s > max_len then
    s = s:sub(1, max_len)
  end
  return s
end

local function GetTextEntryDialogFromActiveWindowName()
  local awn = SystemData.ActiveWindow and SystemData.ActiveWindow.name
  if not awn then
    return nil
  end
  return awn:match("(TuffAlertTextEntryDialog%d+).*")
end

function TuffAlert_Config_TextEntryDialog_Close(wn)
  if not wn or type(wn) ~= "string" then
    wn = GetTextEntryDialogFromActiveWindowName()
  end
  if wn and DoesWindowExist(wn) then
    DestroyWindow(wn)
    text_entry_dialogs[wn] = nil
  end
end

local function TuffAlert_Config_TextEntryDialog_Open(title, message, text, onOk)
  local wn = "TuffAlertTextEntryDialog" .. tostring(next_text_entry_dialog_id)
  next_text_entry_dialog_id = next_text_entry_dialog_id + 1

  text_entry_dialogs[wn] = {
    wn = wn,
    onOk = onOk,
  }

  CreateWindowFromTemplate(wn, "TuffAlertTextEntryDialog", "Root")

  ButtonSetText(wn .. "OkButton", L"OK")
  ButtonSetText(wn .. "CancelButton", L"Cancel")

  LabelSetText(wn .. "TitleBarText", AA_ToWStringOrEmpty(title))
  LabelSetText(wn .. "Label", AA_ToWStringOrEmpty(message))
  TextEditBoxSetText(wn .. "Value", AA_ToWStringOrEmpty(text))
  TextEditBoxSetMaxChars(wn .. "Value", 1024 * 1024)

  WindowAssignFocus(wn .. "Value", true)
  TextEditBoxSelectAll(wn .. "Value")

  return wn
end

function TuffAlert_Config_TextEntryDialog_Ok()
  local wn = GetTextEntryDialogFromActiveWindowName()
  if not wn then
    return
  end

  local dlg = text_entry_dialogs[wn]
  if not dlg then
    TuffAlert_Config_TextEntryDialog_Close(wn)
    return
  end

  if dlg.onOk then
    dlg.onOk(TextEditBoxGetText(wn .. "Value"))
  end

  TuffAlert_Config_TextEntryDialog_Close(wn)
end

local function SyncAddonEnabledCheckbox()
  if not DoesWindowExist(ADDON_ENABLED_CHECKBOX) then
    return
  end

  ButtonSetStayDownFlag(ADDON_ENABLED_CHECKBOX, true)

  local is_enabled = true
  if TuffAlert_IsEnabled then
    is_enabled = (TuffAlert_IsEnabled() == true)
  end

  ButtonSetPressedFlag(ADDON_ENABLED_CHECKBOX, is_enabled)
end

local function TextureAssetToLabel(texture_asset)
  if type(texture_asset) ~= "string" or texture_asset == "" then
    return ""
  end

  if texture_asset == "TuffAlert_Alert" then return "Alert" end
  if texture_asset == "TuffAlert_BringItOn" then return "BringItOn" end
  if texture_asset == "TuffAlert_Retribution" then return "Retribution" end
  if texture_asset == "TuffAlert_Sigmar" then return "Sigmar" end
  if texture_asset == "TuffAlert_Tzeentch" then return "Tzeentch" end

  local stripped = string.match(texture_asset, "^TuffAlert_(.+)$")
  if stripped and stripped ~= "" then
    return stripped
  end

  return texture_asset
end

--------------------------------------------------------------------------------
-- Texture Discovery
local function ScanTextureFolder()
  available_textures = {}

  table.insert(available_textures, "TuffAlert_Alert")
  table.insert(available_textures, "TuffAlert_BringItOn")
  table.insert(available_textures, "TuffAlert_None")
  table.insert(available_textures, "TuffAlert_Retribution")
  table.insert(available_textures, "TuffAlert_Sigmar")
  table.insert(available_textures, "TuffAlert_Tzeentch")

  if TuffAlert_Settings and TuffAlert_Settings.abilities then
    for _, config in pairs(TuffAlert_Settings.abilities) do
      if config and type(config.texture) == "string" and config.texture ~= "" then
        -- Normalize legacy values so we don't keep surfacing old entries.
        if config.texture == "TuffAlert_Alert" or config.texture == "Alert" then
          config.texture = "TuffAlert_Alert"
        elseif config.texture == "TuffAlert_BringItOn" or config.texture == "BringItOn" then
          config.texture = "TuffAlert_BringItOn"
        elseif config.texture == "TuffAlert_Retribution" or config.texture == "Retribution" then
          config.texture = "TuffAlert_Retribution"
        elseif config.texture == "TuffAlert_Sigmar" or config.texture == "Sigmar" then
          config.texture = "TuffAlert_Sigmar"
        elseif config.texture == "TuffAlert_Tzeentch" or config.texture == "Tzeentch" then
          config.texture = "TuffAlert_Tzeentch"
        else
          local normalized = config.texture:gsub("/", "\\")
          if normalized == "Textures\\Alert.tga" then
            config.texture = "TuffAlert_Alert"
          elseif normalized == "Textures\\BringItOn.tga" then
            config.texture = "TuffAlert_BringItOn"
          elseif normalized == "Textures\\Retribution.tga" then
            config.texture = "TuffAlert_Retribution"
          elseif normalized == "Textures\\Sigmar.tga" then
            config.texture = "TuffAlert_Sigmar"
          elseif normalized == "Textures\\Tzeentch.tga" then
            config.texture = "TuffAlert_Tzeentch"
          end
        end

        local found = false
        for _, existing in ipairs(available_textures) do
          if existing == config.texture then
            found = true
            break
          end
        end
        if not found then
          table.insert(available_textures, config.texture)
        end
      end
    end
  end

  return available_textures
end

--------------------------------------------------------------------------------
-- UI Helper Functions
--------------------------------------------------------------------------------

local function ClearErrorLabel()
  if not DoesWindowExist("TuffAlert_ConfigWindowErrorLabel") then
    return
  end
  LabelSetText("TuffAlert_ConfigWindowErrorLabel", L"")
  LabelSetTextColor("TuffAlert_ConfigWindowErrorLabel", 255, 64, 64)
end

local function ShowError(message)
  if not DoesWindowExist("TuffAlert_ConfigWindowErrorLabel") then
    return
  end
  LabelSetTextColor("TuffAlert_ConfigWindowErrorLabel", 255, 64, 64)
  LabelSetText("TuffAlert_ConfigWindowErrorLabel", message)
end

--------------------------------------------------------------------------------
-- Ability Row Management
--------------------------------------------------------------------------------

local function CreateAbilityRow(ability_id, config)
  local row_name = "TuffAlert_AbilityRow_" .. ability_id
  
  -- Destroy existing row if it exists
  if DoesWindowExist(row_name) then
    DestroyWindow(row_name)
  end
  
  -- Create new row from template
  CreateWindowFromTemplate(row_name, ROW_TEMPLATE, SCROLL_CHILD)
  
  -- Store reference
  ability_rows[ability_id] = row_name
  
  -- Set checkbox state
  local checkbox_name = row_name .. "Enabled"
  ButtonSetStayDownFlag(checkbox_name, true)
  ButtonSetPressedFlag(checkbox_name, config.enabled == true)
  
  -- Set ability name
  LabelSetText(row_name .. "Name", towstring(config.name or "Unknown"))
  
  -- Set duration
  TextEditBoxSetText(row_name .. "Duration", towstring(config.duration or 1.5))
  
  -- Set sound toggle
  local sound_checkbox = row_name .. "Sound"
  ButtonSetStayDownFlag(sound_checkbox, true)
  ButtonSetPressedFlag(sound_checkbox, config.sound_enabled == true)
  
  -- Populate texture combobox
  local combo_name = row_name .. "Texture"
  ComboBoxClearMenuItems(combo_name)
  
  local selected_index = 1
  for i, texture_asset in ipairs(available_textures) do
    ComboBoxAddMenuItem(combo_name, towstring(TextureAssetToLabel(texture_asset)))
    if texture_asset == config.texture then
      selected_index = i
    end
  end
  
  suppress_texture_changed = true
  ComboBoxSetSelectedMenuItem(combo_name, selected_index)
  suppress_texture_changed = false
  
  return row_name
end

function TuffAlert_Config_OnTextureMouseDown()
  last_texture_combo_name = SystemData.ActiveWindow and SystemData.ActiveWindow.name

  if DoesWindowExist("TuffAlert_ConfigWindowErrorLabel") then
    LabelSetTextColor("TuffAlert_ConfigWindowErrorLabel", 200, 200, 200)
    LabelSetText("TuffAlert_ConfigWindowErrorLabel", L"Selecting image...")
  end
end

local function GetAbilityIdFromWindowName(window_name)
  -- Extract ability ID from window name like "TuffAlert_AbilityRow_1762"
  local id_str = string.match(window_name, "TuffAlert_AbilityRow_(%d+)")
  return tonumber(id_str)
end

local function GetAbilityIdFromActiveWindow()
  local current = SystemData.ActiveWindow and SystemData.ActiveWindow.name
  for _ = 1, 10 do
    if not current or current == "" then
      return nil
    end
    local id = GetAbilityIdFromWindowName(current)
    if id then
      return id
    end
    current = WindowGetParent(current)
  end
  return nil
end

local function RefreshAbilityList()
  -- Clear existing rows
  for ability_id, row_name in pairs(ability_rows) do
    if DoesWindowExist(row_name) then
      DestroyWindow(row_name)
    end
  end
  ability_rows = {}
  
  -- Create rows for all abilities in settings
  local row_index = 0
  local sorted_abilities = {}
  
  -- Sort abilities by ID for consistent display
  for ability_id, _ in pairs(TuffAlert_Settings.abilities) do
    table.insert(sorted_abilities, ability_id)
  end
  table.sort(sorted_abilities)
  
  -- Create rows
  for _, ability_id in ipairs(sorted_abilities) do
    local config = TuffAlert_Settings.abilities[ability_id]
    local row_name = CreateAbilityRow(ability_id, config)
    
    -- Position the row
    WindowClearAnchors(row_name)
    WindowAddAnchor(row_name, "topleft", SCROLL_CHILD, "topleft", 0, row_index * ROW_HEIGHT)
    
    row_index = row_index + 1
  end
  
  -- Update scroll window size
  -- Keep the scroll child at least as tall as the visible list area.
  local scroll_child_height = math.max(296, row_index * ROW_HEIGHT)

  local list_width = 560
  if DoesWindowExist(WINDOW_NAME .. "AbilityList") then
    local w = WindowGetDimensions(WINDOW_NAME .. "AbilityList")
    if type(w) == "number" then
      list_width = w
    end
  end

  -- Leave room for the vertical scrollbar.
  local child_width = math.max(320, list_width - 26)
  WindowSetDimensions(SCROLL_CHILD, child_width, scroll_child_height)

  -- Match each row to the scroll child width so it doesn't overflow.
  for _, row_name in pairs(ability_rows) do
    if DoesWindowExist(row_name) then
      WindowSetDimensions(row_name, child_width, ROW_HEIGHT)
    end
  end
  
  ScrollWindowUpdateScrollRect(WINDOW_NAME .. "AbilityList")
end

--------------------------------------------------------------------------------
-- Event Handlers
--------------------------------------------------------------------------------

function TuffAlert_Config_OnInitialize()
  -- Scan for available textures
  available_textures = ScanTextureFolder()

  -- The window is defined in XML, but still needs to be instantiated.
  if not DoesWindowExist(WINDOW_NAME) then
    CreateWindow(WINDOW_NAME, false)
  end

  -- Set window title
  if DoesWindowExist(WINDOW_NAME) then
    if DoesWindowExist("TuffAlert_ConfigWindowTitleBarText") then
      LabelSetText("TuffAlert_ConfigWindowTitleBarText", L"TuffAlert Configuration")
    end
    
    -- Set column header labels
    LabelSetText("TuffAlert_ConfigWindowListHeaderEnabledHeader", L"On")
    LabelSetText("TuffAlert_ConfigWindowListHeaderNameHeader", L"Ability Name")
    LabelSetText("TuffAlert_ConfigWindowListHeaderDurationHeader", L"Duration")
    LabelSetText("TuffAlert_ConfigWindowListHeaderSoundHeader", L"Sound")
    LabelSetText("TuffAlert_ConfigWindowListHeaderTextureHeader", L"Image")
    LabelSetText("TuffAlert_ConfigWindowListHeaderDeleteHeader", L"Delete")
    
    -- Set Add New Ability section labels
    if DoesWindowExist("TuffAlert_ConfigWindowAddSectionAddLabel") then
      LabelSetText("TuffAlert_ConfigWindowAddSectionAddLabel", L"Add New Ability")
    end
    if DoesWindowExist("TuffAlert_ConfigWindowAddSectionAddonEnabledLabel") then
      LabelSetText("TuffAlert_ConfigWindowAddSectionAddonEnabledLabel", L"Enabled:")
    end
    if DoesWindowExist("TuffAlert_ConfigWindowAddSectionIDLabel") then
      LabelSetText("TuffAlert_ConfigWindowAddSectionIDLabel", L"Ability ID:")
    end
    if DoesWindowExist("TuffAlert_ConfigWindowAddSectionNameLabel") then
      LabelSetText("TuffAlert_ConfigWindowAddSectionNameLabel", L"Name:")
    end

    if DoesWindowExist("TuffAlert_ConfigWindowImport") then
      ButtonSetText("TuffAlert_ConfigWindowImport", L"Import")
    end
    if DoesWindowExist("TuffAlert_ConfigWindowExport") then
      ButtonSetText("TuffAlert_ConfigWindowExport", L"Export")
    end

    -- Some button templates ignore the XML 'text' attribute; set it explicitly.
    if DoesWindowExist("TuffAlert_ConfigWindowAddSectionAddButton") then
      ButtonSetText("TuffAlert_ConfigWindowAddSectionAddButton", L"+ Add")
    end
    
    -- Hide window initially
    WindowSetShowing(WINDOW_NAME, false)
  end
  
  -- Clear error label (only if it exists)
  if DoesWindowExist("TuffAlert_ConfigWindowErrorLabel") then
    ClearErrorLabel()
  end

  SyncAddonEnabledCheckbox()
end

local function TuffAlert_Config_BuildExportString()
  local ids = {}
  if TuffAlert_Settings and type(TuffAlert_Settings.abilities) == "table" then
    for ability_id, _ in pairs(TuffAlert_Settings.abilities) do
      if type(ability_id) == "number" and ability_id > 0 then
        table.insert(ids, ability_id)
      end
    end
  end
  table.sort(ids)

  local entries = {}
  for _, ability_id in ipairs(ids) do
    local cfg = TuffAlert_Settings.abilities[ability_id]
    if type(cfg) == "table" then
      local enabled = (cfg.enabled == true) and 1 or 0
      local sound_enabled = (cfg.sound_enabled == true) and 1 or 0
      local duration = AA_ClampNumber(cfg.duration, 0.1, 60.0, 1.5)

      local texture = AA_SanitizeOneLineString(cfg.texture, 64, "TuffAlert_Alert")
      texture = AA_TrimString(texture)
      if texture == "" then
        texture = "TuffAlert_Alert"
      end

      local name_default = "Ability " .. tostring(ability_id)
      local name = AA_SanitizeOneLineString(cfg.name, 80, name_default)
      if name == "" then
        name = name_default
      end

      -- Use stable formatting for duration.
      local entry = string.format(
        "%d,%d,%d,%.3f,%d:%s,%d:%s",
        ability_id,
        enabled,
        sound_enabled,
        duration,
        #texture,
        texture,
        #name,
        name
      )
      table.insert(entries, entry)
    end
  end

  return EXPORT_PREFIX .. table.concat(entries, ";")
end

local function AA_ParseLenValue(rest, max_len)
  local colon = rest:find(":", 1, true)
  if not colon then
    return nil, nil, "missing ':'"
  end

  local len_str = rest:sub(1, colon - 1)
  local len_num = tonumber(len_str)
  if type(len_num) ~= "number" then
    return nil, nil, "invalid length"
  end
  len_num = math.floor(len_num)
  if len_num < 0 then
    return nil, nil, "negative length"
  end
  if type(max_len) == "number" and len_num > max_len then
    return nil, nil, "length too large"
  end

  local start_pos = colon + 1
  local end_pos = start_pos + len_num - 1
  if end_pos > #rest then
    return nil, nil, "truncated value"
  end

  local value = rest:sub(start_pos, end_pos)
  local remaining = rest:sub(end_pos + 1)
  return value, remaining, nil
end

local function AA_ParseEntry(entry)
  entry = AA_TrimString(entry)
  if entry == "" then
    return nil, nil, "empty entry"
  end

  local p1 = entry:find(",", 1, true)
  if not p1 then return nil, nil, "missing fields" end
  local p2 = entry:find(",", p1 + 1, true)
  if not p2 then return nil, nil, "missing fields" end
  local p3 = entry:find(",", p2 + 1, true)
  if not p3 then return nil, nil, "missing fields" end
  local p4 = entry:find(",", p3 + 1, true)
  if not p4 then return nil, nil, "missing fields" end

  local id_num = tonumber(entry:sub(1, p1 - 1))
  if type(id_num) ~= "number" or id_num <= 0 then
    return nil, nil, "invalid ability id"
  end
  id_num = math.floor(id_num)

  local enabled = tonumber(entry:sub(p1 + 1, p2 - 1))
  local sound_enabled = tonumber(entry:sub(p2 + 1, p3 - 1))
  local duration = tonumber(entry:sub(p3 + 1, p4 - 1))

  enabled = (enabled == 1)
  sound_enabled = (sound_enabled == 1)
  duration = AA_ClampNumber(duration, 0.1, 60.0, 1.5)

  local rest = entry:sub(p4 + 1)

  local texture, remaining, err = AA_ParseLenValue(rest, 64)
  if not texture then
    return nil, nil, "invalid texture: " .. tostring(err)
  end
  if remaining:sub(1, 1) ~= "," then
    return nil, nil, "missing name separator"
  end
  remaining = remaining:sub(2)

  local name, remaining2, err2 = AA_ParseLenValue(remaining, 80)
  if not name then
    return nil, nil, "invalid name: " .. tostring(err2)
  end
  if remaining2 ~= "" then
    return nil, nil, "unexpected trailing data"
  end

  texture = AA_TrimString(AA_SanitizeOneLineString(texture, 64, "TuffAlert_Alert"))
  if texture == "" then
    texture = "TuffAlert_Alert"
  end

  local name_default = "Ability " .. tostring(id_num)
  name = AA_SanitizeOneLineString(name, 80, name_default)
  if name == "" then
    name = name_default
  end

  return id_num, {
    enabled = enabled,
    duration = duration,
    sound_enabled = sound_enabled,
    texture = texture,
    name = name,
  }, nil
end

local function TuffAlert_Config_ApplyImport(payload_ws)
  ClearErrorLabel()

  local payload = AA_WStringToStringSafe(payload_ws)
  payload = payload:gsub("\r", ""):gsub("\n", "")
  payload = AA_TrimString(payload)

  if payload == "" then
    ShowError(L"Error: empty import string.")
    return
  end

  if #payload > MAX_IMPORT_BYTES then
    ShowError(L"Error: import string too large.")
    return
  end

  if payload:sub(1, #EXPORT_PREFIX) ~= EXPORT_PREFIX then
    ShowError(L"Error: unknown import format (expected AAE1|...).")
    return
  end

  local body = payload:sub(#EXPORT_PREFIX + 1)
  if body == "" then
    ShowError(L"Error: import contained no entries.")
    return
  end

  local new_abilities = {}
  local count = 0
  local idx = 0

  for entry in body:gmatch("([^;]+)") do
    idx = idx + 1

    local id_num, cfg, err = AA_ParseEntry(entry)
    if not cfg then
      ShowError(L"Error: invalid entry #" .. towstring(idx) .. L": " .. towstring(err))
      return
    end

    if not new_abilities[id_num] then
      count = count + 1
      if count > MAX_IMPORT_ABILITIES then
        ShowError(L"Error: import contains too many abilities (max 500).")
        return
      end
    end

    new_abilities[id_num] = cfg
  end

  if count <= 0 then
    ShowError(L"Error: import contained no valid abilities.")
    return
  end

  TuffAlert_Settings.abilities = new_abilities

  -- Refresh visible UI
  if DoesWindowExist(WINDOW_NAME) and WindowGetShowing(WINDOW_NAME) then
    RefreshAbilityList()
    SyncAddonEnabledCheckbox()
  end

  LabelSetTextColor("TuffAlert_ConfigWindowErrorLabel", 64, 255, 64)
  LabelSetText("TuffAlert_ConfigWindowErrorLabel", L"Imported " .. towstring(count) .. L" abilities.")
end

function TuffAlert_Config_OnExport()
  local export_str = TuffAlert_Config_BuildExportString()

  TuffAlert_Config_TextEntryDialog_Open(
    L"Export",
    L"Select all (Ctrl+A) and copy (Ctrl+C) this TuffAlert data string",
    towstring(export_str),
    nil
  )
end

function TuffAlert_Config_OnImport()
  TuffAlert_Config_TextEntryDialog_Open(
    L"Import",
    L"Paste (Ctrl+V) an TuffAlert data string, then click OK (this replaces your current list)",
    L"",
    function(text)
      TuffAlert_Config_ApplyImport(text)
    end
  )
end

function TuffAlert_Config_ToggleWindow()
  if not DoesWindowExist(WINDOW_NAME) then
    CreateWindow(WINDOW_NAME, false)
    if not DoesWindowExist(WINDOW_NAME) then
      TextLogAddEntry("Chat", 0, L"TuffAlert: config window failed to load (check TuffAlert_Config.xml).")
      return
    end
  end
  
  local is_showing = WindowGetShowing(WINDOW_NAME)
  
  if not is_showing then
    RefreshAbilityList()
    ClearErrorLabel()
    SyncAddonEnabledCheckbox()
  end
  
  WindowSetShowing(WINDOW_NAME, not is_showing)
end

function TuffAlert_Config_OnToggleAddonEnabled()
  local checkbox_name = SystemData.ActiveWindow and SystemData.ActiveWindow.name
  if type(checkbox_name) ~= "string" or checkbox_name == "" then
    checkbox_name = ADDON_ENABLED_CHECKBOX
  end
  if not DoesWindowExist(checkbox_name) then
    return
  end

  ButtonSetStayDownFlag(checkbox_name, true)

  local ui_pressed = ButtonGetPressedFlag(checkbox_name)
  local ui_pressed_bool = (ui_pressed == true) or (ui_pressed == 1)

  local setting_enabled = true
  if TuffAlert_IsEnabled then
    setting_enabled = (TuffAlert_IsEnabled() == true)
  end

  local new_state
  if ui_pressed_bool == setting_enabled then
    new_state = not setting_enabled
  else
    new_state = ui_pressed_bool
  end

  if TuffAlert_SetEnabled then
    TuffAlert_SetEnabled(new_state)
  end

  ButtonSetPressedFlag(checkbox_name, new_state)

  if DoesWindowExist("TuffAlert_ConfigWindowErrorLabel") then
    LabelSetTextColor("TuffAlert_ConfigWindowErrorLabel", 64, 255, 64)
    if new_state then
      LabelSetText("TuffAlert_ConfigWindowErrorLabel", L"TuffAlert enabled")
    else
      LabelSetText("TuffAlert_ConfigWindowErrorLabel", L"TuffAlert disabled")
    end
  end
end

function TuffAlert_Config_OnClose()
  WindowSetShowing(WINDOW_NAME, false)
end

function TuffAlert_Config_OnAddAbility()
  ClearErrorLabel()
  
  -- Get input values
  local id_text = TextEditBoxGetText("TuffAlert_ConfigWindowAddSectionIDInput")
  local name_text = TextEditBoxGetText("TuffAlert_ConfigWindowAddSectionNameInput")
  
  -- Convert wstring to string for ID
  local id_str = AA_TrimString(AA_WStringToStringSafe(id_text))
  local ability_id = tonumber(id_str)
  
  -- Validate ability ID
  if not ability_id or ability_id <= 0 then
    ShowError(L"Error: Invalid ability ID. Must be a positive number.")
    return
  end
  
  -- Check if ability already exists
  if TuffAlert_Settings.abilities[ability_id] then
    ShowError(L"Error: Ability ID already exists.")
    return
  end
  
  -- Validate name
  local name_str = AA_TrimString(AA_WStringToStringSafe(name_text))
  if not name_str or name_str == "" then
    ShowError(L"Error: Ability name cannot be empty.")
    return
  end
  
  -- Add new ability with default settings
  TuffAlert_Settings.abilities[ability_id] = {
    enabled = true,
    duration = 1.5,
    sound_enabled = true,
    texture = "TuffAlert_Alert",
    name = name_str
  }
  
  -- Clear input fields
  TextEditBoxSetText("TuffAlert_ConfigWindowAddSectionIDInput", L"")
  TextEditBoxSetText("TuffAlert_ConfigWindowAddSectionNameInput", L"")
  
  -- Refresh the list
  RefreshAbilityList()
  
  -- Show success message
  LabelSetTextColor("TuffAlert_ConfigWindowErrorLabel", 64, 255, 64)
  LabelSetText("TuffAlert_ConfigWindowErrorLabel", L"Ability added successfully")
end

function TuffAlert_Config_OnToggleEnabled()
  local checkbox_name = SystemData.ActiveWindow and SystemData.ActiveWindow.name
  if not checkbox_name or checkbox_name == "" then
    return
  end

  -- Ensure this behaves like a checkbox even if the template defaults differ.
  ButtonSetStayDownFlag(checkbox_name, true)

  local ability_id = nil
  local parent_name = WindowGetParent(checkbox_name)
  if type(parent_name) == "string" and parent_name ~= "" then
    ability_id = GetAbilityIdFromWindowName(parent_name)
  end
  if not ability_id then
    ability_id = GetAbilityIdFromActiveWindow()
  end
  if not ability_id then
    return
  end

  local cfg = TuffAlert_Settings and TuffAlert_Settings.abilities and TuffAlert_Settings.abilities[ability_id]
  if type(cfg) ~= "table" then
    return
  end

  local pressed = ButtonGetPressedFlag(checkbox_name)
  local pressed_bool = (pressed == true) or (pressed == 1)
  local setting_bool = (cfg.enabled == true)

  local new_state
  if pressed_bool == setting_bool then
    -- UI has not toggled yet (or is out of sync): toggle now.
    new_state = not setting_bool
  else
    -- UI already toggled: accept UI state.
    new_state = pressed_bool
  end

  cfg.enabled = new_state
  ButtonSetPressedFlag(checkbox_name, new_state)

  ClearErrorLabel()
end

function TuffAlert_Config_OnDurationChanged()
  local editbox_name = SystemData.ActiveWindow.name
  local parent_name = WindowGetParent(editbox_name)
  local ability_id = GetAbilityIdFromWindowName(parent_name)
  
  if not ability_id then return end
  
  local duration_text = TextEditBoxGetText(editbox_name)
  local duration_str = WStringToString(duration_text)

  if not duration_str or duration_str == "" then
    return
  end
  local duration = tonumber(duration_str)
  
  if duration and duration > 0 then
    if TuffAlert_Settings.abilities[ability_id] then
      TuffAlert_Settings.abilities[ability_id].duration = duration
    end
    ClearErrorLabel()
  else
    ShowError(L"Error: Duration must be a positive number.")
  end
end

function TuffAlert_Config_OnToggleSound()
  local checkbox_name = SystemData.ActiveWindow and SystemData.ActiveWindow.name
  if not checkbox_name or checkbox_name == "" then
    return
  end

  local parent_name = WindowGetParent(checkbox_name)
  local ability_id = GetAbilityIdFromWindowName(parent_name)
  if not ability_id then
    ability_id = GetAbilityIdFromActiveWindow()
  end
  if not ability_id then
    return
  end

  local cfg = TuffAlert_Settings.abilities[ability_id]
  if not cfg then
    return
  end

  ButtonSetStayDownFlag(checkbox_name, true)

  local pressed = ButtonGetPressedFlag(checkbox_name)
  local pressed_bool = (pressed == true) or (pressed == 1)
  local setting_bool = (cfg.sound_enabled == true)

  local new_state
  if pressed_bool == setting_bool then
    new_state = not setting_bool
  else
    new_state = pressed_bool
  end

  cfg.sound_enabled = new_state
  ButtonSetPressedFlag(checkbox_name, new_state)

  ClearErrorLabel()
end

function TuffAlert_Config_OnTextureChanged()
  if suppress_texture_changed then
    return
  end

  local combo_name = last_texture_combo_name
  if type(combo_name) ~= "string" or combo_name == "" then
    combo_name = SystemData.ActiveWindow and SystemData.ActiveWindow.name
  end

  local ability_id = nil
  if type(combo_name) == "string" then
    ability_id = tonumber(string.match(combo_name, "TuffAlert_AbilityRow_(%d+)Texture"))
  end

  if not ability_id then
    ability_id = GetAbilityIdFromActiveWindow()
  end
  
  if not ability_id then return end

  combo_name = "TuffAlert_AbilityRow_" .. ability_id .. "Texture"
  
  local selected_index = ComboBoxGetSelectedMenuItem(combo_name)
  
  if selected_index > 0 and selected_index <= #available_textures then
    local texture_asset = available_textures[selected_index]
    if TuffAlert_Settings.abilities[ability_id] then
      TuffAlert_Settings.abilities[ability_id].texture = texture_asset
    end
    ClearErrorLabel()

    if DoesWindowExist("TuffAlert_ConfigWindowErrorLabel") then
      LabelSetTextColor("TuffAlert_ConfigWindowErrorLabel", 64, 255, 64)
      LabelSetText("TuffAlert_ConfigWindowErrorLabel", L"Saved image: " .. towstring(TextureAssetToLabel(texture_asset)))
    end

    -- Preview: show the alert immediately for the edited ability.
    if TuffAlert_TriggerAbility then
      TuffAlert_TriggerAbility(ability_id)
    end
  end
end

function TuffAlert_Config_OnDeleteAbility()
  local button_name = SystemData.ActiveWindow and SystemData.ActiveWindow.name
  local parent_name = button_name and WindowGetParent(button_name)
  local ability_id = parent_name and GetAbilityIdFromWindowName(parent_name)

  -- Some UI templates can report different active window/parent chains; be defensive.
  if not ability_id then
    ability_id = GetAbilityIdFromActiveWindow()
  end

  if not ability_id then return end
  
  -- Remove from settings
  if TuffAlert_Settings.abilities[ability_id] then
    TuffAlert_Settings.abilities[ability_id] = nil
  end
  
  -- Refresh the list
  RefreshAbilityList()
  
  ClearErrorLabel()
  LabelSetTextColor("TuffAlert_ConfigWindowErrorLabel", 64, 255, 64)
  LabelSetText("TuffAlert_ConfigWindowErrorLabel", L"Ability deleted.")
end
