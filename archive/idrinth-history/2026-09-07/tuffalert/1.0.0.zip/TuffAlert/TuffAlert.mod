<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <UiMod name="TuffAlert" version="1.0" date="18/02/2026">

    <Author name="Tuff Bois - Loc, Rydiak" />

    <Dependencies>
      <Dependency name="EASystem_LayoutEditor" />
      <Dependency name="LibSlash" optional="false" />
    </Dependencies>

    <Description text="Shows a configurable popup/sound when specified combat abilities hit you. Use /tuffalert to configure." />

    <Files>
      <File name="Source\TuffAlert.xml" />
      <File name="Source\TuffAlert_Config.xml" />
      <File name="Source\TuffAlert.lua" />
      <File name="Source\TuffAlert_Config.lua" />
    </Files>

    <OnInitialize>
      <CallFunction name="TuffAlert_OnInitialize" />
      <CallFunction name="TuffAlert_Config_OnInitialize" />
    </OnInitialize>

    <OnShutdown>
      <CallFunction name="TuffAlert_OnShutdown" />
    </OnShutdown>

    <SavedVariables>
      <SavedVariable name="TuffAlert_Settings" />
    </SavedVariables>   

    <VersionSettings gameVersion="1.4.8" windowsVersion="1.0" savedVariablesVersion="1.0" />

    <WARInfo>
      <Categories>
        <Category name="COMBAT" />
      </Categories>
    </WARInfo>

  </UiMod>
</ModuleFile>
