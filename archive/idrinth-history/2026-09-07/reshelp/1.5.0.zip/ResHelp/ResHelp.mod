<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
    <UiMod name="ResHelp" version="1.5" date="06/17/2026">
        <Author name="Sullemunk" />
        <Description text="Helps target/ressing fallen players" />
    <VersionSettings gameVersion="1.4.8" windowsVersion="1.24" savedVariablesVersion="1.24" />
 		<Dependencies>
					<Dependency name="EASystem_Utils" />
					<Dependency name="EASystem_WindowUtils" />			
					<Dependency name="EA_ChatWindow" />
					<Dependency name="EA_AlertTextWindow" />	
		</Dependencies>
 
        <Files>
            <File name="ResHelp.lua" />
			<File name="ResHelp.xml" />
        </Files>
		
        <OnInitialize>
            <CallFunction name="ResHelp.OnInitialize" />
        </OnInitialize>

		<OnUpdate>
		 <CallFunction name="ResHelp.OnUpdate"/>
    	</OnUpdate>
	
        <OnShutdown>
			<CallFunction name="ResHelp.OnShutdown" />
		</OnShutdown>
    </UiMod>
</ModuleFile>