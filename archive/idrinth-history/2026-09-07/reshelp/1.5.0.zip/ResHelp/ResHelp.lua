ResHelp = {}
local WINDOW_NAME_TEST = "ResHelp_Tester"
local PlayerName = wstring.sub( GameData.Player.name,1,-3 )
local version = 1.4
local IgnorePhrase = {["Your"]=true,["You"]=true}
local HasSetRes = false
local HasLoaded = false
local AddParty = true
local AddWarband = true

--Icons of players added to the list
local SocialIcons = {
				["Friend"]=L"<icon00075>",
				["Guild"]=L"<icon00076>",
				["None"]=L"",
				["Ignore"]=L"<icon00068>",
				["Party"]=L"<icon00066>",
				["Warband"]=L"<icon00065>"
}
--Colors of players added to the list (Mostly taken from the Chat text colors)
local SocialColors = {
				["Friend"]=ChatSettings.Channels[10].defaultColor,
				["Guild"]=ChatSettings.Channels[8].defaultColor,
				["None"]=ChatSettings.Channels[7].defaultColor,
				["Ignore"]={r=255,g=25,b=25},
				["Warband"]=ChatSettings.Channels[14].defaultColor,
				["Party"]=ChatSettings.Channels[4].defaultColor
}

local T_Timer = 60		--Time before auto remove from list
local T_Fader = 0.8		--Time for removing (fading away)
local T_Ignore = 10		--Ignore timer so removed players dont get populated again
local MAX_LIST = 8		--Maximum of players in list
local IgnoreList = {}
local CALL_ICON = 79	--Icon for players calling for res
local ICON_SCALE = 0.9

--Status Texts
local TEXT_CAN_RES	=	L"<icon-052> Rez!"
local TEXT_HAS_RES	=	L"Pending"
local TEXT_IS_ALIVE	=	L"Alive"
local TEXT_LOS		=	L"Unavalible"	-- < This can be different things like out of range, no line of sight, ability on cooldown...
local TEXT_DISTANT	=	L"Distant"
local TEXT_REMOVING	=	L"Removing"
local TEXT_CALL_TEXT = 	L"X"			--Text for players calling for res (instead of char level)

ResHelp.ResSlot = 0
ResHelp.Timers = {}
ResHelp.Status = {}
local ResColor = {	--Background Color for the selected Player in the list, if can be ressed
				[false]={r=255,g=100,b=200},
				[true]={r=0,g=255,b=0}
}

local ResStatus = {
				[false]=TEXT_LOS,
				[true]=TEXT_CAN_RES
}

function ResHelp.OnInitialize()
ResHelp.Table = {}
ResHelp.ResList = {
			[1598] = "Rune Of Life"
		, 	[1908] = "Gedup!"
		, 	[8248] = "Breath Of Sigmar"
		, 	[8555] = "Tzeentch Shall Remake You"
		, 	[9246] = "Gift Of Life"
		, 	[9558] = "Stand, Coward!"	
}	

ResHelp.ResBuffs = {
			[1598] = "Rune Of Life"
		, 	[1908] = "Gedup!"
		, 	[8248] = "Breath Of Sigmar"
		, 	[8555] = "Tzeentch Shall Remake You"
		, 	[9246] = "Gift Of Life"
		, 	[9558] = "Stand, Coward!"
		, 	[14526] = "Rally"
		, 	[8567] = "Mark of Remaking"
		, 	[1608] = "Oath Rune of Sanctuary"
		, 	[1619] = "Grimnir's Fury"
		, 	[697] = "Alter Fate"		
		}	

CreateWindow("ResHelpWindow",true)

LayoutEditor.RegisterWindow("ResHelpWindow",L"ResHelper Window",L"Helps displaying Players in need of resses",false, false,true,nil)            	
RegisterEventHandler(SystemData.Events.CHAT_TEXT_ARRIVED, "ResHelp.OnChatText")

WindowRegisterEventHandler( "ResHelpWindow", SystemData.Events.PLAYER_TARGET_UPDATED, "ResHelp.UpdateTarget" )
WindowRegisterEventHandler ("ResHelpWindow", SystemData.Events.PLAYER_TARGET_EFFECTS_UPDATED, "ResHelp.OnEffectsUpdated")
RegisterEventHandler( SystemData.Events.ENTER_WORLD, "ResHelp.CheckRes" )
RegisterEventHandler( SystemData.Events.INTERFACE_RELOADED, "ResHelp.CheckRes" )
RegisterEventHandler(SystemData.Events.ALL_MODULES_INITIALIZED, "ResHelp.CheckRes") 
RegisterEventHandler( SystemData.Events.SHOW_ALERT_TEXT, "ResHelp.AddAlert" )
RegisterEventHandler(SystemData.Events.WORLD_MAP_POINTS_LOADED, "ResHelp.Enable")

ResHelp.CheckRes()
LabelSetText("ResHelpWindowNameLabel",L"RezList   ")
	
	for i=1,MAX_LIST do
		CreateWindowFromTemplate("ResHelpWindow_ResWindow"..i, "ResHelp_Template", "ResHelpWindow")		
		WindowSetId("ResHelpWindow_ResWindow"..i,i)		
		WindowClearAnchors ("ResHelpWindow_ResWindow"..i)
		WindowAddAnchor ("ResHelpWindow_ResWindow"..i, "bottomright", "ResHelpWindow_ResWindow"..(i-1), "topright", 0,7)
		WindowSetShowing("ResHelpWindow_ResWindow"..i,false)
		
		CreateWindowFromTemplate("ResHelpIcon"..i, "ResHelp_IconTemplate", "Root")		
		WindowSetScale("ResHelpIcon"..i,ICON_SCALE)
		WindowSetShowing("ResHelpIcon"..i,false)
	end

CreateWindow (WINDOW_NAME_TEST, true)
PlayerName = wstring.sub( GameData.Player.name,1,-3 )
end

function ResHelp.AddAlert()
--target is too far away, mark it as distant
	if SystemData.AlertText.VecType[1] ~= 0 then return end
	if SystemData.AlertText.VecText[1]:find(L" away to target") then
		local ResName = SystemData.AlertText.VecText[1]:match(L"([%S]+) .+ away to target")
		--d(L"target too far, distant "..towstring(ResName))		
		ResHelp.Status[tostring(ResName)] = TEXT_DISTANT
	end
end

function ResHelp.Enable()
HasLoaded = true
end

function ResHelp.OnChatText()
--Monitored chats for resses (can't type in local chats while dead like SAY or SHOUT, so ignore those)
    if ((GameData.ChatData.type == SystemData.ChatLogFilters.GROUP )
    	or (GameData.ChatData.type == SystemData.ChatLogFilters.TELL_RECEIVE) 		
	    or (GameData.ChatData.type == SystemData.ChatLogFilters.BATTLEGROUP)
	    or (GameData.ChatData.type == SystemData.ChatLogFilters.SCENARIO)	
	    or (GameData.ChatData.type == SystemData.ChatLogFilters.SCENARIO_GROUPS)			
    	or (GameData.ChatData.type == SystemData.ChatLogFilters.CHANNEL_1)
    	or (GameData.ChatData.type == SystemData.ChatLogFilters.CHANNEL_2)		

        )
    then
		--Check if text from players is within object range (bout ~280 ft), if not, don't add
	    if ( GameData.ChatData.objectId == 0 ) then
        return	
		end
		--Phrases to look for, usually X or REZ and only at start of texts, else it can trigger on everything
		if ( wstring.find(GameData.ChatData.text, L"x", 1) == 1 ) or ( wstring.find(GameData.ChatData.text, L"X", 1) == 1 ) or ( wstring.find(wstring.sub(GameData.ChatData.text, 1 ,3), L"rez", 1)) or ( wstring.find(wstring.sub(GameData.ChatData.text, 1 ,3), L"res", 1)) then
			ResHelp.AddChatRes( GameData.ChatData.objectId, GameData.ChatData.text,GameData.ChatData.name,GameData.ChatData.type )    
		end
	end
end

function ResHelp.AddChatRes(_id,_text,_name,_type)
	local ResName = towstring(_name)
	if IgnoreList[tostring(ResName)] ~= nil then return end
	if ResName:find(L"[' ]") then ResName= string.sub(tostring(ResName),1,-3) end
	--d(towstring(ResName)..L"--")
	if IgnorePhrase[tostring(ResName)] == true then return end
	if ResName == PlayerName then return end
	ResHelp.AddList(ResName,CALL_ICON,TEXT_CALL_TEXT,_id)
end

function ResHelp.UpdateTarget( targetClassification, targetId, targetType )
	TargetInfo:UpdateFromClient()
	if  targetType ~= SystemData.TargetObjectType.ALLY_PLAYER then
		return
	end
		
	local tarIcon = Icons.GetCareerIconIDFromCareerLine(TargetInfo:UnitCareer(targetClassification))
	local tarName = ResHelp.FixString(TargetInfo:UnitName(targetClassification))
	local tarHealth = TargetInfo:UnitHealth(targetClassification)
	local tarLevel = TargetInfo:UnitLevel(targetClassification)
	ResHelp.Status[tostring(tarName)] = nil
	
	if tarHealth <= 0 then
			ResHelp.AddList(tarName,tarIcon,tarLevel,targetId)		
	else
		--d(L"Has Health, means player's alive and don't need ress, remove")
		ResHelp.RemoveList(tarName,TEXT_IS_ALIVE,targetId)
	end
end

function ResHelp.CheckBuffs()
--check if target has a pending res buff, if so, remove
	local  TargetBuffs = GetBuffs(GameData.BuffTargetType.TARGET_FRIENDLY)
	if TargetBuffs ~= nil then
		for TargetBuffId, TargetBuff in pairs( TargetBuffs ) do
			if ResHelp.ResBuffs[TargetBuff.abilityId] ~= nil then
				--d(L"Pending Res ability found on player, remove")
				return true
			end
		end
	end
return false
end

function ResHelp.OnEffectsUpdated( updateType, updatedEffects, isFullList )
    if ( updateType == GameData.BuffTargetType.TARGET_FRIENDLY) then
	TargetInfo:UpdateFromClient()
			local tarType = TargetInfo:UnitType("selffriendlytarget")
			if tarType == 3	then			
			if TargetInfo:UnitHealth("selffriendlytarget") ~= 0 then return end
				--d(L"Effect check!")
			local tarName = wstring.sub(TargetInfo:UnitName("selffriendlytarget"),1,-3)			
			if IgnoreList[tostring(tarName)] ~= nil then return end
			for TargetBuffId, TargetBuff in pairs( updatedEffects ) do
				if ResHelp.ResBuffs[TargetBuff.abilityId] ~= nil then				
					--d(L"Pending Res ability found on player, remove")
					ResHelp.RemoveList(tarName,TEXT_HAS_RES)
					IgnoreList[tostring(tarName)] = T_Ignore
					return
				end
			end
		end		
	end
end

function ResHelp.AddList(ResName,CareerIcon,LvL,targetID)
--Add players to the list, and set it's social colors	
	if IgnoreList[tostring(ResName)] ~= nil then return end
	local social = "None"
	for k,v in pairs(ResHelp.Table) do
		if v.Name == towstring(ResName) then
			if targetID > 0 then
				ResHelp.Table[k].Icon = CareerIcon
				ResHelp.Table[k].Level = LvL
				ResHelp.Table[k].ID = targetID
			end
		--d(L"name Already Exist, Don't add, Just update Info")
			return
		end
	end
		
		if GuildWindowTabRoster.IsPlayerInGuild(towstring(ResName)) == true then --check if guild
			social = "Guild"
		end

		if IsWarBandActive() and PartyUtils.IsPlayerInWarband(towstring(ResName)) then --check if wb
			social = "Warband"
		end


				for a=1,5 do --check if party
					local member = PartyUtils.GetPartyMember(a)
					if( member ~= nil and member.name ~= nil and member.name ~= L"" )
					then
						if towstring(ResName) == member.name then 
							social = "Party"
							Level = member.level
							ID = member.worldObjNum
							Icon = Icons.GetCareerIconIDFromCareerLine( member.careerLine )
							break						
						end

					end
				end

	
		if SocialWindowTabFriends.IsPlayerFriend(towstring(ResName)) == true then --check if friend
			social = "Friend"
		end	

		if SocialWindowTabIgnore.IsPlayerIgnored(towstring(ResName)) == true then --check if Ignored
			social = "Ignore"
		end
	
	
	table.insert (ResHelp.Table,{Name=towstring(ResName),Timer=T_Timer,Icon=CareerIcon,Level=LvL,Social=social,ID=targetID})
	--d(L"ResHelpList: Adding")
	if DoesWindowExist("ResHelpWindow_ResWindow"..(#ResHelp.Table)) then
	WindowSetGameActionData("ResHelpWindow_ResWindow"..(#ResHelp.Table).."Select", GameData.PlayerActions.SET_TARGET, 0, towstring(ResName))
	LabelSetText("ResHelpWindow_ResWindow"..(#ResHelp.Table).."Status",L"")	
	LabelSetText("ResHelpWindow_ResWindow"..(#ResHelp.Table).."StatusBG",L"")	
	end	
end

function ResHelp.RemoveList(ResName,Status)
	for k,v in pairs(ResHelp.Table) do
		if v.Name == towstring(ResName) and ResHelp.Timers[tostring(ResName)] == nil then
		--d(L"ResHelpList: Removing")
		ResHelp.Timers[tostring(ResName)] = T_Fader
		ResHelp.Status[tostring(ResName)] = Status or L""
		if DoesWindowExist("ResHelpWindow_ResWindow"..k) then
			LabelSetText("ResHelpWindow_ResWindow"..k.."Status",ResHelp.Status[tostring(ResName)])	
			LabelSetText("ResHelpWindow_ResWindow"..k.."StatusBG",ResHelp.Status[tostring(ResName)])	
		end
		return
		end
	end
end

function ResHelp.OnUpdate(timeElapsed)
	
	--	===================================================================
	--	ResMarkers, Shamelessly stolen from Zomega (Omegus) AutoMark:
	--	===================================================================

			WindowSetShowing (WINDOW_NAME_TEST, true)
			
			local reset1_anchor_x = SystemData.screenResolution.x / 2
			local reset1_anchor_y = SystemData.screenResolution.y / 2
			
			WindowClearAnchors (WINDOW_NAME_TEST)
			WindowAddAnchor (WINDOW_NAME_TEST, "topleft", "Root", "topleft", reset1_anchor_x, reset1_anchor_y)
			local reset1_actual_x, reset1_actual_y = WindowGetScreenPosition (WINDOW_NAME_TEST)
			
			local reset2_anchor_x = reset1_anchor_x + 10
			local reset2_anchor_y = reset1_anchor_y + 10
			
			WindowClearAnchors (WINDOW_NAME_TEST)
			WindowAddAnchor (WINDOW_NAME_TEST, "topleft", "Root", "topleft", reset2_anchor_x, reset2_anchor_y)
			
			local reset2_actual_x, reset2_actual_y = WindowGetScreenPosition (WINDOW_NAME_TEST)
		
	--	===================================================================
		
				if HasSetRes == false and HasLoaded == true and ResHelp.ResAbility ~= nil then
					local SetRes = WindowGetGameActionData ("ResHelpWindow_DoRes")
					if SetRes == nil then
						WindowSetTintColor("ResHelpWindowIcon",255,0,0)
						WindowSetGameActionData ("ResHelpWindow_DoRes", GameData.PlayerActions.DO_ABILITY, ResHelp.ResAbility, L"")
					else
						HasSetRes = true
						WindowSetTintColor("ResHelpWindowIcon",255,255,255)
					end
				end
				
	for ClearWin = 1,MAX_LIST do
		WindowSetShowing("ResHelpIcon"..ClearWin,false)
	end
	
	if #ResHelp.Table>0 then
	for i=1,MAX_LIST do
			WindowSetShowing("ResHelpIcon"..i,false)
			if DoesWindowExist("ResHelpWindow_ResWindow"..i) then
				LabelSetText("ResHelpWindow_ResWindow"..i.."Label",L"")	
				LabelSetText("ResHelpWindow_ResWindow"..i.."Timer",L"")	
				WindowSetShowing("ResHelpWindow_ResWindow"..i,false)
				WindowSetTintColor("ResHelpWindow_ResWindow"..i.."BG", 255, 0,0)
				WindowSetShowing("ResHelpWindow_ResWindow"..i.."Border",false)
				WindowSetId("ResHelpWindow_ResWindow"..i.."Select",i)			
			
			if ResHelp.Table[i] ~= nil and ResHelp.Table[i].ID > 0 then
	
	--	===================================================================
	--	ResMarkers, Shamelessly stolen from Zomega (Omegus) AutoMark:
	--	===================================================================

    WindowClearAnchors (WINDOW_NAME_TEST)
    WindowAddAnchor (WINDOW_NAME_TEST, "topleft", "Root", "topleft", reset1_anchor_x, reset1_anchor_y)

    MoveWindowToWorldObject (WINDOW_NAME_TEST, ResHelp.Table[i].ID, 1.0)
	
    if (WindowGetShowing (WINDOW_NAME_TEST) == false)  then
      WindowSetShowing (WINDOW_NAME_TEST, true)
      WindowSetAlpha ("ResHelpIcon"..i, 0.0)
      continue

    end
	
    local object_x, object_y = WindowGetScreenPosition (WINDOW_NAME_TEST)

    if (reset1_actual_x ~= object_x) or (reset1_actual_y ~= object_y) then
      MoveWindowToWorldObject ("ResHelpIcon"..i, ResHelp.Table[i].ID, 1.0)
      WindowSetAlpha ("ResHelpIcon"..i, 1.0)
      continue 
    end	

    WindowClearAnchors (WINDOW_NAME_TEST)
    WindowAddAnchor (WINDOW_NAME_TEST, "topleft", "Root", "topleft", reset2_anchor_x, reset2_anchor_y)

    MoveWindowToWorldObject (WINDOW_NAME_TEST, ResHelp.Table[i].ID, 1.0)

    object_x, object_y = WindowGetScreenPosition (WINDOW_NAME_TEST)

    if (reset2_actual_x ~= object_x) or (reset2_actual_y ~= object_y) then

      MoveWindowToWorldObject ("ResHelpIcon"..i, ResHelp.Table[i].ID, 1.0)
      WindowSetAlpha ("ResHelpIcon"..i, 1.0)
      continue

    end

	--	===================================================================
	
	
		ResHelp.RemoveList(ResHelp.Table[i].Name,TEXT_REMOVING)

			end	
			end
	end
		local TestTargetGet = towstring(TargetInfo:UnitName("selffriendlytarget"))
		
		for k,v in pairs(ResHelp.Table) do
			if v.Timer > 0 then
			ResHelp.Table[k].Timer = ResHelp.Table[k].Timer - timeElapsed
			
			if tonumber(k) < (MAX_LIST+1) then
						
			if ResHelp.Table[k].Icon ~= nil then
				local Icon_texture, x,y = GetIconData(tonumber(ResHelp.Table[k].Icon))		
				DynamicImageSetTexture("ResHelpWindow_ResWindow"..k.."IconWindowImage",Icon_texture,x,y)
				DynamicImageSetTexture("ResHelpIcon"..k.."Image",Icon_texture,x,y)
			else
				DynamicImageSetTexture("ResHelpWindow_ResWindow"..k.."IconWindowImage",map_markers01,64,64)
				DynamicImageSetTextureSlice("ResHelpWindow_ResWindow"..k.."IconWindowImage","NPC-Healer-Large")
				
				DynamicImageSetTexture("ResHelpIcon"..k.."Image",map_markers01,64,64)
				DynamicImageSetTextureSlice("ResHelpIcon"..k.."Image","NPC-Healer-Large")
			end		
				
				WindowSetShowing("ResHelpWindow_ResWindow"..k,true)
				local perc_comp = ResHelp.Table[k].Timer / T_Timer
				local FillStart = 275
				local FillEnd = 365

				local startFill =  365 * (1 - perc_comp)

				CircleImageSetFillParams( "ResHelpWindow_ResWindow"..k.."IconWindowCircle", FillStart,  FillEnd - startFill ) 
				WindowSetTintColor( "ResHelpWindow_ResWindow"..k.."IconWindowCircle", 255*(1-(((perc_comp)*100)/100)),255*(((perc_comp)*100)/100) , 0)
				
				CircleImageSetFillParams( "ResHelpIcon"..k.."Circle", FillStart,  FillEnd - startFill ) 
				WindowSetTintColor( "ResHelpIcon"..k.."Circle", 255*(1-(((perc_comp)*100)/100)),255*(((perc_comp)*100)/100) , 0)
				
				
				
			if TestTargetGet:match(towstring(v.Name)) then	
			if TargetInfo:UnitHealth ("selffriendlytarget") == 0 then
				if ResHelp.ResAbility ~= nil then
					WindowSetShowing("ResHelpWindow_ResWindow"..k.."Border",true)
					WindowSetLayer("ResHelpWindow_ResWindow"..k,Window.Layers.DEFAULT)
					WindowSetId("ResHelpWindow_DoRes",k)
				else
					WindowSetGameActionData("ResHelpWindow_ResWindow"..k.."Select", GameData.PlayerActions.SET_TARGET, 0, towstring(v.Name))
					WindowSetLayer("ResHelpWindow_ResWindow"..k,Window.Layers.POPUP)
				end
				local IsValid = ResHelp.CheckValid(ResHelp.ResSlot)
				local color = ResColor[IsValid]
				WindowSetTintColor("ResHelpWindow_ResWindow"..k.."BG", color.r, color.g,color.b)		
			
			else
				ResHelp.RemoveList(v.Name,TEXT_IS_ALIVE)
			end
		else
			WindowSetGameActionData("ResHelpWindow_ResWindow"..k.."Select", GameData.PlayerActions.SET_TARGET, 0, towstring(v.Name))
			WindowSetLayer("ResHelpWindow_ResWindow"..k,Window.Layers.POPUP)
		end
			end	
			
			else
				table.remove (ResHelp.Table,k)			--Timed out, remove
			end	

		if DoesWindowExist("ResHelpWindow_ResWindow"..k) then
		LabelSetText("ResHelpWindow_ResWindow"..k.."Label",towstring(towstring(v.Name)..SocialIcons[v.Social]))	
		LabelSetText("ResHelpWindow_ResWindow"..k.."LabelBG",towstring(towstring(v.Name)..SocialIcons[v.Social]))
		LabelSetText("ResHelpWindow_ResWindow"..k.."Timer",towstring(v.Level))
		LabelSetText("ResHelpWindow_ResWindow"..k.."Status",ResHelp.GetStatus(tostring(v.Name)))		
		LabelSetText("ResHelpWindow_ResWindow"..k.."StatusBG",ResHelp.GetStatus(tostring(v.Name)))		
		WindowSetAlpha("ResHelpWindow_ResWindow"..k,ResHelp.GetTimer(tostring(v.Name)))
		local socialColor = SocialColors[v.Social]
		LabelSetTextColor ("ResHelpWindow_ResWindow"..k.."Label", socialColor.r, socialColor.g, socialColor.b)
		WindowSetTintColor ("ResHelpIcon"..k.."Icon", socialColor.r, socialColor.g, socialColor.b)

		end
		end
	if WindowGetShowing("ResHelpWindow") == true then
		WindowSetDimensions("ResHelpWindow",210,math.min(26+(44*#ResHelp.Table),(42*MAX_LIST)+28))	
	end

	else
		WindowSetDimensions("ResHelpWindow",210,35)	
	end	
WindowSetShowing("ResHelpWindow_ResWindow1",#ResHelp.Table>0)	
WindowSetShowing("ResHelpWindow",true)	

	for k,v in pairs(ResHelp.Timers) do
		if v >= 0 then
			ResHelp.Timers[k] = v - timeElapsed
		else
		
				for a,b in pairs(ResHelp.Table) do
				if b.Name == towstring(k) then
					table.remove (ResHelp.Table,a)
					ResHelp.Timers[k] = nil
					ResHelp.Status[k] = nil					
				return
				end
				end
		end
	end

	for key,value in pairs(IgnoreList) do
		if value >= 0 then
			IgnoreList[tostring(key)] = value - timeElapsed
		else
			IgnoreList[tostring(key)] = nil
		end
	end


end	

function ResHelp.GetTimer(m_Name)
if ResHelp.Timers ~= nil and ResHelp.Timers[m_Name] ~= nil then
return ResHelp.Timers[m_Name]
else
return T_Fader
end
end

function ResHelp.GetStatus(m_Name)
	if ResHelp.Status ~= nil and ResHelp.Status[m_Name] ~= nil then
	return ResHelp.Status[m_Name]
	else
			local SendBack = L""
			local TestTargetGet = towstring(TargetInfo:UnitName("selffriendlytarget"))

				if TestTargetGet:match(towstring(m_Name)) then	
					SendBack = ResStatus[ResHelp.CheckValid(ResHelp.ResSlot)]
				else
					SendBack = L""
				end
				
	return SendBack
	end
end

function ResHelp.GetNameSlot(m_Name)
	for k,v in pairs(ResHelp.Table) do
		if tostring(v.name) == tostring(m_Name) then
			return k
		end
	end
return false
end

function ResHelp.CheckRes()
ResHelp.ResAbility = nil		
	local abilityTable = GetAbilityTable(GameData.AbilityType.STANDARD)
	for i, v in pairs(ResHelp.ResList) do
		if abilityTable[i] ~= nil then
			ResHelp.ResAbility = i
			ResHelp.GetSlot()
			return
		end
   end
end

function ResHelp.GetSlot()
	for i=1,130 do
		local Type,actionID,IsEnabled,IsTargetValid,IsBlocked = GetHotbarData(i)
		if actionID == ResHelp.ResAbility then
			ResHelp.ResSlot = i
			break
		end
	end
end

function ResHelp.CheckValid(slot)
--local Valid,Type,actionID,IsEnabled,IsTargetValid,IsBlocked
local Type,actionID,IsEnabled,IsTargetValid,IsBlocked = GetHotbarData( slot )
local Valid = (IsEnabled == true and IsTargetValid == true and IsBlocked == false)
return (Valid)
end


function ResHelp.SelectChar()
	local WindowName = towstring(SystemData.MouseOverWindow.name)
	local Number = WindowGetId(SystemData.MouseOverWindow.name)
	if Number == nil or ResHelp.Table[Number] == nil then return end
	local TestTargetGet = towstring(TargetInfo:UnitName("selffriendlytarget"))
	local TestNameGet = towstring(ResHelp.Table[Number].Name)
		
	if TestTargetGet:match(towstring(TestNameGet)) then	
		if TargetInfo:UnitHealth ("selffriendlytarget") == 0 then
			if ResHelp.ResAbility ~= nil then
					WindowSetLayer("ResHelpWindow_ResWindow"..Number,Window.Layers.DEFAULT)
					WindowSetId("ResHelpWindow_DoRes",Number)
					
							local careerLine = TargetInfo:UnitCareer("selffriendlytarget")
							if( careerLine ~= 0 )
							then
								ResHelp.Table[Number].Icon = Icons.GetCareerIconIDFromCareerLine( careerLine )
								ResHelp.Table[Number].Level = TargetInfo:UnitBattleLevel("selffriendlytarget")
							end
					
			else
				WindowSetGameActionData("ResHelpWindow_ResWindow"..Number.."Select", GameData.PlayerActions.SET_TARGET, 0, towstring(TestNameGet))
					WindowSetLayer("ResHelpWindow_ResWindow"..Number,Window.Layers.POPUP)
			end
		else
			--table.remove (ResHelp.Table,Number)
				ResHelp.RemoveList(TestNameGet,TEXT_IS_ALIVE)
		end
	else
		WindowSetGameActionData("ResHelpWindow_ResWindow"..Number.."Select", GameData.PlayerActions.SET_TARGET, 0, towstring(TestNameGet))
		WindowSetLayer("ResHelpWindow_ResWindow"..Number,Window.Layers.POPUP)
	end

end


function ResHelp.RemoveChar()
	local WindowName = towstring(SystemData.MouseOverWindow.name)
	local Number = WindowGetId(SystemData.MouseOverWindow.name)
	if Number == nil or ResHelp.Table[Number] == nil then return end
	local TestNameGet = towstring(ResHelp.Table[Number].Name)
		
	ResHelp.RemoveList(TestNameGet,TEXT_REMOVING)
	IgnoreList[tostring(TestNameGet)] = T_Ignore
end


function ResHelp.FixString (str)

	if (str == nil) then return nil end

	local str = str
	local pos = str:find (L"^", 1, true)
	if (pos) then str = str:sub (1, pos - 1) end
	
	return str
end

--this will run on exit
function ResHelp.OnShutdown()

	UnregisterEventHandler(SystemData.Events.CHAT_TEXT_ARRIVED, "ResHelp.OnChatText")
	UnregisterEventHandler(SystemData.Events.ENTER_WORLD, "ResHelp.CheckRes")
	UnregisterEventHandler(SystemData.Events.INTERFACE_RELOADED, "ResHelp.CheckRes")
	UnregisterEventHandler(SystemData.Events.ALL_MODULES_INITIALIZED, "ResHelp.CheckRes")
	UnregisterEventHandler(SystemData.Events.SHOW_ALERT_TEXT, "ResHelp.AddAlert")
	UnregisterEventHandler(SystemData.Events.WORLD_MAP_POINTS_LOADED, "ResHelp.Enable")

	if DoesWindowExist("ResHelpWindow") then
		WindowUnregisterEventHandler("ResHelpWindow", SystemData.Events.PLAYER_TARGET_UPDATED)
		WindowUnregisterEventHandler("ResHelpWindow", SystemData.Events.PLAYER_TARGET_EFFECTS_UPDATED)
	end

end