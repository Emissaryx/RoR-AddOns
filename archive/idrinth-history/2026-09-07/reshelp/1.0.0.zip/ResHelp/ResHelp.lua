ResHelp = {}
local version = 1.0
local IgnorePhrase = {["Your"]=true,["You"]=true}
local T_Timer = 40

function ResHelp.OnInitialize()
ResHelp.Table = {}
CreateWindow("ResHelpWindow",true)
LayoutEditor.RegisterWindow("ResHelpWindow",L"ResHelper Window",L"Helps displaying Players in need of resses",false, false,true,nil)            	
RegisterEventHandler(TextLogGetUpdateEventId("Chat"), "ResHelp.TextArrived")
WindowRegisterEventHandler( "ResHelpWindow", SystemData.Events.PLAYER_TARGET_UPDATED, "ResHelp.UpdateTarget" )
WindowRegisterEventHandler ("ResHelpWindow", SystemData.Events.PLAYER_TARGET_EFFECTS_UPDATED, "ResHelp.OnEffectsUpdated")
RegisterEventHandler( SystemData.Events.ENTER_WORLD, "ResHelp.CheckRes" )
RegisterEventHandler( SystemData.Events.INTERFACE_RELOADED, "ResHelp.CheckRes" )
RegisterEventHandler(SystemData.Events.ALL_MODULES_INITIALIZED, "ResHelp.CheckRes") 
RegisterEventHandler( SystemData.Events.SHOW_ALERT_TEXT, "ResHelp.AddAlert" )
ResHelp.CheckRes()
LabelSetText("ResHelpWindowNameLabel",L"ResHelper")
end

function ResHelp.AddAlert()
	if SystemData.AlertText.VecType[1] ~= 0 then return end
	if SystemData.AlertText.VecText[1]:find(L" away to target") then
		local ResName = SystemData.AlertText.VecText[1]:match(L"([%S]+) .+ away to target")
		--d(L"target too far, remove "..towstring(ResName))
		ResHelp.RemoveList(ResName)
	end
end

function ResHelp.UpdateTarget( targetClassification, targetId, targetType )
	TargetInfo:UpdateFromClient()
	if  targetType ~= SystemData.TargetObjectType.ALLY_PLAYER then
		return
	end
	
	local tarIcon = Icons.GetCareerIconIDFromCareerLine(TargetInfo:UnitCareer(targetClassification))
	local tarName = ResHelp.FixString(TargetInfo:UnitName(targetClassification))
	local tarHealth = TargetInfo:UnitHealth(targetClassification)
	local tarLevel = TargetInfo:UnitLevel(targetClassification)
	
	if tarHealth == 0 then
			ResHelp.AddList(tarName,tarIcon,tarLevel)		
	else
		--d(L"Has Health, remove")
		ResHelp.RemoveList(tarName)
	end
end

function ResHelp.CheckBuffs()
	local  TargetBuffs = GetBuffs(GameData.BuffTargetType.TARGET_FRIENDLY)
	if TargetBuffs ~= nil then
		for TargetBuffId, TargetBuff in pairs( TargetBuffs ) do
			if ResHelp.ResList[TargetBuff.abilityId] ~= nil then
				--d(L"Res ability found, remove")
				return true
			end
		end
	end
return false
end

function ResHelp.OnEffectsUpdated( updateType, updatedEffects, isFullList )
    if ( updateType == GameData.BuffTargetType.TARGET_FRIENDLY) then
	TargetInfo:UpdateFromClient()
			local tarType = TargetInfo:UnitType("selffriendlytarget")
			if tarType == 3	then			
			if TargetInfo:UnitHealth("selffriendlytarget") ~= 0 then return end
				--d(L"Effect check!")
			local tarName = wstring.sub(TargetInfo:UnitName("selffriendlytarget"),1,-3)			
			for TargetBuffId, TargetBuff in pairs( updatedEffects ) do
				if ResHelp.ResList[TargetBuff.abilityId] ~= nil then				
					--d(L"Res ability found, remove")
					ResHelp.RemoveList(tarName)
					return
				end
			end
		end		
	end
end

function ResHelp.TextArrived(updateType, filterType)
		if( updateType == SystemData.TextLogUpdate.ADDED ) then 			
			if filterType == SystemData.ChatLogFilters.EMOTE then	
				local _, filterId, text = TextLogGetEntry( "Chat", TextLogGetNumEntries("Chat") - 1 ) 				
				if text:find(L" rez") then
				ResHelp.CheckText(text)
					--d(L"Res Emote")
				end				
			end
		end
end

function ResHelp.CheckText(text)
	local ResName = text:match(L"([%S]+) .+ rez")
	if ResName:find(L"['�]") then ResName= string.sub(tostring(ResName),1,-3) end
	--d(towstring(ResName)..L"--")
	if IgnorePhrase[tostring(ResName)] == true then return end
	ResHelp.AddList(ResName,79,"")
end


function ResHelp.AddList(ResName,CareerIcon,LvL)
	for k,v in pairs(ResHelp.Table) do
		if v.Name == towstring(ResName) then
		--d(L"name Already Exist, Dont add")
			return
		end
	end
	table.insert (ResHelp.Table,{Name=towstring(ResName),Timer=T_Timer,Icon=CareerIcon,Level=LvL})
	--d(L"ResHelpList: Adding")
	WindowSetGameActionData("ResHelpWindow_ResWindow"..(#ResHelp.Table), GameData.PlayerActions.SET_TARGET, 0, towstring(ResName))

end

function ResHelp.RemoveList(ResName)
	for k,v in pairs(ResHelp.Table) do
		if v.Name == towstring(ResName) then
		--d(L"ResHelpList: Removing")
		table.remove (ResHelp.Table,k)
		return
		end
	end
end

--
function ResHelp.OnUpdate(timeElapsed)
	if #ResHelp.Table>0 then
	for i=1,6 do
				LabelSetText("ResHelpWindow_ResWindow"..i.."Label",L"")	
				LabelSetText("ResHelpWindow_ResWindow"..i.."Timer",L"")	
				WindowSetShowing("ResHelpWindow_ResWindow"..i,false)
				WindowSetTintColor("ResHelpWindow_ResWindow"..i.."BG", 255, 0,0)	
	end
		local TestTargetGet = towstring(TargetInfo:UnitName("selffriendlytarget"))
		
		for k,v in pairs(ResHelp.Table) do
			if v.Timer > 0 then
			
			if ResHelp.Table[k].Icon ~= nil then
				local Icon_texture, x,y = GetIconData(tonumber(ResHelp.Table[k].Icon))		
				DynamicImageSetTexture("ResHelpWindow_ResWindow"..k.."Image",Icon_texture,x,y)
			else
				DynamicImageSetTexture("ResHelpWindow_ResWindow"..k.."Image",map_markers01,64,64)
				DynamicImageSetTextureSlice("ResHelpWindow_ResWindow"..k.."Image","NPC-Healer-Large")
			end		
				ResHelp.Table[k].Timer = ResHelp.Table[k].Timer - timeElapsed
				WindowSetShowing("ResHelpWindow_ResWindow"..k,true)
				local perc_comp = ResHelp.Table[k].Timer / T_Timer
				local FillStart = 275
				local FillEnd = 365

				local startFill =  365 * (1 - perc_comp)

				CircleImageSetFillParams( "ResHelpWindow_ResWindow"..k.."Circle", FillStart,  FillEnd - startFill ) 
				
				
			if TestTargetGet:match(towstring(v.Name)) then	
			if TargetInfo:UnitHealth ("selffriendlytarget") == 0 then
				if ResHelp.ResAbility then
					WindowSetGameActionData ("ResHelpWindow_ResWindow"..k, GameData.PlayerActions.DO_ABILITY, ResHelp.ResAbility, L"")
				else
					WindowSetGameActionData("ResHelpWindow_ResWindow"..k, GameData.PlayerActions.SET_TARGET, 0, towstring(v.Name))
				end
				
				WindowSetTintColor("ResHelpWindow_ResWindow"..k.."BG", 0, 255,0)			
			else
				table.remove (ResHelp.Table,k)
			end
		else
			WindowSetGameActionData("ResHelpWindow_ResWindow"..k, GameData.PlayerActions.SET_TARGET, 0, towstring(v.Name))
		end
				
			else
				table.remove (ResHelp.Table,k)			
			end	
		LabelSetText("ResHelpWindow_ResWindow"..k.."Label",v.Name)	
		LabelSetText("ResHelpWindow_ResWindow"..k.."Timer",towstring(v.Level))	
		--StatusBarSetCurrentValue("ResHelpWindow_ResWindow"..k.."TimerBar", v.Timer )
		end			
	WindowSetDimensions("ResHelpWindow",210,math.min(26+(44*#ResHelp.Table),280))	
	end	
WindowSetShowing("ResHelpWindow",#ResHelp.Table>0)	
end	

function ResHelp.CheckRes()
ResHelp.ResAbility = nil
	ResHelp.ResList = {
			[1598] = "Rune Of Life"
		, 	[1908] = "Gedup!"
		, 	[8248] = "Breath Of Sigmar"
		, 	[8555] = "Tzeentch Shall Remake You"
		, 	[9246] = "Gift Of Life"
		, 	[9558] = "Stand, Coward!"
	                  }
	local abilityTable = GetAbilityTable(GameData.AbilityType.STANDARD)
	for i, v in pairs(ResHelp.ResList) do
		if abilityTable[i] ~= nil then
			ResHelp.ResAbility = i
			return
		end
   end
end

function ResHelp.SelectChar()
	local WindowName = towstring(SystemData.MouseOverWindow.name)
	--local Number = 	tonumber(WindowName:match(L"ResHelpWindow_ResWindow([%d.]+)"))
	local Number = WindowGetId(SystemData.MouseOverWindow.name)
	if Number == nil or ResHelp.Table[Number] == nil then return end
	local TestTargetGet = towstring(TargetInfo:UnitName("selffriendlytarget"))
	local TestNameGet = towstring(ResHelp.Table[Number].Name)
		
	if TestTargetGet:match(towstring(TestNameGet)) then	
		if TargetInfo:UnitHealth ("selffriendlytarget") == 0 then
			if ResHelp.ResAbility then
				WindowSetGameActionData ("ResHelpWindow_ResWindow"..Number, GameData.PlayerActions.DO_ABILITY, ResHelp.ResAbility, L"")	
			else
				WindowSetGameActionData("ResHelpWindow_ResWindow"..Number, GameData.PlayerActions.SET_TARGET, 0, towstring(TestNameGet))
			end
		else
			table.remove (ResHelp.Table,Number)
		end
	else
		WindowSetGameActionData("ResHelpWindow_ResWindow"..Number, GameData.PlayerActions.SET_TARGET, 0, towstring(TestNameGet))
	end

end


function ResHelp.FixString (str)

	if (str == nil) then return nil end

	local str = str
	local pos = str:find (L"^", 1, true)
	if (pos) then str = str:sub (1, pos - 1) end
	
	return str
end

--this will run on exit
function ResHelp.OnShutdown()	

end
