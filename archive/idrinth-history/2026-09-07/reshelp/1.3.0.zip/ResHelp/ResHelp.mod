<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
    <UiMod name="ResHelp" version="1.3" date="08/29/2026">
        <Author name="Sullemunk" />
        <Description text="Helping ressurecting players from a list" />
 
 		<Dependencies>
					<Dependency name="EASystem_Utils" />
					<Dependency name="EASystem_WindowUtils" />			
					<Dependency name="EA_ChatWindow" />
					<Dependency name="EA_AlertTextWindow" />	
		</Dependencies>
 
        <Files>
            <File name="ResHelp.lua" />
			<File name="ResHelp.xml" />
        </Files>
		
        <OnInitialize>
            <CallFunction name="ResHelp.OnInitialize" />
        </OnInitialize>

		<OnUpdate>
		 <CallFunction name="ResHelp.OnUpdate"/>
    	</OnUpdate>
	
        <OnShutdown>
			<CallFunction name="ResHelp.OnShutdown" />
		</OnShutdown>
    </UiMod>
</ModuleFile>