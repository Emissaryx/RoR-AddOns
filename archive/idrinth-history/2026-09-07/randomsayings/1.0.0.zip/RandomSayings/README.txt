README file for
RandomSayings:  An Addon for Warhammer Online / Return of Reckoning

Description:
============
Have you ever wanted to give your character a "pool" of quotations.... that you could randomly 
summon from... into local chat with a button press?

Maybe you'd like to be able to hit a button and shout one of five different battle-cries?  Or 
maybe(like I once did in "City of Heroes") you'd like to be able to press a button and randomly 
say one of 50 "Yo momma" jokes!

If so, this is the Addon for you!
Install it. Configure it with your phrases list. Create a Macro for it.  Drag the Macro icon to 
your hotbar...and go!



Installation Instructions:
==========================
As with most Warhammer Addons, you simply have to extract the .zip package that this file came in 
into the game's "Addons" directory.
So, your extraction path would be something similar to:  
     <Warhammer Installation Directory>/Interface/AddOns
	 
When you've finished, you should find that the "AddOns" directory now contains a "RandomSayings" 
sub-directory.

Please proceed to the Configuration Instructions below, as you'll want to change the "default 
sayings" that I've pre-packaged with the AddOn.


Configuration Instructions:
===========================
1) Open up the DefaultSettings.lua file with a text editor.
2) As you can see, there are already almost 40 "sayings" (single lines of text surrounded by 
quotation marks, each line ending in a comma) here.  (These are some sayings I set up for my 
Sorceress, "Karen Killjoy".)  You're going to simply remove these lines and substitute them with 
your own.  But you have to follow the same pattern. (So, you might want to keep several of the 
original lines around for a while as you type your new ones, just so you have a "model" to look 
at.)

Each line must start with a double-quote ("), and end with a double-quote, followed by a comma 
(",).

Please be warned that you should NOT use any double-quotation marks WITHIN each "saying" / line, 
as this will "break" that line of text.  (The computer will "think" that the second quotation 
mark that it finds in that line of text marks the end of it.)

Note that it is very important to leave the rest of the file's structure....the two lines that 
mention "DefaultSettings" and the set of parentheses that surround your "sayings lines".... intact.

3) Save your file.

4) Start your game.  It should prompt you that it has found a new AddOn and ask if you want to 
enable it. 

5) OK, now we have to set up a Macro.  This is a special button that you're going to drag onto 
one of your hotbars.  (You'll end up pressing this in order to get your character to say one of 
the random sayings.)  To do this:

	a) Go to the central game menu, choose "Macros".  

	b) A small window should pop up.  The window shows quite a few icons.  Underneath that is a 
field for "Macro Name" and a larger field beneath that for "Macro Text".   Select/click on one of 
the "empty" icon image boxes in that probably say "No icon set".  Make sure that the "Macro Name" 
and "Macro Text" fields both appear blank when you do this.  

	c) For "Macro Name", type in "RandomSayings".  

	d) For "Macro Text" type or paste in "/script RandomSayings.Speak()".  

	e) To the left of the "Macro Name" field is a box that represents what image is assigned to 
this new macro. Click on that box.  A pop-up form should appear that will show you the available 
images to choose from.  Select one.  

	f) Then click the "Save" button.

	g) Your macro is now saved.  If you look at the collection of icons in the top portion of 
this "Macros" form, the one that you clicked on in step "b" now should show the Macro Image that 
you selected in step "e".  Click on that image and.... DRAG it onto one of your hotbars.  

6) You're all set!  Click on that button and you should immediately say one of your "Random 
Sayings" locally!



How to Update Your Phrases Later On:
====================================
The Addon is rigged to save your custom settings out to your character's profile, once the UI 
reloads after you enable the AddOn.   After that, whenever you launch the game, it will look at 
that character-specific copy of the "Sayings List" instead of the DefaultSettings.lua file that 
you modified in the "Configuration Instructions" above. 

So, if you want to make any changes to your sayings in the future, you'll need to go edit that 
character-specific copy. 
It will be located in this path:

     <Warhammer Installation Directory>\user\settings\Martyrs Square\<character 
name>\<profilename>\RandomSayings\SavedVariables.lua

Simply:
	a) Make sure your game is shut down first. 
	b) Edit and save this file (in the same manner that you edited and saved the 
DefaultSettings.lua file).   


THANKS !!
ENJOY !!