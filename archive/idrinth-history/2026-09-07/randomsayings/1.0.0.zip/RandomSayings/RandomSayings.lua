RandomSayings = {}

 local versionNumber = "1.0"
 local titleString = towstring("<icon=57> <LINK data=\"0\" text=\"[RandomSayings]\" color=\"50,255,50\"> version "..versionNumber.." ")

function RandomSayings.OnInitialize()
    d (L"Initializing Settings")
	if (RandomSayings.Settings == nil) then
		RandomSayings.Settings = {}
	end

	if (RandomSayings.Settings.MySayings ~= nil) then 
		EA_ChatWindow.Print(titleString..towstring("has loaded "..#RandomSayings.Settings.MySayings.." pre-saved user sayings."))
	else
		d (L"RandomSayings has not detected any saved personal Settings.  Attempting to load Defaults.")
		RandomSayings.Settings.MySayings = DefaultSettings.MySayings
		EA_ChatWindow.Print(titleString..towstring("has successfully loaded "..#DefaultSettings.MySayings.." Default saying strings."))
	 end
end


function RandomSayings.Speak()
   local selectedPhrase = towstring(RandomSayings.Settings.MySayings[math.random(1,#RandomSayings.Settings.MySayings)])
   SendChatText(towstring("/say ")..selectedPhrase, L"")
end