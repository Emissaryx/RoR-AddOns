<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
	<UiMod name="RandomSayings" version="1.0.0" date="02.25.2021" >
		<Author name="DR4296" email="dr4296@myoldhouse.com" />
		<Description text="Allows you to create a macro-button that, when pressed, will randomly pick one of a random list of 'sayings' stored in a text file...and '/say' it in the chat window. Be sure to check out the Addon's README.txt file." />
		<VersionSettings gameVersion="1.4.8" windowsVersion="1.0" savedVariablesVersion="1.0" /> 
		<Dependencies>
			<Dependency name="EA_ChatWindow" />
		</Dependencies>
		<Files>
			<File name="RandomSayings.lua" />
			<File name="DefaultSettings.lua" />
		</Files>
		<SavedVariables>
			<SavedVariable name="RandomSayings.Settings" />
		</SavedVariables>
		<OnInitialize>
			<CallFunction name="RandomSayings.OnInitialize" />
		</OnInitialize>
		<OnUpdate />
		<WARInfo>
			<Careers>
				<Career name="BLACKGUARD" />
				<Career name="WITCH_ELF" />
				<Career name="DISCIPLE" />
				<Career name="SORCERER" />
				<Career name="IRON_BREAKER" />
				<Career name="SLAYER" />
				<Career name="RUNE_PRIEST" />
				<Career name="ENGINEER" />
				<Career name="BLACK_ORC" />
				<Career name="CHOPPA" />
				<Career name="SHAMAN" />
				<Career name="SQUIG_HERDER" />
				<Career name="WITCH_HUNTER" />
				<Career name="KNIGHT" />
				<Career name="BRIGHT_WIZARD" />
				<Career name="WARRIOR_PRIEST" />
				<Career name="CHOSEN" />
				<Career name="MARAUDER" />
				<Career name="ZEALOT" />
				<Career name="MAGUS" />
				<Career name="SWORDMASTER" />
				<Career name="SHADOW_WARRIOR" />
				<Career name="WHITE_LION" />
				<Career name="ARCHMAGE" />
			</Careers>
		</WARInfo>
	</UiMod>
</ModuleFile>