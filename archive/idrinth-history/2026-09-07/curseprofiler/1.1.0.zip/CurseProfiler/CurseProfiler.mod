<?xml version="1.0" encoding="UTF-8"?> 
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" >
	<UiMod name="ZCurse_Profiler" version="1.1" date="4/16/2009" >
	<VersionSettings gameVersion="1.3.0" windowsVersion="1.0" savedVariablesVersion="1.0" />	
	<Author name="Curse Inc" email="bugs@wardb.com" />	
	<Description text="The Curse Profiler is Curse's Warhammer Online data collection addon." />
	<Dependencies/>
	<Files>                                        

        <File name="CurseProfilerCompiled.lua" />         

    </Files>
    
	<OnInitialize>
		<CallFunction name="CurseProfiler.Initialize" />
	</OnInitialize>
	<OnUpdate>
		<CallFunction name="CurseProfiler.Update" />
	</OnUpdate>
    <OnShutdown>
		<CallFunction name="CurseProfiler.Shutdown" />
	</OnShutdown>	
	<SavedVariables>
		<SavedVariable name="CurseProfiler.Save" />
	</SavedVariables>
	</UiMod>
</ModuleFile>
</xml>
