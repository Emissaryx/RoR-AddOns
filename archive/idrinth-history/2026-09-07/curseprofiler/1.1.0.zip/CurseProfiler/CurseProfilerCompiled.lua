do


function NewAbilityHandler.Initialize()end

if _G.debug==nil then
SetLoadLuaDebugLibrary(true)
end


CurseProfiler={}
CurseProfiler.ifnot=false
CurseProfiler.endrepeat=2009052011
CurseProfiler.dofunction=nil
CurseProfiler.notwhile="EA_Window_WorldMapZoneViewMapDisplay"
local call__data={n=0}
local function call()
return call__data[1](unpack(call__data,2,call__data.n))
end

local errors={}
CurseProfiler.elseiffor=errors

function CurseProfiler.endand(str)
if(str==nil)then
return""
elseif type(str)=="string"then
return str
elseif type(str)=="wstring"then
return WStringToString(str)
else
return tostring(str)
end
end

function CurseProfiler.trueor(var)
if(type(var)=="boolean")then
if(var==true)then
return towstring("true")
else
return towstring("false")
end
elseif(type(var)=="integer")then
return towstring(tostring(var))
elseif(type(var)=="number")then
return towstring(tostring(var))
elseif(type(var)=="string")then
return towstring(var)
elseif(type(var)=="wstring")then
return var
elseif(type(var)=="table")then
return towstring("table {}")
elseif(type(var)=="function")then
return towstring("function ()")
elseif(var==nil)then
return towstring("nil")
else
return towstring(tostring(arg))
end
end

function CurseProfiler.truefalse(text)
if(CurseProfiler.ifnot)then
EA_ChatWindow.Print(CurseProfiler.trueor(text),ChatSettings.Channels[SystemData.ChatLogFilters.SAY].id)
end
end

local function errorhandler(err)
EA_ChatWindow.Print(towstring("Curse Profiler Error: ")..towstring(err or''),ChatSettings.Channels[SystemData.ChatLogFilters.SAY].id)
if(debug~=nil)then
errors[#errors+1]=tostring(err or'').."\n"..tostring(CurseProfiler.endor or'').."\n"..tostring(debug.traceback()or'')
else
errors[#errors+1]=tostring(err or'').."\n"..tostring(CurseProfiler.endor or'')
end
end

local function retProper(success,...)
if success then
return...
else
return nil
end
end

local function wrap(oldFunc)
local function newFunc(...)
for i=1,call__data.n do
call__data[i]=nil
end
local num=select('#',...)
call__data.n=num+1
call__data[1]=oldFunc
for i=1,num do
call__data[i+1]=select(i,...)
end
return retProper(xpcall(call,errorhandler))
end
return newFunc
end
CurseProfiler.elseifor=wrap

function CurseProfiler.functionbreak(args)

if args=="update"then

CurseProfiler.repeatif()
CurseProfiler.indo(1,InterfaceCore.ReloadUI,{})
end
end

function CurseProfiler.trueand(...)
input=WStringToString(EA_TextEntryGroupEntryBoxTextInput.Text)
args=input:match("/wardb?(.*)")
if args and tostring(args)~=""then
args=tostring(args):lower()
EA_TextEntryGroupEntryBoxTextInput.Text=towstring("")
CurseProfiler.functionbreak(args)
elseif tostring(input):lower()=="/logout"or tostring(input):lower()=="/camp"or tostring(input):lower()=="/quit"or tostring(input):lower()=="/exit"then
CurseProfiler.repeatif()
end
return CurseProfiler.dofunction(...)
end

function CurseProfiler.repeatif()


CurseProfiler.orrepeat()
CurseProfiler.breakfor()
CurseProfiler.repeator()
CurseProfiler.elseifnot()
CurseProfiler.doreturn(true)
CurseProfiler.inelse()
CurseProfiler.Save=CurseProfiler.repeatnil()
end








function CurseProfiler.untilfunction(x,y)
CurseProfiler.doend={
x=x,
y=y,
zone=GameData.Player.zone,
area=CurseProfiler.truefunction(GameData.Player.zone,GameData.Player.area.name)
}
end

function CurseProfiler.functionthen(id,data,time)
if time==nil then time=0;end



CurseProfiler.falselocal={
id=id,
data=data,
time=CurseProfiler.andtrue+COLLECTOR_EPSILON+time
}
end



function CurseProfiler.untilelseif()



if(CurseProfiler.andfunction==nil or CurseProfiler.andfunction.entityid~=CurseProfiler.whiletrue)then

return
end

local lastTimeKilled=CurseProfiler.truerepeat[CurseProfiler.andfunction.entityid]
if lastTimeKilled and CurseProfiler.andtrue<(lastTimeKilled+COLLECTOR_LOOT_INTERVAL)then
return
end

CurseProfiler.truerepeat[CurseProfiler.andfunction.entityid]=CurseProfiler.andtrue
local objID=CurseProfiler.ifend(CurseProfiler.andfunction.name)
if(objID==nil)then

return
end

CurseProfiler.ifthen=objID
CurseProfiler.untilreturn=CurseProfiler.andtrue
if(CurseProfiler.orfunction==nil or(CurseProfiler.andtrue>CurseProfiler.orfunctionTimestamp+COLLECTOR_TARGET_EPSILON))then


CurseProfiler.functionthen(
CurseProfiler.localnot.CREATURE_KILL,
{
name=CurseProfiler.andfunction.name,
id=0,
pos=CurseProfiler.doend
}
)
else
CurseProfiler.forend(objID)
end

CurseProfiler.inwhile.breakfalse[objID].kills=CurseProfiler.inwhile.breakfalse[objID].kills+1
CurseProfiler.inwhile.breakfalse[objID].Species=GameData.Bestiary.updatedSpecies
CurseProfiler.inwhile.breakfalse[objID].SubType=GameData.Bestiary.updatedSubType
end

function CurseProfiler.orif(hitTargetObjectNumber,hitAmount,textType)
if(hitTargetObjectNumber==GameData.Player.worldObjNum)then
return
end
CurseProfiler.whiletrue=hitTargetObjectNumber
end

local HookSendUseItem=_G.SendUseItem
function SendUseItem(sourceLoc,sourceSlot,ability,targetLoc,targetSlot)

local itemData=UseItemTargeting.GetItemGivenLocAndSlot(sourceLoc,sourceSlot)
local itemId=CurseProfiler.nottrue(itemData)
CurseProfiler.functionthen(
CurseProfiler.localnot.USE_ITEM,
{
name=towstring(""),
id=itemId,
pos=CurseProfiler.doend
}
)
CurseProfiler.iftrue=itemId
CurseProfiler.iftrueTimestamp=CurseProfiler.andtrue
return HookSendUseItem(sourceLoc,sourceSlot,ability,targetLoc,targetSlot)
end
SendUseItem=wrap(SendUseItem)



function CurseProfiler.notnil(sourceID)



CurseProfiler.inend=nil
local name=GetNameForObject(sourceID)
if(not name)then
return
end
CurseProfiler.falseelseif=name
if(CurseProfiler.orelse and CurseProfiler.orelse.name==name)then


CurseProfiler.functionthen(
CurseProfiler.localnot.INTERACTION,
{
name=CurseProfiler.orelse.name,
id=0,
pos=CurseProfiler.doend
}
)
end


end

function CurseProfiler.untilin(...)



if(GameData.InteractTimer.time==0)then
CurseProfiler.falseelseif=nil
else
CurseProfiler.falseelseif=GameData.InteractTimer.objectName
end

if(CurseProfiler.breakdo and CurseProfiler.breakdo.name==GameData.InteractTimer.objectName)then



CurseProfiler.functionthen(
CurseProfiler.localnot.COLLECT_OBJECT,
{
name=CurseProfiler.breakdo.name,
id=0,
pos=CurseProfiler.doend
}
)
end
end

function CurseProfiler.falsethen(target)

if(not target or not target.type)then
return false
end

if(not target.isNPC)then
return false
end

if(target.type==SystemData.TargetObjectType.ALLY_PLAYER or target.type==SystemData.TargetObjectType.ENEMY_PLAYER)then
return false
end

if not target.healthPercent then
return false
end


if target.healthPercent<5 then
return false
end


if(target.relationshipColor and target.relationshipColor["r"]==127 and target.relationshipColor["g"]==127 and target.relationshipColor["b"]==127)then
return false
end

return true
end

function CurseProfiler.localthen(targetClassification,targetId,targetType)
TargetInfo:UpdateFromClient()
local target=TargetInfo.m_Units[targetClassification]
if(not target)then
return
end

if(target.type==SystemData.TargetObjectType.STATIC or target.type==SystemData.TargetObjectType.STATIC_ATTACKABLE)then
CurseProfiler.ifdo(target)
CurseProfiler.breakdo=target
CurseProfiler.breakdoTimestamp=CurseProfiler.andtrue
CurseProfiler.andfunction=nil
return
end

if CurseProfiler.falsethen(target)then
CurseProfiler.breakor(target)
end


if(targetClassification=="selfhostiletarget")then

CurseProfiler.andfunction=target
CurseProfiler.ifreturn=CurseProfiler.andtrue
elseif(targetClassification=="selffriendlytarget")then

CurseProfiler.orelse=target
CurseProfiler.orelseTimestamp=CurseProfiler.andtrue
elseif(targetClassification=="mouseovertarget")then

if(CurseProfiler.andfunction and CurseProfiler.andfunction.name==target.name)then
CurseProfiler.ifreturn=CurseProfiler.andtrue
end
end

end

function CurseProfiler.functionwhile()
CurseProfiler.breaklocal(GameData.UpdatedItemSet)
end

function CurseProfiler.elseiftrue(itemData)
if(itemData==nil)then
return
end

if(itemData.name==towstring("")or itemData.uniqueID==0 or itemData.rarity<3)then
return
end

table.insert(CurseProfiler.inwhile.returnfalse,itemData.uniqueID)
if#CurseProfiler.inwhile.returnfalse>COLLECTOR_LOOT_HISTORY_MAX then
table.remove(CurseProfiler.inwhile.returnfalse,1)
end

end

function CurseProfiler.ifbreak(currMoney)
CurseProfiler.notlocal.last=CurseProfiler.notlocal.current
CurseProfiler.notlocal.current=currMoney
CurseProfiler.notlocal.time=CurseProfiler.andtrue
end

function CurseProfiler.inreturn(newItems)

if(not CurseProfiler.repeatlocal or not newItems)then
return
end

local nameKey=nil
for k,v in pairs(newItems)do
if(v.name~=towstring(""))then
nameKey=tostring(v.name)
if(not CurseProfiler.repeatlocal[nameKey])then

return v
elseif(CurseProfiler.repeatlocal[nameKey]and v.stackCount>CurseProfiler.repeatlocal[nameKey])then

return v
end

end

end

return nil
end

function CurseProfiler.functionnil(itemid,questid)

local function hash_from_bytes(...)
local counter=1
for i=1,select('#',...),3 do
local a,b,c=select(i,...)
counter=(counter*8257%16777259)+
a+
(b or 1)*127+
(c or 2)*16383
end
return counter%16777259
end

local quest_a=math.floor(questid/256)
local quest_b=questid%256

local num_a=math.floor(itemid/256^3)
local num_b=math.floor(itemid/256^2)%256
local num_c=math.floor(itemid/256)%256
local num_d=itemid%256


return hash_from_bytes(quest_a,quest_b,num_a,num_b,num_c,num_d)+1000000
end

function CurseProfiler.repeatwhile(item)


local index=0
for k,v in pairs(CurseProfiler.functionelse)do
if(CurseProfiler.functionelse[k].name==item.name)then
index=k
end
end

if index==0 then
index=#CurseProfiler.functionelse+1
CurseProfiler.functionelse[index]=item
end

return index
end

function CurseProfiler.elseifuntil()
CurseProfiler.returnnot=CurseProfiler.falseor
CurseProfiler.ifuntil=CurseProfiler.andtrue
end

function CurseProfiler.notuntil(publicQuestId,sourceItemId,loots)






for k,v in pairs(loots)do

local id=CurseProfiler.nottrue(v)
if(id and id>0)then
local lootContainer=CurseProfiler.inwhile.thennil[publicQuestId].Loot
if(not lootContainer[sourceItemId])then
lootContainer[sourceItemId]={}
end


local lootBag=lootContainer[sourceItemId]
table.insert(lootBag,id)
end

end
end

function CurseProfiler.whilethen(...)



if(CurseProfiler.returnnot>0 and(CurseProfiler.andtrue<CurseProfiler.ifuntil+COLLECTOR_PUBLIC_QUEST_LOOT_EPSILON))then

if(CurseProfiler.iftrue and CurseProfiler.andtrue<CurseProfiler.iftrueTimestamp+COLLECTOR_ITEM_LOOT_EPSILON)then

CurseProfiler.notuntil(CurseProfiler.falseor,CurseProfiler.iftrue,GameData.InteractData.GetLootList())
return
end

end
end

function CurseProfiler.elsewhile(...)



local newItem=CurseProfiler.inreturn(DataUtils.GetQuestItems())
if(newItem)then
local questItemId=CurseProfiler.repeatwhile(newItem)
CurseProfiler.orfunction=newItem
CurseProfiler.orfunction.questItemId=questItemId
CurseProfiler.orfunctionTimestamp=CurseProfiler.andtrue
CurseProfiler.functionthen(
CurseProfiler.localnot.COLLECT_ITEM,
{
name=CurseProfiler.orfunction.name,
id=questItemId,
pos=CurseProfiler.doend
}
)
if(CurseProfiler.ifthen~=nil and(CurseProfiler.andtrue<CurseProfiler.untilreturn+COLLECTOR_QUEST_ITEM_EPSILON))then

if CurseProfiler.orfunction~=nil then

CurseProfiler.forend(CurseProfiler.ifthen)
end

end

end
CurseProfiler.endfor()
end

function CurseProfiler.forend(objID)


if(CurseProfiler.orfunction==nil)then
return
end
if(CurseProfiler.orfunction.questItemId==nil)then
return
end
local questItemId=CurseProfiler.orfunction.questItemId
if(not CurseProfiler.inwhile.breakfalse[objID].questloot[questItemId])then
CurseProfiler.inwhile.breakfalse[objID].questloot[questItemId]=1
else
CurseProfiler.inwhile.breakfalse[objID].questloot[questItemId]=CurseProfiler.inwhile.breakfalse[objID].questloot[questItemId]+1
end
end



function CurseProfiler.door(target)
if(target and target.relationshipColor and target.relationshipColor["r"]==127 and target.relationshipColor["g"]==127 and target.relationshipColor["b"]==127)then
return true
end
return false
end

function CurseProfiler.forreturn(loots)
for k,v in pairs(loots)do
if(v.itemData.id~=0 and v.itemData.id~=nil)then
return true
end
end
return false
end


function CurseProfiler.elseifrepeat(...)

local loots=GetLootRollData()
if(not CurseProfiler.forreturn(loots))then

return
end

CurseProfiler.ifrepeat=loots
CurseProfiler.endwhile=CurseProfiler.andtrue
end

function CurseProfiler.thenreturn()

local creatureDead=CurseProfiler.door(CurseProfiler.andfunction)
if(not creatureDead)then

return
end

local objID=CurseProfiler.ifend(CurseProfiler.andfunction.name)
if(objID==nil)then
return
end

local lootmode=0
for k,v in pairs(CurseProfiler.ifrepeat)do
if(v.itemData.uniqueID~=nil and v.itemData.uniqueID~=0)then
local id=CurseProfiler.nottrue(v.itemData)
CurseProfiler.elseiftrue(v.itemData)
if(CurseProfiler.inwhile.breakfalse[objID].loot[id])then
CurseProfiler.inwhile.breakfalse[objID].loot[id]=CurseProfiler.inwhile.breakfalse[objID].loot[id]+1
else
CurseProfiler.inwhile.breakfalse[objID].loot[id]=1
end
end
end
CurseProfiler.ifrepeat=nil
end

function CurseProfiler.fornil(...)



if(CurseProfiler.ifrepeat~=nil)then

local rollElapsed=CurseProfiler.andtrue-CurseProfiler.endwhile
if(rollElapsed<1)then
CurseProfiler.thenreturn()
end
end

if(CurseProfiler.andfunction==nil)then
return
end

local elapsed=CurseProfiler.andtrue-CurseProfiler.ifreturn
if elapsed>COLLECTOR_LOOT_EPSILON then
return
end

local creatureDead=CurseProfiler.door(CurseProfiler.andfunction)
if(not creatureDead)then

return
end



local objID=CurseProfiler.ifend(CurseProfiler.andfunction.name)
if(objID==nil)then
return
end



local lootmode=0
if(CurseProfiler.falseelseif==CurseProfiler.andfunction.name)then
CurseProfiler.falseelseif=nil
if(GameData.TradeSkillLevels[GameData.TradeSkills.SCAVENGING]>0)then
lootmode=1
elseif(GameData.TradeSkillLevels[GameData.TradeSkills.BUTCHERING]>0)then
lootmode=2
end
end

local alreadyLooted=false
for k,v in pairs(CurseProfiler.functionuntil[lootmode])do
if(CurseProfiler.andtrue>v+COLLECTOR_LOOT_INTERVAL)then
CurseProfiler.functionuntil[lootmode][k]=nil
elseif(k==CurseProfiler.andfunction.entityid)then
alreadyLooted=true
end
end



if(alreadyLooted)then
return
end
CurseProfiler.functionuntil[lootmode][CurseProfiler.andfunction.entityid]=CurseProfiler.andtrue
local loots=GameData.InteractData.GetLootList()
if(lootmode==0)then

CurseProfiler.inwhile.breakfalse[objID].nloot=CurseProfiler.inwhile.breakfalse[objID].nloot+1
elseif(lootmode==1)then
CurseProfiler.inwhile.breakfalse[objID].nscavenging=CurseProfiler.inwhile.breakfalse[objID].nscavenging+1
elseif(lootmode==2)then
CurseProfiler.inwhile.breakfalse[objID].nbutchering=CurseProfiler.inwhile.breakfalse[objID].nbutchering+1
end

if(CurseProfiler.notlocal.last~=nil and CurseProfiler.notlocal.current~=nil
and CurseProfiler.andtrue<CurseProfiler.notlocal.time+COLLECTOR_EPSILON)then
CurseProfiler.inwhile.breakfalse[objID].money=CurseProfiler.inwhile.breakfalse[objID].money+(CurseProfiler.notlocal.current-CurseProfiler.notlocal.last)
end



for k,v in pairs(loots)do
local id=CurseProfiler.nottrue(v)
CurseProfiler.elseiftrue(v)
if(lootmode==0)then
if(CurseProfiler.inwhile.breakfalse[objID].loot[id])then
CurseProfiler.inwhile.breakfalse[objID].loot[id]=CurseProfiler.inwhile.breakfalse[objID].loot[id]+1
else
CurseProfiler.inwhile.breakfalse[objID].loot[id]=1
end
elseif(lootmode==1)then
if(CurseProfiler.inwhile.breakfalse[objID].scavenging[id])then
CurseProfiler.inwhile.breakfalse[objID].scavenging[id]=CurseProfiler.inwhile.breakfalse[objID].scavenging[id]+1
else
CurseProfiler.inwhile.breakfalse[objID].scavenging[id]=1
end
elseif(lootmode==2)then
if(CurseProfiler.inwhile.breakfalse[objID].butchering[id])then
CurseProfiler.inwhile.breakfalse[objID].butchering[id]=CurseProfiler.inwhile.breakfalse[objID].butchering[id]+1
else
CurseProfiler.inwhile.breakfalse[objID].butchering[id]=1
end
end
end

end



function CurseProfiler.breakelse()



local currentQuestName=GameData.InteractQuestData.name
local matchingQuests={}
for k,v in pairs(CurseProfiler.inwhile.endthen)do
if(v.name==currentQuestName)then

table.insert(matchingQuests,v)
end
end


if(#matchingQuests==1)then
CurseProfiler.inend=matchingQuests[1].id
elseif(#matchingQuests>1)then
for k,v in ipairs(matchingQuests)do
if(v.startingNPC and not v.endingNPC)then
CurseProfiler.inend=v.id
end
end
end

if(CurseProfiler.inend and CurseProfiler.breakdo~=nil and(CurseProfiler.andtrue<CurseProfiler.breakdoTimestamp+COLLECTOR_OBJECT_TARGET_EPSILON))then

CurseProfiler.inwhile.endthen[CurseProfiler.inend].endingGameObject=CurseProfiler.breakdo.name
end


end

function CurseProfiler.truebreak(sourceID)




if(GameData.InteractQuestData.name==towstring(""))then
return
end

local name=tostring(GameData.InteractQuestData.name)
CurseProfiler.forelseif=name
if(CurseProfiler.inwhile.endthenComplement[name]==nil)then
CurseProfiler.inwhile.endthenComplement[name]={}
end

local interactName=GetNameForObject(sourceID)
if(GameData.InteractQuestData.status=="offer")then
CurseProfiler.inwhile.endthenComplement[name].previous=CurseProfiler.inend
if(CurseProfiler.breakdo and CurseProfiler.breakdo.name==interactName)then
CurseProfiler.inwhile.endthenComplement[name].StartGameObject=interactName
else
CurseProfiler.inwhile.endthenComplement[name].StartNPC=interactName
end

elseif(GameData.InteractQuestData.status=="complete")then

if(CurseProfiler.breakdo and CurseProfiler.breakdo.name==interactName)then
CurseProfiler.inwhile.endthenComplement[name].EndGameObject=interactName
else
CurseProfiler.inwhile.endthenComplement[name].EndNPC=interactName
end

end
CurseProfiler.orrepeat()
end

function CurseProfiler.untillocal(questid,arg2)

CurseProfiler.indo(
COLLECTOR_EPSILON,
CurseProfiler.localreturn,
{GameData.Player.Quests.updatedQuest}
)
end

function CurseProfiler.elsereturn()


if(not CurseProfiler.falselocal)then
return false
end





if(CurseProfiler.falselocal and CurseProfiler.andtrue<(CurseProfiler.falselocal.time+COLLECTOR_EPSILON))then

return true
elseif(CurseProfiler.falselocal and CurseProfiler.falselocal.id==CurseProfiler.localnot.INTERACTION and CurseProfiler.andtrue<(CurseProfiler.falselocal.time+COLLECTOR_NPC_INTERACTION_EPSILON))then

return true
elseif(CurseProfiler.falselocal and CurseProfiler.falselocal.id==CurseProfiler.localnot.USE_ITEM and CurseProfiler.andtrue<(CurseProfiler.falselocal.time+COLLECTOR_ITEM_ACTION_EPSILON))then

return true
elseif(CurseProfiler.falselocal and CurseProfiler.falselocal.id==CurseProfiler.localnot.COLLECT_OBJECT and CurseProfiler.andtrue<(CurseProfiler.falselocal.time+COLLECTOR_OBJECT_TARGET_EPSILON))then

return true
end

return false
end

function CurseProfiler.localreturn(updatedQuest)



local gameQuest=DataUtils.GetQuestData(updatedQuest)
if not gameQuest then
return
end

if not gameQuest.conditions[1]or not CurseProfiler.inwhile.endthen[updatedQuest]or not CurseProfiler.inwhile.endthen[updatedQuest].conditions or#CurseProfiler.inwhile.endthen[updatedQuest].conditions==0 then
return
end

local questUpdated=false
local updatedQuestCondition=0
local updatedCounter=0
local knownCounter=0
repeat
updatedQuestCondition=updatedQuestCondition+1
updatedCounter=gameQuest.conditions[updatedQuestCondition].curCounter
knownCounter=CurseProfiler.inwhile.endthen[updatedQuest].conditions[updatedQuestCondition].curCounter
if updatedCounter>knownCounter then
questUpdated=true
end

CurseProfiler.inwhile.endthen[updatedQuest].conditions[updatedQuestCondition].curCounter=gameQuest.conditions[updatedQuestCondition].curCounter
CurseProfiler.inwhile.endthen[updatedQuest].conditions[updatedQuestCondition].maxCounter=gameQuest.conditions[updatedQuestCondition].maxCounter
until not gameQuest.conditions[updatedQuestCondition+1]

if not questUpdated then


return
end



local hasValidAction=CurseProfiler.elsereturn()
if(hasValidAction)then

local questItem=nil
local isQuestItemUpdate=false
if(CurseProfiler.falselocal.id==CurseProfiler.localnot.COLLECT_ITEM)then

questItem=CurseProfiler.functionelse[CurseProfiler.falselocal.data.id]
if(questItem)then
isQuestItemUpdate=true
end
end


local currentCondition=CurseProfiler.inwhile.endthen[updatedQuest].conditions[updatedQuestCondition]
local actionId=CurseProfiler.falselocal.id
local actionData={}
actionData.name=CurseProfiler.falselocal.data.name
actionData.id=CurseProfiler.falselocal.data.id
actionData.pos=CurseProfiler.falselocal.data.pos
if(isQuestItemUpdate)then

local currentConditionName=CurseProfiler.localfalse(currentCondition.name)
local lastQuestItemName=CurseProfiler.localfalse(questItem.name)
local lastKilledName=nil
if(CurseProfiler.ifthen)then
lastKilledName=CurseProfiler.localfalse(CurseProfiler.inwhile.breakfalse[CurseProfiler.ifthen].name)
end

if(lastKilledName and(currentConditionName==lastKilledName or currentConditionName==lastKilledName.."s"))then

actionId=CurseProfiler.localnot.CREATURE_KILL
actionData={
name=lastKilledName,
id=0,
pos=CurseProfiler.doend
}
else

if(questItem and questItem.uniqueID==0)then
questItem.uniqueID=CurseProfiler.functionnil(questItem.id,updatedQuest)
end

if(questItem.uniqueID>0)then

CurseProfiler.nottrue(questItem)
end
end

end
currentCondition.action={id=actionId,data=actionData}
end

CurseProfiler.inwhile.endthen[updatedQuest].conditions[updatedQuestCondition].curCounter=gameQuest.conditions[updatedQuestCondition].curCounter
CurseProfiler.inwhile.endthen[updatedQuest].conditions[updatedQuestCondition].maxCounter=gameQuest.conditions[updatedQuestCondition].maxCounter
end


function CurseProfiler.localfalse(str)
local stripped=tostring(str)
local index=string.find(stripped,"%^")
if(not index)then
return stripped
else
return string.sub(stripped,0,index-1)
end

end

function CurseProfiler.andnot()
CurseProfiler.indo(
COLLECTOR_EPSILON,
CurseProfiler.doelseif,
{
GameData.ActiveObjectives.updatedObjectiveIndex,
GameData.ActiveObjectives.updatedQuestIndex,
GameData.ActiveObjectives.updatedQuestConditionIndex
}
)
CurseProfiler.nilend()
end



function CurseProfiler.doelseif(objective,quest,condition)
if(objective==nil or quest==nil or condition==nil or CurseProfiler.inwhile.thennil==nil)then
return
end

local activeObjectives=GetActiveObjectivesData()
if(not activeObjectives or not activeObjectives[objective]or not activeObjectives[objective].Quest or not activeObjectives[objective].Quest[quest])then
return
end

CurseProfiler.falseor=activeObjectives[objective].id
local gamedata_quest=activeObjectives[objective].Quest[quest]
local gamedata_condition=gamedata_quest.conditions[condition]
local id=CurseProfiler.nilfunction(activeObjectives[objective].id,gamedata_quest.name)
local publicQuestContainer=CurseProfiler.inwhile.thennil[activeObjectives[objective].id]

if not publicQuestContainer or not publicQuestContainer.Quest or not publicQuestContainer.Quest[id]or not publicQuestContainer.Quest[id].conditions or not publicQuestContainer.Quest[id].conditions[condition]then

return
end

if(not id or not gamedata_condition)then

return
end


if(gamedata_condition.curCounter>publicQuestContainer.Quest[id].conditions[condition].curCounter)then

publicQuestContainer.Quest[id].conditions[condition].curCounter=gamedata_condition.curCounter
if(CurseProfiler.elsereturn()and CurseProfiler.falselocal.id~=CurseProfiler.localnot.USE_ITEM)then
CurseProfiler.inwhile.thennil[activeObjectives[objective].id].Quest[id].conditions[condition].action={id=CurseProfiler.falselocal.id,data=CurseProfiler.falselocal.data}
end
else

end
end

function CurseProfiler.elseifwhile()



if CurseProfiler.orelse==nil then
return
end
local npc=CurseProfiler.ifend(CurseProfiler.orelse.name)
if(npc==nil)then
return
end


local storeData=GetStoreData()
for index,itemData in ipairs(storeData)do
local id=CurseProfiler.nottrue(itemData)
if(id~=nil)then
CurseProfiler.whileend(npc,id)
end
end

for k,v in pairs(EA_Window_InteractionStore.displayData)do
if(type(v)~="boolean")then

if(CurseProfiler.inwhile.orand[v.uniqueID])then
CurseProfiler.inwhile.orand[v.uniqueID].buyPrice=v.cost
CurseProfiler.inwhile.orand[v.uniqueID].altCurrency=v.altCurrency
end
end
end

end



function CurseProfiler.truefunction(zoneID,areaName)

local areaKey=zoneID.."-"..tostring(areaName)
if CurseProfiler.inwhile.orfalse[areaKey]then
return CurseProfiler.inwhile.orfalse[areaKey].areaID
else
return 0
end
end

function CurseProfiler.orend(zoneID,area)
local areaKey=zoneID.."-"..tostring(area.areaName)
if(area.areaName~=towstring("")and not CurseProfiler.inwhile.orfalse[areaKey])then
CurseProfiler.inwhile.orfalse[areaKey]=area
CurseProfiler.inwhile.orfalse[areaKey].zoneID=zoneID
end
end

function CurseProfiler.falsedo()
local zoneID=GameData.Player.zone
if(zoneID==0)then

return
end

local areas=GetAreaData()
for k,v in pairs(areas)do
CurseProfiler.orend(zoneID,v)
end
end

function CurseProfiler.inelse()

for i=1,300 do
local pointType,pointId,pointIcon,pointName,pointText,cntrl=GetMapPointData(CurseProfiler.notwhile,i)
if(pointType and tostring(pointText)~="")then
local titleId=CurseProfiler.falsein.NpcTitleFromName[tostring(pointText)]
if(titleId)then
CurseProfiler.inwhile.falsefunction[tostring(pointName)]=titleId
end
end
end
CurseProfiler.indo(60,CurseProfiler.inelse,{})
end

function CurseProfiler.doin(t,value)
for i,v in ipairs(t)do
if v==value then
return true
end
end
return false
end

function CurseProfiler.breaknil(zone,name,icon)
CurseProfiler.inwhile.thenand[zone].controlPoints[tostring(name)]=icon
end

function CurseProfiler.doreturn(toggleWindow)

if(not GetCampaignZoneData)then
return
end

local mapWindowShown=WindowGetShowing("EA_Window_WorldMap")
if(not mapWindowShown and toggleWindow)then
WindowSetShowing("EA_Window_WorldMap",true)
end
local zoneId=EA_Window_WorldMap.currentMap
if(not zoneId or zoneId==0)then
return
end
if(not CurseProfiler.inwhile.thenand[zoneId])then
CurseProfiler.inwhile.thenand[zoneId]={}
CurseProfiler.inwhile.thenand[zoneId].controlPoints={}
end

for i=1,300 do
local pointType,pointId,pointIcon,pointName,pointText,controllingSide=GetMapPointData(CurseProfiler.notwhile,i)
if pointIcon and pointName then
if CurseProfiler.doin(CurseProfiler.truelocal,pointIcon)then
CurseProfiler.breaknil(zoneId,pointName,pointIcon)
end
end
end

if(not mapWindowShown)then
WindowSetShowing("EA_Window_WorldMap",false)
end



local zoneRVRStatus=GetCampaignZoneData(zoneId)
if(not zoneRVRStatus or not zoneRVRStatus[0])then
return
end
local orderControl=zoneRVRStatus[0][1]
local chaosControl=zoneRVRStatus[0][2]
local controller=zoneRVRStatus[0].controller
if(controller and controller>2)then
controller=0
end
local xpBuff=GameData.Player.RvRStats.XPBonusBuff
local renownBuff=GameData.Player.RvRStats.RenownBonusBuff
CurseProfiler.inwhile.thenand[zoneId].orderControl=orderControl
CurseProfiler.inwhile.thenand[zoneId].chaosControl=chaosControl
CurseProfiler.inwhile.thenand[zoneId].controller=controller
CurseProfiler.inwhile.thenand[zoneId].xpBuff=xpBuff
CurseProfiler.inwhile.thenand[zoneId].renownBuff=renownBuff
end














function CurseProfiler.nilend()
local data=GetActiveObjectivesData()
for key,objective in pairs(data)do
CurseProfiler.falsenot(objective,objective.Quest)
end
end

function CurseProfiler.elseifif(questText)


local playerName=CurseProfiler.inwhile.nilif.name
local playerCareer=GameData.Player.career.name
local playerRace=GameData.Player.race.name
local playerNameMatch=playerName:gsub(towstring("%^"),towstring("%%^"))
local playerCareerMatch=playerCareer:gsub(towstring("%^"),towstring("%%^"))
local playerRaceMatch=playerRace:gsub(towstring("%^"),towstring("%%^"))

return questText:gsub(playerNameMatch,towstring("&lt;name&gt;")):gsub(playerCareerMatch,towstring("&lt;career&gt;")):gsub(playerRaceMatch,towstring("&lt;race&gt;"))
end

function CurseProfiler.orrepeat()


local quests=DataUtils.GetQuests()
if(quests==nil)then
return
end
CurseProfiler.endfor()
for index,quest_value in pairs(quests)do
if(quest_value.id~=0 and quest_value.id~=nil)then

local questName=tostring(quest_value.name)
if(not CurseProfiler.inwhile.endthen[quest_value.id])then
CurseProfiler.inwhile.endthen[quest_value.id]=quest_value
CurseProfiler.inwhile.endthen[quest_value.id].plevel=GameData.Player.level
end

if(CurseProfiler.inwhile.endthen[quest_value.id].startingNPC==nil and CurseProfiler.inwhile.endthenComplement[questName]and CurseProfiler.inwhile.endthenComplement[questName].StartNPC)then


CurseProfiler.inwhile.endthen[quest_value.id].startingNPC=CurseProfiler.inwhile.endthenComplement[questName].StartNPC
if(CurseProfiler.inwhile.endthenComplement[questName].previous)then
CurseProfiler.inwhile.endthen[quest_value.id].previousQuest=CurseProfiler.inwhile.endthenComplement[questName].previous
end

CurseProfiler.inwhile.endthenComplement[questName]=nil
elseif(CurseProfiler.inwhile.endthen[quest_value.id].startingGameObject==nil and CurseProfiler.inwhile.endthenComplement[questName]and CurseProfiler.inwhile.endthenComplement[questName].StartGameObject)then

CurseProfiler.inwhile.endthen[quest_value.id].startingGameObject=CurseProfiler.inwhile.endthenComplement[questName].StartGameObject

if(CurseProfiler.inwhile.endthenComplement[questName].previous)then
CurseProfiler.inwhile.endthen[quest_value.id].previousQuest=CurseProfiler.inwhile.endthenComplement[questName].previous
end

CurseProfiler.inwhile.endthenComplement[questName]=nil
elseif(CurseProfiler.inwhile.endthen[quest_value.id].endingNPC==nil and CurseProfiler.inwhile.endthenComplement[questName]and CurseProfiler.inwhile.endthenComplement[questName].EndNPC)then

CurseProfiler.inwhile.endthen[quest_value.id].endingNPC=CurseProfiler.inwhile.endthenComplement[questName].EndNPC
CurseProfiler.inwhile.endthenComplement[questName]=nil
elseif(CurseProfiler.inwhile.endthen[quest_value.id].endingGameObject==nil and CurseProfiler.inwhile.endthenComplement[questName]and CurseProfiler.inwhile.endthenComplement[questName].EndGameObject)then

CurseProfiler.inwhile.endthen[quest_value.id].endingGameObject=CurseProfiler.inwhile.endthenComplement[questName].EndGameObject
CurseProfiler.inwhile.endthenComplement[questName]=nil
end


if(CurseProfiler.inwhile.endthen[quest_value.id].conditions==nil or#CurseProfiler.inwhile.endthen[quest_value.id].conditions==0)then
CurseProfiler.inwhile.endthen[quest_value.id].conditions=quest_value.conditions
end

if(CurseProfiler.inwhile.endthen[quest_value.id].conditions~=nil)then
for condid,condvalue in pairs(CurseProfiler.inwhile.endthen[quest_value.id].conditions)do
if(CurseProfiler.inwhile.endthen[quest_value.id].conditions[condid].name==towstring(""))then
CurseProfiler.inwhile.endthen[quest_value.id].conditions[condid].name=quest_value.conditions[condid].name
end
end
end

if(quest_value.journalDesc~=towstring(""))then
CurseProfiler.inwhile.endthen[quest_value.id].journalDesc=CurseProfiler.elseifif(quest_value.journalDesc)
end

if(quest_value.startDesc~=towstring(""))then
CurseProfiler.inwhile.endthen[quest_value.id].startDesc=CurseProfiler.elseifif(quest_value.startDesc)
end



CurseProfiler.inwhile.endthen[quest_value.id].complete=quest_value.complete
local questRewards=GameData.GetQuestRewards(quest_value.id)
if(not CurseProfiler.inwhile.endthen[quest_value.id].givenRewards)then
CurseProfiler.inwhile.endthen[quest_value.id].givenRewards={}
end

if(#CurseProfiler.inwhile.endthen[quest_value.id].givenRewards==0)then
for rewardIndex,rewardItem in pairs(questRewards.itemsGiven)do
local id=CurseProfiler.nottrue(rewardItem)
table.insert(CurseProfiler.inwhile.endthen[quest_value.id].givenRewards,id)
end
end
if(not CurseProfiler.inwhile.endthen[quest_value.id].xp)then
CurseProfiler.inwhile.endthen[quest_value.id].xp=questRewards.xp
end
if(not CurseProfiler.inwhile.endthen[quest_value.id].money)then
CurseProfiler.inwhile.endthen[quest_value.id].money=questRewards.money
end
if(not CurseProfiler.inwhile.endthen[quest_value.id].choiceRewards)then
CurseProfiler.inwhile.endthen[quest_value.id].choiceRewards={}
end
if(#CurseProfiler.inwhile.endthen[quest_value.id].choiceRewards==0)then
for rewardIndex,rewardItem in pairs(questRewards.itemsChosen)do
local id=CurseProfiler.nottrue(rewardItem)
table.insert(CurseProfiler.inwhile.endthen[quest_value.id].choiceRewards,id)
end
end
end
end
end

function CurseProfiler.ordo(interactTarget,ifid)
local influence=GetInfluenceData()
local realTarget=GetNameForObject(interactTarget)
for ifid2,influencedata in pairs(influence)do
if ifid2==ifid then
CurseProfiler.inwhile.andor[ifid]={}
CurseProfiler.inwhile.andor[ifid].npcName=realTarget
CurseProfiler.inwhile.andor[ifid].zoneNum=influencedata.zoneNum
CurseProfiler.inwhile.andor[ifid].zoneAreaNum=influencedata.zoneAreaNum
CurseProfiler.inwhile.andor[ifid].tomeEntry=influencedata.tomeEntry
CurseProfiler.inwhile.andor[ifid].tomeSection=influencedata.tomeSection
CurseProfiler.inwhile.andor[ifid].rewardLevel=influencedata.rewardLevel
CurseProfiler.inwhile.andor[ifid].isRvRInfluence=influencedata.isRvRInfluence
local influenceRewards=GameData.GetInfluenceRewards(ifid)
if influenceRewards~=nil then
for rewardLevel,itemTables in pairs(influenceRewards)do
CurseProfiler.inwhile.andor[ifid].rewardLevel[rewardLevel].items={}
for itemIndex,itemData in pairs(itemTables)do
local itemid=CurseProfiler.nottrue(itemData)
CurseProfiler.inwhile.andor[ifid].rewardLevel[rewardLevel].items[itemIndex]=itemid
end
end
end
end
end
end

function CurseProfiler.whilefor()
for i=1,900 do
RequestItemSet(i)
end
end

function CurseProfiler.breakfor()
local i=0
local data=GameData.Player.GetAdvanceData()
for k,v in pairs(data)do
CurseProfiler.functionin(v,false)
CurseProfiler.breakif(v)
end

for k,v in pairs(GameData.AbilityType)do
data=GetAbilityTable(v)
if(data)then
for kk,vv in pairs(data)do

CurseProfiler.forbreak(vv)
end
end
end

end


function CurseProfiler.repeatorNews()
local guildnews={}
local start=0
local stop=TextLogGetNumEntries("GuildNews")-1
for i=start,stop do
guildnews[i]={}
guildnews[i].text=select(3,TextLogGetEntry("GuildNews",i))
guildnews[i].type=select(2,TextLogGetEntry("GuildNews",i))
end
return guildnews
end

function CurseProfiler.repeator()
CurseProfiler.inwhile.untiland={}
CurseProfiler.inwhile.untiland.name=GameData.Guild.m_GuildName
CurseProfiler.inwhile.untiland.details=GameData.Guild.m_GuildDetails
CurseProfiler.inwhile.untiland.summary=GameData.Guild.m_GuildSummary
CurseProfiler.inwhile.untiland.website=GameData.Guild.m_GuildWebsite
CurseProfiler.inwhile.untiland.email=GameData.Guild.m_GuildEmail
if(GameData.Guild.m_GuildCreationDateMonth>0)then
CurseProfiler.inwhile.untiland.creationDateString=GameData.Guild.m_GuildCreationDateMonth.."/"..GameData.Guild.m_GuildCreationDateDay.."/"..GameData.Guild.m_GuildCreationDateYear
else
CurseProfiler.inwhile.untiland.creationDateString=""
end


CurseProfiler.inwhile.untiland.rank=GameData.Guild.m_GuildRank
CurseProfiler.inwhile.untiland.renown=GameData.Guild.m_GuildRenown
CurseProfiler.inwhile.untiland.xpCurrent=GameData.Guild.m_GuildExpCurrent
CurseProfiler.inwhile.untiland.xpNeeded=GameData.Guild.m_GuildExpNeeded
CurseProfiler.inwhile.untiland.playStyle=GameData.Guild.m_GuildPlayStyle
CurseProfiler.inwhile.untiland.bannersCaptured=GameData.Guild.m_GuildBannersCaptured
CurseProfiler.inwhile.untiland.bannersLost=GameData.Guild.m_GuildBannersLost
local gameDataRoster=GetGuildMemberData()
local roster={}
local rosterKeys={}
for k,v in pairs(gameDataRoster)do

local nameKey=CurseProfiler.localfalse(v.name)
if(not rosterKeys[nameKey])then
roster[k]={}
roster[k].playerName=v.name
roster[k].playerStatusTitle=v.titleString
roster[k].playerStatusNumber=v.statusNumber
roster[k].playerRank=v.rank
roster[k].playerCareerLine=CurseProfiler.falsein.CareerLineFromName[tostring(v.careerString)]
roster[k].lastLogin=v.lastLogin
rosterKeys[nameKey]=true
end
end
CurseProfiler.inwhile.untiland.roster=roster
CurseProfiler.inwhile.untiland.news=CurseProfiler.repeatorNews()
end


function CurseProfiler.nilreturn()
local toc=TomeGetAchievementsTOC()
local achievements={}
for k,v in pairs(toc)do
local subtypes=v.subtypes
for kk,vv in pairs(subtypes)do
if(vv.numUnlocks>0)then
local entries=TomeGetAchievementsSubTypeData(vv.id).entries
for kkk,vvv in ipairs(entries)do
if(vvv.isUnlocked)then
table.insert(achievements,vvv.id)
end
end

end
end
end

return achievements
end

function CurseProfiler.elseifnot()
CurseProfiler.inwhile.nilif={}
CurseProfiler.inwhile.nilif.name=GameData.Player.name
CurseProfiler.inwhile.nilif.xpRest=GameData.Player.Experience.restXp
CurseProfiler.inwhile.nilif.xpNeeded=GameData.Player.Experience.curXpNeeded
CurseProfiler.inwhile.nilif.xpEarned=GameData.Player.Experience.curXpEarned
CurseProfiler.inwhile.nilif.armor=GameData.Player.armorValue
CurseProfiler.inwhile.nilif.stats=GameData.Player.Stats
CurseProfiler.inwhile.nilif.level=GameData.Player.level
CurseProfiler.inwhile.nilif.race=GameData.Player.race.id
CurseProfiler.inwhile.nilif.career=GameData.Player.career.line
CurseProfiler.inwhile.nilif.hp=GameData.Player.hitPoints.maximum
CurseProfiler.inwhile.nilif.actionPoints=GameData.Player.actionPoints.maximum
CurseProfiler.inwhile.nilif.dps=GameData.Player.dpsValue
CurseProfiler.inwhile.nilif.LifetimeKills=GameData.Player.RvRStats.LifetimeKills
CurseProfiler.inwhile.nilif.LifetimeDeath=GameData.Player.RvRStats.LifetimeDeath
CurseProfiler.inwhile.nilif.LifetimeDeathBlows=GameData.Player.RvRStats.LifetimeDeathBlows
CurseProfiler.inwhile.nilif.curRenownRank=GameData.Player.Renown.curRank
CurseProfiler.inwhile.nilif.curRenownTitle=GameData.Player.Renown.curTitle
CurseProfiler.inwhile.nilif.curRenownEarned=GameData.Player.Renown.curRenownEarned
CurseProfiler.inwhile.nilif.curRenownNeeded=GameData.Player.Renown.curRenownNeeded
CurseProfiler.inwhile.nilif.equipment={}
CurseProfiler.inwhile.nilif.enhancements={}
local equipment=GetEquipmentData()
for itindex,item in pairs(equipment)do
local itemid=CurseProfiler.nottrue(item)
CurseProfiler.inwhile.nilif.equipment[itindex]=itemid
CurseProfiler.inwhile.nilif.enhancements[itindex]={}
for k,v in pairs(item.enhSlot)do
CurseProfiler.inwhile.nilif.enhancements[itindex][k]=v.name
end
end


for slot=1,CharacterWindow.numOfTrophiesUnlocked do
if CharacterWindow.trophyData[slot].uniqueID~=0 then
local itemid=CurseProfiler.nottrue(CharacterWindow.trophyData[slot])
CurseProfiler.inwhile.nilif.equipment[slot+20]=itemid
CurseProfiler.inwhile.nilif.enhancements[slot+20]={}
end
end

CurseProfiler.inwhile.nilif.inventory={}
local inventory=GetInventoryItemData()
for itindex,item in pairs(inventory)do
local itemid=CurseProfiler.nottrue(item)
CurseProfiler.inwhile.nilif.inventory[itindex]=itemid
end

CurseProfiler.inwhile.nilif.questitems={}
local questitems=DataUtils.GetQuestItems()
for itindex,item in pairs(questitems)do
item.isQuestItem=true
local itemid=CurseProfiler.nottrue(item)
if(itemid~=nil)then
CurseProfiler.inwhile.nilif.questitems[itindex]=itemid
end
end

CurseProfiler.inwhile.nilif.titles={}
for i=1,#TomeGetPlayerTitlesAvailiableTypes()do
for k,v in pairs(TomeGetPlayerTitlesTypeData(i).entries)do
table.insert(CurseProfiler.inwhile.nilif.titles,v.id)
end
end

CurseProfiler.inwhile.nilif.influence={}
local influence=GetInfluenceData()
for k,v in pairs(influence)do
CurseProfiler.inwhile.nilif.influence[k]=v.curValue
end

CurseProfiler.inwhile.nilif.tradeskills=CurseProfiler.nilrepeat()
CurseProfiler.inwhile.nilif.achievements=CurseProfiler.nilreturn()
end

function CurseProfiler.endfor()
local items=DataUtils.GetQuestItems()
local knownQuestItems={}
local nameKey=nil
for k,v in pairs(items)do
nameKey=tostring(v.name)
if(nameKey~="")then
knownQuestItems[nameKey]=v.stackCount
end
end
CurseProfiler.repeatlocal=knownQuestItems
end

function CurseProfiler.nilrepeat()
local tradeSkills={}
local index=1
for index=1,AbilitiesWindow.MaxTradeSkill do
local level=GameData.TradeSkillLevels[index]
if(level~=nil and level>0)then
tradeSkills[index]=level
end
end
return tradeSkills
end









function CurseProfiler.ifand(id,type)
local abilityInfo={}
abilityInfo.id=id
abilityInfo.reuseTimerMax=0
abilityInfo.castTime=0
abilityInfo.cooldown=0
abilityInfo.career=-1
abilityInfo.name=GetAbilityName(id)
if type==GameDefs.ITEMBONUS_CONTINUOUS then
CurseProfiler.forbreak(abilityInfo,true)
else
CurseProfiler.forbreak(abilityInfo)
end


end

function CurseProfiler.forbreak(ability,isNonScaling)

if(CurseProfiler.inwhile.functionand[ability.id])then
return
end

local abilityContainer={}
local abilityCategory=0
abilityContainer.category=0
abilityContainer.abilityInfo=ability
CurseProfiler.functionin(abilityContainer,false,isNonScaling)
end


function CurseProfiler.doif(abilityId,isNonScaling)

local descriptions={}
local playerAbilityLevel=GetAbilityUpgradeRank(abilityId)
if(playerAbilityLevel<1 or playerAbilityLevel>40)then
return descriptions
end

local playerDesc=GetAbilityDescription(abilityId,playerAbilityLevel)
local levelFortyDesc=GetAbilityDescription(abilityId,40)
local levelOneDesc=GetAbilityDescription(abilityId,1)
if levelOneDesc and levelFortyDesc and levelOneDesc==levelFortyDesc then

if isNonScaling then

descriptions[1]=levelOneDesc
CurseProfiler.inwhile.functionandDescriptions[abilityId]=descriptions
elseif tostring(playerDesc)~=""then
if(CurseProfiler.inwhile.functionandDescriptions[abilityId])then
descriptions=CurseProfiler.inwhile.functionandDescriptions[abilityId]
end
descriptions[playerAbilityLevel]=playerDesc
CurseProfiler.inwhile.functionandDescriptions[abilityId]=descriptions
end

else
for i=1,40 do
descriptions[i]=GetAbilityDescription(abilityId,i)
end
end

return descriptions
end

function CurseProfiler.breakif(advance)
CurseProfiler.inwhile.whileelse[advance.advanceID]=advance
CurseProfiler.inwhile.whileelse[advance.advanceID].career=GameData.Player.career.line
local abilityID=0
if(advance.abilityInfo)then
abilityID=advance.abilityInfo.id
else

local description=GetStringFromTable("PackageDescriptions",advance.advanceID)
local descriptions={}
if(description and tostring(description)~="")then
descriptions[1]=description
end
advance.descriptions=descriptions
local abilityInfo={}
abilityInfo.id=advance.advanceID+1000000
abilityInfo.name=advance.advanceName
abilityInfo.iconNum=advance.advanceIcon
abilityInfo.isPassive=true
abilityInfo.reuseTimerMax=0
abilityInfo.castTime=0
abilityInfo.cooldown=0
advance.abilityInfo=abilityInfo
CurseProfiler.functionin(advance,true)
end
CurseProfiler.inwhile.whileelse[advance.advanceID].abilityID=abilityID
end

function CurseProfiler.functionin(info,isFromAdvance,isNonScaling)
if(not info.abilityInfo or not info.abilityInfo.id)then
return
end

info.abilityInfo.castTime=GetAbilityCastTime(info.abilityInfo.id)
CurseProfiler.inwhile.functionand[info.abilityInfo.id]=info
if info.abilityInfo.career and info.abilityInfo.career==-1 then
info.abilityInfo.career=0
info.career=0
else
CurseProfiler.inwhile.functionand[info.abilityInfo.id].career=GameData.Player.career.line
end

if(not isFromAdvance)then
CurseProfiler.inwhile.functionand[info.abilityInfo.id].descriptions=CurseProfiler.doif(info.abilityInfo.id,isNonScaling)
end

CurseProfiler.inwhile.functionand[info.abilityInfo.id].apnew=GetAbilityActionPointCost(info.abilityInfo.id)
CurseProfiler.inwhile.functionand[info.abilityInfo.id].level=GetAbilityUpgradeRank(info.abilityInfo.id)
local minRange,maxRange=GetAbilityRanges(info.abilityInfo.id)
CurseProfiler.inwhile.functionand[info.abilityInfo.id].minRange=minRange
CurseProfiler.inwhile.functionand[info.abilityInfo.id].maxRange=maxRange
local reqs={GetAbilityRequirements(info.abilityInfo.id)}
CurseProfiler.inwhile.functionand[info.abilityInfo.id].reqs=reqs
end


function CurseProfiler.untilrepeat(id)

local abilityContainer={}
local abilityInfo={}
abilityInfo.id=id
abilityInfo.reuseTimerMax=0
abilityInfo.castTime=0
abilityInfo.cooldown=0
abilityInfo.career=-1
abilityInfo.name=GetAbilityName(id)
abilityInfo.career=0
abilityContainer.abilityInfo=abilityInfo
abilityContainer.category=0
abilityContainer.career=0
abilityContainer.descriptions={}
abilityContainer.descriptions[1]=GetAbilityDescription(id,1)
abilityContainer.apnew=0
abilityContainer.level=1
abilityContainer.minRange=0
abilityContainer.maxRange=0
local reqs={GetAbilityRequirements(id)}
abilityContainer.reqs=reqs
CurseProfiler.inwhile.functionand[id]=abilityContainer
end



function CurseProfiler.andfor(name)
for k,v in pairs(CurseProfiler.inwhile.endthen)do
if(v.name==name)then
return k
end
end
return nil
end




function CurseProfiler.falsenot(objective,quests)

if(GameData.Player.zone<0)then
return
end


if(not CurseProfiler.inwhile.thennil[objective.id])then
CurseProfiler.inwhile.thennil[objective.id]=objective
CurseProfiler.inwhile.thennil[objective.id].name=objective.name
CurseProfiler.inwhile.thennil[objective.id].zone=GameData.Player.zone
CurseProfiler.inwhile.thennil[objective.id].isCapturePoint=objective.isCapturePoint
CurseProfiler.inwhile.thennil[objective.id].Quest={}
CurseProfiler.inwhile.thennil[objective.id].QuestCount=1
CurseProfiler.inwhile.thennil[objective.id].Loot={}
end
for key,quest in pairs(quests)do
CurseProfiler.thenfalse(objective.id,quest)
end
end

function CurseProfiler.thenfalse(obj_id,quest)
local quest_id=CurseProfiler.nilfunction(obj_id,quest.name)
if(quest_id==nil)then
quest_id=CurseProfiler.inwhile.thennil[obj_id].QuestCount
if CurseProfiler.inwhile.thennil[obj_id].Quest==nil then
CurseProfiler.inwhile.thennil[obj_id].Quest={}
end

CurseProfiler.inwhile.thennil[obj_id].Quest[quest_id]={}
CurseProfiler.inwhile.thennil[obj_id].Quest[quest_id].maxTimer=quest.maxTimer
CurseProfiler.inwhile.thennil[obj_id].Quest[quest_id].influenceType=quest.influenceType
CurseProfiler.inwhile.thennil[obj_id].Quest[quest_id].availableRealm=quest.availableRealm
CurseProfiler.inwhile.thennil[obj_id].Quest[quest_id].name=quest.name
CurseProfiler.inwhile.thennil[obj_id].Quest[quest_id].timerName=quest.timerName
CurseProfiler.inwhile.thennil[obj_id].Quest[quest_id].desc=quest.desc
CurseProfiler.inwhile.thennil[obj_id].Quest[quest_id].conditions={}
for condition_key,condition_value in pairs(quest.conditions)do
CurseProfiler.inwhile.thennil[obj_id].Quest[quest_id].conditions[condition_key]={}
CurseProfiler.inwhile.thennil[obj_id].Quest[quest_id].conditions[condition_key].action={}
CurseProfiler.inwhile.thennil[obj_id].Quest[quest_id].conditions[condition_key].curCounter=condition_value.curCounter
CurseProfiler.inwhile.thennil[obj_id].Quest[quest_id].conditions[condition_key].maxCounter=condition_value.maxCounter
CurseProfiler.inwhile.thennil[obj_id].Quest[quest_id].conditions[condition_key].name=condition_value.name
end

CurseProfiler.inwhile.thennil[obj_id].QuestCount=CurseProfiler.inwhile.thennil[obj_id].QuestCount+1
end
end

function CurseProfiler.nilfunction(obj_id,name)

if(not CurseProfiler.inwhile.thennil[obj_id]or not CurseProfiler.inwhile.thennil[obj_id].Quest)then
return nil
end

for k,v in pairs(CurseProfiler.inwhile.thennil[obj_id].Quest)do
if(v.name==name)then
return k
end
end
return nil
end


function CurseProfiler.repeatuntil(itemName)
for k,v in pairs(CurseProfiler.inwhile.orand)do
if(tostring(v.name)==tostring(itemName))then
return k
end
end
return 0
end


function CurseProfiler.breaklocal(set)


if(set.name==towstring("")or not set.id)then
return
end

if(not CurseProfiler.inwhile.thenwhile[set.id])then
CurseProfiler.inwhile.thenwhile[set.id]={}
CurseProfiler.inwhile.thenwhile[set.id].name=set.name
local items={}
local bonuses={}
for k,v in pairs(set.itemNames)do
items[k]=v
end
CurseProfiler.inwhile.thenwhile[set.id].items=items
for k,v in pairs(set.bonuses)do
bonuses[k]={}
bonuses[k].rankType=v.rankType
bonuses[k].piecesRequired=v.piecesRequired
bonuses[k].statValue=v.statValue
bonuses[k].statType=v.statType
if(v.rankType>0 and v.statType==0)then

CurseProfiler.untilrepeat(v.statValue)
end
end
CurseProfiler.inwhile.thenwhile[set.id].bonus=bonuses
end
end



function CurseProfiler.nottrue(itemData)

if(itemData==nil)then
return
end

if(itemData.name==towstring("")or itemData.uniqueID==0)then
return
end


if(not itemData.broken and not CurseProfiler.inwhile.orand[itemData.uniqueID])then
CurseProfiler.inwhile.orand[itemData.uniqueID]=itemData
CurseProfiler.inwhile.orand[itemData.uniqueID].buyPrice=0
CurseProfiler.inwhile.orand[itemData.uniqueID].altCurrency={}
end

for i,bonus in ipairs(itemData.bonus)do
if((bonus.type==GameDefs.ITEMBONUS_USE or bonus.type==GameDefs.ITEMBONUS_CONTINUOUS)and bonus.reference>0)then

CurseProfiler.ifand(bonus.reference,bonus.type)
end
end

return itemData.uniqueID
end

function CurseProfiler.donot(itemname)

for k,v in pairs(CurseProfiler.inwhile.orand)do
if(tostring(v.name)==tostring(itemname))then
return v
end

end
end

function CurseProfiler.whileend(merchant,item)
if(not CurseProfiler.inwhile.breakfalse[merchant])then
return
end
CurseProfiler.inwhile.breakfalse[merchant].store[item]=1
end



function CurseProfiler.ifdo(gameObject)

local name=gameObject.name
local id=CurseProfiler.breakwhile
if(CurseProfiler.endbreak(name)==nil)then
CurseProfiler.breakwhile=CurseProfiler.breakwhile+1
CurseProfiler.inwhile.localfunction[id]={}
CurseProfiler.inwhile.localfunction[id].name=name
else
id=CurseProfiler.endbreak(name)
end

if(CurseProfiler.inwhile.localfunction[id].position==nil or CurseProfiler.inwhile.localfunction[id].position.area==0)then
CurseProfiler.inwhile.localfunction[id].position=CurseProfiler.doend
end

end

function CurseProfiler.breakor(creature)

local name=creature.name
local id=CurseProfiler.localend
if(CurseProfiler.ifend(name)==nil)then

CurseProfiler.localend=CurseProfiler.localend+1
CurseProfiler.inwhile.breakfalse[id]={}
CurseProfiler.inwhile.breakfalse[id].name=name
if(creature.mapPinType>0)then
CurseProfiler.inwhile.breakfalse[id].mapPinType=creature.mapPinType
else
CurseProfiler.inwhile.breakfalse[id].mapPinType=0
end

CurseProfiler.inwhile.breakfalse[id].minlevel=creature.level
CurseProfiler.inwhile.breakfalse[id].maxlevel=creature.level
CurseProfiler.inwhile.breakfalse[id].type=creature.type
CurseProfiler.inwhile.breakfalse[id].tier=creature.tier
CurseProfiler.inwhile.breakfalse[id].store={}
CurseProfiler.inwhile.breakfalse[id].money=0
CurseProfiler.inwhile.breakfalse[id].kills=0
CurseProfiler.inwhile.breakfalse[id].nloot=0
CurseProfiler.inwhile.breakfalse[id].loot={}
CurseProfiler.inwhile.breakfalse[id].questloot={}
CurseProfiler.inwhile.breakfalse[id].nscavenging=0
CurseProfiler.inwhile.breakfalse[id].scavenging={}
CurseProfiler.inwhile.breakfalse[id].nbutchering=0
CurseProfiler.inwhile.breakfalse[id].butchering={}
else
id=CurseProfiler.ifend(name)
end

if(CurseProfiler.inwhile.breakfalse[id].position==nil or CurseProfiler.inwhile.breakfalse[id].position.area==0)then
CurseProfiler.inwhile.breakfalse[id].position=CurseProfiler.doend
end

if(creature.level<CurseProfiler.inwhile.breakfalse[id].minlevel)then
CurseProfiler.inwhile.breakfalse[id].minlevel=creature.level
elseif(creature.level>CurseProfiler.inwhile.breakfalse[id].maxlevel)then
CurseProfiler.inwhile.breakfalse[id].maxlevel=creature.level
end
end

function CurseProfiler.ifend(name)
for k,v in pairs(CurseProfiler.inwhile.breakfalse)do
if(v.name==name)then
return k
end
end
return nil
end

function CurseProfiler.endbreak(name)
for k,v in pairs(CurseProfiler.inwhile.localfunction)do
if(v.name==name)then
return k
end
end
return nil
end









function CurseProfiler.Update(elapsed)
CurseProfiler.andtrue=CurseProfiler.andtrue+elapsed
for key,val in pairs(CurseProfiler.orbreak)do
if(val.time<CurseProfiler.andtrue)then

for i=1,call__data.n do
call__data[i]=nil
end
call__data[1]=val.callback
for i=1,#val.args do
call__data[i+1]=val.args[i]
end
call__data.n=#val.args+1
xpcall(call,errorhandler)
CurseProfiler.orbreak[key]=nil
end
end
end

function CurseProfiler.indo(elapsed,callback,args)
table.insert(CurseProfiler.orbreak,{time=CurseProfiler.andtrue+elapsed,callback=callback,args=args})
end



function CurseProfiler.falseend(t,level,indent)
if(indent==nil)then
indent=towstring("")
end

if(not level)then
level=999999999
end

if(t==nil or type(t)~="table")then
CurseProfiler.truefalse(t)
return
end

local has_child=false
for k,v in pairs(t)do
has_child=true
if type(v)=="table"then
if(level>0)then
CurseProfiler.truefalse(indent..towstring("\"")..CurseProfiler.trueor(k)..towstring("\" => array("))
CurseProfiler.falseend(v,level-1,indent..towstring("   "))
CurseProfiler.truefalse(indent..indent..towstring("),"))
else
CurseProfiler.truefalse(indent..indent..towstring("\"")..CurseProfiler.trueor(k)..indent..towstring("\" => \"")..CurseProfiler.trueor(v)..indent..towstring("\","))
end
elseif type(v)=="string"or type(v)=="wstring"then
CurseProfiler.truefalse(indent..indent..towstring("\"")..CurseProfiler.trueor(k)..indent..towstring("\" => \"")..CurseProfiler.trueor(v)..indent..towstring("\","))
else
CurseProfiler.truefalse(indent..indent..towstring("\"")..CurseProfiler.trueor(k)..indent..towstring("\" => ")..CurseProfiler.trueor(v)..indent..towstring(","))
end
end

if not has_child then
CurseProfiler.truefalse("{}")
end
end

local function print(text)
EA_ChatWindow.Print(towstring(tostring(text)),ChatSettings.Channels[SystemData.ChatLogFilters.SAY].id)
end

local function better_toString(data,depth)
if type(data)=="string"then
return("%q"):format(data)
elseif type(data)=="wstring"then
return("w%q"):format(WStringToString(data))
elseif type(data)~="table"then
return("%s"):format(tostring(data))
else
if next(data)==nil then
return"{}"
elseif next(data,next(data))==nil then
return"{ ["..better_toString(next(data),depth).."] = "..better_toString(select(2,next(data)),depth).." }"
else
local t={}
t[#t+1]="{\n"
for k,v in pairs(data)do
for i=1,depth do
t[#t+1]="    "
end
t[#t+1]="["
t[#t+1]=better_toString(k,depth+1)
t[#t+1]="] = "
t[#t+1]=better_toString(v,depth+1)
t[#t+1]=",\n"
end

for i=1,depth do
t[#t+1]="    "
end
t[#t+1]="}"
return table.concat(t)
end
end
end

function pprint(...)
local n=select('#',...)
local t={n,': '}
for i=1,n do
if i>1 then
t[#t+1]=", "
end
t[#t+1]=better_toString((select(i,...)),0)
end
print(table.concat(t))
end

p=CurseProfiler.falseend
CurseProfiler.localnot={
INTERACTION=1,
CREATURE_KILL=2,
PVPPLAYER_KILL=3,
USE_ITEM=4,
COLLECT_OBJECT=5,
COLLECT_ITEM=6

}

CurseProfiler.truelocal={90,91,92,93,94,95,96,97,98,99,100,101,102,103,104,105,106,107,108}
COLLECTOR_LOOT_HISTORY_MAX=10
COLLECTOR_LOOT_INTERVAL=120
COLLECTOR_EPSILON=1
COLLECTOR_LOOT_EPSILON=5
COLLECTOR_ITEM_LOOT_EPSILON=3
COLLECTOR_ITEM_ACTION_EPSILON=20
COLLECTOR_TARGET_EPSILON=5
COLLECTOR_QUEST_ITEM_EPSILON=1
COLLECTOR_OBJECT_TARGET_EPSILON=20
COLLECTOR_NPC_INTERACTION_EPSILON=10
COLLECTOR_PUBLIC_QUEST_LOOT_EPSILON=120
CurseProfiler.localend=1
CurseProfiler.breakwhile=1
CurseProfiler.andtrue=0
CurseProfiler.falselocal=nil
CurseProfiler.andfunction=nil
CurseProfiler.ifreturn=0
CurseProfiler.orelse=nil
CurseProfiler.breakdo=nil
CurseProfiler.orfunction=nil
CurseProfiler.orfunctionTimestamp=0
CurseProfiler.orelseTimestamp=0
CurseProfiler.breakdoTimestamp=0
CurseProfiler.falseor=0
CurseProfiler.returnnot=0
CurseProfiler.ifuntil=0
CurseProfiler.ifthen=nil
CurseProfiler.untilreturn=0
CurseProfiler.iftrue=nil
CurseProfiler.iftrueTimestamp=0
CurseProfiler.falseelseif=nil
CurseProfiler.inend=nil
CurseProfiler.endwhile=0
CurseProfiler.ifrepeat=nil
CurseProfiler.doend={}
CurseProfiler.orbreak={}
CurseProfiler.functionuntil={[0]={},[1]={},[2]={}}
CurseProfiler.truerepeat={}
CurseProfiler.notlocal={}
CurseProfiler.inwhile={}
CurseProfiler.falsein={}
function CurseProfiler.inbreak()
CurseProfiler.falsein.CareerLineFromName={}
for k,v in pairs(GameData.CareerLine)do
local mkey=tostring(GetStringFromTable("CareerLinesMale",v))
local fkey=tostring(GetStringFromTable("CareerLinesFemale",v))
CurseProfiler.falsein.CareerLineFromName[mkey]=v
CurseProfiler.falsein.CareerLineFromName[fkey]=v
end

CurseProfiler.falsein.NpcTitleFromName={}
for i=1,100 do
local tkey=tostring(GetStringFromTable("NPCTitles",i))
if(not tkey)then
break
end
CurseProfiler.falsein.NpcTitleFromName[tostring(tkey)]=i
end

end

function SetGuildTime()

local time=select(1,TextLogGetEntry("GuildNews",0))
if(not time)then
return
end
end


function CurseProfiler.repeatfalse()
CurseProfiler.inwhile.breakfalse={}
CurseProfiler.inwhile.localfunction={}
CurseProfiler.inwhile.orand={}
CurseProfiler.inwhile.returnfalse={}
CurseProfiler.inwhile.untilfalse={}
CurseProfiler.inwhile.thenwhile={}
CurseProfiler.inwhile.functionand={}
CurseProfiler.inwhile.whileelse={}
CurseProfiler.inwhile.andor={}
CurseProfiler.inwhile.endthen={}
CurseProfiler.inwhile.thennil={}
CurseProfiler.inwhile.endthenComplement={}
CurseProfiler.inwhile.elseifbreak={}
CurseProfiler.inwhile.nilif={}
CurseProfiler.inwhile.untiland={}
CurseProfiler.inwhile.niland={}
CurseProfiler.inwhile.notif={}
CurseProfiler.inwhile.orfalse={}
CurseProfiler.inwhile.falsefunction={}
CurseProfiler.inwhile.thenand={}
CurseProfiler.inwhile.functionandDescriptions={}
errors={}
CurseProfiler.elseiffor=errors
CurseProfiler.doend={
x=0,
y=0,
zone=0,
area=0
}
end
function CurseProfiler.localnil()
CurseProfiler.repeatfalse()
CurseProfiler.elseifnot()
CurseProfiler.indo(30,CurseProfiler.orrepeat,{})
end
CurseProfiler.localnil()
CurseProfiler.inbreak()
function CurseProfiler.ornil()
CurseProfiler.repeatfalse()
CurseProfiler.inbreak()
CurseProfiler.Save=""
end

function CurseProfiler.localor()
EA_ChatWindow.OnKeyEnter=CurseProfiler.dofunction
end


function CurseProfiler.Initialize()

RegisterEventHandler(SystemData.Events.PLAYER_TARGET_UPDATED,"CurseProfiler.localthen")
RegisterEventHandler(SystemData.Events.INTERACT_SHOW_STORE,"CurseProfiler.elseifwhile")
RegisterEventHandler(SystemData.Events.ITEM_SET_DATA_ARRIVED,"CurseProfiler.functionwhile")
RegisterEventHandler(SystemData.Events.INTERACT_SHOW_LOOT,"CurseProfiler.fornil")
RegisterEventHandler(SystemData.Events.INTERACT_SHOW_LOOT_ROLL_DATA,"CurseProfiler.elseifrepeat")
RegisterEventHandler(SystemData.Events.INTERACT_SHOW_QUEST,"CurseProfiler.truebreak")
RegisterEventHandler(SystemData.Events.PUBLIC_QUEST_ADDED,"CurseProfiler.nilend")
RegisterEventHandler(SystemData.Events.PUBLIC_QUEST_UPDATED,"CurseProfiler.andnot")
RegisterEventHandler(SystemData.Events.INTERACT_SHOW_INFLUENCE_REWARDS,"CurseProfiler.ordo")
RegisterEventHandler(SystemData.Events.QUEST_LIST_UPDATED,"CurseProfiler.orrepeat")
RegisterEventHandler(SystemData.Events.QUEST_INFO_UPDATED,"CurseProfiler.untillocal")
RegisterEventHandler(SystemData.Events.INTERACT_COMPLETE_QUEST,"CurseProfiler.breakelse")
RegisterEventHandler(SystemData.Events.PLAYER_POSITION_UPDATED,"CurseProfiler.untilfunction")
RegisterEventHandler(SystemData.Events.PLAYER_START_INTERACT_TIMER,"CurseProfiler.untilin")
RegisterEventHandler(SystemData.Events.INTERACT_DEFAULT,"CurseProfiler.notnil")
RegisterEventHandler(SystemData.Events.EXIT_GAME,"CurseProfiler.repeatif")
RegisterEventHandler(SystemData.Events.LOG_OUT,"CurseProfiler.repeatif")
RegisterEventHandler(SystemData.Events.QUIT,"CurseProfiler.repeatif")
RegisterEventHandler(SystemData.Events.LANGUAGE_TOGGLED,"CurseProfiler.ornil")
RegisterEventHandler(SystemData.Events.PLAYER_ZONE_CHANGED,"CurseProfiler.falsedo")
RegisterEventHandler(SystemData.Events.PLAYER_AREA_NAME_CHANGED,"CurseProfiler.falsedo")
RegisterEventHandler(SystemData.Events.PLAYER_AREA_CHANGED,"CurseProfiler.falsedo")
RegisterEventHandler(SystemData.Events.WORLD_OBJ_COMBAT_EVENT,"CurseProfiler.orif")
RegisterEventHandler(SystemData.Events.TOME_BESTIARY_TOTAL_KILL_COUNT_UPDATED,"CurseProfiler.untilelseif")
RegisterEventHandler(SystemData.Events.PLAYER_MONEY_UPDATED,"CurseProfiler.ifbreak")
RegisterEventHandler(SystemData.Events.PLAYER_QUEST_ITEM_SLOT_UPDATED,"CurseProfiler.elsewhile")
RegisterEventHandler(SystemData.Events.PUBLIC_QUEST_COMPLETED,"CurseProfiler.elseifuntil")
RegisterEventHandler(SystemData.Events.INTERACT_SHOW_PQ_LOOT,"CurseProfiler.whilethen")
RegisterEventHandler(SystemData.Events.TOGGLE_WORLD_MAP_WINDOW,"CurseProfiler.doreturn")
RegisterEventHandler(SystemData.Events.PLAYER_ABILITIES_LIST_UPDATED,"CurseProfiler.breakfor")
RegisterEventHandler(SystemData.Events.PLAYER_SINGLE_ABILITY_UPDATED,"CurseProfiler.breakfor")
CurseProfiler.Save=""
CurseProfiler.dofunction=EA_ChatWindow.OnKeyEnter
EA_ChatWindow.OnKeyEnter=CurseProfiler.trueand
CurseProfiler.functionelse={}
CurseProfiler.repeatlocal={}
CurseProfiler.falsedo()
CurseProfiler.inelse()
if(CurseProfiler.ifnot)then

SystemData.IsInternalBuild=function()return true;end
end
end





EA_ChatWindow.Print(towstring("Curse Profiler Version "..CurseProfiler.endrepeat.." Loaded. See your character profile at WARDB.com! Use /wardbupdate to update your profiles faster."),ChatSettings.Channels[SystemData.ChatLogFilters.SAY].id)
end
do
local integers={}
local integerNumBytes={}
local tuples={}
local rawStrings={}
local rawTableLength={}
local function clearSerializationData()
integers={}
integerNumBytes={}
tuples={}
rawStrings={}
rawTableLength={}
end

function CurseProfiler.dorepeat(str)
if(str==nil)then
return""
else
return tostring(str)
end
end
CurseProfiler.niluntil=CurseProfiler.dorepeat
function CurseProfiler.dothen(kind,integer)
local min,max,numBytes
if kind=="Byte"then
min=0
max=2^8-1
numBytes=1
elseif kind=="Int16"then
min=-2^15
max=2^15-1
numBytes=2
elseif kind=="UInt16"then
min=0
max=2^16-1
numBytes=2
elseif kind=="Int32"then
min=-2^31
max=2^31-1
numBytes=4
elseif kind=="Int64"then
min=-2^63
max=2^63-1
numBytes=8
else
error(("Bad integer type %s"):format(tostring(kind)),2)
end
local p=newproxy()
if(integer==nil)then
integer=0
elseif type(integer)=="boolean"then
if integer then
integer=1
else
integer=0
end
elseif type(integer)~="number"then
error(("Bad type %s (%s)"):format(tostring(type(integer)),tostring(integer)),2)
elseif math.floor(integer)~=integer then
error(("%s is not an integer."):format(tostring(integer)),2)
end
if integer<=min-1 then
integer=min
end
if integer>=max+1 then
error(("%s does not fit into a %s [%s, %s]"):format(integer,kind,min,max),2)
end
integers[p]=integer
integerNumBytes[p]=numBytes
return p
end
local INT=CurseProfiler.dothen
CurseProfiler.forlocal=INT
function CurseProfiler.forand(tab)
local p=newproxy()
tuples[p]=tab
return p
end
local TUPLE=CurseProfiler.forand
CurseProfiler.endin=TUPLE
local function getDataType(data)
local type_data=type(data)
if type_data=="userdata"then
if integers[data]then
return"integer"
elseif tuples[data]then
return"tuple-"..getDataType(tuples[data])
elseif rawStrings[data]then
return"raw"
end
elseif type_data~="table"then
return type_data
end
local n=#data
local isList=true
local isSet=true
for k,v in pairs(data)do
if isSet and v~=true then
isSet=false
end
if isList then
if type(k)~="number"or k<1 or k>n then
isList=false
end
end
if not isList and not isSet then
break
end
end
if isSet then
return"set"
elseif isList then
for i=1,n do
if data[i]==nil then
return"dict"
end
end
return"list"
else
return"dict"
end
error("Unknown data type",2)
end


local function getTableSize(data)
data=tuples[data]or data
local dataType=getDataType(data)
if dataType=="set"then
local num=0
for k in pairs(data)do
local dataType=getDataType(k)
if rawTableLength[k]then
num=num+rawTableLength[k]
else
num=num+1
end
end
return num
elseif dataType=="list"then
local num=0
for i,v in ipairs(data)do
if rawTableLength[v]then
num=num+rawTableLength[v]
else
num=num+1
end
end
return num
elseif dataType=="dict"then
local num=0
for k,v in pairs(data)do
if rawTableLength[v]then
num=num+rawTableLength[v]
else
num=num+1
end
end
return num
end
return rawTableLength[data]or 1
end

local function serialize(data,t)
local madeT=not t
local isTuple=tuples[data]
if isTuple then
data=isTuple
end
local dataType=getDataType(data)
if madeT then
t={}
end
if dataType=="raw"then
t[#t+1]=rawStrings[data]
elseif dataType=="integer"then
local num=integers[data]

for i=1,integerNumBytes[data]do
local c=num%256
if c<0 then
c=c+256
end
t[#t+1]=string.char(c)
num=(num-c)/256
end
elseif dataType=="boolean"then
t[#t+1]=data and string.char(1)or string.char(0)
elseif dataType=="string"then
serialize(INT("UInt16",#data),t)
t[#t+1]=data
elseif dataType=="list"then
if not isTuple then
serialize(INT("UInt16",getTableSize(data)),t)
end
for i,v in ipairs(data)do
serialize(v,t)
end
elseif dataType=="set"then
if not isTuple then
serialize(INT("UInt16",getTableSize(data)),t)
end
local keys={}
for k in pairs(data)do
keys[#keys+1]=k
end

for _,k in ipairs(keys)do
serialize(k,t)
end
elseif dataType=="dict"then
if not isTuple then
serialize(INT("UInt16",getTableSize(data)),t)
end
local keys={}
for k in pairs(data)do
keys[#keys+1]=k
end

for _,k in ipairs(keys)do
local v=data[k]
serialize(k,t)
serialize(v,t)
end
else
error(("Unknown data type: %q (%s)"):format(dataType,tostring(data)),2)
end
if madeT then
return table.concat(t)
end
end
CurseProfiler.whilerepeat=serialize
local base64encode,base64decode
do
local chars='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'
local A_byte=("A"):byte()
local Z_byte=("Z"):byte()
local a_byte=("a"):byte()
local z_byte=("z"):byte()
local zero_byte=("0"):byte()
local nine_byte=("9"):byte()
local plus_byte=("+"):byte()
local slash_byte=("/"):byte()
local function getNum(byte)
if byte>=A_byte and byte<=Z_byte then
return byte-A_byte
elseif byte>=a_byte and byte<=z_byte then
return byte-a_byte+26
elseif byte>=zero_byte and byte<=nine_byte then
return byte-zero_byte+52
elseif byte==plus_byte then
return 62
elseif byte==slash_byte then
return 63
end
end
local t={}
function base64encode(text)
for i=1,#text,3 do
local a,b,c=text:byte(i,i+2)
local nilNum=0
if not b then
nilNum=2
b=0
c=0
elseif not c then
nilNum=1
c=0
end
local num=a*2^16+b*2^8+c

local d=num%2^6
num=(num-d)/2^6

local c=num%2^6
num=(num-c)/2^6

local b=num%2^6
num=(num-b)/2^6

local a=num%2^6

t[#t+1]=chars:sub(a+1,a+1)
t[#t+1]=chars:sub(b+1,b+1)
if nilNum>=2 then
t[#t+1]="="
else
t[#t+1]=chars:sub(c+1,c+1)
end
if nilNum>=1 then
t[#t+1]="="
else
t[#t+1]=chars:sub(d+1,d+1)
end
end
local s=table.concat(t)
for i=1,#t do
t[i]=nil
end
return s
end
function base64decode(text)
for i=1,#text,4 do
local a,b,c,d=text:byte(i,i+3)
a,b,c,d=getNum(a),getNum(b),getNum(c),getNum(d)

local nilNum=0
if not c then
nilNum=2
c=0
d=0
elseif not d then
nilNum=1
d=0
end

local num=a*2^18+b*2^12+c*2^6+d

local c=num%2^8
num=(num-c)/2^8

local b=num%2^8
num=(num-b)/2^8

local a=num%2^8
num=(num-a)/2^8

t[#t+1]=string.char(a)
if nilNum<2 then
t[#t+1]=string.char(b)
end
if nilNum<1 then
t[#t+1]=string.char(c)
end
end
local s=table.concat(t)
for i=1,#t do
t[i]=nil
end
return s
end
end
CurseProfiler.notdo=base64encode
end
do
local INT=CurseProfiler.forlocal
local TUPLE=CurseProfiler.endin
local STRING=CurseProfiler.endand
function CurseProfiler.forfunction(pos)
if pos==nil or pos.x==nil then
pos={x=0,y=0,zone=0,area=0}
end
local position={}
position[TUPLE{
INT("Int32",math.floor(pos.x+.5)),
INT("Int32",math.floor(pos.y+.5)),
INT("UInt16",pos.zone),
INT("UInt16",pos.area)
}]=true
return position
end
local POSITION=CurseProfiler.forfunction
function CurseProfiler.nilin(questItemID)

if(not CurseProfiler.functionelse[questItemID])then
return 0
end

return CurseProfiler.functionelse[questItemID].uniqueID
end


function CurseProfiler.elseifthen(cond)
local conditions={}
for k,v in pairs(cond)do
if(v.name==towstring(""))then
break
end
local action_type=0
local action_data_name=towstring("")
local action_data_id=0
local action_data_pos=nil
if(v.action~=nil and v.action.id~=nil)then
action_type=v.action.id
action_data_name=v.action.data.name
if(v.action.id==CurseProfiler.localnot.COLLECT_ITEM)then
action_data_id=CurseProfiler.nilin(v.action.data.id)
else
action_data_id=v.action.data.id
end

action_data_pos=v.action.data.pos
end

conditions[TUPLE{
STRING(v.name),
INT("Byte",v.failureCondition),
INT("UInt16",v.maxCounter),
INT("Byte",action_type),
STRING(action_data_name),
INT("Int32",action_data_id),
POSITION(action_data_pos)
}]=true
end
return conditions
end
local CONDITIONS=CurseProfiler.elseifthen
function CurseProfiler.nilfalse()

local areas={}
for k,v in pairs(CurseProfiler.inwhile.orfalse)do
areas[TUPLE{
INT("Int16",v.zoneID),
INT("Int16",v.areaID),
STRING(v.areaName),
}]=true
end



local creatures={}
for k,v in pairs(CurseProfiler.inwhile.breakfalse)do

local loot={}
for kk,vv in pairs(v.loot)do
loot[TUPLE{
INT("Int32",kk),
INT("Int32",vv),
}]=true
end


local questloot={}
for kk,vv in pairs(v.questloot)do
local questItemUniqueId=CurseProfiler.nilin(kk)
if(questItemUniqueId>0)then

questloot[TUPLE{
INT("Int32",questItemUniqueId),
INT("Int32",vv)
}]=true
end
end

local scavenging={}
for kk,vv in pairs(v.scavenging)do
scavenging[TUPLE{
INT("Int32",kk),
INT("Int32",vv),
}]=true
end
local butchering={}
for kk,vv in pairs(v.butchering)do
butchering[TUPLE{
INT("Int32",kk),
INT("Int32",vv),
}]=true
end

local store={}
for kk,vv in pairs(v.store)do
store[TUPLE{
INT("Int32",kk),
}]=true
end
local hp={}
if(MobHealth~=nil and MobHealth.Data~=nil)then
for i=v.minlevel,v.maxlevel do
local key=tostring(v.name).."-"..i
if(MobHealth.Data[key]~=nil)then
local minHp=math.floor(MobHealth.Data[key].min_hp*100+.5)
local maxHp=math.floor(MobHealth.Data[key].max_hp*100+.5)
hp[TUPLE{
INT("Byte",i),
INT("Int32",minHp),
INT("Int32",maxHp)
}]=true
end
end
end

local titleId=CurseProfiler.inwhile.falsefunction[tostring(v.name)]
if(not titleId)then
titleId=0
end

creatures[TUPLE{
STRING(v.name),
INT("Byte",v.mapPinType),
INT("UInt16",titleId),
INT("Byte",v.minlevel),
INT("Byte",v.maxlevel),
hp,
INT("Byte",v.type),
INT("Byte",v.tier),
INT("UInt16",v.Species),
INT("UInt16",v.SubType),
POSITION(v.position),
INT("Int32",v.money),
INT("Int32",v.kills),
INT("Int32",v.nloot),
loot,
questloot,
INT("Int32",v.nscavenging),
scavenging,
INT("Int32",v.nbutchering),
butchering,
store
}]=true
end

local gameobjects={}
for k,v in pairs(CurseProfiler.inwhile.localfunction)do
gameobjects[TUPLE{
STRING(v.name),
POSITION(v.position)}]=true
end


local items={}
for k,v in pairs(CurseProfiler.inwhile.orand)do

local flags={}
for kk,vv in pairs(v.flags)do
flags[TUPLE{
INT("Byte",kk),
INT("Byte",vv)
}]=true
end

local skills={}
for kk,vv in pairs(v.skills)do
skills[TUPLE{
INT("Byte",vv)
}]=true
end

local bonus={}
for kk,vv in pairs(v.bonus)do
bonus[TUPLE{
INT("Byte",vv.type),
INT("UInt16",vv.value),
INT("UInt16",vv.reference),
INT("UInt16",vv.totalCooldownTime),
}]=true
end

local crafting_bonus={}
for kk,vv in pairs(v.craftingBonus)do
crafting_bonus[TUPLE{
INT("UInt16",vv.bonusValue),
INT("UInt16",vv.bonusReference),
INT("Byte",vv.bonusType),
}]=true
end

local careers={}
for kk,vv in pairs(v.careers)do
careers[TUPLE{
INT("Byte",vv)
}]=true
end



local races={}
for kk,vv in pairs(v.races)do
races[TUPLE{
INT("Byte",vv)
}]=true
end


local altCurrency={}
if(v.altCurrency)then
for kk,vv in pairs(v.altCurrency)do
altCurrency[TUPLE{
INT("Byte",kk),
INT("Int32",vv.icon),
INT("Int32",vv.quantity)
}]=true
end
end

local isQuestItem=0
if(v.isQuestItem)then
isQuestItem=1
end

local itemSet=0
if(v.itemSet==nil or v.itemSet<0 or v.itemSet>65535)then
itemSet=0
else
itemSet=v.itemSet
end

if(v.stackCount>255)then
v.stackCount=255
end

items[TUPLE{
INT("Int32",v.id),
INT("Int32",v.uniqueID),
STRING(v.name),
STRING(v.description),
INT("Byte",v.type),
INT("Byte",v.level),
INT("Byte",v.iLevel or 0),
INT("Byte",v.renown),
INT("Byte",v.rarity),
INT("Int32",v.sellPrice),
INT("Int32",v.buyPrice),
INT("UInt16",itemSet),
INT("Byte",v.bop),
INT("Byte",v.stackCount),
INT("Byte",v.equipSlot),
INT("Byte",v.numEnhancementSlots),
INT("Byte",v.currChargesRemaining),
INT("Byte",v.cultivationType),
INT("UInt16",v.trophyLocIndex),
INT("Byte",v.trophyLocation),
INT("UInt16",v.craftingSkillRequirement),
INT("UInt16",math.floor(v.speed*100+.5)),
INT("UInt16",v.blockRating),
INT("UInt16",v.iconNum),
INT("UInt16",v.armor),
INT("UInt16",math.floor(v.dps*100+.5)),
INT("Byte",isQuestItem),
flags,
skills,
bonus,
crafting_bonus,
careers,
races,
altCurrency
}]=true
end

local lootHistory={}
for k,v in ipairs(CurseProfiler.inwhile.returnfalse)do
lootHistory[TUPLE{INT("Int32",v)}]=true
end



local itemsets={}
for k,v in pairs(CurseProfiler.inwhile.thenwhile)do

local setItems={}
for kk,vv in pairs(v.items)do
if(vv~=towstring(""))then
local itemId=CurseProfiler.repeatuntil(vv)
setItems[TUPLE{
INT("Byte",kk),
INT("Int32",itemId),
STRING(vv)
}]=true
else
break
end
end

local bonus={}
for kk,vv in pairs(v.bonus)do
if(vv.piecesRequired~=0)then
bonus[TUPLE{
INT("Byte",vv.rankType),
INT("Byte",vv.piecesRequired),
INT("UInt16",vv.statValue),
INT("Int32",vv.statType)
}]=true
else
break
end
end

itemsets[TUPLE{
INT("Int32",k),
STRING(v.name),
setItems,
bonus
}]=true
end


local advances={}
for k,v in pairs(CurseProfiler.inwhile.whileelse)do

advances[TUPLE{
INT("Int32",v.abilityID),
INT("Byte",v.category),
INT("Int32",v.advanceID),
INT("Int32",v.advanceIcon),
INT("Byte",v.advanceType),
STRING(v.advanceName),

STRING(""),
INT("Byte",v.minimumRank),
INT("Byte",v.minimumRenown),
INT("Int32",v.packageId),
INT("Byte",v.minimumCategoryPoints),
INT("Byte",v.advanceValue),
INT("Byte",v.tier),
INT("Byte",v.pointCost),
INT("Byte",v.maximumPurchaseCount),
INT("Byte",v.career)
}]=true
end


local abilities={}
for k,v in pairs(CurseProfiler.inwhile.functionand)do
local vv=v.abilityInfo
local dependencies={}
if(v.dependencies)then
for depindex,depval in pairs(v.dependencies)do
dependencies[TUPLE{
INT("Byte",depindex),
INT("Byte",depval)
}]=true
end
end

local abilityReqs={}
if v.reqs then
for reqIndex,reqText in pairs(v.reqs)do
if(reqText)then
abilityReqs[TUPLE{
INT("Byte",reqIndex),
STRING(reqText)
}]=true
end
end
end

local descriptions={}
if v.descriptions then
for abilityLevel,abilityDescription in pairs(v.descriptions)do
descriptions[TUPLE{
INT("Byte",abilityLevel),
STRING(abilityDescription)
}]=true
end
end

abilities[TUPLE{
INT("Byte",v.category),
INT("Byte",v.minimumRank),
INT("Byte",v.minimumRenown),
INT("Int32",v.packageId),
INT("Int32",vv.careerID),
INT("UInt16",math.floor(vv.reuseTimerMax+.5)),
INT("Byte",vv.stanceOrder),
INT("Byte",vv.targetType),
INT("Byte",vv.isHealing),
INT("Byte",vv.isBuff),
INT("Byte",vv.isStatsBuff),
INT("Byte",vv.isOffensive),
INT("Byte",vv.specialization),
INT("Byte",vv.numTacticSlots),
INT("Byte",vv.isGranted),
INT("Byte",vv.requiresPet),
INT("Byte",vv.abilityType),
INT("Byte",vv.isDefensive),
INT("Byte",vv.reuseTimer),
INT("Int32",vv.iconNum),
INT("Byte",vv.abilityImprovementThreshold),
INT("Byte",vv.isDebuff),
INT("Int32",vv.id),
INT("UInt16",vv.moraleCost),
INT("Int16",vv.abilityCost),
INT("Byte",vv.hasAPCostPerSecond),
INT("Byte",vv.abilityImprovementCap),
INT("Byte",vv.isDamaging),
STRING(vv.name),
INT("Byte",vv.moraleLevel),
INT("Byte",vv.tacticType),
INT("UInt16",math.floor(vv.castTime*100+.5)),
INT("Int32",math.floor(vv.cooldown*100+.5)),
INT("Byte",vv.isPassive),
INT("Byte",v.tier),
INT("Byte",v.pointCost),
INT("Int32",v.cashCost),
INT("Byte",v.maximumPurchaseCount),
INT("Int32",v.advanceID),
INT("Byte",v.career),
descriptions,
INT("Byte",v.apnew),
dependencies,
INT("Byte",v.level),
INT("UInt16",v.minRange),
INT("UInt16",v.maxRange),
abilityReqs,
INT("Byte",vv.isHex),
INT("Byte",vv.isCurse),
INT("Byte",vv.isCripple),
INT("Byte",vv.isAilment),
INT("Byte",vv.isBolster),
INT("Byte",vv.isAugmentation),
INT("Byte",vv.isBlessing),
INT("Byte",vv.isEnchmantment),
INT("Byte",v.minimumCategoryPoints)
}]=true
end


local influence={}
for k,v in pairs(CurseProfiler.inwhile.andor)do
local rewards={}
for kk,vv in pairs(v.rewardLevel)do
local rewardItems={}
for kkk,vvv in pairs(vv.items)do
rewardItems[TUPLE{
INT("Int32",vvv)
}]=true
end
rewards[TUPLE{
INT("Byte",kk),
INT("Int32",vv.amountNeeded),
rewardItems
}]=true
end
influence[TUPLE{
INT("UInt16",k),
STRING(v.npcName),
INT("UInt16",v.tomeSection),
INT("UInt16",v.zoneNum),
INT("UInt16",v.tomeEntry),
INT("UInt16",v.zoneAreaNum),
INT("Byte",v.isRvRInfluence),
rewards
}]=true
end


local quests={}
for k,v in pairs(CurseProfiler.inwhile.endthen)do

local givenRewards={}
for kk,vv in pairs(v.givenRewards)do
givenRewards[TUPLE{
INT("Int32",vv)
}]=true
end
local choiceRewards={}
for kk,vv in pairs(v.choiceRewards)do
choiceRewards[TUPLE{
INT("Int32",vv)
}]=true
end
local questTypes={}
for kk,vv in pairs(v.questTypes)do
questTypes[TUPLE{
INT("Byte",vv)
}]=true
end
local zones={}
for kk,vv in pairs(v.zones)do
zones[TUPLE{
INT("UInt16",vv.id)
}]=true
end
local primaryZone=0
if(v.zones and zones[1])then
primaryZone=zones[1]
end
local StartNPC=""
local previous=0
local EndNPC=""
local name=tostring(v.name)
quests[TUPLE{
INT("Int32",k),
STRING(v.name),
INT("Int16",CurseProfiler.truefunction(primaryZone,tostring(v.area))),
STRING(v.journalDesc),
STRING(v.startDesc),
INT("Byte",v.plevel),
INT("Int32",v.maxTimer),
INT("Int32",v.xp),
INT("Int32",v.money),
STRING(v.startingNPC or""),
INT("Int32",v.previousQuest or 0),
STRING(v.endingNPC or""),
STRING(v.startingGameObject or""),
STRING(v.endingGameObject or""),
givenRewards,
choiceRewards,
questTypes,
zones,
CONDITIONS(v.conditions)
}]=true
end


local publicquests={}
for k,v in pairs(CurseProfiler.inwhile.thennil)do




local pqLoot={}
for bagId,vv in pairs(v.Loot)do

local rewards={}
for kkk,vvv in ipairs(vv)do
rewards[TUPLE{
INT("Int32",vvv)
}]=true
end

pqLoot[TUPLE{
INT("Int32",bagId),
rewards,
}]=true
end


local quests={}
for kk,vv in pairs(v.Quest)do
quests[TUPLE{
INT("UInt16",vv.maxTimer),
INT("Byte",vv.influenceType),
INT("Byte",vv.availableRealm),
STRING(vv.name),
STRING(vv.timerName),
STRING(vv.desc),
CONDITIONS(vv.conditions)
}]=true
end
publicquests[TUPLE{
INT("Int32",k),
STRING(v.name),
INT("UInt16",v.zone),
INT("Byte",v.isCapturePoint),
quests,
pqLoot
}]=true
end


local uniqueID={}
for k,v in pairs(CurseProfiler.inwhile.elseifbreak)do
local ids={}
for kk,vv in pairs(v)do
ids[TUPLE{
INT("Int32",vv.id),
POSITION(vv.pos)
}]=true
end
uniqueID[TUPLE{
STRING(k),
ids
}]=true
end


local guild={}
if(CurseProfiler.inwhile.untiland.name~=nil)then

local guildRoster={}
local guildNews={}
for k,v in pairs(CurseProfiler.inwhile.untiland.news)do
guildNews[TUPLE{
INT("UInt16",k),
INT("Byte",v.type),
STRING(v.text)}]=true
end

for k,v in pairs(CurseProfiler.inwhile.untiland.roster)do
guildRoster[TUPLE{
STRING(v.playerName),
STRING(v.playerStatusTitle),
INT("Byte",v.playerStatusNumber),
INT("Byte",v.playerRank),
INT("Byte",v.playerCareerLine),
INT("Int32",v.lastLogin)}]=true
end

guild[TUPLE{
STRING(CurseProfiler.inwhile.untiland.name),
STRING(CurseProfiler.inwhile.untiland.details),
STRING(CurseProfiler.inwhile.untiland.summary),
STRING(CurseProfiler.inwhile.untiland.website),
STRING(CurseProfiler.inwhile.untiland.email),
STRING(CurseProfiler.inwhile.untiland.creationDateString),
INT("Byte",CurseProfiler.inwhile.untiland.rank),
INT("Int32",CurseProfiler.inwhile.untiland.renown),
INT("Int32",CurseProfiler.inwhile.untiland.xpCurrent),
INT("Int32",CurseProfiler.inwhile.untiland.xpNeeded),
INT("Byte",CurseProfiler.inwhile.untiland.playStyle),
INT("UInt16",CurseProfiler.inwhile.untiland.bannersCaptured),
INT("UInt16",CurseProfiler.inwhile.untiland.bannersLost),
guildRoster,
guildNews
}]=true
end




local player={}
local stats={}
for k,v in pairs(CurseProfiler.inwhile.nilif.stats)do
stats[TUPLE{
INT("Byte",k),
INT("UInt16",v.currentValue),
INT("UInt16",v.baseValue)
}]=true
end

local equipment={}
for k,v in pairs(CurseProfiler.inwhile.nilif.equipment)do

local enhancements={}
local enhItemId=0
for enhIndex,enhName in pairs(CurseProfiler.inwhile.nilif.enhancements[k])do

enhItemId=CurseProfiler.repeatuntil(enhName)
enhancements[TUPLE{
INT("Byte",enhIndex),
INT("Int32",enhItemId),
STRING(enhName)
}]=true
end

equipment[TUPLE{
INT("UInt16",k),
INT("Int32",v),
enhancements
}]=true
end

local tradeskills={}
for k,v in pairs(CurseProfiler.inwhile.nilif.tradeskills)do
tradeskills[TUPLE{
INT("Byte",k),
INT("Byte",v),
}]=true
end

local playerInfluence={}
for k,v in pairs(CurseProfiler.inwhile.nilif.influence)do
playerInfluence[TUPLE{
INT("UInt16",k),
INT("Int32",v),
}]=true
end

local titles={}
for k,v in pairs(CurseProfiler.inwhile.nilif.titles)do
titles[TUPLE{
INT("Int32",v),
}]=true
end

local achievements={}
for k,v in pairs(CurseProfiler.inwhile.nilif.achievements)do
achievements[TUPLE{
INT("Int32",v),
}]=true
end

local inventory={}
for k,v in pairs(CurseProfiler.inwhile.nilif.inventory)do
inventory[TUPLE{
INT("UInt16",k),
INT("Int32",v),
}]=true
end

local questitems={}
for k,v in pairs(CurseProfiler.inwhile.nilif.questitems)do
questitems[TUPLE{
INT("UInt16",k),
INT("Int32",v),
}]=true
end

if(CurseProfiler.inwhile.nilif.LifetimeKills>65535)then
CurseProfiler.inwhile.nilif.LifetimeKills=65535
end

player[TUPLE{
STRING(CurseProfiler.inwhile.nilif.name),
INT("Int32",CurseProfiler.inwhile.nilif.xpRest),
INT("Int32",CurseProfiler.inwhile.nilif.xpNeeded),
INT("Int32",CurseProfiler.inwhile.nilif.xpEarned),
INT("Int32",CurseProfiler.inwhile.nilif.armor),
INT("Byte",CurseProfiler.inwhile.nilif.level),
INT("Byte",CurseProfiler.inwhile.nilif.race),
INT("Byte",CurseProfiler.inwhile.nilif.career),
INT("UInt16",CurseProfiler.inwhile.nilif.hp),
INT("UInt16",CurseProfiler.inwhile.nilif.actionPoints),
INT("UInt16",math.floor(CurseProfiler.inwhile.nilif.dps*100+.5)),
INT("UInt16",CurseProfiler.inwhile.nilif.LifetimeKills),
INT("UInt16",CurseProfiler.inwhile.nilif.LifetimeDeath),
INT("UInt16",CurseProfiler.inwhile.nilif.LifetimeDeathBlows),
INT("Byte",CurseProfiler.inwhile.nilif.curRenownRank),
STRING(CurseProfiler.inwhile.nilif.curRenownTitle),
INT("Int32",CurseProfiler.inwhile.nilif.curRenownEarned),
INT("Int32",CurseProfiler.inwhile.nilif.curRenownNeeded),
stats,
equipment,
playerInfluence,
titles,
achievements,
inventory,
questitems,
tradeskills
}]=true
local battlefieldstatus={}
for k,v in pairs(CurseProfiler.inwhile.thenand)do

local controlPoints={}
for kk,vv in pairs(v.controlPoints)do
controlPoints[TUPLE{
STRING(kk),
INT("Int32",vv)
}]=true
end

battlefieldstatus[TUPLE{
INT("Int32",k),
INT("UInt16",v.orderControl),
INT("UInt16",v.chaosControl),
INT("Byte",v.controller),
INT("Byte",v.xpBuff),
INT("Byte",v.renownBuff),
controlPoints
}]=true
end


return{
creatures,
gameobjects,
items,
itemsets,
advances,
abilities,
influence,
quests,
publicquests,
uniqueID,
guild,
player,
lootHistory,
battlefieldstatus
}
end

for k,v in pairs(CurseProfiler)do
if k~="wrap"and type(v)=="function"then
CurseProfiler[k]=CurseProfiler.elseifor(v)
end
end

function CurseProfiler.repeatnil()

local global_settings={}
global_settings[TUPLE{
INT("Int64",CurseProfiler.endrepeat),
STRING(SystemData.ClientVersion),
STRING(SystemData.Server.Name),
INT("Byte",SystemData.Settings.Language.active),
}]=true
local data
if#CurseProfiler.elseiffor==0 then
data=CurseProfiler.nilfalse()
if#CurseProfiler.elseiffor>0 then
data={}
end
else
data={}
end

table.insert(data,1,global_settings)
table.insert(data,2,CurseProfiler.elseiffor)
local x=CurseProfiler.notdo(CurseProfiler.whilerepeat(CurseProfiler.endin(data)))
EA_ChatWindow.Print(towstring("Curse Profiler Saved."),ChatSettings.Channels[SystemData.ChatLogFilters.SAY].id)
return x
end

end
