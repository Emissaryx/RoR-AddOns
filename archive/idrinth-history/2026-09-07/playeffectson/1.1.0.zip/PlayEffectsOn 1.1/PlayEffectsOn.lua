--------------------------------------------------------------------------------
-- PlayEffectsOn
--
-- A button to quickly and easily change the 'Play ability effects on' setting.
-- Right click on the button to bring up the menu.
--------------------------------------------------------------------------------

if not PlayEffectsOn then
  PlayEffectsOn = {}
end

--------------------------------------------------------------------------------
-- Constants
--------------------------------------------------------------------------------

-- DO NOT MODIFY. The values match the client's internal values.
local MODE_NONE    = 1
local MODE_SELF    = 2
local MODE_PARTY   = 3
local MODE_WARBAND = 4
local MODE_ALL     = 5

-- Shortened names for convenience.
local PERF_CUSTOM_1 = SystemData.Settings.Performance.PERF_LEVEL_CUSTOM1
local PERF_CUSTOM_2 = SystemData.Settings.Performance.PERF_LEVEL_CUSTOM2

-- UI anchor and scaling tweaks to make the text look nice. Depends on fonts.
local UI_CONFIG = {}

UI_CONFIG[SystemData.Settings.Language.ENGLISH]   = { text_all = L"*",  offset =  2, offset_all =  8, scale_all = 1.6 }
UI_CONFIG[SystemData.Settings.Language.KOREAN]    = { text_all = L"* ", offset =  0, offset_all =  0, scale_all = 1.2 }
UI_CONFIG[SystemData.Settings.Language.S_CHINESE] = { text_all = L"*",  offset =  0, offset_all =  9, scale_all = 2.0 }
UI_CONFIG[SystemData.Settings.Language.T_CHINESE] = { text_all = L"*",  offset =  0, offset_all =  9, scale_all = 2.0 }
UI_CONFIG[SystemData.Settings.Language.JAPANESE]  = { text_all = L"*",  offset = -2, offset_all =  4, scale_all = 2.0 }
UI_CONFIG[SystemData.Settings.Language.RUSSIAN]   = { text_all = L"*",  offset =  1, offset_all = 11, scale_all = 2.0 }

-- Same fonts used, so same settings used.
UI_CONFIG[SystemData.Settings.Language.FRENCH]  = UI_CONFIG[SystemData.Settings.Language.ENGLISH]
UI_CONFIG[SystemData.Settings.Language.GERMAN]  = UI_CONFIG[SystemData.Settings.Language.ENGLISH]
UI_CONFIG[SystemData.Settings.Language.SPANISH] = UI_CONFIG[SystemData.Settings.Language.ENGLISH]
UI_CONFIG[SystemData.Settings.Language.ITALIAN] = UI_CONFIG[SystemData.Settings.Language.ENGLISH]

-- The add-on's UI window names.
local WINDOW_NAME_LABEL = "PlayEffectsOn_Label"
local WINDOW_NAME_MAIN = "PlayEffectsOn_Main"

--------------------------------------------------------------------------------
-- Internal Functions
--------------------------------------------------------------------------------

local function GetMode ()

  local perf = SystemData.Settings.Performance.perfLevel

  if (perf == PERF_CUSTOM_1) then
    return SystemData.Settings.Performance["custom1"]["abilityEffects"]

  elseif (perf == PERF_CUSTOM_2) then
    return SystemData.Settings.Performance["custom2"]["abilityEffects"]

  else
    return nil

  end

end

local function SetMode (mode)

  local perf = SystemData.Settings.Performance.perfLevel

  if (perf == PERF_CUSTOM_1) then
    SystemData.Settings.Performance["custom1"]["abilityEffects"] = mode

  elseif (perf == PERF_CUSTOM_2) then
    SystemData.Settings.Performance["custom2"]["abilityEffects"] = mode

  else
    TextLogAddEntry ("Chat", 0, L"PlayEffectsOn: Unable to change the setting as you are not using a custom video performance option.")

  end

  -- Broadcast the event anyway as it'll force a refresh of the PlayEffectsOn UI.
  BroadcastEvent (SystemData.Events.USER_SETTINGS_CHANGED)

end

local function UpdateUI ()

  local config = UI_CONFIG[SystemData.Settings.Language.active]

  -- Reset to defaults. Might be changed depending on the mode. This is a lot of
  -- work just to get an asterisk to display in the middle of the window.
  LabelSetTextColor (WINDOW_NAME_LABEL, 0, 255, 0)
  WindowSetScale (WINDOW_NAME_LABEL, 1.0)
  WindowClearAnchors (WINDOW_NAME_LABEL)
  WindowAddAnchor (WINDOW_NAME_LABEL, "center", WINDOW_NAME_MAIN, "center", 0, config.offset)

  local mode = GetMode ()

  if (mode == MODE_NONE) then
    LabelSetText (WINDOW_NAME_LABEL, L"0")

  elseif (mode == MODE_SELF) then
    -- Space added after the 1 to make the center alignment look nicer. Works
    -- for all languages.
    LabelSetText (WINDOW_NAME_LABEL, L"1 ")

  elseif (mode == MODE_PARTY) then
    LabelSetText (WINDOW_NAME_LABEL, L"6")

  elseif (mode == MODE_WARBAND) then
    LabelSetText (WINDOW_NAME_LABEL, L"24")

  elseif (mode == MODE_ALL) then

    -- The asterisk does weird things based on the font.
    LabelSetText (WINDOW_NAME_LABEL, config.text_all)
    WindowSetScale (WINDOW_NAME_LABEL, config.scale_all)

    WindowClearAnchors (WINDOW_NAME_LABEL)
    WindowAddAnchor (WINDOW_NAME_LABEL, "center", WINDOW_NAME_MAIN, "center", 0, config.offset_all)

  else
    LabelSetText (WINDOW_NAME_LABEL, L"?")
    LabelSetTextColor (WINDOW_NAME_LABEL, 255, 0, 0)

  end

end

--------------------------------------------------------------------------------
-- Events
--------------------------------------------------------------------------------

function PlayEffectsOn.OnInitialize ()

  CreateWindow (WINDOW_NAME_MAIN, true)

  RegisterEventHandler (SystemData.Events.USER_SETTINGS_CHANGED, "PlayEffectsOn.OnUserSettingsChanged")

  -- Fake the event call to set the initial UI state.
  PlayEffectsOn.OnUserSettingsChanged ()

  local mods = ModulesGetData ()

  for _, mod in ipairs (mods) do
    if (mod.name == "PlayEffectsOn") then
      TextLogAddEntry ("Chat", 0, L"<icon00057> PlayEffectsOn " .. towstring (mod.version) .. L" initialized.")
      return
    end
  end

end

function PlayEffectsOn.OnRButtonUp ()

  local function Option (value)
    return function () SetMode (value) end
  end

  EA_Window_ContextMenu.CreateContextMenu (
    SystemData.MouseOverWindow.name,
    EA_Window_ContextMenu.CONTEXT_MENU_1,
    GetStringFromTable ("UserSettingsStrings", StringTables.UserSettings.PERFORMANCE_ABILITY_EFFECTS_ON) .. L"..."
  )

  -- Params for AddMenuItem: text, callback, is_disabled?, close_on_click?

  EA_Window_ContextMenu.AddMenuItem (
    GetStringFromTable ("UserSettingsStrings", StringTables.UserSettings.PERFORMANCE_ABILITY_EFFECTS_NONE) .. L" (0)",
    Option (MODE_NONE),
    false,
    true)

  EA_Window_ContextMenu.AddMenuItem (
    GetStringFromTable ("UserSettingsStrings", StringTables.UserSettings.PERFORMANCE_ABILITY_EFFECTS_SELF) .. L" (1)",
    Option (MODE_SELF),
    false,
    true)

  EA_Window_ContextMenu.AddMenuItem (
    GetStringFromTable ("UserSettingsStrings", StringTables.UserSettings.PERFORMANCE_ABILITY_EFFECTS_PARTY) .. L" (6)",
    Option (MODE_PARTY),
    false,
    true)

  EA_Window_ContextMenu.AddMenuItem (
    GetStringFromTable ("UserSettingsStrings", StringTables.UserSettings.PERFORMANCE_ABILITY_EFFECTS_WARBAND) .. L" (24)",
    Option (MODE_WARBAND),
    false,
    true)

  EA_Window_ContextMenu.AddMenuItem (
    GetStringFromTable ("UserSettingsStrings", StringTables.UserSettings.PERFORMANCE_ABILITY_EFFECTS_ALL) .. L" (*)",
    Option (MODE_ALL),
    false,
    true)

  EA_Window_ContextMenu.Finalize ()

end

function PlayEffectsOn.OnUserSettingsChanged ()

  UpdateUI ()

end
