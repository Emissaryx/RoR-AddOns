Harbinger = {}	
Harbinger.HasCasted = false
Harbinger.Stance = 0	
local CurrentCareer = GameData.Player.career.id
HarbingerCounter = 0
Harbinger.GFX = {[22]="Rune",[66]="Harbinger"}
	
function Harbinger.Initialize()	
	CurrentCareer = GameData.Player.career.id

	TextLogAddEntry("Chat", 0, L"<icon57> Harbinger v1.6 Loaded")

	if CurrentCareer ~= 22 and CurrentCareer ~= 66 then return end

	RegisterEventHandler(SystemData.Events.PLAYER_BEGIN_CAST, "Harbinger.StartCast")
	RegisterEventHandler(SystemData.Events.PLAYER_END_CAST, "Harbinger.EndCast")
	RegisterEventHandler(SystemData.Events.ALL_MODULES_INITIALIZED, "Harbinger.RegisterAbilitySlot")
	RegisterEventHandler(SystemData.Events.LOADING_END, "Harbinger.RegisterAbilitySlot")
	RegisterEventHandler (SystemData.Events.PLAYER_HOT_BAR_UPDATED,"Harbinger.RegisterAbilitySlot")
	Harbinger.RegisterAbilitySlot()
	Harbinger.CheckStance()

	CreateWindow("HarbingerWindow", false)
	LayoutEditor.RegisterWindow( "HarbingerWindow", L"Harbinger", L"Harbinger Recource", true, true, true, nil )	
	Harbinger.update()
	DynamicImageSetTexture("HarbingerWindowFrame",Harbinger.GFX[tonumber(CurrentCareer)],0,0)		
end

function Harbinger.OnShutdown()
	UnregisterEventHandler(SystemData.Events.PLAYER_BEGIN_CAST, "Harbinger.StartCast")
	UnregisterEventHandler(SystemData.Events.PLAYER_END_CAST, "Harbinger.EndCast")
	UnregisterEventHandler(SystemData.Events.ALL_MODULES_INITIALIZED, "Harbinger.RegisterAbilitySlot")
	UnregisterEventHandler(SystemData.Events.LOADING_END, "Harbinger.RegisterAbilitySlot")
	UnregisterEventHandler (SystemData.Events.PLAYER_HOT_BAR_UPDATED,"Harbinger.RegisterAbilitySlot")
end

function Harbinger.StartCast(abilityId, isChannel, desiredCastTime, holdCastBar)
	local currentAbilityId = abilityId
	if currentAbilityId == 8550 or currentAbilityId == 1659 then
		Harbinger.HasCasted = true
	end
end

function Harbinger.EndCast()
	if Harbinger.HasCasted == true then
		if GetHotbarCooldown(HarbingerSlot) > 1 then
			--d("Healing Harbinger of Doom! ")
			Harbinger.Stance = 1
			Harbinger.CheckStance()
		else
			--d("Damaging Harbinger of Doom! ")
			Harbinger.Stance = 2
			Harbinger.CheckStance()
		end
	end
	Harbinger.HasCasted = false
end

--Find the Harbinger abilty slot
function Harbinger.RegisterAbilitySlot()
	HarbingerSlot = 0
	local ID,TYPE
	Harbinger.AbilitySlot={}
	for i=0,121	do
		TYPE,ID=GetHotbarData(i)
		if ID == 8550 or  ID == 1659 then
			HarbingerSlot = i
		return
		end
	end
end

function Harbinger.CheckStance()
	if DoesWindowExist("HarbingerWindowFrame") then
		if Harbinger.Stance == 0 then
		elseif Harbinger.Stance == 1 then
			DynamicImageSetTextureSlice("HarbingerWindowFrame","Healing")
		elseif Harbinger.Stance == 2 then
			DynamicImageSetTextureSlice("HarbingerWindowFrame","Damage")
		end
	end
end

function Harbinger.update()
	if (CurrentCareer == 22) or (CurrentCareer == 66) then
		WindowSetShowing("HarbingerWindow",true)
	else
		WindowSetShowing("HarbingerWindow",false)
	end
end
