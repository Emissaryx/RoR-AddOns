-- AutoBand tools tab UI bindings.
AutoBandWindowTools = {}

AutoBandWindowTools.name = "AutoBandWindowToolsTab"

AutoBandWindowTools.tools_data = {
        [AB_const.KICK_OFFLINE] = { ["button"] = "KickOfflineCheckBox" , ["label"] = "KickOfflineLabel", ["func_kick"]= AutoBand.cmd_kick_toofar, ["func_print"] = AutoBand.cmd_list_offline},
        [AB_const.KICK_ZONE] = { ["button"] = "KickZoneCheckBox" , ["label"] = "KickZoneLabel", ["func_kick"]= AutoBand.cmd_kick_notinzone, ["func_print"] = AutoBand.cmd_list_zone},
        [AB_const.KICK_RANK] = { ["button"] = "KickRankCheckBox" , ["label"] = "KickRankLabel", ["func_kick"]= AutoBand.cmd_kick_rank, ["func_print"] = AutoBand.cmd_list_rank} }

local function set_checkbox_enabled_with_label_color(checkbox_name, label_name, enabled)
    if type(ButtonSetDisabledFlag) == "function" then
        ButtonSetDisabledFlag(checkbox_name, not enabled)
    end
    if type(LabelSetTextColor) == "function" then
        if enabled then
            LabelSetTextColor(label_name, 225, 225, 225)
        else
            LabelSetTextColor(label_name, 150, 150, 150)
        end
    end
end

local function get_realmstats_buttons_state()
    if type(AutoBand.cmd_stats) ~= "function" then
        return false, "cmd_missing"
    end

    if type(AutoBand.is_realmrank_soft_disabled) == "function" and AutoBand.is_realmrank_soft_disabled() then
        return false, "soft_disabled"
    end

    if type(AutoBand.get_realmrank_snapshot_state) == "function" then
        local snapshot_state = AutoBand.get_realmrank_snapshot_state(true, { cache_first = true })
        if type(snapshot_state) == "table" and snapshot_state.status == "ok" then
            return true, "ok"
        end
        if type(snapshot_state) == "table" and type(snapshot_state.status) == "string" then
            return false, snapshot_state.status
        end
        return false, "csv_unavailable"
    end

    local loaded = false
    if type(AutoBand.ensure_realmrank_snapshot_loaded) == "function" then
        loaded = AutoBand.ensure_realmrank_snapshot_loaded(false) == true
    end
    local has_rows = type(AutoBand.realmrank_lookup) == "table" and next(AutoBand.realmrank_lookup) ~= nil
    if not loaded and not has_rows then
        return false, "csv_unavailable"
    end
    if loaded and not has_rows then
        return false, "csv_empty"
    end
    if AutoBand.is_realmrank_data_stale and AutoBand.is_realmrank_data_stale() == true then
        return false, "csv_stale"
    end
    return true, "ok"
end

local function realmstats_disabled_tooltip_text_for_status(status)
    if status == "csv_stale" or status == "stale" or status == "csv_empty" or status == "empty" then
        return "RR data is stale. Use /ab csvrefresh."
    end
    if status == "csv_unavailable" or status == "unavailable" then
        return "RR data is unavailable. Use /ab csvrefresh."
    end
    if status == "soft_disabled" then
        return "RR data is unavailable right now."
    end
    if status == "cmd_missing" then
        return "Realmstats unavailable in this build."
    end
    return "RR data is unavailable. Use /ab csvrefresh."
end

local function get_tooltip_window_name()
    local window_name = nil
    if SystemData and SystemData.ActiveWindow and SystemData.ActiveWindow.name then
        window_name = SystemData.ActiveWindow.name
    elseif SystemData and SystemData.MouseOverWindow and SystemData.MouseOverWindow.name then
        window_name = SystemData.MouseOverWindow.name
    end
    return window_name
end

local function get_tooltip_font_linespacing()
    if type(WindowUtils) == "table" and tonumber(WindowUtils.FONT_DEFAULT_TEXT_LINESPACING) ~= nil then
        return tonumber(WindowUtils.FONT_DEFAULT_TEXT_LINESPACING)
    end
    return 20
end

local function apply_small_tooltip_font()
    if type(LabelSetFont) ~= "function" then
        return
    end
    local linespacing = get_tooltip_font_linespacing()
    LabelSetFont("DefaultTooltipRow1Col1Text", "font_clear_small", linespacing)
    LabelSetFont("DefaultTooltipRow1Col2Text", "font_clear_small", linespacing)
    LabelSetFont("DefaultTooltipRow1Col3Text", "font_clear_small", linespacing)
end

local function restore_tooltip_font()
    if type(LabelSetFont) ~= "function" then
        return
    end
    local linespacing = get_tooltip_font_linespacing()
    LabelSetFont("DefaultTooltipRow1Col1Text", "font_default_text", linespacing)
    LabelSetFont("DefaultTooltipRow1Col2Text", "font_default_text", linespacing)
    LabelSetFont("DefaultTooltipRow1Col3Text", "font_default_text", linespacing)
end

local function show_text_tooltip(tooltip_text)
    if type(Tooltips) ~= "table" or type(Tooltips.CreateTextOnlyTooltip) ~= "function" then
        return
    end
    local window_name = get_tooltip_window_name()
    if not window_name or window_name == "" then
        return
    end
    local tooltip_value = tooltip_text
    if type(tooltip_value) == "string" then
        tooltip_value = towstring(tooltip_value)
    end
    if type(Tooltips.SetTooltipText) == "function" then
        Tooltips.CreateTextOnlyTooltip(window_name)
        apply_small_tooltip_font()
        Tooltips.SetTooltipText(1, 1, tooltip_value)
        if type(Tooltips.Finalize) == "function" then
            Tooltips.Finalize()
        end
    else
        Tooltips.CreateTextOnlyTooltip(window_name, tooltip_value)
    end
    if type(Tooltips.AnchorTooltip) == "function" then
        Tooltips.AnchorTooltip(Tooltips.ANCHOR_WINDOW_TOP)
    end
end

local function hide_text_tooltip()
    if type(Tooltips) ~= "table" or type(Tooltips.DestroyTooltip) ~= "function" then
        return
    end
    local window_name = get_tooltip_window_name()
    if not window_name or window_name == "" then
        return
    end
    restore_tooltip_font()
    Tooltips.DestroyTooltip(window_name)
end

local function maybe_show_realmstats_disabled_tooltip(button_name)
    local button_full_name = AutoBandWindowTools.name .. button_name
    if type(ButtonGetDisabledFlag) ~= "function" or ButtonGetDisabledFlag(button_full_name) ~= true then
        return false
    end
    local text = AutoBandWindowTools.realmstats_disabled_tooltip_text
    if type(text) ~= "string" or text == "" then
        text = "RR data is unavailable. Use /ab csvrefresh."
    end
    show_text_tooltip(text)
    return true
end

local tool_button_tooltips = {
    PrintButton = "Shows players matching the checked boxes. Does not kick.",
    KickButton = "Kicks players matching the checked boxes.",
    SearchRoleButton = "Posts WB needs in the checked channels.",
    FormWarbandButton = "Creates a WB or converts your party.",
    OrganizeButton = "Left-click: organize the WB using the active template.\nRight-click: organize and keep nearby players together.",
    ScoreboardButton = "Previews current WB scoreboard output before sending to /wb.",
    StatsButton = "Shows current realm population.\nRight-click: show tracked names that are online.",
    StatsBreakdownButton = "Shows realm population by tier.\nRight-click: include careers.",
    ResetButton = "Restores default Tools settings.",
}

local function get_selected_search_role_channels()
    if type(ButtonGetPressedFlag) ~= "function" then
        return nil
    end
    local args = {}
    if ButtonGetPressedFlag(AutoBandWindowTools.name .. "SearchRoleChan1CheckBox") then
        table.insert(args, "1")
    end
    if ButtonGetPressedFlag(AutoBandWindowTools.name .. "SearchRoleChanT4CheckBox") then
        table.insert(args, "t4")
    end
    if ButtonGetPressedFlag(AutoBandWindowTools.name .. "SearchRoleChan5CheckBox") then
        table.insert(args, "5")
    end
    return args
end

local function build_search_role_button_tooltip_text()
    local fallback = tool_button_tooltips.SearchRoleButton
    if type(AutoBand) ~= "table" or type(AutoBand.build_search_roles_preview_text) ~= "function" then
        return fallback
    end
    local args = get_selected_search_role_channels()
    if type(args) ~= "table" then
        return fallback
    end
    local ok, text = pcall(AutoBand.build_search_roles_preview_text, args)
    if ok and type(text) == "string" and text ~= "" then
        return text
    end
    return fallback
end

local function build_scoreboard_button_tooltip_text()
    local fallback = tool_button_tooltips.ScoreboardButton
    if type(AutoBand) ~= "table" or type(AutoBand.build_scoreboard_preview_text) ~= "function" then
        return fallback
    end

    local ok, text = pcall(AutoBand.build_scoreboard_preview_text, {})
    if ok and type(text) == "string" and text ~= "" then
        return text
    end
    return fallback
end

local function show_tool_button_tooltip(button_name)
    local text
    if button_name == "SearchRoleButton" then
        text = build_search_role_button_tooltip_text()
    elseif button_name == "ScoreboardButton" then
        text = build_scoreboard_button_tooltip_text()
    else
        text = tool_button_tooltips[button_name]
    end
    if type(text) == "string" and text ~= "" then
        show_text_tooltip(text)
    end
end

local function get_tool_control_name_from_active_window()
    local window_name = get_tooltip_window_name()
    if type(window_name) ~= "string" or window_name == "" then
        return nil
    end
    local prefix = AutoBandWindowTools.name
    if string.sub(window_name, 1, string.len(prefix)) ~= prefix then
        return nil
    end
    return string.sub(window_name, string.len(prefix) + 1)
end

local function build_discord_req_tooltip_text()
    return "Adds 'Discord req.' to search ads."
end

local function build_no_mic_tooltip_text()
    return "Adds '(no mic needed)' to search ads."
end

local function build_too_far_tooltip_text()
    return "Includes players who are too far away.\nProtect/Promote priority is excluded."
end

local function build_wbleader_tell_alert_tooltip_text()
    return "Highlights tells from known WB-Leaders while you lead a WB."
end

local tool_checkbox_tooltips = {
    KickZoneCheckBox = "Includes players outside the leader or assistant zones.",
    KickZoneLabel = "Includes players outside the leader or assistant zones.",
    KickRankCheckBox = "Includes players below the rank requirement.",
    KickRankLabel = "Includes players below the rank requirement.",
    SearchRoleChan1CheckBox = "Posts manual search in /1 Region.",
    SearchRoleChan1Label = "Posts manual search in /1 Region.",
    SearchRoleChanT4CheckBox = "Posts manual search in /t4.",
    SearchRoleChanT4Label = "Posts manual search in /t4.",
    SearchRoleChan5CheckBox = "Posts manual search in /5 LFG.",
    SearchRoleChan5Label = "Posts manual search in /5 LFG.",
    AutoFormSearchCheckBox = "Forms a WB before searching if needed.",
    AutoFormSearchLabel = "Forms a WB before searching if needed.",
    AutoSearchCheckBox = "Posts WB needs in /1 every 5 minutes.",
    AutoSearchLabel = "Posts WB needs in /1 every 5 minutes.",
    AutoPartyNoteCheckBox = "Keeps /partynote updated for the WB.",
    AutoPartyNoteLabel = "Keeps /partynote updated for the WB.",
    NotifyBuffsCheckBox = "Tells the WB when Organize finishes.",
    NotifyBuffsLabel = "Tells the WB when Organize finishes.",
    PrintRoleCheckBox = "Prints role assignments in chat.",
    PrintRoleLabel = "Prints role assignments in chat.",
}

local function tool_checkbox_tooltip_text_for_control(control_name)
    if control_name == "KickOfflineCheckBox" or control_name == "KickOfflineLabel" then
        return build_too_far_tooltip_text()
    end
    if control_name == "DiscordReqCheckBox" or control_name == "DiscordReqLabel" then
        return build_discord_req_tooltip_text()
    end
    if control_name == "NoMicCheckBox" or control_name == "NoMicLabel" then
        return build_no_mic_tooltip_text()
    end
    if control_name == "WBLeaderTellAlertCheckBox" or control_name == "WBLeaderTellAlertLabel" then
        return build_wbleader_tell_alert_tooltip_text()
    end
    return tool_checkbox_tooltips[control_name]
end

local function show_tool_checkbox_tooltip(control_name)
    local text = tool_checkbox_tooltip_text_for_control(control_name)
    if type(text) == "string" and text ~= "" then
        show_text_tooltip(text)
    end
end

local function build_zonevote_preview_tooltip_text()
    if type(AutoBand.get_zonevote_entries) ~= "function" then
        return "ZoneVote unavailable in this build."
    end

    local entries, err = AutoBand.get_zonevote_entries()
    if err ~= nil then
        return tostring(err)
    end
    if type(entries) ~= "table" or #entries == 0 then
        return "No active RvR zones found."
    end

    local title = "Zone"
    if type(AutoBand.get_zonevote_title) == "function" then
        title = AutoBand.get_zonevote_title()
    end

    local lines = { "Starts a vote for active zones.", "ZoneVote preview:", tostring(title) }
    if type(AutoBand.build_zonevote_ready_table) == "function" then
        local ready_table = AutoBand.build_zonevote_ready_table(entries, (AutoBand.zone_vote_config or {}).default_timer_seconds)
        local answers = ready_table and ready_table.Answers
        if type(answers) == "table" and #answers > 0 then
            for _, answer in ipairs(answers) do
                lines[#lines + 1] = "- " .. tostring(answer.Name or "")
            end
            return table.concat(lines, "\n")
        end
    end

    for _, entry in ipairs(entries) do
        local name = tostring(entry.name or ("Zone " .. tostring(entry.zone_id or "?")))
        lines[#lines + 1] = "- " .. name
        if entry.siege_ready == true then
            local prefix = ""
            if type(AutoBand.zonevote_get_ram_icon_token) == "function" then
                prefix = AutoBand.zonevote_get_ram_icon_token()
            end
            lines[#lines + 1] = "- " .. prefix .. name
        end
    end
    return table.concat(lines, "\n")
end

function AutoBandWindowTools.RefreshRealmstatsButtons()
    local available, status = get_realmstats_buttons_state()
    local disabled = not available
    ButtonSetDisabledFlag(AutoBandWindowTools.name .. "StatsButton", disabled)
    ButtonSetDisabledFlag(AutoBandWindowTools.name .. "StatsBreakdownButton", disabled)
    AutoBandWindowTools.realmstats_disabled_tooltip_text = realmstats_disabled_tooltip_text_for_status(status)
    if type(WindowSetShowing) == "function" then
        WindowSetShowing(AutoBandWindowTools.name .. "StatsButtonDisabledHover", disabled)
        WindowSetShowing(AutoBandWindowTools.name .. "StatsBreakdownButtonDisabledHover", disabled)
    end
    return available
end

function AutoBandWindowTools.RefreshSearchDiscordControls()
    local discord_checkbox_name = AutoBandWindowTools.name .. "DiscordReqCheckBox"
    local no_mic_checkbox_name = AutoBandWindowTools.name .. "NoMicCheckBox"
    local no_mic_label_name = AutoBandWindowTools.name .. "NoMicLabel"
    local discord_enabled = AutoBand.saved and AutoBand.saved.search_discord_req_enabled == true
    local no_mic_enabled = AutoBand.saved and AutoBand.saved.search_no_mic_enabled == true

    ButtonSetPressedFlag(discord_checkbox_name, discord_enabled)
    ButtonSetPressedFlag(no_mic_checkbox_name, no_mic_enabled)
    set_checkbox_enabled_with_label_color(no_mic_checkbox_name, no_mic_label_name, discord_enabled)
end


function AutoBandWindowTools.Initialize()
        LabelSetText(AutoBandWindowTools.name .. "KickLabel", L"Manage Players")

        for fid, func in pairs(AutoBandWindowTools.tools_data) do
                LabelSetText(AutoBandWindowTools.name .. func["label"], towstring(AB_const.LABEL_KICK[fid]))
                ButtonSetCheckButtonFlag(AutoBandWindowTools.name .. func["button"], true)
                ButtonSetPressedFlag(AutoBandWindowTools.name .. func["button"], AutoBand.saved.kick_func_enabled[fid])
        end

        ButtonSetText(AutoBandWindowTools.name .. "PrintButton", L"Print")
        ButtonSetText(AutoBandWindowTools.name .. "KickButton", L"Kick")
        ButtonSetText(AutoBandWindowTools.name .. "ZoneVoteButton", L"ZoneVote")

        LabelSetText(AutoBandWindowTools.name .. "SearchRoleLabel", L"Manual Search for Players")
        LabelSetText(AutoBandWindowTools.name .. "SearchRoleChan1Label", L"Manual Search in /1 (region)")
        LabelSetText(AutoBandWindowTools.name .. "SearchRoleChanT4Label", L"Manual Search in /t4")
        LabelSetText(AutoBandWindowTools.name .. "SearchRoleChan5Label", L"Manual Search in /5 (lfg)")

        ButtonSetCheckButtonFlag(AutoBandWindowTools.name .. "SearchRoleChan1CheckBox", true)
        ButtonSetPressedFlag(AutoBandWindowTools.name .. "SearchRoleChan1CheckBox", true)

        ButtonSetCheckButtonFlag(AutoBandWindowTools.name .. "SearchRoleChanT4CheckBox", true)
        ButtonSetPressedFlag(AutoBandWindowTools.name .. "SearchRoleChanT4CheckBox", false)

        ButtonSetCheckButtonFlag(AutoBandWindowTools.name .. "SearchRoleChan5CheckBox", true)
        ButtonSetPressedFlag(AutoBandWindowTools.name .. "SearchRoleChan5CheckBox", false)

        ButtonSetText(AutoBandWindowTools.name .. "SearchRoleButton", L"Manual Search")
        ButtonSetText(AutoBandWindowTools.name .. "FormWarbandButton", L"Form WB")

        LabelSetText(AutoBandWindowTools.name .. "AutoSearchLabel", L"Auto Search in /1 every 5 mins")
        ButtonSetCheckButtonFlag(AutoBandWindowTools.name .. "AutoSearchCheckBox", true)
        ButtonSetPressedFlag(AutoBandWindowTools.name .. "AutoSearchCheckBox", AutoBand.saved.autonote_enabled)

        LabelSetText(AutoBandWindowTools.name .. "AutoPartyNoteLabel", L"Auto Update /partynote for WB")
        ButtonSetCheckButtonFlag(AutoBandWindowTools.name .. "AutoPartyNoteCheckBox", true)
        ButtonSetPressedFlag(AutoBandWindowTools.name .. "AutoPartyNoteCheckBox", AutoBand.saved.autopartynote_enabled)

        ButtonSetText(AutoBandWindowTools.name .. "OrganizeButton", L"Organize WB")
        ButtonSetText(AutoBandWindowTools.name .. "ScoreboardButton", L"AB Scoreboard")
        ButtonSetText(AutoBandWindowTools.name .. "StatsButton", L"Realmstats")
        ButtonSetText(AutoBandWindowTools.name .. "StatsBreakdownButton", L"Realmstats breakdown")

        LabelSetText(AutoBandWindowTools.name .. "NotifyBuffsLabel", L"Notify WB after Organize")
        ButtonSetCheckButtonFlag(AutoBandWindowTools.name .. "NotifyBuffsCheckBox", true)

        LabelSetText(AutoBandWindowTools.name .. "PrintRoleLabel", L"Print Role Assignments")
        ButtonSetCheckButtonFlag(AutoBandWindowTools.name .. "PrintRoleCheckBox", true)

        LabelSetText(AutoBandWindowTools.name .. "DiscordReqLabel", L"Append \"Discord req\"")
        ButtonSetCheckButtonFlag(AutoBandWindowTools.name .. "DiscordReqCheckBox", true)
        LabelSetText(AutoBandWindowTools.name .. "NoMicLabel", L"No mic")
        ButtonSetCheckButtonFlag(AutoBandWindowTools.name .. "NoMicCheckBox", true)
        AutoBandWindowTools.RefreshSearchDiscordControls()

        LabelSetText(AutoBandWindowTools.name .. "AutoFormSearchLabel", L"Autoform WB on search if needed")
        ButtonSetCheckButtonFlag(AutoBandWindowTools.name .. "AutoFormSearchCheckBox", true)

        LabelSetText(AutoBandWindowTools.name .. "WBLeaderTellAlertLabel", L"WB-Leader Tell Alerts")
        ButtonSetCheckButtonFlag(AutoBandWindowTools.name .. "WBLeaderTellAlertCheckBox", true)
        ButtonSetPressedFlag(AutoBandWindowTools.name .. "WBLeaderTellAlertCheckBox", AutoBand.saved.wbleader_tell_alert_enabled == true)

        -- Button bar
        LabelSetText(AutoBandWindowTools.name .. "VersionLabel", L"v" .. towstring(AB_const.VERSION))
        ButtonSetText(AutoBandWindowTools.name .. "ResetButton", L"Restore Defaults")
        AutoBandWindowTools.RefreshRealmstatsButtons()
end

function AutoBandWindowTools.Shutdown()
end


function AutoBandWindowTools.Hide()
        WindowSetShowing(AutoBandWindowTools.name, false)
end


function AutoBandWindowTools.Show()
        ButtonSetPressedFlag(AutoBandWindowTools.name .. "AutoSearchCheckBox", AutoBand.saved.autonote_enabled)
        ButtonSetPressedFlag(AutoBandWindowTools.name .. "AutoPartyNoteCheckBox", AutoBand.saved.autopartynote_enabled)
        ButtonSetPressedFlag(AutoBandWindowTools.name .. "NotifyBuffsCheckBox", AutoBand.saved.notify_buffs_enabled)
        ButtonSetPressedFlag(AutoBandWindowTools.name .. "WBLeaderTellAlertCheckBox", AutoBand.saved.wbleader_tell_alert_enabled == true)
        ButtonSetPressedFlag(AutoBandWindowTools.name .. "PrintRoleCheckBox", AutoBand.saved.printrole_enabled)
        AutoBandWindowTools.RefreshSearchDiscordControls()
        ButtonSetPressedFlag(AutoBandWindowTools.name .. "AutoFormSearchCheckBox", AutoBand.saved.autoform_search_enabled)
        AutoBandWindowTools.RefreshRealmstatsButtons()
        WindowSetShowing(AutoBandWindowTools.name, true)
end


function AutoBandWindowTools.reset_kick_enabled()
        for fid, func in pairs(AutoBandWindowTools.tools_data) do
                ButtonSetPressedFlag(AutoBandWindowTools.name .. func["button"], AB_const.KICK_FUNC_DEFAULT[fid])
                AutoBand.saved.kick_func_enabled[fid] = AB_const.KICK_FUNC_DEFAULT[fid]
        end
end


function AutoBandWindowTools.OnKickOfflineCheckBox()
        AutoBand.saved.kick_func_enabled[AB_const.KICK_OFFLINE] = ButtonGetPressedFlag(AutoBandWindowTools.name .. "KickOfflineCheckBox")
end


function AutoBandWindowTools.OnKickZoneCheckBox()
        AutoBand.saved.kick_func_enabled[AB_const.KICK_ZONE] = ButtonGetPressedFlag(AutoBandWindowTools.name .. "KickZoneCheckBox")
end


function AutoBandWindowTools.OnKickRankCheckBox()
        AutoBand.saved.kick_func_enabled[AB_const.KICK_RANK] = ButtonGetPressedFlag(AutoBandWindowTools.name .. "KickRankCheckBox")
end


function AutoBandWindowTools.OnKickButton()
        for fid, kick_func in pairs(AutoBandWindowTools.tools_data) do
                AutoBand.saved.kick_func_enabled[fid] = ButtonGetPressedFlag(AutoBandWindowTools.name .. kick_func["button"])
                if (AutoBand.saved.kick_func_enabled[fid]) then
                        kick_func.func_kick()
                end
        end
end

function AutoBandWindowTools.OnPrintButton()
        AB_util.print("Warband Report ")
        for fid, kick_func in pairs(AutoBandWindowTools.tools_data) do
                AutoBand.saved.kick_func_enabled[fid] = ButtonGetPressedFlag(AutoBandWindowTools.name .. kick_func["button"])
                if (AutoBand.saved.kick_func_enabled[fid]) then
                        kick_func.func_print()
                end
        end
end

function AutoBandWindowTools.OnZoneVoteButton()
  AutoBand.cmd_zone_vote({})
end

function AutoBandWindowTools.OnOrganizeButton()
  AutoBand.cmd_organize({})
end

function AutoBandWindowTools.OnOrganizeButtonRightClick()
  AutoBand.cmd_organize({"distance"})
end

function AutoBandWindowTools.OnScoreboardButton()
  if type(AutoBand.cmd_scoreboard_probe) == "function" then
    AutoBand.cmd_scoreboard_probe({})
  end
end

function AutoBandWindowTools.OnStatsButton()
  if not AutoBandWindowTools.RefreshRealmstatsButtons() then
    return
  end
  AutoBand.cmd_stats({})
end

local function get_online_monitor_group_count_for_stats_right_click()
  if type(AutoBand.get_online_monitor_count) == "function" then
    local count = tonumber(AutoBand.get_online_monitor_count())
    if count ~= nil and count > 0 then
      return math.floor(count)
    end
    return 0
  end

  if type(AutoBand.online_monitor_groups) ~= "table" then
    return 0
  end

  local count = 0
  for key, _ in pairs(AutoBand.online_monitor_groups) do
    if type(key) == "string" and key ~= "" then
      count = count + 1
    end
  end
  return count
end

function AutoBandWindowTools.OnStatsButtonRightClick()
  if not AutoBandWindowTools.RefreshRealmstatsButtons() then
    return
  end
  if type(AutoBand.cmd_online) ~= "function" then
    return
  end
  if get_online_monitor_group_count_for_stats_right_click() <= 0 then
    return
  end
  AutoBand.cmd_online({})
end

function AutoBandWindowTools.OnStatsBreakdownButton()
  if not AutoBandWindowTools.RefreshRealmstatsButtons() then
    return
  end
  AutoBand.cmd_stats({"breakdown"})
end

function AutoBandWindowTools.OnStatsBreakdownButtonRightClick()
  if not AutoBandWindowTools.RefreshRealmstatsButtons() then
    return
  end
  AutoBand.cmd_stats({"breakdown", "detailed"})
end

function AutoBandWindowTools.OnStatsButtonMouseOver()
  if not maybe_show_realmstats_disabled_tooltip("StatsButton") then
    show_tool_button_tooltip("StatsButton")
  end
end

function AutoBandWindowTools.OnStatsButtonMouseOverEnd()
  hide_text_tooltip()
end

function AutoBandWindowTools.OnStatsBreakdownButtonMouseOver()
  if not maybe_show_realmstats_disabled_tooltip("StatsBreakdownButton") then
    show_tool_button_tooltip("StatsBreakdownButton")
  end
end

function AutoBandWindowTools.OnStatsBreakdownButtonMouseOverEnd()
  hide_text_tooltip()
end

function AutoBandWindowTools.OnZoneVoteButtonMouseOver()
  show_text_tooltip(build_zonevote_preview_tooltip_text())
end

function AutoBandWindowTools.OnZoneVoteButtonMouseOverEnd()
  hide_text_tooltip()
end

function AutoBandWindowTools.OnToolButtonMouseOver()
  show_tool_button_tooltip(get_tool_control_name_from_active_window())
end

function AutoBandWindowTools.OnToolButtonMouseOverEnd()
  hide_text_tooltip()
end

function AutoBandWindowTools.OnToolCheckboxMouseOver()
  show_tool_checkbox_tooltip(get_tool_control_name_from_active_window())
end

function AutoBandWindowTools.OnToolCheckboxMouseOverEnd()
  hide_text_tooltip()
end

function AutoBandWindowTools.OnDiscordReqMouseOver()
  show_tool_checkbox_tooltip("DiscordReqCheckBox")
end

function AutoBandWindowTools.OnDiscordReqMouseOverEnd()
  hide_text_tooltip()
end

function AutoBandWindowTools.OnNoMicMouseOver()
  show_tool_checkbox_tooltip("NoMicCheckBox")
end

function AutoBandWindowTools.OnNoMicMouseOverEnd()
  hide_text_tooltip()
end

function AutoBandWindowTools.OnKickOfflineMouseOver()
  show_tool_checkbox_tooltip("KickOfflineCheckBox")
end

function AutoBandWindowTools.OnKickOfflineMouseOverEnd()
  hide_text_tooltip()
end

function AutoBandWindowTools.OnWBLeaderTellAlertMouseOver()
  show_tool_checkbox_tooltip("WBLeaderTellAlertCheckBox")
end

function AutoBandWindowTools.OnWBLeaderTellAlertMouseOverEnd()
  hide_text_tooltip()
end

function AutoBandWindowTools.OnNotifyBuffsCheckBox()
  AutoBand.cmd_toggle_buffnotify({})
end

function AutoBandWindowTools.OnWBLeaderTellAlertCheckBox()
  AutoBand.cmd_toggle_wbleader_tell_alert({})
end

function AutoBandWindowTools.OnPrintRoleCheckBox()
  AutoBand.cmd_flag_printrole({})
end

function AutoBandWindowTools.OnAutoFormSearchCheckBox()
    AutoBand.cmd_toggle_autoform_search({})
end

function AutoBandWindowTools.OnDiscordReqCheckBox()
    AutoBand.saved.search_discord_req_enabled = ButtonGetPressedFlag(AutoBandWindowTools.name .. "DiscordReqCheckBox")
    AB_util.print("Append \"Discord req\" to searches: " .. tostring(AutoBand.saved.search_discord_req_enabled))
    if AutoBand and AutoBand.mark_template_settings_modified then
        AutoBand.mark_template_settings_modified()
    end
    AutoBandWindowTools.RefreshSearchDiscordControls()
end

function AutoBandWindowTools.OnNoMicCheckBox()
    local checkbox_name = AutoBandWindowTools.name .. "NoMicCheckBox"
    if type(ButtonGetDisabledFlag) == "function" and ButtonGetDisabledFlag(checkbox_name) == true then
        return
    end
    AutoBand.saved.search_no_mic_enabled = ButtonGetPressedFlag(checkbox_name)
    AB_util.print("Append \"no mic needed\" to searches: " .. tostring(AutoBand.saved.search_no_mic_enabled))
    if AutoBand and AutoBand.mark_template_settings_modified then
        AutoBand.mark_template_settings_modified()
    end
end

function AutoBandWindowTools.OnSearchRoleButton()
  local args = {}

        if ButtonGetPressedFlag(AutoBandWindowTools.name .. "SearchRoleChan1CheckBox") then
                table.insert(args, "1")
        end

  if ButtonGetPressedFlag(AutoBandWindowTools.name .. "SearchRoleChanT4CheckBox") then
    table.insert(args, "t4")
  end

  if ButtonGetPressedFlag(AutoBandWindowTools.name .. "SearchRoleChan5CheckBox") then
    table.insert(args, "5")
  end

  AutoBand.cmd_search_roles(args)
end

function AutoBandWindowTools.OnFormWarbandButton()
    AutoBand.cmd_form({})
end

function AutoBandWindowTools.OnAutoSearchCheckBox()
        AutoBand.cmd_flag_autonote({})
end

function AutoBandWindowTools.OnAutoPartyNoteCheckBox()
    AutoBand.cmd_toggle_partynote({})
end

function AutoBandWindowTools.OnResetTools()
    AB_util.debug(AutoBand.saved.kick_func_enabled)
    AB_util.debug(AB_const.KICK_FUNC_DEFAULT)
    AutoBandWindowTools.reset_kick_enabled()

    AutoBand.saved.autonote_enabled = AB_const.AUTONOTE
    AutoBand.saved.autopartynote_enabled = AB_const.AUTOPARTYNOTE
    AutoBand.saved.notify_buffs_enabled = true
    if AutoBand and AutoBand.set_wbleader_tell_alert_enabled then
        AutoBand.set_wbleader_tell_alert_enabled(false, { silent = true, skip_gui_refresh = true })
    else
        AutoBand.saved.wbleader_tell_alert_enabled = false
        if AutoBand and AutoBand.RefreshWBLeaderTellEventSubscription then
            AutoBand.RefreshWBLeaderTellEventSubscription()
        end
    end
    AutoBand.saved.printrole_enabled = AB_const.PRINTROLE
    AutoBand.saved.search_discord_req_enabled = AB_const.SEARCH_DISCORD_REQ
    AutoBand.saved.search_no_mic_enabled = AB_const.SEARCH_NO_MIC
    AutoBand.saved.autoform_search_enabled = AB_const.AUTOFORM_SEARCH

    AB_util.print("Reset ToolsTab-settings to Default.")
    if AutoBand and AutoBand.mark_template_settings_modified then
        AutoBand.mark_template_settings_modified()
    end

    AutoBandWindowTools.Show()
end

-- Helper for labels that should trigger the original checkbox logic
function AutoBandWindowTools.GenericLabelClickHandler(checkboxRelativeName, originalCheckboxHandlerFunction)
    PlaySound(GameData.Sound.BUTTON_CLICK)
    local checkboxFullName = AutoBandWindowTools.name .. checkboxRelativeName
    if type(ButtonGetDisabledFlag) == "function" and ButtonGetDisabledFlag(checkboxFullName) == true then
        return
    end
    ButtonSetPressedFlag(checkboxFullName, not ButtonGetPressedFlag(checkboxFullName))
    if originalCheckboxHandlerFunction then
        originalCheckboxHandlerFunction()
    end
end

-- Helper for labels that ONLY toggle the checkbox visual state (state read later by a separate button)
function AutoBandWindowTools.ToggleCheckboxVisualState(checkboxRelativeName)
    PlaySound(GameData.Sound.BUTTON_CLICK)
    local checkboxFullName = AutoBandWindowTools.name .. checkboxRelativeName
    if type(ButtonGetDisabledFlag) == "function" and ButtonGetDisabledFlag(checkboxFullName) == true then
        return
    end
    ButtonSetPressedFlag(checkboxFullName, not ButtonGetPressedFlag(checkboxFullName))
end

-- Specific label click handlers for AutoBandWindowTools

-- Cases where label click should only toggle checkbox visual state:
function AutoBandWindowTools.OnClickSearchRoleChan1Label()
    PlaySound(GameData.Sound.BUTTON_CLICK)
    AutoBandWindowTools.ToggleCheckboxVisualState("SearchRoleChan1CheckBox")
end
function AutoBandWindowTools.OnClickSearchRoleChanT4Label()
    PlaySound(GameData.Sound.BUTTON_CLICK)
    AutoBandWindowTools.ToggleCheckboxVisualState("SearchRoleChanT4CheckBox")
end
function AutoBandWindowTools.OnClickSearchRoleChan5Label()
    PlaySound(GameData.Sound.BUTTON_CLICK)
    AutoBandWindowTools.ToggleCheckboxVisualState("SearchRoleChan5CheckBox")
end

-- Cases where label click should mimic checkbox action (toggle + call handler):
function AutoBandWindowTools.OnClickKickOfflineLabel()
    AutoBandWindowTools.GenericLabelClickHandler("KickOfflineCheckBox", AutoBandWindowTools.OnKickOfflineCheckBox)
end
function AutoBandWindowTools.OnClickKickZoneLabel()
    AutoBandWindowTools.GenericLabelClickHandler("KickZoneCheckBox", AutoBandWindowTools.OnKickZoneCheckBox)
end
function AutoBandWindowTools.OnClickKickRankLabel()
    AutoBandWindowTools.GenericLabelClickHandler("KickRankCheckBox", AutoBandWindowTools.OnKickRankCheckBox)
end

function AutoBandWindowTools.OnClickAutoSearchLabel()
    AutoBandWindowTools.GenericLabelClickHandler("AutoSearchCheckBox", AutoBandWindowTools.OnAutoSearchCheckBox)
end

function AutoBandWindowTools.OnClickAutoPartyNoteLabel()
    AutoBandWindowTools.GenericLabelClickHandler("AutoPartyNoteCheckBox", AutoBandWindowTools.OnAutoPartyNoteCheckBox)
end

function AutoBandWindowTools.OnClickNotifyBuffsLabel()
    AutoBandWindowTools.GenericLabelClickHandler("NotifyBuffsCheckBox", AutoBandWindowTools.OnNotifyBuffsCheckBox)
end

function AutoBandWindowTools.OnClickWBLeaderTellAlertLabel()
    AutoBandWindowTools.GenericLabelClickHandler("WBLeaderTellAlertCheckBox", AutoBandWindowTools.OnWBLeaderTellAlertCheckBox)
end

function AutoBandWindowTools.OnClickPrintRoleLabel()
    AutoBandWindowTools.GenericLabelClickHandler("PrintRoleCheckBox", AutoBandWindowTools.OnPrintRoleCheckBox)
end

function AutoBandWindowTools.OnClickDiscordReqLabel()
    AutoBandWindowTools.GenericLabelClickHandler("DiscordReqCheckBox", AutoBandWindowTools.OnDiscordReqCheckBox)
end

function AutoBandWindowTools.OnClickNoMicLabel()
    AutoBandWindowTools.GenericLabelClickHandler("NoMicCheckBox", AutoBandWindowTools.OnNoMicCheckBox)
end

function AutoBandWindowTools.OnClickAutoFormSearchLabel()
    AutoBandWindowTools.GenericLabelClickHandler("AutoFormSearchCheckBox", AutoBandWindowTools.OnAutoFormSearchCheckBox)
end
