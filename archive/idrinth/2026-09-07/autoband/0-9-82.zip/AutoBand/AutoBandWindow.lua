AutoBandWindow = {}

AutoBandWindow.name = "AutoBandWindow"
AutoBandWindow.mapicon_name = "AutoBandMapIcon"
AutoBandWindow.warband_disabled_label_name = AutoBandWindow.name .. "WarbandDisabledLabel"

AutoBandWindow.SelectedTab = AB_const.TABS_TOOLS

AutoBandWindow.Tabs = {}
AutoBandWindow.Tabs[ AB_const.TABS_TEMPLATE] = { button = "AutoBandWindowTabsTemplate", name = AutoBandWindowTemplate.name,
                            label = "Templates", show = AutoBandWindowTemplate.Show, hide = AutoBandWindowTemplate.Hide}
AutoBandWindow.Tabs[ AB_const.TABS_TOOLS] = { button = "AutoBandWindowTabsTools", name = AutoBandWindowTools.name,
                            label = "Tools", show = AutoBandWindowTools.Show, hide = AutoBandWindowTools.Hide}
AutoBandWindow.Tabs[ AB_const.TABS_CONFIG] = { button = "AutoBandWindowTabsConfig", name = AutoBandWindowConfig.name,
                            label = "Config", show = AutoBandWindowConfig.Show, hide = AutoBandWindowConfig.Hide}


local function is_warband_disabled()
    return type(AutoBand) == "table"
        and type(AutoBand.is_warband_enabled) == "function"
        and not AutoBand.is_warband_enabled()
end

local function get_tooltip_window_name()
    if SystemData and SystemData.ActiveWindow and SystemData.ActiveWindow.name then
        return SystemData.ActiveWindow.name
    end
    if SystemData and SystemData.MouseOverWindow and SystemData.MouseOverWindow.name then
        return SystemData.MouseOverWindow.name
    end
    return nil
end

local function show_text_tooltip(tooltip_text)
    if type(Tooltips) ~= "table" or type(Tooltips.CreateTextOnlyTooltip) ~= "function" then
        return
    end
    local window_name = get_tooltip_window_name()
    if not window_name or window_name == "" then
        return
    end
    local tooltip_value = tooltip_text
    if type(tooltip_value) == "string" and type(towstring) == "function" then
        tooltip_value = towstring(tooltip_value)
    end
    if type(Tooltips.SetTooltipText) == "function" then
        Tooltips.CreateTextOnlyTooltip(window_name)
        Tooltips.SetTooltipText(1, 1, tooltip_value)
        if type(Tooltips.Finalize) == "function" then
            Tooltips.Finalize()
        end
    else
        Tooltips.CreateTextOnlyTooltip(window_name, tooltip_value)
    end
    if type(Tooltips.AnchorTooltip) == "function" then
        Tooltips.AnchorTooltip(Tooltips.ANCHOR_WINDOW_TOP)
    end
end

local function hide_text_tooltip()
    if type(Tooltips) ~= "table" or type(Tooltips.DestroyTooltip) ~= "function" then
        return
    end
    local window_name = get_tooltip_window_name()
    if not window_name or window_name == "" then
        return
    end
    Tooltips.DestroyTooltip(window_name)
end

local function window_exists(name)
    if type(DoesWindowExist) ~= "function" then
        return true
    end
    local ok, exists = pcall(DoesWindowExist, name)
    return ok and exists == true
end

function AutoBandWindow.RefreshWarbandEnabledState()
    local disabled = is_warband_disabled()
    local title_label_name = AutoBandWindow.name .. "TitleBarText"
    if not window_exists(title_label_name) or not window_exists(AutoBandWindow.warband_disabled_label_name) then
        return false
    end
    LabelSetText(title_label_name, disabled and L"AutoBand - WB OFF" or L"AutoBand")
    LabelSetText(AutoBandWindow.warband_disabled_label_name, L"WB OFF")
    if type(LabelSetTextColor) == "function" then
        LabelSetTextColor(AutoBandWindow.warband_disabled_label_name, 255, 128, 64)
    end
    WindowSetShowing(AutoBandWindow.warband_disabled_label_name, disabled)
    return true
end

function AutoBandWindow.Initialize()
    AutoBandWindow.RefreshWarbandEnabledState()

    -- Tab Text
    AutoBandWindow.SetTabLabels()

    -- Show SelectedTab by default
    AutoBandWindow.show_selected_tab()

    -- display icon ?
    WindowSetShowing(AutoBandWindow.mapicon_name, AutoBand.saved.displayicon)
end

function AutoBandWindow.Hide()
    WindowSetShowing(AutoBandWindow.name, false)
end

function AutoBandWindow.Show()
    AutoBandWindow.RefreshWarbandEnabledState()
    WindowSetShowing(AutoBandWindow.name, true)
    AutoBandWindow.show_selected_tab()
end

function AutoBandWindow.OnWarbandDisabledMouseOver()
    if not is_warband_disabled() then
        return
    end
    show_text_tooltip(
        "Warband features are disabled.\n" ..
        "Warband events and automation are off.\n" ..
        "Settings and realm-rank CSV updates still work.\n" ..
        "Right-click for the icon menu or use /ab enable."
    )
end

function AutoBandWindow.OnWarbandDisabledMouseOverEnd()
    hide_text_tooltip()
end

function AutoBandWindow.OnWarbandDisabledRightClick()
    if not is_warband_disabled() then
        return
    end
    hide_text_tooltip()
    if type(AutoBand) == "table" and type(AutoBand.HandleIconRightClick) == "function" then
        AutoBand.HandleIconRightClick({ include_open_window = false })
    end
end

function AutoBandWindow.ShowConfigTab()
    AutoBandWindow.SelectedTab = AB_const.TABS_CONFIG
    if AutoBandWindow.showing() then
        AutoBandWindow.show_selected_tab()
        return
    end
    AutoBandWindow.Show()
end

function AutoBandWindow.showing()
    return WindowGetShowing(AutoBandWindow.name)
end

function AutoBandWindow.show_selected_tab()
    AutoBandWindow.HideTabAllElements()
    AutoBandWindow.Tabs[AutoBandWindow.SelectedTab].show()
    AutoBandWindow.SetHighlightedTabText(AutoBandWindow.SelectedTab)
end

function AutoBandWindow.toggle_mapicon(value)
    if (value == nil) then
        AutoBand.saved.displayicon = not WindowGetShowing(AutoBandWindow.mapicon_name)
    else
        AutoBand.saved.displayicon = value
    end
    WindowSetShowing(AutoBandWindow.mapicon_name, AutoBand.saved.displayicon)
end


---------------------------------------
-- Tab Controls
---------------------------------------

function AutoBandWindow.SetTabLabels()
    for _, tab in ipairs(AutoBandWindow.Tabs) do
        ButtonSetText(tab.button, towstring(tab.label))
    end
end

function AutoBandWindow.OnLButtonUpTab()
    local windowIndex = WindowGetId(SystemData.ActiveWindow.name)
    AutoBandWindow.SelectedTab = windowIndex
    AutoBandWindow.show_selected_tab()
end

function AutoBandWindow.HideTabAllElements()
    for _, tab in ipairs(AutoBandWindow.Tabs) do
        tab.hide()
    end
end

function AutoBandWindow.SetHighlightedTabText(tabNumber)
    for index, tab in ipairs(AutoBandWindow.Tabs) do
        ButtonSetPressedFlag(tab.button, index == tabNumber)
    end
end
