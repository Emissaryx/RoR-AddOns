--[[
This addon attempts to display the next cleanseable effect on any friendly target. It does it by recieving a list of effects from the server when switchting targets.
That list is in most circumstances ordered. Meaning that the oldest effect is first in the list. However if a debuff is reapplied while its still running than it replaces that effect in the list. 
Reapplied effects can therefore screw up the effect ordering since cleansing always removes the oldest effect. To avoid this the addon keeps a ordered effect list of the selected friendly target.
However this does not account for inaccurate ordering of the initial effect list upon target selection.
--]]


CB = CB or {}
local next = next
local effectIndexList = {}
local effectIconList = {}
local cnt = 1
local oldestEffect = 100000000
local canCleanseHex = ""
local canCleanseAilment = ""
local canCleanseCurse = ""
local currentTarget = 10000
local playerCareer = 0

--this will run on start
function CB.OnInitialize()
	RegisterEventHandler(SystemData.Events.LOADING_END,							"CB.EndLoading")
	RegisterEventHandler(SystemData.Events.PLAYER_TARGET_UPDATED,				"CB.PlayerTargetsUpdated")
	RegisterEventHandler(SystemData.Events.PLAYER_TARGET_EFFECTS_UPDATED,		"CB.PlayerTargetsEffectsUpdated")

	CreateWindow("CBMainWindow", true)
	LayoutEditor.RegisterWindow( "CBMainWindow", L"CB", L"Cleansing Buddy", true, true, false, nil)
end

-- bit of a workaround because there were some issue during intialization
function CB.EndLoading()
	if DoesWindowExist("NextCleanse") then DestroyWindow("NextCleanse") end	-- should remove artifacts when leaving/joining sc/city
	
	if playerCareer == 0 then 
		local playerCareer = GameData.Player.career.line -- this call results in 0 if its called during intialization resulting in the addon not properly loading
		
		-- define cleanseable effect types
		if (playerCareer == GameData.CareerLine.WARRIOR_PRIEST or playerCareer == GameData.CareerLine.ZEALOT) then
			canCleanseHex = true
			canCleanseAilment = false
			canCleanseCurse = true
		elseif (playerCareer == GameData.CareerLine.DISCIPLE or playerCareer == GameData.CareerLine.ARCHMAGE) then
			canCleanseHex = true
			canCleanseAilment = true
			canCleanseCurse = false
		elseif (playerCareer == GameData.CareerLine.SHAMAN or playerCareer == GameData.CareerLine.RUNE_PRIEST) then
			canCleanseHex = false
			canCleanseAilment = true
			canCleanseCurse = true
		else -- this addon will do nothing for you
			CB.OnShutdown()
			return
		end
	end
end

--this will run on exit
function CB.OnShutdown()	
	UnregisterEventHandler(SystemData.Events.LOADING_END,						"CB.EndLoading")
	UnregisterEventHandler(SystemData.Events.PLAYER_TARGET_UPDATED,				"CB.PlayerTargetsUpdated")
	UnregisterEventHandler(SystemData.Events.PLAYER_TARGET_EFFECTS_UPDATED,		"CB.PlayerTargetsEffectsUpdated")
	if DoesWindowExist("NextCleanse") then DestroyWindow("NextCleanse") end
end


-- reset effects after target swap
function CB.PlayerTargetsUpdated(targetClassification,targetId,targetType)
	if(targetClassification == "selffriendlytarget") and (currentTarget ~= targetId) then
		effectIndexList = {}
		effectIconList = {}
		cnt = 1
		currentTarget = targetId
	end
end

-- keeps track of cleanseable effects
function CB.PlayerTargetsEffectsUpdated(targetType,BuffTable,isFullList)
	if targetType ~= 8 or BuffTable == nil then return end -- 8 Friendly
	
	for effectIndex, keys in pairs(BuffTable) do
		if keys.name == nil then -- the server sends an empty table so signal that an effect has ended. when an effect gets reapplied while it still has duration left it sends an empty table first.
			-- removing old effects from the list keeps it short however it loses its sorting
			effectIndexList[effectIndex] = nil
			effectIconList[effectIndex] = nil
			CB.UpdateIconDisplay()
		elseif (keys.isAilment == canCleanseAilment) or (keys.isCurse == canCleanseCurse) or (keys.isHex == canCleanseHex) then --keys.isBlessing == true then
			-- using a simple counter to keep track of the oldest active effects
			effectIndexList[effectIndex] = cnt
			effectIconList[effectIndex] = keys.iconNum	
			cnt = cnt + 1
			CB.UpdateIconDisplay()
		end
	end
end

function CB.UpdateIconDisplay()
	if next(effectIndexList) == nil then -- destory the window if there are no cleanseable effects
		if DoesWindowExist("NextCleanse") then DestroyWindow("NextCleanse") else return end	 
	else
		-- find oldest effect
		oldestEffect = 100000000
		for effectIndex, i in pairs(effectIndexList) do
			if i < oldestEffect then 
				oldestEffect = i
				oldestEffectIndex = effectIndex
			end
		end
		if not DoesWindowExist("NextCleanseIcon") then CreateWindowFromTemplate("NextCleanse", "CBBuffTemplate", "CBMainWindow") end
		local texture, x, y, disabledTexture = GetIconData(effectIconList[oldestEffectIndex])
		DynamicImageSetTexture("NextCleanseIcon", texture, x, y)
	end
end

