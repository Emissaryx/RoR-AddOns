<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
    <UiMod name="CleansingBuddy" version="1.1.0" date="09/15/2023">
        <Author name="Cimba" />
        <Description text="This addon displays the debuff that you will probably cleanse next" />
 
        <Files>
            <File name="CleansingBuddy.lua" />
			<File name="CleansingBuddy.xml" />
        </Files>
		
        <OnInitialize>
            <CallFunction name="CB.OnInitialize" />
        </OnInitialize>
		
		<SavedVariables>
		</SavedVariables>

		<OnUpdate>
    	</OnUpdate>

        <OnShutdown>
			<CallFunction name="CB.OnShutdown" />
		</OnShutdown>
		
		<WARInfo>
			<Categories>
				<Category name="BUFFS_DEBUFFS" />
			</Categories>
			<Careers>
				<Career name="DISCIPLE" />
				<Career name="RUNE_PRIEST" />
				<Career name="SHAMAN" />
				<Career name="WARRIOR_PRIEST" />
				<Career name="ZEALOT" />
				<Career name="ARCHMAGE" />
			</Careers>
		</WARInfo>
    </UiMod>
</ModuleFile>