local firstLoad = true
local firstLoadMessage=true
local oldEA_ChatWindowOnPlayerLinkLButtonUp = nil
local oldEA_ChatWindowOnPlayerLinkRButtonUp = nil
local oldEA_ChatWindowOnRButtonDownProcessed = nil
local oldEA_ChatWindowOnRButtonDown = nil
local oldEA_ChatWindowCreateDefaultContextMenu = nil

local levelChanged=false;
local masteryChanged=false;

local cacheCareer=GameData.Player.career.line


local data  = L""
local text  = L"[QNA+] "
local color = DefaultColor.GREEN
local link  = CreateHyperLink( data, text, {color.r,color.g,color.b}, {} )

local chanInfo=L""
local chanInfo2=L""
local discordURL=L""

--local oldQNAmessage=""
--local oldQNAmasteryMessage=""

local changedTellMessage=false;
local changedTellMessage2=false;

local changedChatMessage=false;
local changedChatMessage2=false;

if not QuickNameActionsRessurected then
  QuickNameActionsRessurected = {}
  QuickNameActionsRessurected.discord=L""
  QuickNameActionsRessurected.tellMessage1 = L"x"
  QuickNameActionsRessurected.tellMessage2 = L"xx"
  QuickNameActionsRessurected.chatMessage1 = L"LFG BS"
  QuickNameActionsRessurected.chatMessage1Channel=L"/5"
  QuickNameActionsRessurected.chatMessage2 = L"LFG BB/BE"
  QuickNameActionsRessurected.chatMessage2Channel=L"/5"
  QuickNameActionsRessurected.smartChannel1=false;
  QuickNameActionsRessurected.smartChannel2=false;
  QuickNameActionsRessurected.GuildLink=L"Guildless"
  QuickNameActionsRessurected.oldQNAmessage=L""
  QuickNameActionsRessurected.oldQNAmasteryMessage=L""
  QuickNameActionsRessurected.discord=L""
  QuickNameActionsRessurected.firstLoadMessage=false;
  QuickNameActionsRessurected.Career=nil

  QuickNameActionsRessurected.careerToArchetype =
  {
    [GameData.CareerLine.IRON_BREAKER] = L"IB",
    [GameData.CareerLine.SWORDMASTER] = L"SM",
    [GameData.CareerLine.CHOSEN] = L"CH",
    [GameData.CareerLine.BLACK_ORC] = L"BO",
    [GameData.CareerLine.KNIGHT] = L"KOTBS",
    [GameData.CareerLine.BLACKGUARD] = L"BG",

    [GameData.CareerLine.WITCH_HUNTER] = L"WH",
    [GameData.CareerLine.WHITE_LION] = L"WL",
    [GameData.CareerLine.MARAUDER] = L"MRD",
    [GameData.CareerLine.WITCH_ELF] = L"WE",
    [GameData.CareerLine.BRIGHT_WIZARD] = L"BW",
    [GameData.CareerLine.MAGUS] = L"MAG",
    [GameData.CareerLine.SORCERER] = L"SRC",
    [GameData.CareerLine.ENGINEER] = L"ENG",
    [GameData.CareerLine.SHADOW_WARRIOR] = L"SW",
    [GameData.CareerLine.SQUIG_HERDER] = L"SH",
    [GameData.CareerLine.CHOPPA] = L"CHP",
    [GameData.CareerLine.SLAYER or GameData.CareerLine.HAMMERER] = L"SLA",

    [GameData.CareerLine.WARRIOR_PRIEST] = L"WP",
    [GameData.CareerLine.DISCIPLE] = L"DOK",
    [GameData.CareerLine.ARCHMAGE] = L"AM",
    [GameData.CareerLine.SHAMAN] = L"SHA",
    [GameData.CareerLine.RUNE_PRIEST] = L"RP",
    [GameData.CareerLine.ZEALOT] = L"ZEL"
  }

  QuickNameActionsRessurected.careerToArchetype2 =
  {
    [GameData.CareerLine.IRON_BREAKER] = "tanks",
    [GameData.CareerLine.SWORDMASTER] = "tanks",
    [GameData.CareerLine.CHOSEN] = "tanks",
    [GameData.CareerLine.BLACK_ORC] = "tanks",
    [GameData.CareerLine.KNIGHT] = "tanks",
    [GameData.CareerLine.BLACKGUARD] = "tanks",

    [GameData.CareerLine.WITCH_HUNTER] = "mdps",
    [GameData.CareerLine.WHITE_LION] = "mdps",
    [GameData.CareerLine.MARAUDER] = "mdps",
    [GameData.CareerLine.WITCH_ELF] = "mdps",
    [GameData.CareerLine.BRIGHT_WIZARD] = "rdps",
    [GameData.CareerLine.MAGUS] = "rdps",
    [GameData.CareerLine.SORCERER] = "rdps",
    [GameData.CareerLine.ENGINEER] = "rdps",
    [GameData.CareerLine.SHADOW_WARRIOR] = "rdps",
    [GameData.CareerLine.SQUIG_HERDER] = "rdps",
    [GameData.CareerLine.CHOPPA] = "mdps",
    [GameData.CareerLine.SLAYER or GameData.CareerLine.HAMMERER] = "mdps",

    [GameData.CareerLine.WARRIOR_PRIEST] = "healers",
    [GameData.CareerLine.DISCIPLE] = "healers",
    [GameData.CareerLine.ARCHMAGE] = "healers",
    [GameData.CareerLine.SHAMAN] = "healers",
    [GameData.CareerLine.RUNE_PRIEST] = "healers",
    [GameData.CareerLine.ZEALOT] = "healers"
  }
end




function QuickNameActionsRessurected.Initialize()
  RegisterEventHandler(SystemData.Events.LOADING_END, "QuickNameActionsRessurected.OnLoad")
  RegisterEventHandler(SystemData.Events.RELOAD_INTERFACE, "QuickNameActionsRessurected.OnLoad")
  RegisterEventHandler(SystemData.Events.ALL_MODULES_INITIALIZED, "QuickNameActionsRessurected.OnLoadFull")

  RegisterEventHandler(SystemData.Events.PLAYER_CAREER_RANK_UPDATED, "QuickNameActionsRessurected.OnLevel")
  RegisterEventHandler(SystemData.Events.PLAYER_RENOWN_RANK_UPDATED, "QuickNameActionsRessurected.OnLevel")

  RegisterEventHandler(SystemData.Events.PLAYER_CAREER_CATEGORY_UPDATED, "QuickNameActionsRessurected.OnRespec")


  --check for libslash
  QuickNameActionsRessurected.LibSlashCheck()

  --register commands
  if QuickNameActionsRessurected.LibSlashCheck() == true then
    LibSlash.RegisterSlashCmd("qna", function() QuickNameActionsRessurected.Slash("qna") end)
    LibSlash.RegisterSlashCmd("qnachat", function(input) QuickNameActionsRessurected.Slash( "qnachat", input ) end)
    LibSlash.RegisterSlashCmd("qnatell", function(input) QuickNameActionsRessurected.Slash( "qnatell", input ) end)
      LibSlash.RegisterSlashCmd("qnadisc", function(input) QuickNameActionsRessurected.Slash( "qnadisc", input ) end)
      LibSlash.RegisterSlashCmd("qnamsg", function() QuickNameActionsRessurected.Slash( "qnamsg") end)
  else return
  end
end


function QuickNameActionsRessurected.setHook()
  if oldEA_ChatWindowOnPlayerLinkLButtonUp == nil then

    --social search hook left button
    oldEA_ChatWindowOnPlayerLinkLButtonUp = EA_ChatWindow.OnPlayerLinkLButtonUp
    --send player tell hook button
    oldEA_ChatWindowOnPlayerLinkRButtonUp = EA_ChatWindow.OnPlayerLinkRButtonUp
    --quick chat send msg button
    oldEA_ChatWindowOnRButtonDown = EA_ChatWindow.OnRButtonDown
    --discord link button
    oldEA_ChatWindowOnTomeLinkLButtonUp = EA_ChatWindow.OnTomeLinkLButtonUp
    --defaulting behaiour of discord links to tome link
    oldEA_ChatWindowOnHyperLinkLButtonUp=EA_ChatWindow.OnHyperLinkLButtonUp
    --menu hook
    oldEA_ChatWindowOnOpenChatMenu = EA_ChatWindow.OnOpenChatMenu

    EA_ChatWindow.OnPlayerLinkLButtonUp = QuickNameActionsRessurected.newEA_ChatWindowOnPlayerLinkLButtonUp
    EA_ChatWindow.OnPlayerLinkRButtonUp = QuickNameActionsRessurected.newEA_ChatWindowOnPlayerLinkRButtonUp
    EA_ChatWindow.OnRButtonDown = QuickNameActionsRessurected.newEA_ChatWindowOnRButtonDown
    EA_ChatWindow.OnTomeLinkLButtonUp = QuickNameActionsRessurected.newEA_ChatWindowOnTomeLinkLButtonUp
    EA_ChatWindow.OnHyperLinkLButtonUp = QuickNameActionsRessurected.newEA_ChatWindowOnHyperLinkLButtonUp
    EA_ChatWindow.OnOpenChatMenu    = QuickNameActionsRessurected.newEA_ChatWindowOnOpenChatMenu
  end
end


--add QNA+ menu
function QuickNameActionsRessurected.newEA_ChatWindowOnOpenChatMenu(...)
  oldEA_ChatWindowOnOpenChatMenu(...)
  EA_Window_ContextMenu.AddCascadingMenuItem( L"QNA+", QuickNameActionsRessurected.MenuDisplay, false, 1 )
  EA_Window_ContextMenu.Finalize(EA_Window_ContextMenu.CONTEXT_MENU_1)
end


local function SocialSearcher(playerName)
  local tableSub = { - 1}
  return SendPlayerSearchRequest(L""..playerName, L"", L"", tableSub, 0, 40, false)
end

--if we find discord.gg link, default behaviour to new tomeLinkButtonUp else old()
function QuickNameActionsRessurected.newEA_ChatWindowOnHyperLinkLButtonUp( linkData, flags, x, y )
  local WWW      = L"discord"
  local tomeLinkText = wstring.match( linkData, WWW )
  if tomeLinkText
  then
     QuickNameActionsRessurected.newEA_ChatWindowOnTomeLinkLButtonUp( linkData, flags, x, y )
     return
  end
 oldEA_ChatWindowOnHyperLinkLButtonUp( linkData, flags, x, y )
end


--click discord.gg link to insert into your chat
function QuickNameActionsRessurected.newEA_ChatWindowOnTomeLinkLButtonUp( linkData, flags, x, y )
  if( WindowGetShowing( "EA_TextEntryGroupEntryBox" ) == false )
  then
      EA_ChatWindow.SwitchChannelWithExistingText( linkData)
  else
  TextEditBoxInsertText( "EA_TextEntryGroupEntryBoxTextInput", linkData )
  end

end


function QuickNameActionsRessurected.newEA_ChatWindowOnPlayerLinkLButtonUp(playerName, flags, x, y )
  --left click hook for player links
if flags==4 then
  --shift to social search
  SocialSearcher(playerName)
elseif flags==8 then
  --ctrl to invite to group
  SendChatText(L"/invite "..playerName, L"")
elseif flags==32 then
  --alt to friend list
  SendChatText(L"/friend "..playerName, L"")
else
  --old
  oldEA_ChatWindowOnPlayerLinkLButtonUp(playerName, flags, x, y )
end
end

function QuickNameActionsRessurected.newEA_ChatWindowOnPlayerLinkRButtonUp(playerName, flags, x, y, wndGroupId)
local tellmsg1 = QuickNameActionsRessurected.tellMessage1
local tellmsg2 = QuickNameActionsRessurected.tellMessage2

if flags==8 then
  --ctrl right click to join group
  SendChatText(L"/join "..playerName, L"")
elseif flags==4 then
  --shift right click to tellmsg1
  SendChatText(L"/tell "..playerName..L" "..towstring(tellmsg1), L"")
elseif flags==32 then
  --alt right click to tellmsg2
  SendChatText(L"/tell "..playerName..L" "..towstring(tellmsg2), L"")
else
  --old behaviour
  oldEA_ChatWindowOnPlayerLinkRButtonUp(playerName, flags, x, y, wndGroupId)
end
end


function QuickNameActionsRessurected.newEA_ChatWindowOnRButtonDown(flags)
  -- main chat window function for msgs
  local chatText = QuickNameActionsRessurected.chatMessage1
  local chatChan = QuickNameActionsRessurected.chatMessage1Channel
  local chatText2 = QuickNameActionsRessurected.chatMessage2
  local chatChan2 = QuickNameActionsRessurected.chatMessage2Channel

--if ctrl+alt pressed then send msg1
  if flags == 40 then
    if QuickNameActionsRessurected.smartChannel1 then
      if chatChan ~= ChatSettings.Channels[EA_ChatWindow.prevChannel].serverCmd then
        chatChan = ChatSettings.Channels[EA_ChatWindow.prevChannel].serverCmd
      end
        SendChatText(towstring(chatText), towstring(chatChan))
    elseif not QuickNameActionsRessurected.smartChannel then
      SendChatText(towstring(chatText), towstring(chatChan))
    end
    --if ctrl+shift then send msg2
  elseif flags == 36 then
    if QuickNameActionsRessurected.smartChannel2 then
      if chatChan ~= ChatSettings.Channels[EA_ChatWindow.prevChannel].serverCmd then
        chatChan = ChatSettings.Channels[EA_ChatWindow.prevChannel].serverCmd
      end
        SendChatText(towstring(chatText2), towstring(chatChan2))
    elseif not QuickNameActionsRessurected.smartChannel then
      SendChatText(towstring(chatText2), towstring(chatChan2))
    end
  else
    oldEA_ChatWindowOnRButtonDown ()
  end
end


local function ChannelInfo1()
  if QuickNameActionsRessurected.smartChannel1 then
    chanInfo=L"smart"
  elseif not QuickNameActionsRessurected.smartChannel1 then
    chanInfo=QuickNameActionsRessurected.chatMessage1Channel
  end
  return chanInfo
end

local function ChannelInfo2()
  if QuickNameActionsRessurected.smartChannel2 then
    chanInfo2=L"smart"
  elseif not QuickNameActionsRessurected.smartChannel2 then
    chanInfo2=QuickNameActionsRessurected.chatMessage2Channel
  end
  return chanInfo2
end

local function ChannelInfo()
  ChannelInfo1()
  ChannelInfo2()
end


--grab all info on load
function QuickNameActionsRessurected.OnLoad()
if firstLoad == true then
  QuickNameActionsRessurected.setHook()
end
end

local function OnEnterOnce()
  if firstLoad then return end
  QuickNameActionsRessurected.MessageMaker()
  QuickNameActionsRessurected.MasteryMessageMaker()
  firstLoad = true;
  firstLoadMessage=false;
end

function QuickNameActionsRessurected.OnLoadFull()
  if not firstLoad then return end
  if firstLoad == true then
  firstLoad = false
  if careerCache==nil or careerCache~=GameData.Player.career.line then
  OnEnterOnce()
end
end
end


--update level count
function QuickNameActionsRessurected.OnLevel()
  if firstLoadMessage then return end
  levelChanged=true;
  QuickNameActionsRessurected.MessageMaker()
end

--update respec count
function QuickNameActionsRessurected.OnRespec()
  if firstLoadMessage then return end
  masteryChanged=true;
  QuickNameActionsRessurected.MasteryMessageMaker()
end

--dumb menu
function QuickNameActionsRessurected.MenuDisplay()

  --get channel info to display for now
  --this whole menu is really stupid but I am too lazy to do a proper GUI and I'd rather have this ugly looking thing and use commands myyself, I'm sorry

  ChannelInfo()

  --create stuff
  EA_Window_ContextMenu.CreateContextMenu( "EA_TextEntryGroup", 2, L"" )
  EA_Window_ContextMenu.AddMenuItem( L"Player Link Actions", nil, false, true, 2 )
  EA_Window_ContextMenu.AddMenuDivider (2)
  EA_Window_ContextMenu.AddMenuItem( L"CTRL+LEFT - Group Invite", nil, false, true, 2 )
  EA_Window_ContextMenu.AddMenuItem( L"CTRL+RIGHT - Join Group", nil, false, true, 2 )
  EA_Window_ContextMenu.AddMenuItem( L"SHIFT+LEFT - Social Search", nil, false, true, 2 )
  EA_Window_ContextMenu.AddMenuItem( L"ALT+LEFT - Add/Remove Friend",nil, false, true,2 )
  EA_Window_ContextMenu.AddMenuItem( L"SHIFT+RIGHT - Tell MSG1", nil, false, true, 2 )
  EA_Window_ContextMenu.AddMenuItem( L"ALT+RIGHT - Tell MSG2", nil, false, true, 2 )
  EA_Window_ContextMenu.AddMenuDivider (2)
  EA_Window_ContextMenu.AddMenuItem( L"Chat Window Actions", nil, false, true, 2 )
  EA_Window_ContextMenu.AddMenuDivider (2)
  EA_Window_ContextMenu.AddMenuItem( L"CTRL+ALT - Chat MSG1", nil, false, true, 2 )
  EA_Window_ContextMenu.AddMenuItem( L"CTRL+SHIFT - Chat MSG2", nil, false, true, 2 )
  EA_Window_ContextMenu.AddMenuDivider (2)
  EA_Window_ContextMenu.AddMenuItem( towstring("QNA+ Chat MSG1 CH: "..tostring(chanInfo)), nil, false, true, EA_Window_ContextMenu.CONTEXT_MENU_2)
  EA_Window_ContextMenu.AddMenuItem( towstring("QNA+ Chat MSG2 CHl: "..tostring(chanInfo2)), nil, false, true, EA_Window_ContextMenu.CONTEXT_MENU_2)
  EA_Window_ContextMenu.AddMenuDivider (2)
  EA_Window_ContextMenu.Finalize( 2, nil )
  --finalize stuff
end


function QuickNameActionsRessurected.OnShutdown()
  --shutdown unregister
UnregisterEventHandler(SystemData.Events.LOADING_END, "QuickNameActionsRessurected.OnLoad")
UnregisterEventHandler(SystemData.Events.RELOAD_INTERFACE, "QuickNameActionsRessurected.OnLoad")
UnregisterEventHandler(SystemData.Events.ALL_MODULES_INITIALIZED, "QuickNameActionsRessurected.OnLoadFull")

UnregisterEventHandler(SystemData.Events.PLAYER_CAREER_RANK_UPDATED, "QuickNameActionsRessurected.OnLevel")
UnregisterEventHandler(SystemData.Events.PLAYER_RENOWN_RANK_UPDATED, "QuickNameActionsRessurected.OnLevel")

UnegisterEventHandler(SystemData.Events.PLAYER_CAREER_CATEGORY_UPDATED, "QuickNameActionsRessurected.OnRespec")
end



--create first message
function QuickNameActionsRessurected.MessageMaker()
  local career=GameData.Player.career.line
  if QuickNameActionsRessurected.Career~=careerCache then
  career = QuickNameActionsRessurected.Career
  end
local QNAiconID = L"<icon"..Icons.GetCareerIconIDFromCareerLine (career)..L">"
local QNAcareerName = QuickNameActionsRessurected.careerToArchetype[career]
local QNArenownLevel = GameData.Player.Renown.curRank
local QNArankLevel = GameData.Player.level
local QNArankID = L"<icon41>"
local QNArenownID = L"<icon45>"


QNAmessage = QNAiconID..L" "..QNAcareerName..L" "..QNArankID..L" "..QNArankLevel..L" "..QNArenownID..L" "..QNArenownLevel

if levelChanged then
  QuickNameActionsRessurected.MessageChanger()
  levelChanged=false;
end
newQNAmessage=QNAmessage
end

function QuickNameActionsRessurected.MasteryMessageMaker()
  local career=GameData.Player.career.line
  if QuickNameActionsRessurected.Career~=careerCache then
  career = QuickNameActionsRessurected.Career
  end
  local QNArole = QuickNameActionsRessurected.careerToArchetype2[career]

  local QNAtankIcon = L"<icon26>"
  local QNAdpsIcon = L"<icon24>"
  local QNAhealIcon = L"<icon23>"
  local QNAicon = L""
  if QNArole == "healers" then QNAicon = QNAhealIcon end
  if QNArole == "tanks" then QNAicon = QNAtankIcon end
  if QNArole == "rdps" or QNArole == "mdps" then QNAicon = QNAdpsIcon end

  EA_Window_InteractionSpecialtyTraining.LoadAdvances()
  QNAmasteryMessage = (tostring(QNAicon).." "..EA_Window_InteractionSpecialtyTraining.initialSpecializationLevels[1].."/"..EA_Window_InteractionSpecialtyTraining.initialSpecializationLevels[2].."/"..EA_Window_InteractionSpecialtyTraining.initialSpecializationLevels[3])
  newQNAmasteryMessage=QNAmasteryMessage


  if masteryChanged then
    QuickNameActionsRessurected.MessageChanger()
    masteryChanged=false;
  end

end



--set discord text and substitute everywhere
function QuickNameActionsRessurected.SetDiscordText(input)
  discordURL=QuickNameActionsRessurected.discord
  local regex = wstring.match(towstring(input), L"\^\%s")
  input = towstring(input)
  if input == L"" or input == nil or regex then
    EA_ChatWindow.Print(link..L"Current discord link is: "..towstring(QuickNameActionsRessurected.DiscordLinker()))
  else
  QuickNameActionsRessurected.discorder=input
  EA_ChatWindow.Print(link..L"New discord link is: "..towstring(QuickNameActionsRessurected.DiscordLinker()))
  if QuickNameActionsRessurected.tellMessage1~=wstring.match(QuickNameActionsRessurected.tellMessage1,QuickNameActionsRessurected.discord)
  then
    QuickNameActionsRessurected.tellMessage1 = wstring.gsub((QuickNameActionsRessurected.tellMessage1),towstring(discordURL), towstring(QuickNameActionsRessurected.DiscordLinker()))
  end
  if QuickNameActionsRessurected.tellMessage2~=wstring.match(QuickNameActionsRessurected.tellMessage2,QuickNameActionsRessurected.discord)
  then
    QuickNameActionsRessurected.tellMessage2 = wstring.gsub((QuickNameActionsRessurected.tellMessage2),towstring(discordURL), towstring(QuickNameActionsRessurected.DiscordLinker()))
  end
  if QuickNameActionsRessurected.chatMessage1~=wstring.match(QuickNameActionsRessurected.chatMessage1,QuickNameActionsRessurected.discord)
  then
    QuickNameActionsRessurected.chatMessage1 = wstring.gsub((QuickNameActionsRessurected.chatMessage1),towstring(discordURL), towstring(QuickNameActionsRessurected.DiscordLinker()))
  end
  if QuickNameActionsRessurected.chatMessage2~=wstring.match(QuickNameActionsRessurected.chatMessage2,QuickNameActionsRessurected.discord)
  then
    QuickNameActionsRessurected.chatMessage2 = wstring.gsub((QuickNameActionsRessurected.chatMessage2),towstring(discordURL), towstring(QuickNameActionsRessurected.DiscordLinker()))
  end
end
  return QuickNameActionsRessurected.DiscordLinker()
end



function QuickNameActionsRessurected.QNAmessage()
  QuickNameActionsRessurected.oldQNAmessage=QNAmessage
  if firstLoadMessage then
  QuickNameActionsRessurected.Career=GameData.Player.career.line
  end
  if (GameData.Player.career.line)~=cacheCareer then
    QuickNameActionsRessurected.MessageMaker()
  end
  return (QNAmessage)
end

function QuickNameActionsRessurected.QNAmastery()
  QuickNameActionsRessurected.oldQNAmasteryMessage=QNAmasteryMessage
  if firstLoadMessage then
  QuickNameActionsRessurected.Career=GameData.Player.career.line
  end
  if (GameData.Player.career.line)~=cacheCareer then
    QuickNameActionsRessurected.Career=GameData.Player.career.line
    QuickNameActionsRessurected.MasteryMessageMaker()
  end
  return (QNAmasteryMessage)
end



function QuickNameActionsRessurected.MessageChanger()
  local oldQNAmasteryMessage=QuickNameActionsRessurected.oldQNAmasteryMessage
  local oldQNAmessage=QuickNameActionsRessurected.oldQNAmessage
  if QuickNameActionsRessurected.tellMessage2==wstring.match(QuickNameActionsRessurected.tellMessage2,towstring(oldQNAmasteryMessage)) or QuickNameActionsRessurected.tellMessage2~=wstring.match(QuickNameActionsRessurected.tellMessage2,towstring(oldQNAmasteryMessage))
  then
    QuickNameActionsRessurected.tellMessage1 = wstring.gsub((QuickNameActionsRessurected.tellMessage1),towstring(oldQNAmasteryMessage), towstring(QuickNameActionsRessurected.QNAmastery()))
  end
  if QuickNameActionsRessurected.tellMessage2==wstring.match(QuickNameActionsRessurected.tellMessage2,towstring(oldQNAmasteryMessage)) or QuickNameActionsRessurected.tellMessage2~=wstring.match(QuickNameActionsRessurected.tellMessage2,towstring(oldQNAmasteryMessage))
  then
    QuickNameActionsRessurected.tellMessage2 = wstring.gsub((QuickNameActionsRessurected.tellMessage2),towstring(oldQNAmasteryMessage), towstring(QuickNameActionsRessurected.QNAmastery()))
  end
  if QuickNameActionsRessurected.chatMessage1==wstring.match(QuickNameActionsRessurected.chatMessage1,towstring(oldQNAmasteryMessage)) or QuickNameActionsRessurected.chatMessage1~=wstring.match(QuickNameActionsRessurected.chatMessage1,towstring(oldQNAmasteryMessage))
  then
    QuickNameActionsRessurected.chatMessage1 = wstring.gsub((QuickNameActionsRessurected.chatMessage1),towstring(oldQNAmasteryMessage), towstring(QuickNameActionsRessurected.QNAmastery()))
  end
  if QuickNameActionsRessurected.chatMessage2==wstring.match(QuickNameActionsRessurected.chatMessage2,towstring(oldQNAmasteryMessage)) or QuickNameActionsRessurected.chatMessage2~=wstring.match(QuickNameActionsRessurected.chatMessage2,towstring(oldQNAmasteryMessage))
  then
    QuickNameActionsRessurected.chatMessage2 = wstring.gsub((QuickNameActionsRessurected.chatMessage2),towstring(oldQNAmasteryMessage), towstring(QuickNameActionsRessurected.QNAmastery()))
  end

  if QuickNameActionsRessurected.tellMessage1==wstring.match(QuickNameActionsRessurected.tellMessage1,towstring(oldQNAmessage)) or QuickNameActionsRessurected.tellMessage1~=wstring.match(QuickNameActionsRessurected.tellMessage1,towstring(oldQNAmessage))
  then
    QuickNameActionsRessurected.tellMessage1 = wstring.gsub((QuickNameActionsRessurected.tellMessage1),towstring(oldQNAmessage), towstring(QuickNameActionsRessurected.QNAmessage()))
  end
  if QuickNameActionsRessurected.tellMessage2==wstring.match(QuickNameActionsRessurected.tellMessage2,towstring(oldQNAmessage)) or QuickNameActionsRessurected.tellMessage2~=wstring.match(QuickNameActionsRessurected.tellMessage2,towstring(oldQNAmessage))
  then
    QuickNameActionsRessurected.tellMessage2 = wstring.gsub((QuickNameActionsRessurected.tellMessage2),towstring(oldQNAmessage), towstring(QuickNameActionsRessurected.QNAmessage()))
  end
  if QuickNameActionsRessurected.chatMessage1==wstring.match(QuickNameActionsRessurected.chatMessage1,towstring(oldQNAmessage)) or QuickNameActionsRessurected.chatMessage1~=wstring.match(QuickNameActionsRessurected.chatMessage1,towstring(oldQNAmessage))
  then
    QuickNameActionsRessurected.chatMessage1 = wstring.gsub((QuickNameActionsRessurected.chatMessage1),towstring(oldQNAmessage), towstring(QuickNameActionsRessurected.QNAmessage()))
  end
  if QuickNameActionsRessurected.chatMessage2==wstring.match(QuickNameActionsRessurected.chatMessage2,towstring(oldQNAmessage)) or QuickNameActionsRessurected.chatMessage2~=wstring.match(QuickNameActionsRessurected.chatMessage2,towstring(oldQNAmessage))
  then
    QuickNameActionsRessurected.chatMessage2 = wstring.gsub((QuickNameActionsRessurected.chatMessage2),towstring(oldQNAmessage), towstring(QuickNameActionsRessurected.QNAmessage()))
  end
end



function QuickNameActionsRessurected.DiscordLinker()
  --prints your discord
  local linkData = tostring("discord.gg/"..tostring(QuickNameActionsRessurected.discorder))
  local data  = linkData
  local text  = linkData
  local color = DefaultColor.LIGHT_BLUE
  local link  = CreateHyperLink( towstring(data), towstring(text), {color.r,color.g,color.b}, {} )
  QuickNameActionsRessurected.discord=link
  return QuickNameActionsRessurected.discord
end


function QuickNameActionsRessurected.PrintOptions()
  EA_ChatWindow.Print(link..L"Current quick-tell message [1] is: "..towstring(QuickNameActionsRessurected.tellMessage1))
  EA_ChatWindow.Print(link..towstring("Current quick-chat message [1 "..tostring(QuickNameActionsRessurected.chatMessage1Channel).."] is: "..tostring(QuickNameActionsRessurected.chatMessage1)))
  EA_ChatWindow.Print(link..L"/qnatell text#num -  to set a new quick-tell message.\n(num 1 or 2 to save as message 1 or 2)")
  EA_ChatWindow.Print(link..L"/qnachat text#/channel#num - to set a new quick-chat message.\n(smart for smart channel mode, num 1 or 2 to save as message 1 or 2)")
  EA_ChatWindow.Print(link..L"/qnadisc text - to set a new discord link. (Usage: /qnadisc wxKdoPl)")
  EA_ChatWindow.Print(link..L"/qnamsg - to see your QNA messages")
end




local function NameMapper(input)
  input = wstring.gsub((input),L"\$discord", towstring(QuickNameActionsRessurected.DiscordLinker()))
  input = wstring.gsub((input),L"\$guild", towstring(QuickNameActionsRessurected.GuildLinker()))
  input = wstring.gsub((input),L"\$level", towstring(QuickNameActionsRessurected.QNAmessage()))
  input = wstring.gsub((input),L"\$mastery", towstring(QuickNameActionsRessurected.QNAmastery()))
  --return
if changedTellMessage then
  QuickNameActionsRessurected.tellMessage1 = input
elseif changedTellMessage2 then
  QuickNameActionsRessurected.tellMessage2 = input
elseif changedChatMessage then
  QuickNameActionsRessurected.chatMessage1 = input
elseif changedChatMessage2 then
  QuickNameActionsRessurected.chatMessage2 = input
end
end


function QuickNameActionsRessurected.SetText(input, messageNumber)
local regex = wstring.match(towstring(input), L"\^\%s")
local qnaSplit = StringSplit(tostring(input), "#")
local input = towstring(qnaSplit[1])
local messageNumber = towstring(qnaSplit[2])

if input == L"" or input == nil or regex then
  EA_ChatWindow.Print(link..L"Current quick-tell message [1] is: "..towstring(QuickNameActionsRessurected.tellMessage1))
  EA_ChatWindow.Print(link..L"Current quick-tell message [2] is: "..towstring(QuickNameActionsRessurected.tellMessage2))
  EA_ChatWindow.Print(link..L"Available message functions are $level, $mastery, $guild and $discord.")
  EA_ChatWindow.Print(link..L"Example usage: /qnatell $level - x - $mastery#2")
else
  if messageNumber==L"1" or not qnaSplit[2] then
  changedTellMessage = true;
  NameMapper(input)
  --QuickNameActionsRessurected.MessageChanger()
  EA_ChatWindow.Print(link..L"Quick-tell message [1] set to: "..towstring(QuickNameActionsRessurected.tellMessage1))
elseif messageNumber==L"2" and qnaSplit[2] then
  changedTellMessage2 = true;
  NameMapper(input)
  EA_ChatWindow.Print(link..L"Quick-tell message [2] set to: "..towstring(QuickNameActionsRessurected.tellMessage2))
  end
  if changedTellMessage then
    changedTellMessage=false;
  elseif changedTellMessage2 then
    changedTellMessage2=false;
  end
end

end



function QuickNameActionsRessurected.SetChatText(input, channel,messageNumber)
local regex = wstring.match(towstring(input), L"\^\%s")

local qnaSplit = StringSplit(tostring(input), "#")
local input = towstring(qnaSplit[1])
local channel = towstring(qnaSplit[2])
local messageNumber = towstring(qnaSplit[3])


if input == L"" or input == nil or regex then
    ChannelInfo()
    EA_ChatWindow.Print(link..towstring("Current quick-chat message [1 "..tostring(QuickNameActionsRessurected.chatMessage1Channel).."] is: "..tostring(QuickNameActionsRessurected.chatMessage1)))
    EA_ChatWindow.Print(link..towstring("Current quick-chat message [2 "..tostring(QuickNameActionsRessurected.chatMessage2Channel).."] is: "..tostring(QuickNameActionsRessurected.chatMessage2)))
else
  if messageNumber==L"1" or not qnaSplit[3] then
    NameMapper(input)
  if channel == nil or channel == L"" or channel=="" or channel==L"smart" then
    changedChatMessage=true;
    NameMapper(input)
    QuickNameActionsRessurected.smartChannel1 = true;
    QuickNameActionsRessurected.chatMessage1Channel = ChatSettings.Channels[EA_ChatWindow.prevChannel].serverCmd
  else
    changedChatMessage=true;
    NameMapper(input)
    QuickNameActionsRessurected.smartChannel1 = false;
    QuickNameActionsRessurected.chatMessage1Channel = tostring(channel)
  end
elseif messageNumber==L"2" then
  if channel == nil or channel == L"" or channel=="" or channel==L"smart" then
    changedChatMessage2=true;
    NameMapper(input)
    QuickNameActionsRessurected.smartChannel2 = true;
    QuickNameActionsRessurected.chatMessage2Channel = ChatSettings.Channels[EA_ChatWindow.prevChannel].serverCmd
  else
    changedChatMessage2=true;
    NameMapper(input)
    QuickNameActionsRessurected.smartChannel2 = false;
    QuickNameActionsRessurected.chatMessage2Channel = tostring(channel)
  end
end
end
  if changedChatMessage then
  ChannelInfo()
  EA_ChatWindow.Print(link..L"Quick-chat message [1] set to: "..towstring(QuickNameActionsRessurected.chatMessage1))
  EA_ChatWindow.Print(link..L"Quick-chat channel [1] set to: "..towstring(chanInfo))
  changedChatMessage=false;
elseif changedChatMessage2 then
  ChannelInfo()
  EA_ChatWindow.Print(link..L"Quick-chat message [2] set to: "..towstring(QuickNameActionsRessurected.chatMessage2))
  EA_ChatWindow.Print(link..L"Quick-chat channel [2] set to: "..towstring(chanInfo2))
  changedChatMessage2=false;
end
end

function QuickNameActionsRessurected.GuildLinker()
  local guildData = GetDatabaseGuildData( GameData.Guild.m_GuildID)
  local data  = L"GUILD:"..guildData.id
  local text  = L"["..guildData.name..L"]"
  local color = DefaultColor.ORANGE
  local link  = CreateHyperLink( data, text, {color.r,color.g,color.b}, {} )
  QuickNameActionsRessurected.GuildLink=link
  return QuickNameActionsRessurected.GuildLink
end




function QuickNameActionsRessurected.PrintQNAMessages()
  EA_ChatWindow.Print(link..L"Current quick-tell message [1] is: "..towstring(QuickNameActionsRessurected.tellMessage1))
  EA_ChatWindow.Print(link..L"Current quick-tell message [2] is: "..towstring(QuickNameActionsRessurected.tellMessage2))
  EA_ChatWindow.Print(link..towstring("Current quick-chat message [1 "..tostring(QuickNameActionsRessurected.chatMessage1Channel).."] is: "..tostring(QuickNameActionsRessurected.chatMessage1)))
  EA_ChatWindow.Print(link..towstring("Current quick-chat message [2 "..tostring(QuickNameActionsRessurected.chatMessage2Channel).."] is: "..tostring(QuickNameActionsRessurected.chatMessage2)))
end



function QuickNameActionsRessurected.Slash(cmd, input)
  if cmd == "qna" then
    QuickNameActionsRessurected.PrintOptions()
  end
if cmd == "qnatell" then
  QuickNameActionsRessurected.SetText(input,messageNumber)
end
if cmd == "qnachat" then
  QuickNameActionsRessurected.SetChatText(input,channel,messageNumber)
end
if cmd == "qnadisc" then
  QuickNameActionsRessurected.SetDiscordText(input)
end
if cmd == "qnamsg" then
  QuickNameActionsRessurected.PrintQNAMessages()
end
end


function QuickNameActionsRessurected.LibSlashCheck()
local mods = ModulesGetData();
for k, v in ipairs(mods) do
  if v.name == "LibSlash" then
    if v.isEnabled then
      return true
    else
      return false
    end
    break
  end
end
end
