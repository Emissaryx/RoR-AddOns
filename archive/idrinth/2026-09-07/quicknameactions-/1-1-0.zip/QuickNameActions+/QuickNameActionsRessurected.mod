<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">

    <UiMod name="QuickNameActions+" version="1.1" date="06/06/21">
    	<VersionSettings gameVersion="1.4.8" windowsVersion="1.0" savedVariablesVersion="1.0" />
     <Author name="xyeppp" />
        <Description text="QuickNameActions+" />
        <Dependencies>
        </Dependencies>

        <Files>
            <File name="QuickNameActionsRessurected.lua" />
          </Files>
        <OnInitialize>
            <CallFunction name="QuickNameActionsRessurected.Initialize" />
        </OnInitialize>
        <OnShutdown>
            <CallFunction name="QuickNameActionsRessurected.OnShutdown" />
        </OnShutdown>
        <SavedVariables>
        <SavedVariable name="QuickNameActionsRessurected.discord" />
        <SavedVariable name="QuickNameActionsRessurected.tellMessage1" />
        <SavedVariable name="QuickNameActionsRessurected.tellMessage2" />
        <SavedVariable name="QuickNameActionsRessurected.chatMessage1" />
        <SavedVariable name="QuickNameActionsRessurected.chatMessage2" />
        <SavedVariable name="QuickNameActionsRessurected.chatMessage1Channel" />
        <SavedVariable name="QuickNameActionsRessurected.chatMessage2Channel" />
        <SavedVariable name="QuickNameActionsRessurected.smartChannel1" />
        <SavedVariable name="QuickNameActionsRessurected.smartChannel2"/>
        <SavedVariable name="QuickNameActionsRessurected.GuildLink" />
        <SavedVariable name="QuickNameActionsRessurected.discorder" />
        <SavedVariable name="QuickNameActionsRessurected.oldQNAmessage" />
        <SavedVariable name="QuickNameActionsRessurected.oldQNAmasteryMessage" />
        <SavedVariable name="QuickNameActionsRessurected.Career"/>
        </SavedVariables>
    </UiMod>
</ModuleFile>
