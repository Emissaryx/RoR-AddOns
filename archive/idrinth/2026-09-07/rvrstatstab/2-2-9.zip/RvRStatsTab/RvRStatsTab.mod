<?xml version="1.0" encoding="UTF-8"?>
<!--
$Id: RvRStatsTab.mod 72 2009-10-02 18:08:16Z Ermite Chevelu $

RvRStatsTab
Copyright (C) 2008-2009  Ermite Chevelu

This file is part of RvRStatsTab.

RvRStatsTab is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

RvRStatsTab is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with RvRStatsTab.  If not, see <http://www.gnu.org/licenses/>.
-->
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <UiMod name="RvRStatsTab" version="2.2.9" date="10/02/2009" >

    <Author name="Ermite Chevelu" email="ermite_chevelu(at)hotmail.com" />
    <Description text="Adds RvR stats to the character window." />
    <VersionSettings gameVersion="1.3.2" windowsVersion="1.0" savedVariablesVersion="1.0" />

    <Dependencies>
      <Dependency name="EASystem_Utils" />
      <Dependency name="EA_ChatWindow"/>
      <Dependency name="EA_CharacterWindow"/>
    </Dependencies>

    <Files>
      <File name="Source/RvRStats.lua"/>
      <File name="Source/RvRStats.xml"/>
      <File name="Source/RvRStatsRvRTab.lua"/>
      <File name="Source/RvRStatsRvRTab.xml"/>
      <File name="Source/locales/enUS.lua" />
      <File name="Source/locales/deDE.lua" />
      <File name="Source/locales/frFR.lua" />
      <File name="Source/locales/esES.lua" />
      <File name="Source/locales/itIT.lua" />
      <File name="Source/locales/ruRU.lua" />
    </Files>

    <OnInitialize>
      <CallFunction name="RvRStatsRvRTab.Init" />
      <CallFunction name="RvRStats.Init" />
    </OnInitialize>
    <OnUpdate>
    </OnUpdate>
    <OnShutdown>
      <CallFunction name="RvRStats.OnShutDown" />
    </OnShutdown>
  </UiMod>
</ModuleFile>
