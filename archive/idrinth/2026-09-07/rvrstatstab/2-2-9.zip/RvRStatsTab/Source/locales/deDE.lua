--[[
$Id: deDE.lua 64 2009-03-20 11:41:05Z Ermite Chevelu $

RvRStatsTab
Copyright (C) 2008-2009  Ermite Chevelu

This file is part of RvRStatsTab.

RvRStatsTab is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

RvRStatsTab is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with RvRStatsTab.  If not, see <http://www.gnu.org/licenses/>.
]]

-- Translation by TheFossy
RvRStats.MESSAGES[L"deDE"] = {
    ["RR"] = L"RR",
    ["TITLE"] = L"Titel",
    ["LIFETIME_KILLS"] = L"Get�tete Gegner (in dieser Spielsitzung)",
    ["LIFETIME_DEATHBLOWS"] = L"Alle Todesst��e",
    ["LIFETIME_DEATHS"] = L"Eigene Tode",
    ["LIFETIME_RATIO_KILL_DEATH"] = L"Verh�ltnis get�tete Gegner/eigene Tode",
    ["LIFETIME_RATIO_DEATHBLOW_DEATH"] = L"Verh�ltnis Todesst��e/eigene Tode",
    ["TOME_OF_KNOWLEDGE"] = L"W�lzer des Wissens",
}