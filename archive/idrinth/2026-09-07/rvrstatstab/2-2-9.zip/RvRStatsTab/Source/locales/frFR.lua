--[[
$Id: frFR.lua 64 2009-03-20 11:41:05Z Ermite Chevelu $

RvRStatsTab
Copyright (C) 2008-2009  Ermite Chevelu

This file is part of RvRStatsTab.

RvRStatsTab is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

RvRStatsTab is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with RvRStatsTab.  If not, see <http://www.gnu.org/licenses/>.
]]


RvRStats.MESSAGES[L"frFR"] = {
    ["RR"] = L"RR",
    ["TITLE"] = L"Titre",
    ["LIFETIME_KILLS"] = L"Victoires (session)",
    ["LIFETIME_DEATHBLOWS"] = L"Coups mortels",
    ["LIFETIME_DEATHS"] = L"D�c�s",
    ["LIFETIME_RATIO_KILL_DEATH"] = L"Ratio victoires/d�c�s",
    ["LIFETIME_RATIO_DEATHBLOW_DEATH"] = L"Ratio coups mortels/d�c�s",
    ["TOME_OF_KNOWLEDGE"] = L"Livre de la Connaissance",
}