--[[
$Id: zhTW.lua 64 2009-03-20 11:41:05Z Ermite Chevelu $

RvRStatsTab
Copyright (C) 2008-2009  Ermite Chevelu

This file is part of RvRStatsTab.

RvRStatsTab is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

RvRStatsTab is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with RvRStatsTab.  If not, see <http://www.gnu.org/licenses/>.
]]


RvRStats.MESSAGES[L"zhTW"] = {
    ["RR"] = L"RR",
    ["TITLE"] = L"Title",
    ["LIFETIME_KILLS"] = L"Lifetime Kills (session)",
    ["LIFETIME_DEATHBLOWS"] = L"Lifetime Deathblows",
    ["LIFETIME_DEATHS"] = L"Lifetime Deaths",
    ["LIFETIME_RATIO_KILL_DEATH"] = L"Kill/Death Ratio",
    ["LIFETIME_RATIO_DEATHBLOW_DEATH"] = L"Deathblow/Death Ratio",
    ["TOME_OF_KNOWLEDGE"] = L"Tome of knowledge",
}