--[[
$Id: RvRStats.lua 64 2009-03-20 11:41:05Z Ermite Chevelu $

RvRStatsTab
Copyright (C) 2008-2009  Ermite Chevelu

This file is part of RvRStatsTab.

RvRStatsTab is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

RvRStatsTab is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with RvRStatsTab.  If not, see <http://www.gnu.org/licenses/>.
]]


RvRStats = {}

RvRStats.MESSAGES = {}

local window = "CharacterWindowRvRStats"
local localizedMessages = {}
local oldShow = nil

-- Initialize local settings
local function initLocale()
   local language = SystemData.Settings.Language
   local switch = {
      [language.ENGLISH] = L"enUS",
      [language.FRENCH] = L"frFR",
      [language.GERMAN] = L"deDE",
      [language.ITALIAN] = L"itIT",
      [language.SPANISH] = L"esES",
      [language.KOREAN] = L"koKR",
      [language.S_CHINESE] = L"zhCN",
      [language.T_CHINESE] = L"zhTW",
      [language.JAPANESE] = L"jaJP",
      [language.RUSSIAN] = L"ruRU"
   }

   local res = switch[language.active] 
   if not res then
      res = L"enUS"
   end

   localizedMessages = RvRStats.MESSAGES[res]
end

-- return localized message
local function getLocalizedMessage(key)
    return localizedMessages[key]
end

-- return class name
local function getClassName(speciesData)
   return speciesData.name .. L" : "
end

-- return formatted kill count
local function getKillCount(speciesData)
   return StringToWString(string.format("%d", speciesData.killCount))
end

-- update RvR tab
local function updateRvRTab()
   local playerRealm = GameData.Player.realm
   local lifetimeKills = GameData.Player.RvRStats.LifetimeKills
   local lifetimeDeathBlows = GameData.Player.RvRStats.LifetimeDeathBlows
   local lifetimeDeaths = GameData.Player.RvRStats.LifetimeDeaths
   local KDRatio = StringToWString(string.format("%.2f" , (lifetimeKills / lifetimeDeaths)))
   local DBDRatio = StringToWString(string.format("%.2f" , (lifetimeDeathBlows / lifetimeDeaths)))
   
   local classA = {["id"] = 0, ["name"] = L"???", ["killCount"] = L"0"}
   local classB = {["id"] = 0, ["name"] = L"???", ["killCount"] = L"0"}
   local classC = {["id"] = 0, ["name"] = L"???", ["killCount"] = L"0"}
   local classD = {["id"] = 0, ["name"] = L"???", ["killCount"] = L"0"}
   local classE = {["id"] = 0, ["name"] = L"???", ["killCount"] = L"0"}
   local classF = {["id"] = 0, ["name"] = L"???", ["killCount"] = L"0"}
   local classG = {["id"] = 0, ["name"] = L"???", ["killCount"] = L"0"}
   local classH = {["id"] = 0, ["name"] = L"???", ["killCount"] = L"0"}
   local classI = {["id"] = 0, ["name"] = L"???", ["killCount"] = L"0"}
   local classJ = {["id"] = 0, ["name"] = L"???", ["killCount"] = L"0"}
   local classK = {["id"] = 0, ["name"] = L"???", ["killCount"] = L"0"}
   local classL = {["id"] = 0, ["name"] = L"???", ["killCount"] = L"0"}
   
   local subTypeData
   
   if playerRealm == GameData.Realm.DESTRUCTION then
      classA.id = 48 -- bright wizard
      classB.id = 49 -- kotbs
      classC.id = 50 -- warrior priest
      classD.id = 51 -- witch hunter
      
      classE.id = 42 -- engineer
      classF.id = 43 -- slayer
      classG.id = 44 -- ironbreaker
      classH.id = 45 -- runepriest
      
      classI.id = 75 -- archmage
      classJ.id = 76 -- white lion
      classK.id = 77 -- shadow warrior
      classL.id = 78 -- swordmaster
   elseif playerRealm == GameData.Realm.ORDER then
      classA.id = 14 -- choosen
      classB.id = 15 -- magus
      classC.id = 16 -- marauder
      classD.id = 17 -- zealot
      
      classE.id = 63 -- shaman
      classF.id = 64 -- squig herder
      classG.id = 92 -- black orc
      classH.id = 93 -- choppa
      
      classI.id = 31 -- witch elf
      classJ.id = 32 -- disciple of khaine
      classK.id = 33 -- blackguard
      classL.id = 34 -- sorcerer
   end
   
   
   -- collect imperial or chaos stats
   subTypeData = TomeGetBestiarySubTypeData( 16 ) -- Human
   if subTypeData then
      for index, speciesData in ipairs( subTypeData.species ) do
         
         -- check if entry is unlock
         if speciesData.isUnlocked == true then
         
            -- bright wizard or choosen
            if speciesData.id == classA.id then
               classA.name = getClassName(speciesData)
               classA.killCount = getKillCount(speciesData)
            end

            -- kotbs or magus
            if speciesData.id == classB.id then
               classB.name = getClassName(speciesData)
               classB.killCount = getKillCount(speciesData)
            end

            -- warrior priest or marauder
            if speciesData.id == classC.id then
               classC.name = getClassName(speciesData)
               classC.killCount = getKillCount(speciesData)
            end
            
            -- witch hunter or zealot
            if speciesData.id == classD.id then
               classD.name = getClassName(speciesData)
               classD.killCount = getKillCount(speciesData)
            end
         end
      end
   end

   -- collect dwarf or greenskin stats
   if playerRealm == GameData.Realm.DESTRUCTION then
      subTypeData = TomeGetBestiarySubTypeData( 13 ) -- Dwarf
   elseif playerRealm == GameData.Realm.ORDER then
      subTypeData = TomeGetBestiarySubTypeData( 15 ) -- Greenskin
   end
   if subTypeData then
      for index, speciesData in ipairs( subTypeData.species ) do
         
         -- check if entry is unlock
         if speciesData.isUnlocked == true then
            
            -- engineer or shaman
            if speciesData.id == classE.id then
               classE.name = getClassName(speciesData)
               classE.killCount = getKillCount(speciesData)
            end

            if speciesData.id == classF.id then -- slayer or squig herder
               classF.name = getClassName(speciesData)
               classF.killCount = getKillCount(speciesData)
            end

            if speciesData.id == classG.id then -- ironbreaker or black orc
               classG.name = getClassName(speciesData)
               classG.killCount = getKillCount(speciesData)
            end

            if speciesData.id == classH.id then -- runepriest or choppa
               classH.name = getClassName(speciesData)
               classH.killCount = getKillCount(speciesData)
            end
         end
      end
   end

   -- collect high elf or dark elf stats
   subTypeData = TomeGetBestiarySubTypeData( 14 )
   if subTypeData then
      for index, speciesData in ipairs( subTypeData.species ) do
         
         -- check if entry is unlock
         if speciesData.isUnlocked == true then
            
            -- archmage or witch elf
            if speciesData.id == classI.id then
               classI.name = getClassName(speciesData)
               classI.killCount = getKillCount(speciesData)
            end

            -- white lion or disciple of khaine
            if speciesData.id == classJ.id then
               classJ.name = getClassName(speciesData)
               classJ.killCount = getKillCount(speciesData)
            end

            -- shadow warrior or blackguard
            if speciesData.id == classK.id then
               classK.name = getClassName(speciesData)
               classK.killCount = getKillCount(speciesData)
            end

            -- swordmaster or sorcerer
            if speciesData.id == classL.id then
               classL.name = getClassName(speciesData)
               classL.killCount = getKillCount(speciesData)
            end
         end
      end
   end
   
   LabelSetText(window.."Header", GameData.Player.name)
   LabelSetText(window.."Title", getLocalizedMessage("RR") .. L": " .. GameData.Player.Renown.curRank .. L"   " .. getLocalizedMessage("TITLE") .. L": " .. GameData.Player.Renown.curTitle)
   LabelSetText(window.."LifetimeK", getLocalizedMessage("LIFETIME_KILLS") .. L": " .. lifetimeKills .. L" (" .. GameData.Player.RvRStats.SessionKills .. L")")
   LabelSetText(window.."LifetimeDB", getLocalizedMessage("LIFETIME_DEATHBLOWS") .. L": " .. lifetimeDeathBlows)
   LabelSetText(window.."LifetimeD", getLocalizedMessage("LIFETIME_DEATHS") .. L": " .. lifetimeDeaths)
   LabelSetText(window.."LifetimeRatioKD", getLocalizedMessage("LIFETIME_RATIO_KILL_DEATH") .. L": " .. KDRatio)
   LabelSetText(window.."LifetimeRatioDBD", getLocalizedMessage("LIFETIME_RATIO_DEATHBLOW_DEATH") .. L": " .. DBDRatio)
   LabelSetText(window.."ClassKills", getLocalizedMessage("TOME_OF_KNOWLEDGE"))
   
   -- Human
   LabelSetText(window.."ClassA_Name", classA.name)
   LabelSetText(window.."ClassA_KillCount", classA.killCount)
   
   LabelSetText(window.."ClassB_Name", classB.name)
   LabelSetText(window.."ClassB_KillCount", classB.killCount)
   
   LabelSetText(window.."ClassC_Name", classC.name)
   LabelSetText(window.."ClassC_KillCount", classC.killCount)
   
   LabelSetText(window.."ClassD_Name", classD.name)
   LabelSetText(window.."ClassD_KillCount", classD.killCount)
   
   -- Dwarf or Greenskin
   LabelSetText(window.."ClassE_Name", classE.name)
   LabelSetText(window.."ClassE_KillCount", classE.killCount)
   
   LabelSetText(window.."ClassF_Name", classF.name)
   LabelSetText(window.."ClassF_KillCount", classF.killCount)
   
   LabelSetText(window.."ClassG_Name", classG.name)
   LabelSetText(window.."ClassG_KillCount", classG.killCount)
   
   LabelSetText(window.."ClassH_Name", classH.name)
   LabelSetText(window.."ClassH_KillCount", classH.killCount)
   
   -- Elf
   LabelSetText(window.."ClassI_Name", classI.name)
   LabelSetText(window.."ClassI_KillCount", classI.killCount)
   
   LabelSetText(window.."ClassJ_Name", classJ.name)
   LabelSetText(window.."ClassJ_KillCount", classJ.killCount)
   
   LabelSetText(window.."ClassK_Name", classK.name)
   LabelSetText(window.."ClassK_KillCount", classK.killCount)
   
   LabelSetText(window.."ClassL_Name", classL.name)
   LabelSetText(window.."ClassL_KillCount", classL.killCount)
end

---- Init ----
function RvRStats.Init()
   initLocale()
   oldShow = CharacterWindow.OnShown
   CharacterWindow.OnShown = RvRStats.OnShown
end

function RvRStats.OnShown()
   updateRvRTab()
   oldShow()
end
