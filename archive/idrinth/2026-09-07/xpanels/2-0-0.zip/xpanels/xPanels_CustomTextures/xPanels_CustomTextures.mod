<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <UiMod name="xPanels_CustomTextures" version="1.0" date="10/25/2008" >

    <Author name="Talvinen" email="redefiance@gmx.de" />
    <Description text="Allowes the user to add additional textures to xPanels" />
    
    <Dependencies>
      <Dependency name="xPanels" />
    </Dependencies>

    <Files>
      <File name="TextureList.lua" />
      <File name="TextureList.xml" />
    </Files>
  </UiMod>
</ModuleFile>
