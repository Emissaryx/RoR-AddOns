This mod allowes you to add additional Textures to xPanels.
Adding a texture is quite easy, creating one is a bit more different, so I'll start with this:

a) Create an Image with width and height each equal to a power of 2, that means:
   2, 4, 8, 16, 32, 64, 128, 256, 512, 1024
   width and height may be different, but must be one of the above values
  
b) if you want to have transparent or semi-transparent parts in your texture,
   you need to use an alpha channel. I won't go into the details, if you don't know
   what to do, try to read it up somewhere.
   
c) the image must be in .dds-format. This is somewhat a rare image format, so you will likely need
   a converter. as of 12/12/08, you can download one from http://www.dsabstraction.com/dds_converter.htm
   remember to save your image in a format that supports alpha channels before converting, if you
   want to use those. I suggest .tga
   
d) After creating an .dds-format file with valid dimensions (and with or without an alpha channel),
   simply copy it into the xPanels_CustomTextures-folder.
   
e) open the TextureList.xml and add your file to the list. just follow the formats of the two
   example textures
   
f) open the TextureList.lua and add your texture to the list. note that you must use the exact
   same name as you used in the TextureList.xml (not neccessary identical to the file name)
   try not to forget a comma etc.
   
g) start or reload WAR

h) you will now see your texture in the dropdown menu of xPanels-Settings

-- talvinen, 12/12/08