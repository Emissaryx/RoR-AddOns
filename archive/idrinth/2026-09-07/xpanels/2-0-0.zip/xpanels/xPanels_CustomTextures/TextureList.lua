if (not xPanels) then return end

xPanels.CustomTextures = {
  
      -- Add your custom textures here. format:
      -- YOUR_TEXTURE_NAME = {width, height},
      
      xPanels_Button1       = {256, 64},
      xPanels_Runes         = {512, 256},
	Demonic               = {2048, 256},
	Sanctuary_Action      = {512, 64},
	Sanctuary_Background  = {2048, 256},
	Sanctuary_Bar         = {2048, 16},
	Sanctuary_Long        = {512, 256},
	Sanctuary_Short       = {256, 256},
	Sanctuary_Extend      = {512, 256},
      
      -- don't edit after this line 
  
  }