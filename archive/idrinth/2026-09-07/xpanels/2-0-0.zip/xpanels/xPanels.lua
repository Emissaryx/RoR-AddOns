xPanels = {}
LibGUI = LibStub("LibGUI")

local Main
local initialized = false
local selectedIndex = nil

local function print(msg)
  EA_ChatWindow.Print(towstring(msg))
end

function xPanels.Initialize()
  print("xPanels Initialized")
  LibSlash.RegisterSlashCmd("xpanels",function(msg) xPanels.Slash(msg) end)
  table.insert(LayoutEditor.EventHandlers, xPanels.SavePosition)
end

function xPanels.SavePosition()
--neo2121 added 'layer' to the list
  local frame, scale, width, height, x, y, layer
  local uiscale = InterfaceCore.GetScale()
  
  for key,val in pairs(xPanels.Settings.Panels) do
    frame = "xPanels_"..key
    scale = WindowGetScale(frame)
    width, height = WindowGetDimensions(frame)
    x, y = WindowGetScreenPosition(frame)
    
    width = scale/uiscale * width
    height = scale/uiscale * height
    WindowSetScale(frame,uiscale)
    WindowSetDimensions(frame,width,height)
    
    val.width = width
    val.height = height
    val.x = x
    val.y = y
  end
  
  if (Main) then
    xPanels.UpdateMenu()
  end
end

function xPanels.Recreate()
  local frame
  local scale = InterfaceCore.GetScale()
  for key,val in pairs(xPanels.Settings.Panels) do
    frame = "xPanels_"..key
    if (DoesWindowExist(frame)) then
      LayoutEditor.UnregisterWindow(frame)
      DestroyWindow(frame)
    end
    CreateWindowFromTemplate(frame,"EA_DynamicImage_DefaultSeparatorRight","Root")
    LayoutEditor.RegisterWindow(frame,towstring(key),"",true,true,true)
    WindowSetDimensions(frame,val.width,val.height)
    WindowSetAlpha(frame,val.alpha)
    if (not val.notint) then
      WindowSetTintColor(frame,unpack(val.color))
    end
    WindowSetHandleInput(frame,false)
-- neo2121 basic error checking for layer value
    if (val.layer) then
      WindowSetLayer(frame,val.layer)
    else
      WindowSetLayer(frame,0)
    end
-- end neo2121
    WindowClearAnchors(frame)
    WindowAddAnchor(frame,"topleft","Root","topleft",val.x/scale,val.y/scale)
    
    if (xPanels.CustomTextures and val.texture) then
      DynamicImageSetTexture(frame, val.texture, 0, 0)
      DynamicImageSetTextureDimensions(frame, unpack(xPanels.CustomTextures[val.texture]))
      --DynamicImageSetTextureScale(frame, val.texscale)
    else
      DynamicImageSetTexture(frame, "tint_square", 0, 0)
    end
  end
end

function xPanels.UpdateMenu()
  Main.Input.list:Clear()
  for key,val in pairs(xPanels.Settings.Panels) do
    Main.Input.list:Add(key)
  end
  if (selectedIndex) then
    Main.Input.list:SelectIndex(selectedIndex)
  else
    Main.Input.list:SelectIndex(1)
  end

  local settings = xPanels.Settings.Panels[WStringToString(Main.Input.list:Selected())]
  if (not settings) then
    Main.Input.width:SetText("")
    Main.Input.height:SetText("")
    Main.Input.alpha:SetText("")
--neo2121 added
    Main.Input.layer:SetText("")
--end neo2121
    Main.Input.colorR:SetText("")
    Main.Input.colorG:SetText("")
    Main.Input.colorB:SetText("")
    Main.Input.notint:Clear()
    Main.Input.texture:SelectIndex(1)
  else
    Main.Input.width:SetText(settings.width)
    Main.Input.height:SetText(settings.height)
    Main.Input.alpha:SetText(settings.alpha)
--neo2121 added
    Main.Input.layer:SetText(settings.layer)
--end neo2121
    Main.Input.colorR:SetText(settings.color[1])
    Main.Input.colorG:SetText(settings.color[2])
    Main.Input.colorB:SetText(settings.color[3])
    Main.Input.notint:SetValue(settings.notint or false)
    Main.Input.texture:Select(settings.texture or "none")
  end
end

function xPanels.OnUpdate()
  if (not initialized) then
    initialized = true
    if (not xPanels.Settings) then
      xPanels.Settings = {}
      xPanels.Settings.Panels = {}
    end
    
    xPanels.Recreate()
  end
  
  if (Main and Main:Showing()) then
    local si = Main.Input.list:SelectedIndex()
    if (si ~= selectedIndex) then
      selectedIndex = si
      xPanels.UpdateMenu()
    end
  end
end

function xPanels.ApplySettings()
  local settings = xPanels.Settings.Panels[WStringToString(Main.Input.list:Selected())]
  
  settings.width = tonumber(Main.Input.width:GetText())
--neo2121 added
  settings.layer = tonumber(Main.Input.layer:GetText())
--end neo2121
  settings.height = tonumber(Main.Input.height:GetText())
  settings.alpha = tonumber(Main.Input.alpha:GetText())
  settings.color = {tonumber(Main.Input.colorR:GetText()),
                    tonumber(Main.Input.colorG:GetText()),
                    tonumber(Main.Input.colorB:GetText())}
  settings.notint = Main.Input.notint:GetValue()
  settings.texture = WStringToString(Main.Input.texture:Selected())
  if (settings.texture == "none") then
    settings.texture = false
  end
                    
  xPanels.Recreate()
end

function xPanels.Move(direction)
  local name = WStringToString(Main.Input.list:Selected())
  local settings = xPanels.Settings.Panels[name]
  local frame = "xPanels_"..name
  local scale = InterfaceCore.GetScale()
  
  if (direction == "up") then
    settings.y = settings.y - 1
  elseif (direction == "down") then
    settings.y = settings.y + 1
  elseif (direction == "right") then
    settings.x = settings.x + 1
  elseif (direction == "left") then
    settings.x = settings.x - 1
  end
  
  WindowClearAnchors(frame)
  WindowAddAnchor(frame,"topleft","Root","topleft",settings.x/scale,settings.y/scale)
end

function xPanels.CreatePanel()
  local name = WStringToString(Main.Input.create:GetText())
  if (name == "") then return end
  
  if (not xPanels.Settings.Panels[name]) then
    xPanels.Settings.Panels[name] = {
      width = 300,
      height = 50,
      layer = 3,
      x = 300,
      y = 300,
      color = {0,0,0},
      alpha = 1,
      notint = false,
      texture = false,
    }
    Main.Input.list:Add(name)
  end
  
  Main.Input.list:Select(name)
  
  xPanels.Recreate()
end

function xPanels.DeletePanel()
  local name = WStringToString(Main.Input.list:Selected())

  xPanels.Settings.Panels[name] = nil

  if (DoesWindowExist("xPanels_"..name)) then
    LayoutEditor.UnregisterWindow("xPanels_"..name)
    DestroyWindow("xPanels_"..name)
  end
  
  xPanels.UpdateMenu()
end

function xPanels.Slash()
  if (not Main) then
    xPanels.CreateMenu()
  end
  
  Main:Show()
end

function xPanels.CreateMenu()
  Main = LibGUI("Blackframe")
  Main:MakeMovable()
  Main:Resize(550,510)
  Main:AnchorTo("Root","center","center",0,0)
  
  Main.CloseButton = Main("Closebutton")
  Main.CloseButton.OnLButtonUp =
    function()
      Main:Hide()
    end
  
  Main.Title = Main("Label")
  Main.Title:Resize(250)
  Main.Title:AnchorTo(Main, "top", "top", 0, 10)
  Main.Title:Font("font_clear_large_bold")
  Main.Title:SetText("xPanels")
  Main.Title:Align("center")
  Main.Title:IgnoreInput()
  
  Main.Labels = {}
  Main.Input = {}
  
  Main.Labels.create = Main("Label")
  Main.Labels.create:SetText("create new label:")
  Main.Labels.create:Align("right")
  Main.Labels.create:Resize(200)
  Main.Labels.create:Position(0,60)
  
  Main.Input.create = Main("Textbox")
  Main.Input.create:Resize(200)
  Main.Input.create:AnchorTo(Main.Labels.create,"right","left",5,-5)

  Main.Input.create_button = Main("Button")
  Main.Input.create_button:Resize(80)
  Main.Input.create_button:AnchorTo(Main.Input.create,"right","left",5,0)
  Main.Input.create_button:SetText("create")
  Main.Input.create_button.OnLButtonUp =
    function()
      xPanels.CreatePanel()
    end
  
  Main.Labels.list = Main("Label")
  Main.Labels.list:SetText("or choose one:")
  Main.Labels.list:Align("right")
  Main.Labels.list:Resize(200)
  Main.Labels.list:Position(0,100)
  
  Main.Input.list = Main("Combobox")
  Main.Input.list:AnchorTo(Main.Labels.list,"right","left",5,-5)
  
  Main.Labels.width = Main("Label")
  Main.Labels.width:SetText("width")
  Main.Labels.width:Align("right")
  Main.Labels.width:Resize(100)
  Main.Labels.width:Position(0,160)
  
  Main.Input.width = Main("Textbox")
  Main.Input.width:Resize(200)
  Main.Input.width:AnchorTo(Main.Labels.width,"right","left",5,-5)

  Main.Labels.height = Main("Label")
  Main.Labels.height:SetText("height")
  Main.Labels.height:Align("right")
  Main.Labels.height:Resize(100)
  Main.Labels.height:Position(0,200)
  
  Main.Input.height = Main("Textbox")
  Main.Input.height:Resize(200)
  Main.Input.height:AnchorTo(Main.Labels.height,"right","left",5,-5)

  Main.Labels.color = Main("Label")
  Main.Labels.color:SetText("color")
  Main.Labels.color:Align("right")
  Main.Labels.color:Resize(100)
  Main.Labels.color:Position(0,240)
  
  Main.Input.colorR = Main("Textbox")
  Main.Input.colorR:Resize(60)
  Main.Input.colorR:AnchorTo(Main.Labels.color,"right","left",5,-5)
  Main.Input.colorG = Main("Textbox")
  Main.Input.colorG:Resize(60)
  Main.Input.colorG:AnchorTo(Main.Input.colorR,"right","left",10,0)
  Main.Input.colorB = Main("Textbox")
  Main.Input.colorB:Resize(60)
  Main.Input.colorB:AnchorTo(Main.Input.colorG,"right","left",10,0)

  Main.Labels.notint = Main("Label")
  Main.Labels.notint:SetText("use texture color")
  Main.Labels.notint:Align("left")
  Main.Labels.notint:Resize(200)
  Main.Labels.notint:Position(140,270)
  
  Main.Input.notint = Main("Checkbox")
  Main.Input.notint:Position(110,270)

  Main.Labels.alpha = Main("Label")
  Main.Labels.alpha:SetText("alpha")
  Main.Labels.alpha:Align("right")
  Main.Labels.alpha:Resize(100)
  Main.Labels.alpha:Position(0,320)

  Main.Input.alpha = Main("Textbox")
  Main.Input.alpha:Resize(200)
  Main.Input.alpha:AnchorTo(Main.Labels.alpha,"right","left",5,-5)


--  Main.Labels.alpha:Align("right")
--  Main.Labels.alpha:Resize(100)
--  Main.Labels.alpha:Position(0,320)

--neo2121 added
  Main.Labels.layer = Main("Label")
  Main.Labels.layer:SetText("Layer")
  Main.Labels.layer:Resize(100)
  Main.Labels.layer:Position(320,313)

  Main.Input.layer = Main("Textbox")
  Main.Input.layer:Resize(100)
  Main.Input.layer:Position(400,313)
--end button
  
  Main.Labels.texture = Main("Label")
  Main.Labels.texture:SetText("texture")
  Main.Labels.texture:Align("right")
  Main.Labels.texture:Resize(100)
  Main.Labels.texture:Position(0,360)

  Main.Input.texture = Main("Combobox")
  Main.Input.texture:AnchorTo(Main.Labels.texture,"right","left",5,-5)
  Main.Input.texture:Add("none")
  if (xPanels.CustomTextures) then
    for k,v in pairs(xPanels.CustomTextures) do
      Main.Input.texture:Add(k)
    end
  end
  
  Main.Input.delete = Main("Button")
  Main.Input.delete:Resize(200)
  Main.Input.delete:Position(105,400)
  Main.Input.delete:SetText("Delete this Panel")
  Main.Input.delete.OnLButtonUp =
    function()
      xPanels.DeletePanel()
    end
    
  Main.Labels.position = Main("Label")
  Main.Labels.position:SetText("change position")
  Main.Labels.position:Resize(100)
  Main.Labels.position:Position(365,150)
  
  Main.Input.position_up = Main("Button")
  Main.Input.position_up:SetText("^")
  Main.Input.position_up:Resize(40)
  Main.Input.position_up:Position(400,180)
  Main.Input.position_up.OnLButtonUp =
    function()
      xPanels.Move("up")
    end
  
  Main.Input.position_right = Main("Button")
  Main.Input.position_right:SetText(">")
  Main.Input.position_right:Resize(40)
  Main.Input.position_right:Position(440,220)  
  Main.Input.position_right.OnLButtonUp =
    function()
      xPanels.Move("right")
    end
  
  Main.Input.position_down = Main("Button")
  Main.Input.position_down:SetText("v")
  Main.Input.position_down:Resize(40)
  Main.Input.position_down:Position(400,260) 
  Main.Input.position_down.OnLButtonUp =
    function()
      xPanels.Move("down")
    end

  Main.Input.position_left = Main("Button")
  Main.Input.position_left:SetText("<")
  Main.Input.position_left:Resize(40)
  Main.Input.position_left:Position(360,220) 
  Main.Input.position_left.OnLButtonUp =
    function()
      xPanels.Move("left")
    end
  
  Main.Input.apply = Main("Button")
  Main.Input.apply:Resize(200)
  Main.Input.apply:Position(50,460)
  Main.Input.apply:SetText("Apply")
  Main.Input.apply.OnLButtonUp =
    function()
      xPanels.ApplySettings()
    end
  
  Main.Input.cancel = Main("Button")
  Main.Input.cancel:Resize(200)
  Main.Input.cancel:AnchorTo(Main.Input.apply,"right","left",50,0)
  Main.Input.cancel:SetText("Cancel")
  Main.Input.cancel.OnLButtonUp =
    function()
      Main:Hide()
    end

  xPanels.UpdateMenu()
end