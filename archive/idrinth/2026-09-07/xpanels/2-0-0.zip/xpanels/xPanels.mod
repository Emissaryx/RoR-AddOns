<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <UiMod name="xPanels" version="2.0" date="10/25/2008" >

    <Author name="Talvinen" email="redefiance@gmx.de" />
    <Description text="" />
    
    <Dependencies>
      <Dependency name="LibSlash" />
    </Dependencies>

    <Files>
      <File name="LibStub.lua" />
      <File name="LibGUI.lua" />
      <File name="xPanels.lua" />
    </Files>

    <SavedVariables>
      <SavedVariable name="xPanels.Settings" />
    </SavedVariables>

    <OnInitialize>
      <CallFunction name="xPanels.Initialize" />
    </OnInitialize>
    <OnUpdate>
      <CallFunction name="xPanels.OnUpdate" />
    </OnUpdate>
  </UiMod>
</ModuleFile>
