ActionBarColor = ActionBarColor or {}
local oldMoraleButtonUpdate, oldActionButtonUpdateEnabledState

local function tint(self, idx, r, g, b)
    local w = self.m_Windows and self.m_Windows[idx]
    if w and w.SetTintColor then w:SetTintColor(r, g, b) end
end

function ActionBarColor.Initialize()
    if ActionBarColor.__hooked then return end

    -- Action buttons
    oldActionButtonUpdateEnabledState = ActionButton.UpdateEnabledState
    ActionButton.UpdateEnabledState = function(self, ...)
        oldActionButtonUpdateEnabledState(self, ...)

        local BASE_ICON = 0  -- keep your index; change if your template differs

        if self.m_IsEnabled and self.m_IsTargetValid then
            tint(self, BASE_ICON, 255, 255, 255)     -- normal
        elseif self.m_IsEnabled then
            tint(self, BASE_ICON, 200,   0,   0)     -- invalid target
        else
            tint(self, BASE_ICON, 125, 125, 125)     -- disabled (no iconType check)
        end
    end

    -- Morale buttons
    oldMoraleButtonUpdate = MoraleButton.Update
    MoraleButton.Update = function(self, ...)
        oldMoraleButtonUpdate(self, ...)

        local BASE_ICON = 2   -- morale template usually uses 2
        if self.m_AbilityId and self.m_AbilityId > 0 then
            if self.m_IsTargetValid then
                tint(self, BASE_ICON, 255, 255, 255)
            else
                tint(self, BASE_ICON, 255,   0,   0)
            end
        end
    end

    ActionBarColor.__hooked = true
end
