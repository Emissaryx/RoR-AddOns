<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
	<UiMod name="MiracleGrow" version="1.61" date="4/25/2008" >
    <VersionSettings gameVersion="1.3.1" windowsVersion="1.40" savedVariablesVersion="1.50" />

		<Author name="Athalin" email="scott@apathyland.com" />
		<Description text="Modifies the cultivation interface. 1.2 fix by Irinia of Volkmar. Extended by Maeron." />
		<Dependencies>
			<Dependency name="EA_BankWindow" />
			<Dependency name="EA_CultivationWindow" />
			<Dependency name="LibSlash" />
		</Dependencies>


		<Files>
			<File name="window.xml" />
            <File name="MiracleGrow.lua" />
		</Files>
        
   		<SavedVariables>
			<SavedVariable name="MiracleGrow.Settings"/>
		</SavedVariables>

		<OnInitialize>
            <CallFunction name="MiracleGrow.Initialize" />
		</OnInitialize>
		<OnUpdate>
		   <CallFunction name="MiracleGrow.OnUpdate" />
		</OnUpdate>
		<OnShutdown/>

	</UiMod>
</ModuleFile>
