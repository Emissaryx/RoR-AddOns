MiracleGrow = {}

local windowName = "MiracleGrow";
local version = "1.60";
local realPlot= 0

MiracleGrow.Settings=MiracleGrow.Settings or {
    sound=1,
    autoconsume=true,
    minlvl=1,
    maxlvl=0,
    showing=true,
    soundnum=215
}

local global_data={
    seeds={},
    soil={},
    water={},
    nutrients={},
    plot=0,
    laststage={0,0,0,0},
    consumestage={0,0,0,0}
}

function MiracleGrow.onHHover()
    realPlot=GameData.Player.Cultivation.CurrentPlot
    GameData.Player.Cultivation.CurrentPlot=MiracleGrow.getPlotForButton()
end

function MiracleGrow.onHHoverEnd()
    GameData.Player.Cultivation.CurrentPlot=realPlot
    CultivationWindow.UpdateAllPlots()
end

function MiracleGrow.onHover()
	local name = SystemData.MouseOverWindow.name
	Tooltips.CreateTextOnlyTooltip ( SystemData.ActiveWindow.name )
	Tooltips.SetTooltipText( 1, 1, L"Plot Status")
	for i=1,4 do
		plotData = GetCultivationInfo(i)
		local currentPlant = plotData["PlantName"]
		if not currentPlant then currentPlant = L"None" end
		Tooltips.SetTooltipText( i+1, 1, L"Plot "..towstring(i)..L" - "..currentPlant)
	end
	Tooltips.Finalize()
	local anchor = { Point = "topright",  RelativeTo = name, RelativePoint = "topleft",   XOffset = 10, YOffset = 0 }
	Tooltips.AnchorTooltip( anchor )
end

function MiracleGrow.onZone()
	if GameData.TradeSkillLevels[GameData.TradeSkills.CULTIVATION] == 0 then
		WindowSetShowing(windowName, false);
	--	MiracleGrow.Settings.showing=false;
	else
		CultivationWindow.UpdateAllPlots()
	end
end

function MiracleGrow.Initialize()
    CreateWindow("MiracleGrow", MiracleGrow.Settings.showing)
	LayoutEditor.RegisterWindow( "MiracleGrow", L"MiracleGrow",L"Planting interface", false, false, true, nil )
	LibSlash.RegisterSlashCmd("MiracleGrow", MiracleGrow.handleSlash)
	LibSlash.RegisterSlashCmd("mg", MiracleGrow.handleSlash)
	RegisterEventHandler(SystemData.Events.LOADING_END, "MiracleGrow.onZone")
    WindowSetGameActionData(windowName.."Plant1Harvest",GameData.PlayerActions.PERFORM_CRAFTING,GameData.TradeSkills.CULTIVATION,L"")
    WindowSetGameActionData(windowName.."Plant2Harvest",GameData.PlayerActions.PERFORM_CRAFTING,GameData.TradeSkills.CULTIVATION,L"")
    WindowSetGameActionData(windowName.."Plant3Harvest",GameData.PlayerActions.PERFORM_CRAFTING,GameData.TradeSkills.CULTIVATION,L"")
    WindowSetGameActionData(windowName.."Plant4Harvest",GameData.PlayerActions.PERFORM_CRAFTING,GameData.TradeSkills.CULTIVATION,L"")
    LabelSetText(windowName.."StartAllStartAllText",L"Plant All")
    LabelSetText(windowName.."StartAllAutoGrowText",L"auto")
  	WindowSetTintColor(windowName.."StartAllStartAll",128,128,128);
    LabelSetTextColor(windowName.."StartAllStartAllText",225,225,225);
    MiracleGrow.setAutoGrowColor()
end

function MiracleGrow.handleSlash(input)
    local args=MiracleGrow.explode(" ",input);
    if args[1] == "help" then
        MiracleGrow.writeHelp();
    elseif args[1] == "hide" then
        MiracleGrow.disableAddon()
    elseif args[1] == "show" then
        MiracleGrow.enableAddon()
    elseif args[1] == "toggle" then
        MiracleGrow.toggleAddon()
    elseif args[1] == "sound" then
        if args[2] == "on" then
            MiracleGrow.Settings.sound=1;
            MiracleGrow.writeChatLine("MiracleGrow sound is now on");
        elseif args[2] == "finish" then
            MiracleGrow.Settings.sound=2;
            MiracleGrow.writeChatLine("MiracleGrow sound is playing on finish");
        else
            MiracleGrow.Settings.sound=0;
            MiracleGrow.writeChatLine("MiracleGrow sound is now off");
        end
    elseif args[1] == "autogrow" then
        if args[2] == "on" then
            if not MiracleGrow.Settings.autoconsume then
                MiracleGrow.onAutoConsumeToggle()
            end
        elseif args[2] == "toggle" then
            MiracleGrow.onAutoConsumeToggle()
        else
            if MiracleGrow.Settings.autoconsume then
                MiracleGrow.onAutoConsumeToggle()
            end
        end
        MiracleGrow.setAutoGrowColor()
    elseif args[1] == "minlvl" then
        local tmp = tonumber(args[2]);
        if tmp ~=nil and tmp < 200 and tmp > 0 then
            MiracleGrow.Settings.minlvl=tmp;
            MiracleGrow.writeChatLine("MiracleGrow will now only show items at or above lvl "..tmp);
        else
            MiracleGrow.writeChatLine("minlvl must be between 1 and 200");
        end
    elseif args[1] == "maxlvl" then
        local tmp = tonumber(args[2]);
        if tmp ~=nil and tmp <= 200 and tmp > 0 then
            MiracleGrow.Settings.maxlvl=tmp;
            MiracleGrow.writeChatLine("MiracleGrow will now only show items under or at lvl "..tmp);
        else
            if tmp ~=nil and tmp == 0 then
                MiracleGrow.Settings.maxlvl=tmp;
                MiracleGrow.writeChatLine("MiracleGrow will now only show items under or at your crafting lvl");
            else
                MiracleGrow.writeChatLine("maxlvl must be between 0 and 200");
            end
        end
    elseif args[1] == "soundnum" then
        local tmp = tonumber(args[2]);
        if tmp ~= nil then
            MiracleGrow.Settings.soundnum=tmp
        end
    elseif args[1] == "playsound" then
        local tmp = tonumber(args[2]);
        if tmp ~= nil then
            PlaySound(tmp);
        end
    else
        MiracleGrow.writeHelp();
    end
end

function MiracleGrow.toggleAddon()
    if MiracleGrow.Settings.showing==true then
        MiracleGrow.disableAddon();
    else
        MiracleGrow.enableAddon();
    end
end

function MiracleGrow.enableAddon()
    if MiracleGrow.Settings.showing==false then
  	    WindowRegisterEventHandler(windowName, SystemData.Events.PLAYER_CULTIVATION_UPDATED, "MiracleGrow.fired");
  	    WindowSetShowing(windowName, true);
  	    MiracleGrow.Settings.showing=true;
  	end
end

function MiracleGrow.disableAddon()
    if MiracleGrow.Settings.showing==true then
  	    WindowUnregisterEventHandler(windowName, SystemData.Events.PLAYER_CULTIVATION_UPDATED);
    	WindowSetShowing(windowName, false);
  	    MiracleGrow.Settings.showing=false;
  	end
end

function MiracleGrow.writeHelp()
    MiracleGrow.writeChatLine("MiracleGrow cultivation addon by Athalin");
    MiracleGrow.writeChatLine("Version: "..version);
    MiracleGrow.writeChatLine("Slash commands (use /MiracleGrow or /mg");
    MiracleGrow.writeChatLine("/mg help - show this");
    MiracleGrow.writeChatLine("/mg autogrow [on/off/toggle] - turn automatical consumption on or off");
    MiracleGrow.writeChatLine("/mg sound [on/finish/off] - turn sounds on (after every stage), on (after last stage) or off");
    MiracleGrow.writeChatLine("/mg minlvl [number] - sets the min level of cultivation items to show");
    MiracleGrow.writeChatLine("/mg maxlvl [number] - sets the max level of cultivation items to show(set to 0 to use crafting lvl)");
    MiracleGrow.writeChatLine("/mg show - displays the window");
    MiracleGrow.writeChatLine("/mg hide - hides the window");
    MiracleGrow.writeChatLine("/mg toggle - toggles the window");
    MiracleGrow.writeChatLine("/mg soundnum [number] - Changes the sound played when cultivating stage changes");
    MiracleGrow.writeChatLine("/mg playsound [number] - Plays the given sound number (To find one you like)");
end

function MiracleGrow.writeChatLine(line)
    EA_ChatWindow.Print(towstring(line));
end

function MiracleGrow.menuShow()
    global_data.plot=MiracleGrow.getPlotForButton();
    local cul = GetCultivationInfo(global_data.plot);
    if cul.StageNum == 4 then
    elseif cul.StageNum==0 or cul.StageNum == 255 then
        global_data.seeds=MiracleGrow.getList(GameData.CultivationTypes.SEED);
        EA_Window_ContextMenu.CreateContextMenu("MiracleGrow")
        for index,data in pairs(global_data.seeds) do
            EA_Window_ContextMenu.AddMenuItem(data.item.stackCount..L"x("..data.item.craftingSkillRequirement..L")"..data.item.name, MiracleGrow.addSeed, false, true);
        end
        EA_Window_ContextMenu.Finalize();
    elseif cul.StageNum==1 and cul.Additives[2].uniqueID==0 then
        global_data.soil=MiracleGrow.getList(GameData.CultivationTypes.SOIL);
        EA_Window_ContextMenu.CreateContextMenu("MiracleGrow")
        for index,data in pairs(global_data.soil) do
            EA_Window_ContextMenu.AddMenuItem(data.item.stackCount..L"x("..data.item.craftingSkillRequirement..L")"..data.item.name, MiracleGrow.addSoil, false, true);
        end
        EA_Window_ContextMenu.Finalize();
    elseif cul.StageNum==2 and cul.Additives[3].uniqueID==0 then
        global_data.water=MiracleGrow.getList(GameData.CultivationTypes.WATERCAN);
        EA_Window_ContextMenu.CreateContextMenu("MiracleGrow")
        for index,data in pairs(global_data.water) do
            EA_Window_ContextMenu.AddMenuItem(data.item.stackCount..L"x("..data.item.craftingSkillRequirement..L")"..data.item.name, MiracleGrow.addWater, false, true);
        end
        EA_Window_ContextMenu.Finalize();
    elseif cul.StageNum==3 and cul.Additives[4].uniqueID==0 then
        global_data.nutrients=MiracleGrow.getList(GameData.CultivationTypes.NUTRIENT);
        EA_Window_ContextMenu.CreateContextMenu("MiracleGrow")
        for index,data in pairs(global_data.nutrients) do
            EA_Window_ContextMenu.AddMenuItem(data.item.stackCount..L"x("..data.item.craftingSkillRequirement..L")"..data.item.name, MiracleGrow.addNutrients, false, true);
        end
        EA_Window_ContextMenu.Finalize();
    end
end


function MiracleGrow.getList(type)
    local items=DataUtils.GetCraftingItems();
    local i=1;
    local out={};
    local max=0;
    if MiracleGrow.Settings.maxlvl==0 then
      max=GameData.TradeSkillLevels[GameData.TradeSkills.CULTIVATION];
    else
      max=MiracleGrow.Settings.maxlvl;
    end
    for index,itemdata in pairs(items) do
        if itemdata.cultivationType == type then
            if max >= itemdata.craftingSkillRequirement and itemdata.craftingSkillRequirement >= MiracleGrow.Settings.minlvl then
                out[i]={invIndex=index,item=itemdata};
                i=i+1;
            end
        elseif type==GameData.CultivationTypes.SEED and itemdata.cultivationType==GameData.CultivationTypes.SPORE then
            if max >= itemdata.craftingSkillRequirement and itemdata.craftingSkillRequirement >= MiracleGrow.Settings.minlvl then
                out[i]={invIndex=index,item=itemdata};
                i=i+1;
            end
        end
    end
    table.sort(out, function(a,b) return a["item"].craftingSkillRequirement<b["item"].craftingSkillRequirement end)
    return out;
end

function MiracleGrow.getPlotForButton()
    local mouseWin = SystemData.MouseOverWindow.name
    local but = mouseWin:match("^MiracleGrowPlant([0-9]).*")
    return tonumber(but)
end

function MiracleGrow.addSeed()
    id=MiracleGrow.getContextMenuPressed()
    AddCraftingItem( 3, global_data.plot, global_data.seeds[id].invIndex, EA_Window_Backpack.TYPE_CRAFTING )
end
function MiracleGrow.addSoil()
    id=MiracleGrow.getContextMenuPressed()
    AddCraftingItem( 3, global_data.plot, global_data.soil[id].invIndex, EA_Window_Backpack.TYPE_CRAFTING )
end
function MiracleGrow.addWater()
    id=MiracleGrow.getContextMenuPressed()
    AddCraftingItem( 3, global_data.plot, global_data.water[id].invIndex, EA_Window_Backpack.TYPE_CRAFTING )
end
function MiracleGrow.addNutrients()
    id=MiracleGrow.getContextMenuPressed()
    AddCraftingItem( 3, global_data.plot, global_data.nutrients[id].invIndex, EA_Window_Backpack.TYPE_CRAFTING )
end



function MiracleGrow.getContextMenuPressed()
    local mouseWin=SystemData.MouseOverWindow.name;
    local but = mouseWin:match("^EA_Window_ContextMenu[0-9]+DefaultItem([0-9]+).*")
--    local but=string.sub(mouseWin,38);
    return tonumber(but)
end

function MiracleGrow.fired(culslot)
	MiracleGrow.updatePlant(culslot)
end

function MiracleGrow.OnUpdate()
	MiracleGrow.updatePlant(1);
	MiracleGrow.updatePlant(2);
	MiracleGrow.updatePlant(3);
	MiracleGrow.updatePlant(4);
end

function MiracleGrow.updatePlant(i)
    local cul=GetCultivationInfo(i);
    if global_data.laststage[i] ~= cul.StageNum then
        if global_data.laststage[i] ~= 0 and global_data.laststage[i] ~= 4 then
            if MiracleGrow.Settings.sound == 1 then
                PlaySound(MiracleGrow.Settings.soundnum);
            elseif MiracleGrow.Settings.sound == 2 and cul.StageNum == 4 then
                PlaySound(MiracleGrow.Settings.soundnum);
            end
        end
        global_data.laststage[i] = cul.StageNum;
    end

    if cul.StageNum==4 then
        WindowSetShowing(windowName.."Plant"..i.."Harvest",true)
        WindowSetShowing(windowName.."Plant"..i.."Button",false)
    else
        WindowSetShowing(windowName.."Plant"..i.."Button",true)
        WindowSetShowing(windowName.."Plant"..i.."Harvest",false)
    end

    LabelSetText(windowName.."Plant"..i.."Time",cul.TotalTimer..L"s");
  	LabelSetText(windowName.."Plant"..i.."Stage",cul.StageTimer..L"s");
  	DynamicImageSetTextureSlice(windowName.."Plant"..i.."ButtonFrame","IconFrame-1");
  	DynamicImageSetTextureSlice(windowName.."Plant"..i.."HarvestFrame","IconFrame-1");
  	if cul.StageNum==0 then
  	    DynamicImageSetTextureSlice(windowName.."Plant"..i.."Button".."Icon","Black-Slot");
        global_data.consumestage[i]=0;
  	elseif cul.StageNum==1 then
  	    if cul.Additives[2].uniqueID==0 then
  	        DynamicImageSetTextureSlice(windowName.."Plant"..i.."Button".."Icon","Dirt-Slot");
            if MiracleGrow.Settings.autoconsume and global_data.consumestage[i] < cul.StageNum then
               global_data.consumestage[i]=cul.StageNum;
               MiracleGrow.autoSoil(i)
            end
  	    else
  	        DynamicImageSetTextureSlice(windowName.."Plant"..i.."Button".."Icon","Dirt");
  	    end
  	elseif cul.StageNum==2 then
        if cul.Additives[3].uniqueID==0 then
            DynamicImageSetTextureSlice(windowName.."Plant"..i.."Button".."Icon","WaterDrop-Slot");
            if MiracleGrow.Settings.autoconsume and global_data.consumestage[i] < cul.StageNum then
                global_data.consumestage[i]=cul.StageNum;
                MiracleGrow.autoWater(i)
            end
        else
            DynamicImageSetTextureSlice(windowName.."Plant"..i.."Button".."Icon","WaterDrop");
        end
  	elseif cul.StageNum==3 then
        if cul.Additives[4].uniqueID==0 then
  	        DynamicImageSetTextureSlice(windowName.."Plant"..i.."Button".."Icon","GreenCross-Slot");
            if MiracleGrow.Settings.autoconsume and global_data.consumestage[i] < cul.StageNum then
                global_data.consumestage[i]=cul.StageNum;
                MiracleGrow.autoNutrients(i)
            end
  	    else
  	       DynamicImageSetTextureSlice(windowName.."Plant"..i.."Button".."Icon","GreenCross");
  	    end
  	elseif cul.StageNum==4 then
  	    DynamicImageSetTextureSlice(windowName.."Plant"..i.."Harvest".."Icon","Square-4");
  	end
end

function MiracleGrow.autoSoil(i)
	global_data.soil=MiracleGrow.getList(GameData.CultivationTypes.SOIL);
	numItems=0;
	for index,data in pairs(global_data.soil) do
		numItems=numItems+1;
	end
	if numItems > 0 then
		AddCraftingItem( 3, i, global_data.soil[1].invIndex, EA_Window_Backpack.TYPE_CRAFTING )
	end
end

function MiracleGrow.autoWater(i)
	global_data.water=MiracleGrow.getList(GameData.CultivationTypes.WATERCAN);
	numItems=0;
	for index,data in pairs(global_data.water) do
		numItems=numItems+1;
	end
	if numItems > 0 then
		AddCraftingItem( 3, i, global_data.water[1].invIndex, EA_Window_Backpack.TYPE_CRAFTING )
	end
end

function MiracleGrow.autoNutrients(i)
	global_data.nutrients=MiracleGrow.getList(GameData.CultivationTypes.NUTRIENT);
	numItems=0;
	for index,data in pairs(global_data.nutrients) do
		numItems=numItems+1;
	end
	if numItems > 0 then
		AddCraftingItem( 3, i, global_data.nutrients[1].invIndex, EA_Window_Backpack.TYPE_CRAFTING )
	end
end


function MiracleGrow.explode(div,str)
    if (div=='') then return false end
    local pos,arr = 0,{}
    for st,sp in function() return string.find(str,div,pos,true) end do
        table.insert(arr,string.sub(str,pos,st-1))
        pos = sp + 1
    end
    table.insert(arr,string.sub(str,pos))
    return arr
end

function MiracleGrow.autoGrow()
	local numItems=0;
    local numSeedsRemaining=-1;
    local numSeedsIndex=1;
	global_data.seeds=MiracleGrow.getList(GameData.CultivationTypes.SEED);
	global_data.soil=MiracleGrow.getList(GameData.CultivationTypes.SOIL);
	global_data.water=MiracleGrow.getList(GameData.CultivationTypes.WATERCAN);
	global_data.nutrients=MiracleGrow.getList(GameData.CultivationTypes.NUTRIENT);
	for i=1,4 do
		local cul = GetCultivationInfo(i);
		if cul.StageNum==0 or cul.StageNum == 255 then
			numItems=0;
            numItems=table.getn(global_data.seeds)
            if numSeedsRemaining < 0 then
              numSeedsRemaining=global_data.seeds[1].item.stackCount
            end
			if numItems > 0 and numSeedsRemaining > 0 then
				AddCraftingItem( 3, i, global_data.seeds[numSeedsIndex].invIndex, EA_Window_Backpack.TYPE_CRAFTING )
                numSeedsRemaining=numSeedsRemaining-1
                if numSeedsRemaining <= 0 then
                    numSeedsIndex=numSeedsIndex+1
                    if numSeedsIndex <= numItems then
                      numSeedsRemaining=global_data.seeds[numSeedsIndex].item.stackCount
                    end
                end
			end
		elseif cul.StageNum==1 and cul.Additives[2].uniqueID==0 and not MiracleGrow.Settings.autoconsume then
			numItems=0;
            numItems=table.getn(global_data.soil)
			if numItems > 0 then
				AddCraftingItem( 3, i, global_data.soil[1].invIndex, EA_Window_Backpack.TYPE_CRAFTING )
			end
		elseif cul.StageNum==2 and cul.Additives[3].uniqueID==0 and not MiracleGrow.Settings.autoconsume then
			numItems=0;
            numItems=table.getn(global_data.water)
			if numItems > 0 then
				AddCraftingItem( 3, i, global_data.water[1].invIndex, EA_Window_Backpack.TYPE_CRAFTING )
			end
		elseif cul.StageNum==3 and cul.Additives[4].uniqueID==0 and not MiracleGrow.Settings.autoconsume then
			numItems=0;
            numItems=table.getn(global_data.nutrients)
			if numItems > 0 then
				AddCraftingItem( 3, i, global_data.nutrients[1].invIndex, EA_Window_Backpack.TYPE_CRAFTING )
			end
        elseif cul.StageNum == 4 then
		end

	end
end

function MiracleGrow.onAutoConsumeToggle()
    if MiracleGrow.Settings.autoconsume then
        MiracleGrow.Settings.autoconsume = false
        MiracleGrow.writeChatLine("AutoGrow: off");
    else
        MiracleGrow.Settings.autoconsume = true
        MiracleGrow.writeChatLine("AutoGrow: on");
    end
    MiracleGrow.OverAutoConsume()
end

function MiracleGrow.OverStartAll()
  	WindowSetTintColor(windowName.."StartAllStartAll",128,128,50);
    LabelSetTextColor(windowName.."StartAllStartAllText",255,255,255);
end

function MiracleGrow.OverEndStartAll()
  	WindowSetTintColor(windowName.."StartAllStartAll",128,128,128);
    LabelSetTextColor(windowName.."StartAllStartAllText",225,225,225);
end

function MiracleGrow.setAutoGrowColor()
    if MiracleGrow.Settings.autoconsume then
  	    WindowSetTintColor(windowName.."StartAllAutoGrow",25,240,25)
    else
  	    WindowSetTintColor(windowName.."StartAllAutoGrow",240,25,25)
    end
end

function MiracleGrow.OverAutoConsume()
    if MiracleGrow.Settings.autoconsume then
  	    WindowSetTintColor(windowName.."StartAllAutoGrow",0,140,0)
    else
  	    WindowSetTintColor(windowName.."StartAllAutoGrow",140,0,0)
    end
end

