JunkDestroy for Return of Reckoning
===================================

The addon adds a button to the backpack window.

By default, the button says "Dry Run Junk". Clicking it lists every grey item
and every other configured-rarity item that would be deleted. It does not
delete anything while DEBUG_MODE is true.

Configuration
-------------

Edit JunkDestroyConfig.lua:

1. Leave DEBUG_MODE = true while testing.
2. Set DELETE_RARITIES to the loot colors you want deleted.
3. Add exact item names under WHITE_WHITELIST_NAMES.
4. Add case-insensitive partial names under WHITE_WHITELIST_FUZZY_NAMES.
5. Optionally add item IDs under WHITE_WHITELIST_IDS.
6. Set DEBUG_MODE = false to enable permanent deletion.

Rarity example:

DELETE_RARITIES =
{
    "Grey",
    "White",
    "Green",
}

Fuzzy whitelist example:

WHITE_WHITELIST_FUZZY_NAMES =
{
    "recall scroll",
    "potion",
}

This keeps any matching configured-rarity item containing those words,
regardless of capitalization.

The whitelist table names still start with WHITE_ for compatibility with older
JunkDestroy configs, but they now protect matches from any configured rarity.

Locked inventory slots are skipped. Crafting and quest-item bags are not
processed.
