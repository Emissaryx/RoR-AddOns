<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
    <UiMod name="JunkDestroy" version="1.2.0" date="06/16/2026">
        <Author name="Codex" email="" />
        <Description text="Deletes configured-rarity items from the inventory, with whitelist and dry-run debug mode support." />
        <VersionSettings gameVersion="1.4.8" windowsVersion="1.0" savedVariablesVersion="1.0" />

        <Dependencies>
            <Dependency name="EA_BackpackWindow" />
            <Dependency name="EA_ChatWindow" />
            <Dependency name="EASystem_Tooltips" />
            <Dependency name="EATemplate_DefaultWindowSkin" />
        </Dependencies>

        <Files>
            <File name="JunkDestroyConfig.lua" />
            <File name="JunkDestroy.lua" />
            <File name="JunkDestroy.xml" />
        </Files>

        <OnInitialize>
            <CallFunction name="JunkDestroy.Initialize" />
        </OnInitialize>
        <OnUpdate>
            <CallFunction name="JunkDestroy.OnUpdate" />
        </OnUpdate>

        <WARInfo>
            <Categories>
                <Category name="ITEMS_INVENTORY" />
            </Categories>
        </WARInfo>
    </UiMod>
</ModuleFile>
