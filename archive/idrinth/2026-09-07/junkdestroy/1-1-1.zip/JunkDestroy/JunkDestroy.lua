JunkDestroy = JunkDestroy or {}

local ADDON_PREFIX = L"[JunkDestroy] "
local RARITY_NAME_TO_VALUE =
{
    grey = 1,
    gray = 1,
    trash = 1,
    utility = 1,
    white = 2,
    common = 2,
    green = 3,
    uncommon = 3,
    blue = 4,
    rare = 4,
    purple = 5,
    veryrare = 5,
    orange = 6,
    artifact = 6,
}

local RARITY_DISPLAY_NAMES =
{
    [1] = "Grey",
    [2] = "White",
    [3] = "Green",
    [4] = "Blue",
    [5] = "Purple",
    [6] = "Orange",
}

JunkDestroy.pendingSlots = {}
JunkDestroy.deleteTimer = 0
JunkDestroy.deletedCount = 0

local function Print(message)
    EA_ChatWindow.Print(ADDON_PREFIX .. towstring(message))
end

local function GetPlainItemName(itemName)
    if type(itemName) == "wstring" then
        local normalName = itemName:match(L"([^^]+)^?([^^]*)")
        return WStringToString(normalName or itemName)
    end

    return tostring(itemName or "")
end

local function IsValidItem(itemData)
    return itemData and itemData.uniqueID and itemData.uniqueID ~= 0
end

local function IsInventorySlotLocked(slot)
    local isLocked = EA_Window_Backpack.IsSlotLocked(
        slot,
        EA_Window_Backpack.VIEW_MODE_INVENTORY
    )

    return isLocked == true
end

local function NormalizeRarityName(rarityName)
    return string.gsub(string.lower(rarityName), "[%s_-]", "")
end

function JunkDestroy.GetDeleteRarityMap()
    local configuredRarities = JunkDestroyConfig.DELETE_RARITIES or { "Grey", "White" }
    local deleteRarities = {}

    for key, value in pairs(configuredRarities) do
        local rarity = value
        if value == true then
            rarity = key
        end

        if type(rarity) == "number" then
            deleteRarities[rarity] = true
        elseif type(rarity) == "string" then
            local rarityValue = RARITY_NAME_TO_VALUE[NormalizeRarityName(rarity)]
            if rarityValue then
                deleteRarities[rarityValue] = true
            end
        end
    end

    return deleteRarities
end

function JunkDestroy.GetDeleteRarityText()
    local deleteRarities = JunkDestroy.GetDeleteRarityMap()
    local rarityNames = {}

    for rarity = 1, 6 do
        if deleteRarities[rarity] then
            table.insert(rarityNames, RARITY_DISPLAY_NAMES[rarity])
        end
    end

    if #rarityNames == 0 then
        return "None"
    end

    return table.concat(rarityNames, ", ")
end

local function IsFuzzyWhitelisted(itemName)
    local fuzzyNames = JunkDestroyConfig.WHITE_WHITELIST_FUZZY_NAMES or {}
    local lowerItemName = string.lower(itemName)

    for key, value in pairs(fuzzyNames) do
        local partialName = value
        if value == true then
            partialName = key
        end

        if type(partialName) == "string"
            and partialName ~= ""
            and string.find(lowerItemName, string.lower(partialName), 1, true)
        then
            return true
        end
    end

    return false
end

function JunkDestroy.IsWhitelistedItem(itemData)
    local whitelistIds = JunkDestroyConfig.WHITE_WHITELIST_IDS or {}
    local whitelistNames = JunkDestroyConfig.WHITE_WHITELIST_NAMES or {}

    if whitelistIds[itemData.uniqueID] then
        return true
    end

    local itemName = GetPlainItemName(itemData.name)
    return whitelistNames[itemName] == true
        or IsFuzzyWhitelisted(itemName)
end

function JunkDestroy.ShouldDelete(itemData, slot)
    if not IsValidItem(itemData) or IsInventorySlotLocked(slot) then
        return false
    end

    local deleteRarities = JunkDestroy.GetDeleteRarityMap()
    return deleteRarities[itemData.rarity] == true
        and not JunkDestroy.IsWhitelistedItem(itemData)
end

function JunkDestroy.ScanInventory()
    local inventory = GetInventoryItemData()
    local slots = {}

    for slot, itemData in pairs(inventory) do
        if JunkDestroy.ShouldDelete(itemData, slot) then
            table.insert(slots, slot)
        end
    end

    table.sort(slots)
    return slots, inventory
end

function JunkDestroy.Run()
    if #JunkDestroy.pendingSlots > 0 then
        Print(L"A deletion run is already in progress.")
        return
    end

    local slots, inventory = JunkDestroy.ScanInventory()

    if #slots == 0 then
        Print(L"No matching configured-rarity items found. Deleting: "
            .. towstring(JunkDestroy.GetDeleteRarityText()))
        return
    end

    if JunkDestroyConfig.DEBUG_MODE then
        Print(L"DEBUG MODE: no items will be deleted.")
        Print(L"Configured rarities: " .. towstring(JunkDestroy.GetDeleteRarityText()))

        for _, slot in ipairs(slots) do
            local itemData = inventory[slot]
            Print(L"Would delete slot " .. slot .. L": " .. itemData.name)
        end

        Print(L"DEBUG MODE: " .. #slots .. L" item(s) identified.")
        return
    end

    JunkDestroy.pendingSlots = slots
    JunkDestroy.deleteTimer = 0
    JunkDestroy.deletedCount = 0
end

function JunkDestroy.OnUpdate(elapsedTime)
    if #JunkDestroy.pendingSlots == 0 then
        return
    end

    JunkDestroy.deleteTimer = JunkDestroy.deleteTimer + elapsedTime
    if JunkDestroy.deleteTimer < JunkDestroyConfig.DELETE_INTERVAL then
        return
    end

    JunkDestroy.deleteTimer = 0

    local slot = table.remove(JunkDestroy.pendingSlots, 1)
    local inventory = GetInventoryItemData()
    local itemData = inventory[slot]

    if JunkDestroy.ShouldDelete(itemData, slot) then
        DestroyItem(Cursor.SOURCE_INVENTORY, slot)
        JunkDestroy.deletedCount = JunkDestroy.deletedCount + 1
    end

    if #JunkDestroy.pendingSlots == 0 then
        Print(L"Deleted " .. JunkDestroy.deletedCount .. L" item(s).")
    end
end

function JunkDestroy.OnMouseOverButton()
    Tooltips.CreateTextOnlyTooltip("JunkDestroyButton")
    Tooltips.SetTooltipText(1, 1, L"Delete configured-rarity junk")
    Tooltips.SetTooltipText(2, 1, L"Deleting: "
        .. towstring(JunkDestroy.GetDeleteRarityText()))

    if JunkDestroyConfig.DEBUG_MODE then
        Tooltips.SetTooltipText(3, 1, L"DEBUG MODE: reports items without deleting")
    else
        Tooltips.SetTooltipText(3, 1, L"LIVE MODE: clicking permanently deletes items")
    end

    Tooltips.Finalize()
    Tooltips.AnchorTooltip(Tooltips.ANCHOR_WINDOW_LEFT)
end

function JunkDestroy.Initialize()
    CreateWindow("JunkDestroyButton", true)
    WindowClearAnchors("JunkDestroyButton")
    WindowAddAnchor(
        "JunkDestroyButton",
        "left",
        "EA_Window_BackpackMoney",
        "right",
        -5,
        0
    )
    WindowSetParent("JunkDestroyButton", "EA_Window_Backpack")

    if JunkDestroyConfig.DEBUG_MODE then
        ButtonSetText("JunkDestroyButton", L"Dry Run Junk")
        Print(L"Loaded in DEBUG MODE. Edit JunkDestroyConfig.lua to enable deletion.")
    else
        ButtonSetText("JunkDestroyButton", L"Delete Junk")
        Print(L"Loaded in LIVE MODE.")
    end

    Print(L"Configured rarities: " .. towstring(JunkDestroy.GetDeleteRarityText()))
end
