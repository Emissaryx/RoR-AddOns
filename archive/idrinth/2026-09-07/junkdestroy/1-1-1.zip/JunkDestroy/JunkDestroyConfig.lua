-- JunkDestroy configuration
--
-- Keep this true until you have checked the dry-run output in chat.
-- Set it to false when you are ready for the button to delete items.
JunkDestroyConfig =
{
    DEBUG_MODE = false,

    -- Rarities to delete from the main inventory.
    -- Valid names: "Grey", "White", "Green", "Blue", "Purple", "Orange"
    -- RoR/API names also work: "Utility", "Common", "Uncommon",
    -- "Rare", "Very Rare", "Artifact".
    DELETE_RARITIES =
    {
        "Grey",
        "White",
        --"Green",
    },

    -- Exact, case-sensitive item names to keep.
    -- Despite the historic WHITE_ name, these protect matching items from
    -- any configured rarity in DELETE_RARITIES.
    -- Add entries like:
    -- ["Example Item Name"] = true,
    WHITE_WHITELIST_NAMES =
    {
        ["Guild Recall Scroll"] = true
    },

    -- Case-insensitive partial names to keep.
    -- Despite the historic WHITE_ name, these protect matching items from
    -- any configured rarity in DELETE_RARITIES.
    -- For example, "recall scroll" keeps every configured-rarity item whose name
    -- contains "recall scroll".
    WHITE_WHITELIST_FUZZY_NAMES =
    {
        -- "recall scroll",
        "Unrefined",
        "bag",
        "tool",
        "unguent",
        "steed",
        "ore",
        "scroll",
        "contraption"


    },

    -- Optional: item IDs to keep. IDs are safer than names when known.
    -- Add entries like:
    -- [123456] = true,
    WHITE_WHITELIST_IDS =
    {
    },

    -- Seconds between deletion requests in live mode.
    DELETE_INTERVAL = 0.10,
}
