RandomSayings = {}

 local versionNumber = "2.0"
 local titleString = towstring("<icon=57> <LINK data=\"0\" text=\"[RandomSayings]\" color=\"50,255,50\"> version "..versionNumber.." ")

function RandomSayings.OnInitialize()
    d (L"Initializing Settings")
	if (RandomSayings.Settings == nil) then
		RandomSayings.Settings = {}
	end

	if (RandomSayings.Settings.MySayings ~= nil) then 
		EA_ChatWindow.Print(titleString..towstring("has loaded "..#RandomSayings.Settings.MySayings.." pre-saved user saying group(s)."))
	else
		d (L"RandomSayings has not detected any saved personal Settings.  Attempting to load Defaults.")
		RandomSayings.Settings.MySayings = DefaultSettings.MySayings
		EA_ChatWindow.Print(titleString..towstring("has successfully loaded "..#DefaultSettings.MySayings.." Default saying group(s)."))
	 end
end


function RandomSayings.Speak(option)
    local setNumber = tonumber(option)
    if (setNumber <= #RandomSayings.Settings.MySayings) then
	    local selectedSet = RandomSayings.Settings.MySayings[setNumber]
		d (L"User selected set number "..setNumber..L", which has "..#selectedSet..L" options in it.")
        local selectedPhrase = towstring(selectedSet[math.random(1,#selectedSet)])
        SendChatText(towstring("/say ")..selectedPhrase, L"")
    end
end