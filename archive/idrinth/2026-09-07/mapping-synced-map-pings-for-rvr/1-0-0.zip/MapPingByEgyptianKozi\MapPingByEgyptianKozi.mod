<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
	<UiMod name="MapPingByEgyptianKozi" version="1.0.0" date="07/26/2026" autoenabled="true">

		<VersionSettings gameVersion="1.4.8" windowsVersion="1.0" savedVariablesVersion="1.0" />

		<Author name="Custom" email="" />
		<Description text="Map Ping: right-click the open World Map to drop a pulsing marker on the World Map and Minimap, synced to your party/warband (leader-only in groups), with a sound cue. Right-click a ping again to remove it. /mapping for options." />

		<Dependencies>
			<Dependency name="EA_ChatWindow" />
			<Dependency name="LibSlash" optional="true" forceEnable="true" />
		</Dependencies>

		<Files>
			<File name="MapPingByEgyptianKozi.xml" />
			<File name="MapPingByEgyptianKozi.lua" />
		</Files>

		<OnInitialize>
			<CallFunction name="MapPingByEgyptianKozi.Initialize" />
		</OnInitialize>

		<OnUpdate>
			<CallFunction name="MapPingByEgyptianKozi.Update" />
		</OnUpdate>

		<OnShutdown>
			<CallFunction name="MapPingByEgyptianKozi.Shutdown" />
		</OnShutdown>

		<SavedVariables>
			<SavedVariable name="MapPingByEgyptianKozi.Settings" global="false" />
		</SavedVariables>

	</UiMod>
</ModuleFile>
