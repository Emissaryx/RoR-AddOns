--[[
	MapPingByEgyptianKozi - Synced map pings for Return of Reckoning

	Right-click the OPEN World Map to drop a pulsing beacon on both the World Map
	and the Minimap. The ping is broadcast to your party/warband (leader-only in a
	group; anyone when solo) as a short tagged party/warband chat line and shown
	on every member's maps with a sound cue. Right-click a ping marker again to
	remove it. Pings persist until removed (right-click) or /mapping clear, and a
	new ping replaces the previous one (only one ping shows at a time).

	All the load-bearing APIs here are the ones proven by the CanvasByEgyptianKozi
	and Enemy addons on this exact client:
	  - Map frames:   EA_Window_WorldMap / EA_Window_WorldMapZoneView /
	                  EA_Window_WorldMapZoneViewMapDisplay
	  - Minimap:      EA_Window_OverheadMap / EA_Window_OverheadMapMapDisplay
	  - Zone id:      EA_Window_WorldMap.currentMap
	  - Mouse->local: SystemData.MousePosition + WindowGetScreenPosition/
	                  WindowGetDimensions/WindowGetScale
	  - Click hook:   WindowRegisterCoreEventHandler(frame,"OnRButtonUp",...)
	  - Leadership:   GameData.Player.isGroupLeader / GetBattlegroupMemberData
	  - Chat sync:    SendChatText("/wb|/p ...") + CHAT_TEXT_ARRIVED interception
]]--

MapPingByEgyptianKozi = MapPingByEgyptianKozi or {}
MapPingByEgyptianKozi.Settings = MapPingByEgyptianKozi.Settings or {}

local MP = MapPingByEgyptianKozi

-- Locals for performance / clarity
local d = EA_ChatWindow and EA_ChatWindow.Print or function() end
local towstring = towstring
local tostring = tostring
local tonumber = tonumber
local pairs = pairs
local tinsert = table.insert
local mfloor = math.floor

-- Verified window names (see header)
local MAP_ROOT   = "EA_Window_WorldMap"
local MAP_VIEW   = "EA_Window_WorldMapZoneView"
local MAP_AREA   = "EA_Window_WorldMapZoneViewMapDisplay"

local MARKER_TEMPLATE = "MapPingByEgyptianKoziMarker"
local WORLD_OVERLAY   = "MapPingByEgyptianKoziOverlay"
local HEAD_TEMPLATE   = "MapPingByEgyptianKoziHeadBeacon"

-- Ping payload tag broadcast over chat and filtered on receipt.
local PING_TAG = "[KBPING]"

-- Map coordinate scale (0..COORD_MAX on each axis), per the client convention.
local COORD_MAX = 65535

-- Pings persist until removed manually (right-click a marker) or /mapping clear.
-- Set to a positive number of seconds to re-enable auto-expiry.
local PING_LIFETIME = 0   -- 0 = never auto-expire

-- Throttle so a leader can't spam the channel faster than this (seconds).
local PING_SEND_COOLDOWN = 1.0

-------------------------------------------------------------------------------
-- Internal state
-------------------------------------------------------------------------------
local initialized = false
local playerName = L""

-- Active pings, keyed by a unique id. Each entry:
--   { zone, x, y, born, from,
--     worldWin, headWin, headObj,  -- world-map marker + attached head beacon
--     pulseElapsed, pulseUp }
local activePings = {}
local nextPingId = 1

-- Cached leadership result (recomputed periodically, not every frame).
local canPingCached = true
local leaderCheckElapsed = 0
local LEADER_CHECK_INTERVAL = 2.0

-- Registration guards
local clickHooked = false
local overlayAttached = false
-- The map-display frame we attached the click handler to (MAP_AREA if it exists,
-- else MAP_VIEW). Kept so coordinate math uses the same frame we hooked.
local hookedFrame = nil

-- Update accumulators
local cleanupElapsed = 0

-- Last time we sent a ping (throttle)
local lastSendTime = 0

-- Set when a marker was just dismissed, so the map-area right-click handler can
-- ignore the same click (prevents "dismiss then immediately re-ping same spot").
local suppressNextMapClick = false


-------------------------------------------------------------------------------
-- Small utilities
-------------------------------------------------------------------------------
local function clamp(v, lo, hi)
	if (v < lo) then return lo end
	if (v > hi) then return hi end
	return v
end

-- Mouse-event modifier detection (same approach as CanvasByEgyptianKozi).
-- Handlers receive a `flags` bitmask; test a bit against SystemData.ButtonFlags.
local function HasFlag(flags, flag)
	if (type(flags) ~= "number" or type(flag) ~= "number" or flag <= 0) then
		return false
	end
	local q = mfloor(flags / flag)
	return (q - 2 * mfloor(q / 2)) == 1
end

local function ShiftFlag()
	if (SystemData and SystemData.ButtonFlags and SystemData.ButtonFlags.SHIFT) then
		return SystemData.ButtonFlags.SHIFT
	end
	return 1  -- stock client value
end

-- Strip the career-line suffix (^...) that unit/player names can carry.
local function FixName(str)
	if (str == nil) then return L"" end
	if (type(str) == "wstring") then
		local m = wstring.match(str, L"([^%^]+)")
		return m or str
	end
	return towstring(tostring(str))
end

local function Now()
	local t = GetComputerTime and GetComputerTime() or 0
	return t or 0
end


-------------------------------------------------------------------------------
-- Leadership / channel resolution
--   Solo (no party, no warband) -> allowed to ping (local only).
--   In a warband  -> only if we are our group's leader flag in the battlegroup.
--   In a party    -> only if nobody else is flagged leader (i.e. we are).
-- Mirrors CanvasByEgyptianKozi.ComputeIsLeader, which works on this client.
-------------------------------------------------------------------------------
local function IsInWarband()
	if (type(GetBattlegroupMemberData) ~= "function") then return false end
	local ok, data = pcall(GetBattlegroupMemberData)
	if (not ok or type(data) ~= "table") then return false end
	for _, group in pairs(data) do
		if (type(group) == "table" and type(group.players) == "table") then
			for _, p in pairs(group.players) do
				if (type(p) == "table" and p.name ~= nil
						and FixName(p.name) == playerName) then
					return true
				end
			end
		end
	end
	return false
end

local function IsInParty()
	-- GetNumGroupmates returns count of OTHER party members (0 when solo).
	if (type(GetNumGroupmates) == "function") then
		local ok, n = pcall(GetNumGroupmates)
		if (ok and type(n) == "number") then return n > 0 end
	end
	-- Fallback: GameData flag if present.
	if (GameData and GameData.Player and GameData.Player.isInGroup ~= nil) then
		return GameData.Player.isInGroup == true
	end
	return false
end

-- Returns true if the player is allowed to BROADCAST a ping.
local function ComputeCanPing()
	local inWarband = IsInWarband()
	local inParty   = IsInParty()

	-- Solo: always allowed (local-only ping).
	if (not inWarband and not inParty) then
		return true
	end

	-- Warband: find ourselves in the battlegroup data and require the leader flag.
	if (inWarband and type(GetBattlegroupMemberData) == "function") then
		local ok, data = pcall(GetBattlegroupMemberData)
		if (ok and type(data) == "table") then
			for _, group in pairs(data) do
				if (type(group) == "table" and type(group.players) == "table") then
					for _, p in pairs(group.players) do
						if (type(p) == "table" and p.name ~= nil
								and FixName(p.name) == playerName) then
							return p.isGroupLeader == true
						end
					end
				end
			end
		end
		return false  -- in a warband but couldn't verify ourselves: deny
	end

	-- Party: we are leader unless someone ELSE is flagged leader.
	if (GameData and GameData.Player and GameData.Player.isGroupLeader ~= nil) then
		return GameData.Player.isGroupLeader == true
	end

	return true
end

local function RefreshLeadership()
	canPingCached = ComputeCanPing()
end

-- Public wrapper so group/warband change events can trigger a leadership refresh.
function MapPingByEgyptianKozi.RefreshLeadershipEvent()
	RefreshLeadership()
end

-- Choose the broadcast channel command for the current group context.
-- Returns "/wb", "/p", or nil (solo -> no broadcast). Uses the same primitives
-- CanvasByEgyptianKozi uses (IsWarBandActive / GetNumGroupmates).
local function GetBroadcastChannel()
	if (type(IsWarBandActive) == "function") then
		local ok, active = pcall(IsWarBandActive)
		if (ok and active) then return "/wb" end
	elseif (IsInWarband()) then
		return "/wb"
	end
	if (IsInParty()) then return "/p" end
	return nil
end


-------------------------------------------------------------------------------
-- Realm colour for the beacon (your realm's colour)
-------------------------------------------------------------------------------
local function GetPingColor()
	local realm = (GameData and GameData.Player and GameData.Player.realm) or 1
	-- Order = blue, Destruction = red
	if (realm == 1) then
		return 60, 160, 255
	else
		return 255, 60, 60
	end
end

-- The colour for a specific ping: green for a personal (private) ping, else the
-- realm colour for the shared group ping.
local function GetColorForPing(ping)
	if (ping and ping.personal) then
		return 40, 220, 70
	end
	return GetPingColor()
end


-------------------------------------------------------------------------------
-- Map helpers
-------------------------------------------------------------------------------
local function WorldMapIsOpen()
	return DoesWindowExist(MAP_ROOT) and WindowGetShowing(MAP_ROOT)
end

-- Current displayed zone/map id from the stock world map.
local function GetCurrentMapZone()
	if (EA_Window_WorldMap and type(EA_Window_WorldMap.currentMap) == "number") then
		return EA_Window_WorldMap.currentMap
	end
	return 0
end

-- The player's current PHYSICAL zone id (where they stand), or nil.
local function GetPlayerZone()
	if (GameData and GameData.Player and type(GameData.Player.zone) == "number") then
		return GameData.Player.zone
	end
	return nil
end

-- Convert the current mouse cursor position into normalized 0..1 coords inside a
-- given map-display frame. Returns nx, ny or nil if it can't be computed.
local function MouseToNormalized(frame)
	if (not DoesWindowExist(frame)) then return nil end
	if (not (SystemData and SystemData.MousePosition)) then return nil end

	local mx = tonumber(SystemData.MousePosition.x)
	local my = tonumber(SystemData.MousePosition.y)
	if (mx == nil or my == nil) then return nil end

	local wx, wy = WindowGetScreenPosition(frame)
	local w, h   = WindowGetDimensions(frame)
	local scale  = WindowGetScale(frame)
	if (not (wx and wy and w and h) or w <= 0 or h <= 0) then return nil end
	if (scale == nil or scale <= 0) then scale = 1 end

	local localX = (mx - wx) / scale
	local localY = (my - wy) / scale

	return clamp(localX / w, 0, 1), clamp(localY / h, 0, 1)
end

-- Attach the world-map overlay: parent it to the zone-view and stretch it over
-- the map display frame. World markers are children of this overlay so the stock
-- map's redraws don't clear them (the pattern CanvasByEgyptianKozi uses).
-- Returns true once the overlay is attached and usable.
-- The frame the overlay is actually anchored over (MAP_AREA if it exists, else
-- MAP_VIEW). Coordinate math must use this exact frame.
local overlayFrame = nil

-- Resolve the world-map frame to place markers directly onto. No separate
-- overlay window: the minimap markers prove that parenting a template instance
-- straight onto a map frame works, and the pre-created overlay window wasn't
-- being registered on this build. So world markers parent directly to the map
-- frame (MAP_AREA if it exists, else MAP_VIEW) exactly like the minimap ones.
-- Returns the frame name, or nil if the world map frame isn't available.
local function ResolveWorldFrame()
	if (DoesWindowExist(MAP_AREA)) then return MAP_AREA end
	if (DoesWindowExist(MAP_VIEW)) then return MAP_VIEW end
	if (DoesWindowExist(MAP_ROOT)) then return MAP_ROOT end
	return nil
end

-- Place a marker window at normalized coords inside a map-display frame.
-- The marker is centered on the point.
local function PlaceMarker(win, frame, nx, ny)
	if (not DoesWindowExist(win) or not DoesWindowExist(frame)) then return false end

	local w, h = WindowGetDimensions(frame)
	if (not (w and h) or w <= 0 or h <= 0) then return false end

	local px = nx * w
	local py = ny * h

	-- Marker is 28x28; offset by half so it centers on the point.
	WindowClearAnchors(win)
	WindowAddAnchor(win, "topleft", frame, "topleft", px - 14, py - 14)
	return true
end


-------------------------------------------------------------------------------
-- Ping marker creation / destruction
-------------------------------------------------------------------------------
local function MarkerWindowName(id, which)
	return "MapPingMarker_" .. which .. "_" .. id
end

-- Instantiate one marker on a given map frame; returns the window name or nil.
local function SpawnMarkerOn(id, which, frame, nx, ny, r, g, b)
	if (not DoesWindowExist(frame)) then return nil end

	local win = MarkerWindowName(id, which)
	if (DoesWindowExist(win)) then
		pcall(DestroyWindow, win)
	end

	local ok = pcall(CreateWindowFromTemplate, win, MARKER_TEMPLATE, frame)
	if (not ok or not DoesWindowExist(win)) then return nil end

	-- Parent + anchor onto the map frame so it scrolls/scales with the map.
	pcall(WindowSetParent, win, frame)
	pcall(WindowSetScale, win, 1.0)

	-- Tint the coloured body to the realm colour; keep border dark + core white.
	pcall(WindowSetTintColor, win .. "Border", 0, 0, 0)
	pcall(WindowSetTintColor, win .. "Outer", r, g, b)
	pcall(WindowSetTintColor, win .. "Core", 255, 255, 255)

	if (not PlaceMarker(win, frame, nx, ny)) then
		pcall(DestroyWindow, win)
		return nil
	end

	WindowSetShowing(win, true)
	pcall(WindowSetAlpha, win, 1.0)
	return win
end

-- The player's own world object id (the entity to hang the head beacon on).
local function GetPlayerWorldObj()
	if (GameData and GameData.Player and type(GameData.Player.worldObjNum) == "number"
			and GameData.Player.worldObjNum ~= 0) then
		return GameData.Player.worldObjNum
	end
	return nil
end

-- Spawn a 3D "above head" beacon attached to the player's world object, so it
-- floats over the character and stays glued through movement / jumping / mount
-- (the engine drives the attach - same mechanism as the target arrow). Returns
-- the (windowName, attachedObjId) pair, or nil.
local function SpawnHeadBeacon(id, r, g, b)
	local objId = GetPlayerWorldObj()
	if (objId == nil) then return nil, nil end

	local win = MarkerWindowName(id, "head")
	if (DoesWindowExist(win)) then pcall(DestroyWindow, win) end

	local ok = pcall(CreateWindowFromTemplate, win, HEAD_TEMPLATE, "Root")
	if (not ok or not DoesWindowExist(win)) then return nil, nil end

	local okA = pcall(AttachWindowToWorldObject, win, objId)
	if (not okA) then
		pcall(DestroyWindow, win)
		return nil, nil
	end

	-- Tint the beacon (children live under $parentContent).
	pcall(WindowSetTintColor, win .. "ContentBorder", 0, 0, 0)
	pcall(WindowSetTintColor, win .. "ContentBody", r, g, b)
	pcall(WindowSetTintColor, win .. "ContentCore", 255, 255, 255)

	WindowSetShowing(win, true)
	pcall(WindowSetAlpha, win, 1.0)
	return win, objId
end

local function DestroyPingWindows(ping)
	if (ping.worldWin and DoesWindowExist(ping.worldWin)) then
		pcall(DestroyWindow, ping.worldWin)
	end
	-- Detach the head beacon from its world object before destroying it.
	if (ping.headWin and DoesWindowExist(ping.headWin)) then
		if (ping.headObj) then
			pcall(DetachWindowFromWorldObject, ping.headWin, ping.headObj)
		end
		pcall(DestroyWindow, ping.headWin)
	end
	ping.worldWin = nil
	ping.headWin = nil
	ping.headObj = nil
end

local function RemovePing(id)
	local ping = activePings[id]
	if (not ping) then return end
	DestroyPingWindows(ping)
	activePings[id] = nil
end

-- Create and display a ping locally (used for both self and received pings).
--   personal = true  -> private green local-only ping (only you see it)
--   personal = false -> the shared group ping (realm colour)
local function ShowPing(zone, x, y, fromName, personal)
	local curZone = GetCurrentMapZone()

	-- One ping per TYPE: a new ping replaces the existing ping of the same kind,
	-- but a personal (green) ping and the shared ping can coexist.
	for existingId, existing in pairs(activePings) do
		if ((existing.personal == true) == (personal == true)) then
			RemovePing(existingId)
		end
	end

	local id = nextPingId
	nextPingId = nextPingId + 1

	-- A ping belongs to the zone it was placed in. The WORLD-map marker is shown
	-- only while that zone is displayed (managed each frame by SyncWorldMarker).
	-- The HEAD beacon floats above your own character (attached to your world
	-- object) whenever you're physically in the ping's zone.
	local ping = {
		zone = zone,
		x = x,
		y = y,
		born = Now(),
		from = fromName or L"",
		personal = (personal == true),
		worldWin = nil,
		headWin = nil,
		headObj = nil,
		pulseElapsed = 0,
		pulseUp = false,
	}
	activePings[id] = ping

	local nx = clamp(x / COORD_MAX, 0, 1)
	local ny = clamp(y / COORD_MAX, 0, 1)
	-- Personal pings are green; shared pings use the realm colour.
	local r, g, b
	if (ping.personal) then
		r, g, b = 40, 220, 70
	else
		r, g, b = GetPingColor()
	end

	-- World marker: created next frame by SyncWorldMarker if the displayed zone
	-- matches. But create it immediately too when appropriate, so a self-placed
	-- ping appears instantly.
	if (WorldMapIsOpen() and GetCurrentMapZone() == zone) then
		local worldFrame = ResolveWorldFrame()
		if (worldFrame) then
			ping.worldWin = SpawnMarkerOn(id, "world", worldFrame, nx, ny, r, g, b)
		end
	end

	-- Head beacon above your own character, when you're in the ping's zone.
	if (zone == curZone) then
		ping.headWin, ping.headObj = SpawnHeadBeacon(id, r, g, b)
	end

	-- Audio cue
	if (MP.Settings.sound and GameData and GameData.Sound) then
		local snd = GameData.Sound.HELP_TIPS_NEW or GameData.Sound.QUEST_OBJECTIVES_COMPLETED
		if (snd) then pcall(PlaySound, snd) end
	end

	-- Store the marker windows on the ping so cleanup can find them.
	return id
end


-------------------------------------------------------------------------------
-- Broadcast + receive
-------------------------------------------------------------------------------
local function BroadcastPing(zone, x, y)
	local channel = GetBroadcastChannel()
	if (channel == nil) then return end          -- solo: nothing to broadcast
	if (type(SendChatText) ~= "function") then return end

	-- Payload: "/wb|/p [KBPING] <zone> <x> <y>" - integers only, space separated.
	-- NOTE: this RoR chat path can't hide the line on receipt, so members WILL
	-- see this short one-liner in their party/warband chat. It's kept compact and
	-- tagged so it's easy to recognize. (A truly hidden data channel does not
	-- exist on this client.)
	local payload = towstring(PING_TAG .. " " .. tostring(zone) .. " "
		.. tostring(mfloor(x)) .. " " .. tostring(mfloor(y)))
	local cmd = towstring(channel .. " ") .. payload
	pcall(SendChatText, cmd, L"")
end

-- Trigger a ping. Two kinds:
--   personal = false : the shared group ping (leader-only in a group), broadcast
--                      to the party/warband so everyone sees it (realm colour).
--   personal = true  : a PRIVATE local-only ping (green). Anyone can place it
--                      regardless of leadership; it is NEVER broadcast and is
--                      visible only to you.
local function DoPing(zone, x, y, personal)
	local now = Now()
	if (now - lastSendTime < PING_SEND_COOLDOWN) then
		return
	end
	lastSendTime = now

	if (personal) then
		-- Private ping: no permission check, no broadcast.
		ShowPing(zone, x, y, playerName, true)
		return
	end

	-- Shared ping: leader-only in a group; always allowed solo.
	if (not canPingCached) then
		d(L"[MapPing] Only the party/warband leader can place a shared ping. Use Shift+Right-Click for a private (green) ping.")
		return
	end

	ShowPing(zone, x, y, playerName, false)
	BroadcastPing(zone, x, y)
end


-------------------------------------------------------------------------------
-- Chat interception: parse [KBPING] payloads coming over party/warband chat.
--
-- Verified against CanvasByEgyptianKozi / Enemy on this client:
--   * event  = SystemData.Events.CHAT_TEXT_ARRIVED
--   * data   = GameData.ChatData  ->  .type / .text / .name
--   * filter by data.type against SystemData.ChatLogFilters.{GROUP,BATTLEGROUP,
--     SCENARIO,SCENARIO_GROUPS}
--
-- NOTE ON SUPPRESSION: this RoR chat path does NOT support cancelling a line
-- from the handler (the stock filter calls are disabled - Enemy notes the same).
-- So we cannot truly hide the raw "[KBPING] ..." text from the chat window here.
-- To keep chat clean anyway, the payload is sent on a dedicated hidden channel
-- when possible; otherwise it appears as a short one-liner. See BroadcastPing.
-------------------------------------------------------------------------------
function MapPingByEgyptianKozi.OnChatTextArrived()
	if (not initialized) then return end
	if (not (GameData and GameData.ChatData)) then return end

	local data = GameData.ChatData
	if (data.text == nil) then return end

	-- Only look at group/warband/scenario chat (where our pings travel).
	local filters = SystemData and SystemData.ChatLogFilters
	if (filters) then
		local t = data.type
		if (t ~= filters.GROUP and t ~= filters.BATTLEGROUP
				and t ~= filters.SCENARIO and t ~= filters.SCENARIO_GROUPS) then
			return
		end
	end

	-- Convert to a plain Lua string for matching.
	local s
	if (WStringToString) then
		local ok, res = pcall(WStringToString, towstring(data.text))
		s = ok and res or nil
	else
		s = tostring(data.text)
	end
	if (s == nil) then return end

	-- Ours? "[KBPING] <zone> <x> <y>"
	local zoneStr, xStr, yStr = s:match("%[KBPING%]%s+(%-?%d+)%s+(%-?%d+)%s+(%-?%d+)")
	if (zoneStr == nil) then return end

	local zone = tonumber(zoneStr)
	local x = tonumber(xStr)
	local y = tonumber(yStr)
	if (zone == nil or x == nil or y == nil) then return end

	-- Skip our own broadcast echoing back (we already showed it locally).
	local from = data.name and FixName(data.name) or L""
	if (from ~= L"" and from == playerName) then return end

	ShowPing(zone, x, y, from)
end


-------------------------------------------------------------------------------
-- World map right-click handler (drop / broadcast a ping)
-------------------------------------------------------------------------------
-- Shared: place a ping at the current mouse position over `frame`.
--   personal = true when Shift was held -> private green local ping.
local function PlacePingAtMouse(frame, personal)
	if (not initialized) then return end
	if (not WorldMapIsOpen()) then return end

	-- If this right-click came from dismissing a marker, swallow it.
	if (suppressNextMapClick) then
		suppressNextMapClick = false
		return
	end

	local nx, ny = MouseToNormalized(frame)
	if (nx == nil) then
		return
	end

	local zone = GetCurrentMapZone()
	local x = mfloor(nx * COORD_MAX + 0.5)
	local y = mfloor(ny * COORD_MAX + 0.5)

	DoPing(zone, x, y, personal)
end

-- Right-click captured via a core-event handler on the world-map frame. The
-- handler receives (flags, x, y): Shift+Right-Click = private green ping,
-- plain Right-Click = shared group ping.
function MapPingByEgyptianKozi.OnMapRButtonUp(flags)
	local personal = HasFlag(flags, ShiftFlag())
	PlacePingAtMouse(hookedFrame or ResolveWorldFrame() or MAP_AREA, personal)
end


-------------------------------------------------------------------------------
-- Marker click handlers: right-click (or left-click) a ping to dismiss it.
-------------------------------------------------------------------------------
local function DismissMarkerByWindow(clickedWin)
	if (clickedWin == nil) then return end
	for id, ping in pairs(activePings) do
		if (ping.worldWin == clickedWin or ping.headWin == clickedWin) then
			RemovePing(id)
			-- Swallow the map-area right-click that rides along with this one,
			-- so dismissing a ping doesn't immediately drop a new ping underneath.
			suppressNextMapClick = true
			return
		end
	end
end

function MapPingByEgyptianKozi.OnMarkerRButtonUp()
	local win = SystemData and SystemData.ActiveWindow and SystemData.ActiveWindow.name
	DismissMarkerByWindow(win)
end

function MapPingByEgyptianKozi.OnMarkerLButtonUp()
	local win = SystemData and SystemData.ActiveWindow and SystemData.ActiveWindow.name
	DismissMarkerByWindow(win)
end


-------------------------------------------------------------------------------
-- Attach the right-click handler to the world map display frame once it exists.
-------------------------------------------------------------------------------
local function TryHookMapClick()
	if (clickHooked) then return end
	if (type(WindowRegisterCoreEventHandler) ~= "function") then return end

	-- The stock map module can load after us. Wait for the zone-view to exist,
	-- then attach to the display frame if present, otherwise the view itself
	-- (mirrors CanvasByEgyptianKozi's fallback).
	if (not DoesWindowExist(MAP_VIEW)) then return end
	local frame = DoesWindowExist(MAP_AREA) and MAP_AREA or MAP_VIEW

	local ok1 = pcall(WindowRegisterCoreEventHandler, frame, "OnRButtonUp",
		"MapPingByEgyptianKozi.OnMapRButtonUp")
	-- Also register left-button-down as a fallback trigger path in case this
	-- client routes right-clicks on the map elsewhere (we still gate on Ctrl in
	-- the handler-free path? no - keep it simple: only right-click places pings).
	if (ok1) then
		clickHooked = true
		hookedFrame = frame
		d(towstring("[MapPing] map click handler attached to " .. frame))
	end
end


-------------------------------------------------------------------------------
-- Pulsing animation + reposition + lifetime cleanup (called every frame)
-------------------------------------------------------------------------------
local PULSE_MIN = 0.35
local PULSE_MAX = 1.0
local PULSE_SPEED = 2.2   -- alpha units per second

local function UpdatePingVisual(ping, elapsed)
	-- Pulse alpha up and down between PULSE_MIN and PULSE_MAX.
	local step = PULSE_SPEED * (elapsed or 0)
	if (ping.pulseUp) then
		ping.pulseElapsed = ping.pulseElapsed + step
		if (ping.pulseElapsed >= (PULSE_MAX - PULSE_MIN)) then
			ping.pulseElapsed = (PULSE_MAX - PULSE_MIN)
			ping.pulseUp = false
		end
	else
		ping.pulseElapsed = ping.pulseElapsed - step
		if (ping.pulseElapsed <= 0) then
			ping.pulseElapsed = 0
			ping.pulseUp = true
		end
	end
	local alpha = PULSE_MIN + ping.pulseElapsed

	if (ping.worldWin and DoesWindowExist(ping.worldWin)) then
		pcall(WindowSetAlpha, ping.worldWin, alpha)
	end
	if (ping.headWin and DoesWindowExist(ping.headWin)) then
		pcall(WindowSetAlpha, ping.headWin, alpha)
	end
end

-- Keep the WORLD-map marker in sync with the CURRENTLY displayed map zone.
-- A ping belongs to the zone it was placed in (ping.zone). The world map can be
-- navigated to other zones, so each frame we compare the displayed zone to the
-- ping's zone:
--   * displayed zone matches  -> ensure the marker exists (create if needed)
--   * displayed zone differs, or the map is closed -> destroy the world marker
-- This is what makes a Praag ping vanish when you flip to a different zone map,
-- instead of showing on every map at the same pixel.
local function SyncWorldMarker(id, ping)
	local shouldShow = WorldMapIsOpen()
		and (GetCurrentMapZone() == ping.zone)

	if (not shouldShow) then
		-- Wrong zone / map closed: remove the world marker (keep the ping record;
		-- it reappears when you navigate back to its zone).
		if (ping.worldWin and DoesWindowExist(ping.worldWin)) then
			pcall(DestroyWindow, ping.worldWin)
		end
		ping.worldWin = nil
		return
	end

	-- Right zone and map open: create the marker if it isn't there yet.
	if (ping.worldWin and DoesWindowExist(ping.worldWin)) then return end
	local worldFrame = ResolveWorldFrame()
	if (not worldFrame) then return end

	local nx = clamp(ping.x / COORD_MAX, 0, 1)
	local ny = clamp(ping.y / COORD_MAX, 0, 1)
	local r, g, b = GetColorForPing(ping)
	ping.worldWin = SpawnMarkerOn(id, "world", worldFrame, nx, ny, r, g, b)
end

-- Keep the above-head beacon in sync with the player's physical zone: show it
-- (attached to your world object) only while you're standing in the ping's zone,
-- hide it otherwise. Also re-attaches if your world object id changes (e.g. after
-- a zone load), which keeps it glued through mounting / transitions.
--
-- IMPORTANT: the head beacon is a 3D world (popup-layer) window, so it would draw
-- ON TOP of the open World Map and clutter it next to the real map marker. So we
-- HIDE the head beacon whenever the World Map is open (the map shows its own
-- marker instead) and show it again when the map is closed.
local function SyncHeadBeacon(id, ping)
	local pz = GetPlayerZone()
	local inZone = (pz == nil) or (ping.zone == nil) or (pz == ping.zone)
	local objId = GetPlayerWorldObj()

	-- The beacon should only EXIST while we're in the ping's zone and loaded.
	if (not inZone or objId == nil) then
		if (ping.headWin and DoesWindowExist(ping.headWin)) then
			if (ping.headObj) then
				pcall(DetachWindowFromWorldObject, ping.headWin, ping.headObj)
			end
			pcall(DestroyWindow, ping.headWin)
		end
		ping.headWin = nil
		ping.headObj = nil
		return
	end

	-- Create/re-attach if missing or our world object changed.
	if (not (ping.headWin and DoesWindowExist(ping.headWin) and ping.headObj == objId)) then
		if (ping.headWin and DoesWindowExist(ping.headWin)) then
			if (ping.headObj) then
				pcall(DetachWindowFromWorldObject, ping.headWin, ping.headObj)
			end
			pcall(DestroyWindow, ping.headWin)
			ping.headWin = nil
			ping.headObj = nil
		end
		local r, g, b = GetColorForPing(ping)
		ping.headWin, ping.headObj = SpawnHeadBeacon(id, r, g, b)
	end

	-- Visibility: hide the world beacon while the World Map is open so it doesn't
	-- overlay the map on top of the map's own marker.
	if (ping.headWin and DoesWindowExist(ping.headWin)) then
		local showBeacon = not WorldMapIsOpen()
		pcall(WindowSetShowing, ping.headWin, showBeacon)
	end
end


-------------------------------------------------------------------------------
-- Public: Initialize / Update / Shutdown
-------------------------------------------------------------------------------
function MapPingByEgyptianKozi.Initialize()
	-- Defaults
	if (MP.Settings.enabled == nil) then MP.Settings.enabled = true end
	if (MP.Settings.sound   == nil) then MP.Settings.sound   = true end

	playerName = FixName(GameData and GameData.Player and GameData.Player.name or L"")

	-- Intercept incoming chat so we can catch [KBPING] payloads.
	if (SystemData and SystemData.Events and SystemData.Events.CHAT_TEXT_ARRIVED) then
		pcall(RegisterEventHandler, SystemData.Events.CHAT_TEXT_ARRIVED,
			"MapPingByEgyptianKozi.OnChatTextArrived")
	end

	-- Recompute leadership when the group/warband changes (proven event names).
	if (SystemData and SystemData.Events) then
		if (SystemData.Events.GROUP_STATUS_UPDATED) then
			pcall(RegisterEventHandler, SystemData.Events.GROUP_STATUS_UPDATED,
				"MapPingByEgyptianKozi.RefreshLeadershipEvent")
		end
		if (SystemData.Events.BATTLEGROUP_UPDATED) then
			pcall(RegisterEventHandler, SystemData.Events.BATTLEGROUP_UPDATED,
				"MapPingByEgyptianKozi.RefreshLeadershipEvent")
		end
	end

	-- First leadership computation.
	RefreshLeadership()

	initialized = true
	d(L"[MapPing] Loaded. Open your World Map and RIGHT-CLICK to ping. Right-click a ping to remove it. /mapping for options.")
end

function MapPingByEgyptianKozi.Update(elapsed)
	if (not initialized) then return end
	elapsed = elapsed or 0

	-- Make sure the world-map click handler is attached (map module may load late).
	if (not clickHooked) then
		TryHookMapClick()
	end

	-- Periodically recompute leadership (cheap, but not every frame).
	leaderCheckElapsed = leaderCheckElapsed + elapsed
	if (leaderCheckElapsed >= LEADER_CHECK_INTERVAL) then
		leaderCheckElapsed = 0
		RefreshLeadership()
	end

	-- Animate + maintain + expire pings.
	local now = Now()
	for id, ping in pairs(activePings) do
		-- Expire only if a positive lifetime is configured (0 = never).
		if (PING_LIFETIME > 0 and (now - ping.born) >= PING_LIFETIME) then
			RemovePing(id)
		else
			SyncWorldMarker(id, ping)
			SyncHeadBeacon(id, ping)
			UpdatePingVisual(ping, elapsed)
		end
	end
end

function MapPingByEgyptianKozi.Shutdown()
	for id in pairs(activePings) do
		RemovePing(id)
	end
end


-------------------------------------------------------------------------------
-- Slash command
-------------------------------------------------------------------------------
function MapPingByEgyptianKozi.SlashCommand(args)
	local cmd = ""
	if (args) then
		if (type(args) == "wstring" and WStringToString) then
			local ok, res = pcall(WStringToString, args)
			if (ok and res) then cmd = res end
		else
			cmd = tostring(args)
		end
	end
	cmd = (cmd:match("^%s*(.-)%s*$") or ""):lower():gsub("%s+", " ")

	if (cmd == "sound on") then
		MP.Settings.sound = true
		d(L"[MapPing] Ping sound enabled")

	elseif (cmd == "sound off") then
		MP.Settings.sound = false
		d(L"[MapPing] Ping sound disabled")

	elseif (cmd == "test") then
		-- Drop a shared ping at the map center (local + broadcast).
		local zone = GetCurrentMapZone()
		DoPing(zone, mfloor(COORD_MAX / 2), mfloor(COORD_MAX / 2), false)
		d(L"[MapPing] Test shared ping placed at map center.")

	elseif (cmd == "testp" or cmd == "testprivate") then
		-- Drop a private green ping at the map center (local only, no broadcast).
		local zone = GetCurrentMapZone()
		DoPing(zone, mfloor(COORD_MAX / 2), mfloor(COORD_MAX / 2), true)
		d(L"[MapPing] Test private (green) ping placed at map center.")

	elseif (cmd == "clear") then
		for id in pairs(activePings) do RemovePing(id) end
		d(L"[MapPing] All pings cleared.")

	elseif (cmd == "status") then
		RefreshLeadership()
		local ctx = IsInWarband() and "warband" or (IsInParty() and "party" or "solo")
		d(towstring("[MapPing] Context: " .. ctx
			.. " | can ping: " .. tostring(canPingCached)
			.. " | zone: " .. tostring(GetCurrentMapZone())))

	else
		d(L"[MapPing] Commands:")
		d(L"  Right-Click the OPEN World Map   - Shared group ping (leader only in a group)")
		d(L"  Shift+Right-Click the World Map  - Private GREEN ping (only you see it, anyone can)")
		d(L"  Right-click a ping marker to remove it")
		d(L"  /mapping test          - Place a test shared ping at map center")
		d(L"  /mapping testp         - Place a test private (green) ping at map center")
		d(L"  /mapping clear         - Remove all active pings")
		d(L"  /mapping sound on|off  - Toggle the ping sound")
		d(L"  /mapping status        - Show group/leader/zone info")
	end
end

if (LibSlash and LibSlash.RegisterSlashCmd) then
	pcall(LibSlash.RegisterSlashCmd, "mapping", function(a) MapPingByEgyptianKozi.SlashCommand(a) end)
	pcall(LibSlash.RegisterSlashCmd, "mappingbyegyptiankozi", function(a) MapPingByEgyptianKozi.SlashCommand(a) end)
end
