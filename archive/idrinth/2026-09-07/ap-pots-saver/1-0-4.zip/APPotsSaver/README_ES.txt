APPotsSaver v1.03 - Instrucciones de uso
========================================

Qué hace
--------
APPotsSaver bloquea el uso de acciones configuradas cuando tus AP actuales están POR ENCIMA del límite fijado para esa acción.

Uso básico
----------
1. Coloca tu poción de AP o la acción que quieras proteger en una casilla de la barra.
2. Haz CTRL + clic izquierdo sobre esa casilla para cambiar su límite de AP.
3. El ciclo es:
   limpiar -> 0 -> 10 -> 20 -> ... -> 200 -> limpiar
4. Cuando la acción tenga límite configurado, verás un texto en la casilla:
   - >30AP = bloqueada a partir de 31 AP
   - =0AP  = solo se puede usar a 0 AP

Comando
-------
/appotssaver

Opciones de configuración
-------------------------
Enabled
- Activa o desactiva el addon por completo.

Show Symbols
- Muestra el límite de AP directamente sobre las casillas vigiladas.

Show Combat Error messages
- Muestra un aviso en combate cuando intentas usar una acción bloqueada.

Use Smart GCD Optimization
- Reduce trabajo innecesario de la UI.
- Tras usar una acción, el addon “duerme” durante la mayor parte del GCD.
- Al acercarse el final del GCD, hace comprobaciones rápidas otra vez.

Idle Check Interval
- Intervalo normal de comprobación cuando no está aplicando la pausa inteligente del GCD.
- Más bajo = reacción más rápida.
- Más alto = menos trabajo para la interfaz.

Burst Check Interval
- Intervalo de comprobación rápida al final del GCD.
- 0.1s es el valor más rápido soportado.

GCD Sleep Duration
- Tiempo que el addon espera tras una acción antes de volver a comprobar.
- El valor recomendado es 1.4s.

GCD Burst Window
- Tiempo durante el cual hace comprobaciones rápidas al salir de la pausa del GCD.
- El valor recomendado es 0.2s.

Valores recomendados
--------------------
- Idle Check Interval: 0.5s
- Burst Check Interval: 0.1s
- GCD Sleep Duration: 1.4s
- GCD Burst Window: 0.2s

Notas
-----
- Esta versión solo revisa las casillas realmente configuradas, no toda la barra completa.
- Si desactivas el addon, deja de bloquear acciones y limpia su estado visual.
