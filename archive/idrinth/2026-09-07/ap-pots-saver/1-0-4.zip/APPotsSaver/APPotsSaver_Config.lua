LibConfig = LibStub("LibConfig")

APPotsSaver_Config = {}

local GUI

function APPotsSaver_Config.RoundTenth(value)
	if type(value) ~= "number" then
		value = tonumber(value) or 0
	end
	value = math.floor((value * 10) + 0.5) / 10
	return value
end

function APPotsSaver_Config.FormatTenthSeconds(value)
	value = APPotsSaver_Config.RoundTenth(value)
	return string.format("%.1fs", value)
end

function APPotsSaver_Config.Slash(input)
	if (not GUI) then
		GUI = LibConfig("APPotsSaver v" .. tostring(APPotsSaver.Settings.Version), APPotsSaver.Settings, true, APPotsSaver_Config.SettingsChanged)

		GUI:AddTab("Info")
		local infoText
		infoText = GUI("label", "APPotsSaver blocks configured abilities when your current AP is ABOVE the cap set on that ability.")
		infoText.label:Font("font_default_text_small")
		infoText.label:Align("left")

		infoText = GUI("label", "CTRL-LEFT CLICK a hotbar slot to cycle its AP cap: clear -> 0 -> 10 -> 20 -> ... -> 200 -> clear.")
		infoText.label:Font("font_default_text_small")
		infoText.label:Align("left")

		infoText = GUI("label", "The text on the button is the max AP allowed. Example: >30AP blocks at 31+ AP.")
		infoText.label:Font("font_default_text_small")
		infoText.label:Align("left")

		infoText = GUI("label", "This version only checks watched slots and can sleep through most of the GCD.")
		infoText.label:Font("font_default_text_small")
		infoText.label:Align("left")

		infoText = GUI("label", "Use + and - to change values in 0.1s steps. Recommended defaults: Idle 0.5s, Burst 0.1s, GCD Sleep 1.4s, Burst Window 0.2s.")
		infoText.label:Font("font_default_text_small")
		infoText.label:Align("left")

		GUI:AddTab("Settings")
		local enabled = GUI("checkbox", "Enabled", "Enabled")
		enabled.label:Font("font_default_text_small")
		local desc = GUI("label", "Master switch for the addon. When off, no actions are blocked.")
		desc.label:Font("font_default_text_small")
		desc.label:Align("left")

		local symbols = GUI("checkbox", "Show Symbols", "Symbols")
		symbols.label:Font("font_default_text_small")
		desc = GUI("label", "Shows the configured AP cap on watched hotbar buttons.")
		desc.label:Font("font_default_text_small")
		desc.label:Align("left")

		local errors = GUI("checkbox", "Show Combat Error messages", "ErrorMessages")
		errors.label:Font("font_default_text_small")
		desc = GUI("label", "Shows an alert if you try to use a blocked action.")
		desc.label:Font("font_default_text_small")
		desc.label:Align("left")

		GUI:AddTab("Performance")
		local smartGCD = GUI("checkbox", "Use Smart GCD Optimization", "UseSmartGCD")
		smartGCD.label:Font("font_default_text_small")
		desc = GUI("label", "Sleeps through most of the GCD, then checks again near the end to reduce UI work.")
		desc.label:Font("font_default_text_small")
		desc.label:Align("left")

		local idleStepper = GUI("stepper", "Idle Check Interval", "IdleInterval", APPotsSaver_Config.RoundTenth)
		idleStepper.label:Font("font_default_text_small")
		idleStepper:SetRange(0.1, 2.0, 0.1)
		idleStepper:SetFormatter(APPotsSaver_Config.FormatTenthSeconds)
		desc = GUI("label", "How often watched slots are checked outside Smart GCD mode. Lower reacts faster.")
		desc.label:Font("font_default_text_small")
		desc.label:Align("left")

		local burstStepper = GUI("stepper", "Burst Check Interval", "BurstInterval", APPotsSaver_Config.RoundTenth)
		burstStepper.label:Font("font_default_text_small")
		burstStepper:SetRange(0.1, 2.0, 0.1)
		burstStepper:SetFormatter(APPotsSaver_Config.FormatTenthSeconds)
		desc = GUI("label", "How often watched slots are checked near the end of the GCD. 0.1s is fastest.")
		desc.label:Font("font_default_text_small")
		desc.label:Align("left")

		local sleepStepper = GUI("stepper", "GCD Sleep Duration", "GCDSleepDuration", APPotsSaver_Config.RoundTenth)
		sleepStepper.label:Font("font_default_text_small")
		sleepStepper:SetRange(0.0, 2.0, 0.1)
		sleepStepper:SetFormatter(APPotsSaver_Config.FormatTenthSeconds)
		desc = GUI("label", "How long the addon waits after an action before resuming checks. Default: 1.4s.")
		desc.label:Font("font_default_text_small")
		desc.label:Align("left")

		local windowStepper = GUI("stepper", "GCD Burst Window", "GCDBurstWindow", APPotsSaver_Config.RoundTenth)
		windowStepper.label:Font("font_default_text_small")
		windowStepper:SetRange(0.1, 1.0, 0.1)
		windowStepper:SetFormatter(APPotsSaver_Config.FormatTenthSeconds)
		desc = GUI("label", "Length of the fast-check window after sleep ends. Default: 0.2s.")
		desc.label:Font("font_default_text_small")
		desc.label:Align("left")
	end
	GUI:Show()
end

function APPotsSaver_Config.SettingsChanged()
	GUI:Hide()
	APPotsSaver.NormalizeSettings()
	APPotsSaver.UpdateSettings()
end
