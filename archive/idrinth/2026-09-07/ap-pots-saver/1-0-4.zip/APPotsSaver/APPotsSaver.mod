<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
	<UiMod name="APPotsSaver" version="1.04" date="05/04/2026" >
		<Author name="Kpihuss" email="" />
		<Description text="APPotsSaver. Based on GCDSaver. Optimized watched-slot updates and smart GCD checks." />
		<VersionSettings gameVersion="1.9.9" windowsVersion="1.0" savedVariablesVersion="1.0" />

		<Dependencies>
			<Dependency name="EA_ActionBars" />
			<Dependency name="LibSlash" />
		</Dependencies>
			
		<Files>
			<File name="libs\LibStub.lua" />
			<File name="libs\LibGUI.lua" />
			<File name="libs\LibConfig.lua" />		
			<File name="APPotsSaver.lua" />			
			<File name="APPotsSaver_Config.lua" />					
		</Files>

		<SavedVariables>
			<SavedVariable name="APPotsSaver.Settings" />
		</SavedVariables>

		<OnInitialize>
			<CallFunction name="APPotsSaver.Initialize" />
		</OnInitialize>

		<OnUpdate>
			<CallFunction name="APPotsSaver.OnUpdate" />
		</OnUpdate>

		<OnShutdown>
			<CallFunction name="APPotsSaver.OnShutdown" />
		</OnShutdown>
	</UiMod>
</ModuleFile>
