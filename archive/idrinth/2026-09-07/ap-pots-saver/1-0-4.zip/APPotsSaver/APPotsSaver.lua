-- Local data
local VERSION = 1.04
local MAX_BUTTONS = 60
local MAX_AP = 200
local AP_STEP = 10
local MIN_INTERVAL = 0.1
local MAX_INTERVAL = 2.0
local MIN_BURST_WINDOW = 0.1
local MAX_BURST_WINDOW = 1.0
local DEFAULT_IDLE_INTERVAL = 0.5
local DEFAULT_BURST_INTERVAL = 0.1
local DEFAULT_GCD_SLEEP_DURATION = 1.4
local DEFAULT_GCD_BURST_WINDOW = 0.2

local eventsRegistered = false
local loadingEnd = false
local currentTime = 0
local nextCheckAt = 0
local gcdSleepUntil = 0
local gcdBurstUntil = 0

-- Localized functions
local tostring = tostring
local towstring = towstring
local floor = math.floor
local max = math.max
local min = math.min
local GetAbilityData = GetAbilityData
local GetHotbarData = GetHotbarData
local BroadcastEvent = BroadcastEvent
local TextLogAddEntry = TextLogAddEntry
local RegisterEventHandler = RegisterEventHandler
local UnregisterEventHandler = UnregisterEventHandler

local orgWindowGameAction = WindowGameAction
local orgActionBarsUpdateSlotEnabledState = ActionBars.UpdateSlotEnabledState
local orgActionButtonOnLButtonDown = ActionButton.OnLButtonDown
local orgActionButtonOnLButtonUp = ActionButton.OnLButtonUp
local orgActionButtonUpdateInventory = ActionButton.UpdateInventory

local function clamp(value, minValue, maxValue)
	if value < minValue then return minValue end
	if value > maxValue then return maxValue end
	return value
end

local function roundToStep(value, step)
	if type(value) ~= "number" then
		return value
	end
	return floor((value / step) + 0.5) * step
end

local function sanitizeInterval(value, defaultValue)
	value = tonumber(value) or defaultValue
	value = roundToStep(value, 0.1)
	value = clamp(value, MIN_INTERVAL, MAX_INTERVAL)
	return value
end

local function sanitizeWindow(value, defaultValue)
	value = tonumber(value) or defaultValue
	value = roundToStep(value, 0.1)
	value = clamp(value, MIN_BURST_WINDOW, MAX_BURST_WINDOW)
	return value
end

local function sanitizeSleep(value, defaultValue)
	value = tonumber(value) or defaultValue
	value = roundToStep(value, 0.1)
	value = clamp(value, 0.0, MAX_INTERVAL)
	return value
end

local function boolDefault(value, defaultValue)
	if value == nil then return defaultValue end
	return value and true or false
end

local function alertText(text)
	if SettingsWindowTabInterface and SettingsWindowTabInterface.SavedMessageSettings and SettingsWindowTabInterface.SavedMessageSettings.combat then
		SystemData.AlertText.VecType = {SystemData.AlertText.Types.COMBAT}
		SystemData.AlertText.VecText = {towstring(text)}
		BroadcastEvent(SystemData.Events.SHOW_ALERT_TEXT)
	end
end

local function getCurrentAP()
	if GameData and GameData.Player and GameData.Player.actionPoints then
		local ap = GameData.Player.actionPoints.current
		if type(ap) == "number" then
			return ap
		end
	end
	return 0
end

local function chatInfo(actionId, threshold)
	local ability = GetAbilityData(actionId)
	if not ability then return end
	local name = tostring(ability.name)
	local icon = "<icon" .. tostring(ability.iconNum) .. ">"
	if threshold == nil then
		TextLogAddEntry("Chat", 0, towstring("APPotsSaver: Clearing AP cap for " .. icon .. " " .. name))
	else
		TextLogAddEntry("Chat", 0, towstring("APPotsSaver: Setting max AP " .. threshold .. " for " .. icon .. " " .. name))
	end
end

local function nextThreshold(current)
	if current == nil then
		return 0
	elseif current >= MAX_AP then
		return nil
	else
		return current + AP_STEP
	end
end

local function isConfiguredAction(actionId)
	return actionId ~= nil and actionId ~= 0 and APPotsSaver.Settings and APPotsSaver.Settings.Abilities and APPotsSaver.Settings.Abilities[actionId] ~= nil
end

local function isAbilityBlocked(actionId, showError)
	if not APPotsSaver.Settings.Enabled then
		return false
	end

	local threshold = APPotsSaver.Settings.Abilities[actionId]
	if threshold == nil then
		return false
	end

	local currentAP = getCurrentAP()
	if currentAP > threshold then
		if showError and APPotsSaver.Settings.ErrorMessages then
			alertText("Too much AP: " .. currentAP .. " / max " .. threshold)
		end
		return true
	end

	return false
end

local function tryGetWindowGameActionData(windowName)
	if type(WindowGetGameActionData) ~= "function" then
		return nil
	end

	local ok, a, b, c, d = pcall(WindowGetGameActionData, windowName)
	if not ok then
		return nil
	end

	if type(a) == "table" then
		return a
	end

	return { a, b, c, d }
end

local function resolveActionIdFromWindow(windowName)
	if not windowName then
		return nil
	end

	local data = tryGetWindowGameActionData(windowName)
	if not data then
		return nil
	end

	if data.actionId then return data.actionId end
	if data.ActionId then return data.ActionId end
	if data.abilityId then return data.abilityId end
	if data.AbilityId then return data.AbilityId end
	if data.id then return data.id end
	if data.Id then return data.Id end

	local slot = data.hotbarSlot or data.HotbarSlot or data.slot or data.Slot or data[1]
	local maybeActionId = data[2]
	if type(maybeActionId) == "number" and maybeActionId ~= 0 then
		return maybeActionId
	end
	if type(slot) == "number" and slot >= 1 and slot <= MAX_BUTTONS then
		local _, actionId = GetHotbarData(slot)
		if type(actionId) == "number" and actionId ~= 0 then
			return actionId
		end
	end

	return nil
end

APPotsSaver = APPotsSaver or {}
APPotsSaver.EnabledStatesNeedUpdate = true
APPotsSaver.ButtonIconsNeedUpdate = true
APPotsSaver.FullRefreshNeeded = true
APPotsSaver.WatchedSlots = {}
APPotsSaver.LastSlotStates = {}

APPotsSaver.DefaultSettings = {
	Version = VERSION,
	Enabled = true,
	Symbols = true,
	ErrorMessages = true,
	UseSmartGCD = true,
	IdleInterval = DEFAULT_IDLE_INTERVAL,
	BurstInterval = DEFAULT_BURST_INTERVAL,
	GCDSleepDuration = DEFAULT_GCD_SLEEP_DURATION,
	GCDBurstWindow = DEFAULT_GCD_BURST_WINDOW,
	Abilities = {},
}

function APPotsSaver.NormalizeSettings()
	APPotsSaver.Settings.Version = APPotsSaver.DefaultSettings.Version
	APPotsSaver.Settings.Enabled = boolDefault(APPotsSaver.Settings.Enabled, APPotsSaver.DefaultSettings.Enabled)
	APPotsSaver.Settings.Symbols = boolDefault(APPotsSaver.Settings.Symbols, APPotsSaver.DefaultSettings.Symbols)
	APPotsSaver.Settings.ErrorMessages = boolDefault(APPotsSaver.Settings.ErrorMessages, APPotsSaver.DefaultSettings.ErrorMessages)
	APPotsSaver.Settings.UseSmartGCD = boolDefault(APPotsSaver.Settings.UseSmartGCD, APPotsSaver.DefaultSettings.UseSmartGCD)
	APPotsSaver.Settings.IdleInterval = sanitizeInterval(APPotsSaver.Settings.IdleInterval, APPotsSaver.DefaultSettings.IdleInterval)
	APPotsSaver.Settings.BurstInterval = sanitizeInterval(APPotsSaver.Settings.BurstInterval, APPotsSaver.DefaultSettings.BurstInterval)
	APPotsSaver.Settings.GCDSleepDuration = sanitizeSleep(APPotsSaver.Settings.GCDSleepDuration, APPotsSaver.DefaultSettings.GCDSleepDuration)
	APPotsSaver.Settings.GCDBurstWindow = sanitizeWindow(APPotsSaver.Settings.GCDBurstWindow, APPotsSaver.DefaultSettings.GCDBurstWindow)
	if type(APPotsSaver.Settings.Abilities) ~= "table" then
		APPotsSaver.Settings.Abilities = {}
	end
end

function APPotsSaver.ScheduleNextCheck(forceImmediate)
	if forceImmediate then
		nextCheckAt = currentTime
		return
	end

	if APPotsSaver.Settings.UseSmartGCD and currentTime < gcdSleepUntil then
		nextCheckAt = gcdSleepUntil
		return
	end

	local interval = APPotsSaver.Settings.IdleInterval
	if APPotsSaver.Settings.UseSmartGCD and currentTime < gcdBurstUntil then
		interval = APPotsSaver.Settings.BurstInterval
	end

	nextCheckAt = currentTime + interval
end

function APPotsSaver.MarkDirty(forceImmediate, fullRefresh)
	APPotsSaver.EnabledStatesNeedUpdate = true
	if fullRefresh then
		APPotsSaver.FullRefreshNeeded = true
		APPotsSaver.LastSlotStates = {}
	end
	APPotsSaver.ScheduleNextCheck(forceImmediate)
end

function APPotsSaver.MarkIconsDirty()
	APPotsSaver.ButtonIconsNeedUpdate = true
end

function APPotsSaver.RebuildWatchedSlots()
	local watched = {}
	for slot = 1, MAX_BUTTONS do
		local _, actionId = GetHotbarData(slot)
		if APPotsSaver.Settings.Enabled and isConfiguredAction(actionId) then
			watched[slot] = true
		end
	end
	APPotsSaver.WatchedSlots = watched
end

function APPotsSaver.NotifyPossibleGlobalCooldown(actionId)
	if not APPotsSaver.Settings.Enabled then return end
	if not APPotsSaver.Settings.UseSmartGCD then return end
	if not actionId or actionId == 0 then return end

	gcdSleepUntil = currentTime + APPotsSaver.Settings.GCDSleepDuration
	gcdBurstUntil = gcdSleepUntil + APPotsSaver.Settings.GCDBurstWindow
	if gcdBurstUntil < gcdSleepUntil then
		gcdBurstUntil = gcdSleepUntil
	end
	APPotsSaver.ScheduleNextCheck(false)
end

function APPotsSaver.Initialize()
	if type(APPotsSaver.Settings) ~= "table" then
		APPotsSaver.Settings = {}
	end

	for key, value in pairs(APPotsSaver.DefaultSettings) do
		if APPotsSaver.Settings[key] == nil then
			if type(value) == "table" then
				APPotsSaver.Settings[key] = {}
			else
				APPotsSaver.Settings[key] = value
			end
		end
	end

	APPotsSaver.NormalizeSettings()
	APPotsSaver.RebuildWatchedSlots()
	APPotsSaver.MarkDirty(true, true)
	APPotsSaver.MarkIconsDirty()

	LibSlash.RegisterSlashCmd("appotssaver", function(input) APPotsSaver_Config.Slash(input) end)

	if APPotsSaver.Settings.Enabled then APPotsSaver.RegisterEvents() end

	TextLogAddEntry("Chat", 0, towstring("<icon57> APPotsSaver v" .. tostring(APPotsSaver.Settings.Version) .. " by Kpihuss loaded. Type /appotssaver for settings."))
end

function APPotsSaver.OnShutdown()
	APPotsSaver.UnregisterEvents()
end

function APPotsSaver.RegisterEvents()
	if not eventsRegistered then
		RegisterEventHandler(SystemData.Events.ENTER_WORLD, "APPotsSaver.ENTER_WORLD")
		RegisterEventHandler(SystemData.Events.PLAYER_ZONE_CHANGED, "APPotsSaver.PLAYER_ZONE_CHANGED")
		RegisterEventHandler(SystemData.Events.INTERFACE_RELOADED, "APPotsSaver.INTERFACE_RELOADED")
		RegisterEventHandler(SystemData.Events.PLAYER_HOT_BAR_UPDATED, "APPotsSaver.PLAYER_HOT_BAR_UPDATED")
	end
	eventsRegistered = true
end

function APPotsSaver.UnregisterEvents()
	if eventsRegistered then
		UnregisterEventHandler(SystemData.Events.ENTER_WORLD, "APPotsSaver.ENTER_WORLD")
		UnregisterEventHandler(SystemData.Events.PLAYER_ZONE_CHANGED, "APPotsSaver.PLAYER_ZONE_CHANGED")
		UnregisterEventHandler(SystemData.Events.INTERFACE_RELOADED, "APPotsSaver.INTERFACE_RELOADED")
		UnregisterEventHandler(SystemData.Events.PLAYER_HOT_BAR_UPDATED, "APPotsSaver.PLAYER_HOT_BAR_UPDATED")
	end
	eventsRegistered = false
end

function APPotsSaver.ENTER_WORLD()
	loadingEnd = true
	APPotsSaver.RebuildWatchedSlots()
	APPotsSaver.MarkIconsDirty()
	APPotsSaver.MarkDirty(true, true)
end

function APPotsSaver.PLAYER_ZONE_CHANGED()
	loadingEnd = true
	APPotsSaver.RebuildWatchedSlots()
	APPotsSaver.MarkIconsDirty()
	APPotsSaver.MarkDirty(true, true)
end

function APPotsSaver.INTERFACE_RELOADED()
	loadingEnd = true
	APPotsSaver.RebuildWatchedSlots()
	APPotsSaver.MarkIconsDirty()
	APPotsSaver.MarkDirty(true, true)
end

function APPotsSaver.PLAYER_HOT_BAR_UPDATED(slot, actionType, actionId)
	APPotsSaver.RebuildWatchedSlots()
	APPotsSaver.UpdateButtonIcon(slot, (APPotsSaver.Settings.Enabled and APPotsSaver.Settings.Symbols and APPotsSaver.Settings.Abilities[actionId]) or nil)
	APPotsSaver.MarkIconsDirty()
	APPotsSaver.MarkDirty(true, true)
end

function APPotsSaver.OnUpdate(elapsed)
	currentTime = currentTime + elapsed

	if not loadingEnd then return end

	if APPotsSaver.ButtonIconsNeedUpdate then
		APPotsSaver.UpdateButtonIcons()
		APPotsSaver.ButtonIconsNeedUpdate = false
	end

	if not APPotsSaver.Settings.Enabled then
		return
	end

	if currentTime < nextCheckAt then
		return
	end

	if APPotsSaver.FullRefreshNeeded then
		APPotsSaver.UpdateButtonsEnabledStates(true)
		APPotsSaver.FullRefreshNeeded = false
		APPotsSaver.EnabledStatesNeedUpdate = false
		APPotsSaver.ScheduleNextCheck(false)
		return
	end

	APPotsSaver.UpdateButtonsEnabledStates(false)
	APPotsSaver.EnabledStatesNeedUpdate = false
	APPotsSaver.ScheduleNextCheck(false)
end

function APPotsSaver.UpdateSettings()
	APPotsSaver.NormalizeSettings()

	if APPotsSaver.Settings.Enabled and not eventsRegistered then
		APPotsSaver.RegisterEvents()
	elseif not APPotsSaver.Settings.Enabled and eventsRegistered then
		APPotsSaver.UnregisterEvents()
	end

	APPotsSaver.RebuildWatchedSlots()
	APPotsSaver.MarkIconsDirty()
	APPotsSaver.MarkDirty(true, true)
	APPotsSaver.UpdateButtonIcons()
	APPotsSaver.UpdateButtonsEnabledStates(true)

	TextLogAddEntry("Chat", 0, towstring("APPotsSaver v" .. tostring(APPotsSaver.Settings.Version) .. " settings: /appotssaver"))
	if APPotsSaver.Settings.Enabled then
		TextLogAddEntry("Chat", 0, L"--- <icon57> Enabled")
	else
		TextLogAddEntry("Chat", 0, L"--- <icon58> Enabled")
	end
	if APPotsSaver.Settings.Symbols then
		TextLogAddEntry("Chat", 0, L"--- <icon57> Show Symbols")
	else
		TextLogAddEntry("Chat", 0, L"--- <icon58> Show Symbols")
	end
	if APPotsSaver.Settings.ErrorMessages then
		TextLogAddEntry("Chat", 0, L"--- <icon57> Show Combat Error Messages")
	else
		TextLogAddEntry("Chat", 0, L"--- <icon58> Show Combat Error Messages")
	end
	if APPotsSaver.Settings.UseSmartGCD then
		TextLogAddEntry("Chat", 0, L"--- <icon57> Smart GCD Optimization")
	else
		TextLogAddEntry("Chat", 0, L"--- <icon58> Smart GCD Optimization")
	end
	TextLogAddEntry("Chat", 0, towstring("--- Idle interval: " .. tostring(APPotsSaver.Settings.IdleInterval) .. "s"))
	TextLogAddEntry("Chat", 0, towstring("--- Burst interval: " .. tostring(APPotsSaver.Settings.BurstInterval) .. "s"))
	TextLogAddEntry("Chat", 0, towstring("--- GCD sleep: " .. tostring(APPotsSaver.Settings.GCDSleepDuration) .. "s"))
	TextLogAddEntry("Chat", 0, towstring("--- GCD burst window: " .. tostring(APPotsSaver.Settings.GCDBurstWindow) .. "s"))
end

function APPotsSaver.UpdateButtonIcons()
	for slot = 1, MAX_BUTTONS do
		local _, actionId = GetHotbarData(slot)
		if APPotsSaver.Settings.Enabled and APPotsSaver.Settings.Symbols and APPotsSaver.Settings.Abilities[actionId] ~= nil then
			APPotsSaver.UpdateButtonIcon(slot, APPotsSaver.Settings.Abilities[actionId])
		else
			APPotsSaver.UpdateButtonIcon(slot, nil)
		end
	end
end

function APPotsSaver.UpdateButtonIcon(slot, value)
	local hbar, buttonid = ActionBars:BarAndButtonIdFromSlot(slot)
	if hbar and buttonid then
		local button = hbar.m_Buttons[buttonid]
		if button and button.m_Windows and button.m_Windows[7] then
			if value == nil then
				button.m_Windows[7]:Show(false)
			else
				button.m_Windows[7]:Show(true)
				button.m_Windows[7]:SetFont("font_clear_small_bold", 10)
				button.m_Windows[7]:SetTextColor(255, 255, 0)
				local displayText = (value == 0) and "=0AP" or (">" .. tostring(value) .. "AP")
				button.m_Windows[7]:SetText(displayText)
			end
		end
	end
end

function APPotsSaver.BuildSlotStateSignature(actionId, isSlotEnabled, isTargetValid, isSlotBlocked, apBlocked)
	return tostring(actionId) .. "|" .. tostring(isSlotEnabled) .. "|" .. tostring(isTargetValid) .. "|" .. tostring(isSlotBlocked) .. "|" .. tostring(apBlocked)
end

function APPotsSaver.UpdateButtonsEnabledStates(forceAll)
	if forceAll then
		for slot = 1, MAX_BUTTONS do
			APPotsSaver.UpdateButtonEnabledState(slot, true)
		end
		return
	end

	for slot, _ in pairs(APPotsSaver.WatchedSlots) do
		APPotsSaver.UpdateButtonEnabledState(slot, false)
	end
end

function APPotsSaver.UpdateButtonEnabledState(slot, force)
	local actionType, actionId, isSlotEnabled, isTargetValid, isSlotBlocked = GetHotbarData(slot)
	local apBlocked = false

	if APPotsSaver.Settings.Enabled and APPotsSaver.Settings.Abilities[actionId] ~= nil then
		local threshold = APPotsSaver.Settings.Abilities[actionId]
		if getCurrentAP() > threshold then
			isSlotEnabled = false
			apBlocked = true
		end
	elseif not force then
		return
	end

	local signature = APPotsSaver.BuildSlotStateSignature(actionId, isSlotEnabled, isTargetValid, isSlotBlocked, apBlocked)
	if not force and APPotsSaver.LastSlotStates[slot] == signature then
		return
	end

	APPotsSaver.LastSlotStates[slot] = signature
	orgActionBarsUpdateSlotEnabledState(slot, isSlotEnabled, isTargetValid, isSlotBlocked)
end

WindowGameAction = function(windowName, ...)
	local actionId = resolveActionIdFromWindow(windowName)
	if actionId and isConfiguredAction(actionId) and isAbilityBlocked(actionId, true) then
		return
	end
	if actionId then
		APPotsSaver.NotifyPossibleGlobalCooldown(actionId)
	end
	return orgWindowGameAction(windowName, ...)
end

function ActionButton.OnLButtonDown(self, flags, x, y)
	if flags == SystemData.ButtonFlags.CONTROL and self and self.m_ActionId ~= 0 then
		APPotsSaver.Settings.Abilities[self.m_ActionId] = nextThreshold(APPotsSaver.Settings.Abilities[self.m_ActionId])
		APPotsSaver.RebuildWatchedSlots()
		APPotsSaver.MarkIconsDirty()
		APPotsSaver.MarkDirty(true, true)
		chatInfo(self.m_ActionId, APPotsSaver.Settings.Abilities[self.m_ActionId])
		return
	end

	if self and self.m_ActionId ~= 0 and isConfiguredAction(self.m_ActionId) and isAbilityBlocked(self.m_ActionId, true) then
		return
	end

	if self and self.m_ActionId ~= 0 then
		APPotsSaver.NotifyPossibleGlobalCooldown(self.m_ActionId)
	end

	return orgActionButtonOnLButtonDown(self, flags, x, y)
end

if type(orgActionButtonOnLButtonUp) == "function" then
	function ActionButton.OnLButtonUp(self, flags, x, y)
		if self and self.m_ActionId ~= 0 and isConfiguredAction(self.m_ActionId) and isAbilityBlocked(self.m_ActionId, false) then
			return
		end
		return orgActionButtonOnLButtonUp(self, flags, x, y)
	end
end

function ActionBars.UpdateSlotEnabledState(slot, isSlotEnabled, isTargetValid, isSlotBlocked)
	local hbar, buttonid = ActionBars:BarAndButtonIdFromSlot(slot)
	if hbar and buttonid then
		local button = hbar.m_Buttons[buttonid]
		if button and APPotsSaver.Settings and APPotsSaver.Settings.Enabled and APPotsSaver.Settings.Abilities[button.m_ActionId] ~= nil then
			local threshold = APPotsSaver.Settings.Abilities[button.m_ActionId]
			if getCurrentAP() > threshold then
				isSlotEnabled = false
			end
		end
	end
	orgActionBarsUpdateSlotEnabledState(slot, isSlotEnabled, isTargetValid, isSlotBlocked)
end

function ActionButton.UpdateInventory(self)
	if not APPotsSaver.Settings or not APPotsSaver.Settings.Enabled or APPotsSaver.Settings.Abilities[self.m_ActionId] == nil then
		orgActionButtonUpdateInventory(self)
	end
end
