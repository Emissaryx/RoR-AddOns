APPotsSaver v1.03 - Usage Instructions
======================================

What it does
------------
APPotsSaver blocks configured actions when your current AP is ABOVE the cap set for that action.

Basic use
---------
1. Put your AP potion or any action you want to protect on a hotbar slot.
2. CTRL + left click that slot to change its AP cap.
3. The cycle is:
   clear -> 0 -> 10 -> 20 -> ... -> 200 -> clear
4. When a cap is configured, the slot text shows:
   - >30AP = blocked at 31 AP and above
   - =0AP  = only usable at 0 AP

Command
-------
/appotssaver

Configuration options
---------------------
Enabled
- Master on/off switch for the addon.

Show Symbols
- Shows the AP cap directly on watched hotbar slots.

Show Combat Error messages
- Shows a combat alert when you try to use a blocked action.

Use Smart GCD Optimization
- Reduces unnecessary UI work.
- After using an action, the addon sleeps through most of the GCD.
- Near the end of the GCD it resumes with fast checks.

Idle Check Interval
- Normal check rate outside the smart GCD sleep window.
- Lower = faster reaction.
- Higher = less UI work.

Burst Check Interval
- Fast check rate used near the end of the GCD.
- 0.1s is the fastest supported value.

GCD Sleep Duration
- How long the addon waits after an action before checking again.
- Recommended value: 1.4s.

GCD Burst Window
- How long the addon keeps fast checks after the sleep ends.
- Recommended value: 0.2s.

Recommended values
------------------
- Idle Check Interval: 0.5s
- Burst Check Interval: 0.1s
- GCD Sleep Duration: 1.4s
- GCD Burst Window: 0.2s

Notes
-----
- This version only checks watched slots instead of scanning the full hotbar continuously.
- If the addon is disabled, it stops blocking actions and clears its visual state.
