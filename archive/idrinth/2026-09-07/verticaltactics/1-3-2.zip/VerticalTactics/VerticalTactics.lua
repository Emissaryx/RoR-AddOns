
VerticalTactics = {}
VerticalTactics.reverse = false
VerticalTactics.setNames = {}

local SET_MENU_BUTTON = "EA_TacticsEditorContentsSetMenuSelectedButton"

function VerticalTactics.Initialize()
	if type(VerticalTactics.setNames) ~= "table" then
		VerticalTactics.setNames = {}
	end

	local modules = ModulesGetData()
	for k,v in ipairs(modules) do
		if v.name == "EA_TacticsWindow_WifNamez" then
			if v.isEnabled and not v.isLoaded then
				ModuleInitialize("EA_TacticsWindow_WifNamez");
			end
			break
		end
	end

	VerticalTactics.InstallSetPreviewNameHook()

	local hookCreateBar = TacticsEditor.CreateBar
	TacticsEditor.CreateBar = function(...)
		hookCreateBar(...)
		VerticalTactics.AnchorTacticButtons()
	end
	local hookUpdateTactics = TacticsEditor.UpdateTactics
	TacticsEditor.UpdateTactics = function()
		hookUpdateTactics()
		VerticalTactics.AnchorTacticButtons()
	end

	local hookTacticShutdown = TacticsEditor.Shutdown
	TacticsEditor.Shutdown = function()
		VerticalTactics.Shutdown()
		hookTacticShutdown()
	end
	if LibSlash then
		LibSlash.RegisterSlashCmd("verticaltactics", function(args)
			if args:match("^reverse (.+)$") then
				local n = args:match("^reverse (.+)$")
				if n == "true" then
					VerticalTactics.reverse = true
					VerticalTactics.AnchorTacticButtons()
				elseif n == "false" then
					VerticalTactics.reverse = false
					VerticalTactics.AnchorTacticButtons()
				end
			else
				EA_ChatWindow.Print(L"[VerticalTactics]: Valid options are:\n reverse [true|false]: enable/disable reverse mode")
			end
		end)
	end
end

function VerticalTactics.Shutdown()
	if DoesWindowExist("EA_TacticsEditor") then
		local x, y = WindowGetDimensions("EA_TacticsEditor")
		if y > x then
			WindowSetDimensions("EA_TacticsEditor", y, x)
		end
	end
end

function VerticalTactics.AnchorTacticButtons()
	if not DoesWindowExist("EA_TacticsEditor") then
		return
	end

	VerticalTactics.RegisterSetNameHandlers()

	local dimX, dimY = WindowGetDimensions("EA_TacticsEditor")
	if dimX > dimY then
		WindowSetDimensions("EA_TacticsEditor", dimY, dimX)
	end
	
	WindowClearAnchors("EA_TacticsEditorContentsSetMenu")
	if VerticalTactics.reverse then
		WindowAddAnchor("EA_TacticsEditorContentsSetMenu", "bottomleft", "EA_TacticsEditor", "bottomleft", 0, 0)
	else
		WindowAddAnchor("EA_TacticsEditorContentsSetMenu", "topleft", "EA_TacticsEditor", "topleft", 0, 0)
	end
	
	local scale = WindowGetScale("EA_TacticsEditor")

	local anchorToWindow    = "EA_TacticsEditor";
	local offsetX           = 1;
	local offsetY           = 47;
	local relativePoint     = "topleft";
	local point             = "topleft";
	if VerticalTactics.reverse then
		offsetY           = -47;
		relativePoint     = "bottomleft";
		point             = "bottomleft";
	end

	local windowName, previousButtonId
	for buttonId = 1, GameData.MAX_TACTICS_SLOTS do
		windowName = "TacticButton"..buttonId
		if not DoesWindowExist(windowName) then
			break
		end
		previousButtonId = buttonId - 1
	
		if (previousButtonId > 0) then
			anchorToWindow  = "TacticButton"..previousButtonId;
			offsetX         = 0;
			if VerticalTactics.reverse then
				offsetY         = -2;
				point           = "topleft";
			else
				offsetY         = 2;
				point           = "bottomleft";
			end
		end

		WindowClearAnchors (windowName);
		WindowSetScale(windowName, scale)
		WindowAddAnchor (windowName, point, anchorToWindow, relativePoint, offsetX, offsetY);
	end
	for slotType = GameData.TacticType.FIRST, GameData.TacticType.NUM_TYPES do
		windowName = "Spacer"..slotType
		if DoesWindowExist(windowName) then
			WindowSetShowing(windowName, false)
		end
	end
end

function VerticalTactics.RegisterSetNameHandlers()
	if not DoesWindowExist(SET_MENU_BUTTON) then
		return
	end

	WindowRegisterCoreEventHandler(SET_MENU_BUTTON, "OnRButtonUp", "VerticalTactics.OnSetNumberRightClick")
	WindowRegisterCoreEventHandler(SET_MENU_BUTTON, "OnMouseOver", "VerticalTactics.OnSetNumberMouseOver")
	WindowRegisterCoreEventHandler(SET_MENU_BUTTON, "OnMouseOverEnd", "VerticalTactics.OnSetNumberMouseOverEnd")
end

function VerticalTactics.GetSelectedSetNumber()
	if not DoesWindowExist(SET_MENU_BUTTON) then
		return nil
	end

	return tonumber(ButtonGetText(SET_MENU_BUTTON))
end

function VerticalTactics.TrimName(text)
	if text == nil then
		return L""
	end

	if type(text) == "wstring" then
		return text:match(L"^%s*(.-)%s*$") or text
	end

	local trimmed = text:match("^%s*(.-)%s*$") or text
	return towstring(trimmed)
end

function VerticalTactics.InstallSetPreviewNameHook()
	if VerticalTactics.previewNameHookInstalled then
		return
	end
	if type(TacticsSetTooltip) ~= "table" or type(TacticsSetTooltip.CreateTooltip) ~= "function" then
		return
	end

	local createTooltip = TacticsSetTooltip.CreateTooltip
	TacticsSetTooltip.CreateTooltip = function(self, desiredSet)
		local setIndex = desiredSet
		if setIndex == nil then
			setIndex = self.currentSet
		end

		local actionText = GetString(StringTables.Default.LABEL_PLAYER_TACTICS_LOADOUT_INSTRUCTIONS)
		if setIndex ~= nil then
			local setName = VerticalTactics.setNames[setIndex + 1]
			if setName ~= nil and setName ~= L"" then
				actionText = setName..L"\n"..actionText
			end
		end

		local actionLabel = self.windowName.."ActionText"
		if DoesWindowExist(actionLabel) then
			LabelSetText(actionLabel, actionText)
		end

		createTooltip(self, desiredSet)
	end

	VerticalTactics.previewNameHookInstalled = true
end

function VerticalTactics.OnSetNumberRightClick()
	local setNumber = VerticalTactics.GetSelectedSetNumber()
	if setNumber == nil then
		return
	end

	Tooltips.ClearTooltip()
	local currentName = VerticalTactics.setNames[setNumber] or L""
	DialogManager.MakeTextEntryDialog(
		L"Name tactic set "..towstring(setNumber),
		L"Enter a name for this tactic set. Leave it blank to clear the name.",
		currentName,
		function(text)
			local name = VerticalTactics.TrimName(text)
			if name == L"" then
				VerticalTactics.setNames[setNumber] = nil
			else
				VerticalTactics.setNames[setNumber] = name
			end
		end,
		nil,
		64,
		false)
end

function VerticalTactics.OnSetNumberMouseOver()
	local setNumber = VerticalTactics.GetSelectedSetNumber()
	if setNumber == nil then
		return
	end

	local setName = VerticalTactics.setNames[setNumber]
	Tooltips.CreateTextOnlyTooltip(SET_MENU_BUTTON, nil)
	if setName ~= nil and setName ~= L"" then
		Tooltips.SetTooltipText(1, 1, setName)
		Tooltips.SetTooltipColorDef(1, 1, Tooltips.COLOR_HEADING)
		Tooltips.SetTooltipText(2, 1, L"Tactic set "..towstring(setNumber))
	else
		Tooltips.SetTooltipText(1, 1, L"Tactic set "..towstring(setNumber))
		Tooltips.SetTooltipColorDef(1, 1, Tooltips.COLOR_HEADING)
	end
	Tooltips.SetTooltipActionText(L"Right-click the number to name this set")
	Tooltips.Finalize()
	Tooltips.AnchorTooltip(Tooltips.ANCHOR_WINDOW_RIGHT)
end

function VerticalTactics.OnSetNumberMouseOverEnd()
	Tooltips.ClearTooltip()
end
