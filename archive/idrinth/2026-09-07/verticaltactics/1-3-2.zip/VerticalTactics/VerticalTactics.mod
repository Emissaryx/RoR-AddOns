<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
	<UiMod name="VerticalTactics" version="1.3.1" date="8/12/2026" >

		<Author name="Reivan" email="" />
		<Description text="Changes the layout of EA_TacticsEditor to vertical and adds custom tactic-set names." />

		<VersionSettings gameVersion="1.3.4" windowsVersion="1.0" savedVariablesVersion="1.0" />
		
        <Dependencies>
        	<Dependency name="EA_TacticsWindow" />
        	<Dependency name="LibSlash" />
        </Dependencies>
        <SavedVariables>
        	<SavedVariable name="VerticalTactics.reverse" />
			<SavedVariable name="VerticalTactics.setNames" />
        </SavedVariables>
       	<Files>
			<File name="VerticalTactics.lua" />
		</Files>
		
		<OnInitialize>
			<CallFunction name="VerticalTactics.Initialize" />
		</OnInitialize>
		<OnShutdown>
			<CallFunction name="VerticalTactics.Shutdown" />
		</OnShutdown>
	</UiMod>
</ModuleFile>
