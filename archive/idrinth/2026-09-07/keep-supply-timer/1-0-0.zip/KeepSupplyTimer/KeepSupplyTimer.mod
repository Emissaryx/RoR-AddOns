<?xml version="1.0.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
    <UiMod name="KeepSupplyTimer" version="1.0.0" date="2026-06-09" description="Adds keep supply timers, BO countdowns, decay risk and keep upgrade info to State of Realm.">
        <Author name="Kpihuss y Gingerbel" />
        <Description text="Adds keep supply timers, BO countdowns, decay risk and keep upgrade info to State of Realm." />

        <VersionSettings gameVersion="1.4.8" windowsVersion="0.2.11" />
        <Dependencies>
            <Dependency name="RoR_SoR" />
            <Dependency name="EA_ChatWindow" />
            <Dependency name="LibSlash" optional="true" forceEnable="true" />
        </Dependencies>
        <Files>
            <File name="KeepSupplyTimer.xml" />
            <File name="KeepSupplyTimer.lua" />
        </Files>
        <SavedVariables>
            <SavedVariable name="KeepSupplyTimerUpgradeState" />
            <SavedVariable name="KeepSupplyTimerSettings" />
        </SavedVariables>
        <OnInitialize>
            <CallFunction name="KeepSupplyTimer.OnInitialize" />
        </OnInitialize>
        <OnUpdate>
            <CallFunction name="KeepSupplyTimer.OnUpdate" />
        </OnUpdate>
        <OnEvent>
            <CallFunction name="KeepSupplyTimer.OnEvent" />
        </OnEvent>
    </UiMod>
</ModuleFile>
