-- KeepSupplyTimer
-- Desarrollado por Kpihuss y Gingerbel.

KeepSupplyTimer = KeepSupplyTimer or {}

local KST = KeepSupplyTimer

KST.VERSION = "1.0.0"
KST.TEMPLATE = "KeepSupplyTimer_Template"
KST.WINDOW_PREFIX = "KeepSupplyTimer_"
KST.REFRESH_INTERVAL = 0.50
KST.SLASH_RETRY_LIMIT = 10
KST.WIDTH = 236
KST.HEIGHT = 20
KST.ANCHOR_X = -4
KST.ANCHOR_Y = -10
KST.RESET_PAIR_TEMPLATE = "KeepSupplyTimer_ResetPair_Template"
KST.RESET_BOX_HOVER_TEMPLATE = "KeepSupplyTimer_ResetBoxHover_Template"
KST.RESET_BOX_HOVER_PREFIX = "KeepSupplyTimer_ResetBoxHover_"
KST.RESET_PAIR_WIDTH = 236
KST.RESET_BOX_WIDTH = 70
KST.RESET_BOX_HEIGHT = 18
KST.RESET_PAIR_OFFSET_X = 0
KST.RESET_PAIR_OFFSET_Y = -2
KST.UNKNOWN_TEXT = "--:--"
KST.CHAT_TAG_TEXT = "KeepSupplyTimer"
KST.CHAT_TAG_COLOR = "255,204,102"
KST.SafeAppendFileLogControlLine = KST.SafeAppendFileLogControlLine or function(text)
    if type(appendFileLogControlLine) == "function" then
        pcall(appendFileLogControlLine, text)
    elseif type(KST) == "table" then
        KST._pendingControlLogLines = KST._pendingControlLogLines or {}
        KST._pendingControlLogLines[#KST._pendingControlLogLines + 1] = tostring(text or "")
    end
end

KST.SHOW_UNKNOWN_WHEN_SUPPLY_EXISTS = true
KST.HIDE_WHEN_NO_SUPPLY_DATA = true
KST.MAX_LOG_ENTRIES = 1000
KST.MAX_DECAY_SAMPLES = 1000
KST.LOG_DECAY_TO_CHAT = false
KST.LOG_DECAYS = false
KST.LOG_DELIVERIES = false
KST.LOG_DELIVERIES_TO_CHAT = false
KST.BO_TEMPLATE = "KeepSupplyTimer_BOTimer_Template"
KST.BO_HOVER_TEMPLATE = "KeepSupplyTimer_BOHover_Template"
KST.BO_WINDOW_PREFIX = "KeepSupplyTimer_BO_"
KST.BO_HOVER_PREFIX = "KeepSupplyTimer_BOHover_"
KST.BO_WIDTH = 50
KST.BO_HEIGHT = 16
KST.BO_TEXT_SCALE = 0.85
KST.BO_HOVER_WIDTH = 56
KST.BO_HOVER_HEIGHT = 20
KST.BO_HOVER_OFFSET_X = -3
KST.BO_HOVER_OFFSET_Y = -2
KST.BO_ANCHOR_X = 0
KST.BO_ANCHOR_Y = -5
KST.SHOW_BO_TIMERS = true
KST.SHOW_BO_READY = false
KST.BO_READY_TEXT = "Rdy"
KST.BO_STABLE_STATE = 0
KST.BO_SECURING_STATE = 16
KST.BO_TIMER_ONLY_WHEN_SECURING = false
KST.BO_SUPPLY_INTERVAL = 42
KST.BO_TOOLTIP_TEMPLATE = "KeepSupplyTimer_BOTooltip_Template"
KST.BO_TOOLTIP_WINDOW = "KeepSupplyTimer_BOTooltip"
KST.BO_TOOLTIP_WIDTH = 430
KST.BO_TOOLTIP_HEIGHT = 136
KST.BO_TOOLTIP_CURSOR_OFFSET_X = 16
KST.BO_TOOLTIP_CURSOR_OFFSET_Y = 16
KST.SHARE_PREFIX = "[KST]"
KST.SHARE_CONTEXT_MENU_NAME = "KeepSupplyTimer"
KST.NPC_UPGRADE_WINDOW = "EA_Window_InteractionKeepUpgrades"
KST.NPC_UPGRADE_SCAN_LIMIT = 260
KST.SHARE_CHANNELS = {
    { key = "warband", label = "/wb Warband", slash = "/wb" },
    { key = "party", label = "/p Party", slash = "/p" },
    { key = "guild", label = "/g Guild", slash = "/g" },
    { key = "say", label = "/s Say", slash = "/s" },
    { key = "region1", label = "/1 Region", slash = "/1" },
    { key = "t4", label = "/t4 T4", slash = "/t4" },
}
KST.BO_START_TIMER_ON_ALREADY_STABLE = true
KST.BO_REQUIRE_KEEP_LEVEL_FOR_SUPPLY = true
KST.LOG_BO_STATE_CHANGES = false
KST.LOG_BO_STATE_CHANGES_TO_CHAT = false
KST.LOG_CLAIM_CHANGES = false
KST.LOG_CLAIM_CHANGES_TO_CHAT = false
KST.LOG_SERVER_TIMER_CANDIDATES = false
KST.LOG_SERVER_TIMER_CANDIDATES_TO_CHAT = false
KST.SERVER_DECAY_GLOBAL_INTERVAL = 300
KST.FILE_LOG_ENABLED_DEFAULT = false
KST.FILE_LOG_NAME = "KeepSupplyTimerFileLog"
KST.FILE_LOG_PATH = "logs/KeepSupplyTimerLog.txt"
KST.FILE_LOG_BASE_PATH = "logs/KeepSupplyTimerLog"
-- Keep a single persistent file. This relies on TextLog incremental saving.
-- Avoid TextLogSaveLog in normal operation because in RoR it can rewrite the
-- file from the current in-memory buffer and lose lines from previous reloads.
KST.FILE_LOG_UNIQUE_PER_SESSION = false
KST.FILE_LOG_APPEND_SAFE = true
KST.FILE_LOG_FILTER = 1
KST.FILE_LOG_MAX_LINES = 50000
KST.FILE_LOG_SAVE_EACH_EVENT = false
-- 0.1.36: archive/mini-log mirroring disabled. Use the single fixed TextLog file again.
KST.FILE_LOG_ARCHIVE_ENABLED = false
KST.FILE_LOG_ARCHIVE_NAME = "KeepSupplyTimerArchiveLog"
KST.FILE_LOG_ARCHIVE_BASE_PATH = "logs/KeepSupplyTimerLog_archive"
KST.FILE_LOG_ARCHIVE_FILTER = 1
KST.FILE_LOG_ARCHIVE_MAX_LINES = 50000
KST.LOG_DECAY_SAMPLES_TO_CHAT = false
KST.DECAY_SAMPLE_MIN_SECONDS = 30
KST.FILE_LOG_FULL_DETAILS = true
KST.LOG_DECAY_TRACKING_SNAPSHOTS = false
KST.DECAY_TRACKING_SNAPSHOT_INTERVAL = 15
-- Research ticks record negative cases: moments where the keep is already a
-- decay candidate but has not decayed yet. This is intentionally append-only
-- to the fixed text log and does not remove any existing data.
KST.ANALYSIS_LOGGING_DEFAULT = false
KST.RESEARCH_TICKS_ENABLED_DEFAULT = false
KST.RESEARCH_TICK_INTERVAL = 5
KST.RESEARCH_TICK_ONLY_AFTER_SUPPLY = true
KST.RESEARCH_TMIN_SECONDS = { [0] = 405, [1] = 295, [2] = 250, [3] = 210 }
-- Visible risk indicator. This is deliberately qualitative: the exact decay
-- formula is still under research, so these levels are intended as operational
-- warnings rather than second-perfect predictions.
KST.SHOW_RISK_TEXT_DEFAULT = true
KST.RISK_TMIN_SECONDS = { [0] = 405, [1] = 295, [2] = 250, [3] = 210 }
KST.RISK_MEDIUM_RATIO = 0.70
KST.RISK_MIN_FINAL_STREAK_SECONDS = 70
KST.RISK_HIGH_FINAL_STREAK_SECONDS = 180
KST.RISK_CRITICAL_FINAL_STREAK_SECONDS = 300
KST.RISK_HIGH_OVER_TMIN_SECONDS = 120
KST.RISK_CRITICAL_OVER_TMIN_SECONDS = 240
KST.RISK_CRITICAL_MISS_SCORE = 520
KST.RISK_HIGH_MISS_SCORE = 360
-- Hybrid aggressive decay prediction. This is the visible/default decay model.
-- It is intentionally an estimated risk model, not a guaranteed server countdown.
KST.DECAY_PREDICTION_MODE_DEFAULT = "AGGRESSIVE"
KST.DECAY_STABILIZED_DISPLAY_SECONDS = 15
KST.DECAY_MODELS = {
    AGGRESSIVE = {
        name = "Hybrid aggressive",
        ageLimit = { [0] = 410, [1] = 290, [2] = 240, [3] = 210, [4] = 330 },
        graceShort = 45,
        graceLong = 75,
    },
    NORMAL = {
        name = "Hybrid normal",
        ageLimit = { [0] = 410, [1] = 295, [2] = 250, [3] = 210, [4] = 330 },
        graceShort = 60,
        graceLong = 80,
    },
}
KST.RISK_TOOLTIP_TEMPLATE = "KeepSupplyTimer_RiskTooltip_Template"
KST.RISK_TOOLTIP_WINDOW = "KeepSupplyTimer_RiskTooltip"
KST.RISK_TOOLTIP_WIDTH = 400
KST.RISK_TOOLTIP_HEIGHT = 390
KST.RISK_TOOLTIP_CURSOR_OFFSET_X = 18
KST.RISK_TOOLTIP_CURSOR_OFFSET_Y = 18
KST.RISK_TOOLTIP_SCALE = 1.0
KST.LOG_KEEP_UPGRADES = true
KST.LOG_KEEP_UPGRADES_TO_CHAT = true
KST.SHOW_KEEP_UPGRADE_TOOLTIPS = true
KST.KEEP_UPGRADE_HOVER_TEMPLATE = "KeepSupplyTimer_KeepHover_Template"
KST.KEEP_UPGRADE_TOOLTIP_TEMPLATE = "KeepSupplyTimer_UpgradeTooltip_Template"
KST.KEEP_UPGRADE_HOVER_PREFIX = "KeepSupplyTimer_KeepHover_"
KST.KEEP_UPGRADE_TOOLTIP_WINDOW = "KeepSupplyTimer_UpgradeTooltip"
KST.KEEP_UPGRADE_HOVER_WIDTH = 170
KST.KEEP_UPGRADE_HOVER_HEIGHT = 42
KST.KEEP_UPGRADE_HOVER_LABEL = "Keep upgrades"
KST.KEEP_UPGRADE_TOOLTIP_WIDTH = 400
KST.KEEP_UPGRADE_TOOLTIP_HEIGHT = 390
KST.KEEP_UPGRADE_MAX_TOOLTIP_LINES = 12
KST.KEEP_UPGRADE_TOOLTIP_ROW_COUNT = 14
KST.KEEP_UPGRADE_TOOLTIP_ANCHOR_TO_CURSOR = true
KST.KEEP_UPGRADE_TOOLTIP_CURSOR_OFFSET_X = 18
KST.KEEP_UPGRADE_TOOLTIP_CURSOR_OFFSET_Y = 18
KST.KEEP_UPGRADE_TOOLTIP_HIDE_WHEN_MOUSE_LEAVES_SOR = true
KST.KEEP_UPGRADE_TOOLTIP_HIDE_GRACE_SECONDS = 0.15
KST.CHAT_LOG_POLL_ENABLED = true
KST.CHAT_LOG_POLL_INTERVAL = 1.00
KST.CHAT_LOG_INITIAL_SCAN_LINES = 100
KST.CHAT_LOG_MANUAL_SCAN_LINES = 300
KST.CHAT_LOG_MAX_SCAN_PER_TICK = 120
KST.CHAT_LOG_NAMES = { "Chat" }
KST.DEBUG_KEEP_UPGRADE_CHAT = false
KST.PERSIST_KEEP_UPGRADES = true

KeepSupplyTimerLog = KeepSupplyTimerLog or {}
KeepSupplyTimerLog.version = KeepSupplyTimerLog.version or KST.VERSION
KeepSupplyTimerLog.events = KeepSupplyTimerLog.events or {}
KeepSupplyTimerLog.decaySamples = KeepSupplyTimerLog.decaySamples or {}
KeepSupplyTimerSettings = KeepSupplyTimerSettings or {}
if KeepSupplyTimerSettings.fileLogEnabled == nil then
    KeepSupplyTimerSettings.fileLogEnabled = KST.FILE_LOG_ENABLED_DEFAULT
end
if KeepSupplyTimerSettings.researchEnabled == nil then
    KeepSupplyTimerSettings.researchEnabled = KST.RESEARCH_TICKS_ENABLED_DEFAULT
end
if KeepSupplyTimerSettings.analysisLogEnabled == nil then
    KeepSupplyTimerSettings.analysisLogEnabled = KST.ANALYSIS_LOGGING_DEFAULT
end
if KeepSupplyTimerSettings.showRiskText == nil then
    KeepSupplyTimerSettings.showRiskText = KST.SHOW_RISK_TEXT_DEFAULT
end
if KeepSupplyTimerSettings.shareChannel == nil then
    KeepSupplyTimerSettings.shareChannel = "warband"
end
if KeepSupplyTimerSettings.keepUpgradesBackup == nil then
    KeepSupplyTimerSettings.keepUpgradesBackup = {}
end
if KeepSupplyTimerSettings.divineFavorChargeState == nil then
    KeepSupplyTimerSettings.divineFavorChargeState = {}
end

-- SavedVariables are only used for lightweight keep-upgrade state. The heavy
-- decay/BO analysis log remains text-log based.
KeepSupplyTimerUpgradeState = KeepSupplyTimerUpgradeState or {}
KeepSupplyTimerUpgradeState.version = KeepSupplyTimerUpgradeState.version or KST.VERSION
KeepSupplyTimerUpgradeState.keepUpgrades = KeepSupplyTimerUpgradeState.keepUpgrades or {}
KeepSupplyTimerUpgradeState.divineFavorChargeState = KeepSupplyTimerUpgradeState.divineFavorChargeState or {}

-- 0.1.36: no persistent archive/minilog state. Keep upgrades/settings only.

KST._elapsed = KST._elapsed or 0
KST._clock = KST._clock or 0
KST._states = KST._states or {}
KST._slashRegistered = KST._slashRegistered or false
KST._slashTries = KST._slashTries or 0
KST._enabled = KST._enabled ~= false
KST._showBOTimers = KST._showBOTimers ~= false
if KST._logBOStateChanges == nil then
    KST._logBOStateChanges = KST.LOG_BO_STATE_CHANGES == true
end
if KST._logClaimChanges == nil then
    KST._logClaimChanges = KST.LOG_CLAIM_CHANGES == true
end
KST._serverDecayGlobalReferenceSessionSeconds = nil
KST._serverDecayGlobalReferenceEventIndex = nil
KST._fileLogInitialized = false
KST._fileLogFailed = false
KST._fileLogLastError = nil
KST._archiveFileLogInitialized = false
KST._archiveFileLogFailed = false
KST._archiveFileLogLastError = nil
KST._archiveFileLogPath = nil
KST._keepUpgrades = KST._keepUpgrades or KeepSupplyTimerUpgradeState.keepUpgrades or {}
KST._keepUpgradeHoverWindows = KST._keepUpgradeHoverWindows or {}
KST._boTooltipWindows = KST._boTooltipWindows or {}
KST._currentUpgradeTooltip = KST._currentUpgradeTooltip or nil
KST._riskHoverWindows = KST._riskHoverWindows or {}
KST._currentRiskTooltip = KST._currentRiskTooltip or nil
KST._chatEventsRegistered = KST._chatEventsRegistered or false
KST._lastUpgradeChatKey = KST._lastUpgradeChatKey or nil
KST._lastUpgradeChatAt = KST._lastUpgradeChatAt or nil
KST._chatLogPollElapsed = KST._chatLogPollElapsed or 0
KST._chatLogLastIndex = KST._chatLogLastIndex or {}
KST._chatLogInitialScanned = KST._chatLogInitialScanned or {}
KST._lastGameChatRaw = KST._lastGameChatRaw or nil
KST._lastGameChatAt = KST._lastGameChatAt or nil
KST._lastResearchTickAt = KST._lastResearchTickAt or {}
KST._buffDebugEnabled = KST._buffDebugEnabled or false
KST._buffDebugLastScanAt = KST._buffDebugLastScanAt or 0
KST._buffDebugSeen = KST._buffDebugSeen or {}
KST.DIVINE_INTERVENTION_BUFF_ID = 31095
KST.DIVINE_INTERVENTION_BUFF_SCAN_INTERVAL = 3
KST._divineInterventionBuffWasActive = KST._divineInterventionBuffWasActive or false
KST._divineInterventionBuffScanElapsed = KST._divineInterventionBuffScanElapsed or 0
KST._lastDivineInterventionBuffUseAt = KST._lastDivineInterventionBuffUseAt or nil
KST._lastDivineFavorAltarContext = KST._lastDivineFavorAltarContext or nil
KST._divineInterventionBuffLastRemaining = KST._divineInterventionBuffLastRemaining or nil
KST.DIVINE_INTERVENTION_REFRESH_MIN_REMAINING = 90
KST.DIVINE_INTERVENTION_REFRESH_JUMP_SECONDS = 20

local REALM_LABELS = {
    [0] = "N",
    [1] = "O",
    [2] = "D",
}

local function toString(value)
    if value == nil then
        return ""
    end

    if type(value) == "string" then
        return value
    end

    if type(value) == "number" or type(value) == "boolean" then
        return tostring(value)
    end

    if type(WStringToString) == "function" then
        local ok, text = pcall(WStringToString, value)
        if ok and type(text) == "string" then
            return text
        end
    end

    local ok, text = pcall(tostring, value)
    if ok and type(text) == "string" then
        return text
    end

    return ""
end

local function toWString(value)
    if type(towstring) == "function" then
        local ok, text = pcall(towstring, toString(value))
        if ok and text ~= nil then
            return text
        end
    end

    return toString(value)
end

local function getTag()
    return toWString(
        "[<LINK data=\"\" text=\""
            .. KST.CHAT_TAG_TEXT
            .. "\" color=\""
            .. KST.CHAT_TAG_COLOR
            .. "\">]: "
    )
end

local function chatPrint(message)
    local line = getTag() .. toWString(message)
    local printed = false

    if type(TextLogAddEntry) == "function" then
        local ok = pcall(TextLogAddEntry, "Chat", 0, line)
        printed = ok
    end

    if not printed and type(EA_ChatWindow) == "table" and type(EA_ChatWindow.Print) == "function" then
        pcall(EA_ChatWindow.Print, line)
    end
end

local function windowExists(windowName)
    if windowName == nil or windowName == "" then
        return false
    end

    if type(DoesWindowExist) ~= "function" then
        return true
    end

    local ok, exists = pcall(DoesWindowExist, windowName)
    return ok and exists == true
end

local function isNormalZone(zoneId)
    local zoneNumber = tonumber(zoneId)
    if zoneNumber == nil then
        return false
    end

    if type(RoR_SoR) == "table" then
        if type(RoR_SoR.Forts) == "table" and RoR_SoR.Forts[zoneNumber] ~= nil then
            return false
        end
        if type(RoR_SoR.City) == "table" and RoR_SoR.City[zoneNumber] ~= nil then
            return false
        end
    end

    return true
end

local function getZoneWindow(zoneId)
    local zoneNumber = tonumber(zoneId)
    if zoneNumber == nil then
        return nil
    end

    return "SoR_" .. tostring(zoneNumber)
end

local function getOverlayName(zoneId)
    local zoneNumber = tonumber(zoneId)
    if zoneNumber == nil then
        return nil
    end

    return KST.WINDOW_PREFIX .. tostring(zoneNumber)
end

local function getState(zoneId)
    local zoneNumber = tonumber(zoneId)
    if zoneNumber == nil then
        return nil
    end

    if type(KST._states[zoneNumber]) ~= "table" then
        KST._states[zoneNumber] = {
            keeps = {
                [1] = {},
                [2] = {},
            },
            bos = {},
        }
    end

    if type(KST._states[zoneNumber].keeps) ~= "table" then
        KST._states[zoneNumber].keeps = {
            [1] = {},
            [2] = {},
        }
    end

    if type(KST._states[zoneNumber].bos) ~= "table" then
        KST._states[zoneNumber].bos = {}
    end

    return KST._states[zoneNumber]
end

local function isOpenZone(zoneId)
    if type(RoR_SoR) ~= "table" or type(RoR_SoR.OpenZones) ~= "table" then
        return false
    end

    return RoR_SoR.OpenZones[tostring(zoneId)] ~= nil or RoR_SoR.OpenZones[tonumber(zoneId)] ~= nil
end

local function getOpenZoneIds()
    local zones = {}
    if type(RoR_SoR) ~= "table" or type(RoR_SoR.OpenZones) ~= "table" then
        return zones
    end

    if type(RoR_SoR.StackSort) == "table" then
        for _, entry in ipairs(RoR_SoR.StackSort) do
            local zoneId = tonumber(type(entry) == "table" and entry.Zone)
            if zoneId ~= nil and isOpenZone(zoneId) and isNormalZone(zoneId) and windowExists(getZoneWindow(zoneId)) then
                zones[#zones + 1] = zoneId
            end
        end
    end

    if #zones == 0 then
        for zoneKey, _ in pairs(RoR_SoR.OpenZones) do
            local zoneId = tonumber(zoneKey)
            if zoneId ~= nil and isNormalZone(zoneId) and windowExists(getZoneWindow(zoneId)) then
                zones[#zones + 1] = zoneId
            end
        end

        table.sort(zones)
    end

    return zones
end

local function getKeepsForZone(zoneId)
    if type(RoR_SoR) ~= "table" or type(RoR_SoR.KEEP_IDs) ~= "table" then
        return nil
    end

    return RoR_SoR.KEEP_IDs[tostring(zoneId)] or RoR_SoR.KEEP_IDs[tonumber(zoneId)]
end

local function formatElapsed(seconds)
    local value = math.floor(tonumber(seconds) or 0)
    if value < 0 then
        value = 0
    end

    local hours = math.floor(value / 3600)
    local minutes = math.floor((value % 3600) / 60)
    local secs = value % 60

    if hours > 0 then
        return tostring(hours) .. ":" .. string.format("%02d", minutes) .. ":" .. string.format("%02d", secs)
    end

    return tostring(minutes) .. ":" .. string.format("%02d", secs)
end

local function formatCountdown(seconds)
    local value = math.ceil(tonumber(seconds) or 0)
    if value < 0 then
        value = 0
    end

    return formatElapsed(value)
end

local function getEventTimeText()
    if type(os) == "table" and type(os.date) == "function" then
        local ok, value = pcall(os.date, "%Y-%m-%d %H:%M:%S")
        if ok and value ~= nil then
            return toString(value)
        end
    end

    return "session+" .. formatElapsed(KST._clock)
end

local function parseEpochLikeValue(value)
    local n = tonumber(value)
    if n ~= nil and n > 1000000000 then
        return n
    end

    local text = toString(value)
    local y, mo, d, h, mi, s = string.match(text, "(%d%d%d%d)%D+(%d%d)%D+(%d%d)%D+(%d%d)%D+(%d%d)%D+(%d%d)")
    if y ~= nil and type(os) == "table" and type(os.time) == "function" then
        local ok, epoch = pcall(os.time, {
            year = tonumber(y),
            month = tonumber(mo),
            day = tonumber(d),
            hour = tonumber(h),
            min = tonumber(mi),
            sec = tonumber(s),
        })
        if ok and tonumber(epoch) ~= nil then
            return tonumber(epoch)
        end
    end

    return nil
end

local function tryGlobalTimeFunction(functionName)
    local fn = _G and _G[functionName] or nil
    if type(fn) ~= "function" then
        return nil
    end

    local ok, a, b, c, d, e, f = pcall(fn)
    if not ok then
        return nil
    end

    local direct = parseEpochLikeValue(a)
    if direct ~= nil then
        return direct
    end

    -- Some clients expose date/time as Y,M,D,H,M,S.
    if tonumber(a) ~= nil and tonumber(b) ~= nil and tonumber(c) ~= nil and tonumber(d) ~= nil and tonumber(e) ~= nil and type(os) == "table" and type(os.time) == "function" then
        local okEpoch, epoch = pcall(os.time, {
            year = tonumber(a),
            month = tonumber(b),
            day = tonumber(c),
            hour = tonumber(d),
            min = tonumber(e),
            sec = tonumber(f) or 0,
        })
        if okEpoch and tonumber(epoch) ~= nil then
            return tonumber(epoch)
        end
    end

    return nil
end

local function getRealEpochSeconds()
    if type(os) == "table" and type(os.time) == "function" then
        local ok, value = pcall(os.time)
        if ok and tonumber(value) ~= nil then
            return tonumber(value)
        end
    end

    local candidates = {
        "GetEpochTime",
        "GetServerTime",
        "GetCurrentTime",
        "GetCurrentDateTime",
        "GetDateTime",
        "GetRealTime",
        "GetWallClockTime",
        "GetUnixTime",
        "GetSecondsSince1970",
    }

    for _, name in ipairs(candidates) do
        local epoch = tryGlobalTimeFunction(name)
        if epoch ~= nil then
            return epoch
        end
    end

    if KST ~= nil and KST._realClockMissingLogged ~= true then
        KST._realClockMissingLogged = true
        if type(appendFileLogControlLine) == "function" then
            KST.SafeAppendFileLogControlLine("[KST_TIME_WARNING] no real epoch clock available; timers can only advance while the UI session is running")
        end
    end

    return nil
end

local function getEpochTimeText(epochSeconds)
    local epoch = tonumber(epochSeconds)
    if epoch == nil then
        return nil
    end

    if type(os) == "table" and type(os.date) == "function" then
        local ok, value = pcall(os.date, "%Y-%m-%d %H:%M:%S", epoch)
        if ok and value ~= nil then
            return toString(value)
        end
    end

    return nil
end

local function getEndTimeText(epochSeconds, sessionSeconds)
    local epochText = getEpochTimeText(epochSeconds)
    if epochText ~= nil and epochText ~= "" then
        return epochText
    end

    local session = tonumber(sessionSeconds)
    if session ~= nil then
        return "session+" .. formatElapsed(session)
    end

    return nil
end

local function computeAbsoluteEnd(nowEpoch, nowSession, remainingSeconds)
    local remaining = tonumber(remainingSeconds)
    if remaining == nil then
        return nil, nil
    end

    local endEpoch = nil
    local endSession = nil
    if tonumber(nowEpoch) ~= nil then
        endEpoch = tonumber(nowEpoch) + remaining
    end
    if tonumber(nowSession) ~= nil then
        endSession = tonumber(nowSession) + remaining
    end
    return endEpoch, endSession
end

local function getNearestModuloDistance(value, interval)
    local number = tonumber(value)
    local size = tonumber(interval)
    if number == nil or size == nil or size <= 0 then
        return nil, nil
    end

    local rounded = math.floor(number)
    local modulo = rounded % size
    local distance = modulo
    if size - modulo < distance then
        distance = size - modulo
    end

    return modulo, distance
end

local function addModuloAnalysis(event, prefix, seconds)
    if type(event) ~= "table" then
        return
    end

    local value = tonumber(seconds)
    if value == nil then
        return
    end

    local intervals = { 5, 15, 30, 42, 60, 90 }
    for _, interval in ipairs(intervals) do
        local modulo, distance = getNearestModuloDistance(value, interval)
        if modulo ~= nil then
            event[prefix .. "Mod" .. tostring(interval)] = modulo
            event[prefix .. "Mod" .. tostring(interval) .. "Delta"] = distance
            event[prefix .. "Near" .. tostring(interval) .. "s2"] = distance <= 2
        end
    end
end

local function extractClockSecond(value)
    local text = toString(value)
    local second = string.match(text, ":(%d%d)$")
    return tonumber(second)
end

local function addTimingAnalysisToEvent(event)
    if type(event) ~= "table" then
        return
    end

    addModuloAnalysis(event, "elapsed", event.elapsedSeconds)
    addModuloAnalysis(event, "lastSup", event.secondsSinceLastSupply)
    addModuloAnalysis(event, "belowStreak", event.decayCurrentBelowStreakSeconds)
    addModuloAnalysis(event, "session", event.sessionSeconds)

    local clockSecond = extractClockSecond(event.observedAt)
    if clockSecond ~= nil then
        event.realClockSecond = clockSecond
        addModuloAnalysis(event, "realClockSecond", clockSecond)
    end
end

local function getZoneNameText(zoneId)
    local zoneNumber = tonumber(zoneId)
    if zoneNumber ~= nil and type(GetZoneName) == "function" then
        local ok, value = pcall(GetZoneName, zoneNumber)
        if ok and value ~= nil then
            local text = toString(value)
            if text ~= "" then
                return text
            end
        end
    end

    return "Zone " .. tostring(zoneId or "?")
end

local function getKeepNameText(keepId, keepIndex)
    local keepNumber = tonumber(keepId)
    if keepNumber ~= nil and type(GetKeepName) == "function" then
        local ok, value = pcall(GetKeepName, keepNumber)
        if ok and value ~= nil then
            local text = toString(value)
            if text ~= "" then
                return text
            end
        end
    end

    return "Keep " .. tostring(keepIndex or "?")
end

local function getKeepClaimText(keepData)
    local claim = toString(keepData and keepData.Claim)
    if claim == "" or claim == "0" or string.lower(claim) == "nil" then
        return "UnClaimed"
    end

    return claim
end

local function isKeepClaimed(claimText)
    local claim = toString(claimText)
    return claim ~= "" and claim ~= "0" and claim ~= "UnClaimed"
end

local function getRealmNameText(owner)
    local ownerNumber = tonumber(owner) or 0
    if type(GetRealmName) == "function" then
        local ok, value = pcall(GetRealmName, ownerNumber)
        if ok and value ~= nil then
            local text = toString(value)
            if text ~= "" then
                return text
            end
        end
    end

    if ownerNumber == 1 then
        return "Order"
    elseif ownerNumber == 2 then
        return "Destruction"
    end

    return "Neutral"
end

local function getBOStateName(state)
    local stateNumber = tonumber(state)
    if stateNumber == nil then
        return "Unknown"
    elseif stateNumber == 0 then
        return "Stable"
    elseif stateNumber == 2 then
        return "Abandoned"
    elseif stateNumber == 4 then
        return "Capping"
    elseif stateNumber == 8 then
        return "Unlocking/Locked"
    elseif stateNumber == 9 then
        return "Locked"
    elseif stateNumber == 10 then
        return "Locked"
    elseif stateNumber == 16 then
        return "Securing"
    end

    return "State " .. tostring(stateNumber)
end

local function getBOStateFullText(owner, state)
    local realm = getRealmNameText(owner)
    local stateName = getBOStateName(state)

    if stateName == "Stable" then
        return realm
    end

    return realm .. " " .. stateName
end

local function getObjectiveNameText(objectiveId, objectiveIndex)
    local objectiveNumber = tonumber(objectiveId)
    if objectiveNumber ~= nil and objectiveNumber ~= 0 and type(GetObjectiveName) == "function" then
        local ok, value = pcall(GetObjectiveName, objectiveNumber)
        if ok and value ~= nil then
            local text = toString(value)
            if text ~= "" then
                return text
            end
        end
    end

    return "BO " .. tostring(objectiveIndex or "?")
end

local function getBOIdsForZone(zoneId)
    if type(RoR_SoR) ~= "table" or type(RoR_SoR.BO_IDs) ~= "table" then
        return nil
    end

    return RoR_SoR.BO_IDs[tostring(zoneId)] or RoR_SoR.BO_IDs[tonumber(zoneId)]
end

local function getBOStatesForZone(zoneId)
    if type(RoR_SoR) ~= "table" or type(RoR_SoR.BO_States) ~= "table" then
        return nil
    end

    return RoR_SoR.BO_States[tostring(zoneId)] or RoR_SoR.BO_States[tonumber(zoneId)]
end

local function getBOTimersForZone(zoneId)
    if type(RoR_SoR) ~= "table" or type(RoR_SoR.Timers) ~= "table" then
        return nil
    end

    return RoR_SoR.Timers[tostring(zoneId)] or RoR_SoR.Timers[tonumber(zoneId)]
end

function getRequiredBOsForSupply(rank)
    local rankNumber = tonumber(rank) or 0

    -- Working hypothesis for current RoR campaign rules:
    -- lower-rank keeps need fewer active BO supply lines, while higher-rank
    -- keeps need more BOs before the secured objectives actually generate supplies.
    if rankNumber >= 4 then
        return 4
    elseif rankNumber >= 3 then
        return 3
    end

    return 2
end

local function getKeepForRealm(zoneId, realm)
    local realmNumber = tonumber(realm) or 0
    if realmNumber == 0 then
        return nil, nil
    end

    local keeps = getKeepsForZone(zoneId)
    if type(keeps) ~= "table" then
        return nil, nil
    end

    for i = 1, 2 do
        local keepData = type(keeps[i]) == "table" and keeps[i] or nil
        if tonumber(keepData and keepData.Owner) == realmNumber then
            return keepData, i
        end
    end

    return nil, nil
end

local function isBOSupplyActiveOwnedState(owner, state, timer)
    local ownerNumber = tonumber(owner) or 0
    local stateNumber = tonumber(state)
    local timerNumber = tonumber(timer)

    if ownerNumber == 0 then
        return false
    end

    -- If SoR itself still shows a BO timer, the BO is still transitioning
    -- (capping/securing/locking). It is not yet a clean supply-cycle timer.
    if timerNumber ~= nil and timerNumber > 0 then
        return false
    end

    -- In practice, a BO can keep state 16 (Securing) after the visible securing
    -- countdown has disappeared. That is the state Daniel observed as already
    -- generating supplies. Some clients expose stable ownership as state 0 or nil.
    if stateNumber == nil then
        return true
    end

    return stateNumber == KST.BO_STABLE_STATE or stateNumber == KST.BO_SECURING_STATE
end

local function getBOGenerationInfo(zoneId, realm)
    local realmNumber = tonumber(realm) or 0
    local info = {
        realm = realmNumber,
        keepIndex = nil,
        keepId = nil,
        keepName = nil,
        keepRank = nil,
        requiredBOs = nil,
        activeBOs = 0,
        canGenerate = false,
    }

    if realmNumber == 0 then
        return info
    end

    local keepData, keepIndex = getKeepForRealm(zoneId, realmNumber)
    local rank = tonumber(keepData and keepData.Rank)
    info.keepIndex = keepIndex
    info.keepId = tonumber(keepData and keepData.ID)
    info.keepName = getKeepNameText(info.keepId, keepIndex)
    info.keepRank = rank
    info.requiredBOs = getRequiredBOsForSupply(rank)

    local boIds = getBOIdsForZone(zoneId)
    local boStates = getBOStatesForZone(zoneId)
    local boTimers = getBOTimersForZone(zoneId)

    for i = 1, 4 do
        local boData = type(boIds) == "table" and type(boIds[i]) == "table" and boIds[i] or nil
        local owner = tonumber(boData and boData.Owner) or 0
        local state = type(boStates) == "table" and tonumber(boStates[i]) or nil
        local timer = type(boTimers) == "table" and tonumber(boTimers[i]) or nil

        if owner == realmNumber and isBOSupplyActiveOwnedState(owner, state, timer) then
            info.activeBOs = info.activeBOs + 1
        end
    end

    if KST.BO_REQUIRE_KEEP_LEVEL_FOR_SUPPLY then
        info.canGenerate = info.requiredBOs ~= nil and info.activeBOs >= info.requiredBOs
    else
        info.canGenerate = info.activeBOs > 0
    end

    return info
end

local function getBOSnapshot(zoneId, keepOwner)
    local boIds = getBOIdsForZone(zoneId)
    local boStates = getBOStatesForZone(zoneId)
    local boTimers = getBOTimersForZone(zoneId)
    local snapshot = {}
    local summary = {
        order = 0,
        destruction = 0,
        neutral = 0,
        ownedByKeepRealm = 0,
        total = 0,
    }

    for i = 1, 4 do
        local boData = type(boIds) == "table" and type(boIds[i]) == "table" and boIds[i] or nil
        local boId = tonumber(boData and boData.ID) or 0
        local owner = tonumber(boData and boData.Owner) or 0
        local state = type(boStates) == "table" and tonumber(boStates[i]) or nil
        local timer = type(boTimers) == "table" and tonumber(boTimers[i]) or nil

        if boId ~= 0 or owner ~= 0 or state ~= nil or timer ~= nil then
            summary.total = summary.total + 1
            if owner == 1 then
                summary.order = summary.order + 1
            elseif owner == 2 then
                summary.destruction = summary.destruction + 1
            else
                summary.neutral = summary.neutral + 1
            end

            if tonumber(keepOwner) ~= nil and owner == tonumber(keepOwner) then
                summary.ownedByKeepRealm = summary.ownedByKeepRealm + 1
            end

            local supplyActive = isBOSupplyActiveOwnedState(owner, state, timer)
            local generationInfo = getBOGenerationInfo(zoneId, owner)

            snapshot[i] = {
                index = i,
                id = boId,
                name = getObjectiveNameText(boId, i),
                owner = owner,
                realm = getRealmNameText(owner),
                state = state,
                timer = timer and math.floor(timer) or nil,
                timerText = timer and formatElapsed(timer) or nil,
                ownedByKeepRealm = tonumber(keepOwner) ~= nil and owner == tonumber(keepOwner) or false,
                supplyActive = supplyActive,
                supplyGenerating = supplyActive and generationInfo.canGenerate or false,
                activeBOsForRealm = generationInfo.activeBOs,
                requiredBOsForSupply = generationInfo.requiredBOs,
                keepRankForRealm = generationInfo.keepRank,
                keepNameForRealm = generationInfo.keepName,
            }
        end
    end

    return snapshot, summary
end


local function clampBOCount(value)
    local number = math.floor(tonumber(value) or 0)
    if number < 0 then
        number = 0
    elseif number > 4 then
        number = 4
    end
    return number
end

local function createDecayStats()
    return {
        startedAtSessionSeconds = math.floor(tonumber(KST._clock) or 0),
        lastAccumulatedAt = tonumber(KST._clock) or 0,
        totalSeconds = 0,
        friendlyBOSeconds = { [0] = 0, [1] = 0, [2] = 0, [3] = 0, [4] = 0 },
        activeBOSeconds = { [0] = 0, [1] = 0, [2] = 0, [3] = 0, [4] = 0 },
        enemyBOSeconds = { [0] = 0, [1] = 0, [2] = 0, [3] = 0, [4] = 0 },
        belowRequiredSeconds = 0,
        atRequiredSeconds = 0,
        aboveRequiredSeconds = 0,
        rawBelowRequiredSeconds = 0,
        rawAtRequiredSeconds = 0,
        rawAboveRequiredSeconds = 0,
        missingBOScore = 0,
        rawMissingBOScore = 0,
        enemyBOScore = 0,
        friendlyBOScore = 0,
        activeBOScore = 0,
        currentBelowStreakSeconds = 0,
        longestBelowStreakSeconds = 0,
        lastAtOrAboveRequiredAtSessionSeconds = math.floor(tonumber(KST._clock) or 0),
        currentRawBelowStreakSeconds = 0,
        longestRawBelowStreakSeconds = 0,
        lastRawAtOrAboveRequiredAtSessionSeconds = math.floor(tonumber(KST._clock) or 0),
        candidateObserved = false,
        candidateActive = false,
        candidateStartedCount = 0,
        candidateCancelledCount = 0,
        candidateActiveSeconds = 0,
        candidateCurrentStreakSeconds = 0,
        candidateLongestStreakSeconds = 0,
        candidateCurrentStartedAtSessionSeconds = nil,
        candidateLastStartedAtSessionSeconds = nil,
        candidateLastCancelledAtSessionSeconds = nil,
        hardDeficitSeconds = 0,
        weightedMissingBOSeconds = 0,
        weightedMissingBOSquaredSeconds = 0,
    }
end

local function resetDecayStats(keepState)
    if type(keepState) ~= "table" then
        return nil
    end

    keepState.decayStats = createDecayStats()
    keepState.lastDecayTrackingSnapshotAt = tonumber(KST._clock) or 0
    return keepState.decayStats
end

local function getDecayStats(keepState)
    if type(keepState) ~= "table" then
        return nil
    end

    if type(keepState.decayStats) ~= "table" then
        keepState.decayStats = createDecayStats()
    end

    if type(keepState.decayStats.friendlyBOSeconds) ~= "table" then
        keepState.decayStats.friendlyBOSeconds = { [0] = 0, [1] = 0, [2] = 0, [3] = 0, [4] = 0 }
    end
    if type(keepState.decayStats.activeBOSeconds) ~= "table" then
        keepState.decayStats.activeBOSeconds = { [0] = 0, [1] = 0, [2] = 0, [3] = 0, [4] = 0 }
    end
    if type(keepState.decayStats.enemyBOSeconds) ~= "table" then
        keepState.decayStats.enemyBOSeconds = { [0] = 0, [1] = 0, [2] = 0, [3] = 0, [4] = 0 }
    end

    keepState.decayStats.currentBelowStreakSeconds = tonumber(keepState.decayStats.currentBelowStreakSeconds) or 0
    keepState.decayStats.longestBelowStreakSeconds = tonumber(keepState.decayStats.longestBelowStreakSeconds) or 0
    keepState.decayStats.currentRawBelowStreakSeconds = tonumber(keepState.decayStats.currentRawBelowStreakSeconds) or 0
    keepState.decayStats.longestRawBelowStreakSeconds = tonumber(keepState.decayStats.longestRawBelowStreakSeconds) or 0
    keepState.decayStats.candidateStartedCount = tonumber(keepState.decayStats.candidateStartedCount) or 0
    keepState.decayStats.candidateCancelledCount = tonumber(keepState.decayStats.candidateCancelledCount) or 0
    keepState.decayStats.candidateActiveSeconds = tonumber(keepState.decayStats.candidateActiveSeconds) or 0
    keepState.decayStats.candidateCurrentStreakSeconds = tonumber(keepState.decayStats.candidateCurrentStreakSeconds) or 0
    keepState.decayStats.candidateLongestStreakSeconds = tonumber(keepState.decayStats.candidateLongestStreakSeconds) or 0
    keepState.decayStats.hardDeficitSeconds = tonumber(keepState.decayStats.hardDeficitSeconds) or 0
    keepState.decayStats.weightedMissingBOSeconds = tonumber(keepState.decayStats.weightedMissingBOSeconds) or 0
    keepState.decayStats.weightedMissingBOSquaredSeconds = tonumber(keepState.decayStats.weightedMissingBOSquaredSeconds) or 0

    return keepState.decayStats
end

local function getRawBOCountsForRealm(zoneId, realm)
    local realmNumber = tonumber(realm) or 0
    local boSnapshot, boSummary = getBOSnapshot(zoneId, realmNumber)
    local friendly = tonumber(boSummary and boSummary.ownedByKeepRealm) or 0
    local neutral = tonumber(boSummary and boSummary.neutral) or 0
    local total = tonumber(boSummary and boSummary.total) or 0
    local enemy = total - friendly - neutral
    if enemy < 0 then
        enemy = 0
    end

    return clampBOCount(friendly), clampBOCount(enemy), clampBOCount(neutral), total, boSnapshot, boSummary
end

local function accumulateDecayStats(zoneId, keepState, owner, generationInfo)
    if type(keepState) ~= "table" then
        return nil
    end

    -- Only accumulate scientific decay samples after a real supply/rank-gain reset.
    -- The visible timer can still be reset by a progress loss, but that is not a valid
    -- sample for the supply-delivered -> decay interval we are trying to measure.
    if keepState.lastSupplyDeliveredAt == nil then
        return nil
    end

    local stats = getDecayStats(keepState)
    local now = tonumber(KST._clock) or 0
    local last = tonumber(stats.lastAccumulatedAt) or now
    local delta = now - last
    if delta <= 0 then
        stats.lastAccumulatedAt = now
        return stats
    end

    local rawFriendly, rawEnemy = getRawBOCountsForRealm(zoneId, owner)
    local activeFriendly = clampBOCount(generationInfo and generationInfo.activeBOs)
    local required = tonumber(generationInfo and generationInfo.requiredBOs)
    local candidateActive = required ~= nil and activeFriendly < required
    local missingBOsNow = 0
    if candidateActive then
        missingBOsNow = required - activeFriendly
        if missingBOsNow < 0 then
            missingBOsNow = 0
        end
    end

    -- Candidate-state counters are logged to test whether the server uses a
    -- paused timer, a weighted deficit clock, or probabilistic checks.
    if required ~= nil then
        if stats.candidateObserved ~= true then
            stats.candidateObserved = true
            stats.candidateActive = candidateActive
            if candidateActive then
                stats.candidateStartedCount = (tonumber(stats.candidateStartedCount) or 0) + 1
                stats.candidateCurrentStartedAtSessionSeconds = last
                stats.candidateLastStartedAtSessionSeconds = last
            end
        elseif candidateActive ~= stats.candidateActive then
            if candidateActive then
                stats.candidateStartedCount = (tonumber(stats.candidateStartedCount) or 0) + 1
                stats.candidateCurrentStartedAtSessionSeconds = last
                stats.candidateLastStartedAtSessionSeconds = last
            else
                stats.candidateCancelledCount = (tonumber(stats.candidateCancelledCount) or 0) + 1
                stats.candidateLastCancelledAtSessionSeconds = last
                stats.candidateCurrentStartedAtSessionSeconds = nil
                stats.candidateCurrentStreakSeconds = 0
            end
            stats.candidateActive = candidateActive
        end

        if candidateActive then
            stats.candidateActiveSeconds = (tonumber(stats.candidateActiveSeconds) or 0) + delta
            stats.candidateCurrentStreakSeconds = (tonumber(stats.candidateCurrentStreakSeconds) or 0) + delta
            if (tonumber(stats.candidateCurrentStreakSeconds) or 0) > (tonumber(stats.candidateLongestStreakSeconds) or 0) then
                stats.candidateLongestStreakSeconds = stats.candidateCurrentStreakSeconds
            end
            stats.weightedMissingBOSeconds = (tonumber(stats.weightedMissingBOSeconds) or 0) + (missingBOsNow * delta)
            stats.weightedMissingBOSquaredSeconds = (tonumber(stats.weightedMissingBOSquaredSeconds) or 0) + (missingBOsNow * missingBOsNow * delta)
            if missingBOsNow >= 2 then
                stats.hardDeficitSeconds = (tonumber(stats.hardDeficitSeconds) or 0) + delta
            end
        end
    end

    stats.totalSeconds = (tonumber(stats.totalSeconds) or 0) + delta
    stats.friendlyBOSeconds[rawFriendly] = (tonumber(stats.friendlyBOSeconds[rawFriendly]) or 0) + delta
    stats.activeBOSeconds[activeFriendly] = (tonumber(stats.activeBOSeconds[activeFriendly]) or 0) + delta
    stats.enemyBOSeconds[rawEnemy] = (tonumber(stats.enemyBOSeconds[rawEnemy]) or 0) + delta

    stats.friendlyBOScore = (tonumber(stats.friendlyBOScore) or 0) + (rawFriendly * delta)
    stats.activeBOScore = (tonumber(stats.activeBOScore) or 0) + (activeFriendly * delta)
    stats.enemyBOScore = (tonumber(stats.enemyBOScore) or 0) + (rawEnemy * delta)

    if required ~= nil then
        if activeFriendly < required then
            stats.belowRequiredSeconds = (tonumber(stats.belowRequiredSeconds) or 0) + delta
            stats.missingBOScore = (tonumber(stats.missingBOScore) or 0) + ((required - activeFriendly) * delta)
            stats.currentBelowStreakSeconds = (tonumber(stats.currentBelowStreakSeconds) or 0) + delta
            if (tonumber(stats.currentBelowStreakSeconds) or 0) > (tonumber(stats.longestBelowStreakSeconds) or 0) then
                stats.longestBelowStreakSeconds = stats.currentBelowStreakSeconds
            end
        elseif activeFriendly == required then
            stats.atRequiredSeconds = (tonumber(stats.atRequiredSeconds) or 0) + delta
            stats.currentBelowStreakSeconds = 0
            stats.lastAtOrAboveRequiredAtSessionSeconds = now
        else
            stats.aboveRequiredSeconds = (tonumber(stats.aboveRequiredSeconds) or 0) + delta
            stats.currentBelowStreakSeconds = 0
            stats.lastAtOrAboveRequiredAtSessionSeconds = now
        end

        if rawFriendly < required then
            stats.rawBelowRequiredSeconds = (tonumber(stats.rawBelowRequiredSeconds) or 0) + delta
            stats.rawMissingBOScore = (tonumber(stats.rawMissingBOScore) or 0) + ((required - rawFriendly) * delta)
            stats.currentRawBelowStreakSeconds = (tonumber(stats.currentRawBelowStreakSeconds) or 0) + delta
            if (tonumber(stats.currentRawBelowStreakSeconds) or 0) > (tonumber(stats.longestRawBelowStreakSeconds) or 0) then
                stats.longestRawBelowStreakSeconds = stats.currentRawBelowStreakSeconds
            end
        elseif rawFriendly == required then
            stats.rawAtRequiredSeconds = (tonumber(stats.rawAtRequiredSeconds) or 0) + delta
            stats.currentRawBelowStreakSeconds = 0
            stats.lastRawAtOrAboveRequiredAtSessionSeconds = now
        else
            stats.rawAboveRequiredSeconds = (tonumber(stats.rawAboveRequiredSeconds) or 0) + delta
            stats.currentRawBelowStreakSeconds = 0
            stats.lastRawAtOrAboveRequiredAtSessionSeconds = now
        end
    end

    stats.lastAccumulatedAt = now
    return stats
end

local function roundNumber(value, decimals)
    local number = tonumber(value)
    if number == nil then
        return nil
    end

    local places = tonumber(decimals) or 0
    local factor = 1
    for _ = 1, places do
        factor = factor * 10
    end

    return math.floor(number * factor + 0.5) / factor
end

local function formatSecondsTable(values)
    if type(values) ~= "table" then
        return nil
    end

    local parts = {}
    for i = 0, 4 do
        local seconds = tonumber(values[i]) or 0
        if seconds > 0 then
            parts[#parts + 1] = tostring(i) .. ":" .. formatElapsed(seconds)
        end
    end

    if #parts == 0 then
        return nil
    end

    return table.concat(parts, ",")
end

local function copyDecayStatsToEvent(event, keepState)
    if type(event) ~= "table" or type(keepState) ~= "table" then
        return
    end

    local stats = type(keepState.decayStats) == "table" and keepState.decayStats or nil
    local total = stats and tonumber(stats.totalSeconds) or nil
    local lastSupplyAt = tonumber(keepState.lastSupplyDeliveredAt)

    event.lastSupplySessionSeconds = lastSupplyAt and math.floor(lastSupplyAt) or nil
    event.lastSupplySession = lastSupplyAt and formatElapsed(lastSupplyAt) or nil
    event.lastSupplyObservedAt = keepState.lastSupplyObservedAt
    event.lastSupplyEventIndex = keepState.lastSupplyEventIndex
    event.lastSupplyWasObserved = lastSupplyAt ~= nil
    event.decaySampleAccepted = false
    event.decaySampleReason = "no previous observed supply"

    if lastSupplyAt ~= nil then
        local sinceSupply = (tonumber(KST._clock) or 0) - lastSupplyAt
        event.secondsSinceLastSupply = math.floor(sinceSupply)
        event.elapsedSinceLastSupply = formatElapsed(sinceSupply)
        event.decaySampleReason = "ok"
        event.decaySampleAccepted = sinceSupply >= (tonumber(KST.DECAY_SAMPLE_MIN_SECONDS) or 0)
    end

    if total ~= nil then
        event.decayStatsStartedAtSessionSeconds = tonumber(stats.startedAtSessionSeconds) and math.floor(stats.startedAtSessionSeconds) or nil
        event.decayStatsStartedAtSession = stats.startedAtSessionSeconds and formatElapsed(stats.startedAtSessionSeconds) or nil
        event.decayTotalTrackedSeconds = math.floor(total)
        event.decayTotalTracked = formatElapsed(total)
        event.decayFriendlyBOSeconds = stats.friendlyBOSeconds
        event.decayActiveBOSeconds = stats.activeBOSeconds
        event.decayEnemyBOSeconds = stats.enemyBOSeconds
        event.decayFriendlyBOTime = formatSecondsTable(stats.friendlyBOSeconds)
        event.decayActiveBOTime = formatSecondsTable(stats.activeBOSeconds)
        event.decayEnemyBOTime = formatSecondsTable(stats.enemyBOSeconds)
        event.decayBelowRequiredSeconds = math.floor(tonumber(stats.belowRequiredSeconds) or 0)
        event.decayBelowRequired = formatElapsed(stats.belowRequiredSeconds or 0)
        event.decayAtRequiredSeconds = math.floor(tonumber(stats.atRequiredSeconds) or 0)
        event.decayAtRequired = formatElapsed(stats.atRequiredSeconds or 0)
        event.decayAboveRequiredSeconds = math.floor(tonumber(stats.aboveRequiredSeconds) or 0)
        event.decayAboveRequired = formatElapsed(stats.aboveRequiredSeconds or 0)
        event.decayRawBelowRequiredSeconds = math.floor(tonumber(stats.rawBelowRequiredSeconds) or 0)
        event.decayRawBelowRequired = formatElapsed(stats.rawBelowRequiredSeconds or 0)
        event.decayRawAtRequiredSeconds = math.floor(tonumber(stats.rawAtRequiredSeconds) or 0)
        event.decayRawAtRequired = formatElapsed(stats.rawAtRequiredSeconds or 0)
        event.decayRawAboveRequiredSeconds = math.floor(tonumber(stats.rawAboveRequiredSeconds) or 0)
        event.decayRawAboveRequired = formatElapsed(stats.rawAboveRequiredSeconds or 0)
        event.decayMissingBOScore = math.floor(tonumber(stats.missingBOScore) or 0)
        event.decayRawMissingBOScore = math.floor(tonumber(stats.rawMissingBOScore) or 0)
        event.decayEnemyBOScore = math.floor(tonumber(stats.enemyBOScore) or 0)
        event.decayFriendlyBOScore = math.floor(tonumber(stats.friendlyBOScore) or 0)
        event.decayActiveBOScore = math.floor(tonumber(stats.activeBOScore) or 0)

        event.decayCurrentBelowStreakSeconds = math.floor(tonumber(stats.currentBelowStreakSeconds) or 0)
        event.decayCurrentBelowStreak = formatElapsed(stats.currentBelowStreakSeconds or 0)
        event.currentBelowStreakAtDecaySeconds = event.decayCurrentBelowStreakSeconds
        event.currentBelowStreakAtDecay = event.decayCurrentBelowStreak
        event.decayLongestBelowStreakSeconds = math.floor(tonumber(stats.longestBelowStreakSeconds) or 0)
        event.decayLongestBelowStreak = formatElapsed(stats.longestBelowStreakSeconds or 0)
        event.decayCurrentRawBelowStreakSeconds = math.floor(tonumber(stats.currentRawBelowStreakSeconds) or 0)
        event.decayCurrentRawBelowStreak = formatElapsed(stats.currentRawBelowStreakSeconds or 0)
        event.decayLongestRawBelowStreakSeconds = math.floor(tonumber(stats.longestRawBelowStreakSeconds) or 0)
        event.decayLongestRawBelowStreak = formatElapsed(stats.longestRawBelowStreakSeconds or 0)

        local lastAtOrAbove = tonumber(stats.lastAtOrAboveRequiredAtSessionSeconds)
        if lastAtOrAbove ~= nil then
            local sinceAtOrAbove = (tonumber(KST._clock) or 0) - lastAtOrAbove
            if sinceAtOrAbove < 0 then
                sinceAtOrAbove = 0
            end
            event.timeSinceLastAtOrAboveRequirementSeconds = math.floor(sinceAtOrAbove)
            event.timeSinceLastAtOrAboveRequirement = formatElapsed(sinceAtOrAbove)
        end

        local lastRawAtOrAbove = tonumber(stats.lastRawAtOrAboveRequiredAtSessionSeconds)
        if lastRawAtOrAbove ~= nil then
            local sinceRawAtOrAbove = (tonumber(KST._clock) or 0) - lastRawAtOrAbove
            if sinceRawAtOrAbove < 0 then
                sinceRawAtOrAbove = 0
            end
            event.timeSinceLastRawAtOrAboveRequirementSeconds = math.floor(sinceRawAtOrAbove)
            event.timeSinceLastRawAtOrAboveRequirement = formatElapsed(sinceRawAtOrAbove)
        end

        event.candidateActiveSeconds = math.floor(tonumber(stats.candidateActiveSeconds) or 0)
        event.candidateActive = formatElapsed(stats.candidateActiveSeconds or 0)
        event.candidateCurrentStreakSeconds = math.floor(tonumber(stats.candidateCurrentStreakSeconds) or 0)
        event.candidateCurrentStreak = formatElapsed(stats.candidateCurrentStreakSeconds or 0)
        event.candidateLongestStreakSeconds = math.floor(tonumber(stats.candidateLongestStreakSeconds) or 0)
        event.candidateLongestStreak = formatElapsed(stats.candidateLongestStreakSeconds or 0)
        event.candidateStartedCount = tonumber(stats.candidateStartedCount) or 0
        event.candidateCancelledCount = tonumber(stats.candidateCancelledCount) or 0
        event.candidateCurrentStartedAtSessionSeconds = stats.candidateCurrentStartedAtSessionSeconds and math.floor(tonumber(stats.candidateCurrentStartedAtSessionSeconds) or 0) or nil
        event.candidateLastStartedAtSessionSeconds = stats.candidateLastStartedAtSessionSeconds and math.floor(tonumber(stats.candidateLastStartedAtSessionSeconds) or 0) or nil
        event.candidateLastCancelledAtSessionSeconds = stats.candidateLastCancelledAtSessionSeconds and math.floor(tonumber(stats.candidateLastCancelledAtSessionSeconds) or 0) or nil
        if event.candidateCurrentStartedAtSessionSeconds ~= nil then
            local age = (tonumber(KST._clock) or 0) - event.candidateCurrentStartedAtSessionSeconds
            if age < 0 then
                age = 0
            end
            event.candidateAgeSeconds = math.floor(age)
            event.candidateAge = formatElapsed(age)
        end
        event.hardDeficitSeconds = math.floor(tonumber(stats.hardDeficitSeconds) or 0)
        event.hardDeficit = formatElapsed(stats.hardDeficitSeconds or 0)
        event.weightedMissingBOSeconds = math.floor(tonumber(stats.weightedMissingBOSeconds) or 0)
        event.weightedMissingBOSquaredSeconds = math.floor(tonumber(stats.weightedMissingBOSquaredSeconds) or 0)
        event.safeAtOrAboveSeconds = math.floor((tonumber(stats.atRequiredSeconds) or 0) + (tonumber(stats.aboveRequiredSeconds) or 0))
        event.safeAtOrAbove = formatElapsed((tonumber(stats.atRequiredSeconds) or 0) + (tonumber(stats.aboveRequiredSeconds) or 0))

        if total > 0 then
            event.decayAverageFriendlyBOs = roundNumber((tonumber(stats.friendlyBOScore) or 0) / total, 2)
            event.decayAverageActiveBOs = roundNumber((tonumber(stats.activeBOScore) or 0) / total, 2)
            event.decayAverageEnemyBOs = roundNumber((tonumber(stats.enemyBOScore) or 0) / total, 2)
        end
    end

    addTimingAnalysisToEvent(event)
end

local function trimLog()
    if type(KeepSupplyTimerLog) ~= "table" then
        KeepSupplyTimerLog = {}
    end
    if type(KeepSupplyTimerLog.events) ~= "table" then
        KeepSupplyTimerLog.events = {}
    end

    while #KeepSupplyTimerLog.events > KST.MAX_LOG_ENTRIES do
        table.remove(KeepSupplyTimerLog.events, 1)
    end
end

local function trimDecaySamples()
    if type(KeepSupplyTimerLog) ~= "table" then
        KeepSupplyTimerLog = {}
    end
    if type(KeepSupplyTimerLog.decaySamples) ~= "table" then
        KeepSupplyTimerLog.decaySamples = {}
    end

    local maxSamples = tonumber(KST.MAX_DECAY_SAMPLES) or 1000
    while #KeepSupplyTimerLog.decaySamples > maxSamples do
        table.remove(KeepSupplyTimerLog.decaySamples, 1)
    end
end


local function isFileLogEnabled()
    if type(KeepSupplyTimerSettings) ~= "table" then
        KeepSupplyTimerSettings = {}
    end

    if KeepSupplyTimerSettings.fileLogEnabled == nil then
        KeepSupplyTimerSettings.fileLogEnabled = KST.FILE_LOG_ENABLED_DEFAULT
    end

    return KeepSupplyTimerSettings.fileLogEnabled ~= false
end

local function sanitizeLogField(value)
    local text = toString(value)
    text = string.gsub(text, "\r", " ")
    text = string.gsub(text, "\n", " ")
    text = string.gsub(text, "\t", " ")
    text = string.gsub(text, "|", "/")
    return text
end

local function formatLogBool(value)
    if value == true then
        return "Y"
    elseif value == false then
        return "N"
    end
    return nil
end

local function formatBOLogDetail(snapshot)
    if type(snapshot) ~= "table" then
        return nil
    end

    local parts = {}
    for i = 1, 4 do
        local bo = type(snapshot[i]) == "table" and snapshot[i] or nil
        if bo ~= nil then
            local item = {}
            item[#item + 1] = "i=" .. sanitizeLogField(bo.index or i)
            item[#item + 1] = "name=" .. sanitizeLogField(bo.name or "?")
            item[#item + 1] = "owner=" .. sanitizeLogField(bo.realm or bo.owner or "?")
            item[#item + 1] = "ownerId=" .. sanitizeLogField(bo.owner or "?")
            item[#item + 1] = "state=" .. sanitizeLogField(getBOStateName(bo.state))
            item[#item + 1] = "stateId=" .. sanitizeLogField(bo.state or "?")
            item[#item + 1] = "timer=" .. sanitizeLogField(bo.timerText or bo.timer or "-")
            item[#item + 1] = "ownedByKeepRealm=" .. sanitizeLogField(formatLogBool(bo.ownedByKeepRealm) or "?")
            item[#item + 1] = "supplyActive=" .. sanitizeLogField(formatLogBool(bo.supplyActive) or "?")
            item[#item + 1] = "supplyGenerating=" .. sanitizeLogField(formatLogBool(bo.supplyGenerating) or "?")
            item[#item + 1] = "activeBOsForRealm=" .. sanitizeLogField(bo.activeBOsForRealm or "?")
            item[#item + 1] = "requiredBOsForSupply=" .. sanitizeLogField(bo.requiredBOsForSupply or "?")
            item[#item + 1] = "keepRankForRealm=" .. sanitizeLogField(bo.keepRankForRealm or "?")
            item[#item + 1] = "keepNameForRealm=" .. sanitizeLogField(bo.keepNameForRealm or "?")
            parts[#parts + 1] = "BO" .. tostring(i) .. "{" .. table.concat(item, ",") .. "}"
        end
    end

    if #parts == 0 then
        return nil
    end

    return table.concat(parts, ";")
end

local function formatKeepLogDetail(snapshot)
    if type(snapshot) ~= "table" then
        return nil
    end

    local parts = {}
    for i = 1, 2 do
        local keep = type(snapshot[i]) == "table" and snapshot[i] or nil
        if keep ~= nil then
            local item = {}
            item[#item + 1] = "i=" .. sanitizeLogField(keep.index or i)
            item[#item + 1] = "name=" .. sanitizeLogField(keep.name or "?")
            item[#item + 1] = "realm=" .. sanitizeLogField(keep.realm or keep.owner or "?")
            item[#item + 1] = "ownerId=" .. sanitizeLogField(keep.owner or "?")
            item[#item + 1] = "rank=" .. sanitizeLogField(keep.rank or keep.stars or "?")
            item[#item + 1] = "supply=" .. sanitizeLogField(keep.supply or "?")
            item[#item + 1] = "state=" .. sanitizeLogField(keep.state or "?")
            item[#item + 1] = "guild=" .. sanitizeLogField(keep.guild or keep.claim or "?")
            item[#item + 1] = "claimed=" .. sanitizeLogField(formatLogBool(keep.claimed) or "?")
            parts[#parts + 1] = "KEEP" .. tostring(i) .. "{" .. table.concat(item, ",") .. "}"
        end
    end

    if #parts == 0 then
        return nil
    end

    return table.concat(parts, ";")
end

local function buildFileLogLine(event)
    if type(event) ~= "table" then
        return nil
    end

    local parts = {}
    local function add(key, value)
        if value ~= nil then
            parts[#parts + 1] = key .. "=" .. sanitizeLogField(value)
        end
    end

    add("idx", type(KeepSupplyTimerLog) == "table" and type(KeepSupplyTimerLog.events) == "table" and #KeepSupplyTimerLog.events or nil)
    add("sampleId", event.decaySampleId)
    add("trackId", event.decayTrackingSnapshotId)
    add("sourceIdx", event.sourceEventIndex)
    add("reason", event.snapshotReason or event.trackingReason or event.researchReason)
    add("researchId", event.researchTickId)
    add("decayed", formatLogBool(event.decayed))
    add("eligible", formatLogBool(event.decayEligible))
    add("candidate", formatLogBool(event.decayCandidate))
    add("time", event.observedAt)
    add("session", event.sessionSeconds)
    add("event", event.event)
    add("zone", event.zoneName)
    add("keep", event.keepName)
    add("bo", event.boName)
    add("realm", event.realm or event.realmAfter)
    add("owner", event.owner or event.ownerAfter)
    add("stars", event.stars or event.rank or event.rankAfter)
    add("guild", event.guild or event.guildAfter or event.claim or event.claimAfter)
    add("upgrade", event.upgradeName)
    add("upgradeRank", event.upgradeRank)
    add("upgradeState", event.upgradeState)
    add("upgradeDuration", event.upgradeDurationSeconds)
    add("upgradeStartedAt", event.upgradeStartedAt)
    add("upgradeStartedSession", event.upgradeStartedSessionSeconds)
    add("upgradeBuildEndsAt", event.upgradeBuildEndsAt)
    add("upgradeBuildEndsSession", event.upgradeBuildEndsAtSessionSeconds)
    add("upgradeStartedEpoch", event.upgradeStartedEpoch)
    add("upgradeBuildEndsEpoch", event.upgradeBuildEndsEpoch)
    add("upgradeRemoveEndsAt", event.upgradeRemoveEndsAt)
    add("upgradeRemoveEndsSession", event.upgradeRemoveEndsAtSessionSeconds)
    add("upgradeRemoveEndsEpoch", event.upgradeRemoveEndsEpoch)
    add("upgradeFirstChargeAt", event.upgradeFirstChargeAt)
    add("upgradeFirstChargeSession", event.upgradeFirstChargeAtSessionSeconds)
    add("upgradeFirstChargeEpoch", event.upgradeFirstChargeEpoch)
    add("upgradeRechargeInterval", event.upgradeRechargeIntervalSeconds)
    add("upgradeMaxCharges", event.upgradeMaxCharges)
    add("upgradeSource", event.upgradeSource)
    add("rawChat", event.rawChatText)

    if event.supplyBefore ~= nil or event.supplyAfter ~= nil then
        add("supply", toString(event.supplyBefore or "?") .. "->" .. toString(event.supplyAfter or "?"))
    else
        add("supply", event.supply)
    end

    if event.rankBefore ~= nil or event.rankAfter ~= nil then
        add("rank", toString(event.rankBefore or "?") .. "->" .. toString(event.rankAfter or "?"))
    end

    if event.stateNameBefore ~= nil or event.stateNameAfter ~= nil then
        add("state", toString(event.stateNameBefore or "?") .. "->" .. toString(event.stateNameAfter or "?"))
    end

    if event.realmBefore ~= nil or event.realmAfter ~= nil then
        add("realmChange", toString(event.realmBefore or "?") .. "->" .. toString(event.realmAfter or "?"))
    end

    add("timer", event.timerText or event.timer)
    add("elapsed", event.elapsed)
    add("elapsedSec", event.elapsedSeconds)
    add("BOs", toString(event.boOwnedByKeepRealm or event.boOwnedByNewRealm or "?") .. "/" .. toString(event.boTotal or "?"))
    add("req", toString(event.activeBOs or event.activeBOsForRealm or "?") .. "/" .. toString(event.requiredBOs or event.requiredBOsForSupply or "?"))
    add("missingBOsNow", event.missingBOsNow)
    add("rawMissingBOsNow", event.rawMissingBOsNow)
    add("BOdef", event.elapsedSinceBORequirementLost or event.elapsedSinceBORequirementLostSeconds)
    add("ref", event.serverDecayReference or event.serverDecayReferenceSeconds)
    add("globalRef", event.serverDecayGlobalReference or event.serverDecayGlobalReferenceSessionSeconds)
    add("globalExpected", event.expectedGlobalDecayIn or event.expectedGlobalDecayInSeconds)
    add("lastSup", event.elapsedSinceLastSupply or event.secondsSinceLastSupply)
    add("lastSupIdx", event.lastSupplyEventIndex)
    add("sample", event.decaySampleAccepted == true and "Y" or (event.decaySampleAccepted == false and "N" or nil))
    add("sampleReason", event.decaySampleReason)
    add("tracked", event.decayTotalTracked or event.decayTotalTrackedSeconds)
    add("rawBOTime", event.decayFriendlyBOTime)
    add("activeBOTime", event.decayActiveBOTime)
    add("enemyBOTime", event.decayEnemyBOTime)
    add("below", event.decayBelowRequired or event.decayBelowRequiredSeconds)
    add("at", event.decayAtRequired or event.decayAtRequiredSeconds)
    add("above", event.decayAboveRequired or event.decayAboveRequiredSeconds)
    add("rawBelow", event.decayRawBelowRequired or event.decayRawBelowRequiredSeconds)
    add("missScore", event.decayMissingBOScore)
    add("rawMissScore", event.decayRawMissingBOScore)
    add("enemyScore", event.decayEnemyBOScore)
    add("avgRawBO", event.decayAverageFriendlyBOs)
    add("avgActiveBO", event.decayAverageActiveBOs)
    add("avgEnemyBO", event.decayAverageEnemyBOs)
    add("progressAtLastSupply", event.progressAtLastSupply)
    add("lastSupplyGain", event.lastSupplyGain)
    add("progressBeforeDecay", event.progressBeforeDecay)
    add("progressAfterDecay", event.progressAfterDecay)
    add("progressLostAmount", event.progressLostAmount)
    add("lossType", event.lossType)
    add("anomaly", event.anomaly)
    add("anomalyReason", event.anomalyReason)
    add("currentBelowStreak", event.currentBelowStreakAtDecay or event.decayCurrentBelowStreak or event.decayCurrentBelowStreakSeconds)
    add("currentBelowStreakSec", event.currentBelowStreakAtDecaySeconds or event.decayCurrentBelowStreakSeconds)
    add("longestBelowStreak", event.decayLongestBelowStreak or event.decayLongestBelowStreakSeconds)
    add("longestBelowStreakSec", event.decayLongestBelowStreakSeconds)
    add("timeSinceLastAtOrAboveReq", event.timeSinceLastAtOrAboveRequirement or event.timeSinceLastAtOrAboveRequirementSeconds)
    add("timeSinceLastAtOrAboveReqSec", event.timeSinceLastAtOrAboveRequirementSeconds)
    add("currentRawBelowStreak", event.decayCurrentRawBelowStreak or event.decayCurrentRawBelowStreakSeconds)
    add("currentRawBelowStreakSec", event.decayCurrentRawBelowStreakSeconds)
    add("longestRawBelowStreak", event.decayLongestRawBelowStreak or event.decayLongestRawBelowStreakSeconds)
    add("longestRawBelowStreakSec", event.decayLongestRawBelowStreakSeconds)
    add("timeSinceLastRawAtOrAboveReq", event.timeSinceLastRawAtOrAboveRequirement or event.timeSinceLastRawAtOrAboveRequirementSeconds)
    add("timeSinceLastRawAtOrAboveReqSec", event.timeSinceLastRawAtOrAboveRequirementSeconds)
    add("candidateAge", event.candidateAge or event.candidateAgeSeconds)
    add("candidateAgeSec", event.candidateAgeSeconds)
    add("candidateActive", event.candidateActive or event.candidateActiveSeconds)
    add("candidateActiveSec", event.candidateActiveSeconds)
    add("candidateCurrentStreak", event.candidateCurrentStreak or event.candidateCurrentStreakSeconds)
    add("candidateCurrentStreakSec", event.candidateCurrentStreakSeconds)
    add("candidateLongestStreak", event.candidateLongestStreak or event.candidateLongestStreakSeconds)
    add("candidateLongestStreakSec", event.candidateLongestStreakSeconds)
    add("candidateStartedCount", event.candidateStartedCount)
    add("candidateCancelledCount", event.candidateCancelledCount)
    add("candidateCurrentStartedAt", event.candidateCurrentStartedAtSessionSeconds)
    add("candidateLastStartedAt", event.candidateLastStartedAtSessionSeconds)
    add("candidateLastCancelledAt", event.candidateLastCancelledAtSessionSeconds)
    add("safeAtOrAbove", event.safeAtOrAbove or event.safeAtOrAboveSeconds)
    add("safeAtOrAboveSec", event.safeAtOrAboveSeconds)
    add("hardDeficit", event.hardDeficit or event.hardDeficitSeconds)
    add("hardDeficitSec", event.hardDeficitSeconds)
    add("weightedMissingBOs", event.weightedMissingBOSeconds)
    add("weightedMissingBOsSq", event.weightedMissingBOSquaredSeconds)
    add("tmin", event.tminSeconds)
    add("elapsedMinusTmin", event.elapsedMinusTminSeconds)
    add("elapsedMinusTminText", event.elapsedMinusTmin)
    add("elapsedMod5", event.elapsedMod5)
    add("elapsedMod15", event.elapsedMod15)
    add("elapsedMod30", event.elapsedMod30)
    add("elapsedMod42", event.elapsedMod42)
    add("elapsedMod60", event.elapsedMod60)
    add("elapsedMod90", event.elapsedMod90)
    add("elapsedMod5Delta", event.elapsedMod5Delta)
    add("elapsedMod15Delta", event.elapsedMod15Delta)
    add("elapsedMod30Delta", event.elapsedMod30Delta)
    add("elapsedMod42Delta", event.elapsedMod42Delta)
    add("elapsedMod60Delta", event.elapsedMod60Delta)
    add("elapsedMod90Delta", event.elapsedMod90Delta)
    add("elapsedNear5s2", formatLogBool(event.elapsedNear5s2))
    add("elapsedNear15s2", formatLogBool(event.elapsedNear15s2))
    add("elapsedNear30s2", formatLogBool(event.elapsedNear30s2))
    add("elapsedNear42s2", formatLogBool(event.elapsedNear42s2))
    add("elapsedNear60s2", formatLogBool(event.elapsedNear60s2))
    add("elapsedNear90s2", formatLogBool(event.elapsedNear90s2))
    add("lastSupMod5", event.lastSupMod5)
    add("lastSupMod15", event.lastSupMod15)
    add("lastSupMod30", event.lastSupMod30)
    add("lastSupMod42", event.lastSupMod42)
    add("lastSupMod60", event.lastSupMod60)
    add("lastSupMod90", event.lastSupMod90)
    add("lastSupMod5Delta", event.lastSupMod5Delta)
    add("lastSupMod15Delta", event.lastSupMod15Delta)
    add("lastSupMod30Delta", event.lastSupMod30Delta)
    add("lastSupMod42Delta", event.lastSupMod42Delta)
    add("lastSupMod60Delta", event.lastSupMod60Delta)
    add("lastSupMod90Delta", event.lastSupMod90Delta)
    add("lastSupNear5s2", formatLogBool(event.lastSupNear5s2))
    add("lastSupNear15s2", formatLogBool(event.lastSupNear15s2))
    add("lastSupNear30s2", formatLogBool(event.lastSupNear30s2))
    add("lastSupNear42s2", formatLogBool(event.lastSupNear42s2))
    add("lastSupNear60s2", formatLogBool(event.lastSupNear60s2))
    add("lastSupNear90s2", formatLogBool(event.lastSupNear90s2))
    add("belowStreakMod5", event.belowStreakMod5)
    add("belowStreakMod15", event.belowStreakMod15)
    add("belowStreakMod30", event.belowStreakMod30)
    add("belowStreakMod42", event.belowStreakMod42)
    add("belowStreakMod60", event.belowStreakMod60)
    add("belowStreakMod90", event.belowStreakMod90)
    add("belowStreakNear15s2", formatLogBool(event.belowStreakNear15s2))
    add("belowStreakNear42s2", formatLogBool(event.belowStreakNear42s2))
    add("sessionMod15", event.sessionMod15)
    add("sessionNear15s2", formatLogBool(event.sessionNear15s2))
    add("realClockSecond", event.realClockSecond)
    add("realClockSecondMod15", event.realClockSecondMod15)
    add("realClockSecondNear15s2", formatLogBool(event.realClockSecondNear15s2))

    -- Detailed fields for external analysis. These are intentionally written to
    -- the text log because SavedVariables are no longer the authoritative store.
    add("version", KST.VERSION)
    add("claimed", formatLogBool(event.claimed))
    add("sourceEvent", event.sourceEvent)
    add("referenceSet", formatLogBool(event.referenceSet or event.serverDecayReferenceSet or event.serverDecayGlobalReferenceSet))
    add("initialObservation", formatLogBool(event.initialObservation))
    add("timerReset", formatLogBool(event.timerReset))
    add("timerResetReason", event.timerResetReason)
    add("boRequirementMet", formatLogBool(event.boRequirementMet))
    add("boRequirementLostAt", event.boRequirementLostAtSessionSeconds)
    add("expectedDecayAt", event.expectedDecayAtSessionSeconds)
    add("expectedDecayIn", event.expectedDecayIn or event.expectedDecayInSeconds)
    add("globalExpectedAt", event.expectedGlobalDecayAtSessionSeconds)
    add("globalInterval", event.serverDecayGlobalInterval or event.serverDecayGlobalIntervalSeconds)
    add("lastSupplySession", event.lastSupplySession or event.lastSupplySessionSeconds)
    add("lastSupplyObservedAt", event.lastSupplyObservedAt)
    add("lastSupplyObserved", formatLogBool(event.lastSupplyWasObserved))
    add("decayStatsStart", event.decayStatsStartedAtSession or event.decayStatsStartedAtSessionSeconds)
    add("rawAt", event.decayRawAtRequired or event.decayRawAtRequiredSeconds)
    add("rawAbove", event.decayRawAboveRequired or event.decayRawAboveRequiredSeconds)
    add("friendlyScore", event.decayFriendlyBOScore)
    add("activeScore", event.decayActiveBOScore)
    add("hybridState", event.hybridDecayState or event.decayPredictionState)
    add("hybridPrev", event.hybridDecayPreviousState)
    add("hybridReason", event.hybridDecayReason or event.decayPredictionReason)
    add("hybridModel", event.hybridDecayModel)
    add("hybridAgeLimit", event.hybridDecayAgeLimitSeconds)
    add("hybridGrace", event.hybridDecayGraceSeconds)
    add("hybridArmedAt", event.hybridDecayArmedAtSessionSeconds)
    add("hybridCriticalAt", event.hybridDecayCriticalAtSessionSeconds)
    add("hybridToArmed", event.hybridDecayTimeToArmedSeconds)
    add("hybridToCritical", event.hybridDecayTimeToCriticalSeconds)
    add("hybridOverdue", event.hybridDecayCriticalOverdueSeconds)
    add("hybridError", event.hybridDecayPredictionErrorSeconds)
    add("hybridWasCritical", formatLogBool(event.hybridDecayWasCritical))
    add("hybridCriticalFor", event.hybridDecayCriticalForSeconds)
    add("hybridBelowSince", event.hybridDecaySegmentStartedAtSessionSeconds)
    add("hybridBelowFor", event.hybridDecayBelowForSeconds)
    add("boOrder", event.boOrder)
    add("boDestro", event.boDestruction)
    add("boNeutral", event.boNeutral)

    if KST.FILE_LOG_FULL_DETAILS == true then
        add("keepSnapshot", formatKeepLogDetail(event.keepSnapshot))
        add("boSnapshot", formatBOLogDetail(event.boSnapshot))
    end

    return table.concat(parts, " | ")
end

local function sanitizeFileNamePart(value)
    local text = toString(value)
    text = string.gsub(text, "[^%w_%-]", "_")
    text = string.gsub(text, "_+", "_")
    if text == "" then
        text = "session"
    end
    return text
end

local function buildUniqueFileLogPath()
    if type(KeepSupplyTimerLog) ~= "table" then
        KeepSupplyTimerLog = {}
    end

    if KST.FILE_LOG_UNIQUE_PER_SESSION == false then
        return KST.FILE_LOG_PATH
    end

    if type(KeepSupplyTimerLog.fileLogCurrentPath) == "string" and KeepSupplyTimerLog.fileLogCurrentPath ~= "" then
        return KeepSupplyTimerLog.fileLogCurrentPath
    end

    local nextRunId = (tonumber(KeepSupplyTimerLog.fileLogRunId) or 0) + 1
    KeepSupplyTimerLog.fileLogRunId = nextRunId
    KeepSupplyTimerLog.fileLogCurrentRunId = nextRunId

    local stamp = nil
    if type(os) == "table" and type(os.date) == "function" then
        local ok, value = pcall(os.date, "%Y%m%d_%H%M%S")
        if ok and value ~= nil and toString(value) ~= "" then
            stamp = sanitizeFileNamePart(value)
        end
    end

    if stamp == nil or stamp == "" then
        stamp = "run"
    end

    local path = KST.FILE_LOG_BASE_PATH
        .. "_"
        .. stamp
        .. "_"
        .. string.format("%06d", nextRunId)
        .. ".txt"

    KeepSupplyTimerLog.fileLogCurrentPath = path
    KeepSupplyTimerLog.fileLogCurrentStartedAt = getEventTimeText()
    KeepSupplyTimerLog.fileLogCurrentStartedSessionSeconds = math.floor(tonumber(KST._clock) or 0)

    return path
end

local function getCurrentFileLogPathText()
    if type(KeepSupplyTimerLog) == "table" and type(KeepSupplyTimerLog.fileLogCurrentPath) == "string" and KeepSupplyTimerLog.fileLogCurrentPath ~= "" then
        return KeepSupplyTimerLog.fileLogCurrentPath
    end

    if KST.FILE_LOG_UNIQUE_PER_SESSION == false then
        return KST.FILE_LOG_PATH
    end

    return KST.FILE_LOG_BASE_PATH .. "_<session>.txt"
end


local function buildArchiveFileLogPath()
    if KST.FILE_LOG_ARCHIVE_ENABLED ~= true then
        return nil
    end

    if type(KST._archiveFileLogPath) == "string" and KST._archiveFileLogPath ~= "" then
        return KST._archiveFileLogPath
    end

    if type(KeepSupplyTimerFileLogState) ~= "table" then
        KeepSupplyTimerFileLogState = {}
    end

    local nextRunId = (tonumber(KeepSupplyTimerFileLogState.runId) or 0) + 1
    KeepSupplyTimerFileLogState.runId = nextRunId
    KeepSupplyTimerFileLogState.version = KST.VERSION
    KeepSupplyTimerFileLogState.lastStartedAt = getEventTimeText()
    KeepSupplyTimerFileLogState.lastStartedSessionSeconds = math.floor(tonumber(KST._clock) or 0)

    local versionPart = sanitizeFileNamePart("v" .. toString(KST.VERSION))
    if versionPart == nil or versionPart == "" then
        versionPart = "v"
    end

    local path = KST.FILE_LOG_ARCHIVE_BASE_PATH
        .. "_"
        .. versionPart
        .. "_"
        .. string.format("%06d", nextRunId)
        .. ".txt"

    KeepSupplyTimerFileLogState.currentPath = path
    KeepSupplyTimerFileLogState.currentRunId = nextRunId
    KST._archiveFileLogPath = path

    return path
end

local function getCurrentArchiveFileLogPathText()
    if type(KST._archiveFileLogPath) == "string" and KST._archiveFileLogPath ~= "" then
        return KST._archiveFileLogPath
    end

    if type(KeepSupplyTimerFileLogState) == "table" and type(KeepSupplyTimerFileLogState.currentPath) == "string" and KeepSupplyTimerFileLogState.currentPath ~= "" then
        return KeepSupplyTimerFileLogState.currentPath
    end

    return KST.FILE_LOG_ARCHIVE_BASE_PATH .. "_<run>.txt"
end

local function initializeArchiveFileLog()
    if KST.FILE_LOG_ARCHIVE_ENABLED ~= true then
        return false
    end

    if KST._archiveFileLogInitialized == true then
        return true
    end

    if KST._archiveFileLogFailed == true then
        return false
    end

    if type(TextLogCreate) ~= "function" or type(TextLogSetEnabled) ~= "function" or type(TextLogAddEntry) ~= "function" then
        KST._archiveFileLogFailed = true
        KST._archiveFileLogLastError = "TextLog API unavailable"
        return false
    end

    local logName = KST.FILE_LOG_ARCHIVE_NAME
    local filePath = buildArchiveFileLogPath()
    if filePath == nil or filePath == "" then
        KST._archiveFileLogFailed = true
        KST._archiveFileLogLastError = "archive path unavailable"
        return false
    end

    local okCreate = pcall(TextLogCreate, logName, KST.FILE_LOG_ARCHIVE_MAX_LINES)
    if not okCreate then
        KST._archiveFileLogLastError = "TextLogCreate failed or already existed; continuing"
    end

    pcall(TextLogSetEnabled, logName, true)

    if type(TextLogAddFilterType) == "function" then
        pcall(TextLogAddFilterType, logName, KST.FILE_LOG_ARCHIVE_FILTER, toWString(""))
    end

    if type(TextLogSetIncrementalSaving) == "function" then
        pcall(TextLogSetIncrementalSaving, logName, true, toWString(filePath))
    end

    KST._archiveFileLogInitialized = true
    KST._archiveFileLogFailed = false

    KeepSupplyTimerFileLogState.currentPath = filePath
    KeepSupplyTimerFileLogState.currentRunId = KeepSupplyTimerFileLogState.currentRunId or KeepSupplyTimerFileLogState.runId
    KeepSupplyTimerFileLogState.lastHeaderAt = getEventTimeText()

    pcall(TextLogAddEntry, logName, KST.FILE_LOG_ARCHIVE_FILTER, toWString("--- KeepSupplyTimer " .. KST.VERSION .. " archive session started at " .. getEventTimeText() .. " path=" .. filePath .. " fixedPath=" .. getCurrentFileLogPathText() .. " archive=Y savedVariables=UPGRADES+FILELOGSTATE+SETTINGS fullDetails=Y ---"))

    return true
end

local function appendArchiveFileLogLine(line)
    if KST.FILE_LOG_ARCHIVE_ENABLED ~= true then
        return false
    end

    if line == nil or line == "" then
        return false
    end

    if not initializeArchiveFileLog() then
        return false
    end

    local okAdd = pcall(TextLogAddEntry, KST.FILE_LOG_ARCHIVE_NAME, KST.FILE_LOG_ARCHIVE_FILTER, toWString(line))
    if not okAdd then
        KST._archiveFileLogFailed = true
        KST._archiveFileLogLastError = "archive TextLogAddEntry failed"
        return false
    end

    KeepSupplyTimerFileLogState.lastWriteAt = getEventTimeText()
    KeepSupplyTimerFileLogState.lastWriteSessionSeconds = math.floor(tonumber(KST._clock) or 0)
    KeepSupplyTimerFileLogState.lastEventLine = string.sub(line, 1, 180)
    return true
end

local function initializeFileLog()
    if not isFileLogEnabled() then
        return false
    end

    if KST._fileLogInitialized == true then
        return true
    end

    if KST._fileLogFailed == true then
        return false
    end

    if type(TextLogCreate) ~= "function" or type(TextLogSetEnabled) ~= "function" or type(TextLogAddEntry) ~= "function" then
        KST._fileLogFailed = true
        KST._fileLogLastError = "TextLog API unavailable"
        return false
    end

    local logName = KST.FILE_LOG_NAME
    local filePath = buildUniqueFileLogPath()

    -- Do not destroy the TextLog object here. In append-safe mode we want the
    -- disk log to behave as a persistent append-only file across /reloadui.
    -- If the TextLog already exists, TextLogCreate may fail; that is not fatal.
    local okCreate = pcall(TextLogCreate, logName, KST.FILE_LOG_MAX_LINES)
    if not okCreate then
        KST._fileLogLastError = "TextLogCreate failed or already existed; continuing"
    end

    pcall(TextLogSetEnabled, logName, true)

    if type(TextLogAddFilterType) == "function" then
        pcall(TextLogAddFilterType, logName, KST.FILE_LOG_FILTER, toWString(""))
    end

    if type(TextLogSetIncrementalSaving) == "function" then
        pcall(TextLogSetIncrementalSaving, logName, true, toWString(filePath))
    end

    KST._fileLogInitialized = true
    KST._fileLogFailed = false
    KST._fileLogLastError = nil

    KeepSupplyTimerLog.fileLogPath = filePath
    KeepSupplyTimerLog.fileLogMaxLines = KST.FILE_LOG_MAX_LINES

    TextLogAddEntry(logName, KST.FILE_LOG_FILTER, toWString("--- KeepSupplyTimer " .. KST.VERSION .. " session started at " .. getEventTimeText() .. " path=" .. filePath .. " appendSafe=Y savedVariables=UPGRADES+SETTINGS archive=OFF fullDetails=Y ---"))
    if KST.FILE_LOG_APPEND_SAFE ~= true and type(TextLogSaveLog) == "function" then
        pcall(TextLogSaveLog, logName)
    end

    return true
end

local function appendFileLogLine(event)
    if not isFileLogEnabled() then
        return false
    end

    if not initializeFileLog() then
        return false
    end

    local line = buildFileLogLine(event)
    if line == nil or line == "" then
        return false
    end

    local okAdd = pcall(TextLogAddEntry, KST.FILE_LOG_NAME, KST.FILE_LOG_FILTER, toWString(line))
    if not okAdd then
        KST._fileLogFailed = true
        KST._fileLogLastError = "TextLogAddEntry failed"
        return false
    end

    if KST.FILE_LOG_APPEND_SAFE ~= true and KST.FILE_LOG_SAVE_EACH_EVENT and type(TextLogSaveLog) == "function" then
        pcall(TextLogSaveLog, KST.FILE_LOG_NAME)
    end

    KeepSupplyTimerLog.fileLogPath = buildUniqueFileLogPath()
    KeepSupplyTimerLog.fileLogLastEvent = event.event
    KeepSupplyTimerLog.fileLogLastWriteAt = event.observedAt
    KeepSupplyTimerLog.fileLogLastWriteSessionSeconds = event.sessionSeconds
    return true
end

local function afterEventStored(event)
    if type(event) ~= "table" then
        return
    end

    appendFileLogLine(event)
end

local function normalizeKeepKey(value)
    local text = toString(value)
    text = string.gsub(text, "\r", " ")
    text = string.gsub(text, "\n", " ")
    text = string.gsub(text, "^%s+", "")
    text = string.gsub(text, "%s+$", "")
    text = string.gsub(text, "’", "'")
    text = string.gsub(text, "‘", "'")
    text = string.gsub(text, "`", "'")
    text = string.gsub(text, "´", "'")
    text = string.gsub(text, "–", "-")
    text = string.gsub(text, "—", "-")
    text = string.gsub(text, "%s+", " ")
    text = string.lower(text)
    return text
end

function normalizeKeepLooseKey(value)
    local text = normalizeKeepKey(value)
    text = string.gsub(text, "[%p%s]+", "")
    return text
end

function normalizeKeepBaseKey(value)
    local text = normalizeKeepKey(value)
    text = string.gsub(text, "%f[%a][Tt]he%f[%A]%s+", "")
    local suffixes = {
        "keep",
        "citadel",
        "hold",
        "fortress",
        "garrison",
        "castle",
        "stronghold",
        "tower",
    }

    for _, suffix in ipairs(suffixes) do
        text = string.gsub(text, "%s+" .. suffix .. "$", "")
    end

    text = string.gsub(text, "^%s+", "")
    text = string.gsub(text, "%s+$", "")
    text = string.gsub(text, "[%p%s]+", "")
    return text
end

-- Canonical keep ids are the RoR /guildreleasekeep numbers. They are stable
-- enough to keep saved upgrade state attached to the right keep after /reload,
-- while aliases cover chat/SoR naming differences such as Charon's Citadel vs
-- Charon's Keep.
KST.CANONICAL_KEEPS = KST.CANONICAL_KEEPS or {
    [1] = { name = "Dok Karaz", zone = "Barak Varr", pairing = "Dwarf/Greenskin", tier = 2 },
    [2] = { name = "Fangbreaka Swamp", zone = "Marshes of Madness", pairing = "Dwarf/Greenskin", tier = 2 },
    [3] = { name = "Gnol Baraz", zone = "Black Fire Pass", pairing = "Dwarf/Greenskin", tier = 3 },
    [4] = { name = "Thickmuck Pit", zone = "The Badlands", pairing = "Dwarf/Greenskin", tier = 3, aliases = { "Thickmut Pit", "Badlands Thickmuck Pit" } },
    [5] = { name = "Karaz Drengi", zone = "Kadrin Valley", pairing = "Dwarf/Greenskin", tier = 4 },
    [6] = { name = "Kazad Dammaz", zone = "Kadrin Valley", pairing = "Dwarf/Greenskin", tier = 4 },
    [7] = { name = "Bloodfist Rock", zone = "Thunder Mountain", pairing = "Dwarf/Greenskin", tier = 4 },
    [8] = { name = "Karak Karag", zone = "Thunder Mountain", pairing = "Dwarf/Greenskin", tier = 4 },
    [9] = { name = "Ironskin Skar", zone = "Black Crag", pairing = "Dwarf/Greenskin", tier = 4, aliases = { "Ironskin Scar" } },
    [10] = { name = "Badmoon Hole", zone = "Black Crag", pairing = "Dwarf/Greenskin", tier = 4 },
    [11] = { name = "Mandred's Hold", zone = "Ostland", pairing = "Empire/Chaos", tier = 2 },
    [12] = { name = "Stonetroll Keep", zone = "Troll Country", pairing = "Empire/Chaos", tier = 2 },
    [13] = { name = "Passwatch Castle", zone = "Talabecland", pairing = "Empire/Chaos", tier = 3 },
    [14] = { name = "Stoneclaw Castle", zone = "High Pass", pairing = "Empire/Chaos", tier = 3 },
    [15] = { name = "Wilhelm's Fist", zone = "Reikland", pairing = "Empire/Chaos", tier = 4 },
    [16] = { name = "Morr's Repose", zone = "Reikland", pairing = "Empire/Chaos", tier = 4 },
    [17] = { name = "Southern Garrison", zone = "Praag", pairing = "Empire/Chaos", tier = 4 },
    [18] = { name = "Garrison of Skulls", zone = "Praag", pairing = "Empire/Chaos", tier = 4 },
    [19] = { name = "Zimmeron's Hold", zone = "Chaos Wastes", pairing = "Empire/Chaos", tier = 4 },
    [20] = { name = "Charon's Keep", zone = "Chaos Wastes", pairing = "Empire/Chaos", tier = 4, aliases = { "Charon's Citadel", "Charons Citadel" } },
    [21] = { name = "Cascades of Thunder", zone = "Ellyrion", pairing = "High Elf/Dark Elf", tier = 2 },
    [22] = { name = "Spite's Reach", zone = "The Shadowlands", pairing = "High Elf/Dark Elf", tier = 2, aliases = { "Spites Reach", "Shadowlands Spite's Reach" } },
    [23] = { name = "The Well of Qhaysh", zone = "Saphery", pairing = "High Elf/Dark Elf", tier = 3, aliases = { "Well of Qhaysh" } },
    [24] = { name = "Ghrond's Sacristy", zone = "Avelorn", pairing = "High Elf/Dark Elf", tier = 3 },
    [25] = { name = "Arbor of Light", zone = "Eataine", pairing = "High Elf/Dark Elf", tier = 4 },
    [26] = { name = "Pillars of Remembrance", zone = "Eataine", pairing = "High Elf/Dark Elf", tier = 4 },
    [27] = { name = "Covenant of Flame", zone = "Dragonwake", pairing = "High Elf/Dark Elf", tier = 4 },
    [28] = { name = "Drakebreaker's Scourge", zone = "Dragonwake", pairing = "High Elf/Dark Elf", tier = 4 },
    [29] = { name = "Hatred's Way", zone = "Caledor", pairing = "High Elf/Dark Elf", tier = 4 },
    [30] = { name = "Wrath's Resolve", zone = "Caledor", pairing = "High Elf/Dark Elf", tier = 4 },
}

function addCanonicalKeepLookupAlias(lookup, id, value)
    if type(lookup) ~= "table" or id == nil then
        return
    end

    local key = normalizeKeepKey(value)
    local loose = normalizeKeepLooseKey(value)
    local base = normalizeKeepBaseKey(value)
    if key ~= "" then lookup[key] = id end
    if loose ~= "" then lookup[loose] = id end
    if base ~= "" then lookup[base] = id end
end

function buildCanonicalKeepLookup()
    if type(KST._canonicalKeepLookup) == "table" then
        return KST._canonicalKeepLookup
    end

    local lookup = {}
    for id, info in pairs(KST.CANONICAL_KEEPS or {}) do
        addCanonicalKeepLookupAlias(lookup, id, info.name)
        if type(info.aliases) == "table" then
            for _, alias in ipairs(info.aliases) do
                addCanonicalKeepLookupAlias(lookup, id, alias)
            end
        end
    end

    KST._canonicalKeepLookup = lookup
    return lookup
end

function getCanonicalKeepIdFromName(value)
    local lookup = buildCanonicalKeepLookup()
    local key = normalizeKeepKey(value)
    local loose = normalizeKeepLooseKey(value)
    local base = normalizeKeepBaseKey(value)
    return lookup[key] or lookup[loose] or lookup[base]
end

function getCanonicalKeepIdForKeep(keepData, keepName)
    local keepId = tonumber(type(keepData) == "table" and keepData.ID or keepData)
    if keepId ~= nil and type(KST.CANONICAL_KEEPS) == "table" and KST.CANONICAL_KEEPS[keepId] ~= nil then
        return keepId
    end

    return getCanonicalKeepIdFromName(keepName)
end

function getCanonicalKeepInfo(value)
    local id = tonumber(value)
    if id == nil then
        id = getCanonicalKeepIdFromName(value)
    end
    if id == nil then
        return nil, nil
    end
    return KST.CANONICAL_KEEPS[id], id
end

function registerKeepUpgradeStoreAlias(store, value)
    if type(store) ~= "table" then
        return
    end

    local key = normalizeKeepKey(value)
    local loose = normalizeKeepLooseKey(value)
    if type(store.aliases) ~= "table" then
        store.aliases = {}
    end
    if key ~= "" then
        store.aliases[key] = true
        store.normalizedKeepKey = store.normalizedKeepKey or key
    end
    if loose ~= "" then
        store.aliases[loose] = true
        store.looseKeepKey = store.looseKeepKey or loose
    end

    local base = normalizeKeepBaseKey(value)
    if base ~= "" then
        store.aliases[base] = true
        store.baseKeepKey = store.baseKeepKey or base
    end

    local canonicalId = getCanonicalKeepIdFromName(value)
    local canonicalInfo = canonicalId ~= nil and KST.CANONICAL_KEEPS[canonicalId] or nil
    if canonicalId ~= nil and type(canonicalInfo) == "table" then
        store.canonicalKeepId = canonicalId
        store.canonicalKeepName = canonicalInfo.name
        store.canonicalZoneName = canonicalInfo.zone
        addCanonicalKeepLookupAlias(store.aliases, true, canonicalInfo.name)
        if type(canonicalInfo.aliases) == "table" then
            for _, alias in ipairs(canonicalInfo.aliases) do
                addCanonicalKeepLookupAlias(store.aliases, true, alias)
            end
        end
    end
end

function findVisibleKeepForUpgradeName(keepName)
    local loose = normalizeKeepLooseKey(keepName)
    if loose == "" then
        return nil
    end

    local wantedCanonical = getCanonicalKeepIdFromName(keepName)
    local zones = getOpenZoneIds()
    for _, zoneId in ipairs(zones) do
        local keeps = getKeepsForZone(zoneId)
        if type(keeps) == "table" then
            for keepIndex = 1, 2 do
                local keepData = type(keeps[keepIndex]) == "table" and keeps[keepIndex] or nil
                local keepId = tonumber(keepData and keepData.ID)
                local currentName = getKeepNameText(keepId, keepIndex)
                local currentCanonical = getCanonicalKeepIdForKeep(keepData, currentName)
                local currentLoose = normalizeKeepLooseKey(currentName)
                local currentBase = normalizeKeepBaseKey(currentName)
                local wantedBase = normalizeKeepBaseKey(keepName)
                if (wantedCanonical ~= nil and currentCanonical ~= nil and wantedCanonical == currentCanonical) or currentLoose == loose or (wantedBase ~= "" and currentBase ~= "" and currentBase == wantedBase) then
                    return tonumber(zoneId), keepIndex, keepData, currentName
                end
            end
        end
    end

    return nil
end

KST.KEEP_UPGRADE_DURATIONS = KST.KEEP_UPGRADE_DURATIONS or {
    ["Door Hitpoints"] = { [1] = 5 * 60, [2] = 10 * 60 },
    ["Improved Respawns"] = { [1] = 5 * 60, [2] = 5 * 60, [3] = 10 * 60 },
    ["Banker"] = { [1] = 5 * 60 },
    ["Healing Ritualist"] = { [1] = 5 * 60 },
    ["Divine Favor Altar"] = { [1] = 5 * 60 },
    ["Healer"] = { [1] = 5 * 60 },
    ["Guild Vault Keeper"] = { [1] = 5 * 60 },
    ["Guild Flight Master"] = { [1] = 5 * 60 },
    ["Static Guards"] = { [1] = 5 * 60 },
    ["Lifetap Ritualist"] = { [1] = 5 * 60 },
    ["Oil Control"] = { [0] = 2 * 60, [1] = 2 * 60, [2] = 3 * 60 },
}

KST.KEEP_UPGRADE_SPECIALS = KST.KEEP_UPGRADE_SPECIALS or {
    ["Divine Favor Altar"] = {
        [1] = {
            buildDuration = 5 * 60,
            firstChargeDelay = 15 * 60,
            rechargeInterval = 15 * 60,
            maxCharges = 3,
        },
    },
}

local function tableHasAnyEntry(value)
    if type(value) ~= "table" then
        return false
    end

    for _, _ in pairs(value) do
        return true
    end

    return false
end

local function scrubRestoredKeepUpgradeBindings()
    if type(KST._keepUpgrades) ~= "table" then
        return
    end

    -- keepId/zoneId/keepIndex are runtime SoR bindings. They can be stale after
    -- /reload. Matching restored upgrades by exact/base keep name is safer and
    -- prevents a stale id from hiding a valid saved upgrade.
    for _, store in pairs(KST._keepUpgrades) do
        if type(store) == "table" then
            store.keepId = nil
            store.zoneId = nil
            store.keepIndex = nil
        end
    end
end


function normalizeRestoredBuiltUpgradeRecords()
    if type(KST._keepUpgrades) ~= "table" then
        return false
    end

    local changed = false
    for _, store in pairs(KST._keepUpgrades) do
        if type(store) == "table" and type(store.upgrades) == "table" then
            for _, record in pairs(store.upgrades) do
                if type(record) == "table" then
                    -- Old builds represented already-built normal upgrades as
                    -- state="building" with durationSeconds=0 and buildEndsAt
                    -- equal to the previous session time. After /reload the
                    -- session clock resets, so those records looked like active
                    -- construction timers or could disappear from the visible set.
                    if record.name ~= "Divine Favor Altar" and record.state == "building" and tonumber(record.durationSeconds) == 0 then
                        record.state = "built"
                        record.buildEndsAtSessionSeconds = nil
                        record.buildEndsEpoch = nil
                        record.buildEndsAt = nil
                        changed = true
                    end

                    if record.name ~= "Divine Favor Altar" and record.state == "detected" and tonumber(record.durationSeconds) == 0 then
                        record.state = "built"
                        changed = true
                    end

                    if record.name == "Divine Favor Altar" and tonumber(record.divineManualCharges) ~= nil then
                        record.state = "building"
                        record.durationSeconds = 0
                        record.divineChargesUnknown = nil
                        record.divineBadEstimate = nil
                        changed = true
                    end
                end
            end
        end
    end

    return changed
end


function rebuildKeepUpgradeStoreAliases(store)
    if type(store) ~= "table" then
        return
    end

    if type(store.aliases) ~= "table" then
        store.aliases = {}
    end

    registerKeepUpgradeStoreAlias(store, store.keepName)
    registerKeepUpgradeStoreAlias(store, store.currentKeepName)
    registerKeepUpgradeStoreAlias(store, store.canonicalKeepName)

    if tonumber(store.canonicalKeepId) ~= nil and type(KST.CANONICAL_KEEPS) == "table" then
        local info = KST.CANONICAL_KEEPS[tonumber(store.canonicalKeepId)]
        if type(info) == "table" then
            store.canonicalKeepName = store.canonicalKeepName or info.name
            store.canonicalZoneName = store.canonicalZoneName or info.zone
            registerKeepUpgradeStoreAlias(store, info.name)
            if type(info.aliases) == "table" then
                for _, alias in ipairs(info.aliases) do
                    registerKeepUpgradeStoreAlias(store, alias)
                end
            end
        end
    end
end

function rebuildAllKeepUpgradeAliases()
    if type(KST._keepUpgrades) ~= "table" then
        return
    end
    for _, store in pairs(KST._keepUpgrades) do
        rebuildKeepUpgradeStoreAliases(store)
    end
end

function buildKeepUpgradesFlatBackup()
    local flat = {}
    if type(KST._keepUpgrades) ~= "table" then
        return flat
    end

    for key, store in pairs(KST._keepUpgrades) do
        if type(store) == "table" and type(store.upgrades) == "table" then
            local outStore = {
                key = toString(key),
                keepName = store.keepName,
                currentKeepName = store.currentKeepName,
                canonicalKeepId = store.canonicalKeepId,
                canonicalKeepName = store.canonicalKeepName,
                canonicalZoneName = store.canonicalZoneName,
                claim = store.claim,
                owner = store.owner,
                lastUpdateAt = store.lastUpdateAt,
                lastUpdateSessionSeconds = store.lastUpdateSessionSeconds,
                lastUpdateEpoch = store.lastUpdateEpoch,
                upgrades = {},
            }

            for upgradeKey, record in pairs(store.upgrades) do
                if type(record) == "table" then
                    local copy = {}
                    for field, value in pairs(record) do
                        if type(value) ~= "function" and type(value) ~= "userdata" and type(value) ~= "thread" then
                            copy[field] = value
                        end
                    end
                    copy._backupUpgradeKey = toString(upgradeKey)
                    outStore.upgrades[#outStore.upgrades + 1] = copy
                end
            end

            if #outStore.upgrades > 0 then
                flat[#flat + 1] = outStore
            end
        end
    end

    return flat
end

function restoreKeepUpgradesFromFlatBackup(flat)
    if type(flat) ~= "table" or #flat == 0 then
        return false
    end

    local restored = {}
    for _, sourceStore in ipairs(flat) do
        if type(sourceStore) == "table" then
            local key = normalizeKeepKey(sourceStore.keepName or sourceStore.canonicalKeepName or sourceStore.currentKeepName or sourceStore.key)
            if key ~= "" then
                local store = {
                    keepName = sourceStore.keepName or sourceStore.canonicalKeepName or sourceStore.currentKeepName,
                    currentKeepName = sourceStore.currentKeepName,
                    canonicalKeepId = tonumber(sourceStore.canonicalKeepId),
                    canonicalKeepName = sourceStore.canonicalKeepName,
                    canonicalZoneName = sourceStore.canonicalZoneName,
                    claim = sourceStore.claim,
                    owner = sourceStore.owner,
                    lastUpdateAt = sourceStore.lastUpdateAt,
                    lastUpdateSessionSeconds = sourceStore.lastUpdateSessionSeconds,
                    lastUpdateEpoch = sourceStore.lastUpdateEpoch,
                    upgrades = {},
                    aliases = {},
                }

                if type(sourceStore.upgrades) == "table" then
                    for _, record in ipairs(sourceStore.upgrades) do
                        if type(record) == "table" then
                            local upgradeKey = toString(record._backupUpgradeKey)
                            if upgradeKey == "" then
                                upgradeKey = string.lower(toString(record.name)) .. ":" .. tostring(record.rank or "?")
                            end
                            record._backupUpgradeKey = nil
                            store.upgrades[upgradeKey] = record
                        end
                    end
                end

                rebuildKeepUpgradeStoreAliases(store)
                restored[key] = store
            end
        end
    end

    if tableHasAnyEntry(restored) then
        KST._keepUpgrades = restored
        return true
    end
    return false
end


function KST.GetDivineFavorPersistKey(record, store)
    if type(store) == "table" and tonumber(store.canonicalKeepId) ~= nil then
        return "id:" .. tostring(tonumber(store.canonicalKeepId))
    end
    if type(record) == "table" and tonumber(record.canonicalKeepId) ~= nil then
        return "id:" .. tostring(tonumber(record.canonicalKeepId))
    end

    local name = ""
    if type(record) == "table" then
        name = record.keepName or record.canonicalKeepName or record.currentKeepName or ""
    end
    if name == "" and type(store) == "table" then
        name = store.keepName or store.canonicalKeepName or store.currentKeepName or ""
    end

    local normalized = normalizeKeepKey(name)
    if normalized ~= "" then
        return "name:" .. normalized
    end

    return nil
end

function KST.SaveDivineFavorChargeSnapshot(record, store, reason)
    if type(record) ~= "table" or type(store) ~= "table" or record.name ~= "Divine Favor Altar" then
        return false
    end

    local key = KST.GetDivineFavorPersistKey(record, store)
    if key == nil or key == "" then
        return false
    end

    KeepSupplyTimerSettings = KeepSupplyTimerSettings or {}
    KeepSupplyTimerUpgradeState = KeepSupplyTimerUpgradeState or {}
    KeepSupplyTimerSettings.divineFavorChargeState = KeepSupplyTimerSettings.divineFavorChargeState or {}
    KeepSupplyTimerUpgradeState.divineFavorChargeState = KeepSupplyTimerUpgradeState.divineFavorChargeState or {}

    local nowSession = math.floor(tonumber(KST._clock) or 0)
    local nowEpoch = getRealEpochSeconds()
    local nextEpoch = tonumber(record.divineNextChargeEpoch)
    local nextSession = tonumber(record.divineNextChargeAtSessionSeconds)
    if nextEpoch == nil and nowEpoch ~= nil and nextSession ~= nil then
        local remainingFromSession = nextSession - nowSession
        if remainingFromSession > 0 then
            nextEpoch = nowEpoch + remainingFromSession
        end
    end

    local firstEpoch = tonumber(record.firstChargeEpoch)
    local firstSession = tonumber(record.firstChargeAtSessionSeconds)
    if firstEpoch == nil and nowEpoch ~= nil and firstSession ~= nil then
        local remainingFirst = firstSession - nowSession
        if remainingFirst > 0 then
            firstEpoch = nowEpoch + remainingFirst
        end
    end

    local snapshot = {
        key = key,
        keepName = toString(record.keepName or store.keepName),
        canonicalKeepId = store.canonicalKeepId,
        canonicalKeepName = store.canonicalKeepName,
        canonicalZoneName = store.canonicalZoneName,
        charges = tonumber(record.divineManualCharges),
        maxCharges = tonumber(record.maxCharges) or 3,
        rechargeIntervalSeconds = tonumber(record.rechargeIntervalSeconds) or (15 * 60),
        divineNextChargeAt = getEndTimeText(nextEpoch, nextSession),
        divineNextChargeEpoch = nextEpoch,
        divineNextChargeAtSessionSeconds = nextSession,
        firstChargeEpoch = firstEpoch,
        firstChargeAtSessionSeconds = firstSession,
        savedAt = getEventTimeText(),
        savedEpoch = nowEpoch,
        savedSessionSeconds = nowSession,
        reason = toString(reason),
    }

    KeepSupplyTimerSettings.divineFavorChargeState[key] = snapshot
    KeepSupplyTimerUpgradeState.divineFavorChargeState[key] = snapshot

    KST.SafeAppendFileLogControlLine("[KST_DIVINE_SNAPSHOT_SAVE] key=" .. toString(key) .. " keep=" .. toString(snapshot.keepName) .. " charges=" .. tostring(snapshot.charges) .. "/" .. tostring(snapshot.maxCharges) .. " nextEpoch=" .. tostring(snapshot.divineNextChargeEpoch) .. " reason=" .. toString(reason))
    return true
end

function KST.FindDivineFavorChargeSnapshot(record, store)
    KeepSupplyTimerSettings = KeepSupplyTimerSettings or {}
    KeepSupplyTimerUpgradeState = KeepSupplyTimerUpgradeState or {}

    local candidates = {}
    local key = KST.GetDivineFavorPersistKey(record, store)
    if key ~= nil and key ~= "" then
        candidates[#candidates + 1] = key
    end

    local name = ""
    if type(record) == "table" then
        name = record.keepName or record.canonicalKeepName or record.currentKeepName or ""
    end
    if name == "" and type(store) == "table" then
        name = store.keepName or store.canonicalKeepName or store.currentKeepName or ""
    end
    local normalized = normalizeKeepKey(name)
    if normalized ~= "" then
        candidates[#candidates + 1] = "name:" .. normalized
    end
    if type(store) == "table" and tonumber(store.canonicalKeepId) ~= nil then
        candidates[#candidates + 1] = "id:" .. tostring(tonumber(store.canonicalKeepId))
    end

    local sources = {
        KeepSupplyTimerSettings.divineFavorChargeState,
        KeepSupplyTimerUpgradeState.divineFavorChargeState,
    }

    for _, source in ipairs(sources) do
        if type(source) == "table" then
            for _, candidate in ipairs(candidates) do
                local snapshot = source[candidate]
                if type(snapshot) == "table" then
                    return snapshot, candidate
                end
            end
        end
    end

    return nil, nil
end

function KST.ApplyDivineFavorChargeSnapshot(record, store, reason)
    if type(record) ~= "table" or type(store) ~= "table" or record.name ~= "Divine Favor Altar" then
        return false
    end

    local snapshot, key = KST.FindDivineFavorChargeSnapshot(record, store)
    if type(snapshot) ~= "table" or tonumber(snapshot.charges) == nil then
        return false
    end

    local nowSession = math.floor(tonumber(KST._clock) or 0)
    local nowEpoch = getRealEpochSeconds()

    record.state = "building"
    record.durationSeconds = 0
    record.buildEndsAtSessionSeconds = nowSession
    record.buildEndsEpoch = nowEpoch
    record.buildEndsAt = getEndTimeText(record.buildEndsEpoch, record.buildEndsAtSessionSeconds)
    record.firstChargeDelaySeconds = 0
    record.firstChargeAtSessionSeconds = nowSession
    record.firstChargeEpoch = nowEpoch
    record.firstChargeAt = getEndTimeText(record.firstChargeEpoch, record.firstChargeAtSessionSeconds)
    record.rechargeIntervalSeconds = tonumber(snapshot.rechargeIntervalSeconds) or tonumber(record.rechargeIntervalSeconds) or (15 * 60)
    record.maxCharges = tonumber(snapshot.maxCharges) or tonumber(record.maxCharges) or 3
    record.divineManualCharges = tonumber(snapshot.charges)
    local targetEpoch = tonumber(snapshot.divineNextChargeEpoch)
    local targetSession = tonumber(snapshot.divineNextChargeAtSessionSeconds)

    -- Preferred path: absolute end epoch. This is the only reliable reference
    -- across /reload or full game restart.
    if targetEpoch ~= nil and nowEpoch ~= nil then
        local remaining = targetEpoch - nowEpoch
        if remaining <= 0 then
            targetSession = nowSession
        else
            targetSession = nowSession + remaining
        end
    elseif targetEpoch == nil and nowEpoch ~= nil and tonumber(snapshot.savedEpoch) ~= nil and tonumber(snapshot.divineNextChargeAtSessionSeconds) ~= nil and tonumber(snapshot.savedSessionSeconds) ~= nil then
        -- Migration path for old snapshots: reconstruct absolute end epoch from
        -- saved epoch + remaining-at-save.
        local savedDelta = tonumber(snapshot.divineNextChargeAtSessionSeconds) - tonumber(snapshot.savedSessionSeconds)
        if savedDelta ~= nil and savedDelta > 0 then
            targetEpoch = tonumber(snapshot.savedEpoch) + savedDelta
            local remaining = targetEpoch - nowEpoch
            targetSession = nowSession + math.max(0, remaining)
        end
    elseif targetEpoch == nil and tonumber(snapshot.divineNextChargeAtSessionSeconds) ~= nil and tonumber(snapshot.savedSessionSeconds) ~= nil then
        -- Last-resort session-only fallback. This cannot advance while the game
        -- is closed, so log it explicitly.
        local savedDelta = tonumber(snapshot.divineNextChargeAtSessionSeconds) - tonumber(snapshot.savedSessionSeconds)
        if savedDelta ~= nil and savedDelta > 0 then
            targetSession = nowSession + savedDelta
            KST.SafeAppendFileLogControlLine("[KST_TIME_WARNING] applying Divine Favor timer from session-only snapshot; offline time cannot be subtracted")
        end
    end

    record.divineNextChargeEpoch = targetEpoch
    record.divineNextChargeAtSessionSeconds = targetSession
    record.divineNextChargeAt = getEndTimeText(record.divineNextChargeEpoch, record.divineNextChargeAtSessionSeconds)
    record.divineChargesUnknown = nil
    record.divineBadEstimate = nil
    record.divineSnapshotAppliedAt = getEventTimeText()
    record.divineSnapshotAppliedReason = toString(reason)

    KST.SafeAppendFileLogControlLine("[KST_DIVINE_SNAPSHOT_APPLY] key=" .. toString(key) .. " keep=" .. toString(record.keepName or store.keepName) .. " charges=" .. tostring(record.divineManualCharges) .. "/" .. tostring(record.maxCharges) .. " nextEpoch=" .. tostring(record.divineNextChargeEpoch) .. " reason=" .. toString(reason))
    return true
end

function KST.ApplyDivineFavorSnapshotsToAllStores(reason)
    if type(KST._keepUpgrades) ~= "table" then
        return false
    end

    local changed = false
    for _, store in pairs(KST._keepUpgrades) do
        if type(store) == "table" and type(store.upgrades) == "table" then
            for _, record in pairs(store.upgrades) do
                if type(record) == "table" and record.name == "Divine Favor Altar" then
                    if KST.ApplyDivineFavorChargeSnapshot(record, store, reason) then
                        changed = true
                    end
                end
            end
        end
    end

    return changed
end

local function persistKeepUpgrades(reason)
    if KST.PERSIST_KEEP_UPGRADES ~= true then
        return
    end

    KeepSupplyTimerUpgradeState = KeepSupplyTimerUpgradeState or {}
    KeepSupplyTimerSettings = KeepSupplyTimerSettings or {}

    local upgrades = KST._keepUpgrades or {}

    KeepSupplyTimerUpgradeState.version = KST.VERSION
    KeepSupplyTimerUpgradeState.keepUpgrades = upgrades
    KeepSupplyTimerUpgradeState.savedAt = getEventTimeText()
    KeepSupplyTimerUpgradeState.savedEpoch = getRealEpochSeconds()
    KeepSupplyTimerUpgradeState.savedSessionSeconds = math.floor(tonumber(KST._clock) or 0)
    KeepSupplyTimerUpgradeState.reason = reason or "update"

    -- Secondary backup. Some clients are more reliable with the main settings
    -- SavedVariable than with an additional custom state table during /reload.
    KeepSupplyTimerSettings.keepUpgradesBackup = upgrades
    KeepSupplyTimerSettings.keepUpgradesBackupSavedAt = KeepSupplyTimerUpgradeState.savedAt
    KeepSupplyTimerSettings.keepUpgradesBackupSavedEpoch = KeepSupplyTimerUpgradeState.savedEpoch
    KeepSupplyTimerSettings.keepUpgradesBackupReason = reason or "update"
    local flatBackup = buildKeepUpgradesFlatBackup()
    KeepSupplyTimerSettings.keepUpgradesFlatBackup = flatBackup
    KeepSupplyTimerSettings.keepUpgradesFlatBackupSavedAt = KeepSupplyTimerUpgradeState.savedAt
    KeepSupplyTimerSettings.keepUpgradesFlatBackupSavedEpoch = KeepSupplyTimerUpgradeState.savedEpoch

    -- Also keep the flat backup in the dedicated SavedVariable table. In RoR
    -- this is safer than relying only on nested live tables with runtime aliases.
    KeepSupplyTimerUpgradeState.keepUpgradesFlatBackup = flatBackup
    KeepSupplyTimerUpgradeState.keepUpgradesFlatBackupSavedAt = KeepSupplyTimerUpgradeState.savedAt
    KeepSupplyTimerUpgradeState.keepUpgradesFlatBackupSavedEpoch = KeepSupplyTimerUpgradeState.savedEpoch

    -- Refresh separate Divine Favor charge snapshots whenever we persist the
    -- general upgrade state, so charge counts survive even if the live upgrade
    -- table is restored from an older source.
    if type(upgrades) == "table" then
        for _, store in pairs(upgrades) do
            if type(store) == "table" and type(store.upgrades) == "table" then
                for _, record in pairs(store.upgrades) do
                    if type(record) == "table" and record.name == "Divine Favor Altar" and tonumber(record.divineManualCharges) ~= nil then
                        KST.SaveDivineFavorChargeSnapshot(record, store, reason or "persist")
                    end
                end
            end
        end
    end
end

local function restoreKeepUpgradesFromSavedVariables()
    KeepSupplyTimerUpgradeState = KeepSupplyTimerUpgradeState or {}
    KeepSupplyTimerSettings = KeepSupplyTimerSettings or {}

    local primary = KeepSupplyTimerUpgradeState.keepUpgrades
    local backup = KeepSupplyTimerSettings.keepUpgradesBackup
    local flatSettings = KeepSupplyTimerSettings.keepUpgradesFlatBackup
    local flatState = KeepSupplyTimerUpgradeState.keepUpgradesFlatBackup
    local restoredFromFlat = false

    -- Prefer the flat backup first. It is a serialization-safe snapshot and
    -- preserves Divine Favor charge fields more reliably across /reload than
    -- the live nested table with runtime aliases.
    if restoreKeepUpgradesFromFlatBackup(flatSettings) then
        restoredFromFlat = true
    elseif restoreKeepUpgradesFromFlatBackup(flatState) then
        restoredFromFlat = true
    elseif tableHasAnyEntry(primary) then
        KST._keepUpgrades = primary
    elseif tableHasAnyEntry(backup) then
        KST._keepUpgrades = backup
    elseif type(KST._keepUpgrades) ~= "table" then
        KST._keepUpgrades = {}
    end

    scrubRestoredKeepUpgradeBindings()
    local normalizedBuiltRecords = normalizeRestoredBuiltUpgradeRecords()
    rebuildAllKeepUpgradeAliases()
    local restoredDivineSnapshots = KST.ApplyDivineFavorSnapshotsToAllStores("restore")

    -- Re-save into both SavedVariables after choosing the best available source,
    -- but do not replace non-empty data with an empty table during startup.
    if tableHasAnyEntry(KST._keepUpgrades) then
        if restoredDivineSnapshots == true then
            persistKeepUpgrades("restore-divine-snapshot")
        elseif normalizedBuiltRecords == true then
            persistKeepUpgrades("restore-normalized-built")
        else
            persistKeepUpgrades("restore")
        end
    end
end

local function getUpgradeDurationSeconds(upgradeName, rank)
    local name = toString(upgradeName)
    local rankNumber = tonumber(rank)
    local special = KST.KEEP_UPGRADE_SPECIALS[name]
    if type(special) == "table" and type(special[rankNumber]) == "table" and tonumber(special[rankNumber].buildDuration) ~= nil then
        return tonumber(special[rankNumber].buildDuration)
    end

    local byRank = KST.KEEP_UPGRADE_DURATIONS[name]
    if type(byRank) == "table" then
        local duration = tonumber(byRank[rankNumber])
        if duration == nil and rankNumber == 0 then
            duration = tonumber(byRank[1])
        end
        return duration
    end

    return nil
end

local function getUpgradeSpecialInfo(upgradeName, rank)
    local special = KST.KEEP_UPGRADE_SPECIALS[toString(upgradeName)]
    if type(special) ~= "table" then
        return nil
    end

    return special[tonumber(rank)]
end

local function getSessionTimeText(seconds)
    local value = tonumber(seconds)
    if value == nil then
        return nil
    end
    return "session+" .. formatElapsed(value)
end

local function ensureKeepUpgradeStore(keepName)
    local key = normalizeKeepKey(keepName)
    if key == "" then
        return nil, nil
    end

    if type(KST._keepUpgrades) ~= "table" then
        KST._keepUpgrades = {}
    end

    if type(KST._keepUpgrades[key]) ~= "table" then
        KST._keepUpgrades[key] = {
            keepName = toString(keepName),
            upgrades = {},
            aliases = {},
            lastUpdateAt = nil,
            lastUpdateSessionSeconds = nil,
        }
    end

    local store = KST._keepUpgrades[key]
    if type(store.upgrades) ~= "table" then
        store.upgrades = {}
    end
    registerKeepUpgradeStoreAlias(store, keepName)

    -- If the keep is currently visible in SoR, bind the parsed chat name to the
    -- concrete SoR keep too. This fixes cases where chat and GetKeepName use
    -- slightly different punctuation/localisation, so the upgrade was detected
    -- but the keep tooltip could not find it.
    local zoneId, keepIndex, keepData, currentName = findVisibleKeepForUpgradeName(keepName)
    if zoneId ~= nil and keepIndex ~= nil then
        store.zoneId = zoneId
        store.keepIndex = keepIndex
        store.keepId = tonumber(keepData and keepData.ID) or store.keepId
        store.owner = tonumber(keepData and keepData.Owner) or store.owner
        store.claim = getKeepClaimText(keepData)
        store.currentKeepName = currentName
        local canonicalId = getCanonicalKeepIdForKeep(keepData, currentName)
        if canonicalId ~= nil then
            local canonicalInfo = KST.CANONICAL_KEEPS[canonicalId]
            store.canonicalKeepId = canonicalId
            if type(canonicalInfo) == "table" then
                store.canonicalKeepName = canonicalInfo.name
                store.canonicalZoneName = canonicalInfo.zone
            end
        end
        registerKeepUpgradeStoreAlias(store, currentName)
    end

    return store, key
end

function storeMatchesKeep(store, key, loose, keepId, zoneId, keepIndex)
    if type(store) ~= "table" then
        return false
    end

    local currentKeepId = tonumber(keepId)
    local storeKeepId = tonumber(store.keepId)
    local currentCanonical = nil
    if currentKeepId ~= nil and type(KST.CANONICAL_KEEPS) == "table" and KST.CANONICAL_KEEPS[currentKeepId] ~= nil then
        currentCanonical = currentKeepId
    else
        currentCanonical = getCanonicalKeepIdFromName(key)
    end
    local storeCanonical = tonumber(store.canonicalKeepId) or getCanonicalKeepIdFromName(store.keepName)
    if currentCanonical ~= nil and storeCanonical ~= nil then
        return currentCanonical == storeCanonical
    end
    if currentKeepId ~= nil and storeKeepId ~= nil and currentKeepId == storeKeepId then
        return true
    end

    local currentLoose = toString(loose)
    local storeNameLoose = normalizeKeepLooseKey(store.keepName)
    if currentLoose ~= "" and storeNameLoose ~= "" and currentLoose == storeNameLoose then
        return true
    end

    local currentBase = normalizeKeepBaseKey(key)
    local storeBase = normalizeKeepBaseKey(store.keepName)
    if currentBase ~= "" and storeBase ~= "" and currentBase == storeBase then
        return true
    end

    -- Alias matching is exact after normalization. Base alias handles Charon's
    -- Citadel vs Charon's Keep. No substring matching and no global fallback.
    if type(store.aliases) == "table" then
        if key ~= "" and store.aliases[key] == true then
            return true
        end
        if currentLoose ~= "" and store.aliases[currentLoose] == true then
            return true
        end
        if currentBase ~= "" and store.aliases[currentBase] == true then
            return true
        end
    end

    -- Runtime zone+keepIndex is only a last safe option when we do not have any
    -- keepId for the current keep. Restored stores have these fields scrubbed.
    if currentKeepId == nil and zoneId ~= nil and keepIndex ~= nil and tonumber(store.zoneId) == tonumber(zoneId) and tonumber(store.keepIndex) == tonumber(keepIndex) then
        return true
    end

    return false
end

local function getKeepUpgradeStore(keepName, keepData, zoneId, keepIndex)
    local key = normalizeKeepKey(keepName)
    local loose = normalizeKeepLooseKey(keepName)
    if key == "" or type(KST._keepUpgrades) ~= "table" then
        return nil
    end

    local exact = KST._keepUpgrades[key]
    if type(exact) == "table" then
        return exact
    end

    local keepId = tonumber(type(keepData) == "table" and keepData.ID or keepData)
    local matchedStore = nil
    local matchedCount = 0
    local totalStore = nil
    local totalCount = 0

    for _, store in pairs(KST._keepUpgrades) do
        if type(store) == "table" and type(store.upgrades) == "table" then
            totalStore = store
            totalCount = totalCount + 1

            if storeMatchesKeep(store, key, loose, keepId, zoneId, keepIndex) then
                matchedStore = store
                matchedCount = matchedCount + 1
            end
        end
    end

    if matchedCount == 1 then
        matchedStore.zoneId = tonumber(zoneId) or matchedStore.zoneId
        matchedStore.keepIndex = tonumber(keepIndex) or matchedStore.keepIndex
        if type(keepData) == "table" then
            matchedStore.keepId = tonumber(keepData.ID) or matchedStore.keepId
            matchedStore.owner = tonumber(keepData.Owner) or matchedStore.owner
        end
        registerKeepUpgradeStoreAlias(matchedStore, keepName)
        return matchedStore
    end

    -- Never show one detected upgrade store on every keep. If the data cannot
    -- be matched to this specific keep, the tooltip must stay empty for it.
    return nil
end

local function sanitizeChatTextForParsing(text)
    local raw = toString(text)
    raw = string.gsub(raw, "\r", " ")
    raw = string.gsub(raw, "\n", " ")
    -- Remove common RoR color/link markup while keeping visible text when possible.
    raw = string.gsub(raw, "|c%x%x%x%x%x%x%x%x", "")
    raw = string.gsub(raw, "|r", "")
    raw = string.gsub(raw, "<LINK[^>]-text=\"([^\"]-)\"[^>]->", "%1")
    raw = string.gsub(raw, "<[^>]->", "")
    -- TextLog entries can include timestamps or channel prefixes before the real chat text.
    raw = string.gsub(raw, "^%s*%[%d%d:%d%d:%d%d%]%s*", "")
    raw = string.gsub(raw, "^%s*%[%d:%d%d:%d%d%]%s*", "")
    raw = string.gsub(raw, "^%s*%[%d%d:%d%d%]%s*", "")
    raw = string.gsub(raw, "^%s*%[%d:%d%d%]%s*", "")
    raw = string.gsub(raw, "^%s*%[[^%]]-%]%s*", "")
    raw = string.gsub(raw, "%s+", " ")
    raw = string.gsub(raw, "^%s+", "")
    raw = string.gsub(raw, "%s+$", "")
    return raw
end

local function parseKeepUpgradePurchaseText(text)
    local raw = sanitizeChatTextForParsing(text)

    local upgradeName, rank, keepName = string.match(raw, "^The%s+(.+)%s+Rank%s+(%d+)%s+keep%s+upgrade%s+has%s+been%s+purchased%s+for%s+(.+)%.%s*$")
    if upgradeName == nil then
        upgradeName, rank, keepName = string.match(raw, "The%s+(.+)%s+Rank%s+(%d+)%s+keep%s+upgrade%s+has%s+been%s+purchased%s+for%s+(.+)%.?")
    end

    if upgradeName == nil or rank == nil or keepName == nil then
        return nil
    end

    upgradeName = string.gsub(upgradeName, "^%s+", "")
    upgradeName = string.gsub(upgradeName, "%s+$", "")
    keepName = string.gsub(keepName, "^%s+", "")
    keepName = string.gsub(keepName, "%s+$", "")
    keepName = string.gsub(keepName, "%.$", "")

    return upgradeName, tonumber(rank), keepName, raw
end

local function parseKeepUpgradeRemovedText(text)
    local raw = sanitizeChatTextForParsing(text)

    local upgradeName, rank, keepName = string.match(raw, "^The%s+(.+)%s+Rank%s+(%d+)%s+keep%s+upgrade%s+has%s+been%s+removed%s+and%s+is%s+no%s+longer%s+available%s+at%s+(.+)%.%s*$")
    if upgradeName == nil then
        upgradeName, rank, keepName = string.match(raw, "The%s+(.+)%s+Rank%s+(%d+)%s+keep%s+upgrade%s+has%s+been%s+removed%s+and%s+is%s+no%s+longer%s+available%s+at%s+(.+)%.?")
    end

    if upgradeName == nil or rank == nil or keepName == nil then
        return nil
    end

    upgradeName = string.gsub(upgradeName, "^%s+", "")
    upgradeName = string.gsub(upgradeName, "%s+$", "")
    keepName = string.gsub(keepName, "^%s+", "")
    keepName = string.gsub(keepName, "%s+$", "")
    keepName = string.gsub(keepName, "%.$", "")

    return upgradeName, tonumber(rank), keepName, raw
end

local function appendKeepUpgradeLog(eventType, keepName, upgradeRecord, rawText)
    if type(upgradeRecord) ~= "table" then
        return nil
    end

    local event = {
        event = eventType or "KEEP_UPGRADE_PURCHASED",
        observedAt = getEventTimeText(),
        sessionSeconds = math.floor(tonumber(KST._clock) or 0),
        keepName = toString(keepName),
        upgradeName = upgradeRecord.name,
        upgradeRank = upgradeRecord.rank,
        upgradeState = upgradeRecord.state,
        upgradeDurationSeconds = upgradeRecord.durationSeconds,
        upgradeStartedAt = upgradeRecord.startedAt,
        upgradeStartedSessionSeconds = upgradeRecord.startedSessionSeconds,
        upgradeStartedEpoch = upgradeRecord.startedEpoch,
        upgradeBuildEndsAt = upgradeRecord.buildEndsAt,
        upgradeBuildEndsAtSessionSeconds = upgradeRecord.buildEndsAtSessionSeconds,
        upgradeBuildEndsEpoch = upgradeRecord.buildEndsEpoch,
        upgradeRemoveEndsAt = upgradeRecord.removeEndsAt,
        upgradeRemoveEndsAtSessionSeconds = upgradeRecord.removeEndsAtSessionSeconds,
        upgradeRemoveEndsEpoch = upgradeRecord.removeEndsEpoch,
        upgradeFirstChargeAt = upgradeRecord.firstChargeAt,
        upgradeFirstChargeAtSessionSeconds = upgradeRecord.firstChargeAtSessionSeconds,
        upgradeFirstChargeEpoch = upgradeRecord.firstChargeEpoch,
        upgradeRechargeIntervalSeconds = upgradeRecord.rechargeIntervalSeconds,
        upgradeMaxCharges = upgradeRecord.maxCharges,
        upgradeDivineManualCharges = upgradeRecord.divineManualCharges,
        upgradeDivineNextChargeAt = upgradeRecord.divineNextChargeAt,
        upgradeDivineNextChargeEpoch = upgradeRecord.divineNextChargeEpoch,
        upgradeDivineNextChargeAtSessionSeconds = upgradeRecord.divineNextChargeAtSessionSeconds,
        upgradeDivineLastUseAt = upgradeRecord.divineLastUseAt,
        upgradeDivineLastBlessedGuild = upgradeRecord.divineLastBlessedGuild,
        upgradeSyncZoneName = upgradeRecord.syncZoneName,
        upgradeSyncReceivedAt = upgradeRecord.syncReceivedAt,
        upgradeSource = upgradeRecord.source,
        rawChatText = rawText,
    }

    appendFileLogLine(event)
    return event
end

local function recordKeepUpgradePurchase(upgradeName, rank, keepName, rawText)
    if upgradeName == nil or rank == nil or keepName == nil then
        return nil
    end

    local dedupeKey = "purchase|" .. normalizeKeepKey(keepName) .. "|" .. toString(upgradeName) .. "|" .. toString(rank)
    local now = tonumber(KST._clock) or 0
    if KST._lastUpgradeChatKey == dedupeKey and tonumber(KST._lastUpgradeChatAt) ~= nil and now - tonumber(KST._lastUpgradeChatAt) < 2 then
        return nil
    end
    KST._lastUpgradeChatKey = dedupeKey
    KST._lastUpgradeChatAt = now

    local store = ensureKeepUpgradeStore(keepName)
    if store == nil then
        return nil
    end

    local duration = getUpgradeDurationSeconds(upgradeName, rank)
    local special = getUpgradeSpecialInfo(upgradeName, rank)
    if type(special) == "table" and tonumber(special.buildDuration) ~= nil then
        duration = tonumber(special.buildDuration)
    end

    local startedSession = math.floor(now)
    local startedEpoch = getRealEpochSeconds()
    local buildEndSession = duration ~= nil and (startedSession + duration) or nil
    local buildEndEpoch = (duration ~= nil and startedEpoch ~= nil) and (startedEpoch + duration) or nil
    local record = {
        name = toString(upgradeName),
        rank = tonumber(rank),
        keepName = toString(keepName),
        state = "building",
        source = "chat",
        rawText = rawText,
        startedAt = getEventTimeText(),
        startedEpoch = startedEpoch,
        startedSessionSeconds = startedSession,
        durationSeconds = duration,
        buildEndsAtSessionSeconds = buildEndSession,
        buildEndsEpoch = buildEndEpoch,
        buildEndsAt = getEndTimeText(buildEndEpoch, buildEndSession),
        lastUpdateAt = getEventTimeText(),
        lastUpdateSessionSeconds = startedSession,
    }

    if type(special) == "table" then
        record.firstChargeDelaySeconds = tonumber(special.firstChargeDelay)
        record.rechargeIntervalSeconds = tonumber(special.rechargeInterval)
        record.maxCharges = tonumber(special.maxCharges)
        if buildEndSession ~= nil and record.firstChargeDelaySeconds ~= nil then
            record.firstChargeAtSessionSeconds = buildEndSession + record.firstChargeDelaySeconds
            if buildEndEpoch ~= nil then
                record.firstChargeEpoch = buildEndEpoch + record.firstChargeDelaySeconds
            end
            record.firstChargeAt = getEndTimeText(record.firstChargeEpoch, record.firstChargeAtSessionSeconds)
        end
    end

    local upgradeKey = string.lower(record.name) .. ":" .. tostring(record.rank or "?")
    store.upgrades[upgradeKey] = record
    store.lastUpdateAt = record.lastUpdateAt
    store.lastUpdateSessionSeconds = record.lastUpdateSessionSeconds
    store.lastUpdateEpoch = startedEpoch

    persistKeepUpgrades("purchase")
    appendKeepUpgradeLog("KEEP_UPGRADE_PURCHASED", keepName, record, rawText)

    if KST.LOG_KEEP_UPGRADES_TO_CHAT then
        chatPrint("Keep upgrade detected: " .. record.keepName .. " - " .. record.name .. " R" .. tostring(record.rank or "?") .. ".")
    end

    return record
end

local function recordKeepUpgradeRemoved(upgradeName, rank, keepName, rawText)
    if upgradeName == nil or rank == nil or keepName == nil then
        return nil
    end

    local dedupeKey = "remove|" .. normalizeKeepKey(keepName) .. "|" .. toString(upgradeName) .. "|" .. toString(rank)
    local now = tonumber(KST._clock) or 0
    if KST._lastUpgradeChatKey == dedupeKey and tonumber(KST._lastUpgradeChatAt) ~= nil and now - tonumber(KST._lastUpgradeChatAt) < 2 then
        return nil
    end
    KST._lastUpgradeChatKey = dedupeKey
    KST._lastUpgradeChatAt = now

    local store = ensureKeepUpgradeStore(keepName)
    if store == nil then
        return nil
    end

    local duration = getUpgradeDurationSeconds(upgradeName, rank)
    local startedSession = math.floor(now)
    local startedEpoch = getRealEpochSeconds()
    local removeEndSession = duration ~= nil and (startedSession + duration) or nil
    local removeEndEpoch = (duration ~= nil and startedEpoch ~= nil) and (startedEpoch + duration) or nil
    local record = {
        name = toString(upgradeName),
        rank = tonumber(rank),
        keepName = toString(keepName),
        state = "removing",
        source = "chat",
        rawText = rawText,
        startedAt = getEventTimeText(),
        startedEpoch = startedEpoch,
        startedSessionSeconds = startedSession,
        durationSeconds = duration,
        removeEndsAtSessionSeconds = removeEndSession,
        removeEndsEpoch = removeEndEpoch,
        removeEndsAt = getEndTimeText(removeEndEpoch, removeEndSession),
        lastUpdateAt = getEventTimeText(),
        lastUpdateSessionSeconds = startedSession,
    }

    local upgradeKey = string.lower(record.name) .. ":" .. tostring(record.rank or "?")
    store.upgrades[upgradeKey] = record
    store.lastUpdateAt = record.lastUpdateAt
    store.lastUpdateSessionSeconds = record.lastUpdateSessionSeconds
    store.lastUpdateEpoch = startedEpoch

    persistKeepUpgrades("remove")
    appendKeepUpgradeLog("KEEP_UPGRADE_REMOVED", keepName, record, rawText)

    if KST.LOG_KEEP_UPGRADES_TO_CHAT then
        chatPrint("Keep upgrade removal detected: " .. record.keepName .. " - " .. record.name .. " R" .. tostring(record.rank or "?") .. ".")
    end

    return record
end


local function parseDivineFavorBlessingText(text)
    local raw = sanitizeChatTextForParsing(text)
    local guildName = string.match(raw, "^Your%s+god%s+has%s+blessed%s+you%s+due%s+the%s+efforts%s+of%s+(.+)%.?%s*$")
    if guildName == nil then
        guildName = string.match(raw, "Your%s+god%s+has%s+blessed%s+you%s+due%s+the%s+efforts%s+of%s+(.+)%.?")
    end
    if guildName == nil then
        guildName = string.match(raw, "^Your%s+god%s+has%s+blessed%s+you%s+due%s+to%s+the%s+efforts%s+of%s+(.+)%.?%s*$")
    end
    if guildName == nil then
        guildName = string.match(raw, "Your%s+god%s+has%s+blessed%s+you%s+due%s+to%s+the%s+efforts%s+of%s+(.+)%.?")
    end
    if guildName == nil then
        return nil
    end

    guildName = string.gsub(guildName, "^%s+", "")
    guildName = string.gsub(guildName, "%s+$", "")
    guildName = string.gsub(guildName, "%.$", "")
    return guildName, raw
end

local function normalizeGuildName(value)
    local text = normalizeKeepKey(value)
    text = string.gsub(text, "^<", "")
    text = string.gsub(text, ">$", "")
    text = string.gsub(text, "[%p%s]+", "")
    return text
end

local getUpgradeStatus

local function getDivineFavorRecordStatusForUse(record)
    local status, remaining, charges, nextChargeAt = getUpgradeStatus(record)
    local maxCharges = tonumber(record and record.maxCharges) or 3
    local chargeCount = tonumber(charges)

    if status == "charged" then
        if chargeCount == nil then
            chargeCount = maxCharges
        end
    elseif status == "charging" then
        chargeCount = 0
    elseif status == "built" then
        chargeCount = maxCharges
    else
        chargeCount = 0
    end

    return status, remaining, chargeCount, maxCharges, nextChargeAt
end

local function findDivineFavorAltarRecordForGuild(guildName)
    local normalizedGuild = normalizeGuildName(guildName)
    local matchedRecord = nil
    local matchedStore = nil
    local matchedCount = 0
    local fallbackRecord = nil
    local fallbackStore = nil
    local fallbackCount = 0

    if type(KST._keepUpgrades) ~= "table" then
        return nil, nil, 0
    end

    for _, store in pairs(KST._keepUpgrades) do
        if type(store) == "table" and type(store.upgrades) == "table" then
            local storeGuild = normalizeGuildName(store.claim)
            for _, record in pairs(store.upgrades) do
                if type(record) == "table" and record.name == "Divine Favor Altar" and record.state ~= "removing" and record.state ~= "removed" then
                    fallbackRecord = record
                    fallbackStore = store
                    fallbackCount = fallbackCount + 1

                    if normalizedGuild ~= "" and storeGuild ~= "" and normalizedGuild == storeGuild then
                        matchedRecord = record
                        matchedStore = store
                        matchedCount = matchedCount + 1
                    end
                end
            end
        end
    end

    if matchedCount == 1 then
        return matchedRecord, matchedStore, matchedCount
    end

    if matchedCount == 0 and fallbackCount == 1 then
        return fallbackRecord, fallbackStore, fallbackCount
    end

    return nil, nil, matchedCount
end

function KST.FindDivineFavorAltarForBuff()
    if type(KST._shareContext) == "table" then
        local record, store = KST.GetDivineFavorRecordForContext(KST._shareContext)
        if type(record) == "table" and type(store) == "table" then
            return record, store, "selected-context"
        end
    end

    if type(KST._lastDivineFavorAltarContext) == "table" then
        local record, store = KST.GetDivineFavorRecordForContext(KST._lastDivineFavorAltarContext)
        if type(record) == "table" and type(store) == "table" then
            return record, store, "last-divine-altar-context"
        end
    end

    local matchedRecord = nil
    local matchedStore = nil
    local matchedCount = 0

    if type(KST._keepUpgrades) ~= "table" then
        return nil, nil, "none"
    end

    for _, store in pairs(KST._keepUpgrades) do
        if type(store) == "table" and type(store.upgrades) == "table" then
            for _, record in pairs(store.upgrades) do
                if type(record) == "table" and record.name == "Divine Favor Altar" and record.state ~= "removing" and record.state ~= "removed" then
                    matchedRecord = record
                    matchedStore = store
                    matchedCount = matchedCount + 1
                end
            end
        end
    end

    if matchedCount == 1 then
        return matchedRecord, matchedStore, "unique-known-altar"
    end

    return nil, nil, "ambiguous-" .. tostring(matchedCount)
end

function KST.RecordDivineFavorChargeUsed(record, store, source, rawText)
    if type(record) ~= "table" or type(store) ~= "table" then
        appendFileLogLine({
            event = "DIVINE_FAVOR_CHARGE_USE_UNMATCHED",
            observedAt = getEventTimeText(),
            sessionSeconds = math.floor(tonumber(KST._clock) or 0),
            source = toString(source),
            rawChatText = rawText,
        })
        return nil
    end

    local status, remaining, charges, maxCharges = getDivineFavorRecordStatusForUse(record)
    local interval = tonumber(record.rechargeIntervalSeconds) or (15 * 60)
    local now = tonumber(KST._clock) or 0
    local nowSession = math.floor(now)
    local nowEpoch = getRealEpochSeconds()

    local beforeCharges = tonumber(charges) or 0
    local afterCharges = beforeCharges - 1
    if afterCharges < 0 then
        afterCharges = 0
    end

    record.divineManualCharges = afterCharges
    record.divineChargesUnknown = nil
    record.divineBadEstimate = nil
    record.divineEstimateStartedAt = nil
    record.divineEstimateStartedSessionSeconds = nil
    record.divineEstimateStartedEpoch = nil
    record.divineLastUseAt = getEventTimeText()
    record.divineLastUseSessionSeconds = nowSession
    record.divineLastUseEpoch = nowEpoch
    record.divineLastBlessedGuild = toString(source)
    record.lastUpdateAt = record.divineLastUseAt
    record.lastUpdateSessionSeconds = nowSession
    record.lastUpdateEpoch = nowEpoch

    if beforeCharges >= maxCharges then
        record.divineNextChargeEpoch, record.divineNextChargeAtSessionSeconds = computeAbsoluteEnd(nowEpoch, nowSession, interval)
        record.divineNextChargeAt = getEndTimeText(record.divineNextChargeEpoch, record.divineNextChargeAtSessionSeconds)
    elseif tonumber(record.divineNextChargeEpoch) == nil and nowEpoch ~= nil and tonumber(record.divineNextChargeAtSessionSeconds) ~= nil then
        local remainingExisting = tonumber(record.divineNextChargeAtSessionSeconds) - nowSession
        if remainingExisting > 0 then
            record.divineNextChargeEpoch = nowEpoch + remainingExisting
            record.divineNextChargeAt = getEndTimeText(record.divineNextChargeEpoch, record.divineNextChargeAtSessionSeconds)
        end
    end

    store.lastUpdateAt = record.lastUpdateAt
    store.lastUpdateSessionSeconds = record.lastUpdateSessionSeconds
    store.lastUpdateEpoch = record.lastUpdateEpoch

    KST.SaveDivineFavorChargeSnapshot(record, store, "divine-charge-used-" .. toString(source))
    persistKeepUpgrades("divine-charge-used-" .. toString(source))
    KST.SafeAppendFileLogControlLine("[KST_PERSIST_DIVINE] keep=" .. toString(record.keepName or store.keepName) .. " charges=" .. tostring(afterCharges) .. "/" .. tostring(maxCharges) .. " reason=divine-charge-used")
    appendKeepUpgradeLog("DIVINE_FAVOR_CHARGE_USED", record.keepName or store.keepName, record, rawText)

    appendFileLogLine({
        event = "DIVINE_FAVOR_CHARGE_USED",
        observedAt = record.divineLastUseAt,
        sessionSeconds = nowSession,
        source = toString(source),
        keepName = toString(record.keepName or store.keepName),
        canonicalKeepId = store.canonicalKeepId,
        beforeCharges = beforeCharges,
        afterCharges = afterCharges,
        nextChargeAt = record.divineNextChargeAt,
        nextChargeAtSessionSeconds = record.divineNextChargeAtSessionSeconds,
        nextChargeEpoch = record.divineNextChargeEpoch,
        rawChatText = rawText,
    })

    return record
end


local function recordDivineFavorBlessingUsed(guildName, rawText)
    local record, store, matchCount = findDivineFavorAltarRecordForGuild(guildName)
    if type(record) ~= "table" or type(store) ~= "table" then
        appendFileLogLine({
            event = "DIVINE_FAVOR_BLESSING_UNMATCHED",
            observedAt = getEventTimeText(),
            sessionSeconds = math.floor(tonumber(KST._clock) or 0),
            guildName = toString(guildName),
            matchCount = tonumber(matchCount) or 0,
            rawChatText = rawText,
        })
        if KST.LOG_KEEP_UPGRADES_TO_CHAT then
            chatPrint("Divine Favor blessing detected, but no unique altar could be matched for guild: " .. toString(guildName) .. ".")
        end
        return nil
    end

    local beforeStatus, beforeRemaining, beforeCharges, beforeMaxCharges = getDivineFavorRecordStatusForUse(record)
    local usedRecord = KST.RecordDivineFavorChargeUsed(record, store, "chat-blessing:" .. toString(guildName), rawText)

    if KST.LOG_KEEP_UPGRADES_TO_CHAT and type(usedRecord) == "table" then
        local _, _, afterCharges, maxCharges = getDivineFavorRecordStatusForUse(usedRecord)
        local nextText = ""
        local nextRemaining = getUpgradeRemaining(usedRecord, "divineNextChargeEpoch", "divineNextChargeAtSessionSeconds")
        if nextRemaining ~= nil then
            nextText = " next in " .. formatCountdown(nextRemaining)
        elseif tonumber(afterCharges) ~= nil and tonumber(maxCharges) ~= nil and tonumber(afterCharges) >= tonumber(maxCharges) then
            nextText = " max charges"
        else
            nextText = " next unknown"
        end
        chatPrint("Divine Favor charge used: " .. toString(usedRecord.keepName or store.keepName) .. " " .. tostring(beforeCharges or 0) .. "/" .. tostring(beforeMaxCharges or 3) .. " -> " .. tostring(afterCharges or 0) .. "/" .. tostring(maxCharges or 3) .. "." .. nextText .. ".")
    end

    return usedRecord
end

local function parseKSTTimeSeconds(value)
    local text = toString(value)
    local h, m, s = string.match(text, "^(%d+):(%d%d):(%d%d)$")
    if h ~= nil then
        return (tonumber(h) or 0) * 3600 + (tonumber(m) or 0) * 60 + (tonumber(s) or 0)
    end

    m, s = string.match(text, "^(%d+):(%d%d)$")
    if m ~= nil then
        return (tonumber(m) or 0) * 60 + (tonumber(s) or 0)
    end

    local seconds = string.match(text, "^(%d+)$")
    if seconds ~= nil then
        return tonumber(seconds)
    end

    return nil
end


local function parseKSTSingleUpgradePart(zoneName, keepName, upgradePart, raw)
    local text = toString(upgradePart)
    text = string.gsub(text, "^%s+", "")
    text = string.gsub(text, "%s+$", "")

    local upgradeName, rank, statusText = string.match(text, "^(.+)%s+R(%d+)%s+(.+)$")
    if upgradeName == nil or rank == nil or statusText == nil then
        return nil
    end

    upgradeName = string.gsub(upgradeName, "^%s+", "")
    upgradeName = string.gsub(upgradeName, "%s+$", "")
    statusText = string.gsub(statusText, "^%s+", "")
    statusText = string.gsub(statusText, "%s+$", "")

    local parsed = {
        zoneName = zoneName,
        keepName = keepName,
        upgradeName = upgradeName,
        rank = tonumber(rank),
        statusText = statusText,
        rawText = raw,
    }

    local timeText = nil

    timeText = string.match(statusText, "^building%s+([%d:]+)$")
    if timeText ~= nil then
        parsed.state = "building"
        parsed.remainingSeconds = parseKSTTimeSeconds(timeText)
        return parsed
    end

    timeText = string.match(statusText, "^removing%s+([%d:]+)$")
    if timeText ~= nil then
        parsed.state = "removing"
        parsed.remainingSeconds = parseKSTTimeSeconds(timeText)
        return parsed
    end

    timeText = string.match(statusText, "^first%s+charge%s+([%d:]+)")
    if timeText ~= nil then
        parsed.state = "first-charge"
        parsed.remainingSeconds = parseKSTTimeSeconds(timeText)
        local zero, max = string.match(statusText, "(%d+)%s*/%s*(%d+)")
        parsed.charges = tonumber(zero) or 0
        parsed.maxCharges = tonumber(max) or 3
        return parsed
    end

    local charges, maxCharges, nextText = string.match(statusText, "^charges%s+(%d+)%s*/%s*(%d+)%s+next%s+([%d:]+)$")
    if charges ~= nil then
        parsed.state = "charges"
        parsed.charges = tonumber(charges)
        parsed.maxCharges = tonumber(maxCharges)
        parsed.remainingSeconds = parseKSTTimeSeconds(nextText)
        return parsed
    end

    charges, maxCharges = string.match(statusText, "^charges%s+(%d+)%s*/%s*(%d+)%s+max$")
    if charges ~= nil then
        parsed.state = "charges"
        parsed.charges = tonumber(charges)
        parsed.maxCharges = tonumber(maxCharges)
        parsed.remainingSeconds = nil
        return parsed
    end

    if statusText == "built" then
        parsed.state = "built"
        parsed.remainingSeconds = 0
        return parsed
    end

    if statusText == "removed" then
        parsed.state = "removed"
        parsed.remainingSeconds = 0
        return parsed
    end

    if statusText == "detected" then
        parsed.state = "detected"
        return parsed
    end

    return nil
end

local function parseKSTSyncText(text)
    local raw = sanitizeChatTextForParsing(text)
    if raw == "" then
        return nil
    end

    -- Ignore the local confirmation line printed by this addon after sending a
    -- share message. Real chat lines still contain [KST], but not this prefix.
    if string.find(raw, "Shared to /", 1, true) ~= nil then
        return nil
    end

    local kstStart = string.find(raw, "%[KST%]")
    if kstStart == nil then
        return nil
    end

    local payload = string.sub(raw, kstStart + 5)
    payload = string.gsub(payload, "^%s+", "")
    payload = string.gsub(payload, "%s+$", "")

    local zoneName, keepName, upgradePart = string.match(payload, "^([^|]+)%s*|%s*([^|]+)%s*|%s*(.+)$")
    if zoneName == nil or keepName == nil or upgradePart == nil then
        return nil
    end

    zoneName = string.gsub(zoneName, "^%s+", "")
    zoneName = string.gsub(zoneName, "%s+$", "")
    keepName = string.gsub(keepName, "^%s+", "")
    keepName = string.gsub(keepName, "%s+$", "")
    upgradePart = string.gsub(upgradePart, "^%s+", "")
    upgradePart = string.gsub(upgradePart, "%s+$", "")

    local summary = string.match(upgradePart, "^This%s+keep%s+has%s+the%s+following%s+upgrades:%s*(.+)$")
    if summary == nil then
        summary = string.match(upgradePart, "^This%s+keep%s+has%s+this%s+upgrade:%s*(.+)$")
    end
    if summary == nil then
        summary = string.match(upgradePart, "^Upgrades:%s*(.+)$")
    end
    if summary == nil then
        summary = string.match(upgradePart, "^Este%s+castillo%s+tiene%s+las%s+siguientes%s+mejoras:%s*(.+)$")
    end
    if summary == nil then
        summary = string.match(upgradePart, "^Este%s+castillo%s+tiene%s+esta%s+mejora:%s*(.+)$")
    end

    if summary ~= nil then
        local parsedList = {}
        summary = string.gsub(summary, "^%s+", "")
        summary = string.gsub(summary, "%s+$", "")

        if string.lower(summary) == "none" then
            return nil
        end

        for part in string.gmatch(summary, "([^;]+)") do
            local parsed = parseKSTSingleUpgradePart(zoneName, keepName, part, raw)
            if parsed ~= nil then
                parsedList[#parsedList + 1] = parsed
            end
        end

        if #parsedList == 1 then
            return parsedList[1]
        end
        if #parsedList > 1 then
            return parsedList
        end

        return nil
    end

    return parseKSTSingleUpgradePart(zoneName, keepName, upgradePart, raw)
end

local function recordKSTSyncedUpgrade(parsed)
    if type(parsed) ~= "table" or parsed.upgradeName == nil or parsed.rank == nil or parsed.keepName == nil then
        return nil
    end

    local dedupeKey = "sync|" .. normalizeKeepKey(parsed.keepName) .. "|" .. toString(parsed.upgradeName) .. "|" .. tostring(parsed.rank) .. "|" .. toString(parsed.statusText)
    local now = tonumber(KST._clock) or 0
    if KST._lastUpgradeChatKey == dedupeKey and tonumber(KST._lastUpgradeChatAt) ~= nil and now - tonumber(KST._lastUpgradeChatAt) < 2 then
        return nil
    end
    KST._lastUpgradeChatKey = dedupeKey
    KST._lastUpgradeChatAt = now

    local store = ensureKeepUpgradeStore(parsed.keepName)
    if store == nil then
        return nil
    end

    store.canonicalKeepId = store.canonicalKeepId or getCanonicalKeepIdFromName(parsed.keepName)
    if tonumber(store.canonicalKeepId) ~= nil and type(KST.CANONICAL_KEEPS) == "table" then
        local info = KST.CANONICAL_KEEPS[tonumber(store.canonicalKeepId)]
        if type(info) == "table" then
            store.canonicalKeepName = info.name
            store.canonicalZoneName = info.zone
        end
    end

    local nowSession = math.floor(now)
    local nowEpoch = getRealEpochSeconds()
    local remaining = tonumber(parsed.remainingSeconds)
    local rankNumber = tonumber(parsed.rank)
    local duration = getUpgradeDurationSeconds(parsed.upgradeName, rankNumber)
    local record = {
        name = toString(parsed.upgradeName),
        rank = rankNumber,
        keepName = toString(parsed.keepName),
        source = "chat-sync",
        syncZoneName = toString(parsed.zoneName),
        syncReceivedAt = getEventTimeText(),
        rawText = parsed.rawText,
        startedAt = getEventTimeText(),
        startedEpoch = nowEpoch,
        startedSessionSeconds = nowSession,
        durationSeconds = duration,
        lastUpdateAt = getEventTimeText(),
        lastUpdateSessionSeconds = nowSession,
        lastUpdateEpoch = nowEpoch,
    }

    if parsed.state == "building" then
        record.state = "building"
        record.durationSeconds = remaining or duration
        if remaining ~= nil then
            record.buildEndsAtSessionSeconds = nowSession + remaining
            if nowEpoch ~= nil then
                record.buildEndsEpoch = nowEpoch + remaining
            end
            record.buildEndsAt = getEndTimeText(record.buildEndsEpoch, record.buildEndsAtSessionSeconds)
        end
    elseif parsed.state == "removing" then
        record.state = "removing"
        record.durationSeconds = remaining or duration
        if remaining ~= nil then
            record.removeEndsAtSessionSeconds = nowSession + remaining
            if nowEpoch ~= nil then
                record.removeEndsEpoch = nowEpoch + remaining
            end
            record.removeEndsAt = getEndTimeText(record.removeEndsEpoch, record.removeEndsAtSessionSeconds)
        end
    elseif parsed.state == "removed" then
        record.state = "removed"
        record.durationSeconds = 0
        record.removeEndsAtSessionSeconds = nowSession
        record.removeEndsEpoch = nowEpoch
        record.removeEndsAt = getEndTimeText(record.removeEndsEpoch, record.removeEndsAtSessionSeconds)
    elseif parsed.state == "first-charge" then
        record.state = "building"
        record.durationSeconds = 0
        record.buildEndsAtSessionSeconds = nowSession
        record.buildEndsEpoch = nowEpoch
        record.buildEndsAt = getEndTimeText(record.buildEndsEpoch, record.buildEndsAtSessionSeconds)
        record.firstChargeDelaySeconds = remaining
        record.rechargeIntervalSeconds = 15 * 60
        record.maxCharges = tonumber(parsed.maxCharges) or 3
        if remaining ~= nil then
            record.firstChargeAtSessionSeconds = nowSession + remaining
            if nowEpoch ~= nil then
                record.firstChargeEpoch = nowEpoch + remaining
            end
            record.firstChargeAt = getEndTimeText(record.firstChargeEpoch, record.firstChargeAtSessionSeconds)
        end
    elseif parsed.state == "charges" then
        record.state = "building"
        record.durationSeconds = 0
        record.buildEndsAtSessionSeconds = nowSession
        record.buildEndsEpoch = nowEpoch
        record.buildEndsAt = getEndTimeText(record.buildEndsEpoch, record.buildEndsAtSessionSeconds)
        record.firstChargeDelaySeconds = 0
        record.firstChargeAtSessionSeconds = nowSession
        record.firstChargeEpoch = nowEpoch
        record.firstChargeAt = getEndTimeText(record.firstChargeEpoch, record.firstChargeAtSessionSeconds)
        record.rechargeIntervalSeconds = 15 * 60
        record.maxCharges = tonumber(parsed.maxCharges) or 3
        record.divineManualCharges = tonumber(parsed.charges) or 0
        if remaining ~= nil and record.divineManualCharges < record.maxCharges then
            record.divineNextChargeAtSessionSeconds = nowSession + remaining
            if nowEpoch ~= nil then
                record.divineNextChargeEpoch = nowEpoch + remaining
            end
            record.divineNextChargeAt = getEndTimeText(record.divineNextChargeEpoch, record.divineNextChargeAtSessionSeconds)
        end
    elseif parsed.state == "built" then
        record.state = "built"
        record.durationSeconds = 0
        record.buildEndsAtSessionSeconds = nil
        record.buildEndsEpoch = nil
        record.buildEndsAt = nil
    else
        record.state = "detected"
    end

    local upgradeKey = string.lower(record.name) .. ":" .. tostring(record.rank or "?")
    store.upgrades[upgradeKey] = record
    store.lastUpdateAt = record.lastUpdateAt
    store.lastUpdateSessionSeconds = record.lastUpdateSessionSeconds
    store.lastUpdateEpoch = record.lastUpdateEpoch
    rebuildKeepUpgradeStoreAliases(store)

    persistKeepUpgrades("chat-sync")
    appendKeepUpgradeLog("KEEP_UPGRADE_CHAT_SYNC_RECEIVED", parsed.keepName, record, parsed.rawText)

    if KST.LOG_KEEP_UPGRADES_TO_CHAT then
        chatPrint("KST sync received: " .. toString(record.keepName) .. " - " .. getShareUpgradeSummary(record) .. ".")
    end

    return record
end

local function handleChatTextForKeepUpgrades(text)
    if KST.LOG_KEEP_UPGRADES ~= true then
        return false
    end

    local scanText = sanitizeChatTextForParsing(text)
    if scanText == "" then
        return false
    end

    local upgradeName, rank, keepName, raw = parseKeepUpgradePurchaseText(scanText)
    if upgradeName ~= nil then
        recordKeepUpgradePurchase(upgradeName, rank, keepName, raw)
        return true
    end

    upgradeName, rank, keepName, raw = parseKeepUpgradeRemovedText(scanText)
    if upgradeName ~= nil then
        recordKeepUpgradeRemoved(upgradeName, rank, keepName, raw)
        return true
    end

    local blessedGuild, blessingRaw = parseDivineFavorBlessingText(scanText)
    if blessedGuild ~= nil then
        recordDivineFavorBlessingUsed(blessedGuild, blessingRaw)
        return true
    end

    local sync = parseKSTSyncText(scanText)
    if sync ~= nil then
        if type(sync) == "table" and sync[1] ~= nil then
            for _, item in ipairs(sync) do
                recordKSTSyncedUpgrade(item)
            end
        else
            recordKSTSyncedUpgrade(sync)
        end
        return true
    end

    if KST.DEBUG_KEEP_UPGRADE_CHAT == true and string.find(scanText, "keep upgrade") ~= nil then
        appendFileLogLine({
            event = "KEEP_UPGRADE_CHAT_UNPARSED",
            observedAt = getEventTimeText(),
            sessionSeconds = math.floor(tonumber(KST._clock) or 0),
            rawChatText = scanText,
        })
    end

    return false
end

local function handleTextLogEntryForKeepUpgrades(logName, entryIndex, ...)
    local matched = false
    for i = 1, select("#", ...) do
        local value = select(i, ...)
        local text = toString(value)
        if text ~= "" then
            local ok, result = pcall(handleChatTextForKeepUpgrades, text)
            if ok and result == true then
                matched = true
            end
        end
    end
    return matched
end

local function scanChatLogForKeepUpgrades(logName, maxBackfill, forceBackfill)
    if KST.CHAT_LOG_POLL_ENABLED ~= true or type(TextLogGetNumEntries) ~= "function" or type(TextLogGetEntry) ~= "function" then
        return false
    end

    local okCount, count = pcall(TextLogGetNumEntries, logName)
    count = tonumber(count)
    if not okCount or count == nil or count <= 0 then
        return false
    end

    if type(KST._chatLogLastIndex) ~= "table" then
        KST._chatLogLastIndex = {}
    end
    if type(KST._chatLogInitialScanned) ~= "table" then
        KST._chatLogInitialScanned = {}
    end

    -- WAR/RoR TextLog indices are normally zero-based: 0 .. count - 1.
    -- Older KeepSupplyTimer builds scanned 1 .. count, which can miss the first
    -- entry and waste one read at the end. Use the same indexing style seen in
    -- WARCommander/LibDateTime.
    local lastAvailable = count - 1
    local last = tonumber(KST._chatLogLastIndex[logName])
    local initialDone = KST._chatLogInitialScanned[logName] == true
    local startIndex

    if forceBackfill == true then
        local back = tonumber(maxBackfill) or tonumber(KST.CHAT_LOG_MANUAL_SCAN_LINES) or 300
        startIndex = math.max(0, count - back)
    elseif last == nil or initialDone ~= true then
        local back = tonumber(maxBackfill) or tonumber(KST.CHAT_LOG_INITIAL_SCAN_LINES) or 100
        startIndex = math.max(0, count - back)
        KST._chatLogInitialScanned[logName] = true
    elseif lastAvailable < last then
        startIndex = math.max(0, count - (tonumber(KST.CHAT_LOG_INITIAL_SCAN_LINES) or 100))
    else
        startIndex = last + 1
    end

    if startIndex > lastAvailable then
        KST._chatLogLastIndex[logName] = lastAvailable
        return false
    end

    local maxPerTick = tonumber(KST.CHAT_LOG_MAX_SCAN_PER_TICK) or 120
    if forceBackfill == true then
        maxPerTick = tonumber(maxBackfill) or tonumber(KST.CHAT_LOG_MANUAL_SCAN_LINES) or 300
    end
    local endIndex = math.min(lastAvailable, startIndex + maxPerTick - 1)

    local matchedAny = false
    for index = startIndex, endIndex do
        local results = { pcall(TextLogGetEntry, logName, index) }
        local ok = table.remove(results, 1)
        if ok then
            local matched = handleTextLogEntryForKeepUpgrades(logName, index, unpack(results))
            if matched == true then
                matchedAny = true
            end
        end
    end

    if forceBackfill ~= true then
        KST._chatLogLastIndex[logName] = endIndex
    end
    return matchedAny
end

local function pollChatLogsForKeepUpgrades(forceBackfill)
    local names = KST.CHAT_LOG_NAMES
    if type(names) ~= "table" then
        names = { "Chat" }
    end

    local matchedAny = false
    for _, logName in ipairs(names) do
        local ok, matched = pcall(scanChatLogForKeepUpgrades, logName, forceBackfill == true and KST.CHAT_LOG_MANUAL_SCAN_LINES or nil, forceBackfill == true)
        if ok and matched == true then
            matchedAny = true
        end
    end
    return matchedAny
end

local function handleCurrentGameChatDataForKeepUpgrades()
    if type(GameData) ~= "table" or type(GameData.ChatData) ~= "table" then
        return false
    end

    local raw = toString(GameData.ChatData.text)
    if raw == "" then
        return false
    end

    -- CHAT_TEXT_ARRIVED normally passes no args; the text is in GameData.ChatData,
    -- exactly as WARCommander reads it. Guard against the same event being routed
    -- both through RegisterEventHandler and the module OnEvent callback.
    local now = tonumber(KST._clock) or 0
    local chatType = toString(GameData.ChatData.type)
    local chatName = toString(GameData.ChatData.name)
    local key = chatType .. "|" .. chatName .. "|" .. raw
    if KST._lastGameChatRaw == key and tonumber(KST._lastGameChatAt) ~= nil and now - tonumber(KST._lastGameChatAt) < 5 then
        return false
    end
    KST._lastGameChatRaw = key
    KST._lastGameChatAt = now

    if KST.DEBUG_KEEP_UPGRADE_CHAT == true then
        local clean = sanitizeChatTextForParsing(raw)
        if string.find(clean, "keep upgrade") ~= nil then
            appendFileLogLine({
                event = "KEEP_UPGRADE_CHAT_EVENT_SEEN",
                observedAt = getEventTimeText(),
                sessionSeconds = math.floor(now),
                chatType = chatType,
                chatName = chatName,
                rawChatText = clean,
                chatSource = "GameData.ChatData",
            })
        end
    end

    return handleChatTextForKeepUpgrades(raw)
end

function KeepSupplyTimer.OnChatTextArrived(...)
    local matchedAny = false

    -- In RoR, CHAT_TEXT_ARRIVED often supplies the message through
    -- GameData.ChatData.text rather than function arguments.
    local okGame, matchedGame = pcall(handleCurrentGameChatDataForKeepUpgrades)
    if okGame and matchedGame == true then
        matchedAny = true
    end

    for i = 1, select("#", ...) do
        local value = select(i, ...)
        local text = toString(value)
        if text ~= "" then
            local ok, result = pcall(handleChatTextForKeepUpgrades, text)
            if ok and result == true then
                matchedAny = true
            end
        end
    end

    return matchedAny
end

function KeepSupplyTimer.OnChatEvent(...)
    KeepSupplyTimer.OnChatTextArrived(...)
end

function KeepSupplyTimer.OnEvent(...)
    KeepSupplyTimer.OnChatTextArrived(...)
end

function KST.RegisterChatEvents()
    if KST._chatEventsRegistered == true then
        return true
    end

    local registered = false
    local events = type(SystemData) == "table" and type(SystemData.Events) == "table" and SystemData.Events or nil
    local function tryRegister(eventValue)
        if eventValue == nil then
            return
        end
        if type(RegisterEventHandler) == "function" then
            local ok = pcall(RegisterEventHandler, eventValue, "KeepSupplyTimer.OnChatTextArrived")
            if ok then
                registered = true
            end
        end
        if type(RegisterEvent) == "function" then
            local ok = pcall(RegisterEvent, eventValue)
            if ok then
                registered = true
            end
        end
    end

    if type(events) == "table" then
        tryRegister(events.CHAT_TEXT_ARRIVED)
        tryRegister(events.CHAT_TEXT_RECEIVED)
        tryRegister(events.CHAT_TEXT)
        tryRegister(events.CHAT_LOG_UPDATED)
    end

    KST._chatEventsRegistered = registered
    return registered
end

local function appendDecayTrackingSnapshot(zoneId, keepIndex, keepData, keepState, generationInfo, reason)
    if KST.LOG_DECAY_TRACKING_SNAPSHOTS ~= true then
        return nil
    end

    if type(keepState) ~= "table" or keepState.lastSupplyDeliveredAt == nil then
        return nil
    end

    local keepId = tonumber(keepData and keepData.ID) or tonumber(keepState.keepId)
    local owner = tonumber(keepData and keepData.Owner) or tonumber(keepState.owner) or 0
    if owner == 0 then
        return nil
    end

    local rank = tonumber(keepData and keepData.Rank) or tonumber(keepState.rank)
    local supply = tonumber(keepData and keepData.Supply) or tonumber(keepState.lastSupply)
    local claim = getKeepClaimText(keepData)

    local event = {
        event = "DECAY_TRACKING_SNAPSHOT",
        snapshotReason = reason or "interval",
        decayTrackingSnapshotId = (tonumber(KeepSupplyTimerLog.decayTrackingSnapshotLastId) or 0) + 1,
        observedAt = getEventTimeText(),
        sessionSeconds = math.floor(tonumber(KST._clock) or 0),
        zoneId = tonumber(zoneId),
        zoneName = getZoneNameText(zoneId),
        keepIndex = tonumber(keepIndex),
        keepId = keepId,
        keepName = getKeepNameText(keepId, keepIndex),
        owner = owner,
        realm = getRealmNameText(owner),
        claim = claim,
        guild = claim,
        claimed = isKeepClaimed(claim),
        stars = rank,
        rank = rank,
        supply = supply,
        activeBOs = tonumber(generationInfo and generationInfo.activeBOs) or 0,
        requiredBOs = tonumber(generationInfo and generationInfo.requiredBOs),
        boRequirementMet = generationInfo and generationInfo.canGenerate == true or false,
    }

    local boSnapshot, boSummary = getBOSnapshot(zoneId, owner)
    event.boSnapshot = boSnapshot
    event.boOrder = boSummary.order
    event.boDestruction = boSummary.destruction
    event.boNeutral = boSummary.neutral
    event.boOwnedByKeepRealm = boSummary.ownedByKeepRealm
    event.boTotal = boSummary.total
    event.keepSnapshot = getKeepSnapshot(zoneId)

    copyDecayStatsToEvent(event, keepState)

    KeepSupplyTimerLog.decayTrackingSnapshotLastId = event.decayTrackingSnapshotId
    KeepSupplyTimerLog.lastDecayTrackingSnapshot = event
    KeepSupplyTimerLog.lastDecayTrackingSnapshotAt = event.observedAt
    KeepSupplyTimerLog.lastDecayTrackingSnapshotSessionSeconds = event.sessionSeconds

    appendFileLogLine(event)
    keepState.lastDecayTrackingSnapshotAt = tonumber(KST._clock) or 0
    return event
end

local function maybeAppendDecayTrackingSnapshot(zoneId, keepIndex, keepData, keepState, generationInfo)
    if KST.LOG_DECAY_TRACKING_SNAPSHOTS ~= true then
        return nil
    end

    if type(keepState) ~= "table" or keepState.lastSupplyDeliveredAt == nil then
        return nil
    end

    local interval = tonumber(KST.DECAY_TRACKING_SNAPSHOT_INTERVAL) or 30
    if interval <= 0 then
        return nil
    end

    local now = tonumber(KST._clock) or 0
    local last = tonumber(keepState.lastDecayTrackingSnapshotAt) or tonumber(keepState.lastSupplyDeliveredAt) or now
    if now - last >= interval then
        return appendDecayTrackingSnapshot(zoneId, keepIndex, keepData, keepState, generationInfo, "interval")
    end

    return nil
end

local function safeAppendDecayTrackingSnapshot(zoneId, keepIndex, keepData, keepState, generationInfo, reason)
    local ok, result = pcall(appendDecayTrackingSnapshot, zoneId, keepIndex, keepData, keepState, generationInfo, reason)
    if ok then
        return result
    end

    -- Never allow scientific tracking output to interrupt the core keep state
    -- update. If a snapshot fails, the next refresh must not repeatedly log the
    -- same SUPPLY_DELIVERED event.
    return nil
end

local function safeMaybeAppendDecayTrackingSnapshot(zoneId, keepIndex, keepData, keepState, generationInfo)
    local ok, result = pcall(maybeAppendDecayTrackingSnapshot, zoneId, keepIndex, keepData, keepState, generationInfo)
    if ok then
        return result
    end

    return nil
end


local function isResearchEnabled()
    if type(KeepSupplyTimerSettings) ~= "table" then
        KeepSupplyTimerSettings = {}
    end
    if KeepSupplyTimerSettings.researchEnabled == nil then
        KeepSupplyTimerSettings.researchEnabled = KST.RESEARCH_TICKS_ENABLED_DEFAULT
    end
    return KeepSupplyTimerSettings.researchEnabled ~= false
end

local function getResearchTMinSeconds(stars)
    local rank = math.floor(tonumber(stars) or 0)
    if rank < 0 then
        rank = 0
    elseif rank > 3 then
        rank = 3
    end

    local tableRef = type(KST.RESEARCH_TMIN_SECONDS) == "table" and KST.RESEARCH_TMIN_SECONDS or nil
    return tableRef and tonumber(tableRef[rank]) or nil
end

local function getResearchKey(zoneId, keepIndex)
    return toString(zoneId or "?") .. ":" .. toString(keepIndex or "?")
end

local function storeResearchLogEvent(event)
    if type(event) ~= "table" then
        return nil
    end

    if type(KeepSupplyTimerLog) ~= "table" then
        KeepSupplyTimerLog = {}
    end
    if type(KeepSupplyTimerLog.events) ~= "table" then
        KeepSupplyTimerLog.events = {}
    end

    KeepSupplyTimerLog.researchTickLastId = (tonumber(KeepSupplyTimerLog.researchTickLastId) or 0) + 1
    event.researchTickId = KeepSupplyTimerLog.researchTickLastId
    KeepSupplyTimerLog.version = KST.VERSION
    KeepSupplyTimerLog.lastResearchTick = event
    KeepSupplyTimerLog.events[#KeepSupplyTimerLog.events + 1] = event
    event.eventIndex = #KeepSupplyTimerLog.events
    trimLog()
    afterEventStored(event)
    return event
end

local function buildDecayResearchTick(zoneId, keepIndex, keepData, keepState, generationInfo, reason, decayed)
    if type(keepState) ~= "table" or type(keepData) ~= "table" then
        return nil
    end

    if KST.RESEARCH_TICK_ONLY_AFTER_SUPPLY == true and keepState.lastSupplyDeliveredAt == nil then
        return nil
    end

    local keepId = tonumber(keepData and keepData.ID) or tonumber(keepState and keepState.keepId)
    local owner = tonumber(keepData and keepData.Owner) or tonumber(keepState and keepState.owner) or 0
    local rank = tonumber(keepData and keepData.Rank) or tonumber(keepData and keepData.RankStars) or tonumber(keepState and keepState.rank) or 0
    local supply = tonumber(keepData and keepData.Supply) or tonumber(keepState and keepState.lastSupply) or 0
    local claim = getKeepClaimText(keepData)
    local activeBOs = tonumber(generationInfo and generationInfo.activeBOs) or 0
    local requiredBOs = tonumber(generationInfo and generationInfo.requiredBOs)
    local missingBOsNow = nil
    if requiredBOs ~= nil then
        missingBOsNow = requiredBOs - activeBOs
        if missingBOsNow < 0 then
            missingBOsNow = 0
        end
    end

    local rawFriendly, rawEnemy = getRawBOCountsForRealm(zoneId, owner)
    local rawMissingBOsNow = nil
    if requiredBOs ~= nil then
        rawMissingBOsNow = requiredBOs - rawFriendly
        if rawMissingBOsNow < 0 then
            rawMissingBOsNow = 0
        end
    end

    local lastSupplyAt = tonumber(keepState.lastSupplyDeliveredAt)
    local elapsedSinceSupply = lastSupplyAt and ((tonumber(KST._clock) or 0) - lastSupplyAt) or nil
    local tmin = getResearchTMinSeconds(rank)
    local elapsedMinusTmin = nil
    if elapsedSinceSupply ~= nil and tmin ~= nil then
        elapsedMinusTmin = elapsedSinceSupply - tmin
    end

    local candidate = requiredBOs ~= nil and activeBOs < requiredBOs
    local eligible = candidate and elapsedSinceSupply ~= nil and tmin ~= nil and elapsedSinceSupply >= tmin

    local event = {
        event = "DECAY_RESEARCH_TICK",
        researchReason = reason or "interval",
        observedAt = getEventTimeText(),
        sessionSeconds = math.floor(tonumber(KST._clock) or 0),
        zoneId = tonumber(zoneId),
        zoneName = getZoneNameText(zoneId),
        keepIndex = tonumber(keepIndex),
        keepId = keepId,
        keepName = getKeepNameText(keepId, keepIndex),
        owner = owner,
        realm = getRealmNameText(owner),
        claim = claim,
        guild = claim,
        claimed = isKeepClaimed(claim),
        stars = rank,
        rank = rank,
        supply = supply,
        activeBOs = activeBOs,
        requiredBOs = requiredBOs,
        missingBOsNow = missingBOsNow,
        rawMissingBOsNow = rawMissingBOsNow,
        decayCandidate = candidate,
        decayEligible = eligible,
        decayed = decayed == true,
        tminSeconds = tmin,
        elapsedMinusTminSeconds = elapsedMinusTmin and math.floor(elapsedMinusTmin) or nil,
        elapsedMinusTmin = elapsedMinusTmin and formatElapsed(math.abs(elapsedMinusTmin)) or nil,
        boRequirementMet = generationInfo and generationInfo.canGenerate == true or false,
    }

    if elapsedSinceSupply ~= nil then
        event.elapsedSeconds = math.floor(elapsedSinceSupply)
        event.elapsed = formatElapsed(elapsedSinceSupply)
    end

    local lostAt = tonumber(keepState.boRequirementLostAt)
    if lostAt ~= nil then
        local elapsedSinceLost = (tonumber(KST._clock) or 0) - lostAt
        if elapsedSinceLost < 0 then
            elapsedSinceLost = 0
        end
        event.boRequirementLostAtSessionSeconds = math.floor(lostAt)
        event.elapsedSinceBORequirementLostSeconds = math.floor(elapsedSinceLost)
        event.elapsedSinceBORequirementLost = formatElapsed(elapsedSinceLost)
    end

    local boSnapshot, boSummary = getBOSnapshot(zoneId, owner)
    event.boSnapshot = boSnapshot
    event.boOrder = boSummary.order
    event.boDestruction = boSummary.destruction
    event.boNeutral = boSummary.neutral
    event.boOwnedByKeepRealm = boSummary.ownedByKeepRealm
    event.boTotal = boSummary.total
    event.keepSnapshot = getKeepSnapshot(zoneId)

    copyDecayStatsToEvent(event, keepState)
    return event
end

local function appendDecayResearchTick(zoneId, keepIndex, keepData, keepState, generationInfo, reason, decayed)
    if not isResearchEnabled() then
        return nil
    end

    local event = buildDecayResearchTick(zoneId, keepIndex, keepData, keepState, generationInfo, reason, decayed)
    if event == nil then
        return nil
    end

    return storeResearchLogEvent(event)
end

local function safeAppendDecayResearchTick(zoneId, keepIndex, keepData, keepState, generationInfo, reason, decayed)
    local ok, result = pcall(appendDecayResearchTick, zoneId, keepIndex, keepData, keepState, generationInfo, reason, decayed)
    if ok then
        return result
    end
    return nil
end

local function maybeAppendDecayResearchTick(zoneId, keepIndex, keepData, keepState, generationInfo)
    if not isResearchEnabled() then
        return nil
    end
    if type(keepState) ~= "table" or keepState.lastSupplyDeliveredAt == nil then
        return nil
    end

    local required = tonumber(generationInfo and generationInfo.requiredBOs)
    local active = tonumber(generationInfo and generationInfo.activeBOs) or 0
    if required == nil or active >= required then
        return nil
    end

    local interval = tonumber(KST.RESEARCH_TICK_INTERVAL) or 5
    if interval <= 0 then
        return nil
    end

    local now = tonumber(KST._clock) or 0
    local key = getResearchKey(zoneId, keepIndex)
    local last = tonumber(KST._lastResearchTickAt[key]) or 0
    if now - last >= interval then
        KST._lastResearchTickAt[key] = now
        return appendDecayResearchTick(zoneId, keepIndex, keepData, keepState, generationInfo, "interval", false)
    end

    return nil
end

local function safeMaybeAppendDecayResearchTick(zoneId, keepIndex, keepData, keepState, generationInfo)
    local ok, result = pcall(maybeAppendDecayResearchTick, zoneId, keepIndex, keepData, keepState, generationInfo)
    if ok then
        return result
    end
    return nil
end

local forceFileLogSaveQuiet

local function persistDecaySample(event)
    if type(event) ~= "table" then
        return nil
    end

    if event.event ~= "PROGRESS_LOST" and event.event ~= "RANK_LOST" then
        return nil
    end

    if type(KeepSupplyTimerLog) ~= "table" then
        KeepSupplyTimerLog = {}
    end
    if type(KeepSupplyTimerLog.decaySamples) ~= "table" then
        KeepSupplyTimerLog.decaySamples = {}
    end

    local nextId = (tonumber(KeepSupplyTimerLog.decaySamplesLastId) or 0) + 1
    KeepSupplyTimerLog.decaySamplesLastId = nextId

    local sample = {
        event = "DECAY_SAMPLE",
        decaySampleId = nextId,
        sourceEvent = event.event,
        sourceEventIndex = event.eventIndex,
        observedAt = event.observedAt,
        sessionSeconds = event.sessionSeconds,
        zoneId = event.zoneId,
        zoneName = event.zoneName,
        keepIndex = event.keepIndex,
        keepId = event.keepId,
        keepName = event.keepName,
        owner = event.owner,
        realm = event.realm,
        claim = event.claim,
        guild = event.guild,
        claimed = event.claimed,
        stars = event.stars,
        rankBefore = event.rankBefore,
        rankAfter = event.rankAfter,
        supplyBefore = event.supplyBefore,
        supplyAfter = event.supplyAfter,
        elapsedSeconds = event.elapsedSeconds,
        elapsed = event.elapsed,
        lastSupplySessionSeconds = event.lastSupplySessionSeconds,
        lastSupplySession = event.lastSupplySession,
        lastSupplyObservedAt = event.lastSupplyObservedAt,
        lastSupplyEventIndex = event.lastSupplyEventIndex,
        lastSupplyWasObserved = event.lastSupplyWasObserved,
        secondsSinceLastSupply = event.secondsSinceLastSupply,
        elapsedSinceLastSupply = event.elapsedSinceLastSupply,
        decaySampleAccepted = event.decaySampleAccepted,
        decaySampleReason = event.decaySampleReason,
        boOrder = event.boOrder,
        boDestruction = event.boDestruction,
        boNeutral = event.boNeutral,
        boOwnedByKeepRealm = event.boOwnedByKeepRealm,
        boTotal = event.boTotal,
        activeBOs = event.activeBOs,
        requiredBOs = event.requiredBOs,
        boRequirementMet = event.boRequirementMet,
        boRequirementLostAtSessionSeconds = event.boRequirementLostAtSessionSeconds,
        elapsedSinceBORequirementLostSeconds = event.elapsedSinceBORequirementLostSeconds,
        elapsedSinceBORequirementLost = event.elapsedSinceBORequirementLost,
        decayStatsStartedAtSessionSeconds = event.decayStatsStartedAtSessionSeconds,
        decayStatsStartedAtSession = event.decayStatsStartedAtSession,
        decayTotalTrackedSeconds = event.decayTotalTrackedSeconds,
        decayTotalTracked = event.decayTotalTracked,
        decayFriendlyBOTime = event.decayFriendlyBOTime,
        decayActiveBOTime = event.decayActiveBOTime,
        decayEnemyBOTime = event.decayEnemyBOTime,
        decayBelowRequiredSeconds = event.decayBelowRequiredSeconds,
        decayBelowRequired = event.decayBelowRequired,
        decayAtRequiredSeconds = event.decayAtRequiredSeconds,
        decayAtRequired = event.decayAtRequired,
        decayAboveRequiredSeconds = event.decayAboveRequiredSeconds,
        decayAboveRequired = event.decayAboveRequired,
        decayRawBelowRequiredSeconds = event.decayRawBelowRequiredSeconds,
        decayRawBelowRequired = event.decayRawBelowRequired,
        decayRawAtRequiredSeconds = event.decayRawAtRequiredSeconds,
        decayRawAtRequired = event.decayRawAtRequired,
        decayRawAboveRequiredSeconds = event.decayRawAboveRequiredSeconds,
        decayRawAboveRequired = event.decayRawAboveRequired,
        decayMissingBOScore = event.decayMissingBOScore,
        decayRawMissingBOScore = event.decayRawMissingBOScore,
        decayEnemyBOScore = event.decayEnemyBOScore,
        decayFriendlyBOScore = event.decayFriendlyBOScore,
        decayActiveBOScore = event.decayActiveBOScore,
        decayAverageFriendlyBOs = event.decayAverageFriendlyBOs,
        decayAverageActiveBOs = event.decayAverageActiveBOs,
        decayAverageEnemyBOs = event.decayAverageEnemyBOs,
    }

    KeepSupplyTimerLog.decaySamples[#KeepSupplyTimerLog.decaySamples + 1] = sample
    trimDecaySamples()

    KeepSupplyTimerLog.lastDecaySample = sample
    KeepSupplyTimerLog.lastDecaySampleId = nextId
    KeepSupplyTimerLog.lastDecaySampleAt = sample.observedAt
    KeepSupplyTimerLog.lastDecaySampleSessionSeconds = sample.sessionSeconds

    appendFileLogLine(sample)
    forceFileLogSaveQuiet()

    return sample
end

local function appendFileLogControlLine(text)
    if not isFileLogEnabled() then
        return false
    end

    if not initializeFileLog() then
        return false
    end

    local okAdd = pcall(TextLogAddEntry, KST.FILE_LOG_NAME, KST.FILE_LOG_FILTER, toWString(text))
    if okAdd and KST.FILE_LOG_APPEND_SAFE ~= true and type(TextLogSaveLog) == "function" then
        pcall(TextLogSaveLog, KST.FILE_LOG_NAME)
    end

    return okAdd == true
end

forceFileLogSaveQuiet = function()
    if not isFileLogEnabled() then
        return false
    end

    if not initializeFileLog() then
        return false
    end

    -- In append-safe mode the TextLog incremental saver is the persistence
    -- mechanism. Calling TextLogSaveLog can rewrite the target file from the
    -- current in-memory buffer and erase lines from earlier reloads.
    if KST.FILE_LOG_APPEND_SAFE == true then
        KeepSupplyTimerLog.fileLogAutoSaveAt = getEventTimeText()
        KeepSupplyTimerLog.fileLogAutoSaveSessionSeconds = math.floor(tonumber(KST._clock) or 0)
        KeepSupplyTimerLog.fileLogAutoSaveLastError = nil
        return true
    end

    if type(TextLogSaveLog) ~= "function" then
        return false
    end

    local ok = pcall(TextLogSaveLog, KST.FILE_LOG_NAME)
    if ok then
        KeepSupplyTimerLog.fileLogAutoSaveAt = getEventTimeText()
        KeepSupplyTimerLog.fileLogAutoSaveSessionSeconds = math.floor(tonumber(KST._clock) or 0)
        KeepSupplyTimerLog.fileLogAutoSaveLastError = nil
        return true
    end

    KeepSupplyTimerLog.fileLogAutoSaveLastError = "TextLogSaveLog failed"
    return false
end

local function getFileLogStatusText()
    local enabled = isFileLogEnabled()
    if not enabled then
        return "filelog=off path=" .. getCurrentFileLogPathText()
    end

    if KST._fileLogInitialized then
        return "filelog=on initialized appendSafe=" .. toString(KST.FILE_LOG_APPEND_SAFE == true and "Y" or "N") .. " path=" .. getCurrentFileLogPathText() .. " archive=OFF"
    end

    if KST._fileLogFailed then
        return "filelog=on failed path=" .. getCurrentFileLogPathText() .. " archive=OFF error=" .. toString(KST._fileLogLastError or "unknown")
    end

    return "filelog=on pending appendSafe=" .. toString(KST.FILE_LOG_APPEND_SAFE == true and "Y" or "N") .. " path=" .. getCurrentFileLogPathText() .. " archive=OFF"
end

local function saveFileLogNow()
    if not isFileLogEnabled() then
        chatPrint("File log is disabled. Use /ksupply filelog on first. " .. getFileLogStatusText())
        return false
    end

    if not initializeFileLog() then
        chatPrint("File log manual save failed. " .. getFileLogStatusText())
        return false
    end

    local marker = "--- KeepSupplyTimer manual save at " .. getEventTimeText() .. " ---"
    pcall(TextLogAddEntry, KST.FILE_LOG_NAME, KST.FILE_LOG_FILTER, toWString(marker))
    if KST.FILE_LOG_APPEND_SAFE == true then
        KeepSupplyTimerLog.fileLogManualSaveAt = getEventTimeText()
        KeepSupplyTimerLog.fileLogManualSaveSessionSeconds = math.floor(KST._clock or 0)
        KeepSupplyTimerLog.fileLogManualSaveLastError = nil
        chatPrint("File log marker written to " .. getCurrentFileLogPathText() .. " using append-safe incremental mode. SavedVariables store only keep upgrades/settings; text log is the main decay/BO record.")
        return true
    end

    if type(TextLogSaveLog) ~= "function" then
        KeepSupplyTimerLog.fileLogManualSaveLastError = "TextLogSaveLog unavailable"
        chatPrint("Manual TextLog save is not available in this client. Incremental saving may still write the file. SavedVariables are used only for keep upgrades; the text log is the main decay/BO record.")
        return false
    end

    local ok = pcall(TextLogSaveLog, KST.FILE_LOG_NAME)
    if ok then
        KeepSupplyTimerLog.fileLogManualSaveAt = getEventTimeText()
        KeepSupplyTimerLog.fileLogManualSaveSessionSeconds = math.floor(KST._clock or 0)
        KeepSupplyTimerLog.fileLogManualSaveLastError = nil
        chatPrint("File log saved manually to " .. getCurrentFileLogPathText() .. ". SavedVariables are used only for keep upgrades; the text log is the main decay/BO record.")
        return true
    end

    KeepSupplyTimerLog.fileLogManualSaveLastError = "TextLogSaveLog failed"
    chatPrint("File log manual save failed. " .. getFileLogStatusText())
    return false
end


local function getServerDecayReferenceSeconds()
    if type(KeepSupplyTimerLog) ~= "table" then
        return nil
    end

    return tonumber(KeepSupplyTimerLog.serverDecayReferenceSeconds)
end

local function getExpectedDecayInfo(lostAtSeconds)
    local reference = getServerDecayReferenceSeconds()
    local lostAt = tonumber(lostAtSeconds)
    if reference == nil or lostAt == nil then
        return nil, nil, nil
    end

    local expectedAt = lostAt + reference
    local remaining = expectedAt - KST._clock
    if remaining < 0 then
        remaining = 0
    end

    return expectedAt, remaining, reference
end

local function getServerDecayGlobalReferenceSessionSeconds()
    return tonumber(KST._serverDecayGlobalReferenceSessionSeconds)
end

local function getGlobalDecayTickInfo(lostAtSeconds)
    local anchor = getServerDecayGlobalReferenceSessionSeconds()
    local lostAt = tonumber(lostAtSeconds)
    local interval = tonumber(KST.SERVER_DECAY_GLOBAL_INTERVAL) or 300

    if anchor == nil or lostAt == nil or interval <= 0 then
        return nil, nil, nil, nil
    end

    local expectedAt = anchor
    if expectedAt < lostAt then
        local jumps = math.ceil((lostAt - expectedAt) / interval)
        if jumps < 0 then
            jumps = 0
        end
        expectedAt = anchor + (jumps * interval)
    end

    local remaining = expectedAt - KST._clock
    if remaining < 0 then
        remaining = 0
    end

    return expectedAt, remaining, anchor, interval
end

local function getKeepSnapshot(zoneId)
    local keeps = getKeepsForZone(zoneId)
    local snapshot = {}

    for i = 1, 2 do
        local keepData = type(keeps) == "table" and type(keeps[i]) == "table" and keeps[i] or nil
        local keepId = tonumber(keepData and keepData.ID)
        local owner = tonumber(keepData and keepData.Owner) or 0
        local rank = tonumber(keepData and keepData.Rank)
        local supply = tonumber(keepData and keepData.Supply)
        local state = tonumber(keepData and keepData.State)
        local claim = getKeepClaimText(keepData)

        if keepId ~= nil or owner ~= 0 or rank ~= nil or supply ~= nil or state ~= nil then
            snapshot[i] = {
                index = i,
                id = keepId,
                name = getKeepNameText(keepId, i),
                owner = owner,
                realm = getRealmNameText(owner),
                rank = rank,
                stars = rank,
                supply = supply,
                state = state,
                claim = claim,
                guild = claim,
                claimed = isKeepClaimed(claim),
            }
        end
    end

    return snapshot
end

local function appendBOLog(eventType, zoneId, boIndex, boData, beforeOwner, afterOwner, beforeState, afterState, timer)
    if type(KeepSupplyTimerLog) ~= "table" then
        KeepSupplyTimerLog = {}
    end
    if type(KeepSupplyTimerLog.events) ~= "table" then
        KeepSupplyTimerLog.events = {}
    end

    local boId = tonumber(boData and boData.ID) or 0
    local event = {
        event = eventType,
        observedAt = getEventTimeText(),
        sessionSeconds = math.floor(tonumber(KST._clock) or 0),
        zoneId = tonumber(zoneId),
        zoneName = getZoneNameText(zoneId),
        boIndex = tonumber(boIndex),
        boId = boId,
        boName = getObjectiveNameText(boId, boIndex),
        ownerBefore = tonumber(beforeOwner),
        ownerAfter = tonumber(afterOwner),
        realmBefore = getRealmNameText(beforeOwner),
        realmAfter = getRealmNameText(afterOwner),
        stateBefore = tonumber(beforeState),
        stateAfter = tonumber(afterState),
        stateNameBefore = getBOStateName(beforeState),
        stateNameAfter = getBOStateName(afterState),
        stateTextBefore = getBOStateFullText(beforeOwner, beforeState),
        stateTextAfter = getBOStateFullText(afterOwner, afterState),
        timer = timer and math.floor(timer) or nil,
        timerText = timer and formatElapsed(timer) or nil,
    }

    local generationInfo = getBOGenerationInfo(zoneId, afterOwner)
    event.supplyActive = isBOSupplyActiveOwnedState(afterOwner, afterState, timer)
    event.supplyGenerating = event.supplyActive and generationInfo.canGenerate or false
    event.activeBOsForRealm = generationInfo.activeBOs
    event.requiredBOsForSupply = generationInfo.requiredBOs
    event.keepRankForRealm = generationInfo.keepRank
    event.keepNameForRealm = generationInfo.keepName

    local boSnapshot, boSummary = getBOSnapshot(zoneId, afterOwner)
    event.boSnapshot = boSnapshot
    event.boOrder = boSummary.order
    event.boDestruction = boSummary.destruction
    event.boNeutral = boSummary.neutral
    event.boOwnedByNewRealm = boSummary.ownedByKeepRealm
    event.boTotal = boSummary.total
    event.keepSnapshot = getKeepSnapshot(zoneId)

    KeepSupplyTimerLog.version = KST.VERSION
    KeepSupplyTimerLog.lastEvent = event
    KeepSupplyTimerLog.events[#KeepSupplyTimerLog.events + 1] = event
    event.eventIndex = #KeepSupplyTimerLog.events
    trimLog()
    afterEventStored(event)

    if KST.LOG_BO_STATE_CHANGES_TO_CHAT then
        chatPrint(
            eventType
                .. ": "
                .. event.zoneName
                .. " - "
                .. event.boName
                .. " "
                .. event.stateTextBefore
                .. " -> "
                .. event.stateTextAfter
                .. " timer="
                .. toString(event.timerText or "-")
        )
    end

    return event
end


local function appendServerTimerLog(eventType, zoneId, keepIndex, keepData, keepState, generationInfo, extra)
    if KST.LOG_SERVER_TIMER_CANDIDATES ~= true then
        return nil
    end

    if type(KeepSupplyTimerLog) ~= "table" then
        KeepSupplyTimerLog = {}
    end
    if type(KeepSupplyTimerLog.events) ~= "table" then
        KeepSupplyTimerLog.events = {}
    end

    extra = type(extra) == "table" and extra or {}

    local keepId = tonumber(keepData and keepData.ID) or tonumber(keepState and keepState.keepId)
    local owner = tonumber(keepData and keepData.Owner) or tonumber(keepState and keepState.owner) or 0
    local rank = tonumber(keepData and keepData.Rank) or tonumber(keepState and keepState.rank)
    local supply = tonumber(keepData and keepData.Supply) or tonumber(keepState and keepState.lastSupply)
    local claim = getKeepClaimText(keepData)
    local lostAt = tonumber(extra.boRequirementLostAtSessionSeconds or (keepState and keepState.boRequirementLostAt))
    local elapsedSinceLost = lostAt and (KST._clock - lostAt) or nil
    local expectedAt, expectedIn, reference = getExpectedDecayInfo(lostAt)
    local globalExpectedAt, globalExpectedIn, globalAnchor, globalInterval = getGlobalDecayTickInfo(lostAt)

    local event = {
        event = eventType,
        observedAt = getEventTimeText(),
        sessionSeconds = math.floor(tonumber(KST._clock) or 0),
        zoneId = tonumber(zoneId),
        zoneName = getZoneNameText(zoneId),
        keepIndex = tonumber(keepIndex),
        keepId = keepId,
        keepName = getKeepNameText(keepId, keepIndex),
        owner = owner,
        realm = getRealmNameText(owner),
        claim = claim,
        guild = claim,
        claimed = isKeepClaimed(claim),
        stars = rank,
        rank = rank,
        supply = supply,
        activeBOs = tonumber(generationInfo and generationInfo.activeBOs) or 0,
        requiredBOs = tonumber(generationInfo and generationInfo.requiredBOs),
        boRequirementMet = generationInfo and generationInfo.canGenerate == true or false,
        boRequirementLostAtSessionSeconds = lostAt and math.floor(lostAt) or nil,
        elapsedSinceBORequirementLostSeconds = elapsedSinceLost and math.floor(elapsedSinceLost) or nil,
        elapsedSinceBORequirementLost = elapsedSinceLost and formatElapsed(elapsedSinceLost) or nil,
        serverDecayReferenceSeconds = reference and math.floor(reference) or nil,
        serverDecayReference = reference and formatElapsed(reference) or nil,
        expectedDecayAtSessionSeconds = expectedAt and math.floor(expectedAt) or nil,
        expectedDecayInSeconds = expectedIn and math.floor(expectedIn) or nil,
        expectedDecayIn = expectedIn and formatElapsed(expectedIn) or nil,
        serverDecayGlobalReferenceSessionSeconds = globalAnchor and math.floor(globalAnchor) or nil,
        serverDecayGlobalReference = globalAnchor and formatElapsed(globalAnchor) or nil,
        serverDecayGlobalIntervalSeconds = globalInterval and math.floor(globalInterval) or nil,
        serverDecayGlobalInterval = globalInterval and formatElapsed(globalInterval) or nil,
        expectedGlobalDecayAtSessionSeconds = globalExpectedAt and math.floor(globalExpectedAt) or nil,
        expectedGlobalDecayInSeconds = globalExpectedIn and math.floor(globalExpectedIn) or nil,
        expectedGlobalDecayIn = globalExpectedIn and formatElapsed(globalExpectedIn) or nil,
        sourceEventIndex = extra.sourceEventIndex,
        sourceEvent = extra.sourceEvent,
        referenceSet = extra.referenceSet == true,
        initialObservation = extra.initialObservation == true,
    }

    local boSnapshot, boSummary = getBOSnapshot(zoneId, owner)
    event.boSnapshot = boSnapshot
    event.boOrder = boSummary.order
    event.boDestruction = boSummary.destruction
    event.boNeutral = boSummary.neutral
    event.boOwnedByKeepRealm = boSummary.ownedByKeepRealm
    event.boTotal = boSummary.total
    event.keepSnapshot = getKeepSnapshot(zoneId)

    KeepSupplyTimerLog.version = KST.VERSION
    KeepSupplyTimerLog.lastEvent = event
    KeepSupplyTimerLog.events[#KeepSupplyTimerLog.events + 1] = event
    event.eventIndex = #KeepSupplyTimerLog.events
    trimLog()
    afterEventStored(event)

    if KST.LOG_SERVER_TIMER_CANDIDATES_TO_CHAT then
        chatPrint(
            eventType
                .. ": "
                .. event.zoneName
                .. " - "
                .. event.keepName
                .. " ["
                .. event.realm
                .. "] BOs="
                .. toString(event.activeBOs or "?")
                .. "/"
                .. toString(event.requiredBOs or "?")
                .. " elapsedBOdef="
                .. toString(event.elapsedSinceBORequirementLost or "-")
                .. " ref="
                .. toString(event.serverDecayReference or "-")
        )
    end

    return event
end

function normalizeDecayMode(value)
    local text = string.upper(toString(value or ""))
    if text == "NORMAL" then
        return "NORMAL"
    end
    return "AGGRESSIVE"
end

function getActiveDecayModel()
    if type(KeepSupplyTimerSettings) ~= "table" then
        KeepSupplyTimerSettings = {}
    end
    if KeepSupplyTimerSettings.decayPredictionMode == nil then
        KeepSupplyTimerSettings.decayPredictionMode = KST.DECAY_PREDICTION_MODE_DEFAULT
    end

    local mode = normalizeDecayMode(KeepSupplyTimerSettings.decayPredictionMode)
    KeepSupplyTimerSettings.decayPredictionMode = mode
    local model = type(KST.DECAY_MODELS) == "table" and KST.DECAY_MODELS[mode] or nil
    return model or KST.DECAY_MODELS.AGGRESSIVE, mode
end

function getHybridAgeLimitSeconds(rank, model)
    local rankNumber = math.floor(tonumber(rank) or 0)
    if rankNumber < 0 then
        rankNumber = 0
    elseif rankNumber > 4 then
        rankNumber = 4
    end

    model = type(model) == "table" and model or getActiveDecayModel()
    local limits = type(model.ageLimit) == "table" and model.ageLimit or nil
    return limits and (tonumber(limits[rankNumber]) or tonumber(limits[3])) or 210
end

function clearHybridDecayPrediction(keepState, stateText, reason)
    if type(keepState) ~= "table" then
        return
    end

    keepState.decayPreviousState = keepState.decayState
    keepState.decayState = stateText
    keepState.decaySegmentStartedAt = nil
    keepState.decayArmedAt = nil
    keepState.decayCriticalAt = nil
    keepState.decayTimeToArmed = nil
    keepState.decayTimeToCritical = nil
    keepState.decayCriticalOverdue = nil
    keepState.decayAgeLimitSeconds = nil
    keepState.decayGraceSeconds = nil
    keepState.decayPredictionReason = reason
end

function copyHybridDecayPredictionToEvent(event, keepState)
    if type(event) ~= "table" or type(keepState) ~= "table" then
        return
    end

    event.hybridDecayState = keepState.decayState
    event.hybridDecayPreviousState = keepState.decayPreviousState
    event.hybridDecayReason = keepState.decayPredictionReason
    event.hybridDecayModel = keepState.decayModelName
    event.hybridDecayAgeLimitSeconds = keepState.decayAgeLimitSeconds
    event.hybridDecayGraceSeconds = keepState.decayGraceSeconds
    event.hybridDecaySegmentStartedAtSessionSeconds = keepState.decaySegmentStartedAt and math.floor(keepState.decaySegmentStartedAt) or nil
    event.hybridDecayArmedAtSessionSeconds = keepState.decayArmedAt and math.floor(keepState.decayArmedAt) or nil
    event.hybridDecayCriticalAtSessionSeconds = keepState.decayCriticalAt and math.floor(keepState.decayCriticalAt) or nil
    event.hybridDecayTimeToArmedSeconds = keepState.decayTimeToArmed and math.floor(keepState.decayTimeToArmed) or nil
    event.hybridDecayTimeToCriticalSeconds = keepState.decayTimeToCritical and math.floor(keepState.decayTimeToCritical) or nil
    event.hybridDecayCriticalOverdueSeconds = keepState.decayCriticalOverdue and math.floor(keepState.decayCriticalOverdue) or nil

    local now = tonumber(KST._clock) or 0
    if keepState.decaySegmentStartedAt ~= nil then
        local belowFor = now - (tonumber(keepState.decaySegmentStartedAt) or now)
        if belowFor < 0 then belowFor = 0 end
        event.hybridDecayBelowForSeconds = math.floor(belowFor)
    end

    if keepState.decayCriticalAt ~= nil and (event.event == "PROGRESS_LOST" or event.event == "RANK_LOST" or event.event == "HYBRID_DECAY_REAL_LOSS") then
        event.hybridDecayPredictionErrorSeconds = math.floor(now - keepState.decayCriticalAt)
    end

    if event.event == "PROGRESS_LOST" or event.event == "RANK_LOST" or event.event == "HYBRID_DECAY_REAL_LOSS" then
        event.hybridDecayWasCritical = keepState.decayState == "CRITICAL"
        if keepState.decayState == "CRITICAL" and keepState.decayLastStateChangeAt ~= nil then
            event.hybridDecayCriticalForSeconds = math.floor(now - (tonumber(keepState.decayLastStateChangeAt) or now))
        end
    end
end

function appendHybridDecayLog(eventType, zoneId, keepIndex, keepData, keepState, generationInfo, extra)
    if KST.LOG_DECAYS ~= true then
        return nil
    end

    if type(KeepSupplyTimerLog) ~= "table" then
        KeepSupplyTimerLog = {}
    end
    if type(KeepSupplyTimerLog.events) ~= "table" then
        KeepSupplyTimerLog.events = {}
    end

    extra = type(extra) == "table" and extra or {}
    local owner = tonumber(keepData and keepData.Owner) or tonumber(keepState and keepState.owner) or 0
    local keepId = tonumber(keepData and keepData.ID) or tonumber(keepState and keepState.keepId)
    local rank = tonumber(keepData and keepData.Rank) or tonumber(keepState and keepState.rank) or 0
    local supply = tonumber(keepData and keepData.Supply) or tonumber(keepState and keepState.lastSupply) or 0
    local activeBOs = tonumber(generationInfo and generationInfo.activeBOs) or tonumber(keepState and keepState.activeBOsForSupply) or 0
    local requiredBOs = tonumber(generationInfo and generationInfo.requiredBOs) or tonumber(keepState and keepState.requiredBOsForSupply) or getRequiredBOsForSupply(rank)
    local missingBOs = requiredBOs - activeBOs
    if missingBOs < 0 then missingBOs = 0 end

    local event = {
        event = eventType,
        observedAt = getEventTimeText(),
        sessionSeconds = math.floor(tonumber(KST._clock) or 0),
        zoneId = tonumber(zoneId),
        zoneName = getZoneNameText(zoneId),
        keepIndex = tonumber(keepIndex),
        keepId = keepId,
        keepName = getKeepNameText(keepId, keepIndex),
        owner = owner,
        realm = getRealmNameText(owner),
        claim = getKeepClaimText(keepData),
        guild = getKeepClaimText(keepData),
        claimed = isKeepClaimed(getKeepClaimText(keepData)),
        stars = rank,
        rank = rank,
        supply = supply,
        activeBOs = activeBOs,
        requiredBOs = requiredBOs,
        missingBOsNow = missingBOs,
        boRequirementMet = activeBOs >= requiredBOs,
        sourceEventIndex = extra.sourceEventIndex,
        sourceEvent = extra.sourceEvent,
        reason = extra.reason,
    }

    copyHybridDecayPredictionToEvent(event, keepState)

    local boSnapshot, boSummary = getBOSnapshot(zoneId, owner)
    event.boSnapshot = boSnapshot
    event.boOrder = boSummary.order
    event.boDestruction = boSummary.destruction
    event.boNeutral = boSummary.neutral
    event.boOwnedByKeepRealm = boSummary.ownedByKeepRealm
    event.boTotal = boSummary.total
    event.keepSnapshot = getKeepSnapshot(zoneId)

    KeepSupplyTimerLog.version = KST.VERSION
    KeepSupplyTimerLog.lastEvent = event
    KeepSupplyTimerLog.events[#KeepSupplyTimerLog.events + 1] = event
    event.eventIndex = #KeepSupplyTimerLog.events
    trimLog()
    afterEventStored(event)
    return event
end

function updateHybridAggressiveDecayPrediction(zoneId, keepIndex, keepData, keepState, generationInfo, reason)
    if type(keepState) ~= "table" then
        return nil
    end

    local now = tonumber(KST._clock) or 0
    local model, mode = getActiveDecayModel()
    local rank = tonumber(keepData and keepData.Rank) or tonumber(keepState.rank) or 0
    local progress = tonumber(keepData and keepData.Supply) or tonumber(keepState.lastSupply) or 0
    local lastSupplyAt = tonumber(keepState.lastSupplyDeliveredAt)
    local activeBOs = tonumber(generationInfo and generationInfo.activeBOs) or tonumber(keepState.activeBOsForSupply) or 0
    local requiredBOs = tonumber(generationInfo and generationInfo.requiredBOs) or getRequiredBOsForSupply(rank)
    local belowRequirement = activeBOs < requiredBOs
    local previousState = keepState.decayState

    keepState.requiredBOsForSupply = requiredBOs
    keepState.activeBOsForSupply = activeBOs
    keepState.belowRequirement = belowRequirement
    keepState.decayModel = mode
    keepState.decayModelName = model.name or mode

    if progress <= 0 then
        clearHybridDecayPrediction(keepState, "ZERO", "Progress is 0%. Nothing can decay yet.")
    elseif lastSupplyAt == nil then
        clearHybridDecayPrediction(keepState, "UNKNOWN", "No observed supply yet; prediction starts after the next supply increase.")
    elseif not belowRequirement then
        local stabilized = previousState == "AGING" or previousState == "ARMED" or previousState == "CRITICAL"
        local stableSince = tonumber(keepState.decayLastStateChangeAt) or now
        if previousState == "STABILIZED" and now - stableSince < (tonumber(KST.DECAY_STABILIZED_DISPLAY_SECONDS) or 15) then
            keepState.decayState = "STABILIZED"
            keepState.decayPredictionReason = "Decay risk was cancelled because BO requirement is met."
        elseif stabilized then
            keepState.decayPreviousState = previousState
            keepState.decayState = "STABILIZED"
            keepState.decayLastStateChangeAt = now
            keepState.decayPredictionReason = "Decay risk cancelled: BO requirement is met."
        else
            keepState.decayState = "SAFE"
            keepState.decayPredictionReason = "BO requirement is met."
        end
        keepState.decaySegmentStartedAt = nil
        keepState.decayArmedAt = nil
        keepState.decayCriticalAt = nil
        keepState.decayTimeToArmed = nil
        keepState.decayTimeToCritical = nil
        keepState.decayCriticalOverdue = nil
        keepState.decayAgeLimitSeconds = getHybridAgeLimitSeconds(rank, model)
        keepState.decayGraceSeconds = nil
    else
        if keepState.decaySegmentStartedAt == nil then
            keepState.decaySegmentStartedAt = now
        end

        local ageLimit = getHybridAgeLimitSeconds(rank, model)
        local armedAt = lastSupplyAt + ageLimit
        local grace = tonumber(model.graceLong) or 75
        if keepState.decaySegmentStartedAt >= armedAt then
            grace = tonumber(model.graceShort) or 45
        end
        local criticalAt = math.max(armedAt, keepState.decaySegmentStartedAt + grace)

        keepState.decayAgeLimitSeconds = ageLimit
        keepState.decayGraceSeconds = grace
        keepState.decayArmedAt = armedAt
        keepState.decayCriticalAt = criticalAt

        if now < armedAt then
            keepState.decayState = "AGING"
            keepState.decayTimeToArmed = armedAt - now
            keepState.decayTimeToCritical = criticalAt - now
            keepState.decayCriticalOverdue = nil
            keepState.decayPredictionReason = "Below BO requirement, but supply age has not reached the rank threshold yet."
        elseif now < criticalAt then
            keepState.decayState = "ARMED"
            keepState.decayTimeToArmed = 0
            keepState.decayTimeToCritical = criticalAt - now
            keepState.decayCriticalOverdue = nil
            keepState.decayPredictionReason = "Supply age threshold reached; waiting for aggressive below-requirement grace."
        else
            keepState.decayState = "CRITICAL"
            keepState.decayTimeToArmed = 0
            keepState.decayTimeToCritical = 0
            keepState.decayCriticalOverdue = now - criticalAt
            keepState.decayPredictionReason = "Threshold and aggressive grace exceeded while below BO requirement."
        end
    end

    if previousState ~= keepState.decayState then
        keepState.decayPreviousState = previousState
        keepState.decayLastStateChangeAt = now
        if previousState ~= nil or keepState.decayState == "AGING" or keepState.decayState == "ARMED" or keepState.decayState == "CRITICAL" or keepState.decayState == "STABILIZED" then
            local eventType = "HYBRID_DECAY_STATE_CHANGED"
            if keepState.decayState == "CRITICAL" then
                eventType = "HYBRID_DECAY_CRITICAL_REACHED"
            elseif keepState.decayState == "STABILIZED" then
                eventType = "HYBRID_DECAY_STABILIZED"
            elseif keepState.decayState == "AGING" and previousState ~= "ARMED" and previousState ~= "CRITICAL" then
                eventType = "HYBRID_DECAY_SEGMENT_STARTED"
            end
            appendHybridDecayLog(eventType, zoneId, keepIndex, keepData, keepState, generationInfo, { reason = reason or "state_update" })
        end
    end

    return keepState.decayState
end

local function updateKeepBORequirementState(zoneId, keepIndex, keepData, keepState, initialObservation)
    if type(keepState) ~= "table" then
        return nil
    end

    local owner = tonumber(keepData and keepData.Owner) or tonumber(keepState.owner) or 0
    local generationInfo = getBOGenerationInfo(zoneId, owner)
    local isMet = generationInfo.canGenerate == true
    local previousMet = keepState.boRequirementMet
    local wasObserved = keepState.boRequirementObserved == true

    if not wasObserved then
        keepState.boRequirementObserved = true
        keepState.boRequirementMet = isMet
        keepState.activeBOsForSupply = generationInfo.activeBOs
        keepState.requiredBOsForSupply = generationInfo.requiredBOs
        if isMet then
            keepState.boRequirementLostAt = nil
        else
            keepState.boRequirementLostAt = KST._clock
            if KST.LOG_SERVER_TIMER_CANDIDATES and initialObservation == true then
                appendServerTimerLog("SERVER_DECAY_TIMER_CANDIDATE_STARTED", zoneId, keepIndex, keepData, keepState, generationInfo, { initialObservation = true })
            end
        end
        return generationInfo
    end

    if previousMet == true and not isMet then
        keepState.boRequirementLostAt = KST._clock
        if KST.LOG_SERVER_TIMER_CANDIDATES then
            appendServerTimerLog("SERVER_DECAY_TIMER_CANDIDATE_STARTED", zoneId, keepIndex, keepData, keepState, generationInfo)
        end
    elseif previousMet == false and isMet then
        if KST.LOG_SERVER_TIMER_CANDIDATES then
            appendServerTimerLog("SERVER_DECAY_TIMER_CANDIDATE_CANCELLED", zoneId, keepIndex, keepData, keepState, generationInfo)
        end
        keepState.boRequirementLostAt = nil
    elseif not isMet and keepState.boRequirementLostAt == nil then
        keepState.boRequirementLostAt = KST._clock
    end

    keepState.boRequirementMet = isMet
    keepState.activeBOsForSupply = generationInfo.activeBOs
    keepState.requiredBOsForSupply = generationInfo.requiredBOs

    return generationInfo
end

local function appendLog(eventType, zoneId, keepIndex, keepData, keepState, beforeSupply, afterSupply, beforeRank, afterRank, elapsedSeconds)
    if type(KeepSupplyTimerLog) ~= "table" then
        KeepSupplyTimerLog = {}
    end
    if type(KeepSupplyTimerLog.events) ~= "table" then
        KeepSupplyTimerLog.events = {}
    end

    local keepId = tonumber(keepData and keepData.ID) or tonumber(keepState and keepState.keepId)
    local owner = tonumber(keepData and keepData.Owner) or tonumber(keepState and keepState.owner) or 0
    local elapsedNumber = tonumber(elapsedSeconds)
    local stars = tonumber(beforeRank) or tonumber(afterRank)
    local claim = getKeepClaimText(keepData)

    local event = {
        event = eventType,
        observedAt = getEventTimeText(),
        sessionSeconds = math.floor(tonumber(KST._clock) or 0),
        zoneId = tonumber(zoneId),
        zoneName = getZoneNameText(zoneId),
        keepIndex = tonumber(keepIndex),
        keepId = keepId,
        keepName = getKeepNameText(keepId, keepIndex),
        owner = owner,
        realm = getRealmNameText(owner),
        claim = claim,
        guild = claim,
        claimed = isKeepClaimed(claim),
        stars = stars,
        rankBefore = tonumber(beforeRank),
        rankAfter = tonumber(afterRank),
        supplyBefore = tonumber(beforeSupply),
        supplyAfter = tonumber(afterSupply),
        elapsedSeconds = elapsedNumber and math.floor(elapsedNumber) or nil,
        elapsed = elapsedNumber and formatElapsed(elapsedNumber) or "unknown",
        timerReset = eventType == "RANK_LOST" or eventType == "PROGRESS_LOST",
        timerResetReason = (eventType == "RANK_LOST" or eventType == "PROGRESS_LOST") and eventType or nil,
        progressAtLastSupply = keepState and keepState.progressAtLastSupply or nil,
        lastSupplyGain = keepState and keepState.lastSupplyGain or nil,
        progressBeforeDecay = tonumber(beforeSupply),
        progressAfterDecay = tonumber(afterSupply),
        progressLostAmount = (tonumber(beforeSupply) ~= nil and tonumber(afterSupply) ~= nil) and (tonumber(beforeSupply) - tonumber(afterSupply)) or nil,
        lossType = (eventType == "PROGRESS_LOST" and tonumber(afterSupply) == 0 and "FULL_RESET") or (eventType == "RANK_LOST" and "RANK_LOSS") or (eventType == "PROGRESS_ANOMALY" and "PARTIAL_DROP_BUG") or nil,
        anomaly = eventType == "PROGRESS_ANOMALY" and "Y" or nil,
        anomalyReason = eventType == "PROGRESS_ANOMALY" and "partial progress drop observed; real keep decay should be X->0" or nil,
    }

    local boSnapshot, boSummary = getBOSnapshot(zoneId, owner)
    event.boSnapshot = boSnapshot
    event.boOrder = boSummary.order
    event.boDestruction = boSummary.destruction
    event.boNeutral = boSummary.neutral
    event.boOwnedByKeepRealm = boSummary.ownedByKeepRealm
    event.boTotal = boSummary.total
    event.keepSnapshot = getKeepSnapshot(zoneId)

    local generationInfo = getBOGenerationInfo(zoneId, owner)
    local lostAt = tonumber(keepState and keepState.boRequirementLostAt)
    local elapsedSinceLost = lostAt and (KST._clock - lostAt) or nil
    event.activeBOs = tonumber(generationInfo and generationInfo.activeBOs) or 0
    event.requiredBOs = tonumber(generationInfo and generationInfo.requiredBOs)
    event.boRequirementMet = generationInfo and generationInfo.canGenerate == true or false
    copyHybridDecayPredictionToEvent(event, keepState)
    event.boRequirementLostAtSessionSeconds = lostAt and math.floor(lostAt) or nil
    event.elapsedSinceBORequirementLostSeconds = elapsedSinceLost and math.floor(elapsedSinceLost) or nil
    event.elapsedSinceBORequirementLost = elapsedSinceLost and formatElapsed(elapsedSinceLost) or nil

    local expectedAt, expectedIn, reference = getExpectedDecayInfo(lostAt)
    event.serverDecayReferenceSeconds = reference and math.floor(reference) or nil
    event.serverDecayReference = reference and formatElapsed(reference) or nil
    event.expectedDecayAtSessionSeconds = expectedAt and math.floor(expectedAt) or nil
    event.expectedDecayInSeconds = expectedIn and math.floor(expectedIn) or nil
    event.expectedDecayIn = expectedIn and formatElapsed(expectedIn) or nil

    if eventType == "PROGRESS_LOST" or eventType == "RANK_LOST" or eventType == "PROGRESS_ANOMALY" then
        copyDecayStatsToEvent(event, keepState)
    else
        addTimingAnalysisToEvent(event)
    end

    local globalExpectedAt, globalExpectedIn, globalAnchor, globalInterval = getGlobalDecayTickInfo(lostAt)
    event.serverDecayGlobalReferenceSessionSeconds = globalAnchor and math.floor(globalAnchor) or nil
    event.serverDecayGlobalReference = globalAnchor and formatElapsed(globalAnchor) or nil
    event.serverDecayGlobalIntervalSeconds = globalInterval and math.floor(globalInterval) or nil
    event.serverDecayGlobalInterval = globalInterval and formatElapsed(globalInterval) or nil
    event.expectedGlobalDecayAtSessionSeconds = globalExpectedAt and math.floor(globalExpectedAt) or nil
    event.expectedGlobalDecayInSeconds = globalExpectedIn and math.floor(globalExpectedIn) or nil
    event.expectedGlobalDecayIn = globalExpectedIn and formatElapsed(globalExpectedIn) or nil

    if (eventType == "PROGRESS_LOST" or eventType == "RANK_LOST") and KeepSupplyTimerLog.serverDecayReferenceSeconds == nil and elapsedSinceLost ~= nil and elapsedSinceLost > 0 then
        KeepSupplyTimerLog.serverDecayReferenceSeconds = math.floor(elapsedSinceLost)
        KeepSupplyTimerLog.serverDecayReference = formatElapsed(elapsedSinceLost)
        event.serverDecayReferenceSeconds = KeepSupplyTimerLog.serverDecayReferenceSeconds
        event.serverDecayReference = KeepSupplyTimerLog.serverDecayReference
        event.serverDecayReferenceSet = true
    end

    if (eventType == "PROGRESS_LOST" or eventType == "RANK_LOST") and KST._serverDecayGlobalReferenceSessionSeconds == nil then
        KST._serverDecayGlobalReferenceSessionSeconds = KST._clock
        event.serverDecayGlobalReferenceSessionSeconds = math.floor(KST._clock)
        event.serverDecayGlobalReference = formatElapsed(KST._clock)
        event.serverDecayGlobalIntervalSeconds = tonumber(KST.SERVER_DECAY_GLOBAL_INTERVAL) or 300
        event.serverDecayGlobalInterval = formatElapsed(event.serverDecayGlobalIntervalSeconds)
        event.serverDecayGlobalReferenceSet = true
        KeepSupplyTimerLog.serverDecayGlobalReferenceSessionSeconds = event.serverDecayGlobalReferenceSessionSeconds
        KeepSupplyTimerLog.serverDecayGlobalReference = event.serverDecayGlobalReference
        KeepSupplyTimerLog.serverDecayGlobalReferenceEvent = eventType
        KeepSupplyTimerLog.serverDecayGlobalReferenceZoneName = event.zoneName
        KeepSupplyTimerLog.serverDecayGlobalReferenceKeepName = event.keepName
        KeepSupplyTimerLog.serverDecayGlobalIntervalSeconds = event.serverDecayGlobalIntervalSeconds
        KeepSupplyTimerLog.serverDecayGlobalInterval = event.serverDecayGlobalInterval
    end

    KeepSupplyTimerLog.version = KST.VERSION
    KeepSupplyTimerLog.lastEvent = event
    KeepSupplyTimerLog.events[#KeepSupplyTimerLog.events + 1] = event
    event.eventIndex = #KeepSupplyTimerLog.events
    trimLog()
    afterEventStored(event)
    if eventType == "PROGRESS_LOST" or eventType == "RANK_LOST" then
        persistDecaySample(event)
        appendHybridDecayLog("HYBRID_DECAY_REAL_LOSS", zoneId, keepIndex, keepData, keepState, generationInfo, { sourceEventIndex = event.eventIndex, sourceEvent = eventType, reason = "real_decay" })
    elseif eventType == "PROGRESS_ANOMALY" then
        appendHybridDecayLog("HYBRID_DECAY_PARTIAL_LOSS_ANOMALY", zoneId, keepIndex, keepData, keepState, generationInfo, { sourceEventIndex = event.eventIndex, sourceEvent = eventType, reason = "partial_drop_ignored" })
    end

    local sourceEventIndex = #KeepSupplyTimerLog.events

    if event.serverDecayReferenceSet == true then
        appendServerTimerLog(
            "SERVER_DECAY_TIMER_REFERENCE_SET",
            zoneId,
            keepIndex,
            keepData,
            keepState,
            getBOGenerationInfo(zoneId, owner),
            {
                sourceEventIndex = sourceEventIndex,
                sourceEvent = eventType,
                referenceSet = true,
                boRequirementLostAtSessionSeconds = lostAt,
            }
        )
    end

    if event.serverDecayGlobalReferenceSet == true then
        local globalReferenceEvent = appendServerTimerLog(
            "SERVER_DECAY_GLOBAL_REFERENCE_SET",
            zoneId,
            keepIndex,
            keepData,
            keepState,
            getBOGenerationInfo(zoneId, owner),
            {
                sourceEventIndex = sourceEventIndex,
                sourceEvent = eventType,
                referenceSet = true,
                boRequirementLostAtSessionSeconds = lostAt,
            }
        )
        KST._serverDecayGlobalReferenceEventIndex = #KeepSupplyTimerLog.events
        if type(globalReferenceEvent) == "table" then
            globalReferenceEvent.serverDecayGlobalReferenceSet = true
        end
    end

    if eventType == "PROGRESS_LOST" or eventType == "RANK_LOST" then
        if KST.LOG_DECAY_TO_CHAT then
            chatPrint(
                eventType
                    .. ": "
                    .. event.zoneName
                    .. " - "
                    .. event.keepName
                    .. " ["
                    .. event.realm
                    .. "] stars="
                    .. toString(event.stars or "?")
                    .. " supply "
                    .. toString(event.supplyBefore or "?")
                    .. "->"
                    .. toString(event.supplyAfter or "?")
                    .. " after "
                    .. event.elapsed
                    .. " BOs="
                    .. toString(event.boOwnedByKeepRealm or "?")
                    .. "/"
                    .. toString(event.boTotal or 4)
                    .. " req="
                    .. toString(event.activeBOs or "?")
                    .. "/"
                    .. toString(event.requiredBOs or "?")
                    .. " lastSup="
                    .. toString(event.elapsedSinceLastSupply or event.elapsed or "unknown")
                    .. " sample="
                    .. toString(event.decaySampleAccepted == true and "Y" or "N")
                    .. " avgBO="
                    .. toString(event.decayAverageFriendlyBOs or "-")
                    .. "/"
                    .. toString(event.decayAverageActiveBOs or "-")
                    .. " enemyAvg="
                    .. toString(event.decayAverageEnemyBOs or "-")
                    .. " BOdef="
                    .. toString(event.elapsedSinceBORequirementLost or "-")
                    .. " below="
                    .. toString(event.decayBelowRequired or "-")
                    .. " missScore="
                    .. toString(event.decayMissingBOScore or "-")
            )
        end
    elseif eventType == "SUPPLY_DELIVERED" or eventType == "RANK_GAINED" then
        if KST.LOG_DELIVERIES_TO_CHAT then
            chatPrint(
                eventType
                    .. ": "
                    .. event.zoneName
                    .. " - "
                    .. event.keepName
                    .. " ["
                    .. event.realm
                    .. "] stars="
                    .. toString(event.rankAfter or "?")
                    .. " supply "
                    .. toString(event.supplyBefore or "?")
                    .. "->"
                    .. toString(event.supplyAfter or "?")
            )
        end
    end

    return event
end

local function appendClaimLog(zoneId, keepIndex, keepData, keepState, beforeClaim, afterClaim)
    if type(KeepSupplyTimerLog) ~= "table" then
        KeepSupplyTimerLog = {}
    end
    if type(KeepSupplyTimerLog.events) ~= "table" then
        KeepSupplyTimerLog.events = {}
    end

    local keepId = tonumber(keepData and keepData.ID) or tonumber(keepState and keepState.keepId)
    local owner = tonumber(keepData and keepData.Owner) or tonumber(keepState and keepState.owner) or 0
    local rank = tonumber(keepData and keepData.Rank) or tonumber(keepState and keepState.rank)
    local supply = tonumber(keepData and keepData.Supply) or tonumber(keepState and keepState.lastSupply)

    local event = {
        event = "CLAIM_CHANGED",
        observedAt = getEventTimeText(),
        sessionSeconds = math.floor(tonumber(KST._clock) or 0),
        zoneId = tonumber(zoneId),
        zoneName = getZoneNameText(zoneId),
        keepIndex = tonumber(keepIndex),
        keepId = keepId,
        keepName = getKeepNameText(keepId, keepIndex),
        owner = owner,
        realm = getRealmNameText(owner),
        stars = rank,
        rank = rank,
        supply = supply,
        claimBefore = beforeClaim,
        claimAfter = afterClaim,
        guildBefore = beforeClaim,
        guildAfter = afterClaim,
        claim = afterClaim,
        guild = afterClaim,
        claimed = isKeepClaimed(afterClaim),
    }

    local boSnapshot, boSummary = getBOSnapshot(zoneId, owner)
    event.boSnapshot = boSnapshot
    event.boOrder = boSummary.order
    event.boDestruction = boSummary.destruction
    event.boNeutral = boSummary.neutral
    event.boOwnedByKeepRealm = boSummary.ownedByKeepRealm
    event.boTotal = boSummary.total
    event.keepSnapshot = getKeepSnapshot(zoneId)

    KeepSupplyTimerLog.version = KST.VERSION
    KeepSupplyTimerLog.lastEvent = event
    KeepSupplyTimerLog.events[#KeepSupplyTimerLog.events + 1] = event
    event.eventIndex = #KeepSupplyTimerLog.events
    trimLog()
    afterEventStored(event)

    if KST.LOG_CLAIM_CHANGES_TO_CHAT then
        chatPrint(
            "CLAIM_CHANGED: "
                .. event.zoneName
                .. " - "
                .. event.keepName
                .. " "
                .. toString(beforeClaim or "?")
                .. " -> "
                .. toString(afterClaim or "?")
        )
    end

    return event
end

local function resetKeepState(keepState, keepData)
    keepState.keepId = tonumber(keepData and keepData.ID)
    keepState.owner = tonumber(keepData and keepData.Owner) or 0
    keepState.rank = tonumber(keepData and keepData.Rank)
    keepState.claim = getKeepClaimText(keepData)
    keepState.lastSupply = tonumber(keepData and keepData.Supply)
    keepState.lastDeliveryAt = nil
    keepState.lastSupplyDeliveredAt = nil
    keepState.lastSupplyObservedAt = nil
    keepState.lastSupplyEventIndex = nil
    keepState.rankAtLastDelivery = nil
    keepState.progressAtLastSupply = nil
    keepState.lastSupplyGain = nil
    keepState.lossLoggedForDelivery = false
    keepState.decayStats = nil
    keepState.lastDecayTrackingSnapshotAt = nil
    keepState.boRequirementObserved = false
    keepState.boRequirementMet = nil
    keepState.boRequirementLostAt = nil
    keepState.activeBOsForSupply = nil
    keepState.requiredBOsForSupply = nil
    clearHybridDecayPrediction(keepState, "UNKNOWN", "Keep state reset.")
    keepState.decayLastStateChangeAt = nil
end

local function updateKeepState(zoneId, keepIndex, keepData)
    local zoneState = getState(zoneId)
    if zoneState == nil then
        return nil
    end

    if type(zoneState.keeps[keepIndex]) ~= "table" then
        zoneState.keeps[keepIndex] = {}
    end

    local keepState = zoneState.keeps[keepIndex]
    local keepId = tonumber(keepData and keepData.ID)
    local owner = tonumber(keepData and keepData.Owner) or 0
    local rank = tonumber(keepData and keepData.Rank)
    local supply = tonumber(keepData and keepData.Supply)
    local claim = getKeepClaimText(keepData)

    if keepId == nil or owner == 0 or rank == nil or supply == nil then
        keepState.keepId = keepId
        keepState.owner = owner
        keepState.rank = rank
        keepState.claim = claim
        keepState.lastSupply = supply
        keepState.lastDeliveryAt = nil
        keepState.lastSupplyDeliveredAt = nil
        keepState.lastSupplyObservedAt = nil
        keepState.lastSupplyEventIndex = nil
        keepState.rankAtLastDelivery = nil
        keepState.lossLoggedForDelivery = false
        keepState.decayStats = nil
        keepState.lastDecayTrackingSnapshotAt = nil
        keepState.boRequirementObserved = false
        keepState.boRequirementMet = nil
        keepState.boRequirementLostAt = nil
        keepState.activeBOsForSupply = nil
        keepState.requiredBOsForSupply = nil
        clearHybridDecayPrediction(keepState, "UNKNOWN", "Missing keep data.")
        keepState.decayLastStateChangeAt = nil
        return nil
    end

    if keepState.keepId ~= keepId or keepState.owner ~= owner then
        resetKeepState(keepState, keepData)
        local initGenerationInfo = updateKeepBORequirementState(zoneId, keepIndex, keepData, keepState, false)
        updateHybridAggressiveDecayPrediction(zoneId, keepIndex, keepData, keepState, initGenerationInfo, "initial_keep_observation")
        return keepState
    end

    if keepState.lastSupply == nil then
        keepState.rank = rank
        keepState.claim = claim
        keepState.lastSupply = supply
        keepState.lastSupplyDeliveredAt = nil
        keepState.lastSupplyObservedAt = nil
        keepState.lastSupplyEventIndex = nil
        keepState.decayStats = nil
        keepState.lastDecayTrackingSnapshotAt = nil
        keepState.lossLoggedForDelivery = false
        local initGenerationInfo = updateKeepBORequirementState(zoneId, keepIndex, keepData, keepState, false)
        updateHybridAggressiveDecayPrediction(zoneId, keepIndex, keepData, keepState, initGenerationInfo, "initial_keep_observation")
        return keepState
    end

    local generationInfo = updateKeepBORequirementState(zoneId, keepIndex, keepData, keepState, false)
    accumulateDecayStats(zoneId, keepState, owner, generationInfo)
    safeMaybeAppendDecayTrackingSnapshot(zoneId, keepIndex, keepData, keepState, generationInfo)

    local previousSupply = tonumber(keepState.lastSupply)
    local previousRank = tonumber(keepState.rank)
    local elapsedSinceDelivery = nil
    if keepState.lastDeliveryAt ~= nil then
        elapsedSinceDelivery = KST._clock - keepState.lastDeliveryAt
    end

    local elapsedSinceSupply = nil
    if keepState.lastSupplyDeliveredAt ~= nil then
        elapsedSinceSupply = KST._clock - keepState.lastSupplyDeliveredAt
    end

    local previousClaim = keepState.claim
    if KST._logClaimChanges and previousClaim ~= nil and previousClaim ~= claim then
        appendClaimLog(zoneId, keepIndex, keepData, keepState, previousClaim, claim)
    end

    if previousSupply ~= nil and previousRank ~= nil and supply == previousSupply and rank == previousRank then
        safeMaybeAppendDecayResearchTick(zoneId, keepIndex, keepData, keepState, generationInfo)
        updateHybridAggressiveDecayPrediction(zoneId, keepIndex, keepData, keepState, generationInfo, "steady_state")
    end

    if previousRank ~= nil and rank > previousRank then
        local deliveryEvent = nil
        if KST.LOG_DELIVERIES then
            deliveryEvent = appendLog("RANK_GAINED", zoneId, keepIndex, keepData, keepState, previousSupply, supply, previousRank, rank, elapsedSinceDelivery)
        end
        keepState.lastDeliveryAt = KST._clock
        keepState.lastSupplyDeliveredAt = KST._clock
        keepState.lastSupplyObservedAt = getEventTimeText()
        keepState.lastSupplyEventIndex = deliveryEvent and deliveryEvent.eventIndex or (type(KeepSupplyTimerLog) == "table" and type(KeepSupplyTimerLog.events) == "table" and #KeepSupplyTimerLog.events or nil)
        keepState.rankAtLastDelivery = rank
        keepState.progressAtLastSupply = supply
        keepState.lastSupplyGain = (previousSupply ~= nil and supply ~= nil) and (supply - previousSupply) or nil
        keepState.lossLoggedForDelivery = false
        keepState.keepId = keepId
        keepState.owner = owner
        keepState.rank = rank
        keepState.claim = claim
        keepState.lastSupply = supply
        resetDecayStats(keepState)
        if generationInfo and generationInfo.canGenerate ~= true then
            keepState.decaySegmentStartedAt = KST._clock
        else
            keepState.decaySegmentStartedAt = nil
        end
        updateHybridAggressiveDecayPrediction(zoneId, keepIndex, keepData, keepState, generationInfo, "supply_reset")
        safeAppendDecayTrackingSnapshot(zoneId, keepIndex, keepData, keepState, generationInfo, "supply_reset")
    elseif previousSupply ~= nil and supply > previousSupply then
        local deliveryEvent = nil
        if KST.LOG_DELIVERIES then
            deliveryEvent = appendLog("SUPPLY_DELIVERED", zoneId, keepIndex, keepData, keepState, previousSupply, supply, previousRank, rank, nil)
        end
        keepState.lastDeliveryAt = KST._clock
        keepState.lastSupplyDeliveredAt = KST._clock
        keepState.lastSupplyObservedAt = getEventTimeText()
        keepState.lastSupplyEventIndex = deliveryEvent and deliveryEvent.eventIndex or (type(KeepSupplyTimerLog) == "table" and type(KeepSupplyTimerLog.events) == "table" and #KeepSupplyTimerLog.events or nil)
        keepState.rankAtLastDelivery = rank
        keepState.progressAtLastSupply = supply
        keepState.lastSupplyGain = (previousSupply ~= nil and supply ~= nil) and (supply - previousSupply) or nil
        keepState.lossLoggedForDelivery = false
        keepState.keepId = keepId
        keepState.owner = owner
        keepState.rank = rank
        keepState.claim = claim
        keepState.lastSupply = supply
        resetDecayStats(keepState)
        if generationInfo and generationInfo.canGenerate ~= true then
            keepState.decaySegmentStartedAt = KST._clock
        else
            keepState.decaySegmentStartedAt = nil
        end
        updateHybridAggressiveDecayPrediction(zoneId, keepIndex, keepData, keepState, generationInfo, "supply_reset")
        safeAppendDecayTrackingSnapshot(zoneId, keepIndex, keepData, keepState, generationInfo, "supply_reset")
    elseif previousRank ~= nil and rank < previousRank then
        if KST.LOG_DECAYS == true and keepState.lossLoggedForDelivery ~= true then
            appendLog("RANK_LOST", zoneId, keepIndex, keepData, keepState, previousSupply, supply, previousRank, rank, elapsedSinceSupply)
        end
        safeAppendDecayResearchTick(zoneId, keepIndex, keepData, keepState, generationInfo, "rank_loss", true)
        -- A rank loss resets the keep progress to 0 automatically. Start a new
        -- local visible cycle at the degradation moment, but do not mark it as a
        -- valid supply-delivered reset for scientific decay samples.
        keepState.lastDeliveryAt = KST._clock
        keepState.lastSupplyDeliveredAt = nil
        keepState.lastSupplyObservedAt = nil
        keepState.lastSupplyEventIndex = nil
        keepState.rankAtLastDelivery = rank
        keepState.lossLoggedForDelivery = false
        keepState.decayStats = nil
    elseif previousSupply ~= nil and supply < previousSupply then
        if supply == 0 then
            if KST.LOG_DECAYS == true and keepState.lossLoggedForDelivery ~= true then
                appendLog("PROGRESS_LOST", zoneId, keepIndex, keepData, keepState, previousSupply, supply, previousRank, rank, elapsedSinceSupply)
            end
            safeAppendDecayResearchTick(zoneId, keepIndex, keepData, keepState, generationInfo, "decay", true)
            -- Real keep decay: progress always resets to 0. After the reset, wait
            -- for the next real supply delivery before accepting another sample.
            keepState.lastDeliveryAt = KST._clock
            keepState.lastSupplyDeliveredAt = nil
            keepState.lastSupplyObservedAt = nil
            keepState.lastSupplyEventIndex = nil
            keepState.rankAtLastDelivery = rank
            keepState.lossLoggedForDelivery = false
            keepState.decayStats = nil
        else
            -- Keeps should not lose partial progress. Treat X->Y (Y>0) as an
            -- addon/SoR read anomaly. Only write the analysis log when research
            -- logging is explicitly enabled.
            if KST.LOG_DECAYS == true then
                appendLog("PROGRESS_ANOMALY", zoneId, keepIndex, keepData, keepState, previousSupply, supply, previousRank, rank, elapsedSinceSupply)
            end
            supply = previousSupply
        end
    end

    keepState.keepId = keepId
    keepState.owner = owner
    keepState.rank = rank
    keepState.claim = claim
    keepState.lastSupply = supply

    updateHybridAggressiveDecayPrediction(zoneId, keepIndex, keepData, keepState, generationInfo, "post_keep_update")

    return keepState
end


local function isRiskTextEnabled()
    if type(KeepSupplyTimerSettings) ~= "table" then
        KeepSupplyTimerSettings = {}
    end
    if KeepSupplyTimerSettings.showRiskText == nil then
        KeepSupplyTimerSettings.showRiskText = KST.SHOW_RISK_TEXT_DEFAULT
    end
    return KeepSupplyTimerSettings.showRiskText ~= false
end

local function getRiskTMinSeconds(stars)
    local model = getActiveDecayModel()
    return getHybridAgeLimitSeconds(stars, model)
end

local function getKeepRiskInfo(keepState)
    local result = {
        code = "?",
        label = "Unknown",
        short = "D:?",
        level = 0,
        reason = "no data",
        elapsedSec = nil,
        tmin = nil,
        mediumAt = nil,
        activeBOs = keepState and keepState.activeBOsForSupply or nil,
        requiredBOs = keepState and keepState.requiredBOsForSupply or nil,
        currentBelowStreakSec = nil,
        belowSec = nil,
        missScore = nil,
        elapsedMinusTmin = nil,
        missingBOsNow = nil,
        protectedNow = false,
        decayState = keepState and keepState.decayState or nil,
        decayModel = keepState and keepState.decayModelName or nil,
        timeToArmedSec = keepState and keepState.decayTimeToArmed or nil,
        timeToCriticalSec = keepState and keepState.decayTimeToCritical or nil,
        criticalOverdueSec = keepState and keepState.decayCriticalOverdue or nil,
        graceSec = keepState and keepState.decayGraceSeconds or nil,
    }

    if type(keepState) ~= "table" then
        return result
    end

    local supply = tonumber(keepState.lastSupply) or 0
    local rank = tonumber(keepState.rank) or 0
    local active = tonumber(keepState.activeBOsForSupply)
    local required = tonumber(keepState.requiredBOsForSupply) or getRequiredBOsForSupply(rank)
    result.activeBOs = active
    result.requiredBOs = required

    local activeSafe = active ~= nil and active or 0
    local missingNow = required - activeSafe
    if missingNow < 0 then
        missingNow = 0
    end
    result.missingBOsNow = missingNow
    result.protectedNow = active ~= nil and active >= required

    local lastSupplyAt = tonumber(keepState.lastSupplyDeliveredAt)
    if lastSupplyAt ~= nil then
        local now = tonumber(KST._clock) or 0
        local elapsed = now - lastSupplyAt
        if elapsed < 0 then elapsed = 0 end
        result.elapsedSec = math.floor(elapsed)
    end

    result.tmin = tonumber(keepState.decayAgeLimitSeconds) or getRiskTMinSeconds(rank)
    result.mediumAt = result.tmin
    if result.elapsedSec ~= nil and result.tmin ~= nil then
        result.elapsedMinusTmin = math.floor(result.elapsedSec - result.tmin)
    end

    local stats = type(keepState.decayStats) == "table" and keepState.decayStats or nil
    result.currentBelowStreakSec = stats and math.floor(tonumber(stats.currentBelowStreakSeconds) or 0) or nil
    result.belowSec = stats and math.floor(tonumber(stats.belowRequiredSeconds) or 0) or nil
    result.missScore = stats and math.floor(tonumber(stats.missingBOScore) or 0) or nil

    if supply <= 0 or keepState.decayState == "ZERO" then
        result.code = "ZERO"
        result.label = "No progress"
        result.short = "D:0%"
        result.level = 0
        result.reason = keepState.decayPredictionReason or "progress is 0%"
        return result
    end

    if lastSupplyAt == nil or keepState.decayState == "UNKNOWN" or keepState.decayState == nil then
        result.code = "?"
        result.label = "Unknown"
        result.short = "D:?"
        result.level = 0
        result.reason = keepState.decayPredictionReason or "no observed supply"
        return result
    end

    local state = toString(keepState.decayState)
    if state == "SAFE" then
        result.code = "OK"
        result.label = "Safe"
        result.short = "D:OK"
        result.level = 0
    elseif state == "STABILIZED" then
        result.code = "STAB"
        result.label = "Stabilized"
        result.short = "D:ST"
        result.level = 1
    elseif state == "AGING" then
        result.code = "LOW"
        result.label = "Aging"
        result.short = "D:AG"
        result.level = 1
    elseif state == "ARMED" then
        result.code = "HIGH"
        result.label = "Armed"
        result.short = "D:AR"
        result.level = 3
    elseif state == "CRITICAL" then
        result.code = "CRIT"
        result.label = "Critical"
        result.short = "D:CR"
        result.level = 4
    else
        result.code = "?"
        result.label = "Unknown"
        result.short = "D:?"
        result.level = 0
    end

    result.reason = keepState.decayPredictionReason or result.label
    return result
end

local function formatRiskInfoForChat(prefix, keepState)
    local r = getKeepRiskInfo(keepState)
    local pieces = {
        prefix or "Keep",
        toString(r.short or "D:?"),
        toString(r.label or "Unknown"),
        "reason=" .. toString(r.reason or "?"),
    }
    if r.elapsedSec ~= nil then
        pieces[#pieces + 1] = "sinceSupply=" .. formatElapsed(r.elapsedSec)
    end
    if r.tmin ~= nil then
        pieces[#pieces + 1] = "rankThreshold=" .. formatElapsed(r.tmin)
    end
    if r.activeBOs ~= nil or r.requiredBOs ~= nil then
        pieces[#pieces + 1] = "req=" .. toString(r.activeBOs or "?") .. "/" .. toString(r.requiredBOs or "?")
    end
    if r.timeToArmedSec ~= nil and r.timeToArmedSec > 0 then
        pieces[#pieces + 1] = "armedIn=" .. formatElapsed(r.timeToArmedSec)
    end
    if r.timeToCriticalSec ~= nil and r.timeToCriticalSec > 0 then
        pieces[#pieces + 1] = "criticalIn=" .. formatElapsed(r.timeToCriticalSec)
    end
    if r.criticalOverdueSec ~= nil and r.criticalOverdueSec > 0 then
        pieces[#pieces + 1] = "critical+" .. formatElapsed(r.criticalOverdueSec)
    end
    if r.graceSec ~= nil then
        pieces[#pieces + 1] = "grace=" .. tostring(math.floor(r.graceSec)) .. "s"
    end
    return table.concat(pieces, " | ")
end

local function getKeepText(keepState, fallbackIndex)
    if type(keepState) ~= "table" then
        return nil
    end

    local owner = tonumber(keepState.owner) or 0
    local label = REALM_LABELS[owner] or ("K" .. tostring(fallbackIndex))
    local text = KST.UNKNOWN_TEXT

    if keepState.lastDeliveryAt ~= nil then
        text = formatElapsed(KST._clock - keepState.lastDeliveryAt)
    elseif not KST.SHOW_UNKNOWN_WHEN_SUPPLY_EXISTS then
        return nil
    end

    local suffix = ""
    if isRiskTextEnabled() then
        local risk = getKeepRiskInfo(keepState)
        suffix = " " .. toString(risk.short or "R:?")
    end

    return label .. " " .. text .. suffix
end

local function getResetBoxText(keepState)
    if type(keepState) ~= "table" then
        return nil
    end

    local text = KST.UNKNOWN_TEXT
    if keepState.lastDeliveryAt ~= nil then
        text = formatElapsed(KST._clock - keepState.lastDeliveryAt)
    end

    local risk = getKeepRiskInfo(keepState)
    return text .. " " .. toString(risk.short or "R:?")
end

local function getUpgradeRemaining(record, epochField, sessionField)
    if type(record) ~= "table" then
        return nil
    end

    local nowEpoch = getRealEpochSeconds()
    local targetEpoch = tonumber(record[epochField])
    if nowEpoch ~= nil and targetEpoch ~= nil then
        return targetEpoch - nowEpoch
    end

    local targetSession = tonumber(record[sessionField])
    if targetSession ~= nil then
        return targetSession - (tonumber(KST._clock) or 0)
    end

    return nil
end

function getUpgradeStatus(record)
    if type(record) ~= "table" then
        return "unknown", nil, nil, nil
    end

    if record.state == "built" and record.name ~= "Divine Favor Altar" then
        return "built", nil, nil, nil
    end

    if record.state == "removing" or record.state == "removed" then
        local remaining = getUpgradeRemaining(record, "removeEndsEpoch", "removeEndsAtSessionSeconds")
        if remaining ~= nil and remaining > 0 then
            return "removing", remaining, nil, nil
        end
        return "removed", nil, nil, nil
    end

    -- Divine Favor Altar is special. Once it has charge fields, do not let a
    -- stale session buildEndsAtSessionSeconds from before /reload make it look
    -- like it is constructing again. Only treat it as construction if it has a
    -- real positive construction duration.
    if record.name == "Divine Favor Altar" and tonumber(record.maxCharges) ~= nil then
        local buildRemaining = getUpgradeRemaining(record, "buildEndsEpoch", "buildEndsAtSessionSeconds")
        if tonumber(record.durationSeconds) ~= nil and tonumber(record.durationSeconds) > 0 and buildRemaining ~= nil and buildRemaining > 0 then
            return "building", buildRemaining, nil, nil
        end

        local firstRemaining = getUpgradeRemaining(record, "firstChargeEpoch", "firstChargeAtSessionSeconds")
        local interval = tonumber(record.rechargeIntervalSeconds)
        local maxCharges = tonumber(record.maxCharges) or 3
        if interval == nil or interval <= 0 then
            return "built", nil, nil, nil
        end

        if record.divineChargesUnknown == true then
            local estimateRemaining = getUpgradeRemaining(record, "divineNextChargeEpoch", "divineNextChargeAtSessionSeconds")
            if estimateRemaining == nil then
                estimateRemaining = firstRemaining
            end
            if estimateRemaining ~= nil and interval ~= nil and interval > 0 then
                while estimateRemaining <= 0 do
                    estimateRemaining = estimateRemaining + interval
                end
            end
            return "charged-unknown", estimateRemaining, nil, nil
        end

        if firstRemaining ~= nil and firstRemaining > 0 then
            return "charging", firstRemaining, 0, nil
        end

        if tonumber(record.divineManualCharges) ~= nil then
            local charges = tonumber(record.divineManualCharges) or 0
            local nextRemaining = getUpgradeRemaining(record, "divineNextChargeEpoch", "divineNextChargeAtSessionSeconds")

            if nextRemaining ~= nil then
                while nextRemaining <= 0 and charges < maxCharges do
                    charges = charges + 1
                    nextRemaining = nextRemaining + interval
                end
                if charges >= maxCharges then
                    nextRemaining = nil
                end
            end

            if charges < 0 then charges = 0 end
            if charges > maxCharges then charges = maxCharges end

            return "charged", nextRemaining, charges, nil
        end

        if firstRemaining == nil then
            return "built", nil, maxCharges, nil
        end

        local elapsedSinceFirst = -firstRemaining
        local charges = math.floor(elapsedSinceFirst / interval) + 1
        if charges < 0 then charges = 0 end
        if charges > maxCharges then charges = maxCharges end

        local nextRemaining = nil
        if charges < maxCharges then
            nextRemaining = interval - (elapsedSinceFirst % interval)
        end

        return "charged", nextRemaining, charges, nil
    end

    local buildRemaining = getUpgradeRemaining(record, "buildEndsEpoch", "buildEndsAtSessionSeconds")
    if buildRemaining == nil then
        return "detected", nil, nil, nil
    end

    if buildRemaining > 0 then
        return "building", buildRemaining, nil, nil
    end

    return "built", nil, nil, nil
end

function cleanupCompletedRemovalUpgradesForStore(store, reason)
    if type(store) ~= "table" or type(store.upgrades) ~= "table" then
        return false
    end

    local changed = false
    for key, record in pairs(store.upgrades) do
        if type(record) == "table" then
            local status = select(1, getUpgradeStatus(record))
            if status == "removed" and tonumber(record.rank) == 0 then
                store.upgrades[key] = nil
                changed = true
            end
        end
    end

    if changed then
        store.lastUpdateAt = getEventTimeText()
        store.lastUpdateSessionSeconds = math.floor(tonumber(KST._clock) or 0)
        store.lastUpdateEpoch = getRealEpochSeconds()
        persistKeepUpgrades(reason or "cleanup-removed-r0")
    end

    return changed
end


function KST.RecordIsR0BuildingDuplicateOfRemoval(record, removingByName)
    if type(record) ~= "table" or type(removingByName) ~= "table" then
        return false
    end

    if tonumber(record.rank) ~= 0 then
        return false
    end

    if record.state ~= "building" then
        return false
    end

    local nameKey = KST.NPCNormalizeUpgradeName(record.name)
    return nameKey ~= "" and removingByName[nameKey] == true
end

function KST.BuildRemovingUpgradeNameIndex(upgrades)
    local removingByName = {}
    if type(upgrades) ~= "table" then
        return removingByName
    end

    for _, record in pairs(upgrades) do
        if type(record) == "table" and record.state == "removing" then
            local nameKey = KST.NPCNormalizeUpgradeName(record.name)
            if nameKey ~= "" then
                removingByName[nameKey] = true
            end
        end
    end

    return removingByName
end


local function buildUpgradeTooltipText(keepName)
    local store = getKeepUpgradeStore(keepName)
    local title = toString(keepName)
    if title == "" then
        title = "Keep"
    end

    if store == nil or type(store.upgrades) ~= "table" then
        return title .. "\n\nNo keep upgrades detected from chat yet."
    end

    local rows = {}
    local removingByName = KST.BuildRemovingUpgradeNameIndex(store.upgrades)
    for _, record in pairs(store.upgrades) do
        if type(record) == "table" and not KST.RecordIsR0BuildingDuplicateOfRemoval(record, removingByName) then
            rows[#rows + 1] = record
        end
    end

    table.sort(rows, function(a, b)
        local at = tonumber(a.startedSessionSeconds) or 0
        local bt = tonumber(b.startedSessionSeconds) or 0
        if at == bt then
            return toString(a.name) < toString(b.name)
        end
        return at < bt
    end)

    local lines = {}
    lines[#lines + 1] = title
    lines[#lines + 1] = "Keep upgrades detected:"

    if #rows == 0 then
        lines[#lines + 1] = "- none"
    end

    local maxLines = tonumber(KST.KEEP_UPGRADE_MAX_TOOLTIP_LINES) or 18
    local shown = 0
    for _, record in ipairs(rows) do
        shown = shown + 1
        if shown > maxLines then
            lines[#lines + 1] = "... +" .. tostring(#rows - maxLines) .. " more"
            break
        end

        local status, remaining, charges, nextChargeAt = getUpgradeStatus(record)
        local prefix = "?"
        local suffix = ""
        if status == "building" then
            if tonumber(record.rank) == 0 then
                prefix = "building R0"
            else
                prefix = "building"
            end
            suffix = " - " .. formatCountdown(remaining) .. " left"
        elseif status == "removing" then
            prefix = "removing"
            suffix = remaining ~= nil and (" - " .. formatCountdown(remaining) .. " left") or " - duration unknown"
        elseif status == "removed" then
            prefix = "removed"
            suffix = " - completed est."
        elseif status == "charging" then
            prefix = "built"
            suffix = " - first charge in " .. formatCountdown(remaining) .. " (0/" .. tostring(record.maxCharges or 3) .. ")"
        elseif status == "charged-unknown" then
            prefix = "altar"
            if remaining ~= nil then
                suffix = " - charges unknown, bad estimate, next est. " .. formatCountdown(remaining)
            else
                suffix = " - charges unknown, bad estimate"
            end
        elseif status == "charged" then
            prefix = "altar"
            if nextChargeAt ~= nil then
                suffix = " - charges " .. tostring(charges or 0) .. "/" .. tostring(record.maxCharges or 3) .. ", next " .. formatCountdown(remaining)
            else
                suffix = " - charges " .. tostring(charges or 0) .. "/" .. tostring(record.maxCharges or 3) .. " max"
            end
        elseif status == "built" then
            prefix = "built"
            suffix = " - completed est."
        else
            prefix = "detected"
        end

        lines[#lines + 1] = prefix .. " " .. toString(record.name) .. " R" .. tostring(record.rank or "?") .. suffix
    end

    if store.lastUpdateAt ~= nil then
        lines[#lines + 1] = "Last update: " .. toString(store.lastUpdateAt)
    end
    lines[#lines + 1] = "Source: chat parser"

    return table.concat(lines, "\n")
end


local function getSorGraphicTexture(suffix, fallback)
    if type(SOR_SavedSettings) == "table" and SOR_SavedSettings["GraphicSet"] ~= nil then
        local prefix = toString(SOR_SavedSettings["GraphicSet"])
        if prefix ~= "" then
            return prefix .. tostring(suffix or "")
        end
    end
    return fallback or ("1" .. tostring(suffix or ""))
end

local function setTooltipLabelText(windowName, text, r, g, b)
    if windowName == nil or windowName == "" then
        return
    end
    if type(LabelSetText) == "function" then
        pcall(LabelSetText, windowName, toWString(text or ""))
    end
    if r ~= nil and type(LabelSetTextColor) == "function" then
        pcall(LabelSetTextColor, windowName, tonumber(r) or 255, tonumber(g) or 255, tonumber(b) or 255)
    end
end

local function getTooltipIconGlyph(textureName)
    local text = toString(textureName)
    if text == "" then
        return "*", 190, 190, 190
    end
    if text:find("BlipOrd") or text:find("ObjOrd") then
        return "*", 80, 165, 255
    elseif text:find("BlipDes") or text:find("ObjDes") then
        return "*", 255, 80, 80
    elseif text:find("Lost") or text:find("Lock") then
        return "x", 180, 180, 180
    elseif text:find("Flame") then
        return "^", 255, 170, 60
    elseif text:find("SoR") then
        return "+", 220, 220, 220
    end
    return "-", 190, 190, 190
end

local function setTooltipImageTexture(windowName, textureName, w, h)
    if windowName == nil or windowName == "" then
        return
    end

    -- 0.1.35: icon windows are labels instead of DynamicImages. This avoids
    -- XML load errors on clients where SoR texture aliases like ObjUnknown,
    -- 1Alphaback or 1FrameHigh are not registered globally.
    local glyph, r, g, b = getTooltipIconGlyph(textureName)
    if type(LabelSetText) == "function" then
        pcall(LabelSetText, windowName, toWString(glyph))
    end
    if type(LabelSetTextColor) == "function" then
        pcall(LabelSetTextColor, windowName, r, g, b)
    end

    if type(WindowSetShowing) == "function" then
        pcall(WindowSetShowing, windowName, true)
    end
end

local function getRealmColor(owner)
    local ownerNumber = tonumber(owner) or 0
    if ownerNumber == 1 then
        return 80, 165, 255
    elseif ownerNumber == 2 then
        return 255, 80, 80
    end
    return 190, 190, 190
end

local function getRealmBlipTexture(owner)
    local ownerNumber = tonumber(owner) or 0
    if ownerNumber == 1 then
        return "BlipOrd"
    elseif ownerNumber == 2 then
        return "BlipDes"
    end
    return "ObjUnknown"
end

local function getRealmObjTexture(owner, removed)
    local ownerNumber = tonumber(owner) or 0
    if removed == true then
        if ownerNumber == 1 then
            return "LostOrd"
        elseif ownerNumber == 2 then
            return "LostDes"
        end
        return "ObjLock"
    end

    if ownerNumber == 1 then
        return "ObjOrd"
    elseif ownerNumber == 2 then
        return "ObjDes"
    end
    return "ObjUnknown"
end

local function getStarText(rank)
    local n = tonumber(rank) or 0
    if n <= 0 then
        return ""
    end
    local out = ""
    for _ = 1, n do
        out = out .. "*"
    end
    return out
end

local function getUpgradeRowsForTooltip(keepName, owner, keepData, zoneId, keepIndex)
    local store = getKeepUpgradeStore(keepName, keepData, zoneId, keepIndex)
    local rows = {}

    if store == nil or type(store.upgrades) ~= "table" then
        rows[#rows + 1] = {
            text = "No upgrades matched this keep.",
            texture = "ObjUnknown",
            color = { 190, 190, 190 },
        }
        return rows, store
    end

    cleanupCompletedRemovalUpgradesForStore(store, "tooltip-cleanup-removed-r0")

    local records = {}
    for _, record in pairs(store.upgrades) do
        if type(record) == "table" then
            records[#records + 1] = record
        end
    end

    table.sort(records, function(a, b)
        local priority = {
            removing = 1,
            building = 2,
            charging = 3,
            charged = 4,
            built = 5,
            detected = 6,
            removed = 7,
        }
        local as = select(1, getUpgradeStatus(a))
        local bs = select(1, getUpgradeStatus(b))
        local ap = priority[as] or 50
        local bp = priority[bs] or 50
        if ap == bp then
            local at = tonumber(a.startedSessionSeconds) or 0
            local bt = tonumber(b.startedSessionSeconds) or 0
            if at == bt then
                return toString(a.name) < toString(b.name)
            end
            return at < bt
        end
        return ap < bp
    end)

    local maxLines = tonumber(KST.KEEP_UPGRADE_MAX_TOOLTIP_LINES) or 12
    local shown = 0
    for _, record in ipairs(records) do
        shown = shown + 1
        if shown > maxLines then
            rows[#rows + 1] = {
                text = "+" .. tostring(#records - maxLines) .. " more upgrades...",
                texture = "SoRicon",
                color = { 220, 220, 220 },
            }
            break
        end

        local status, remaining, charges, _ = getUpgradeStatus(record)
        local name = toString(record.name)
        local rankText = "R" .. tostring(record.rank or "?")
        local text = name .. " " .. rankText
        local texture = "ObjUnknown"
        local color = { 230, 230, 230 }

        if status == "building" then
            text = name .. " " .. rankText .. "  building: " .. formatCountdown(remaining)
            texture = "ObjUnknown"
            if tonumber(record.rank) == 0 then
                color = { 255, 70, 70 }
            else
                color = { 255, 220, 90 }
            end
        elseif status == "removing" then
            text = name .. " " .. rankText .. "  removing: " .. (remaining ~= nil and formatCountdown(remaining) or "unknown")
            texture = "ObjLock"
            color = { 255, 140, 80 }
        elseif status == "removed" then
            text = name .. " " .. rankText .. "  removed est."
            texture = getRealmObjTexture(owner, true)
            color = { 140, 140, 140 }
        elseif status == "charging" then
            text = name .. " " .. rankText .. "  first charge: " .. formatCountdown(remaining) .. "  0/" .. tostring(record.maxCharges or 3)
            texture = getSorGraphicTexture("Flame", "1Flame")
            color = { 180, 220, 255 }
        elseif status == "charged" then
            if remaining ~= nil then
                text = name .. " " .. rankText .. "  charges " .. tostring(charges or 0) .. "/" .. tostring(record.maxCharges or 3) .. "  next: " .. formatCountdown(remaining)
            else
                text = name .. " " .. rankText .. "  charges " .. tostring(charges or 0) .. "/" .. tostring(record.maxCharges or 3) .. " max"
            end
            texture = getSorGraphicTexture("Flame", "1Flame")
            color = { 120, 210, 255 }
        elseif status == "built" then
            text = name .. " " .. rankText .. "  completed est."
            texture = getRealmObjTexture(owner, false)
            color = { 120, 220, 120 }
        else
            text = name .. " " .. rankText .. "  detected"
            texture = "ObjUnknown"
            color = { 210, 210, 210 }
        end

        rows[#rows + 1] = {
            text = text,
            texture = texture,
            color = color,
        }
    end

    if #rows == 0 then
        rows[#rows + 1] = {
            text = "No keep upgrades detected from chat yet.",
            texture = "ObjUnknown",
            color = { 190, 190, 190 },
        }
    end

    return rows, store
end


function getKSTContextMenuPressedIndex()
    local mouseWin = nil
    if type(SystemData) == "table" and type(SystemData.MouseOverWindow) == "table" then
        mouseWin = toString(SystemData.MouseOverWindow.name)
    end
    if (mouseWin == nil or mouseWin == "") and type(SystemData) == "table" and type(SystemData.ActiveWindow) == "table" then
        mouseWin = toString(SystemData.ActiveWindow.name)
    end

    local index = nil
    if mouseWin ~= nil then
        index = string.match(mouseWin, "^EA_Window_ContextMenu[0-9]+DefaultItem([0-9]+).*")
    end
    return tonumber(index)
end

function addKSTContextMenuItem(label, action)
    if type(KST._shareMenuItems) ~= "table" then
        KST._shareMenuItems = {}
    end
    KST._shareMenuItems[#KST._shareMenuItems + 1] = action
    EA_Window_ContextMenu.AddMenuItem(toWString(label), KeepSupplyTimer.OnShareContextMenuItem, false, true)
end

function KeepSupplyTimer.OnShareContextMenuItem()
    local index = getKSTContextMenuPressedIndex()
    local item = type(KST._shareMenuItems) == "table" and KST._shareMenuItems[index] or nil
    if type(item) == "table" and type(item.fn) == "function" then
        item.fn(item)
    end
end

function getKeepUpgradeHoverDataForContextMenu()
    local windowName = getMouseOverWindowName()
    local data = nil

    if windowName ~= nil and type(KST._keepUpgradeHoverWindows) == "table" then
        data = KST._keepUpgradeHoverWindows[windowName]
        if type(data) ~= "table" then
            data = KST._keepUpgradeHoverWindows[toString(windowName):gsub("Hitbox$", "")]
        end
    end

    if type(data) == "table" then
        return data
    end

    local current = KST._currentUpgradeTooltip
    if type(current) == "table" and current.zoneId ~= nil and current.keepIndex ~= nil then
        return current
    end

    return nil
end

function getKeepShareContext(zoneId, keepIndex)
    local keeps = getKeepsForZone(zoneId)
    local keepData = type(keeps) == "table" and type(keeps[keepIndex]) == "table" and keeps[keepIndex] or nil
    local keepId = tonumber(keepData and keepData.ID)
    local keepName = getKeepNameText(keepId, keepIndex)
    local store = getKeepUpgradeStore(keepName, keepData, zoneId, keepIndex)
    cleanupCompletedRemovalUpgradesForStore(store, "share-menu-cleanup-removed-r0")

    local records = {}
    if type(store) == "table" and type(store.upgrades) == "table" then
        local removingByName = KST.BuildRemovingUpgradeNameIndex(store.upgrades)
        for key, record in pairs(store.upgrades) do
            if type(record) == "table" and not KST.RecordIsR0BuildingDuplicateOfRemoval(record, removingByName) then
                record._shareKey = toString(key)
                records[#records + 1] = record
            end
        end
    end

    table.sort(records, function(a, b)
        local an = toString(a.name) .. tostring(a.rank or "")
        local bn = toString(b.name) .. tostring(b.rank or "")
        return an < bn
    end)

    return {
        zoneId = tonumber(zoneId),
        keepIndex = tonumber(keepIndex),
        keepData = keepData,
        keepName = keepName,
        store = store,
        records = records,
    }
end

function getShareChannelByKey(key)
    local wanted = toString(key)
    for _, channel in ipairs(KST.SHARE_CHANNELS or {}) do
        if channel.key == wanted then
            return channel
        end
    end
    return (KST.SHARE_CHANNELS or {})[1]
end

function getShareStatusText(record)
    local status, remaining, charges, _ = getUpgradeStatus(record)
    local stateText = toString(status)

    if status == "building" then
        stateText = "building " .. formatCountdown(remaining)
    elseif status == "removing" then
        stateText = "removing " .. formatCountdown(remaining)
    elseif status == "charging" then
        stateText = "first charge " .. formatCountdown(remaining) .. " 0/" .. tostring(record.maxCharges or 3)
    elseif status == "charged-unknown" then
        if remaining ~= nil then
            stateText = "charges unknown next-est " .. formatCountdown(remaining)
        else
            stateText = "charges unknown"
        end
    elseif status == "charged" then
        if remaining ~= nil then
            stateText = "charges " .. tostring(charges or 0) .. "/" .. tostring(record.maxCharges or 3) .. " next " .. formatCountdown(remaining)
        else
            stateText = "charges " .. tostring(charges or record.maxCharges or 3) .. "/" .. tostring(record.maxCharges or 3) .. " max"
        end
    elseif status == "built" then
        stateText = "built"
    elseif status == "removed" then
        stateText = "removed"
    elseif status == "detected" then
        stateText = "detected"
    end

    return stateText
end

function getShareUpgradeSummary(record)
    if type(record) ~= "table" then
        return "unknown upgrade"
    end
    return toString(record.name) .. " R" .. tostring(record.rank or "?") .. " " .. getShareStatusText(record)
end

function getShareContextNames(context)
    local zoneName = getZoneNameText(context and context.zoneId)
    local keepName = toString(context and context.keepName or "?")
    local store = type(context) == "table" and context.store or nil
    local canonicalId = nil
    if type(store) == "table" then
        canonicalId = tonumber(store.canonicalKeepId)
    end
    if canonicalId == nil then
        canonicalId = getCanonicalKeepIdFromName(keepName)
    end
    local canonicalInfo = canonicalId ~= nil and KST.CANONICAL_KEEPS[canonicalId] or nil
    if type(canonicalInfo) == "table" then
        keepName = canonicalInfo.name
        zoneName = canonicalInfo.zone or zoneName
    end
    return zoneName, keepName
end

function getShareUpgradeMessage(context, record)
    local zoneName, keepName = getShareContextNames(context)
    return toString(KST.SHARE_PREFIX) .. " " .. toString(zoneName) .. " | " .. keepName .. " | This keep has this upgrade: " .. getShareUpgradeSummary(record)
end

function getShareAllUpgradesMessage(context)
    local zoneName, keepName = getShareContextNames(context)
    local summaries = {}

    if type(context) == "table" and type(context.records) == "table" then
        for _, record in ipairs(context.records) do
            summaries[#summaries + 1] = getShareUpgradeSummary(record)
        end
    end

    local summaryText = table.concat(summaries, "; ")
    if summaryText == "" then
        summaryText = "none"
    end

    -- Human-readable for players without the addon, but still machine-parsable
    -- for players with KeepSupplyTimer.
    return toString(KST.SHARE_PREFIX) .. " " .. toString(zoneName) .. " | " .. keepName .. " | This keep has the following upgrades: " .. summaryText
end

function sendKSTChatCommand(commandText)
    local text = toString(commandText)
    if text == "" then
        return false
    end

    if type(SendChatText) == "function" then
        local ok = pcall(SendChatText, toWString(text), L"")
        if ok then
            return true
        end
        ok = pcall(SendChatText, toWString(text))
        if ok then
            return true
        end
    end

    if type(EA_ChatWindow) == "table" then
        if type(EA_ChatWindow.SendText) == "function" then
            local ok = pcall(EA_ChatWindow.SendText, toWString(text))
            if ok then
                return true
            end
        end
        if type(EA_ChatWindow.OnSendText) == "function" then
            local ok = pcall(EA_ChatWindow.OnSendText, toWString(text))
            if ok then
                return true
            end
        end
    end

    return false
end

function shareKSTMessage(channelKey, message)
    local channel = getShareChannelByKey(channelKey)
    if channel == nil then
        chatPrint("Share failed: unknown channel.")
        return false
    end

    local command = toString(channel.slash) .. " " .. toString(message)
    local ok = sendKSTChatCommand(command)
    if ok then
        chatPrint("Shared to " .. toString(channel.slash) .. ": " .. toString(message))
    else
        chatPrint("Unable to send chat automatically. Copy/send: " .. command)
    end
    return ok
end

function shareKSTRecordToChannel(channelKey, context, record)
    if type(record) ~= "table" then
        chatPrint("No upgrade selected to share.")
        return
    end
    shareKSTMessage(channelKey, getShareUpgradeMessage(context, record))
end

function shareKSTAllToChannel(channelKey, context)
    if type(context) ~= "table" or type(context.records) ~= "table" or #context.records == 0 then
        chatPrint("No upgrades matched this keep to share.")
        return
    end

    shareKSTMessage(channelKey, getShareAllUpgradesMessage(context))
end

function addKSTContextMenuCallbackItem(label, callback, hasSubMenu)
    if type(callback) ~= "function" then
        callback = KeepSupplyTimer.MenuNoop
    end
    EA_Window_ContextMenu.AddMenuItem(toWString(label), callback, false, false)
end

function KeepSupplyTimer.MenuNoop()
end

function shareKSTAllAndRemember(channelKey)
    shareKSTAllToChannel(channelKey, KST._shareContext)
    if KeepSupplyTimerSettings ~= nil then
        KeepSupplyTimerSettings.shareChannel = channelKey
    end
end

function KeepSupplyTimer.ShareAllRegion() shareKSTAllAndRemember("region1") end
function KeepSupplyTimer.ShareAllT4() shareKSTAllAndRemember("t4") end
function KeepSupplyTimer.ShareAllWarband() shareKSTAllAndRemember("warband") end
function KeepSupplyTimer.ShareAllGuild() shareKSTAllAndRemember("guild") end
function KeepSupplyTimer.ShareAllParty() shareKSTAllAndRemember("party") end

function KST.SetSelectedShareChannel(channelKey)
    local channel = getShareChannelByKey(channelKey)
    if type(channel) ~= "table" then
        chatPrint("Unknown share channel.")
        return
    end

    KST._shareSelectedChannel = channel.key
    if KeepSupplyTimerSettings ~= nil then
        KeepSupplyTimerSettings.shareChannel = channel.key
    end
    chatPrint("Selected upgrade share channel set to " .. toString(channel.slash) .. ".")
end

function KeepSupplyTimer.SetSelectedShareRegion() KST.SetSelectedShareChannel("region1") end
function KeepSupplyTimer.SetSelectedShareT4() KST.SetSelectedShareChannel("t4") end
function KeepSupplyTimer.SetSelectedShareWarband() KST.SetSelectedShareChannel("warband") end
function KeepSupplyTimer.SetSelectedShareGuild() KST.SetSelectedShareChannel("guild") end
function KeepSupplyTimer.SetSelectedShareParty() KST.SetSelectedShareChannel("party") end

function KST.OpenSelectedShareChannelMenu(channelKey)
    if type(EA_Window_ContextMenu) ~= "table" or type(EA_Window_ContextMenu.CreateContextMenu) ~= "function" then
        chatPrint("Context menu is not available.")
        return
    end

    if type(KST._shareContext) ~= "table" then
        chatPrint("No keep selected for sharing.")
        return
    end

    local channel = getShareChannelByKey(channelKey)
    if type(channel) ~= "table" then
        chatPrint("Unknown share channel.")
        return
    end

    KST._shareSelectedChannel = channel.key
    if KeepSupplyTimerSettings ~= nil then
        KeepSupplyTimerSettings.shareChannel = channel.key
    end

    KST._shareRecordList = {}
    KST._shareSelectedChannelByIndex = {}

    EA_Window_ContextMenu.CreateContextMenu(KST.SHARE_CONTEXT_MENU_NAME)
    addKSTContextMenuCallbackItem("== Selected upgrades: " .. toString(channel.label) .. " ==", KeepSupplyTimer.MenuNoop, false)
    addKSTSelectedUpgradeItemsForChannel(channel.key, channel.slash)
    addKSTContextMenuCallbackItem("------------------------------", KeepSupplyTimer.MenuNoop, false)
    addKSTContextMenuCallbackItem("Back to keep upgrade menu", KeepSupplyTimer.ReopenKeepShareMenu, false)
    addKSTContextMenuCallbackItem("Print share preview locally", KeepSupplyTimer.PrintSharePreview, false)
    EA_Window_ContextMenu.Finalize()
end

function KeepSupplyTimer.OpenSelectedShareRegion() KST.OpenSelectedShareChannelMenu("region1") end
function KeepSupplyTimer.OpenSelectedShareT4() KST.OpenSelectedShareChannelMenu("t4") end
function KeepSupplyTimer.OpenSelectedShareWarband() KST.OpenSelectedShareChannelMenu("warband") end
function KeepSupplyTimer.OpenSelectedShareGuild() KST.OpenSelectedShareChannelMenu("guild") end
function KeepSupplyTimer.OpenSelectedShareParty() KST.OpenSelectedShareChannelMenu("party") end

function KeepSupplyTimer.ReopenKeepShareMenu()
    if type(KST._shareContext) ~= "table" or KST._shareContext.zoneId == nil or KST._shareContext.keepIndex == nil then
        chatPrint("No keep selected for sharing.")
        return
    end
    openKSTKeepShareMenu(KST._shareContext.zoneId, KST._shareContext.keepIndex)
end


function KeepSupplyTimer.ShareSelectedUpgrade01() shareKSTSelectedRecordIndex(1) end
function KeepSupplyTimer.ShareSelectedUpgrade02() shareKSTSelectedRecordIndex(2) end
function KeepSupplyTimer.ShareSelectedUpgrade03() shareKSTSelectedRecordIndex(3) end
function KeepSupplyTimer.ShareSelectedUpgrade04() shareKSTSelectedRecordIndex(4) end
function KeepSupplyTimer.ShareSelectedUpgrade05() shareKSTSelectedRecordIndex(5) end
function KeepSupplyTimer.ShareSelectedUpgrade06() shareKSTSelectedRecordIndex(6) end
function KeepSupplyTimer.ShareSelectedUpgrade07() shareKSTSelectedRecordIndex(7) end
function KeepSupplyTimer.ShareSelectedUpgrade08() shareKSTSelectedRecordIndex(8) end
function KeepSupplyTimer.ShareSelectedUpgrade09() shareKSTSelectedRecordIndex(9) end
function KeepSupplyTimer.ShareSelectedUpgrade10() shareKSTSelectedRecordIndex(10) end
function KeepSupplyTimer.ShareSelectedUpgrade11() shareKSTSelectedRecordIndex(11) end
function KeepSupplyTimer.ShareSelectedUpgrade12() shareKSTSelectedRecordIndex(12) end
function KeepSupplyTimer.ShareSelectedUpgrade13() shareKSTSelectedRecordIndex(13) end
function KeepSupplyTimer.ShareSelectedUpgrade14() shareKSTSelectedRecordIndex(14) end
function KeepSupplyTimer.ShareSelectedUpgrade15() shareKSTSelectedRecordIndex(15) end
function KeepSupplyTimer.ShareSelectedUpgrade16() shareKSTSelectedRecordIndex(16) end
function KeepSupplyTimer.ShareSelectedUpgrade17() shareKSTSelectedRecordIndex(17) end
function KeepSupplyTimer.ShareSelectedUpgrade18() shareKSTSelectedRecordIndex(18) end
function KeepSupplyTimer.ShareSelectedUpgrade19() shareKSTSelectedRecordIndex(19) end
function KeepSupplyTimer.ShareSelectedUpgrade20() shareKSTSelectedRecordIndex(20) end
function KeepSupplyTimer.ShareSelectedUpgrade21() shareKSTSelectedRecordIndex(21) end
function KeepSupplyTimer.ShareSelectedUpgrade22() shareKSTSelectedRecordIndex(22) end
function KeepSupplyTimer.ShareSelectedUpgrade23() shareKSTSelectedRecordIndex(23) end
function KeepSupplyTimer.ShareSelectedUpgrade24() shareKSTSelectedRecordIndex(24) end
function KeepSupplyTimer.ShareSelectedUpgrade25() shareKSTSelectedRecordIndex(25) end
function KeepSupplyTimer.ShareSelectedUpgrade26() shareKSTSelectedRecordIndex(26) end
function KeepSupplyTimer.ShareSelectedUpgrade27() shareKSTSelectedRecordIndex(27) end
function KeepSupplyTimer.ShareSelectedUpgrade28() shareKSTSelectedRecordIndex(28) end
function KeepSupplyTimer.ShareSelectedUpgrade29() shareKSTSelectedRecordIndex(29) end
function KeepSupplyTimer.ShareSelectedUpgrade30() shareKSTSelectedRecordIndex(30) end
function KeepSupplyTimer.ShareSelectedUpgrade31() shareKSTSelectedRecordIndex(31) end
function KeepSupplyTimer.ShareSelectedUpgrade32() shareKSTSelectedRecordIndex(32) end
function KeepSupplyTimer.ShareSelectedUpgrade33() shareKSTSelectedRecordIndex(33) end
function KeepSupplyTimer.ShareSelectedUpgrade34() shareKSTSelectedRecordIndex(34) end
function KeepSupplyTimer.ShareSelectedUpgrade35() shareKSTSelectedRecordIndex(35) end
function KeepSupplyTimer.ShareSelectedUpgrade36() shareKSTSelectedRecordIndex(36) end
function KeepSupplyTimer.ShareSelectedUpgrade37() shareKSTSelectedRecordIndex(37) end
function KeepSupplyTimer.ShareSelectedUpgrade38() shareKSTSelectedRecordIndex(38) end
function KeepSupplyTimer.ShareSelectedUpgrade39() shareKSTSelectedRecordIndex(39) end
function KeepSupplyTimer.ShareSelectedUpgrade40() shareKSTSelectedRecordIndex(40) end

function getShareSelectedUpgradeCallback(index)
    local callbacks = {
        KeepSupplyTimer.ShareSelectedUpgrade01,
        KeepSupplyTimer.ShareSelectedUpgrade02,
        KeepSupplyTimer.ShareSelectedUpgrade03,
        KeepSupplyTimer.ShareSelectedUpgrade04,
        KeepSupplyTimer.ShareSelectedUpgrade05,
        KeepSupplyTimer.ShareSelectedUpgrade06,
        KeepSupplyTimer.ShareSelectedUpgrade07,
        KeepSupplyTimer.ShareSelectedUpgrade08,
        KeepSupplyTimer.ShareSelectedUpgrade09,
        KeepSupplyTimer.ShareSelectedUpgrade10,
        KeepSupplyTimer.ShareSelectedUpgrade11,
        KeepSupplyTimer.ShareSelectedUpgrade12,
        KeepSupplyTimer.ShareSelectedUpgrade13,
        KeepSupplyTimer.ShareSelectedUpgrade14,
        KeepSupplyTimer.ShareSelectedUpgrade15,
        KeepSupplyTimer.ShareSelectedUpgrade16,
        KeepSupplyTimer.ShareSelectedUpgrade17,
        KeepSupplyTimer.ShareSelectedUpgrade18,
        KeepSupplyTimer.ShareSelectedUpgrade19,
        KeepSupplyTimer.ShareSelectedUpgrade20,
        KeepSupplyTimer.ShareSelectedUpgrade21,
        KeepSupplyTimer.ShareSelectedUpgrade22,
        KeepSupplyTimer.ShareSelectedUpgrade23,
        KeepSupplyTimer.ShareSelectedUpgrade24,
        KeepSupplyTimer.ShareSelectedUpgrade25,
        KeepSupplyTimer.ShareSelectedUpgrade26,
        KeepSupplyTimer.ShareSelectedUpgrade27,
        KeepSupplyTimer.ShareSelectedUpgrade28,
        KeepSupplyTimer.ShareSelectedUpgrade29,
        KeepSupplyTimer.ShareSelectedUpgrade30,
        KeepSupplyTimer.ShareSelectedUpgrade31,
        KeepSupplyTimer.ShareSelectedUpgrade32,
        KeepSupplyTimer.ShareSelectedUpgrade33,
        KeepSupplyTimer.ShareSelectedUpgrade34,
        KeepSupplyTimer.ShareSelectedUpgrade35,
        KeepSupplyTimer.ShareSelectedUpgrade36,
        KeepSupplyTimer.ShareSelectedUpgrade37,
        KeepSupplyTimer.ShareSelectedUpgrade38,
        KeepSupplyTimer.ShareSelectedUpgrade39,
        KeepSupplyTimer.ShareSelectedUpgrade40,
    }
    return callbacks[tonumber(index)]
end

function addKSTSelectedUpgradeItemsForChannel(channelKey, channelLabel)
    local context = KST._shareContext
    if type(context) ~= "table" or type(context.records) ~= "table" or #context.records == 0 then
        addKSTContextMenuCallbackItem("  " .. channelLabel .. " - no upgrades", KeepSupplyTimer.MenuNoop, false)
        return
    end

    local maxPerChannel = 10
    local shown = 0
    for _, record in ipairs(context.records) do
        shown = shown + 1
        if shown > maxPerChannel then
            break
        end

        local index = #KST._shareRecordList + 1
        KST._shareRecordList[index] = record
        KST._shareSelectedChannelByIndex[index] = channelKey
        local callback = getShareSelectedUpgradeCallback(index)
        if type(callback) == "function" then
            addKSTContextMenuCallbackItem("  " .. channelLabel .. " - " .. getShareUpgradeSummary(record), callback, false)
        end
    end

    if #context.records > maxPerChannel then
        addKSTContextMenuCallbackItem("  " .. channelLabel .. " - +" .. tostring(#context.records - maxPerChannel) .. " more not shown", KeepSupplyTimer.MenuNoop, false)
    end
end

function addKSTSelectedUpgradeItemsCompact()
    local context = KST._shareContext
    local channelKey = toString(KST._shareSelectedChannel)
    local channel = getShareChannelByKey(channelKey)
    local channelLabel = toString(channel and channel.slash or "?")

    if type(context) ~= "table" or type(context.records) ~= "table" or #context.records == 0 then
        addKSTContextMenuCallbackItem("  " .. channelLabel .. " - no upgrades", KeepSupplyTimer.MenuNoop, false)
        return
    end

    local maxShown = 12
    local shown = 0
    for _, record in ipairs(context.records) do
        shown = shown + 1
        if shown > maxShown then
            break
        end

        local index = #KST._shareRecordList + 1
        KST._shareRecordList[index] = record
        KST._shareSelectedChannelByIndex[index] = channelKey
        local callback = getShareSelectedUpgradeCallback(index)
        if type(callback) == "function" then
            addKSTContextMenuCallbackItem("  " .. channelLabel .. " - " .. getShareUpgradeSummary(record), callback, false)
        end
    end

    if #context.records > maxShown then
        addKSTContextMenuCallbackItem("  " .. channelLabel .. " - +" .. tostring(#context.records - maxShown) .. " more not shown", KeepSupplyTimer.MenuNoop, false)
    end
end

function shareKSTSelectedRecordIndex(index)
    local numberIndex = tonumber(index)
    local record = type(KST._shareRecordList) == "table" and KST._shareRecordList[numberIndex] or nil
    local channelKey = type(KST._shareSelectedChannelByIndex) == "table" and KST._shareSelectedChannelByIndex[numberIndex] or KST._shareSelectedChannel
    if type(record) ~= "table" or channelKey == nil then
        chatPrint("No selected upgrade to share.")
        return
    end

    shareKSTRecordToChannel(channelKey, KST._shareContext, record)
    if KeepSupplyTimerSettings ~= nil then
        KeepSupplyTimerSettings.shareChannel = channelKey
    end
end

function KeepSupplyTimer.PrintSharePreview()
    if type(KST._shareContext) ~= "table" or type(KST._shareContext.records) ~= "table" or #KST._shareContext.records == 0 then
        chatPrint("No upgrades matched this keep.")
    else
        chatPrint(getShareAllUpgradesMessage(KST._shareContext))
    end
end


function KST.IsNPCUpgradeWindowOpenForRead()
    local root = toString(KST.NPC_UPGRADE_WINDOW)
    if not windowExists(root) then
        return false, "NPC upgrade window is not open."
    end

    local showing = KST.NPCSafeCallOne("WindowGetShowing", root)
    if showing ~= true then
        return false, "NPC upgrade window is not visible."
    end

    return true, nil
end

function KST.GetContextKeepOwnerId(context)
    local keepData = type(context) == "table" and context.keepData or nil
    if type(keepData) ~= "table" then
        return nil
    end

    return tonumber(keepData.Owner)
        or tonumber(keepData.owner)
        or tonumber(keepData.Realm)
        or tonumber(keepData.realm)
        or tonumber(keepData.realmId)
        or tonumber(keepData.RealmId)
        or tonumber(keepData.ownerId)
        or tonumber(keepData.OwnerId)
        or tonumber(keepData.OwnedBy)
end


function KST.NormalizeGuildName(value)
    local text = string.lower(toString(value))
    text = string.gsub(text, "^%s+", "")
    text = string.gsub(text, "%s+$", "")
    text = string.gsub(text, "[\226\128\153\226\128\156\226\128\157]", "'")
    text = string.gsub(text, "[^%w]+", "")
    return text
end

function KST.GetPlayerGuildName()
    local candidates = {}

    if type(GameData) == "table" then
        if type(GameData.Player) == "table" then
            candidates[#candidates + 1] = GameData.Player.guildName
            candidates[#candidates + 1] = GameData.Player.GuildName
            candidates[#candidates + 1] = GameData.Player.guild
            candidates[#candidates + 1] = GameData.Player.Guild
            candidates[#candidates + 1] = GameData.Player.guild_name
        end
        if type(GameData.Guild) == "table" then
            candidates[#candidates + 1] = GameData.Guild.name
            candidates[#candidates + 1] = GameData.Guild.Name
            candidates[#candidates + 1] = GameData.Guild.guildName
            candidates[#candidates + 1] = GameData.Guild.GuildName
        end
    end

    if type(SystemData) == "table" then
        if type(SystemData.Player) == "table" then
            candidates[#candidates + 1] = SystemData.Player.guildName
            candidates[#candidates + 1] = SystemData.Player.GuildName
            candidates[#candidates + 1] = SystemData.Player.guild
            candidates[#candidates + 1] = SystemData.Player.Guild
        end
        if type(SystemData.Guild) == "table" then
            candidates[#candidates + 1] = SystemData.Guild.name
            candidates[#candidates + 1] = SystemData.Guild.Name
            candidates[#candidates + 1] = SystemData.Guild.guildName
            candidates[#candidates + 1] = SystemData.Guild.GuildName
        end
    end

    local functionNames = {
        "GetPlayerGuildName",
        "GetGuildName",
        "GetMyGuildName",
        "GetGuild",
    }

    for _, functionName in ipairs(functionNames) do
        local fn = _G and _G[functionName] or nil
        if type(fn) == "function" then
            local ok, value = pcall(fn)
            if ok then
                candidates[#candidates + 1] = value
            end
        end
    end

    for _, value in ipairs(candidates) do
        local text = toString(value)
        local normalized = KST.NormalizeGuildName(text)
        if text ~= "" and normalized ~= "" and normalized ~= "unguilded" and normalized ~= "noguild" and normalized ~= "nil" and normalized ~= "0" then
            return text
        end
    end

    return nil
end

function KST.ContextKeepMatchesPlayerGuild(context)
    local claim = getKeepClaimText(type(context) == "table" and context.keepData or nil)
    if not isKeepClaimed(claim) then
        return false, claim, nil, "not_claimed"
    end

    local playerGuild = KST.GetPlayerGuildName()
    if playerGuild == nil or playerGuild == "" then
        return false, claim, nil, "player_guild_unknown"
    end

    if KST.NormalizeGuildName(claim) ~= KST.NormalizeGuildName(playerGuild) then
        return false, claim, playerGuild, "guild_mismatch"
    end

    return true, claim, playerGuild, nil
end



function KST.NormalizeZoneName(value)
    local text = string.lower(toString(value))
    text = string.gsub(text, "^%s+", "")
    text = string.gsub(text, "%s+$", "")
    text = string.gsub(text, "[\226\128\153\226\128\156\226\128\157]", "'")
    text = string.gsub(text, "[^%w]+", "")
    return text
end

function KST.GetCurrentPlayerZoneId()
    local candidates = {}

    if type(GameData) == "table" then
        if type(GameData.Player) == "table" then
            candidates[#candidates + 1] = GameData.Player.zone
            candidates[#candidates + 1] = GameData.Player.zoneId
            candidates[#candidates + 1] = GameData.Player.zoneID
            candidates[#candidates + 1] = GameData.Player.Zone
            candidates[#candidates + 1] = GameData.Player.ZoneId
            candidates[#candidates + 1] = GameData.Player.ZoneID
            candidates[#candidates + 1] = GameData.Player.map
            candidates[#candidates + 1] = GameData.Player.mapId
            candidates[#candidates + 1] = GameData.Player.mapID
        end
        candidates[#candidates + 1] = GameData.PlayerZone
        candidates[#candidates + 1] = GameData.PlayerZoneId
        candidates[#candidates + 1] = GameData.PlayerZoneID
        candidates[#candidates + 1] = GameData.CurrentZone
        candidates[#candidates + 1] = GameData.CurrentZoneId
        candidates[#candidates + 1] = GameData.CurrentZoneID
    end

    if type(SystemData) == "table" then
        if type(SystemData.Player) == "table" then
            candidates[#candidates + 1] = SystemData.Player.zone
            candidates[#candidates + 1] = SystemData.Player.zoneId
            candidates[#candidates + 1] = SystemData.Player.zoneID
            candidates[#candidates + 1] = SystemData.Player.Zone
            candidates[#candidates + 1] = SystemData.Player.ZoneId
            candidates[#candidates + 1] = SystemData.Player.ZoneID
        end
        candidates[#candidates + 1] = SystemData.CurrentZone
        candidates[#candidates + 1] = SystemData.CurrentZoneId
        candidates[#candidates + 1] = SystemData.CurrentZoneID
    end

    local functionNames = {
        "GetCurrentZone",
        "GetCurrentZoneId",
        "GetCurrentZoneID",
        "GetPlayerZone",
        "GetPlayerZoneId",
        "GetPlayerZoneID",
        "GetZoneId",
        "GetZoneID",
        "GetMapZone",
        "GetMapZoneId",
        "GetMapZoneID",
    }

    for _, value in ipairs(candidates) do
        local zoneId = tonumber(value)
        if zoneId ~= nil and zoneId > 0 then
            return zoneId
        end
    end

    for _, functionName in ipairs(functionNames) do
        local fn = _G and _G[functionName] or nil
        if type(fn) == "function" then
            local ok, value = pcall(fn)
            if ok then
                local zoneId = tonumber(value)
                if zoneId ~= nil and zoneId > 0 then
                    return zoneId
                end
            end
        end
    end

    return nil
end

function KST.GetCurrentPlayerZoneName()
    local candidates = {}

    if type(GameData) == "table" then
        if type(GameData.Player) == "table" then
            candidates[#candidates + 1] = GameData.Player.zoneName
            candidates[#candidates + 1] = GameData.Player.ZoneName
            candidates[#candidates + 1] = GameData.Player.mapName
            candidates[#candidates + 1] = GameData.Player.MapName
        end
        candidates[#candidates + 1] = GameData.CurrentZoneName
        candidates[#candidates + 1] = GameData.PlayerZoneName
    end

    if type(SystemData) == "table" then
        if type(SystemData.Player) == "table" then
            candidates[#candidates + 1] = SystemData.Player.zoneName
            candidates[#candidates + 1] = SystemData.Player.ZoneName
        end
        candidates[#candidates + 1] = SystemData.CurrentZoneName
    end

    local functionNames = {
        "GetCurrentZoneName",
        "GetPlayerZoneName",
        "GetZoneName",
    }

    for _, value in ipairs(candidates) do
        local text = toString(value)
        if text ~= "" and KST.NormalizeZoneName(text) ~= "" then
            return text
        end
    end

    for _, functionName in ipairs(functionNames) do
        local fn = _G and _G[functionName] or nil
        if type(fn) == "function" then
            local ok, value = pcall(fn)
            if ok then
                local text = toString(value)
                if text ~= "" and KST.NormalizeZoneName(text) ~= "" then
                    return text
                end
            end
        end
    end

    return nil
end

function KST.ContextKeepIsInCurrentPlayerZone(context)
    local contextZoneId = tonumber(type(context) == "table" and context.zoneId or nil)
    local contextZoneName = getZoneNameText(contextZoneId)
    local currentZoneId = KST.GetCurrentPlayerZoneId()

    if currentZoneId ~= nil and contextZoneId ~= nil then
        if currentZoneId == contextZoneId then
            return true, currentZoneId, contextZoneId, nil, contextZoneName
        end
        return false, currentZoneId, contextZoneId, nil, contextZoneName
    end

    local currentZoneName = KST.GetCurrentPlayerZoneName()
    if currentZoneName ~= nil and currentZoneName ~= "" and contextZoneName ~= nil and contextZoneName ~= "" then
        if KST.NormalizeZoneName(currentZoneName) == KST.NormalizeZoneName(contextZoneName) then
            return true, currentZoneId, contextZoneId, currentZoneName, contextZoneName
        end
        return false, currentZoneId, contextZoneId, currentZoneName, contextZoneName
    end

    return false, currentZoneId, contextZoneId, currentZoneName, contextZoneName
end


function KST.ValidateContextKeepForNPCRead(context)
    if type(context) ~= "table" or context.keepName == nil or context.keepName == "" then
        return false, "No keep selected for NPC upgrade read."
    end

    local okWindow, windowReason = KST.IsNPCUpgradeWindowOpenForRead()
    if not okWindow then
        return false, windowReason
    end

    local playerRealm = getPlayerRealmId()
    local owner = KST.GetContextKeepOwnerId(context)
    if playerRealm ~= nil and owner ~= nil and owner ~= playerRealm then
        return false, "Refused: selected keep is not owned by your realm."
    end

    local claim = getKeepClaimText(context.keepData)
    if not isKeepClaimed(claim) then
        return false, "Refused: selected keep is not claimed by a guild."
    end

    local playerGuild = KST.GetPlayerGuildName()
    if playerGuild ~= nil and playerGuild ~= "" and KST.NormalizeGuildName(playerGuild) ~= KST.NormalizeGuildName(claim) then
        KST.SafeAppendFileLogControlLine("[KST_NPC_GUILD_WARNING] claim=" .. toString(claim) .. " playerGuild=" .. toString(playerGuild) .. " action=allowed_because_npc_window_is_open")
    end

    local sameZone, currentZoneId, contextZoneId, currentZoneName, contextZoneName = KST.ContextKeepIsInCurrentPlayerZone(context)
    if not sameZone then
        return false, "Refused: selected keep is not in your current zone. Current zone="
            .. toString(currentZoneName or currentZoneId or "?")
            .. ", selected zone=" .. toString(contextZoneName or contextZoneId or "?") .. "."
    end

    return true, nil
end


function KST.MemoryResetNormalize(value)
    return normalizeKeepLooseKey(value)
end

function KST.MemoryResetAddKey(keys, value)
    local key = KST.MemoryResetNormalize(value)
    if key ~= "" then
        keys[key] = true
    end

    local base = normalizeKeepBaseKey(value)
    if base ~= "" then
        keys[base] = true
    end
end

function KST.MemoryResetGetCanonicalId(keepName, keepId)
    local id = tonumber(keepId)
    if id ~= nil and type(KST.CANONICAL_KEEPS) == "table" and KST.CANONICAL_KEEPS[id] ~= nil then
        return id
    end
    return getCanonicalKeepIdFromName(keepName)
end

function KST.MemoryResetBuildTarget(context)
    if type(context) ~= "table" then
        return nil
    end

    local keepName = toString(context.keepName)
    if keepName == "" then
        return nil
    end

    local keepData = type(context.keepData) == "table" and context.keepData or nil
    local keepId = tonumber(keepData and keepData.ID) or tonumber(context.keepId)
    local zoneId = tonumber(context.zoneId)
    local keepIndex = tonumber(context.keepIndex)
    local canonicalId = KST.MemoryResetGetCanonicalId(keepName, keepId)
    local keys = {}

    KST.MemoryResetAddKey(keys, keepName)

    if keepId ~= nil then
        local nameFromId = getKeepNameText(keepId, keepIndex)
        KST.MemoryResetAddKey(keys, nameFromId)
    end

    if canonicalId ~= nil and type(KST.CANONICAL_KEEPS) == "table" then
        local info = KST.CANONICAL_KEEPS[tonumber(canonicalId)]
        if type(info) == "table" then
            KST.MemoryResetAddKey(keys, info.name)
            KST.MemoryResetAddKey(keys, info.zone)
            if type(info.aliases) == "table" then
                for _, alias in ipairs(info.aliases) do
                    KST.MemoryResetAddKey(keys, alias)
                end
            end
        end
    end

    return {
        keepName = keepName,
        keepId = keepId,
        zoneId = zoneId,
        keepIndex = keepIndex,
        canonicalId = canonicalId,
        keys = keys,
    }
end

function KST.MemoryResetStoreMatches(store, key, target)
    if type(store) ~= "table" or type(target) ~= "table" then
        return false
    end

    if key ~= nil and target.keys[KST.MemoryResetNormalize(key)] == true then
        return true
    end

    local storeKeepId = tonumber(store.keepId)
    if target.keepId ~= nil and storeKeepId ~= nil and target.keepId == storeKeepId then
        return true
    end

    local storeCanonical = tonumber(store.canonicalKeepId)
        or KST.MemoryResetGetCanonicalId(store.keepName, store.keepId)
        or KST.MemoryResetGetCanonicalId(store.currentKeepName, store.keepId)
        or KST.MemoryResetGetCanonicalId(store.canonicalKeepName, store.keepId)
    if target.canonicalId ~= nil and storeCanonical ~= nil and tonumber(target.canonicalId) == tonumber(storeCanonical) then
        return true
    end

    local names = {
        store.keepName,
        store.currentKeepName,
        store.canonicalKeepName,
        store.key,
    }
    for _, name in ipairs(names) do
        if target.keys[KST.MemoryResetNormalize(name)] == true then
            return true
        end
        local base = normalizeKeepBaseKey(name)
        if base ~= "" and target.keys[base] == true then
            return true
        end
    end

    if type(store.aliases) == "table" then
        for alias, value in pairs(store.aliases) do
            if value == true and target.keys[KST.MemoryResetNormalize(alias)] == true then
                return true
            end
        end
    end

    if target.zoneId ~= nil and target.keepIndex ~= nil and tonumber(store.zoneId) == target.zoneId and tonumber(store.keepIndex) == target.keepIndex then
        return true
    end

    return false
end

function KST.MemoryResetRemoveStores(sourceTable, target)
    if type(sourceTable) ~= "table" then
        return 0
    end

    local removed = 0
    for key, store in pairs(sourceTable) do
        if KST.MemoryResetStoreMatches(store, key, target) then
            sourceTable[key] = nil
            removed = removed + 1
        end
    end
    return removed
end

function KST.MemoryResetRemoveFlat(flat, target)
    if type(flat) ~= "table" then
        return 0
    end

    local removed = 0
    for i = #flat, 1, -1 do
        local store = flat[i]
        if KST.MemoryResetStoreMatches(store, store and store.key, target) then
            table.remove(flat, i)
            removed = removed + 1
        end
    end
    return removed
end

function KST.MemoryResetCandidateList()
    local candidates = {}
    local zones = getOpenZoneIds()

    for _, zoneId in ipairs(zones) do
        local keeps = getKeepsForZone(zoneId)
        if type(keeps) == "table" then
            for keepIndex = 1, 2 do
                local keepData = type(keeps[keepIndex]) == "table" and keeps[keepIndex] or nil
                if keepData ~= nil then
                    local keepId = tonumber(keepData.ID)
                    local keepName = getKeepNameText(keepId, keepIndex)
                    candidates[#candidates + 1] = {
                        zoneId = tonumber(zoneId),
                        zoneName = getZoneNameText(zoneId),
                        keepIndex = tonumber(keepIndex),
                        keepId = keepId,
                        keepName = keepName,
                        keepData = keepData,
                    }
                end
            end
        end
    end

    table.sort(candidates, function(a, b)
        local az = toString(a.zoneName)
        local bz = toString(b.zoneName)
        if az == bz then
            return tonumber(a.keepIndex or 0) < tonumber(b.keepIndex or 0)
        end
        return az < bz
    end)

    return candidates
end

function KST.MemoryResetPrintCandidates()
    local candidates = KST.MemoryResetCandidateList()
    if #candidates == 0 then
        chatPrint("Reset upgrades: no open keep candidates found.")
        return
    end

    chatPrint("Reset upgrades candidates. Use /ksupply resetkeepupgrades 1, /ksupply resetkeepupgrades 2, etc.")
    for i, item in ipairs(candidates) do
        chatPrint(tostring(i) .. ". " .. toString(item.zoneName) .. " - " .. toString(item.keepName))
    end
end

function KST.MemoryResetContextFromArg(rawArgument)
    local arg = toString(rawArgument)
    arg = string.gsub(arg, "^%s+", "")
    arg = string.gsub(arg, "%s+$", "")

    if arg == "" then
        return nil
    end

    local candidates = KST.MemoryResetCandidateList()
    local numeric = tonumber(arg)
    if numeric ~= nil then
        local selected = candidates[numeric]
        if type(selected) == "table" then
            return getKeepShareContext(selected.zoneId, selected.keepIndex)
        end
        return nil
    end

    local wanted = KST.MemoryResetNormalize(arg)
    local wantedBase = normalizeKeepBaseKey(arg)
    for _, item in ipairs(candidates) do
        local name = toString(item.keepName)
        if KST.MemoryResetNormalize(name) == wanted or (wantedBase ~= "" and normalizeKeepBaseKey(name) == wantedBase) then
            return getKeepShareContext(item.zoneId, item.keepIndex)
        end
    end

    return nil
end

function KST.MemoryResetExecute(context, source)
    local target = KST.MemoryResetBuildTarget(context)
    if target == nil then
        chatPrint("Reset upgrades: no valid keep selected.")
        return false
    end

    KST._keepUpgrades = KST._keepUpgrades or {}
    KeepSupplyTimerUpgradeState = KeepSupplyTimerUpgradeState or {}
    KeepSupplyTimerSettings = KeepSupplyTimerSettings or {}

    local removedRuntime = KST.MemoryResetRemoveStores(KST._keepUpgrades, target)
    local removedPrimary = KST.MemoryResetRemoveStores(KeepSupplyTimerUpgradeState.keepUpgrades, target)
    local removedBackup = KST.MemoryResetRemoveStores(KeepSupplyTimerSettings.keepUpgradesBackup, target)
    local removedFlatOld = KST.MemoryResetRemoveFlat(KeepSupplyTimerSettings.keepUpgradesFlatBackup, target)

    rebuildAllKeepUpgradeAliases()

    local nowText = getEventTimeText()
    local nowEpoch = getRealEpochSeconds()
    local nowSession = math.floor(tonumber(KST._clock) or 0)

    KeepSupplyTimerUpgradeState.version = KST.VERSION
    KeepSupplyTimerUpgradeState.keepUpgrades = KST._keepUpgrades
    KeepSupplyTimerUpgradeState.savedAt = nowText
    KeepSupplyTimerUpgradeState.savedEpoch = nowEpoch
    KeepSupplyTimerUpgradeState.savedSessionSeconds = nowSession
    KeepSupplyTimerUpgradeState.reason = "memory-reset"

    KeepSupplyTimerSettings.keepUpgradesBackup = KST._keepUpgrades
    KeepSupplyTimerSettings.keepUpgradesBackupSavedAt = nowText
    KeepSupplyTimerSettings.keepUpgradesBackupSavedEpoch = nowEpoch
    KeepSupplyTimerSettings.keepUpgradesBackupReason = "memory-reset"
    KeepSupplyTimerSettings.keepUpgradesFlatBackup = buildKeepUpgradesFlatBackup()
    KeepSupplyTimerSettings.keepUpgradesFlatBackupSavedAt = nowText

    KST.SafeAppendFileLogControlLine("[KST_RESET_MEMORY] source=" .. toString(source or "?")
        .. " keep=" .. toString(target.keepName)
        .. " runtime=" .. tostring(removedRuntime)
        .. " primary=" .. tostring(removedPrimary)
        .. " backup=" .. tostring(removedBackup)
        .. " flatOld=" .. tostring(removedFlatOld))

    chatPrint("Upgrade memory deleted for " .. toString(target.keepName) .. ".")
    return true
end

function KeepSupplyTimer.ResetSelectedKeepUpgradesMenu()
    if type(KST._shareContext) ~= "table" then
        chatPrint("Reset upgrades: no keep selected from context menu.")
        return
    end
    KST.MemoryResetExecute(KST._shareContext, "context-menu")
end

function KeepSupplyTimer.ResetSelectedKeepUpgrades()
    KeepSupplyTimer.ResetSelectedKeepUpgradesMenu()
end

function KST.MemoryResetSlash(rawArgument)
    local arg = toString(rawArgument)
    arg = string.gsub(arg, "^%s+", "")
    arg = string.gsub(arg, "%s+$", "")

    if arg == "" then
        KST.MemoryResetPrintCandidates()
        return false
    end

    local context = KST.MemoryResetContextFromArg(arg)
    if type(context) ~= "table" then
        chatPrint("Reset upgrades: keep not found for '" .. toString(arg) .. "'.")
        KST.MemoryResetPrintCandidates()
        return false
    end

    return KST.MemoryResetExecute(context, "slash")
end


function KeepSupplyTimer.ReadNPCUpgradesForSelectedKeep()
    local context = KST._shareContext
    local ok, reason = KST.ValidateContextKeepForNPCRead(context)
    if not ok then
        chatPrint(reason or "NPC upgrade read refused.")
        return
    end

    KST.ReadNPCUpgradeWindow(context.keepName)
end


function KST.GetDivineFavorRecordForContext(context)
    if type(context) ~= "table" then
        return nil, nil
    end

    local store = getKeepUpgradeStore(context.keepName, context.keepData, context.zoneId, context.keepIndex)
    if type(store) ~= "table" or type(store.upgrades) ~= "table" then
        return nil, store
    end

    for _, record in pairs(store.upgrades) do
        if type(record) == "table" and record.name == "Divine Favor Altar" and record.state ~= "removed" and record.state ~= "removing" then
            return record, store
        end
    end

    return nil, store
end

function KST.SetDivineFavorChargesForContext(context, charges, source)
    local record, store = KST.GetDivineFavorRecordForContext(context)
    if type(record) ~= "table" or type(store) ~= "table" then
        chatPrint("No Divine Favor Altar detected for selected keep.")
        return false
    end

    local maxCharges = tonumber(record.maxCharges) or 3
    local newCharges = tonumber(charges) or 0
    if newCharges < 0 then newCharges = 0 end
    if newCharges > maxCharges then newCharges = maxCharges end

    local interval = tonumber(record.rechargeIntervalSeconds) or (15 * 60)
    local nowSession = math.floor(tonumber(KST._clock) or 0)
    local nowEpoch = getRealEpochSeconds()

    record.state = "building"
    record.durationSeconds = 0
    record.buildEndsAtSessionSeconds = nowSession
    record.buildEndsEpoch = nowEpoch
    record.buildEndsAt = getEndTimeText(record.buildEndsEpoch, record.buildEndsAtSessionSeconds)
    record.firstChargeDelaySeconds = 0
    record.firstChargeAtSessionSeconds = nowSession
    record.firstChargeEpoch = nowEpoch
    record.firstChargeAt = getEndTimeText(record.firstChargeEpoch, record.firstChargeAtSessionSeconds)
    record.rechargeIntervalSeconds = interval
    record.maxCharges = maxCharges
    record.divineManualCharges = newCharges
    record.divineChargesUnknown = nil
    record.divineBadEstimate = nil
    record.divineEstimateStartedAt = nil
    record.divineEstimateStartedSessionSeconds = nil
    record.divineEstimateStartedEpoch = nil
    record.divineLastManualSetAt = getEventTimeText()
    record.divineLastManualSetSessionSeconds = nowSession
    record.divineLastManualSetEpoch = nowEpoch

    if newCharges < maxCharges then
        local existingRemaining = getUpgradeRemaining(record, "divineNextChargeEpoch", "divineNextChargeAtSessionSeconds")
        if existingRemaining == nil or existingRemaining <= 0 then
            record.divineNextChargeEpoch, record.divineNextChargeAtSessionSeconds = computeAbsoluteEnd(nowEpoch, nowSession, interval)
        elseif tonumber(record.divineNextChargeEpoch) == nil and nowEpoch ~= nil and tonumber(record.divineNextChargeAtSessionSeconds) ~= nil then
            record.divineNextChargeEpoch = nowEpoch + existingRemaining
        end
        record.divineNextChargeAt = getEndTimeText(record.divineNextChargeEpoch, record.divineNextChargeAtSessionSeconds)
    else
        record.divineNextChargeAtSessionSeconds = nil
        record.divineNextChargeEpoch = nil
        record.divineNextChargeAt = nil
    end

    record.lastUpdateAt = getEventTimeText()
    record.lastUpdateSessionSeconds = nowSession
    record.lastUpdateEpoch = nowEpoch
    store.lastUpdateAt = record.lastUpdateAt
    store.lastUpdateSessionSeconds = nowSession
    store.lastUpdateEpoch = nowEpoch

    persistKeepUpgrades("divine-manual-charges")
    appendKeepUpgradeLog("DIVINE_FAVOR_CHARGES_MANUAL", context.keepName or store.keepName, record, "manual source=" .. toString(source or "?") .. " charges=" .. tostring(newCharges))
    chatPrint("Divine Favor Altar charges set for " .. toString(context.keepName or store.keepName) .. ": " .. tostring(newCharges) .. "/" .. tostring(maxCharges) .. ".")
    return true
end

function KST.AdjustDivineFavorChargesForContext(context, delta, source)
    local record = KST.GetDivineFavorRecordForContext(context)
    if type(record) ~= "table" then
        chatPrint("No Divine Favor Altar detected for selected keep.")
        return false
    end

    local _, _, charges = getUpgradeStatus(record)
    local current = tonumber(charges)
    if current == nil then
        current = tonumber(record.divineManualCharges) or 0
    end

    return KST.SetDivineFavorChargesForContext(context, current + (tonumber(delta) or 0), source)
end

function KeepSupplyTimer.DivineChargesMinus()
    KST.AdjustDivineFavorChargesForContext(KST._shareContext, -1, "menu-minus")
end

function KeepSupplyTimer.DivineChargesPlus()
    KST.AdjustDivineFavorChargesForContext(KST._shareContext, 1, "menu-plus")
end

function KeepSupplyTimer.DivineChargesSet0()
    KST.SetDivineFavorChargesForContext(KST._shareContext, 0, "menu-set0")
end

function KeepSupplyTimer.DivineChargesSet1()
    KST.SetDivineFavorChargesForContext(KST._shareContext, 1, "menu-set1")
end

function KeepSupplyTimer.DivineChargesSet2()
    KST.SetDivineFavorChargesForContext(KST._shareContext, 2, "menu-set2")
end

function KeepSupplyTimer.DivineChargesSet3()
    KST.SetDivineFavorChargesForContext(KST._shareContext, 3, "menu-set3")
end


function openKSTKeepShareMenu(zoneId, keepIndex)
    if type(EA_Window_ContextMenu) ~= "table" or type(EA_Window_ContextMenu.CreateContextMenu) ~= "function" then
        chatPrint("Context menu is not available.")
        return
    end

    local context = getKeepShareContext(zoneId, keepIndex)
    KST._shareContext = context
    KST._shareRecordList = {}
    KST._shareSelectedChannelByIndex = {}

    EA_Window_ContextMenu.CreateContextMenu(KST.SHARE_CONTEXT_MENU_NAME)

    addKSTContextMenuCallbackItem("Read keep upgrades, requires NPC upgrade window open", KeepSupplyTimer.ReadNPCUpgradesForSelectedKeep, false)
    addKSTContextMenuCallbackItem("------------------------------", KeepSupplyTimer.MenuNoop, false)

    addKSTContextMenuCallbackItem("== Share all upgrades ==", KeepSupplyTimer.MenuNoop, false)
    addKSTContextMenuCallbackItem("  By Region (/1)", KeepSupplyTimer.ShareAllRegion, false)
    addKSTContextMenuCallbackItem("  By Tier 4 (/t4)", KeepSupplyTimer.ShareAllT4, false)
    addKSTContextMenuCallbackItem("  By Warband (/wb)", KeepSupplyTimer.ShareAllWarband, false)
    addKSTContextMenuCallbackItem("  By Guild (/g)", KeepSupplyTimer.ShareAllGuild, false)
    addKSTContextMenuCallbackItem("  By Party (/p)", KeepSupplyTimer.ShareAllParty, false)

    addKSTContextMenuCallbackItem("------------------------------", KeepSupplyTimer.MenuNoop, false)
    addKSTContextMenuCallbackItem("== Share selected upgrades ==", KeepSupplyTimer.MenuNoop, false)
    addKSTContextMenuCallbackItem("  Select upgrade for Region (/1) >", KeepSupplyTimer.OpenSelectedShareRegion, false)
    addKSTContextMenuCallbackItem("  Select upgrade for Tier 4 (/t4) >", KeepSupplyTimer.OpenSelectedShareT4, false)
    addKSTContextMenuCallbackItem("  Select upgrade for Warband (/wb) >", KeepSupplyTimer.OpenSelectedShareWarband, false)
    addKSTContextMenuCallbackItem("  Select upgrade for Guild (/g) >", KeepSupplyTimer.OpenSelectedShareGuild, false)
    addKSTContextMenuCallbackItem("  Select upgrade for Party (/p) >", KeepSupplyTimer.OpenSelectedShareParty, false)

    addKSTContextMenuCallbackItem("------------------------------", KeepSupplyTimer.MenuNoop, false)
    addKSTContextMenuCallbackItem("== Divine Favor Altar charges ==", KeepSupplyTimer.MenuNoop, false)
    addKSTContextMenuCallbackItem("  Divine charges -1", KeepSupplyTimer.DivineChargesMinus, false)
    addKSTContextMenuCallbackItem("  Divine charges +1", KeepSupplyTimer.DivineChargesPlus, false)
    addKSTContextMenuCallbackItem("  Set Divine charges 0/3", KeepSupplyTimer.DivineChargesSet0, false)
    addKSTContextMenuCallbackItem("  Set Divine charges 1/3", KeepSupplyTimer.DivineChargesSet1, false)
    addKSTContextMenuCallbackItem("  Set Divine charges 2/3", KeepSupplyTimer.DivineChargesSet2, false)
    addKSTContextMenuCallbackItem("  Set Divine charges 3/3", KeepSupplyTimer.DivineChargesSet3, false)
    addKSTContextMenuCallbackItem("------------------------------", KeepSupplyTimer.MenuNoop, false)
    addKSTContextMenuCallbackItem("Reset selected keep upgrades", KeepSupplyTimer.ResetSelectedKeepUpgradesMenu, false)
    addKSTContextMenuCallbackItem("Print share preview locally", KeepSupplyTimer.PrintSharePreview, false)

    EA_Window_ContextMenu.Finalize()
end

function KeepSupplyTimer.OnKeepContextMenu()
    local data = getKeepUpgradeHoverDataForContextMenu()
    if type(data) ~= "table" or data.zoneId == nil or data.keepIndex == nil then
        chatPrint("No keep selected for sharing.")
        return
    end

    openKSTKeepShareMenu(data.zoneId, data.keepIndex)
end

local function populateUpgradeTooltipWindow(tooltipName, keepName, keepData, zoneId, keepIndex)
    if tooltipName == nil then
        return
    end

    local owner = tonumber(keepData and keepData.Owner) or tonumber(keepData and keepData.owner) or 0
    local rank = tonumber(keepData and keepData.Rank) or tonumber(keepData and keepData.rank) or 0
    local supply = tonumber(keepData and keepData.Supply) or tonumber(keepData and keepData.supply) or 0
    local claim = getKeepClaimText(keepData)
    local claimed = isKeepClaimed(claim)
    local realmText = getRealmNameText(owner)
    local rr, rg, rb = getRealmColor(owner)

    setTooltipImageTexture(tooltipName .. "HeaderIcon", getRealmBlipTexture(owner), 18, 18)
    if type(WindowSetShowing) == "function" then
        pcall(WindowSetShowing, tooltipName .. "Black", true)
        pcall(WindowSetShowing, tooltipName .. "Back", true)
        pcall(WindowSetShowing, tooltipName .. "Frame", true)
        pcall(WindowSetShowing, tooltipName .. "HeaderIcon", true)
        pcall(WindowSetShowing, tooltipName .. "Text", false)
    end
    if type(WindowSetAlpha) == "function" then
        pcall(WindowSetAlpha, tooltipName .. "Black", 0.86)
        pcall(WindowSetAlpha, tooltipName .. "Back", 0.95)
        pcall(WindowSetAlpha, tooltipName .. "Frame", 1.0)
    end
    if type(WindowSetTintColor) == "function" then
        pcall(WindowSetTintColor, tooltipName .. "Black", 0, 0, 0)
    end

    setTooltipLabelText(tooltipName .. "Title", keepName, 255, 206, 64)
    if claimed then
        setTooltipLabelText(tooltipName .. "Guild", "<" .. claim .. ">", 80, 165, 255)
    else
        setTooltipLabelText(tooltipName .. "Guild", "<UnClaimed>", 140, 140, 140)
    end

    local starText = getStarText(rank)
    local meta = realmText .. " Keep " .. tostring(rank)
    if starText ~= "" then
        meta = meta .. " " .. starText
    end
    local requiredForSupply = getRequiredBOsForSupply(rank)
    meta = meta .. "   Supply: " .. tostring(math.floor((supply or 0) + 0.5)) .. "%"
    meta = meta .. "   Supply BOs: " .. tostring(requiredForSupply)
    setTooltipLabelText(tooltipName .. "Meta", meta, rr, rg, rb)
    setTooltipLabelText(tooltipName .. "Section", "Keep upgrades", 255, 220, 120)

    local rows, store = getUpgradeRowsForTooltip(keepName, owner, keepData, zoneId, keepIndex)
    local rowCount = tonumber(KST.KEEP_UPGRADE_TOOLTIP_ROW_COUNT) or 14
    for i = 1, rowCount do
        local iconName = tooltipName .. "Row" .. tostring(i) .. "Icon"
        local textName = tooltipName .. "Row" .. tostring(i) .. "Text"
        local row = rows[i]
        if type(row) == "table" then
            setTooltipImageTexture(iconName, row.texture or "ObjUnknown", 15, 15)
            local c = row.color or { 255, 255, 255 }
            setTooltipLabelText(textName, row.text or "", c[1], c[2], c[3])
            if type(WindowSetShowing) == "function" then
                pcall(WindowSetShowing, iconName, true)
                pcall(WindowSetShowing, textName, true)
            end
        else
            if type(WindowSetShowing) == "function" then
                pcall(WindowSetShowing, iconName, false)
                pcall(WindowSetShowing, textName, false)
            end
        end
    end

    local footer = "Source: chat parser"
    if type(store) == "table" and store.keepName ~= nil and normalizeKeepLooseKey(store.keepName) ~= normalizeKeepLooseKey(keepName) then
        footer = "Matched: " .. toString(store.keepName) .. "     " .. footer
    end
    if type(store) == "table" and store.lastUpdateAt ~= nil then
        footer = "Last update: " .. toString(store.lastUpdateAt) .. "     " .. footer
    end
    setTooltipLabelText(tooltipName .. "Footer", footer, 150, 150, 150)
end

local function ensureUpgradeTooltipWindow()
    local tooltipName = KST.KEEP_UPGRADE_TOOLTIP_WINDOW
    if windowExists(tooltipName) then
        return tooltipName
    end
    if type(CreateWindowFromTemplate) ~= "function" then
        return nil
    end

    local parent = "Root"
    if windowExists("RoR_SoR_Main_Window") then
        parent = "RoR_SoR_Main_Window"
    end

    local ok = pcall(CreateWindowFromTemplate, tooltipName, KST.KEEP_UPGRADE_TOOLTIP_TEMPLATE, parent)
    if not ok or not windowExists(tooltipName) then
        return nil
    end

    if type(WindowSetDimensions) == "function" then
        pcall(WindowSetDimensions, tooltipName, KST.KEEP_UPGRADE_TOOLTIP_WIDTH, KST.KEEP_UPGRADE_TOOLTIP_HEIGHT)
        pcall(WindowSetDimensions, tooltipName .. "Black", KST.KEEP_UPGRADE_TOOLTIP_WIDTH, KST.KEEP_UPGRADE_TOOLTIP_HEIGHT)
        pcall(WindowSetDimensions, tooltipName .. "Back", KST.KEEP_UPGRADE_TOOLTIP_WIDTH, KST.KEEP_UPGRADE_TOOLTIP_HEIGHT)
        pcall(WindowSetDimensions, tooltipName .. "Frame", KST.KEEP_UPGRADE_TOOLTIP_WIDTH, KST.KEEP_UPGRADE_TOOLTIP_HEIGHT)
    end
    if type(WindowSetTintColor) == "function" then
        pcall(WindowSetTintColor, tooltipName .. "Black", 0, 0, 0)
    end
    if type(WindowSetAlpha) == "function" then
        pcall(WindowSetAlpha, tooltipName .. "Black", 0.86)
        pcall(WindowSetAlpha, tooltipName .. "Back", 0.95)
        pcall(WindowSetAlpha, tooltipName .. "Frame", 1.0)
        pcall(WindowSetAlpha, tooltipName, 1.0)
    end
    -- Back/Frame are tintable resize images in 0.1.35; no external texture alias needed.
    if type(WindowSetShowing) == "function" then
        pcall(WindowSetShowing, tooltipName .. "Black", true)
        pcall(WindowSetShowing, tooltipName .. "Back", true)
        pcall(WindowSetShowing, tooltipName .. "Frame", true)
        pcall(WindowSetShowing, tooltipName, false)
    end
    return tooltipName
end

local function showKeepUpgradeTooltipFor(zoneId, keepIndex, anchorWindow)
    local keeps = getKeepsForZone(zoneId)
    local keepData = type(keeps) == "table" and type(keeps[keepIndex]) == "table" and keeps[keepIndex] or nil
    local keepId = tonumber(keepData and keepData.ID)
    local keepName = getKeepNameText(keepId, keepIndex)
    local tooltipName = ensureUpgradeTooltipWindow()
    if tooltipName == nil then
        return false
    end

    populateUpgradeTooltipWindow(tooltipName, keepName, keepData, zoneId, keepIndex)

    if type(WindowClearAnchors) == "function" then
        pcall(WindowClearAnchors, tooltipName)
    end
    if type(WindowAddAnchor) == "function" then
        local anchored = false

        -- Do not call getKeepHoverOverlayName() here: it is declared later in
        -- this file, so calling it from this earlier function can break the
        -- tooltip on some clients. Build the overlay name directly instead.
        local anchorTarget = toString(KST.KEEP_UPGRADE_HOVER_PREFIX or "KeepSupplyTimer_KeepHover_")
            .. tostring(zoneId) .. "_" .. tostring(keepIndex)

        if not windowExists(anchorTarget) then
            anchorTarget = anchorWindow or getZoneWindow(zoneId) or "Root"
        end

        -- Place the tooltip below the keep-upgrades label/hitbox.
        local ok = pcall(WindowAddAnchor, tooltipName, "topleft", anchorTarget, "bottomleft", -115, 4)
        anchored = ok == true
        if anchored ~= true then
            pcall(WindowAddAnchor, tooltipName, "topleft", anchorTarget, "bottomleft", 0, 4)
        end
    end
    if type(WindowSetShowing) == "function" then
        pcall(WindowSetShowing, tooltipName .. "Black", true)
        pcall(WindowSetShowing, tooltipName .. "Back", true)
        pcall(WindowSetShowing, tooltipName .. "Frame", true)
        pcall(WindowSetShowing, tooltipName, true)
    end
    if type(WindowSetAlpha) == "function" then
        pcall(WindowSetAlpha, tooltipName .. "Black", 0.86)
        pcall(WindowSetAlpha, tooltipName .. "Back", 0.95)
        pcall(WindowSetAlpha, tooltipName .. "Frame", 1.0)
    end

    KST._currentUpgradeTooltip = {
        zoneId = tonumber(zoneId),
        keepIndex = tonumber(keepIndex),
        anchorWindow = anchorWindow,
    }
    return true
end

local function hideKeepUpgradeTooltip()
    local tooltipName = KST.KEEP_UPGRADE_TOOLTIP_WINDOW
    if windowExists(tooltipName) and type(WindowSetShowing) == "function" then
        pcall(WindowSetShowing, tooltipName, false)
    end
    KST._currentUpgradeTooltip = nil
end

function KeepSupplyTimer.OnKeepMouseOver()
    local windowName = getMouseOverWindowName()
    local data = nil

    if windowName ~= nil and type(KST._keepUpgradeHoverWindows) == "table" then
        data = KST._keepUpgradeHoverWindows[windowName]
    end

    -- Fallback: if ActiveWindow/MouseOverWindow is not one of our hitboxes,
    -- try to infer the hitbox from the active window name used by the event.
    -- This keeps the tooltip visible on clients where MouseOverWindow reports
    -- the underlying SoR window instead of our transparent overlay.
    if type(data) ~= "table" and type(SystemData) == "table" and type(SystemData.ActiveWindow) == "table" then
        local activeName = toString(SystemData.ActiveWindow.name)
        if activeName ~= nil and activeName ~= "" and type(KST._keepUpgradeHoverWindows) == "table" then
            data = KST._keepUpgradeHoverWindows[activeName]
            if type(data) == "table" then
                windowName = activeName
            end
        end
    end

    if type(data) == "table" then
        showKeepUpgradeTooltipFor(data.zoneId, data.keepIndex, windowName)
    end
end

function KeepSupplyTimer.OnKeepMouseOut()
    hideKeepUpgradeTooltip()
end

local function findKeepWindowName(zoneId, keepIndex)
    local z = tostring(zoneId)
    local i = tostring(keepIndex)
    local candidates = {
        "SoR_" .. z .. "Keep" .. i,
        "SoR_" .. z .. "_Keep" .. i,
        "SoR_" .. z .. "K" .. i,
        "SoR_" .. z .. "_K" .. i,
        "SoR_" .. z .. "KeepWindow" .. i,
        "SoR_" .. z .. "_KeepWindow" .. i,
        "SoR_" .. z .. "Fort" .. i,
    }

    for _, name in ipairs(candidates) do
        if windowExists(name) then
            return name
        end
    end

    return nil
end

local function getKeepHoverOverlayName(zoneId, keepIndex)
    return KST.KEEP_UPGRADE_HOVER_PREFIX .. tostring(zoneId) .. "_" .. tostring(keepIndex)
end

local function getFriendlyKeepIndexForZone(zoneId)
    local playerRealm = getPlayerRealmId()
    if playerRealm == nil then
        return nil
    end

    local zoneState = getState(zoneId)
    if type(zoneState) ~= "table" or type(zoneState.keeps) ~= "table" then
        return nil
    end

    for i = 1, 2 do
        local keepState = zoneState.keeps[i]
        if type(keepState) == "table" and tonumber(keepState.owner) == tonumber(playerRealm) then
            return i
        end
    end

    return nil
end

local function getKeepUpgradeHoverLabel(zoneId, keepIndex)
    local realmId = getPlayerRealmId()
    if realmId == nil then
        local zoneState = getState(zoneId)
        if type(zoneState) == "table" and type(zoneState.keeps) == "table" then
            local keepState = zoneState.keeps[tonumber(keepIndex) or 0]
            realmId = type(keepState) == "table" and tonumber(keepState.owner) or nil
        end
    end

    if tonumber(realmId) == 1 then
        return "Order keep upgrades"
    elseif tonumber(realmId) == 2 then
        return "Destro keep upgrades"
    end

    return toString(KST.KEEP_UPGRADE_HOVER_LABEL or "Keep upgrades")
end

local function ensureKeepUpgradeHoverOverlay(zoneId, keepIndex)
    if KST.SHOW_KEEP_UPGRADE_TOOLTIPS ~= true then
        return nil
    end

    local zoneWindow = getZoneWindow(zoneId)
    if zoneWindow == nil or not windowExists(zoneWindow) then
        return nil
    end

    local overlayName = getKeepHoverOverlayName(zoneId, keepIndex)

    if not windowExists(overlayName) then
        if type(CreateWindowFromTemplate) ~= "function" then
            return nil
        end
        local ok = pcall(CreateWindowFromTemplate, overlayName, KST.KEEP_UPGRADE_HOVER_TEMPLATE, zoneWindow)
        if not ok or not windowExists(overlayName) then
            return nil
        end
    end

    if type(WindowClearAnchors) == "function" then
        pcall(WindowClearAnchors, overlayName)
    end

    if type(WindowAddAnchor) == "function" then
        -- Single hover label: anchored at the bottom center of the zone pair so
        -- it stays stable when the SoR scale changes. Tooltip content still
        -- comes from the friendly keep only.
        pcall(WindowAddAnchor, overlayName, "bottom", zoneWindow, "bottom", 0, -8)
    end

    if type(WindowSetDimensions) == "function" then
        pcall(WindowSetDimensions, overlayName, KST.KEEP_UPGRADE_HOVER_WIDTH, KST.KEEP_UPGRADE_HOVER_HEIGHT)
        pcall(WindowSetDimensions, overlayName .. "TextBG", KST.KEEP_UPGRADE_HOVER_WIDTH, 18)
        pcall(WindowSetDimensions, overlayName .. "Text", KST.KEEP_UPGRADE_HOVER_WIDTH, 18)
    end
    if type(LabelSetText) == "function" then
        local label = toWString(getKeepUpgradeHoverLabel(zoneId, keepIndex))
        pcall(LabelSetText, overlayName .. "TextBG", label)
        pcall(LabelSetText, overlayName .. "Text", label)
    end
    if type(LabelSetTextColor) == "function" then
        pcall(LabelSetTextColor, overlayName .. "TextBG", 0, 0, 0)
        pcall(LabelSetTextColor, overlayName .. "Text", 255, 220, 120)
    end
    if type(WindowSetShowing) == "function" then
        pcall(WindowSetShowing, overlayName .. "TextBG", true)
        pcall(WindowSetShowing, overlayName .. "Text", true)
        pcall(WindowSetShowing, overlayName, true)
    end

    if type(KST._keepUpgradeHoverWindows) ~= "table" then
        KST._keepUpgradeHoverWindows = {}
    end
    local hoverData = {
        zoneId = tonumber(zoneId),
        keepIndex = tonumber(keepIndex),
    }
    KST._keepUpgradeHoverWindows[overlayName] = hoverData
    KST._keepUpgradeHoverWindows[overlayName .. "Hitbox"] = hoverData
    KST._keepUpgradeHoverWindows[overlayName .. "TextBG"] = hoverData
    KST._keepUpgradeHoverWindows[overlayName .. "Text"] = hoverData

    return overlayName
end

local function updateKeepUpgradeHoverOverlays(zoneId)
    for i = 1, 2 do
        local overlay = getKeepHoverOverlayName(zoneId, i)
        if windowExists(overlay) and type(WindowSetShowing) == "function" then
            pcall(WindowSetShowing, overlay, false)
        end
        if type(KST._keepUpgradeHoverWindows) == "table" then
            KST._keepUpgradeHoverWindows[overlay] = nil
            KST._keepUpgradeHoverWindows[overlay .. "Hitbox"] = nil
            KST._keepUpgradeHoverWindows[overlay .. "TextBG"] = nil
            KST._keepUpgradeHoverWindows[overlay .. "Text"] = nil
        end
    end

    if KST.SHOW_KEEP_UPGRADE_TOOLTIPS ~= true then
        return
    end

    local keepIndex = getFriendlyKeepIndexForZone(zoneId)
    if keepIndex == nil then
        return
    end

    ensureKeepUpgradeHoverOverlay(zoneId, keepIndex)
end

local function hideKeepUpgradeHoverOverlays(zoneId)
    for i = 1, 2 do
        local overlay = getKeepHoverOverlayName(zoneId, i)
        if windowExists(overlay) and type(WindowSetShowing) == "function" then
            pcall(WindowSetShowing, overlay, false)
        end
        if type(KST._keepUpgradeHoverWindows) == "table" then
            KST._keepUpgradeHoverWindows[overlay] = nil
            KST._keepUpgradeHoverWindows[overlay .. "Hitbox"] = nil
            KST._keepUpgradeHoverWindows[overlay .. "TextBG"] = nil
            KST._keepUpgradeHoverWindows[overlay .. "Text"] = nil
        end
    end
end

getMouseOverWindowName = function()
    -- WAR/RoR event handlers usually expose the hovered window as
    -- SystemData.ActiveWindow.name. MouseOverWindow is not reliable on all
    -- clients and, in 0.1.26, could make the tooltip disappear immediately.
    if type(SystemData) == "table" then
        if type(SystemData.ActiveWindow) == "table" then
            local activeName = toString(SystemData.ActiveWindow.name)
            if activeName ~= nil and activeName ~= "" then
                return activeName
            end
        end
        if type(SystemData.MouseOverWindow) == "table" then
            local mouseName = toString(SystemData.MouseOverWindow.name)
            if mouseName ~= nil and mouseName ~= "" then
                return mouseName
            end
        end
    end
    return nil
end

local function getRiskTooltipColor(risk)
    local code = type(risk) == "table" and toString(risk.code) or "?"
    if code == "ZERO" then
        return 255, 255, 255
    elseif code == "OK" then
        return 120, 255, 120
    elseif code == "STAB" then
        return 120, 220, 255
    elseif code == "?" then
        return 180, 180, 180
    elseif code == "LOW" then
        return 255, 220, 80
    elseif code == "HIGH" then
        return 255, 160, 60
    elseif code == "CRIT" then
        return 255, 70, 70
    end

    local level = type(risk) == "table" and tonumber(risk.level) or 0
    if level >= 4 then
        return 255, 70, 70
    elseif level >= 3 then
        return 255, 160, 60
    elseif level >= 2 then
        return 255, 220, 80
    elseif level >= 1 then
        return 160, 220, 255
    end
    return 180, 180, 180
end


local function getRiskHoverDataForWindow(windowName)
    if windowName == nil or windowName == "" or type(KST._riskHoverWindows) ~= "table" then
        return nil
    end

    local data = KST._riskHoverWindows[windowName]
    if type(data) == "table" then
        return data
    end

    local text = toString(windowName)
    local parentFromBackground = (text:gsub("Background$", ""))
    local parentFromTextBG = (text:gsub("TextBG$", ""))
    local parentFromText = (text:gsub("Text$", ""))
    local candidates = {
        parentFromBackground,
        parentFromTextBG,
        parentFromText,
    }
    for _, candidate in ipairs(candidates) do
        data = KST._riskHoverWindows[candidate]
        if type(data) == "table" then
            return data
        end
    end

    data = getRiskHoverDataFromName(windowName)
    if type(data) == "table" then
        return data
    end

    return nil
end

local function ensureRiskTooltipWindow()
    local tooltipName = KST.RISK_TOOLTIP_WINDOW
    if windowExists(tooltipName) then
        return tooltipName
    end
    if type(CreateWindowFromTemplate) ~= "function" then
        return nil
    end

    local parent = "Root"
    if windowExists("RoR_SoR_Main_Window") then
        parent = "RoR_SoR_Main_Window"
    end

    local ok = pcall(CreateWindowFromTemplate, tooltipName, KST.RISK_TOOLTIP_TEMPLATE, parent)
    if not ok or not windowExists(tooltipName) then
        return nil
    end

    if type(WindowSetDimensions) == "function" then
        pcall(WindowSetDimensions, tooltipName, KST.RISK_TOOLTIP_WIDTH, KST.RISK_TOOLTIP_HEIGHT)
        pcall(WindowSetDimensions, tooltipName .. "Black", KST.RISK_TOOLTIP_WIDTH, KST.RISK_TOOLTIP_HEIGHT)
        pcall(WindowSetDimensions, tooltipName .. "Back", KST.RISK_TOOLTIP_WIDTH, KST.RISK_TOOLTIP_HEIGHT)
        pcall(WindowSetDimensions, tooltipName .. "Frame", KST.RISK_TOOLTIP_WIDTH, KST.RISK_TOOLTIP_HEIGHT)
    end
    if type(WindowSetTintColor) == "function" then
        pcall(WindowSetTintColor, tooltipName .. "Black", 0, 0, 0)
    end
    if type(WindowSetAlpha) == "function" then
        pcall(WindowSetAlpha, tooltipName .. "Black", 0.86)
        pcall(WindowSetAlpha, tooltipName .. "Back", 0.95)
        pcall(WindowSetAlpha, tooltipName .. "Frame", 1.0)
        pcall(WindowSetAlpha, tooltipName, 1.0)
    end
    if type(WindowSetShowing) == "function" then
        pcall(WindowSetShowing, tooltipName .. "Black", true)
        pcall(WindowSetShowing, tooltipName .. "Back", true)
        pcall(WindowSetShowing, tooltipName .. "Frame", true)
        pcall(WindowSetShowing, tooltipName, false)
    end
    return tooltipName
end

local function getRiskTooltipKeepName(keepState, keepIndex)
    local keepId = type(keepState) == "table" and tonumber(keepState.keepId) or nil
    return getKeepNameText(keepId, keepIndex)
end

local function getRiskTooltipRealmText(keepState, keepIndex)
    local owner = type(keepState) == "table" and tonumber(keepState.owner) or 0
    local label = REALM_LABELS[owner] or ("K" .. tostring(keepIndex or "?"))
    local realm = getRealmNameText(owner)
    if realm == nil or realm == "" then
        realm = label
    end
    return label .. " " .. realm
end


function normalizeRealmId(value)
    if value == nil then
        return nil
    end

    local numberValue = tonumber(value)
    if numberValue == 1 or numberValue == 2 then
        return numberValue
    end

    local text = string.lower(toString(value))
    if text == "order" or string.find(text, "order", 1, true) then
        return 1
    end
    if text == "destro" or text == "destruction" or string.find(text, "destruction", 1, true) or string.find(text, "destro", 1, true) then
        return 2
    end

    return nil
end

function getPlayerRealmId()
    local candidate

    if type(GameData) == "table" and type(GameData.Player) == "table" then
        candidate = normalizeRealmId(GameData.Player.realm)
        if candidate ~= nil then return candidate end
        candidate = normalizeRealmId(GameData.Player.Realm)
        if candidate ~= nil then return candidate end
        candidate = normalizeRealmId(GameData.Player.realmId)
        if candidate ~= nil then return candidate end
        candidate = normalizeRealmId(GameData.Player.realmID)
        if candidate ~= nil then return candidate end
        candidate = normalizeRealmId(GameData.Player.playerRealm)
        if candidate ~= nil then return candidate end
        candidate = normalizeRealmId(GameData.Player.PlayerRealm)
        if candidate ~= nil then return candidate end
    end

    if type(SystemData) == "table" and type(SystemData.Player) == "table" then
        candidate = normalizeRealmId(SystemData.Player.realm)
        if candidate ~= nil then return candidate end
        candidate = normalizeRealmId(SystemData.Player.Realm)
        if candidate ~= nil then return candidate end
        candidate = normalizeRealmId(SystemData.Player.realmId)
        if candidate ~= nil then return candidate end
        candidate = normalizeRealmId(SystemData.Player.realmID)
        if candidate ~= nil then return candidate end
    end

    local functionNames = {
        "GetPlayerRealm",
        "GetPlayerRealmId",
        "GetPlayerRealmID",
        "GetRealm",
        "GetRealmId",
        "GetRealmID",
    }
    for _, functionName in ipairs(functionNames) do
        local fn = _G and _G[functionName] or nil
        if type(fn) == "function" then
            local ok, value = pcall(fn)
            if ok then
                candidate = normalizeRealmId(value)
                if candidate ~= nil then
                    return candidate
                end
            end
        end
    end

    return nil
end

function getKeepPerspectiveText(owner)
    local ownerNumber = tonumber(owner) or 0
    local playerRealm = getPlayerRealmId()

    if playerRealm ~= nil and ownerNumber == playerRealm then
        return "Your keep", "friendly", playerRealm
    elseif playerRealm ~= nil and ownerNumber ~= 0 and ownerNumber ~= playerRealm then
        return "Enemy keep", "enemy", playerRealm
    end

    return "Keep", "neutral", playerRealm
end

function formatBOPlural(count)
    local numberValue = tonumber(count)
    if numberValue == 1 then
        return "BO"
    end
    return "BOs"
end

function formatRankRequirementLine(rank, required)
    local rankText = tostring(tonumber(rank) or 0)
    local requiredText = tostring(tonumber(required) or "?")
    return "Supplies: rank " .. rankText .. " requires " .. requiredText .. " active " .. formatBOPlural(required) .. " in this zone."
end

function formatBOActionText(perspective, risk, active, required, missing, toArmedText, toCritText)
    local requiredSafe = tonumber(required) or 0
    local activeSafe = tonumber(active)
    local missingSafe = tonumber(missing) or 0
    local toDrop = 1
    if activeSafe ~= nil then
        toDrop = activeSafe - requiredSafe + 1
        if toDrop < 1 then
            toDrop = 1
        end
    end

    if perspective == "friendly" then
        if risk.code == "ZERO" then
            return "Defend BOs to generate supplies and escort them to the keep so it can start leveling."
        elseif risk.code == "OK" then
            return "Defend: hold at least " .. tostring(requiredSafe) .. " " .. formatBOPlural(requiredSafe) .. " and escort supplies to keep/warcamp."
        elseif risk.code == "?" then
            return "Defend: hold " .. tostring(requiredSafe) .. " " .. formatBOPlural(requiredSafe) .. " until supply spawns, then escort it to the keep."
        elseif risk.code == "LOW" then
            return "Defend: retake " .. tostring(missingSafe) .. " " .. formatBOPlural(missingSafe) .. " or deliver supply before the risk window opens."
        elseif risk.code == "MED" then
            return "Do not drop below " .. tostring(requiredSafe) .. " " .. formatBOPlural(requiredSafe) .. "; deliver supply to reset the timer."
        elseif risk.code == "HIGH" then
            return "Defend now: retake " .. tostring(missingSafe) .. " " .. formatBOPlural(missingSafe) .. " or deliver supply."
        elseif risk.code == "CRIT" then
            return "Emergency: retake " .. tostring(missingSafe) .. " " .. formatBOPlural(missingSafe) .. " or escort supply now."
        end
    elseif perspective == "enemy" then
        if risk.code == "ZERO" then
            return "No reset play until the enemy keep gains progress."
        elseif risk.code == "OK" then
            return "Attack: take or neutralize " .. tostring(toDrop) .. " " .. formatBOPlural(toDrop) .. " so the enemy keep can lose progress."
        elseif risk.code == "?" then
            return "Attack: capture enemy BOs to keep them below " .. tostring(requiredSafe) .. ", preventing supplies from spawning; timer is unknown."
        elseif risk.code == "LOW" then
            return "Attack: keep enemy BOs below " .. tostring(requiredSafe) .. " so the keep can decay. High risk: " .. toString(toArmedText or "?") .. " | Critical: " .. toString(toCritText or "?")
        elseif risk.code == "MED" then
            return "Attack now: take " .. tostring(toDrop) .. " " .. formatBOPlural(toDrop) .. "; the timer is already high."
        elseif risk.code == "HIGH" then
            return "Attack: keep them below " .. tostring(requiredSafe) .. " " .. formatBOPlural(requiredSafe) .. "; the reset window is near or already open."
        elseif risk.code == "CRIT" then
            return "Attack: deny BOs and supply; enemy reset is expected soon."
        end
    end

    if risk.code == "OK" or risk.code == "MED" then
        return "To defend: keep " .. tostring(requiredSafe) .. " " .. formatBOPlural(requiredSafe) .. ". To reset: drop the owner below " .. tostring(requiredSafe) .. "."
    elseif risk.code == "ZERO" then
        return "No progress can reset yet."
    elseif risk.code == "?" then
        return "Timer unknown: watch the next supply and BO count."
    end

    return "Owner needs " .. tostring(requiredSafe) .. " " .. formatBOPlural(requiredSafe) .. "; attackers should keep them below that."
end

local function formatRiskTooltipKeepRows(keepState, keepIndex)
    if type(keepState) ~= "table" then
        return "Keep " .. tostring(keepIndex or "?") .. ": no data", "", "", "", "", "", 190, 190, 190
    end

    local risk = getKeepRiskInfo(keepState)
    local rr, rg, rb = getRiskTooltipColor(risk)
    local name = getRiskTooltipKeepName(keepState, keepIndex)
    local realm = getRiskTooltipRealmText(keepState, keepIndex)
    local perspectiveText, perspective = getKeepPerspectiveText(keepState.owner)

    local supply = tonumber(keepState.lastSupply)
    local supplyText = supply ~= nil and (tostring(math.floor(supply)) .. "%") or "?"
    local elapsedText = risk.elapsedSec ~= nil and formatElapsed(risk.elapsedSec) or "?"
    local tminText = risk.tmin ~= nil and formatElapsed(risk.tmin) or "?"
    local rank = tonumber(keepState.rank) or 0
    local active = tonumber(risk.activeBOs)
    local required = tonumber(risk.requiredBOs) or getRequiredBOsForSupply(rank)
    local boText = toString(active or "?") .. "/" .. toString(required or "?")
    local missing = tonumber(risk.missingBOsNow) or 0

    local row1 = perspectiveText .. ": " .. realm .. " - " .. name .. " | " .. toString(risk.short or "D:?") .. " " .. toString(risk.label or "Unknown")
    local row2 = "Progress " .. supplyText .. " | Last supply " .. elapsedText .. " | Rank threshold " .. tminText
    local row3 = "Active/required BOs: " .. boText .. " | Missing: " .. tostring(missing)
    local row4 = formatRankRequirementLine(rank, required)
    local row5 = "Model: " .. toString(risk.decayModel or "Hybrid aggressive")
    local row6 = formatBOActionText(perspective, risk, active, required, missing)

    if risk.code == "ZERO" then
        row2 = "Progress 0%. Nothing can reset yet."
        row3 = formatRankRequirementLine(rank, required)
        row4 = formatBOActionText(perspective, risk, active, required, missing)
        row5 = ""
        row6 = "Addon is waiting for the next observed supply to calculate risk."
    elseif risk.code == "?" then
        row2 = "Progress " .. supplyText .. " | Last supply not observed."
        row5 = "The next delivered supply will start the prediction."
        row6 = formatBOActionText(perspective, risk, active, required, missing)
    elseif risk.code == "OK" then
        row5 = "Safe while the BO requirement remains met."
        row6 = formatBOActionText(perspective, risk, active, required, missing)
    elseif risk.code == "STAB" then
        row5 = "No decay risk: enough BOs are under control."
        row6 = "This stabilized status is temporary and will return to SAFE."
    elseif risk.code == "LOW" then
        local toArmed = risk.timeToArmedSec ~= nil and formatElapsed(risk.timeToArmedSec) or "?"
        local toCrit = risk.timeToCriticalSec ~= nil and formatElapsed(risk.timeToCriticalSec) or "?"
        row5 = "Below BO safety requirement (" .. tostring(required or "?") .. "). High risk: " .. toArmed .. " | Critical: " .. toCrit
        row6 = formatBOActionText(perspective, risk, active, required, missing, toArmed, toCrit)
    elseif risk.code == "HIGH" then
        local toCrit = risk.timeToCriticalSec ~= nil and formatElapsed(risk.timeToCriticalSec) or "?"
        row5 = "High risk. Critical in approx " .. toCrit .. " if " .. tostring(required or "?") .. " " .. formatBOPlural(required) .. " are not retaken."
        row6 = formatBOActionText(perspective, risk, active, required, missing)
    elseif risk.code == "CRIT" then
        local overdue = risk.criticalOverdueSec ~= nil and formatElapsed(risk.criticalOverdueSec) or "?"
        row5 = "CRITICAL for " .. overdue .. ". Progress can reset to 0 on the next server update."
        row6 = formatBOActionText(perspective, risk, active, required, missing)
    end

    return row1, row2, row3, row4, row5, row6, rr, rg, rb
end

local function populateRiskTooltipWindow(tooltipName, zoneId, keepIndex)
    if tooltipName == nil then
        return
    end

    local zoneState = getState(zoneId)
    local keepState = zoneState and zoneState.keeps and zoneState.keeps[keepIndex] or nil
    local keepName = getRiskTooltipKeepName(keepState, keepIndex)
    local owner = type(keepState) == "table" and tonumber(keepState.owner) or 0

    setTooltipImageTexture(tooltipName .. "HeaderIcon", getRealmBlipTexture(owner), 18, 18)

    if type(WindowSetShowing) == "function" then
        pcall(WindowSetShowing, tooltipName .. "Black", true)
        pcall(WindowSetShowing, tooltipName .. "Back", true)
        pcall(WindowSetShowing, tooltipName .. "Frame", true)
        pcall(WindowSetShowing, tooltipName .. "HeaderIcon", true)
        pcall(WindowSetShowing, tooltipName .. "Text", false)
        for i = 1, 14 do
            pcall(WindowSetShowing, tooltipName .. "Row" .. tostring(i) .. "Icon", false)
            pcall(WindowSetShowing, tooltipName .. "Row" .. tostring(i) .. "Text", false)
        end
    end

    setTooltipLabelText(tooltipName .. "Title", "Keep decay risk", 255, 206, 64)
    setTooltipLabelText(tooltipName .. "Guild", getZoneNameText(zoneId) .. " - " .. keepName, 170, 210, 255)

    local row1, row2, row3, row4, row5, row6, rr, rg, rb = formatRiskTooltipKeepRows(keepState, keepIndex)

    setTooltipLabelText(tooltipName .. "Meta", row1, rr, rg, rb)
    setTooltipLabelText(tooltipName .. "Section", row2, 230, 230, 230)

    local rows = {
        { text = row3, color = { 230, 230, 230 } },
        { text = row4, color = { 235, 235, 235 } },
        { text = row5, color = { 255, 230, 120 } },
        { text = row6, color = { 205, 225, 255 } },
    }

    for i, row in ipairs(rows) do
        local textName = tooltipName .. "Row" .. tostring(i) .. "Text"
        local c = row.color or { 255, 255, 255 }
        setTooltipLabelText(textName, row.text or "", c[1], c[2], c[3])
        if type(WindowSetShowing) == "function" then
            pcall(WindowSetShowing, textName, true)
        end
    end

    setTooltipLabelText(tooltipName .. "Footer", "Estimated decay risk: last supply + rank threshold + BO requirement + grace period.", 150, 150, 150)
end

local function showRiskTooltipFor(zoneId, keepIndex, anchorWindow)
    local tooltipName = ensureRiskTooltipWindow()
    if tooltipName == nil then
        return false
    end

    populateRiskTooltipWindow(tooltipName, zoneId, keepIndex)

    if type(WindowClearAnchors) == "function" then
        pcall(WindowClearAnchors, tooltipName)
    end
    if type(WindowAddAnchor) == "function" then
        local x = tonumber(KST.RISK_TOOLTIP_CURSOR_OFFSET_X) or 18
        local y = tonumber(KST.RISK_TOOLTIP_CURSOR_OFFSET_Y) or 18
        local ok = pcall(WindowAddAnchor, tooltipName, "topleft", "CursorWindow", "bottomright", x, y)
        if not ok then
            pcall(WindowAddAnchor, tooltipName, "topleft", anchorWindow or getZoneWindow(zoneId) or "Root", "bottomleft", 0, 4)
        end
    end

    if type(WindowSetShowing) == "function" then
        pcall(WindowSetShowing, tooltipName, true)
    end

    KST._currentRiskTooltip = {
        zoneId = tonumber(zoneId),
        keepIndex = tonumber(keepIndex),
        anchorWindow = anchorWindow,
    }
    return true
end

local function hideRiskTooltip()
    local tooltipName = KST.RISK_TOOLTIP_WINDOW
    if windowExists(tooltipName) and type(WindowSetShowing) == "function" then
        pcall(WindowSetShowing, tooltipName, false)
    end
    KST._currentRiskTooltip = nil
end

function KeepSupplyTimer.OnRiskMouseOver()
    if not isRiskTextEnabled() then
        return
    end
    local windowName = getMouseOverWindowName()
    local data = getRiskHoverDataForWindow(windowName)
    if type(data) == "table" and data.zoneId ~= nil and data.keepIndex ~= nil then
        showRiskTooltipFor(data.zoneId, data.keepIndex, windowName)
    end
end

function KeepSupplyTimer.OnRiskMouseOut()
    hideRiskTooltip()
end

local function refreshCurrentRiskTooltip()
    local current = KST._currentRiskTooltip
    if type(current) ~= "table" or current.zoneId == nil then
        return
    end

    local zoneState = getState(current.zoneId)
    if zoneState == nil or zoneState.showing ~= true then
        hideRiskTooltip()
        return
    end

    showRiskTooltipFor(current.zoneId, current.keepIndex, current.anchorWindow)
end

local function isMouseOverKnownKeepHoverWindow(windowName)
    if windowName == nil or windowName == "" then
        return false
    end
    if type(KST._keepUpgradeHoverWindows) ~= "table" then
        return false
    end
    return type(KST._keepUpgradeHoverWindows[windowName]) == "table"
end

local function shouldKeepUpgradeTooltipStayVisible(current)
    -- 0.1.27: do not hide by polling SystemData.MouseOverWindow. In testing,
    -- some clients report the underlying SoR window or nothing at all, causing
    -- the 0.1.26 tooltip to vanish instantly. Hiding is now handled by
    -- OnMouseOverEnd/OnMouseOut on the transparent keep hitbox.
    return type(current) == "table"
end

local function refreshCurrentUpgradeTooltip()
    local current = KST._currentUpgradeTooltip
    if type(current) ~= "table" then
        return
    end

    if shouldKeepUpgradeTooltipStayVisible(current) ~= true then
        hideKeepUpgradeTooltip()
        return
    end

    showKeepUpgradeTooltipFor(current.zoneId, current.keepIndex, current.anchorWindow)
end

local function getResetPairOverlayName(zoneId)
    return KST.WINDOW_PREFIX .. tostring(zoneId) .. "_ResetPair"
end

local function getResetBoxWindowName(zoneId, keepIndex)
    local suffix = tonumber(keepIndex) == 1 and "Left" or "Right"
    return getResetPairOverlayName(zoneId) .. suffix
end

function getResetBoxHoverOverlayName(zoneId, keepIndex)
    return KST.RESET_BOX_HOVER_PREFIX .. tostring(zoneId) .. "_" .. tostring(keepIndex)
end

getRiskHoverDataFromName = function(windowName)
    local text = toString(windowName)
    if text == nil or text == "" then
        return nil
    end

    text = text:gsub("Hitbox$", "")
    text = text:gsub("Background$", "")
    text = text:gsub("TextBG$", "")
    text = text:gsub("Text$", "")

    local zoneId, keepIndex = text:match("^" .. KST.RESET_BOX_HOVER_PREFIX .. "(%d+)_(%d+)$")
    if zoneId ~= nil and keepIndex ~= nil then
        return { zoneId = tonumber(zoneId), keepIndex = tonumber(keepIndex) }
    end

    zoneId = text:match("^" .. KST.WINDOW_PREFIX .. "(%d+)_ResetPairLeft$")
    if zoneId ~= nil then
        return { zoneId = tonumber(zoneId), keepIndex = 1 }
    end

    zoneId = text:match("^" .. KST.WINDOW_PREFIX .. "(%d+)_ResetPairRight$")
    if zoneId ~= nil then
        return { zoneId = tonumber(zoneId), keepIndex = 2 }
    end

    return nil
end

function registerRiskHoverWindow(windowName, zoneId, keepIndex)
    if windowName == nil or windowName == "" then
        return
    end
    if type(KST._riskHoverWindows) ~= "table" then
        KST._riskHoverWindows = {}
    end
    local data = { zoneId = tonumber(zoneId), keepIndex = tonumber(keepIndex) }
    KST._riskHoverWindows[windowName] = data
    KST._riskHoverWindows[windowName .. "Hitbox"] = data
    KST._riskHoverWindows[windowName .. "Background"] = data
    KST._riskHoverWindows[windowName .. "Text"] = data
    KST._riskHoverWindows[windowName .. "TextBG"] = data
end

function unregisterRiskHoverWindow(windowName)
    if windowName == nil or windowName == "" or type(KST._riskHoverWindows) ~= "table" then
        return
    end
    KST._riskHoverWindows[windowName] = nil
    KST._riskHoverWindows[windowName .. "Hitbox"] = nil
    KST._riskHoverWindows[windowName .. "Background"] = nil
    KST._riskHoverWindows[windowName .. "Text"] = nil
    KST._riskHoverWindows[windowName .. "TextBG"] = nil
end

local function registerResetBoxHover(zoneId, keepIndex)
    registerRiskHoverWindow(getResetBoxWindowName(zoneId, keepIndex), zoneId, keepIndex)
    registerRiskHoverWindow(getResetBoxHoverOverlayName(zoneId, keepIndex), zoneId, keepIndex)
end

local function unregisterResetBoxHover(zoneId, keepIndex)
    unregisterRiskHoverWindow(getResetBoxWindowName(zoneId, keepIndex))
    unregisterRiskHoverWindow(getResetBoxHoverOverlayName(zoneId, keepIndex))
end

function ensureResetBoxHoverOverlay(zoneId, keepIndex)
    local pairName = getResetPairOverlayName(zoneId)
    local boxName = getResetBoxWindowName(zoneId, keepIndex)
    local hoverName = getResetBoxHoverOverlayName(zoneId, keepIndex)
    if pairName == nil or not windowExists(pairName) or boxName == nil or not windowExists(boxName) then
        return nil
    end

    local created = false
    if not windowExists(hoverName) then
        if type(CreateWindowFromTemplate) ~= "function" then
            return nil
        end
        local ok = pcall(CreateWindowFromTemplate, hoverName, KST.RESET_BOX_HOVER_TEMPLATE, pairName)
        if not ok or not windowExists(hoverName) then
            return nil
        end
        created = true
    end

    if type(WindowClearAnchors) == "function" then
        pcall(WindowClearAnchors, hoverName)
    end
    if type(WindowAddAnchor) == "function" then
        pcall(WindowAddAnchor, hoverName, "topleft", boxName, "topleft", 0, 0)
    end
    if type(WindowSetDimensions) == "function" then
        pcall(WindowSetDimensions, hoverName, KST.RESET_BOX_WIDTH, KST.RESET_BOX_HEIGHT)
        pcall(WindowSetDimensions, hoverName .. "Background", KST.RESET_BOX_WIDTH, KST.RESET_BOX_HEIGHT)
    end
    if created and type(WindowSetScale) == "function" and windowExists("RoR_SoR_Main_Window") and type(WindowGetScale) == "function" then
        local ok, scale = pcall(WindowGetScale, "RoR_SoR_Main_Window")
        if ok and tonumber(scale) ~= nil then
            pcall(WindowSetScale, hoverName, scale)
        end
    end
    if type(WindowSetAlpha) == "function" then
        pcall(WindowSetAlpha, hoverName, 1.0)
        pcall(WindowSetAlpha, hoverName .. "Background", 0.01)
    end
    if type(WindowSetShowing) == "function" then
        pcall(WindowSetShowing, hoverName, true)
        pcall(WindowSetShowing, hoverName .. "Background", true)
    end

    registerRiskHoverWindow(hoverName, zoneId, keepIndex)
    return hoverName
end

local function getResetPairRuntimeWidth(zoneWindow)
    local fallback = tonumber(KST.RESET_PAIR_WIDTH) or 236

    if zoneWindow ~= nil and type(WindowGetDimensions) == "function" then
        local ok, width, height = pcall(WindowGetDimensions, zoneWindow)
        width = tonumber(width)
        if ok and width ~= nil and width > fallback then
            return math.floor(width)
        end
    end

    return fallback
end

local function ensureResetPairOverlay(zoneId)
    local zoneWindow = getZoneWindow(zoneId)
    local pairName = getResetPairOverlayName(zoneId)
    if zoneWindow == nil or not windowExists(zoneWindow) then
        return nil
    end

    local created = false
    if not windowExists(pairName) then
        if type(CreateWindowFromTemplate) ~= "function" then
            return nil
        end
        local ok = pcall(CreateWindowFromTemplate, pairName, KST.RESET_PAIR_TEMPLATE, zoneWindow)
        if not ok or not windowExists(pairName) then
            return nil
        end
        created = true
    end

    if type(WindowClearAnchors) == "function" then
        pcall(WindowClearAnchors, pairName)
    end
    local pairWidth = getResetPairRuntimeWidth(zoneWindow)

    if type(WindowAddAnchor) == "function" then
        pcall(WindowAddAnchor, pairName, "bottomleft", zoneWindow, "bottomleft", tonumber(KST.RESET_PAIR_OFFSET_X) or 0, tonumber(KST.RESET_PAIR_OFFSET_Y) or -2)
    end
    if type(WindowSetDimensions) == "function" then
        -- Make the parent overlay span the whole SoR pairing panel. The right
        -- decay box is a child of this overlay, so changing only its anchor was
        -- not enough on the RoR UI system.
        pcall(WindowSetDimensions, pairName, pairWidth, KST.RESET_BOX_HEIGHT)
        pcall(WindowSetDimensions, pairName .. "Left", KST.RESET_BOX_WIDTH, KST.RESET_BOX_HEIGHT)
        pcall(WindowSetDimensions, pairName .. "LeftBackground", KST.RESET_BOX_WIDTH, KST.RESET_BOX_HEIGHT)
        pcall(WindowSetDimensions, pairName .. "LeftText", KST.RESET_BOX_WIDTH, KST.RESET_BOX_HEIGHT)
        pcall(WindowSetDimensions, pairName .. "LeftTextBG", KST.RESET_BOX_WIDTH, KST.RESET_BOX_HEIGHT)
        pcall(WindowSetDimensions, pairName .. "Right", KST.RESET_BOX_WIDTH, KST.RESET_BOX_HEIGHT)
        pcall(WindowSetDimensions, pairName .. "RightBackground", KST.RESET_BOX_WIDTH, KST.RESET_BOX_HEIGHT)
        pcall(WindowSetDimensions, pairName .. "RightText", KST.RESET_BOX_WIDTH, KST.RESET_BOX_HEIGHT)
        pcall(WindowSetDimensions, pairName .. "RightTextBG", KST.RESET_BOX_WIDTH, KST.RESET_BOX_HEIGHT)
    end
    if type(WindowClearAnchors) == "function" then
        pcall(WindowClearAnchors, pairName .. "Left")
        pcall(WindowClearAnchors, pairName .. "Right")
    end
    if type(WindowAddAnchor) == "function" then
        pcall(WindowAddAnchor, pairName .. "Left", "topleft", pairName, "topleft", 3, 0)
        pcall(WindowAddAnchor, pairName .. "Right", "topright", pairName, "topright", -3, 0)
    end
    if created and type(WindowSetScale) == "function" and windowExists("RoR_SoR_Main_Window") and type(WindowGetScale) == "function" then
        local ok, scale = pcall(WindowGetScale, "RoR_SoR_Main_Window")
        if ok and tonumber(scale) ~= nil then
            pcall(WindowSetScale, pairName, scale)
        end
    end
    if type(WindowSetAlpha) == "function" then
        pcall(WindowSetAlpha, pairName, 1.0)
        pcall(WindowSetAlpha, pairName .. "Left", 1.0)
        pcall(WindowSetAlpha, pairName .. "Right", 1.0)
        pcall(WindowSetAlpha, pairName .. "LeftBackground", 0.64)
        pcall(WindowSetAlpha, pairName .. "RightBackground", 0.64)
    end
    if type(WindowSetShowing) == "function" then
        pcall(WindowSetShowing, pairName .. "Left", true)
        pcall(WindowSetShowing, pairName .. "Right", true)
    end

    registerResetBoxHover(zoneId, 1)
    registerResetBoxHover(zoneId, 2)
    ensureResetBoxHoverOverlay(zoneId, 1)
    ensureResetBoxHoverOverlay(zoneId, 2)
    return pairName
end

local function setResetBoxText(zoneId, keepIndex, keepState, text)
    local boxName = getResetBoxWindowName(zoneId, keepIndex)
    if type(keepState) == "table" and keepState.lastResetBoxText == text then
        return
    end

    local labelText = toWString(text or KST.UNKNOWN_TEXT)
    if type(LabelSetText) == "function" then
        pcall(LabelSetText, boxName .. "Text", labelText)
        pcall(LabelSetText, boxName .. "TextBG", labelText)
    end

    local r, g, b = 255, 255, 255
    if type(keepState) == "table" then
        r, g, b = getRiskTooltipColor(getKeepRiskInfo(keepState))
    end
    if type(LabelSetTextColor) == "function" then
        pcall(LabelSetTextColor, boxName .. "Text", r, g, b)
        pcall(LabelSetTextColor, boxName .. "TextBG", 0, 0, 0)
    end

    if type(keepState) == "table" then
        keepState.lastResetBoxText = text
    end
end

local function showResetPairOverlay(zoneId, leftState, leftText, rightState, rightText)
    local pairName = ensureResetPairOverlay(zoneId)
    if pairName == nil then
        return false
    end

    setResetBoxText(zoneId, 1, leftState, leftText)
    setResetBoxText(zoneId, 2, rightState, rightText)

    if type(WindowSetShowing) == "function" then
        pcall(WindowSetShowing, pairName, true)
        pcall(WindowSetShowing, pairName .. "Left", true)
        pcall(WindowSetShowing, pairName .. "Right", true)
    end

    local zoneState = getState(zoneId)
    if type(zoneState) == "table" then
        zoneState.showing = true
    end
    return true
end

local function hideOverlay(zoneId)
    local zoneState = getState(zoneId)
    local pairName = getResetPairOverlayName(zoneId)
    local legacyName = getOverlayName(zoneId)

    if type(WindowSetShowing) == "function" then
        if windowExists(pairName) then
            pcall(WindowSetShowing, pairName, false)
        end
        for i = 1, 2 do
            local hoverName = getResetBoxHoverOverlayName(zoneId, i)
            if windowExists(hoverName) then
                pcall(WindowSetShowing, hoverName, false)
            end
        end
        if windowExists(legacyName) then
            pcall(WindowSetShowing, legacyName, false)
        end
    end

    unregisterResetBoxHover(zoneId, 1)
    unregisterResetBoxHover(zoneId, 2)

    if type(KST._currentRiskTooltip) == "table" and tonumber(KST._currentRiskTooltip.zoneId) == tonumber(zoneId) then
        hideRiskTooltip()
    end

    if type(zoneState) == "table" then
        zoneState.showing = false
        zoneState.lastText = nil
        if type(zoneState.keeps) == "table" then
            for i = 1, 2 do
                if type(zoneState.keeps[i]) == "table" then
                    zoneState.keeps[i].lastResetBoxText = nil
                end
            end
        end
    end
end

local function getBOOverlayName(zoneId, boIndex)
    return KST.BO_WINDOW_PREFIX .. tostring(zoneId) .. "_" .. tostring(boIndex)
end

function KST.getBOHoverOverlayName(zoneId, boIndex)
    return KST.BO_HOVER_PREFIX .. tostring(zoneId) .. "_" .. tostring(boIndex)
end

local function getBOWindowName(zoneId, boIndex)
    return "SoR_" .. tostring(zoneId) .. "BO" .. tostring(boIndex)
end

function KST.registerBOTooltipWindow(zoneId, boIndex, overlayName)
    if overlayName == nil or overlayName == "" then
        return
    end

    if type(KST._boTooltipWindows) ~= "table" then
        KST._boTooltipWindows = {}
    end

    local data = {
        zoneId = tonumber(zoneId),
        boIndex = tonumber(boIndex),
    }

    KST._boTooltipWindows[overlayName] = data
    KST._boTooltipWindows[overlayName .. "Background"] = data
    KST._boTooltipWindows[overlayName .. "Hitbox"] = data
    KST._boTooltipWindows[overlayName .. "TextBG"] = data
    KST._boTooltipWindows[overlayName .. "Text"] = data
end

function KST.ensureBOHoverOverlay(zoneId, boIndex)
    local zoneWindow = getZoneWindow(zoneId)
    local timerName = getBOOverlayName(zoneId, boIndex)
    local hoverName = KST.getBOHoverOverlayName(zoneId, boIndex)

    if zoneWindow == nil or not windowExists(zoneWindow) or timerName == nil or not windowExists(timerName) then
        return nil
    end

    local created = false
    if not windowExists(hoverName) then
        if type(CreateWindowFromTemplate) ~= "function" then
            return nil
        end

        local ok = pcall(CreateWindowFromTemplate, hoverName, KST.BO_HOVER_TEMPLATE, zoneWindow)
        if not ok or not windowExists(hoverName) then
            return nil
        end
        created = true
    end

    if type(WindowClearAnchors) == "function" then
        pcall(WindowClearAnchors, hoverName)
    end
    if type(WindowAddAnchor) == "function" then
        pcall(WindowAddAnchor, hoverName, "topleft", timerName, "topleft", tonumber(KST.BO_HOVER_OFFSET_X) or -3, tonumber(KST.BO_HOVER_OFFSET_Y) or -2)
    end
    if type(WindowSetDimensions) == "function" then
        pcall(WindowSetDimensions, hoverName, tonumber(KST.BO_HOVER_WIDTH) or 56, tonumber(KST.BO_HOVER_HEIGHT) or 20)
        pcall(WindowSetDimensions, hoverName .. "Background", tonumber(KST.BO_HOVER_WIDTH) or 56, tonumber(KST.BO_HOVER_HEIGHT) or 20)
    end
    if created and type(WindowSetScale) == "function" and windowExists("RoR_SoR_Main_Window") and type(WindowGetScale) == "function" then
        local ok, scale = pcall(WindowGetScale, "RoR_SoR_Main_Window")
        if ok and tonumber(scale) ~= nil then
            pcall(WindowSetScale, hoverName, scale)
        end
    end
    if type(WindowSetAlpha) == "function" then
        pcall(WindowSetAlpha, hoverName, 1.0)
        pcall(WindowSetAlpha, hoverName .. "Background", 0.01)
    end
    if type(WindowSetShowing) == "function" then
        pcall(WindowSetShowing, hoverName, true)
        pcall(WindowSetShowing, hoverName .. "Background", true)
    end

    KST.registerBOTooltipWindow(zoneId, boIndex, hoverName)
    return hoverName
end

local function ensureBOOverlay(zoneId, boIndex)
    local zoneWindow = getZoneWindow(zoneId)
    local boWindow = getBOWindowName(zoneId, boIndex)
    local overlayName = getBOOverlayName(zoneId, boIndex)

    if zoneWindow == nil or not windowExists(zoneWindow) or not windowExists(boWindow) then
        return nil
    end

    local created = false
    if not windowExists(overlayName) then
        if type(CreateWindowFromTemplate) ~= "function" then
            return nil
        end

        local ok = pcall(CreateWindowFromTemplate, overlayName, KST.BO_TEMPLATE, zoneWindow)
        if not ok or not windowExists(overlayName) then
            return nil
        end
        created = true
    end

    if created then
        if type(WindowClearAnchors) == "function" then
            pcall(WindowClearAnchors, overlayName)
        end
        if type(WindowAddAnchor) == "function" then
            pcall(WindowAddAnchor, overlayName, "bottom", boWindow, "top", KST.BO_ANCHOR_X, KST.BO_ANCHOR_Y)
        end
        if type(WindowSetDimensions) == "function" then
            pcall(WindowSetDimensions, overlayName, KST.BO_WIDTH, KST.BO_HEIGHT)
            pcall(WindowSetDimensions, overlayName .. "Background", KST.BO_WIDTH, KST.BO_HEIGHT)
            pcall(WindowSetDimensions, overlayName .. "Text", KST.BO_WIDTH, KST.BO_HEIGHT)
            pcall(WindowSetDimensions, overlayName .. "TextBG", KST.BO_WIDTH, KST.BO_HEIGHT)
        end
        if type(WindowSetScale) == "function" and windowExists("RoR_SoR_Main_Window") and type(WindowGetScale) == "function" then
            local ok, scale = pcall(WindowGetScale, "RoR_SoR_Main_Window")
            if ok and tonumber(scale) ~= nil then
                local boScale = tonumber(KST.BO_TEXT_SCALE) or 0.85
                pcall(WindowSetScale, overlayName, tonumber(scale) * boScale)
            end
        end
        if type(LabelSetTextColor) == "function" then
            pcall(LabelSetTextColor, overlayName .. "Text", 255, 255, 255)
            pcall(LabelSetTextColor, overlayName .. "TextBG", 0, 0, 0)
        end
    end

    KST.registerBOTooltipWindow(zoneId, boIndex, overlayName)
    KST.ensureBOHoverOverlay(zoneId, boIndex)

    return overlayName
end

local function hideBOOverlay(zoneId, boIndex)
    local overlayName = getBOOverlayName(zoneId, boIndex)
    local hoverName = KST.getBOHoverOverlayName(zoneId, boIndex)
    if windowExists(overlayName) and type(WindowSetShowing) == "function" then
        pcall(WindowSetShowing, overlayName, false)
    end
    if windowExists(hoverName) and type(WindowSetShowing) == "function" then
        pcall(WindowSetShowing, hoverName, false)
    end
    if type(KST._currentBOTooltip) == "table" and tonumber(KST._currentBOTooltip.zoneId) == tonumber(zoneId) and tonumber(KST._currentBOTooltip.boIndex) == tonumber(boIndex) then
        hideBOTooltip()
    end

    local zoneState = getState(zoneId)
    if zoneState ~= nil and type(zoneState.bos) == "table" and type(zoneState.bos[boIndex]) == "table" then
        zoneState.bos[boIndex].showing = false
        zoneState.bos[boIndex].lastText = nil
    end
end

local function hideBOOverlays(zoneId)
    for i = 1, 4 do
        hideBOOverlay(zoneId, i)
    end
end

function getBOTooltipWindow()
    local tooltipName = KST.BO_TOOLTIP_WINDOW
    if windowExists(tooltipName) then
        if type(WindowSetDimensions) == "function" then
            pcall(WindowSetDimensions, tooltipName, KST.BO_TOOLTIP_WIDTH, KST.BO_TOOLTIP_HEIGHT)
            pcall(WindowSetDimensions, tooltipName .. "Black", KST.BO_TOOLTIP_WIDTH, KST.BO_TOOLTIP_HEIGHT)
            pcall(WindowSetDimensions, tooltipName .. "Back", KST.BO_TOOLTIP_WIDTH, KST.BO_TOOLTIP_HEIGHT)
        end
        return tooltipName
    end

    if type(CreateWindowFromTemplate) ~= "function" then
        return nil
    end

    local parent = "Root"
    if windowExists("RoR_SoR_Main_Window") then
        parent = "RoR_SoR_Main_Window"
    end

    local ok = pcall(CreateWindowFromTemplate, tooltipName, KST.BO_TOOLTIP_TEMPLATE, parent)
    if not ok or not windowExists(tooltipName) then
        return nil
    end

    if type(WindowSetDimensions) == "function" then
        pcall(WindowSetDimensions, tooltipName, KST.BO_TOOLTIP_WIDTH, KST.BO_TOOLTIP_HEIGHT)
        pcall(WindowSetDimensions, tooltipName .. "Black", KST.BO_TOOLTIP_WIDTH, KST.BO_TOOLTIP_HEIGHT)
        pcall(WindowSetDimensions, tooltipName .. "Back", KST.BO_TOOLTIP_WIDTH, KST.BO_TOOLTIP_HEIGHT)
    end
    if type(WindowSetAlpha) == "function" then
        pcall(WindowSetAlpha, tooltipName, 1.0)
        pcall(WindowSetAlpha, tooltipName .. "Black", 0.90)
        pcall(WindowSetAlpha, tooltipName .. "Back", 0.35)
    end
    if type(WindowSetShowing) == "function" then
        pcall(WindowSetShowing, tooltipName, false)
    end

    return tooltipName
end

function getBOTooltipDataForWindow(windowName)
    local name = toString(windowName)
    if name == "" then
        return nil, nil
    end

    if type(KST._boTooltipWindows) == "table" then
        local data = KST._boTooltipWindows[name]
        if type(data) ~= "table" then
            local parentName = name
            parentName = string.gsub(parentName, "Hitbox$", "")
            parentName = string.gsub(parentName, "Background$", "")
            parentName = string.gsub(parentName, "TextBG$", "")
            parentName = string.gsub(parentName, "Text$", "")
            data = KST._boTooltipWindows[parentName]
        end

        if type(data) == "table" and data.zoneId ~= nil and data.boIndex ~= nil then
            return tonumber(data.zoneId), tonumber(data.boIndex)
        end
    end

    local prefix = toString(KST.BO_WINDOW_PREFIX)
    if string.sub(name, 1, string.len(prefix)) ~= prefix then
        return nil, nil
    end

    local rest = string.sub(name, string.len(prefix) + 1)
    rest = string.gsub(rest, "Background$", "")
    rest = string.gsub(rest, "Hitbox$", "")
    rest = string.gsub(rest, "TextBG$", "")
    rest = string.gsub(rest, "Text$", "")

    local zoneText, boText = string.match(rest, "^(%d+)_(%d+)$")
    local zoneId = tonumber(zoneText)
    local boIndex = tonumber(boText)

    if zoneId == nil or boIndex == nil then
        return nil, nil
    end

    return zoneId, boIndex
end

function populateBOTooltipWindow(tooltipName, zoneId, boIndex)
    local boIds = getBOIdsForZone(zoneId)
    local boStates = getBOStatesForZone(zoneId)
    local boTimers = getBOTimersForZone(zoneId)
    local zoneState = getState(zoneId)
    local boState = zoneState and zoneState.bos and zoneState.bos[boIndex] or nil

    local boData = type(boIds) == "table" and type(boIds[boIndex]) == "table" and boIds[boIndex] or nil
    local boId = tonumber(boData and boData.ID) or 0
    local owner = tonumber(boData and boData.Owner) or 0
    local state = type(boStates) == "table" and tonumber(boStates[boIndex]) or nil
    local timer = type(boTimers) == "table" and tonumber(boTimers[boIndex]) or nil
    local boName = getBONameText(boId, boIndex)
    local realmName = getRealmNameText(owner)

    local generationInfo = getBOGenerationInfo(zoneId, owner)
    local active = tonumber(generationInfo and generationInfo.activeBOs)
    local required = tonumber(generationInfo and generationInfo.requiredBOs)
    local interval = tonumber(KST.BO_SUPPLY_INTERVAL) or 42
    local remainingText = "?"

    if type(boState) == "table" and boState.supplyCycleAnchor ~= nil and interval > 0 then
        local elapsed = (tonumber(KST._clock) or 0) - tonumber(boState.supplyCycleAnchor)
        if elapsed < 0 then
            elapsed = 0
        end
        remainingText = formatCountdown(interval - (elapsed % interval))
    end

    local title = "Estimated next supply"
    local row1 = toString(boName) .. " | " .. toString(realmName)
    local row2 = "Estimated next supply spawn: " .. remainingText .. "  (approx. " .. tostring(interval) .. "s cycle)"
    local row3 = "Local estimate only. This is not a server-confirmed timer."
    local footer = "Resets when the BO owner/state changes or when supply requirements change."

    if owner == 0 or boId == 0 then
        row1 = "BO not detected or has no owner."
        row2 = "No estimated supply spawn is available."
        row3 = "This timer is only shown for detected allied/enemy BOs."
    elseif not isBOStableOwnedState(owner, state, timer) then
        row2 = "BO is not secured yet; the supply line is not active."
        row3 = "If the SoR shows its own countdown, the BO is still in capture/transition."
    elseif type(generationInfo) ~= "table" or generationInfo.canGenerate ~= true then
        if active ~= nil and required ~= nil then
            row2 = "No supply generation: " .. tostring(active) .. "/" .. tostring(required) .. " active BOs."
            row3 = "This keep needs " .. tostring(required) .. " active BOs to generate supplies."
        else
            row2 = "No estimated supply spawn is available."
            row3 = "The BO requirement for this keep could not be calculated."
        end
    elseif active ~= nil and required ~= nil then
        row1 = row1 .. " | BOs " .. tostring(active) .. "/" .. tostring(required)
    end

    setTooltipLabelText(tooltipName .. "Title", title, 255, 206, 64)
    setTooltipLabelText(tooltipName .. "Row1", row1, 210, 230, 255)
    setTooltipLabelText(tooltipName .. "Row2", row2, 230, 230, 230)
    setTooltipLabelText(tooltipName .. "Row3", row3, 255, 230, 120)
    setTooltipLabelText(tooltipName .. "Footer", footer, 175, 175, 175)
end

function showBOTooltipFor(zoneId, boIndex, anchorWindow)
    local tooltipName = getBOTooltipWindow()
    if tooltipName == nil then
        return false
    end

    populateBOTooltipWindow(tooltipName, zoneId, boIndex)

    if type(WindowClearAnchors) == "function" then
        pcall(WindowClearAnchors, tooltipName)
    end
    if type(WindowAddAnchor) == "function" then
        local x = tonumber(KST.BO_TOOLTIP_CURSOR_OFFSET_X) or 16
        local y = tonumber(KST.BO_TOOLTIP_CURSOR_OFFSET_Y) or 16
        local ok = pcall(WindowAddAnchor, tooltipName, "topleft", "CursorWindow", "bottomright", x, y)
        if not ok then
            pcall(WindowAddAnchor, tooltipName, "topleft", anchorWindow or "Root", "bottomleft", 0, 4)
        end
    end
    if type(WindowSetShowing) == "function" then
        pcall(WindowSetShowing, tooltipName, true)
    end

    KST._currentBOTooltip = {
        zoneId = tonumber(zoneId),
        boIndex = tonumber(boIndex),
        anchorWindow = anchorWindow,
    }
    return true
end

function hideBOTooltip()
    local tooltipName = KST.BO_TOOLTIP_WINDOW
    if windowExists(tooltipName) and type(WindowSetShowing) == "function" then
        pcall(WindowSetShowing, tooltipName, false)
    end
    KST._currentBOTooltip = nil
end

function KeepSupplyTimer.OnBOMouseOver(...)
    local candidates = {}

    -- Some WAR/RoR UI callbacks pass the triggering window as an argument,
    -- while other clients only expose it through SystemData.ActiveWindow.
    -- Collect both forms so the BO timer hover works on the actual timer text
    -- and on its invisible hitbox.
    local argCount = select("#", ...)
    for i = 1, argCount do
        local argName = toString(select(i, ...))
        if argName ~= nil and argName ~= "" then
            candidates[#candidates + 1] = argName
        end
    end

    local primaryName = getMouseOverWindowName()
    if primaryName ~= nil and primaryName ~= "" then
        candidates[#candidates + 1] = primaryName
    end

    if type(SystemData) == "table" then
        if type(SystemData.ActiveWindow) == "table" then
            local activeName = toString(SystemData.ActiveWindow.name)
            if activeName ~= nil and activeName ~= "" then
                candidates[#candidates + 1] = activeName
            end
        end
        if type(SystemData.MouseOverWindow) == "table" then
            local mouseName = toString(SystemData.MouseOverWindow.name)
            if mouseName ~= nil and mouseName ~= "" then
                candidates[#candidates + 1] = mouseName
            end
        end
    end

    for _, windowName in ipairs(candidates) do
        local zoneId, boIndex = getBOTooltipDataForWindow(windowName)
        if zoneId ~= nil and boIndex ~= nil then
            showBOTooltipFor(zoneId, boIndex, windowName)
            return
        end
    end
end

function KeepSupplyTimer.OnBOMouseOut()
    hideBOTooltip()
end

local function showBOOverlay(zoneId, boIndex, text)
    local overlayName = ensureBOOverlay(zoneId, boIndex)
    if overlayName == nil then
        return false
    end

    local zoneState = getState(zoneId)
    if zoneState == nil then
        return false
    end
    if type(zoneState.bos[boIndex]) ~= "table" then
        zoneState.bos[boIndex] = {}
    end
    local boState = zoneState.bos[boIndex]

    if boState.lastText ~= text then
        local labelText = toWString(text)
        if type(LabelSetText) == "function" then
            pcall(LabelSetText, overlayName .. "Text", labelText)
            pcall(LabelSetText, overlayName .. "TextBG", labelText)
        end
        boState.lastText = text
    end

    KST.registerBOTooltipWindow(zoneId, boIndex, overlayName)

    if type(WindowSetShowing) == "function" and boState.showing ~= true then
        pcall(WindowSetShowing, overlayName, true)
    end
    KST.ensureBOHoverOverlay(zoneId, boIndex)
    boState.showing = true
    return true
end

local function isBOSecuringState(state)
    return tonumber(state) == KST.BO_SECURING_STATE
end

local function isBOStableOwnedState(owner, state, timer)
    -- Kept for compatibility with older internal function names. In 0.1.10
    -- this means "owned BO with no visible SoR transition timer and capable of
    -- being part of a supply line", not strictly state 0 only.
    return isBOSupplyActiveOwnedState(owner, state, timer)
end

local function resetBOSupplyEstimate(boState)
    boState.securedAt = nil
    boState.supplyCycleAnchor = nil
end

local function startBOSupplyEstimate(boState)
    boState.securedAt = KST._clock
    boState.supplyCycleAnchor = KST._clock
end

local function updateBOState(zoneId, boIndex)

    local zoneState = getState(zoneId)
    if zoneState == nil then
        return
    end
    if type(zoneState.bos[boIndex]) ~= "table" then
        zoneState.bos[boIndex] = {}
    end

    local boState = zoneState.bos[boIndex]
    local boIds = getBOIdsForZone(zoneId)
    local boStates = getBOStatesForZone(zoneId)
    local boTimers = getBOTimersForZone(zoneId)

    local boData = type(boIds) == "table" and type(boIds[boIndex]) == "table" and boIds[boIndex] or nil
    local boId = tonumber(boData and boData.ID) or 0
    local owner = tonumber(boData and boData.Owner) or 0
    local state = type(boStates) == "table" and tonumber(boStates[boIndex]) or nil
    local timer = type(boTimers) == "table" and tonumber(boTimers[boIndex]) or nil

    if boId == 0 and owner == 0 and state == nil and timer == nil then
        boState.observed = false
        boState.id = nil
        boState.owner = nil
        boState.state = nil
        boState.timer = nil
        return
    end

    local isStableNow = isBOStableOwnedState(owner, state, timer)
    local generationInfo = getBOGenerationInfo(zoneId, owner)
    local isGeneratingNow = isStableNow and generationInfo.canGenerate == true

    if boState.observed ~= true or boState.id ~= boId then
        boState.observed = true
        boState.id = boId
        boState.owner = owner
        boState.state = state
        boState.timer = timer
        boState.canGenerate = isGeneratingNow
        boState.activeBOsForRealm = generationInfo.activeBOs
        boState.requiredBOsForSupply = generationInfo.requiredBOs
        boState.keepRankForRealm = generationInfo.keepRank

        if isGeneratingNow and KST.BO_START_TIMER_ON_ALREADY_STABLE then
            startBOSupplyEstimate(boState)
        else
            resetBOSupplyEstimate(boState)
        end
        return
    end

    local previousOwner = tonumber(boState.owner) or 0
    local previousState = tonumber(boState.state)
    local previousCanGenerate = boState.canGenerate == true
    local wasStable = isBOStableOwnedState(previousOwner, previousState, boState.timer)
    local changed = previousOwner ~= owner or previousState ~= state

    if changed and KST._logBOStateChanges then
        appendBOLog("BO_STATE_CHANGED", zoneId, boIndex, boData, previousOwner, owner, previousState, state, timer)
    end

    if isStableNow and (not wasStable or previousOwner ~= owner) then
        if KST._logBOStateChanges then
            appendBOLog("BO_SECURED", zoneId, boIndex, boData, previousOwner, owner, previousState, state, timer)
        end
    end

    if isGeneratingNow then
        if not previousCanGenerate or boState.supplyCycleAnchor == nil or previousOwner ~= owner then
            startBOSupplyEstimate(boState)
            if KST._logBOStateChanges then
                appendBOLog("BO_SUPPLY_GENERATION_STARTED", zoneId, boIndex, boData, previousOwner, owner, previousState, state, timer)
            end
        end
    else
        if previousCanGenerate and KST._logBOStateChanges then
            appendBOLog("BO_SUPPLY_GENERATION_STOPPED", zoneId, boIndex, boData, previousOwner, owner, previousState, state, timer)
        end
        resetBOSupplyEstimate(boState)
    end

    boState.id = boId
    boState.owner = owner
    boState.state = state
    boState.timer = timer
    boState.canGenerate = isGeneratingNow
    boState.activeBOsForRealm = generationInfo.activeBOs
    boState.requiredBOsForSupply = generationInfo.requiredBOs
    boState.keepRankForRealm = generationInfo.keepRank
end

local function getBODisplayText(zoneId, boIndex)
    local boIds = getBOIdsForZone(zoneId)
    local boStates = getBOStatesForZone(zoneId)
    local boTimers = getBOTimersForZone(zoneId)

    local boData = type(boIds) == "table" and type(boIds[boIndex]) == "table" and boIds[boIndex] or nil
    local boId = tonumber(boData and boData.ID) or 0
    local owner = tonumber(boData and boData.Owner) or 0
    local state = type(boStates) == "table" and tonumber(boStates[boIndex]) or nil
    local timer = type(boTimers) == "table" and tonumber(boTimers[boIndex]) or nil

    if boId == 0 or owner == 0 then
        return nil
    end

    -- Do not show RoR_SoR's raw BO timer here. If SoR itself shows a
    -- countdown, that countdown is a transition timer. Once the visible timer
    -- disappears, state 16/0/nil can be treated as part of the supply cycle.
    if not isBOStableOwnedState(owner, state, timer) then
        return nil
    end

    local generationInfo = getBOGenerationInfo(zoneId, owner)
    if KST.BO_REQUIRE_KEEP_LEVEL_FOR_SUPPLY and not generationInfo.canGenerate then
        return nil
    end

    local zoneState = getState(zoneId)
    local boState = zoneState and zoneState.bos and zoneState.bos[boIndex] or nil
    if type(boState) ~= "table" or boState.supplyCycleAnchor == nil then
        return nil
    end

    local interval = tonumber(KST.BO_SUPPLY_INTERVAL) or 42
    if interval <= 0 then
        return nil
    end

    local elapsed = KST._clock - boState.supplyCycleAnchor
    if elapsed < 0 then
        elapsed = 0
    end

    local cycleElapsed = elapsed % interval
    local remaining = interval - cycleElapsed

    return formatCountdown(remaining)
end

local function updateBOTimersForZone(zoneId)
    if not KST._showBOTimers then
        for i = 1, 4 do
            updateBOState(zoneId, i)
        end
        hideBOOverlays(zoneId)
        return
    end

    for i = 1, 4 do
        updateBOState(zoneId, i)
        local text = getBODisplayText(zoneId, i)
        if text ~= nil then
            showBOOverlay(zoneId, i, text)
        else
            hideBOOverlay(zoneId, i)
        end
    end

    if type(KST._currentBOTooltip) == "table" and tonumber(KST._currentBOTooltip.zoneId) == tonumber(zoneId) then
        local tooltipName = KST.BO_TOOLTIP_WINDOW
        local boIndex = tonumber(KST._currentBOTooltip.boIndex)
        if boIndex ~= nil and windowExists(tooltipName) then
            populateBOTooltipWindow(tooltipName, zoneId, boIndex)
        end
    end
end

local function updateZone(zoneId)
    local keeps = getKeepsForZone(zoneId)
    if type(keeps) ~= "table" then
        hideOverlay(zoneId)
        hideBOOverlays(zoneId)
        hideKeepUpgradeHoverOverlays(zoneId)
        return false
    end

    local keepStates = {}
    local keepTexts = {}

    for keepIndex = 1, 2 do
        local keepData = type(keeps[keepIndex]) == "table" and keeps[keepIndex] or nil
        local keepState = updateKeepState(zoneId, keepIndex, keepData)
        keepStates[keepIndex] = keepState
        keepTexts[keepIndex] = getResetBoxText(keepState) or (KST.UNKNOWN_TEXT .. " R:?")
    end

    updateBOTimersForZone(zoneId)
    updateKeepUpgradeHoverOverlays(zoneId)

    if isRiskTextEnabled() then
        showResetPairOverlay(zoneId, keepStates[1], keepTexts[1], keepStates[2], keepTexts[2])
    else
        hideOverlay(zoneId)
    end

    return true
end

local function hideMissingZones(seenZones)
    for zoneId, _ in pairs(KST._states) do
        local zoneNumber = tonumber(zoneId)
        if zoneNumber ~= nil and seenZones[zoneNumber] ~= true then
            hideOverlay(zoneNumber)
            hideBOOverlays(zoneNumber)
            hideKeepUpgradeHoverOverlays(zoneNumber)
        end
    end
end

function KST.Refresh(delta)
    if not KST._enabled then
        local seen = {}
        hideMissingZones(seen)
        return
    end

    local seenZones = {}
    for _, zoneId in ipairs(getOpenZoneIds()) do
        seenZones[zoneId] = true
        updateZone(zoneId)
    end

    hideMissingZones(seenZones)
    refreshCurrentUpgradeTooltip()
    refreshCurrentRiskTooltip()
end

function KST.Reset()
    for zoneId, _ in pairs(KST._states) do
        hideOverlay(tonumber(zoneId))
        hideBOOverlays(tonumber(zoneId))
        hideKeepUpgradeHoverOverlays(tonumber(zoneId))
    end

    hideRiskTooltip()
    KST._states = {}
    chatPrint("Stored observed supply timers reset. New timers will start after the next observed supply increase.")
end

function KST.printStatus()
    local zones = getOpenZoneIds()
    if #zones == 0 then
        chatPrint("No open RoR_SoR zone windows found.")
        return
    end

    for _, zoneId in ipairs(zones) do
        local state = getState(zoneId)
        local o1 = getKeepText(state.keeps[1], 1) or "K1:-"
        local o2 = getKeepText(state.keeps[2], 2) or "K2:-"
        chatPrint("Zone " .. tostring(zoneId) .. ": " .. o1 .. " " .. o2)
    end
end


function KST.printBOStatus()
    local zones = getOpenZoneIds()
    if #zones == 0 then
        chatPrint("No open RoR_SoR zone windows found.")
        return
    end

    for _, zoneId in ipairs(zones) do
        local parts = {}
        for i = 1, 4 do
            local boIds = getBOIdsForZone(zoneId)
            local boStates = getBOStatesForZone(zoneId)
            local boTimers = getBOTimersForZone(zoneId)
            local boData = type(boIds) == "table" and type(boIds[i]) == "table" and boIds[i] or nil
            local owner = tonumber(boData and boData.Owner) or 0
            local state = type(boStates) == "table" and tonumber(boStates[i]) or nil
            local timer = type(boTimers) == "table" and tonumber(boTimers[i]) or nil
            local displayText = getBODisplayText(zoneId, i)
            local generationInfo = getBOGenerationInfo(zoneId, owner)
            local supplyActive = isBOSupplyActiveOwnedState(owner, state, timer)
            parts[#parts + 1] = "BO" .. tostring(i) .. " " .. getBOStateFullText(owner, state) .. " state=" .. toString(state or "?") .. " sorTimer=" .. toString(timer and formatElapsed(timer) or "-") .. " active=" .. toString(supplyActive and "Y" or "N") .. " gen=" .. toString(generationInfo.canGenerate and "Y" or "N") .. " BOs=" .. toString(generationInfo.activeBOs or 0) .. "/" .. toString(generationInfo.requiredBOs or "?") .. " rank=" .. toString(generationInfo.keepRank or "?") .. " supplyEst=" .. toString(displayText or "-")
        end
        chatPrint("Zone " .. tostring(zoneId) .. ": " .. table.concat(parts, " | "))
    end
end

function KST.printLog(limit)
    local entries = type(KeepSupplyTimerLog) == "table" and KeepSupplyTimerLog.events or nil
    if type(entries) ~= "table" or #entries == 0 then
        chatPrint("Log is empty.")
        return
    end

    local count = tonumber(limit) or 10
    if count < 1 then
        count = 10
    end
    if count > 30 then
        count = 30
    end

    local first = #entries - count + 1
    if first < 1 then
        first = 1
    end

    chatPrint("Showing " .. tostring(#entries - first + 1) .. " of " .. tostring(#entries) .. " saved log entries.")
    for i = first, #entries do
        local e = entries[i]
        if e.event == "SERVER_DECAY_TIMER_CANDIDATE_STARTED" or e.event == "SERVER_DECAY_TIMER_CANDIDATE_CANCELLED" or e.event == "SERVER_DECAY_TIMER_REFERENCE_SET" or e.event == "SERVER_DECAY_GLOBAL_REFERENCE_SET" then
            chatPrint(
                "#"
                    .. tostring(i)
                    .. " "
                    .. toString(e.event or "?")
                    .. " "
                    .. toString(e.zoneName or e.zoneId or "?")
                    .. " - "
                    .. toString(e.keepName or "?")
                    .. " ["
                    .. toString(e.realm or "?")
                    .. "] BOs="
                    .. toString(e.activeBOs or "?")
                    .. "/"
                    .. toString(e.requiredBOs or "?")
                    .. " BOdef="
                    .. toString(e.elapsedSinceBORequirementLost or "-")
                    .. " ref="
                    .. toString(e.serverDecayReference or "-")
                    .. " expected="
                    .. toString(e.expectedDecayIn or "-")
                    .. " globalRef="
                    .. toString(e.serverDecayGlobalReference or "-")
                    .. " globalExpected="
                    .. toString(e.expectedGlobalDecayIn or "-")
            )
        elseif e.event == "BO_STATE_CHANGED" or e.event == "BO_SECURED" or e.event == "BO_SUPPLY_GENERATION_STARTED" or e.event == "BO_SUPPLY_GENERATION_STOPPED" then
            chatPrint(
                "#"
                    .. tostring(i)
                    .. " "
                    .. toString(e.event or "?")
                    .. " "
                    .. toString(e.zoneName or e.zoneId or "?")
                    .. " - "
                    .. toString(e.boName or ("BO" .. toString(e.boIndex or "?")))
                    .. " "
                    .. toString(e.stateTextBefore or e.stateNameBefore or "?")
                    .. " -> "
                    .. toString(e.stateTextAfter or e.stateNameAfter or "?")
                    .. " sorTimer="
                    .. toString(e.timerText or "-")
                    .. " active="
                    .. toString(e.supplyActive and "Y" or "N")
                    .. " gen="
                    .. toString(e.supplyGenerating and "Y" or "N")
                    .. " BOs="
                    .. toString(e.activeBOsForRealm or "?")
                    .. "/"
                    .. toString(e.requiredBOsForSupply or "?")
            )
        elseif e.event == "CLAIM_CHANGED" then
            chatPrint(
                "#"
                    .. tostring(i)
                    .. " "
                    .. toString(e.event or "?")
                    .. " "
                    .. toString(e.zoneName or e.zoneId or "?")
                    .. " - "
                    .. toString(e.keepName or "?")
                    .. " "
                    .. toString(e.claimBefore or "?")
                    .. " -> "
                    .. toString(e.claimAfter or "?")
            )
        else
            chatPrint(
                "#"
                    .. tostring(i)
                    .. " "
                    .. toString(e.event or "?")
                    .. " "
                    .. toString(e.zoneName or e.zoneId or "?")
                    .. " - "
                    .. toString(e.keepName or "?")
                    .. " stars="
                    .. toString(e.stars or "?")
                    .. " supply "
                    .. toString(e.supplyBefore or "?")
                    .. "->"
                    .. toString(e.supplyAfter or "?")
                    .. " guild="
                    .. toString(e.guild or e.claim or "?")
                    .. " elapsed="
                    .. toString(e.elapsed or "unknown")
                    .. " BOs="
                    .. toString(e.boOwnedByKeepRealm or "?")
                    .. "/"
                    .. toString(e.boTotal or 4)
                    .. " req="
                    .. toString(e.activeBOs or "?")
                    .. "/"
                    .. toString(e.requiredBOs or "?")
                    .. " BOdef="
                    .. toString(e.elapsedSinceBORequirementLost or "-")
                    .. " lastSup="
                    .. toString(e.elapsedSinceLastSupply or e.elapsed or "unknown")
                    .. " sample="
                    .. toString(e.decaySampleAccepted == true and "Y" or "N")
                    .. " avgBO="
                    .. toString(e.decayAverageFriendlyBOs or "-")
                    .. "/"
                    .. toString(e.decayAverageActiveBOs or "-")
                    .. " enemy="
                    .. toString(e.decayAverageEnemyBOs or "-")
                    .. " below="
                    .. toString(e.decayBelowRequired or "-")
            )
        end
    end
end


function KST.printDecaySamples(limit)
    local count = tonumber(limit) or 10
    if count < 1 then
        count = 10
    end
    if count > 30 then
        count = 30
    end

    local samples = {}
    local storedSamples = type(KeepSupplyTimerLog) == "table" and KeepSupplyTimerLog.decaySamples or nil
    if type(storedSamples) == "table" and #storedSamples > 0 then
        for i, e in ipairs(storedSamples) do
            if type(e) == "table" then
                samples[#samples + 1] = { index = e.decaySampleId or i, event = e }
            end
        end
    else
        local entries = type(KeepSupplyTimerLog) == "table" and KeepSupplyTimerLog.events or nil
        if type(entries) == "table" then
            for i, e in ipairs(entries) do
                if type(e) == "table" and (e.event == "PROGRESS_LOST" or e.event == "RANK_LOST") and e.decaySampleAccepted == true then
                    samples[#samples + 1] = { index = i, event = e }
                end
            end
        end
    end

    if #samples == 0 then
        chatPrint("No accepted decay samples yet. A valid sample needs an observed SUPPLY_DELIVERED before PROGRESS_LOST/RANK_LOST.")
        return
    end

    local first = #samples - count + 1
    if first < 1 then
        first = 1
    end

    chatPrint("Showing " .. tostring(#samples - first + 1) .. " of " .. tostring(#samples) .. " stored decay samples.")
    for i = first, #samples do
        local item = samples[i]
        local e = item.event
        chatPrint(
            "#"
                .. tostring(item.index)
                .. " "
                .. toString(e.zoneName or e.zoneId or "?")
                .. " - "
                .. toString(e.keepName or "?")
                .. " ["
                .. toString(e.realm or "?")
                .. "] stars="
                .. toString(e.stars or "?")
                .. " decay="
                .. toString(e.elapsedSinceLastSupply or e.elapsed or "unknown")
                .. " guild="
                .. toString(e.guild or e.claim or "?")
                .. " rawBOavg="
                .. toString(e.decayAverageFriendlyBOs or "-")
                .. " activeBOavg="
                .. toString(e.decayAverageActiveBOs or "-")
                .. " enemyBOavg="
                .. toString(e.decayAverageEnemyBOs or "-")
                .. " below="
                .. toString(e.decayBelowRequired or "-")
                .. " missScore="
                .. toString(e.decayMissingBOScore or "-")
        )
    end
end

function KST.clearLog()
    KeepSupplyTimerLog = KeepSupplyTimerLog or {}
    KeepSupplyTimerLog.version = KST.VERSION
    KeepSupplyTimerLog.events = {}
    KeepSupplyTimerLog.decaySamples = {}
    KeepSupplyTimerLog.decaySamplesLastId = nil
    KeepSupplyTimerLog.lastDecaySample = nil
    KeepSupplyTimerLog.lastDecaySampleId = nil
    KeepSupplyTimerLog.lastDecaySampleAt = nil
    KeepSupplyTimerLog.lastDecaySampleSessionSeconds = nil
    KeepSupplyTimerLog.decayTrackingSnapshotLastId = nil
    KeepSupplyTimerLog.lastDecayTrackingSnapshot = nil
    KeepSupplyTimerLog.lastDecayTrackingSnapshotAt = nil
    KeepSupplyTimerLog.lastDecayTrackingSnapshotSessionSeconds = nil
    KeepSupplyTimerLog.lastEvent = nil
    KeepSupplyTimerLog.serverDecayReferenceSeconds = nil
    KeepSupplyTimerLog.serverDecayReference = nil
    KeepSupplyTimerLog.serverDecayGlobalReferenceSessionSeconds = nil
    KeepSupplyTimerLog.serverDecayGlobalReference = nil
    KeepSupplyTimerLog.serverDecayGlobalReferenceEvent = nil
    KeepSupplyTimerLog.serverDecayGlobalReferenceZoneName = nil
    KeepSupplyTimerLog.serverDecayGlobalReferenceKeepName = nil
    KeepSupplyTimerLog.serverDecayGlobalIntervalSeconds = nil
    KeepSupplyTimerLog.serverDecayGlobalInterval = nil
    KST._serverDecayGlobalReferenceSessionSeconds = nil
    KST._serverDecayGlobalReferenceEventIndex = nil
    KST.SafeAppendFileLogControlLine("--- KeepSupplyTimer clearlog at " .. getEventTimeText() .. " ---")
    chatPrint("Saved supply/decay log cleared, including server decay references. " .. getFileLogStatusText())
end

function KST.printKeepUpgrades(filter)
    local filterText = toString(filter)
    if filterText ~= "" then
        filterText = string.lower(filterText)
    end

    local stores = {}
    if type(KST._keepUpgrades) == "table" then
        for _, store in pairs(KST._keepUpgrades) do
            if type(store) == "table" then
                if filterText == "" or string.find(string.lower(toString(store.keepName)), filterText, 1, true) ~= nil then
                    stores[#stores + 1] = store
                end
            end
        end
    end

    table.sort(stores, function(a, b) return toString(a.keepName) < toString(b.keepName) end)

    if #stores == 0 then
        chatPrint("No keep upgrades detected from chat yet.")
        return
    end

    for _, store in ipairs(stores) do
        local text = buildUpgradeTooltipText(store.keepName)
        for line in string.gmatch(text, "[^\n]+") do
            chatPrint(line)
        end
    end
end

function KST.clearKeepUpgrades()
    KST._keepUpgrades = {}
    KST._lastUpgradeChatKey = nil
    KST._lastUpgradeChatAt = nil
    persistKeepUpgrades("clear")
    if type(KeepSupplyTimerUpgradeState) == "table" then
        KeepSupplyTimerUpgradeState.keepUpgrades = {}
    end
    if type(KeepSupplyTimerSettings) == "table" then
        KeepSupplyTimerSettings.keepUpgradesBackup = {}
    end
    KST.SafeAppendFileLogControlLine("--- KeepSupplyTimer clearupgrades at " .. getEventTimeText() .. " ---")
    chatPrint("Detected keep upgrades cleared.")
end


function KST.printRiskStatus()
    local zones = getOpenZoneIds()
    if #zones == 0 then
        chatPrint("No open RoR_SoR zone windows found.")
        return
    end

    for _, zoneId in ipairs(zones) do
        local state = getState(zoneId)
        for keepIndex = 1, 2 do
            local keepState = state and state.keeps and state.keeps[keepIndex] or nil
            if type(keepState) == "table" and keepState.keepId ~= nil then
                local name = getKeepNameText(keepState.keepId, keepIndex)
                chatPrint(formatRiskInfoForChat(toString(getZoneNameText(zoneId)) .. " - " .. toString(name), keepState))
            end
        end
    end
end

function clearHybridDecayPredictions()
    for _, zoneState in pairs(KST._states or {}) do
        if type(zoneState) == "table" and type(zoneState.keeps) == "table" then
            for keepIndex = 1, 2 do
                local keepState = zoneState.keeps[keepIndex]
                if type(keepState) == "table" then
                    clearHybridDecayPrediction(keepState, "UNKNOWN", "Prediction reset manually.")
                    keepState.decayLastStateChangeAt = nil
                    keepState.lastResetBoxText = nil
                end
            end
        end
    end
end

function printDecayPredictionStatus(debugMode)
    local zones = getOpenZoneIds()
    if #zones == 0 then
        chatPrint("No open RoR_SoR zone windows found.")
        return
    end

    local _, mode = getActiveDecayModel()
    chatPrint("Hybrid decay model: " .. tostring(mode) .. ".")
    for _, zoneId in ipairs(zones) do
        local state = getState(zoneId)
        for keepIndex = 1, 2 do
            local keepState = state and state.keeps and state.keeps[keepIndex] or nil
            if type(keepState) == "table" and keepState.keepId ~= nil then
                local name = getKeepNameText(keepState.keepId, keepIndex)
                local risk = getKeepRiskInfo(keepState)
                local line = toString(getZoneNameText(zoneId)) .. " - " .. toString(name)
                    .. " | " .. toString(risk.short or "D:?")
                    .. " " .. toString(risk.label or "Unknown")
                    .. " | supply=" .. toString(keepState.lastSupply or "?") .. "%"
                    .. " | lastSup=" .. toString(risk.elapsedSec ~= nil and formatElapsed(risk.elapsedSec) or "?")
                    .. " | BOs=" .. toString(risk.activeBOs or "?") .. "/" .. toString(risk.requiredBOs or "?")
                if risk.timeToArmedSec ~= nil and risk.timeToArmedSec > 0 then
                    line = line .. " | armedIn=" .. formatElapsed(risk.timeToArmedSec)
                end
                if risk.timeToCriticalSec ~= nil and risk.timeToCriticalSec > 0 then
                    line = line .. " | criticalIn=" .. formatElapsed(risk.timeToCriticalSec)
                end
                if risk.criticalOverdueSec ~= nil and risk.criticalOverdueSec > 0 then
                    line = line .. " | critical+" .. formatElapsed(risk.criticalOverdueSec)
                end
                if debugMode == true then
                    line = line .. " | armedAt=" .. toString(keepState.decayArmedAt and formatElapsed(keepState.decayArmedAt) or "-")
                        .. " | criticalAt=" .. toString(keepState.decayCriticalAt and formatElapsed(keepState.decayCriticalAt) or "-")
                        .. " | segmentAt=" .. toString(keepState.decaySegmentStartedAt and formatElapsed(keepState.decaySegmentStartedAt) or "-")
                        .. " | grace=" .. toString(keepState.decayGraceSeconds or "-")
                        .. " | reason=" .. toString(keepState.decayPredictionReason or "?")
                end
                chatPrint(line)
            end
        end
    end
end



function KST.NPCSafeCallOne(fnName, ...)
    local fn = _G and _G[fnName] or nil
    if type(fn) ~= "function" then
        return nil
    end
    local ok, value = pcall(fn, ...)
    if ok then
        return value
    end
    return nil
end

function KST.NPCSafeCallTwo(fnName, ...)
    local fn = _G and _G[fnName] or nil
    if type(fn) ~= "function" then
        return nil, nil
    end
    local ok, a, b = pcall(fn, ...)
    if ok then
        return a, b
    end
    return nil, nil
end

function KST.NPCGetWindowTextProbe(windowName)
    local text = nil

    if type(LabelGetText) == "function" then
        local ok, value = pcall(LabelGetText, windowName)
        if ok and value ~= nil then
            text = toString(value)
        end
    end

    if (text == nil or text == "") and type(ButtonGetText) == "function" then
        local ok, value = pcall(ButtonGetText, windowName)
        if ok and value ~= nil then
            text = toString(value)
        end
    end

    if (text == nil or text == "") and type(TextEditBoxGetText) == "function" then
        local ok, value = pcall(TextEditBoxGetText, windowName)
        if ok and value ~= nil then
            text = toString(value)
        end
    end

    if (text == nil or text == "") and type(WindowGetText) == "function" then
        local ok, value = pcall(WindowGetText, windowName)
        if ok and value ~= nil then
            text = toString(value)
        end
    end

    return text
end

function KST.NPCGetWindowChildrenProbe(windowName)
    if type(WindowGetChildren) == "function" then
        local ok, children = pcall(WindowGetChildren, windowName)
        if ok and type(children) == "table" then
            return children
        end
    end

    if type(WindowGetChildCount) == "function" and type(WindowGetChild) == "function" then
        local okCount, count = pcall(WindowGetChildCount, windowName)
        count = tonumber(count)
        if okCount and count ~= nil and count > 0 then
            local children = {}
            for i = 1, count do
                local okChild, child = pcall(WindowGetChild, windowName, i)
                if okChild and child ~= nil then
                    children[#children + 1] = toString(child)
                end
            end
            return children
        end
    end

    return nil
end

function KST.NPCSanitizeLogValue(value)
    local text = toString(value)
    text = string.gsub(text, "\n", " ")
    text = string.gsub(text, "\r", " ")
    text = string.gsub(text, "|", "/")
    return text
end

function KST.NPCAppendRawLine(tag, data)
    local line = "[KST_NPC] " .. toString(tag)
    if type(data) == "table" then
        for key, value in pairs(data) do
            line = line .. " | " .. toString(key) .. "=" .. KST.NPCSanitizeLogValue(value)
        end
    end
    KST.SafeAppendFileLogControlLine(line)
end


function KST.NPCLogWindowNode(windowName, depth)
    local showing = KST.NPCSafeCallOne("WindowGetShowing", windowName)
    local x, y = KST.NPCSafeCallTwo("WindowGetScreenPosition", windowName)
    local w, h = KST.NPCSafeCallTwo("WindowGetDimensions", windowName)
    local text = KST.NPCGetWindowTextProbe(windowName)

    appendFileLogLine({
        event = "NPC_UPGRADE_WINDOW_NODE",
        observedAt = getEventTimeText(),
        sessionSeconds = math.floor(tonumber(KST._clock) or 0),
    })

    KST.NPCAppendRawLine("NODE", {
        time = getEventTimeText(),
        session = math.floor(tonumber(KST._clock) or 0),
        windowName = toString(windowName),
        depth = tonumber(depth) or 0,
        showing = showing,
        x = tonumber(x),
        y = tonumber(y),
        width = tonumber(w),
        height = tonumber(h),
        text = text,
    })

    return text
end


function KST.NPCProbeKnownWindow(windowName, tag)
    if windowName == nil or windowName == "" then
        return false
    end

    local exists = windowExists(windowName)
    local showing = KST.NPCSafeCallOne("WindowGetShowing", windowName)
    local x, y = KST.NPCSafeCallTwo("WindowGetScreenPosition", windowName)
    local w, h = KST.NPCSafeCallTwo("WindowGetDimensions", windowName)
    local text = KST.NPCGetWindowTextProbe(windowName)

    if exists or text ~= nil or tonumber(w) ~= nil then
        KST.NPCAppendRawLine("PROBE", {
            tag = tag,
            windowName = toString(windowName),
            exists = exists,
            showing = showing,
            x = tonumber(x),
            y = tonumber(y),
            width = tonumber(w),
            height = tonumber(h),
            text = text,
        })
        return true
    end

    return false
end

function KST.NPCProbeKnownUpgradeControls()
    local root = toString(KST.NPC_UPGRADE_WINDOW)
    local list = root .. "ListBox"
    local found = 0

    KST.NPCAppendRawLine("KNOWN_PROBE_START", {
        time = getEventTimeText(),
        session = math.floor(tonumber(KST._clock) or 0),
        root = root,
    })

    if KST.NPCProbeKnownWindow(root, "root") then found = found + 1 end
    if KST.NPCProbeKnownWindow(list, "list") then found = found + 1 end

    for row = 1, 8 do
        local rowName = list .. "Row" .. tostring(row)
        if KST.NPCProbeKnownWindow(rowName, "row" .. tostring(row)) then found = found + 1 end

        for side = 1, 2 do
            local prefix = rowName
            local suffix = tostring(side)
            local candidates = {
                prefix .. "Upgrade" .. suffix,
                prefix .. "Name" .. suffix,
                prefix .. "Rank" .. suffix,
                prefix .. "Rank" .. suffix .. "Text",
                prefix .. "RankText" .. suffix,
                prefix .. "Rank" .. suffix .. "Label",
                prefix .. "Cost" .. suffix,
                prefix .. "Cost" .. suffix .. "Text",
                prefix .. "CostText" .. suffix,
                prefix .. "Time" .. suffix,
                prefix .. "Time" .. suffix .. "Text",
                prefix .. "TimeText" .. suffix,
                prefix .. "Increase" .. suffix,
                prefix .. "Decrease" .. suffix,
                prefix .. "Plus" .. suffix,
                prefix .. "Minus" .. suffix,
                prefix .. "PlusButton" .. suffix,
                prefix .. "MinusButton" .. suffix,
                prefix .. "Button" .. suffix,
            }

            for _, candidate in ipairs(candidates) do
                if KST.NPCProbeKnownWindow(candidate, "row" .. tostring(row) .. "_side" .. suffix) then
                    found = found + 1
                end
            end
        end
    end

    KST.NPCAppendRawLine("KNOWN_PROBE_END", {
        time = getEventTimeText(),
        session = math.floor(tonumber(KST._clock) or 0),
        found = found,
    })

    chatPrint("NPC known-control probe complete. found=" .. tostring(found) .. ". Check [KST_NPC] PROBE lines in the log.")
    return found
end



function KST.NPCReadText(windowName)
    local text = KST.NPCGetWindowTextProbe(windowName)
    text = toString(text)
    text = string.gsub(text, "^%s+", "")
    text = string.gsub(text, "%s+$", "")
    return text
end

function KST.NPCReadShowing(windowName)
    local showing = KST.NPCSafeCallOne("WindowGetShowing", windowName)
    return showing == true
end

function KST.NPCParseTimeSeconds(text)
    local value = string.lower(toString(text))
    value = string.gsub(value, "^%s+", "")
    value = string.gsub(value, "%s+$", "")
    if value == "" then
        return nil
    end

    local h, m, s = string.match(value, "^(%d+):(%d%d):(%d%d)$")
    if h ~= nil then
        return (tonumber(h) or 0) * 3600 + (tonumber(m) or 0) * 60 + (tonumber(s) or 0)
    end

    m, s = string.match(value, "^(%d+):(%d%d)$")
    if m ~= nil then
        return (tonumber(m) or 0) * 60 + (tonumber(s) or 0)
    end

    local total = 0
    local found = false
    local hours = string.match(value, "(%d+)%s*h")
    if hours ~= nil then
        total = total + (tonumber(hours) or 0) * 3600
        found = true
    end
    local minutes = string.match(value, "(%d+)%s*m")
    if minutes ~= nil then
        total = total + (tonumber(minutes) or 0) * 60
        found = true
    end
    local seconds = string.match(value, "(%d+)%s*s")
    if seconds ~= nil then
        total = total + (tonumber(seconds) or 0)
        found = true
    end

    if found then
        return total
    end

    local justNumber = string.match(value, "^(%d+)$")
    if justNumber ~= nil then
        return tonumber(justNumber)
    end

    return nil
end

function KST.NPCResolveKeepName(rawName)
    local input = toString(rawName)
    input = string.gsub(input, "^%s+", "")
    input = string.gsub(input, "%s+$", "")

    if input ~= "" then
        local canonicalId = getCanonicalKeepIdFromName(input)
        if canonicalId ~= nil and type(KST.CANONICAL_KEEPS) == "table" and type(KST.CANONICAL_KEEPS[canonicalId]) == "table" then
            return KST.CANONICAL_KEEPS[canonicalId].name
        end

        local zones = getOpenZoneIds()
        for _, zoneId in ipairs(zones) do
            local keeps = getKeepsForZone(zoneId)
            if type(keeps) == "table" then
                for keepIndex = 1, 2 do
                    local keepData = type(keeps[keepIndex]) == "table" and keeps[keepIndex] or nil
                    local keepId = tonumber(keepData and keepData.ID)
                    local keepName = getKeepNameText(keepId, keepIndex)
                    if normalizeKeepLooseKey(keepName) == normalizeKeepLooseKey(input) then
                        return keepName
                    end
                end
            end
        end

        return input
    end

    local root = toString(KST.NPC_UPGRADE_WINDOW)
    local candidates = {
        root .. "KeepName",
        root .. "KeepNameText",
        root .. "Name",
        root .. "NameText",
        root .. "Title",
        root .. "TitleText",
        root .. "Header",
        root .. "HeaderText",
        root .. "HeaderKeepName",
        root .. "HeaderKeepNameText",
        root .. "TopKeepName",
        root .. "TopKeepNameText",
    }

    for _, windowName in ipairs(candidates) do
        local text = KST.NPCReadText(windowName)
        if text ~= "" and text ~= "Upgrade Keep" then
            return KST.NPCResolveKeepName(text)
        end
    end

    return nil
end


function KST.NPCNormalizeUpgradeName(value)
    local text = string.lower(toString(value))
    text = string.gsub(text, "[\226\128\153\226\128\156\226\128\157]", "'")
    text = string.gsub(text, "[^%w]+", "")
    return text
end

function KST.NPCGetPlayerOpenKeepCandidates()
    local candidates = {}
    local playerRealm = getPlayerRealmId()
    local zones = getOpenZoneIds()

    for _, zoneId in ipairs(zones) do
        local keeps = getKeepsForZone(zoneId)
        if type(keeps) == "table" then
            for keepIndex = 1, 2 do
                local keepData = type(keeps[keepIndex]) == "table" and keeps[keepIndex] or nil
                local owner = tonumber(keepData and keepData.Realm) or tonumber(keepData and keepData.realm) or tonumber(keepData and keepData.Owner) or tonumber(keepData and keepData.owner) or tonumber(keepData and keepData.OwnedBy)
                if owner == nil and type(keepData) == "table" then
                    owner = tonumber(keepData.realmId) or tonumber(keepData.RealmId) or tonumber(keepData.ownerId) or tonumber(keepData.OwnerId)
                end

                if playerRealm == nil or owner == playerRealm then
                    local keepId = tonumber(keepData and keepData.ID)
                    local keepName = getKeepNameText(keepId, keepIndex)
                    candidates[#candidates + 1] = {
                        zoneId = zoneId,
                        zoneName = getZoneNameText(zoneId),
                        keepIndex = keepIndex,
                        keepId = keepId,
                        keepName = keepName,
                        owner = owner,
                    }
                end
            end
        end
    end

    table.sort(candidates, function(a, b)
        local az = toString(a.zoneName)
        local bz = toString(b.zoneName)
        if az == bz then
            return tonumber(a.keepIndex) < tonumber(b.keepIndex)
        end
        return az < bz
    end)

    return candidates
end

function KST.NPCPrintPlayerOpenKeepCandidates()
    local candidates = KST.NPCGetPlayerOpenKeepCandidates()
    if #candidates == 0 then
        chatPrint("NPC read: no open player-realm keep candidates found.")
        return candidates
    end

    chatPrint("NPC read candidates. Use /ksupply npcread 1, /ksupply npcread 2, etc.")
    for i, item in ipairs(candidates) do
        chatPrint(tostring(i) .. ". " .. toString(item.zoneName) .. " - " .. toString(item.keepName))
    end
    return candidates
end

function KST.NPCResolveKeepNameFromArgument(rawKeepName)
    local input = toString(rawKeepName)
    input = string.gsub(input, "^%s+", "")
    input = string.gsub(input, "%s+$", "")

    if input == "" then
        local candidates = KST.NPCPrintPlayerOpenKeepCandidates()
        if #candidates == 1 then
            return candidates[1].keepName
        end
        return nil
    end

    local index = tonumber(input)
    if index ~= nil then
        local candidates = KST.NPCGetPlayerOpenKeepCandidates()
        local selected = candidates[index]
        if type(selected) == "table" then
            return selected.keepName
        end
        chatPrint("NPC read: candidate #" .. tostring(index) .. " not found.")
        KST.NPCPrintPlayerOpenKeepCandidates()
        return nil
    end

    return KST.NPCResolveKeepName(input)
end


function KST.NPCRemoveUpgradeRecords(store, upgradeName)
    if type(store) ~= "table" or type(store.upgrades) ~= "table" then
        return 0
    end

    local removed = 0
    local target = KST.NPCNormalizeUpgradeName(upgradeName)
    for key, record in pairs(store.upgrades) do
        if type(record) == "table" and KST.NPCNormalizeUpgradeName(record.name) == target then
            store.upgrades[key] = nil
            removed = removed + 1
        end
    end

    return removed
end

function KST.NPCRecordUpgradeState(keepName, upgradeName, rank, state, remainingSeconds, rawText)
    local rankNumber = tonumber(rank)
    if keepName == nil or upgradeName == nil or upgradeName == "" or rankNumber == nil then
        return nil
    end

    local store = ensureKeepUpgradeStore(keepName)
    if store == nil then
        return nil
    end

    if rankNumber <= 0 and state == "none" then
        local removed = KST.NPCRemoveUpgradeRecords(store, upgradeName)
        if removed > 0 then
            store.lastUpdateAt = getEventTimeText()
            store.lastUpdateSessionSeconds = math.floor(tonumber(KST._clock) or 0)
            store.lastUpdateEpoch = getRealEpochSeconds()
        end
        return nil
    end

    local parsed = {
        zoneName = "NPC",
        keepName = keepName,
        upgradeName = upgradeName,
        rank = rankNumber,
        rawText = rawText,
    }

    if state == "building" then
        parsed.remainingSeconds = tonumber(remainingSeconds)
        if rankNumber <= 0 then
            parsed.state = "removing"
            parsed.statusText = "removing " .. formatCountdown(parsed.remainingSeconds or 0)
            -- A timed R0 row in the NPC keep-upgrade window is the game's
            -- deconstruction/removal representation. Remove stale building/built
            -- entries for the same upgrade before writing the removal state.
            KST.NPCRemoveUpgradeRecords(store, upgradeName)
        else
            parsed.state = "building"
            parsed.statusText = "building " .. formatCountdown(parsed.remainingSeconds or 0)
        end
    else
        parsed.state = "built"
        parsed.remainingSeconds = 0
        parsed.statusText = "built"
    end

    local record = recordKSTSyncedUpgrade(parsed)
    if type(record) == "table" then
        record.source = "npc-window"
        record.syncZoneName = nil
        record.syncReceivedAt = nil
        record.rawText = rawText

        if record.name == "Divine Favor Altar" and state ~= "building" then
            local nowSession = math.floor(tonumber(KST._clock) or 0)
            local nowEpoch = getRealEpochSeconds()
            local interval = 15 * 60

            record.state = "building"
            record.durationSeconds = 0
            record.buildEndsAtSessionSeconds = nowSession
            record.buildEndsEpoch = nowEpoch
            record.buildEndsAt = getEndTimeText(record.buildEndsEpoch, record.buildEndsAtSessionSeconds)
            record.firstChargeDelaySeconds = 0
            record.firstChargeAtSessionSeconds = nowSession
            record.firstChargeEpoch = nowEpoch
            record.firstChargeAt = getEndTimeText(record.firstChargeEpoch, record.firstChargeAtSessionSeconds)
            record.rechargeIntervalSeconds = interval
            record.maxCharges = 3
            record.divineManualCharges = nil
            record.divineChargesUnknown = true
            record.divineBadEstimate = true
            record.divineEstimateStartedAt = getEventTimeText()
            record.divineEstimateStartedSessionSeconds = nowSession
            record.divineEstimateStartedEpoch = nowEpoch
            record.divineNextChargeAtSessionSeconds = nowSession + interval
            if nowEpoch ~= nil then
                record.divineNextChargeEpoch = nowEpoch + interval
            else
                record.divineNextChargeEpoch = nil
            end
            record.divineNextChargeAt = getEndTimeText(record.divineNextChargeEpoch, record.divineNextChargeAtSessionSeconds)
        end

        if record.name == "Divine Favor Altar" then
            KST._lastDivineFavorAltarContext = KST.MemoryResetContextFromArg(keepName)
            KST.ApplyDivineFavorChargeSnapshot(record, store, "npc-read")
            KST.SafeAppendFileLogControlLine("[KST_DIVINE_ALTAR_CONTEXT] source=npc-read keep=" .. toString(keepName))
        end
    end

    return record
end

function KST.ReadNPCUpgradeWindow(rawKeepName)
    local root = toString(KST.NPC_UPGRADE_WINDOW)
    if not windowExists(root) then
        chatPrint("NPC upgrade window not found: " .. root)
        return false
    end

    local keepName = KST.NPCResolveKeepNameFromArgument(rawKeepName)
    if keepName == nil or keepName == "" then
        chatPrint("NPC read stopped: choose a candidate with /ksupply npcread 1 or pass the keep name.")
        return false
    end

    local list = root .. "ListBox"
    local found = 0
    local active = 0
    local building = 0
    local skipped = 0
    local removed = 0
    local lines = {}

    for row = 1, 8 do
        local rowName = list .. "Row" .. tostring(row)
        for side = 1, 2 do
            local suffix = tostring(side)
            local upgradeWindow = rowName .. "Upgrade" .. suffix
            local rankWindow = rowName .. "Rank" .. suffix
            local timeWindow = rowName .. "Time" .. suffix

            local upgradeName = KST.NPCReadText(upgradeWindow)
            local rankText = KST.NPCReadText(rankWindow)
            local timeText = KST.NPCReadText(timeWindow)
            local rankNumber = tonumber(rankText)
            local timeSeconds = KST.NPCParseTimeSeconds(timeText)
            local timeShowing = KST.NPCReadShowing(timeWindow)

            if upgradeName ~= "" and rankNumber ~= nil then
                found = found + 1
                local state = "none"
                if timeSeconds ~= nil and timeSeconds > 0 then
                    state = "building"
                    building = building + 1
                elseif rankNumber > 0 then
                    state = "built"
                    active = active + 1
                else
                    skipped = skipped + 1
                end

                local beforeRemove = 0
                if state == "none" then
                    local store = ensureKeepUpgradeStore(keepName)
                    beforeRemove = KST.NPCRemoveUpgradeRecords(store, upgradeName)
                    if beforeRemove > 0 then
                        removed = removed + beforeRemove
                    end
                else
                    KST.NPCRecordUpgradeState(keepName, upgradeName, rankNumber, state, timeSeconds, "NPC window scan")
                end

                lines[#lines + 1] = upgradeName .. " R" .. tostring(rankNumber) .. " " .. state .. (timeSeconds ~= nil and (" " .. formatCountdown(timeSeconds)) or "")

                KST.NPCAppendRawLine("READ_ROW", {
                    keepName = keepName,
                    row = row,
                    side = side,
                    upgrade = upgradeName,
                    rank = rankNumber,
                    time = timeText,
                    timeShowing = timeShowing,
                    state = state,
                    removed = beforeRemove,
                })
            end
        end
    end

    local store = ensureKeepUpgradeStore(keepName)
    if type(store) == "table" then
        rebuildKeepUpgradeStoreAliases(store)
        store.lastUpdateAt = getEventTimeText()
        store.lastUpdateSessionSeconds = math.floor(tonumber(KST._clock) or 0)
        store.lastUpdateEpoch = getRealEpochSeconds()
    end

    persistKeepUpgrades("npc-window")

    KST.NPCAppendRawLine("READ_END", {
        keepName = keepName,
        found = found,
        active = active,
        building = building,
        skipped = skipped,
        removed = removed,
    })

    chatPrint("NPC read: " .. keepName .. " found=" .. tostring(found) .. " active=" .. tostring(active) .. " building=" .. tostring(building) .. " skipped=" .. tostring(skipped) .. " removed=" .. tostring(removed) .. ".")
    return found > 0
end


function KST.NPCScanWindowRecursive(windowName, depth, visited, state)
    if windowName == nil or windowName == "" then
        return
    end
    if state.count >= state.limit then
        return
    end
    if visited[windowName] == true then
        return
    end

    visited[windowName] = true
    state.count = state.count + 1

    local text = KST.NPCLogWindowNode(windowName, depth)
    if text ~= nil and text ~= "" then
        state.textCount = state.textCount + 1
        if state.textCount <= 14 then
            chatPrint("NPC text: " .. toString(windowName) .. " = " .. toString(text))
        end
    end

    local children = KST.NPCGetWindowChildrenProbe(windowName)
    if type(children) == "table" then
        for _, child in ipairs(children) do
            KST.NPCScanWindowRecursive(toString(child), depth + 1, visited, state)
            if state.count >= state.limit then
                return
            end
        end
    end
end

function KST.NPCPrintCurrentMouseoverWindow()
    local mouseWin = getMouseOverWindowName()
    if mouseWin ~= nil and mouseWin ~= "" then
        chatPrint("Mouseover window: " .. toString(mouseWin))
        KST.NPCLogWindowNode(mouseWin, 0)
    end
end

function KST.ScanNPCUpgradeWindow()
    local root = KST.NPC_UPGRADE_WINDOW
    if not windowExists(root) then
        chatPrint("NPC upgrade window not found: " .. toString(root))
        KST.NPCPrintCurrentMouseoverWindow()
        return false
    end

    local showing = KST.NPCSafeCallOne("WindowGetShowing", root)
    local x, y = KST.NPCSafeCallTwo("WindowGetScreenPosition", root)
    local w, h = KST.NPCSafeCallTwo("WindowGetDimensions", root)

    appendFileLogLine({
        event = "NPC_UPGRADE_WINDOW_SCAN_START",
        observedAt = getEventTimeText(),
        sessionSeconds = math.floor(tonumber(KST._clock) or 0),
    })
    KST.NPCAppendRawLine("SCAN_START", {
        time = getEventTimeText(),
        session = math.floor(tonumber(KST._clock) or 0),
        windowName = root,
        showing = showing,
        x = tonumber(x),
        y = tonumber(y),
        width = tonumber(w),
        height = tonumber(h),
    })

    chatPrint("Scanning NPC upgrade window: " .. root .. " showing=" .. tostring(showing) .. " size=" .. tostring(w or "?") .. "x" .. tostring(h or "?"))

    local state = {
        count = 0,
        textCount = 0,
        limit = tonumber(KST.NPC_UPGRADE_SCAN_LIMIT) or 260,
    }
    KST.NPCScanWindowRecursive(root, 0, {}, state)
    KST.NPCProbeKnownUpgradeControls()

    appendFileLogLine({
        event = "NPC_UPGRADE_WINDOW_SCAN_END",
        observedAt = getEventTimeText(),
        sessionSeconds = math.floor(tonumber(KST._clock) or 0),
    })
    KST.NPCAppendRawLine("SCAN_END", {
        time = getEventTimeText(),
        session = math.floor(tonumber(KST._clock) or 0),
        windowName = root,
        scannedWindows = state.count,
        textWindows = state.textCount,
    })

    if state.count <= 1 then
        chatPrint("NPC scan found the root only. Hover rows/buttons and run /ksupply npchover to log exact child names.")
    else
        chatPrint("NPC scan complete. windows=" .. tostring(state.count) .. " textWindows=" .. tostring(state.textCount) .. ". Check KeepSupplyTimerLog.txt.")
    end

    return true
end

function KST.LogNPCMouseoverWindow()
    local mouseWin = getMouseOverWindowName()
    if mouseWin == nil or mouseWin == "" then
        chatPrint("No mouseover window detected.")
        KST.NPCAppendRawLine("MOUSEOVER_NONE", {
            time = getEventTimeText(),
            session = math.floor(tonumber(KST._clock) or 0),
        })
        return false
    end

    local text = KST.NPCLogWindowNode(mouseWin, 0)
    KST.NPCAppendRawLine("MOUSEOVER", {
        time = getEventTimeText(),
        session = math.floor(tonumber(KST._clock) or 0),
        windowName = toString(mouseWin),
        text = text,
    })
    chatPrint("Logged mouseover window: " .. toString(mouseWin) .. (text ~= nil and text ~= "" and (" text=" .. text) or ""))
    return true
end


function KST.BuffDebugSafeText(value)
    local text = toString(value)
    text = string.gsub(text, "\n", " ")
    text = string.gsub(text, "\r", " ")
    text = string.gsub(text, "%s+", " ")
    text = string.gsub(text, "^%s+", "")
    text = string.gsub(text, "%s+$", "")
    return text
end

function KST.BuffDebugMaybeRecord(sourceName, pathText, value, out)
    if type(value) ~= "table" or type(out) ~= "table" then
        return
    end

    local name = KST.BuffDebugSafeText(value.name or value.Name or value.effectName or value.EffectName or value.abilityName or value.AbilityName or value.displayName or value.DisplayName)
    local icon = KST.BuffDebugSafeText(value.icon or value.Icon or value.iconNum or value.iconId or value.IconId or value.iconID or value.IconID)
    local effectId = KST.BuffDebugSafeText(value.id or value.ID or value.effectId or value.effectID or value.EffectId or value.EffectID or value.buffId or value.buffID or value.BuffId or value.BuffID or value.abilityId or value.abilityID or value.AbilityId or value.AbilityID)
    local duration = KST.BuffDebugSafeText(value.duration or value.Duration or value.durationRemaining or value.DurationRemaining or value.remaining or value.Remaining or value.timeRemaining or value.TimeRemaining)
    local stacks = KST.BuffDebugSafeText(value.stacks or value.Stacks or value.stackCount or value.StackCount)
    local caster = KST.BuffDebugSafeText(value.casterName or value.CasterName or value.caster or value.Caster or value.sourceName or value.SourceName)

    if name == "" and effectId == "" and icon == "" and duration == "" then
        return
    end

    local lower = string.lower(name)
    local interesting = false
    if lower ~= "" then
        if string.find(lower, "divine") ~= nil or string.find(lower, "intervention") ~= nil or string.find(lower, "favor") ~= nil or string.find(lower, "favour") ~= nil or string.find(lower, "bless") ~= nil then
            interesting = true
        end
    end

    out[#out + 1] = {
        source = toString(sourceName),
        path = toString(pathText),
        name = name,
        id = effectId,
        icon = icon,
        duration = duration,
        stacks = stacks,
        caster = caster,
        interesting = interesting,
    }
end

function KST.BuffDebugWalk(sourceName, value, pathText, depth, out, visited)
    if type(value) ~= "table" or type(out) ~= "table" then
        return
    end
    if tonumber(depth) == nil or tonumber(depth) <= 0 then
        return
    end
    if type(visited) ~= "table" then
        visited = {}
    end
    if visited[value] == true then
        return
    end
    visited[value] = true

    KST.BuffDebugMaybeRecord(sourceName, pathText, value, out)

    local count = 0
    for key, child in pairs(value) do
        count = count + 1
        if count > 220 then
            break
        end
        if type(child) == "table" then
            KST.BuffDebugWalk(sourceName, child, toString(pathText) .. "." .. toString(key), tonumber(depth) - 1, out, visited)
        end
    end
end

function KST.BuffDebugCollect()
    local out = {}
    if type(GameData) == "table" then
        KST.BuffDebugWalk("GameData.Player.effects", GameData.Player and (GameData.Player.effects or GameData.Player.Effects or GameData.Player.buffs or GameData.Player.Buffs), "GameData.Player.effects", 4, out, {})
        KST.BuffDebugWalk("GameData.Player", GameData.Player, "GameData.Player", 3, out, {})
        KST.BuffDebugWalk("GameData.Buffs", GameData.Buffs or GameData.buffs, "GameData.Buffs", 4, out, {})
        KST.BuffDebugWalk("GameData.Effects", GameData.Effects or GameData.effects, "GameData.Effects", 4, out, {})
        KST.BuffDebugWalk("GameData.PlayerEffects", GameData.PlayerEffects or GameData.playerEffects, "GameData.PlayerEffects", 4, out, {})
    end
    if type(SystemData) == "table" then
        KST.BuffDebugWalk("SystemData.Player", SystemData.Player, "SystemData.Player", 3, out, {})
        KST.BuffDebugWalk("SystemData.Buffs", SystemData.Buffs or SystemData.buffs, "SystemData.Buffs", 4, out, {})
        KST.BuffDebugWalk("SystemData.Effects", SystemData.Effects or SystemData.effects, "SystemData.Effects", 4, out, {})
    end

    return out
end

function KST.BuffDebugLine(item)
    return "[KST_BUFF] source=" .. toString(item.source)
        .. " path=" .. toString(item.path)
        .. " name=" .. toString(item.name)
        .. " id=" .. toString(item.id)
        .. " icon=" .. toString(item.icon)
        .. " duration=" .. toString(item.duration)
        .. " stacks=" .. toString(item.stacks)
        .. " caster=" .. toString(item.caster)
end

function KST.BuffItemIsDivineIntervention(item)
    if type(item) ~= "table" then
        return false
    end

    local wanted = tostring(tonumber(KST.DIVINE_INTERVENTION_BUFF_ID) or 31095)
    local id = toString(item.id)
    if id == wanted then
        return true
    end

    local name = string.lower(toString(item.name))
    if name == "divine intervention" then
        return true
    end

    return false
end

function KST.BuffHeadStyleCollectSelfBuffs()
    local effects = nil

    if type(GetBuffs) == "function" and type(GameData) == "table" and type(GameData.BuffTargetType) == "table" and GameData.BuffTargetType.SELF ~= nil then
        local ok, result = pcall(GetBuffs, GameData.BuffTargetType.SELF)
        if ok then
            effects = result
        end
    end

    return effects
end

function KST.BuffEffectGetId(effect)
    if type(effect) ~= "table" then
        return nil
    end

    return tonumber(effect.abilityId)
        or tonumber(effect.abilityID)
        or tonumber(effect.AbilityId)
        or tonumber(effect.AbilityID)
        or tonumber(effect.id)
        or tonumber(effect.ID)
        or tonumber(effect.effectId)
        or tonumber(effect.effectID)
        or tonumber(effect.EffectId)
        or tonumber(effect.EffectID)
        or tonumber(effect.buffId)
        or tonumber(effect.buffID)
        or tonumber(effect.BuffId)
        or tonumber(effect.BuffID)
end

function KST.BuffEffectGetName(effect)
    if type(effect) ~= "table" then
        return ""
    end

    return KST.BuffDebugSafeText(effect.name or effect.Name or effect.effectName or effect.EffectName or effect.abilityName or effect.AbilityName)
end

function KST.BuffEffectGetRemainingSeconds(effect)
    if type(effect) ~= "table" then
        return nil
    end

    local candidates = {
        effect.durationRemaining,
        effect.DurationRemaining,
        effect.remaining,
        effect.Remaining,
        effect.timeRemaining,
        effect.TimeRemaining,
        effect.remainingTime,
        effect.RemainingTime,
        effect.secondsRemaining,
        effect.SecondsRemaining,
        effect.duration,
        effect.Duration,
    }

    for _, value in ipairs(candidates) do
        local number = tonumber(value)
        if number ~= nil then
            return number
        end
    end

    return nil
end

function KST.BuffEffectIsDivineIntervention(effect)
    local wanted = tonumber(KST.DIVINE_INTERVENTION_BUFF_ID) or 31095
    local id = KST.BuffEffectGetId(effect)
    if id ~= nil and id == wanted then
        return true
    end

    local name = string.lower(KST.BuffEffectGetName(effect))
    if name == "divine intervention" then
        return true
    end

    return false
end

function KST.FindDivineInterventionBuffFromEffects(effects)
    if type(effects) ~= "table" then
        return nil
    end

    for key, effect in pairs(effects) do
        if KST.BuffEffectIsDivineIntervention(effect) then
            return {
                source = "GetBuffs(SELF)",
                path = "GetBuffs.SELF." .. toString(key),
                name = KST.BuffEffectGetName(effect),
                id = toString(KST.BuffEffectGetId(effect) or ""),
                icon = KST.BuffDebugSafeText(effect.icon or effect.Icon or effect.iconNum or effect.iconId or effect.IconId),
                duration = KST.BuffDebugSafeText(effect.duration or effect.Duration or effect.durationRemaining or effect.DurationRemaining or effect.remaining or effect.Remaining or effect.timeRemaining or effect.TimeRemaining),
                remainingSeconds = KST.BuffEffectGetRemainingSeconds(effect),
                stacks = KST.BuffDebugSafeText(effect.stacks or effect.Stacks or effect.stackCount or effect.StackCount),
                caster = KST.BuffDebugSafeText(effect.casterName or effect.CasterName or effect.caster or effect.Caster),
            }
        end
    end

    return nil
end

function KST.FindDivineInterventionBuff()
    local effects = KST.BuffHeadStyleCollectSelfBuffs()
    local buff = KST.FindDivineInterventionBuffFromEffects(effects)
    if buff ~= nil then
        return buff
    end

    -- Fallback to the older broad diagnostic collector. This is slower and less
    -- reliable, so it is only used if BuffHead-style GetBuffs(SELF) did not find it.
    local items = KST.BuffDebugCollect()
    for _, item in ipairs(items) do
        if KST.BuffItemIsDivineIntervention(item) then
            return item
        end
    end
    return nil
end

function KST.HandleDivineInterventionBuffDetected(item, reason)
    local now = tonumber(KST._clock) or 0
    reason = toString(reason)
    if reason == "" then
        reason = "applied"
    end

    -- A refresh is detected by a clear remaining-time jump, so the old 10s
    -- debounce would hide valid recasts. Keep a very small guard only against
    -- duplicate handling inside the same scan/frame.
    if tonumber(KST._lastDivineInterventionBuffUseAt) ~= nil and (now - tonumber(KST._lastDivineInterventionBuffUseAt)) < 1 then
        return false
    end

    KST._lastDivineInterventionBuffUseAt = now

    local record, store, matchReason = KST.FindDivineFavorAltarForBuff()
    if type(record) ~= "table" or type(store) ~= "table" then
        appendFileLogLine({
            event = "DIVINE_INTERVENTION_BUFF_UNMATCHED",
            observedAt = getEventTimeText(),
            sessionSeconds = math.floor(now),
            buffId = toString(item and item.id),
            buffName = toString(item and item.name),
            buffRemaining = tonumber(item and item.remainingSeconds),
            reason = toString(reason),
            matchReason = toString(matchReason),
        })
        chatPrint("Divine Intervention buff detected, but no unique Divine Favor Altar could be matched.")
        return false
    end

    local beforeStatus, beforeRemaining, beforeCharges, beforeMaxCharges = getDivineFavorRecordStatusForUse(record)
    local usedRecord = KST.RecordDivineFavorChargeUsed(record, store, "buff-31095-" .. toString(reason), "Divine Intervention buff id 31095 detected; reason=" .. toString(reason))
    local _, _, afterCharges, maxCharges = getDivineFavorRecordStatusForUse(usedRecord)

    appendFileLogLine({
        event = "DIVINE_INTERVENTION_BUFF_DETECTED",
        observedAt = getEventTimeText(),
        sessionSeconds = math.floor(now),
        buffId = toString(item and item.id),
        buffName = toString(item and item.name),
        buffRemaining = tonumber(item and item.remainingSeconds),
        keepName = toString(record.keepName or store.keepName),
        reason = toString(reason),
        matchReason = toString(matchReason),
        beforeCharges = beforeCharges,
        afterCharges = afterCharges,
    })

    local remainingText = ""
    if tonumber(item and item.remainingSeconds) ~= nil then
        remainingText = " remaining=" .. formatCountdown(tonumber(item.remainingSeconds))
    end
    chatPrint("Divine Intervention buff " .. toString(reason) .. ": " .. toString(record.keepName or store.keepName) .. " " .. tostring(beforeCharges or 0) .. "/" .. tostring(beforeMaxCharges or 3) .. " -> " .. tostring(afterCharges or 0) .. "/" .. tostring(maxCharges or 3) .. "." .. remainingText)
    return true
end

function KST.CheckDivineInterventionBuff(force)
    local item = KST.FindDivineInterventionBuff()
    if item ~= nil then
        local remaining = tonumber(item.remainingSeconds)
        local previousRemaining = tonumber(KST._divineInterventionBuffLastRemaining)
        local shouldHandle = false
        local reason = "applied"

        if force == true then
            shouldHandle = true
            reason = "manual-check"
        elseif KST._divineInterventionBuffWasActive ~= true then
            shouldHandle = true
            reason = "applied"
        elseif remaining ~= nil and previousRemaining ~= nil then
            local minRemaining = tonumber(KST.DIVINE_INTERVENTION_REFRESH_MIN_REMAINING) or 90
            local jumpSeconds = tonumber(KST.DIVINE_INTERVENTION_REFRESH_JUMP_SECONDS) or 20
            if remaining >= minRemaining and remaining > (previousRemaining + jumpSeconds) then
                shouldHandle = true
                reason = "refreshed"
            end
        end

        if shouldHandle == true then
            local handled = KST.HandleDivineInterventionBuffDetected(item, reason)
            if handled == true then
                KST._divineInterventionBuffWasActive = true
            else
                -- Do not lock detection if matching failed. Keep retrying every
                -- scan while the buff is active until an altar can be matched.
                KST._divineInterventionBuffWasActive = false
            end
        else
            KST._divineInterventionBuffWasActive = true
        end

        KST._divineInterventionBuffLastRemaining = remaining
        return true
    end

    KST._divineInterventionBuffWasActive = false
    KST._divineInterventionBuffLastRemaining = nil
    return false
end

function KST.BuffDebugDump(reason)
    local items = KST.BuffDebugCollect()
    KST.SafeAppendFileLogControlLine("[KST_BUFF_DUMP] reason=" .. toString(reason or "?") .. " count=" .. tostring(#items))

    local interestingCount = 0
    for _, item in ipairs(items) do
        if item.interesting == true then
            interestingCount = interestingCount + 1
            KST.SafeAppendFileLogControlLine(KST.BuffDebugLine(item) .. " interesting=1")
        end
    end

    if interestingCount == 0 then
        for i, item in ipairs(items) do
            if i > 80 then
                KST.SafeAppendFileLogControlLine("[KST_BUFF] truncated after 80 entries")
                break
            end
            KST.SafeAppendFileLogControlLine(KST.BuffDebugLine(item))
        end
    end

    chatPrint("Buff debug dump written. entries=" .. tostring(#items) .. " interesting=" .. tostring(interestingCount) .. ".")
end

function KST.BuffDebugSnapshot()
    local items = KST.BuffDebugCollect()
    local seen = KST._buffDebugSeen or {}
    local newCount = 0

    for _, item in ipairs(items) do
        local key = toString(item.source) .. "|" .. toString(item.path) .. "|" .. toString(item.name) .. "|" .. toString(item.id) .. "|" .. toString(item.icon)
        if seen[key] ~= true then
            seen[key] = true
            newCount = newCount + 1
            if item.interesting == true then
                KST.SafeAppendFileLogControlLine(KST.BuffDebugLine(item) .. " new=1 interesting=1")
            else
                KST.SafeAppendFileLogControlLine(KST.BuffDebugLine(item) .. " new=1")
            end
        end
    end

    KST._buffDebugSeen = seen
    if newCount > 0 then
        KST.SafeAppendFileLogControlLine("[KST_BUFF_SCAN] new=" .. tostring(newCount) .. " totalSeen=" .. tostring(#items))
    end
end

function KST.BuffDebugHover()
    local mouseWin = nil
    if type(SystemData) == "table" and type(SystemData.MouseOverWindow) == "table" then
        mouseWin = SystemData.MouseOverWindow.name
    end
    if mouseWin == nil or mouseWin == "" then
        chatPrint("Buff hover debug: no mouseover window.")
        KST.SafeAppendFileLogControlLine("[KST_BUFF_HOVER] none")
        return
    end

    chatPrint("Buff hover window: " .. toString(mouseWin))
    KST.SafeAppendFileLogControlLine("[KST_BUFF_HOVER] window=" .. toString(mouseWin))

    if type(KST.NPCLogWindowNode) == "function" then
        local text = KST.NPCLogWindowNode(mouseWin, 0)
        KST.SafeAppendFileLogControlLine("[KST_BUFF_HOVER_TEXT] window=" .. toString(mouseWin) .. " text=" .. toString(text))
    end
end

function KST.BuffDebugRegisterEvents()
    local events = type(SystemData) == "table" and type(SystemData.Events) == "table" and SystemData.Events or nil
    if type(events) ~= "table" then
        return 0
    end

    local registered = 0
    for name, value in pairs(events) do
        local lname = string.lower(toString(name))
        if string.find(lname, "effect") ~= nil or string.find(lname, "buff") ~= nil or string.find(lname, "ability") ~= nil then
            if type(RegisterEventHandler) == "function" then
                local ok = pcall(RegisterEventHandler, value, "KeepSupplyTimer.OnBuffDebugEvent")
                if ok then
                    registered = registered + 1
                    KST.SafeAppendFileLogControlLine("[KST_BUFF_EVENT_REGISTER] name=" .. toString(name) .. " value=" .. toString(value))
                end
            end
            if type(RegisterEvent) == "function" then
                pcall(RegisterEvent, value)
            end
        end
    end

    return registered
end

function KeepSupplyTimer.OnBuffDebugEvent(...)
    if KST._buffDebugEnabled ~= true then
        return
    end

    KST.SafeAppendFileLogControlLine("[KST_BUFF_EVENT] args=" .. tostring(select("#", ...)))
    KST.BuffDebugSnapshot()
end



local function getAnalysisLogStatusText()
    local analysis = type(KeepSupplyTimerSettings) == "table" and KeepSupplyTimerSettings.analysisLogEnabled == true
    return "analysislog=" .. (analysis and "on" or "off")
        .. " filelog=" .. (isFileLogEnabled() and "on" or "off")
        .. " research=" .. ((type(KeepSupplyTimerSettings) == "table" and KeepSupplyTimerSettings.researchEnabled ~= false) and "on" or "off")
        .. " bolog=" .. (KST._logBOStateChanges == true and "on" or "off")
        .. " claimlog=" .. (KST._logClaimChanges == true and "on" or "off")
        .. " decaylog=" .. (KST.LOG_DECAYS == true and "on" or "off")
end

function KST.SetAnalysisLogging(enabled, quiet)
    enabled = enabled == true
    KeepSupplyTimerSettings = KeepSupplyTimerSettings or {}
    KeepSupplyTimerSettings.analysisLogEnabled = enabled
    KeepSupplyTimerSettings.fileLogEnabled = enabled
    KeepSupplyTimerSettings.researchEnabled = enabled

    KST._logBOStateChanges = enabled
    KST._logClaimChanges = enabled
    KST.LOG_DELIVERIES = enabled
    KST.LOG_DECAYS = enabled
    KST.LOG_SERVER_TIMER_CANDIDATES = enabled
    KST.LOG_DECAY_TRACKING_SNAPSHOTS = enabled

    if enabled then
        KST._fileLogFailed = false
        initializeFileLog()
    end

    if quiet ~= true then
        if enabled then
            chatPrint("Analysis logging enabled. BO/claim/decay/research/file logs are ON. " .. getFileLogStatusText())
        else
            chatPrint("Analysis logging disabled. Public mode: BO/claim/decay/research/file logs are OFF.")
        end
    end
end

function KST.printHelp()
    chatPrint("Commands: /ksupply on, /ksupply off, /ksupply reset, /ksupply status, /ksupply bos, /ksupply botimers on|off, /ksupply analysislog on|off|status, /ksupply bolog on|off, /ksupply claimlog on|off, /ksupply upgradehover on|off, /ksupply upgrades [keep], /ksupply scanupgrades, /ksupply npcscan, /ksupply npcprobe, /ksupply npcread [keep], /ksupply npchover, /ksupply guild, /ksupply zone, /ksupply buffdebug on|off, /ksupply buffdump, /ksupply buffcheck, /ksupply buffhover, /ksupply resetupgrades [keep|n], /ksupply saveupgrades, /ksupply clearupgrades, /ksupply research on|off|status, /ksupply risk on|off|status|aggressive|normal, /ksupply decay, /ksupply decaydebug, /ksupply decayreset, /ksupply decaymodel aggressive|normal, /ksupply filelog on|off|status, /ksupply save, /ksupply log [n], /ksupply samples [n], /ksupply clearlog, /ksupply help.")
end

function KST.HandleSlash(input)
    local args = {}
    for word in string.gmatch(toString(input), "%S+") do
        args[#args + 1] = string.lower(word)
    end

    local command = args[1] or ""
    if command == "" or command == "help" then
        KST.printHelp()
    elseif command == "on" then
        KST._enabled = true
        chatPrint("Enabled.")
    elseif command == "off" then
        KST._enabled = false
        for zoneId, _ in pairs(KST._states) do
            hideOverlay(tonumber(zoneId))
            hideBOOverlays(tonumber(zoneId))
            hideKeepUpgradeHoverOverlays(tonumber(zoneId))
        end
        hideKeepUpgradeTooltip()
        hideRiskTooltip()
        chatPrint("Disabled.")
    elseif command == "reset" then
        KST.Reset()
    elseif command == "status" then
        KST.printStatus()
    elseif command == "bos" then
        KST.printBOStatus()
    elseif command == "botimers" then
        local value = args[2] or ""
        if value == "off" then
            KST._showBOTimers = false
            for zoneId, _ in pairs(KST._states) do
                hideBOOverlays(tonumber(zoneId))
            end
            chatPrint("BO timers disabled.")
        else
            KST._showBOTimers = true
            chatPrint("BO timers enabled.")
        end
    elseif command == "analysislog" or command == "researchlog" or command == "debuglog" then
        local value = args[2] or ""
        if value == "on" then
            KST.SetAnalysisLogging(true)
        elseif value == "off" then
            KST.SetAnalysisLogging(false)
        else
            chatPrint("Analysis logging status: " .. getAnalysisLogStatusText() .. ". Use /ksupply analysislog on|off.")
        end
    elseif command == "bolog" then
        local value = args[2] or ""
        if value == "off" then
            KST._logBOStateChanges = false
            chatPrint("BO state-change logging disabled.")
        else
            KST._logBOStateChanges = true
            chatPrint("BO state-change logging enabled.")
        end
    elseif command == "claimlog" then
        local value = args[2] or ""
        if value == "off" then
            KST._logClaimChanges = false
            chatPrint("Keep claim-change logging disabled.")
        else
            KST._logClaimChanges = true
            chatPrint("Keep claim-change logging enabled.")
        end
    elseif command == "upgradehover" then
        local value = args[2] or ""
        if value == "off" then
            KST.SHOW_KEEP_UPGRADE_TOOLTIPS = false
            for zoneId, _ in pairs(KST._states) do
                hideKeepUpgradeHoverOverlays(tonumber(zoneId))
            end
            hideKeepUpgradeTooltip()
            chatPrint("Keep upgrade SoR hover tooltips disabled.")
        else
            KST.SHOW_KEEP_UPGRADE_TOOLTIPS = true
            chatPrint("Keep upgrade SoR hover tooltips enabled.")
        end
    elseif command == "upgrades" or command == "upgrade" then
        KST.printKeepUpgrades(args[2])
    elseif command == "scanupgrades" then
        local matched = pollChatLogsForKeepUpgrades(true)
        chatPrint("Scanned recent chat log for keep upgrades. matched=" .. tostring(matched == true))
    elseif command == "npcscan" then
        KST.ScanNPCUpgradeWindow()
    elseif command == "guild" then
        chatPrint("Detected player guild: " .. toString(KST.GetPlayerGuildName() or "?"))
        if type(KST._shareContext) == "table" then
            chatPrint("Selected keep claim: " .. toString(getKeepClaimText(KST._shareContext.keepData)))
        end
    elseif command == "zone" then
        chatPrint("Detected current zone: id=" .. toString(KST.GetCurrentPlayerZoneId() or "?") .. " name=" .. toString(KST.GetCurrentPlayerZoneName() or "?"))
    elseif command == "buffdebug" then
        local value = args[2] or ""
        if value == "on" then
            KST._buffDebugEnabled = true
            KST._buffDebugSeen = {}
            local registered = KST.BuffDebugRegisterEvents()
            chatPrint("Buff debug enabled. registeredEvents=" .. tostring(registered) .. ". Use /ksupply buffdump while Divine Intervention is active.")
            KST.BuffDebugDump("enable")
        elseif value == "off" then
            KST._buffDebugEnabled = false
            chatPrint("Buff debug disabled.")
        else
            chatPrint("Buff debug is " .. tostring(KST._buffDebugEnabled == true and "on" or "off") .. ". Use /ksupply buffdebug on|off, /ksupply buffdump, /ksupply buffhover.")
        end
    elseif command == "buffdump" then
        KST.BuffDebugDump("manual")
    elseif command == "buffcheck" then
        local found = KST.CheckDivineInterventionBuff(true)
        chatPrint("Divine Intervention buff check: " .. tostring(found == true and "found" or "not found") .. ".")
    elseif command == "buffhover" then
        KST.BuffDebugHover()
    elseif command == "resetupgrades" or command == "resetkeepupgrades" or command == "resetcurrent" then
        local resetArg = ""
        local rawInput = toString(input)
        local firstSpace = string.find(rawInput, "%s+")
        if firstSpace ~= nil then
            resetArg = string.gsub(string.sub(rawInput, firstSpace + 1), "^%s+", "")
        end
        KST.MemoryResetSlash(resetArg)
    elseif command == "npcprobe" then
        KST.NPCProbeKnownUpgradeControls()
    elseif command == "npcread" then
        local keepNameArg = ""
        local rawInput = toString(input)
        local firstSpace = string.find(rawInput, "%s+")
        if firstSpace ~= nil then
            keepNameArg = string.gsub(string.sub(rawInput, firstSpace + 1), "^%s+", "")
        end
        KST.ReadNPCUpgradeWindow(keepNameArg)
    elseif command == "npchover" then
        KST.LogNPCMouseoverWindow()
    elseif command == "divinecharges" then
        local keepArg = args[2] or ""
        local chargeArg = args[3] or ""
        local context = nil
        if tonumber(keepArg) ~= nil then
            context = KST.MemoryResetContextFromArg(keepArg)
        elseif keepArg ~= "" and chargeArg ~= "" then
            context = KST.MemoryResetContextFromArg(keepArg)
        elseif type(KST._shareContext) == "table" then
            context = KST._shareContext
            chargeArg = keepArg
        end
        KST.SetDivineFavorChargesForContext(context, tonumber(chargeArg), "slash")
    elseif command == "saveupgrades" then
        persistKeepUpgrades("manual")
        chatPrint("Keep upgrade state prepared for SavedVariables. It will survive /reloadui and normal logout.")
    elseif command == "debugupgradechat" then
        local value = args[2] or ""
        if value == "on" then
            KST.DEBUG_KEEP_UPGRADE_CHAT = true
            chatPrint("Keep upgrade chat debug enabled.")
        else
            KST.DEBUG_KEEP_UPGRADE_CHAT = false
            chatPrint("Keep upgrade chat debug disabled.")
        end
    elseif command == "clearupgrades" then
        KST.clearKeepUpgrades()
    elseif command == "research" then
        local value = args[2] or ""
        if value == "off" then
            KeepSupplyTimerSettings.researchEnabled = false
            KeepSupplyTimerSettings.analysisLogEnabled = false
            chatPrint("Decay research ticks disabled.")
        elseif value == "on" then
            KeepSupplyTimerSettings.researchEnabled = true
            chatPrint("Decay research ticks enabled. interval=" .. tostring(KST.RESEARCH_TICK_INTERVAL) .. "s.")
        else
            local enabledText = KeepSupplyTimerSettings.researchEnabled ~= false and "ON" or "OFF"
            chatPrint("Decay research ticks: " .. enabledText .. ". interval=" .. tostring(KST.RESEARCH_TICK_INTERVAL) .. "s. Events: DECAY_RESEARCH_TICK.")
        end
    elseif command == "risk" then
        local value = args[2] or ""
        if value == "off" then
            KeepSupplyTimerSettings.showRiskText = false
            for zoneId, _ in pairs(KST._states) do
                local zoneState = getState(tonumber(zoneId))
                if zoneState ~= nil then
                    zoneState.lastText = nil
                end
            end
            hideRiskTooltip()
            chatPrint("Keep decay risk indicator disabled.")
        elseif value == "on" then
            KeepSupplyTimerSettings.showRiskText = true
            for zoneId, _ in pairs(KST._states) do
                local zoneState = getState(tonumber(zoneId))
                if zoneState ~= nil then
                    zoneState.lastText = nil
                end
            end
            chatPrint("Keep decay risk indicator enabled. Hover each lower-corner reset box to show details.")
        elseif value == "aggressive" or value == "normal" then
            KeepSupplyTimerSettings.decayPredictionMode = normalizeDecayMode(value)
            chatPrint("Hybrid decay model set to " .. tostring(KeepSupplyTimerSettings.decayPredictionMode) .. ".")
            printDecayPredictionStatus(false)
        else
            local enabledText = isRiskTextEnabled() and "ON" or "OFF"
            local _, mode = getActiveDecayModel()
            chatPrint("Keep decay risk indicator: " .. enabledText .. ". Model=" .. tostring(mode) .. ". Levels: D:0% no progress, D:OK safe, D:? unknown, D:AG aging, D:AR armed, D:CR critical, D:ST stabilized. Hover each lower-corner reset box for details.")
            KST.printRiskStatus()
        end
    elseif command == "decay" then
        printDecayPredictionStatus(false)
    elseif command == "decaydebug" then
        printDecayPredictionStatus(true)
    elseif command == "decayreset" then
        clearHybridDecayPredictions()
        hideRiskTooltip()
        chatPrint("Hybrid decay predictions reset. New predictions will start from current keep/supply observations.")
    elseif command == "decaymodel" then
        local value = args[2] or ""
        if value == "normal" or value == "aggressive" then
            KeepSupplyTimerSettings.decayPredictionMode = normalizeDecayMode(value)
            chatPrint("Hybrid decay model set to " .. tostring(KeepSupplyTimerSettings.decayPredictionMode) .. ".")
            printDecayPredictionStatus(false)
        else
            local _, mode = getActiveDecayModel()
            chatPrint("Hybrid decay model: " .. tostring(mode) .. ". Use /ksupply decaymodel aggressive or /ksupply decaymodel normal.")
        end
    elseif command == "filelog" then
        local value = args[2] or ""
        if value == "off" then
            KeepSupplyTimerSettings.fileLogEnabled = false
            KeepSupplyTimerSettings.analysisLogEnabled = false
            chatPrint("File log disabled. " .. getFileLogStatusText())
        elseif value == "on" then
            KeepSupplyTimerSettings.fileLogEnabled = true
            KST._fileLogFailed = false
            initializeFileLog()
            chatPrint("File log enabled. " .. getFileLogStatusText())
        else
            chatPrint(getFileLogStatusText())
        end
    elseif command == "save" or command == "savelog" then
        saveFileLogNow()
    elseif command == "savevars" then
        saveFileLogNow()
        persistKeepUpgrades("manual")
        chatPrint("Keep upgrades are stored in SavedVariables for /reloadui. Decay/BO analysis remains in the text log.")
    elseif command == "samples" or command == "decaysamples" then
        KST.printDecaySamples(args[2])
    elseif command == "log" then
        KST.printLog(args[2])
    elseif command == "clearlog" then
        KST.clearLog()
    else
        chatPrint("Unknown command: " .. command)
        KST.printHelp()
    end
end

function KST.TryRegisterSlash()
    if KST._slashRegistered then
        return true
    end

    if KST._slashTries >= KST.SLASH_RETRY_LIMIT then
        return false
    end

    KST._slashTries = KST._slashTries + 1

    if type(LibSlash) ~= "table" then
        return false
    end

    local register = LibSlash.RegisterWSlashCmd
    if type(register) ~= "function" then
        register = LibSlash.RegisterSlashCmd
    end

    if type(register) ~= "function" then
        return false
    end

    register("ksupply", function(input) KST.HandleSlash(input) end)
    pcall(register, "kst", function(input) KST.HandleSlash(input) end)
    KST._slashRegistered = true
    return true
end

function KeepSupplyTimer.OnInitialize()
    KeepSupplyTimerLog = KeepSupplyTimerLog or {}
    KeepSupplyTimerLog.version = KST.VERSION
    KeepSupplyTimerLog.events = KeepSupplyTimerLog.events or {}
    KeepSupplyTimerLog.decaySamples = KeepSupplyTimerLog.decaySamples or {}
    KeepSupplyTimerSettings = KeepSupplyTimerSettings or {}
    if KeepSupplyTimerSettings.fileLogEnabled == nil then
        KeepSupplyTimerSettings.fileLogEnabled = KST.FILE_LOG_ENABLED_DEFAULT
    end
    if KeepSupplyTimerSettings.researchEnabled == nil then
        KeepSupplyTimerSettings.researchEnabled = KST.RESEARCH_TICKS_ENABLED_DEFAULT
    end
    if KeepSupplyTimerSettings.analysisLogEnabled == nil then
        KeepSupplyTimerSettings.analysisLogEnabled = KST.ANALYSIS_LOGGING_DEFAULT
    end
    KST.SetAnalysisLogging(KeepSupplyTimerSettings.analysisLogEnabled == true, true)
    if KeepSupplyTimerSettings.showRiskText == nil then
        KeepSupplyTimerSettings.showRiskText = KST.SHOW_RISK_TEXT_DEFAULT
    end
    if KeepSupplyTimerSettings.decayPredictionMode == nil then
        KeepSupplyTimerSettings.decayPredictionMode = KST.DECAY_PREDICTION_MODE_DEFAULT
    else
        KeepSupplyTimerSettings.decayPredictionMode = normalizeDecayMode(KeepSupplyTimerSettings.decayPredictionMode)
    end
    if KeepSupplyTimerSettings.shareChannel == nil then
        KeepSupplyTimerSettings.shareChannel = "warband"
    end
    if KeepSupplyTimerSettings.keepUpgradesBackup == nil then
        KeepSupplyTimerSettings.keepUpgradesBackup = {}
    end
    KST._serverDecayGlobalReferenceSessionSeconds = nil
    KST._serverDecayGlobalReferenceEventIndex = nil
    restoreKeepUpgradesFromSavedVariables()
    initializeFileLog()
    KST.RegisterChatEvents()
    pollChatLogsForKeepUpgrades(false)
    KST.TryRegisterSlash()
end

function KeepSupplyTimer.OnUpdate(elapsed)
    local delta = tonumber(elapsed) or 0
    if delta <= 0 then
        return
    end

    KST._clock = KST._clock + delta
    KST._elapsed = KST._elapsed + delta
    if KST._elapsed < KST.REFRESH_INTERVAL then
        return
    end

    local refreshDelta = KST._elapsed
    KST._elapsed = 0

    if not KST._slashRegistered and KST._slashTries < KST.SLASH_RETRY_LIMIT then
        KST.TryRegisterSlash()
    end
    if not KST._chatEventsRegistered then
        KST.RegisterChatEvents()
    end

    KST._chatLogPollElapsed = (tonumber(KST._chatLogPollElapsed) or 0) + refreshDelta
    if KST._chatLogPollElapsed >= (tonumber(KST.CHAT_LOG_POLL_INTERVAL) or 1) then
        KST._chatLogPollElapsed = 0
        pollChatLogsForKeepUpgrades(false)
    end

    KST._divineInterventionBuffScanElapsed = (tonumber(KST._divineInterventionBuffScanElapsed) or 0) + refreshDelta
    if KST._divineInterventionBuffScanElapsed >= (tonumber(KST.DIVINE_INTERVENTION_BUFF_SCAN_INTERVAL) or 3) then
        KST._divineInterventionBuffScanElapsed = 0
        KST.CheckDivineInterventionBuff()
    end

    if KST._buffDebugEnabled == true then
        KST._buffDebugLastScanAt = (tonumber(KST._buffDebugLastScanAt) or 0) + refreshDelta
        if KST._buffDebugLastScanAt >= 1 then
            KST._buffDebugLastScanAt = 0
            KST.BuffDebugSnapshot()
        end
    end

    KST.Refresh(refreshDelta)
end
