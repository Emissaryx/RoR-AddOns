KeepSupplyTimer 1.0.0

Adds keep supply timers, BO countdowns, decay risk and keep upgrade info to State of Realm.

# KeepSupplyTimer

## 0.2.10

- Fix del tooltip del temporizador de siguiente supply en BO: se añade un hitbox propio, registro explícito de ventanas BO y fallback para `ActiveWindow`/`MouseOverWindow`.
- El tooltip del BO muestra ahora el estado de generación, BOs activos/requeridos y la estimación local del siguiente supply.
 0.1.39

# KeepSupplyTimer 0.1.28

Addon experimental para Return of Reckoning que se superpone al `State of Realm` (`RoR_SoR`).

## Créditos

Desarrollado por Kpihuss y Gingerbel.

## Qué muestra

- Tiempo desde la última subida observada de suministro del keep. Si el keep pierde rango o su progreso se resetea, el contador local se reinicia desde ese momento para no seguir arrastrando el tiempo anterior.
- Temporizador estimado sobre BOs cuando la BO ya puede formar parte de la línea de supplies: owner Order/Destro, sin temporizador interno visible de SoR, y con estado `16` (`Securing` sin cuenta atrás), `0` o estado interno vacío/nil.
- No muestra temporizador durante `Capping` (`state == 4`).
- No muestra temporizador durante `Securing` mientras SoR aún muestra una cuenta atrás, porque ese contador es la transición de asegurar la bandera, no el respawn de supply.
- El temporizador de BO solo aparece si el reino controla suficientes BOs activas según el rango del keep. Hipótesis usada: rango 1-2 necesita 2 BOs, rango 3 necesita 3 BOs, rango 4+ necesita 4 BOs.

La estimación de supply de BO usa un ciclo local de 42 segundos desde el momento en que el addon observa que la BO ya está activa y generando supplies según la regla anterior. Si el addon se carga cuando la BO ya estaba generando, empieza igualmente una estimación local desde ese momento, porque RoR_SoR no expone un temporizador real de respawn de supply cuando la bandera ya está activa.


A partir de la 0.1.18, el log de texto de `/logs` vuelve a usar un único fichero fijo: `logs/KeepSupplyTimerLog.txt`, en modo append-safe, para evitar que los datos anteriores se borren al hacer `/reloadui` o recargar el addon. El buffer interno del TextLog está ampliado a 50000 líneas.

A partir de la 0.1.21, mientras un keep tiene una muestra activa desde un `SUPPLY_DELIVERED`, el addon escribe snapshots periódicos `DECAY_TRACKING_SNAPSHOT` en el log de texto cada 15 segundos. Estos snapshots guardan los acumuladores finos aunque luego haya `/reloadui` antes del decay real.

A partir de la 0.1.35, el addon añade un modo de investigación de decay. Mientras un keep tiene un supply observado y está por debajo del requisito de BOs, registra `DECAY_RESEARCH_TICK` cada 5 segundos. Estos ticks son los casos negativos necesarios para distinguir fórmula determinista, timer pausado por BOs, déficit ponderado o checks probabilísticos.

A partir de la 0.1.37, se desactiva el sistema de archivos `archive_v0_1_33_*.txt` y se vuelve al comportamiento anterior: un único log principal en `logs/KeepSupplyTimerLog.txt`.

A partir de la 0.1.39, el tooltip de riesgo usa fondo oscuro tipo tooltip de mejoras de keep, eliminando el fondo amarillo/naranja.

## Qué registra

Guarda los eventos directamente en el log de texto `logs/KeepSupplyTimerLog.txt`:

- `SUPPLY_DELIVERED`: el porcentaje del keep ha subido.
- `PROGRESS_LOST`: el porcentaje del keep ha bajado.
- `RANK_GAINED`: el keep ha ganado estrellas/rango.
- `RANK_LOST`: el keep ha perdido estrellas/rango. Este evento reinicia el contador local del keep desde el momento de la degradación.
- `CLAIM_CHANGED`: cambia la guild que tiene reclamado el keep.
- `BO_STATE_CHANGED`: una bandera/BO ha cambiado de owner o de estado.
- `BO_SECURED`: el addon ha observado que una BO pasa a estar activa para supply, aunque todavía puede no generar si faltan BOs para el rango del keep.
- `BO_SUPPLY_GENERATION_STARTED`: la BO pasa a generar supplies según owner, estado sin timer visible y BOs requeridas por rango del keep. Aquí empieza la estimación local de 42s.
- `BO_SUPPLY_GENERATION_STOPPED`: la BO deja de generar supplies, normalmente por cambio de estado, pérdida de BOs suficientes o cambio de owner.
- `SERVER_DECAY_TIMER_CANDIDATE_STARTED`: el keep cae por debajo de las BOs activas requeridas para su rango; se marca como posible inicio del temporizador interno de degradación del servidor.
- `SERVER_DECAY_TIMER_CANDIDATE_CANCELLED`: el keep vuelve a cumplir las BOs requeridas antes de degradarse; se cancela esa hipótesis.
- `SERVER_DECAY_TIMER_REFERENCE_SET`: primera degradación observada con un candidato previo; el addon guarda esa duración como referencia para comparar futuras degradaciones.

Los eventos de keep incluyen la guild que tiene reclamado el keep (`claim`, `guild`, `claimed`) y snapshot de BOs. Los eventos de BO incluyen snapshot de keeps, también con guild reclamada.

A partir de la 0.1.15, los eventos de degradación (`PROGRESS_LOST` y `RANK_LOST`) incluyen también una muestra de decay aceptada cuando existe un `SUPPLY_DELIVERED` anterior observado del mismo keep. Además registran acumuladores desde el último supply: tiempo con 0/1/2/3/4 BOs propias, BOs activas para supply, BOs enemigas, tiempo por debajo/en/encima del requisito de BOs, media de BOs propias/activas/enemigas, y puntuaciones acumuladas (`decayMissingBOScore`, `decayRawMissingBOScore`, `decayEnemyBOScore`).

A partir de la 0.1.21, el log de texto también incluye `DECAY_TRACKING_SNAPSHOT`, que vuelca esos mismos acumuladores durante el seguimiento activo, antes de que ocurra el decay. Esto permite reconstruir mejor los datos aunque el juego o la UI se recarguen antes de la degradación.

## Estados de BO usados por RoR_SoR

- `0` o estado vacío/nil = estable/controlada.
- `2` = abandoned.
- `4` = capping.
- `8` = unlocking/locked.
- `9` = locked.
- `10` = locked.
- `16` = securing. Si tiene timer visible en SoR, aún es transición; si no tiene timer visible, el addon lo trata como BO activa para supplies.

## Comandos

Requiere `LibSlash` para comandos:

- `/ksupply status`
- `/ksupply bos`
- `/ksupply log`
- `/ksupply log 20`
- `/ksupply samples`
- `/ksupply samples 20`
- `/ksupply clearlog`
- `/ksupply reset`
- `/ksupply botimers on`
- `/ksupply botimers off`
- `/ksupply bolog on`
- `/ksupply bolog off`
- `/ksupply claimlog on`
- `/ksupply claimlog off`
- `/ksupply on`
- `/ksupply off`
- `/ksupply research on`
- `/ksupply research off`
- `/ksupply research status`
- `/ksupply help`

## Dónde se guarda el log

Guarda el registro estructurado en SavedVariables y, desde la 0.1.13, también escribe un log incremental de texto en `logs/KeepSupplyTimerLog.txt`. El registro estructurado de SavedVariables suele quedar en una ruta parecida a:

`Warhammer Online - Return of Reckoning/user/settings/Martyrs Square/<Personaje>/<Perfil>/KeepSupplyTimer/SavedVariables.lua`

Busca `KeepSupplyTimerLog` dentro de ese archivo.

Para forzar el volcado de SavedVariables a disco, sal del juego normalmente o usa `/reloadui`. Para el log de texto, usa `/ksupply save`.


## 0.1.13

- Adds a session-global server decay reference event: `SERVER_DECAY_GLOBAL_REFERENCE_SET`.
- The global reference is set only by the first keep degradation/reset observed in the current UI session, assuming the server uses the same decay tick for all keeps.
- Keeps the previous BO-deficit candidate logs as diagnostic data, but the global marker is no longer inferred from the first candidate.


## 0.1.13 - Incremental file log

The structured data is still stored in `SavedVariables.lua` by the game client when it reloads the UI or exits normally. Warhammer/RoR does not expose a reliable public function to force SavedVariables to disk after every table mutation.

To avoid losing an entire test session after a crash, this version also writes a compact one-line-per-event log using the TextLog API with incremental saving enabled. The file path is:

```
logs/KeepSupplyTimerLog.txt
```

Useful commands:

```
/ksupply filelog status
/ksupply filelog on
/ksupply filelog off
/ksupply clearlog
```

`/ksupply clearlog` limpia el registro interno de la sesión y escribe una línea separadora en el log incremental de texto.


## 0.1.14 - Manual file-log save

Adds:

```
/ksupply save
/ksupply savelog
```

This writes a marker line and calls `TextLogSaveLog()` for the incremental text log:

```
logs/KeepSupplyTimerLog.txt
```

Esto no depende de `SavedVariables.lua`; el fichero principal para análisis es `logs/KeepSupplyTimerLog.txt`.


## Cambios 0.1.23

- Cambiado el intervalo estimado de aparición/generación de supplies en BO de 40s a 42s.
- La constante interna `KST.BO_SUPPLY_INTERVAL` pasa a `42`.

## Cambios 0.1.21

La versión 0.1.21 añade una tabla persistente separada `KeepSupplyTimerLog.decaySamples`. Cada vez que se detecta un `PROGRESS_LOST` o `RANK_LOST`, el addon copia una muestra compacta con los datos importantes del decay. Esta tabla no se recorta con el log normal de eventos, por lo que no se pierden muestras aunque el registro general llegue al límite de eventos.

Además, cada decay escribe una línea especial `DECAY_SAMPLE` en `logs/KeepSupplyTimerLog.txt` y fuerza `TextLogSaveLog()` inmediatamente. Esto no puede forzar el guardado físico de `SavedVariables.lua`, que sigue dependiendo de `/reloadui` o de salir normalmente del juego, pero sí reduce el riesgo de perder muestras si el log normal se llena.

## Muestras de decay 0.1.15

La versión 0.1.15 separa el contador visible del keep de la muestra científica de decay. El contador visual puede reiniciarse al perder progreso, pero una muestra solo se considera válida si el addon ha observado antes un `SUPPLY_DELIVERED` o `RANK_GAINED` del mismo keep en la misma sesión.

En cada `PROGRESS_LOST`/`RANK_LOST` válido se guardan, entre otros:

- `lastSupplySessionSeconds`, `lastSupplyEventIndex`, `secondsSinceLastSupply`, `elapsedSinceLastSupply`.
- `decayFriendlyBOTime`: tiempo acumulado con 0/1/2/3/4 BOs controladas por el reino del keep.
- `decayActiveBOTime`: tiempo acumulado con 0/1/2/3/4 BOs activas para generar supply.
- `decayEnemyBOTime`: tiempo acumulado con 0/1/2/3/4 BOs enemigas.
- `decayBelowRequired`, `decayAtRequired`, `decayAboveRequired`.
- `decayMissingBOScore`, `decayRawMissingBOScore`, `decayEnemyBOScore`.
- `decayAverageFriendlyBOs`, `decayAverageActiveBOs`, `decayAverageEnemyBOs`.

Usa `/ksupply samples 20` para ver dentro del juego las últimas muestras de decay aceptadas.


## 0.1.21
- Fixes repeated SUPPLY_DELIVERED spam if a decay tracking snapshot fails.
- Updates keep state before writing snapshot details, so logging cannot break the scientific timer state.

## 0.1.24

Adds keep-upgrade tracking from chat messages like:

`The Door Hitpoints Rank 1 keep upgrade has been purchased for Garrison of Skulls.`

Detected upgrades are stored in memory for the current addon session, logged to `logs/KeepSupplyTimerLog.txt`, and shown in a custom SoR hover tooltip when the mouse is placed over a keep panel, when the client exposes usable SoR keep window names. If the hover layer cannot attach on a client/layout, use `/ksupply upgrades` to print the detected upgrade state in chat.

Known upgrade timings included:

- Door Hitpoints R1: 5m, R2: +10m.
- Improved Respawns R1: 5m, R2: +5m, R3: +10m.
- Banker, Healing Ritualist, Healer, Guild Vault Keeper, Guild Flight Master, Static Guards, Lifetap Ritualist R1: 5m.
- Oil Control R1: 2m, R2: +3m.
- Divine Favor Altar R1: 5m build, first charge 15m after build, then one charge every 15m, max stock 3.

New commands:

- `/ksupply upgrades [keep]`
- `/ksupply clearupgrades`
- `/ksupply upgradehover on|off`


## 0.1.25

- Upgrade tooltip is now anchored under the mouse cursor through `CursorWindow` instead of next to the hidden keep overlay.
- Added parser for removed keep upgrades: `The [Upgrade] Rank [N] keep upgrade has been removed and is no longer available at [Keep].`
- Removed upgrades use the same estimated duration as construction and are shown as `removing` / `removed`.
- Divine Favor Altar charge estimates are cancelled while the altar is being removed.
- No previous decay, BO, supply, upgrade purchase or detailed log fields were removed.


## 0.1.26

- Fixes upgrade tooltip visibility when anchored to CursorWindow.
- The tooltip now auto-hides when the mouse is no longer over one of the SoR keep hover hitboxes, even if OnMouseOut is not fired by the client.
- Keeps all previous upgrade, decay, BO and module diagnostic logging fields.


## 0.1.28

- Tooltip de mejoras corregido: se vuelve a mostrar correctamente.
- Se usa `SystemData.ActiveWindow.name` como referencia primaria en eventos `OnMouseOver`, siguiendo el patrón de StateOfRealm.
- Se añade `OnMouseOverEnd` al hitbox transparente para ocultar el tooltip al salir del keep.
- Se elimina el ocultado agresivo por polling de `MouseOverWindow` añadido en 0.1.26, que podía ocultar el tooltip inmediatamente en algunos clientes.
- No se elimina ningún dato de log ni ningún campo recogido.


## 0.1.28
- Tooltip background made darker/translucent and moved to popup layer.
- Added TextLog Chat polling fallback for keep upgrade purchase/removal messages.
- Added `/ksupply scanupgrades` and `/ksupply debugupgradechat on/off`.
- Added Oil Control Rank 0 duration fallback.


## 0.1.33

Adds a per-run archive text log mirror. The fixed `logs/KeepSupplyTimerLog.txt` is still written, but every line is also mirrored to `logs/KeepSupplyTimerLog_archive_v0_1_33_000001.txt`, `...000002.txt`, etc. This protects long analysis sessions from RoR client truncation/recreation of the fixed TextLog file.


## 0.1.37

Añadido indicador cualitativo de riesgo de pérdida de progreso en el SoR. No intenta predecir al segundo: usa nivel del keep, tiempo desde último supply observado, requisito de BOs, racha bajo requisito y déficit acumulado. Comando: `/ksupply risk on|off|status`. Niveles visibles: `R:OK`, `R:B`, `R:M`, `R:A`, `R:CR`, `R:?`.


## 0.1.38

- Aumentado el ancho real del texto principal del SoR para que no se autoescale a un tamaño minúsculo al añadir `R:OK`, `R:B`, `R:M`, `R:A` o `R:CR`.
- El bloque completo del indicador inferior ahora acepta hover, no solo el texto exacto, para que sea mucho más fácil activar el tooltip.
- Añadido tooltip específico de riesgo al pasar el ratón por el indicador inferior. Resume ambos keeps de la zona: nivel de riesgo, tiempo desde último supply, ventana mínima estimada, BOs activas/requeridas, racha bajo requisito y razón del nivel.
- Ligeramente aumentados los timers de BO para mejorar legibilidad.


## 0.1.75

- Updated reset/decay risk levels: R:0%, R:OK, R:?, R:B, R:M, R:A and R:CR.
- R:M now means the keep is currently protected by BOs, but the timer since last supply is high enough that losing BOs may become dangerous quickly.
- Reset/decay tooltips now use short descriptive text explaining progress, last supply, BO state and likely consequence.


## 0.1.75

- Fixes detected keep upgrades not appearing in the keep tooltip when the chat keep name and the SoR keep name differ by punctuation/localisation.
- Binds detected upgrades to the visible SoR keep when possible and uses alias/fuzzy matching as fallback.


## 0.1.75

- Adds the active BO requirement for supply generation to decay/reset tooltips.
- Adds `Supply BOs: X` to the keep-upgrade tooltip header.
- Decay tooltip BO line now explicitly says whether supplies can generate or how many BOs are missing.


## 0.1.75

- Fixes a Lua 5.1 main-chunk local variable limit error introduced by recent tooltip/upgrade matching helpers.
- No gameplay logic changes from 0.1.55.


## 0.1.75

- Fixes keep upgrade tooltips showing one keep's upgrades on every keep.
- Removes the unsafe global fallback that displayed the only detected upgrade store for all keeps.
- Tightens upgrade matching to keepId, exact normalized keep name, safe alias, or safe zone+keepIndex only when keepId is unavailable.


## 0.1.75

- Fixes chat keep names like Charon's Citadel not matching SoR keep names like Charon's Keep.
- Adds a base-name matcher that strips generic suffixes such as Keep/Citadel/Hold/Fortress/Garrison.
- Keeps strict matching: no global fallback and no substring matching, so upgrades should not appear on unrelated keeps.


## 0.1.75

- Improves the decay/risk tooltip readability.
- Increases the tooltip height to prevent the lower grey lines from crowding/overlapping.
- Makes the action line gold and the consequence line light blue.
- Forces runtime dimensions so existing UI windows resize correctly.


## 0.1.75

- Adds a tooltip to BO supply countdowns.
- The tooltip explains that the next-supply timer is an addon estimate, not a server-confirmed timer.
- Shows BO name, owner realm, BO requirement and estimated interval when available.


## 0.1.75

- Adds a right-click context menu on keep upgrade hover areas.
- Share all upgrades or one selected upgrade.
- Share channels: /wb, /p, /g, /s, /1 and /t4.
- Shared messages include zone, keep, upgrade, rank, current state and remaining time if building/removing/charging.


## 0.1.75

- Improves keep-upgrade persistence after `/reload`.
- Saves keep upgrades both in `KeepSupplyTimerUpgradeState` and a backup inside `KeepSupplyTimerSettings`.
- On restore, ignores stale runtime `keepId`, `zoneId` and `keepIndex` bindings and rematches by exact/base keep name.
- Keeps the no-global-fallback rule, so one keep's upgrades should not appear on every keep.


## 0.1.75

- Adds a canonical table for all 30 RoR keeps using the /guildreleasekeep numbers.
- Stores and matches keep upgrades by canonical keep id when possible.
- Adds zone metadata and aliases for known name differences, including Charon's Citadel -> Charon's Keep.
- Keeps the existing safe behavior: no global fallback and no substring matching across unrelated keeps.


## 0.1.75

- Improves the keep-upgrade share context menu.
- The first menu now shows direct channel choices for sharing all upgrades: /wb, /p, /1 and /t4.
- The previous second-level channel selector remains available through 'Share all: choose channel...'.
- 'Share one upgrade' now opens an upgrade selector, then the channel selector.


## 0.1.75

- Tracks Divine Favor Altar charge usage.
- Parses blessing chat messages: 'Your god has blessed you due the efforts of <guild>'.
- Subtracts one available Divine Favor charge when the message is detected.
- Starts a new 15-minute recharge estimate after a charge is used.
- Persists the adjusted charge count and next-charge timer through /reload.


## 0.1.75

- Fixes Divine Favor Altar charge consumption logic.
- If the altar was full, 3/3, using a charge starts the 15-minute recharge timer.
- If a recharge countdown was already running, using another charge does not reset that countdown; only the charge count is reduced.


## 0.1.75

- Reworks the keep-upgrade share context menu into the requested hierarchy.
- Root menu: share all upgrades or share selected upgrades.
- Share all: choose /1, /t4, /wb or /p.
- Share selected: choose /1, /t4, /wb or /p, then choose the exact upgrade to send.
- Keeps the local preview option.


## 0.1.75

- Changes keep-upgrade share menu text back to English.
- Reworks the menu hierarchy with named callbacks instead of generic index callbacks.
- Root: Share all upgrades / Share selected upgrades.
- Share all: choose Region (/1), Tier 4 (/t4), Warband (/wb), or Party (/p).
- Share selected: choose channel first, then choose one upgrade.


## 0.1.75

- Replaces the broken submenu-style share menu with one flat English menu using visual divisions.
- Share all upgrades directly by /1, /t4, /wb or /p.
- Share selected upgrades from the same menu under each channel section.
- Completed R0 removal entries are removed from the tooltip/share menu after their timer finishes.
- Adds a flat backup of keep upgrade data to improve persistence across /reload.


## 0.1.75

- Adds receiver support for shared `[KST]` upgrade messages.
- Other players with the addon now parse shared lines such as `[KST] Chaos Wastes | Charon's Keep | Healer R1 building 1:22`.
- Synced upgrades are stored as `source = chat-sync`, persisted, and shown in the same keep-upgrade tooltips.
- Supports building/removing timers, built/removed states, Divine Favor first charge, and Divine Favor charge counts with next-charge timers.


## 0.1.75

- Changes share-all messages to a human-readable summary for players without the addon.
- New share-all format: `[KST] Zone | Keep | This keep has the following upgrades: Upgrade R1 built; Upgrade R1 building 1:22`.
- The receiver parser still incorporates those summaries into other players' local tooltips.
- Single-upgrade shared messages remain supported for selected-upgrade sharing.


## 0.1.75

- Building upgrade rows with rank 0 are now shown in red.
- This highlights R0 upgrades as removal/deconstruction-related entries.


## 0.1.75

- Moves the right keep decay/reset indicator to the lower-right corner of each SoR pairing panel.
- The left indicator remains anchored to the lower-left corner.
- No changes to decay logic, sharing, Divine Favor or persistence.


## 0.1.75

- Fixes right keep decay indicator placement more robustly.
- The parent reset-pair overlay now uses the runtime width of the SoR pairing panel instead of the fixed 236px width.
- The right indicator is again anchored to the right edge of that full-width overlay.


## 0.1.75

- Selected-upgrade share messages are now human-readable too.
- New selected-upgrade format: `[KST] Zone | Keep | This keep has this upgrade: Healer R1 building 1:22`.
- The receiver parser accepts both the new human-readable selected format and the previous raw selected-upgrade format.


## 0.2.09 hybrid-aggressive

- Integrated the NPC Upgrade Merchant diagnostic scanner into the hybrid-aggressive build.
- New command: `/ksupply npcscan` scans `EA_Window_InteractionKeepUpgrades` and logs visible child windows/texts.
- New command: `/ksupply npchover` logs the current mouseover window name/text.
- This is the diagnostic step needed before automatically updating keep upgrades from the NPC window.


## 0.2.09 hybrid-aggressive

- Fixes the Lua load error: `main function has more than 200 local variables`.
- NPC diagnostic scanner helper functions now live under `KST.*` instead of adding local functions to the Lua main chunk.
- Keeps `/ksupply npcscan` and `/ksupply npchover`.


## 0.2.09 hybrid-aggressive

- Fixes NPC diagnostic logging: custom windowName/text fields were being dropped by the structured logger.
- Adds raw `[KST_NPC]` lines for scan start/end, nodes and mouseover.
- Use `/ksupply npcscan` and `/ksupply npchover`, then search the log for `[KST_NPC]`.


## 0.2.09 hybrid-aggressive

- Adds `/ksupply npcprobe`.
- `npcscan` now also probes known candidate controls such as `EA_Window_InteractionKeepUpgradesListBoxRow1Upgrade1`.
- This is needed because the client exposes the row controls by name/mouseover, but `WindowGetChildren` only returns the root window.


## 0.2.09 hybrid-aggressive

- Adds `/ksupply npcread [keep name]`.
- Reads `Upgrade`, `Rank` and `Time` controls from `EA_Window_InteractionKeepUpgradesListBoxRow*`.
- Updates the local keep-upgrade store from the NPC window.
- Rank 0 with no timer is treated as not built and clears stale records for that upgrade.
- Rank > 0 with no timer is treated as built.
- Any row with a visible/readable timer is treated as building and uses that timer.


## 0.2.09 hybrid-aggressive

- Fixes `/ksupply npcread` error caused by an undefined `normalizeUpgradeName` helper.
- `/ksupply npcread` with no argument now lists the open keeps belonging to the player's realm.
- You can then use `/ksupply npcread 1`, `/ksupply npcread 2`, etc., instead of typing the full keep name.
- If there is only one candidate, `/ksupply npcread` selects it automatically.


## 0.2.09 hybrid-aggressive

- Adds a keep context-menu option: `Read keep upgrades, requires NPC upgrade window open`.
- The command reads the NPC Upgrade Keep window for the keep whose tooltip/menu was clicked, so you no longer need to type or select the keep name manually.
- The NPC upgrade window still needs to be open.


## 0.2.09 hybrid-aggressive

- Adds user-error guards to the context-menu NPC read action.
- The context-menu NPC read now refuses to update if the NPC upgrade window is not open/visible, if the selected keep is not owned by your realm, if the selected keep is not guild-claimed, or if the selected keep is in another detected player zone.
- Adds context-menu option: `Reset selected keep upgrades`.
- Reset clears only the upgrade records for the keep selected in the SoR context menu.


## 0.2.09 hybrid-aggressive

- Adds a guild-ownership guard to the context-menu NPC read action.
- The addon now refuses to read/apply the NPC upgrade window to a selected keep if the keep is not claimed by the player's guild.
- If the player's guild cannot be detected, the context-menu NPC read is refused rather than risking assignment to the wrong keep.
- Adds `/ksupply guild` to print the detected player guild for debugging.


## 0.2.09 hybrid-aggressive

- Adds a strict current-zone guard to the context-menu NPC read action.
- The addon now refuses to apply NPC-window upgrades unless the selected keep is in the player's current zone/map.
- If current zone cannot be detected, the read is refused rather than risking assignment to another SoR keep.
- Adds `/ksupply zone` to print the detected current zone id/name.


## 0.2.09 hybrid-aggressive

- Fixes `Reset selected keep upgrades`.
- Reset now deletes all upgrade memory for the selected keep, not only the currently matched store's `upgrades` table.
- It removes matching runtime stores, primary SavedVariables stores, backup stores and flat backup entries.
- Matching uses canonical keep id, keep id, normalized name, aliases and zone/keep index fallback.


## 0.2.09 hybrid-aggressive

- Moves `Reset selected keep upgrades` to the bottom of the keep context menu, next to the local preview action, to avoid click issues near the top of the menu.
- Wraps reset execution with error reporting in chat.
- Adds `/ksupply resetupgrades` and `/ksupply resetkeepupgrades` as fallback commands using the current menu/hover keep context.


## 0.2.09 hybrid-aggressive

- Adds immediate chat/log diagnostics to the reset context-menu callback.
- Adds a second reset item at the top of the menu: `!! RESET selected keep upgrades !!`.
- Adds `/ksupply resetcurrent` and `/ksupply testresetclick` for diagnostics.


## 0.2.09 hybrid-aggressive

- Fixes `/ksupply resetupgrades` and `/ksupply resetkeepupgrades`.
- Reset commands now accept `/ksupply resetupgrades 1` or `/ksupply resetupgrades Keep Name`.
- With no argument and no current menu/hover context, the addon prints numbered keep candidates instead of doing nothing.


## 0.2.09 hybrid-aggressive

- Clarifies and fixes reset behavior.
- Context-menu reset now uses only the keep from the menu context, not hover fallback.
- Slash reset without argument no longer resets anything; it lists candidates and requires `/ksupply resetupgrades <number>` or `/ksupply resetupgrades <keep name>`.
- Removes debug chat spam and ignores duplicate reset callbacks within 2 seconds.


## 0.2.09 hybrid-aggressive

- Rewrites the keep-upgrade memory reset system from scratch.
- Removes the previous reset implementation.
- `Reset selected keep upgrades` deletes memory only for the selected keep from runtime state, primary SavedVariables, backup SavedVariables and flat backup.
- `/ksupply resetkeepupgrades` and `/ksupply resetupgrades` with no argument only list candidates.
- `/ksupply resetkeepupgrades <number>` and `/ksupply resetkeepupgrades <keep name>` perform the deletion.


## 0.2.09 hybrid-aggressive

- Softens guild-name validation for the NPC keep-upgrade read.
- The read still requires the NPC window to be open, the selected keep to be in the current zone, owned by your realm, and claimed by a guild.
- If the detected player guild and keep claim do not match, the addon now logs `[KST_NPC_GUILD_WARNING]` instead of blocking the read, because guild-name detection can be unreliable.
- `/ksupply guild` now also prints the selected keep claim when a keep context is available.


## 0.2.09 hybrid-aggressive

- Adds Guild `/g` as a visible share channel in the keep-upgrade context menu.
- Added to `Share all upgrades` as `By Guild (/g)`.
- Added to `Share selected upgrades` as `-- By Guild (/g) --`.


## 0.2.09 hybrid-aggressive

- Divine Favor Altar read from the NPC now marks charges as unknown and starts a bad 15-minute estimate timer from the read moment.
- Tooltip/share text shows `charges unknown` / `next-est` for those NPC-only estimates.
- Adds manual Divine Favor charge controls to the keep context menu: -1, +1, set 0/3, 1/3, 2/3, 3/3.
- Manual charge setting clears the unknown/bad-estimate flag and persists the corrected value.


## 0.2.09 hybrid-aggressive

- Compacts the keep-upgrade context menu.
- `Share all upgrades` still has Region/T4/Warband/Guild/Party.
- `Share selected upgrades` now lists upgrades only once, using the selected channel.
- Added channel selector entries: Use Region, Use T4, Use Warband, Use Guild, Use Party.
- Default selected channel is Guild `/g` unless a previous channel is saved.


## 0.2.09 hybrid-aggressive

- Moves selected-upgrade sharing into per-channel secondary menus.
- The main menu now shows only one entry per channel: Region, T4, Warband, Guild, Party.
- Clicking one opens a second context menu listing the selected upgrades for that channel.
- This avoids repeating every upgrade under every channel in the main menu.


## 0.2.09 hybrid-aggressive

- Adds `>` indicators to selected-upgrade channel entries to show they open a secondary menu.


## 0.2.09 hybrid-aggressive

- Treats timed R0 rows from the NPC keep-upgrade window as `removing`, not `building`.
- When a removal exists for an upgrade, stale duplicate `R0 building` rows for the same upgrade are hidden from tooltips and share menus.
- NPC reads now clear old records for that upgrade before writing a timed R0 removal state.


## 0.2.09 hybrid-aggressive

- Adds buff diagnostics for Divine Intervention.
- New commands: `/ksupply buffdebug on|off`, `/ksupply buffdump`, `/ksupply buffhover`.
- Buff debug scans likely GameData/SystemData buff/effect tables, logs new effects, and highlights names containing divine/intervention/favor/favour/bless.
- Purpose: identify the technical id/name/source for the Divine Intervention buff so altar charge usage can be automated later.


## 0.2.09 hybrid-aggressive

- Adds automatic Divine Intervention buff detection using buff id `31095`.
- When the buff appears, the addon decrements one Divine Favor Altar charge.
- Uses a 10-second debounce and only fires on inactive -> active transition.
- Matching priority: selected keep context first, otherwise a single known active Divine Favor Altar.
- Adds `/ksupply buffcheck` for manual detection testing.


## 0.2.09 hybrid-aggressive

- Reworks Divine Intervention detection using BuffHead as reference.
- Uses `GetBuffs(GameData.BuffTargetType.SELF)` and checks buff/effect id `31095`.
- Scan frequency changed to every 3 seconds to reduce load.
- Keeps the old broad buff diagnostic collector only as fallback if GetBuffs(SELF) does not find the buff.


## 0.2.09 hybrid-aggressive

- `/ksupply buffcheck` now forces Divine Intervention charge handling even if the buff is already active.
- Automatic detection no longer locks itself if the buff is found but no altar can be matched; it retries every 3 seconds while the buff remains active.
- The addon now remembers the last Divine Favor Altar read from the NPC and uses it as preferred target for buff-based charge decrement.


## 0.2.09 hybrid-aggressive

- Divine Intervention detection now stores the buff remaining time.
- If the buff is already active and its remaining time jumps up clearly, the addon treats it as a new altar use and decrements another charge.
- Refresh rule: current remaining must be at least 90 seconds and more than previous remaining + 20 seconds.
- This supports repeated Divine Favor Altar uses before the 2-minute buff expires.


## 0.2.09 hybrid-aggressive

- Fixes Lua error: `attempt to call global 'getUpgradeStatus' (a nil value)` when using `/ksupply buffcheck`.
- Predeclares `getUpgradeStatus` so Divine Intervention charge handling can call it safely.


## 0.2.09 hybrid-aggressive

- Fixes built keep upgrades being lost or converted back into fake building timers after `/reloadui`.
- Normal built upgrades are now saved as explicit `state="built"`, not `state="building"` with a zero-second timer.
- Adds restore-time migration for old saved records that used the zero-second building representation.
- Divine Favor Altar keeps its special charge/timer handling.


## 0.2.09 hybrid-aggressive

- Makes the flat serialized keep-upgrade backup the preferred restore source after `/reloadui`.
- Stores the flat backup in both `KeepSupplyTimerSettings` and `KeepSupplyTimerUpgradeState`.
- Fixes Divine Favor Altar charge records reverting to fake construction timers after `/reloadui`.
- Divine Favor Altar now ignores stale session build timers once charge fields exist, unless it is genuinely still under construction with a positive duration.
- Adds `[KST_PERSIST_DIVINE]` log line whenever a buff/command decrements altar charges and persists them.


## 0.2.09 hybrid-aggressive

- Adds a dedicated persistent Divine Favor charge snapshot table in both SavedVariables.
- Charge snapshots are keyed by canonical keep id/name and survive `/reloadui` independently from the general upgrade table.
- After restore or NPC read, a saved Divine Favor charge snapshot overrides stale NPC first-charge/unknown estimates.
- Fixes the case where pre-reload `charges 2/3 next ...` becomes post-reload `first charge ... 0/3`.
- Adds `[KST_DIVINE_SNAPSHOT_SAVE]` and `[KST_DIVINE_SNAPSHOT_APPLY]` diagnostic log lines.


## 0.2.09 hybrid-aggressive

- Divine Favor charge timers now use the estimated absolute end time as the reference, not the start/session timestamp.
- On save, the addon stores `divineNextChargeEpoch` whenever a real clock is available.
- On restore, it calculates remaining time from `endEpoch - currentEpoch`, so `/reloadui`, closing the game, and reopening should subtract elapsed real time.
- Old snapshots are migrated by reconstructing `endEpoch = savedEpoch + remainingAtSave` when possible.
- If the client exposes no real wall-clock/epoch API, the addon logs `[KST_TIME_WARNING]`; in that case offline timer advancement is technically impossible and only in-session timers can be correct.
