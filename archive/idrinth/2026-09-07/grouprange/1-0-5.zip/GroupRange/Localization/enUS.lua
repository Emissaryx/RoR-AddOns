if (not GroupRangeLocalization) then
	GroupRangeLocalization = {};
	GroupRangeLocalization.Language = {};
end

GroupRangeLocalization.Language[SystemData.Settings.Language.ENGLISH] = 
{
	["Setup.General.Offset"] = L"Offset",
	["Setup.General.Offset.Info"] = L"The number of pixels to offset the containers above targets",
	["Setup.General.Offset.X"] = L"X",
	["Setup.General.Offset.Y"] = L"Y",
	["Setup.General.UpdateDelay"] = L"Update Delay",
	["Setup.Style.Title"] = L"Style",
	["Setup.Style.UseStyle"] = L"Use this style",
	["Setup.General.Title"] = L"Options",
	["Setup.Menu.General"] = L"General",
	["Setup.Menu.Style"] = L"Style",
	["Setup.Menu.Title"] = L"GroupRange Options",
	["Setup.Style.NoSettings"] = L"There are no settings to change",
};

