if (not GroupRangeSetup) then GroupRangeSetup = {} end
GroupRangeSetup.WindowName = "GroupRangeSetupMenuWindow";
GroupRangeSetup.ActiveWindow = nil;

local windowName = GroupRangeSetup.WindowName;
local initialAnchorCreated = false;

local localization = GroupRangeLocalization.GetMapping();

function GroupRangeSetup.Initialize()

	GroupRangeSetup.General.Initialize();
	GroupRangeSetup.Style.Initialize();

	LabelSetText(windowName .. "Label", localization["Setup.Menu.Title"]);
	ButtonSetText(windowName .. "GeneralSetupButton", localization["Setup.Menu.General"]);
	ButtonSetText(windowName .. "StyleSetupButton", localization["Setup.Menu.Style"]);

end

function GroupRangeSetup.LoadSettings()

	GroupRangeSetup.General.LoadSettings();
	GroupRangeSetup.Style.LoadSettings();
	
end

function GroupRangeSetup.SetActiveWindow(setupWindow)
	
	if (GroupRangeSetup.ActiveWindow == setupWindow) then return end

	if (GroupRangeSetup.ActiveWindow and GroupRangeSetup.ActiveWindow.WindowName) then
		WindowClearAnchors(GroupRangeSetup.ActiveWindow.WindowName);	
		WindowAddAnchor(GroupRangeSetup.ActiveWindow.WindowName, "center", "Root", "center", 0, 0);	
		GroupRangeSetup.ActiveWindow.Hide();
	end
	
	GroupRangeSetup.ActiveWindow = setupWindow;
	
	if (setupWindow and setupWindow.WindowName) then
		GroupRangeSetup.ActiveWindow.Show();
		
		if (not initialAnchorCreated) then
			WindowClearAnchors(windowName);
			WindowAddAnchor(windowName, "center", "Root", "topright", -310, -340);
			initialAnchorCreated = true;
		end
		
		WindowClearAnchors(setupWindow.WindowName);
		WindowAddAnchor(setupWindow.WindowName, "topright", windowName, "topleft", 0, 0);
	else
		WindowClearAnchors(windowName);
		WindowAddAnchor(windowName, "center", "Root", "center", 0, 0);
		initialAnchorCreated = false;
	end

end

function GroupRangeSetup.Show()

	if (WindowGetShowing(windowName)) then return end
	
	WindowSetShowing(windowName, true);
	
	WindowUtils.AddToOpenList(windowName, GroupRangeSetup.OnCloseLUp, WindowUtils.Cascade.MODE_NONE);
	
	Sound.Play(Sound.WINDOW_OPEN);

end

function GroupRangeSetup.Hide()

	if (not WindowGetShowing(windowName)) then return end
	
	WindowSetShowing(windowName, false);
	
	Sound.Play(Sound.WINDOW_CLOSE);
	
	WindowUtils.RemoveFromOpenList(windowName);

end

function GroupRangeSetup.OnHidden()

	GroupRangeSetup.SetActiveWindow();
	
	GroupRange.DestroyAllContainers(); -- destroy all containers when the setup is closed
	
end

function GroupRangeSetup.OnCloseLUp()

	GroupRangeSetup.Hide();

end

function GroupRangeSetup.OnGeneralSetupLUp()

	GroupRangeSetup.SetActiveWindow(GroupRangeSetup.General);

end

function GroupRangeSetup.OnStyleSetupLUp()

	GroupRangeSetup.SetActiveWindow(GroupRangeSetup.Style);

end