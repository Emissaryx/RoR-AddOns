if (not GroupRangeSetup) then GroupRangeSetup = {} end
GroupRangeSetup.Style = {};
GroupRangeSetup.Style.WindowName = "GroupRangeSetupStyleWindow";

local styles = {};
local activeStyle = nil;
local activeWindow;

local windowName = GroupRangeSetup.Style.WindowName;
local localization = GroupRangeLocalization.GetMapping();

function GroupRangeSetup.Style.Initialize()

	LabelSetText(windowName .. "StyleLabel", localization["Setup.Style.Title"]);
	LabelSetText(windowName .. "UseStyleCheckboxLabel", localization["Setup.Style.UseStyle"]);
	
	ComboBoxClearMenuItems(windowName .. "StyleCombo");
	for _,style in pairs(GroupRange.Styles) do
		ComboBoxAddMenuItem(windowName .. "StyleCombo", towstring(style.Name));
		
		if (style.Setup) then
			style.Setup.Initialize();
		end
		
		table.insert(styles, style);
	end

	ComboBoxSetSelectedMenuItem(windowName .. "StyleCombo", 1);
	GroupRangeSetup.Style.OnStyleChanged();
	
	GroupRangeSetup.Style.LoadSettings();
	
end

function GroupRangeSetup.Style.LoadSettings()
	
end

function GroupRangeSetup.Style.Show()

	if (WindowGetShowing(windowName)) then return end
	
	WindowSetShowing(windowName, true);
	
	if (activeWindow) then
		activeWindow.Show();
	end
	
	WindowUtils.AddToOpenList(windowName, GroupRangeSetup.Style.OnCloseLUp, WindowUtils.Cascade.MODE_NONE);
	
	Sound.Play(Sound.WINDOW_OPEN);

end

function GroupRangeSetup.Style.Hide()

	if (not WindowGetShowing(windowName)) then return end
	
	WindowSetShowing(windowName, false);
	
	Sound.Play(Sound.WINDOW_CLOSE);
	
	WindowUtils.RemoveFromOpenList(windowName);

end

function GroupRangeSetup.Style.OnHidden()

	GroupRangeSetup.SetActiveWindow();
	
	if (activeWindow) then
		activeWindow.Hide();
	end
	
end

function GroupRangeSetup.Style.OnCloseLUp()

	GroupRangeSetup.Style.Hide();

end

function GroupRangeSetup.Style.OnStyleChanged()

	local value = ComboBoxGetSelectedMenuItem(windowName .. "StyleCombo");
	local style = styles[value];
	
	activeStyle = style.Identifier;
	
	local isChecked = (GroupRange.Settings.ActiveStyles[activeStyle] == true);
	ButtonSetPressedFlag(windowName .. "UseStyle" .. "Button", isChecked);
	
	if (activeWindow) then
		activeWindow.Hide();
		activeWindow = nil;
	end
	
	if (style.Setup) then
		activeWindow = style.Setup;
		WindowClearAnchors(style.Setup.WindowName);	
		WindowAddAnchor(style.Setup.WindowName, "bottomleft", windowName, "topleft", 0, 0);
		if (WindowGetShowing(windowName)) then
			activeWindow.Show();
		end
	end
	
end

function GroupRangeSetup.Style.OnUseStyleLUp()

	local isChecked = ButtonGetPressedFlag(windowName .. "UseStyle" .. "Button") == false;
	ButtonSetPressedFlag(windowName .. "UseStyle" .. "Button", isChecked);
	
	if (isChecked) then
		GroupRange.Settings.ActiveStyles[activeStyle] = isChecked;
	else
		GroupRange.Settings.ActiveStyles[activeStyle] = nil;
	end
	
	GroupRange.DestroyAllContainers();
	
end