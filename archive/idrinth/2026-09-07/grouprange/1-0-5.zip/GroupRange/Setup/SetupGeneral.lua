if (not GroupRangeSetup) then GroupRangeSetup = {} end
GroupRangeSetup.General = {};
GroupRangeSetup.General.WindowName = "GroupRangeSetupGeneralWindow";

local UPDATE_DELAY = { 0.1, 0.5, 1, 2, 5, 10 };

local windowName = GroupRangeSetup.General.WindowName;
local localization = GroupRangeLocalization.GetMapping();

local function GetDelayValue(value, valueList)

	local index = 1;
	
	for k, v in ipairs(valueList) do
		if (value == v) then
			return k;
		elseif (value > v) then
			index = k;
		end
	end

	return index;

end

function GroupRangeSetup.General.Initialize()

	LabelSetText(windowName .. "OptionsLabel", localization["Setup.General.Title"]);
	LabelSetText(windowName .. "UpdateDelayLabel", localization["Setup.General.UpdateDelay"]);
	
	LabelSetText(windowName .. "OffsetLabel", localization["Setup.General.Offset"]);
	LabelSetText(windowName .. "OffsetDescriptionLabel", localization["Setup.General.Offset.Info"]);
	LabelSetText(windowName .. "OffsetXLabel", localization["Setup.General.Offset.X"]);
	LabelSetText(windowName .. "OffsetYLabel", localization["Setup.General.Offset.Y"]);
	
	GroupRangeSetup.General.LoadSettings();
	
end

function GroupRangeSetup.General.LoadSettings()

	SliderBarSetCurrentPosition(windowName .. "UpdateDelaySlider", math.max(math.min(1, (GetDelayValue(GroupRange.Settings.Delay, UPDATE_DELAY) - 1) / (#UPDATE_DELAY - 1)), 0));
	GroupRangeSetup.General.OnSlideUpdateDelay();
	
	TextEditBoxSetText(windowName .. "OffsetXEditBox", towstring(GroupRange.Settings.Offset.X));
	TextEditBoxSetText(windowName .. "OffsetYEditBox", towstring(GroupRange.Settings.Offset.Y));
	
end

function GroupRangeSetup.General.Show()

	if (WindowGetShowing(windowName)) then return end
	
	WindowSetShowing(windowName, true);
	
	WindowUtils.AddToOpenList(windowName, GroupRangeSetup.General.OnCloseLUp, WindowUtils.Cascade.MODE_NONE);
	
	Sound.Play(Sound.WINDOW_OPEN);

end

function GroupRangeSetup.General.Hide()

	if (not WindowGetShowing(windowName)) then return end
	
	WindowSetShowing(windowName, false);
	
	Sound.Play(Sound.WINDOW_CLOSE);
	
	WindowUtils.RemoveFromOpenList(windowName);

end

function GroupRangeSetup.General.OnHidden()

	GroupRangeSetup.SetActiveWindow();
	
end

function GroupRangeSetup.General.OnCloseLUp()

	GroupRangeSetup.General.Hide();

end

function GroupRangeSetup.General.OnSlideUpdateDelay()

	local value = UPDATE_DELAY[1 + math.floor(SliderBarGetCurrentPosition(windowName .. "UpdateDelaySlider") * (#UPDATE_DELAY - 1))];
	
	local stringValue = "%.2fs";
	LabelSetText(windowName .. "UpdateDelayValue", towstring(stringValue:format(value)));

	GroupRange.Settings.Delay = value;

end

function GroupRangeSetup.General.OnOffsetXChanged()

	local value = tonumber(TextEditBoxGetText(windowName .. "OffsetXEditBox"));
	GroupRange.Settings.Offset.X = value;

end

function GroupRangeSetup.General.OnOffsetYChanged()

	local value = tonumber(TextEditBoxGetText(windowName .. "OffsetYEditBox"));
	GroupRange.Settings.Offset.Y = value;

end