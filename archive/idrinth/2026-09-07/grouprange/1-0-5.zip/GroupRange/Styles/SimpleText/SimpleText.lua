local CHARACTER_HEIGHT_NEAR = 180; -- the size in pixels of a character when their distance is 1ft
local CHARACTER_HEIGHT_FAR = 30; -- the size in pixels of a character when their distance is 300ft
local FAR_DISTANCE = 300;

local identifier = "SimpleText";
GroupRange.Styles[identifier] = {};

local style = GroupRange.Styles[identifier];
style.Identifier = identifier;
style.Name = "Simple Text";
style.Setup = GroupRangeSetup.Style.SimpleText;
style.Template = Frame:Subclass("GroupRangeTextTemplate");

local ColorStyle = { GroupHeal = 1, Heal = 2, Guard = 3 };
local Layer = { Background = 1, Default = 2, Foreground = 3 };

function style.Initialize(object)

	object.StyleTemplate[style.Identifier] = style.Template:Create(object);
		
end

local function SetLayer(window)

	local settings = GroupRange.Settings.Styles[identifier];
	local layer = 1; --default

	if (settings.Layer == Layer.Background) then
		layer = 0;
	elseif (settings.Layer == Layer.Foreground) then
		layer = 2;
	end
	
	WindowSetLayer(window, layer);

end

function style.Template:Create(parent)

	local settings = GroupRange.Settings.Styles[identifier];
	local frame = self:CreateFromTemplate(parent:GetName() .. style.Identifier, parent:GetName());
	
	frame.Parent = parent;
	
	WindowClearAnchors(frame:GetName());
	WindowAddAnchor(frame:GetName(), "center", parent:GetName(), "center", GroupRange.Settings.Offset.X + settings.Offset.X, GroupRange.Settings.Offset.Y + settings.Offset.Y);
	
	SetLayer(frame:GetName());
	WindowSetShowing(frame:GetName(), true);
	
	return frame;
	
end

function style.Template:SetShowing(isVisible)
	if (WindowGetShowing(self:GetName()) ~= isVisible) then
		WindowSetShowing(self:GetName(), isVisible);
	end
end

function style.Template:Update(distance)

	local settings = GroupRange.Settings.Styles[identifier];
	local groupMember = self.Parent.GroupMember;
	
	if (not distance or not groupMember.IsValid or not groupMember.IsOnline or groupMember.IsDistant) then
		self:SetShowing(false);
		return;
	else
		self:SetShowing(true);
	end

	local r,g,b = 255,255,255;
	local displayValue = "";

	local Range = { Near = 100, Far = 150 };

	if (settings.ColorStyle == ColorStyle.GroupHeal) then
		Range = { Near = 95, Far = 105 };
	elseif (settings.ColorStyle == ColorStyle.Guard) then
		Range = { Near = 25, Far = 30 };
	end

	if (distance) then
		if (distance < Range.Near) then
			r,g,b = 0,255,0;
		elseif (distance > Range.Far) then
			r,g,b = 255,0,0;
		elseif (distance >= Range.Near) then
			r,g,b = 255,255,0;
		end
		
		displayValue = distance;
	end
	
	if (self.DisplayValue == displayValue) then return end
	self.DisplayValue = displayValue;

	LabelSetTextColor(self:GetName() .. "Distance", r, g, b);
	LabelSetText(self:GetName() .. "Distance", towstring(displayValue));
	
	if (settings.AutoPosition) then
		WindowClearAnchors(self:GetName());
		
		local rootScale = InterfaceCore.GetScale();
		local height = math.max(0, CHARACTER_HEIGHT_FAR + (FAR_DISTANCE - distance) * (CHARACTER_HEIGHT_NEAR - CHARACTER_HEIGHT_FAR) / FAR_DISTANCE);
		local scale = height / CHARACTER_HEIGHT_NEAR;
		
		-- attempt to fix the height where between the middle ranges, the height is about 50px off
		if (scale < 0.7) then
			height = height * 0.7;
		else
			height = height * scale;
		end
		
		WindowAddAnchor(self:GetName(), "center", self.Parent:GetName(), "center", GroupRange.Settings.Offset.X + settings.Offset.X, GroupRange.Settings.Offset.Y + settings.Offset.Y + (height / rootScale));
	end

end

function style.Update(object, distance)

	object.StyleTemplate[style.Identifier]:Update(distance);

end

function style.Destroy(object)

	object.StyleTemplate[style.Identifier]:Destroy();
	object.StyleTemplate[style.Identifier] = nil;

end