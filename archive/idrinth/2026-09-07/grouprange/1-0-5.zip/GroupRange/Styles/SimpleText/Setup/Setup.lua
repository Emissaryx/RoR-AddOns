if (not GroupRangeSetup) then GroupRangeSetup = {} end
GroupRangeSetup.Style.SimpleText = {};
GroupRangeSetup.Style.SimpleText.WindowName = "GroupRangeSetupStyleSimpleTextWindow";

local ColorStyle = { GroupHeal = 1, Heal = 2, Guard = 3 };
local Layer = { Background = 1, Default = 2, Foreground = 3 };

local windowName = GroupRangeSetup.Style.SimpleText.WindowName;
local localization = GroupRangeLocalization.GetMapping();

local function CheckSettings()

	local settings = GroupRange.Settings.Styles;

	if (not settings.SimpleText) then
		settings.SimpleText =
		{
			AutoPosition = false,
			ColorStyle = ColorStyle.GroupHeal,
		};
	end
	settings = settings.SimpleText;

	if (not settings.Layer) then
		settings.Layer = Layer.Default;
	end
	
	if (not settings.Offset) then
		settings.Offset = { X = 0, Y = 0 };
	end
	
end

function GroupRangeSetup.Style.SimpleText.Initialize()

	CheckSettings();
	
	WindowSetTintColor(windowName .. "Background", 0, 0, 0);
	WindowSetAlpha(windowName .. "Background", 0.9);

	LabelSetText(windowName .. "TitleLabel", towstring(GroupRange.Styles.SimpleText.Name));
	LabelSetText(windowName .. "AutoPositionCheckboxLabel", L"Auto position");
	LabelSetText(windowName .. "ColorStyleLabel", L"Color by");
	
	ComboBoxClearMenuItems(windowName .. "ColorStyleCombo");
	ComboBoxAddMenuItem(windowName .. "ColorStyleCombo", L"Group Heal Range");
	ComboBoxAddMenuItem(windowName .. "ColorStyleCombo", L"Heal Range");
	ComboBoxAddMenuItem(windowName .. "ColorStyleCombo", L"Guard Range");
	
	LabelSetText(windowName .. "OffsetLabel", L"Offset");
	LabelSetText(windowName .. "OffsetXLabel", L"X");
	LabelSetText(windowName .. "OffsetYLabel", L"Y");
	
	LabelSetText(windowName .. "LayerLabel", L"Layer");
	ComboBoxClearMenuItems(windowName .. "LayerCombo");
	ComboBoxAddMenuItem(windowName .. "LayerCombo", L"Background");
	ComboBoxAddMenuItem(windowName .. "LayerCombo", L"Default");
	ComboBoxAddMenuItem(windowName .. "LayerCombo", L"Foreground");
	
	GroupRangeSetup.Style.SimpleText.LoadSettings();
	
end

function GroupRangeSetup.Style.SimpleText.LoadSettings()

	ButtonSetPressedFlag(windowName .. "AutoPosition" .. "Button", (GroupRange.Settings.Styles.SimpleText.AutoPosition == true));
	ComboBoxSetSelectedMenuItem(windowName .. "ColorStyleCombo", GroupRange.Settings.Styles.SimpleText.ColorStyle);
	ComboBoxSetSelectedMenuItem(windowName .. "LayerCombo", GroupRange.Settings.Styles.SimpleText.Layer);
	
	TextEditBoxSetText(windowName .. "OffsetXEditBox", towstring(GroupRange.Settings.Styles.SimpleText.Offset.X));
	TextEditBoxSetText(windowName .. "OffsetYEditBox", towstring(GroupRange.Settings.Styles.SimpleText.Offset.Y));
	
end

function GroupRangeSetup.Style.SimpleText.Show()

	if (WindowGetShowing(windowName)) then return end
	WindowSetShowing(windowName, true);

end

function GroupRangeSetup.Style.SimpleText.Hide()

	if (not WindowGetShowing(windowName)) then return end
	WindowSetShowing(windowName, false);

end

function GroupRangeSetup.Style.SimpleText.OnAutoPositionLUp()

	local isChecked = ButtonGetPressedFlag(windowName .. "AutoPosition" .. "Button") == false;
	ButtonSetPressedFlag(windowName .. "AutoPosition" .. "Button", isChecked);
	GroupRange.Settings.Styles.SimpleText.AutoPosition = isChecked;
	
end

function GroupRangeSetup.Style.SimpleText.OnColorStyleChanged()

	local value = ComboBoxGetSelectedMenuItem(windowName .. "ColorStyleCombo");
	GroupRange.Settings.Styles.SimpleText.ColorStyle = value;
	
end

function GroupRangeSetup.Style.SimpleText.OnOffsetXChanged()

	local value = tonumber(TextEditBoxGetText(windowName .. "OffsetXEditBox"));
	GroupRange.Settings.Styles.SimpleText.Offset.X = value;

end

function GroupRangeSetup.Style.SimpleText.OnOffsetYChanged()

	local value = tonumber(TextEditBoxGetText(windowName .. "OffsetYEditBox"));
	GroupRange.Settings.Styles.SimpleText.Offset.Y = value;

end

function GroupRangeSetup.Style.SimpleText.OnLayerChanged()

	local value = ComboBoxGetSelectedMenuItem(windowName .. "LayerCombo");
	GroupRange.Settings.Styles.SimpleText.Layer = value;
	
end