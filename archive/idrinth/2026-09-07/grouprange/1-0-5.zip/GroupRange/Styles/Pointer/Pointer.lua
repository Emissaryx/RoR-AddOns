local CHARACTER_HEIGHT_NEAR = 180; -- the size in pixels of a character when their distance is 1ft
local CHARACTER_HEIGHT_FAR = 30; -- the size in pixels of a character when their distance is 300ft
local FAR_DISTANCE = 300;

local identifier = "Pointer";
GroupRange.Styles[identifier] = {};

local style = GroupRange.Styles[identifier];
style.Identifier = identifier;
style.Name = "Pointer";
style.Setup = GroupRangeSetup.Style.Pointer;
style.Template = Frame:Subclass("GroupRangeIconTemplate");

local ColorStyle = { GroupHeal = 1, Heal = 2, Guard = 3 };
local Layer = { Background = 1, Default = 2, Foreground = 3 };

function style.Initialize(object)

	object.StyleTemplate[style.Identifier] = style.Template:Create(object);
		
end

local function SetLayer(window)

	local settings = GroupRange.Settings.Styles[identifier];
	local layer = 1; --default

	if (settings.Layer == Layer.Background) then
		layer = 0;
	elseif (settings.Layer == Layer.Foreground) then
		layer = 2;
	end
	
	WindowSetLayer(window, layer);

end

function style.Template:Create(parent)

	local settings = GroupRange.Settings.Styles[identifier];
	local frame = self:CreateFromTemplate(parent:GetName() .. style.Identifier, parent:GetName());
	
	frame.Parent = parent;
	
	DynamicImageSetTexture(frame:GetName() .. "Icon", "GroupRange_Pointer", 0, 0);
	
	WindowClearAnchors(frame:GetName());
	WindowAddAnchor(frame:GetName(), "center", parent:GetName(), "center", GroupRange.Settings.Offset.X + settings.Offset.X, GroupRange.Settings.Offset.Y + settings.Offset.Y);
	
	SetLayer(frame:GetName());
	WindowSetShowing(frame:GetName(), true);
	
	return frame;
	
end

function style.Template:SetShowing(isVisible)
	if (WindowGetShowing(self:GetName()) ~= isVisible) then
		WindowSetShowing(self:GetName(), isVisible);
	end
end

function style.Template:Update(distance)

	local settings = GroupRange.Settings.Styles[identifier];
	local groupMember = self.Parent.GroupMember;
	
	if (not distance or distance > FAR_DISTANCE or not groupMember.IsValid or not groupMember.IsOnline or groupMember.IsDistant) then
		self:SetShowing(false);
		return;
	else
		self:SetShowing(true);
	end

	local r,g,b = 255,255,255;
	local displayValue = "";

	local Range = { Near = 95, Far = 105 }; -- default ColorStyle.GroupHeal

	if (settings.ColorStyle == ColorStyle.Heal) then
		Range = { Near = 100, Far = 150 };
	elseif (settings.ColorStyle == ColorStyle.Guard) then
		Range = { Near = 25, Far = 30 };
	end

	if (distance) then
		if (distance < Range.Near) then
			r,g,b = 0,255,0;
		elseif (distance > Range.Far) then
			r,g,b = 255,0,0;
		elseif (distance >= Range.Near) then
			r,g,b = 255,255,0;
		end
	end
	
	displayValue = distance;
	
	if (self.DisplayValue == displayValue) then return end
	self.DisplayValue = displayValue;
	
	if (settings.HideInRange and distance < Range.Near) then
		if (WindowGetShowing(self:GetName() .. "Icon")) then
			WindowSetShowing(self:GetName() .. "Icon", false);
		end
		return;
	end
	
	if (not WindowGetShowing(self:GetName() .. "Icon")) then
		WindowSetShowing(self:GetName() .. "Icon", true);
	end
	
	local rootScale = InterfaceCore.GetScale();
	local height = math.max(0, CHARACTER_HEIGHT_FAR + (FAR_DISTANCE - distance) * (CHARACTER_HEIGHT_NEAR - CHARACTER_HEIGHT_FAR) / FAR_DISTANCE);
	local scale = height / CHARACTER_HEIGHT_NEAR;
	
	-- attempt to fix the height where between the middle ranges, the height is about 50px off
	if (scale < 0.7) then
		height = height * 0.7;
	else
		height = height * scale;
	end
	
	-- add in the size of the pointer
	if (settings.AutoScale) then
		height = height - (32 * scale);
	end
	
	if (not settings.AutoPosition) then
		height = 0;
	end
	
	WindowClearAnchors(self:GetName());
	WindowAddAnchor(self:GetName(), "center", self.Parent:GetName(), "center", GroupRange.Settings.Offset.X + settings.Offset.X, GroupRange.Settings.Offset.Y + settings.Offset.Y + (height / rootScale));
	
	if (settings.AutoScale) then
		WindowSetScale(self:GetName(), scale * rootScale);
	end
	
	if (not self.Color or self.Color.R ~= r or self.Color.G ~= g or self.Color.B ~= b) then
		self.Color = { R = r, G = g, B = b };
		WindowSetTintColor(self:GetName() .. "Icon", r, g, b);
	end
	
end

function style.Update(object, distance)

	object.StyleTemplate[style.Identifier]:Update(distance);

end

function style.Destroy(object)

	object.StyleTemplate[style.Identifier]:Destroy();
	object.StyleTemplate[style.Identifier] = nil;

end