if (not GroupRangeSetup) then GroupRangeSetup = {} end
GroupRangeSetup.Style.Pointer = {};
GroupRangeSetup.Style.Pointer.WindowName = "GroupRangeSetupStylePointerWindow";

local ColorStyle = { GroupHeal = 1, Heal = 2, Guard = 3 };
local Layer = { Background = 1, Default = 2, Foreground = 3 };

local windowName = GroupRangeSetup.Style.Pointer.WindowName;
local localization = GroupRangeLocalization.GetMapping();

local function CheckSettings()

	local settings = GroupRange.Settings.Styles;

	if (not settings.Pointer) then
		settings.Pointer =
		{
			AutoPosition = true,
			AutoScale = true,
			HideInRange = false,
			ColorStyle = ColorStyle.GroupHeal,
		};
	end
	settings = settings.Pointer;

	if (not settings.Layer) then
		settings.Layer = Layer.Default;
	end
	
	if (not settings.Offset) then
		settings.Offset = { X = 0, Y = 0 };
	end
	
end

function GroupRangeSetup.Style.Pointer.Initialize()

	CheckSettings();
	
	WindowSetTintColor(windowName .. "Background", 0, 0, 0);
	WindowSetAlpha(windowName .. "Background", 0.9);

	LabelSetText(windowName .. "TitleLabel", towstring(GroupRange.Styles.Pointer.Name));
	
	LabelSetText(windowName .. "AutoPositionCheckboxLabel", L"Auto position");
	LabelSetText(windowName .. "AutoScaleCheckboxLabel", L"Auto scale");
	LabelSetText(windowName .. "HideInRangeCheckboxLabel", L"Hide when in range");
	LabelSetText(windowName .. "ColorStyleLabel", L"Color by");
	
	ComboBoxClearMenuItems(windowName .. "ColorStyleCombo");
	ComboBoxAddMenuItem(windowName .. "ColorStyleCombo", L"Group Heal Range");
	ComboBoxAddMenuItem(windowName .. "ColorStyleCombo", L"Heal Range");
	ComboBoxAddMenuItem(windowName .. "ColorStyleCombo", L"Guard Range");
	
	LabelSetText(windowName .. "OffsetLabel", L"Offset");
	LabelSetText(windowName .. "OffsetXLabel", L"X");
	LabelSetText(windowName .. "OffsetYLabel", L"Y");
	
	LabelSetText(windowName .. "LayerLabel", L"Layer");
	ComboBoxClearMenuItems(windowName .. "LayerCombo");
	ComboBoxAddMenuItem(windowName .. "LayerCombo", L"Background");
	ComboBoxAddMenuItem(windowName .. "LayerCombo", L"Default");
	ComboBoxAddMenuItem(windowName .. "LayerCombo", L"Foreground");
	
	GroupRangeSetup.Style.Pointer.LoadSettings();
	
end

function GroupRangeSetup.Style.Pointer.LoadSettings()
	
	ButtonSetPressedFlag(windowName .. "AutoPosition" .. "Button", (GroupRange.Settings.Styles.Pointer.AutoPosition == true));
	ButtonSetPressedFlag(windowName .. "AutoScale" .. "Button", (GroupRange.Settings.Styles.Pointer.AutoScale == true));
	ButtonSetPressedFlag(windowName .. "HideInRange" .. "Button", (GroupRange.Settings.Styles.Pointer.HideInRange == true));
	ComboBoxSetSelectedMenuItem(windowName .. "ColorStyleCombo", GroupRange.Settings.Styles.Pointer.ColorStyle);
	ComboBoxSetSelectedMenuItem(windowName .. "LayerCombo", GroupRange.Settings.Styles.Pointer.Layer);
	
	TextEditBoxSetText(windowName .. "OffsetXEditBox", towstring(GroupRange.Settings.Styles.Pointer.Offset.X));
	TextEditBoxSetText(windowName .. "OffsetYEditBox", towstring(GroupRange.Settings.Styles.Pointer.Offset.Y));
	
end

function GroupRangeSetup.Style.Pointer.Show()

	if (WindowGetShowing(windowName)) then return end
	WindowSetShowing(windowName, true);

end

function GroupRangeSetup.Style.Pointer.Hide()

	if (not WindowGetShowing(windowName)) then return end
	WindowSetShowing(windowName, false);

end

function GroupRangeSetup.Style.Pointer.OnAutoPositionLUp()

	local isChecked = ButtonGetPressedFlag(windowName .. "AutoPosition" .. "Button") == false;
	ButtonSetPressedFlag(windowName .. "AutoPosition" .. "Button", isChecked);
	GroupRange.Settings.Styles.Pointer.AutoPosition = isChecked;
	
end

function GroupRangeSetup.Style.Pointer.OnAutoScaleLUp()

	local isChecked = ButtonGetPressedFlag(windowName .. "AutoScale" .. "Button") == false;
	ButtonSetPressedFlag(windowName .. "AutoScale" .. "Button", isChecked);
	GroupRange.Settings.Styles.Pointer.AutoScale = isChecked;
	
end

function GroupRangeSetup.Style.Pointer.OnHideInRangeLUp()

	local isChecked = ButtonGetPressedFlag(windowName .. "HideInRange" .. "Button") == false;
	ButtonSetPressedFlag(windowName .. "HideInRange" .. "Button", isChecked);
	GroupRange.Settings.Styles.Pointer.HideInRange = isChecked;
	
end

function GroupRangeSetup.Style.Pointer.OnColorStyleChanged()

	local value = ComboBoxGetSelectedMenuItem(windowName .. "ColorStyleCombo");
	GroupRange.Settings.Styles.Pointer.ColorStyle = value;
	
end

function GroupRangeSetup.Style.Pointer.OnOffsetXChanged()

	local value = tonumber(TextEditBoxGetText(windowName .. "OffsetXEditBox"));
	GroupRange.Settings.Styles.Pointer.Offset.X = value;

end

function GroupRangeSetup.Style.Pointer.OnOffsetYChanged()

	local value = tonumber(TextEditBoxGetText(windowName .. "OffsetYEditBox"));
	GroupRange.Settings.Styles.Pointer.Offset.Y = value;

end

function GroupRangeSetup.Style.Pointer.OnLayerChanged()

	local value = ComboBoxGetSelectedMenuItem(windowName .. "LayerCombo");
	GroupRange.Settings.Styles.Pointer.Layer = value;
	
end