if (not GroupRangeSetup) then GroupRangeSetup = {} end
GroupRangeSetup.Style.GroupBox = {};
GroupRangeSetup.Style.GroupBox.WindowName = "GroupRangeSetupStyleGroupBoxWindow";

local Growth = { Down = 1, Up = 2 };
local ColorStyle = { GroupHeal = 1, Heal = 2, Guard = 3 };
local Layer = { Background = 1, Default = 2, Foreground = 3 };

local windowName = GroupRangeSetup.Style.GroupBox.WindowName;
local localization = GroupRangeLocalization.GetMapping();

local function CheckSettings()

	local settings = GroupRange.Settings.Styles;
	
	if (not settings.GroupBox) then
		settings.GroupBox =
		{
			Movable = true,
			AutoSize = true,
			Growth = Growth.Down;
			ColorStyle = ColorStyle.GroupHeal,
		};
	end
	settings = settings.GroupBox;

	if (not settings.Layer) then
		settings.Layer = Layer.Default;
	end
	
end

function GroupRangeSetup.Style.GroupBox.Initialize()

	CheckSettings();
	
	WindowSetShowing("GroupRangeGroupBoxTemplate", false);
	
	WindowSetTintColor(windowName .. "Background", 0, 0, 0);
	WindowSetAlpha(windowName .. "Background", 0.9);

	LabelSetText(windowName .. "TitleLabel", towstring(GroupRange.Styles.GroupBox.Name));
	LabelSetText(windowName .. "MovableCheckboxLabel", L"Movable");
	LabelSetText(windowName .. "AutoSizeCheckboxLabel", L"Auto size");
	LabelSetText(windowName .. "GrowthLabel", L"Grow");
	
	ComboBoxClearMenuItems(windowName .. "GrowthCombo");
	ComboBoxAddMenuItem(windowName .. "GrowthCombo", L"Down");
	ComboBoxAddMenuItem(windowName .. "GrowthCombo", L"Up");
	
	LabelSetText(windowName .. "ColorStyleLabel", L"Color by");
	ComboBoxClearMenuItems(windowName .. "ColorStyleCombo");
	ComboBoxAddMenuItem(windowName .. "ColorStyleCombo", L"Group Heal Range");
	ComboBoxAddMenuItem(windowName .. "ColorStyleCombo", L"Heal Range");
	ComboBoxAddMenuItem(windowName .. "ColorStyleCombo", L"Guard Range");
	
	LabelSetText(windowName .. "LayerLabel", L"Layer");
	ComboBoxClearMenuItems(windowName .. "LayerCombo");
	ComboBoxAddMenuItem(windowName .. "LayerCombo", L"Background");
	ComboBoxAddMenuItem(windowName .. "LayerCombo", L"Default");
	ComboBoxAddMenuItem(windowName .. "LayerCombo", L"Foreground");
	
	GroupRangeSetup.Style.GroupBox.LoadSettings();
	
end

function GroupRangeSetup.Style.GroupBox.LoadSettings()
	
	ButtonSetPressedFlag(windowName .. "AutoSize" .. "Button", (GroupRange.Settings.Styles.GroupBox.AutoSize == true));
	ButtonSetPressedFlag(windowName .. "Movable" .. "Button", (GroupRange.Settings.Styles.GroupBox.Movable == true));
	ComboBoxSetSelectedMenuItem(windowName .. "GrowthCombo", GroupRange.Settings.Styles.GroupBox.Growth);
	ComboBoxSetSelectedMenuItem(windowName .. "ColorStyleCombo", GroupRange.Settings.Styles.GroupBox.ColorStyle);
	ComboBoxSetSelectedMenuItem(windowName .. "LayerCombo", GroupRange.Settings.Styles.GroupBox.Layer);
	
end

function GroupRangeSetup.Style.GroupBox.Show()

	if (WindowGetShowing(windowName)) then return end
	WindowSetShowing(windowName, true);

end

function GroupRangeSetup.Style.GroupBox.Hide()

	if (not WindowGetShowing(windowName)) then return end
	WindowSetShowing(windowName, false);

end

function GroupRangeSetup.Style.GroupBox.OnMovableLUp()

	local isChecked = ButtonGetPressedFlag(windowName .. "Movable" .. "Button") == false;
	ButtonSetPressedFlag(windowName .. "Movable" .. "Button", isChecked);
	GroupRange.Settings.Styles.GroupBox.Movable = isChecked;
	
end

function GroupRangeSetup.Style.GroupBox.OnAutoSizeLUp()

	local isChecked = ButtonGetPressedFlag(windowName .. "AutoSize" .. "Button") == false;
	ButtonSetPressedFlag(windowName .. "AutoSize" .. "Button", isChecked);
	GroupRange.Settings.Styles.GroupBox.AutoSize = isChecked;
	
end

function GroupRangeSetup.Style.GroupBox.OnGrowthChanged()

	local value = ComboBoxGetSelectedMenuItem(windowName .. "GrowthCombo");
	GroupRange.Settings.Styles.GroupBox.Growth = value;
	
end

function GroupRangeSetup.Style.GroupBox.OnColorStyleChanged()

	local value = ComboBoxGetSelectedMenuItem(windowName .. "ColorStyleCombo");
	GroupRange.Settings.Styles.GroupBox.ColorStyle = value;
	
end

function GroupRangeSetup.Style.GroupBox.OnLayerChanged()

	local value = ComboBoxGetSelectedMenuItem(windowName .. "LayerCombo");
	GroupRange.Settings.Styles.GroupBox.Layer = value;
	
end