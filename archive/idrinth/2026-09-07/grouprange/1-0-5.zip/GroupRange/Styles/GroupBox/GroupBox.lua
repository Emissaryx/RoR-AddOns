local identifier = "GroupBox";
GroupRange.Styles[identifier] = {};

local style = GroupRange.Styles[identifier];
style.Identifier = identifier;
style.Name = "Group Box";
style.Setup = GroupRangeSetup.Style.GroupBox;
style.Template = Frame:Subclass("GroupRangeGroupBoxTemplate");

local windowName = "GroupRangeGroupBoxTemplate";

local Growth = { Down = 1, Up = 2 };
local ColorStyle = { GroupHeal = 1, Heal = 2, Guard = 3 };
local Layer = { Background = 1, Default = 2, Foreground = 3 };

local groupIndexes = {};
local nameToIndex = {};

function style.OnInitialize()

	LayoutEditor.RegisterWindow(windowName, towstring(identifier), L"", false, false, false, nil);
	
end

function style.Initialize(object)

	--object.StyleTemplate[style.Identifier] = style.Template:Create(object);
	style.Create();
	
end

local function Reanchor()

	local settings = GroupRange.Settings.Styles[identifier];
	
	local x, y = WindowGetScreenPosition(windowName);
	local width, height = WindowGetDimensions(windowName);
	local uiScale = InterfaceCore.GetScale();
	local scale = WindowGetScale(windowName);

	WindowClearAnchors(windowName);
	if (settings.Growth == Growth.Up) then
		WindowAddAnchor(windowName, "topleft", "Root", "bottomleft", x / uiScale, (y / uiScale) + (height * scale / uiScale));
	else
		WindowAddAnchor(windowName, "topleft", "Root", "topleft", x / uiScale, y / uiScale);	
	end
	
end

local function SetLayer(window)

	local settings = GroupRange.Settings.Styles[identifier];
	local layer = 1; --default

	if (settings.Layer == Layer.Background) then
		layer = 0;
	elseif (settings.Layer == Layer.Foreground) then
		layer = 2;
	end
	
	WindowSetLayer(window, layer);

end

local function SetDimensions(window, count)

	local settings = GroupRange.Settings.Styles[identifier];
	local height = 145;
	local width = 165;

	if (settings.AutoSize) then
		if (count) then
			height = 25 + (count * 24);
		end
	end
	
	WindowSetDimensions(window, width, height);

end

function style.Create()

	local settings = GroupRange.Settings.Styles[identifier];

	if (not style.Initialized) then
		WindowSetMovable(windowName, (settings.Movable == true));
		SetLayer(windowName);
		Reanchor();
	
		style.Initialized = true;
	end

	if (not style.DisplayValue) then
		style.DisplayValue = {};
	end
	
	if (not style.Users) then
		style.Users = 1;
	else
		style.Users = style.Users + 1;
	end
	
	style.UpdateAll();
	
end

local function round(num, decimals)
	return tonumber(string.format("%." .. (decimals or 0) .. "f", num))
end

function style.UpdateAll()

	local settings = GroupRange.Settings.Styles[identifier];
	
	WindowSetShowing(windowName, false);

	local labelCount = 5;
	local validCount = 0;
	local invalidCount = 0;
	nameToIndex = {}; -- clear the cache
	
	for index = 1, 5 do
	
		local groupMember = LibGroup.GroupMembers.ByIndex[index];
		
		if (groupMember.IsValid) then
			validCount = validCount + 1;
			local labelIndex = validCount;
			
			nameToIndex[groupMember.Name] = labelIndex;
			LabelSetText(windowName .. "GroupMember" .. labelIndex, groupMember.Name);
			style.UpdateMember(groupMember, groupMember.Distance);
		else	
			invalidCount = invalidCount + 1;
			local labelIndex = labelCount + 1 - invalidCount;
					
			LabelSetText(windowName .. "GroupMember" .. labelIndex, L"");
			LabelSetText(windowName .. "GroupMember" .. labelIndex .. "Distance", L"");
			style.DisplayValue[labelIndex] = nil;
		end
		
	end
	
	SetDimensions(windowName, validCount);
	if (not WindowGetShowing(windowName)) then
		WindowSetShowing(windowName, true);
	end

end

function style.UpdateMember(groupMember, distance)

	if (not groupMember.IsValid or not nameToIndex[groupMember.Name]) then
		return;
	end
	
	local labelIndex = nameToIndex[groupMember.Name];
	local settings = GroupRange.Settings.Styles[identifier];

	local r,g,b = 255,255,255;
	local displayValue = "";

	local Range = { Near = 100, Far = 150 };

	if (settings.ColorStyle == ColorStyle.GroupHeal) then
		Range = { Near = 95, Far = 105 };
	elseif (settings.ColorStyle == ColorStyle.Guard) then
		Range = { Near = 25, Far = 30 };
	end

	if (distance) then
		if (distance < Range.Near) then
			r,g,b = 0,255,0;
		elseif (distance > Range.Far) then
			r,g,b = 255,0,0;
		elseif (distance >= Range.Near) then
			r,g,b = 255,255,0;
		end
		
		if (distance > 100000) then
			displayValue = math.floor(distance / 1000) .. "k";
		elseif (distance > 10000) then
			displayValue = round(distance / 1000, 1) .. "k";
		elseif (distance > 1000) then
			displayValue = round(distance / 1000, 2) .. "k";
		else	
			displayValue = distance;
		end
	else
		r,g,b = 30,30,30;
		displayValue = "N/A";
	end
	
	if (style.DisplayValue[labelIndex] == displayValue) then return end
	style.DisplayValue[labelIndex] = displayValue;

	LabelSetTextColor(windowName .. "GroupMember" .. labelIndex .. "Distance", r, g, b);
	LabelSetText(windowName .. "GroupMember" .. labelIndex .. "Distance", towstring(displayValue));

end

function style.Update(object, distance)

	--object.StyleTemplate[style.Identifier]:Update(object.GroupMember, distance);
	style.UpdateMember(object.GroupMember, distance);

end

function style.Destroy(object)

	local settings = GroupRange.Settings.Styles[identifier];

	if (style.Users and style.Users > 0) then
		style.Users = style.Users - 1;
	else
		style.Users = 0;
	end

	if (style.Users == 0) then
		WindowSetShowing(windowName, false);
		style.Initialized = false;
	else
		style.UpdateAll();
	end

end

function style.OnLUp()

	Reanchor();
	
end

function style.OnLayoutEditorFinished()

	Reanchor();
	
	-- the layout edit will force show the window
	if (not style.Users or style.Users == 0) then
		WindowSetShowing(windowName, false);
	end
	
end