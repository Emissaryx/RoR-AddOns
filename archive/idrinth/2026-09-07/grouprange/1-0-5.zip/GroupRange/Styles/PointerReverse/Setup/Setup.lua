if (not GroupRangeSetup) then GroupRangeSetup = {} end
GroupRangeSetup.Style.PointerReverse = {};
GroupRangeSetup.Style.PointerReverse.WindowName = "GroupRangeSetupStylePointerReverseWindow";

local ColorStyle = { GroupHeal = 1, Heal = 2, Guard = 3 };
local Layer = { Background = 1, Default = 2, Foreground = 3 };

local windowName = GroupRangeSetup.Style.PointerReverse.WindowName;
local localization = GroupRangeLocalization.GetMapping();

local function CheckSettings()

	local settings = GroupRange.Settings.Styles;

	if (not settings.PointerReverse) then
		settings.PointerReverse =
		{
			AutoScale = true,
			HideInRange = false,
			ColorStyle = ColorStyle.GroupHeal,
		};
	end
	settings = settings.PointerReverse;

	if (not settings.Layer) then
		settings.Layer = Layer.Default;
	end
	
	if (not settings.Offset) then
		settings.Offset = { X = 0, Y = 0 };
	end
	
end

function GroupRangeSetup.Style.PointerReverse.Initialize()

	CheckSettings();
	
	WindowSetTintColor(windowName .. "Background", 0, 0, 0);
	WindowSetAlpha(windowName .. "Background", 0.9);

	LabelSetText(windowName .. "TitleLabel", towstring(GroupRange.Styles.PointerReverse.Name));
	
	LabelSetText(windowName .. "AutoScaleCheckboxLabel", L"Auto scale");
	LabelSetText(windowName .. "HideInRangeCheckboxLabel", L"Hide when in range");
	LabelSetText(windowName .. "ColorStyleLabel", L"Color by");
	
	ComboBoxClearMenuItems(windowName .. "ColorStyleCombo");
	ComboBoxAddMenuItem(windowName .. "ColorStyleCombo", L"Group Heal Range");
	ComboBoxAddMenuItem(windowName .. "ColorStyleCombo", L"Heal Range");
	ComboBoxAddMenuItem(windowName .. "ColorStyleCombo", L"Guard Range");
	
	LabelSetText(windowName .. "OffsetLabel", L"Offset");
	LabelSetText(windowName .. "OffsetXLabel", L"X");
	LabelSetText(windowName .. "OffsetYLabel", L"Y");
	
	LabelSetText(windowName .. "LayerLabel", L"Layer");
	ComboBoxClearMenuItems(windowName .. "LayerCombo");
	ComboBoxAddMenuItem(windowName .. "LayerCombo", L"Background");
	ComboBoxAddMenuItem(windowName .. "LayerCombo", L"Default");
	ComboBoxAddMenuItem(windowName .. "LayerCombo", L"Foreground");
	
	GroupRangeSetup.Style.PointerReverse.LoadSettings();
	
end

function GroupRangeSetup.Style.PointerReverse.LoadSettings()
	
	ButtonSetPressedFlag(windowName .. "AutoScale" .. "Button", (GroupRange.Settings.Styles.PointerReverse.AutoScale == true));
	ButtonSetPressedFlag(windowName .. "HideInRange" .. "Button", (GroupRange.Settings.Styles.PointerReverse.HideInRange == true));
	ComboBoxSetSelectedMenuItem(windowName .. "ColorStyleCombo", GroupRange.Settings.Styles.PointerReverse.ColorStyle);
	ComboBoxSetSelectedMenuItem(windowName .. "LayerCombo", GroupRange.Settings.Styles.PointerReverse.Layer);
	
	TextEditBoxSetText(windowName .. "OffsetXEditBox", towstring(GroupRange.Settings.Styles.PointerReverse.Offset.X));
	TextEditBoxSetText(windowName .. "OffsetYEditBox", towstring(GroupRange.Settings.Styles.PointerReverse.Offset.Y));
	
end

function GroupRangeSetup.Style.PointerReverse.Show()

	if (WindowGetShowing(windowName)) then return end
	WindowSetShowing(windowName, true);

end

function GroupRangeSetup.Style.PointerReverse.Hide()

	if (not WindowGetShowing(windowName)) then return end
	WindowSetShowing(windowName, false);

end

function GroupRangeSetup.Style.PointerReverse.OnAutoScaleLUp()

	local isChecked = ButtonGetPressedFlag(windowName .. "AutoScale" .. "Button") == false;
	ButtonSetPressedFlag(windowName .. "AutoScale" .. "Button", isChecked);
	GroupRange.Settings.Styles.PointerReverse.AutoScale = isChecked;
	
end

function GroupRangeSetup.Style.PointerReverse.OnHideInRangeLUp()

	local isChecked = ButtonGetPressedFlag(windowName .. "HideInRange" .. "Button") == false;
	ButtonSetPressedFlag(windowName .. "HideInRange" .. "Button", isChecked);
	GroupRange.Settings.Styles.PointerReverse.HideInRange = isChecked;
	
end

function GroupRangeSetup.Style.PointerReverse.OnColorStyleChanged()

	local value = ComboBoxGetSelectedMenuItem(windowName .. "ColorStyleCombo");
	GroupRange.Settings.Styles.PointerReverse.ColorStyle = value;
	
end

function GroupRangeSetup.Style.PointerReverse.OnOffsetXChanged()

	local value = tonumber(TextEditBoxGetText(windowName .. "OffsetXEditBox"));
	GroupRange.Settings.Styles.PointerReverse.Offset.X = value;

end

function GroupRangeSetup.Style.PointerReverse.OnOffsetYChanged()

	local value = tonumber(TextEditBoxGetText(windowName .. "OffsetYEditBox"));
	GroupRange.Settings.Styles.PointerReverse.Offset.Y = value;

end

function GroupRangeSetup.Style.PointerReverse.OnLayerChanged()

	local value = ComboBoxGetSelectedMenuItem(windowName .. "LayerCombo");
	GroupRange.Settings.Styles.PointerReverse.Layer = value;
	
end