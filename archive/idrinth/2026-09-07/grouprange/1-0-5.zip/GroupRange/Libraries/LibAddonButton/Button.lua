LibAddonButton = LibAddonButton or {};
LibAddonButton.Button = Frame:Subclass("LibAddonButtonTemplate");

local DEFAULT_ICON = "LibAddonButton_Default";
local DEFAULT_ANIMATION =
{
	FPS = 10,
	Frames = { "LibAddonButton_Gear1", "LibAddonButton_Gear2", "LibAddonButton_Gear3", "LibAddonButton_Gear4", "LibAddonButton_Gear5", "LibAddonButton_Gear6" },
};
local DEFAULT_PRESSED_ICON = "LibAddonButton_Pressed";

local function UpdateIcon(self)

	self.Animation.Frame = 0;
	self.Animation.Duration = 0;

	if (self.Pressed) then
		if (not self.Animation.IsPressedAnimated) then
			self:DisplayIcon(self.Icons.Pressed);
		end
	elseif (self.Highlighted) then
		if (not self.Animation.IsHighlightAnimated) then
			self:DisplayIcon(self.Icons.Highlight);
		end
	else
		if (not self.Animation.IsDefaultAnimated) then
			self:DisplayIcon(self.Icons.Default);
		end
	end
	
end

function LibAddonButton.Button:Create(name, width, height, defaultIcon, highlightIcon, pressedIcon)

	local windowName = "LibAddonButton" .. name;
	local button = self:CreateFromTemplate(windowName, "Root");
	button.Menu = { Name = name, Subitems = {} };
	button.Icons =
	{
		Default = defaultIcon or DEFAULT_ICON,
		Highlight = highlightIcon or defaultIcon or DEFAULT_ICON,
		Pressed = pressedIcon or defaultIcon or DEFAULT_ICON,
	}
	if (not (defaultIcon and highlightIcon and pressedIcon)) then
		button.Icons.Highlight = DEFAULT_ANIMATION;
		button.Icons.Pressed = DEFAULT_PRESSED_ICON;
	end
	button.Animation = 
	{
		Frame = 0,
		Duration = 0,
		IsDefaultAnimated = (type(button.Icons.Default) == "table"),
		IsHighlightAnimated = (type(button.Icons.Highlight) == "table"),
		IsPressedAnimated = (type(button.Icons.Pressed) == "table"),
	};
	button.MenuItems = 0;
	button.Override = { LUp = nil, RUp = nil };
	
	button:SetDimensions(width or 40, height or 40);
	if (button.Animation.IsDefaultAnimated) then
		button:DisplayIcon(button.Icons.Default[1]);
	else
		button:DisplayIcon(button.Icons.Default);
	end
	
	return button;
	
end

-- Used to override the default LUp/RUp events
function LibAddonButton.Button:SetLUpOverride(callbackFunction)
	self.Override.LUp = callbackFunction;
end

function LibAddonButton.Button:SetRUpOverride(callbackFunction)
	self.Override.RUp = callbackFunction;
	d((self.Override.RUp ~= nil));
end

function LibAddonButton.Button:DisplayIcon(icon)

	if (self.Icons.Current ~= icon) then
		DynamicImageSetTexture(self:GetName(), icon or DEFAULT_ICON, 0, 0);
		self.Icons.Current = icon;
	end

end

function LibAddonButton.Button:SetPosition(x, y)

	self:SetAnchor({ XOffset = x, YOffset = y });

end

local function AnchorContext(self)

	local interfaceScale = InterfaceCore.GetScale();
	local contextMenu = EA_Window_ContextMenu.contextMenus[1];
	local contextWidth, contextHeight = WindowGetDimensions(contextMenu.name);
	local buttonX, buttonY = WindowGetScreenPosition(self:GetName());
	local buttonWidth, buttonHeight = self:GetDimensions();
	local screenWidth, screenHeight = GetScreenResolution();
	
	LibAddonButton.SavePosition(self.Menu.Name, buttonX / interfaceScale, buttonY / interfaceScale);

	local pointX, pointY, relativePointX, relativePointY, x, y = "right", "top", "left", "top", 10, 0;
	local anchorRight = true;
	local anchorTop = true;
	
	if (buttonX + (contextWidth + buttonWidth + 10) * interfaceScale > screenWidth) then
		relativePointX = "right";
		pointX = "left";
		x = -10;
	end
	
	if (buttonY + (contextHeight * interfaceScale) > screenHeight) then
		relativePointY = "bottom";
		pointY = "bottom"
	end
	
	WindowClearAnchors(contextMenu.name);
	WindowAddAnchor(contextMenu.name, pointY .. pointX, self:GetName(), relativePointY .. relativePointX, x, y);
	
end

local function CompareMenuItem(itemA, itemB)
	if (itemB == nil) then
		return false;
	end

	return (WStringsCompare(itemA.Text, itemB.Text) < 0);
	
end

local function ShowContext(menu, menuId)

	menuId = menuId or EA_Window_ContextMenu.CONTEXT_MENU_1;
	
	EA_Window_ContextMenu.CreateContextMenu(SystemData.ActiveWindow.name, menuId);
	
	for index, menuItem in ipairs(menu) do
		if (menuItem.Subitems) then
			EA_Window_ContextMenu.AddCascadingMenuItem(menuItem.Text, function() ShowContext(menuItem.Subitems, menuId + 1) end, false, menuId)
		else
			EA_Window_ContextMenu.AddMenuItem(menuItem.Text, menuItem.Callback, false, true, menuId);
		end
	end
	
    EA_Window_ContextMenu.Finalize(menuId);

end

function LibAddonButton.Button:OnLButtonDown(flags, mouseX, mouseY)

	self.Pressed = true;
	UpdateIcon(self);

end

function LibAddonButton.Button:ProccessLButtonUp(flags, mouseX, mouseY)

	local itemCount = #self.Menu.Subitems;
	if (itemCount == 0) then
		return;
	end
	local resortMenu = (itemCount ~= self.MenuItems);

	if (resortMenu) then
		table.sort(self.Menu.Subitems, CompareMenuItem);
		self.MenuItems = itemCount;
	end
	
	ShowContext(self.Menu.Subitems);
	AnchorContext(self);
	
end

function LibAddonButton.Button:OnLButtonUp(flags, mouseX, mouseY)

	self.Pressed = false;
	UpdateIcon(self);
	
	if (self.Override.LUp ~= nil) then
		local success, errmsg = pcall(self.Override.LUp);
		return;
	end
	
	self:ProccessLButtonUp(flags, mouseX, mouseY);

end

function LibAddonButton.Button:ToggleLock(isMovable)

	if (isMovable == nil) then
		isMovable = not WindowGetMovable(self:GetName());
	end
	
	self:SetMovable(isMovable);

end

function LibAddonButton.Button:OnRButtonUp(flags, mouseX, mouseY)
	
	if (self.Override.RUp ~= nil) then
		local success, errmsg = pcall(self.Override.RUp);
		return;
	end

	local contextMenuID = EA_Window_ContextMenu.CONTEXT_MENU_1;
	local text = GetString(StringTables.Default.LABEL_TO_LOCK); -- "Lock"
	
	if (not WindowGetMovable(self:GetName())) then
		text = GetString(StringTables.Default.LABEL_TO_UNLOCK); -- "Unlock"
	end

	EA_Window_ContextMenu.CreateContextMenu(SystemData.ActiveWindow.name, contextMenuID);
	EA_Window_ContextMenu.AddMenuItem(text, function() self:ToggleLock() end, false, true, contextMenuID);
	
	-- modify the context creation so the minimum menu width is smaller
	local contextMenu = EA_Window_ContextMenu.contextMenus[contextMenuID];	
	local minWidth = EA_Window_ContextMenu.MIN_WIDTH;
	EA_Window_ContextMenu.MIN_WIDTH = contextMenu.greatestWidth + 10;
    EA_Window_ContextMenu.Finalize(contextMenuID);
	EA_Window_ContextMenu.MIN_WIDTH = minWidth;
	
	-- manually anchor the context menu item so that it won't break when the menu is going offscreen
	WindowClearAnchors(contextMenu.name .. "DefaultItem1");
	WindowAddAnchor(contextMenu.name .. "DefaultItem1", "topleft", contextMenu.name, "topleft", 5, 5);
	AnchorContext(self);
	
end

function LibAddonButton.Button:OnMouseOver(flags, mouseX, mouseY)

	self.Highlighted = true;
	UpdateIcon(self);

end

function LibAddonButton.Button:OnMouseOverEnd(flags, mouseX, mouseY)

	self.Pressed = false;
	self.Highlighted = false;
	UpdateIcon(self);
	
end

local function RunAnimation(self, elapsed, animation)

	self.Animation.Duration = self.Animation.Duration - elapsed;
	if (self.Animation.Duration <= 0) then
		self.Animation.Frame = (self.Animation.Frame % #animation.Frames) + 1;
		self.Animation.Duration = 1 / math.max(animation.FPS or 1, 1);
		self:DisplayIcon(animation.Frames[self.Animation.Frame]);
	end
			
end

function LibAddonButton.Button:Update(elapsed)

	if (self.Pressed) then
		if (self.Animation.IsPressedAnimated) then
			RunAnimation(self, elapsed, self.Icons.Pressed);
		end
	elseif (self.Highlighted) then
		if (self.Animation.IsHighlightAnimated) then
			RunAnimation(self, elapsed, self.Icons.Highlight);
		end
	else
		if (self.Animation.IsDefaultAnimated) then
			RunAnimation(self, elapsed, self.Icons.Default);
		end
	end

end