<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
	<UiMod name="LibAddonButton" version="1.0.0" date="9/13/2010" >
		<VersionSettings gameVersion="1.3.6" windowsVersion="1.0" savedVariablesVersion="1.1" />

		<Author name="Healix" email="" />
		<Description text="Creates icon buttons for addons" />
       
		<Dependencies>
		</Dependencies>

		<Files>
			<File name="Core.xml" />
			<File name="Core.lua" />
			<File name="Button.lua" />
		</Files>
		
		<SavedVariables>
			<SavedVariable name="LibAddonButton.Settings" />		  
		</SavedVariables>
		
		<OnInitialize>
			<CallFunction name="LibAddonButton.Initialize" />
		</OnInitialize>
		<OnUpdate>
			<CallFunction name="LibAddonButton.OnUpdate" />
		</OnUpdate>
		<OnShutdown>
			<CallFunction name="LibAddonButton.Unload" />
		</OnShutdown>
		<WARInfo>
		</WARInfo>
	</UiMod>
</ModuleFile>
