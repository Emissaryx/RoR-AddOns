--[[

Registering a button:
	LibAddonButton.Register("uniqeName", buttonWidth, buttonHeight, "DefaultTexture", "HighlightTexture", "PressedTexture")
	
	By default, if the "PressedTexture" or "HighlightTexture" is left blank, then "DefaultTexture" will be used. If they
	are all left blank, the default animated gear button will be used.
	
	A texture can be a simple string that is the name of a texture, or an animation. The format of an animation is:
	
	local animation =
	{
		FPS = 10,	-- display 1 frame every 0.1 seconds
		Frames =	-- this must be an index-based array from 1 to n
		{
			"FrameTexture1", "FrameTexture2", "FrameTexture3"
		}
	}
	
Adding a menu item:
	LibAddonButton.AddMenuItem("uniqeName", L"label text", callbackFunction)
	
Adding a cascading menu item:
	local menu = LibAddonButton.AddCascadingMenuItem("uniqeName", L"label text")
	
	This function returns the created menu that is used to add submenu items.
	Examples to add submenu items:
	
	LibAddonButton.AddMenuSubitem(menu, L"A", callbackFunction)
	menu = LibAddonButton.AddCascadingMenuSubitem(menu, L"B", callbackFunction)
	LibAddonButton.AddMenuSubitem(menu, L"C", callbackFunction)
	menu = LibAddonButton.AddCascadingMenuSubitem(menu, L"D", callbackFunction)
	LibAddonButton.AddMenuSubitem(menu, L"E", callbackFunction)
	
	The above will result in:
	
	A
	B	>	C
			D	>	E
			
Overriding the default behavior of the LUp/RUp events:
	First you must find the button using either method:
	
	local button = LibAddonButton.Register("uniqueName", ... )
	local button = LibAddonButton.GetButton("uniqueName")
	
	Then to override the LUp/RUp events:
	
	button:SetLUpOverride(callbackFunction)
	button:SetRUpOverride(callbackFunction)
	
--]]

LibAddonButton = LibAddonButton or {};

local refreshRequired = false;
local updateQueue = {};
local registeredButtons = {};
local animatedButtons = {};
local animatedButtonCount = 0;

local function AddAnimation(name)

	if (not animatedButtons[name]) then
		animatedButtonCount = animatedButtonCount + 1;
	end

	animatedButtons[name] = true;

end

local function QueueUpdate(name)
	updateQueue[name] = true;
	refreshRequired = true;
end

local function UpdateButton(name)

	local button = registeredButtons[name];
	if (not button) then return end
	
	--[[ The original intent was to hide buttons with no menu items
	local menuItems = #button.Menu.Subitems;
	button:Show(menuItems > 0);
	--]]
	
	button:Show(true);

end

local function LoadSettings()

	if (not LibAddonButton.Settings) then
		LibAddonButton.Settings = {};
	end
	
end

function LibAddonButton.Initialize()

	LoadSettings();
	
end

function LibAddonButton.Unload()

	local interfaceScale = InterfaceCore.GetScale();

	for name, button in pairs(registeredButtons) do
		if (DoesWindowExist(button:GetName())) then
			local x, y = WindowGetScreenPosition(button:GetName());
			LibAddonButton.SavePosition(button.Menu.Name, x / interfaceScale, y / interfaceScale);
		end
	end

end

function LibAddonButton.SavePosition(name, x, y)

	if (name and registeredButtons[name]) then
		LibAddonButton.Settings[name] = { X = x, Y = y };
	end

end

function LibAddonButton.Register(name, width, height, defaultIcon, highlightIcon, pressedIcon)

	-- if called with no name, one will be generated
	if (not name) then
		name = 1;
		while (registeredButtons[name]) do
			name = name + 1;
		end
	end

	if (not registeredButtons[name]) then
		registeredButtons[name] = LibAddonButton.Button:Create(name, width, height, defaultIcon, highlightIcon, pressedIcon);
		
		if (type(defaultIcon) == "table" or type(highlightIcon) == "table" or type(pressedIcon) == "table" or not (defaultIcon and highlightIcon and pressedIcon)) then
			AddAnimation(name);
		end
		
		local button = registeredButtons[name];
		button.Name = name;
		
		local settings = LibAddonButton.Settings[name];
		if (settings) then
			button:SetPosition(settings.X, settings.Y);
		else
			button:ToggleLock(true); -- the first time a button is seen, it is automatically unlocked
		end
		
		QueueUpdate(name);
	end
	
	return registeredButtons[name];

end

local function AddMenuItem(menu, text, isCascading, callbackFunction)
	
	local menuItem =
	{
		Text = towstring(text),
		Callback = callbackFunction,
	}
	
	if (isCascading) then
		menuItem.Parent = menu;
		menuItem.Subitems = {};
	end
	
	table.insert(menu.Subitems, menuItem);
	
	local item = menu;
	while (item.Parent) do
		item = item.Parent;
	end
	if (item.Name) then
		QueueUpdate(item.Name);
	end
	
	return menuItem;

end

function LibAddonButton.AddMenuItem(name, text, callbackFunction)

	if (not registeredButtons[name]) then return end
	AddMenuItem(registeredButtons[name].Menu, text, false, callbackFunction)

end

function LibAddonButton.AddCascadingMenuItem(name, text)

	if (not registeredButtons[name]) then return end
	return AddMenuItem(registeredButtons[name].Menu, text, true)

end

function LibAddonButton.AddMenuSubitem(menu, text, callbackFunction)

	if (not menu or not menu.Subitems) then return end
	AddMenuItem(menu, text, false, callbackFunction);

end

function LibAddonButton.AddCascadingMenuSubitem(menu, text)

	if (not menu or not menu.Subitems) then return end
	return AddMenuItem(menu, text, true);
	
end

-- Returns the button for the specified name
function LibAddonButton.GetButton(name)

	if (not registeredButtons[name]) then return end
	return registeredButtons[name];

end

function LibAddonButton.OnUpdate(elapsed)

	if (refreshRequired) then
		refreshRequired = false;
		for name, _ in pairs(updateQueue) do
			UpdateButton(name);
		end
		updateQueue = {};
	end
	
	if (animatedButtonCount > 0) then
		for name, _ in pairs(animatedButtons) do
			registeredButtons[name]:Update(elapsed);
		end
	end

end