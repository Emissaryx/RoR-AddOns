if (not GroupRangeLocalization) then
	GroupRangeLocalization = {};
	GroupRangeLocalization.Language = {};
end

local localizationWarning = false;

function GroupRangeLocalization.GetMapping()

	local lang = GroupRangeLocalization.Language[SystemData.Settings.Language.active];
	
	if (not lang) then
		if (not localizationWarning) then
			d("Your current language is not supported. English will be used instead.");
			localizationWarning = true;
		end
		lang = GroupRangeLocalization.Language[SystemData.Settings.Language.ENGLISH];
	end
	
	return lang;
	
end