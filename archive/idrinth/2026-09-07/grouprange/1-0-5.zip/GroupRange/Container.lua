GroupRangeContainer = Frame:Subclass("GroupRangeContainerTemplate");

function GroupRangeContainer:Create(groupMember)
	local frame = self:CreateFromTemplate("GroupRange" .. tostring(groupMember.Name), "Root");

	frame.GroupMember = groupMember;
	frame.AttachedTo = nil;
	frame.StyleTemplate = {};
	frame.Style = {};
	
	for style, enabled in pairs(GroupRange.Settings.ActiveStyles) do
		frame.Style[style] = GroupRange.Styles[style];
		if (frame.Style[style]) then
			frame.Style[style].Initialize(frame);
		end
	end
	
	if (groupMember.WorldObjectId and groupMember.WorldObjectId ~= 0) then
		frame:AttachTo(groupMember.WorldObjectId);
		frame:SetShowing(true);
	end
	
	return frame;
end

function GroupRangeContainer:SetShowing(isVisible)
	if (WindowGetShowing(self:GetName()) ~= isVisible) then
		WindowSetShowing(self:GetName(), isVisible);
	end
end

function GroupRangeContainer:AttachTo(objectId)

	if (objectId and objectId == 0) then
		objectId = nil;
	end

	if (self.AttachedTo) then
		DetachWindowFromWorldObject(self:GetName(), self.AttachedTo)
	end
	if (objectId) then
		AttachWindowToWorldObject(self:GetName(), objectId);
	end
	self.AttachedTo = objectId;

end

function GroupRangeContainer:Destroy()

	self:AttachTo(nil);
	
	for id, style in pairs(self.Style) do
		style.Destroy(self);
	end
	
	FrameManager:Remove(self:GetName());
	DestroyWindow(self:GetName());
	
end

function GroupRangeContainer:Update(distance)
	
	for id, style in pairs(self.Style) do
		style.Update(self, distance);
	end

end