GroupRange = GroupRange or {};

local VERSION_SETTINGS = 1;
local UPDATE_THROTTLE = 1;

GroupRange.TimeCount = 0;
GroupRange.Container = {};
local playersName = L"";

local lastUpdate = 0;
GroupRange.Styles = {};

local isLibSlashRegistered = false;
local isLibAddonButtonRegistered = false;

local function RegisterLibs()
	if (not isLibSlashRegistered) then
		if (LibSlash) then
			LibSlash.RegisterWSlashCmd("grouprange", function(args) GroupRange.SlashCommand(args) end);
			isLibSlashRegistered = true;
		end
	end

	if (not isLibAddonButtonRegistered) then
		if (LibAddonButton) then
			LibAddonButton.Register("fx");
			LibAddonButton.AddMenuItem("fx", "GroupRange", GroupRangeSetup.Show);
			isLibAddonButtonRegistered = true;
		end
	end
end

local function print(text)

	EA_ChatWindow.Print(towstring(tostring(text)), ChatSettings.Channels[SystemData.ChatLogFilters.SAY].id);

end

function GroupRange.Initialize()
	
	RegisterEventHandler(SystemData.Events.LOADING_END, "GroupRange.OnLoadingEnd");
	RegisterEventHandler(SystemData.Events.INTERFACE_RELOADED, "GroupRange.OnLoadingEnd");
	table.insert(LayoutEditor.EventHandlers, GroupRange.OnLayoutEditorFinished);
	
	GroupRange.LoadSettings();
	GroupRangeSetup.Initialize();
	
	LibGroup.Register(LibGroup.Events.GROUP_UPDATED, GroupRange.OnGroupUpdated);
	LibGroup.Register(LibGroup.Events.GROUP_MEMBER_DISTANCE_CHANGED, GroupRange.OnGroupMemberDistanceChanged);
	LibGroup.Register(LibGroup.Events.GROUP_MEMBER_REMOVED, GroupRange.OnGroupMemberRemoved);
	LibGroup.Register(LibGroup.Events.GROUP_MEMBER_WORLD_OBJECT_CHANGED, GroupRange.OnGroupMemberWorldObjectChanged);
	
end

local function UpdateSettings()

	local version = GroupRange.Settings.Version;

	-- changes from version to version go here
	if (version == nil or type(version) == "string") then
		version = 1;
	end
	if (version == 1) then
		version = 2;
	end
	
end

function GroupRange.LoadSettings()

	if (not GroupRange.Settings) then
		GroupRange.Settings = {};
	else
		UpdateSettings();
	end
	
	GroupRange.Settings.Version = VERSION_SETTINGS;
	
	local settings = GroupRange.Settings;
	
	if (not settings.Offset) then
		settings.Offset = { X = 0, Y = 0 };
	end
	if (not settings.Delay) then
		settings.Delay = 0.1;
	end
	if (not settings.Styles) then
		settings.Styles = {};
	end
	if (not settings.ActiveStyles) then
		settings.ActiveStyles = { Pointer = true };
	end

end

function GroupRange.OnLayoutEditorFinished(exitCode)
	
	if (exitCode ~= LayoutEditor.EDITING_END) then return end
	
	for id, style in pairs(GroupRange.Styles) do
		if (style.OnLayoutEditorFinished) then
			style.OnLayoutEditorFinished();
		end
	end

end

function GroupRange.AddStyle(style)

	if (not style.Identifier) then
		return;
	end
	if (GroupRange.Styles[style.Identifier]) then
		d("The style \"" .. style.Name .. "\" already exists");
		return;
	end
	
	GroupRange.Styles[style.Identifier] = style;

end

function GroupRange.SlashCommand(args)

	local option, value = args:match(L"([a-z0-9]+)[ ]?(.*)");
	
	GroupRangeSetup.Show();

end

function GroupRange.OnLoadingEnd()
	
	RegisterLibs();
	
    playersName = GameData.Player.name:match(L"([^^]+)^?([^^]*)");
	GroupRange.DestroyAllContainers();

end

function GroupRange.OnGroupUpdated()

end

function GroupRange.OnGroupMemberDistanceChanged(groupMember)

	if (GroupRange.Container[groupMember.Name]) then
		--GroupRange.DestroyContainer(groupMember);
	end

end

function GroupRange.OnGroupMemberRemoved(groupMember)

	if (GroupRange.Container[groupMember.Name]) then
		GroupRange.DestroyContainer(groupMember);
	end

end

function GroupRange.OnGroupMemberWorldObjectChanged(oldId, newId, groupMember)

	if (GroupRange.Container[groupMember.Name]) then
		GroupRange.Container[groupMember.Name]:AttachTo(newId);
	end

	--GroupRange.DestroyContainer(groupMember);
			
end

function GroupRange.DestroyAllContainers()

	for name, container in pairs(GroupRange.Container) do
		GroupRange.DestroyContainer(LibGroup.GroupMembers.ByName[name]);
	end
end

function GroupRange.CreateContainer(groupMember)

	if (not groupMember or not groupMember.IsValid or GroupRange.Container[groupMember.Name]) then return end
	
	local container = GroupRangeContainer:Create(groupMember);
	GroupRange.Container[groupMember.Name] = container;
	
	return container;
	
end

function GroupRange.DestroyContainer(groupMember)
	
	if (not groupMember) then return end
	
	local container = GroupRange.Container[groupMember.Name];
	if (not container) then return end;
	
	GroupRange.Container[groupMember.Name] = nil;
	container:Destroy();

end

function GroupRange.UpdateDisplay()

	for index, groupMember in pairs(LibGroup.GroupMembers.ByIndex) do
		if (groupMember and groupMember.IsValid and groupMember.Name ~= playersName) then
			
			if (not GroupRange.Container[groupMember.Name]) then
				GroupRange.CreateContainer(groupMember);
			end
			
			local container = GroupRange.Container[groupMember.Name];
			
			if (container) then
				container:Update(groupMember.Distance);
			end
			
		end
	end
	
end

function GroupRange.OnUpdate(elapsed)
	GroupRange.TimeCount = GroupRange.TimeCount + elapsed;

	if (GroupRange.TimeCount - lastUpdate >= (GroupRange.Settings.Delay or UPDATE_THROTTLE)) then
		 GroupRange.UpdateDisplay();
		
		lastUpdate = GroupRange.TimeCount;
	end
end