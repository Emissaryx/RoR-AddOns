<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
	<UiMod name="GroupRange" version="1.0.5" date="9/14/2010" >
		<VersionSettings gameVersion="1.3.6" windowsVersion="1.0" savedVariablesVersion="1.0" />

		<Author name="Healix" email="" />
		<Description text="Range display on group members" />
       
		<Dependencies>
			<Dependency name="EASystem_LayoutEditor" />
			<Dependency name="LibGroup" />
		</Dependencies>

		<Files>
			<File name="Localization.lua" />
			<File name="Localization/enUS.lua" />
			
			<File name="Setup/SetupStyle.xml" />
			<File name="Setup/SetupStyle.lua" />
			<File name="Setup/SetupGeneral.xml" />
			<File name="Setup/SetupGeneral.lua" />
			<File name="Setup/SetupMenu.xml" />
			<File name="Setup/Setup.lua" />
			
			<File name="Display.xml" />
			<File name="Container.lua" />
			<File name="Core.lua" />
			
			<File name="Styles/SimpleText/Setup/Setup.xml" />
			<File name="Styles/SimpleText/Setup/Setup.lua" />
			<File name="Styles/SimpleText/SimpleText.lua" />
			
			<File name="Styles/Pointer/Setup/Setup.xml" />
			<File name="Styles/Pointer/Setup/Setup.lua" />
			<File name="Styles/Pointer/Pointer.lua" />
			
			<File name="Styles/PointerReverse/Setup/Setup.xml" />
			<File name="Styles/PointerReverse/Setup/Setup.lua" />
			<File name="Styles/PointerReverse/PointerReverse.lua" />
			
			<File name="Styles/GroupBox/Setup/Setup.xml" />
			<File name="Styles/GroupBox/Setup/Setup.lua" />
			<File name="Styles/GroupBox/GroupBox.lua" />
		</Files>
		
		<SavedVariables>
			<SavedVariable name="GroupRange.Settings" />		  
		</SavedVariables>
		
		<OnInitialize>
			<CreateWindow name="GroupRangeGroupBoxTemplate" show="false" />
			<CreateWindow name="GroupRangeSetupStyleGroupBoxWindow" show="false" />
			<CreateWindow name="GroupRangeSetupStylePointerReverseWindow" show="false" />
			<CreateWindow name="GroupRangeSetupStylePointerWindow" show="false" />
			<CreateWindow name="GroupRangeSetupStyleSimpleTextWindow" show="false" />
			<CreateWindow name="GroupRangeSetupStyleWindow" show="false" />
			<CreateWindow name="GroupRangeSetupGeneralWindow" show="false" />
			<CreateWindow name="GroupRangeSetupMenuWindow" show="false" />
			<CallFunction name="GroupRange.Initialize" />
			<CallFunction name="GroupRange.Styles.GroupBox.OnInitialize" />
		</OnInitialize>
		<OnUpdate>
			<CallFunction name="GroupRange.OnUpdate" />
		</OnUpdate>
		<OnShutdown/>
		<WARInfo>
			<Categories>
			</Categories>
			<Careers>
				<Career name="BLACKGUARD" />
				<Career name="WITCH_ELF" />
				<Career name="DISCIPLE" />
				<Career name="SORCERER" />
				<Career name="IRON_BREAKER" />
				<Career name="SLAYER" />
				<Career name="RUNE_PRIEST" />
				<Career name="ENGINEER" />
				<Career name="BLACK_ORC" />
				<Career name="CHOPPA" />
				<Career name="SHAMAN" />
				<Career name="SQUIG_HERDER" />
				<Career name="WITCH_HUNTER" />
				<Career name="KNIGHT" />
				<Career name="BRIGHT_WIZARD" />
				<Career name="WARRIOR_PRIEST" />
				<Career name="CHOSEN" />
				<Career name= "MARAUDER" />
				<Career name="ZEALOT" />
				<Career name="MAGUS" />
				<Career name="SWORDMASTER" />
				<Career name="SHADOW_WARRIOR" />
				<Career name="WHITE_LION" />
				<Career name="ARCHMAGE" />
			</Careers>
		</WARInfo>
	</UiMod>
</ModuleFile>
