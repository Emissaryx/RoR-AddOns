# EA_OpenPartyWindow

EA_OpenPartyWindow replaces the default Return of Reckoning Open Parties and Warbands window. It keeps the default tabs and adds role summaries, Manage-tab sorting, alt-spec overlays, and optional rank/order integration with other addons.

## Features

### Built In

- World and Nearby tooltips show tank, healer, and DPS summaries, including melee/ranged DPS splits.
- The Manage tab shows party counts and a labeled warband role summary.
- Manage `Sort` can group warband members by role, then by name, without breaking row actions or drag/drop.
- Career icons can show RoRGroupScoreboard alt-spec overlays.
- Loot-roll defaults differ from the default UI: usable gear, currency, potions, talismans, event items, and trash default to Need; unusable gear defaults to Greed; crafting stays Ask Me.

### Optional Addon Support

- AutoBand: when already installed with usable Renown Rank data, rank text can show `CR/RR` in Manage and tooltips.
- Enemy: when already installed with unit-frame sorting enabled, Manage `Sort` can follow Enemy's role order and alt-spec ignore settings.
- Without AutoBand or Enemy, the addon keeps its default-compatible fallback behavior.

## Usage

- Clear `Sort` in the Manage tab to use the default row order.
- Review Loot Options after installing if you do not want the custom auto-roll defaults.
- Reload the UI after replacing addon files.

## Changelog

### 1.4.4 - 2026-05-16 - Wholdar

- Reintroduced Manage-tab role sorting as `Sort`: toggleable, role-then-name ordered, and safe for row actions/drag/drop.
- Added optional Enemy support for Manage sort order and Enemy alt-spec ignore settings.
- Changed the Manage warband header from compact role numbers to labeled role text; Manage summaries follow the active sort order.
- Tightened AutoBand rank display so `CR/RR` layout requires usable RR data; default rank layout stays otherwise.
- Added aligned tooltip rank/name labels for `CR/RR` display.
- Changed World/Nearby role-summary order to tanks, healers, DPS.
- Refreshed Manage overlays and sorting while the tab is open when scoreboard or Enemy state changes.

### 1.4.3 - 2026-03-05 - Wholdar

- Added optional AutoBand RR lookup for tooltips, Manage rows, and dragged Manage rows.

### 1.4.2 - 2025-12-20 - Wholdar

- Stopped applying scoreboard alt-spec role overrides to World/Nearby role counts for warbands the player has not joined.

### 1.4.1 - 2025-12-18 - Wholdar

- Incorporated default UI Leader Marks support, including Manage controls, tooltips, zone handling, marker commands, and related layout changes.

### 1.3.3 - 2025-12-12 - Wholdar

- Added alt-spec overlay handling for the warband leader row in World/Nearby mouseover tooltips.

### 1.3.2 - 2025-12-05 - Wholdar

- Added shared role counting, melee/ranged DPS splits, scoreboard alt-spec detection, career-icon overlays, and Manage-tab overlay polling.
- Removed the always-on Manage-tab role sorting from `1.3.0`/`1.3.1`; Manage rows returned to default row order while role counts stayed.
- Added the event auto-roll row and changed most auto-roll defaults away from the default UI's Ask Me behavior.
- Downgraded legacy Need values for unusable gear to Greed.
- Added module `VersionSettings` metadata and updated the description.

### 1.3.1 - 2025-03-28 - Yun

- Metadata-only update: version `1.3.1`, author `EAMythic,Yun`; no shipped source changes.

### 1.3.0 - 2021-05-10 - Yun

- First Idrinth package for this addon. The `.mod` file reports version `1.3`; Idrinth lists it as `1.3.0`.
- Added tank/DPS/healer counts to World/Nearby open-warband tooltips and the Manage tab.
- Added always-on Manage-tab row ordering by tank, DPS, then healer.
