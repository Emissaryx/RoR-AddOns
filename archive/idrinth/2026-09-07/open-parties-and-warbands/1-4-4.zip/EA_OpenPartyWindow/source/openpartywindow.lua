
EA_Window_OpenParty = {}

local PARENT_WINDOW = "EA_Window_OpenParty"
local FLY_OUT_WINDOW = "EA_Window_OpenPartyFlyOut"
local TOOLTIP_BORDER_OFFSET = 10
local FADE_OUT_DELAY = 3
local TOTAL_NUM_NOTIFY_MEMBERS = 3

EA_Window_OpenParty.TAB_NEARBY = 1
EA_Window_OpenParty.TAB_WORLD = 2
EA_Window_OpenParty.LOOT_ROLL_OPTIONS = 3
EA_Window_OpenParty.TAB_MANAGE = 4
EA_Window_OpenParty.TabData = {
    [EA_Window_OpenParty.TAB_NEARBY]        = { tabName = "TabNearby",          windowName = "Nearby",          scenarioAllow = false },
    [EA_Window_OpenParty.TAB_WORLD]         = { tabName = "TabWorld",           windowName = "World",           scenarioAllow = false },
    [EA_Window_OpenParty.LOOT_ROLL_OPTIONS] = { tabName = "TabLootRollOptions", windowName = "LootRollOptions", scenarioAllow = true },
    [EA_Window_OpenParty.TAB_MANAGE]        = { tabName = "TabManage",          windowName = "Manage",          scenarioAllow = false }
}
-- populated in Initialize based on the above data
local TabsAllowedWithinScenario = {}

EA_Window_OpenParty.InterestTypes = {
    [GameData.OpenPartyInterest.NOT_SET] = GetStringFromTable( "SocialStrings", StringTables.Social.PARTY_INTEREST_ANY ),
    [GameData.OpenPartyInterest.PVE] = GetStringFromTable( "SocialStrings", StringTables.Social.PARTY_INTEREST_PVE ),
    [GameData.OpenPartyInterest.RVR] = GetStringFromTable( "SocialStrings", StringTables.Social.PARTY_INTEREST_RVR ),
    [GameData.OpenPartyInterest.PQ] = GetStringFromTable( "SocialStrings", StringTables.Social.PARTY_INTEREST_PQ ),
    [GameData.OpenPartyInterest.SCENARIO] = GetStringFromTable( "SocialStrings", StringTables.Social.PARTY_INTEREST_SCENARIO ),
    [GameData.OpenPartyInterest.DUNGEON] = GetStringFromTable( "SocialStrings", StringTables.Social.PARTY_INTEREST_DUNGEON )
}
EA_Window_OpenParty.InterestTypeColors = {
    [GameData.OpenPartyInterest.NOT_SET] = { r=255,g=255,b=255 },
    [GameData.OpenPartyInterest.PVE] = { r=255,g=204,b=102 },
    [GameData.OpenPartyInterest.RVR] = { r=255,g=0,b=0 },
    [GameData.OpenPartyInterest.PQ] = { r=102,g=102,b=255 },
    [GameData.OpenPartyInterest.SCENARIO] = { r=0,g=166,b=80 },
    [GameData.OpenPartyInterest.DUNGEON] = { r=160,g=65,b=13 }
}

EA_Window_OpenParty.PartyTextColor = {
    r=253,
    g=253,
    b=253,
}
EA_Window_OpenParty.WarbandTextColor = {
    r=178,
    b=255,
    g=116,
}

EA_Window_OpenParty.ICON_ALLIANCE   = 65
EA_Window_OpenParty.ICON_FRIEND     = 66
EA_Window_OpenParty.ICON_GUILD      = 67
EA_Window_OpenParty.ICON_IGNORE     = 68

EA_Window_OpenParty.TOTAL_NUM_GROUP_MEMBERS = 6
EA_Window_OpenParty.TOTAL_NUM_WARBAND_MEMBERS = 24
-- Used to fade the window out
EA_Window_OpenParty.fadeOutDelay = 0
local SCOREBOARD_POLL_INTERVAL = 2
local scoreboardPollTimer = 0
local scoreboardAltSpecSignature = nil

EA_Window_OpenParty.RoleTypes = {
    TANK = "tank",
    MDPS = "mdps",
    RDPS = "rdps",
    HEALER = "healer",
}

-- Career role lookup used for composition/role summaries.
EA_Window_OpenParty.CareerRoles = {
    [GameData.CareerLine.ENGINEER]       = EA_Window_OpenParty.RoleTypes.RDPS,
    [GameData.CareerLine.BRIGHT_WIZARD]  = EA_Window_OpenParty.RoleTypes.RDPS,
    [GameData.CareerLine.SORCERER]       = EA_Window_OpenParty.RoleTypes.RDPS,
    [GameData.CareerLine.SQUIG_HERDER]   = EA_Window_OpenParty.RoleTypes.RDPS,
    [GameData.CareerLine.MAGUS]          = EA_Window_OpenParty.RoleTypes.RDPS,
    [GameData.CareerLine.SHADOW_WARRIOR] = EA_Window_OpenParty.RoleTypes.RDPS,

    [GameData.CareerLine.WITCH_ELF]      = EA_Window_OpenParty.RoleTypes.MDPS,
    [GameData.CareerLine.WHITE_LION]     = EA_Window_OpenParty.RoleTypes.MDPS,
    [GameData.CareerLine.SLAYER]         = EA_Window_OpenParty.RoleTypes.MDPS,
    [GameData.CareerLine.WITCH_HUNTER]   = EA_Window_OpenParty.RoleTypes.MDPS,
    [GameData.CareerLine.CHOPPA]         = EA_Window_OpenParty.RoleTypes.MDPS,
    [GameData.CareerLine.MARAUDER]       = EA_Window_OpenParty.RoleTypes.MDPS,

    [GameData.CareerLine.IRON_BREAKER]   = EA_Window_OpenParty.RoleTypes.TANK,
    [GameData.CareerLine.CHOSEN]         = EA_Window_OpenParty.RoleTypes.TANK,
    [GameData.CareerLine.BLACK_ORC]      = EA_Window_OpenParty.RoleTypes.TANK,
    [GameData.CareerLine.KNIGHT]         = EA_Window_OpenParty.RoleTypes.TANK,
    [GameData.CareerLine.SWORDMASTER]    = EA_Window_OpenParty.RoleTypes.TANK,
    [GameData.CareerLine.BLACKGUARD]     = EA_Window_OpenParty.RoleTypes.TANK,

    [GameData.CareerLine.ZEALOT]         = EA_Window_OpenParty.RoleTypes.HEALER,
    [GameData.CareerLine.WARRIOR_PRIEST] = EA_Window_OpenParty.RoleTypes.HEALER,
    [GameData.CareerLine.RUNE_PRIEST]    = EA_Window_OpenParty.RoleTypes.HEALER,
    [GameData.CareerLine.ARCHMAGE]       = EA_Window_OpenParty.RoleTypes.HEALER,
    [GameData.CareerLine.SHAMAN]         = EA_Window_OpenParty.RoleTypes.HEALER,
    [GameData.CareerLine.DISCIPLE]       = EA_Window_OpenParty.RoleTypes.HEALER,
}

local function ToNameString(name)
    if not name then
        return nil
    end
    if type(name) ~= "string" and WStringToString then
        name = WStringToString(name)
    end
    if type(name) ~= "string" then
        name = tostring(name)
    end
    if not name then
        return nil
    end
    return name
end

local function NormalizeNameKey(name)
    local asString = ToNameString(name)
    if not asString then
        return nil
    end
    return string.lower(asString)
end

local function IsRunePriestOrZealot(careerId)
    return careerId == GameData.CareerLine.RUNE_PRIEST or careerId == GameData.CareerLine.ZEALOT
end

function EA_Window_OpenParty.GetEnemySettings()
    if type(Enemy) ~= "table" then
        return nil
    end

    if type(Enemy.unitFrames) == "table" and type(Enemy.unitFrames.settings) == "table" then
        return Enemy.unitFrames.settings
    end

    if type(Enemy.Settings) == "table" then
        return Enemy.Settings
    end

    return nil
end

function EA_Window_OpenParty.ShouldEnemyIgnoreAltSpecForCareer(careerId)
    local settings = EA_Window_OpenParty.GetEnemySettings()
    if not settings then
        return false
    end

    if settings.unitFramesDisableAltSpecCheck == true then
        return true
    end

    if settings.unitFramesDisableAltSpecCheckForRunePriestZealot == true and IsRunePriestOrZealot(careerId) then
        return true
    end

    return false
end

function EA_Window_OpenParty.GetEnemyAltSpecSettingsSignature()
    local settings = EA_Window_OpenParty.GetEnemySettings()
    if not settings then
        return "none"
    end

    return (settings.unitFramesDisableAltSpecCheck == true and "1" or "0")..":"
        ..(settings.unitFramesDisableAltSpecCheckForRunePriestZealot == true and "1" or "0")
end

-- Returns AutoBand RR for a member name, or nil when AutoBand is unavailable
-- or has no fresh/cached RR for that member.
function EA_Window_OpenParty.GetAutoBandRenownRankForName(memberName)
    if not memberName then
        return nil
    end

    if not AutoBand or type(AutoBand.get_realm_rank_for_name) ~= "function" then
        return nil
    end

    local ok, rr = pcall(AutoBand.get_realm_rank_for_name, memberName)
    if not ok or rr == nil then
        return nil
    end

    rr = tonumber(rr)
    if rr == nil then
        return nil
    end

    rr = math.floor(rr)
    if rr < 0 then
        return nil
    end

    return rr
end

local function HasAutoBandRenownLookup()
    if not AutoBand or type(AutoBand.get_realm_rank_for_name) ~= "function" then
        return false
    end

    if type(AutoBand.is_realmrank_soft_disabled) == "function" then
        local ok, disabled = pcall(AutoBand.is_realmrank_soft_disabled)
        if not ok or disabled == true then
            return false
        end
    end

    local hasRows = false

    if type(AutoBand.has_realmrank_snapshot_rows) == "function" then
        local ok, result = pcall(AutoBand.has_realmrank_snapshot_rows)
        if ok then
            hasRows = result == true
        end
    elseif type(AutoBand.realmrank_lookup) == "table" then
        local rowCount = 0
        for _ in pairs(AutoBand.realmrank_lookup) do
            rowCount = rowCount + 1
        end
        hasRows = rowCount > 0
    end

    if not hasRows then
        return false
    end

    if type(AutoBand.is_realmrank_data_stale) == "function" then
        local ok, stale = pcall(AutoBand.is_realmrank_data_stale)
        if not ok or stale == true then
            return false
        end
    end

    return true
end

-- Normalize AutoBand rank values for display.
function EA_Window_OpenParty.GetAutoBandRankText(rank)
    if rank == nil then
        return L""
    end

    local numericRank = tonumber(rank)
    if numericRank ~= nil then
        numericRank = math.floor(numericRank)
        return towstring(numericRank)
    end

    return towstring(rank)
end

local function BuildTooltipRankText(level, memberName, useRenownLookup)
    if useRenownLookup ~= true then
        return L"("..GetString(StringTables.Default.LABEL_RANK)..L" "..level..L")"
    end

    local text = L"(CR"..EA_Window_OpenParty.GetAutoBandRankText(level)
    local rr = EA_Window_OpenParty.GetAutoBandRenownRankForName(memberName)
    if rr ~= nil then
        text = text..L", RR"..EA_Window_OpenParty.GetAutoBandRankText(rr)
    end
    return text..L")"
end

function EA_Window_OpenParty.UseTooltipRankAlignedLayout()
    return HasAutoBandRenownLookup()
end

local function TooltipWindowExists(windowName)
    if type(DoesWindowExist) ~= "function" then
        return true
    end

    return DoesWindowExist(windowName) == true
end

local function TooltipSetText(windowName, text)
    if TooltipWindowExists(windowName) and type(LabelSetText) == "function" then
        LabelSetText(windowName, text)
    end
end

local function TooltipSetShowing(windowName, showing)
    if TooltipWindowExists(windowName) and type(WindowSetShowing) == "function" then
        WindowSetShowing(windowName, showing)
    end
end

function EA_Window_OpenParty.GetTooltipRankAndNameLabelNames(memberWindowName, useAlignedRankLayout)
    local defaultRankText = memberWindowName.."RankText"
    local defaultNameText = memberWindowName.."NameText"
    local alignedRankText = memberWindowName.."RankTextAligned"
    local alignedNameText = memberWindowName.."NameTextAligned"

    if useAlignedRankLayout == true and TooltipWindowExists(alignedRankText) and TooltipWindowExists(alignedNameText) then
        return alignedRankText, alignedNameText
    end

    return defaultRankText, defaultNameText
end

function EA_Window_OpenParty.SetTooltipRankAndName(memberWindowName, level, memberName, useAlignedRankLayout)
    local defaultRankText = memberWindowName.."RankText"
    local defaultNameText = memberWindowName.."NameText"
    local alignedRankText = memberWindowName.."RankTextAligned"
    local alignedNameText = memberWindowName.."NameTextAligned"
    local activeRankText, activeNameText = EA_Window_OpenParty.GetTooltipRankAndNameLabelNames(memberWindowName, useAlignedRankLayout)
    local rankText = BuildTooltipRankText(level, memberName, useAlignedRankLayout == true)
    local nameText = memberName or L""

    if activeRankText == alignedRankText and activeNameText == alignedNameText then
        TooltipSetText(alignedRankText, rankText)
        TooltipSetText(alignedNameText, nameText)
        TooltipSetText(defaultRankText, L"")
        TooltipSetText(defaultNameText, L"")
        TooltipSetShowing(alignedRankText, true)
        TooltipSetShowing(alignedNameText, true)
        TooltipSetShowing(defaultRankText, false)
        TooltipSetShowing(defaultNameText, false)
    else
        TooltipSetText(defaultRankText, rankText)
        TooltipSetText(defaultNameText, nameText)
        TooltipSetText(alignedRankText, L"")
        TooltipSetText(alignedNameText, L"")
        TooltipSetShowing(defaultRankText, true)
        TooltipSetShowing(defaultNameText, true)
        TooltipSetShowing(alignedRankText, false)
        TooltipSetShowing(alignedNameText, false)
    end

    return activeRankText, activeNameText
end

-- Ensure we only surface alt-spec data for the warband the player is in;
-- this avoids cross-warband leakage.
local function DoesGroupContainPlayer(groupLeaderData)
    if not groupLeaderData or not GameData or not GameData.Player or not GameData.Player.name then
        return false
    end

    local playerName = GameData.Player.name
    local playerNameString = NormalizeNameKey(playerName)

    if groupLeaderData.leaderName and WStringsCompareIgnoreGrammer(groupLeaderData.leaderName, playerName) == 0 then
        return true
    end
    local leaderNameString = NormalizeNameKey(groupLeaderData.leaderName)
    if playerNameString and leaderNameString and playerNameString == leaderNameString then
        return true
    end

    local members = groupLeaderData.Group
    if not members then
        return false
    end

    for idx = 1, #members do
        local member = members[idx]
        if member and member.m_memberName and WStringsCompareIgnoreGrammer(member.m_memberName, playerName) == 0 then
            return true
        end
        local memberNameString = NormalizeNameKey(member and member.m_memberName)
        if playerNameString and memberNameString and playerNameString == memberNameString then
            return true
        end
    end

    return false
end

-- Lookup the role overlay icon id from RoRGroupScoreboard data (uses the same
-- ArchTypeIcons table defined in interface/default/ror_groupscoreboard/rorgroupscoreboard.lua).
local function TryGetScoreboardArchtypeIcon(memberName, playersData)
    local data = playersData
    if data == nil then
        data = RoRGroupScoreboard and RoRGroupScoreboard.playersDataRaw
    end
    if not data then
        return nil
    end

    local archtypeIcons = RoRGroupScoreboard.ArchTypeIcons

    for _, pdata in pairs(data) do
        local at = pdata and pdata.archtype
        local iconId = archtypeIcons and at and at > 0 and archtypeIcons[at]
        if iconId then
            -- Exact wstring compare first, mirroring scoreboard data storage.
            if memberName and pdata.name and WStringsCompareIgnoreGrammer and WStringsCompareIgnoreGrammer(pdata.name, memberName) == 0 then
                return iconId
            end

            -- Fallback to string-lowered compare if needed.
            local memberKeyLower = NormalizeNameKey(memberName)
            local pdataKeyLower = NormalizeNameKey(pdata.name)
            if memberKeyLower and pdataKeyLower and memberKeyLower == pdataKeyLower then
                return iconId
            end
        end
    end

    return nil
end

function EA_Window_OpenParty.GetScoreboardDataRaw()
    if RoRGroupScoreboard and RoRGroupScoreboard.playersDataRaw then
        return RoRGroupScoreboard.playersDataRaw
    end
    return nil
end

-- Resolve role for counts, honoring scoreboard archtype DPS overrides.
local function GetScoreboardAdjustedRole(memberName, careerId, playersData)
    if not careerId then
        return nil
    end

    local data = playersData
    if data == nil then
        data = RoRGroupScoreboard and RoRGroupScoreboard.playersDataRaw
    end

    if data then
        for _, pdata in pairs(data) do
            if pdata and pdata.archtype and pdata.archtype > 0 and pdata.name and memberName then
                if WStringsCompareIgnoreGrammer and WStringsCompareIgnoreGrammer(pdata.name, memberName) == 0 then
                    -- archtype > 0 => DPS; map healer/edge careers to mdps/rdps like scoreboard/tooltip.
                    if careerId == GameData.CareerLine.ZEALOT
                        or careerId == GameData.CareerLine.RUNE_PRIEST
                        or careerId == GameData.CareerLine.ARCHMAGE
                        or careerId == GameData.CareerLine.SHAMAN then
                        return EA_Window_OpenParty.RoleTypes.RDPS
                    elseif careerId == GameData.CareerLine.WARRIOR_PRIEST
                        or careerId == GameData.CareerLine.DISCIPLE
                        or careerId == GameData.CareerLine.SQUIG_HERDER
                        or careerId == GameData.CareerLine.SHADOW_WARRIOR then
                        return EA_Window_OpenParty.RoleTypes.MDPS
                    end
                end
            end
        end
    end

    return nil
end

-- Expose scoreboard archtype lookup without group gating (for manage tab lists).
function EA_Window_OpenParty.GetScoreboardArchtypeIcon(memberName)
    return TryGetScoreboardArchtypeIcon(memberName)
end

-- Returns the scoreboard-provided alt-spec overlay icon for a specific member
-- name inside the player's current warband tooltip. Only available when the
-- player is in the warband and the scoreboard shows an alt-spec shift.
function EA_Window_OpenParty.GetAltSpecIconForName(groupLeaderData, memberName)
    if not memberName then
        return nil
    end

    if not groupLeaderData or groupLeaderData.isWarband ~= true then
        return nil
    end

    -- Only surface alt-spec info for the warband the player is actually in.
    if not DoesGroupContainPlayer(groupLeaderData) then
        return nil
    end

    local iconId = TryGetScoreboardArchtypeIcon(memberName)
    if not iconId then
        return nil
    end

    return iconId
end

function EA_Window_OpenParty.GetGroupRoleCounts(groupLeaderData)
    local scoreboardData = EA_Window_OpenParty.GetScoreboardDataRaw()
    local allowScoreboard = false
    if groupLeaderData and groupLeaderData.isWarband == true and DoesGroupContainPlayer(groupLeaderData) then
        allowScoreboard = true
    end
    local counts = {
        tanks = 0,
        mdps = 0,
        rdps = 0,
        healers = 0,
    }
    local seenMembers = {}
    local seenMembersRaw = {}

    local function HasSeenMember(memberName)
        if not memberName then
            return false
        end

        local memberKey = NormalizeNameKey(memberName)
        if memberKey and seenMembers[memberKey] then
            return true
        end

        if WStringsCompareIgnoreGrammer and #seenMembersRaw > 0 then
            for idx = 1, #seenMembersRaw do
                if WStringsCompareIgnoreGrammer(seenMembersRaw[idx], memberName) == 0 then
                    return true
                end
            end
        end

        return false
    end

    local function MarkSeenMember(memberName)
        local memberKey = NormalizeNameKey(memberName)
        if memberKey then
            seenMembers[memberKey] = true
        end
        if WStringsCompareIgnoreGrammer then
            table.insert(seenMembersRaw, memberName)
        end
    end

    local function AddMember(member)
        if not member then
            return
        end

        local careerId = member.m_careerID or member.careerId or member.careerLine
        if not careerId or careerId == 0 then
            return
        end
        local memberName = member.m_memberName or member.name
        if not memberName then
            return
        end
        if HasSeenMember(memberName) then
            return
        end
        MarkSeenMember(memberName)

        local role = nil
        if allowScoreboard then
            role = GetScoreboardAdjustedRole(memberName, careerId, scoreboardData)
        end
        if not role then
            role = EA_Window_OpenParty.CareerRoles[careerId]
        end
        if role == EA_Window_OpenParty.RoleTypes.TANK then
            counts.tanks = counts.tanks + 1
        elseif role == EA_Window_OpenParty.RoleTypes.MDPS then
            counts.mdps = counts.mdps + 1
        elseif role == EA_Window_OpenParty.RoleTypes.RDPS then
            counts.rdps = counts.rdps + 1
        elseif role == EA_Window_OpenParty.RoleTypes.HEALER then
            counts.healers = counts.healers + 1
        end
    end

    if groupLeaderData then
        if groupLeaderData.leaderCareer then
            AddMember({ m_memberName = groupLeaderData.leaderName, m_careerID = groupLeaderData.leaderCareer })
        end
        local groupMembers = groupLeaderData.Group
        if groupMembers and #groupMembers > 0 then
            for idx = 1, #groupMembers do
                AddMember(groupMembers[idx])
            end
        end
    end

    counts.dds = counts.mdps + counts.rdps

    return counts
end

local function BuildScoreboardAltSpecSignature()
    local data = EA_Window_OpenParty.GetScoreboardDataRaw and EA_Window_OpenParty.GetScoreboardDataRaw()
    if not data then
        return nil
    end

    local sigParts = {}

    local archtypeIcons = RoRGroupScoreboard and RoRGroupScoreboard.ArchTypeIcons

    for _, pdata in pairs(data) do
        if pdata and pdata.name then
            local key = NormalizeNameKey(pdata.name)
            if key then
                local at = tonumber(pdata.archtype) or 0
                local iconId = 0
                if archtypeIcons and at > 0 and archtypeIcons[at] then
                    iconId = archtypeIcons[at]
                end
                sigParts[#sigParts + 1] = key..":"..tostring(at)..":"..tostring(iconId)
            end
        end
    end

    if #sigParts == 0 then
        return nil
    end

    table.sort(sigParts)
    return table.concat(sigParts, ",")
end

local function RefreshManageTab()
    if not WindowGetShowing(PARENT_WINDOW) then
        return
    end

    if not EA_Window_OpenParty.IsTabSelected(EA_Window_OpenParty.TAB_MANAGE) then
        return
    end

    EA_Window_OpenPartyManage.UpdateWarband()
end

local function FormatDpsText(mdps, rdps)
    local total = mdps + rdps
    if mdps > 0 and rdps > 0 then
        return towstring(total)..L" (M"..towstring(mdps)..L"/R"..towstring(rdps)..L")"
    elseif mdps > 0 then
        return L"M"..towstring(mdps)
    elseif rdps > 0 then
        return L"R"..towstring(rdps)
    end
    return towstring(total)
end

function EA_Window_OpenParty.BuildRoleSummaryText(roleCounts)
    if not roleCounts then
        return L""
    end

    return L"Tanks: "..towstring(roleCounts.tanks or 0)
        ..L" Healers: "..towstring(roleCounts.healers or 0)
        ..L" DPS: "..FormatDpsText(roleCounts.mdps or 0, roleCounts.rdps or 0)
end

local function PrintScenarioError()
    if EA_ChatWindow
    then
        local errorMsg = GetStringFromTable( "Default", StringTables.Default.TEXT_FEATURE_NOT_AVAILABLE_IN_SCENARIO )
        EA_ChatWindow.Print( errorMsg, SystemData.ChatLogFilters.USER_ERROR )
    end
end

local function ChooseAvailableTab()
    -- use nearby as default unless disabled, then use first allowed
    if ButtonGetDisabledFlag( PARENT_WINDOW..EA_Window_OpenParty.TabData[EA_Window_OpenParty.TAB_NEARBY].tabName )
    then
        return TabsAllowedWithinScenario[1]
    else
        return EA_Window_OpenParty.TAB_NEARBY
    end
end

function EA_Window_OpenParty.Initialize()
    -- Title Bar
    LabelSetText( PARENT_WINDOW.."TitleBarText", GetStringFromTable("SocialStrings", StringTables.Social.LABEL_SOCIAL_OPENPARTY_TITLE) )

    -- Tabs
    ButtonSetText( PARENT_WINDOW.."TabNearby", GetStringFromTable("SocialStrings", StringTables.Social.TAB_LABEL_NEARBY) )
    ButtonSetText( PARENT_WINDOW.."TabWorld", GetStringFromTable("SocialStrings", StringTables.Social.TAB_LABEL_WORLD) )
    ButtonSetText( PARENT_WINDOW.."TabLootRollOptions", GetStringFromTable("SocialStrings", StringTables.Social.TAB_LABEL_LOOT_ROLL_OPTIONS) )
    ButtonSetText( PARENT_WINDOW.."TabManage", GetStringFromTable("SocialStrings", StringTables.Social.TAB_LABEL_MANAGE) )

    -- Event Handlers
    WindowRegisterEventHandler( FLY_OUT_WINDOW, SystemData.Events.SOCIAL_OPENPARTY_NOTIFY,  "EA_Window_OpenParty.OnOpenPartyNotification" )
    WindowRegisterEventHandler( PARENT_WINDOW, SystemData.Events.TOGGLE_BATTLEGROUP_WINDOW, "EA_Window_OpenParty.ToggleManageShowing" )
    WindowRegisterEventHandler( PARENT_WINDOW, SystemData.Events.SCENARIO_BEGIN,            "EA_Window_OpenParty.OnScenarioBegin" )
    WindowRegisterEventHandler( PARENT_WINDOW, SystemData.Events.CITY_SCENARIO_BEGIN,       "EA_Window_OpenParty.OnScenarioBegin" )
    WindowRegisterEventHandler( PARENT_WINDOW, SystemData.Events.SCENARIO_END,              "EA_Window_OpenParty.OnScenarioEnd" )
    WindowRegisterEventHandler( PARENT_WINDOW, SystemData.Events.CITY_SCENARIO_END,         "EA_Window_OpenParty.OnScenarioEnd" )
    WindowRegisterEventHandler( PARENT_WINDOW, SystemData.Events.BATTLEGROUP_UPDATED,       "EA_Window_OpenParty.UpdateManageTabDisable" )
    WindowRegisterEventHandler( PARENT_WINDOW, SystemData.Events.GROUP_UPDATED,             "EA_Window_OpenParty.UpdateManageTabDisable" )
    WindowRegisterEventHandler( PARENT_WINDOW, SystemData.Events.OPEN_LFM_WINDOW,           "EA_Window_OpenParty.OpenToWorldTab" )

    -- Hide the flyout window
    WindowSetShowing( FLY_OUT_WINDOW, false )
    -- Register flyout's anchor with the layout editor
    LayoutEditor.RegisterWindow( FLY_OUT_WINDOW.."Anchor",
                            GetStringFromTable( "HUDStrings", StringTables.HUD.LABEL_HUD_OP_NOTIFICATION_FLYOUT_NAME ),
                            GetStringFromTable( "HUDStrings", StringTables.HUD.LABEL_HUD_OP_NOTIFICATION_FLYOUT_DESC ),
                            false, false,
                            true, nil )

    -- Initialize child tab windows
    EA_Window_OpenPartyNearby.Initialize()
    EA_Window_OpenPartyWorld.Initialize()
    EA_Window_OpenPartyLootRollOptions.Initialize()
    EA_Window_OpenPartyManage.Initialize()

    -- Init tooltip windows
    CreateWindow( "EA_Tooltip_OpenParty", false )
    CreateWindow( "EA_Tooltip_OpenPartyWorld", false )

    for tabId, tabData in pairs( EA_Window_OpenParty.TabData )
    do
        if tabData.scenarioAllow
        then
            table.insert( TabsAllowedWithinScenario, tabId )
        end
    end

    EA_Window_OpenParty.SelectTab( EA_Window_OpenParty.TAB_NEARBY )
    EA_Window_OpenParty.UpdateInScenarioTabDisable()
end

function EA_Window_OpenParty.OnScenarioBegin()
    WindowSetShowing( PARENT_WINDOW, false )
    EA_Window_OpenParty.UpdateInScenarioTabDisable()
end

function EA_Window_OpenParty.OnScenarioEnd()
    EA_Window_OpenParty.UpdateInScenarioTabDisable()
end

-- TAB FUNCTIONS
function EA_Window_OpenParty.OnClickTab()
    local tabId = WindowGetId( SystemData.ActiveWindow.name )
    EA_Window_OpenParty.SelectTab( tabId )
end

function EA_Window_OpenParty.SelectTab( tab )
    if( EA_Window_OpenParty.TabData[tab] == nil )
    then
        tab = ChooseAvailableTab()
    end

    -- Don't switch tabs if it's disabled
    if( ButtonGetDisabledFlag( PARENT_WINDOW..EA_Window_OpenParty.TabData[tab].tabName ) )
    then
        return
    end

    for tabId, tabData in pairs( EA_Window_OpenParty.TabData )
    do
        local activeTab = (tabId == tab)
        WindowSetShowing( PARENT_WINDOW..tabData.windowName, activeTab )
        ButtonSetPressedFlag( PARENT_WINDOW..tabData.tabName, activeTab )
    end
end

function EA_Window_OpenParty.IsTabSelected( tab )
    if( EA_Window_OpenParty.TabData[tab] == nil )
    then
        return false
    end
    local windowName = EA_Window_OpenParty.TabData[tab].windowName
    return WindowGetShowing( PARENT_WINDOW..windowName )
end

local manageDisableDelay = 0
-- Handles the delayed Manage-tab disable workaround and Manage-tab data polling.
function EA_Window_OpenParty.OnUpdate( timePassed )
    if( manageDisableDelay > 0 )
    then
        manageDisableDelay = manageDisableDelay - timePassed
        if( manageDisableDelay <= 0 )
        then
            if( EA_Window_OpenParty.IsTabSelected( EA_Window_OpenParty.TAB_MANAGE ) )
            then
                EA_Window_OpenParty.SelectTab( ChooseAvailableTab() )
            end
            ButtonSetDisabledFlag( PARENT_WINDOW..EA_Window_OpenParty.TabData[EA_Window_OpenParty.TAB_MANAGE].tabName, true )
        end
    end

    scoreboardPollTimer = scoreboardPollTimer - timePassed
    if not (WindowGetShowing(PARENT_WINDOW) and EA_Window_OpenParty.IsTabSelected(EA_Window_OpenParty.TAB_MANAGE)) then
        return
    end

    if scoreboardPollTimer <= 0 then
        scoreboardPollTimer = SCOREBOARD_POLL_INTERVAL
        local refreshManage = false

        local sig = BuildScoreboardAltSpecSignature()
        if sig ~= scoreboardAltSpecSignature then
            scoreboardAltSpecSignature = sig
            refreshManage = true
        end

        if EA_Window_OpenPartyManage
            and EA_Window_OpenPartyManage.HasEnemySortChanged
            and EA_Window_OpenPartyManage.HasEnemySortChanged()
        then
            refreshManage = true
        end

        if refreshManage then
            RefreshManageTab()
        end
    end
end

function EA_Window_OpenParty.DisableTab( tab )

    -- Moving between warband groups can briefly look like leaving the group,
    -- so delay Manage-tab disable long enough for the re-add to arrive.
    if( tab == EA_Window_OpenParty.TAB_MANAGE )
    then
        manageDisableDelay = 2
        return
    end


    -- if the tab we're disabling is currently selected, switch to something else
    if( EA_Window_OpenParty.IsTabSelected( tab ) )
    then
        EA_Window_OpenParty.SelectTab( ChooseAvailableTab() )
    end

    ButtonSetDisabledFlag( PARENT_WINDOW..EA_Window_OpenParty.TabData[tab].tabName, true )
end

function EA_Window_OpenParty.EnableTab( tab )
    if( tab == EA_Window_OpenParty.TAB_MANAGE )
    then
        manageDisableDelay = 0
    end

    ButtonSetDisabledFlag( PARENT_WINDOW..EA_Window_OpenParty.TabData[tab].tabName, false )
end

function EA_Window_OpenParty.OpenToWorldTab()
    if ( GameData.Player.isInScenario or GameData.Player.isInSiege )
    then
        PrintScenarioError()
        return
    end
    EA_Window_OpenParty.SelectTab( EA_Window_OpenParty.TAB_WORLD )
    WindowSetShowing( PARENT_WINDOW, true )
end

function EA_Window_OpenParty.OpenToManageTab()
    if ( GameData.Player.isInScenario or GameData.Player.isInSiege )
    then
        PrintScenarioError()
        return
    end
    EA_Window_OpenParty.SelectTab( EA_Window_OpenParty.TAB_MANAGE )
    WindowSetShowing( PARENT_WINDOW, true )
end

function EA_Window_OpenParty.ToggleManageShowing()
    if( ButtonGetDisabledFlag( PARENT_WINDOW..EA_Window_OpenParty.TabData[EA_Window_OpenParty.TAB_MANAGE].tabName ) )
    then
        return
    end

    local openPartyWindowShowing = WindowGetShowing( PARENT_WINDOW )
    local manageTabSelected = EA_Window_OpenParty.IsTabSelected( EA_Window_OpenParty.TAB_MANAGE )

    if( openPartyWindowShowing and manageTabSelected )
    then
        EA_Window_OpenParty.ToggleFullWindow()
    else
        EA_Window_OpenParty.OpenToManageTab()
    end
end

function EA_Window_OpenParty.ToggleFullWindow()
    WindowSetShowing( PARENT_WINDOW, not WindowGetShowing( PARENT_WINDOW ) )
end

function EA_Window_OpenParty.OnShown()
    WindowUtils.OnShown()

    -- make sure we don't open to a disabled tab
    for tabId, tabData in pairs( EA_Window_OpenParty.TabData )
    do
        if EA_Window_OpenParty.IsTabSelected( tabId )
        then
            if ButtonGetDisabledFlag( PARENT_WINDOW..tabData.tabName )
            then
                EA_Window_OpenParty.SelectTab( ChooseAvailableTab() )
            end
            break
        end
    end
end

function EA_Window_OpenParty.OnHidden()
    WindowUtils.OnHidden()
end


function EA_Window_OpenParty.UpdateManageTabDisable()
    if( IsWarBandActive() or PartyUtils.IsPartyActive() )
    then
        if( GameData.Player.isInScenario or GameData.Player.isInSiege )
        then
            EA_Window_OpenParty.DisableTab( EA_Window_OpenParty.TAB_MANAGE )
            return
        end
        EA_Window_OpenParty.EnableTab( EA_Window_OpenParty.TAB_MANAGE )

    else
        EA_Window_OpenParty.DisableTab( EA_Window_OpenParty.TAB_MANAGE )
    end
end

function EA_Window_OpenParty.UpdateInScenarioTabDisable()
    for tabId, tabData in pairs( EA_Window_OpenParty.TabData )
    do
        if  (GameData.Player.isInScenario or GameData.Player.isInSiege)
            and not tabData.scenarioAllow
        then
            EA_Window_OpenParty.DisableTab( tabId )
        else
            EA_Window_OpenParty.EnableTab( tabId )
        end
    end
    EA_Window_OpenParty.UpdateManageTabDisable()
end



function EA_Window_OpenParty.GetLocationTypeColor( locationIdx )
    if( EA_Window_OpenParty.InterestTypeColors[locationIdx] == nil )
    then
        -- Default to PVE
        locationIdx = GameData.OpenPartyInterest.PVE
    end
    return EA_Window_OpenParty.InterestTypeColors[locationIdx]
end

function EA_Window_OpenParty.GetLocationTypeName( locationIdx )
    if( EA_Window_OpenParty.InterestTypes[locationIdx] == nil )
    then
        -- Default to PVE
        locationIdx = GameData.OpenPartyInterest.PVE
    end
    return EA_Window_OpenParty.InterestTypes[locationIdx]
end

function EA_Window_OpenParty.OnUpdateForFlyOut( timePassed )
    if( EA_Window_OpenParty.fadeOutDelay > 0 )
    then
        EA_Window_OpenParty.fadeOutDelay = EA_Window_OpenParty.fadeOutDelay - timePassed
        if( EA_Window_OpenParty.fadeOutDelay < 0 )
        then
            EA_Window_OpenParty.FadeOutFlyoutWindow()
            EA_Window_OpenParty.fadeOutDelay = 0
        end
    end
end

function EA_Window_OpenParty.OnMouseOverSearchButton()
    if( WindowGetShowing( PARENT_WINDOW ) == true )
    then
        Tooltips.CreateTextOnlyTooltip( SystemData.MouseOverWindow.name, GetStringFromTable("SocialStrings", StringTables.Social.TEXT_SOCIAL_SEARCHBUTTON_HIDE) )
    else
        Tooltips.CreateTextOnlyTooltip( SystemData.MouseOverWindow.name, GetStringFromTable("SocialStrings", StringTables.Social.TEXT_SOCIAL_SEARCHBUTTON) )
    end
    Tooltips.AnchorTooltip( Tooltips.ANCHOR_WINDOW_TOP )
end

function EA_Window_OpenParty.FadeOutFlyoutWindow()
    WindowStartAlphaAnimation( FLY_OUT_WINDOW, Window.AnimationType.SINGLE_NO_RESET, 1.0, 0.0, 1.0, false, 0, 0 )
end

-- Get the list of available parties in this area.  This function is called when the user enters the area where
-- Open Parties exist.
function EA_Window_OpenParty.OnOpenPartyNotification()

    local openPartyAvailable = GetOpenPartyNotificationList()
    local x,y, width, height

    -- If there's nothing in the list, tell the user nothing was found
    if( #openPartyAvailable <= 0  )
    then
        LabelSetText( FLY_OUT_WINDOW.."Header", GetStringFromTable( "SocialStrings", StringTables.Social.LABEL_SOCIAL_HEADER_NOOPENPARTY ) )
        x, y = WindowGetOffsetFromParent( FLY_OUT_WINDOW.."Header" )
        width, height = WindowGetDimensions( FLY_OUT_WINDOW.."Header" )
        width = width + x + TOOLTIP_BORDER_OFFSET
        height = height + y + TOOLTIP_BORDER_OFFSET
        WindowSetDimensions( FLY_OUT_WINDOW, width, height )

        for idx=1, TOTAL_NUM_NOTIFY_MEMBERS
        do
            WindowSetShowing( FLY_OUT_WINDOW.."Leader"..idx.."Text", false )
            WindowSetShowing( FLY_OUT_WINDOW.."Leader"..idx.."RatioText", false )
        end

    else
        LabelSetText( FLY_OUT_WINDOW.."Header", GetStringFromTable( "SocialStrings", StringTables.Social.LABEL_SOCIAL_HEADER_OPENPARTY ) )
        x, y = WindowGetOffsetFromParent( FLY_OUT_WINDOW.."Header" )
        width, height = WindowGetDimensions( FLY_OUT_WINDOW.."Header" )
        width = width + x
        height = y + height

        -- Loop over all possible entries
        for index, partyData in ipairs( openPartyAvailable )
        do
            -- Only show a few
            if( index > TOTAL_NUM_NOTIFY_MEMBERS )
            then
                break
            end

            LabelSetText( FLY_OUT_WINDOW.."Leader"..index.."Text", partyData.leaderName )

            local maxGroupMembers = EA_Window_OpenParty.TOTAL_NUM_GROUP_MEMBERS
            local color = EA_Window_OpenParty.PartyTextColor
            if( partyData.isWarband )
            then
                maxGroupMembers = EA_Window_OpenParty.TOTAL_NUM_WARBAND_MEMBERS
                color = EA_Window_OpenParty.WarbandTextColor
            end
            LabelSetTextColor( FLY_OUT_WINDOW.."Leader"..index.."Text", color.r, color.b, color.g )
            LabelSetText( FLY_OUT_WINDOW.."Leader"..index.."RatioText", L"("..partyData.numGroupMembers..L"/"..maxGroupMembers..L")" )
            LabelSetTextColor( FLY_OUT_WINDOW.."Leader"..index.."RatioText", EA_Window_OpenParty.PartyTextColor.r, EA_Window_OpenParty.PartyTextColor.g, EA_Window_OpenParty.PartyTextColor.b )

            WindowSetShowing( FLY_OUT_WINDOW.."Leader"..index.."Text", true )
            WindowSetShowing( FLY_OUT_WINDOW.."Leader"..index.."RatioText", true )

            local ratioX, _ = WindowGetOffsetFromParent( FLY_OUT_WINDOW.."Leader"..index.."RatioText" )
            local _, _, _, _, leaderYOffset = WindowGetAnchor( FLY_OUT_WINDOW.."Leader"..index.."Text", 1 )
            local sizeX, sizeY = WindowGetDimensions( FLY_OUT_WINDOW.."Leader"..index.."RatioText" )
            width = math.max( width, ratioX + sizeX )
            height = height + sizeY + leaderYOffset
        end

        height = height + TOOLTIP_BORDER_OFFSET
        width = width + TOOLTIP_BORDER_OFFSET
        WindowSetDimensions( FLY_OUT_WINDOW, width, height )


        -- Hide any listings we're not using
        for idx=#openPartyAvailable+1, TOTAL_NUM_NOTIFY_MEMBERS do
            WindowSetShowing( FLY_OUT_WINDOW.."Leader"..idx.."Text", false )
            WindowSetShowing( FLY_OUT_WINDOW.."Leader"..idx.."RatioText", false )
        end

    end

    WindowSetShowing( FLY_OUT_WINDOW, true )
    WindowStartAlphaAnimation ( FLY_OUT_WINDOW, Window.AnimationType.SINGLE_NO_RESET, 0.0, 1.0, 0.5, false, 0, 0 )
    EA_Window_OpenParty.fadeOutDelay = FADE_OUT_DELAY
end
