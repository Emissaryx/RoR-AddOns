
EA_Window_OpenPartyManage = {}
EA_Window_OpenPartyManage.warbandParties = {} -- only used to populate list boxes (ListBox needs a global table)
EA_Window_OpenPartyManage.sortByRole = true

local PARENT_WINDOW = "EA_Window_OpenPartyManage"
local WARBAND_HEADER_TEXT = L"WB Members"
local draggedWindow = nil
local displayedMemberIndices = {}
local ROLE_TANK = "tank"
local ROLE_HEALER = "healer"
local ROLE_MDPS = "mdps"
local ROLE_RDPS = "rdps"

local function ShouldIgnoreEnemyAltSpecForMember(member, useEnemyAltSpecRules)
    if useEnemyAltSpecRules ~= true then
        return false
    end

    if not member or not EA_Window_OpenParty.ShouldEnemyIgnoreAltSpecForCareer then
        return false
    end

    return EA_Window_OpenParty.ShouldEnemyIgnoreAltSpecForCareer(member.careerLine)
end

-- Resolve member role with scoreboard alt-spec overrides (mdps/rdps) to mirror tooltip behavior.
local function GetMemberRole(member, scoreboardData, useEnemyAltSpecRules)
    if not member or not member.careerLine then
        return nil
    end

    local role = EA_Window_OpenParty.CareerRoles[member.careerLine]
    if ShouldIgnoreEnemyAltSpecForMember(member, useEnemyAltSpecRules) then
        return role
    end

    local data = scoreboardData
    if data == nil and RoRGroupScoreboard and RoRGroupScoreboard.playersDataRaw then
        data = RoRGroupScoreboard.playersDataRaw
    end

    if data and WStringsCompareIgnoreGrammer then
        for _, pdata in pairs(data) do
            if pdata and pdata.archtype and pdata.archtype > 0 and pdata.name and member.name then
                if WStringsCompareIgnoreGrammer(pdata.name, member.name) == 0 then
                    -- Archtype > 0 means DPS alt-spec; map healer/edge careers to mdps/rdps like tooltip.
                    if member.careerLine == GameData.CareerLine.ZEALOT
                        or member.careerLine == GameData.CareerLine.RUNE_PRIEST
                        or member.careerLine == GameData.CareerLine.ARCHMAGE
                        or member.careerLine == GameData.CareerLine.SHAMAN then
                        role = EA_Window_OpenParty.RoleTypes.RDPS
                    elseif member.careerLine == GameData.CareerLine.WARRIOR_PRIEST
                        or member.careerLine == GameData.CareerLine.DISCIPLE
                        or member.careerLine == GameData.CareerLine.SQUIG_HERDER
                        or member.careerLine == GameData.CareerLine.SHADOW_WARRIOR then
                        role = EA_Window_OpenParty.RoleTypes.MDPS
                    end
                    break
                end
            end
        end
    end

    return role
end

local function FormatDpsSegment(mdps, rdps)
    local total = mdps + rdps
    if mdps > 0 and rdps > 0 then
        return towstring(total)..L"(M"..towstring(mdps)..L"/R"..towstring(rdps)..L")"
    elseif mdps > 0 then
        return L"M"..towstring(mdps)
    elseif rdps > 0 then
        return L"R"..towstring(rdps)
    end
    return towstring(total)
end

local function FormatRoleCount(count, singular, plural)
    if count == 1 then
        return towstring(count)..L" "..singular
    end

    return towstring(count)..L" "..plural
end

local function FormatDpsRoleSegment(mdps, rdps)
    local total = mdps + rdps
    if mdps > 0 and rdps > 0 then
        return towstring(total)..L" DPS (M"..towstring(mdps)..L"/R"..towstring(rdps)..L")"
    elseif mdps > 0 then
        return towstring(total)..L" DPS (M"..towstring(mdps)..L")"
    elseif rdps > 0 then
        return towstring(total)..L" DPS (R"..towstring(rdps)..L")"
    end

    return towstring(total)..L" DPS"
end

local DEFAULT_ROLE_SORT_RANKS = {
    [ROLE_TANK] = 10,
    [ROLE_HEALER] = 20,
    [ROLE_MDPS] = 30,
    [ROLE_RDPS] = 31,
    unknown = 50,
}
local enemySortCache = {}
local enemySortSignature = nil

local function BuildEnemyRoleSortRanks()
    if type(Enemy) ~= "table" then
        return nil
    end

    local settings = Enemy.Settings
    if EA_Window_OpenParty.GetEnemySettings then
        settings = EA_Window_OpenParty.GetEnemySettings()
    end
    if type(settings) ~= "table" then
        return nil
    end

    if settings.unitFramesEnabled ~= true or settings.unitFramesSortingEnabled ~= true then
        return nil
    end

    local sorting = settings.unitFramesSorting
    if type(sorting) ~= "table" then
        return nil
    end

    local sort1 = sorting[1]
    local sort2 = sorting[2]
    local sort3 = sorting[3]

    if enemySortCache.settings == settings
        and enemySortCache.sort1 == sort1
        and enemySortCache.sort2 == sort2
        and enemySortCache.sort3 == sort3
    then
        return enemySortCache.ranks
    end

    local enemyArchetypes = Enemy.Archetypes
    if type(enemyArchetypes) ~= "table" then
        enemyArchetypes = {}
    end

    local tankArchetype = enemyArchetypes.Tank or 1
    local dpsArchetype = enemyArchetypes.Dps or 2
    local healerArchetype = enemyArchetypes.Healer or 3
    local ranks = { unknown = DEFAULT_ROLE_SORT_RANKS.unknown }
    local seen = {}

    local function AddRank(archetype, index)
        if archetype == nil then
            return false
        end

        if seen[archetype] then
            return false
        end
        seen[archetype] = true

        local baseRank = index * 10
        if archetype == tankArchetype then
            ranks[ROLE_TANK] = baseRank
        elseif archetype == healerArchetype then
            ranks[ROLE_HEALER] = baseRank
        elseif archetype == dpsArchetype then
            ranks[ROLE_MDPS] = baseRank
            ranks[ROLE_RDPS] = baseRank + 1
        else
            return false
        end

        return true
    end

    if not AddRank(sort1, 1) or not AddRank(sort2, 2) or not AddRank(sort3, 3)
        or ranks[ROLE_TANK] == nil
        or ranks[ROLE_HEALER] == nil
        or ranks[ROLE_MDPS] == nil
        or ranks[ROLE_RDPS] == nil
    then
        ranks = nil
    end

    enemySortCache.settings = settings
    enemySortCache.sort1 = sort1
    enemySortCache.sort2 = sort2
    enemySortCache.sort3 = sort3
    enemySortCache.ranks = ranks

    return ranks
end

local function ShouldUseEnemyAltSpecRules()
    return EA_Window_OpenPartyManage.sortByRole == true and BuildEnemyRoleSortRanks() ~= nil
end

local function BuildEnemySortSignature()
    if not EA_Window_OpenPartyManage.sortByRole then
        return nil
    end

    local ranks = BuildEnemyRoleSortRanks()
    if not ranks then
        return nil
    end

    return tostring(ranks[ROLE_TANK])..":"
        ..tostring(ranks[ROLE_HEALER])..":"
        ..tostring(ranks[ROLE_MDPS])..":"
        ..tostring(ranks[ROLE_RDPS])..":"
        ..(EA_Window_OpenParty.GetEnemyAltSpecSettingsSignature and EA_Window_OpenParty.GetEnemyAltSpecSettingsSignature() or "none")
end

local function GetActiveRoleSortRanks()
    if EA_Window_OpenPartyManage.sortByRole then
        local enemyRanks = BuildEnemyRoleSortRanks()
        if enemyRanks then
            return enemyRanks
        end
    end

    return DEFAULT_ROLE_SORT_RANKS
end

local function GetRoleSortRank(role, roleSortRanks)
    return roleSortRanks[role] or roleSortRanks.unknown
end

local function GetMemberSortName(member)
    if not member or not member.name then
        return ""
    end

    if type(member.name) ~= "string" and WStringToString then
        return WStringToString(member.name)
    end

    return tostring(member.name)
end

local function BuildRoleSortOrderText(roleSortRanks)
    local sortOrder = {
        { rank = roleSortRanks[ROLE_TANK], label = L"tanks", index = 1 },
        { rank = roleSortRanks[ROLE_HEALER], label = L"healers", index = 2 },
        { rank = roleSortRanks[ROLE_MDPS], label = L"melee DPS", index = 3 },
        { rank = roleSortRanks[ROLE_RDPS], label = L"ranged DPS", index = 4 },
    }

    table.sort(sortOrder, function(left, right)
        if left.rank == right.rank then
            return left.index < right.index
        end

        return left.rank < right.rank
    end)

    local text = sortOrder[1].label
    for index = 2, table.getn(sortOrder)
    do
        text = text..L", "..sortOrder[index].label
    end

    return text
end

local function BuildSortTooltipOrderText()
    local enemyRanks = BuildEnemyRoleSortRanks()
    if enemyRanks then
        return L"Order picked up from your Enemy settings: "..BuildRoleSortOrderText(enemyRanks)
    end

    return L"Order: "..BuildRoleSortOrderText(DEFAULT_ROLE_SORT_RANKS)
end

local function BuildRoleSummarySegments(tanks, mdps, rdps, healers)
    local ranks = GetActiveRoleSortRanks()
    local segments = {
        {
            rank = ranks[ROLE_TANK],
            index = 1,
            text = towstring(tanks),
            labeledText = FormatRoleCount(tanks, L"Tank", L"Tanks"),
        },
        {
            rank = ranks[ROLE_HEALER],
            index = 2,
            text = towstring(healers),
            labeledText = FormatRoleCount(healers, L"Healer", L"Healers"),
        },
        {
            rank = ranks[ROLE_MDPS],
            index = 3,
            text = FormatDpsSegment(mdps, rdps),
            labeledText = FormatDpsRoleSegment(mdps, rdps),
        },
    }

    table.sort(segments, function(left, right)
        if left.rank == right.rank then
            return left.index < right.index
        end

        return left.rank < right.rank
    end)

    return segments
end

local function BuildCompactRoleSummaryText(tanks, mdps, rdps, healers)
    local segments = BuildRoleSummarySegments(tanks, mdps, rdps, healers)
    local text = segments[1].text
    for index = 2, table.getn(segments)
    do
        text = text..L"-"..segments[index].text
    end

    return text
end

local function BuildLabeledRoleSummaryText(tanks, mdps, rdps, healers)
    local segments = BuildRoleSummarySegments(tanks, mdps, rdps, healers)
    local text = segments[1].labeledText
    for index = 2, table.getn(segments)
    do
        text = text..L" - "..segments[index].labeledText
    end

    return text
end

local function BuildManageRankText(member)
    if not member or member.level == nil then
        return L""
    end

    local rankText = towstring(member.level)
    if EA_Window_OpenParty.GetAutoBandRankText then
        rankText = EA_Window_OpenParty.GetAutoBandRankText(member.level)
    end

    if EA_Window_OpenParty.GetAutoBandRenownRankForName then
        local rr = EA_Window_OpenParty.GetAutoBandRenownRankForName(member.name)
        if rr ~= nil then
            local rrText = towstring(rr)
            if EA_Window_OpenParty.GetAutoBandRankText then
                rrText = EA_Window_OpenParty.GetAutoBandRankText(rr)
            end
            return rankText..L"/"..rrText..L" "
        end
    end

    return rankText
end

--
-- RowId conversion functions.
--
-- RowIds are a unique identifier for each row,
-- e.g. group 1 is 1 thru 6, group 2 is 7 thru 12...
--

local function GetRowId( partyIndex, rowIndex )
    return ((partyIndex - 1) * 6) + rowIndex
end

local function GetPartyByRowId( rowId )
    return math.ceil( rowId / 6 )
end

local function GetRowIndexByRowId( rowId )
    return math.mod( rowId + 5, 6 ) + 1
end

local function GetPartyWindowName( partyIndex )
    return PARENT_WINDOW.."Warband"..partyIndex
end

local function GetRowWindowName( partyIndex, rowIndex )
    local partyWindow = GetPartyWindowName( partyIndex )
    return partyWindow.."ListRow"..rowIndex
end

--
-- Misc window name functions
--

local function GetPartyIndexByWindowName( window )
    if( window == nil )
    then
        return 0
    end

    for partyIndex = 1, PartyUtils.PARTIES_PER_WARBAND do
        -- Compare substrings to take non-parent windows into account
        -- NOTE: This won't work if we ever put more than 9 groups in the window, which is very unlikely but who knows!
        local partyWindow = GetPartyWindowName( partyIndex )
        local partyWindowNameLen = string.len( partyWindow )
        if ( string.len(window) >= partyWindowNameLen and string.sub(window, 1, partyWindowNameLen) == partyWindow ) then
            return partyIndex
        end
    end
    return 0
end

local function GetDisplayedRowIndex( partyIndex, memberIndex )
    local displayRows = displayedMemberIndices[partyIndex]
    if( displayRows )
    then
        for rowIndex, dataIndex in ipairs( displayRows )
        do
            if( dataIndex == memberIndex )
            then
                return rowIndex
            end
        end
    end

    return memberIndex
end

local function GetRowIdByWindowName( window )
    local partyIndex = GetPartyIndexByWindowName( window )
    if ( partyIndex == 0 ) then
        return 0
    end
    for rowIndex = 1, PartyUtils.PLAYERS_PER_PARTY do
        -- Compare substrings to take non-parent windows into account
        local rowWindowName = GetRowWindowName( partyIndex, rowIndex )
        local rowWindowNameLen = string.len( rowWindowName )
        if ( string.len(window) >= rowWindowNameLen and string.sub(window, 1, rowWindowNameLen) == rowWindowName ) then
            local displayRows = displayedMemberIndices[partyIndex]
            local dataIndex = rowIndex
            if( displayRows and displayRows[rowIndex] )
            then
                dataIndex = displayRows[rowIndex]
            end
            return GetRowId( partyIndex, dataIndex )
        end
    end
    return 0
end

local function GetRowIdFromWindow( window )
    if( window == nil )
    then
        return 0
    end

    local rowId = GetRowIdByWindowName( window )
    if( rowId == 0 and WindowGetId )
    then
        rowId = WindowGetId( window )
    end

    if( rowId == nil )
    then
        return 0
    end

    return rowId
end

--------------------------------------------------------------------------------
-- GLOBAL FUNCTIONS
--------------------------------------------------------------------------------

function EA_Window_OpenPartyManage.Initialize()
    RegisterEventHandler( SystemData.Events.L_BUTTON_UP_PROCESSED, "EA_Window_OpenPartyManage.OnLButtonUpProcessed" )

    WindowRegisterEventHandler( PARENT_WINDOW, SystemData.Events.BATTLEGROUP_UPDATED,       "EA_Window_OpenPartyManage.UpdateWarband" )
    WindowRegisterEventHandler( PARENT_WINDOW, SystemData.Events.GROUP_UPDATED,             "EA_Window_OpenPartyManage.UpdateParty" )
    WindowRegisterEventHandler( PARENT_WINDOW, SystemData.Events.GROUP_SETTINGS_UPDATED,    "EA_Window_OpenPartyManage.UpdateSettings" )
    WindowRegisterEventHandler( PARENT_WINDOW, SystemData.Events.BATTLEGROUP_MEMBER_UPDATED,"EA_Window_OpenPartyManage.SingleMemberUpdate" )
    WindowRegisterEventHandler( PARENT_WINDOW, SystemData.Events.PLAYER_ZONE_CHANGED,       "EA_Window_OpenPartyManage.LeaderMarksZoneChange" )

    LabelSetText( PARENT_WINDOW.."LootHeaderText", GetStringFromTable( "SocialStrings", StringTables.Social.HEADER_LOOT_OPTIONS ) )
    LabelSetText( PARENT_WINDOW.."WarbandHeaderText", WARBAND_HEADER_TEXT )
    LabelSetText( PARENT_WINDOW.."WarbandSortByRoleLabel", L"Sort" )
    ButtonSetPressedFlag( PARENT_WINDOW.."WarbandSortByRoleButton", EA_Window_OpenPartyManage.sortByRole == true )

    -- Options
    LabelSetText( PARENT_WINDOW.."NeedOnUseButtonLabel", GetString( StringTables.Default.LABEL_NEED_ON_USE_SETTING ) )
    LabelSetText( PARENT_WINDOW.."AutoLootRvRLabel", GetString( StringTables.Default.LABEL_AUTO_LOOT_RVR_SETTING ) )

    LabelSetText( PARENT_WINDOW.."LootModeTitle", GetString( StringTables.Default.LABEL_CURRENT_LOOT_MODE ) )
    ComboBoxAddMenuItem( PARENT_WINDOW.."LootModeCombo", GetString( StringTables.Default.LABEL_LOOT_ROUND_ROBIN ) )
    ComboBoxAddMenuItem( PARENT_WINDOW.."LootModeCombo", GetString( StringTables.Default.LABEL_LOOT_FFA ) )
    ComboBoxAddMenuItem( PARENT_WINDOW.."LootModeCombo", GetString( StringTables.Default.LABEL_LOOT_MASTER_LOOT ) )

    LabelSetText( PARENT_WINDOW.."LootThresholdTitle", GetString( StringTables.Default.LABEL_CURRENT_LOOT_THRESHOLD ) )
    ComboBoxAddMenuItem( PARENT_WINDOW.."LootThresholdCombo", GetString( StringTables.Default.LABEL_ALL) )
    ComboBoxAddMenuItem( PARENT_WINDOW.."LootThresholdCombo", GetString( StringTables.Default.LABEL_ITEM_RARITY_COMMON ) )
    ComboBoxAddMenuItem( PARENT_WINDOW.."LootThresholdCombo", GetString( StringTables.Default.LABEL_ITEM_RARITY_UNCOMMON ) )
    ComboBoxAddMenuItem( PARENT_WINDOW.."LootThresholdCombo", GetString( StringTables.Default.LABEL_ITEM_RARITY_RARE ) )
    ComboBoxAddMenuItem( PARENT_WINDOW.."LootThresholdCombo", GetString( StringTables.Default.LABEL_ITEM_RARITY_VERY_RARE ) )
    ComboBoxAddMenuItem( PARENT_WINDOW.."LootThresholdCombo", GetString( StringTables.Default.LABEL_ITEM_RARITY_ARTIFACT ) )
    ComboBoxAddMenuItem( PARENT_WINDOW.."LootThresholdCombo", GetString( StringTables.Default.LABEL_NONE ) )

    LabelSetText( PARENT_WINDOW.."MasterLooterTitle", GetString( StringTables.Default.LABEL_CURRENT_MASTER_LOOTERS ) )


    -- Legend
    LabelSetText( PARENT_WINDOW.."LegendLeaderText", GetStringFromTable("SocialStrings", StringTables.Social.MANAGE_LEGEND_WARBAND_LEADER) )
    LabelSetText( PARENT_WINDOW.."LegendMainAssistText", GetStringFromTable("SocialStrings", StringTables.Social.MANAGE_LEGEND_MAIN_ASSIST) )
    LabelSetText( PARENT_WINDOW.."LegendAssistantText", GetStringFromTable("SocialStrings", StringTables.Social.MANAGE_LEGEND_WARBAND_ASSISTANT) )
    LabelSetText( PARENT_WINDOW.."LegendMasterLooterText", GetStringFromTable("SocialStrings", StringTables.Social.MANAGE_LEGEND_MASTER_LOOTER) )

    -- Leader Mark
    LabelSetText( PARENT_WINDOW.."LegendLeaderMarkText", L"Leader Marks" )
    ComboBoxAddMenuItem( PARENT_WINDOW.."LegendLeaderMarkCombo", L"None")
    EA_Window_OpenPartyManage.SelectedMark = 1


    -- Set Label Text
    ButtonSetText( PARENT_WINDOW.."ConvertToWarbandButton" , GetString( StringTables.Default.LABEL_PARTY_FORM_WARPARTY ) )

    LabelSetText( GetPartyWindowName(1).."Label", GetString( StringTables.Default.LABEL_GROUP_1 ) )
    LabelSetText( GetPartyWindowName(2).."Label", GetString( StringTables.Default.LABEL_GROUP_2 ) )
    LabelSetText( GetPartyWindowName(3).."Label", GetString( StringTables.Default.LABEL_GROUP_3 ) )
    LabelSetText( GetPartyWindowName(4).."Label", GetString( StringTables.Default.LABEL_GROUP_4 ) )

    for partyIndex = 1, PartyUtils.PARTIES_PER_WARBAND
    do
        local partyWindowCheckBox = GetPartyWindowName(partyIndex).."Show"
        ButtonSetCheckButtonFlag( partyWindowCheckBox, true )
        ButtonSetPressedFlag( partyWindowCheckBox, true )
    end

    CreateWindow( PARENT_WINDOW.."DragWindow", false )
    WindowSetTintColor( PARENT_WINDOW.."DragWindowRowBackground", 255, 255, 255 )
    WindowSetAlpha( PARENT_WINDOW.."DragWindowRowBackground", 0.1 )

    -- Hide hover frame
    WindowSetShowing( PARENT_WINDOW.."WarbandHoverFrame", false )
    DefaultColor.SetWindowTint( PARENT_WINDOW.."WarbandHoverFrame", DefaultColor.TEAL )

    EA_Window_OpenPartyManage.UpdateWarband()
    EA_Window_OpenPartyManage.UpdateSettings()

end

local function EnableShowCheckBoxes( enable )
    for partyIndex = 1, PartyUtils.PARTIES_PER_WARBAND
    do
        local partyWindowCheckBox = GetPartyWindowName(partyIndex).."Show"
        ButtonSetDisabledFlag( partyWindowCheckBox, not enable )
    end
end

function EA_Window_OpenPartyManage.FormWarband()
    if( ButtonGetDisabledFlag( PARENT_WINDOW.."ConvertToWarbandButton" ) )
    then
        return
    end

    SendChatText( L"/warbandconvert", L"" )
end

local function UpdateFormWarbandButtonState()
    local warbandActive = IsWarBandActive()
    WindowSetShowing( PARENT_WINDOW.."ConvertToWarband", not warbandActive )
    ButtonSetDisabledFlag( PARENT_WINDOW.."ConvertToWarbandButton", not GameData.Player.isGroupLeader )
end

function EA_Window_OpenPartyManage.OnShown()
    EA_Window_OpenPartyManage.UpdateWarband()
end

local function IsManageTabHidden()
    return (not WindowGetShowing( "EA_Window_OpenParty" ) or not WindowGetShowing( "EA_Window_OpenPartyManage" ))
end

function EA_Window_OpenPartyManage.SingleMemberUpdate( partyIndex, memberIndex )
    if IsManageTabHidden()
    then
        return
    end

    local member = PartyUtils.GetWarbandMember( partyIndex, memberIndex )

    if( member == nil )
    then
        return
    end

    local rowWindow = GetRowWindowName( partyIndex, GetDisplayedRowIndex( partyIndex, memberIndex ) )
    if( member.online )
    then
        LabelSetTextColor( rowWindow.."Name", 255, 255, 255 )
    else
        LabelSetTextColor( rowWindow.."Name", 100, 100, 100 )
    end
end

function EA_Window_OpenPartyManage.UpdateWarband()
    if IsManageTabHidden()
    then
        return
    end

    local warbandActive = IsWarBandActive()
    EnableShowCheckBoxes( warbandActive )
    UpdateFormWarbandButtonState()
    if( warbandActive )
    then
        WindowSetFontAlpha( PARENT_WINDOW.."Warband", 1.0 )
    else
        WindowSetFontAlpha( PARENT_WINDOW.."Warband", 0.4 )
    end

    -- put warband data in to global table for list box population
    EA_Window_OpenPartyManage.warbandParties = PartyUtils.GetWarbandData()
    local totals = { tanks = 0, mdps = 0, rdps = 0, healers = 0 }

    for index = 1, PartyUtils.PARTIES_PER_WARBAND
    do
        local pt, pmd, prd, ph = EA_Window_OpenPartyManage.UpdateWarbandParty( index )
        totals.tanks = totals.tanks + pt
        totals.mdps = totals.mdps + pmd
        totals.rdps = totals.rdps + prd
        totals.healers = totals.healers + ph
    end
    local memberCount = totals.tanks + totals.mdps + totals.rdps + totals.healers
    LabelSetText( PARENT_WINDOW.."WarbandHeaderText",
        WARBAND_HEADER_TEXT..L" ("..towstring(memberCount)..L"): "
        ..BuildLabeledRoleSummaryText(totals.tanks, totals.mdps, totals.rdps, totals.healers) )
    enemySortSignature = BuildEnemySortSignature()

    EA_Window_OpenPartyManage.UpdateMasterLooterList()
    EA_Window_OpenPartyManage.UpdateSettings()
    EA_Window_OpenPartyManage.UpdateLeaderMarks()
end

function EA_Window_OpenPartyManage.HasEnemySortChanged()
    if not EA_Window_OpenPartyManage.sortByRole then
        enemySortSignature = nil
        return false
    end

    local signature = BuildEnemySortSignature()
    if signature ~= enemySortSignature then
        enemySortSignature = signature
        return true
    end

    return false
end

function EA_Window_OpenPartyManage.UpdateParty()
    if IsManageTabHidden()
    then
        return
    end

    EA_Window_OpenPartyManage.UpdateMasterLooterList()
    EA_Window_OpenPartyManage.UpdateSettings()
    UpdateFormWarbandButtonState()
end

local function UpdateWarbandPartyRow( partyIndex, rowIndex, dataIndex )
    local member = PartyUtils.GetWarbandMember( partyIndex, dataIndex )
    if( member == nil )
    then
        return
    end

    local windowName = GetRowWindowName( partyIndex, rowIndex )

    if( displayedMemberIndices[partyIndex] == nil )
    then
        displayedMemberIndices[partyIndex] = {}
    end
    displayedMemberIndices[partyIndex][rowIndex] = dataIndex
    WindowSetId( windowName, GetRowId( partyIndex, dataIndex ) )

    LabelSetText( windowName.."Name", member.name )
    LabelSetText( windowName.."Rank", member.levelText )

    WindowSetShowing( windowName.."GroupLeaderIcon", member.isGroupLeader )
    WindowSetShowing( windowName.."GroupAssistantIcon", member.isAssistant and not member.isGroupLeader )
    WindowSetShowing( windowName.."MainAssistIcon", member.isMainAssist )
    WindowSetShowing( windowName.."MasterLooterIcon", member.isMasterLooter )

    if member.careerIcon then
        local tex, tx, ty = GetIconData( member.careerIcon )
        if tex then
            DynamicImageSetTexture( windowName.."CareerIcon", tex, tx, ty )
        end
    end

    WindowSetShowing( windowName.."AltIcon", false )
    if EA_Window_OpenParty.GetScoreboardArchtypeIcon then
        local altIconId = nil
        if not ShouldIgnoreEnemyAltSpecForMember(member, ShouldUseEnemyAltSpecRules()) then
            altIconId = EA_Window_OpenParty.GetScoreboardArchtypeIcon( member.name )
        end
        if altIconId then
            local tex2, tx2, ty2 = GetIconData( altIconId )
            if tex2 then
                DynamicImageSetTexture( windowName.."AltIcon", tex2, tx2, ty2 )
                WindowSetShowing( windowName.."AltIcon", true )
            end
        end
    end

    if( member.online )
    then
        LabelSetTextColor( windowName.."Name", 255, 255, 255 )
    else
        LabelSetTextColor( windowName.."Name", 100, 100, 100 )
    end
end

function EA_Window_OpenPartyManage.UpdateWarbandParty( partyIndex )
    local party = PartyUtils.GetWarbandParty( partyIndex )
    local scoreboardData = EA_Window_OpenParty.GetScoreboardDataRaw()
    local roleSortRanks = DEFAULT_ROLE_SORT_RANKS
    local useEnemyAltSpecRules = ShouldUseEnemyAltSpecRules()
    local displayOrder = {}
    local sortData = {}
    local ptanks, pmdps, prdps, phealers = 0, 0, 0, 0

    displayedMemberIndices[partyIndex] = {}

    if( EA_Window_OpenPartyManage.sortByRole )
    then
        roleSortRanks = GetActiveRoleSortRanks()
    end

    for index, member in ipairs( party.players )
    do
        -- Add career icon to the table...
        member.careerIcon = Icons.GetCareerIconIDFromCareerLine( member.careerLine )
        member.levelText = BuildManageRankText(member)

        -- Role counts with scoreboard alt-spec overrides when allowed.
        local role = GetMemberRole(member, scoreboardData, useEnemyAltSpecRules)
        local sortEntry = { index = index, sortRank = GetRoleSortRank(role, roleSortRanks) }
        if( EA_Window_OpenPartyManage.sortByRole )
        then
            sortEntry.sortName = GetMemberSortName(member)
        end
        table.insert( sortData, sortEntry )
        if role == EA_Window_OpenParty.RoleTypes.TANK then
            ptanks = ptanks + 1
        elseif role == EA_Window_OpenParty.RoleTypes.MDPS then
            pmdps = pmdps + 1
        elseif role == EA_Window_OpenParty.RoleTypes.RDPS then
            prdps = prdps + 1
        elseif role == EA_Window_OpenParty.RoleTypes.HEALER then
            phealers = phealers + 1
        end
    end

    if( EA_Window_OpenPartyManage.sortByRole )
    then
        table.sort( sortData, function( left, right )
            if( left.sortRank ~= right.sortRank )
            then
                return left.sortRank < right.sortRank
            end

            if( left.sortName ~= right.sortName )
            then
                return left.sortName < right.sortName
            end

            return left.index < right.index
        end )
    end

    for rowIndex, sortEntry in ipairs( sortData )
    do
        local dataIndex = sortEntry.index
        table.insert( displayOrder, dataIndex )
        displayedMemberIndices[partyIndex][rowIndex] = dataIndex

        local rowWindow = GetRowWindowName( partyIndex, rowIndex )
        WindowSetId( rowWindow, GetRowId( partyIndex, dataIndex ) )
    end

    for rowIndex = table.getn(displayOrder) + 1, PartyUtils.PLAYERS_PER_PARTY
    do
        local rowWindow = GetRowWindowName( partyIndex, rowIndex )
        WindowSetId( rowWindow, GetRowId( partyIndex, rowIndex ) )
    end

    ListBoxSetDisplayOrder( GetPartyWindowName(partyIndex).."List", displayOrder )

    for rowIndex, dataIndex in ipairs( displayOrder )
    do
        UpdateWarbandPartyRow( partyIndex, rowIndex, dataIndex )
    end

    local labelgroup
    if partyIndex == 1 then labelgroup = StringTables.Default.LABEL_GROUP_1 end
    if partyIndex == 2 then labelgroup = StringTables.Default.LABEL_GROUP_2 end
    if partyIndex == 3 then labelgroup = StringTables.Default.LABEL_GROUP_3 end
    if partyIndex == 4 then labelgroup = StringTables.Default.LABEL_GROUP_4 end

    LabelSetText( GetPartyWindowName(partyIndex).."Label",
        GetString( labelgroup )..L": "..BuildCompactRoleSummaryText(ptanks, pmdps, prdps, phealers) )

    return ptanks, pmdps, prdps, phealers
end

local function WarbandPartyPopulator( partyIndex, populatorIndices )
    if( populatorIndices == nil )
    then
        return
    end

    for rowIndex, dataIndex in ipairs( populatorIndices )
    do
        UpdateWarbandPartyRow( partyIndex, rowIndex, dataIndex )
    end
end

function EA_Window_OpenPartyManage.PopulateParty1()
    WarbandPartyPopulator( 1, EA_Window_OpenPartyManageWarband1List.PopulatorIndices )
end
function EA_Window_OpenPartyManage.PopulateParty2()
    WarbandPartyPopulator( 2, EA_Window_OpenPartyManageWarband2List.PopulatorIndices )
end
function EA_Window_OpenPartyManage.PopulateParty3()
    WarbandPartyPopulator( 3, EA_Window_OpenPartyManageWarband3List.PopulatorIndices )
end
function EA_Window_OpenPartyManage.PopulateParty4()
    WarbandPartyPopulator( 4, EA_Window_OpenPartyManageWarband4List.PopulatorIndices )
end


function EA_Window_OpenPartyManage.ToggleWarbandVisibility()
    if( BattlegroupHUD )
    then
        BattlegroupHUD.Update()
    end
end

function EA_Window_OpenPartyManage.ToggleSortByRole()
    local buttonName = PARENT_WINDOW.."WarbandSortByRoleButton"
    local newState = not ButtonGetPressedFlag( buttonName )

    EA_Window_OpenPartyManage.sortByRole = newState
    ButtonSetPressedFlag( buttonName, newState )
    EA_Window_OpenPartyManage.UpdateWarband()
end

function EA_Window_OpenPartyManage.OnMouseoverSortByRole()
    Tooltips.CreateTextOnlyTooltip( SystemData.ActiveWindow.name )

    Tooltips.SetTooltipText( 1, 1, L"Sort" )
    Tooltips.SetTooltipColorDef( 1, 1, Tooltips.COLOR_HEADING )

    Tooltips.SetTooltipText( 2, 1, L"Sort each group by role." )
    Tooltips.SetTooltipColorDef( 2, 1, Tooltips.COLOR_BODY )

    Tooltips.SetTooltipText( 3, 1, BuildSortTooltipOrderText() )
    Tooltips.SetTooltipColorDef( 3, 1, Tooltips.COLOR_BODY )

    Tooltips.Finalize()
    Tooltips.AnchorTooltip( Tooltips.ANCHOR_WINDOW_RIGHT )
end

function EA_Window_OpenPartyManage.CountWarband()
    local Counter = 0
    local warband = PartyUtils.GetWarbandData()
    for _, party in ipairs( warband )
    do
        Counter = Counter + table.getn(party.players)
    end

    return Counter
end

--------------------------------------------------------------------------------
-- PARTY SETTINGS FUNCTIONS
--------------------------------------------------------------------------------

function EA_Window_OpenPartyManage.UpdateSettings()

    -- Adding 1 is necessary because GameData.Player.Group.Settings.lootMode is needlessly incremented by the client
    local masterLooterIsActive = GameData.Player.Group.Settings.lootMode == (GameData.LootModes.MASTER_LOOT + 1)

    -- NEED ON USE
    ButtonSetPressedFlag( PARENT_WINDOW.."NeedOnUseButtonButton", GameData.Player.Group.Settings.noNeedOnGreed )
    ButtonSetDisabledFlag( PARENT_WINDOW.."NeedOnUseButtonButton", masterLooterIsActive or GameData.Player.isGroupLeader == false )

    -- AUTO LOOT IN RVR
    ButtonSetPressedFlag( PARENT_WINDOW.."AutoLootRvRButton", GameData.Player.Group.Settings.autoLootInRvR )
    ButtonSetDisabledFlag( PARENT_WINDOW.."AutoLootRvRButton", masterLooterIsActive or GameData.Player.isGroupLeader == false )


    -- LOOT MODE
    ComboBoxSetSelectedMenuItem( PARENT_WINDOW.."LootModeCombo", GameData.Player.Group.Settings.lootMode )
    ComboBoxSetDisabledFlag( PARENT_WINDOW.."LootModeCombo", GameData.Player.isGroupLeader == false )

    -- LOOT THRESHOLD
    local disableThreshold = ((GameData.Player.isGroupLeader == true) and (GameData.Player.Group.Settings.lootMode == 3)) == false
    ComboBoxSetSelectedMenuItem( PARENT_WINDOW.."LootThresholdCombo", GameData.Player.Group.Settings.lootThreshold )
    ComboBoxSetDisabledFlag( PARENT_WINDOW.."LootThresholdCombo", disableThreshold )

    -- MASTER LOOTER
    local disableMasterCombo = not masterLooterIsActive
    ComboBoxSetDisabledFlag( PARENT_WINDOW.."MasterLooterCombo", disableMasterCombo or GameData.Player.isGroupLeader == false )
    if( GameData.Player.Group.Settings.isMasterLooter ~= nil )
    then
        for index, isMasterLooter in ipairs( GameData.Player.Group.Settings.isMasterLooter )
        do
            if( isMasterLooter )
            then
                ComboBoxSetSelectedMenuItem( PARENT_WINDOW.."MasterLooterCombo", index )
                break
            end
        end
    end
end

function EA_Window_OpenPartyManage.ToggleNeedOnUse()
    if( not ButtonGetDisabledFlag( PARENT_WINDOW.."NeedOnUseButtonButton" ) )
    then
        local isPressed = ButtonGetPressedFlag( PARENT_WINDOW.."NeedOnUseButtonButton" )
        SetGroupNeedMode( not isPressed )
        ButtonSetPressedFlag( PARENT_WINDOW.."NeedOnUseButtonButton", not isPressed )
    end
end

function EA_Window_OpenPartyManage.OnMouseoverNeedOnUse()
    Tooltips.CreateTextOnlyTooltip( SystemData.ActiveWindow.name )

    Tooltips.SetTooltipText( 1, 1, GetString( StringTables.Default.LABEL_NEED_ON_USE_SETTING ) )
    Tooltips.SetTooltipColorDef( 1, 1, Tooltips.COLOR_HEADING )

    Tooltips.SetTooltipText( 2, 1, GetString( StringTables.Default.TEXT_NEED_ON_USE_DESC ) )
    Tooltips.SetTooltipColorDef( 2, 1, Tooltips.COLOR_BODY )

    Tooltips.Finalize()
    Tooltips.AnchorTooltip( Tooltips.ANCHOR_WINDOW_RIGHT )
end

function EA_Window_OpenPartyManage.ToggleAutoLootRvR()
    if( not ButtonGetDisabledFlag( PARENT_WINDOW.."AutoLootRvRButton" ) )
    then
        local isPressed = ButtonGetPressedFlag( PARENT_WINDOW.."AutoLootRvRButton" )
        SetGroupAutoLootInRvR( not isPressed )
        ButtonSetPressedFlag( PARENT_WINDOW.."AutoLootRvRButton", not isPressed )
    end
end

function EA_Window_OpenPartyManage.OnMouseoverLeaderMark()
    Tooltips.CreateTextOnlyTooltip( SystemData.ActiveWindow.name )

    local row = 1
    local text = L"Leader Markers"
    Tooltips.SetTooltipText( 1, 1, text)
    Tooltips.SetTooltipColorDef( 1, 1, Tooltips.COLOR_HEADING )
    row = row + 1

    text = L"You must be leading a Warband of 16 or more players to activate a visible Leader Marker."
    Tooltips.SetTooltipText( row, 1, text)
    Tooltips.SetTooltipColorDef( row, 1, Tooltips.COLOR_BODY )
    row = row + 1

    local type = L"Unlocking New Colors:   "
    Tooltips.SetTooltipText( row, 1, type)
    Tooltips.SetTooltipColorDef( row, 1, Tooltips.COLOR_HEADING )
    row = row + 1

    text = L"Purchase and equip the item from the Commander Vendor in your capital city to add new colors. Once unlocked, you can swap out the pocket item."
    Tooltips.SetTooltipText( row, 1, text)
    Tooltips.SetTooltipColorDef( row, 1, Tooltips.COLOR_BODY )

    Tooltips.Finalize()
    Tooltips.AnchorTooltip( Tooltips.ANCHOR_WINDOW_RIGHT )
end

function EA_Window_OpenPartyManage.OnMouseoverAutoLootRvR()
    Tooltips.CreateTextOnlyTooltip( SystemData.ActiveWindow.name )

    Tooltips.SetTooltipText( 1, 1, GetString( StringTables.Default.LABEL_AUTO_LOOT_RVR_SETTING ) )
    Tooltips.SetTooltipColorDef( 1, 1, Tooltips.COLOR_HEADING )

    Tooltips.SetTooltipText( 2, 1, GetString( StringTables.Default.TEXT_AUTO_LOOT_RVR_DESC ) )
    Tooltips.SetTooltipColorDef( 2, 1, Tooltips.COLOR_BODY )

    Tooltips.Finalize()
    Tooltips.AnchorTooltip( Tooltips.ANCHOR_WINDOW_RIGHT )
end



function EA_Window_OpenPartyManage.OnLootModeSelChange( newMode )
    SetGroupLootMode( newMode )
end

function EA_Window_OpenPartyManage.OnMouseoverLootModeCombo()
    local txtColumn = Tooltips.COLUMN_RIGHT_LEFT_ALIGN

    Tooltips.CreateTextOnlyTooltip( SystemData.ActiveWindow.name )

    local row = 1
    local text = GetString( StringTables.Default.LABEL_CURRENT_LOOT_MODE )
    Tooltips.SetTooltipText( 1, 1, text)
    Tooltips.SetTooltipColorDef( 1, 1, Tooltips.COLOR_HEADING )
    row = row + 1

    text =  GetString( StringTables.Default.TEXT_LOOT_MODE_DESC )
    Tooltips.SetTooltipText( row, 1, text)
    Tooltips.SetTooltipColorDef( row, 1, Tooltips.COLOR_BODY )
    row = row + 1

    local type = GetString( StringTables.Default.LABEL_LOOT_ROUND_ROBIN )..L":   "
    text =  GetString( StringTables.Default.TEXT_LOOT_ROUND_ROBIN_DESC )
    Tooltips.SetTooltipText( row, 1, type)
    Tooltips.SetTooltipColorDef( row, 1, Tooltips.COLOR_HEADING )
    Tooltips.SetTooltipText( row, txtColumn, text)
    Tooltips.SetTooltipColorDef( row, txtColumn, Tooltips.COLOR_BODY )
    row = row + 1

    type = GetString( StringTables.Default.LABEL_LOOT_FFA )..L":   "
    text = GetString( StringTables.Default.TEXT_LOOT_FFA_DESC )
    Tooltips.SetTooltipText( row, 1, type)
    Tooltips.SetTooltipColorDef( row, 1, Tooltips.COLOR_HEADING )
    Tooltips.SetTooltipText( row, txtColumn, text)
    Tooltips.SetTooltipColorDef( row, txtColumn, Tooltips.COLOR_BODY )
    row = row + 1

    type = GetString( StringTables.Default.LABEL_LOOT_MASTER_LOOT )..L":   "
    text = GetString( StringTables.Default.TEXT_LOOT_MASTER_LOOT_DESC )
    Tooltips.SetTooltipText( row, 1, type)
    Tooltips.SetTooltipColorDef( row, 1, Tooltips.COLOR_HEADING )
    Tooltips.SetTooltipText( row, txtColumn, text)
    Tooltips.SetTooltipColorDef( row, txtColumn, Tooltips.COLOR_BODY )

    -- Show action text when the player cannot change the loot options
    if( GameData.Player.isGroupLeader == false ) then
        local actiontext = GetString( StringTables.Default.TEXT_CHANGE_LOOT_OPTIONS )
        Tooltips.SetTooltipActionText( actiontext )
    end

    Tooltips.Finalize()
    Tooltips.AnchorTooltip( Tooltips.ANCHOR_WINDOW_RIGHT )
end

function EA_Window_OpenPartyManage.OnLootThresholdSelChange( newThreshold )
    SetGroupLootThreshold( newThreshold )
end

function EA_Window_OpenPartyManage.OnMouseoverLootThresholdCombo()

    Tooltips.CreateTextOnlyTooltip( SystemData.ActiveWindow.name )

    local text = GetString( StringTables.Default.LABEL_CURRENT_LOOT_THRESHOLD )
    Tooltips.SetTooltipText( 1, 1, text)
    Tooltips.SetTooltipColorDef( 1, 1, Tooltips.COLOR_HEADING )

    text =  GetString( StringTables.Default.TEXT_LOOT_THRESHOLD_DESC )
    Tooltips.SetTooltipText( 2, 1, text)
    Tooltips.SetTooltipColorDef( 2, 1, Tooltips.COLOR_BODY )

    -- Show action text when the player cannot change the loot options
    if( GameData.Player.isGroupLeader == false ) then
        local actiontext = GetString( StringTables.Default.TEXT_CHANGE_LOOT_OPTIONS )
        Tooltips.SetTooltipActionText( actiontext )
    end

    Tooltips.Finalize()
    Tooltips.AnchorTooltip( Tooltips.ANCHOR_WINDOW_RIGHT )

end

function EA_Window_OpenPartyManage.OnMasterLooterSelChange( newMasterLooter )
    if( newMasterLooter <= 0 )
    then
        return
    end
    SystemData.UserInput.selectedGroupMember = ComboBoxGetSelectedText( PARENT_WINDOW.."MasterLooterCombo" )
    PartyUtils.SetMasterLooter()
end

function EA_Window_OpenPartyManage.UpdateMasterLooterList()
    ComboBoxClearMenuItems( PARENT_WINDOW.."MasterLooterCombo" )
    if( not IsWarBandActive() )
    then
        ComboBoxAddMenuItem( PARENT_WINDOW.."MasterLooterCombo", GameData.Player.name )
        for index = 1, PartyUtils.PLAYERS_PER_PARTY_WITHOUT_LOCAL
        do
            if( PartyUtils.IsPartyMemberValid( index ) )
            then
                ComboBoxAddMenuItem( PARENT_WINDOW.."MasterLooterCombo", PartyUtils.GetPartyMember( index ).name )
            end
        end
    else
        local warband = PartyUtils.GetWarbandData()
        for _, group in ipairs( warband )
        do
            for _, member in ipairs( group.players )
            do
                ComboBoxAddMenuItem( PARENT_WINDOW.."MasterLooterCombo", member.name )
            end
        end
    end
end

-- Builds Leader Marks Combobox and table
function EA_Window_OpenPartyManage.UpdateLeaderMarks()
    -- check if you are leader, if not set mark to none and disable choices
    local isLeader = GameData.Player.isGroupLeader
    local warbandActive = IsWarBandActive()

    ComboBoxSetDisabledFlag( PARENT_WINDOW.."LegendLeaderMarkCombo",
        (isLeader == false) or (EA_Window_OpenPartyManage.CountWarband() < 16) or (warbandActive == false) )

    EA_Window_OpenPartyManage.LeaderMarks = {}
    ComboBoxClearMenuItems( PARENT_WINDOW.."LegendLeaderMarkCombo" )

    -- 1st combobox choice should be "None" (0)
    ComboBoxAddMenuItem( PARENT_WINDOW.."LegendLeaderMarkCombo", L"None")
    EA_Window_OpenPartyManage.LeaderMarks[1] = 0
    if EA_Window_OpenPartyManage.CheckForMarks() == true then
        local currentSubTypeData = TomeGetAchievementsSubTypeData(175)

        for _, entryData in ipairs(currentSubTypeData.entries) do
            if entryData.isUnlocked then
                ComboBoxAddMenuItem( PARENT_WINDOW.."LegendLeaderMarkCombo", towstring(wstring.gsub(entryData.name, L"Warband Leader ", L"")) )
                table.insert(EA_Window_OpenPartyManage.LeaderMarks, entryData.unlockEventId)
            end
        end
    end
    ComboBoxSetSelectedMenuItem( PARENT_WINDOW.."LegendLeaderMarkCombo", EA_Window_OpenPartyManage.SelectedMark)
end

-- Check if you have the ToK unlocked
function EA_Window_OpenPartyManage.CheckForMarks()
    for _, typeData in ipairs(TomeGetAchievementsTOC()) do
        for _, subTypeData in ipairs(typeData.subtypes) do
            if subTypeData.id == 175 then
                return true
            end
        end
    end
    return false
end

function EA_Window_OpenPartyManage.LeaderMarksZoneChange()
    local isLeader = GameData.Player.isGroupLeader
    local warbandActive = IsWarBandActive()
    ComboBoxSetDisabledFlag( PARENT_WINDOW.."LegendLeaderMarkCombo",
        (isLeader == false) or (EA_Window_OpenPartyManage.CountWarband() < 16) or (warbandActive == false) )

    if isLeader == false then
        EA_Window_OpenPartyManage.SelectedMark = 1
        return
    end

    if EA_Window_OpenPartyManage.SelectedMark > 1 then
        EA_Window_OpenPartyManage.OnLeaderMarkSelChange( EA_Window_OpenPartyManage.SelectedMark )
    end
end

function EA_Window_OpenPartyManage.OnLeaderMarkSelChange( newMode )
    if newMode == 0 then return end
    EA_Window_OpenPartyManage.SelectedMark = newMode
    SendChatText( L"]warbandmarker "..towstring(EA_Window_OpenPartyManage.LeaderMarks[newMode]), L"" )
    EA_Window_OpenPartyManage.UpdateLeaderMarks()
end

--------------------------------------------------------------------------------
-- CONTEXT MENU FUNCTIONS AND CALLBACKS
--------------------------------------------------------------------------------
function EA_Window_OpenPartyManage.ShowWarbandMemberMenu( member )

    SystemData.UserInput.selectedGroupMember = member.name

    -- Build the Custom Section of the Player Menu
    local customMenuItems = {}

    -- Show the "Make Leader" option if the player is a group leader
    if( GameData.Player.isGroupLeader )
    then
        table.insert( customMenuItems, PlayerMenuWindow.NewCustomItem( GetString( StringTables.Default.LABEL_MAKE_LEADER ), PartyUtils.SetWarbandLeader, member.isGroupLeader or not member.online ) )
        if( member.isAssistant )
        then
            table.insert( customMenuItems, PlayerMenuWindow.NewCustomItem( GetString( StringTables.Default.LABEL_DEMOTE_ASSISTANT ), PartyUtils.DemoteWarbandAssistant, member.isGroupLeader or not member.online ) )
        else
            table.insert( customMenuItems, PlayerMenuWindow.NewCustomItem( GetString( StringTables.Default.LABEL_MAKE_ASSISTANT ), PartyUtils.SetWarbandAssistant, member.isGroupLeader or not member.online ) )
        end
    end

    -- Main Assist
    local mainAssistMember = PartyUtils.GetWarbandMainAssist()
    if( GameData.Player.isGroupLeader or ( mainAssistMember ~= nil and WStringsCompareIgnoreGrammer( mainAssistMember.name, GameData.Player.name ) == 0 ) )
    then
        table.insert( customMenuItems, PlayerMenuWindow.NewCustomItem( GetString( StringTables.Default.LABEL_MAKE_MAIN_ASSIST ), PartyUtils.SetMainAssist, member.isMainAssist or not member.online ) )
    end

    -- Master looter
    local masterLootSet = GameData.Player.Group.Settings.lootMode == (GameData.LootModes.MASTER_LOOT + 1)
    if( GameData.Player.isGroupLeader and masterLootSet ) then
        table.insert( customMenuItems, PlayerMenuWindow.NewCustomItem( GetString( StringTables.Default.LABEL_MAKE_MASTER_LOOTER ), PartyUtils.SetMasterLooter, member.isMasterLooter or not member.online ) )
    end

     -- Create the Menu
    PlayerMenuWindow.ShowMenu( member.name, 0, customMenuItems )

end

--------------------------------------------------------------------------------
-- WARBAND MEMBER ROW EVENT HANDLERS
--------------------------------------------------------------------------------

function EA_Window_OpenPartyManage.OnRButtonUpPlayerRow()
    local rowId = GetRowIdFromWindow( SystemData.MouseOverWindow.name )
    local partyIndex = GetPartyByRowId( rowId )
    local memberIndex = GetRowIndexByRowId( rowId )
    local member = PartyUtils.GetWarbandMember( partyIndex, memberIndex )
    if( member )
    then
        EA_Window_OpenPartyManage.ShowWarbandMemberMenu( member )
    end
end

--------------------------------------------------------------------------------
-- DRAGGING FUNCTIONS
--------------------------------------------------------------------------------

local function ShowMouseOverHoverFrame( hoverPartyIndex )
    local rowId = GetRowIdFromWindow( draggedWindow )
    if( rowId == 0 )
    then
        WindowSetShowing( PARENT_WINDOW.."WarbandHoverFrame", false )
        return
    end

    local partyIndex = GetPartyByRowId( rowId )
    if( partyIndex == hoverPartyIndex )
    then
        WindowSetShowing( PARENT_WINDOW.."WarbandHoverFrame", false )
        return
    end

    WindowClearAnchors( PARENT_WINDOW.."WarbandHoverFrame" )
    WindowAddAnchor( PARENT_WINDOW.."WarbandHoverFrame", "topleft", SystemData.MouseOverWindow.name, "topleft", 0, 0 )
    WindowAddAnchor( PARENT_WINDOW.."WarbandHoverFrame", "bottomright", SystemData.MouseOverWindow.name, "bottomright", 0, 0 )

    WindowSetShowing( PARENT_WINDOW.."WarbandHoverFrame", true )
end

function EA_Window_OpenPartyManage.OnMouseOverWarbandListBox()
    if( draggedWindow == nil )
    then
        WindowSetShowing( PARENT_WINDOW.."WarbandHoverFrame", false )
        return
    end

    local newPartyIndex = GetPartyIndexByWindowName( SystemData.MouseOverWindow.name )
    ShowMouseOverHoverFrame( newPartyIndex )
end

function EA_Window_OpenPartyManage.OnMouseOverPlayerRow()
    if( draggedWindow == nil )
    then
        WindowSetShowing( PARENT_WINDOW.."WarbandHoverFrame", false )
        return
    end

    local newRowId = GetRowIdByWindowName( SystemData.MouseOverWindow.name )
    local newPartyIndex = GetPartyByRowId( newRowId )
    ShowMouseOverHoverFrame( newPartyIndex )
end

function EA_Window_OpenPartyManage.OnMouseOverEndWarbandListBox()
    WindowSetShowing( PARENT_WINDOW.."WarbandHoverFrame", false )
end

function EA_Window_OpenPartyManage.OnLButtonDownPlayerRow()
    if( GameData.Player.isGroupLeader == false and GameData.Player.isWarbandAssistant == false )
    then
        return
    end

    -- We can sometimes get a mouse down trigger on this window with
    -- SystemData.MouseOverWindow.name set to Root due to the game not having focus
    if( not string.find( SystemData.MouseOverWindow.name, PARENT_WINDOW.."Warband" ) )
    then
        return
    end

    draggedWindow = SystemData.MouseOverWindow.name
end

function EA_Window_OpenPartyManage.OnMouseOverEndPlayerRow()
    if( draggedWindow == nil )
    then
        return
    end

    local rowId = GetRowIdFromWindow( draggedWindow )
    if( rowId == 0 )
    then
        draggedWindow = nil
        return
    end

    local partyIndex = GetPartyByRowId( rowId )
    local memberIndex = GetRowIndexByRowId( rowId )
    local party = EA_Window_OpenPartyManage.warbandParties[partyIndex]
    if( party == nil or party.players == nil )
    then
        draggedWindow = nil
        return
    end

    local member = party.players[memberIndex]
    if( member == nil )
    then
        draggedWindow = nil
        return
    end

    LabelSetText( PARENT_WINDOW.."DragWindowName", member.name )
    LabelSetText( PARENT_WINDOW.."DragWindowRank", BuildManageRankText(member) )
    local texture, x, y = GetIconData( member.careerIcon )
    DynamicImageSetTexture( PARENT_WINDOW.."DragWindowCareerIcon", texture, x, y )
    WindowSetShowing( PARENT_WINDOW.."DragWindowGroupLeaderIcon", member.isGroupLeader )
    WindowSetShowing( PARENT_WINDOW.."DragWindowMainAssistIcon", member.isMainAssist )
    WindowSetShowing( PARENT_WINDOW.."DragWindowMasterLooterIcon", member.isMasterLooter )

    WindowClearAnchors( PARENT_WINDOW.."DragWindow" )
    local anchor = { Point = "topleft", RelativeTo = "CursorWindow", RelativePoint = "topleft", XOffset = 0, YOffset = 0 }
    WindowAddAnchor( PARENT_WINDOW.."DragWindow", anchor.Point, anchor.RelativeTo, anchor.RelativePoint, anchor.XOffset, anchor.YOffset )
    WindowSetShowing( PARENT_WINDOW.."DragWindow", true )
    WindowSetShowing( PARENT_WINDOW.."WarbandHoverFrame", false )
end

function EA_Window_OpenPartyManage.OnLButtonUpProcessed()
    if( draggedWindow == nil )
    then
        return
    end

    local rowId = GetRowIdFromWindow( draggedWindow )
    if( rowId == 0 )
    then
        draggedWindow = nil
        return
    end

    local partyIndex = GetPartyByRowId( rowId )
    local memberIndex = GetRowIndexByRowId( rowId )
    local member = PartyUtils.GetWarbandMember( partyIndex, memberIndex )

    if(     member ~= nil
        and string.find( SystemData.MouseOverWindow.name, PARENT_WINDOW.."Warband" )
        and string.find( SystemData.MouseOverWindow.name, "List" )
        and draggedWindow ~= SystemData.MouseOverWindow.name )
    then
        if( string.find( SystemData.MouseOverWindow.name, "Row" ) )
        then
            local newRowId = GetRowIdByWindowName( SystemData.MouseOverWindow.name )
            local newPartyIndex = GetPartyByRowId( newRowId )
            local newMemberIndex = GetRowIndexByRowId( newRowId )
            local memberToSwap = PartyUtils.GetWarbandMember( newPartyIndex, newMemberIndex )
            if( memberToSwap ~= nil and partyIndex ~= newPartyIndex )
            then
                PartyUtils.SwapWarbandMembers( member.name, memberToSwap.name )
            end
        else
            -- didn't drop on another player, move to this party
            local newPartyIndex = GetPartyIndexByWindowName( SystemData.MouseOverWindow.name )
            if( partyIndex ~= newPartyIndex )
            then
                PartyUtils.MoveWarbandMember( member.name, newPartyIndex )
            end
        end
    end

    WindowClearAnchors( PARENT_WINDOW.."DragWindow" )
    WindowSetShowing( PARENT_WINDOW.."DragWindow", false )
    WindowSetShowing( PARENT_WINDOW.."WarbandHoverFrame", false )
    draggedWindow = nil
end
