<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
	<UiMod name="fpsbox" version="1.1" date="12/19/2008" >

		<Author name="Deryle" email="yay no email!" />
		<Description text="Small moveable text window that displays your average FPS." />
        	
        	<VersionSettings gameVersion="1.3.1" windowsVersion="1.0" savedVariablesVersion="1.0" />
        	
		<Files>
			<File name="fpsbox.xml" />
		</Files>
		
		<OnInitialize>
            		<CallFunction name="fpsbox.Initialize" />
		</OnInitialize>

		<OnShutdown>
			<CallFunction name="fpsbox.Shutdown" />
		</OnShutdown>
		
		<OnUpdate>
            		<CallFunction name="fpsbox.OnUpdate" />
        	</OnUpdate>
        	
		<SavedVariables>
		    <SavedVariable name="fpsbox.bucketSize" />
		    <SavedVariable name="fpsbox.recalcIntervall" />
		    <SavedVariable name="fpsbox.Settings" />
		</SavedVariables>
		
	</UiMod>
</ModuleFile>
