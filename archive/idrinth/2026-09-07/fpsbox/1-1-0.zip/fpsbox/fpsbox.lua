--Please note a large portion of credit should go to Shirah for their contribution of the ApproxFPS mod.
fpsbox = {}

fpsbox.bucketSize = 30
fpsbox.recalcIntervall = 20


--Thanks to Shirah
local timeSinceRecalc = 0   -- time passed since last full recalc
local bucketsSum = 0        -- sum of the buckets
local bucketIndex = 1       -- index of the last modified bucket
local buckets = {}          -- table holding the samples

fpsbox.Defaults = {
	["anchor-point"]                = "center",
	["anchor-relpoint"]             = "center",
	["anchor-relwin"]               = "Root",
	["anchor-x"]                    = 0,
	["anchor-y"]                    = 0,
	["anchor-scale"]                = 0.72,
}

--Function thanks to Shirah :)
local function displayFPS(frameTime)
    local fps = nil
    local avgfps = nil

    -- calculate fps
    if(frameTime > 0) then
        fps = math.floor(1/frameTime)
    end

    -- calculate avgfps
    if(bucketsSum > 0) then
        avgfps = math.floor(fpsbox.bucketSize/bucketsSum)
    end

    -- update label
    --local labelText = L"(FPS) C:"..(fps or L"N/A")..L" | A:"..(avgfps or L"N/A")
    local labelText = L"FPS:"..(avgfps or L"N/A")
    
    LabelSetText("fpsboxWindowText", labelText)

end

function fpsbox.Initialize()
	if not fpsbox.Settings then fpsbox.Settings = {} end
	
	--first lets create the window, otherwise WAR doesn't know it exists
	CreateWindow("fpsboxWindow", true)
	--time to register the layout
	LayoutEditor.RegisterWindow( "fpsboxWindow", L"fpsbox", L"Displays your average FPS", false, false, true, nil )
	--register event to update window on reload of UI
	RegisterEventHandler(SystemData.Events.INTERFACE_RELOADED, "fpsbox.OnUpdate")
    	RegisterEventHandler(SystemData.Events.LOADING_END, "fpsbox.OnLoad")
    	RegisterEventHandler(SystemData.Events.RELOAD_INTERFACE, "fpsbox.OnLoad")
	
	table.insert(LayoutEditor.EventHandlers, fpsbox.SavePosition)
end

function fpsbox.OnLoad()
    fpsbox.RestorePosition()
end

function fpsbox.Shutdown()
	--unregister the event if we turn off the mod
	UnregisterEventHandler(SystemData.Events.INTERFACE_RELOADED, "fpsbox.OnUpdate");	
end

function fpsbox.WindowInitialize()
	--reset values
	for i = 1, fpsbox.bucketSize do
		buckets[i] = 50 --fake value
		bucketsSum = bucketsSum + buckets[i]
	end

	displayFPS(0)
end

--Update function thanks to Shirah :)
function fpsbox.OnUpdate(elapsedTime)
	if not elapsedTime then return end
	
    timeSinceRecalc = timeSinceRecalc + elapsedTime

    bucketIndex = bucketIndex + 1
    if (bucketIndex > fpsbox.bucketSize) then
        bucketIndex = 1
    end

    if (timeSinceRecalc > fpsbox.recalcIntervall) then
        buckets[bucketIndex] = elapsedTime
        bucketsSum = 0
        for i = 1, fpsbox.bucketSize do
            bucketsSum = bucketsSum + buckets[i]
        end
        timeSinceRecalc = 0
    else  
        bucketsSum = bucketsSum - buckets[bucketIndex] + elapsedTime
        buckets[bucketIndex] = elapsedTime
    end

    displayFPS(elapsedTime)
end

function fpsbox.RestorePosition()
    -- Restore the previous position of the window, even across addon version changes
    
    LayoutEditor.UnregisterWindow("fpsboxWindow")
    
    WindowClearAnchors("fpsboxWindow")
    WindowAddAnchor("fpsboxWindow",
        fpsbox.GetSetting("anchor-point"),
        fpsbox.GetSetting("anchor-relwin"),
        fpsbox.GetSetting("anchor-relpoint"),
        fpsbox.GetSetting("anchor-x"),
        fpsbox.GetSetting("anchor-y"))
    	WindowSetScale("fpsboxWindow", fpsbox.GetSetting("anchor-scale"))
    LayoutEditor.RegisterWindow("fpsboxWindow", L"fpsbox", L"Displays your average FPS", false, false, false, nil)
end

function fpsbox.SavePosition(eventId)
    -- Save position when the layout editor tells us it's finished.
    if eventId == LayoutEditor.EDITING_END then
        local point, relpoint, relwin, x, y = WindowGetAnchor("fpsboxWindow", 1)
        fpsbox.SetSetting("anchor-point", point)
        fpsbox.SetSetting("anchor-relpoint", relpoint)
        fpsbox.SetSetting("anchor-relwin", relwin)
        fpsbox.SetSetting("anchor-x", x)
        fpsbox.SetSetting("anchor-y", y)
        fpsbox.SetSetting("anchor-scale", WindowGetScale("fpsboxWindow"))
    end
end

function fpsbox.GetSetting(key)
    if fpsbox.Settings[key] ~= nil then
        return fpsbox.Settings[key]
    else
        if fpsbox.Defaults[key] ~= nil then
            fpsbox.Settings[key] = fpsbox.Defaults[key]
            return fpsbox.Settings[key]
        else
            return nil
        end
    end
end

function fpsbox.SetSetting(key, value)
    fpsbox.Settings[key] = value
end