------------------------------------------------------------
----------------------- zTimeLib.lua -----------------------
------------------------------------------------------------
--                        zTimeLib
--                 by Zarious of Ulthuan
--             (aka fridgid of Eredar [WoW])
--                  zarious@byteblur.com
--			
--	special thanks to Aiiane, Zypher, Beeblebrox42,
--	Felyza, m0td_2k, Wobin, Thrae, BotanicalPuppet,
--	and others from WARUIDev for day to day tips
--	and help
--
--			 v0.6 r1
--         function scheduling and time functions
--
------------------------------------------------------------
------------------------------------------------------------
-- prevents older versions from overwriting newer ones
local MAJOR, MINOR = 0.6, 1
local VER = 1000 * MAJOR + MINOR
if zTime and zTime.Version and (zTime.Version > VER) then
	MAJOR, MINOR, VER = nil
	return
else
	zTime = {}
	zTime.Version = VER
	MAJOR, MINOR, VER = nil
end

-- tweak bin size by changing this value
-- last bin's size will always be 600 (10 mins)
local binsize = 0.05
-- number of schedule bins
local binnumb = 12
-- localize dispatch, timedata, zfps, and framescheduler tables to prevent tampering
local zTimeData = { hour = 0, min = 0, sec = 0,  offset = 0, time = 0 }
local zFrameSchedule = {}
local zDispatchTable = {}
-- table of data used to run the epoch master updater
local tdelay = 0.05 -- throttling delay, max delay error (time a schedules exec time will differ from its scheduled exec time) when scheduling functions will be double this value
local zTich = { epoch = 0, tdelay = tdelay, nextupdate = 0 + tdelay, lastupdate = 0, tdiff = 0, tich = 0, UID = 0 }
tdelay = nil

-- very small speed boost
local mathfloor = math.floor
local mathfmod = math.fmod
local mathmodf = math.modf
local strformat = string.format
local mathmodf = math.modf
local mathabs = math.abs
local strsub = string.sub
local strlen = string.len
local tonum = tonumber

-- creates subtables (schedule bins) in the dispatch table
for i=1,binnumb do
	zDispatchTable[i] = {}
end

-- init, adds time updaters
function zTime.Init()
	zTime.AddSchedule("TimeGrabber", 15, zTime.UpdateTimeData) -- update time data 15 seconds after ui loads
	zTime.AddSchedule("TimeGrabber", 60, zTime.UpdateTimeData, -1) -- then reupdate every minute to keep clock data more or less in sync
end

-- shutdown lol?
function zTime.ShutDown()
end

-- returns a unique id
local function UniqueID()
	zTich.UID = zTich.UID + 1 
	return zTich.UID
end

-- returns entire frame scheduler table
function zTime.GetFrameSchedule()
	return zFrameSchedule
end

-- returns entire zTich table
function zTime.GetTichTable()
	return zTich
end

-- returns master epoch value (time since ui was last loaded)
function zTime.GetEpoch()
	return zTich.epoch
end

-- returns entire dispatch table
function zTime.GetDispatchTable()
	return zDispatchTable
end

-- returns a table with the time and offset of the last chat log entry
function zTime.GetLastStamp()
	local entry = TextLogGetNumEntries("Chat") - 1 -- last entry is invalid
	if entry < 1 then entry = nil return zTimeData end -- bugfix: uses defualt data if no messages yet
	local stamp = TextLogGetEntry("Chat", entry)
	stamp = WStringToString(stamp)
	local time = {}
	if (strlen(stamp) == 10) then -- sanity check
		time.hour = tonum(strsub(stamp, 2, 3))
		time.min = tonum(strsub(stamp, 5, 6))
		time.sec = tonum(strsub(stamp, 8, 9))
		time.offset = zTime.GetEpoch()
	else -- not enough logs / time is invalid etc
		time.hour = 0
		time.min = 0
		time.sec = 0
		time.offset = 0
	end
	stamp = nil
	return time
end

-- updates TimeData table with most recent timestamp info
function zTime.UpdateTimeData()
	zTimeData = zTime.GetLastStamp()
	zTime.TimeSync()
end

-- updates current time in timedata table
-- difference between above command is the above one fulll reupdates time from the most recent chatlog stamp
-- where as this command only only recomputes the time from the offset of the time already in ztimedata vs current epoch
function zTime.TimeSync()
	zTimeData.time = zTime.GetEpoch() - zTimeData.offset + zTime.HMSToSec(zTimeData)
end

-- returns timedata table
function zTime.GetTimeData()
	return zTimeData
end

-- returns cur time in seconds (7200 would be 2:00 (AM), 86399 would be 11:59 PM or 23:59 etc)
-- this assumes that the TimeGrabber schedules are running, and at least one chat msg has been recieved
function zTime.GetRealTime()
	return zTimeData.time
end

-- comverts seconds into hr, min, sec table format 
function zTime.SecToHMS(sec)
	local min = mathfloor(sec/60)
	local sec = mathfmod(sec, 60)
	local hr = mathfloor(min/60)
	local min = mathfmod(min, 60)
	return { hour = hr, min = min, sec = sec }
end

-- converts hr, min, sec table into sec
function zTime.HMSToSec(hms)
	return (hms.hour * 3600) + (hms.min * 60) + hms.sec
end

-- creates a scheduler which runs every frame
-- DO NOT USE THIS FOR TASKS WHICH DO NOT NEED > 0.1 SUB SECOND PRECISION
-- i also recommend you throttle anything thats computationally heavy
-- returns id needed to deschedule
function zTime.CreateFrameScheduler(func)
	if (type(func) ~= "function") then return false end
	local scheduleID = UniqueID()
	zFrameSchedule[scheduleID] = func
	return scheduleID
end

-- destroys a frame schedule by id
function zTime.DestroyFrameScheduler(id)
	if not zFrameSchedule[id] then return false end
	zFrameSchedule[id] = nil
	return true
end

-- returns a table of exponientally increasing values based on binsize where the last bin is always 600s (10 mins)
function zTime.CreateBins(binsize, numb)
	local bintime  = {}
	for i=1,numb do
		bintime[i] = (math.pow(600/binsize, 1/numb)^i * binsize)
	end
	return bintime
end

local timebins = zTime.CreateBins(binsize, binnumb)

-- returns the schedule bin number a schedule with length len should be placed in
-- schedules larger than the largest bin are assigned the largest bin
function zTime.GetBinSlot(len)
	for k,v in ipairs(timebins) do
		if (k and v) then
			if (len < v) then
				if (k ~= 1) then
					return k-1
				else
					return k
				end
			end
		end
	end
	if (len > timebins[#timebins]) then
		return #timebins
	end
	return false
end

-- Adds a schedule to the dispatch table, returns id for unscheduling
-- name - can be use by outside commands for more logical usage, optional, has no internal effect
-- len - length of time before executing func
-- func - function to be executed
-- repete - times to run schedule, optional, defaults to 1, -1 for indefinately
-- returns scheduleid for easy manipulation/unscheduling
-- TODO: maybe add error handler for functions that return errors
function zTime.AddSchedule(name, len, func, repete) -- pete repete returns
	if ((not len) or (len < 0)) then return false end
	local insert = {}
	local binID = zTime.GetBinSlot(len)
	insert.len = len
	if (type(func) == "function") then
		insert.func = func
	else
		d("zTime.AddSchedule: Function type invalid.")
		bindID, insert = nil
		return false
	end
	insert.pause = false -- pause flag
	insert.rtime = len + zTime.GetEpoch() -- next exec mark
	if not repete then 
		insert.repete = 1
	elseif (repete > 0) then
		insert.repete = mathmodf(repete)
	elseif (repete == -1) then
		insert.repete = -1 -- repeat forever
	else
		insert.repete = 1
		d("zTime.AddSchedule: Invalid repeat argument, defaulting to one.")
	end
	if name then insert.name = name end
	local scheduleID = UniqueID()
	if not scheduleID and binID then bindID, insert, scheduleID = nil; return false end
	zDispatchTable[binID][scheduleID] = insert
	insert = nil
	return scheduleID
end

function zTime.Noop()
end

-- a periodic latch prevents the underlying function from running more than once every n seconds
-- if the function should be spammed multiple times, it will be called again at the end of the period
-- run is the new function with latch integrated
-- terminate will delete the latch and noop run
-- code from RDX (for WoW) by Bill Johnson (C) Raid Informatics modified for WAR
function zTime.CreatePeriodicLatch(period, func)
	local latched, again, id
	local dargtbl = {} -- dynamic arguments table
	local function Latch()
		latched = nil -- reset latch status
		if again then
			func(unpack(dargtbl)) -- run command if it was spammed during closed latch period
			for k in pairs(dargtbl) do dargtbl[k] = nil end
			again = nil
			latched = true
			id = zTime.AddSchedule(nil, period, Latch)
		end
	end
	local function Run(...)
		if not latched then
			func(...)
			latched = true
			again = nil
			id = zTime.AddSchedule(nil, period, Latch)
		else
			if not again then
				again = true -- saves supplied arguments in a table for later unlatched execution
				for i=1,select("#",...) do dargtbl[i] = select(i,...) end
			end
		end
	end
	local function Terminate()
		Run = zTime.Noop
		Latch = zTime.Noop
		latched, again, id = nil, nil, nil
		for k in pairs(dargtbl) do dargtbl[k] = nil end
		Terminate = nil
	end
	return Run, Terminate
end

-- pauses a schedule by id
-- sets the schedule's pause value as the current time
-- upon resuming, the time last is calculated and added to the original rtime
function zTime.PauseSchedule(id)
	local bin = zTime.GetSchedBin(id)
	if bin then
		if zDispatchTable[bin][id] then
			if not zDispatchTable[bin][id].pause then
				zDispatchTable[bin][id].pause = zTime.GetEpoch()
				zTime.ChangeBin(id, bin, #zDispatchTable) -- moves to last bin
				bin = nil
				return true
			else
				d("zTime.PauseSchedule: Schedule is already paused.")
				bin = nil
				return false
			end
		else
			d("zTime.PauseSchedule: Invalid or nonexistant schedule.")
			bin = nil
			return false
		end
	end
end

-- unpauses a schedule by id, and updates its rtime
function zTime.UnPauseSchedule(id)
	local bin = zTime.GetSchedBin(id)
	if bin then
		if zDispatchTable[bin][id] then
			if zDispatchTable[bin][id].pause then
				-- difference of original run time and time schedule was paused
				zDispatchTable[bin][id].pause = false
				zDispatchTable[bin][id].rtime = zTime.GetEpoch() + zDispatchTable[bin][id].rtime - zDispatchTable[bin][id].pause
				local binchk = zTime.BinCheck(id, bin)
				if (binchk and binchk ~= bin) then
					zTime.ChangeBin(id, bin, binchk)
				end
				bin, binchk = nil
				return true
			else 
				d("zTime.UnPauseSchedule: Failed, schedule not currently paused.")
				bin = nil
				return false
			end
		else
			d("zTime.UnPauseSchedule: Invalid or nonexistant schedule.")
			bin = nil
			return false
		end
	end
end

-- removes an entry from the dispatch table by id
-- note: this does not check for existence, it merely nils all bins at id key
function zTime.DelSchedule(id)
	for i=1,#zDispatchTable do
		zDispatchTable[i][id] = nil
	end
end

-- returns the schedule table for schedule by id
function zTime.GetSchedule(id)
	local bin = zTime.GetSchedBin(id)
	if bin then
		local task = {}
		if zDispatchTable[bin][id].name then task.name = zDispatchTable[bin][id].name end
		task.func = zDispatchTable[bin][id].func
		task.len = zDispatchTable[bin][id].len
		task.repete = zDispatchTable[bin][id].repete
		task.pause = zDispatchTable[bin][id].pause
		task.rtime = zDispatchTable[bin][id].rtime
		bin = nil
		return task
	end
	d("zTime.GetSchedule: ID not found.")
	return false
end

-- returns the schedule bin (number) of schedule id
function zTime.GetSchedBin(id)
	for i=1,#zDispatchTable do
		if zDispatchTable[i][id] then -- assumes only one bin will have any given id
			return i
		end	
	end
	d("zTime.GetSchedBin: ID not found.")
	return false
end

-- moves schedule with id from source bin to dest bin
function zTime.ChangeBin(id, source, dest)
	if zDispatchTable[source][id] then
		zDispatchTable[dest][id] = zDispatchTable[source][id] -- shallow copy table from source to the dest
		zDispatchTable[source][id] = nil
	end
end

-- returns the bin a schedule should be in at this time, given it's id and current bin
function zTime.BinCheck(id, key)
	if not ((zDispatchTable[key]) and (type(zDispatchTable[key]) == "table")) then
		d("zTime.BinCheck: Master dispatch table missing/corrupt or schedule does not exist.")
		return false
	end
	if not ((zDispatchTable[key][id]) and (type(zDispatchTable[key][id]) == "table")) then
		d("zTime.BinCheck: Dispatch sub-table missing/corrupt or schedule does not exist.")
		return false
	end
	local toexec = zDispatchTable[key][id].rtime - zTime.GetEpoch() -- time until exec
	if (toexec > 0) then
		return zTime.GetBinSlot(toexec)
	else
		return 1
	end
	return false
end

-- dispatch sub-table's run time ticker
bintimetick = zTime.CreateBins(binsize, binnumb)

-- the dispatcher coordinates the execution of each schedule bin at its specified time interval
-- it is called by epochupdate every throttledelay
function zTime.Dispatch()
	if not ((zDispatchTable) and (type(zDispatchTable) == "table")) then
		d("zTime.Dispatch: Master dispatch table missing or corrupt.")
		return
	end
	for k,v in ipairs(zDispatchTable) do
		if (k and v) then -- if the current time is greater then that bins run time, process the bin
			if (bintimetick[k] <= zTime.GetEpoch()) then
				bintimetick[k] = bintimetick[k] + timebins[k]
				zTime.DispatchBin(k)
			end
		end
	end
end

-- dispatches a single schedule bin (key)
-- the bin checks all non-paused schedules for resorting and then execution
-- if the schedule is set to repeat, its rtime is update, otherwise its removed after execution
function zTime.DispatchBin(key)
	if not ((zDispatchTable[key]) and (type(zDispatchTable[key]) == "table")) then
		d("zTime.DispatchBin: Dispatch sub-table missing or corrupt.")
		return
	end
	for k,v in pairs(zDispatchTable[key]) do
		if (k and v) then
			if (v.len and v.func and (v.pause ~= nil) and v.rtime and v.repete) then
				if not v.pause then
					if (v.rtime > zTime.GetEpoch()) then -- not exec time
						local bin = zTime.BinCheck(k, key)
						if (bin and bin ~= key) then
							zTime.ChangeBin(k, key, bin)
						end
						bin = nil
					elseif (v.rtime <= zTime.GetEpoch()) then -- if run time <= cur time, exec time
						local status, err = pcall(v.func)
						if status then -- no errors
							if (v.repete == 1) then -- if runonce, no need to decrement, just delete
								zTime.DelSchedule(k)
							elseif (v.repete > 1) then
								v.repete = v.repete - 1 -- decrement repeat val
								v.rtime = v.rtime + v.len -- mark next exec time
								local bin = zTime.BinCheck(k, key)
								if (bin and bin ~= key) then -- change bins if necess
									zTime.ChangeBin(k, key, bin)
								end
								bin = nil
							elseif (v.repete == -1) then -- set next run time for indef repeating schedules
								v.rtime =  v.rtime + v.len
								local bin = zTime.BinCheck(k, key)
								if (bin and bin ~= key) then
									zTime.ChangeBin(k, key, bin)
								end
								bin = nil
							elseif (v.repete < 1) then -- neg, non -1, repeat values
								zTime.DelSchedule(k)
							end 
						else -- errors, debug error then remove offending schedule from table
							d("zTime.DispatchBin: Schedule " .. k .. "'s function returned an error. ")
							d(err)
							zTime.DelSchedule(k)
						end
						status, err = nil
					end
				else
					-- paused schedules
				end
			end
		end
	end
end

-- frame scheduler: runs all functions in its table once per frame
-- its called once per frame by epochupdater with zero throttling
-- if a schedule errors out, the error is dumped to debug, and the schedule is deleted
function zTime.FrameScheduler()
	if not (zFrameSchedule) then
		d("zTime.FrameScheduler: Frame scheduler table missing or corrupt.")
		return
	end
	for k,v in pairs(zFrameSchedule) do
		if (k and v) then
			if (type(v) == "function") then
				local status, err = pcall(v)
				if not status then
					d("zTime.FrameScheduler: " .. k .. "'s function returned an error. ")
					d(err)
					zTime.DestroyFrameScheduler(k) -- remove offending schedulers from table
				end
				status, err = nil
			end
		end
	end
end

-- master time epoch updater
-- the actual epoch value is not throttled and updates once per frame (all frame schedules are also run)
-- the dispatcher and timesync'er are both throttled to prevent unecessary updates
_G["zTime_EpochUpdate"] = function(tich)
	zTich.epoch = zTich.epoch + tich
	zTich.tich = tich
	zTime.FrameScheduler()
	if (zTich.epoch > zTich.nextupdate) then -- throttle gate; prevent dispatch/timesync unless throttledelay has passed
		zTich.nextupdate = zTich.epoch + zTich.tdelay
		zTich.tdiff = zTich.epoch - zTich.lastupdate
		zTich.lastupdate = zTich.epoch
		zTime.Dispatch()
		zTime.TimeSync()
	end
end

-- onupdate registration and init to start the whole shebang
RegisterEventHandler(SystemData.Events.UPDATE_PROCESSED, "zTime_EpochUpdate")
zTime.Init()
