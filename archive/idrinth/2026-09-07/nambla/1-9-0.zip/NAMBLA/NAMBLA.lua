-- To customize this addon, look for comments starting with "CUSTOM:" in the code below, and read them.

local oldActionButtonUpdateBurning = nil
local oldActionButtonUpdateCooldownAnimation = nil
local oldActionButtonCreate = nil
local oldActionButtonUpdateKeyBindingText = nil
local oldMoraleButtonUpdate = nil
local oldActionButtonUpdateEnabledState = nil

-- taken from EA_ActionBars actionbutton.lua
local BASE_ICON         = 0
local BUTTON_TEXT       = 1
local COOLDOWN          = 2
local COOLDOWN_TIMER    = 3
local FLASH_ANIM        = 4
local ACTIVE_ANIM       = 5
local GLOW_ANIM         = 6
local STACK_COUNT_TEXT  = 7

local USE_ENABLED_ICON  = 42

local function HideButtonTextures(btn)
    -- CUSTOM: Remove any of the 4 lines below for button states in which you want the normal border to show
    ButtonSetTexture(btn, Button.ButtonState.NORMAL, "", 0, 0)
    ButtonSetTexture(btn, Button.ButtonState.HIGHLIGHTED, "", 0, 0)
    ButtonSetTexture(btn, Button.ButtonState.PRESSED, "", 0, 0)
    ButtonSetTexture(btn, Button.ButtonState.PRESSED_HIGHLIGHTED, "", 0, 0)
end

function NixAllMessyBitsLiningActionbuttons_aka_NAMBLA(btn)
    
    for barNum,barData in pairs(ActionBars.m_Bars) do
        for btnNum,btnData in ipairs(barData.m_Buttons) do
            HideButtonTextures(btnData.m_Name.."Action")
        end
    end
end

local oldSpawnActionBars

function NAMBLA_Initialize()
    RegisterEventHandler(SystemData.Events.LOADING_END, "NixAllMessyBitsLiningActionbuttons_aka_NAMBLA")
    RegisterEventHandler(SystemData.Events.RELOAD_INTERFACE, "NixAllMessyBitsLiningActionbuttons_aka_NAMBLA")
    RegisterEventHandler(SystemData.Events.ALL_MODULES_INITIALIZED,
        "NixAllMessyBitsLiningActionbuttons_aka_NAMBLA")
    RegisterEventHandler(SystemData.Events.PLAYER_CAREER_LINE_UPDATED,
        "NixAllMessyBitsLiningActionbuttons_aka_NAMBLA")
    
    oldSpawnActionBars = ActionBarClusterManager.SpawnActionBars
    ActionBarClusterManager.SpawnActionBars =
        function(...)
            oldSpawnActionBars(...)
            NixAllMessyBitsLiningActionbuttons_aka_NAMBLA()
        end
    
    oldActionButtonUpdateBurning = ActionButton.UpdateBurning
    ActionButton.UpdateBurning =
        function(...)
            oldActionButtonUpdateBurning(...)
            -- CUSTOM: remove the 6 lines below if you want the "glow" for abilities corresponding to career resource state (shaman mork/gork glow, etc)
            local self = ...
            local glowFrame = self.m_Windows[GLOW_ANIM]
            if glowFrame:IsShowing() then
                glowFrame:StopAnimation(true)
                glowFrame:Show(false)
            end
        end
        
    oldActionButtonUpdateCooldownAnimation = ActionButton.UpdateCooldownAnimation
    ActionButton.UpdateCooldownAnimation =
        function(...)
            oldActionButtonUpdateCooldownAnimation(...)
            local self = ...
            local cooldownFrame = self.m_Windows[COOLDOWN]
            local cooldownTimer = self.m_Windows[COOLDOWN_TIMER]
            local flashFrame = self.m_Windows[FLASH_ANIM]
            local iconFrame = self.m_Windows[BASE_ICON]

            -- CUSTOM: If you want the "flash" when the cooldown ends, change the line below to 1. Otherwise, leave it at 0.
            flashFrame:SetAlpha(0.0)

            if ((self.m_Cooldown > 0) and (self.m_MaxCooldown > 0)) then
                -- CUSTOM: change the number below to set how transparent the cooldown fading/piewipe is. 0 will make the fading/piewipe disappear.
                cooldownFrame:SetAlpha(0.8)
                cooldownFrame:SetTintColor(0, 0, 0)
                iconFrame:SetTintColor(100, 100, 100)

                -- CUSTOM: remove the lines below if you want the "s" on the end of button cooldown time text
                if self.m_Cooldown > 3 then
					if self.m_Cooldown >= 60 then
						cooldownTimer:SetText(wstring.format(L"%dm", math.ceil(self.m_Cooldown / 60)))
                    else
						cooldownTimer:SetText(wstring.format(L"%d", self.m_Cooldown))
					end
                else
                    cooldownTimer:SetText(wstring.format(L"%0.1f", self.m_Cooldown))
                end
                
                -- CUSTOM: Remove everything except the line with (true) in it of this block if you want the text to display for GCDs as well
                if self.m_MaxCooldown >= 1.6 then
                    -- CUSTOM: Change the 'true' below to 'false' if you don't want to force cooldown text to display
                    cooldownTimer:Show(true)
                else
                    cooldownTimer:Show(false)
                end
                
            else
                cooldownTimer:Show(false)
        
                if (self.m_IsEnabled == true) and (self.m_IsTargetValid == true) then
                    -- CUSTOM: Change the numbers below if you want to modify the color that valid target enabled skills are tinted. All 255 = White = Normal.
                    iconFrame:SetTintColor(255, 255, 255)
                elseif (self.m_IsEnabled == true) then
                    -- CUSTOM: Change the numbers below to set the color that invalid target enabled skills are tinted. Default is 200,0,0 = red.
                    iconFrame:SetTintColor(200, 0, 0)
                elseif (self.m_IsTargetValid == false) then
                    -- CUSTOM: Change the numbers below to set the color that invalid target disabled skills are tinted. Default is 100,0,0 = dark red.
                    iconFrame:SetTintColor(100, 0, 0)
                elseif self.m_IsEnabled == false then
                    texture, x, y, disabledTexture = GetIconData(self.m_IconNum)
					if disabledTexture == "" then
						-- CUSTOM: Change the numbers below to set the color that valid target disabled skills are tinted if they don't have
						-- a specific 'disabled icon. Default is 150,150,150= gray.
						iconFrame:SetTintColor(150, 150, 150)
					end
                else
                    -- Don't touch this.
                    iconFrame:SetTintColor(255, 255, 255)
                end
            end
        end
        
    oldActionButtonCreate = ActionButton.Create
    ActionButton.Create =
        function(...)
            local newButton = oldActionButtonCreate(...)
            if not newButton then return nil end
            local timerLabel = newButton.m_Windows[COOLDOWN_TIMER].m_Name
            local buttonLabel = newButton.m_Windows[BUTTON_TEXT].m_Name
            
            -- CUSTOM: remove the line below if you want the cooldown time text to be its normal size/font
            LabelSetFont(timerLabel, "font_clear_large_bold", 22)
            
            -- CUSTOM: remove the line below if you want the keybinding text to be its normal size/font
            LabelSetFont(buttonLabel, "font_clear_medium_bold", 22)
            
            WindowSetDimensions(timerLabel, WindowGetDimensions(WindowGetParent(timerLabel)))
            
            return newButton
        end
        
    oldActionButtonUpdateKeyBindingText = ActionButton.UpdateKeyBindingText
    ActionButton.UpdateKeyBindingText =
        function(...)
            oldActionButtonUpdateKeyBindingText(...)
            local self = ...
            local buttonLabel = self.m_Windows[BUTTON_TEXT].m_Name
            
            -- CUSTOM: change true to false in the line below if you don't want to see key bindings on any buttons
            WindowSetShowing(buttonLabel, true)
            
            local btnName = self.m_Name
            if btnName:sub(1,12) == "EA_ActionBar" then
                HideButtonTextures(btnName.."Action")
            end
            
        end
        
    oldActionButtonUpdateEnabledState = ActionButton.UpdateEnabledState
    ActionButton.UpdateEnabledState = function(self, ...)
        oldActionButtonUpdateEnabledState(self, ...)
        
        local iconFrame = self.m_Windows[BASE_ICON]
        
        if (self.m_IsEnabled == true) and (self.m_IsTargetValid == true) then
            -- CUSTOM: Change the numbers below if you want to modify the color that valid target enabled skills are tinted. All 255 = White = Normal.
            iconFrame:SetTintColor(255, 255, 255)
        elseif (self.m_IsEnabled == true) then
            -- CUSTOM: Change the numbers below to set the color that invalid target enabled skills are tinted. Default is 255,0,0 = red.
            iconFrame:SetTintColor(255, 0, 0)
        elseif (self.m_IsTargetValid == false) then
            -- CUSTOM: Change the numbers below to set the color that invalid target disabled skills are tinted. Default is 255,0,0 = red.
            iconFrame:SetTintColor(255, 0, 0)
        elseif self.m_IsEnabled == false then
			texture, x, y, disabledTexture = GetIconData(self.m_IconNum)
			if disabledTexture == "" then
				-- CUSTOM: Change the numbers below to set the color that valid target disabled skills are tinted if they don't have
				-- a specific 'disabled icon. Default is 150,150,150= gray.
				iconFrame:SetTintColor(150, 150, 150)
			end
        else
            -- Don't touch this.
            iconFrame:SetTintColor(255, 255, 255)
        end
        
    end
    
    -- And now, post-hook the morale buttons' Update() function
    oldMoraleButtonUpdate = MoraleButton.Update
    MoraleButton.Update = function(self, ...)
        oldMoraleButtonUpdate(self, ...)
        
        local BASE_ICON         = 2
    
        if self.m_AbilityId > 0 then
            if self.m_IsTargetValid then
                -- CUSTOM: Change the numbers below to set the color that valid target morale abilities are tinted. All 255 = White = Normal.
                self.m_Windows[BASE_ICON]:SetTintColor (255, 255, 255)
            else
                -- CUSTOM: Change the numbers below to set the color that invalid target morale abilities are tinted. Default = 255,0,0 = red.
                self.m_Windows[BASE_ICON]:SetTintColor (255, 0, 0)
            end
        end
        
    end
end
