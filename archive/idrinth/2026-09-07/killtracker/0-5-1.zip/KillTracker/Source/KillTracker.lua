--------------------------------------------------------------------------------
-- Copyright (c) 2008 Bloodwalker <metagamegeek@gmail.com>
-- 
-- Permission is hereby granted, free of charge, to any person obtaining a copy
-- of this software and associated documentation files (the "Software"), to deal
-- in the Software without restriction, including without limitation the rights
-- to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
-- copies of the Software, and to permit persons to whom the Software is
-- furnished to do so, subject to the following conditions:

-- The above copyright notice and this permission notice shall be included in
-- all copies or substantial portions of the Software.

-- THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
-- IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
-- FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
-- AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
-- LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
-- OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
-- THE SOFTWARE.
--
--------------------------------------------------------------------------------
-- File:      Source/KillTracker.lua
-- Date:      2009-02-08T04:20:19Z
-- Author:    Bloodwalker
-- Version:   Release v0.5.1
-- Revision:  32
-- File Rev:  32
-- Copyright: 2008
--------------------------------------------------------------------------------

--------------------------------------------------------------------------------
--#
--#			Local Functions and definitions
--#
--------------------------------------------------------------------------------
local LibToolkit = LibStub("LibToolkit-0.1")

local MAJOR_VER = 0.5
local MINOR_VER = 1

local CHAT_LOG_FILTER = 987
local CHAT_LOG_COLOR = DefaultColor.ORANGE

local hookShutdownPlayInterface

local windowName = "KillTrackerWindow"
local EMPTY_SIZE = {x=330, y=40}
local labelWidth = 0
local buttonWidth = 0
local rowHeight = 20
local ALIGN_RIGHT = 1
local ALIGN_LEFT = 2

local toggleName = "KillTrackerToggle"

local startOfSession = true
local startingTotals = {}

--------------------------------------------------------------------------------
--# Initialize a new chat filter so I can color KillTracker text output to
--# the chat window
--------------------------------------------------------------------------------
LibToolkit.NewChatFilter(CHAT_LOG_FILTER, CHAT_LOG_COLOR)

local function print(txt)
	LibToolkit.print(CHAT_LOG_FILTER, "[KillTracker]", txt)
end

local function PrintVersion()
	print("Loaded KillTracker Ver. " .. MAJOR_VER .. "." .. MINOR_VER)
end

--------------------------------------------------------------------------------
--#
--#			Local Window Control Functions
--#
--------------------------------------------------------------------------------


local function ShowWindow()
    WindowSetShowing( windowName, true )
	KillTracker_Options.showTracker = true
end

local function HideWindow()
    WindowSetShowing( windowName, false )
	KillTracker_Options.showTracker = false
end

local function ToggleWindow()
	if WindowGetShowing( windowName ) then
		HideWindow()
	else
		ShowWindow()
	end
end

local function RefreshButton()
    local isOpen = WindowGetShowing( windowName )
    
    ButtonSetPressedFlag( toggleName .. "ButtonOpen",   isOpen)
    ButtonSetPressedFlag( toggleName .. "ButtonClosed", isOpen)
end

local function ResetWindowAnchor()
	--[===[@alpha@
	d("Resetting Tracker Anchor")
	--@end-alpha@]===]

    WindowClearAnchors ( windowName )

	local anchor
	if 	KillTracker_Options.aligned == ALIGN_LEFT then
		anchor = { Point = "topleft",
					 RelativeTo = "Root",
					 RelativePoint = "topleft",
					 XOffset = 255,
					 YOffset = 305, }
	else
		anchor = { Point = "topright",
					 RelativeTo = "Root",
					 RelativePoint = "topright",
					 XOffset = -255,
					 YOffset = 305, }
	end

	WindowAddAnchor( windowName, anchor.Point, anchor.RelativeTo, anchor.RelativePoint, anchor.XOffset, anchor.YOffset ) 

end

local function UpdateTrackerWindowSize()

	--[===[@alpha@
	d("KillTracker Update Window Size")
	--@end-alpha@]===]
	local totalHeight = 0

    if( KillTracker.Player.species[1] == nil ) then    
        -- Set the Empty size so the window container still appears for the layout editor.
        WindowSetDimensions( windowName, EMPTY_SIZE.x, EMPTY_SIZE.y)
        return
    end

    -- Resize the individual data windows and components
    for rowNumber = 1, KillTracker_Options.trackSpecies do
   		local rowName = windowName .. "Data" .. rowNumber
   		if( WindowGetShowing(rowName) == true ) then
			WindowSetDimensions( rowName .. "Name", buttonWidth, rowHeight )
			WindowSetDimensions( rowName .. "KillCount", labelWidth, rowHeight )
			-- Another bug fix, if we resize the TEXT pops out above the label instead of inside, so we relabel after resizing
			LabelSetText(rowName .. "KillCount", LabelGetText(rowName .. "KillCount"))
			WindowSetDimensions( rowName, buttonWidth + labelWidth, rowHeight )
			totalHeight = totalHeight + rowHeight
   		end
	end

	-- Resize the top level container and tracker window
	WindowSetDimensions( windowName, 
						buttonWidth + labelWidth,
						totalHeight )
	
end

local function UpdateTrackerWindow()

	--[===[@alpha@
	d("Updating Kill Tracking Window")
	--@end-alpha@]===]
	local rowWindowName = windowName .. "Data"
	local maxLabelWidth = 0
	local maxButtonWidth = 0
	local killCountLabel = ""
	local speciesButton = ""
	for rowCounter = 1, KillTracker_Options.trackSpecies do
		if (KillTracker.Player.species[rowCounter] ~= nil) then
			local speciesId = KillTracker.Player.species[rowCounter]
			local speciesInfo = TomeGetBestiarySpeciesData( speciesId )
			local countText
			if KillTracker_Options.sessionTracker then
--[[
			if not startingTotals[speciesId] then
					startingTotals[speciesId] = speciesInfo.killCount
				end
--]]
				countText = speciesInfo.killCount - startingTotals[speciesId]
			else
				countText = speciesInfo.killCount
			end
			WindowSetShowing(rowWindowName .. rowCounter, true)

			killCountLabel = rowWindowName .. rowCounter .. "KillCount"
			speciesButton = rowWindowName .. rowCounter .. "Name"
			killCountText = " " .. countText

			LabelSetText( killCountLabel , towstring(killCountText) )

			-- Autoresize works fine getting smaller but not larger so we make sure we start large
			WindowSetDimensions( speciesButton, 400, rowHeight )
			ButtonSetText( speciesButton, speciesInfo.name)
			local labelX, _ = LabelGetTextDimensions( killCountLabel )
			local buttonX, _ = ButtonGetTextDimensions( speciesButton )
			if (maxLabelWidth < labelX) then
				maxLabelWidth = labelX
			end
			if (maxButtonWidth < buttonX) then
				maxButtonWidth = buttonX
			end
		else
			-- if we have nothing to Show Hide the row
			WindowSetShowing(rowWindowName .. rowCounter, false)
		end
	end
	-- Make sure to Hide any unused rows
	for rowCounter = KillTracker_Options.trackSpecies + 1, 10 do
		WindowSetShowing(rowWindowName .. rowCounter, false)
		KillTracker.Player.species[rowCounter] = nil
	end
	-- Another bug fix, the width is a few pixel shy so we add a few to the reported numbers
	labelWidth = maxLabelWidth + 5
	buttonWidth = maxButtonWidth + 5

	UpdateTrackerWindowSize()

end

local function UpdateTracker()

	--[===[@alpha@
	d("Updating Kill Tracking List")
	--@end-alpha@]===]

	local speciesId = GameData.Bestiary.updatedSpecies
	local oldKillTracker = KillTracker.Player.species
	local newKillTracker = {}
	local rowCount = 1
	local maxSpecies = KillTracker_Options.trackSpecies

	newKillTracker[rowCount] = speciesId
	if not startingTotals[speciesId] then
		local speciesInfo = TomeGetBestiarySpeciesData( speciesId )			
		startingTotals[speciesId] = speciesInfo.killCount - 1
	end

	for trackerIndex, killedId in ipairs(oldKillTracker) do
		if (killedId ~= speciesId) then
			rowCount = rowCount + 1
			newKillTracker[rowCount] = killedId
			if not startingTotals[killedId] then
				local speciesInfo = TomeGetBestiarySpeciesData( killedId )			
				startingTotals[killedId] = speciesInfo.killCount - 1
			end
			if (rowCount == maxSpecies) then break end
		end
	end

	KillTracker.Player.species = newKillTracker

	UpdateTrackerWindow()
end

local function CreateTrackerWindow( aligned )

	--[===[@alpha@
	d("Creating Tracker Window")
	--@end-alpha@]===]
	if DoesWindowExist( windowName) then
		DestroyWindow( windowName )
		DestroyWindow( toggleName )
		LayoutEditor.UnregisterWindow( windowName )
	end
	local templateWindow
	local anchors
	local toggleAnchor
	if aligned == ALIGN_LEFT then
		templateWindow = "KillTrackerWindowLeft"
		anchors = { "topleft" }
		toggleAnchor = { point = "topleft", relativeTo = windowName, relativePoint = "topleft", xoffset = 0, yoffset = -38 }
		KillTracker_Options.aligned = ALIGN_LEFT
	else
		templateWindow = "KillTrackerWindowRight"
		anchors = { "topright" }
		toggleAnchor = { point = "topright", relativeTo = windowName, relativePoint = "topright", xoffset = 0, yoffset = -38 }
		KillTracker_Options.aligned = ALIGN_RIGHT
	end
	
	CreateWindowFromTemplate( windowName, templateWindow, "Root" )
	WindowSetShowing( windowName, KillTracker_Options.showTracker )
	
	-- Setup toggle button
	CreateWindow( toggleName , KillTracker_Options.showToggle )
    ButtonSetStayDownFlag( toggleName .. "ButtonOpen",   true)
    ButtonSetStayDownFlag( toggleName .. "ButtonClosed", true)
	WindowClearAnchors( toggleName )
	WindowAddAnchor( toggleName, toggleAnchor.point, toggleAnchor.relativeTo, toggleAnchor.relativePoint, toggleAnchor.xoffset, toggleAnchor.yoffset ) 
	RefreshButton()
	
	-- Register the tracker window with the Layout Editor
	LayoutEditor.RegisterWindow( windowName,
                                L"Kill Tracker - Species Window",
                                L"Kill Tracking Window for Recently Killed Species",
                                false, false,
                                false, nil,
								anchors )

	-- if we dont have an anchor set new anchor
	local anchorCount = WindowGetAnchorCount(windowName)
	if anchorCount == 0 then
		if KillTracker_Options.lastAnchor then
			local anchor = KillTracker_Options.lastAnchor
			WindowClearAnchors( windowName )
			WindowAddAnchor( windowName, anchor.point, anchor.relativeTo, anchor.relativePoint, anchor.xoffset, anchor.yoffset ) 
		else
			ResetWindowAnchor()
		end
	end

end

local function GetCurrentKills()
	--[===[@alpha@
	d("Getting current kill totals from tome")
	--@end-alpha@]===]
	startingTotals = {}
	for index, speciesId in pairs(KillTracker.Player.species) do
		local success, data = pcall(TomeGetBestiarySpeciesData, speciesId)
		if success then
			startingTotals[speciesId] = data.killCount
		end
	end
end
--------------------------------------------------------------------------------
--# Tome Window interaction functions
--#
--------------------------------------------------------------------------------
local function OpenTomeToSpecies( speciesId )
    local params = { speciesId }
    TomeWindow.SetState( TomeWindow.PAGE_BESTIARY_SPECIES_INFO, params )
end

local function TomeIsShowingSpecies( speciesId )

    return TomeWindow.currentState.pageType == TomeWindow.PAGE_BESTIARY_SPECIES_INFO 
            and speciesId == TomeWindow.currentState.params[1]
end

--------------------------------------------------------------------------------
--#
--#			Global Functions for internal use
--#
--------------------------------------------------------------------------------

KillTracker = {}

function KillTracker.Initialize()

	d("Initializing KillTracker ver " .. MAJOR_VER .. "." .. MINOR_VER)
	-- init addon options
	if not KillTracker_Options then
		KillTracker_Options = {}
	end

	if not KillTracker_Options.trackSpecies then
		KillTracker_Options.trackSpecies = 5 -- default to 5
	end
	if not KillTracker_Options.aligned then
		KillTracker_Options.aligned = ALIGN_RIGHT -- default to right aligned window
	end
	if KillTracker_Options.showTracker == nil then
		KillTracker_Options.showTracker = true -- default to show the tracker
	end
	if KillTracker_Options.showToggle == nil then
		KillTracker_Options.showToggle = true -- default to show the toggle
	end
	if KillTracker_Options.sessionTracker == nil then
		KillTracker_Options.sessionTracker = false -- default to tracking totals
	end

	-- init players saved data
	if not KillTracker_Saved then
		KillTracker_Saved = {}
	end

	local PlayerIdentity = LibToolkit.Clean.ServerName .. ":" .. LibToolkit.Clean.PlayerName
	if not KillTracker_Saved[PlayerIdentity] then
		KillTracker_Saved[PlayerIdentity] = {}
	end

	KillTracker.Player = KillTracker_Saved[PlayerIdentity]

	if not KillTracker.Player.species then
		KillTracker.Player.species = {}
	end

	-- Create the killtracker
	if KillTracker_Options.aligned == ALIGN_LEFT then
		CreateTrackerWindow( ALIGN_LEFT )
	else
		CreateTrackerWindow( ALIGN_RIGHT )
	end
	
	-- hook InterfaceCore.ShutdownPlayInterface
	hookShutdownPlayInterface = InterfaceCore.ShutdownPlayInterface
	InterfaceCore.ShutdownPlayInterface = KillTracker.OnShutdown

    RegisterEventHandler( SystemData.Events.LOADING_BEGIN, "KillTracker.DisableUpdates" )
	RegisterEventHandler( SystemData.Events.LOADING_END, "KillTracker.EnableUpdates" )
	RegisterEventHandler( SystemData.Events.INTERFACE_RELOADED, "KillTracker.EnableUpdates" )

	-- Register slash command for kill tracker	
	LibSlash.RegisterSlashCmd("killtracker", KillTracker.SlashHandler)
    LibSlash.RegisterSlashCmd("kt", KillTracker.SlashHandler)

	PrintVersion()

end

--------------------------------------------------------------------------------
--#
--#			Global Event Handler Functions
--#
--------------------------------------------------------------------------------

function KillTracker.OnShutdown(...)

	--[===[@alpha@
	d("KillTracker Pre-Shutdown")
	--@end-alpha@]===]
	local point, relativePoint, relativeTo, xoffset, yoffset = WindowGetAnchor( windowName, 1 )
	KillTracker_Options.lastAnchor = {}
	KillTracker_Options.lastAnchor.point = point
	KillTracker_Options.lastAnchor.relativePoint = relativePoint
	KillTracker_Options.lastAnchor.relativeTo = relativeTo
	KillTracker_Options.lastAnchor.xoffset = xoffset
	KillTracker_Options.lastAnchor.yoffset = yoffset
	
	return hookShutdownPlayInterface(...)
end

function KillTracker.EnableUpdates()

	--[===[@alpha@
	d("KillTracker Enable Events")
	--@end-alpha@]===]
    RegisterEventHandler(SystemData.Events.TOME_BESTIARY_SPECIES_KILL_COUNT_UPDATED, "KillTracker.OnBestiarySpeciesKillCountUpdated")

	if startOfSession then
		startOfSession = false
		GetCurrentKills()
	end
	UpdateTrackerWindow()

end

function KillTracker.DisableUpdates()

	--[===[@alpha@
	d("KillTracker Disable Events")
	--@end-alpha@]===]
    UnregisterEventHandler(SystemData.Events.TOME_BESTIARY_SPECIES_KILL_COUNT_UPDATED, "KillTracker.OnBestiarySpeciesKillCountUpdated")

end

function KillTracker.OnBestiarySpeciesUpdated()
	-- this only gets fired when we delayed a kill count update
	--[===[@alpha@
	d("KillTracker Bestiary Species Updated")
	--@end-alpha@]===]
	local speciesId = GameData.Bestiary.updatedSpecies
	local speciesInfo = TomeGetBestiarySpeciesData( speciesId )
  
	if (speciesInfo.killCount > 0) then
		UpdateTracker()
	end
	UnregisterEventHandler(SystemData.Events.TOME_BESTIARY_SPECIES_UPDATED, "KillTracker.OnBestiarySpeciesUpdated")
end


function KillTracker.OnBestiarySpeciesKillCountUpdated()

	--[===[@alpha@
	d("KillTracker Updating Species Kill Count")
	--@end-alpha@]===]
	local speciesId = GameData.Bestiary.updatedSpecies
    
    -- Is the species unlocked? if not a species update will follow do our kill update then
    if not TomeIsBestiarySpeciesUnlocked( speciesId ) then
   		RegisterEventHandler(SystemData.Events.TOME_BESTIARY_SPECIES_UPDATED, "KillTracker.OnBestiarySpeciesUpdated")
		return
    end

	UpdateTracker()

end

function KillTracker.OpenTome()

	--[===[@alpha@
	d("KillTracker Opening Tome Window")
	--@end-alpha@]===]

    local windowId = WindowGetId( WindowGetParent( SystemData.ActiveWindow.name ) )
    local speciesId = KillTracker.Player.species[windowId]
    
    -- If we are clicking the same killCount button, hide the Tome
    if( WindowGetShowing( "TomeWindow" ) == false  ) then
        MenuBarWindow.ToggleTomeWindow()
    elseif( TomeIsShowingSpecies( speciesId ) == true ) then
        MenuBarWindow.ToggleTomeWindow()
        return
    end
    OpenTomeToSpecies( speciesId )
    
end

--------------------------------------------------------------------------------
--# Toggle Button Event Handlers
--#
--------------------------------------------------------------------------------
function KillTracker.Toggle()
	ToggleWindow()
	RefreshButton()
end

function KillTracker.SlashHandler(args)
	--[===[@alpha@
	d("slashHandler args=" .. args)
	--@end-alpha@]===]
	local cmd = StringSplit(args)
	if (cmd[1] == "species") then
		-- Report current number of species tracked
		if not cmd[2] then
			print("Currently tracking last " .. KillTracker_Options.trackSpecies .. " species killed")
			return
		end
		local option = tonumber(cmd[2])
		-- limit max to 10
		if (option > 10) then
			option = 10
		-- limit min to 5
		elseif (option < 5) then
			option = 5
		end
		KillTracker_Options.trackSpecies = option
		print("Now tracking the last " .. option .. " species killed")
		UpdateTrackerWindow()
	elseif (cmd[1] == "track") then
		if cmd[2] == "session" then
			KillTracker_Options.sessionTracker = true
		elseif cmd[2] == "tome" then
			KillTracker_Options.sessionTracker = false
		else
			local tracking
			if KillTracker_Options.sessionTracker then
				tracking = "by play session"
			else
				tracking = "by ToK totals"
			end
			print("Currently tracking kills " .. tracking)
			return
		end
		UpdateTrackerWindow()
	elseif (cmd[1] == "align") then
		if cmd[2] == "left" then
			CreateTrackerWindow( ALIGN_LEFT )
			ResetWindowAnchor()
			UpdateTrackerWindow()
		elseif cmd[2] == "right" then
			CreateTrackerWindow( ALIGN_RIGHT )
			ResetWindowAnchor()
			UpdateTrackerWindow()
		else
			local side
			if KillTracker_Options.aligned == ALIGN_LEFT then
				side = "LEFT"
			else
				side = "RIGHT"
			end
			print("KillTracker window currently aligned to the " .. side)
			return
		end
	elseif cmd[1] == "button" then
		local showText
		if cmd[2] == "on" then
			KillTracker_Options.showToggle = true
			WindowSetShowing( toggleName, KillTracker_Options.showToggle)
		elseif cmd[2] == "off" then
			KillTracker_Options.showToggle = false
			WindowSetShowing( toggleName, KillTracker_Options.showToggle)
		else
			if KillTracker_Options.showToggle then
				showText = "Showing"
			else
				showText = "Hidden"
			end
			print("KillTracker Toggle Button: " .. showText)
			return		
		end
	elseif (cmd[1] == "version" or cmd[1] == "ver") then
		PrintVersion()
	elseif (cmd[1] == "toggle" or cmd[1] == "tog") then
		ToggleWindow()
	elseif (cmd[1] == "on" or cmd[1] == "show") then
		ShowWindow()
		print("Showing KillTracker Window")
	elseif (cmd[1] == "off" or cmd[1] == "hide") then
		HideWindow()
		print("Hiding KillTracker Window")
	elseif (cmd[1] == "reset") then
		ShowWindow()
		ResetWindowAnchor()
	    print("Resetting Kill Tracker position")
	else -- Generic help
		print("KillTracker Kill Tracker Help:")
		print("  /killtracker [command [option]] or /kt")
		print("    on|off  - Shows or Hides the Kill Tracker window")
		print("    toggle  - Toggle showing the Kill Tracker window")
		print("    button [on|off] - Toggle showing the Kill Tracker Toggle button")
		print("    align [left|right] - Set KillTracker Window to left or right hand justified display")
		print("    reset   - Resets Kill Tracker window back to the original position")
		print("    species [number] - Set number of species to track (min 5, max 10), will report the current number of species tracked if [number] not supplied")
		print("    track [session|tome] - Track kills by session or by total kills from the Tome of Knowledge")
		print("    version - Print the current KillTracker version to chat window")
	end

end
