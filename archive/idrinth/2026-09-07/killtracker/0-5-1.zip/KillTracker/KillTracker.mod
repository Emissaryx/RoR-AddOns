<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
	<UiMod name="KillTracker" version="0.5.1" date="31/12/2008">
		<Author name="Bloodwalker" email="metagamegeek@gmail.com" />
		<Description text="Kill Tracker window for Recently Killed Species" />
		<Dependencies>
			<Dependency name="EA_ChatWindow"/>
			<Dependency name="EA_TomeOfKnowledge"/>
			<Dependency name="LibSlash"/>
		</Dependencies>
		<Files>
			<File name="Libs/LibStub.lua" />
			<File name="Libs/LibToolkit.lua" />
			<File name="Source/KillTracker.lua" />
			<File name="Source/KillTracker.xml" />
		</Files>
		<OnInitialize>
			<CallFunction name="KillTracker.Initialize" />
		</OnInitialize>
		<SavedVariables>
			<SavedVariable name="KillTracker_Options" />
			<SavedVariable name="KillTracker_Saved" />
		</SavedVariables>
	</UiMod>
</ModuleFile>