VPBreakdown = {}
local lineWidth = 24
local lineOffset = 10
VPBreakdown.orderPer = 0
VPBreakdown.destroPer = 0
VPBreakdown.orderVP = 0
VPBreakdown.destroVP = 0

local contributions = {
	[1] = {40, 40, 20, 0, 0},
	[2] = {45, 35, 20, 0, 0},
	[3] = {45, 35, 20, 0, 0},
	[4] = {45, 30, 25, 0, 0},
	[5] = {100, 0, 0, 0, 0}
	}

function VPBreakdown.Initialize()
	DEBUG (towstring("VP Breakdown Loaded"))

	if(VPBreakdown.Opt == nil) then
		VPBreakdown.Opt = { }
		VPBreakdown.Opt.Showing = 1
	end

	LibSlash.RegisterSlashCmd("vpb", function(args) VPBreakdown.HandleSlash(args) end)

	if ( EA_Window_ZoneControl ~= nil ) and ( WindowGetShowing("EA_Window_ZoneControl") == true ) then 
		WindowRegisterCoreEventHandler("EA_Window_ZoneControl", "OnLButtonUp", "VPBreakdown.ShowWindow") 
		WindowRegisterCoreEventHandler("EA_Window_ZoneControl", "OnRButtonUp", "VPBreakdown.HideWindow") 
	end
 
    	RegisterEventHandler(SystemData.Events.ZONE_CONTROL_DETAIL_AMOUNTS_UPDATED, "VPBreakdown.UpdateDetailAmounts")
    	RegisterEventHandler(SystemData.Events.PLAYER_ZONE_CHANGED,                 "VPBreakdown.UpdateDetailAmounts")
	RegisterEventHandler(SystemData.Events.INTERFACE_RELOADED, "VPBreakdown.UpdateDetailAmounts")
	RegisterEventHandler(SystemData.Events.ENTER_WORLD, "VPBreakdown.UpdateDetailAmounts")
	RegisterEventHandler(SystemData.Events.LOADING_END, "VPBreakdown.UpdateDetailAmounts")

	VPBreakdown.CreateWindow()
end

function VPBreakdown.CreateWindow()
	CreateWindow("VPBreakdownWindow", false)
	LayoutEditor.RegisterWindow(	 "VPBreakdownWindow",
						L"VPBreakdownWindow",
						L"VP Breakdown",
						false, false, true, nil)

	WindowAddAnchor("VPBreakdownWindowLine1", "topleft", "VPBreakdownWindow", "topleft", 0, lineWidth+lineOffset)
	LabelSetText("VPBreakdownWindowLine1Name", L"Objectives")

	WindowAddAnchor("VPBreakdownWindowLine2", "topleft", "VPBreakdownWindow", "topleft", 0, 2*lineWidth+lineOffset)
	LabelSetText("VPBreakdownWindowLine2Name", L"Scenarios")

	WindowAddAnchor("VPBreakdownWindowLine3", "topleft", "VPBreakdownWindow", "topleft", 0, 3*lineWidth+lineOffset)
	LabelSetText("VPBreakdownWindowLine3Name", L"Skirmish")

	WindowAddAnchor("VPBreakdownWindowLine6", "topleft", "VPBreakdownWindow", "topleft", 0, 4*lineWidth+lineOffset)
	LabelSetText("VPBreakdownWindowLine6Name", L"Total")
	
	WindowSetShowing("VPBreakdownWindow", false)
end

function VPBreakdown.GetDetailAmounts(realm)
    	local returnArray = {}
    	returnArray[1], returnArray[2], returnArray[3], returnArray[4], returnArray[5] = GetZoneControlDetailAmounts(realm)
	return returnArray
end

function VPBreakdown.UpdateDetailAmounts()	
	local canShow = VPBreakdown.AllowedToShowDetailWindow()
	
	if(VPBreakdown.Opt.Showing == 1) then
		if(canShow) then
			VPBreakdown.ShowWindow()
		else
			VPBreakdown.TempHideWindow()
		end
	else
		VPBreakdown.HideWindow()
	end
end

function VPBreakdown.UpdateDetailLabels()
	local currentTier
	
	if(VPBreakdown.InContestedCity()) then
		currentTier = 5
	else
		currentTier = GetZoneTier()
	end
	
	local tierContribution = contributions[currentTier]

	LabelSetText("VPBreakdownWindowLine1Cont", towstring("(") .. towstring(tierContribution[1]) .. towstring(")"))
	LabelSetText("VPBreakdownWindowLine2Cont", towstring("(") .. towstring(tierContribution[2]) .. towstring(")"))
	LabelSetText("VPBreakdownWindowLine3Cont", towstring("(") .. towstring(tierContribution[3]) .. towstring(")"))
	LabelSetText("VPBreakdownWindowLine6Cont", towstring("(100)"))
	
	LabelSetText("VPBreakdownWindowTitle", towstring(GetZoneName(GameData.Player.zone)))

	local orderControl = VPBreakdown.GetDetailAmounts(GameData.Realm.ORDER)
    	local destructionControl = VPBreakdown.GetDetailAmounts(GameData.Realm.DESTRUCTION)
	
	local orderObj = orderControl[3] * (tierContribution[1]/100)
	local orderScen = orderControl[1] * (tierContribution[2]/100)
	local orderSkir = orderControl[2] * (tierContribution[3]/100)	
	local orderTotal = orderObj + orderScen + orderSkir

	LabelSetText("VPBreakdownWindowLine1OrderVP", towstring(wstring.format(L"%0.2f",orderObj)))
	LabelSetText("VPBreakdownWindowLine2OrderVP", towstring(wstring.format(L"%0.2f",orderScen)))
	LabelSetText("VPBreakdownWindowLine3OrderVP", towstring(wstring.format(L"%0.2f",orderSkir)))
	LabelSetText("VPBreakdownWindowLine6OrderVP", towstring(wstring.format(L"%0.2f",orderTotal)))
	LabelSetText("VPBreakdownWindowLine1OrderPer", GetStringFormat(StringTables.Default.GENERIC_PERCENTAGE, { orderControl[3] }))
	LabelSetText("VPBreakdownWindowLine2OrderPer", GetStringFormat(StringTables.Default.GENERIC_PERCENTAGE, { orderControl[1] }))
	LabelSetText("VPBreakdownWindowLine3OrderPer", GetStringFormat(StringTables.Default.GENERIC_PERCENTAGE, { orderControl[2] }))


	local destroObj = destructionControl[3] * (tierContribution[1]/100)
	local destroScen = destructionControl[1] * (tierContribution[2]/100)
	local destroSkir = destructionControl[2] * (tierContribution[3]/100)
	local destroTotal = destroObj + destroScen + destroSkir
	
	LabelSetText("VPBreakdownWindowLine1DestroVP", towstring(wstring.format(L"%0.2f",destroObj)))
	LabelSetText("VPBreakdownWindowLine2DestroVP", towstring(wstring.format(L"%0.2f",destroScen)))
	LabelSetText("VPBreakdownWindowLine3DestroVP", towstring(wstring.format(L"%0.2f",destroSkir)))
	LabelSetText("VPBreakdownWindowLine6DestroVP", towstring(wstring.format(L"%0.2f",destroTotal)))
	LabelSetText("VPBreakdownWindowLine1DestroPer", GetStringFormat(StringTables.Default.GENERIC_PERCENTAGE, { destructionControl[3] }))
	LabelSetText("VPBreakdownWindowLine2DestroPer", GetStringFormat(StringTables.Default.GENERIC_PERCENTAGE, { destructionControl[1] }))
	LabelSetText("VPBreakdownWindowLine3DestroPer", GetStringFormat(StringTables.Default.GENERIC_PERCENTAGE, { destructionControl[2] }))

	local orderPercent, destroPercent = VPBreakdown.GetTotalPercent(orderTotal, destroTotal)
	
	LabelSetText("VPBreakdownWindowOrder", wstring.format(L"%0.1f", orderPercent) .. towstring("%"))
	LabelSetText("VPBreakdownWindowDestro", wstring.format(L"%0.1f", destroPercent) .. towstring("%"))
end

function VPBreakdown.HandleSlash(args)
	local opt, val = args:match("([a-z0-9]+)[ ]?(.*)")
	
	if(not opt) then
		if(VPBreakdown.AllowedToShowDetailWindow()) then
			if(VPBreakdown.Opt.Showing == 1 and WindowGetShowing("VPBreakdownWindow")) then
				VPBreakdown.HideWindow()	
			elseif(VPBreakdown.Opt.Showing == 0) then
				VPBreakdown.ShowWindow()
			end
		else
			VPBreakdown.TempHideWindow()
		end
	elseif(opt == "tell") then
		VPBreakdown.SendMessage(val)
	end
end

function VPBreakdown.GetTotalPercent(ordervp, destvp)
	local orderRating, destRating = GetUnderdogRatings()

	local orderper
	local destper

	if(GetZoneTier() == 4) then
		if(orderRating == 3) then
			orderper = ordervp/75
			destper = destvp/55
		end
		if(orderRating == 2) then
			orderper = ordervp/70
			destper = destvp/60
		end
		if(orderRating == 1) then
			orderper = ordervp/65
			destper = destvp/65
		end
		if(orderRating == 0) then
			orderper = ordervp/65
			destper = destvp/65
		end
		if(orderRating == -1) then
			orderper = ordervp/65
			destper = destvp/65
		end
		if(orderRating == -2) then
			orderper = ordervp/60
			destper = destvp/70
		end
		if(orderRating == -3) then
			orderper = ordervp/55
			destper = destvp/75
		end
	else
		orderper = ordervp/65
		destper = destvp/65
	end

	local orderReturn = 100 * orderper
	local destReturn = 100 * destper

	VPBreakdown.orderVP = ordervp
	VPBreakdown.destroVP = destvp
	VPBreakdown.orderPer = orderReturn
	VPBreakdown.destroPer = destReturn

	return orderReturn, destReturn
end

function VPBreakdown.ShowWindow()
	WindowSetShowing("EA_Window_ZoneControlDetailWindow", false)
	WindowSetShowing("VPBreakdownWindow", true)
	VPBreakdown.UpdateDetailLabels()
	VPBreakdown.Opt.Showing = 1
end

function VPBreakdown.HideWindow()
	WindowSetShowing("VPBreakdownWindow", false)
	VPBreakdown.Opt.Showing = 0
end

function VPBreakdown.TempHideWindow()
	WindowSetShowing("VPBreakdownWindow", false)
end

function VPBreakdown.InContestedCity()
    	local instanceIdData = GetCityInstanceId()
    	return (instanceIdData.instanceId > 1)
end

function VPBreakdown.AllowedToShowDetailWindow()
	if (GameData.Player.City.id ~= 0) then
       	return false
    	end

	if (VPBreakdown.InContestedCity()) then
		return false
	end
    
   	local zoneData = nil
    	if (GameData.Player.zone > 0) then
	      local parentMap = MapGetParentMap( GameDefs.MapLevel.ZONE_MAP, GameData.Player.zone )
      	if parentMap ~= nil and parentMap.mapNumber < GameData.ExpansionMapRegion.FIRST then
			zoneData = GetCampaignZoneData( GameData.Player.zone )    
      	end
    	end
    	return (zoneData ~= nil)
end

function VPBreakdown.SendMessage(channel)
	local message

	message = L"/"..towstring(channel)..L" "..towstring(GetZoneName(GameData.Player.zone))..L": Order has "..towstring(wstring.format(L"%0.2f",VPBreakdown.orderVP))..L" VP for "..towstring(wstring.format(L"%0.1f",VPBreakdown.orderPer))..L"%.  Destruction has "..towstring(wstring.format(L"%0.2f",VPBreakdown.destroVP))..L" VP for "..towstring(wstring.format(L"%0.1f",VPBreakdown.destroPer))..L"%."
	SendChatText(towstring(message),L"")
end
