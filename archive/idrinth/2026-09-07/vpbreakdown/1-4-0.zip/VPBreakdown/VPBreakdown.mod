<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
	<UiMod name="VPBreakdown" version="1.4a" date="09/25/2010" >

		<Author name="Serapis" email="" />
		<Description text="A more accurate breakdown of your current zone's VP" />
		
		<VersionSettings gameVersion="1.3.6" />
		
        	<Dependencies>
			<Dependency name="LibSlash" />
			<Dependency name="EA_ChatWindow" />
			<Dependency name="EA_ZoneControlWindow" />
        	</Dependencies>
        
		<Files>
			<File name="VPBreakdown.lua" />
			<File name="VPBreakdown.xml" />
		</Files>
		<SavedVariables>
			<SavedVariable name="VPBreakdown.Opt" />
		</SavedVariables>
		
		<OnInitialize>
           		<CallFunction name="VPBreakdown.Initialize" />
		</OnInitialize>
		<OnUpdate />
		<OnShutdown />
	</UiMod>
</ModuleFile>
