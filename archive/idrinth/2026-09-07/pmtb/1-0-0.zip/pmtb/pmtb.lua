
PMTB = {}
local PMTB = PMTB

-- local constants
local last_morale_level = 0
local global_cooldown = 1.4
local GetMoraleCooldown = GetMoraleCooldown

--Called when Addon loaded
function PMTB:OnInitialize()
  RegisterEventHandler(SystemData.Events.PLAYER_MORALE_UPDATED, "PMTB.PLAYER_MORALE_UPDATED")
end


--Player Morale
function PMTB.PLAYER_MORALE_UPDATED(moralePercent, moraleLevel)
  if (moraleLevel > last_morale_level) and
     (moraleLevel == 1  or
      moraleLevel == 2  or
      moraleLevel == 3  or
      moraleLevel == 4 )
  then
    local cd, mcd = GetMoraleCooldown(moraleLevel)
    local _, id = GetMoraleBarData (moraleLevel)
    if (cd < global_cooldown) and id then
      if moraleLevel == 2 then
	  SendChatText(towstring("/wb <LINK data=\"0\" text=\"MORAL 2 READY! \" color=\"255,0,255\">"), L"")		
	  end
	  if moraleLevel == 4 then
	  SendChatText(towstring("/wb <LINK data=\"0\" text=\"MORAL 4 READY! \" color=\"255,255,0\">"), L"")		
	  end
    end
  end
  last_morale_level = moraleLevel
end


