<?xml version="1.0" encoding="UTF-8"?>

<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" >

	<UiMod name="PMTB" version="1.0" date="12.02.2018" >

		<Author name="Kaorich" email="" />
		
		<VersionSettings gameVersion="1.4.1" windowsVersion="1.0" savedVariablesVersion="1.0" />

		<Description text="Phalanx moral tracker for BWs" />

		<Dependencies>
		</Dependencies>

		<Files>
			<File name="pmtb.xml" />
			<File name="pmtb.lua" />
		</Files>

		<OnInitialize>
			<CallFunction name="PMTB.OnInitialize" />
		</OnInitialize>

		<OnUpdate>
		</OnUpdate>

		<OnShutdown>
		</OnShutdown>

		<SavedVariables>
		</SavedVariables>

	</UiMod>

</ModuleFile>