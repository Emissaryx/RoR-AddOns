<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
    <UiMod name="FlagCap" version="1.0" date="11/2/2021">
        <Author name="Sullemunk" />
        <Description text="A scenario flagcap tracker" />
         <Dependencies>
            <Dependency name="EA_ObjectiveTrackers" />
        </Dependencies>
 
        <Files>
            <File name="FlagCap.lua" />
			<File name="FlagCap.xml" />
        </Files>
		
        <OnInitialize>
            <CallFunction name="FlagCap.OnInitialize" />
        </OnInitialize>

		<OnUpdate>
		<CallFunction name="FlagCap.OnUpdate" />
    	</OnUpdate>
	
        <OnShutdown>
			<CallFunction name="FlagCap.OnShutdown" />
		</OnShutdown>
    </UiMod>
</ModuleFile>