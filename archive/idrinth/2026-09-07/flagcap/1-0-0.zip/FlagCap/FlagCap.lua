FlagCap = {}
local version = 1.0
local prevPoint = 0
local prevCapPoint = 0
local PlayerRealm
local targetFrame = "FlagCapWindow"

function FlagCap.OnInitialize()
RegisterEventHandler( SystemData.Events.OBJECTIVE_CONTROL_POINTS_UPDATED, "FlagCap.OnPointUpdate" )
RegisterEventHandler( SystemData.Events.OBJECTIVE_OWNER_UPDATED, "FlagCap.OnPointUpdate" )
CreateWindow(targetFrame,false)
StatusBarSetMaximumValue( targetFrame.."ControlBar", 100 )
PlayerRealm = GameData.Player.realm

FlagCap.Color = {[0]=DefaultColor.RealmColors[0],[1]=DefaultColor.RealmColors[1],[2]=DefaultColor.RealmColors[2]}	--Realm color
FlagCap.InvColor = {[0]=DefaultColor.RealmColors[0],[1]=DefaultColor.RealmColors[2],DefaultColor.RealmColors[1]}	--Inverted Realm color

LayoutEditor.RegisterWindow( "FlagCapWindow", L"FlagCapWindow", L"FlagCapWindow", false, false, true, nil )
LayoutEditor.RegisterEditCallback(FlagCap.OnLayoutEditorFinished)	--makes sure that the window is hidden if the player aborts the layout editor
end

function FlagCap.OnPointUpdate(ObjNumber)
if not GameData.Player.isInScenario	then return end
local ObjectiveData = GetActiveObjectivesData()
	if ObjectiveData == nil then return end
	if ObjectiveData[1] == nil then return end
	if ObjectiveData[1].isCapturePoint == false then return end
	local mirror = false

	ObjectiveData = ObjectiveData[1]

	if tonumber(ObjectiveData.id) == tonumber(ObjNumber) then
        local controlBarWindow = targetFrame.."ControlBar"
        local controllPoints = ObjectiveData.curControlPoints
        local controlFill = math.abs(controllPoints)
		
		
        StatusBarSetCurrentValue( controlBarWindow, controlFill )
        
		--mirror false = <-
	local CapRealm = GameData.Realm.NONE
		if ObjectiveData.controllingRealm == GameData.Realm.NONE then
			
			   if ( controllPoints < 0 ) then
			   
			   
					if controllPoints < prevCapPoint then
						CapRealm = GameData.Realm.ORDER
						mirror = true
					elseif controllPoints > prevCapPoint then
						CapRealm = GameData.Realm.DESTRUCTION
						mirror = false
						
					elseif controllPoints == prevCapPoint then
						CapRealm = GameData.Realm.NONE
					end	
						
					
				elseif ( controllPoints > 0 ) then
			   
			   
					if controllPoints < prevCapPoint then
						CapRealm = GameData.Realm.ORDER
						mirror = false
					elseif controllPoints > prevCapPoint then
						CapRealm = GameData.Realm.DESTRUCTION
						mirror = true
						
					elseif controllPoints == prevCapPoint then
						CapRealm = GameData.Realm.NONE			
					end			
				end

			elseif ObjectiveData.controllingRealm == GameData.Realm.DESTRUCTION then
				if controlFill < prevPoint then
					CapRealm = GameData.Realm.ORDER
					mirror = false
				elseif controlFill > prevPoint then
					CapRealm = GameData.Realm.DESTRUCTION
					mirror = true
				elseif controlFill == prevPoint then
					CapRealm = GameData.Realm.NONE	
				end
			
			
			elseif ObjectiveData.controllingRealm == GameData.Realm.ORDER then
				if controlFill < prevPoint then
					CapRealm = GameData.Realm.DESTRUCTION
					mirror = false
				elseif controlFill > prevPoint then
					CapRealm = GameData.Realm.ORDER
					mirror = true
				elseif controlFill == prevPoint then
					CapRealm = GameData.Realm.NONE	
				end
			end

		
        local realm = GameData.Realm.NONE
        if ( controllPoints < 0 )
        then
            realm = GameData.Realm.ORDER
        elseif ( controllPoints > 0 )
        then
            realm = GameData.Realm.DESTRUCTION
        end
		
        local barColor = DefaultColor.RealmColors[realm]
		local width,height = WindowGetDimensions(targetFrame)
		
			DynamicImageSetTextureOrientation (targetFrame.."ArrowArrow",mirror)
			WindowSetTintColor( controlBarWindow, barColor.r, barColor.g, barColor.b )			

            local flagColor = FlagCap.Color[ObjectiveData.controllingRealm]
			local arrowColor = FlagCap.Color[CapRealm]
            LabelSetText( targetFrame.."Name", ObjectiveData.name )
			LabelSetText( targetFrame.."NameBG", ObjectiveData.name )

			DynamicImageSetTextureSlice(targetFrame.."Owner","objectivebar_"..TrackerUtils.GetFlagSliceForOwner(ObjectiveData.controllingRealm))			
			WindowSetTintColor( targetFrame.."Arrow", arrowColor.r, arrowColor.g, arrowColor.b )
			WindowStartAlphaAnimation(targetFrame.."Arrow", 2, 1, 0, 0.5, true, 0.5, 0)
			WindowSetShowing(targetFrame.."Arrow",not (controlFill == prevPoint))

			prevPoint = controlFill
			prevCapPoint = controllPoints
			
			
			LabelSetText(targetFrame.."Time",towstring(controlFill))
			LabelSetText(targetFrame.."TimeBG",towstring(controlFill))
	end


end


function FlagCap.OnUpdate()
if not GameData.Player.isInScenario	then return end
local ObjectiveData = GetActiveObjectivesData()
	if ObjectiveData == nil then
		prevPoint = 0
		prevCapPoint = 0
	end
	
	if ObjectiveData[1] == nil then return end
	if ObjectiveData[1].isCapturePoint == false then return end
	local mirror = false
	local width,height = WindowGetDimensions(targetFrame.."ControlBar")
	ObjectiveData = ObjectiveData[1]


	WindowSetShowing(targetFrame, true)
	WindowSetShowing(targetFrame.."ControlBar", true)
	WindowSetShowing(targetFrame.."Lock", ObjectiveData.isFortress)
	
	WindowStartAlphaAnimation(targetFrame, 2, 1, 0, 0.5, true, 0.5, 0)
      
    local controlFill = math.abs(ObjectiveData.curControlPoints)
        
	DynamicImageSetTextureSlice(targetFrame.."Owner","objectivebar_"..TrackerUtils.GetFlagSliceForOwner(ObjectiveData.controllingRealm))
	WindowSetOffsetFromParent(targetFrame.."Arrow",((-10)+(width*(controlFill/100))),-3)
		
end

function FlagCap.OnLayoutEditorFinished( editorCode )
	if( editorCode == LayoutEditor.EDITING_END ) then
	WindowSetShowing("FlagCapWindow", false)
	end
end

function FlagCap.OnShutdown()	
UnregisterEventHandler( SystemData.Events.OBJECTIVE_CONTROL_POINTS_UPDATED, "FlagCap.OnPointUpdate" )
UnregisterEventHandler( SystemData.Events.OBJECTIVE_OWNER_UPDATED, "FlagCap.OnPointUpdate" )
end
