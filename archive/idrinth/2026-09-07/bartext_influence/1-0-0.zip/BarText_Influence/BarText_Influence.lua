BarText_Influence = {}


--
-- Config table data and saved variable
--
BarText_Influence_Config = {};
BarText_Influence_Config.defaultFormatString = L"[inf]/[infmax] ([infp]%)";
BarText_Influence_Config.currentFormatString = BarText_Influence_Config.defaultFormatString;

--
--  Helper function to get the current version specified in the .mod-file
--
function BarText_Influence.getVersion()
  local mods = ModulesGetData();
  for modIndex, modData in ipairs( mods ) do
    if( modData.name == "BarText (Influence)" ) then
      return modData.version;
    end
  end
  return "";
end

--
--  Initialize of the program
--
function BarText_Influence.OnInitialize()
  LibSlash.RegisterWSlashCmd("btinf", function(arg) BarText_Influence.SlashHandler(arg) end);

  EA_ChatWindow.Print(towstring("BarText (Influence) " .. BarText_Influence.getVersion() .. " Loaded."));

  RegisterEventHandler( SystemData.Events.PLAYER_INFLUENCE_UPDATED, "BarText_Influence.PlayerInfluenceUpdated" );
  RegisterEventHandler( SystemData.Events.PLAYER_ZONE_CHANGED, "BarText_Influence.PlayerInfluenceUpdated" );
  RegisterEventHandler( SystemData.Events.PLAYER_AREA_CHANGED, "BarText_Influence.PlayerInfluenceUpdated" );
  RegisterEventHandler( SystemData.Events.ENTER_WORLD, "BarText_Influence.PlayerInfluenceUpdated" );
end

--
-- Handler for the slashcommands
--
function BarText_Influence.SlashHandler( args )
  local opt, val = args:match(L"([a-z0-9]+)[ ]?(.*)")

  if( opt == nil or opt == L"help" ) then
    BarText_Influence.Print("BarText (Influence):");
    BarText_Influence.Print("/btinf help - Show this help");
    BarText_Influence.Print("/btinf show - Show current formatstring");
    BarText_Influence.Print("/btinf set - Show possible variables to use in formatstring");
    BarText_Influence.Print("/btinf set <formatstring> - Set the formatstring");
    BarText_Influence.Print("/btinf reset - Resets the formatstring to default");
  elseif( opt == L"show" ) then
    BarText_Influence.Print(L"Current formatstring: " .. BarText_Influence_Config.currentFormatString);
  elseif( opt == L"set" and val == L"" ) then
    BarText_Influence.Print("Possible values to use in BarText (Influence) formatstring:");
    BarText_Influence.Print("[inf] = Current influence");
    BarText_Influence.Print("[infmax] = Maximum influence for this level");
    BarText_Influence.Print("[infp] = Current influence in percent for this level");
    BarText_Influence.Print("[area] = Current area name");
    BarText_Influence.Print("[zone] = Current zone name");
    BarText_Influence.Print("[npc] = Name of npc that handles rewards");
  elseif( opt == L"set" and val ~= nil ) then
    BarText_Influence.Print(L"Formatstring set to:" .. val);
    BarText_Influence_Config.currentFormatString = val;
  elseif( opt == L"reset" ) then
    BarText_Influence_Config.currentFormatString = BarText_Influence_Config.defaultFormatString;
  elseif( opt ~= nil ) then
    BarText_Influence.Print("Unknown option");
  end
  BarText_Influence.PlayerInfluenceUpdated();
end

--
-- Helper print function
--
function BarText_Influence.Print( text )
  EA_ChatWindow.Print(towstring(tostring(text)), ChatSettings.Channels[SystemData.ChatLogFilters.SAY].id);
end

--
-- function that sets the labeltext and replaces the [vals] when influence updates
--
function BarText_Influence.PlayerInfluenceUpdated()
    local influenceId = EA_Window_PublicQuestTracker.GetLocalAreaInfluenceID();
    local influenceData = DataUtils.GetInfluenceData( influenceId )
  
    -- setup correct pos for window
    local x = WindowGetDimensions( "BarText_InfluenceOverlay" );
    WindowSetDimensions("BarText_InfluenceText",x,17);

    if( influenceData == nil ) then
        WindowSetShowing("BarText_InfluenceText", false)
        return;
    else
      WindowSetShowing("BarText_InfluenceText", true)
    end

    local inf = wstring.format(L"%d", influenceData.curValue );
    local infmax = L"0";
    for _ , v in pairs(influenceData.rewardLevel) do
      infmax = wstring.format(L"%d", v.amountNeeded);
    end
    local infp = wstring.format(L"%d", inf/infmax*100);
    local area = GetZoneAreaName( influenceData.zoneNum, influenceData.zoneAreaNum );
    local zone = GetZoneName( influenceData.zoneNum );
    local npc  = influenceData.npcName;

    local text = wstring.gsub( BarText_Influence_Config.currentFormatString, L"%[inf%]", inf );
    text = wstring.gsub( text, L"%[infmax%]", infmax );
    text = wstring.gsub( text, L"%[infp%]", infp );
    text = wstring.gsub( text, L"%[area%]", area );
    text = wstring.gsub( text, L"%[zone%]", zone );
    text = wstring.gsub( text, L"%[npc%]", npc );

    LabelSetText( "BarText_InfluenceText", text );
end

function BarText_Influence.OnMouseOver()
  EA_Window_PublicQuestTracker.OnMouseOverInfluenceBar();
end