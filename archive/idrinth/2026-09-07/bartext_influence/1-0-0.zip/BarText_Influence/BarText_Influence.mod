<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
	<UiMod name="BarText (Influence)" version="1.0.0" date="10/12/2008" >

		<Author name="WarWolf" email="warwolf.667@gmail.com" />
		<Description text="Adds text to the influencebar." />

	    <Dependencies>
			<Dependency name="EA_ChatWindow" />
			<Dependency name="EA_QuestTrackerWindow" />
			<Dependency name="LibSlash" />
	    </Dependencies>
	    
	    <SavedVariables>
			<SavedVariable name="BarText_Influence_Config" />
		</SavedVariables>

		<Files>
			<File name="BarText_Influence.xml" />
		</Files>
		
		<OnInitialize>
			<CreateWindow name="BarText_InfluenceOverlay" show="true" />
			<CreateWindow name="BarText_InfluenceText" show="true" />
			<CallFunction name="BarText_Influence.OnInitialize" />
		</OnInitialize>
	</UiMod>
</ModuleFile>
