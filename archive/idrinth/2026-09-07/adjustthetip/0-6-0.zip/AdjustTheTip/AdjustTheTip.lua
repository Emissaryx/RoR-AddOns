-- Mod:		AdjustTheTip
-- Author:	DarthVon (thedpui02@sneakemail.com)
-- Version:	0.6-beta
-- Date:	09/28/2008
-- ========================
-- Description:
--	Overrides standard UI functionality to support a delayed fade out of mouseovertarget
--		updates in order to give you more time to see what you quickly pass over.
--	Overrides standard UI allowing re-anchoring of the ability tooltip so the
--		mouseovertarget window can be placed at the top or left screen edges without
--		causing the tooltip to become deformed.
--	Tracks last friendly and enemy mouse over targets and allows targetting of them from
--		the mouseovertarget window.
--	Adds a health meter to the mouseovertarget window
--	Adds a proper influence tooltip to the influence bar
--


AdjustTheTip = {}

local DefaultMouseOverTargetWindow_UpdateTarget = MouseOverTargetWindow.UpdateTarget
local DefaultMouseOverTargetUnitFrame_UpdateUnit = MouseOverTargetUnitFrame.UpdateUnit
local DefaultTooltips_CreateAbilityTooltip = Tooltips.CreateAbilityTooltip
local DefaultLayoutControlFrame_CreateContextMenu = LayoutControlFrame.CreateContextMenu
local DefaultEA_Window_ContextMenu_Finalize = EA_Window_ContextMenu.Finalize
local DefaultEA_Window_PublicQuestTracker_OnMouseOverInfluenceBar = EA_Window_PublicQuestTracker.OnMouseOverInfluenceBar

local c_MOUSEOVER_CONTAINER_WINDOW = "MouseOverTargetWindow"
local c_MOUSEOVER_TARGET = "mouseovertarget"
local c_HEALTH_BAR_CONTAINER = "MouseOverTargetPlayerHealth"

AdjustTheTip.MenuItems_Anchor = {
	{ Position = "TopLeft", Data = { Type = "CheckBox", Name = "AdjustTheTipContextMenuAnchorTopLeft", Text = L"Top Left", Value = false, Callback = "AdjustTheTip.OnAnchorTopLeft" } },
	{ Position = "TopRight", Data = { Type = "CheckBox", Name = "AdjustTheTipContextMenuAnchorTopRight", Text = L"Top Right", Value = false, Callback = "AdjustTheTip.OnAnchorTopRight" } },
	{ Position = "BottomLeft", Data = { Type = "CheckBox", Name = "AdjustTheTipContextMenuAnchorBottomLeft", Text = L"Bottom Left", Value = false, Callback = "AdjustTheTip.OnAnchorBottomLeft" } },
	{ Position = "BottomRight", Data = { Type = "CheckBox", Name = "AdjustTheTipContextMenuAnchorBottomRight", Text = L"Bottom Right (default)", Value = true, Callback = "AdjustTheTip.OnAnchorBottomRight" } }
}

AdjustTheTip.MenuItems_DelayedFading = {
	{ Data = { Type = "CheckBox", Name = "AdjustTheTipContextMenuDelayedFadingEnabled", Text = L"Enabled", Value = true, Callback = "AdjustTheTip.OnDelayedFadingEnabled" } },
	{ Data = { Type = "Sider", Name = "AdjustTheTipContextMenuDelayedFadingDelay", Text = L"Delay (sec)", Value = 2.0, Callback = "AdjustTheTip.OnDelayedFadingDelay", SlideCallback = "AdjustTheTip.OnDelayedFadingDelaySlider" } }
}


------------------------------------
--
--
function AdjustTheTip.Initialize( )

	AdjustTheTip.EnableReanchor = true

	MouseOverTargetWindow.UpdateTarget = AdjustTheTip.UpdateTarget
    MouseOverTargetUnitFrame.UpdateUnit = AdjustTheTip.UpdateUnit

	EA_Window_PublicQuestTracker.OnMouseOverInfluenceBar = AdjustTheTip.OnMouseOverInfluenceBar

    WindowSetHandleInput( "MouseOverTargetWindow", true )
    WindowRegisterCoreEventHandler( "MouseOverTargetWindow", "OnLButtonUp", "AdjustTheTip.OnMouseOverTargetWindowClick" )
    
    AdjustTheTip.AddTargetHealthToMouseOver( )

	if( AdjustTheTip.EnableReanchor == true ) then
		Tooltips.CreateAbilityTooltip = AdjustTheTip.CreateAbilityTooltip
		LayoutControlFrame.CreateContextMenu = AdjustTheTip.CreateContextMenu
		EA_Window_ContextMenu.Finalize = AdjustTheTip.ContextMenu_Finalize

		for _, item in ipairs( AdjustTheTip.MenuItems_Anchor ) do
			if( item.Data.Type == "CheckBox" ) then
				AdjustTheTip.CreateCheckBoxMenuItem( item.Data )
			end
		end

		for _, item in ipairs( AdjustTheTip.MenuItems_DelayedFading ) do
			if( item.Data.Type == "CheckBox" ) then
				AdjustTheTip.CreateCheckBoxMenuItem( item.Data )
			elseif( item.Data.Type == "Sider" ) then
				AdjustTheTip.CreateSliderMenuItem( item.Data )
			end
		end

		if( not AdjustTheTip.SavedVariables ) then
			AdjustTheTip.SavedVariables = {}
		else
			for _, item in ipairs( AdjustTheTip.MenuItems_Anchor ) do
				item.Data.Value = item.Position == AdjustTheTip.SavedVariables["anchor"]
			end
			
			for _, item in ipairs( AdjustTheTip.MenuItems_DelayedFading ) do
				if( AdjustTheTip.SavedVariables[item.Data.Name] ~= nil ) then
					item.Data.Value = AdjustTheTip.SavedVariables[item.Data.Name]
				end
			end
		end
	end

end


------------------------------------
--
--
function AdjustTheTip.Shutdown( )

	MouseOverTargetWindow.UpdateTarget = DefaultMouseOverTargetWindow_UpdateTarget
    MouseOverTargetUnitFrame.UpdateUnit = DefaultMouseOverTargetUnitFrame_UpdateUnit
    EA_Window_PublicQuestTracker.OnMouseOverInfluenceBar = DefaultEA_Window_PublicQuestTracker_OnMouseOverInfluenceBar

	if( AdjustTheTip.EnableReanchor == true ) then
		Tooltips.CreateAbilityTooltip = DefaultTooltips_CreateAbilityTooltip
		LayoutControlFrame.CreateContextMenu = DefaultLayoutControlFrame_CreateContextMenu
		EA_Window_ContextMenu.Finalize = DefaultEA_Window_ContextMenu_Finalize

		for _, item in ipairs( AdjustTheTip.MenuItems_Anchor ) do
			if( item.Data.Value == true ) then
				AdjustTheTip.SavedVariables["anchor"] = item.Position
			end
			DestroyWindow( item.Data.Name )
		end

		for _, item in ipairs( AdjustTheTip.MenuItems_DelayedFading ) do
			AdjustTheTip.SavedVariables[item.Data.Name] = item.Data.Value
			DestroyWindow( item.Data.Name )
		end
	end

end


------------------------------------
--
--
function AdjustTheTip.UpdateTarget( targetClassification, targetId, targetType )

	if( not AdjustTheTip.MenuItems_DelayedFading[1].Data.Value ) then
		DefaultMouseOverTargetWindow_UpdateTarget( targetClassification, targetId, targetType )
		return
	end

	--<BEGIN MODIFIED MYTHIC CODE>
    if( targetClassification ~= c_MOUSEOVER_TARGET )
    then
        return
    end

    -- This is a little cheesy, but works until we can better differentiate
    -- between target changes and target hp updates. -bmazza
    local oldMouseOverEntityId = TargetInfo:UnitEntityId("mouseovertarget")

    TargetInfo:UpdateFromClient ()    
    MouseOverTargetWindow.unitFrame:UpdateUnit ()

    --WindowSetAlpha(c_MOUSEOVER_CONTAINER_WINDOW, 1.0)

    if( TargetInfo:UnitEntityId("mouseovertarget") ~= 0 )
    then
		WindowSetShowing( c_MOUSEOVER_CONTAINER_WINDOW, true )
	end
	--<END MODIFIED MYTHIC CODE>

end


------------------------------------
--
--
function AdjustTheTip:UpdateUnit( )

	if( not AdjustTheTip.MenuItems_DelayedFading[1].Data.Value ) then
		DefaultMouseOverTargetUnitFrame_UpdateUnit( self )
		AdjustTheTip.TrackMouseOverTargets( self )
		AdjustTheTip.SetMouseOverTargetHealth( TargetInfo:UnitHealth( self.m_UnitId ) )
		return
	end

	--<BEGIN MODIFIED MYTHIC CODE>
    -- Using local variables because I removed the arguments...
    local unitId = self.m_UnitId
 
    -- Track these so the frame knows whether or not to show the con level (ie, not for static objects)
    -- Similar reasoning behind caching m_IsThePlayer.    
    self.m_Type = TargetInfo:UnitType (unitId);    
    self.m_IsAStaticObject  = (self.m_Type == SystemData.TargetObjectType.STATIC_ATTACKABLE or self.m_Type == SystemData.TargetObjectType.STATIC)
    self.m_IsThePlayer      = (self.m_Type == SystemData.TargetObjectType.SELF)
    self.m_IsFriendly       = TargetInfo:UnitIsFriendly(unitId)
    
    -- Unit must have a name to show.
    local unitName      = TargetInfo:UnitName (unitId)
    local unitHasName   = unitName ~= L""
    local showUnitFrame = unitHasName -- and (self.m_Type ~= SystemData.TargetObjectType.STATIC)  -- Still showing static object frames, even though i hate it!

    -- If unit does not have a name, hide all mouseovers.
    if (not showUnitFrame) then
		local startAlpha = WindowGetAlpha( self:GetName( ) )
		WindowStartAlphaAnimation( self:GetName( ), Window.AnimationType.SINGLE_NO_RESET, 1, 0, 2.0, false, AdjustTheTip.MenuItems_DelayedFading[2].Data.Value, 0 )

        --self:Show(false)
        self.m_TargetObjectWindow:Show(false)
        Tooltips.ClearTooltip()
        return
	else
		WindowStopAlphaAnimation( self:GetName( ) );
		self:Show(false)
    end
    
    -- Otherwise, update and show the mouseover of the appropriate type.

    -- Show a static object (e.g. road sign):
    if (self.m_IsAStaticObject) then
        self:ShowAndUpdateForStaticObject(unitName)
    
    -- Show a non-static mousover (e.g. player, monster, or static attackable):
    else
        self:ShowAndUpdateForNonStatic(unitId, unitName)
    end
    --<END MODIFIED MYTHIC CODE>
   
	AdjustTheTip.TrackMouseOverTargets( self )
    AdjustTheTip.SetMouseOverTargetHealth( TargetInfo:UnitHealth( unitId ) )

end


------------------------------------
--
--
function AdjustTheTip:TrackMouseOverTargets( )

	local unitId = self.m_UnitId
	local unitName = TargetInfo:UnitName( unitId )
    local unitHasName = unitName ~= L""
    
	if( unitHasName and not TargetInfo:UnitIsNPC( unitId ) ) then
		if( self.m_IsFriendly ) then
			AdjustTheTip.lastMouseOverFriendly = unitName
		else
			AdjustTheTip.lastMousedOverEnemy = unitName
		end
	end

end


------------------------------------
--
--
function AdjustTheTip.OnMouseOverTargetWindowClick( )

	if( WindowGetAlpha( "MouseOverTargetUnitWindow" ) == 0 ) then
		return
	end

	if( AdjustTheTip.lastMouseOverFriendly ~= nil ) then
		TargetPlayer( AdjustTheTip.lastMouseOverFriendly )
	end
	
	if( AdjustTheTip.lastMouseOverEnemy ~= nil ) then
		TargetPlayer( AdjustTheTip.lastMouseOverEnemy )
	end

end


--<BEGIN UNMODIFIED MYTHIC CODE>

local function GetAbilityCastTimeText (abilityData)
    if (abilityData.numTacticSlots > 0)
    then
        return GetString (StringTables.Default.LABEL_ABILITY_TOOLTIP_PASSIVE_CAST)
    end
    
    local castTime = GetAbilityCastTime (abilityData.id)
    
    if (castTime > 0) 
    then
        local _, castTimeFraction = math.modf (castTime)
        local params = nil
        
        if (castTimeFraction ~= 0)
        then
            params = { wstring.format( L"%.1f", castTime) }
        else
            params = { wstring.format( L"%d", castTime) }
        end
            
        return (GetStringFormat (StringTables.Default.LABEL_ABILITY_TOOLTIP_CAST_TIME, params))
    end    
    
    return (GetString (StringTables.Default.LABEL_ABILITY_TOOLTIP_INSTANT_CAST))
end

local function GetAbilityCostText (abilityData)
    if (abilityData.moraleLevel ~= 0) 
    then    
        local params = { abilityData.moraleLevel }
        return (GetStringFormat (StringTables.Default.LABEL_ABILITY_TOOLTIP_MORALE_COST, params))
    elseif (abilityData.numTacticSlots ~= 0) 
    then
        local params = { abilityData.numTacticSlots, Tooltips.TacticsTypeStrings[abilityData.tacticType] }
        return (GetStringFormat (StringTables.Default.LABEL_ABILITY_TOOLTIP_TACTIC_COST, params))
    else
        local apCost = GetAbilityActionPointCost (abilityData.id)
        
        if (apCost > 0)
        then
            local params = { apCost }
            
            if (abilityData.hasAPCostPerSecond)
            then
                return (GetStringFormat (StringTables.Default.LABEL_ABILITY_TOOLTIP_AP_COST_PER_SECOND, params))
            else
                return (GetStringFormat (StringTables.Default.LABEL_ABILITY_TOOLTIP_ACTION_POINT_COST, params))
            end
        end
    end
    
    return (GetString (StringTables.Default.LABEL_ABILITY_TOOLTIP_NO_COST))
end

local function GetAbilityRangeText (abilityData)
    local labelText = GetString (StringTables.Default.LABEL_ABILITY_TOOLTIP_NO_RANGE)
    local minRange, maxRange = GetAbilityRanges (abilityData.id)
    
    if ((minRange > 0) and (maxRange > 0))
    then
        local params = { minRange, maxRange }
        labelText = GetStringFormat (StringTables.Default.LABEL_ABILITY_TOOLTIP_MIN_RANGE_TO_MAX_RANGE, params)  
    elseif (maxRange > 0) 
    then
        local params = { maxRange }
        labelText = GetStringFormat (StringTables.Default.LABEL_ABILITY_TOOLTIP_MAX_RANGE, params)
    elseif (abilityData.targetType == GameData.TargetTypes.TARGET_ENEMY)
    then
        labelText = GetString (StringTables.Default.LABEL_ABILITY_TOOLTIP_MELEE_RANGE)
    end
    
    return (labelText)
end

local function GetAbilityLevelText (abilityData)
    local upgradeRank = GetAbilityUpgradeRank (abilityData.id)
    
    if (upgradeRank > 0)
    then
        return (GetStringFormat (StringTables.Default.LABEL_ABILITY_TOOLTIP_ABILITY_RANK, {upgradeRank}))
    end
    
    return (GetString (StringTables.Default.LABEL_ABILITY_TOOLTIP_ABILITY_NO_RANK))
end

local function GetAbilityCooldownText (cooldown)
    if (cooldown > 0) 
    then
        local timeText, min, sec = TimeUtils.FormatSeconds (cooldown)
        return (GetStringFormat (StringTables.Default.LABEL_ABILITY_TOOLTIP_COOLDOWN, { timeText }))
    end
    
    return (GetString (StringTables.Default.LABEL_ABILITY_TOOLTIP_NO_COOLDOWN))
end

--<END UNMODIFIED MYTHIC CODE>


------------------------------------
--
--
function AdjustTheTip.CreateAbilityTooltip( abilityData, mouseoverWindow, anchor, extraText, extraTextColor )

	if( anchor ~= Tooltips.ANCHOR_MOUSE_OVER_TARGET_WINDOW ) then
		DefaultTooltips_CreateAbilityTooltip( abilityData, mouseoverWindow, anchor, extraText, extraTextColor )
		AdjustTheTip.AbilityTooltipSetShowing( true )
		return
	end

	--<BEGIN MODIFIED MYTHIC CODE>
    if( abilityData == nil ) then
        return
    end
    
    local labelText = L""
    local c_BASE_TOOLTIP_WIDTH = 350
    local c_TOOLTIP_BUFFER = 15

    -- Name, Desc    
    LabelSetText ("AbilityTooltipDesc", GetAbilityDesc (abilityData.id))
    
    -- Left Column (spec line, cost, cast time)
    
    LabelSetText ("AbilityTooltipName",         GetStringFormat(StringTables.Default.LABEL_ABILITY_TOOLTIP_ABILITY_NAME, {abilityData.name}))
    LabelSetText ("AbilityTooltipSpecLine",     DataUtils.GetAbilitySpecLine (abilityData))
    LabelSetText ("AbilityTooltipCost",         GetAbilityCostText (abilityData))
    LabelSetText ("AbilityTooltipCastTime",     GetAbilityCastTimeText (abilityData))
    
    -- Right Column (type, range, cooldown)
    
    LabelSetText ("AbilityTooltipType",         DataUtils.GetAbilityTypeText (abilityData))
    LabelSetText ("AbilityTooltipLevel",        GetAbilityLevelText (abilityData))
    LabelSetText ("AbilityTooltipRange",        GetAbilityRangeText (abilityData))
    LabelSetText ("AbilityTooltipCooldown",     GetAbilityCooldownText (abilityData.cooldown))
    
    
    -- Requirements...
    local reqs = {}
    reqs[1], reqs[2], reqs[3] = GetAbilityRequirements (abilityData.id)
    
    for reqsIndex = 1, 3
    do
        local reqsLabel = "AbilityTooltipRequirements"..reqsIndex
        
        if ((reqs[reqsIndex] ~= nil) and (DoesWindowExist (reqsLabel)))
        then
            LabelSetText (reqsLabel, reqs[reqsIndex])
        else
            LabelSetText (reqsLabel, L"")
        end
    end
    
    -- Extra Text
    Tooltips.SetExtraText ("AbilityTooltip", "ActionText", "ActionTextLine", extraText, extraTextColor)

    -- Create the tooltip...anchoring magically works!
    AdjustTheTip.CreateCustomTooltip (mouseoverWindow, "AbilityTooltip")
    
    local x, y = WindowGetDimensions("AbilityTooltipDesc")    
    WindowSetDimensions("AbilityTooltipDesc", c_BASE_TOOLTIP_WIDTH, y )
    
    local nameWidth, nameHeight = LabelGetTextDimensions("AbilityTooltipName")
    local typeWidth, typeHeight = LabelGetTextDimensions("AbilityTooltipType")  

    local costWidth, costHeight = LabelGetTextDimensions("AbilityTooltipCost")
    local rangeWidth, rangeHeight = LabelGetTextDimensions("AbilityTooltipRange")  

    local casttimeWidth, casttimeHeight = LabelGetTextDimensions("AbilityTooltipCastTime")
    local cooldownWidth, cooldownHeight = LabelGetTextDimensions("AbilityTooltipCooldown")  
  
    local width1 = nameWidth + typeWidth + c_TOOLTIP_BUFFER
    local width2 = costWidth + rangeWidth + c_TOOLTIP_BUFFER
    local width3 = casttimeWidth + cooldownWidth + c_TOOLTIP_BUFFER
    
    local newWidth = math.max( width1, width2 )
    newWidth = math.max( newWidth, width3 )    
    x, y = WindowGetDimensions("AbilityTooltipDesc")  
   
    if( newWidth > c_BASE_TOOLTIP_WIDTH ) then        
        WindowSetDimensions("AbilityTooltipDesc", newWidth, y )
    else
        WindowSetDimensions("AbilityTooltipDesc", c_BASE_TOOLTIP_WIDTH, y )
    end       
    
    LabelSetText ("AbilityTooltipDesc", GetAbilityDesc (abilityData.id))
    
    --[[
    -- Intercept and rebuild this anchor due to the strange way the ability tooltip window is constructed
    if( anchor == Tooltips.ANCHOR_MOUSE_OVER_TARGET_WINDOW )
    then
        local abilityMargin = 15
        _, anchorYOffset = WindowGetDimensions( "AbilityTooltipActionText" )
        anchor = { Point = "bottomright", RelativeTo = "MouseOverTargetWindow", RelativePoint = "bottomright",
                   XOffset = -x - Tooltips.MOUSE_OVER_TARGET_TOOLTIP_MARGIN - abilityMargin,
                   YOffset = -anchorYOffset - Tooltips.MOUSE_OVER_TARGET_TOOLTIP_MARGIN - abilityMargin }
    end
    
    Tooltips.AnchorTooltip (anchor)
    --]]
	--<END MODIFIED MYTHIC CODE>
	
	Tooltips.SetUpdateCallback( AdjustTheTip.UpdateCallback )

end


------------------------------------
--
--
function AdjustTheTip.CreateCustomTooltip( mouseOverWindow, tooltipWindow )

	--<BEGIN MODIFIED MYTHIC CODE>
    Tooltips.curMouseOverWindow = mouseOverWindow
    
    Tooltips.ClearTooltip()
    
    Tooltips.curTooltipWindow = tooltipWindow
    
    --WindowSetShowing( Tooltips.curTooltipWindow, true )

    Tooltips.visible = true
	--<END MODIFIED MYTHIC CODE>
	
end


------------------------------------
--
--
function AdjustTheTip.UpdateCallback( timeElapsed )

	local uiScale = InterfaceCore.GetScale( )
	local tipBackgroundX, tipBackgroundY = WindowGetScreenPosition( "AbilityTooltipBackground" )
	local tipBackgroundW, tipBackgroundH = WindowGetDimensions( "AbilityTooltipBackground" )
	local tipX, tipY = WindowGetScreenPosition( "AbilityTooltip" )
	
	local deltaX = ((tipX - tipBackgroundX) / uiScale)
	local deltaY = ((tipY - tipBackgroundY) / uiScale)
	local position = nil

	for _, item in ipairs( AdjustTheTip.MenuItems_Anchor ) do
		if( item.Data.Value == true ) then
			position = string.lower(item.Position)
			if( item.Position == "TopLeft" ) then
				deltaX = deltaX + (15 * uiScale)
			elseif( item.Position == "TopRight" ) then
				deltaX = deltaX - tipBackgroundW + (15 * uiScale)
			elseif( item.Position == "BottomLeft" ) then
				deltaY = deltaY - tipBackgroundH
			elseif( item.Position == "BottomRight" ) then
				deltaX = deltaX - tipBackgroundW + (15 * uiScale)
				deltaY = deltaY - tipBackgroundH
			else
				d( "Baaaaaad" )
			end
		end
	end

	local newAnchor = { Point=position, RelativeTo="MouseOverTargetWindow", RelativePoint=position, XOffset=deltaX, YOffset=deltaY }
	WindowClearAnchors( Tooltips.curTooltipWindow )
	WindowAddAnchor( Tooltips.curTooltipWindow, newAnchor.Point, newAnchor.RelativeTo, newAnchor.RelativePoint, newAnchor.XOffset, newAnchor.YOffset )
	AdjustTheTip.AbilityTooltipSetShowing( false )

	if( not WindowGetShowing( Tooltips.curTooltipWindow ) ) then
		WindowSetShowing( Tooltips.curTooltipWindow, true )
		return
	end

	AdjustTheTip.AbilityTooltipSetShowing( true )
	Tooltips.SetUpdateCallback( nil )

	--AdjustTheTip.HighlightWindow( "MouseOverTargetWindow" )
	--AdjustTheTip.HighlightWindow( Tooltips.curTooltipWindow )

end


------------------------------------
--
--
function AdjustTheTip.AbilityTooltipSetShowing( show )

	local parent = "AbilityTooltip"
	local windows = {
		"Name",
		"SpecLine",
		"Cost",
		"CastTime",
		"Type",
		"Level",
		"Range",
		"Cooldown",
		"Requirements1",
		"Requirements2",
		"Requirements3",
		"Desc",
		"ActionText",
		"ActionTextLine",
		"HeaderSeperator",
		"Background"
	}

	WindowSetAlpha( parent, show and 1.0 or 0.0 )
	for _, v in ipairs(windows) do
		WindowSetShowing( parent .. v, show )
	end

end


------------------------------------
--
--
function AdjustTheTip.AddTargetHealthToMouseOver( )

	CreateWindowFromTemplate( c_HEALTH_BAR_CONTAINER, "MouseOverTargetHealthContainerTemplate", "MouseOverTargetUnitWindow" )

	local mouseOverW, mouseOverH = WindowGetDimensions( "MouseOverTargetUnitWindow" )
	WindowSetDimensions( "MouseOverTargetUnitWindow", mouseOverW, mouseOverH + 30 )

	WindowAddAnchor( c_HEALTH_BAR_CONTAINER, "bottomright", "MouseOverTargetUnitWindow", "bottomright", -10, -10 )

	StatusBarSetBackgroundTint( c_HEALTH_BAR_CONTAINER .. "HealthPercentBarBar", 128, 128, 128 )
	StatusBarSetForegroundTint( c_HEALTH_BAR_CONTAINER .. "HealthPercentBarBar", 0, 255, 0 )

	StatusBarSetMaximumValue( c_HEALTH_BAR_CONTAINER .. "HealthPercentBarBar", 100 ) 

	AdjustTheTip.SetMouseOverTargetHealth( 100 )

end


------------------------------------
--
--
function AdjustTheTip.SetMouseOverTargetHealth( val )

	StatusBarSetCurrentValue( c_HEALTH_BAR_CONTAINER .. "HealthPercentBarBar", val )
	LabelSetText( c_HEALTH_BAR_CONTAINER .. "HealthText", towstring( val ) .. L"%" )

end


--[[ DEBUG
------------------------------------
--
--
function AdjustTheTip.HighlightWindow( window )

	if( WindowGetShowing( HelpTips.FOCUS_WINDOW_NAME ) ) then
		WindowStopAlphaAnimation( HelpTips.FOCUS_WINDOW_NAME )
		WindowSetShowing( HelpTips.FOCUS_WINDOW_NAME, false )
	end
	HelpTips.SetFocusOnWindow( window )

end
--]]

------------------------------------
--
--
function AdjustTheTip:CreateContextMenu( )

	AdjustTheTip.allowContextMenuFinalize = false
	DefaultLayoutControlFrame_CreateContextMenu( self )
	AdjustTheTip.allowContextMenuFinalize = true

	if( self.m_activeFrame:GetSourceWindowName() == "MouseOverTargetWindow" ) then
		EA_Window_ContextMenu.AddCascadingMenuItem( L"Delayed Fading", AdjustTheTip.SpawnDelayedFadingContextMenu, false )
		EA_Window_ContextMenu.AddCascadingMenuItem( L"Ability Tooltip Anchor", AdjustTheTip.SpawnAnchorContextMenu, false )
	end

	EA_Window_ContextMenu.Finalize( )

end


------------------------------------
--
--
function AdjustTheTip.ContextMenu_Finalize( contextMenuNumber, anchor )

	local isContextMenu1 = (contextMenuNumber == nil) or (contextMenuNumber == EA_Window_ContextMenu.CONTEXT_MENU_1)

	if( (AdjustTheTip.allowContextMenuFinalize ~= false) or 
		((AdjustTheTip.allowContextMenuFinalize == false) and (not isContextMenu1)) )
	then
		DefaultEA_Window_ContextMenu_Finalize( contextMenuNumber, anchor )
	end

end


------------------------------------
--
--
function AdjustTheTip.SpawnDelayedFadingContextMenu( )

    EA_Window_ContextMenu.Hide( EA_Window_ContextMenu.CONTEXT_MENU_3 )
    EA_Window_ContextMenu.CreateContextMenu( "", EA_Window_ContextMenu.CONTEXT_MENU_2 )

	for _, item in ipairs( AdjustTheTip.MenuItems_DelayedFading ) do
		if( item.Data.Type == "CheckBox" ) then
			ButtonSetPressedFlag( item.Data.Name .. "CheckBox", item.Data.Value )
		elseif( item.Data.Type == "Slider" ) then
			LabelSetText( item.Data.Name .. "SliderValueLabel", towstring( item.Data.Value ) )
			SliderBarSetCurrentPosition( item.Data.Name .. "SliderBar", item.Data.Value )
		end

		EA_Window_ContextMenu.AddUserDefinedMenuItem( item.Data.Name, EA_Window_ContextMenu.CONTEXT_MENU_2 )
	end

    EA_Window_ContextMenu.Finalize( EA_Window_ContextMenu.CONTEXT_MENU_2 )

end


------------------------------------
--
--
function AdjustTheTip.SpawnAnchorContextMenu( )

    EA_Window_ContextMenu.Hide( EA_Window_ContextMenu.CONTEXT_MENU_3 )
    EA_Window_ContextMenu.CreateContextMenu( "", EA_Window_ContextMenu.CONTEXT_MENU_2 )

	for _, item in ipairs( AdjustTheTip.MenuItems_Anchor ) do
		if( item.Data.Type == "CheckBox" ) then
			ButtonSetPressedFlag( item.Data.Name .. "CheckBox", item.Data.Value )
			EA_Window_ContextMenu.AddUserDefinedMenuItem( item.Data.Name, EA_Window_ContextMenu.CONTEXT_MENU_2 )
		end
	end

    EA_Window_ContextMenu.Finalize( EA_Window_ContextMenu.CONTEXT_MENU_2 )

end


------------------------------------
--
--
function AdjustTheTip.OnAnchorTopLeft( ) AdjustTheTip.OnAnchor( "TopLeft" ) end
function AdjustTheTip.OnAnchorTopRight( ) AdjustTheTip.OnAnchor( "TopRight" ) end
function AdjustTheTip.OnAnchorBottomLeft( ) AdjustTheTip.OnAnchor( "BottomLeft" ) end
function AdjustTheTip.OnAnchorBottomRight( ) AdjustTheTip.OnAnchor( "BottomRight" ) end
function AdjustTheTip.OnAnchor( anchorCorner )

	EA_Window_ContextMenu.Hide( EA_Window_ContextMenu.CONTEXT_MENU_2 )
	for _, item in ipairs( AdjustTheTip.MenuItems_Anchor ) do
		item.Data.Value = item.Position == anchorCorner
		WindowSetShowing( item.Data.Name, false )
	end

end


------------------------------------
--
--
function AdjustTheTip.OnDelayedFadingEnabled( )
	EA_Window_ContextMenu.Hide( EA_Window_ContextMenu.CONTEXT_MENU_2 )

	local item = AdjustTheTip.MenuItems_DelayedFading[1]
	item.Data.Value = not ButtonGetPressedFlag( item.Data.Name .. "CheckBox" )
end


------------------------------------
--
--
function AdjustTheTip.OnDelayedFadingDelay( )
	for _, item in ipairs( AdjustTheTip.MenuItems_DelayedFading ) do
		if( item.Data.SlideCallback == "AdjustTheTip.OnDelayedFadingDelaySlider" ) then
			local sliderPos = SliderBarGetCurrentPosition( item.Data.Name .. "SliderBar" )
			local val = math.floor( ((sliderPos * 10) + .05) * 10 ) / 10
			LabelSetText( item.Data.Name .. "SliderValueLabel", towstring( val ) )
			item.Data.Value = val
		end
	end
end


--[[ TODO: Get this shit working
function AdjustTheTip.OnDelayedFadingDelaySlider( sliderPos )
	d( "AdjustTheTip.OnDelayedFadingDelaySlider" )
end
--]]



------------------------------------
--
--
function AdjustTheTip.CreateCheckBoxMenuItem( itemData )

    CreateWindowFromTemplate( itemData.Name, "ChatContextMenuItemCheckBox", "Root" )
    LabelSetText( itemData.Name .. "CheckBoxLabel", itemData.Text )
    ButtonSetPressedFlag( itemData.Name .. "CheckBox", itemData.Value )
    WindowRegisterCoreEventHandler( itemData.Name, "OnLButtonUp", itemData.Callback )
    WindowSetShowing( itemData.Name, false )

end


------------------------------------
--
--
function AdjustTheTip.CreateSliderMenuItem( itemData )

	CreateWindowFromTemplate( itemData.Name, "AdjustTheTipMenuItemSlider", "Root" )
	LabelSetText( itemData.Name .. "SliderLabel", itemData.Text )
	LabelSetText( itemData.Name .. "SliderValueLabel", towstring( itemData.Value ) )
	SliderBarSetCurrentPosition( itemData.Name .. "SliderBar", itemData.Value / 10 )
	--WindowRegisterCoreEventHandler( itemData.Name .. "SliderBar", "OnSlide", itemData.SlideCallback )
	WindowRegisterCoreEventHandler( itemData.Name, "OnLButtonUp", itemData.Callback )
    WindowSetShowing( itemData.Name, false )

end


------------------------------------
--
--
function AdjustTheTip.OnMouseOverInfluenceBar( )

    Tooltips.CreateTextOnlyTooltip( SystemData.ActiveWindow.name, nil ) 
    Tooltips.AnchorTooltip( Tooltips.ANCHOR_WINDOW_LEFT )
    Tooltips.SetUpdateCallback( AdjustTheTip.UpdateInfluenceTooltip )

end


------------------------------------
--
--
function AdjustTheTip.UpdateInfluenceTooltip( )

    local influenceData = DataUtils.GetInfluenceData( EA_Window_PublicQuestTracker.GetLocalAreaInfluenceID())

	--<BEGIN MODIFIED MYTHIC CODE>
	--function TomeWindow.OnMouseOverInfluenceDisplay()
    
    --local influenceId = WindowGetId( SystemData.ActiveWindow.name )
    --DEBUG(L" Entry InfluenceId"..influenceId )
        
    --local influenceData = DataUtils.GetInfluenceData( influenceId )
    if( influenceData == nil ) then
        return
    end    

    local zoneName  = GetZoneName( influenceData.zoneNum )
    local areaName = GetZoneAreaName(  influenceData.zoneNum, influenceData.zoneAreaNum )

    local text = GetStringFormat( StringTables.Default.TEXT_INFLUENCE_DESC,
                                 { areaName, zoneName,
                                    influenceData.rewardLevel[1].amountNeeded,
                                    influenceData.npcName,
                                    influenceData.rewardLevel[2].amountNeeded,
                                    influenceData.rewardLevel[3].amountNeeded } )

    -- Name
    local row = 1
    local column = 1
    Tooltips.SetTooltipText( row, column, GetString( StringTables.Default.LABEL_AREA_INFLUENCE ) )
    row = row + 1

    -- Desc
    Tooltips.SetTooltipText( row, column, text )
    Tooltips.SetTooltipColor( row, column, 255, 204, 51 )
    row = row + 1

    -- Current Points
	local curPointsText = GetStringFormat( StringTables.Default.TEXT_CURRENT_INFLUENCE, { influenceData.curValue } )
	curPointsText = curPointsText .. wstring.format( L"/%d (", influenceData.rewardLevel[3].amountNeeded )
	local percent = 100
	if( influenceData.curValue < influenceData.rewardLevel[1].amountNeeded ) then
		percent = (influenceData.curValue / influenceData.rewardLevel[1].amountNeeded) * 100
		curPointsText = curPointsText .. wstring.format( L"%d%%,", percent )
	end
	if( influenceData.curValue < influenceData.rewardLevel[2].amountNeeded ) then
		percent = ((influenceData.curValue % influenceData.rewardLevel[2].amountNeeded) / influenceData.rewardLevel[2].amountNeeded) * 100
		curPointsText = curPointsText .. wstring.format( L"%d%%,", percent )
	end
	if( influenceData.curValue < influenceData.rewardLevel[3].amountNeeded ) then
		percent = ((influenceData.curValue % influenceData.rewardLevel[3].amountNeeded) / influenceData.rewardLevel[3].amountNeeded) * 100
	end
    curPointsText = curPointsText .. wstring.format( L"%d%%)", percent )

    Tooltips.SetTooltipText( row, column, curPointsText )
    Tooltips.SetTooltipColor( row, column, 255, 204, 102 )
    row = row + 1                           

    -- Rewards Avail / Recieved
    if( influenceData.rewardLevel[1].rewardsRecieved == true ) then
        Tooltips.SetTooltipText( row, column, GetString( StringTables.Default.TEXT_BASIC_REWARD_RECEIVED) )
        Tooltips.SetTooltipColor( row, column, 150, 150, 150 )
        row = row + 1
    elseif( influenceData.curValue >= influenceData.rewardLevel[1].amountNeeded ) then
        Tooltips.SetTooltipText( row, column, GetString( StringTables.Default.TEXT_BASIC_REWARD_AVAILIABLE ) )
        Tooltips.SetTooltipColor( row, column, 255, 255, 0 )
        row = row + 1
    end

    if( influenceData.rewardLevel[2].rewardsRecieved == true ) then
        Tooltips.SetTooltipText( row, column, GetString( StringTables.Default.TEXT_ADVANCED_REWARD_RECEIVED) )
        Tooltips.SetTooltipColor( row, column, 150, 150, 150 )
        row = row + 1
    elseif( influenceData.curValue >= influenceData.rewardLevel[2].amountNeeded ) then
        Tooltips.SetTooltipText( row, column, GetString( StringTables.Default.TEXT_ADVANCED_REWARD_AVAILIABLE ) )
        Tooltips.SetTooltipColor( row, column, 255, 255, 0 )
        row = row + 1
    end

    if( influenceData.rewardLevel[3].rewardsRecieved == true ) then
        Tooltips.SetTooltipText( row, column, GetString( StringTables.Default.TEXT_ELITE_REWARD_RECEIVED) )
        Tooltips.SetTooltipColor( row, column, 150, 150, 150 )
        row = row + 1
    elseif( influenceData.curValue >= influenceData.rewardLevel[3].amountNeeded ) then
        Tooltips.SetTooltipText( row, column, GetString( StringTables.Default.TEXT_ELITE_REWARD_AVAILIABLE ) )
        Tooltips.SetTooltipColor( row, column, 255, 255, 0 )
        row = row + 1
    end

    Tooltips.Finalize()
    --<END MODIFIED MYTHIC CODE>

end