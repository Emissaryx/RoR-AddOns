<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" >

    <UiMod name="AdjustTheTip" version="See Below" date="09/28/2008">
        <Author name="DarthVon" email="thedpui02@sneakemail.com" />
        <Description text="Adds a delayed fade-out to the mouse-over target window.  Adds clicking to target last mouse-over.  Adds a health meter to the mouse-over target window.  Allows reanchoring of Ability tooltip.  [Version: 0.6-beta]" />

		<Dependencies>
			<Dependency name="EASystem_Tooltips" />
			<Dependency name="EASystem_LayoutEditor" />
			<Dependency name="EASystem_WindowUtils" />
			<Dependency name="EASystem_Utils" />
			<Dependency name="EA_ContextMenu" />
			<Dependency name="EA_MouseOverTargetWindow"/>
		</Dependencies>
		
		<Files>
			<File name="AdjustTheTip.lua" />
			<File name="AdjustTheTip.xml" />
		</Files>

		<SavedVariables>
			<SavedVariable name="AdjustTheTip.SavedVariables" />
		</SavedVariables>
		
        <OnInitialize>
            <CallFunction name="AdjustTheTip.Initialize" />
        </OnInitialize>
        <OnShutdown>
            <CallFunction name="AdjustTheTip.Shutdown" />
        </OnShutdown>
    </UiMod>
    
</ModuleFile>    