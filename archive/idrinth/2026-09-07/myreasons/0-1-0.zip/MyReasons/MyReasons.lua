MyReasons = {}
MyReasons.Version = 0.1

-- Two simple macros:
-- /script MyReasons.TargetNote(L"No Heals!", true);
-- /script MyReasons.TargetNote(L"Hated Hostile!", false);

function MyReasons.OnInitialize()
	--using a hook instead of PLAYER_TARGET_UPDATED event since we want the updated data
	--TargetWindow doesn't exist during Init(), so hooking after interface is loaded	
	RegisterEventHandler(SystemData.Events.LOADING_END, "MyReasons.HookTargetWindow");	
 	RegisterEventHandler(SystemData.Events.INTERFACE_RELOADED, "MyReasons.HookTargetWindow");	
 	
 	-- Create windows and let em register
	CreateWindow("MyReasonsHostile", true)
	LayoutEditor.RegisterWindow( "MyReasonsHostile",
								L"MyReasonsHostile",
								L"Displays a note for the hostile target.",
								false, false,
								true, nil )
	WindowSetLayer("MyReasonsHostile", Window.Layers.OVERLAY)
								
	CreateWindow("MyReasonsFriendly", true)
	LayoutEditor.RegisterWindow( "MyReasonsFriendly",
								L"MyReasonsFriendly",
								L"Displays a note for the friendly target.",
								false, false,
								true, nil )
 	WindowSetLayer("MyReasonsFriendly", Window.Layers.OVERLAY)
 	
	-- check and recreate MyReasonsSavedData
	if not MyReasonsSavedData then 	
		MyReasonsSavedData = { }
		MyReasonsSavedData["version"] = MyReasons.Version
	end	
		
	-- determine a server name for this character
	MyReasons.ServerName = WStringToString(GameData.Account.ServerName)
	if not MyReasonsSavedData[MyReasons.ServerName] then
		MyReasonsSavedData[MyReasons.ServerName] = { }
	end	
	
	-- register slash commands
	if LibSlash then
		LibSlash.RegisterSlashCmd( "mr", function( args ) MyReasons.SlashCommand( args ) end )
		TextLogAddEntry( "Chat", filter, towstring( "MyReasons ("..MyReasons.Version..") loaded. Type /mr for options.") );
	else
		TextLogAddEntry( "Chat", filter, towstring( "MyReasons: LibSlash not installed. Slash commands disabled.") );		
	end	
	
	d(towstring("MyReasons "..MyReasons.Version.." Initialized."))
end	

-- Steal hook and make us do the magic
local runOnce = true
function MyReasons.HookTargetWindow()
	if runOnce then
		MyReasons.HookedUpdateTarget = TargetWindow.UpdateTarget	
		TargetWindow.UpdateTarget = MyReasons.OnUpdate
		runOnce = false
	end	
end

function MyReasons.OnUpdate(...)
	-- run the old target function
	MyReasons.HookedUpdateTarget(...)

	local hostileNote = L""
	local friendlyNote = L""
		
	if wstring.len(TargetInfo:UnitName("selfhostiletarget")) > 3 then
		hostileNote = MyReasons.FindNote(TargetInfo:UnitName("selfhostiletarget"))
	end
	
	if wstring.len(TargetInfo:UnitName("selffriendlytarget")) > 3 then
		friendlyNote = MyReasons.FindNote(TargetInfo:UnitName("selffriendlytarget"))
	end
	
	-- update text display
	LabelSetText("MyReasonsHostileText", hostileNote)
	LabelSetText("MyReasonsFriendlyText", friendlyNote)	
end 
    
function MyReasons.FindNote(playerName)
	playerName = string.upper(string.match(WStringToString(playerName), "(.+)(%^)(.+)"))
	if MyReasonsSavedData[MyReasons.ServerName][playerName] then
		return towstring(MyReasonsSavedData[MyReasons.ServerName][playerName])
	end
	return L""
end
  
-- Slash command handler, requires LibSlash to be installed
function MyReasons.SlashCommand(args)
	local opt, val = args:match( "([a-z0-9]+)[ ]?(.*)" )
	if opt == "add" then
		MyReasons.AddPlayer(val)
	elseif opt == "remove" then
		MyReasons.RemovePlayer(val)
	elseif opt == "reset" then
		MyReasons.ResetPlayers()
	else
		EA_ChatWindow.Print(L"Usage: /mr add name note")
		EA_ChatWindow.Print(L"Usage: /mr remove name")
		EA_ChatWindow.Print(L"Usage: /mr reset")
	end	
end

function MyReasons.AddPlayer(args)
	local name, note = args:match( "([a-zA-Z0-9]+)[ ]?(.*)" )
	
	if name then
		name = name:upper()
		MyReasonsSavedData[MyReasons.ServerName][name] = note
		EA_ChatWindow.Print(L"MyReasons: Added "..towstring(name)..L" with note: "..towstring(note))			
	end
end

function MyReasons.RemovePlayer(args)

	local name, rest = args:match( "([a-zA-Z0-9]+)[ ]?(.*)" )
		
	if name then
		name = name:upper()
		if MyReasonsSavedData[MyReasons.ServerName][name] then
			MyReasonsSavedData[MyReasons.ServerName][name] = nil
			EA_ChatWindow.Print(L"MyReasons: Removed note for "..towstring(name))
		else
			EA_ChatWindow.Print(L"MyReasons: No note exists for "..towstring(name))
		end
	
	end
	
end

function MyReasons.ResetPlayers()
	MyReasonsSavedData[MyReasons.ServerName] = {}
	EA_ChatWindow.Print(L"MyReasons: Reset all notes for "..towstring(MyReasons.ServerName)..L".")			
end

function MyReasons.TargetNote(note, friendlyTarget)
	local targetType = "selfhostiletarget"
	if friendlyTarget then
		targetType = "selffriendlytarget"
	end
	if TargetInfo:UnitType(targetType) == SystemData.TargetObjectType.ENEMY_PLAYER or TargetInfo:UnitType(targetType) == SystemData.TargetObjectType.ALLY_PLAYER then
		local name = TargetInfo:UnitName(targetType)
			name = name:upper()
			MyReasonsSavedData[MyReasons.ServerName][name] = note
			EA_ChatWindow.Print(L"MyReasons: Added "..towstring(name)..L" with note: "..towstring(note))
		return
	end
	EA_ChatWindow.Print(L"MyReasons: Your target is not a valid player.")	
end

function MyReasons.OnShutdown()
	TargetWindow.UpdateTarget = MyReasons.CareerTextHook
end
