<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
	<UiMod name="MyReasons" version="0.1" date="21/01/2009" >
	
		<Author name="Elendra" email="" />
		<Description text="Displays a note for friendly and hostile targets." />
		
		<Files>
			<File name="MyReasons.xml" />
		</Files>

		<Dependencies>
			<Dependency name="LibSlash" />
		</Dependencies>

		<SavedVariables>
			<SavedVariable name="MyReasonsSavedData" />
		</SavedVariables>

		<OnInitialize>
			<CallFunction name="MyReasons.OnInitialize" />
		</OnInitialize>
		
		<OnShutdown>
			<CallFunction name="MyReasons.OnShutdown" />
		</OnShutdown>

</UiMod>
</ModuleFile>