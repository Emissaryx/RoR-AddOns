<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <UiMod name="Tortall_DPS_Reborn" version="1.1.0" date="2026-06-06">
    <VersionSettings gameVersion="1.4.8" windowsVersion="1.0" savedVariablesVersion="1.0" />
    <Author name="Tortall Updated by Emissary" email="emissary@returnofreckoning.com" />
    <Description text="Tortall's DPS Meter - Reborn Edition. Combined and improved." />
    <Dependencies>
      <Dependency name="EATemplate_DefaultWindowSkin" />
      <Dependency name="EASystem_Utils" />
      <Dependency name="EASystem_WindowUtils" />
      <Dependency name="EASystem_Tooltips" />
      <Dependency name="EASystem_LayoutEditor" />
      <Dependency name="EA_ChatWindow" />
    </Dependencies>
    <Files>
      <File name="TortallDPS_Core.lua" />
      <File name="TortallDPS_Core_ru.lua" />
      <File name="Tortall_DPS.lua" />
      <File name="Tortall_DPS_Detail.xml" />
      <File name="Tortall_DPS_Toggle.xml" />
      <File name="Tortall_DPS.xml" />
    </Files>
    <OnInitialize>
      <CallFunction name="TortallDPSCore.Initialize" />
      <CreateWindow name="TortallDPSToggle" show="true" />
      <CreateWindow name="TortallDPSMeterGroupWindow" show="false" />
      <CreateWindow name="TortallDPSMeter" show="false" />
    </OnInitialize>
    <OnShutdown>
      <CallFunction name="TortallDPSCore.Shutdown" />
    </OnShutdown>
    <OnUpdate>
      <CallFunction name="TortallDPSMeter.Update" />
    </OnUpdate>
    <SavedVariables>
      <SavedVariable name="TortallDPSCore.SavedState" />
      <SavedVariable name="TortallDPSMeter.Settings" />
    </SavedVariables>
  </UiMod>
</ModuleFile>