<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
    <UiMod name="WBStutterLess" version="2.2" date="20/01/2022" >
        <VersionSettings gameVersion="1.4.8" windowsVersion="1.0" savedVariablesVersion="1.0" />
        
        <Author name="Zapz"/>
        <Description text="Reduces stutters in warband during keeps/forts. Also adds a toggle/macro for overhead nameplates/healthbars/abilty effects in user settings to help reduce lag" />
        
        <Files>
            <File name="WBStutterLess.xml" />
        </Files>
        
        <OnInitialize>
            <CallFunction name="WBStutterLess.Initialize" /> 
        </OnInitialize> 
        
        <SavedVariables>
            <SavedVariable name="WBStutterLess.Settings"/>
        </SavedVariables>
        
        <Dependencies>
            <Dependency name="Enemy" />
        </Dependencies>
        
    </UiMod>
</ModuleFile>