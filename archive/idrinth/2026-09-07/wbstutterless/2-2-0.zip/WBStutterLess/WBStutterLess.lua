WBStutterLess = {}

WBStutterLess.DefaultSettings   = {
    toggle                      = true,
    version                     = L"2.2",
    icon                        = 152,
}

WBStutterLess.DefaultLowName    = { 
    yourhealth      = 2,        npctitles       = true,     enemynpcs       = false,    enemytitles     = false,
    enemyhealth     = 3,        enemyplayers    = false,    target          = false,    enemyguilds     = false,
    friendlyhealth  = 2,        your            = false,    targetguild     = false,    friendlynpcs    = false,
    npchealth       = 2,        friendlyguilds  = false,    friendlyplayers = false,    targettitle     = false,
    grouphealth     = 2,        friendlytitles  = false,    yourguild       = false,    yourpet         = false,
    targethealth    = 2,        font            = 1,        yourtitle       = false,    abilityeffects  = 2,
}

---------------------------------------------------------------------------------------------------------------

---------------------------------------------------------------------------------------------------------------

local function shallowCopy(original)
    local copy = {}
    for key, value in pairs(original) do
        copy[key] = value
    end
    return copy
end

local function CreateUpdateMacro(MacroName, MacroText, MacroIcon)
    local Macros = GetMacrosData()
    local MacroId = nil

    for i = 1, #Macros do
        if Macros[i].name == towstring(MacroName) then
            MacroId = i
            break
        elseif ( Macros[i].text == L"" or Macros[i].iconNum == 0 ) and MacroId == nil then
            MacroId = i 
        end
    end

    if MacroId ~= nil then 
        SetMacroData( towstring(MacroName), towstring(MacroText), MacroIcon, MacroId )
        return true
    else
        return false
    end
end

function WBStutterLess.Initialize()
    RegisterEventHandler( SystemData.Events.ALL_MODULES_INITIALIZED,    "WBStutterLess.GroupWindowHook" )
    
    WBStutterLess.RestoreSavedSettings()
    WBStutterLess.UserSettingsUI()
    
    TextLogAddEntry( "Chat", 0, L"<icon69> WBStutterLess v".. WBStutterLess.DefaultSettings.version .. L": View 'WBS' tab in [U]ser Settings for toggle options." )
    if CreateUpdateMacro( L"WBStutterLess", L"/script WBStutterLess.Toggle()", WBStutterLess.Settings.icon) then
        TextLogAddEntry( "Chat", 0, L"<icon69> WBStutterLess: <icon52> Toggle macro updated! View macros ESC > 'Macros'")
    else
        TextLogAddEntry( "Chat", 0, L"<icon69> WBStutterLess: <icon41> Failed to create toggle macro. Manually create a macro name 'WBStutterLess' and save." )
        
        local old_Window_Macro_OnSave = EA_Window_Macro.OnSave
        EA_Window_Macro.OnSave = function ()
            old_Window_Macro_OnSave()
            
            local macroName = TextEditBoxGetText( "EA_Window_MacroDetailsName" )
            if macroName == L"WBStutterLess" then
                SetMacroData( macroName, L"/script WBStutterLess.Toggle()", WBStutterLess.Settings.icon, EA_Window_Macro.activeId )
            end
        end
    end
    
    if LibSlash then
        LibSlash.RegisterSlashCmd( "wbs", function(input) WBStutterLess.Slash(input) end )
    end
end

function WBStutterLess.Slash(input)
    if input == "reset" then
        WBStutterLess.Settings = nil
        InterfaceCore.ReloadUI()
    end
end

function WBStutterLess.RestoreSavedSettings()
    -- Init user settings window
    SettingsWindowTabbed.UpdateSettings()
    SettingsWindowTabbed.SelectTab(5)

    -- Load saved settings
    WBStutterLess.Settings          = ( WBStutterLess.Settings or WBStutterLess.DefaultSettings )
    WBStutterLess.Settings.LowNames = ( WBStutterLess.Settings.LowNames or WBStutterLess.DefaultLowName )
    
    -- Copy users settings
    if WBStutterLess.Settings.Names == nil then
        WBStutterLess.Settings.Names                = shallowCopy( SystemData.Settings.Names )
        WBStutterLess.Settings.Names.abilityeffects = SystemData.Settings.Performance.custom1.abilityEffects

        TextLogAddEntry( "Chat", 0, L"<icon69> WBStutterLess: <icon41> <icon57> User Settings Saved!" )
    end
end

function WBStutterLess.UserSettingsUI()
    local TabData = SettingsWindowTabbed.Tabs[SettingsWindowTabbed.TABS_TARGETTING]
    ButtonSetText(TabData.name, L"<icon69> WBS" )
    
    local windowName = "WBStutterLess"
    CreateWindowFromTemplate( windowName, "WBSTemplate", "SettingsWindowTabbed" )
    ButtonSetText( windowName.."Button", L"<icon69>WBStutterLess")
    ButtonSetCheckButtonFlag( windowName.."Button", true )

    local windowNameSettings = "WBStutterLessSettings"
    CreateWindowFromTemplate( windowNameSettings, "WBSSettingsTemplate", SettingsWindowTabTargetting.contentsName.."SettingsHealthbars" )
    LabelSetText( windowNameSettings.."Label", L"Custom 1 Ability Effects:" )
    ComboBoxAddMenuItem( windowNameSettings.."Combo", GetStringFromTable( "UserSettingsStrings",  StringTables.UserSettings.PERFORMANCE_ABILITY_EFFECTS_NONE ))
    ComboBoxAddMenuItem( windowNameSettings.."Combo", GetStringFromTable( "UserSettingsStrings",  StringTables.UserSettings.PERFORMANCE_ABILITY_EFFECTS_SELF ))
    ComboBoxAddMenuItem( windowNameSettings.."Combo", GetStringFromTable( "UserSettingsStrings",  StringTables.UserSettings.PERFORMANCE_ABILITY_EFFECTS_PARTY ))
    ComboBoxAddMenuItem( windowNameSettings.."Combo", GetStringFromTable( "UserSettingsStrings",  StringTables.UserSettings.PERFORMANCE_ABILITY_EFFECTS_WARBAND ))
    ComboBoxAddMenuItem( windowNameSettings.."Combo", GetStringFromTable( "UserSettingsStrings",  StringTables.UserSettings.PERFORMANCE_ABILITY_EFFECTS_ALL ))

    local old_target_updatesettings = SettingsWindowTabTargetting.UpdateSettings
    SettingsWindowTabTargetting.UpdateSettings = function()
        old_target_updatesettings()
        ComboBoxSetSelectedMenuItem( "WBStutterLessSettingsCombo", SystemData.Settings.Performance.custom1.abilityEffects )    
    end

    local old_target_applycurrent = SettingsWindowTabTargetting.ApplyCurrent
    SettingsWindowTabTargetting.ApplyCurrent = function()
        old_target_applycurrent()
        SystemData.Settings.Performance.custom1.abilityEffects = ComboBoxGetSelectedMenuItem( "WBStutterLessSettingsCombo" )
        
        if not WBStutterLess.Settings.toggle then
            WBStutterLess.Settings.LowNames                 = shallowCopy(SystemData.Settings.Names)
            WBStutterLess.Settings.LowNames.abilityeffects  = SystemData.Settings.Performance.custom1.abilityEffects
            WBStutterLess.Settings.icon                     = 145
        else
            WBStutterLess.Settings.Names                    = shallowCopy(SystemData.Settings.Names)
            WBStutterLess.Settings.Names.abilityeffects     = SystemData.Settings.Performance.custom1.abilityEffects
            WBStutterLess.Settings.icon                     = 152
        end  
    end
end

function WBStutterLess.OnMouseOverButton()
    Tooltips.CreateTextOnlyTooltip( "WBStutterLessButton", nil ) 
    Tooltips.SetTooltipText( 1, 1, L"Save and Toggle" )
    Tooltips.SetTooltipColorDef ( 1, 1, Tooltips.COLOR_HEADING )
    Tooltips.Finalize()
    Tooltips.AnchorTooltip( Tooltips.ANCHOR_WINDOW_TOP )
end

function WBStutterLess.OnLButtonUp()
    WBStutterLess.Toggle()
end

function WBStutterLess.SetSettings(names)
    SystemData.Settings.Names = shallowCopy(names)
    SystemData.Settings.Performance.custom1.abilityEffects = names.abilityeffects

    SettingsWindowTabTargetting.UpdateSettings()
    SettingsWindowTabbed.OnApplyButton()
end

function WBStutterLess.Toggle()
    if WindowGetShowing( "SettingsWindowTabbed" ) then SettingsWindowTabTargetting.ApplyCurrent() end

    if SystemData.Settings.Performance.perfLevel ~= 5 then
        WindowSetShowing( "SettingsWindowTabbed", true )
        SettingsWindowTabbed.SelectTab(2)   -- Video tab
        TextLogAddEntry( "Chat", 0, L"<icon69> WBStutterLess: <icon33> Please use video performance level: Custom 1" )
        return
    else
        SettingsWindowTabbed.SelectTab(5)   -- WBS tab
    end

    WBStutterLess.Settings.toggle = not WBStutterLess.Settings.toggle
    
    if WBStutterLess.Settings.toggle then
        WBStutterLess.SetSettings( WBStutterLess.Settings.Names )
        
        CreateUpdateMacro( L"WBStutterLess", L"/script WBStutterLess.Toggle()", WBStutterLess.Settings.icon ) 
        -- TextLogAddEntry( "Chat", 0, L"<icon69> WBStutterLess: <icon41> Toggle Off!" )
        WBStutterLess.Settings.toggle = true
    else
        WBStutterLess.SetSettings( WBStutterLess.Settings.LowNames )
        
        CreateUpdateMacro( L"WBStutterLess", L"/script WBStutterLess.Toggle()", WBStutterLess.Settings.icon ) 
        -- TextLogAddEntry( "Chat", 0, L"<icon69> WBStutterLess: <icon52> Toggle On!" )
        WBStutterLess.Settings.toggle = false
    end
end

---------------------------------------------------------------------------------------------------------------
-- Main stutter reduction function
---------------------------------------------------------------------------------------------------------------

function WBStutterLess.GroupWindowHook()
    UnregisterEventHandler( SystemData.Events.BATTLEGROUP_UPDATED,  "GroupWindow.OnGroupUpdated")
    UnregisterEventHandler( SystemData.Events.GROUP_PLAYER_ADDED,   "GroupWindow.OnGroupPlayerAdded")
    UnregisterEventHandler( SystemData.Events.GROUP_EFFECTS_UPDATED,"GroupWindow.OnEffectsUpdated")
    UnregisterEventHandler( SystemData.Events.GROUP_STATUS_UPDATED, "GroupWindow.OnStatusUpdated")

    WBStutterLess.DestroyGroupMembers()

    GroupWindow.OnScenarioBegin = function () end
    GroupWindow.ConditionalShow = function () end

    GroupWindow.OnScenarioEnd = function () 
        GroupWindow.inScenarioGroup = false 
        GroupWindow.UpdateGroupMembers()
    end

    GroupWindow.UpdateGroupMembers  = function () 
        if ( GroupWindow.groupData == nil ) then return end

        GroupWindow.inWorldGroup = GroupWindow.IsMemberValid( 1 )

        if( GameData.Player.isInScenario or GameData.Player.isInSiege )  then
            if( GroupWindow.inScenarioGroup == false ) then
                GroupWindow.inWorldGroup = false
            end
        end
    end
end

function WBStutterLess.DestroyGroupMembers()
    for index = 1, GroupWindow.MAX_GROUP_MEMBERS do
        if ( GroupWindow.groupMembers[index] ~= nil ) then
            local unitId = GroupWindow.groupMembers[index].m_unitId

            GroupWindow.groupMembers[index].m_RvRFrame:Destroy()
            GroupWindow.groupMembers[index]:Destroy()

            UnitFrames.m_UnitIdToFrameMapping[unitId] = nil
            GroupWindow.groupMembers[index] = nil
        end
        
        if ( GroupWindow.Buffs[index] ~= nil ) then
            GroupWindow.Buffs[index]:Shutdown()
            GroupWindow.Buffs[index] = nil
        end
    end
end