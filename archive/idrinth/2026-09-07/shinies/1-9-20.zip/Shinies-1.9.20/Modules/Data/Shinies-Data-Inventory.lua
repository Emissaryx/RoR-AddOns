--[[
	This application is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    The applications is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with the applications.  If not, see <http://www.gnu.org/licenses/>.
--]]

local Shinies 		= _G.Shinies
local T		    	= Shinies.T
local MODNAME 		= "Shinies-Data-Inventory"
local mod	 		= Shinies : NewModule( MODNAME, "WAR-AceTimer-3.0" )
ShiniesDataInventory	= mod
mod:SetModuleType( "Data" )
mod:SetName( T["Shinies Item Data Store"] )
mod:SetDescription( T["Provides a method of storing and retrieving current inventory and bank information."] )
mod:SetDefaults( 
{
	factionrealm =
	{
		chars = 
		{
			["**"] =									-- char slot
			{
				locs = 
				{
					["**"] =							-- item loc 
					{
						["**"] =						-- slot
						{
							uniqueID	= 0,
							stackCount	= 0,
						},
					},
				},
				items = 
				{
					["**"] =							-- item id
					{
						["**"] = 						-- item loc
						{
							["**"] = false				-- slot
						},
					
					},
				},
				totals 		= 
				{
					["**"] = 							-- itemLoc
					{
						["**"] =						-- item id
						{
							count		= 0,
						},
					},
				},
			},
		},
	},
} )

ShiniesDataInventory.callbacks = LibStub : GetLibrary( "WAR-CallbackHandler-1.0", true ) : New( ShiniesDataInventory )

local new, del, wipe = Shinies.new, Shinies.del, Shinies.wipe

local pairs 				= pairs
local ipairs				= ipairs
local tinsert				= table.insert
local tsort					= table.sort
local tostring				= tostring
local type					= type
local string_sub			= string.sub
local string_format			= string.format

local ShiniesAPI		= Shinies : GetModule( "Shinies-API-Core" )

local BANK_STORAGE_PREFIX = "BANK:"
local BANK_STORAGE_PREFIX_LENGTH = 5

local allItemSets = {}
allItemSets[GameData.ItemLocs.INVENTORY] 		= { data = DataUtils.GetItems }						-- 3
allItemSets[GameData.ItemLocs.BANK] 			= { data = DataUtils.GetBankData }					-- 4
allItemSets[GameData.ItemLocs.CRAFTING_ITEM] 	= { data = DataUtils.GetCraftingItems }				-- 30
allItemSets[GameData.ItemLocs.CURRENCY_ITEM] 	= { data = DataUtils.GetCurrencyItems }				-- 31

--
-- These are the items on the player, and do not require a specific location to access.
-- Bank items are stored separately by zone so multiple banks do not overwrite each other.
--
local playerSets = {}
playerSets[GameData.ItemLocs.INVENTORY]			= allItemSets[GameData.ItemLocs.INVENTORY]
playerSets[GameData.ItemLocs.CRAFTING_ITEM]		= allItemSets[GameData.ItemLocs.CRAFTING_ITEM]
playerSets[GameData.ItemLocs.CURRENCY_ITEM]		= allItemSets[GameData.ItemLocs.CURRENCY_ITEM]

local processItemSlotUpdated, processItemLoc, clearItemLoc

local invData

local pendingProcessing		= new()

local pendingTime			= 0.5
local currentBankItemLoc	= nil

local function GetCurrentBankItemLoc()
	if GameData ~= nil and GameData.Player ~= nil and GameData.Player.zone ~= nil then
		return BANK_STORAGE_PREFIX .. tostring(GameData.Player.zone)
	end

	return GameData.ItemLocs.BANK
end

local function IsBankStorageItemLoc( itemLoc )
	return type(itemLoc) == "string" and string_sub( itemLoc, 1, BANK_STORAGE_PREFIX_LENGTH ) == BANK_STORAGE_PREFIX
end

local function GetStoredItemCount(charData, itemLoc, itemId)
	if charData == nil or charData.totals == nil or charData.totals[itemLoc] == nil or charData.totals[itemLoc][itemId] == nil or charData.totals[itemLoc][itemId].count == nil then
		return 0
	end

	return charData.totals[itemLoc][itemId].count
end

local function GetStoredBankItemCount(charData, itemId)
	local count = 0
	local hasZoneBankData = false

	if charData == nil or charData.totals == nil then
		return 0
	end

	for itemLoc, _ in pairs( charData.totals )
	do
		if IsBankStorageItemLoc( itemLoc ) then
			hasZoneBankData = true
			count = count + GetStoredItemCount( charData, itemLoc, itemId )
		end
	end

	if not hasZoneBankData then
		count = count + GetStoredItemCount( charData, GameData.ItemLocs.BANK, itemId )
	end

	return count
end

local function GetLocationSummary(charData, itemLoc)
	local slots = 0
	local uniqueItems = 0
	local stackCount = 0

	if charData ~= nil and charData.locs ~= nil and charData.locs[itemLoc] ~= nil then
		for _ in pairs( charData.locs[itemLoc] )
		do
			slots = slots + 1
		end
	end

	if charData ~= nil and charData.totals ~= nil and charData.totals[itemLoc] ~= nil then
		for _, total in pairs( charData.totals[itemLoc] )
		do
			uniqueItems = uniqueItems + 1
			stackCount = stackCount + ( total.count or 0 )
		end
	end

	return slots, uniqueItems, stackCount
end

function mod:GetCharacterItemInfo( charSlot, itemId )
	local characterInventoryCount = 0
	local totalInventoryCount = 0
	
	-- Select the given characters database
	local chardb = self.db.factionrealm.chars[charSlot]
				   
	-- Get the count in the current player inventory count
	for itemLoc, _ in pairs( playerSets )
	do
		characterInventoryCount = characterInventoryCount + GetStoredItemCount(chardb, itemLoc, itemId)
	end
	
	-- Get the current total inventory count
	totalInventoryCount = characterInventoryCount
	totalInventoryCount = totalInventoryCount + GetStoredBankItemCount(chardb, itemId)
	
	return characterInventoryCount, totalInventoryCount
end

function mod:GetBankStatusLines()
	local lines = new()
	local bankRows = new()
	local charData = self.db.factionrealm.chars[GameData.Account.SelectedCharacterSlot]
	local currentBucket = GetCurrentBankItemLoc()

	tinsert( lines, "Shinies bank buckets for this character:" )
	tinsert( lines, "current zone bucket: " .. currentBucket )

	local slots, uniqueItems, stackCount = GetLocationSummary( charData, GameData.ItemLocs.BANK )
	tinsert( bankRows, {
		name = "legacy BANK",
		text = string_format( "legacy BANK slots=%d unique=%d stacks=%d", slots, uniqueItems, stackCount ),
	} )

	if charData ~= nil and charData.totals ~= nil then
		for itemLoc, _ in pairs( charData.totals )
		do
			if IsBankStorageItemLoc( itemLoc ) then
				slots, uniqueItems, stackCount = GetLocationSummary( charData, itemLoc )
				tinsert( bankRows, {
					name = itemLoc,
					text = string_format( "%s slots=%d unique=%d stacks=%d", itemLoc, slots, uniqueItems, stackCount ),
				} )
			end
		end
	end

	tsort( bankRows, function(a, b) return a.name < b.name end )

	for _, row in ipairs( bankRows )
	do
		tinsert( lines, row.text )
	end

	del( bankRows )

	return lines
end

function mod:OnInitialize()
end

function mod:OnEnable()
	RegisterEventHandler( SystemData.Events.INTERACT_OPEN_BANK, 				"ShiniesDataInventory.OnInteractBankOpen" )
	RegisterEventHandler( SystemData.Events.PLAYER_BANK_SLOT_UPDATED, 			"ShiniesDataInventory.OnPlayerBankSlotUpdated" )
	RegisterEventHandler( SystemData.Events.PLAYER_INVENTORY_SLOT_UPDATED, 		"ShiniesDataInventory.OnPlayerInventorySlotUpdated" )
	RegisterEventHandler( SystemData.Events.PLAYER_CRAFTING_SLOT_UPDATED, 		"ShiniesDataInventory.OnPlayerCraftingSlotUpdated" )
	RegisterEventHandler( SystemData.Events.PLAYER_CURRENCY_SLOT_UPDATED, 		"ShiniesDataInventory.OnPlayerCurrencySlotUpdated" )
	
	-- Create the basing pending processing tables we need
	for k, v in pairs( allItemSets )
	do
		pendingProcessing[k] = new()	
	end
	
	-- Update our database for easy access
	invData = self.db.factionrealm.chars[GameData.Account.SelectedCharacterSlot]

	-- Schedule a prlayer data update	
	ShiniesDataInventory:ScheduleTimer( "UpdatePlayerData", 1 )
end

function mod:OnDisable()
	UnregisterEventHandler( SystemData.Events.INTERACT_OPEN_BANK, 				"ShiniesDataInventory.OnInteractBankOpen" )
	UnregisterEventHandler( SystemData.Events.PLAYER_BANK_SLOT_UPDATED, 		"ShiniesDataInventory.OnPlayerBankSlotUpdated" )
	UnregisterEventHandler( SystemData.Events.PLAYER_INVENTORY_SLOT_UPDATED, 	"ShiniesDataInventory.OnPlayerInventorySlotUpdated" )
	UnregisterEventHandler( SystemData.Events.PLAYER_CRAFTING_SLOT_UPDATED, 	"ShiniesDataInventory.OnPlayerCraftingSlotUpdated" )
	UnregisterEventHandler( SystemData.Events.PLAYER_CURRENCY_SLOT_UPDATED, 	"ShiniesDataInventory.OnPlayerCurrencySlotUpdated" )
end

function ShiniesDataInventory.OnInteractBankOpen()
	-- Respect activity gating
	if Shinies and Shinies.IsActivityPaused and Shinies:IsActivityPaused() then return end

	currentBankItemLoc = GetCurrentBankItemLoc()

	-- Clear old pre-zone bank data. It is ambiguous, so repopulate the opened bank from live data.
	clearItemLoc( GameData.ItemLocs.BANK )

	-- We only clear the items we have stored for this bank, as
	-- we will receive slot updates for all of the items in the bank
	-- right after this event which will handle the updates
	clearItemLoc( currentBankItemLoc )
end

function ShiniesDataInventory.OnPlayerBankSlotUpdated( updatedSlots )
	-- Respect activity gating
	if Shinies and Shinies.IsActivityPaused and Shinies:IsActivityPaused() then return end

	if currentBankItemLoc == nil then
		currentBankItemLoc = GetCurrentBankItemLoc()
	end

	-- Add the updated slots to the processing queue
	tinsert( pendingProcessing[GameData.ItemLocs.BANK], { itemLoc = currentBankItemLoc, slots = updatedSlots } )
	
	ShiniesDataInventory:ScheduleTimer( "OnProcessingTimer", pendingTime )
end

function ShiniesDataInventory.OnPlayerInventorySlotUpdated( updatedSlots )
	-- Respect activity gating
	if Shinies and Shinies.IsActivityPaused and Shinies:IsActivityPaused() then return end
	-- Add the updated slots to the processing queue
	tinsert( pendingProcessing[GameData.ItemLocs.INVENTORY], updatedSlots )
	
	ShiniesDataInventory:ScheduleTimer( "OnProcessingTimer", pendingTime )
end

function ShiniesDataInventory.OnPlayerCraftingSlotUpdated( updatedSlots )
	-- Respect activity gating
	if Shinies and Shinies.IsActivityPaused and Shinies:IsActivityPaused() then return end
	-- Add the updated slots to the processing queue
	tinsert( pendingProcessing[GameData.ItemLocs.CRAFTING_ITEM], updatedSlots )
	
	ShiniesDataInventory:ScheduleTimer( "OnProcessingTimer", pendingTime )
end

function ShiniesDataInventory.OnPlayerCurrencySlotUpdated( updatedSlots )
	-- Respect activity gating
	if Shinies and Shinies.IsActivityPaused and Shinies:IsActivityPaused() then return end
	-- Add the updated slots to the processing queue
	tinsert( pendingProcessing[GameData.ItemLocs.CURRENCY_ITEM], updatedSlots )
	
	ShiniesDataInventory:ScheduleTimer( "OnProcessingTimer", pendingTime )
end

function mod:OnProcessingTimer()
	-- Respect activity gating
	if Shinies and Shinies.IsActivityPaused and Shinies:IsActivityPaused() then return end
	for itemLoc, locData in pairs( pendingProcessing )
	do
		for _, data in ipairs( locData )
		do
			if itemLoc == GameData.ItemLocs.BANK then
				processItemSlotUpdated( data.itemLoc or GetCurrentBankItemLoc(), data.slots, GameData.ItemLocs.BANK )
			else
				processItemSlotUpdated( itemLoc, data )	
			end
		end
		wipe(locData)
	end
end

function mod:UpdatePlayerData()
	-- Respect activity gating
	if Shinies and Shinies.IsActivityPaused and Shinies:IsActivityPaused() then return end
	for itemLoc, v in pairs( playerSets )
	do
		processItemLoc( itemLoc )	
	end
end

---------------------------------------------------------
-- LOCAL FUNCTIONS
---------------------------------------------------------

function clearItemLoc( itemLoc )
	-- Clear all tables for this item loc
	invData.totals[itemLoc] 	= nil
	invData.locs[itemLoc]		= nil
	for id, item in pairs( invData.items )
	do
		item[itemLoc] = nil
	end
end

function processItemLoc( itemLoc )
	-- Clear the info for this item loc
	clearItemLoc( itemLoc )

	-- Attempt to retrieve our data
	local data = allItemSets[itemLoc].data()
	if( data ~= nil ) then
		-- Iterate the data we received and process accordingly	
		for slot, item in ipairs( data )
		do
			processItemSlotUpdated( itemLoc, {slot} )
		end		
	end
end

function processItemSlotUpdated( itemLoc, updatedSlots, sourceItemLoc )
	local oldItem
	local newItem
	sourceItemLoc = sourceItemLoc or itemLoc

	-- Iterate the updated slots
	for idx, slot in ipairs( updatedSlots )
	do
		-- Get the old item id in the updated inventory slot
		oldItem = invData.locs[itemLoc][slot]
		
		-- Get the current item in the slot
		newItem = DataUtils.GetItemData( sourceItemLoc, slot )
		
		local isOldValid = oldItem ~= nil and ShiniesAPI:Item_IsValid( oldItem )
		local isNewValid = newItem ~= nil and ShiniesAPI:Item_IsValid( newItem )
		
		-- If the old item is valid, remove the information for it
		if( isOldValid ) then
			-- Remove the old slot information
			invData.locs[itemLoc][slot] = nil
			invData.items[oldItem.uniqueID][itemLoc][slot] = nil
			invData.totals[itemLoc][oldItem.uniqueID].count = invData.totals[itemLoc][oldItem.uniqueID].count - oldItem.stackCount
		end	 
		
		-- If the new item is valid, add its slot information
		if( isNewValid ) then
			-- Update our location map
			invData.locs[itemLoc][slot].uniqueID 	= newItem.uniqueID
			invData.locs[itemLoc][slot].stackCount	= newItem.stackCount
			
			-- Update the item map
			invData.items[newItem.uniqueID][itemLoc][slot] = true

			-- Update the totals for each location
			invData.totals[itemLoc][newItem.uniqueID].count = invData.totals[itemLoc][newItem.uniqueID].count + newItem.stackCount				
		end
		
	end
end
