<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
	<UiMod name="OneClickGTAOE" version="1.1.0" date="06/02/2025" >
		<Author name="Talladego" email="" />
		<Description text="OneClickGTAOE" />
		<VersionSettings gameVersion="1.4.8" windowsVersion="1.0" savedVariablesVersion="1.0" />
		<Files>
			<File name="OneClickGTAOE.lua" />						
		</Files>
	</UiMod>
</ModuleFile>
