OneClickGTAOE = OneClickGTAOE or {}

OneClickGTAOE.Abilities = {
	-- Common
	[651] = true, 	-- Hail of Doom
	-- Archmage
	[9251] = true, 	-- Mistress of the Marsh
	[9309] = true, 	-- Flames of the Phoenix
	-- Bright Wizard
	[8177] = true, 	-- Rain of Fire
	[8222] = true, 	-- Conflagration of Doom
	-- Shadow Warrior
	[9142] = true, 	-- Rain of Steel
	-- Engineer
	[1581] = true, 	-- Artillery Barrage
	[1537] = true, 	-- Napalm Grenade
	[1541] = true, 	-- Phosphorous Shells
	[1524] = true, 	-- Land Mine
	-- Rune Priest
	[1612] = true, 	-- Master Rune of Fury
	[1615] = true, 	-- Master Rune of Speed
	[1618] = true, 	-- Master Rune of Adamant
	[6039] = true, 	-- Runic Conduit
	[32583] = true, -- Runic Conduit
	-- Shaman
	[1927] = true, 	-- Sticky Feetz
	-- Zealot
	[8572] = true, 	-- Ritual of Innervation
	[8574] = true, 	-- Ritual of Superiority
	[8577] = true, 	-- Ritual of Lunacy
	[6040] = true, 	-- Ritual Nexus
	[35594] = true, -- Ritual Nexus
	-- Magus
	[8494] = true, 	-- Dissolving Mist
	[8498] = true, 	-- Tzeentch's Firestorm
	[8541] = true, 	-- Daemonic Infestation
	-- Sorceror
	[9485] = true, 	-- Pit of Shades
}

local orgActionButtonOnLButtonDown = ActionButton.OnLButtonDown
function ActionButton.OnLButtonDown(self, flags, x, y)
		orgActionButtonOnLButtonDown(self, flags, x, y)
		if flags == SystemData.ButtonFlags.GAME_ACTION and OneClickGTAOE.Abilities[self.m_ActionId] then
			WindowGameAction( SystemData.ActiveWindow.name )
		end
end