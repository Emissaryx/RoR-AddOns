<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
    <UiMod name="AAOPopCalc" version="0.2.0" date="2026-05-08">
        <Author name="Wholdar, leftayparxoun" />
        <Description text="Shows AAO-narrowed population estimates for current RoR_SoR open zones." />
        <VersionSettings gameVersion="1.4.8" windowsVersion="0.1" />
        <Dependencies>
            <Dependency name="RoR_SoR" />
            <Dependency name="LibSlash" optional="true" forceEnable="true" />
        </Dependencies>
        <Files>
            <File name="AAOPopCalc.xml" />
            <File name="AAOPopCalc.lua" />
        </Files>
        <OnInitialize>
            <CallFunction name="AAOPopCalc.OnInitialize" />
        </OnInitialize>
        <OnUpdate>
            <CallFunction name="AAOPopCalc.OnUpdate" />
        </OnUpdate>
    </UiMod>
</ModuleFile>
