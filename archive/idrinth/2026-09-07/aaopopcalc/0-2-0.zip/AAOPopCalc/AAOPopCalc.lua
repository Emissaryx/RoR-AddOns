AAOPopCalc = AAOPopCalc or {}

local Calc = AAOPopCalc
Calc.CHAT_PREFIX = "<icon29962> [<LINK data=\"0\" color=\"255,204,102\" text=\"APC\">] "
Calc.AAO_HOVER_TEMPLATE = "AAOPopCalc_AAOHoverTemplate"
Calc.AAO_HOVER_PREFIX = "AAOPopCalc_AAO_"
Calc.AAO_HOVER_WIDTH = 78
Calc.AAO_HOVER_HEIGHT = 30
Calc.REALM_HOVER_TEMPLATE = "AAOPopCalc_RealmHoverTemplate"
Calc.REALM_HOVER_PREFIX = "AAOPopCalc_POP_"
Calc.REALM_HOVER_WIDTH = 50
Calc.REALM_HOVER_HEIGHT = 30

Calc._slashRegistered = Calc._slashRegistered or false
Calc._slashMissingReported = Calc._slashMissingReported or false
Calc._tooltipHooked = Calc._tooltipHooked or false
Calc._originalOnMouseOverStart = Calc._originalOnMouseOverStart or nil
Calc._aaoHoverWindows = Calc._aaoHoverWindows or {}
Calc._realmHoverWindows = Calc._realmHoverWindows or {}
Calc._refreshElapsed = Calc._refreshElapsed or 0

local POP_LABEL_RANGES = {
    scouts = { low = 0, high = 9 },
    parties = { low = 10, high = 24 },
    warbands = { low = 25, high = 99 },
    vanguard = { low = 100, high = 199 },
    battlehost = { low = 200, high = 299 },
    warhost = { low = 300, high = nil },
}

local REALM_NAMES = {
    [1] = "Order",
    [2] = "Destro",
}

local ZONE_LINK_COLOR = "210,180,140"
local REALM_LINK_COLORS = {
    [1] = "100,170,255",
    [2] = "255,80,80",
}
local RAW_REALM_LINK_COLORS = {
    [1] = "170,215,255",
    [2] = "255,170,170",
}
local STALE_AAO_TEXT = "AAO lag?"
local MAX_VISIBLE_AAO_PERCENT = 400
local REFRESH_INTERVAL = 1

local function toWString(text)
    if towstring then
        local ok, result = pcall(towstring, text or "")
        if ok and result ~= nil then
            return result
        end
    end

    return text or ""
end

local function toString(value)
    if value == nil then
        return ""
    end

    if type(value) == "string" then
        return value
    end

    if type(value) == "number" or type(value) == "boolean" then
        return tostring(value)
    end

    if WStringToString then
        local ok, text = pcall(WStringToString, value)
        if ok and type(text) == "string" then
            return text
        end
    end

    local ok, text = pcall(tostring, value)
    if ok and type(text) == "string" then
        return text
    end

    return ""
end

local function trim(text)
    local value = toString(text)
    value = string.gsub(value, "^%s+", "")
    value = string.gsub(value, "%s+$", "")
    return value
end

local function chatPrint(message)
    local line = toWString(Calc.CHAT_PREFIX .. toString(message))
    if EA_ChatWindow and EA_ChatWindow.Print then
        EA_ChatWindow.Print(line)
    elseif TextLogAddEntry then
        TextLogAddEntry("Chat", 0, line)
    end
end

local function windowExists(windowName)
    if windowName == nil or type(DoesWindowExist) ~= "function" then
        return false
    end

    local ok, exists = pcall(DoesWindowExist, windowName)
    return ok and exists == true
end

local function coloredLink(text, color)
    return "<LINK data=\"\" text=\"" .. toString(text) .. "\" color=\"" .. toString(color) .. "\">"
end

local function copyRange(range)
    if type(range) ~= "table" then
        return nil
    end

    return {
        low = range.low,
        high = range.high,
    }
end

function Calc.ParsePopulationRange(value)
    if type(value) == "number" then
        return {
            low = value,
            high = value,
        }
    end

    local text = trim(value)
    if text == "" then
        return nil
    end

    local normalized = string.lower(text)
    local namedRange = POP_LABEL_RANGES[normalized]
    if namedRange ~= nil then
        return copyRange(namedRange)
    end

    local lowText, highText = string.match(text, "^(%d+)%s*%-%s*(%d+)$")
    if lowText ~= nil and highText ~= nil then
        local low = tonumber(lowText)
        local high = tonumber(highText)
        if low ~= nil and high ~= nil then
            return {
                low = low,
                high = high,
            }
        end
    end

    local openLowText = string.match(text, "^(%d+)%s*%+$")
    if openLowText ~= nil then
        local low = tonumber(openLowText)
        if low ~= nil then
            return {
                low = low,
                high = nil,
            }
        end
    end

    local exact = tonumber(text)
    if exact ~= nil then
        return {
            low = exact,
            high = exact,
        }
    end

    return nil
end

local function maxValue(left, right)
    if left == nil then
        return right
    end

    if right == nil then
        return left
    end

    return math.max(left, right)
end

local function minValue(left, right)
    if left == nil then
        return right
    end

    if right == nil then
        return left
    end

    return math.min(left, right)
end

local function ceilValue(value)
    return math.ceil(value - 0.000001)
end

local function floorValue(value)
    return math.floor(value + 0.000001)
end

local function estimateFromIntegerPairs(high, low, aaoPercent)
    if high.high == nil or low.high == nil then
        return nil
    end

    local aao = aaoPercent / 100
    local isCappedAAO = aaoPercent == MAX_VISIBLE_AAO_PERCENT
    local ratioLow = aao + 0.9
    local ratioHigh = nil
    if not isCappedAAO then
        ratioHigh = aao + 1.1
    end
    local highStart = maxValue(high.low, 1)
    local lowStart = maxValue(low.low, isCappedAAO and 0 or 1)
    local result = {
        high = {},
        low = {},
        valid = false,
    }

    for lowPop = lowStart, low.high do
        for highPop = highStart, high.high do
            local validPair = false
            if isCappedAAO and lowPop == 0 then
                validPair = highPop > 0
            elseif lowPop > 0 then
                local ratio = highPop / lowPop
                validPair = ratio + 0.000001 >= ratioLow
                    and (ratioHigh == nil or ratio - 0.000001 <= ratioHigh)
            end

            if validPair then
                result.valid = true
                result.high.low = minValue(result.high.low, highPop)
                result.high.high = maxValue(result.high.high, highPop)
                result.low.low = minValue(result.low.low, lowPop)
                result.low.high = maxValue(result.low.high, lowPop)
            end
        end
    end

    return result
end

function Calc.EstimateNoAAOFromRanges(orderRange, destroRange)
    local order = copyRange(orderRange)
    local destro = copyRange(destroRange)

    if type(order) ~= "table" or type(destro) ~= "table" then
        return nil
    end

    if order.low == nil or order.high == nil or destro.low == nil or destro.high == nil then
        return nil
    end

    local result = {
        order = {},
        destro = {},
        valid = false,
    }

    local function includePair(orderPop, destroPop)
        result.valid = true
        result.order.low = minValue(result.order.low, orderPop)
        result.order.high = maxValue(result.order.high, orderPop)
        result.destro.low = minValue(result.destro.low, destroPop)
        result.destro.high = maxValue(result.destro.high, destroPop)
    end

    for orderPop = order.low, order.high do
        for destroPop = destro.low, destro.high do
            local validPair = false
            if orderPop == 0 and destroPop == 0 then
                validPair = true
            elseif orderPop > 0 and destroPop > 0 then
                local highPop = math.max(orderPop, destroPop)
                local lowPop = math.min(orderPop, destroPop)
                validPair = highPop / lowPop <= 1.1 + 0.000001
            end

            if validPair then
                includePair(orderPop, destroPop)
            end
        end
    end

    if result.valid ~= true then
        if destro.high ~= nil and order.low == destro.high + 1 and destro.high > 0 then
            includePair(order.low, destro.high)
        elseif order.high ~= nil and destro.low == order.high + 1 and order.high > 0 then
            includePair(order.high, destro.low)
        end
    end

    return result
end

function Calc.EstimateFromRanges(highRange, lowRange, aaoPercent)
    local high = copyRange(highRange)
    local low = copyRange(lowRange)
    local percent = tonumber(aaoPercent)

    if type(high) ~= "table" or type(low) ~= "table" or percent == nil or percent <= 0 then
        return nil
    end

    if high.low == nil or low.low == nil then
        return nil
    end

    local integerEstimate = estimateFromIntegerPairs(high, low, percent)
    if integerEstimate ~= nil then
        return integerEstimate
    end

    local aao = percent / 100
    local isCappedAAO = percent == MAX_VISIBLE_AAO_PERCENT
    local ratioHigh = nil
    if not isCappedAAO then
        ratioHigh = aao + 1.1
    end
    local liveLowMinimum = maxValue(low.low, isCappedAAO and 0 or 1)
    local highLowerFromLow
    if isCappedAAO and liveLowMinimum == 0 then
        highLowerFromLow = 1
    else
        highLowerFromLow = ceilValue((aao + 0.9) * liveLowMinimum)
    end
    local highUpperFromLow = nil
    if ratioHigh ~= nil and low.high ~= nil then
        highUpperFromLow = floorValue(ratioHigh * low.high)
    end

    local lowLowerFromHigh = nil
    if ratioHigh ~= nil then
        lowLowerFromHigh = ceilValue((maxValue(high.low, 1)) / ratioHigh)
    end
    local lowUpperFromHigh = nil
    if high.high ~= nil then
        lowUpperFromHigh = floorValue(high.high / (aao + 0.9))
    end

    local narrowedHigh = {
        low = maxValue(high.low, highLowerFromLow),
        high = minValue(high.high, highUpperFromLow),
    }

    local narrowedLow = {
        low = maxValue(liveLowMinimum, lowLowerFromHigh),
        high = minValue(low.high, lowUpperFromHigh),
    }

    local valid = true
    if narrowedHigh.high ~= nil and narrowedHigh.low > narrowedHigh.high then
        valid = false
    end
    if narrowedLow.high ~= nil and narrowedLow.low > narrowedLow.high then
        valid = false
    end

    return {
        high = narrowedHigh,
        low = narrowedLow,
        valid = valid,
    }
end

function Calc.FormatRange(range)
    if type(range) ~= "table" or range.low == nil then
        return "?"
    end

    if range.high == nil then
        return tostring(range.low) .. "+"
    end

    if range.low == range.high then
        return tostring(range.low)
    end

    return tostring(range.low) .. "-" .. tostring(range.high)
end

local function getRealmColorDef(realm)
    local realmNumber = tonumber(realm)
    if type(RoR_SoR) == "table" and type(RoR_SoR.RealmColors) == "table" and realmNumber ~= nil then
        return RoR_SoR.RealmColors[realmNumber + 1] or RoR_SoR.RealmColors[1]
    end

    if type(Tooltips) == "table" then
        return Tooltips.COLOR_BODY or Tooltips.MAP_DESC_TEXT_COLOR or 1
    end

    return 1
end

local function getTooltipTitleColor()
    if type(Tooltips) == "table" then
        return Tooltips.MAP_DESC_TEXT_COLOR or Tooltips.COLOR_BODY or 1
    end

    return 1
end

local function setTooltipText(row, column, text)
    if type(Tooltips) == "table" and type(Tooltips.SetTooltipText) == "function" then
        Tooltips.SetTooltipText(row, column, toWString(text))
    end
end

local function setTooltipColor(row, column, colorDef)
    if type(Tooltips) == "table" and type(Tooltips.SetTooltipColorDef) == "function" then
        Tooltips.SetTooltipColorDef(row, column, colorDef)
    end
end

local function formatColoredNumber(value, color)
    return coloredLink(tostring(value), color)
end

local function formatColoredRange(range, color)
    if type(range) ~= "table" or range.low == nil then
        return "?"
    end

    if range.high == nil then
        return formatColoredNumber(range.low, color) .. "+"
    end

    if range.low == range.high then
        return formatColoredNumber(range.low, color)
    end

    return formatColoredNumber(range.low, color) .. "-" .. formatColoredNumber(range.high, color)
end

local function formatColoredPercent(value, color)
    return formatColoredNumber(value or 0, color) .. "%"
end

local function getRealmName(realm)
    return REALM_NAMES[tonumber(realm)] or "Realm " .. tostring(realm or "?")
end

local function formatRealmName(realm, linkColor)
    local realmNumber = tonumber(realm)
    local color = linkColor or REALM_LINK_COLORS[realmNumber]
    local name = getRealmName(realmNumber)
    if color == nil then
        return name
    end

    return coloredLink(name, color)
end

local function getOppositeRealm(realm)
    local value = tonumber(realm)
    if value == 1 then
        return 2
    end

    if value == 2 then
        return 1
    end

    return nil
end

local function getZoneName(zoneId)
    local zoneNumber = tonumber(zoneId)
    if zoneNumber == nil then
        return tostring(zoneId or "?")
    end

    if type(RoR_SoR) == "table" and type(RoR_SoR.ZoneNames) == "table" then
        local pair = RoR_SoR.ZoneNames[zoneNumber]
        if type(pair) == "table" and pair[1] ~= nil and pair[2] ~= nil and pair[1] ~= pair[2] then
            local left = ""
            local right = ""

            if type(GetZoneName) == "function" then
                left = toString(GetZoneName(tonumber(pair[1])))
                right = toString(GetZoneName(tonumber(pair[2])))
            end

            if left ~= "" and right ~= "" then
                return left .. " / " .. right
            end
        end
    end

    if type(GetZoneName) == "function" then
        local name = toString(GetZoneName(zoneNumber))
        if name ~= "" then
            return name
        end
    end

    return "Zone " .. tostring(zoneNumber)
end

local function isNormalZone(zoneId)
    local zoneNumber = tonumber(zoneId)
    if zoneNumber == nil then
        return false
    end

    if type(RoR_SoR) == "table" and type(RoR_SoR.Forts) == "table" and RoR_SoR.Forts[zoneNumber] ~= nil then
        return false
    end

    if zoneNumber == 161 or zoneNumber == 162 then
        return false
    end

    return true
end

local function getRangeForRealm(orderRange, destroRange, realm)
    if tonumber(realm) == 1 then
        return orderRange
    end

    if tonumber(realm) == 2 then
        return destroRange
    end

    return nil
end

function Calc.BuildZoneEstimate(zoneId, status)
    if type(status) ~= "table" then
        return nil
    end

    local orderRange = Calc.ParsePopulationRange(status.Order_Pop)
    local destroRange = Calc.ParsePopulationRange(status.Destro_Pop)
    if orderRange == nil or destroRange == nil then
        return {
            zoneId = tonumber(zoneId),
            zoneName = getZoneName(zoneId),
            orderRaw = orderRange,
            destroRaw = destroRange,
            error = "population range unavailable",
        }
    end

    local aaoRealm = tonumber(status.AAO)
    local aaoPercent = tonumber(status.AAOMulti)
    local estimate = nil
    local noAAOEstimate = nil
    local lowRealm = nil
    local highRealm = nil

    if aaoRealm == 1 or aaoRealm == 2 then
        lowRealm = aaoRealm
        highRealm = getOppositeRealm(aaoRealm)
        estimate = Calc.EstimateFromRanges(
            getRangeForRealm(orderRange, destroRange, highRealm),
            getRangeForRealm(orderRange, destroRange, lowRealm),
            aaoPercent
        )
    else
        noAAOEstimate = Calc.EstimateNoAAOFromRanges(orderRange, destroRange)
    end

    return {
        zoneId = tonumber(zoneId),
        zoneName = getZoneName(zoneId),
        tier = tonumber(status.Tier),
        orderRaw = orderRange,
        destroRaw = destroRange,
        aaoRealm = aaoRealm,
        aaoPercent = aaoPercent,
        lowRealm = lowRealm,
        highRealm = highRealm,
        estimate = estimate,
        noAAOEstimate = noAAOEstimate,
    }
end

local function getDisplayRanges(entry)
    if type(entry) ~= "table" then
        return nil
    end

    local display = {
        order = entry.orderRaw,
        destro = entry.destroRaw,
        aaoRealm = nil,
        aaoPercent = nil,
        suffixText = "no AAO",
        suffixTail = "",
    }

    if type(entry.estimate) == "table" and entry.estimate.valid == true then
        if entry.highRealm == 1 then
            display.order = entry.estimate.high
            display.destro = entry.estimate.low
        elseif entry.highRealm == 2 then
            display.destro = entry.estimate.high
            display.order = entry.estimate.low
        end

        display.aaoRealm = entry.lowRealm
        display.aaoPercent = entry.aaoPercent
    elseif type(entry.estimate) == "table" and entry.estimate.valid == false then
        display.aaoRealm = entry.lowRealm
        display.aaoPercent = entry.aaoPercent
        display.suffixTail = ", " .. STALE_AAO_TEXT
    elseif entry.aaoRealm == 1 or entry.aaoRealm == 2 then
        display.aaoRealm = entry.aaoRealm
        display.aaoPercent = entry.aaoPercent
        display.suffixTail = ", estimate unavailable"
    elseif type(entry.noAAOEstimate) == "table" and entry.noAAOEstimate.valid == true then
        display.order = entry.noAAOEstimate.order
        display.destro = entry.noAAOEstimate.destro
    elseif type(entry.noAAOEstimate) == "table" and entry.noAAOEstimate.valid == false then
        display.suffixText = "no AAO, " .. STALE_AAO_TEXT
    end

    if display.aaoRealm ~= nil then
        display.suffixText = "AAO "
            .. getRealmName(display.aaoRealm)
            .. " "
            .. tostring(display.aaoPercent or 0)
            .. "%"
            .. display.suffixTail
    end

    return display
end

local function buildOutputLine(entry)
    if type(entry) ~= "table" then
        return nil
    end

    local zoneName = coloredLink(entry.zoneName, ZONE_LINK_COLOR)

    if entry.error ~= nil then
        return zoneName .. ": " .. entry.error .. "."
    end

    local orderColor = REALM_LINK_COLORS[1]
    local destroColor = REALM_LINK_COLORS[2]
    local rawOrderColor = RAW_REALM_LINK_COLORS[1]
    local rawDestroColor = RAW_REALM_LINK_COLORS[2]
    local display = getDisplayRanges(entry)
    if display == nil then
        return nil
    end

    local suffix = display.suffixText
    if display.aaoRealm ~= nil then
        local aaoRealmNumber = tonumber(display.aaoRealm)
        local aaoColor = RAW_REALM_LINK_COLORS[aaoRealmNumber]
        suffix = "AAO "
            .. formatRealmName(display.aaoRealm, aaoColor)
            .. " "
            .. formatColoredPercent(display.aaoPercent, aaoColor)
            .. display.suffixTail
    end

    return zoneName
        .. ": "
        .. formatColoredRange(display.order, orderColor)
        .. " / "
        .. formatColoredRange(display.destro, destroColor)
        .. " (SoR "
        .. formatColoredRange(entry.orderRaw, rawOrderColor)
        .. " / "
        .. formatColoredRange(entry.destroRaw, rawDestroColor)
        .. ", "
        .. suffix
        .. ")"
end

local function getZoneStatus(zoneId)
    if type(RoR_SoR) ~= "table" or type(RoR_SoR.ZoneStatus) ~= "table" then
        return nil
    end

    return RoR_SoR.ZoneStatus[tostring(zoneId)] or RoR_SoR.ZoneStatus[tonumber(zoneId)]
end

function Calc.ShowRealmPopulationTooltip(zoneId, realm, windowName)
    if type(Tooltips) ~= "table" or type(Tooltips.CreateTextOnlyTooltip) ~= "function" then
        return false
    end

    local entry = Calc.BuildZoneEstimate(zoneId, getZoneStatus(zoneId))
    if type(entry) ~= "table" then
        return false
    end

    local text = entry.error
    if text == nil then
        local display = getDisplayRanges(entry)
        if type(display) ~= "table" then
            return false
        end

        if tonumber(realm) == 1 then
            text = Calc.FormatRange(display.order)
        elseif tonumber(realm) == 2 then
            text = Calc.FormatRange(display.destro)
        else
            return false
        end
    end

    Tooltips.CreateTextOnlyTooltip(windowName, nil)
    setTooltipText(1, 1, text)
    setTooltipColor(1, 1, getRealmColorDef(realm))

    if type(Tooltips.Finalize) == "function" then
        Tooltips.Finalize()
    end
    if type(Tooltips.AnchorTooltip) == "function" then
        Tooltips.AnchorTooltip(Tooltips.ANCHOR_WINDOW_TOP)
    end

    return true
end

function Calc.ShowGuildTooltip(zoneId, windowName)
    if type(Tooltips) ~= "table" or type(Tooltips.CreateTextOnlyTooltip) ~= "function" then
        return false
    end

    local guilds = nil
    if type(RoR_SoR) == "table" and type(RoR_SoR.InvolvedGuilds) == "table" then
        guilds = RoR_SoR.InvolvedGuilds[tostring(zoneId)] or RoR_SoR.InvolvedGuilds[tonumber(zoneId)]
    end

    Tooltips.CreateTextOnlyTooltip(windowName, nil)
    if type(guilds) == "table" and #guilds > 0 then
        setTooltipText(1, 1, "Involved Guilds:")
        setTooltipColor(1, 1, getTooltipTitleColor())

        local guildLine = ""
        for _, guildName in pairs(guilds) do
            guildLine = guildLine .. "<icon20204> " .. toString(guildName) .. "<br>"
        end
        setTooltipText(3, 1, guildLine)
    else
        setTooltipText(1, 1, "No Guilds Involved")
        setTooltipColor(1, 1, getTooltipTitleColor())
    end

    setTooltipColor(3, 1, getRealmColorDef(0))

    if type(Tooltips.Finalize) == "function" then
        Tooltips.Finalize()
    end
    if type(Tooltips.AnchorTooltip) == "function" then
        Tooltips.AnchorTooltip(Tooltips.ANCHOR_WINDOW_TOP)
    end

    return true
end

function Calc.GetOpenZoneEstimates()
    local entries = {}

    if type(RoR_SoR) ~= "table" or type(RoR_SoR.OpenZones) ~= "table" or type(RoR_SoR.ZoneStatus) ~= "table" then
        return entries
    end

    for zoneKey, _ in pairs(RoR_SoR.OpenZones) do
        local zoneId = tonumber(zoneKey)
        if zoneId ~= nil and isNormalZone(zoneId) then
            local status = RoR_SoR.ZoneStatus[tostring(zoneId)]
            local entry = Calc.BuildZoneEstimate(zoneId, status)
            if entry ~= nil then
                entries[#entries + 1] = entry
            end
        end
    end

    table.sort(entries, function(left, right)
        local leftTier = tonumber(left.tier) or 0
        local rightTier = tonumber(right.tier) or 0
        if leftTier ~= rightTier then
            return leftTier > rightTier
        end

        return tostring(left.zoneName or "") < tostring(right.zoneName or "")
    end)

    return entries
end

function Calc.GetPopulationZoneIdFromWindow(windowName)
    local zoneId = tonumber(string.match(toString(windowName), "^SoR_(%d+)POP$"))
    if zoneId ~= nil and isNormalZone(zoneId) then
        return zoneId
    end

    return nil
end

function Calc.GetAAOZoneIdFromWindow(windowName)
    local name = toString(windowName)
    local zoneId = tonumber(string.match(name, "^SoR_(%d+)AAO$"))
    if zoneId == nil then
        zoneId = tonumber(string.match(name, "^SoR_(%d+)AAO_BG$"))
    end
    if zoneId == nil then
        zoneId = tonumber(string.match(name, "^" .. Calc.AAO_HOVER_PREFIX .. "(%d+)$"))
    end

    if zoneId ~= nil and isNormalZone(zoneId) then
        return zoneId
    end

    return nil
end

function Calc.GetPopulationRealmFromWindow(windowName)
    local name = toString(windowName)
    local realmName, zoneText = string.match(name, "^" .. Calc.REALM_HOVER_PREFIX .. "(%a+)_(%d+)$")
    local zoneId = tonumber(zoneText)
    if zoneId == nil or not isNormalZone(zoneId) then
        return nil, nil
    end

    if realmName == "Order" then
        return zoneId, 1
    end

    if realmName == "Destro" then
        return zoneId, 2
    end

    return nil, nil
end

local function getMouseOverWindowName()
    if type(SystemData) ~= "table" or type(SystemData.MouseOverWindow) ~= "table" then
        return ""
    end

    return toString(SystemData.MouseOverWindow.name)
end

function Calc.OnRoRSORMouseOverStart(...)
    local windowName = getMouseOverWindowName()
    local realmZoneId, realm = Calc.GetPopulationRealmFromWindow(windowName)
    if realmZoneId ~= nil and Calc.ShowRealmPopulationTooltip(realmZoneId, realm, windowName) then
        return
    end

    local aaoZoneId = Calc.GetAAOZoneIdFromWindow(windowName)
    if aaoZoneId ~= nil and Calc.ShowGuildTooltip(aaoZoneId, windowName) then
        return
    end

    local popZoneId = Calc.GetPopulationZoneIdFromWindow(windowName)
    if popZoneId ~= nil then
        return
    end

    if type(Calc._originalOnMouseOverStart) == "function" then
        return Calc._originalOnMouseOverStart(...)
    end
end

function Calc.HookRoRSORTooltip()
    if type(RoR_SoR) ~= "table" or type(RoR_SoR.OnMouseOverStart) ~= "function" then
        return false
    end

    if RoR_SoR.OnMouseOverStart == Calc.OnRoRSORMouseOverStart then
        Calc._tooltipHooked = true
        return true
    end

    Calc._originalOnMouseOverStart = RoR_SoR.OnMouseOverStart
    RoR_SoR.OnMouseOverStart = Calc.OnRoRSORMouseOverStart
    Calc._tooltipHooked = true
    return true
end

function Calc.OnAAOMouseOver()
    local windowName = getMouseOverWindowName()
    local zoneId = Calc.GetAAOZoneIdFromWindow(windowName)
    if zoneId ~= nil then
        Calc.ShowGuildTooltip(zoneId, windowName)
    end
end

function Calc.OnAAORButtonUp()
    local windowName = getMouseOverWindowName()
    local zoneId = Calc.GetAAOZoneIdFromWindow(windowName)
    if zoneId == nil then
        zoneId = Calc.GetPopulationRealmFromWindow(windowName)
    end
    if zoneId == nil or type(RoR_SoR) ~= "table" or type(RoR_SoR.POPOption) ~= "function" then
        return
    end

    local previousWindow = nil
    if type(SystemData) == "table" and type(SystemData.MouseOverWindow) == "table" then
        previousWindow = SystemData.MouseOverWindow.name
        SystemData.MouseOverWindow.name = "SoR_" .. tostring(zoneId) .. "POP"
    end

    local ok, err = pcall(RoR_SoR.POPOption)

    if type(SystemData) == "table" and type(SystemData.MouseOverWindow) == "table" then
        SystemData.MouseOverWindow.name = previousWindow
    end

    if not ok then
        error(err)
    end
end

function Calc.OnRealmPopulationMouseOver()
    local windowName = getMouseOverWindowName()
    local zoneId, realm = Calc.GetPopulationRealmFromWindow(windowName)
    if zoneId ~= nil then
        Calc.ShowRealmPopulationTooltip(zoneId, realm, windowName)
    end
end

local function ensureHoverOverlay(overlayName, templateName, parentWindow, anchorWindow, width, height, mouseOverHandler, point, relativePoint)
    if not windowExists(parentWindow) or not windowExists(anchorWindow) then
        return false
    end

    local created = false
    if not windowExists(overlayName) then
        if type(CreateWindowFromTemplate) ~= "function" then
            return false
        end

        local ok = pcall(CreateWindowFromTemplate, overlayName, templateName, parentWindow)
        if not ok or not windowExists(overlayName) then
            return false
        end
        created = true
    end

    if created then
        if type(WindowClearAnchors) == "function" then
            pcall(WindowClearAnchors, overlayName)
        end
        if type(WindowAddAnchor) == "function" then
            pcall(WindowAddAnchor, overlayName, point or "center", anchorWindow, relativePoint or "center", 0, 0)
        end
        if type(WindowSetDimensions) == "function" then
            pcall(WindowSetDimensions, overlayName, width, height)
        end
        if type(WindowRegisterCoreEventHandler) == "function" then
            pcall(WindowRegisterCoreEventHandler, overlayName, "OnMouseOver", mouseOverHandler)
            pcall(WindowRegisterCoreEventHandler, overlayName, "OnRButtonUp", "AAOPopCalc.OnAAORButtonUp")
        end
    end

    if type(WindowSetShowing) == "function" then
        pcall(WindowSetShowing, overlayName, true)
    end

    return true
end

function Calc.EnsureAAOHoverOverlay(zoneId)
    local zoneNumber = tonumber(zoneId)
    if zoneNumber == nil or not isNormalZone(zoneNumber) then
        return false
    end

    local zoneWindow = "SoR_" .. tostring(zoneNumber)
    local orderOverlayName = Calc.REALM_HOVER_PREFIX .. "Order_" .. tostring(zoneNumber)
    local destroOverlayName = Calc.REALM_HOVER_PREFIX .. "Destro_" .. tostring(zoneNumber)
    local hasRealmOverlay = false
    if ensureHoverOverlay(
        orderOverlayName,
        Calc.REALM_HOVER_TEMPLATE,
        zoneWindow,
        zoneWindow .. "POPOrder",
        Calc.REALM_HOVER_WIDTH,
        Calc.REALM_HOVER_HEIGHT,
        "AAOPopCalc.OnRealmPopulationMouseOver",
        "left",
        "left"
    ) then
        Calc._realmHoverWindows[zoneNumber] = Calc._realmHoverWindows[zoneNumber] or {}
        Calc._realmHoverWindows[zoneNumber].order = orderOverlayName
        hasRealmOverlay = true
    end

    if ensureHoverOverlay(
        destroOverlayName,
        Calc.REALM_HOVER_TEMPLATE,
        zoneWindow,
        zoneWindow .. "POPDestro",
        Calc.REALM_HOVER_WIDTH,
        Calc.REALM_HOVER_HEIGHT,
        "AAOPopCalc.OnRealmPopulationMouseOver",
        "right",
        "right"
    ) then
        Calc._realmHoverWindows[zoneNumber] = Calc._realmHoverWindows[zoneNumber] or {}
        Calc._realmHoverWindows[zoneNumber].destro = destroOverlayName
        hasRealmOverlay = true
    end

    local aaoWindow = zoneWindow .. "AAO"
    local aaoAnchorWindow = zoneWindow .. "POPICON"
    if not windowExists(aaoAnchorWindow) then
        aaoAnchorWindow = aaoWindow
    end

    local overlayName = Calc.AAO_HOVER_PREFIX .. tostring(zoneNumber)
    if ensureHoverOverlay(
        overlayName,
        Calc.AAO_HOVER_TEMPLATE,
        zoneWindow,
        aaoAnchorWindow,
        Calc.AAO_HOVER_WIDTH,
        Calc.AAO_HOVER_HEIGHT,
        "AAOPopCalc.OnAAOMouseOver",
        "center",
        "center"
    ) then
        Calc._aaoHoverWindows[zoneNumber] = overlayName
    end

    return Calc._aaoHoverWindows[zoneNumber] ~= nil or hasRealmOverlay
end

function Calc.RefreshAAOHoverOverlays()
    if type(RoR_SoR) ~= "table" or type(RoR_SoR.OpenZones) ~= "table" then
        return
    end

    local openZones = {}
    for zoneKey, _ in pairs(RoR_SoR.OpenZones) do
        local zoneId = tonumber(zoneKey)
        if zoneId ~= nil and isNormalZone(zoneId) then
            openZones[zoneId] = true
            Calc.EnsureAAOHoverOverlay(zoneId)
        end
    end

    for zoneId, overlayName in pairs(Calc._aaoHoverWindows) do
        if openZones[tonumber(zoneId)] ~= true and type(WindowSetShowing) == "function" and windowExists(overlayName) then
            pcall(WindowSetShowing, overlayName, false)
        end
    end

    for zoneId, overlayNames in pairs(Calc._realmHoverWindows) do
        if openZones[tonumber(zoneId)] ~= true and type(WindowSetShowing) == "function" and type(overlayNames) == "table" then
            if windowExists(overlayNames.order) then
                pcall(WindowSetShowing, overlayNames.order, false)
            end
            if windowExists(overlayNames.destro) then
                pcall(WindowSetShowing, overlayNames.destro, false)
            end
        end
    end
end

local function printHelp()
    chatPrint("Commands: /aao [status|help] (aliases: /aaopop, /apc)")
    chatPrint("Shows AAO-narrowed population ranges for current RoR_SoR open zones.")
end

function Calc.PrintStatus()
    local entries = Calc.GetOpenZoneEstimates()
    if #entries == 0 then
        chatPrint("No RoR_SoR open zones with population data are loaded yet.")
        return
    end

    chatPrint("AAO population estimates for " .. tostring(#entries) .. " open zone(s):")
    for _, entry in ipairs(entries) do
        chatPrint(buildOutputLine(entry))
    end
end

function Calc.HandleSlash(input)
    local commandLine = trim(input)
    local command = ""

    if commandLine ~= "" then
        command = string.match(commandLine, "^(%S+)") or ""
        command = string.lower(command)
    end

    if command == "" or command == "status" or command == "zones" then
        Calc.PrintStatus()
        return
    end

    if command == "help" then
        printHelp()
        return
    end

    chatPrint("Unknown command: " .. command)
    printHelp()
end

function Calc.TryRegisterSlash()
    if Calc._slashRegistered then
        return true
    end

    if type(LibSlash) ~= "table" then
        if not Calc._slashMissingReported then
            chatPrint("LibSlash not found; /aao is unavailable.")
            Calc._slashMissingReported = true
        end
        return false
    end

    local register = LibSlash.RegisterWSlashCmd
    if type(register) ~= "function" then
        register = LibSlash.RegisterSlashCmd
    end

    if type(register) ~= "function" then
        return false
    end

    register("aao", function(slashInput) Calc.HandleSlash(slashInput) end)
    register("aaopop", function(slashInput) Calc.HandleSlash(slashInput) end)
    register("apc", function(slashInput) Calc.HandleSlash(slashInput) end)

    Calc._slashRegistered = true
    return true
end

function Calc.OnInitialize()
    Calc.TryRegisterSlash()
    Calc.HookRoRSORTooltip()
    Calc.RefreshAAOHoverOverlays()
end

function Calc.OnUpdate(elapsed)
    local delta = tonumber(elapsed) or 0

    Calc._refreshElapsed = Calc._refreshElapsed + delta
    if Calc._refreshElapsed < REFRESH_INTERVAL then
        return
    end
    Calc._refreshElapsed = 0

    if not Calc._slashRegistered then
        Calc.TryRegisterSlash()
    end

    if Calc._tooltipHooked ~= true
        or (type(RoR_SoR) == "table" and RoR_SoR.OnMouseOverStart ~= Calc.OnRoRSORMouseOverStart) then
        Calc.HookRoRSORTooltip()
    end

    Calc.RefreshAAOHoverOverlays()
end
