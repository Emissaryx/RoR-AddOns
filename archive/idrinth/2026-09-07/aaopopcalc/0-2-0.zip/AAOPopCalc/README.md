# AAOPopCalc

AAOPopCalc is a Return of Reckoning addon for `RoR_SoR`. It turns State of Realm population buckets and AAO values into tighter Order/Destruction population estimates for open normal RvR zones.

## Usage

- Adds `/aao`, `/aaopop`, and `/apc`.
- Prints one line per open normal RvR zone with calculated Order/Destro ranges, lighter raw `RoR_SoR` buckets, and visible AAO realm/percent when present.
- Adds population-row hovers to `RoR_SoR`: Order shows the calculated Order range, Destro shows the calculated Destro range.
- Skips forts and city/pairing pseudo-zones because `RoR_SoR` stores those population values differently from normal RvR zones.

## Requirements

`RoR_SoR` is required. `LibSlash` is optional but needed for slash commands.

## RoR_SoR Data

AAOPopCalc reads `Order_Pop`, `Destro_Pop`, `AAO`, `AAOMulti`, and `Tier` from `RoR_SoR.ZoneStatus[zoneId]`.
`RoR_SoR` AAO can lag behind its population buckets, so estimates may briefly look inconsistent.

## Population Buckets

- `Scouts`: `0-9`
- `Parties`: `10-24`
- `Warbands`: `25-99`
- `Vanguard`: `100-199`
- `Battlehost`: `200-299`
- `Warhost`: `300+`

## Spreadsheet Source

Source spreadsheet: `AAO pop calcs`

https://docs.google.com/spreadsheets/d/1lba8Au6AYhcv7B8fNFoGcNInPenJjjjHw_OYWhPa9JA/edit?usp=sharing

AAOPopCalc is based on a 2026-05-06 Google spreadsheet export. The link came from a RoR Discord discussion where spreadsheet author `leftayparxoun` described a calculation sheet for faction population limits extrapolated from SoR stats.

## Calculation

When AAO is visible, `AAO` is treated as the low-population realm (`1` Order, `2` Destro). The source sheet stores AAO as a percentage cell, so `100%` in the sheet matches `AAOMulti / 100` in the addon.

```text
highRealmPopulation / lowRealmPopulation >= AAOMulti / 100 + 0.9
highRealmPopulation / lowRealmPopulation <= AAOMulti / 100 + 1.1
```

The source sheet converts that ratio band to high-pop and low-pop endpoint formulas with `ROUND`.

## Runtime Differences

The sheet models a known high-population realm against a known low-population realm. AAOPopCalc keeps the same ratio assumptions, but adjusts runtime boundary handling:

- Finite AAO buckets enumerate every valid integer population pair, then derive min/max bounds from those pairs. This avoids rounded endpoint artifacts. Example: `0-9` vs `0-9` at `40%` AAO is `0-9`/`0-7` in the sheet endpoint formulas, but `3-9`/`2-6` in AAOPopCalc.
- Visible `400%` AAO means `400%+`: no upper ratio boundary, and `0` is valid for the AAO realm when its SoR bucket includes `0`.
- Open-ended AAO buckets such as `300+` cannot be fully enumerated, so they use the sheet's rearranged inequalities with integer-safe ceiling/floor bounds instead of spreadsheet `ROUND`.
- No-AAO Order-vs-Destruction display is not directly modeled by the sheet. For finite no-AAO buckets, AAOPopCalc uses the 0% ratio band and enumerates pairs where the larger/smaller population ratio is at most `1.1`, with `(0,0)` as the only zero case.
- Adjacent finite no-AAO buckets keep the shared boundary pair. `10-24` vs `0-9` can resolve to `10` vs `9`, and the reverse to `9` vs `10`.
- Open-ended no-AAO buckets keep the raw `RoR_SoR` range because there is no finite upper boundary to enumerate safely.

## Changelog

### 0.2.0 - 2026-05-06 - Wholdar

- Treat visible `400%` AAO as `400%+`, with no upper ratio boundary and AAO-realm `0` allowed when the SoR bucket includes `0`.
- Use lighter faction colors for raw `RoR_SoR` numbers so calculated ranges stand out.
- Note that `RoR_SoR` AAO can lag behind population buckets.

### 0.1.0 - 2026-05-06 - Wholdar

- Initial release.
