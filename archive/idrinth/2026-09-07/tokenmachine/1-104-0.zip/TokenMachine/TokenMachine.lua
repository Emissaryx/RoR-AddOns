TokenMachine = {}

-- Our own local constants (used in the settings table below)
local CHOICE_NEED = 1
local CHOICE_GREED = 2
local CHOICE_PASS = 3
local CHOICE_NOTHING = 4
-- .. and the translation to the ingame ones
local rollTable =
{
    [CHOICE_NEED] = GameData.LootRoll.NEED,
    [CHOICE_GREED] = GameData.LootRoll.GREED,
    [CHOICE_PASS] = GameData.LootRoll.PASS,
}

-- The default settings. This will be overwritten by any loaded savedvariable.
TokenMachine.Settings =
{
 -- [##uniqueId##] = default choice,
    [208400] = CHOICE_NEED, -- Recruit's Medallion
    [208401] = CHOICE_NEED, -- Scout's Medallion
    [208402] = CHOICE_NEED, -- Soldier's Medallion
    [208403] = CHOICE_NEED, -- Officer's Medallion
    
    [208452] = CHOICE_NEED, -- Conqueror's Crest
    [208453] = CHOICE_NEED, -- Invader's Crest
    [208454] = CHOICE_NEED, -- Warlord's Crest
    [208455] = CHOICE_NEED, -- Royal Crest
    
    [208408] = CHOICE_NEED, -- Silver Scarab
    [208409] = CHOICE_NEED, -- Golden Scarab
    [208410] = CHOICE_NEED, -- Silver Ankh
    [208411] = CHOICE_NEED, -- Golden Cartouche
    
    [11837]  = CHOICE_NEED, -- Ordnance
    [11847]  = CHOICE_NEED, -- Skull of the Fallen
    [206669] = CHOICE_NEED, -- Common Firework
    [207413] = CHOICE_NEED, -- Expedition Resources
}
TokenMachine.DefaultSettings = TokenMachine.Settings

-- The initial history values. This will be overwritten by any loaded history.
TokenMachine.History = {}
for k,_ in pairs(TokenMachine.Settings) do TokenMachine.History[k] = 0 end

-- The initial session values. This is intentionally reset each time the addon loads.
TokenMachine.Session = {}
for k,_ in pairs(TokenMachine.Settings) do TokenMachine.Session[k] = 0 end

-- This table is used for tracking inventory stack counts (to allow for counting token gains into existing stacks)
local stackCounts = {}
local oldStackID = {}

-- These are used for the config GUI.
local TokenDisplayData =
{
    -- uniqueID versions
    [208400] = {icon=25003,rarity=SystemData.ItemRarity.UNCOMMON,wnd="Recruit"}, -- Recruit's Medallion
    [208401] = {icon=25005,rarity=SystemData.ItemRarity.UNCOMMON,wnd="Scout"}, -- Scout's Medallion
    [208402] = {icon=25006,rarity=SystemData.ItemRarity.UNCOMMON,wnd="Soldier"}, -- Soldier's Medallion
    [208403] = {icon=25001,rarity=SystemData.ItemRarity.UNCOMMON,wnd="Officer"}, -- Officer's Medallion
    
    [208452] = {icon=25000,rarity=SystemData.ItemRarity.RARE,wnd="Conqueror"}, -- Conqueror's Crest
    [208453] = {icon=25002,rarity=SystemData.ItemRarity.VERY_RARE,wnd="Invader"}, -- Invader's Crest
    [208454] = {icon=25007,rarity=SystemData.ItemRarity.VERY_RARE,wnd="Warlord"}, -- Warlord's Crest
    [208455] = {icon=25004,rarity=SystemData.ItemRarity.ARTIFACT,wnd="Royal"}, -- Royal Crest
    
    [208408] = {icon=27041,rarity=SystemData.ItemRarity.UNCOMMON,wnd="SilverScarab"}, -- Silver Scarab
    [208409] = {icon=27005,rarity=SystemData.ItemRarity.UNCOMMON,wnd="GoldenScarab"}, -- Golden Scarab
    [208410] = {icon=20456,rarity=SystemData.ItemRarity.RARE,wnd="SilverAnkh"}, -- Silver Ankh
    [208411] = {icon=27039,rarity=SystemData.ItemRarity.VERY_RARE,wnd="GoldenCartouche"}, -- Golden Cartouche
    
    [11837]  = {icon=919,rarity=SystemData.ItemRarity.UNCOMMON,wnd="Ordnance"}, -- Ordnance
    [11847]  = {icon=374,rarity=SystemData.ItemRarity.UNCOMMON,wnd="Skull"}, -- Skull of the Fallen
    [206669] = {icon=534,rarity=SystemData.ItemRarity.COMMON,wnd="Firework"}, -- Common Firework
    [207413] = {icon=762,rarity=SystemData.ItemRarity.COMMON,wnd="Resources"}, -- Expedition Resources
}

function TokenMachine.SetupOption()
    local active = SystemData.ActiveWindow.name
    local optionID = WindowGetId(active)
    
    -- Only setup options who have a valid ID
    local tokenData = TokenDisplayData[optionID]
    if not tokenData then return end
    
    local icon,x,y = GetIconData(tokenData.icon)
    DynamicImageSetTexture(active.."ImageIcon", icon, x, y)
    local color = GameDefs.ItemRarity[tokenData.rarity].color
    WindowSetTintColor(active.."Border", color.r, color.g, color.b)
    
    ComboBoxAddMenuItem(active.."Choice", GetString( StringTables.Default.LABEL_NEED ))
    ComboBoxAddMenuItem(active.."Choice", GetString( StringTables.Default.LABEL_GREED ))
    ComboBoxAddMenuItem(active.."Choice", GetString( StringTables.Default.LABEL_PASS ))
    ComboBoxAddMenuItem(active.."Choice", L"---") -- To not auto-roll on this token.
    
    ComboBoxSetSelectedMenuItem(active.."Choice", TokenMachine.Settings[optionID])
end

function TokenMachine.UpdateOption()
    local active = SystemData.ActiveWindow.name
    local setting = WindowGetParent(active)
    local optionID = WindowGetId(setting)
    local choice = ComboBoxGetSelectedMenuItem(active)
    TokenMachine.Settings[optionID] = choice
end

function TokenMachine.OpenOption()
    local active = SystemData.ActiveWindow.name
    local setting = WindowGetParent(active)
    ComboBoxExternalOpenMenu(setting.."Choice")
end

function TokenMachine.UpdateCounts()
    for k,v in pairs(TokenDisplayData) do
        local labelName = "TokenMachineSettings"..v.wnd.."Text"
        local text = towstring(TokenMachine.History[k])
        if TokenMachine.Session[k] > 0 then
            text = text..L" (+"..towstring(TokenMachine.Session[k])..L")"
        end
        LabelSetText(labelName, text)
    end
end

function TokenMachine.ToggleSettings()
    WindowUtils.ToggleShowing("TokenMachineSettings")
end

function TokenMachine.ProcessRolls()
    local lootRolls = GetLootRollData()
    
    -- Don't try to roll on things if the backpack is full.
    if EA_Window_Backpack.overflowCount > 0 then return end
    
    for index,rollData in ipairs(lootRolls) do
        local itemData = rollData.itemData

        if TokenMachine.Settings[itemData.uniqueID] then
            -- This is something we're supposed to roll on.
            local choice = rollTable[TokenMachine.Settings[itemData.uniqueID]]
            if choice ~= CHOICE_NOTHING then
                SelectItemRollChoice(rollData.sourceId, rollData.lootSlot, choice)
            end
        end
    end
    
    -- Support the TidyRoll loot roll frames - update their display if installed
    if TidyRoll and TidyRoll.UpdateLootRollData then
        TidyRoll.UpdateLootRollData()
    else
        -- Update the display of the roll window
        EA_Window_LootRoll.UpdateLootRollData()
    end
end

-- Used to display gain/loss summaries
local newTokens = {}

-- Used to prevent initial load spam from affecting counts
local notPrevLoaded = true

function TokenMachine.OnLoad()
    if notPrevLoaded then
        notPrevLoaded = false
    end
end

function TokenMachine.ProcessCurrencyUpdates(updatedSlots)

    local items = DataUtils.GetCurrencyItems()

    -- Don't process the initial spam for load.
    if notPrevLoaded and SystemData.LoadingData.isLoading then return end
    
    for _,slot in ipairs(updatedSlots) do
        local itemData = items[slot]
        if itemData then
            local id = itemData.uniqueID
            -- Only process this as a potential new gain if we already have this slot initialized
            if stackCounts[slot] then
                if TokenMachine.Settings[id] or TokenMachine.Settings[oldStackID[slot]] then
                    if not TokenMachine.Settings[id] then id = oldStackID[slot] end
                    if itemData.isNew then
                        -- This is a token we track, and it's a new stack.
                        
                        if newTokens[id] then
                            newTokens[id].count = newTokens[id].count + itemData.stackCount
                        else
                            newTokens[id] = {count=itemData.stackCount,
                                             color=DataUtils.GetItemRarityColor(itemData),
                                             name=itemData.name}
                        end
                    elseif itemData.stackCount ~= stackCounts[slot] and itemData.uniqueID == oldStackID[slot] then
                        -- This is a token we track, and the stack size changed. Check to make sure we're not xfering from the bank.
                        if not (DoesWindowExist("BankWindow") and WindowGetShowing("BankWindow")) then
                            -- Okay, so this is actually from loot, not the bank
                            local added = itemData.stackCount - stackCounts[slot]
                            if newTokens[id] then
                                newTokens[id].count = newTokens[id].count + added
                            else
                                newTokens[id] = {count=added,
                                                 color=DataUtils.GetItemRarityColor(itemData),
                                                 name=itemData.name}
                            end
                        end
                    end
                end
            end
            stackCounts[slot] = itemData.stackCount
            oldStackID[slot] = itemData.uniqueID
        end
    end
    
    -- Update the history/session counts
    TokenMachine.UpdateCounts()
end

function TokenMachine.OnUpdate(timePassed)

    if notPrevLoaded and SystemData.LoadingData.isLoading then return end
    if not newTokens or not next(newTokens) then return end

    local newTokes = newTokens
    newTokens = {}
    
    for k,v in pairs(newTokes) do
        if v.count > 0 then
            TokenMachine.History[k] = TokenMachine.History[k] + v.count
            TokenMachine.Session[k] = TokenMachine.Session[k] + v.count
        end
        
        if v.count > 1 then
            EA_ChatWindow.Print(L"+++ "..CreateHyperLink(L"ITEM:"..k,
                L"["..v.name..L"]", {v.color.r,v.color.g,v.color.b}, {})..L" (x"..v.count..L") +++")
        elseif v.count == 1 then
            EA_ChatWindow.Print(L"+++ "..CreateHyperLink(L"ITEM:"..k,
                L"["..v.name..L"]", {v.color.r,v.color.g,v.color.b}, {})..L" +++")
        end
    end
    
    TokenMachine.UpdateCounts()
end

function TokenMachine.IsPlayerSolo()
    if GameData.Player.isInScenario then return false end
    if IsWarBandActive() then return false end
    if PartyUtils.IsPartyActive() then return false end
    
    return true
end

local oldOnLootItem = EA_Window_Loot.OnLootItem
function TokenMachine.OnLootItemHook(...)
    if TokenMachine.IsPlayerSolo() then
        -- Bypass BOP warning if player is solo
        local rowNum = WindowGetId(SystemData.ActiveWindow.name)
        local lootIndex = EA_Window_LootList.PopulatorIndices[rowNum]
        LootItem(lootIndex)
    else
        return oldOnLootItem(...)
    end
end
EA_Window_Loot.OnLootItem = TokenMachine.OnLootItemHook

local oldOnLootAll = EA_Window_Loot.OnLootAll
function TokenMachine.OnLootAllHook(...)
    if TokenMachine.IsPlayerSolo() then
        -- Bypass BOP warning if player is solo
        EA_Window_Loot.OnLootAllBindOnPickUpItems()
    else
        return oldOnLootAll(...)
    end
end
EA_Window_Loot.OnLootAll = TokenMachine.OnLootAllHook

function TokenMachine.Initialize()

    for k,v in pairs(TokenMachine.DefaultSettings) do
        if not TokenMachine.Settings[k] then
            TokenMachine.Settings[k] = v
        end
        if not TokenMachine.History[k] then
            TokenMachine.History[k] = 0
        end
    end

    CreateWindow("TokenMachineSettings", true)
    LabelSetText("TokenMachineSettingsTitleText", L"TokenMachine")
    
    -- Update the history/session counts
    TokenMachine.UpdateCounts()
    
    if LibSlash and not LibSlash.IsSlashCmdRegistered("token") then
        LibSlash.RegisterSlashCmd("token", TokenMachine.ToggleSettings)
    end
    
    if DoesWindowExist("EA_Window_Backpack") then
        CreateWindow("TokenMachineButton", true)
        WindowSetParent("TokenMachineButton", "EA_Window_Backpack")
        WindowAddAnchor("TokenMachineButton", "left", "EA_Window_BackpackClose", "right", -5, 0)
    end
    
    -- Initialize stack counts and id's
    for slot,itemData in ipairs(DataUtils.GetCurrencyItems()) do
        stackCounts[slot] = itemData.stackCount
        oldStackID[slot] = itemData.uniqueID
    end
    
    RegisterEventHandler(SystemData.Events.INTERACT_SHOW_LOOT_ROLL_DATA, "TokenMachine.ProcessRolls")
    RegisterEventHandler(SystemData.Events.PLAYER_CURRENCY_SLOT_UPDATED, "TokenMachine.ProcessCurrencyUpdates")
    RegisterEventHandler(SystemData.Events.LOADING_END, "TokenMachine.OnLoad")
    RegisterEventHandler(SystemData.Events.RELOAD_INTERFACE, "TokenMachine.OnLoad")
end