<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
	<UiMod name="TokenMachine" version="1.104" date="25/05/2010" >

		<Author name="Aiiane" email="aiiane@aiiane.net" />
		<Description text="Automatically rolls Need on RvR tokens/crests." />
        
        <VersionSettings gameVersion="1.3.5" windowsVersion="1.4" savedVariablesVersion="1.1" />
        
        <Dependencies>
            <Dependency name="EA_LootWindow" />
            <Dependency name="EA_BackpackWindow" optional="true" />
            <Dependency name="LibSlash" optional="true" />
            <Dependency name="TidyRoll" optional="true" />
        </Dependencies>
        
		<Files>
            <File name="TokenMachine.xml" />
			<File name="TokenMachine.lua" />
		</Files>
        
        <SavedVariables>
            <SavedVariable name="TokenMachine.Settings" />
            <SavedVariable name="TokenMachine.History" />
        </SavedVariables>
		
		<OnInitialize>
            <CallFunction name="TokenMachine.Initialize" />
		</OnInitialize>
		<OnUpdate>
            <CallFunction name="TokenMachine.OnUpdate" />
        </OnUpdate>
		<OnShutdown/>
        
        <WARInfo>
    <Categories>
        <Category name="ITEMS_INVENTORY" />
        <Category name="RVR" />
        <Category name="GROUPING" />
    </Categories>
    <Careers>
        <Career name="BLACKGUARD" />
        <Career name="WITCH_ELF" />
        <Career name="DISCIPLE" />
        <Career name="SORCERER" />
        <Career name="IRON_BREAKER" />
        <Career name="SLAYER" />
        <Career name="RUNE_PRIEST" />
        <Career name="ENGINEER" />
        <Career name="BLACK_ORC" />
        <Career name="CHOPPA" />
        <Career name="SHAMAN" />
        <Career name="SQUIG_HERDER" />
        <Career name="WITCH_HUNTER" />
        <Career name="KNIGHT" />
        <Career name="BRIGHT_WIZARD" />
        <Career name="WARRIOR_PRIEST" />
        <Career name="CHOSEN" />
        <Career name= "MARAUDER" />
        <Career name="ZEALOT" />
        <Career name="MAGUS" />
        <Career name="SWORDMASTER" />
        <Career name="SHADOW_WARRIOR" />
        <Career name="WHITE_LION" />
        <Career name="ARCHMAGE" />
    </Careers>
</WARInfo>

		
	</UiMod>
</ModuleFile>
