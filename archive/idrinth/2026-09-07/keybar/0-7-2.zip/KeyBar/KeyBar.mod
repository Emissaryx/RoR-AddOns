<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
    <UiMod name="KeyBar" version="0.7.2" date="24/02/2021">
        <Author name="Floffel, based on the work from Sullemunk" />
        <Description text="A command window for easy use of abilities, macros and consumables. use: /KeyBar for settings and help." />
         <Dependencies>        
            <Dependency name="EATemplate_DefaultWindowSkin" />
            <Dependency name="EASystem_WindowUtils" />
            <Dependency name="EASystem_Utils" />            
            <Dependency name="EA_LegacyTemplates" />
			<Dependency name="EA_ChatSystem" />
			<Dependency name="EA_ActionBars" />
			<Dependency name="LibCooldown" optional="false" forceEnable="true" />						
			<Dependency name="LibSlash" />						
        </Dependencies>
 

        <Files>
            <File name="KeyBar.lua" />
			<File name="KeyBar.xml" />
			<File name="KeyBarSettings.lua" />
			<File name="KeyBarSettings.xml" />
			<File name="KeyBarHelp.xml" />
        </Files>
		
		<!-- this function will run when the addon loads -->
        <OnInitialize>
            <CallFunction name="KeyBar.OnInitialize" />
            <CallFunction name="KeyBarSettings.OnInitialize" />
        </OnInitialize>

		<OnUpdate>
    	</OnUpdate>

		<SavedVariables>
			<SavedVariable name="KeyBar.Button"/>
			<SavedVariable name="KeyBar.Settings"/>
		</SavedVariables>		

		<!-- this function will run when the addon exits -->
        <OnShutdown>
			<CallFunction name="KeyBar.OnShutdown" />
		</OnShutdown>
		<WARInfo>
			<Careers>
				<Career name="BLACKGUARD" />
				<Career name="WITCH_ELF" />
				<Career name="DISCIPLE" />
				<Career name="SORCERER" />
				<Career name="IRON_BREAKER" />
				<Career name="SLAYER" />
				<Career name="RUNE_PRIEST" />
				<Career name="ENGINEER" />
				<Career name="BLACK_ORC" />
				<Career name="CHOPPA" />
				<Career name="SHAMAN" />
				<Career name="SQUIG_HERDER" />
				<Career name="WITCH_HUNTER" />
				<Career name="KNIGHT" />
				<Career name="BRIGHT_WIZARD" />
				<Career name="WARRIOR_PRIEST" />
				<Career name="CHOSEN" />
				<Career name="MARAUDER" />
				<Career name="ZEALOT" />
				<Career name="MAGUS" />
				<Career name="SWORDMASTER" />
				<Career name="SHADOW_WARRIOR" />
				<Career name="WHITE_LION" />
				<Career name="ARCHMAGE" />
			</Careers>
		</WARInfo>
    </UiMod>
</ModuleFile>