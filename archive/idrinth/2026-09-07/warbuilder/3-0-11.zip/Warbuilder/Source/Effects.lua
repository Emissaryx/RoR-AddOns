--mass used 

--Flee
Warbuilder.ComponentEffects[245]={abilityId = 245,castByPlayer = true,duration = 10,effectText = 1114,iconNum = 5004,isBuff = true,isCasterDispellable = false,isDamaging = false,isDebuff = false,isDefensive = true,isGranted = false,isHealing = false,isOffensive = false,isPassive = false,isStatsBuff = false,name = 245,permanentUntilDispelled = false}

--Panic!
Warbuilder.ComponentEffects[247]={abilityId = 247,castByPlayer = true,duration = 10,effectText = 1199,iconNum = 5004,isBuff = false,isCasterDispellable = false,isDamaging = false,isDebuff = true,isDefensive = false,isGranted = false,isHealing = false,isOffensive = true,isPassive = false,isStatsBuff = false,name = 247,permanentUntilDispelled = false}