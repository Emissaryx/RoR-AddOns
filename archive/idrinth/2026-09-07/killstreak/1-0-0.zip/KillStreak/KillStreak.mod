<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
    <UiMod name="KillStreak" version="1.0" date="08/01/21">
        <Author name="Sullemunk" />
        <Description text="A recreation of Wrath of Heroes Killstreak tracker, made by Sullemunk for RoR" />
 
        <Files>
            <File name="KillStreak.lua" />
			<File name="KillStreak.xml" />
        </Files>
		
        <OnInitialize>
            <CallFunction name="KillStreak.OnInitialize" />
        </OnInitialize>

		<OnUpdate>
    	</OnUpdate>
	
        <OnShutdown>
			<CallFunction name="KillStreak.OnShutdown" />
		</OnShutdown>
    </UiMod>
</ModuleFile>