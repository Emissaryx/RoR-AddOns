# LiveEventLedger

LiveEventLedger shows Tome live-event progress across your characters in one small account-wide window.

## Usage

### Opening The Ledger

- Use `/lel`.
- Right-click the Live Events tab inside the Tome of Knowledge.
- Right-click the Tome of Knowledge button on the menu bar.

### Live Event Ledger Icon

- Use `/lel icon` to toggle the movable Live Event Ledger icon; `/lel icon show` and `/lel icon hide` set it explicitly.
- Left-click the Live Event Ledger icon to open or close the ledger. Right-click it to open, close, or hide the icon.
- Icon visibility is saved per character.

### Ledger Window

- Click a column header to sort; click the active header again to reverse it.
- Right-click a non-current character row and choose `Remove from tracking` to remove that character from the ledger after confirming.
- Use `Open ToK` for the selected event's task details.
- Use `Refresh` to rescan the current character.

Only characters that have logged in with the addon enabled can appear. The dropdown shows recent events, with ended events marked ` - ended` and listed last.

## Slash Commands

- `/lel` opens the ledger.
- `/lel refresh` rescans current live-event data.
- `/lel icon` toggles the Live Event Ledger icon.
- `/lel icon show` shows the Live Event Ledger icon.
- `/lel icon hide` hides the Live Event Ledger icon.
- `/lel help` shows the command list.

## Requirements

The stock Tome of Knowledge live-event UI is required. `LibSlash` is optional but required for slash commands.

## Changelog

### 0.3.4 - 2026-06-13 - Wholdar

- Made icon visibility per character.

### 0.3.3 - 2026-06-13 - Wholdar

- Kept the icon hidden unless explicitly enabled.

### 0.3.2 - 2026-06-12 - Wholdar

- Added public `LiveEventLedger.Toggle()` for optional use in other addons.

### 0.3.1 - 2026-06-12 - Wholdar

- Moved ended events to the bottom of the dropdown.
- Made the footer `Open ToK` hint clickable.
- Stopped icon drag-release from toggling the ledger.

### 0.3.0 - 2026-06-12 - Wholdar

- Added an optional movable Tome-style Live Event Ledger icon with left-click open/close and right-click open/close/hide.
- Added right-click actions to the Tome of Knowledge Live Events tab and menu-bar button.

### 0.2.0 - 2026-05-31 - Wholdar

- Added a right-click option to remove a tracked character from the ledger after confirming.

### 0.1.0 - 2026-05-31 - Wholdar

- Initial release.
