-- SilverWF: (2024-10-04) Added showing unique item and ability IDs
-- Perkus:  Oct-23-08  Fixed the following:
-- 1) Searched & Replaced ChatWindow -> EA_ChatWindow (SlashHandler was totally broken since WAR's latest UI change)
-- 2) Fixed Nisp.SetItemTooltipData:
--	a) For equippable items it was reporting price of last comparisontooltips instead of equipped item
--	b) Repair item handling was also wrong - after you got a tooltip for one, it would suppress the tooltip on the next regular item, etc.
--	c) It now correctly shows prices of all comparison items a well as broken items in addition to the current item!
-- 3) Added a "Nisp initialized message" on Init()
-- 5) Added debug statements to dump tooltip names and prices when debug mode is on
--
--TO DO:
-- b) There's a really minor bug with "No sell price" items like trophies and pockets: they only show the "No Sell Price" string once when you switch
--	to their tooltip from a tooltip that *does* have a price.  Thereafter the tooltip won't show this string upon repeated display.
--	I don't know how to make it do that properly, and in fact it's mostly likely Mythic's bug and not fixable via a mod unless you hack it somehow.
--	Odds are it's exactly the same way it behaves with 0 mods running...


Nisp = {}

local OldSetItemTooltipData = nil
local OldAbilityTooltipData = nil
local OldInventoryRButtonUp = nil
local MouseOverItemData = nil
local prevTooltipWindow = nil;

function Nisp.Init()

	OldSetItemTooltipData = Tooltips.SetItemTooltipData
	OldAbilityTooltipData = Tooltips.SetAbilityTooltipData
	OldInventoryRButtonUp = EA_Window_Backpack.InventoryRButtonUp
	EA_Window_Backpack.InventoryRButtonUp = Nisp.RButtonUp

	LibSlash.RegisterSlashCmd("nisp", function(args) Nisp.SlashHandler(args) end)

	Tooltips.SetItemTooltipData = Nisp.SetItemTooltipData
	Tooltips.SetAbilityTooltipData = Nisp.SetAbilityTooltipData

	if Nisp.Enabled == nil then
		Nisp.Enabled = true
		EA_ChatWindow.Print(L"Nisp Installed and Enabled")
	elseif Nisp.Enabled == true then
		EA_ChatWindow.Print(L"Nisp Initialized and Enabled (/nisp for commands)")
	elseif Nisp.Enabled == false then
		EA_ChatWindow.Print(L"Nisp Initialized, but disabled (/nisp for commands)")
	end
	if Nisp.DebugEnabled == nil then Nisp.DebugEnabled = false end
	if Nisp.DumpItemsTable == nil then Nisp.DumpItemsTable = {} end
end


function Nisp.SlashHandler(args)
	local opt, val = args:match("([a-z0-9]+)[ ]?(.*)")
	if not opt then
		EA_ChatWindow.Print(L"Nisp commands:")
		EA_ChatWindow.Print(L"/nisp on - to turn on npc item sales prices")
		EA_ChatWindow.Print(L"/nisp off - to turn off npc item sales prices")
		EA_ChatWindow.Print(L"Debug Commands:")
		EA_ChatWindow.Print(L"/nisp debug on - to turn debugging on")
		EA_ChatWindow.Print(L"/nisp debug off - to turn debugging off")
		EA_ChatWindow.Print(L"/nisp debug dumpclear - to clear dumped items")
	elseif opt == "on" then
		Nisp.Enabled = true
		EA_ChatWindow.Print(L"Nisp Enabled")
	elseif opt == "off" then
		Nisp.Enabled = false
		EA_ChatWindow.Print(L"Nisp Disabled")
	elseif opt == "debug" then
		if val == "on" then Nisp.DebugEnabled = true; EA_ChatWindow.Print(L"Nisp debugging on (hold down SHIFT)")	--ARM added "hold down Shift"
		elseif val == "off" then Nisp.DebugEnabled = false; EA_ChatWindow.Print(L"Nisp debugging off")
		elseif val == "dumpclear" then Nisp.DumpClear() end
	end
end


-------------------------------------------------------------------------------------------------------------------------------------------------------------
-- Perkus: NOTE: This function gets called at least TWICE when mousing over equippable items (i.e. weapons, armor, accessories, etc.) if the player has an
-- item equipped in the matching slot!  First call is for the item itself (with a tooltipWindow == "ItemTooltip"), and the second call is for the currently
-- currently equipped item (with a tooltipWindow == "ItemComparisonTooltip").  Actually, if you're running the mod "preciousss", if gets called up to 4
-- additional times when mouse over a jewelry item - once for every equipped jewelry item!
-- Exception: Tooltips over repairable items call with tooltipWindow == BrokenItemTooltipRepairedItem instead of "ItemTooltip", and may also call
-- with additional Comparison tooltips!
-- In order to show the correct itemData for each tooltip item, you must set Tooltips.curTooltipWindow = tooltipWindow, then restore it so it gets clean up!
-------------------------------------------------------------------------------------------------------------------------------------------------------------
local function formatMoney (amount, stack)
	local formAmount = L"won't buy this"
	if amount > 0 then
		local amountG = math.floor (amount / 10000)
		local amountS = math.floor ((amount - (amountG * 10000)) / 100)
		local amountB = math.mod (amount, 100)	
		local textAG = L""
		local textAS = L""
		local textAB = L""
		
		if amountG ~= 0 then textAG = towstring(amountG)..L"<icon46>" end
		if amountS ~= 0 then textAS = L" "..towstring(amountS)..L"<icon47>" end
		if amountB ~= 0 then textAB = L" "..towstring(amountB)..L"<icon48>"	end
		
		formAmount = textAG..textAS..textAB
		
		if stack > 1 then
			local stackED = amount * stack
			local stackG = math.floor (stackED / 10000)
			local stackS = math.floor ((stackED - (stackG * 10000)) / 100)
			local stackB = math.mod (stackED, 100)	
			local textSG = L""
			local textSS = L""
			local textSB = L""	

			if stackG ~= 0 then textSG = towstring(stackG)..L"<icon46>" end
			if stackS ~= 0 then textSS = L" "..towstring(stackS)..L"<icon47>" end
			if stackB ~= 0 then textSB = L" "..towstring(stackB)..L"<icon48>"end
			
			formAmount = formAmount..L" each, "..textSG..textSS..textSB..L" total"
		end
	end
	
	return formAmount
end

function Nisp.SetItemTooltipData( tooltipWindow, itemData, extraText, extraTextColor )
	-- SWF: Showing unique item IDs
	local naMe = itemData.description -- SWF: saving default desccription, because all items are always have description, but not always - extra text.
	if not itemData.description then itemData.description = L"" end
	local itID = towstring(itemData.uniqueID) -- SWF: catching item id
	local itIC = towstring(itemData.iconNum) -- SWF: catching item icon number
	local itPrice = itemData.sellPrice
	local itStack = itemData.stackCount
	local itSP = formatMoney ( itPrice , itStack )
	
	itemData.description = L"* itemID: "..itID..L", icon: "..itIC..L"\n"..L"* vendor: "..itSP..L"\n"..itemData.description -- SWF: creating new description

	OldSetItemTooltipData( tooltipWindow, itemData, extraText, extraTextColor );

	itemData.description = naMe -- SWF: Returning default desc when mouse off, to prevent overstacking id rows
	
	local strToolTipWindowName = tostring(tooltipWindow)

	if Nisp.DebugEnabled then
		EA_ChatWindow.Print(L"tooltipWindow = " .. towstring(strToolTipWindowName))
	end
	
	if Nisp.Enabled then
		if Nisp.DebugEnabled then
			EA_ChatWindow.Print(L"Showing Sell Price = " .. towstring(itemData.sellPrice))
		end

		local prevTooltipWindow = Tooltips.curTooltipWindow -- save the current tooltip window
		Tooltips.curTooltipWindow = strToolTipWindowName -- make the tooltip window for which we're being called the "current" tooltip window
		--Tooltips.ShowSellPrice(itemData); -- add the sell price to that window
		Tooltips.curTooltipWindow = prevTooltipWindow -- restore the current tooltip window (required for proper clean-up when multiple tooltips are shown at once)
	end
end

function Nisp.SetAbilityTooltipData( tooltipWindow, skillData, extraText, extraTextColor )
	-- SWF: Showing unique skill IDs
	local naMe = extraText -- SWF: saving default extra text: skills doesn't have description, so we use extra text which is always present.
	local itID = towstring(skillData.id) -- SWF: catching skill id
	local itIC = towstring(skillData.iconNum) -- SWF: catching skill id
	if not extraText then extraText = L"" end
	extraText = L"* ability ID: "..itID..L", icon: "..itIC..L"\n"..extraText -- SWF: creating new extra

	OldAbilityTooltipData( tooltipWindow, skillData, extraText, extraTextColor );

	extraText = naMe -- SWF: Returning default text when mouse off
	
	local strAToolTipWindowName = tostring(tooltipWindow)
	local prevATooltipWindow = Tooltips.curTooltipWindow -- save the current tooltip window
	Tooltips.curTooltipWindow = strAToolTipWindowName 	-- make the tooltip window for which we're being called the "current" tooltip window
	Tooltips.curTooltipWindow = prevATooltipWindow -- restore the current tooltip window (required for proper clean-up when multiple tooltips are shown at once)
end

------------------------ DEBUG TOOLS ---------------------------

function Nisp.RButtonUp(buttonId, flags)
	if(flags == SystemData.ButtonFlags.SHIFT and Nisp.DebugEnabled) then
		slot = EA_Window_Backpack.GetSlotFromActionButtonGroup( SystemData.ActiveWindow.name, buttonId )
		MouseOverItemData = DataUtils.GetItems()[slot]
		Nisp.DumpItem(MouseOverItemData.name)
	else
		OldInventoryRButtonUp(buttonId, flags)
	end
end

function Nisp.DumpItem(itemName)
	itemData = Nisp.GetItemByName(itemName)
	if(Nisp.Contains(itemData.uniqueID) == false) then
		table.insert(Nisp.DumpItemsTable, itemData)
		Nisp.Contains(itemData.name)
		EA_ChatWindow.Print(L"Dumped item: "..itemData.name)
	else
		EA_ChatWindow.Print(L"Item Dump contains item: "..itemData.name)
	end
end

function Nisp.GetItemByName(itemName)
	for slotId, itemData in pairs(DataUtils.GetItems()) do
		if itemData.name == itemName and itemName ~= "" then
			return itemData
		end
	end
end

function Nisp.Contains(uniqueID)
	for slotId, itemData in ipairs(Nisp.DumpItemsTable) do
		if(itemData.uniqueID == uniqueID) then
			return true
		end
	end

	return false
end

function Nisp.DumpClear()
	Nisp.DumpItemsTable = {}
	EA_ChatWindow.Print(L"Dump Table Cleared")
end
