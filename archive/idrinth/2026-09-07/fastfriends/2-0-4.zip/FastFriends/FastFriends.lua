-- DECLARE ADDON ---------------------------------------------------------------
FastFriends = {
    version = "2.04",
    hasLoaded = false,
    loginMsgShown = false,
    bootPrintPending = false,
    bootElapsed = 0,
    bootPrintDelaySec = 0.25,
    serverName = "",
    factionKey = "",
    myName = "",
    actionQueue = {},
    isDebug = false,
    -- Advanced sync controls (persisted in FastFriendsDB._settings)
    -- Defaults are set during OnInitialize.
    syncMaster = true,
    syncMode = "opt-in",   -- one of: "all", "level", "opt-in" (default: opt-in)
    minLevel = 16,
    listFriends = true,
    listIgnore = true,
    db = nil, -- points to FastFriendsDB[serverName][factionKey]
    slash = { ff = false, fastfriends = false },
    firstSyncPending = false, -- true until a character completes its initial sync in this server+faction
    syncActive = false,
    initReconcilePending = false,
    initReconcileElapsed = 0,
    initReconcileMaxWaitSec = 10.0,
    pendingAction = nil,
    pendingElapsed = 0,
    verifyDelaySec = 1.0,
    retryLimit = 4,
    socialEventsRegistered = false,
    rescanAfterSync = false,
    synclog = false,
    debugListSnapshots = false,
    listServerCaps = { friend = 100, ignore = 100 }, -- server-advertised maxima
    listCapBuffer = { friend = 1, ignore = 1 },      -- guard slots kept free (actual limit = server cap - buffer)
    listCaps = nil,                                  -- optional explicit overrides for actual limits
    listWarnRemainingPercent = { friend = 0.1, ignore = 0.1 },
    listCapacityState = nil,
    lastWorldEvent = nil,
    initBootstrapDone = false,
    identityPending = false,
    identityWaitElapsed = 0,
    identityWaitIntervalSec = 0.2,
    pendingLoadingEnd = false,
    noteSupportEnabled = false,
    noteSupportReason = nil,
    listCountsReady = { friend = false, ignore = false },
    loginMsgCountsPending = false,
    loginMsgPendingLists = { friend = false, ignore = false },
    initialDiffConfirmMinThreshold = 10,
    initialDiffConfirmThresholdRatio = 0.5,
    initialDiffConfirmPreviewLimit = 8,
    initialDiffConfirmReminderSec = 10.0,
    initialDiffConfirmState = nil,
    wasSeenAtLogin = false,
    localListCache = { friend = nil, ignore = nil },
    localListCacheDirty = { friend = true, ignore = true },
    localListSnapshot = { friend = nil, ignore = nil }
}
--------------------------------------------------------------------------------

local ff_debugSortedNamesFromMap
local ff_debugPreview
local ff_debugServerListSnapshot
local ff_ensure_realm_bucket
local ff_debug_dump_friend_note
local ff_force_note_rescan


-- EVENT HANDLERS --------------------------------------------------------------
function FastFriends.OnInitialize()
    FastFriends.Debug("FastFriends.OnInitialize()")

    -- reset loaded flag for /reloadui and zoning
    FastFriends.hasLoaded = false
    FastFriends.loginMsgShown = false

    -- reset deferred bootstrap state
    FastFriends.initBootstrapDone = false
    FastFriends.identityPending = false
    FastFriends.identityWaitElapsed = 0
    FastFriends.pendingLoadingEnd = false
    FastFriends.ResetCapacityState()
    FastFriends.listCountsReady = { friend = false, ignore = false }
    FastFriends.loginMsgCountsPending = false
    FastFriends.loginMsgPendingLists = { friend = false, ignore = false }
    FastFriends.initialDiffConfirmState = nil
    FastFriends.wasSeenAtLogin = false
    FastFriends.localListCache = { friend = nil, ignore = nil }
    FastFriends.localListCacheDirty = { friend = true, ignore = true }
    FastFriends.localListSnapshot = { friend = nil, ignore = nil }

    -- load player name
    FastFriends.myName = FastFriends.TrimName(GameData.Player.name)

    -- reset boot-print fallback until bootstrap completes
    FastFriends.bootPrintPending = false
    FastFriends.bootElapsed = 0

    FastFriends.TryCompleteBootstrap()
end

-- Deferred bootstrap helpers -------------------------------------------------
local function ff_trim_identity(text)
    local s = tostring(text or "")
    s = string.gsub(s, "^%s+", "")
    s = string.gsub(s, "%s+$", "")
    return s
end

function FastFriends.ResolveServerName()
    local account = GameData and GameData.Account
    if not (account and account.ServerName) then return nil end
    local raw = account.ServerName
    local t = type(raw)
    local s
    if t == "wstring" then
        if WStringToString then
            s = WStringToString(raw)
        else
            s = tostring(raw)
        end
    else
        s = tostring(raw)
    end
    if s == nil then return nil end
    s = ff_trim_identity(s)
    if s == "" or s == "nil" then return nil end
    return s
end

function FastFriends.ResolveFactionKey()
    local player = GameData and GameData.Player
    if not player then return nil end
    local realm = player.realm
    if realm == 1 then return "Order" end
    if realm == 2 then return "Destruction" end
    return nil
end

function FastFriends.BootstrapSession()
    -- Ensure per-character DB exists even if the helper addon isn't loaded in tests
    if FastFriendsCharDB == nil then FastFriendsCharDB = {} end

    FastFriends.RefreshFriendNoteSupport()

    -- initialize friends database and server table
    if FastFriendsDB == nil then FastFriendsDB = {} end
    -- settings bucket (installation-global); persist debug across reloads
    if FastFriendsDB._settings == nil then FastFriendsDB._settings = {} end
    if FastFriendsDB._settings.debug == nil then FastFriendsDB._settings.debug = false end
    FastFriends.isDebug = FastFriendsDB._settings.debug and true or false
    -- synclog toggle (prints per-entry changes during sync)
    if FastFriendsDB._settings.synclog == nil then FastFriendsDB._settings.synclog = false end
    FastFriends.synclog = FastFriendsDB._settings.synclog and true or false
    -- Advanced sync settings (installation-global)
    if FastFriendsDB._settings.syncMaster == nil then FastFriendsDB._settings.syncMaster = true end
    if FastFriendsDB._settings.syncMode == nil then FastFriendsDB._settings.syncMode = "opt-in" end
    if FastFriendsDB._settings.minLevel == nil then FastFriendsDB._settings.minLevel = 16 end
    if FastFriendsDB._settings.listFriends == nil then FastFriendsDB._settings.listFriends = true end
    if FastFriendsDB._settings.listIgnore == nil then FastFriendsDB._settings.listIgnore = true end
    -- Mirror into session fields for convenience
    FastFriends.syncMaster = FastFriendsDB._settings.syncMaster and true or false
    FastFriends.syncMode = tostring(FastFriendsDB._settings.syncMode or "opt-in")
    FastFriends.minLevel = tonumber(FastFriendsDB._settings.minLevel or 16) or 16
    FastFriends.listFriends = FastFriendsDB._settings.listFriends and true or false
    FastFriends.listIgnore = FastFriendsDB._settings.listIgnore and true or false

    -- No session flag: tests reset per-character DB explicitly per test.
    if FastFriendsDB[FastFriends.serverName] == nil then
        FastFriendsDB[FastFriends.serverName] = {}
    end

    -- reference server-level bucket for current session
    local serverDB = FastFriendsDB[FastFriends.serverName]

    -- ensure faction bucket exists
    if serverDB[FastFriends.factionKey] == nil then serverDB[FastFriends.factionKey] = {} end
    if serverDB[FastFriends.factionKey].friend == nil then serverDB[FastFriends.factionKey].friend = {} end
    if serverDB[FastFriends.factionKey].ignore == nil then serverDB[FastFriends.factionKey].ignore = {} end
    if serverDB[FastFriends.factionKey].friend._deleted == nil then serverDB[FastFriends.factionKey].friend._deleted = {} end
    if serverDB[FastFriends.factionKey].ignore._deleted == nil then serverDB[FastFriends.factionKey].ignore._deleted = {} end

    -- point convenience handle to current server+faction scope
    FastFriends.db = serverDB[FastFriends.factionKey]

    -- Migrate friend list entries to structured records (for descriptions)
    FastFriends.MigrateFriendRecords()

    -- Ensure our own character is never tracked in global lists (belt-and-suspenders)
    if FastFriends.db.friend then
        FastFriends.db.friend[FastFriends.myName] = nil
        if FastFriends.db.friend._deleted then FastFriends.db.friend._deleted[FastFriends.myName] = nil end
    end
    if FastFriends.db.ignore then
        FastFriends.db.ignore[FastFriends.myName] = nil
        if FastFriends.db.ignore._deleted then FastFriends.db.ignore._deleted[FastFriends.myName] = nil end
    end

    -- metadata bucket: track which characters have completed their first sync
    if FastFriends.db._meta == nil then FastFriends.db._meta = {} end
    if FastFriends.db._meta.seenChars == nil then FastFriends.db._meta.seenChars = {} end
    if FastFriends.db._meta.charOverrides == nil then FastFriends.db._meta.charOverrides = {} end
    -- Limbo table: pending per-character overrides scheduled from another character
    if FastFriends.db._meta.pendingCharOverrides == nil then FastFriends.db._meta.pendingCharOverrides = {} end
    if FastFriends.db._meta.friendNoteSeq == nil then FastFriends.db._meta.friendNoteSeq = 0 end
    if FastFriends.db._meta.friendNotePerChar == nil then FastFriends.db._meta.friendNotePerChar = {} end
    if FastFriends.db._meta.friendNoteDigest == nil then FastFriends.db._meta.friendNoteDigest = "" end
    FastFriends.noteScanElapsed = 0
    if FastFriends.noteScanIntervalSec == nil then FastFriends.noteScanIntervalSec = 1.0 end
    FastFriends.wasSeenAtLogin = (FastFriends.db._meta.seenChars[FastFriends.myName] == true)
    if FastFriends.db._meta.seenChars[FastFriends.myName] ~= true then
        FastFriends.firstSyncPending = true
    else
        FastFriends.firstSyncPending = false
    end

    -- If there is a per-character override, mirror it into the global table for
    -- visibility/back-compat (helps after renames and for /ff seen output).
    do
        local nm = tostring(FastFriends.myName or "")
        local co = FastFriendsCharDB and FastFriendsCharDB.override
        if co == true or co == false then
            FastFriends.db._meta.charOverrides[nm] = (co and true or false)
        end
    end

    -- If there is a pending override for this character, apply it immediately
    do
        local nm = tostring(FastFriends.myName or "")
        local pco = FastFriends.db._meta.pendingCharOverrides[nm]
        if pco == nil then
            pco = FastFriends.db._meta.pendingCharOverrides[string.lower(nm)]
            if pco ~= nil then
                -- Clean up the lowercase key after applying
                FastFriends.db._meta.pendingCharOverrides[string.lower(nm)] = nil
            end
        end
        if pco ~= nil then
            if pco == true or pco == false then
                -- Apply to per-character storage and mirror into global for listing/back-compat
                if FastFriendsCharDB then FastFriendsCharDB.override = (pco and true or false) end
                if FastFriends.db and FastFriends.db._meta and FastFriends.db._meta.charOverrides then
                    FastFriends.db._meta.charOverrides[nm] = (pco and true or false)
                end
                local v = (pco and "on" or "off")
                FastFriends.Print(towstring("Applied scheduled override for this character: sync="..v))
            elseif pco == "reset" then
                if FastFriendsCharDB then FastFriendsCharDB.override = nil end
                if FastFriends.db and FastFriends.db._meta and FastFriends.db._meta.charOverrides then
                    FastFriends.db._meta.charOverrides[nm] = nil
                end
                FastFriends.Print(L"Applied scheduled override for this character: reset to default")
            end
            FastFriends.db._meta.pendingCharOverrides[nm] = nil
        end
    end

    -- Create UI window (but don't show it yet)
    if FastFriends.UI and FastFriends.UI.CreateWindows then
        FastFriends.UI.CreateWindows()
    end

    -- register event handlers
    RegisterEventHandler( SystemData.Events.LOADING_END, "FastFriends.LoadingEnd" )

    -- register social events now
    FastFriends.RegisterSocialEvents()

    -- schedule one-shot initial reconcile via timer
    FastFriends.initReconcilePending = true
    FastFriends.initReconcileElapsed = 0
    FastFriends.Debug("Initial reconcile timer scheduled (init)")
    FastFriends.lastWorldEvent = "INIT"

    -- Fallback: if events do not trigger the automatic login message,
    -- print it after a brief delay so the timer can progress.
    FastFriends.bootPrintPending = true
    FastFriends.bootElapsed = 0

    -- register slash commands via LibSlash when available
    FastFriends.RegisterSlashCommands()

    -- print loaded message with preferred alias
    local alias = FastFriends.GetPreferredAlias()
    FastFriends.Print(towstring("Loaded v"..tostring(FastFriends.version)..". Use "..alias.." help"))

    -- One-time info message about installation-global storage (generic key)
    -- Migrate older versioned keys to a stable flag.
    if FastFriendsDB._notice_installation_global ~= true then
        if FastFriendsDB._notice_installation_global_2_0 == true or FastFriendsDB._notice_installation_global_1_8 == true or FastFriendsDB._notice_account_global_1_8 == true then
            FastFriendsDB._notice_installation_global = true
            FastFriendsDB._notice_installation_global_2_0 = nil
            FastFriendsDB._notice_installation_global_1_8 = nil
            FastFriendsDB._notice_account_global_1_8 = nil
        else
            FastFriends.Print(L"Storage is installation-global across characters.")
            FastFriends.Print(L"Log each character once per server/faction to refresh.")
            FastFriendsDB._notice_installation_global = true
        end
    end

    -- One-time hint for new default: opt-in mode
    if FastFriendsDB._notice_opt_in_default ~= true then
        local modeNow = string.lower(tostring(FastFriends.syncMode or "opt-in"))
        if modeNow == "opt-in" then
            local alias = FastFriends.GetPreferredAlias()
            FastFriends.Print(towstring("Sync is opt-in by default. Use "..alias.." char sync on or "..alias.." mode level|all."))
        end
        FastFriendsDB._notice_opt_in_default = true
    end
end

function FastFriends.TryCompleteBootstrap()
    if FastFriends.initBootstrapDone then return true end

    local server = FastFriends.ResolveServerName()
    local faction = FastFriends.ResolveFactionKey()

    if not server or not faction then
        FastFriends.identityPending = true
        return false
    end

    FastFriends.serverName = server
    FastFriends.factionKey = faction
    FastFriends.identityPending = false

    FastFriends.BootstrapSession()
    FastFriends.initBootstrapDone = true

    if FastFriends.pendingLoadingEnd then
        FastFriends.LoadingEnd()
    end

    return true
end


-- Friend note support detection ---------------------------------------------
local function ff_has_socialwindow_tables(sw)
    if type(sw) ~= "table" then return false end
    local root = sw.AddvancedFriends
    if type(root) ~= "table" then return false end
    local order = root.order
    local destro = root.destro
    if type(order) ~= "table" or type(destro) ~= "table" then return false end
    if type(order.localFriends) ~= "table" or type(destro.localFriends) ~= "table" then return false end
    return true
end

local function ff_has_socialwindow_mod()
    if type(Mods) ~= "table" then return false end
    if Mods["EA_SocialWindow"] ~= nil then return true end
    for key in pairs(Mods) do
        if type(key) == "string" and string.lower(key) == "ea_socialwindow" then
            return true
        end
    end
    return false
end

function FastFriends.RefreshFriendNoteSupport()
    local sw = _G.SocialWindowTabFriends
    local hasTables = ff_has_socialwindow_tables(sw)
    local hasMod = ff_has_socialwindow_mod()

    if hasTables and sw and sw.__ff_stub_no_notes then
        hasTables = false
    end

    if hasTables then
        FastFriends.noteSupportEnabled = true
        FastFriends.noteSupportReason = nil
        return true
    end

    FastFriends.noteSupportEnabled = false
    if hasMod then
        FastFriends.noteSupportReason = "EA_SocialWindow detected but AddvancedFriends data is missing."
    elseif sw then
        FastFriends.noteSupportReason = "EA_SocialWindow tables found but AddvancedFriends structure is incomplete."
    else
        FastFriends.noteSupportReason = "EA_SocialWindow not detected."
    end
    return false
end

function FastFriends.CanSyncFriendNotes()
    if FastFriends.noteSupportEnabled then
        return true
    end
    return FastFriends.RefreshFriendNoteSupport()
end

-- Cleanup on UI shutdown ------------------------------------------------------
local function ff_flush_friend_notes_on_shutdown()
    if FastFriends == nil then return end
    if not FastFriends.IsListEnabled or not FastFriends.IsListEnabled("friend") then return end
    local ok, err = pcall(function()
        local localFriends, available = FastFriends.GetShutdownLocalNameList("friend")
        if available then
            FastFriends.ScanLocalFriendNotes(localFriends)
        end
    end)
    if not ok then
        FastFriends.Debug("OnShutdown note flush skipped: "..tostring(err))
    end
end

local function ff_flush_social_lists_on_shutdown()
    if FastFriends == nil then return end
    if not FastFriends.initBootstrapDone then return end
    if FastFriends.db == nil then return end

    local canSync, _ = FastFriends.ShouldSync()
    if not canSync then return end

    local ok, err = pcall(function()
        if FastFriends.db.friend and FastFriends.IsListEnabled("friend") then
            local localFriends, available = FastFriends.GetShutdownLocalNameList("friend")
            if available then
                FastFriends.PromoteLocalEntriesToGlobal(localFriends, FastFriends.db.friend, "friend")
                FastFriends.AddToDeletedList(localFriends, "friend")
                if FastFriends.db._meta then
                    if FastFriends.CanSyncFriendNotes() then
                        FastFriends.db._meta.friendNoteDigest = FastFriends.ComputeFriendNoteDigest(localFriends)
                    else
                        FastFriends.db._meta.friendNoteDigest = ""
                    end
                end
            end
        end

        local localIgnores = nil
        local ignoreAvailable = false
        if FastFriends.db.ignore or FastFriends.db.friend then
            localIgnores, ignoreAvailable = FastFriends.GetShutdownLocalNameList("ignore")
        end

        if ignoreAvailable then
            FastFriends.HandleIgnoredFriends(localIgnores)
            if FastFriends.db.ignore and FastFriends.IsListEnabled("ignore") then
                FastFriends.PromoteLocalEntriesToGlobal(localIgnores, FastFriends.db.ignore, "ignore")
                FastFriends.AddToDeletedList(localIgnores, "ignore")
            end
        end
    end)
    if not ok then
        FastFriends.Debug("OnShutdown social flush skipped: "..tostring(err))
    end
end

function FastFriends.OnShutdown()
    ff_flush_friend_notes_on_shutdown()
    ff_flush_social_lists_on_shutdown()
    -- Unregister our event handlers to avoid duplicate bindings across reloads
    UnregisterEventHandler(SystemData.Events.LOADING_END, "FastFriends.LoadingEnd")
    FastFriends.UnregisterSocialEvents()
end


function FastFriends.LoadingEnd()
    FastFriends.Debug("FastFriends.LoadingEnd()")
    FastFriends.RefreshFriendNoteSupport()
    if not FastFriends.initBootstrapDone then
        FastFriends.pendingLoadingEnd = true
        return
    end
    FastFriends.pendingLoadingEnd = false
    FastFriends.lastWorldEvent = "LOADING_END"

    if not FastFriends.hasLoaded then
        -- If no initial reconcile timer is pending yet, schedule it; otherwise, keep current timer.
        FastFriends.hasLoaded = true

        -- Print login status once automatically if not already printed
        if not FastFriends.loginMsgShown then
            FastFriends.MaybePrintLoginMessage(true)
        end

        -- Start the initial reconcile timer if not already pending
        if not FastFriends.initReconcilePending then
            FastFriends.initReconcilePending = true
            FastFriends.initReconcileElapsed = 0
            FastFriends.Debug("Initial reconcile timer started")
        else
            FastFriends.Debug("Initial reconcile timer already pending")
        end

        -- If this is a brand-new character for this server/faction and we have no actions to run,
        -- mark initialization now so seenChars is persisted on first logout.
        if FastFriends.firstSyncPending and #FastFriends.actionQueue == 0 then
            FastFriends.MarkCharInitialized()
            FastFriends.firstSyncPending = false
        end

        return
    end
end


function FastFriends.Update()
    if not FastFriends.initBootstrapDone then
        if not FastFriends.TryCompleteBootstrap() then
            return
        end
    end
    -- Do nothing until initial login status line has been printed automatically
    if not FastFriends.loginMsgShown then return end
    -- Suppress event-driven reconciliation during the initial reconcile timer
    if FastFriends.initReconcilePending then return end
    if FastFriends.HasPendingInitialDiffConfirmation() then return end
    -- When actively syncing, let OnUpdate own the flow to reduce churn.
    if FastFriends.syncActive then return end
    -- Check character-level sync eligibility (master/mode/override)
    local canSync, _ = FastFriends.ShouldSync()
    if not canSync then return end
    FastFriends.Debug("FastFriends.Update(): #FastFriends.actionQueue="..tostring(#FastFriends.actionQueue))

    -- If this is the first session for this character in this server+faction,
    -- suppress deletion detection until we've drained the initial action queue.
    if FastFriends.firstSyncPending and #FastFriends.actionQueue == 0 then
        -- Mark as initialized and skip count-based reconciliation this tick
        FastFriends.MarkCharInitialized()
        FastFriends.firstSyncPending = false
        return
    end

    if #FastFriends.actionQueue == 0 then
        -- determine if an add or delete occurred
        local friendEnabled = FastFriends.IsListEnabled("friend")
        local ignoreEnabled = FastFriends.IsListEnabled("ignore")
        local localFriends = {}
        local localIgnores = {}

        if friendEnabled then
            localFriends = FastFriends.ConsumeCachedLocalList("friend") or FastFriends.GetLocalNameList("friend")
        else
            -- Drop any stale cache if the list was disabled after caching.
            FastFriends.ConsumeCachedLocalList("friend")
        end
        if ignoreEnabled then
            localIgnores = FastFriends.ConsumeCachedLocalList("ignore") or FastFriends.GetLocalNameList("ignore")
        else
            FastFriends.ConsumeCachedLocalList("ignore")
        end

        if friendEnabled and FastFriends.db and FastFriends.db.friend then
            FastFriends.DebugListSnapshot("Update local", "friend", localFriends)
            FastFriends.DebugListSnapshot("Update global", "friend", FastFriends.db.friend)
            FastFriends.DebugDeletedSnapshot("Update global friend", FastFriends.db.friend._deleted)
            FastFriends.DebugListDiff("Update", "friend", localFriends, FastFriends.db.friend)
        end
        if ignoreEnabled and FastFriends.db and FastFriends.db.ignore then
            FastFriends.DebugListSnapshot("Update local", "ignore", localIgnores)
            FastFriends.DebugListSnapshot("Update global", "ignore", FastFriends.db.ignore)
            FastFriends.DebugDeletedSnapshot("Update global ignore", FastFriends.db.ignore._deleted)
            FastFriends.DebugListDiff("Update", "ignore", localIgnores, FastFriends.db.ignore)
        end

        local localFriendCount = FastFriends.GetTableSize(localFriends)
        local localIgnoreCount = FastFriends.GetTableSize(localIgnores)
        local globalFriendCount = FastFriends.GetTableSize(FastFriends.db.friend)
        local globalIgnoreCount = FastFriends.GetTableSize(FastFriends.db.ignore)

        FastFriends.Debug("localFriendCount: "..tostring(localFriendCount).." / globalFriends: "..tostring(globalFriendCount))
        FastFriends.Debug("localIgnoreCount: "..tostring(localIgnoreCount).." / globalIgnores: "..tostring(globalIgnoreCount))

        FastFriends.EvaluateCapacity("friend", localFriendCount)
        FastFriends.EvaluateCapacity("ignore", localIgnoreCount)

        if friendEnabled and localFriendCount > globalFriendCount then
            FastFriends.Reconcile(localFriends, FastFriends.db.friend, "friend")
        elseif ignoreEnabled and localIgnoreCount > globalIgnoreCount then
            FastFriends.Reconcile(localIgnores, FastFriends.db.ignore, "ignore")
        elseif friendEnabled and localFriendCount < globalFriendCount then
            FastFriends.AddToDeletedList(localFriends, "friend")
        elseif ignoreEnabled and localIgnoreCount < globalIgnoreCount then
            FastFriends.AddToDeletedList(localIgnores, "ignore")
        elseif friendEnabled and FastFriends.HasBidirectionalListDiff(localFriends, FastFriends.db.friend) then
            -- Equal-count swap (e.g. rename): run reconcile so stale global names can be cleaned.
            FastFriends.Reconcile(localFriends, FastFriends.db.friend, "friend")
        elseif ignoreEnabled and FastFriends.HasBidirectionalListDiff(localIgnores, FastFriends.db.ignore) then
            FastFriends.Reconcile(localIgnores, FastFriends.db.ignore, "ignore")
        end
    else
        -- Queue has work; switch to sync mode and let OnUpdate handle it
        FastFriends.SyncBegin()
    end
end
--------------------------------------------------------------------------------


-- CUSTOM METHODS --------------------------------------------------------------
function FastFriends.ReconcileDeletes(localList, deleteList, reconcileType)
    FastFriends.Debug("FastFriends.ReconcileDeletes: "..reconcileType)
    if localList == nil then return {} end
    if deleteList == nil then return localList end

    -- Collect first, then mutate: avoids table-walk edge cases in older runtimes.
    local pendingRemovals = {}
    for name,_ in pairs(localList) do
        if deleteList[name] ~= nil then
            pendingRemovals[#pendingRemovals + 1] = name
        end
    end
    for i = 1, #pendingRemovals do
        local name = pendingRemovals[i]
        FastFriends.SyncLog("Queue: remove '"..name.."' from local "..reconcileType.." list")
        FastFriends.AddAction(name, reconcileType, "remove")
        localList[name] = nil
    end

    return localList
end

function FastFriends.GetBidirectionalListDiff(localList, globalList)
    local localOnly = {}
    local globalOnly = {}
    if localList == nil or globalList == nil then
        return localOnly, globalOnly
    end
    for name,_ in pairs(localList) do
        if name ~= "_deleted" and name ~= FastFriends.myName and globalList[name] == nil then
            localOnly[#localOnly + 1] = name
        end
    end
    for name,_ in pairs(globalList) do
        if name ~= "_deleted" and name ~= FastFriends.myName and localList[name] == nil then
            globalOnly[#globalOnly + 1] = name
        end
    end
    return localOnly, globalOnly
end

function FastFriends.HasBidirectionalListDiff(localList, globalList)
    local localOnly, globalOnly = FastFriends.GetBidirectionalListDiff(localList, globalList)
    return (#localOnly > 0 and #globalOnly > 0)
end

function FastFriends.IsSeenCharacter()
    if FastFriends.db == nil or FastFriends.db._meta == nil then return false end
    local seen = FastFriends.db._meta.seenChars
    if seen == nil then return false end
    return seen[FastFriends.myName] == true
end

function FastFriends.HasPendingInitialDiffConfirmation()
    local state = FastFriends.initialDiffConfirmState
    return state ~= nil and state.status == "pending"
end

function FastFriends.ClearInitialDiffConfirmation()
    FastFriends.initialDiffConfirmState = nil
end

function FastFriends.BuildInitialDiffListSummary(localList, globalList, deleteList, listType)
    local summary = {
        listType = listType,
        localCount = FastFriends.GetTableSize(localList or {}),
        globalCount = FastFriends.GetTableSize(globalList or {}),
        referenceSize = 0,
        deleted = 0,
        deletedNames = {},
        localOnly = 0,
        localOnlyNames = {},
        globalOnly = 0,
        globalOnlyNames = {},
        total = 0
    }
    summary.referenceSize = summary.localCount
    if summary.globalCount > summary.referenceSize then
        summary.referenceSize = summary.globalCount
    end

    local working = FastFriends.CopyLocalListSnapshot(localList or {})
    if deleteList ~= nil then
        for name, _ in pairs(working) do
            if name ~= "_deleted" and name ~= FastFriends.myName and deleteList[name] ~= nil then
                summary.deleted = summary.deleted + 1
                summary.deletedNames[#summary.deletedNames + 1] = tostring(name)
                working[name] = nil
            end
        end
    end
    local localOnlyNames, globalOnlyNames = FastFriends.GetBidirectionalListDiff(working, globalList or {})
    table.sort(summary.deletedNames, function(a, b)
        return string.lower(a) < string.lower(b)
    end)
    table.sort(localOnlyNames, function(a, b)
        return string.lower(a) < string.lower(b)
    end)
    table.sort(globalOnlyNames, function(a, b)
        return string.lower(a) < string.lower(b)
    end)
    summary.localOnly = #localOnlyNames
    summary.localOnlyNames = localOnlyNames
    summary.globalOnly = #globalOnlyNames
    summary.globalOnlyNames = globalOnlyNames
    summary.total = summary.deleted + summary.localOnly + summary.globalOnly
    return summary
end

function FastFriends.BuildInitialDiffConfirmState(localFriends, localIgnores)
    if not FastFriends.wasSeenAtLogin then return nil end

    local minThreshold = tonumber(FastFriends.initialDiffConfirmMinThreshold or 10) or 10
    if minThreshold < 1 then minThreshold = 1 end
    local ratio = tonumber(FastFriends.initialDiffConfirmThresholdRatio or 0.5) or 0.5
    if ratio < 0 then ratio = 0 end

    local state = {
        status = "pending",
        threshold = minThreshold,
        minThreshold = minThreshold,
        thresholdRatio = ratio,
        total = 0,
        referenceSize = 0,
        reminderElapsed = 0,
        reminderCount = 0,
        friendEnabled = FastFriends.IsListEnabled("friend"),
        ignoreEnabled = FastFriends.IsListEnabled("ignore"),
        friend = nil,
        ignore = nil
    }

    if state.friendEnabled then
        state.friend = FastFriends.BuildInitialDiffListSummary(localFriends or {}, FastFriends.db.friend, FastFriends.db.friend and FastFriends.db.friend._deleted, "friend")
        state.total = state.total + (state.friend.total or 0)
        state.referenceSize = state.referenceSize + (state.friend.referenceSize or 0)
    end
    if state.ignoreEnabled then
        state.ignore = FastFriends.BuildInitialDiffListSummary(localIgnores or {}, FastFriends.db.ignore, FastFriends.db.ignore and FastFriends.db.ignore._deleted, "ignore")
        state.total = state.total + (state.ignore.total or 0)
        state.referenceSize = state.referenceSize + (state.ignore.referenceSize or 0)
    end

    local ratioThreshold = math.ceil((state.referenceSize or 0) * ratio)
    if ratioThreshold < 1 then ratioThreshold = 1 end
    if ratioThreshold > state.threshold then
        state.threshold = ratioThreshold
    end

    if state.total < state.threshold then return nil end
    return state
end

local function ff_format_initial_diff_detail(label, summary)
    if summary == nil or (summary.total or 0) <= 0 then return nil end
    local parts = {}
    if (summary.deleted or 0) > 0 then
        parts[#parts + 1] = "local-removals="..tostring(summary.deleted)
    end
    if (summary.localOnly or 0) > 0 then
        parts[#parts + 1] = "global-adds="..tostring(summary.localOnly)
    end
    if (summary.globalOnly or 0) > 0 then
        parts[#parts + 1] = "local-adds="..tostring(summary.globalOnly)
    end
    if #parts == 0 then return nil end
    return label..": "..table.concat(parts, ", ")
end

function FastFriends.FormatInitialDiffConfirmSummary(state)
    if state == nil then return "0 entries" end
    local details = {}
    local friendDetail = ff_format_initial_diff_detail("friends", state.friend)
    if friendDetail ~= nil then details[#details + 1] = friendDetail end
    local ignoreDetail = ff_format_initial_diff_detail("ignore", state.ignore)
    if ignoreDetail ~= nil then details[#details + 1] = ignoreDetail end
    local triggerText = ""
    if (state.referenceSize or 0) > 0 then
        triggerText = string.format("; threshold=%d/%d", tonumber(state.threshold or 0) or 0, tonumber(state.referenceSize or 0) or 0)
    end
    if #details == 0 then
        return tostring(state.total or 0).." entries"..triggerText
    end
    return string.format("%d entries (%s%s)", tonumber(state.total or 0) or 0, table.concat(details, "; "), triggerText)
end

function FastFriends.PrintInitialDiffConfirmPrompt(state)
    if state == nil then return end
    local alias = FastFriends.GetPreferredAlias()
    local name = tostring(FastFriends.myName or "?")
    local summary = FastFriends.FormatInitialDiffConfirmSummary(state)
    FastFriends.Print(towstring("Large initial diff detected for seen character '"..name.."': "..summary.."."))
    FastFriends.Print(towstring("Run "..alias.." confirm status to review names, "..alias.." confirm to apply it, or "..alias.." confirm no to keep this character's current lists as global."))
end

local function ff_format_initial_diff_name_preview(names)
    if names == nil or #names == 0 then return nil end
    local limit = tonumber(FastFriends.initialDiffConfirmPreviewLimit or 8) or 8
    if limit < 1 then limit = 1 end
    local preview = {}
    local maxIndex = #names
    if maxIndex > limit then maxIndex = limit end
    for i = 1, maxIndex do
        preview[#preview + 1] = tostring(names[i])
    end
    local text = table.concat(preview, ", ")
    if #names > limit then
        text = text.." ... (+"..tostring(#names - limit).." more)"
    end
    return text
end

local function ff_print_initial_diff_name_group(label, names)
    if names == nil or #names == 0 then return end
    local preview = ff_format_initial_diff_name_preview(names)
    if preview == nil then return end
    FastFriends.Print(towstring(label.." ("..tostring(#names).."): "..preview))
end

function FastFriends.PrintInitialDiffConfirmDetails(state)
    if state == nil then return end
    local name = tostring(FastFriends.myName or "?")
    FastFriends.Print(towstring("Pending initial diff for '"..name.."': "..FastFriends.FormatInitialDiffConfirmSummary(state)))
    if state.friend ~= nil then
        ff_print_initial_diff_name_group("Friends add locally from global", state.friend.globalOnlyNames)
        ff_print_initial_diff_name_group("Friends add globally from local", state.friend.localOnlyNames)
        ff_print_initial_diff_name_group("Friends remove locally (deleted globally)", state.friend.deletedNames)
    end
    if state.ignore ~= nil then
        ff_print_initial_diff_name_group("Ignore add locally from global", state.ignore.globalOnlyNames)
        ff_print_initial_diff_name_group("Ignore add globally from local", state.ignore.localOnlyNames)
        ff_print_initial_diff_name_group("Ignore remove locally (deleted globally)", state.ignore.deletedNames)
    end
end

function FastFriends.ProcessInitialDiffConfirmReminder(dt)
    local state = FastFriends.initialDiffConfirmState
    if state == nil or state.status ~= "pending" then return end
    if (state.reminderCount or 0) >= 1 then return end

    local interval = tonumber(FastFriends.initialDiffConfirmReminderSec or 10.0) or 10.0
    if interval <= 0 then return end

    state.reminderElapsed = (state.reminderElapsed or 0) + FastFriends.ResolveDelta(dt)
    if state.reminderElapsed < interval then return end

    state.reminderElapsed = 0
    state.reminderCount = (state.reminderCount or 0) + 1
    FastFriends.Print(L"Still waiting for initial diff confirmation.")
    FastFriends.PrintInitialDiffConfirmPrompt(state)
end


-- List capacity helpers -------------------------------------------------------
function FastFriends.ResetCapacityState()
    FastFriends.listCapacityState = {
        friend = { limitWarned = false, nearWarned = false, blocked = {} },
        ignore = { limitWarned = false, nearWarned = false, blocked = {} }
    }
end

function FastFriends.GetCapacityState(listType)
    if FastFriends.listCapacityState == nil then
        FastFriends.ResetCapacityState()
    end
    local state = FastFriends.listCapacityState[listType]
    if state == nil then
        state = { limitWarned = false, nearWarned = false, blocked = {} }
        FastFriends.listCapacityState[listType] = state
    else
        if state.limitWarned == nil then state.limitWarned = false end
        if state.nearWarned == nil then state.nearWarned = false end
        if state.blocked == nil then state.blocked = {} end
    end
    return state
end

local function ff_init_list_count_state()
    if FastFriends.listCountsReady == nil then
        FastFriends.listCountsReady = { friend = false, ignore = false }
    else
        if FastFriends.listCountsReady.friend == nil then FastFriends.listCountsReady.friend = false end
        if FastFriends.listCountsReady.ignore == nil then FastFriends.listCountsReady.ignore = false end
    end
    if FastFriends.loginMsgPendingLists == nil then
        FastFriends.loginMsgPendingLists = { friend = false, ignore = false }
    else
        if FastFriends.loginMsgPendingLists.friend == nil then FastFriends.loginMsgPendingLists.friend = false end
        if FastFriends.loginMsgPendingLists.ignore == nil then FastFriends.loginMsgPendingLists.ignore = false end
    end
end

local function ff_collect_login_counts(fOn, iOn)
    local counts = {
        friendCount = nil,
        ignoreCount = nil,
        pending = { friend = false, ignore = false }
    }
    if fOn then
        if FastFriends.IsListCountReady("friend") then
            counts.friendCount = FastFriends.GetLocalListCount("friend")
        else
            counts.pending.friend = true
        end
    end
    if iOn then
        if FastFriends.IsListCountReady("ignore") then
            counts.ignoreCount = FastFriends.GetLocalListCount("ignore")
        else
            counts.pending.ignore = true
        end
    end
    return counts
end

function FastFriends.BeginLoginMsgConfirm(fOn, iOn, counts)
    local state = FastFriends.loginMsgConfirmState
    if state == nil or state.status ~= "pending" then
        state = {
            status = "pending",
            friendEnabled = fOn and true or false,
            ignoreEnabled = iOn and true or false,
            friendCount = counts.friendCount,
            ignoreCount = counts.ignoreCount,
            waitFrames = 0,
            source = nil
        }
        FastFriends.loginMsgConfirmState = state
        return state
    end

    state.friendEnabled = fOn and true or false
    state.ignoreEnabled = iOn and true or false
    state.friendCount = counts.friendCount
    state.ignoreCount = counts.ignoreCount
    state.waitFrames = 0
    return state
end

function FastFriends.IsListCountReady(listType)
    if listType ~= "friend" and listType ~= "ignore" then return false end
    ff_init_list_count_state()
    return FastFriends.listCountsReady[listType] and true or false
end

function FastFriends.MarkListCountsReady(listType)
    if listType ~= "friend" and listType ~= "ignore" then return end
    ff_init_list_count_state()
    if FastFriends.listCountsReady[listType] then return end
    FastFriends.listCountsReady[listType] = true
    FastFriends.CheckLoginMessageFollowup()
end

local function ff_update_loginmsg_pending(listType, needed)
    ff_init_list_count_state()
    if listType ~= "friend" and listType ~= "ignore" then return end
    FastFriends.loginMsgPendingLists[listType] = needed and true or false
    FastFriends.loginMsgCountsPending = (FastFriends.loginMsgPendingLists.friend and true or false)
        or (FastFriends.loginMsgPendingLists.ignore and true or false)
end

function FastFriends.ClearLoginMessagePending()
    ff_init_list_count_state()
    FastFriends.loginMsgPendingLists.friend = false
    FastFriends.loginMsgPendingLists.ignore = false
    FastFriends.loginMsgCountsPending = false
end

function FastFriends.CheckLoginMessageFollowup()
    if FastFriends.loginMsgConfirmState and FastFriends.loginMsgConfirmState.status == "pending" then
        return
    end
    if not FastFriends.loginMsgCountsPending then return end
    if not FastFriends.loginMsgShown then return end
    ff_init_list_count_state()
    if FastFriends.loginMsgPendingLists.friend and not FastFriends.IsListCountReady("friend") then return end
    if FastFriends.loginMsgPendingLists.ignore and not FastFriends.IsListCountReady("ignore") then return end
    FastFriends.ClearLoginMessagePending()
    FastFriends.MaybePrintLoginMessage(false, true)
end

function FastFriends.GetListServerCap(listType)
    if FastFriends.listServerCaps == nil then return nil end
    local cap = FastFriends.listServerCaps[listType]
    if cap == nil then return nil end
    cap = tonumber(cap)
    if cap and cap > 0 then return cap end
    return nil
end

function FastFriends.GetListCapBuffer(listType)
    local buffer = 0
    if FastFriends.listCapBuffer ~= nil then
        local v = FastFriends.listCapBuffer[listType]
        if v ~= nil then
            buffer = tonumber(v) or 0
        end
    end
    if buffer < 0 then buffer = 0 end
    return buffer
end

function FastFriends.GetListCap(listType)
    if FastFriends.listCaps ~= nil then
        local override = FastFriends.listCaps[listType]
        if override ~= nil then
            local cap = tonumber(override)
            if cap and cap > 0 then return cap end
            return nil
        end
    end
    local serverCap = FastFriends.GetListServerCap(listType)
    if not serverCap then return nil end
    local buffer = FastFriends.GetListCapBuffer(listType)
    local cap = serverCap - buffer
    if cap < 0 then cap = 0 end
    return cap
end

function FastFriends.GetCapacityWarnRemaining(listType, cap)
    if not cap or cap <= 0 then return nil end
    local slots = nil
    if FastFriends.listWarnRemainingSlots then
        local v = FastFriends.listWarnRemainingSlots[listType]
        if v ~= nil then
            local n = tonumber(v)
            if n and n >= 0 then slots = n end
        end
    end
    if slots == nil then
        local pct = nil
        if FastFriends.listWarnRemainingPercent then
            pct = tonumber(FastFriends.listWarnRemainingPercent[listType])
        end
        if pct == nil then pct = 0.1 end
        if pct <= 0 then return nil end
        local computed = math.floor(cap * pct + 0.5)
        if computed < 1 then computed = 1 end
        slots = computed
    end
    if slots <= 0 then return nil end
    if slots > cap then slots = cap end
    return slots
end

function FastFriends.GetActionOp(action)
    if action == nil then return "add" end
    local op = action.op
    if op == "remove" then return "remove" end
    if op == "note" then return "note" end
    return "add"
end

function FastFriends.CountQueuedAdds(listType)
    local count = 0
    if FastFriends.pendingAction and FastFriends.pendingAction.type == listType and FastFriends.GetActionOp(FastFriends.pendingAction) == "add" then
        count = count + 1
    end
    for i = 1, #FastFriends.actionQueue do
        local a = FastFriends.actionQueue[i]
        if a and a.type == listType and FastFriends.GetActionOp(a) == "add" then
            count = count + 1
        end
    end
    return count
end

function FastFriends.GetListLabel(listType)
    if listType == "friend" then return "Friend list" end
    if listType == "ignore" then return "Ignore list" end
    return "List"
end

function FastFriends.MarkCapacityBlocked(listType, name, cap)
    local state = FastFriends.GetCapacityState(listType)
    if state == nil then return end
    if state.blocked[name] then return end
    state.blocked[name] = true
    state.limitWarned = true
    local label = FastFriends.GetListLabel(listType)
    local serverCap = FastFriends.GetListServerCap(listType)
    local trimHint
    if listType == "friend" then
        trimHint = " You can remove friends with /friendremove <Name> (or via the UI)."
    else
        trimHint = " You can remove ignores with /ignore <Name> (or via the UI)."
    end
    local msg
    if serverCap then
        msg = string.format("%s reached FastFriends limit %d (server cap %d). Skipping sync for '%s'. Trim entries to resume syncing.%s", label, cap, serverCap, name, trimHint)
    else
        msg = string.format("%s reached FastFriends limit %d. Skipping sync for '%s'. Trim entries to resume syncing.%s", label, cap, name, trimHint)
    end
    FastFriends.Print(towstring(msg))
end

function FastFriends.EvaluateCapacity(listType, localCount)
    if not FastFriends.IsListEnabled(listType) then return end
    local cap = FastFriends.GetListCap(listType)
    if not cap then return end
    local state = FastFriends.GetCapacityState(listType)
    if state == nil then return end
    local count = tonumber(localCount or 0) or 0
    if count < 0 then count = 0 end
    local queuedAdds = FastFriends.CountQueuedAdds(listType)
    local total = count + queuedAdds
    if total < 0 then total = 0 end
    local remaining = cap - total
    local label = FastFriends.GetListLabel(listType)
    local serverCap = FastFriends.GetListServerCap(listType)

    if total >= cap then
        if not state.limitWarned then
            local trimHint
            if listType == "friend" then
                trimHint = " You can also remove friends with /friendremove <Name>."
            else
                trimHint = " You can also remove ignores with /ignore <Name>."
            end
            local msg
            if serverCap then
                msg = string.format("%s reached FastFriends limit %d (server cap %d). Trim entries to unlock further sync.%s", label, cap, serverCap, trimHint)
            else
                msg = string.format("%s reached FastFriends limit %d. Trim entries to unlock further sync.%s", label, cap, trimHint)
            end
            FastFriends.Print(towstring(msg))
            state.limitWarned = true
        end
        state.nearWarned = true
        return
    end

    if state.limitWarned or (state.blocked and next(state.blocked) ~= nil) then
        state.limitWarned = false
        state.blocked = {}
    end

    local warnRemaining = FastFriends.GetCapacityWarnRemaining(listType, cap)
    if warnRemaining then
        if remaining <= warnRemaining then
            if not state.nearWarned then
                local slotsWord = (remaining == 1) and "slot" or "slots"
                local msg
                if serverCap then
                    msg = string.format("%s is nearly full (server cap %d, FastFriends limit %d, %d %s left).", label, serverCap, cap, remaining, slotsWord)
                else
                    msg = string.format("%s is nearly full (FastFriends limit %d, %d %s left).", label, cap, remaining, slotsWord)
                end
                FastFriends.Print(towstring(msg))
                state.nearWarned = true
            end
        else
            state.nearWarned = false
        end
    end
end


function FastFriends.Reconcile(localList, globalList, reconcileType)
    FastFriends.Debug("Reconcile(): "..reconcileType)

    -- add local characters to global list
    local isFriend = (reconcileType == "friend")
    local noteSupport = false
    if isFriend then noteSupport = FastFriends.CanSyncFriendNotes() end
    local charName = tostring(FastFriends.myName or "")
    local cap = FastFriends.GetListCap(reconcileType)
    local baseCount = FastFriends.GetTableSize(localList)
    local effectiveCount = baseCount
    if cap then
        effectiveCount = effectiveCount + FastFriends.CountQueuedAdds(reconcileType)
        FastFriends.EvaluateCapacity(reconcileType, baseCount)
    end
    -- Rename-like hint: only set when we see a swap pattern in this snapshot:
    -- local-only names and global-only names at the same time.
    local localOnlyNames, globalOnlyNames = FastFriends.GetBidirectionalListDiff(localList, globalList)
    local renameSwapCandidate = (#localOnlyNames > 0 and #globalOnlyNames > 0)
    local renameSwapStale = nil
    local renameSwapTarget = nil
    if isFriend and #localOnlyNames == 1 and #globalOnlyNames == 1 then
        renameSwapTarget = tostring(localOnlyNames[1] or "")
        renameSwapStale = tostring(globalOnlyNames[1] or "")
    end

    FastFriends.PromoteLocalEntriesToGlobal(localList, globalList, reconcileType)

    -- add global characters to local list or update description
    for name, entry in pairs(globalList) do
        if name ~= "_deleted" and name ~= FastFriends.myName then
            if localList[name] == nil then
                if cap and effectiveCount >= cap then
                    FastFriends.MarkCapacityBlocked(reconcileType, name, cap)
                else
                    FastFriends.SyncLog("Queue: add '"..name.."' to local "..reconcileType.." list")
                    local added = false
                    local actionRenameTarget = nil
                    if renameSwapTarget and renameSwapStale and name == renameSwapStale then
                        actionRenameTarget = renameSwapTarget
                    end
                    if isFriend then
                        if noteSupport then
                            local desc = FastFriends.GetFriendDescriptionFromValue(entry)
                            local seq = FastFriends.GetFriendSeqFromValue(entry)
                            local noteText = FastFriends.NormalizeNoteText(desc)
                            added = FastFriends.AddAction(name, reconcileType, "add", noteText, renameSwapCandidate, actionRenameTarget)
                            FastFriends.SetCharFriendSeq(name, seq)
                            if noteText ~= "" then
                                local queuedNote = FastFriends.AddAction(name, reconcileType, "note", noteText)
                                if queuedNote then
                                    FastFriends.SyncLog(string.format("Queue: note for '%s' -> '%s'", name, noteText))
                                end
                            end
                        else
                            added = FastFriends.AddAction(name, reconcileType, "add", nil, renameSwapCandidate, actionRenameTarget)
                        end
                    else
                        added = FastFriends.AddAction(name, reconcileType, "add", nil, renameSwapCandidate, actionRenameTarget)
                    end
                    if added and cap then
                        effectiveCount = effectiveCount + 1
                    end
                end
            elseif isFriend and noteSupport then
                local globalDesc = FastFriends.GetFriendDescriptionFromValue(entry)
                local localDesc = FastFriends.NormalizeDescription(localList[name])
                local entrySeq = FastFriends.GetFriendSeqFromValue(entry)
                local charSeq = FastFriends.GetFriendSeqForChar(charName, name)
                if globalDesc ~= localDesc then
                    if charSeq ~= entrySeq then
                        FastFriends.UpdateLocalFriendDescription(name, globalDesc)
                        FastFriends.SetCharFriendSeq(name, entrySeq)
                        localList[name].desc = globalDesc
                        FastFriends.DebugFriendNote("apply-global", name, string.format("desc='%s' seq=%d", FastFriends.AbbrevDesc(globalDesc), entrySeq))
                        FastFriends.SyncLog(string.format("Local: applied note for '%s' -> '%s'", name, globalDesc))
                    end
                else
                    FastFriends.SetCharFriendSeq(name, entrySeq)
                end
            end
        end
    end
    if cap then
        local finalCount = FastFriends.GetTableSize(localList)
        FastFriends.EvaluateCapacity(reconcileType, finalCount)
    end
end

function FastFriends.PromoteLocalEntriesToGlobal(localList, globalList, reconcileType)
    if localList == nil or globalList == nil then return false end

    local changed = false
    local isFriend = (reconcileType == "friend")
    local noteSupport = false
    if isFriend then noteSupport = FastFriends.CanSyncFriendNotes() end
    local charName = tostring(FastFriends.myName or "")

    for name, entry in pairs(localList) do
        if name ~= FastFriends.myName then
            local clearedDeleted = false
            if globalList._deleted and globalList._deleted[name] ~= nil then
                clearedDeleted = true
            end
            if isFriend then
                if noteSupport then
                    local localDesc = FastFriends.NormalizeDescription(entry)
                    local current = FastFriends.NormalizeGlobalFriendEntry(globalList, name)
                    if current == nil then
                        FastFriends.DebugFriendNote("promote-local", name, string.format("local='%s' seq(new)", FastFriends.AbbrevDesc(localDesc)))
                        FastFriends.SetGlobalFriendDescription(name, localDesc, charName)
                        FastFriends.EnsureGlobalPresence(reconcileType, name, FastFriends.NormalizeGlobalFriendEntry(globalList, name))
                        FastFriends.SyncLog("Global: added '"..name.."' to "..reconcileType.." list")
                        FastFriends.SyncLogNoteChange("Global", name, localDesc, nil)
                        changed = true
                    else
                        local globalDesc = FastFriends.GetFriendDescriptionFromValue(current)
                        local entrySeq = FastFriends.GetFriendSeqFromValue(current)
                        local charSeq = FastFriends.GetFriendSeqForChar(charName, name)
                        if localDesc ~= globalDesc then
                            local shouldPush = false
                            if entrySeq == 0 then
                                if globalDesc == "" and localDesc ~= "" then
                                    shouldPush = true
                                elseif charSeq == entrySeq then
                                    shouldPush = true
                                end
                            elseif charSeq == entrySeq then
                                shouldPush = true
                            end
                            if shouldPush then
                                local previousDesc = globalDesc
                                FastFriends.SetGlobalFriendDescription(name, localDesc, charName)
                                FastFriends.SyncLogNoteChange("Global", name, localDesc, previousDesc)
                                current = FastFriends.NormalizeGlobalFriendEntry(globalList, name)
                                entrySeq = FastFriends.GetFriendSeqFromValue(current)
                                globalDesc = FastFriends.GetFriendDescriptionFromValue(current)
                                FastFriends.DebugFriendNote("promote-local", name, string.format("applied local='%s' newSeq=%d", FastFriends.AbbrevDesc(localDesc), entrySeq))
                                changed = true
                            end
                        end
                        FastFriends.EnsureGlobalPresence(reconcileType, name, current)
                        if clearedDeleted then
                            changed = true
                        end
                    end
                else
                    if globalList[name] == nil then
                        globalList[name] = true
                        FastFriends.SyncLog("Global: added '"..name.."' to "..reconcileType.." list")
                        changed = true
                    end
                    FastFriends.EnsureGlobalPresence(reconcileType, name, globalList[name])
                    if clearedDeleted then
                        changed = true
                    end
                end
            else
                if globalList[name] == nil then
                    globalList[name] = true
                    FastFriends.SyncLog("Global: added '"..name.."' to "..reconcileType.." list")
                    changed = true
                end
                FastFriends.EnsureGlobalPresence(reconcileType, name, globalList[name])
                if clearedDeleted then
                    changed = true
                end
            end
        end
    end

    return changed
end


function FastFriends.AddAction(name, actionType, op, desc, renameCandidate, renameTarget)
    FastFriends.Debug("FastFriends.AddAction(): "..tostring(actionType).."/"..tostring(op).." - "..name)

    -- Normalize inputs
    local n = tostring(name)
    if n == tostring(FastFriends.myName or "") then return false end
    local t = tostring(actionType)
    local o = op or "add"
    local note = nil
    local wantNote = FastFriends.noteSupportEnabled or FastFriends.CanSyncFriendNotes()
    if o == "note" then wantNote = true end
    if desc ~= nil and wantNote then
        note = tostring(desc)
    end
    local renameFlag = (renameCandidate == true)
    local moveTarget = nil
    if renameTarget ~= nil then
        local target = tostring(renameTarget)
        if target ~= "" and target ~= n then
            moveTarget = target
        end
    end

    -- De-duplicate: skip if identical action is already queued or in-flight
    for i = 1, #FastFriends.actionQueue do
        local a = FastFriends.actionQueue[i]
        if a and a.name == n and a.type == t and (a.op or "add") == o then
            if note ~= nil then a.desc = note end
            if renameFlag then a.renameCandidate = true end
            if moveTarget ~= nil then a.renameTarget = moveTarget end
            return false
        end
    end
    if FastFriends.pendingAction and FastFriends.pendingAction.name == n and FastFriends.pendingAction.type == t and (FastFriends.pendingAction.op or "add") == o then
        if note ~= nil then FastFriends.pendingAction.desc = note end
        if renameFlag then FastFriends.pendingAction.renameCandidate = true end
        if moveTarget ~= nil then FastFriends.pendingAction.renameTarget = moveTarget end
        return false
    end

    local index = #FastFriends.actionQueue + 1
    FastFriends.actionQueue[index] = { name = n, type = t, op = o, retries = 0, desc = note, renameCandidate = renameFlag, renameTarget = moveTarget }
    return true
end

function FastFriends.DropFriendActionsForName(name, reason)
    local trimmed = tostring(name or "")
    if trimmed == "" then return false end
    local removed = false
    local i = 1
    while i <= #FastFriends.actionQueue do
        local a = FastFriends.actionQueue[i]
        if a and a.type == "friend" and a.name == trimmed then
            table.remove(FastFriends.actionQueue, i)
            removed = true
        else
            i = i + 1
        end
    end
    if FastFriends.pendingAction and FastFriends.pendingAction.type == "friend" and FastFriends.pendingAction.name == trimmed then
        FastFriends.pendingAction = nil
        FastFriends.pendingElapsed = 0
        removed = true
    end
    if removed then
        local suffix = ""
        if reason ~= nil and reason ~= "" then
            suffix = " ("..tostring(reason)..")"
        end
        FastFriends.SyncLog(string.format("Queue: dropped friend sync for '%s'%s", trimmed, suffix))
    end
    return removed
end

function FastFriends.HandleIgnoredFriends(ignoreList)
    if FastFriends.db == nil or FastFriends.db.friend == nil then return false end
    local list = ignoreList or {}
    local anyChange = false
    local friendList = FastFriends.db.friend
    if friendList._deleted == nil then
        friendList._deleted = {}
    end
    for name, on in pairs(list) do
        if on and name ~= FastFriends.myName and name ~= "_deleted" then
            local trimmed = tostring(name)
            local dropped = FastFriends.DropFriendActionsForName(trimmed, "ignored")
            if dropped then anyChange = true end
            local removedGlobal = false
            if friendList[trimmed] ~= nil then
                friendList[trimmed] = nil
                removedGlobal = true
            end
            if friendList._deleted[trimmed] ~= true then
                friendList._deleted[trimmed] = true
                anyChange = true
            end
            if removedGlobal then
                FastFriends.SyncLog("Global: removed '"..trimmed.."' from friend list (ignored)")
                anyChange = true
            end
            if FastFriends.db._meta and FastFriends.db._meta.friendNotePerChar then
                for _, map in pairs(FastFriends.db._meta.friendNotePerChar) do
                    if type(map) == "table" then
                        map[trimmed] = nil
                    end
                end
            end
            FastFriends.SetCharFriendSeq(trimmed, 0)
        end
    end
    if anyChange then
        if FastFriends.db._meta then
            FastFriends.db._meta.friendNoteDigest = ""
        end
        FastFriends.MarkLocalListDirty("friend")
        if FastFriends.syncActive and FastFriends.pendingAction == nil and #FastFriends.actionQueue == 0 then
            FastFriends.SyncFinish()
        end
    end
    return anyChange
end

-- Helper: detect an existing queued friend note entry for the friend.
function FastFriends.HasPendingFriendAction(name)
    if name == nil then return false end
    local target = tostring(name)
    if target == "" then return false end
    if FastFriends.pendingAction and FastFriends.pendingAction.type == "friend" and FastFriends.pendingAction.name == target then
        return true
    end
    for i = 1, #FastFriends.actionQueue do
        local a = FastFriends.actionQueue[i]
        if a and a.type == "friend" and a.name == target then
            return true
        end
    end
    return false
end

function FastFriends.HasQueuedFriendNoteAction(name)
    if name == nil then return false end
    local target = tostring(name)
    if target == "" then return false end
    if FastFriends.pendingAction and FastFriends.pendingAction.type == "friend" and FastFriends.pendingAction.op == "note" and FastFriends.pendingAction.name == target then
        return true
    end
    for i = 1, #FastFriends.actionQueue do
        local a = FastFriends.actionQueue[i]
        if a and a.type == "friend" and a.op == "note" and a.name == target then
            return true
        end
    end
    return false
end

function FastFriends.RetargetQueuedFriendNoteAction(oldName, newName, noteText)
    local source = tostring(oldName or "")
    local target = tostring(newName or "")
    if source == "" or target == "" or source == target then return false end

    local resolvedNote = FastFriends.NormalizeNoteText(noteText)
    if resolvedNote == "" then
        resolvedNote = FastFriends.GetGlobalFriendDescription(target)
    end

    local changed = false
    local targetQueued = FastFriends.HasQueuedFriendNoteAction(target)

    if FastFriends.pendingAction and FastFriends.pendingAction.type == "friend" and FastFriends.pendingAction.op == "note" and FastFriends.pendingAction.name == source then
        if targetQueued then
            FastFriends.pendingAction = nil
            FastFriends.pendingElapsed = 0
        else
            FastFriends.pendingAction.name = target
            FastFriends.pendingAction.renameCandidate = true
            FastFriends.pendingAction.renameTarget = target
            if resolvedNote ~= "" then
                FastFriends.pendingAction.desc = resolvedNote
            end
            targetQueued = true
        end
        changed = true
    end

    local i = 1
    while i <= #FastFriends.actionQueue do
        local a = FastFriends.actionQueue[i]
        if a and a.type == "friend" and a.op == "note" and a.name == source then
            if targetQueued then
                table.remove(FastFriends.actionQueue, i)
            else
                a.name = target
                a.renameCandidate = true
                a.renameTarget = target
                if resolvedNote ~= "" then
                    a.desc = resolvedNote
                end
                targetQueued = true
                i = i + 1
            end
            changed = true
        else
            i = i + 1
        end
    end

    if changed then
        FastFriends.SyncLog(string.format("Queue: moved note action from '%s' to '%s' during rename cleanup", source, target))
    end
    return changed
end

-- Helper: apply a queued note once the friend is visible locally.
function FastFriends.ProcessQueuedFriendNoteAction(action)
    if action == nil then return true end
    local name = tostring(action.name or "")
    if name == "" then return true end
    local noteSupport = FastFriends.CanSyncFriendNotes()
    local desc = action.desc
    if desc == nil then
        desc = FastFriends.GetGlobalFriendDescription(name)
    end
    local noteText = FastFriends.NormalizeNoteText(desc)
    if not noteSupport then
        FastFriends.SyncLog(string.format("Skipping note for '%s': note support disabled", name))
        return true
    end
    local globalList = FastFriends.db and FastFriends.db.friend
    if not globalList then
        FastFriends.SyncLog(string.format("Skipping note for '%s': no longer in global friend list", name))
        return true
    end
    if globalList._deleted and globalList._deleted[name] then
        FastFriends.SyncLog(string.format("Skipping note for '%s': no longer in global friend list", name))
        return true
    end
    if globalList[name] == nil then
        FastFriends.SyncLog(string.format("Skipping note for '%s': no longer in global friend list", name))
        return true
    end
    local localFriends = FastFriends.GetLocalNameList("friend")
    if not FastFriends.LocalListContains(localFriends, name) then
        FastFriends.DebugFriendNote("note-wait", name, "friend not yet present")
        return false
    end
    if action.renameCandidate == true then
        local localDesc = FastFriends.NormalizeDescription(localFriends[name])
        if localDesc ~= "" and localDesc ~= noteText then
            FastFriends.SyncLog(string.format("Skipping note for '%s': local note changed during rename cleanup", name))
            return true
        end
    end
    FastFriends.UpdateLocalFriendDescription(name, noteText)
    FastFriends.SyncLog(string.format("Synced: note for '%s' -> '%s'", name, noteText))
    if FastFriends.syncStats then
        FastFriends.syncStats.noteOk = (FastFriends.syncStats.noteOk or 0) + 1
    end
    local seq = FastFriends.GetGlobalFriendSeq(name)
    FastFriends.SetCharFriendSeq(name, seq)
    return true
end


function FastFriends.AddOrRemoveCharacter(name, slashCommand, op)
    FastFriends.Debug("FastFriends.AddOrRemoveCharacter(): "..tostring(slashCommand).."/"..tostring(op).." - "..name)

    local cmd = L""
    local wname = towstring(name)
    if slashCommand == "friend" then
        if op == "remove" then
            cmd = L"/friendremove "..wname
        else
            -- explicit add, mirror default UI behavior
            cmd = L"/friendadd "..wname
        end
    elseif slashCommand == "ignore" then
        -- Default UI uses /ignore <name> as a toggle for both add and remove
        cmd = L"/ignore "..wname
    else
        -- fallback, best-effort add as friend
        cmd = L"/friendadd "..wname
    end

    -- api can't add more than one character at a time, so they need to be spaced out.
    SendChatText(cmd, L"")

    if slashCommand == "friend" then
        FastFriends.MarkLocalListDirty("friend")
    elseif slashCommand == "ignore" then
        FastFriends.MarkLocalListDirty("ignore")
    else
        FastFriends.MarkLocalListDirty("friend")
    end
end


function FastFriends.AddToDeletedList(localList, listType)
    FastFriends.Debug("FastFriends.AddToDeletedList(): "..listType)
    if FastFriends.db == nil or FastFriends.db[listType] == nil then return end
    if localList == nil then localList = {} end
    if FastFriends.db[listType]._deleted == nil then
        FastFriends.db[listType]._deleted = {}
    end

    -- Collect first, then mutate: avoids table-walk edge cases in older runtimes.
    local removedNames = {}
    for name,_ in pairs(FastFriends.db[listType]) do
        if localList[name] == nil and name ~= "_deleted" and name ~= FastFriends.myName then
            removedNames[#removedNames + 1] = name
        end
    end
    for i = 1, #removedNames do
        local name = removedNames[i]
        FastFriends.db[listType][name] = nil
        FastFriends.db[listType]._deleted[name] = true
        FastFriends.SyncLog("Global: removed '"..name.."' from "..listType.." list")
    end
end

function FastFriends.ReplaceGlobalListWithLocal(localList, listType)
    if FastFriends.db == nil or FastFriends.db[listType] == nil then return end
    if localList == nil then localList = {} end

    local bucket = FastFriends.db[listType]
    if bucket._deleted == nil then
        bucket._deleted = {}
    end

    local removedNames = {}
    for name, _ in pairs(bucket) do
        if name ~= "_deleted" and name ~= FastFriends.myName and localList[name] == nil then
            removedNames[#removedNames + 1] = name
        end
    end
    for i = 1, #removedNames do
        local name = removedNames[i]
        bucket[name] = nil
        bucket._deleted[name] = true
        if listType == "friend" then
            FastFriends.SetCharFriendSeq(name, 0)
        end
        FastFriends.SyncLog("Global: removed '"..name.."' from "..listType.." list")
    end

    for name, entry in pairs(localList) do
        if name ~= "_deleted" and name ~= FastFriends.myName then
            if listType == "friend" then
                local existed = bucket[name] ~= nil
                local previousDesc = FastFriends.GetFriendDescriptionFromValue(bucket[name])
                local desc = FastFriends.NormalizeDescription(entry)
                FastFriends.SetGlobalFriendDescription(name, desc, tostring(FastFriends.myName or ""))
                FastFriends.EnsureGlobalPresence(listType, name, FastFriends.NormalizeGlobalFriendEntry(bucket, name))
                if not existed then
                    FastFriends.SyncLog("Global: added '"..name.."' to "..listType.." list")
                elseif previousDesc ~= desc then
                    FastFriends.SyncLogNoteChange("Global", name, desc, previousDesc)
                end
            else
                local existed = bucket[name] ~= nil
                bucket[name] = true
                bucket._deleted[name] = nil
                if not existed then
                    FastFriends.SyncLog("Global: added '"..name.."' to "..listType.." list")
                end
            end
        end
    end
end

function FastFriends.ApplyCurrentLocalListsAsGlobal()
    local friendEnabled = FastFriends.IsListEnabled("friend")
    local ignoreEnabled = FastFriends.IsListEnabled("ignore")
    local noteSupport = FastFriends.CanSyncFriendNotes()

    if friendEnabled then
        local localFriends = FastFriends.GetLocalNameList("friend")
        FastFriends.MarkListCountsReady("friend")
        FastFriends.ReplaceGlobalListWithLocal(localFriends, "friend")
        if noteSupport then
            FastFriends.db._meta.friendNoteDigest = FastFriends.ComputeFriendNoteDigest(localFriends)
        else
            FastFriends.db._meta.friendNoteDigest = ""
        end
    end

    if ignoreEnabled then
        local localIgnores = FastFriends.GetLocalNameList("ignore")
        FastFriends.MarkListCountsReady("ignore")
        FastFriends.ReplaceGlobalListWithLocal(localIgnores, "ignore")
    end

    FastFriends.actionQueue = {}
    FastFriends.pendingAction = nil
    FastFriends.pendingElapsed = 0
    FastFriends.syncActive = false
    FastFriends.rescanAfterSync = false
    FastFriends.ClearInitialDiffConfirmation()
    FastFriends.MarkAllLocalListsDirty()
    if not FastFriends.hasLoaded then
        FastFriends.hasLoaded = true
    end

    FastFriends.Print(towstring("Initial diff rejected. Current local lists are now the global lists for this server and faction."))
end


function FastFriends.MarkLocalListDirty(listType)
    if listType ~= "friend" and listType ~= "ignore" then return end
    if FastFriends.localListCache == nil then
        FastFriends.localListCache = { friend = nil, ignore = nil }
    end
    if FastFriends.localListCacheDirty == nil then
        FastFriends.localListCacheDirty = { friend = true, ignore = true }
    end
    FastFriends.localListCache[listType] = nil
    FastFriends.localListCacheDirty[listType] = true
end

function FastFriends.MarkAllLocalListsDirty()
    FastFriends.MarkLocalListDirty("friend")
    FastFriends.MarkLocalListDirty("ignore")
end

function FastFriends.CopyLocalListSnapshot(list)
    local copy = {}
    for name, entry in pairs(list or {}) do
        if type(entry) == "table" then
            local entryCopy = {}
            for k, v in pairs(entry) do
                entryCopy[k] = v
            end
            copy[name] = entryCopy
        else
            copy[name] = entry
        end
    end
    return copy
end

function FastFriends.RememberLocalListSnapshot(listType, list, allowEmpty)
    if listType ~= "friend" and listType ~= "ignore" then return end
    if FastFriends.localListSnapshot == nil then
        FastFriends.localListSnapshot = { friend = nil, ignore = nil }
    end
    local snapshot = list or {}
    if not allowEmpty and FastFriends.GetTableSize(snapshot) == 0 then
        return
    end
    FastFriends.localListSnapshot[listType] = FastFriends.CopyLocalListSnapshot(snapshot)
end

function FastFriends.GetRememberedLocalListSnapshot(listType)
    if listType ~= "friend" and listType ~= "ignore" then return nil end
    if FastFriends.localListSnapshot == nil then return nil end
    local snapshot = FastFriends.localListSnapshot[listType]
    if snapshot == nil then return nil end
    return FastFriends.CopyLocalListSnapshot(snapshot)
end

-- Guarantee a global entry exists and is not marked deleted
function FastFriends.EnsureGlobalPresence(listType, name, value)
    if FastFriends.db == nil or name == nil then return end
    local bucket = FastFriends.db[listType]
    if bucket == nil then return end
    if bucket[name] == nil then
        if value ~= nil then
            bucket[name] = value
        else
            bucket[name] = true
        end
    end
    if bucket._deleted ~= nil then
        bucket._deleted[name] = nil
    end
end

function FastFriends.CacheLocalList(listType, list)
    if listType ~= "friend" and listType ~= "ignore" then return end
    if FastFriends.localListCache == nil then
        FastFriends.localListCache = { friend = nil, ignore = nil }
    end
    if FastFriends.localListCacheDirty == nil then
        FastFriends.localListCacheDirty = { friend = true, ignore = true }
    end
    FastFriends.localListCache[listType] = list
    FastFriends.localListCacheDirty[listType] = false
end

function FastFriends.ConsumeCachedLocalList(listType)
    if listType ~= "friend" and listType ~= "ignore" then return nil end
    if FastFriends.localListCache == nil then return nil end
    local list = FastFriends.localListCache[listType]
    FastFriends.localListCache[listType] = nil
    if FastFriends.localListCacheDirty == nil then
        FastFriends.localListCacheDirty = { friend = true, ignore = true }
    end
    FastFriends.localListCacheDirty[listType] = true
    return list
end

function FastFriends.GetLocalNameList(listType)
    local localList = {}
    local serverList = {}
    local noteSupport = false

    if listType == "friend" then
        local fetchFriends = GetFriendsList
        serverList = fetchFriends and fetchFriends() or nil
        noteSupport = FastFriends.CanSyncFriendNotes()
        if noteSupport then
            FastFriends.localFriendWNames = {}
        else
            FastFriends.localFriendWNames = nil
        end
    elseif listType == "ignore" then
        local fetchIgnore = GetIgnoreList
        serverList = fetchIgnore and fetchIgnore() or nil
    end

    if type(serverList) ~= "table" then
        FastFriends.Debug("GetLocalNameList("..tostring(listType).."): source unavailable")
        return localList, false
    end

    ff_debugServerListSnapshot(listType, serverList)

    for _, character in pairs(serverList) do
        if character and character.name ~= nil then
            local trimmed = FastFriends.TrimName(character.name)
            if listType == "friend" then
                if not noteSupport then
                    localList[trimmed] = true
                else
                    local desc = FastFriends.GetLocalFriendDescription(character.name, true)
                    localList[trimmed] = { desc = desc, wname = character.name }
                    if FastFriends.localFriendWNames then
                        FastFriends.localFriendWNames[trimmed] = character.name
                    end
                end
            else
                localList[trimmed] = true
            end
        end
    end

    if next(localList) ~= nil then
        FastFriends.MarkListCountsReady(listType)
    end
    FastFriends.DebugListSnapshot("Local snapshot", listType, localList)
    FastFriends.RememberLocalListSnapshot(listType, localList, false)

    return localList, true
end

function FastFriends.GetShutdownLocalNameList(listType)
    local localList, available = FastFriends.GetLocalNameList(listType)
    if available then
        if FastFriends.GetTableSize(localList) == 0 then
            local snapshot = FastFriends.GetRememberedLocalListSnapshot(listType)
            if snapshot ~= nil and FastFriends.GetTableSize(snapshot) > 0 then
                FastFriends.Debug("GetShutdownLocalNameList("..tostring(listType).."): live list empty, using remembered snapshot")
                return snapshot, true
            end
        end
        return localList, true
    end

    local remembered = FastFriends.GetRememberedLocalListSnapshot(listType)
    if remembered ~= nil then
        FastFriends.Debug("GetShutdownLocalNameList("..tostring(listType).."): using remembered snapshot")
        return remembered, true
    end

    local cache = FastFriends.localListCache
    local cacheDirty = FastFriends.localListCacheDirty
    if cache ~= nil and cacheDirty ~= nil and cacheDirty[listType] == false and cache[listType] ~= nil then
        FastFriends.Debug("GetShutdownLocalNameList("..tostring(listType).."): using cached snapshot")
        return cache[listType], true
    end

    return nil, false
end

function FastFriends.GetLocalListCount(listType)
    if listType ~= "friend" and listType ~= "ignore" then return 0 end
    local source
    if listType == "friend" then
        local fetchFriends = GetFriendsList
        source = fetchFriends and fetchFriends() or nil
    else
        local fetchIgnore = GetIgnoreList
        source = fetchIgnore and fetchIgnore() or nil
    end
    if type(source) ~= "table" then return 0 end
    local count = 0
    for _, entry in pairs(source) do
        local name = entry and entry.name
        if name ~= nil then
            local trimmed = FastFriends.TrimName(name)
            if trimmed ~= FastFriends.myName then
                count = count + 1
            end
        else
            count = count + 1
        end
    end
    return count
end
--------------------------------------------------------------------------------


-- Friend description helpers ---------------------------------------------------
function FastFriends.SafeToWString(text)
    if towstring then
        return towstring(tostring(text or ""))
    end
    return tostring(text or "")
end

function FastFriends.ToPlainString(value)
    if value == nil then return "" end
    local t = type(value)
    if t == "wstring" then
        if WStringToString then
            return WStringToString(value)
        end
    end
    return tostring(value)
end

function FastFriends.NormalizeDescription(entry)
    if entry == nil then return "" end
    if type(entry) == "table" then
        if entry.desc ~= nil then return FastFriends.ToPlainString(entry.desc) end
        if entry.description ~= nil then return FastFriends.ToPlainString(entry.description) end
        if entry.note ~= nil then return FastFriends.ToPlainString(entry.note) end
    elseif type(entry) == "wstring" or type(entry) == "string" then
        return FastFriends.ToPlainString(entry)
    end
    return ""
end

function FastFriends.LocalListContains(localList, name)
    if localList == nil then return false end
    local v = localList[name]
    if v == nil then return false end
    if type(v) == "table" then return true end
    return v and true or false
end

function FastFriends.GetSocialWindowRealmKey()
    local realm = GameData and GameData.Player and GameData.Player.realm
    if realm == 1 then return "order" end
    if realm == 2 then return "destro" end
    return nil
end

function FastFriends.GetPlayerSavedName()
    if GameData and GameData.Player then
        local nm = GameData.Player.name
        if type(nm) == "wstring" then return nm end
        return FastFriends.SafeToWString(nm)
    end
    return nil
end

ff_ensure_realm_bucket = function(root, realmKey)
    if root[realmKey] == nil or type(root[realmKey]) ~= "table" then
        root[realmKey] = {}
    end
    local realmBucket = root[realmKey]
    if realmBucket.localFriends == nil or type(realmBucket.localFriends) ~= "table" then
        realmBucket.localFriends = {}
    end
    if realmBucket.accountFriends == nil then realmBucket.accountFriends = {} end
    if realmBucket.accountFriendsDel == nil then realmBucket.accountFriendsDel = {} end
    return realmBucket
end

ff_force_note_rescan = function(reason)
    if FastFriends.db and FastFriends.db._meta then
        FastFriends.db._meta.friendNoteDigest = ""
    end
    -- Mark dirty and run a scan immediately, bypassing the timer gate.
    FastFriends.noteScanElapsed = tonumber(FastFriends.noteScanIntervalSec or 1.0) or 1.0
    if FastFriends.isDebug then
        FastFriends.DebugFriendNote("note-rescan", FastFriends.myName or "?", tostring(reason or ""))
    end
    FastFriends.ScanLocalFriendNotes()
end

-- Debug helper: dump SocialWindow note fields for a given name
ff_debug_dump_friend_note = function(name)
    local nm = FastFriends.TrimName(name)
    if nm == "" then
        FastFriends.Print(towstring("Usage: /ff notepeek <Name>"))
        return
    end
    if not FastFriends.CanSyncFriendNotes() then
        FastFriends.Print(towstring("Notes unavailable: "..tostring(FastFriends.noteSupportReason or "unknown")))
        return
    end
    local root = FastFriends.EnsureSocialWindowRoot()
    local realmKey = FastFriends.GetSocialWindowRealmKey()
    local charKey = FastFriends.GetPlayerSavedName()
    if not (root and realmKey and charKey) then
        FastFriends.Print(towstring("Notes unavailable: missing realm or character"))
        return
    end
    local label = FastFriends.ToPlainString(charKey)
    local function dump_bucket(bucket, bucketLabel)
        if type(bucket) ~= "table" then
            FastFriends.Print(towstring(bucketLabel..": <none>"))
            return
        end
        local target = nil
        for k, v in pairs(bucket) do
            if type(k) == "wstring" or type(k) == "string" then
                if FastFriends.TrimName(k) == nm and type(v) == "table" then
                    target = v; break
                end
            end
        end
        if target == nil and bucket[nm] and type(bucket[nm]) == "table" then
            target = bucket[nm]
        end
        if target == nil then
            FastFriends.Print(towstring(bucketLabel..": <no entry>"))
            return
        end
        local desc = target.description or target.desc or target.note or ""
        local meta = getmetatable(target) or {}
        local flags = {}
        if meta.__ff_note_entry_watch then flags[#flags+1] = "entry-watch" end
        if meta.__newindex then flags[#flags+1] = "__newindex" end
        local flagText = (#flags > 0) and (" ["..table.concat(flags, ",").."]") or ""
        FastFriends.Print(towstring(string.format("%s: name=%s desc=%s%s", bucketLabel, tostring(target.name or ""), tostring(desc), flagText)))
        -- Show other fields for debugging (non-table values only)
        local parts = {}
        for k, v in pairs(target) do
            if type(v) ~= "table" then
                local val = tostring(v)
                if string.len(val) > 40 then val = string.sub(val, 1, 37).."..." end
                parts[#parts+1] = tostring(k).."="..val
            end
        end
        table.sort(parts)
        if #parts > 0 then
            FastFriends.Print(towstring("   fields: "..table.concat(parts, ", ")))
        end
    end

    local function dump_global(name)
        if not (FastFriends.db and FastFriends.db.friend) then
            FastFriends.Print(towstring("Global: <unavailable>"))
            return
        end
        local key = tostring(name)
        local entry = FastFriends.db.friend[key]
        if entry == nil then
            FastFriends.Print(towstring("Global: <no entry>"))
            return
        end
        local desc = FastFriends.GetFriendDescriptionFromValue(entry)
        FastFriends.Print(towstring(string.format("Global: desc=%s", tostring(desc))))
    end

    local realm = root[realmKey]
    if not realm then
        FastFriends.Print(towstring("Notes unavailable: realm bucket missing"))
        return
    end
    local charBucket = nil
    if realm.localFriends then
        charBucket = realm.localFriends[charKey]
    end
    dump_bucket(charBucket, "Local".."("..label..")")
    if realm.accountFriends then
        dump_bucket(realm.accountFriends, "Account")
    end

    dump_global(nm)
end

function FastFriends.EnsureSocialWindowRoot()
    if SocialWindowTabFriends == nil or type(SocialWindowTabFriends) ~= "table" then
        SocialWindowTabFriends = {}
    end
    local sw = SocialWindowTabFriends
    if sw.AddvancedFriends == nil or type(sw.AddvancedFriends) ~= "table" then
        sw.AddvancedFriends = {}
    end
    local root = sw.AddvancedFriends
    ff_ensure_realm_bucket(root, "order")
    ff_ensure_realm_bucket(root, "destro")
    return root
end

function FastFriends.AbbrevDesc(desc)
    local s = FastFriends.ToPlainString(desc)
    if string.len(s) > 60 then
        s = string.sub(s, 1, 57).."..."
    end
    return s
end

local function ff_trim(s)
    return (string.gsub(string.gsub(s, "^%s+", ""), "%s+$", ""))
end

function FastFriends.NormalizeNoteText(text)
    local s = FastFriends.ToPlainString(text)
    s = ff_trim(s)
    return s
end

-- Compute a compact digest for friend notes.
-- Notes can be large across many characters; a numeric hash keeps SavedVariables small
-- and avoids string-length quirks in the game client while still detecting changes.
function FastFriends.ComputeFriendNoteDigest(localList)
    if not FastFriends.CanSyncFriendNotes() then return "" end
    -- Sort + checksum: lightweight, order-insensitive, good enough to spot edits.
    local entries = {}
    for name, info in pairs(localList) do
        if name ~= FastFriends.myName then
            local desc = FastFriends.NormalizeDescription(info)
            if desc ~= "" then
                entries[#entries + 1] = tostring(name).."\0"..desc
            end
        end
    end
    table.sort(entries)
    local concat = table.concat(entries, "\1")
    local sum = 0
    for i = 1, #concat do
        sum = sum + string.byte(concat, i)
    end
    return tostring(sum)..":"..tostring(#concat)
end

function FastFriends.DebugFriendNote(context, name, detail)
    if not FastFriends.isDebug then return end
    local n = FastFriends.ToPlainString(name)
    local msg = string.format("Reconcile(): friend note [%s] %s %s", tostring(context or "?"), n, tostring(detail or ""))
    FastFriends.Debug(msg)
end

-- Helper: treat nil or empty strings as "no note" when logging changes.
local function ff_has_note_text(text)
    if text == nil then return false end
    if text == "" then return false end
    return true
end

-- SyncLog wrapper that trims inputs and suppresses no-op note updates.
function FastFriends.SyncLogNoteChange(scope, name, newDesc, previousDesc)
    if not FastFriends.CanSyncFriendNotes() then return end
    local newText = FastFriends.NormalizeNoteText(newDesc)
    local oldText = FastFriends.NormalizeNoteText(previousDesc)
    if newText == "" then
        if ff_has_note_text(oldText) then
            FastFriends.SyncLog(string.format("%s: removed note for '%s'", scope, name))
        end
        return
    end
    FastFriends.SyncLog(string.format("%s: updated note for '%s' -> '%s'", scope, name, newText))
end

function FastFriends.GetLocalFriendDescription(wname, noteSupport)
    if noteSupport == false then return "" end
    if noteSupport ~= true then
        if not FastFriends.CanSyncFriendNotes() then return "" end
    end
    if wname == nil then return "" end
    local root = FastFriends.EnsureSocialWindowRoot()
    local realmKey = FastFriends.GetSocialWindowRealmKey()
    if not realmKey then return "" end
    local realmBucket = ff_ensure_realm_bucket(root, realmKey)
    local charKey = FastFriends.GetPlayerSavedName()
    if not charKey then return "" end
    local charBucket = realmBucket.localFriends[charKey]
    if charBucket == nil then return "" end
    local entry = charBucket[wname]
    if entry == nil then
        local target = FastFriends.TrimName(wname)
        for key, data in pairs(charBucket) do
            if type(data) == "table" then
                if FastFriends.TrimName(key) == target then
                    entry = data
                    break
                end
            end
        end
    end
    if entry and type(entry) == "table" then
        if entry.description ~= nil then return FastFriends.NormalizeNoteText(entry.description) end
        if entry.desc ~= nil then return FastFriends.NormalizeNoteText(entry.desc) end
        if entry.note ~= nil then return FastFriends.NormalizeNoteText(entry.note) end
    end
    return ""
end

function FastFriends.ResolveFriendWName(name)
    if FastFriends.localFriendWNames and FastFriends.localFriendWNames[name] ~= nil then
        return FastFriends.localFriendWNames[name]
    end
    local fetchFriends = GetFriendsList
    local list = fetchFriends and fetchFriends() or nil
    if type(list) ~= "table" then
        return FastFriends.SafeToWString(name)
    end
    for _, character in pairs(list) do
        if character and character.name ~= nil then
            local trimmed = FastFriends.TrimName(character.name)
            if trimmed == name then
                if FastFriends.localFriendWNames == nil then FastFriends.localFriendWNames = {} end
                FastFriends.localFriendWNames[name] = character.name
                return character.name
            end
        end
    end
    return FastFriends.SafeToWString(name)
end

function FastFriends.UpdateLocalFriendDescription(name, desc)
    if not FastFriends.CanSyncFriendNotes() then return end
    if not name then return end
    local root = FastFriends.EnsureSocialWindowRoot()
    local realmKey = FastFriends.GetSocialWindowRealmKey()
    if not realmKey then return end
    local realmBucket = ff_ensure_realm_bucket(root, realmKey)
    local charKey = FastFriends.GetPlayerSavedName()
    if not charKey then return end
    if realmBucket.localFriends[charKey] == nil then
        realmBucket.localFriends[charKey] = {}
    end
    local charBucket = realmBucket.localFriends[charKey]
    local wname = FastFriends.ResolveFriendWName(name)
    if not wname then return end
    local entry = charBucket[wname]
    if entry == nil or type(entry) ~= "table" then
        entry = { name = wname, description = FastFriends.SafeToWString("") }
        charBucket[wname] = entry
    end
    entry.name = wname
    local previous = FastFriends.NormalizeNoteText(entry.description)
    local nextDesc = FastFriends.NormalizeNoteText(desc)
    if previous ~= nextDesc then
        entry.description = FastFriends.SafeToWString(nextDesc)
        FastFriends.DebugFriendNote("local-store", name, "set desc='"..FastFriends.AbbrevDesc(nextDesc).."'")
    else
        entry.description = FastFriends.SafeToWString(nextDesc)
    end
    if FastFriends.localFriendWNames then
        FastFriends.localFriendWNames[name] = wname
    end
    FastFriends.MarkLocalListDirty("friend")
end

function FastFriends.NormalizeGlobalFriendEntry(globalList, name)
    if globalList == nil then return nil end
    local entry = globalList[name]
    if entry == nil then return nil end
    if type(entry) ~= "table" then
        local desc = ""
        if entry ~= true then
            desc = FastFriends.ToPlainString(entry)
        end
        entry = { desc = desc }
        globalList[name] = entry
        return entry
    end
    if entry.desc == nil and entry.description ~= nil then
        entry.desc = FastFriends.ToPlainString(entry.description)
        entry.description = nil
    end
    if entry.desc == nil then entry.desc = "" end
    entry.seq = tonumber(entry.seq or 0) or 0
    return entry
end

function FastFriends.SetGlobalFriendDescription(name, desc, sourceChar)
    if FastFriends.db == nil or FastFriends.db.friend == nil then return end
    local globalList = FastFriends.db.friend
    local entry = FastFriends.NormalizeGlobalFriendEntry(globalList, name)
    local plain = FastFriends.NormalizeNoteText(desc)
    local appliedSeq = nil
    if entry == nil then
        local seq = FastFriends.NextFriendSeq()
        globalList[name] = { desc = plain, seq = seq }
        entry = globalList[name]
        appliedSeq = seq
    else
        if entry.desc ~= plain then
            local seq = FastFriends.NextFriendSeq()
            entry.desc = plain
            entry.seq = seq
            appliedSeq = seq
        else
            if entry.seq == nil then entry.seq = tonumber(FastFriends.db._meta.friendNoteSeq or 0) or 0 end
            appliedSeq = entry.seq
        end
    end
    local charName = sourceChar
    if charName == nil or charName == "" then
        charName = tostring(FastFriends.myName or "")
    end
    if charName ~= nil and charName ~= "" then
        FastFriends.SetFriendSeqForChar(charName, name, appliedSeq or FastFriends.GetFriendSeqFromValue(entry))
    end
end

function FastFriends.GetFriendSeqFromValue(entry)
    if entry and type(entry) == "table" then
        return tonumber(entry.seq or 0) or 0
    end
    return 0
end

function FastFriends.GetGlobalFriendSeq(name)
    if FastFriends.db == nil or FastFriends.db.friend == nil then return 0 end
    local entry = FastFriends.NormalizeGlobalFriendEntry(FastFriends.db.friend, name)
    return FastFriends.GetFriendSeqFromValue(entry)
end

function FastFriends.NextFriendSeq()
    if FastFriends.db == nil or FastFriends.db._meta == nil then return 0 end
    local meta = FastFriends.db._meta
    local current = tonumber(meta.friendNoteSeq or 0) or 0
    current = current + 1
    meta.friendNoteSeq = current
    return current
end

function FastFriends.SetFriendSeqForChar(charName, friendName, seq)
    if FastFriends.db == nil or FastFriends.db._meta == nil then return end
    if charName == nil or charName == "" then return end
    friendName = tostring(friendName or "")
    local meta = FastFriends.db._meta
    if meta.friendNotePerChar == nil then meta.friendNotePerChar = {} end
    local perChar = meta.friendNotePerChar
    if perChar[charName] == nil then perChar[charName] = {} end
    perChar[charName][friendName] = tonumber(seq or 0) or 0
end

function FastFriends.GetFriendSeqForChar(charName, friendName)
    if FastFriends.db == nil or FastFriends.db._meta == nil then return 0 end
    local perChar = FastFriends.db._meta.friendNotePerChar
    if perChar == nil then return 0 end
    local charMap = perChar[charName]
    if charMap == nil then return 0 end
    return tonumber(charMap[friendName] or 0) or 0
end

function FastFriends.GetCharFriendSeq(friendName)
    local charName = tostring(FastFriends.myName or "")
    if charName == "" then return 0 end
    return FastFriends.GetFriendSeqForChar(charName, friendName)
end

function FastFriends.SetCharFriendSeq(friendName, seq)
    local charName = tostring(FastFriends.myName or "")
    if charName == "" then return end
    FastFriends.SetFriendSeqForChar(charName, friendName, seq)
end

function FastFriends.GetFriendNoteStats()
    if not FastFriends.CanSyncFriendNotes() then return 0, 0 end
    if FastFriends.db == nil or FastFriends.db.friend == nil then return 0, 0 end
    local total, noted = 0, 0
    for name, entry in pairs(FastFriends.db.friend) do
        if name ~= "_deleted" then
            total = total + 1
            if FastFriends.GetFriendDescriptionFromValue(entry) ~= "" then
                noted = noted + 1
            end
        end
    end
    return total, noted
end

-- Lightweight helper to reuse delta-time fallbacks without repeated lookups
function FastFriends.ResolveDelta(timePassed)
    local delta = tonumber(timePassed)
    if not delta or delta <= 0 then
        local sys = _G.SystemData
        if sys then
            if type(sys.FrameTime) == "number" then
                delta = sys.FrameTime
            elseif sys.DeltaTime ~= nil then
                delta = tonumber(sys.DeltaTime) or 0
            elseif sys.TimeSinceLastFrame ~= nil then
                delta = tonumber(sys.TimeSinceLastFrame) or 0
            end
        end
        if not delta or delta < 0 then delta = 0 end
    end
    if delta > 1 then delta = 1 end
    return delta
end

-- Gatekeeper for friend-note scanning so we skip work early when impossible
function FastFriends.ShouldScanNotes()
    if not FastFriends.hasLoaded then return false end
    if not FastFriends.loginMsgShown then return false end
    if FastFriends.initReconcilePending then return false end
    if FastFriends.HasPendingInitialDiffConfirmation() then return false end
    if FastFriends.syncActive then return false end
    if not FastFriends.IsListEnabled("friend") then return false end
    if not FastFriends.CanSyncFriendNotes() then return false end
    return true
end

function FastFriends.NoteScanOnUpdate(dt)
    if not FastFriends.ShouldScanNotes() then return end
    local delta = FastFriends.ResolveDelta(dt)
    -- If a watcher flagged a recent note edit, fast-forward the interval.
    local interval = tonumber(FastFriends.noteScanIntervalSec or 1.0) or 1.0
    if interval <= 0 then interval = 1.0 end
    FastFriends.noteScanElapsed = (FastFriends.noteScanElapsed or 0) + delta
    if FastFriends.noteScanElapsed < interval then return end
    FastFriends.noteScanElapsed = 0
    FastFriends.ScanLocalFriendNotes()
end

function FastFriends.ScanLocalFriendNotes(localFriends)
    if not FastFriends.CanSyncFriendNotes() then return end
    if FastFriends.db == nil or FastFriends.db.friend == nil then return end
    if FastFriends.HasPendingInitialDiffConfirmation() then return end
    local canSync = FastFriends.ShouldSync()
    if not canSync then return end
    local localFriendsList = localFriends
    if localFriendsList == nil then
        localFriendsList = FastFriends.GetLocalNameList("friend")
    end
    local globalFriends = FastFriends.db.friend
    -- Do not act when the local list is empty (common right after login); prevents digest churn on incomplete data.
    if FastFriends.GetTableSize(localFriendsList) == 0 then return end
    local digest = FastFriends.ComputeFriendNoteDigest(localFriendsList)
    if FastFriends.db._meta.friendNoteDigest == digest then return end
    if FastFriends.isDebug then
        FastFriends.Debug(string.format("FastFriends.Reconcile(): friend notes changed (old=%s new=%s)", tostring(FastFriends.db._meta.friendNoteDigest), tostring(digest)))
    end
    FastFriends.db._meta.friendNoteDigest = digest
    FastFriends.Reconcile(localFriendsList, FastFriends.db.friend, "friend")
    if #FastFriends.actionQueue > 0 and not FastFriends.syncActive then
        FastFriends.SyncBegin()
    end
end

function FastFriends.GetFriendDescriptionFromValue(entry)
    if entry == nil then return "" end
    if type(entry) == "table" then
        if entry.desc ~= nil then return FastFriends.NormalizeNoteText(entry.desc) end
        if entry.description ~= nil then return FastFriends.NormalizeNoteText(entry.description) end
    elseif entry ~= true then
        return FastFriends.NormalizeNoteText(entry)
    end
    return ""
end

function FastFriends.GetGlobalFriendDescription(name)
    if FastFriends.db == nil or FastFriends.db.friend == nil then return "" end
    local entry = FastFriends.NormalizeGlobalFriendEntry(FastFriends.db.friend, name)
    if entry and entry.desc ~= nil then
        return FastFriends.ToPlainString(entry.desc)
    end
    return ""
end

function FastFriends.MigrateFriendRecords()
    if FastFriends.db == nil or FastFriends.db.friend == nil then return end
    local friendList = FastFriends.db.friend
    for name, value in pairs(friendList) do
        if name ~= "_deleted" then
            if type(value) ~= "table" then
                if value == nil then
                    friendList[name] = nil
                else
                    local desc = ""
                    if value ~= true then desc = FastFriends.ToPlainString(value) end
                    friendList[name] = { desc = desc, seq = 0 }
                end
            else
                if value.desc == nil and value.description ~= nil then
                    value.desc = FastFriends.ToPlainString(value.description)
                    value.description = nil
                end
                if value.desc == nil then value.desc = "" end
                value.seq = tonumber(value.seq or 0) or 0
            end
        end
    end
end



-- UTILITY METHODS -------------------------------------------------------------
function FastFriends.Print(text)
    -- Print to Chat log without forcing a grey filter; tag is colored via <LINK> markup
    TextLogAddEntry("Chat", 0, FastFriends.GetTag()..text)
end

function FastFriends.Debug(object)
    if not FastFriends.isDebug then return end
    if object == nil then
        FastFriends.Print(L"Debug: nil")
        return
    end
    local t = type(object)
    -- If already a wstring, print as-is; otherwise stringify and convert
    if t == "wstring" then
        FastFriends.Print(object)
    else
        FastFriends.Print(towstring(tostring(object)))
    end
end

ff_debugSortedNamesFromMap = function(map)
    if map == nil then return {} end
    local names = {}
    for name, _ in pairs(map) do
        if name ~= "_deleted" then
            names[#names + 1] = tostring(name)
        end
    end
    table.sort(names, function(a, b)
        return string.lower(a) < string.lower(b)
    end)
    return names
end

ff_debugPreview = function(names, limit)
    local count = #names
    local maxItems = limit or 12
    local previewCount = count
    if maxItems > 0 and previewCount > maxItems then
        previewCount = maxItems
    end
    local entries = {}
    for i = 1, previewCount do
        entries[i] = names[i]
    end
    local suffix = ""
    if count > previewCount then
        suffix = string.format(" (+%d more)", count - previewCount)
    end
    return entries, suffix
end

ff_debugServerListSnapshot = function(listType, serverList)
    if not FastFriends.isDebug then return end
    if not FastFriends.debugListSnapshots then return end
    local names = {}
    for _, entry in pairs(serverList or {}) do
        local raw = FastFriends.ToPlainString(entry and entry.name)
        local trimmed = FastFriends.TrimName(entry and entry.name)
        local label = trimmed
        if raw ~= trimmed then
            label = raw.." -> "..trimmed
        end
        names[#names + 1] = label
    end
    table.sort(names, function(a, b)
        return string.lower(a) < string.lower(b)
    end)
    local preview, suffix = ff_debugPreview(names, 12)
    FastFriends.Debug(string.format("Server %s list count=%d%s", listType, #names, suffix))
    if #preview > 0 then
        FastFriends.Debug("    "..table.concat(preview, ", "))
    end
end

function FastFriends.DebugListSnapshot(context, listType, list)
    if not FastFriends.isDebug then return end
    if not FastFriends.debugListSnapshots then return end
    local count = FastFriends.GetTableSize(list or {})
    if count > 20 then
        FastFriends.Debug(string.format("%s %s count=%d (suppressed)", context, listType, count))
        return
    end
    local names = ff_debugSortedNamesFromMap(list or {})
    local preview, suffix = ff_debugPreview(names, 12)
    FastFriends.Debug(string.format("%s %s count=%d%s", context, listType, #names, suffix))
    if #preview > 0 then
        FastFriends.Debug("    "..table.concat(preview, ", "))
    end
end

function FastFriends.DebugDeletedSnapshot(context, deleted)
    if not FastFriends.isDebug then return end
    if not FastFriends.debugListSnapshots then return end
    local names = ff_debugSortedNamesFromMap(deleted or {})
    if #names == 0 then
        FastFriends.Debug(context.." _deleted empty")
        return
    end
    local preview, suffix = ff_debugPreview(names, 12)
    FastFriends.Debug(string.format("%s _deleted count=%d%s", context, #names, suffix))
    FastFriends.Debug("    "..table.concat(preview, ", "))
end

function FastFriends.DebugListDiff(context, listType, localList, globalList)
    if not FastFriends.isDebug then return end
    if not FastFriends.debugListSnapshots then return end
    local missingInGlobal = {}
    if localList then
        for name, _ in pairs(localList) do
            if name ~= "_deleted" and name ~= FastFriends.myName then
                if globalList == nil or globalList[name] == nil then
                    missingInGlobal[#missingInGlobal + 1] = tostring(name)
                end
            end
        end
    end
    local missingInLocal = {}
    if globalList then
        for name, _ in pairs(globalList) do
            if name ~= "_deleted" and name ~= FastFriends.myName then
                if localList == nil or localList[name] == nil then
                    missingInLocal[#missingInLocal + 1] = tostring(name)
                end
            end
        end
    end
    table.sort(missingInGlobal, function(a, b)
        return string.lower(a) < string.lower(b)
    end)
    table.sort(missingInLocal, function(a, b)
        return string.lower(a) < string.lower(b)
    end)
    if #missingInGlobal == 0 then
        FastFriends.Debug(string.format("%s %s diff missingInGlobal: none", context, listType))
    else
        FastFriends.Debug(string.format("%s %s diff missingInGlobal (%d): %s", context, listType, #missingInGlobal, table.concat(missingInGlobal, ", ")))
    end
    if #missingInLocal == 0 then
        FastFriends.Debug(string.format("%s %s diff missingInLocal: none", context, listType))
    else
        FastFriends.Debug(string.format("%s %s diff missingInLocal (%d): %s", context, listType, #missingInLocal, table.concat(missingInLocal, ", ")))
    end
end

-- Color helpers ---------------------------------------------------------------
function FastFriends.ColorGrey(desc)
    local s = tostring(desc or "")
    local link = "<LINK data=\"\" text=\""..s.."\" color=\"160,160,160\">"
    return towstring(link)
end

-- Grey all text except specific tokens left in default color
function FastFriends.ColorGreyExceptTokens(desc, tokens)
    local s = tostring(desc or "")
    local out = L""
    local len = string.len(s)
    local idx = 1
    while idx <= len do
        -- Find nearest token occurrence at or after idx
        local tokI, tokJ, tokStr
        for _, tok in ipairs(tokens or {}) do
            local i, j = string.find(s, tok, idx, true)
            if i and (not tokI or i < tokI) then tokI, tokJ, tokStr = i, j, tok end
        end
        -- Find next digit run start
        local numI
        do
            local k = idx
            while k <= len do
                local ch = string.sub(s, k, k)
                if ch >= '0' and ch <= '9' then numI = k; break end
                k = k + 1
            end
        end
        local nextI, nextType
        if tokI and (not numI or tokI < numI) then
            nextI, nextType = tokI, 'token'
        else
            nextI, nextType = numI, 'number'
        end
        if not nextI then
            local tail = string.sub(s, idx)
            if tail ~= "" then out = out..FastFriends.ColorGrey(tail) end
            break
        end
        if nextI > idx then
            out = out..FastFriends.ColorGrey(string.sub(s, idx, nextI - 1))
        end
        if nextType == 'token' then
            out = out..towstring(tokStr)
            idx = tokJ + 1
        else
            -- number run
            local j = nextI
            while j <= len do
                local ch = string.sub(s, j, j)
                if not (ch >= '0' and ch <= '9') then break end
                j = j + 1
            end
            out = out..towstring(string.sub(s, nextI, j - 1))
            idx = j
        end
    end
    return out
end

function FastFriends.ColorGreyExcept(desc)
    return FastFriends.ColorGreyExceptTokens(desc, { "custom", "ON", "ENABLED", "SYNCING" })
end

-- Settings helpers ------------------------------------------------------------
function FastFriends.IsListEnabled(listType)
    if listType == "friend" then return FastFriends.listFriends and true or false end
    if listType == "ignore" then return FastFriends.listIgnore and true or false end
    return false
end

function FastFriends.SetSetting(key, value, defaultValue)
    if not (FastFriendsDB and FastFriendsDB._settings) then return end
    if value == defaultValue then
        FastFriendsDB._settings[key] = nil
    else
        FastFriendsDB._settings[key] = value
    end
end

function FastFriends.GetCharOverride()
    -- Back-compat: prefer legacy global mirror by character name (server+faction scoped)
    if FastFriends.db and FastFriends.db._meta and FastFriends.db._meta.charOverrides then
        local v = FastFriends.db._meta.charOverrides[FastFriends.myName]
        if v == true then return true end
        if v == false then return false end
    end
    -- Per-character storage (survives renames)
    if FastFriendsCharDB and (FastFriendsCharDB.override == true or FastFriendsCharDB.override == false) then
        return (FastFriendsCharDB.override and true or false)
    end
    return nil
end

-- Returns: boolean canSync, string reason
function FastFriends.ShouldSync()
    -- Master switch first
    if not (FastFriends.syncMaster and true or false) then
        return false, "Sync is disabled because Master Sync is OFF."
    end

    -- Character override (final say)
    local over = FastFriends.GetCharOverride()
    if over ~= nil then
        if over == true then return true, "Sync is enabled by a character override." end
        return false, "Sync is disabled by a character override."
    end

    -- Global mode
    local mode = string.lower(tostring(FastFriends.syncMode or "level"))
    if mode == "all" then
        return true, "Sync is enabled by global mode 'all'."
    elseif mode == "opt-in" or mode == "optin" then
        return false, "Sync requires a character override (global mode 'opt-in')."
    end
    -- mode == level (gates by minimum level)
    local lvl = tonumber(GameData.Player.level or 0) or 0
    local minL = tonumber(FastFriends.minLevel or 16) or 16
    if lvl >= minL then
        return true, string.format("Level mode is active: your level %d meets the minimum %d.", lvl, minL)
    else
        return false, string.format("Level mode is active: your level %d is below the minimum %d.", lvl, minL)
    end
end

-- Compute effective sync without considering the character override
function FastFriends.DefaultSyncForChar()
    if not (FastFriends.syncMaster and true or false) then return false end
    local mode = string.lower(tostring(FastFriends.syncMode or "level"))
    if mode == "all" then return true end
    if mode == "opt-in" or mode == "optin" then return false end
    local lvl = tonumber(GameData.Player.level or 0) or 0
    local minL = tonumber(FastFriends.minLevel or 16) or 16
    return lvl >= minL
end

function FastFriends.SyncAbort(reason)
    if FastFriends.syncActive then
        local r = tostring(reason or "aborted")
        FastFriends.Print(towstring("Sync aborted: "..r))
    end
    FastFriends.syncActive = false
    FastFriends.pendingAction = nil
    FastFriends.pendingElapsed = 0
    FastFriends.rescanAfterSync = false
    FastFriends.syncStats = nil
    -- Clear queue to avoid stale operations
    FastFriends.actionQueue = {}
    FastFriends.MarkAllLocalListsDirty()
end

function FastFriends.MaybePrintLoginMessage(markShown, countsOnly)
    local countsOnlyMode = countsOnly and true or false
    local can, reason = FastFriends.ShouldSync()
    local name = tostring(FastFriends.myName or "?")
    local fOn = FastFriends.listFriends and true or false
    local iOn = FastFriends.listIgnore and true or false
    local function ff_listcounts_friend_part(count, cap)
        local part = string.format("F=%d/%d", count, cap)
        if FastFriends.CanSyncFriendNotes() then
            local _, noted = FastFriends.GetFriendNoteStats()
            part = part.." "..string.format("(notes=%d)", noted)
        end
        return part
    end
    local function buildListInfo()
        local friendCap = FastFriends.GetListCap("friend") or 0
        local ignoreCap = FastFriends.GetListCap("ignore") or 0
        local confirmState = FastFriends.loginMsgConfirmState
        if confirmState ~= nil then
            if confirmState.status == "pending" then
                return "", {
                    friend = confirmState.friendEnabled and true or false,
                    ignore = confirmState.ignoreEnabled and true or false
                }
            elseif confirmState.status == "ready" then
                local parts = {}
                if confirmState.friendEnabled and confirmState.confirmFriendCount ~= nil then
                    parts[#parts + 1] = ff_listcounts_friend_part(confirmState.confirmFriendCount, friendCap)
                end
                if confirmState.ignoreEnabled and confirmState.confirmIgnoreCount ~= nil then
                    parts[#parts + 1] = string.format("I=%d/%d", confirmState.confirmIgnoreCount, ignoreCap)
                end
                FastFriends.loginMsgConfirmState = nil
                if #parts == 0 then
                    return "", { friend = false, ignore = false }
                end
                return string.format("%s listcounts are %s.", name, table.concat(parts, ", ")), { friend = false, ignore = false }
            end
        end

        local counts = ff_collect_login_counts(fOn, iOn)
        if counts.pending.friend or counts.pending.ignore then
            return "", counts.pending
        end
        if counts.friendCount == nil and counts.ignoreCount == nil then
            return "", counts.pending
        end

        local state = FastFriends.BeginLoginMsgConfirm(fOn, iOn, counts)
        local pending = {
            friend = state.friendEnabled and true or false,
            ignore = state.ignoreEnabled and true or false
        }
        return "", pending
    end
    local listInfo, pendingCounts = buildListInfo()
    local confirmState = FastFriends.loginMsgConfirmState
    if confirmState and confirmState.status == "pending" and confirmState.source == nil then
        if markShown then
            confirmState.source = "auto"
        else
            confirmState.source = "manual"
        end
    end
    pendingCounts = pendingCounts or { friend = false, ignore = false }
    if countsOnlyMode then
        if listInfo ~= "" then
            FastFriends.Print(towstring(listInfo))
        end
        return
    end
    if markShown then
        if fOn then
            ff_update_loginmsg_pending("friend", pendingCounts.friend)
        else
            ff_update_loginmsg_pending("friend", false)
        end
        if iOn then
            ff_update_loginmsg_pending("ignore", pendingCounts.ignore)
        else
            ff_update_loginmsg_pending("ignore", false)
        end
        if FastFriends.loginMsgCountsPending then
            FastFriends.CheckLoginMessageFollowup()
        end
    end
    if can then
        if fOn and iOn then
            FastFriends.Print(towstring(string.format("Syncing is enabled for %s. FriendList and IgnoreList are syncing with other synced characters.", name)))
        elseif fOn and not iOn then
            FastFriends.Print(towstring(string.format("Syncing is enabled for %s. FriendList is syncing with other synced characters; IgnoreList is disabled.", name)))
        elseif (not fOn) and iOn then
            FastFriends.Print(towstring(string.format("Syncing is enabled for %s. IgnoreList is syncing with other synced characters; FriendList is disabled.", name)))
        else
            FastFriends.Print(towstring(string.format("Syncing is enabled for %s, but both FriendList and IgnoreList are disabled.", name)))
        end
        if listInfo ~= "" then
            FastFriends.Print(towstring(string.format("Why: %s %s", reason, listInfo)))
        else
            FastFriends.Print(towstring("Why: "..reason))
        end
    else
        if listInfo ~= "" then
            FastFriends.Print(towstring(string.format("Syncing is disabled for %s.", name)))
            FastFriends.Print(towstring(string.format("Why: %s %s", reason, listInfo)))
        else
            FastFriends.Print(towstring(string.format("Syncing is disabled for %s.", name)))
            FastFriends.Print(towstring("Why: "..reason))
        end
    end
    -- Only mark as shown when called from our auto path (not via slash cmd)
    if markShown then FastFriends.loginMsgShown = true end
end

function FastFriends.ProcessLoginMsgConfirm(timePassed)
    local state = FastFriends.loginMsgConfirmState
    if state == nil or state.status ~= "pending" then return end

    state.waitFrames = (state.waitFrames or 0) + 1
    local required = FastFriends.loginMsgConfirmWaitFrames or 1
    if state.waitFrames <= required then return end

    local counts = ff_collect_login_counts(state.friendEnabled, state.ignoreEnabled)
    if counts.pending.friend or counts.pending.ignore then
        state.friendCount = counts.friendCount
        state.ignoreCount = counts.ignoreCount
        state.waitFrames = 0
        return
    end

    if state.friendEnabled and counts.friendCount == nil then
        state.waitFrames = 0
        return
    end
    if state.ignoreEnabled and counts.ignoreCount == nil then
        state.waitFrames = 0
        return
    end

    local friendMatches = (not state.friendEnabled) or (counts.friendCount == state.friendCount)
    local ignoreMatches = (not state.ignoreEnabled) or (counts.ignoreCount == state.ignoreCount)

    if friendMatches and ignoreMatches then
        state.status = "ready"
        state.confirmFriendCount = counts.friendCount
        state.confirmIgnoreCount = counts.ignoreCount
        state.waitFrames = 0
        FastFriends.loginMsgConfirmState = state

        if state.source == "auto" then
            FastFriends.CheckLoginMessageFollowup()
        else
            FastFriends.MaybePrintLoginMessage(false, true)
            if FastFriends.loginMsgConfirmState == state then
                FastFriends.loginMsgConfirmState = nil
            end
        end
        return
    end

    state.friendCount = counts.friendCount
    state.ignoreCount = counts.ignoreCount
    state.waitFrames = 0
end

function FastFriends.TrimName(text)
    -- Safely remove the localization suffix "^M" or "^F" when present
    local s
    local tt = type(text)
    if tt == "wstring" then
        s = WStringToString(text)
    else
        s = tostring(text or "")
    end
    local len = string.len(s)
    if len >= 2 then
        local tail = string.sub(s, len - 1, len)
        if tail == "^M" or tail == "^F" then
            return string.sub(s, 1, len - 2)
        end
    end
    return s
end

-- Capitalize only the first character; leave the rest unchanged
function FastFriends.CapitalizeFirst(text)
    local s = tostring(text or "")
    if s == "" then return s end
    local first = string.sub(s, 1, 1)
    local rest = string.sub(s, 2)
    return string.upper(first)..rest
end

function FastFriends.GetTableSize(tbl)
    local size = 0

    for name,_ in pairs(tbl) do
        if name ~= "_deleted" and name ~= FastFriends.myName then
            size = size + 1
        end
    end

    return size
end

-- Raw size of a table (no filtering)
function FastFriends.GetRawTableSize(tbl)
    if tbl == nil then return 0 end
    local size = 0
    for _ in pairs(tbl) do size = size + 1 end
    return size
end

-- Character initialization tracking (per server+faction)

function FastFriends.MarkCharInitialized()
    if FastFriends.db == nil then return end
    if FastFriends.db._meta == nil then FastFriends.db._meta = {} end
    if FastFriends.db._meta.seenChars == nil then FastFriends.db._meta.seenChars = {} end
    FastFriends.db._meta.seenChars[FastFriends.myName] = true
end
--------------------------------------------------------------------------------


-- Slash registration helpers ---------------------------------------------------
function FastFriends.GetPreferredAlias()
    if FastFriends.slash and FastFriends.slash.ff then return "/ff" end
    return "/fastfriends"
end

local function ff_isSlashRegistered(alias)
    if not LibSlash then return false end
    -- Try known queries first
    if LibSlash.IsSlashCmdRegistered then
        local res = LibSlash.IsSlashCmdRegistered(alias)
        if res ~= nil then return res and true or false end
    end
    if LibSlash.GetCmdHandler then
        local handler = LibSlash.GetCmdHandler(alias)
        if handler ~= nil then return true end
    end
    -- Heuristic: common internal tables used by some LibSlash variants
    if LibSlash.cmds and LibSlash.cmds[alias] ~= nil then return true end
    if LibSlash.SlashCommands and LibSlash.SlashCommands[alias] ~= nil then return true end
    if LibSlash.RegisteredSlashCmds and LibSlash.RegisteredSlashCmds[alias] ~= nil then return true end
    return false
end

local function ff_tryRegister(alias)
    if not (LibSlash and LibSlash.RegisterSlashCmd) then return false end
    if ff_isSlashRegistered(alias) then return false end
    local res = LibSlash.RegisterSlashCmd(alias, function(msg) FastFriends.Slash(msg) end)
    -- Many libs return nothing; treat non-false as success
    return res ~= false
end

function FastFriends.RegisterSlashCommands()
    -- Prefer /ff, but never override if something already claimed it
    FastFriends.slash.ff = ff_tryRegister("ff") and true or false
    -- Ensure a long alias exists for fallback and discoverability
    FastFriends.slash.fastfriends = ff_tryRegister("fastfriends") and true or ff_isSlashRegistered("fastfriends")
end


-- Slash command handling -------------------------------------------------------
local function ff_parseCmd(msg)
    local s = tostring(msg or "")
    if s == "" then return "", "" end
    local c, p = string.match(s, "^(%S+)%s*(.*)$")
    if not c then return string.lower(s), "" end
    return string.lower(c), p or ""
end

local function ff_parseBool(word)
    if not word or word == "" then return nil end
    word = string.lower(word)
    if word == "on" or word == "true" or word == "1" or word == "enable" then return true end
    if word == "off" or word == "false" or word == "0" or word == "disable" then return false end
    if word == "toggle" or word == "t" then return nil end
    return nil
end

function FastFriends.Slash(msg)
    local cmd, param = ff_parseCmd(msg)
    cmd = cmd or ""

    if cmd == "" then
        if FastFriends.UI and FastFriends.UI.Show then
            FastFriends.UI.Show()
            return
        else
            -- Fallback to help output when UI is unavailable
            cmd = "help"
        end
    end
    if cmd == "help" or cmd == "?" then
        FastFriends.Print(L"FastFriends commands:")
        local alias = FastFriends.GetPreferredAlias()
        local masterCur = (FastFriends.syncMaster and "ON" or "OFF")
        local masterTag = (FastFriends.syncMaster and "default" or "custom")
        local mode = string.lower(tostring(FastFriends.syncMode or "opt-in"))
        local modeDesc = (mode == "all") and "All" or ((mode == "opt-in") and "Opt-in" or ("Level (min "..tostring(FastFriends.minLevel)..")"))
        local modeTag = (mode == "opt-in") and "default" or "custom"
        local levelTag = (tonumber(FastFriends.minLevel or 16) == 16) and "default" or "custom"
        local fCur = (FastFriends.listFriends and "ON" or "OFF")
        local fTag = (FastFriends.listFriends and "default" or "custom")
        local iCur = (FastFriends.listIgnore and "ON" or "OFF")
        local iTag = (FastFriends.listIgnore and "default" or "custom")
        local slogCur = (FastFriends.synclog and "ON" or "OFF")
        local slogTag = (FastFriends.synclog and "custom" or "default")
        local over = FastFriends.GetCharOverride()
        local overCur = (over == nil) and "unset" or ((over and "on") or "off")
        local overTag = (over == nil) and "default" or "custom"

        local function ff_help(alias, cmd, desc)
            FastFriends.Print(towstring(alias.." "..cmd.." - ")..FastFriends.ColorGreyExcept(desc))
        end
        ff_help(alias, "status", "Shows current status.")
        ff_help(alias, "confirm [status|no]", "Resolve a pending large initial diff. Prompts at max(10, half of the larger current local/global enabled-list size); 'status' reviews names and 'no' keeps local as global.")
        ff_help(alias, "ui", "Opens the settings window.")
        ff_help(alias, "servers", "List servers seen by this game installation.")
        ff_help(alias, "sync on|off", string.format("Master toggle for all syncing. [current: %s, %s]", masterCur, masterTag))
        ff_help(alias, "mode all|level|opt-in", string.format("Default sync rule. [current: %s, %s]", modeDesc, modeTag))
        ff_help(alias, "level <number>", string.format("Level for 'level' mode. [current: %d, %s]", tonumber(FastFriends.minLevel or 16) or 16, levelTag))
        ff_help(alias, "char sync on|off", string.format("Override for this character. [current: %s, %s]", overCur, overTag))
        ff_help(alias, "char reset", "Remove overrides and follow global rules.")
        ff_help(alias, "ochar <name> [sync] on|off [faction order|destruction] [server S]", "Schedule another character to opt-in/out on next login (defaults to current server and faction).")
        ff_help(alias, "ochar <name> reset [faction order|destruction] [server S]", "Schedule another character to clear its override on next login (defaults to current server and faction).")
        ff_help(alias, "seen [server S]", "List already-seen characters; shows faction and if opted in/out.")
        ff_help(alias, "pending [server S] [faction order|destruction]", "List pending overrides; use 'pending clear name or all' to clear.")
        ff_help(alias, "friends on|off", string.format("FriendList sync. [current: %s, %s]", fCur, fTag))
        ff_help(alias, "ignore on|off", string.format("IgnoreList sync. [current: %s, %s]", iCur, iTag))
        -- hidden command: loginmsg (prints the login status line); intentionally not listed here
        ff_help(alias, "synclog on|off|toggle", string.format("Sync action logs. [current: %s, %s]", slogCur, slogTag))
        return
    end

    if cmd == "ui" or cmd == "config" or cmd == "settings" then
        if FastFriends.UI and FastFriends.UI.Show then
            FastFriends.UI.Show()
        else
            FastFriends.Print(L"UI is currently unavailable.")
        end
        return
    end

    if cmd == "sync" then
        local b = ff_parseBool(param)
        if b == nil then
            FastFriends.syncMaster = not (FastFriends.syncMaster and true or false)
        else
            FastFriends.syncMaster = b and true or false
        end
        FastFriends.SetSetting("syncMaster", FastFriends.syncMaster and true or false, true)
        if not FastFriends.syncMaster then
            FastFriends.SyncAbort("master off")
        end
        FastFriends.Print(towstring("Master Sync = "..tostring(FastFriends.syncMaster)))
        return
    end

    if cmd == "mode" then
        local val = string.lower(tostring(param or ""))
        if val ~= "all" and val ~= "level" and val ~= "opt-in" and val ~= "optin" then
            FastFriends.Print(L"Usage: /ff mode all|level|opt-in")
            return
        end
        if val == "optin" then val = "opt-in" end
        FastFriends.syncMode = val
        -- Reset to default if 'opt-in'
        if val == "opt-in" then
            FastFriends.SetSetting("syncMode", nil, nil) -- remove key (default)
        else
            FastFriends.SetSetting("syncMode", val, "opt-in")
        end
        FastFriends.Print(towstring("Sync mode = "..val))
        return
    end

    if cmd == "level" then
        local n = tonumber(param)
        if not n then
            FastFriends.Print(L"Usage: /ff level <number>")
            return
        end
        if n < 1 then n = 1 end
        FastFriends.minLevel = n
        FastFriends.SetSetting("minLevel", n, 16)
        FastFriends.Print(towstring("Level mode threshold = "..tostring(n)))
        return
    end

    if cmd == "char" or cmd == "currentchar" then
        local sub, arg = ff_parseCmd(param)
        sub = sub or ""
        if sub == "sync" then
            local b = ff_parseBool(arg)
            if b == nil then
                FastFriends.Print(L"Usage: /ff char sync on|off")
                return
            end
            -- If requested value matches the default behavior, clear the override
            local defaultCan = FastFriends.DefaultSyncForChar()
            if (b and true or false) == defaultCan then
                if FastFriendsCharDB then FastFriendsCharDB.override = nil end
                if FastFriends.db and FastFriends.db._meta and FastFriends.db._meta.charOverrides then
                    FastFriends.db._meta.charOverrides[FastFriends.myName] = nil
                end
                FastFriends.Print(L"Character override cleared (matches default)")
            else
                if FastFriendsCharDB then FastFriendsCharDB.override = (b and true or false) end
                if FastFriends.db and FastFriends.db._meta and FastFriends.db._meta.charOverrides then
                    FastFriends.db._meta.charOverrides[FastFriends.myName] = b and true or false
                end
                FastFriends.Print(towstring("Character override set: sync="..tostring(b and true or false)))
            end
            -- If turning off while syncing, abort
            if b == false then FastFriends.SyncAbort("char override off") end
            return
        elseif sub == "reset" then
            if FastFriendsCharDB then FastFriendsCharDB.override = nil end
            if FastFriends.db and FastFriends.db._meta and FastFriends.db._meta.charOverrides then
                FastFriends.db._meta.charOverrides[FastFriends.myName] = nil
            end
            FastFriends.Print(L"Character override cleared")
            return
        else
            FastFriends.Print(L"Usage: /ff char sync on|off | /ff char reset")
            return
        end
    end

    if cmd == "otherchar" or cmd == "ochar" or cmd == "achar" then
        -- Tokenize params: <name> [sync] on|off|reset [server S] [faction order|destruction|1|2]
        local function ff_tokens(s)
            local out = {}
            for w in string.gmatch(tostring(s or ""), "%S+") do out[#out + 1] = w end
            return out
        end
        local tokens = ff_tokens(param)
        if #tokens < 2 then
            FastFriends.Print(L"Usage: /ff ochar <name> [sync] on|off | /ff ochar <name> reset [server S] [faction order|destruction]")
            return
        end
        local rawTarget = tokens[1]
        local target = FastFriends.CapitalizeFirst(FastFriends.TrimName(rawTarget))
        if target == tostring(FastFriends.myName or "") then
            FastFriends.Print(L"Use '/ff currentchar ...' for this character.")
            return
        end
        local idx = 2
        local op = nil -- true/false or "reset"
        local server = tostring(FastFriends.serverName or "")
        local faction = tostring(FastFriends.factionKey or "")
        while idx <= #tokens do
            local t = string.lower(tokens[idx])
            if t == "sync" then
                idx = idx + 1
            elseif t == "on" then
                op = true; idx = idx + 1
            elseif t == "off" then
                op = false; idx = idx + 1
            elseif t == "reset" then
                op = "reset"; idx = idx + 1
            elseif t == "server" then
                if idx + 1 <= #tokens then server = tokens[idx + 1] end
                idx = idx + 2
            elseif t == "faction" then
                local fv = ""
                if idx + 1 <= #tokens then fv = string.lower(tokens[idx + 1]) end
                if fv == "order" or fv == "1" then faction = "Order"
                elseif fv == "destruction" or fv == "2" then faction = "Destruction"
                end
                idx = idx + 2
            else
                -- allow bare faction as convenience
                if t == "order" then faction = "Order"; idx = idx + 1
                elseif t == "destruction" then faction = "Destruction"; idx = idx + 1
                else
                    -- unknown token; stop
                    idx = idx + 1
                end
            end
        end
        if op == nil then
            FastFriends.Print(L"Usage: /ff ochar <name> [sync] on|off | /ff ochar <name> reset [server S] [faction order|destruction]")
            return
        end
        -- Ensure destination buckets exist
        if FastFriendsDB[server] == nil then FastFriendsDB[server] = {} end
        if FastFriendsDB[server][faction] == nil then FastFriendsDB[server][faction] = {} end
        local dst = FastFriendsDB[server][faction]
        if dst._meta == nil then dst._meta = {} end
        if dst._meta.pendingCharOverrides == nil then dst._meta.pendingCharOverrides = {} end
        dst._meta.pendingCharOverrides[target] = op
        if op == true then
            FastFriends.Print(towstring("Scheduled: '"..target.."' will be opted IN on next login ("..server.."/"..faction..")"))
        elseif op == false then
            FastFriends.Print(towstring("Scheduled: '"..target.."' will be opted OUT on next login ("..server.."/"..faction..")"))
        else
            FastFriends.Print(towstring("Scheduled: '"..target.."' will RESET to default on next login ("..server.."/"..faction..")"))
        end
        return
    end

    if cmd == "friends" then
        local b = ff_parseBool(param)
        local prev = FastFriends.listFriends and true or false
        if b == nil then
            FastFriends.listFriends = not (FastFriends.listFriends and true or false)
        else
            FastFriends.listFriends = b and true or false
        end
        if (FastFriends.listFriends and true or false) ~= prev then
            FastFriends.MarkLocalListDirty("friend")
        end
        FastFriends.SetSetting("listFriends", FastFriends.listFriends and true or false, true)
        FastFriends.Print(towstring("Friends syncing = "..tostring(FastFriends.listFriends)))
        if not FastFriends.listFriends then FastFriends.SyncAbort("friends disabled") end
        return
    end

    if cmd == "ignore" then
        local b = ff_parseBool(param)
        local prev = FastFriends.listIgnore and true or false
        if b == nil then
            FastFriends.listIgnore = not (FastFriends.listIgnore and true or false)
        else
            FastFriends.listIgnore = b and true or false
        end
        if (FastFriends.listIgnore and true or false) ~= prev then
            FastFriends.MarkLocalListDirty("ignore")
        end
        FastFriends.SetSetting("listIgnore", FastFriends.listIgnore and true or false, true)
        FastFriends.Print(towstring("Ignore syncing = "..tostring(FastFriends.listIgnore)))
        if not FastFriends.listIgnore then FastFriends.SyncAbort("ignore disabled") end
        return
    end

    if cmd == "loginmsg" then
        -- Hidden command: just print the login status line on-demand
        FastFriends.MaybePrintLoginMessage(false)
        return
    end

    if cmd == "confirm" then
        local choice = string.lower(ff_trim_identity(param or ""))
        local state = FastFriends.initialDiffConfirmState
        if state == nil or state.status ~= "pending" then
            FastFriends.Print(L"No pending initial diff confirmation.")
            return
        end
        if choice == "status" or choice == "show" or choice == "list" or choice == "preview" then
            FastFriends.PrintInitialDiffConfirmDetails(state)
            return
        end
        if choice == "" or choice == "yes" or choice == "ok" or choice == "apply" then
            state.status = "approved"
            FastFriends.initialDiffConfirmState = state
            FastFriends.RunInitialReconcile()
            return
        end
        if choice == "no" or choice == "keep" or choice == "local" or choice == "reject" then
            FastFriends.ApplyCurrentLocalListsAsGlobal()
            return
        end
        FastFriends.Print(L"Usage: /ff confirm [status|no]")
        return
    end

    if cmd == "debug" then
        local sub, arg = ff_parseCmd(param)
        sub = sub or ""
        if sub == "lists" then
            local desired = ff_parseBool(arg)
            if desired == nil then
                FastFriends.debugListSnapshots = not (FastFriends.debugListSnapshots and true or false)
            else
                FastFriends.debugListSnapshots = desired and true or false
            end
            FastFriends.Print(towstring("Debug list snapshots = "..tostring(FastFriends.debugListSnapshots)))
            return
        end
        local desired = ff_parseBool(param)
        if desired == nil then
            FastFriends.isDebug = not FastFriends.isDebug
        else
            FastFriends.isDebug = desired and true or false
        end
        -- persist with default reset (default OFF)
        FastFriends.SetSetting("debug", FastFriends.isDebug and true or false, false)
        FastFriends.Print(towstring("Debug = "..tostring(FastFriends.isDebug)))
        return
    end

    if cmd == "status" then
        local paramText = tostring(param or "")
        local tokens = {}
        for w in string.gmatch(paramText, "%S+") do tokens[#tokens + 1] = w end

        local function ff_is_verbose_token(text)
            local t = string.lower(text or "")
            return (t == "detailed" or t == "detail" or t == "full" or t == "verbose" or t == "-v" or t == "--verbose" or t == "debug")
        end

        local verbose = false
        local showNoteReason = false

        if #tokens == 0 then
            verbose = ff_is_verbose_token(paramText)
        else
            for i = 1, #tokens do
                local tok = tokens[i]
                if ff_is_verbose_token(tok) then verbose = true end
                if string.lower(tok) == "notes" then showNoteReason = true end
            end
        end

        if showNoteReason then verbose = true end
        local v = tostring(FastFriends.version or "?")
        local srv = tostring(FastFriends.serverName or "?")
        local fac = tostring(FastFriends.factionKey or "?")
        local lvl = tonumber(GameData.Player.level or 0) or 0
        -- Global block
        local function ff_status_kv(label, value, hint)
            local line = towstring("  "..label..": ")..FastFriends.ColorGreyExcept(value)
            if hint and hint ~= "" then
                line = line..FastFriends.ColorGrey(" ("..hint..")")
            end
            FastFriends.Print(line)
        end
        FastFriends.Print(L"--- FastFriends Status ---")
        local alias = FastFriends.GetPreferredAlias()
        FastFriends.Print(L"[Global Settings]"..FastFriends.ColorGrey(" - Open UI: "..alias.." ui"))
        ff_status_kv("Master Sync", (FastFriends.syncMaster and "ENABLED" or "DISABLED"), alias.." sync on|off")
        local mode = string.lower(tostring(FastFriends.syncMode or "level"))
        if mode == "all" then
            ff_status_kv("Sync Mode", "All", alias.." mode all|level|opt-in")
        elseif mode == "opt-in" then
            ff_status_kv("Sync Mode", "Opt-in", alias.." mode all|level|opt-in")
        else
            ff_status_kv("Sync Mode", "Level (min level "..tostring(FastFriends.minLevel)..")", alias.." mode level; "..alias.." level N")
        end
        ff_status_kv("Lists", "Friends="..(FastFriends.listFriends and "ON" or "OFF")..", Ignore="..(FastFriends.listIgnore and "ON" or "OFF"), alias.." friends on|off; "..alias.." ignore on|off")
        -- Character block
        FastFriends.Print(towstring("[Current Character: ")..FastFriends.ColorGrey(FastFriends.myName)..towstring(" (")..FastFriends.ColorGrey("Level ")..towstring(tostring(lvl))..towstring(")]"))
        local can, reason = FastFriends.ShouldSync()
        ff_status_kv("Effective Status", (can and "SYNCING" or "NOT SYNCING"), alias.." char sync on|off; "..alias.." char reset")
        ff_status_kv("Reason", tostring(reason))
        if FastFriends.HasPendingInitialDiffConfirmation() then
            ff_status_kv("Initial Diff", "PENDING CONFIRMATION - "..FastFriends.FormatInitialDiffConfirmSummary(FastFriends.initialDiffConfirmState), alias.." confirm status | "..alias.." confirm | "..alias.." confirm no")
        end
        -- Snapshot block (only with detailed flag)
        if verbose then
            local dbg = FastFriends.isDebug and "on" or "off"
            local ev = FastFriends.socialEventsRegistered and "enabled" or "disabled"
            local initReconcile
            if FastFriends.initReconcilePending then
                local maxWait = tonumber(FastFriends.initReconcileMaxWaitSec or 10.0) or 10.0
                local elapsed = tonumber(FastFriends.initReconcileElapsed or 0) or 0
                local remaining = maxWait - elapsed
                if remaining < 0 then remaining = 0 end
                local evt = tostring(FastFriends.lastWorldEvent or "INIT")
                initReconcile = string.format("pending(%.1fs,evt=%s)", remaining, evt)
            else
                initReconcile = "done"
            end
            local line1 = string.format("v%s | Debug=%s | Server=%s | Faction=%s | Events=%s | InitialReconcile=%s", v, dbg, srv, fac, ev, initReconcile)
            local fCount = FastFriends.GetTableSize(FastFriends.db.friend)
            local iCount = FastFriends.GetTableSize(FastFriends.db.ignore)
            local fDel = FastFriends.GetRawTableSize(FastFriends.db.friend._deleted)
            local iDel = FastFriends.GetRawTableSize(FastFriends.db.ignore._deleted)
            local noteEnabled = FastFriends.CanSyncFriendNotes()
            local noteTotal, noteWith = 0, 0
            local noteSummary = "disabled"
            local noteDetail = nil
            local noteDigest = nil
            if noteEnabled then
                noteTotal, noteWith = FastFriends.GetFriendNoteStats()
                noteSummary = string.format("%d/%d", noteWith, noteTotal)
                noteDetail = FastFriends.noteSupportReason or "EA_SocialWindow tables detected."
                if FastFriends.db and FastFriends.db._meta then
                    noteDigest = FastFriends.db._meta.friendNoteDigest
                end
            else
                noteDetail = FastFriends.noteSupportReason or "EA_SocialWindow not detected."
            end
            local sync = FastFriends.syncActive and "active" or "idle"
            local q = #FastFriends.actionQueue or 0
            local rescan = FastFriends.rescanAfterSync and "yes" or "no"
            local pend = "none"
            if FastFriends.pendingAction ~= nil then
                local pa = FastFriends.pendingAction
                local t = tostring(pa.type or "?")
                local op = tostring(pa.op or "add")
                local nm = tostring(pa.name or "?")
                pend = string.format("%s:%s:'%s'", t, op, nm)
            end
            local fCap = FastFriends.GetListCap("friend") or 0
            local iCap = FastFriends.GetListCap("ignore") or 0
            local fSrv = FastFriends.GetListServerCap("friend") or 0
            local iSrv = FastFriends.GetListServerCap("ignore") or 0
            local line2 = string.format(
                "Sync=%s | Queue=%d | Pending=%s | Rescan=%s | DB: F=%d/%d (srv=%d del=%d) I=%d/%d (srv=%d del=%d) Notes=%s",
                sync, q, pend, rescan, fCount, fCap, fSrv, fDel, iCount, iCap, iSrv, iDel, noteSummary)
            FastFriends.Print(towstring("[Debug]"))
            FastFriends.Print(towstring(line1))
            FastFriends.Print(towstring(line2))
            if showNoteReason then
                if noteDetail and noteDetail ~= "" then
                    if noteEnabled then
                        FastFriends.Print(FastFriends.ColorGrey("[Notes] "..noteDetail))
                    else
                        FastFriends.Print(FastFriends.ColorGrey("[Notes] "..noteDetail))
                    end
                end
                FastFriends.Print(FastFriends.ColorGrey("[Notes] digest="..tostring(noteDigest or "<unset>")))
            end
        end
        return
    end

    if cmd == "pending" then
        -- Manage or list pending per-character overrides
        local function ff_tokens(s)
            local out = {}
            for w in string.gmatch(tostring(s or ""), "%S+") do out[#out + 1] = w end
            return out
        end
        local tokens = ff_tokens(param)
        local mode = "list" -- or "clear"
        local target = nil   -- name or "all"
        local server = tostring(FastFriends.serverName or "")
        local faction = tostring(FastFriends.factionKey or "")
        local idx = 1
        if idx <= #tokens and string.lower(tokens[idx]) == "clear" then
            mode = "clear"; idx = idx + 1
        end
        while idx <= #tokens do
            local t = string.lower(tokens[idx])
            if t == "server" then
                if idx + 1 <= #tokens then server = tokens[idx + 1] end
                idx = idx + 2
            elseif t == "faction" then
                local fv = ""; if idx + 1 <= #tokens then fv = string.lower(tokens[idx + 1]) end
                if fv == "order" or fv == "1" then faction = "Order"
                elseif fv == "destruction" or fv == "2" then faction = "Destruction" end
                idx = idx + 2
            else
                if mode == "clear" and target == nil then
                    target = tokens[idx]
                end
                idx = idx + 1
            end
        end
        local sdb = FastFriendsDB[server]
        if sdb == nil or sdb[faction] == nil or sdb[faction]._meta == nil then
            if mode == "list" then
                FastFriends.Print(towstring("No pending overrides for server '"..server.."' ["..faction.."]."))
            else
                FastFriends.Print(towstring("Nothing to clear on server '"..server.."' ["..faction.."]."))
            end
            return
        end
        local pend = sdb[faction]._meta.pendingCharOverrides or {}
        if mode == "list" then
            -- Collect names
            local names = {}
            for name, _ in pairs(pend) do names[#names + 1] = tostring(name) end
            if #names == 0 then
                FastFriends.Print(towstring("No pending overrides for server '"..server.."' ["..faction.."]."))
                return
            end
            table.sort(names, function(a,b) return string.lower(a) < string.lower(b) end)
            FastFriends.Print(towstring("Pending overrides for server '"..server.."' ["..faction.."]:"))
            for i = 1, #names do
                local v = pend[names[i]]
                local desc = (v == true and "on") or (v == false and "off") or (v == "reset" and "reset") or tostring(v)
                FastFriends.Print(towstring(" - "..names[i]..": "..desc))
            end
            return
        end
        -- mode == clear
        if target == nil then
            FastFriends.Print(L"Usage: /ff pending clear <name|all> [server S] [faction order|destruction]")
            return
        end
        if string.lower(target) == "all" then
            local count = 0
            for name, _ in pairs(pend) do pend[name] = nil; count = count + 1 end
            FastFriends.Print(towstring(string.format("Cleared %d pending override(s) (%s/%s)", count, server, faction)))
            return
        end
        local name = FastFriends.CapitalizeFirst(FastFriends.TrimName(target))
        local cleared = false
        if pend[name] ~= nil then pend[name] = nil; cleared = true end
        if pend[string.lower(name)] ~= nil then pend[string.lower(name)] = nil; cleared = true end
        if cleared then
            FastFriends.Print(towstring("Cleared pending override for '"..name.."' ("..server.."/"..faction..")"))
        else
            FastFriends.Print(towstring("No pending override for '"..name.."' ("..server.."/"..faction..")"))
        end
        return
    end

    if cmd == "seen" then
        -- List seen characters on a server (default: current server), grouped by faction
        local srv = tostring(FastFriends.serverName or "")
        local sub, arg = ff_parseCmd(param)
        if sub == "server" and arg and arg ~= "" then
            srv = arg
        end
        local sdb = FastFriendsDB[srv]
        if sdb == nil then
            FastFriends.Print(towstring("No data for server '"..srv.."'."))
            return
        end
        FastFriends.Print(towstring("Already-seen characters on server '"..srv.."':"))
        local count = 0
        local function listFaction(fkey)
            local fdb = sdb[fkey]
            if not (fdb and fdb._meta and fdb._meta.seenChars) then return end
            local names = {}
            for name, on in pairs(fdb._meta.seenChars) do
                if on then names[#names + 1] = tostring(name) end
            end
            table.sort(names, function(a, b)
                return string.lower(a) < string.lower(b)
            end)
            for i = 1, #names do
                count = count + 1
                local ov = nil
                if fdb._meta and fdb._meta.charOverrides then ov = fdb._meta.charOverrides[names[i]] end
                local suffix = ""
                if ov == true then suffix = " (opted in)" elseif ov == false then suffix = " (opted out)" end
                FastFriends.Print(towstring(" - "..names[i].." ["..fkey.."]"..suffix))
            end
        end
        listFaction("Order")
        listFaction("Destruction")
        if count == 0 then FastFriends.Print(L" (none)") end
        return
    end

    if cmd == "servers" then
        -- List all servers with stored data
        local names = {}
        for k, v in pairs(FastFriendsDB or {}) do
            if type(v) == "table" and string.sub(tostring(k), 1, 1) ~= "_" then
                names[#names + 1] = tostring(k)
            end
        end
        table.sort(names, function(a, b) return string.lower(a) < string.lower(b) end)
        if #names == 0 then
            FastFriends.Print(L"No servers have been seen yet.")
            return
        end
        FastFriends.Print(L"Servers with FastFriends data:")
        for i = 1, #names do FastFriends.Print(towstring(" - "..names[i])) end
        return
    end

    if cmd == "synclog" then
        local desired = ff_parseBool(param)
        if desired == nil then
            FastFriends.synclog = not FastFriends.synclog
        else
            FastFriends.synclog = desired and true or false
        end
        FastFriends.SetSetting("synclog", FastFriends.synclog and true or false, false)
        FastFriends.Print(towstring("Synclog = "..tostring(FastFriends.synclog)))
        return
    end

    if cmd == "notepeek" or cmd == "notecheck" then
        if param == nil or param == "" then
            FastFriends.Print(towstring("Usage: /"..FastFriends.GetPreferredAlias().." notepeek <Name>"))
            return
        end
        local target = FastFriends.TrimName(param)
        ff_debug_dump_friend_note(target)
        return
    end

    if cmd == "notescan" then
        ff_force_note_rescan("manual-cmd")
        FastFriends.Print(L"Note scan triggered.")
        return
    end

    -- fallback
    local alias = FastFriends.GetPreferredAlias()
    FastFriends.Print(towstring("Unknown command. Try: "..alias.." help"))
end


-- Determine faction key --------------------------------------------------------
function FastFriends.GetFactionKey()
    local faction = FastFriends.ResolveFactionKey()
    if faction ~= nil then return faction end
    return "Unknown"
end

-- Event registration helpers --------------------------------------------------
function FastFriends.OnFriendsEvent()
    -- friend list updated by client
    local cacheDirty = nil
    if FastFriends.localListCacheDirty then
        cacheDirty = FastFriends.localListCacheDirty.friend
    end
    FastFriends.Debug(string.format("OnFriendsEvent(): syncActive=%s initPending=%s rescanAfterSync=%s cacheDirty=%s", tostring(FastFriends.syncActive), tostring(FastFriends.initReconcilePending), tostring(FastFriends.rescanAfterSync), tostring(cacheDirty)))
    FastFriends.MarkListCountsReady("friend")
    -- During bootstrap timer, do not force reconcile early
    if not FastFriends.initBootstrapDone then return end
    if not FastFriends.loginMsgShown then return end
    if FastFriends.initReconcilePending then return end
    if FastFriends.syncActive then
        FastFriends.rescanAfterSync = true
        return
    end
    -- Process normally. Cache the local list so Update() can reuse it without re-fetching.
    local localFriends = nil
    if FastFriends.IsListEnabled("friend") then
        localFriends = FastFriends.GetLocalNameList("friend")
        FastFriends.RememberLocalListSnapshot("friend", localFriends, true)
        FastFriends.CacheLocalList("friend", localFriends)
        FastFriends.ScanLocalFriendNotes(localFriends)
    end
    if FastFriends.db and FastFriends.db.friend then
        FastFriends.DebugListSnapshot("OnFriendsEvent global", "friend", FastFriends.db.friend)
        FastFriends.DebugDeletedSnapshot("OnFriendsEvent global friend", FastFriends.db.friend._deleted)
        FastFriends.DebugListDiff("OnFriendsEvent", "friend", localFriends, FastFriends.db.friend)
    end
    FastFriends.Update()
end

function FastFriends.OnIgnoreEvent()
    -- ignore list updated by client
    local cacheDirty = nil
    if FastFriends.localListCacheDirty then
        cacheDirty = FastFriends.localListCacheDirty.ignore
    end
    FastFriends.Debug(string.format("OnIgnoreEvent(): syncActive=%s initPending=%s rescanAfterSync=%s cacheDirty=%s", tostring(FastFriends.syncActive), tostring(FastFriends.initReconcilePending), tostring(FastFriends.rescanAfterSync), tostring(cacheDirty)))
    FastFriends.MarkListCountsReady("ignore")
    if not FastFriends.initBootstrapDone then return end
    if not FastFriends.loginMsgShown then return end
    if FastFriends.initReconcilePending then return end
    local localIgnores = FastFriends.GetLocalNameList("ignore")
    FastFriends.RememberLocalListSnapshot("ignore", localIgnores, true)
    if FastFriends.IsListEnabled("ignore") then
        FastFriends.CacheLocalList("ignore", localIgnores)
    else
        FastFriends.ConsumeCachedLocalList("ignore")
    end
    FastFriends.HandleIgnoredFriends(localIgnores)
    if FastFriends.db and FastFriends.db.ignore then
        FastFriends.DebugListSnapshot("OnIgnoreEvent global", "ignore", FastFriends.db.ignore)
        FastFriends.DebugDeletedSnapshot("OnIgnoreEvent global ignore", FastFriends.db.ignore._deleted)
        FastFriends.DebugListDiff("OnIgnoreEvent", "ignore", localIgnores, FastFriends.db.ignore)
    end
    if FastFriends.syncActive then
        FastFriends.rescanAfterSync = true
        return
    end
    FastFriends.Update()
end

function FastFriends.RegisterSocialEvents()
    -- Idempotent: avoid duplicate registrations
    if FastFriends.socialEventsRegistered then
        FastFriends.Debug("Events already enabled")
        return
    end
    -- Unconditionally register canonical events
    RegisterEventHandler(SystemData.Events.SOCIAL_FRIENDS_UPDATED, "FastFriends.OnFriendsEvent")
    RegisterEventHandler(SystemData.Events.SOCIAL_IGNORE_UPDATED,  "FastFriends.OnIgnoreEvent")
    FastFriends.socialEventsRegistered = true
    FastFriends.Debug("Events enabled")
end

-- Unregister social events (used on shutdown)
function FastFriends.UnregisterSocialEvents()
    if not FastFriends.socialEventsRegistered then return end
    UnregisterEventHandler(SystemData.Events.SOCIAL_FRIENDS_UPDATED, "FastFriends.OnFriendsEvent")
    UnregisterEventHandler(SystemData.Events.SOCIAL_IGNORE_UPDATED,  "FastFriends.OnIgnoreEvent")
    FastFriends.socialEventsRegistered = false
end

-- Dynamic, colored chat prefix using <LINK> markup; version removed from tag
function FastFriends.GetTag()
    -- Brackets outside; only the word FastFriends is colored
    local s = "[<LINK data=\"\" text=\"FastFriends\" color=\"173,216,230\">]: "
    return towstring(s)
end

-- Sync logging helper (respects FastFriends.synclog)
function FastFriends.SyncLog(message)
    if not FastFriends.synclog then return end
    local t = type(message)
    if t == "wstring" then
        FastFriends.Print(message)
    else
        FastFriends.Print(towstring(tostring(message)))
    end
end

-- Per-frame driver: progress queue without relying on social events
function FastFriends.OnUpdate(timePassed)
    local resolvedDelta
    local function getDelta()
        if resolvedDelta == nil then
            resolvedDelta = FastFriends.ResolveDelta(timePassed)
        end
        return resolvedDelta
    end

    -- Always tick the initial reconcile timer if pending
    if FastFriends.initReconcilePending then
        local dt = getDelta()
        FastFriends.initReconcileElapsed = (FastFriends.initReconcileElapsed or 0) + dt
        local timeout = (FastFriends.initReconcileElapsed >= (FastFriends.initReconcileMaxWaitSec or 10.0))
        if timeout then
            FastFriends.Debug("Initial reconcile timer expired; reconciling now")
            FastFriends.RunInitialReconcile()
        end
    end

    -- If the automatic login message did not print via events, print it after a short delay
    if not FastFriends.loginMsgShown and (FastFriends.bootPrintPending and true or false) then
        local dt2 = getDelta()
        FastFriends.bootElapsed = (FastFriends.bootElapsed or 0) + dt2
        if FastFriends.bootElapsed >= (FastFriends.bootPrintDelaySec or 0.25) then
            FastFriends.MaybePrintLoginMessage(true)
            FastFriends.bootPrintPending = false
        end
    end

    FastFriends.ProcessLoginMsgConfirm(timePassed)

    -- Hold everything else until we've printed the automatic login status line
    if not FastFriends.loginMsgShown then return end
    -- Suppress event-driven reconciliation during the initial reconcile timer
    if FastFriends.initReconcilePending then return end
    if FastFriends.HasPendingInitialDiffConfirmation() then
        FastFriends.ProcessInitialDiffConfirmReminder(getDelta())
        return
    end
    if not FastFriends.hasLoaded then return end
    FastFriends.NoteScanOnUpdate(timePassed)
    if not FastFriends.syncActive then return end -- event-driven when idle
    -- If sync just became disabled, abort immediately
    local canSync, _ = FastFriends.ShouldSync()
    if not canSync then
        FastFriends.SyncAbort("disabled by settings")
        return
    end
    local dt = getDelta()

    -- If nothing is pending, send the next action
    if FastFriends.pendingAction == nil then
        if #FastFriends.actionQueue > 0 then
            local a = FastFriends.actionQueue[1]
            -- If the list type is now disabled, drop this action and continue
            if not FastFriends.IsListEnabled(a.type) then
                table.remove(FastFriends.actionQueue, 1)
                return
            end
            if a.type == "friend" and a.op == "note" then
                local applied = FastFriends.ProcessQueuedFriendNoteAction(a)
                if applied then
                    table.remove(FastFriends.actionQueue, 1)
                    if #FastFriends.actionQueue == 0 then
                        FastFriends.SyncFinish()
                    end
                end
                return
            end
            FastFriends.AddOrRemoveCharacter(a.name, a.type, a.op)
            FastFriends.pendingAction = { name=a.name, type=a.type, op=a.op, retries=a.retries or 0, desc=a.desc, renameCandidate=a.renameCandidate, renameTarget=a.renameTarget }
            FastFriends.pendingElapsed = 0
            return
        end
        -- No more work; leave sync mode for event-driven idle
        FastFriends.SyncFinish()
        return
    end

    -- Verify the pending action after a small delay to allow the client to update
    FastFriends.pendingElapsed = (FastFriends.pendingElapsed or 0) + dt
    if FastFriends.pendingElapsed < (FastFriends.verifyDelaySec or 0.5) then return end

    local pa = FastFriends.pendingAction
    -- If the relevant list got disabled mid-sync, drop this action
    if not FastFriends.IsListEnabled(pa.type) then
        if #FastFriends.actionQueue > 0 and FastFriends.actionQueue[1].name == pa.name and FastFriends.actionQueue[1].type == pa.type then
            table.remove(FastFriends.actionQueue, 1)
        end
        FastFriends.pendingAction = nil
        FastFriends.pendingElapsed = 0
        if #FastFriends.actionQueue == 0 then
            FastFriends.SyncFinish()
        end
        return
    end
    local listNow = FastFriends.GetLocalNameList(pa.type)
    local ok = false
    if pa.op == "remove" then
        ok = (not FastFriends.LocalListContains(listNow, pa.name))
    else
        ok = FastFriends.LocalListContains(listNow, pa.name)
    end

    if ok then
        -- pop the completed action (ensure it matches the queue head)
        if #FastFriends.actionQueue > 0 and FastFriends.actionQueue[1].name == pa.name and FastFriends.actionQueue[1].type == pa.type then
            table.remove(FastFriends.actionQueue, 1)
        end
        FastFriends.pendingAction = nil
        FastFriends.pendingElapsed = 0
        -- success feedback
        if FastFriends.syncStats then
            if pa.op == "remove" then
                FastFriends.syncStats.remOk = (FastFriends.syncStats.remOk or 0) + 1
            else
                FastFriends.syncStats.addOk = (FastFriends.syncStats.addOk or 0) + 1
            end
        end
        local verbPast = (pa.op == "remove") and "removed" or "added"
        FastFriends.SyncLog(string.format("Synced: %s '%s' in local %s list", verbPast, pa.name, pa.type))
        if pa.type == "friend" then
            local noteSupport = FastFriends.CanSyncFriendNotes()
            if pa.op == "remove" then
                if noteSupport then
                    FastFriends.UpdateLocalFriendDescription(pa.name, "")
                end
                if FastFriends.localFriendWNames then
                    FastFriends.localFriendWNames[pa.name] = nil
                end
                FastFriends.SetCharFriendSeq(pa.name, 0)
            elseif pa.op == "add" then
                local seq = FastFriends.GetGlobalFriendSeq(pa.name)
                FastFriends.SetCharFriendSeq(pa.name, seq)
                if noteSupport and not FastFriends.HasQueuedFriendNoteAction(pa.name) then
                    local desc = pa.desc
                    if desc == nil then
                        desc = FastFriends.GetGlobalFriendDescription(pa.name)
                    end
                    FastFriends.UpdateLocalFriendDescription(pa.name, desc)
                end
            end
        end
        -- If we just drained the queue on a first-time character, mark initialized
        if FastFriends.firstSyncPending and #FastFriends.actionQueue == 0 then
            FastFriends.MarkCharInitialized()
            FastFriends.firstSyncPending = false
        end
        -- If no more work, leave sync mode
        if #FastFriends.actionQueue == 0 then
            FastFriends.SyncFinish()
        end
        return
    end

    -- Not yet applied; retry up to limit
    pa.retries = (pa.retries or 0) + 1
    local verb = (pa.op == "remove") and "remove" or "add"
    FastFriends.SyncLog(string.format("Warning: failed to %s '%s' in local %s list (attempt %d)", verb, pa.name, pa.type, pa.retries))

    if pa.retries <= (FastFriends.retryLimit or 4) then
        FastFriends.AddOrRemoveCharacter(pa.name, pa.type, pa.op)
        FastFriends.pendingElapsed = 0
        FastFriends.pendingAction = pa
    else
        FastFriends.SyncLog(string.format("Giving up on '%s' for local %s list after %d attempts", pa.name, pa.type, pa.retries))
        -- If a local removal failed, revert the global state to keep consistency
        if pa.op == "remove" then
            if FastFriends.db and FastFriends.db[pa.type] and FastFriends.db[pa.type]._deleted then
                FastFriends.db[pa.type][pa.name] = true
                FastFriends.db[pa.type]._deleted[pa.name] = nil
                FastFriends.SyncLog(string.format("Reverted: keeping '%s' in global %s list", pa.name, pa.type))
            end
        elseif pa.op == "add" then
            -- Rename cleanup: if this add came from a local-vs-global swap pattern
            -- and the name still is not in deleted, drop it from global without
            -- forcing deleted state.
            if FastFriends.db and FastFriends.db[pa.type] then
                local bucket = FastFriends.db[pa.type]
                local alreadyDeleted = (bucket._deleted and bucket._deleted[pa.name] == true)
                if not alreadyDeleted and pa.renameCandidate == true then
                    if pa.type == "friend" and pa.renameTarget ~= nil and pa.renameTarget ~= "" and pa.renameTarget ~= pa.name then
                        local sourceEntry = FastFriends.NormalizeGlobalFriendEntry(bucket, pa.name)
                        local sourceDesc = FastFriends.GetFriendDescriptionFromValue(sourceEntry)
                        if sourceDesc ~= "" then
                            local targetEntry = FastFriends.NormalizeGlobalFriendEntry(bucket, pa.renameTarget)
                            local targetDesc = FastFriends.GetFriendDescriptionFromValue(targetEntry)
                            if targetDesc == "" then
                                FastFriends.SetGlobalFriendDescription(pa.renameTarget, sourceDesc, tostring(FastFriends.myName or ""))
                                FastFriends.SyncLog(string.format("Global: moved note from '%s' to '%s' during rename cleanup", pa.name, pa.renameTarget))
                                targetDesc = sourceDesc
                            end
                            if targetDesc ~= "" then
                                FastFriends.RetargetQueuedFriendNoteAction(pa.name, pa.renameTarget, targetDesc)
                            end
                        end
                    end
                    bucket[pa.name] = nil
                    FastFriends.SyncLog(string.format("Reverted: removed stale '%s' from global %s list during rename cleanup", pa.name, pa.type))
                elseif not alreadyDeleted and bucket[pa.name] ~= nil then
                    -- Abandon unreachable add target to avoid retry loops on every login.
                    -- Kept out of _deleted so a future legitimate local presence can re-seed normally.
                    bucket[pa.name] = nil
                    FastFriends.SyncLog(string.format("Reverted: removed unreachable '%s' from global %s list after repeated add failures", pa.name, pa.type))
                end
            end
        end
        -- stats
        if FastFriends.syncStats then
            FastFriends.syncStats.fail = (FastFriends.syncStats.fail or 0) + 1
        end
        -- Drop the action and continue
        if #FastFriends.actionQueue > 0 and FastFriends.actionQueue[1].name == pa.name and FastFriends.actionQueue[1].type == pa.type then
            table.remove(FastFriends.actionQueue, 1)
        end
        FastFriends.pendingAction = nil
        FastFriends.pendingElapsed = 0
        if #FastFriends.actionQueue == 0 then
            FastFriends.SyncFinish()
        end
    end
end
-- One-shot initial reconcile runner -----------------------------------------
function FastFriends.RunInitialReconcile()
    -- Do initial reconcile now
    FastFriends.Debug("Init reconcile now")
    local canSync, _ = FastFriends.ShouldSync()
    if not canSync then
        FastFriends.initReconcilePending = false
        return
    end
    local noteSupport = FastFriends.CanSyncFriendNotes()
    local friendEnabled = FastFriends.IsListEnabled("friend")
    local ignoreEnabled = FastFriends.IsListEnabled("ignore")
    local localFriends = nil
    local localIgnores = nil

    if friendEnabled then
        localFriends = FastFriends.GetLocalNameList("friend")
        FastFriends.MarkListCountsReady("friend")
    end
    if ignoreEnabled then
        localIgnores = FastFriends.GetLocalNameList("ignore")
        FastFriends.MarkListCountsReady("ignore")
    end

    local initialConfirm = FastFriends.initialDiffConfirmState
    local confirmApproved = initialConfirm ~= nil and initialConfirm.status == "approved"
    if not confirmApproved then
        local gateState = FastFriends.BuildInitialDiffConfirmState(localFriends, localIgnores)
        if gateState ~= nil then
            FastFriends.initialDiffConfirmState = gateState
            if not FastFriends.hasLoaded then
                FastFriends.hasLoaded = true
            end
            FastFriends.initReconcilePending = false
            FastFriends.PrintInitialDiffConfirmPrompt(gateState)
            return
        end
    else
        FastFriends.ClearInitialDiffConfirmation()
    end

    if friendEnabled then
        local localFriendsReconciled = FastFriends.ReconcileDeletes(localFriends or {}, FastFriends.db.friend._deleted, "friend")
        FastFriends.Reconcile(localFriendsReconciled, FastFriends.db.friend, "friend")
        if noteSupport then
            FastFriends.db._meta.friendNoteDigest = FastFriends.ComputeFriendNoteDigest(localFriendsReconciled)
        else
            FastFriends.db._meta.friendNoteDigest = ""
        end
    end
    if ignoreEnabled then
        local localIgnoresReconciled = FastFriends.ReconcileDeletes(localIgnores or {}, FastFriends.db.ignore._deleted, "ignore")
        FastFriends.Reconcile(localIgnoresReconciled, FastFriends.db.ignore, "ignore")
    end
    -- Fallback: some environments never fire LOADING_END; ensure we mark loaded once initial reconcile completes.
    if not FastFriends.hasLoaded then
        FastFriends.hasLoaded = true
    end
    FastFriends.initReconcilePending = false
    -- No queued work: mark this character as initialized immediately
    if FastFriends.firstSyncPending and #FastFriends.actionQueue == 0 then
        FastFriends.MarkCharInitialized()
        FastFriends.firstSyncPending = false
    end
    -- If there is queued work after initial reconcile, enable sync mode.
    if #FastFriends.actionQueue > 0 then
        FastFriends.SyncBegin()
    end
end

-- Sync lifecycle helpers ------------------------------------------------------
function FastFriends.SyncBegin()
    FastFriends.syncActive = true
    FastFriends.syncStats = { addOk = 0, remOk = 0, noteOk = 0, fail = 0 }
    -- Always announce start
    local q = #FastFriends.actionQueue or 0
    FastFriends.Print(towstring(string.format("Global sync started. items=%d", q)))
end

function FastFriends.SyncFinish()
    local s = FastFriends.syncStats or { addOk = 0, remOk = 0, noteOk = 0, fail = 0 }
    local msg = string.format("Global sync done. +%d/-%d, notes=%d, fail=%d",
        tonumber(s.addOk) or 0, tonumber(s.remOk) or 0, tonumber(s.noteOk) or 0, tonumber(s.fail) or 0)
    FastFriends.Print(towstring(msg))
    FastFriends.syncStats = nil
    FastFriends.syncActive = false
    FastFriends.MarkAllLocalListsDirty()
    if FastFriends.rescanAfterSync then
        FastFriends.rescanAfterSync = false
        FastFriends.Update()
    end
end
