-- FastFriends_ConfigUI.lua
-- Configuration UI for the FastFriends addon.

if not FastFriends then FastFriends = {} end

FastFriends.UI = {
    WindowName = "FastFriendsConfigMain",
    _dirty = false
}

-- One-time window creation and static control setup
function FastFriends.UI.CreateWindows()
    if DoesWindowExist and DoesWindowExist(FastFriends.UI.WindowName) then
        return
    end
    CreateWindow(FastFriends.UI.WindowName, true)
    WindowSetShowing(FastFriends.UI.WindowName, false)

    local win = FastFriends.UI.WindowName
    -- Title and buttons
    LabelSetText(win.."TitleBarText", towstring("FastFriends v"..tostring(FastFriends.version).." Settings"))
    ButtonSetText(win.."CloseButton", L"Close")
    ButtonSetText(win.."DefaultsButton", L"Defaults")

    -- Static labels
    LabelSetText(win.."SyncMasterLabel", L"Enable Master Sync")
    LabelSetText(win.."ListFriendsLabel", L"Sync Friends List")
    LabelSetText(win.."ListIgnoreLabel", L"Sync Ignore List")
    LabelSetText(win.."SyncModeLabel", L"Global Sync Mode:")
    LabelSetText(win.."ModeAllLabel", L"All Characters")
    LabelSetText(win.."ModeLevelLabel", L"Characters at or above Level:")
    LabelSetText(win.."ModeOptInLabel", L"Opt-In per Character")
    LabelSetText(win.."CharOverrideLabel", L"This Character's Sync:")
    LabelSetText(win.."CharOverrideDefaultLabel", L"Default")
    LabelSetText(win.."CharOverrideOnLabel", L"On")
    LabelSetText(win.."CharOverrideOffLabel", L"Off")
end

-- Show the settings window
function FastFriends.UI.Show()
    FastFriends.UI.CreateWindows()
    FastFriends.UI._dirty = false
    FastFriends.UI.RefreshControls()
    WindowSetShowing(FastFriends.UI.WindowName, true)
end

-- Close the settings window and save changes
function FastFriends.UI.Close()
    FastFriends.UI.SaveFromControls()
    if FastFriends.UI._dirty and FastFriends.MaybePrintLoginMessage then
        FastFriends.MaybePrintLoginMessage()
    end
    FastFriends.UI._dirty = false
    WindowSetShowing(FastFriends.UI.WindowName, false)
end

-- Update all UI controls to reflect the current settings
function FastFriends.UI.RefreshControls()
    if not FastFriends.db then return end
    local win = FastFriends.UI.WindowName

    -- Master Toggles
    ButtonSetPressedFlag(win.."SyncMasterCheckbox", FastFriends.syncMaster)
    ButtonSetPressedFlag(win.."FriendsCheckbox", FastFriends.listFriends)
    ButtonSetPressedFlag(win.."IgnoreCheckbox", FastFriends.listIgnore)

    -- Sync Mode Radio Buttons
    local mode = FastFriends.syncMode or "opt-in"
    ButtonSetPressedFlag(win.."ModeAllRadio", mode == "all")
    ButtonSetPressedFlag(win.."ModeLevelRadio", mode == "level")
    ButtonSetPressedFlag(win.."ModeOptInRadio", mode == "opt-in")

    -- Min Level EditBox
    TextEditBoxSetText(win.."MinLevelEditBox", towstring(tostring(FastFriends.minLevel or 16)))

    -- Character Override Label with character name
    local nm = tostring(FastFriends.myName or "?")
    LabelSetText(win.."CharOverrideLabel", towstring("This Character's ("..nm..") Sync:"))

    -- Character Override Radio Buttons
    local charOverride = FastFriends.GetCharOverride()
    ButtonSetPressedFlag(win.."CharOverrideDefaultRadio", charOverride == nil)
    ButtonSetPressedFlag(win.."CharOverrideOnRadio", charOverride == true)
    ButtonSetPressedFlag(win.."CharOverrideOffRadio", charOverride == false)

    FastFriends.UI.UpdateEnabledStates()
end

-- Read UI controls and save settings
function FastFriends.UI.SaveFromControls()
    if not FastFriends.db then return end
    local win = FastFriends.UI.WindowName
    local changed = false

    -- Master Sync
    local newMaster = (ButtonGetPressedFlag(win.."SyncMasterCheckbox") and true or false)
    if (FastFriends.syncMaster and true or false) ~= newMaster then changed = true end
    FastFriends.syncMaster = newMaster
    FastFriends.SetSetting("syncMaster", FastFriends.syncMaster, true)
    if not FastFriends.syncMaster then FastFriends.SyncAbort("master off") end

    -- List Toggles
    local newFriends = (ButtonGetPressedFlag(win.."FriendsCheckbox") and true or false)
    if (FastFriends.listFriends and true or false) ~= newFriends then
        changed = true
        FastFriends.MarkLocalListDirty("friend")
    end
    FastFriends.listFriends = newFriends
    FastFriends.SetSetting("listFriends", FastFriends.listFriends, true)
    if not FastFriends.listFriends then FastFriends.SyncAbort("friends disabled") end

    local newIgnore = (ButtonGetPressedFlag(win.."IgnoreCheckbox") and true or false)
    if (FastFriends.listIgnore and true or false) ~= newIgnore then
        changed = true
        FastFriends.MarkLocalListDirty("ignore")
    end
    FastFriends.listIgnore = newIgnore
    FastFriends.SetSetting("listIgnore", FastFriends.listIgnore, true)
    if not FastFriends.listIgnore then FastFriends.SyncAbort("ignore disabled") end

    -- Sync Mode
    local oldMode = tostring(FastFriends.syncMode or "opt-in")
    if ButtonGetPressedFlag(win.."ModeAllRadio") then
        FastFriends.syncMode = "all"
    elseif ButtonGetPressedFlag(win.."ModeLevelRadio") then
        FastFriends.syncMode = "level"
    else
        FastFriends.syncMode = "opt-in"
    end
    if tostring(FastFriends.syncMode or "level") ~= oldMode then changed = true end
    FastFriends.SetSetting("syncMode", FastFriends.syncMode, "opt-in")

    -- Min Level
    local n = tonumber(WStringToString(TextEditBoxGetText(win.."MinLevelEditBox")))
    if n and n >= 1 then
        local oldMin = tonumber(FastFriends.minLevel or 16) or 16
        if n < 1 then n = 1 end
        FastFriends.minLevel = n
        if (tonumber(FastFriends.minLevel or 16) or 16) ~= oldMin then changed = true end
        FastFriends.SetSetting("minLevel", n, 16)
    end

    -- Character Override
    local override = nil
    if ButtonGetPressedFlag(win.."CharOverrideOnRadio") then
        override = true
    elseif ButtonGetPressedFlag(win.."CharOverrideOffRadio") then
        override = false
    end
    local prevOverride = FastFriends.GetCharOverride()
    -- Persist to per-character storage and mirror to global for listing
    if FastFriendsCharDB then FastFriendsCharDB.override = override end
    if FastFriends.db and FastFriends.db._meta and FastFriends.db._meta.charOverrides then
        FastFriends.db._meta.charOverrides[FastFriends.myName] = override
    end
    if override ~= prevOverride then changed = true end
    if override == false then FastFriends.SyncAbort("char override off") end

    -- No chat output here; UI changes should be silent until Close
    if changed then FastFriends.UI._dirty = true end
end

-- Grey out controls that are not applicable based on other settings
function FastFriends.UI.UpdateEnabledStates()
    local win = FastFriends.UI.WindowName
    local masterOn = ButtonGetPressedFlag(win.."SyncMasterCheckbox")
    local isLevelMode = ButtonGetPressedFlag(win.."ModeLevelRadio")

    -- Sub-controls depend on Master Sync
    ButtonSetDisabledFlag(win.."FriendsCheckbox", not masterOn)
    ButtonSetDisabledFlag(win.."IgnoreCheckbox", not masterOn)
    ButtonSetDisabledFlag(win.."ModeAllRadio", not masterOn)
    ButtonSetDisabledFlag(win.."ModeLevelRadio", not masterOn)
    ButtonSetDisabledFlag(win.."ModeOptInRadio", not masterOn)
    ButtonSetDisabledFlag(win.."CharOverrideDefaultRadio", not masterOn)
    ButtonSetDisabledFlag(win.."CharOverrideOnRadio", not masterOn)
    ButtonSetDisabledFlag(win.."CharOverrideOffRadio", not masterOn)

    -- Min Level edit box is not a Button; disable input instead when not applicable
    local enableMin = masterOn and isLevelMode
    if WindowSetHandleInput then WindowSetHandleInput(win.."MinLevelEditBox", enableMin) end
end

-- Event Handlers for UI controls
function FastFriends.UI.OnToggleSyncMaster()
    local win = FastFriends.UI.WindowName
    local cur = (FastFriends.syncMaster and true or false)
    local newPressed = not cur
    FastFriends.syncMaster = newPressed and true or false
    ButtonSetPressedFlag(win.."SyncMasterCheckbox", (newPressed == true))
    FastFriends.SetSetting("syncMaster", FastFriends.syncMaster, true)
    if not FastFriends.syncMaster then FastFriends.SyncAbort("master off") end
    FastFriends.UI.UpdateEnabledStates()
    FastFriends.UI._dirty = true
end

function FastFriends.UI.OnModeChanged()
    local win = FastFriends.UI.WindowName
    local active = SystemData.ActiveWindow.name
    local mode
    if active == win.."ModeAllRadio" then mode = "all"
    elseif active == win.."ModeLevelRadio" then mode = "level"
    else mode = "opt-in" end
    FastFriends.UI.SetSyncMode(mode)
end

-- Helper to set sync mode consistently from either radio or label clicks
function FastFriends.UI.SetSyncMode(mode)
    local win = FastFriends.UI.WindowName
    local desired = tostring(mode or "opt-in")
    if desired ~= "all" and desired ~= "level" and desired ~= "opt-in" then desired = "level" end
    -- If radios are disabled, ignore
    if ButtonGetDisabledFlag and ButtonGetDisabledFlag(win.."ModeAllRadio") then return end
    local prev = tostring(FastFriends.syncMode or "opt-in")
    FastFriends.syncMode = desired
    ButtonSetPressedFlag(win.."ModeAllRadio", desired == "all")
    ButtonSetPressedFlag(win.."ModeLevelRadio", desired == "level")
    ButtonSetPressedFlag(win.."ModeOptInRadio", desired == "opt-in")
    FastFriends.SetSetting("syncMode", FastFriends.syncMode, "opt-in")
    FastFriends.UI.UpdateEnabledStates()
    if tostring(FastFriends.syncMode or "level") ~= prev then FastFriends.UI._dirty = true end
end

-- Helper to update the per-character override selection
function FastFriends.UI.SetCharOverride(selection)
    local win = FastFriends.UI.WindowName
    local target
    if selection == "on" then
        target = win.."CharOverrideOnRadio"
    elseif selection == "off" then
        target = win.."CharOverrideOffRadio"
    else
        selection = "default"
        target = win.."CharOverrideDefaultRadio"
    end

    if ButtonGetDisabledFlag and ButtonGetDisabledFlag(target) then return end

    local override = nil
    if selection == "on" then
        override = true
    elseif selection == "off" then
        override = false
    end

    local prevOverride = FastFriends.GetCharOverride()
    if FastFriendsCharDB then FastFriendsCharDB.override = override end
    if FastFriends.db and FastFriends.db._meta and FastFriends.db._meta.charOverrides then
        FastFriends.db._meta.charOverrides[FastFriends.myName] = override
    end

    ButtonSetPressedFlag(win.."CharOverrideDefaultRadio", override == nil)
    ButtonSetPressedFlag(win.."CharOverrideOnRadio", override == true)
    ButtonSetPressedFlag(win.."CharOverrideOffRadio", override == false)

    if override == false then FastFriends.SyncAbort("char override off") end
    if override ~= prevOverride then FastFriends.UI._dirty = true end
end

function FastFriends.UI.OnCharOverrideChanged()
    local win = FastFriends.UI.WindowName
    local active = SystemData.ActiveWindow.name
    if active == win.."CharOverrideOnRadio" then
        FastFriends.UI.SetCharOverride("on")
    elseif active == win.."CharOverrideOffRadio" then
        FastFriends.UI.SetCharOverride("off")
    else
        FastFriends.UI.SetCharOverride("default")
    end
end

function FastFriends.UI.OnToggleFriends()
    local win = FastFriends.UI.WindowName
    if ButtonGetDisabledFlag and ButtonGetDisabledFlag(win.."FriendsCheckbox") then return end
    local cur = (FastFriends.listFriends and true or false)
    local newPressed = not cur
    FastFriends.listFriends = newPressed and true or false
    ButtonSetPressedFlag(win.."FriendsCheckbox", (newPressed == true))
    FastFriends.SetSetting("listFriends", FastFriends.listFriends, true)
    if not FastFriends.listFriends then FastFriends.SyncAbort("friends disabled") end
    FastFriends.UI._dirty = true
end

function FastFriends.UI.OnToggleIgnore()
    local win = FastFriends.UI.WindowName
    if ButtonGetDisabledFlag and ButtonGetDisabledFlag(win.."IgnoreCheckbox") then return end
    local cur = (FastFriends.listIgnore and true or false)
    local newPressed = not cur
    FastFriends.listIgnore = newPressed and true or false
    ButtonSetPressedFlag(win.."IgnoreCheckbox", (newPressed == true))
    FastFriends.SetSetting("listIgnore", FastFriends.listIgnore, true)
    if not FastFriends.listIgnore then FastFriends.SyncAbort("ignore disabled") end
    FastFriends.UI._dirty = true
end

-- Label click support: clicking the text toggles the associated
-- checkbox visually, then calls the checkbox's original handler.
local function ff_toggle_from_label(relCheckboxName, originalHandler)
    local win = FastFriends.UI.WindowName
    local full = win..relCheckboxName
    if ButtonGetDisabledFlag and ButtonGetDisabledFlag(full) then return end
    ButtonSetPressedFlag(full, not ButtonGetPressedFlag(full))
    if originalHandler then originalHandler() end
end

function FastFriends.UI.OnClickSyncMasterLabel()
    ff_toggle_from_label("SyncMasterCheckbox", FastFriends.UI.OnToggleSyncMaster)
end

function FastFriends.UI.OnClickFriendsLabel()
    ff_toggle_from_label("FriendsCheckbox", FastFriends.UI.OnToggleFriends)
end

function FastFriends.UI.OnClickIgnoreLabel()
    ff_toggle_from_label("IgnoreCheckbox", FastFriends.UI.OnToggleIgnore)
end

function FastFriends.UI.OnMinLevelCommit()
    local win = FastFriends.UI.WindowName
    local n = tonumber(WStringToString(TextEditBoxGetText(win.."MinLevelEditBox")))
    if not n or n < 1 then
        TextEditBoxSetText(win.."MinLevelEditBox", towstring(tostring(FastFriends.minLevel or 16)))
        return
    end
    if n < 1 then n = 1 end
    local oldMin = tonumber(FastFriends.minLevel or 16) or 16
    FastFriends.minLevel = n
    FastFriends.SetSetting("minLevel", n, 16)
    TextEditBoxSetText(win.."MinLevelEditBox", towstring(tostring(n)))
    if n ~= oldMin then FastFriends.UI._dirty = true end
end

function FastFriends.UI.OnRestoreDefaults()
    -- Reset all settings to their default values
    FastFriends.syncMaster = true
    FastFriends.listFriends = true
    FastFriends.listIgnore = true
    FastFriends.syncMode = "opt-in"
    FastFriends.minLevel = 16
    if FastFriendsCharDB then FastFriendsCharDB.override = nil end
    if FastFriends.db and FastFriends.db._meta and FastFriends.db._meta.charOverrides then
        FastFriends.db._meta.charOverrides[FastFriends.myName] = nil
    end

    -- Clear from saved variables
    FastFriends.SetSetting("syncMaster", nil, nil)
    FastFriends.SetSetting("listFriends", nil, nil)
    FastFriends.SetSetting("listIgnore", nil, nil)
    FastFriends.SetSetting("syncMode", nil, nil)
    FastFriends.SetSetting("minLevel", nil, nil)

    -- Refresh the UI to show the new default values
    FastFriends.UI.RefreshControls()
    FastFriends.UI._dirty = true
end

-- Label clicks for radio options
function FastFriends.UI.OnClickModeAllLabel()
    FastFriends.UI.SetSyncMode("all")
end

function FastFriends.UI.OnClickModeLevelLabel()
    FastFriends.UI.SetSyncMode("level")
end

function FastFriends.UI.OnClickModeOptInLabel()
    FastFriends.UI.SetSyncMode("opt-in")
end

function FastFriends.UI.OnClickCharOverrideDefaultLabel()
    FastFriends.UI.SetCharOverride("default")
end

function FastFriends.UI.OnClickCharOverrideOnLabel()
    FastFriends.UI.SetCharOverride("on")
end

function FastFriends.UI.OnClickCharOverrideOffLabel()
    FastFriends.UI.SetCharOverride("off")
end
