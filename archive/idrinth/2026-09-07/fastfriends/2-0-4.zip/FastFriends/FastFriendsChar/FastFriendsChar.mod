<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
    <UiMod name="FastFriendsChar" version="1.0" date="2026-03-27">
        <Author name="Wholdar" />
        <Description text="Per-character data storage for FastFriends." />
        <VersionSettings gameVersion="1.4.8" />
        <!-- No dependencies: acts as a lightweight data holder. Loaded before FastFriends via FastFriends' dependency. -->
        <Files>
            <File name="FastFriendsChar.lua" />
        </Files>
        <OnInitialize>
            <CallFunction name="FastFriendsChar.OnInitialize" />
        </OnInitialize>
        <SavedVariables>
            <SavedVariable name="FastFriendsCharDB" />
        </SavedVariables>
    </UiMod>
</ModuleFile>
