-- FastFriendsChar.lua
-- Minimal per-character data holder for FastFriends

FastFriendsChar = {}

function FastFriendsChar.OnInitialize()
    -- Ensure the per-character database exists
    if FastFriendsCharDB == nil then
        FastFriendsCharDB = {}
    end
end

