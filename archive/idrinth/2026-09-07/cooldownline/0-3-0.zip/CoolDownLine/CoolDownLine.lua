
CoolDownLine = {}
NextUp = 0
ANIMATIONTIMER = {}
local Cools2={}
local GetHotbarData = GetHotbarData
local GetHotbarCooldown = GetHotbarCooldown

if not MaxLength or MaxLength == nil then
MaxLength = 750 --750
end
if not MaxHeight or MaxHeight == nil then
MaxHeight = 40--40
end

if not CDLSAVES or CDLSAVES == nil then
CDLSAVES = {}
CDLSAVES.Offset = -50
end



function CoolDownLine.Initialize()

	LibSlash.RegisterSlashCmd("CDL", function(input) HandleSlash(input) end)
	
--Announce that the addon is loaded
	TextLogAddEntry("Chat", 0, L"<icon=57> CoolDownLine v0.3B Loaded. W:"..towstring(MaxLength)..L",H:"..towstring(MaxHeight)..L", Offset:"..towstring(CDLSAVES.Offset))

--Make the main window/bar
	CreateWindow("CoolDownLineWnd", true)

--If abilitys are switched or annything change, update the hotbars and re-register all abilitys
	RegisterEventHandler(SystemData.Events.PLAYER_HOT_BAR_UPDATED,"CoolDownLine.RegisterAbilities")
	RegisterEventHandler(SystemData.Events.ENTER_WORLD,"CoolDownLine.RegisterAbilities")
	RegisterEventHandler(SystemData.Events.INTERFACE_RELOADED,"CoolDownLine.RegisterAbilities")
	RegisterEventHandler(SystemData.Events.LOADING_END,"CoolDownLine.RegisterAbilities")
	
--The texts marks
	LabelSetText("10secTimeValue",L"10s")	
	LabelSetText("30secTimeValue",L"30s")	
	LabelSetText("1minTimeValue",L"1m")	
	LabelSetText("10minTimeValue",L"10m")

--set the cooldown animations to 0 (stop them from animating)
Animationtimer = 0		
StartAnimation = 0	

end

function CoolDownLine.OnUpdate( timeElapsed )--this is whats running every frame
	WindowSetDimensions("CoolDownLineWnd",MaxLength,MaxHeight)
	WindowSetOffsetFromParent("10secBG2",(MaxLength*0.25) , 1)
	WindowSetDimensions("10secBG2",2,MaxHeight-2)
	WindowSetOffsetFromParent("30secBG2",(MaxLength*0.50) , 1)
	WindowSetDimensions("30secBG2",2,MaxHeight-2)
	WindowSetOffsetFromParent("60secBG2",(MaxLength*0.75) , 1)
	WindowSetDimensions("60secBG2",2,MaxHeight-2)	
	WindowSetDimensions("CoolDownLineWndIcon",MaxHeight-4,MaxHeight-4)
	WindowSetDimensions("CoolDownLineWndFrame",MaxHeight-2,MaxHeight-2)
	
LowestCD = 9999		-- annything above this, i don't even bother showing
NextUp = nil		--next ability to be ready, start by setting it to nothing
DynamicImageSetTexture("CoolDownLineWndIcon","icon000020", 62, 62)		--sets the next-up-ability icon to empty
LabelSetText("NextCDValue",L"")		--clears the next-up-ability timer

for i=0,121	do		--goes throu every Hotbar slot, one at a time
	local windowName = "CoolDownLineWnd"..i		--assigns a window name to slots, "CoolDownLineWnd0" to "CoolDownLineWnd121"
	local Fader = tonumber(wstring.format(L"%.01f",GetHotbarCooldown(i)))
	if GetHotbarCooldown(i) > 1.6 and GetHotbarCooldown(i) < 600 then --if the cooldown is above the Global cooldown (else it would show even abilitys w/o a cooldown)
		Cools2[i].ISONCOOLDOWN = true 		--set the hotbar slot to ISONCOOLDOWN if above statement is true..
	elseif GetHotbarCooldown(i) < 0.01 then	
		Cools2[i].ISONCOOLDOWN = false		--else ISONCOOLDOWN gets set to false..
		if ( DoesWindowExist( windowName ) ) then DestroyWindow(windowName);StartAnimation = 1 end	--and if it is false, destroy the window (or they will be stacking upp infinitly)
	end
	if Cools2[i].ISONCOOLDOWN == true then

		--Setting up the icon for ability with the Lowest cooldown on the Line
		if GetHotbarCooldown(i) < LowestCD then LowestCD = GetHotbarCooldown(i); NextUp = i end
		if NextUp ~= nil then
		local Nexticon = GetHotbarIcon(NextUp)	
		local Nexttime = TimeUtils.FormatTimeCondensed(GetHotbarCooldown(NextUp))
		LabelSetText("NextCDValue",towstring(Nexttime))
		if Nexticon < 10000 and Nexticon > 1000 then
		DynamicImageSetTexture("CoolDownLineWndIcon",tostring(L"icon00"..towstring(Nexticon)), 62, 62)	
		elseif Nexticon < 1000  and Nexticon > 100 then
		DynamicImageSetTexture("CoolDownLineWndIcon",tostring(L"icon000"..towstring(Nexticon)), 62, 62)
		elseif Nexticon < 100	then
		DynamicImageSetTexture("CoolDownLineWndIcon",tostring(L"icon0000"..towstring(Nexticon)), 62, 62)
		else 
		DynamicImageSetTexture("CoolDownLineWndIcon",tostring(L"icon0"..towstring(Nexticon)), 62, 62)			
		end		
	end
				
	if ( DoesWindowExist( windowName ) ) then 
	
	WindowSetDimensions(tostring(towstring(windowName)..L"A"),MaxHeight-7,MaxHeight-7)
	WindowSetDimensions(tostring(towstring(windowName)..L"AFlash"),MaxHeight+16,MaxHeight+16)
	
	if (ANIMATIONTIMER[windowName] > 0) then ANIMATIONTIMER[windowName] = ANIMATIONTIMER[windowName]-timeElapsed end	
		
	if ANIMATIONTIMER[windowName] <= 0 then AnimatedImageStopAnimation(tostring(towstring(windowName)..L"AFlash")) end	
	
	WindowSetShowing( windowName, true )  
	WindowSetOffsetFromParent(tostring(towstring(windowName)..L"BTimeValue"),-10, 45+CDLSAVES.Offset)
	
	if GetHotbarCooldown(i) < 1 then
	WindowSetAlpha(tostring(windowName),Fader)
	else
	WindowSetAlpha(tostring(windowName),1)
	end
		
 	if GetHotbarCooldown(i) < 10 then
	--WindowSetOffsetFromParent(windowName, math.floor(GetHotbarCooldown(i)*(28+(20-(GetHotbarCooldown(i)*2)))), -6)
	--WindowSetOffsetFromParent(windowName, ((GetHotbarCooldown(i)/10)*(MaxLength*0.25)), -6)

	--Here's some MatheMagics to get the icons working, God i hate math(because i'm realy terrible at it)
	--WindowSetOffsetFromParent(windowName, ((GetHotbarCooldown(i)/10)*(MaxLength*0.25)), -6)
	WindowSetOffsetFromParent(windowName, ((GetHotbarCooldown(i)/10)*(MaxLength*(2-(GetHotbarCooldown(i)/15))))*0.1875, -6)
	LabelSetText(tostring(towstring(windowName)..L"BTimeValue"),wstring.format(L"%.01f",towstring(GetHotbarCooldown(i))))
	elseif GetHotbarCooldown(i) > 10 and GetHotbarCooldown(i) < 30 then
	WindowSetOffsetFromParent(windowName, (MaxLength*0.125)+((GetHotbarCooldown(i)/20)*(MaxLength*0.25)) , -6) 	
	local testtime = TimeUtils.FormatSeconds(GetHotbarCooldown(i), true)
	LabelSetText(tostring(towstring(windowName)..L"BTimeValue"),testtime)	
	elseif GetHotbarCooldown(i) > 30 and GetHotbarCooldown(i) < 60 then
	WindowSetOffsetFromParent(windowName, (MaxLength*0.25)+((GetHotbarCooldown(i)/30)*(MaxLength*0.25)) , -6)
	local testtime = TimeUtils.FormatTimeCondensed(GetHotbarCooldown(i))
	LabelSetText(tostring(towstring(windowName)..L"BTimeValue"),testtime)	
	elseif GetHotbarCooldown(i) > 60 and GetHotbarCooldown(i) < 600 then
	WindowSetOffsetFromParent(windowName, (MaxLength*0.75)+(((GetHotbarCooldown(i)-60)/600)*(MaxLength*0.25)), -6)
	
	local testtime = TimeUtils.FormatTimeCondensed(GetHotbarCooldown(i))
	LabelSetText(tostring(towstring(windowName)..L"BTimeValue"),testtime)	
	end	
	else
	CreateWindowFromTemplate( windowName, "CoolDownLineICONTemplate", "CoolDownLineWnd" )
	AnimatedImageStartAnimation (tostring(towstring(windowName)..L"AFlash"), 0, true, true, 0)
	ANIMATIONTIMER[windowName] = 0.6
	WindowSetShowing( windowName, false ) 
	WindowSetParent(windowName,"CoolDownLineWnd")
	if GetHotbarIcon(i) < 10000 and GetHotbarIcon(i) > 1000 then
	DynamicImageSetTexture(tostring(towstring(windowName)..L"AIcon"),tostring(L"icon00"..towstring(GetHotbarIcon(i))), 62, 62)
	elseif GetHotbarIcon(i) < 1000 and GetHotbarIcon(i) > 100 then
	DynamicImageSetTexture(tostring(towstring(windowName)..L"AIcon"),tostring(L"icon000"..towstring(GetHotbarIcon(i))), 62, 62)
	elseif GetHotbarIcon(i) < 100 then
	DynamicImageSetTexture(tostring(towstring(windowName)..L"AIcon"),tostring(L"icon0000"..towstring(GetHotbarIcon(i))), 62, 62)	
	else
	DynamicImageSetTexture(tostring(towstring(windowName)..L"AIcon"),tostring(L"icon0"..towstring(GetHotbarIcon(i))), 62, 62)
	end
	end
end
end

if StartAnimation == 1 then
WindowSetDimensions("CoolDownLineWndFlash",MaxHeight+14,MaxHeight+14)
WindowSetShowing ("CoolDownLineWndFlash", true)
AnimatedImageStartAnimation ("CoolDownLineWndFlash", 0, true, true, 0)
StartAnimation = 0
Animationtimer = 0.6
end

	if Animationtimer > 0 then
	Animationtimer = Animationtimer - timeElapsed
	else
	AnimatedImageStopAnimation ("CoolDownLineWndFlash")
	end
end

function CoolDownLine.RegisterAbilities()
	local abilityData,ID,cooldown,TYPE
	Cools2={}
	for i=0,121	do
	Cools2[i] = {}
Cools2[i].ISONCOOLDOWN = false	
TYPE,ID=GetHotbarData(i)
abilityData=GetAbilityData(ID)
Cools2[i].ABDATA = abilityData
Cools2[i].ABID = ID
Cools2[i].ABTYPE = TYPE
end
end

function HandleSlash(action)	--Slashcommands 
	local input1 = string.sub(action,0,string.find(action," "))
	if string.find(action," ") ~= nil then
		input1 = string.sub(action,0,string.find(action," ")-1)
		input2 = string.sub(action,string.find(action," ")+1,-1)
	end

	if input1 == "width" then MaxLength = tonumber(input2)
	elseif input1 == "height" then MaxHeight = tonumber(input2)
	elseif input1 == "offset" then CDLSAVES.Offset = tonumber(input2)
	elseif input1 == "default" then MaxLength = 750;MaxHeight = 40;CDLSAVES.Offset = -50
end
end





