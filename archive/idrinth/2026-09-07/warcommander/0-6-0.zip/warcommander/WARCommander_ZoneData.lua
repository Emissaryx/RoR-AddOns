

-- in here till they get updated in MapMonster main files
WARCommander_ZoneInfo={}
WARCommander_ZoneInfo[33]  = { offsetX  = 32652,   offsetY  = 34113, -- Doomfist Crater
                             mapsizeX = 13119,   mapsizeY = 13119,
                             chunkX   = 65536,   chunkY   = 65536 }
                
                
                             
WARCommander_ZoneInfo[232] = { offsetX  = 26146,   offsetY  = 34407, -- Tor Anroc
                             mapsizeX = 20448,   mapsizeY = 20448,
                             chunkX   = 65536,   chunkY   = 65536 }
     
     
-- Black Fire Basin --                           
WARCommander_ZoneInfo[38]  = { offsetX  = 33244,   offsetY  = 28354, -- Black Fire Basin ??
                             mapsizeX = 19552,   mapsizeY = 19552,
                             chunkX   = 65536,   chunkY   = 65536 }

-- Temple of Isha --
WARCommander_ZoneInfo[236] = { offsetX  = 32324,   offsetY  = 32859, -- Temple of Isha ??
                             mapsizeX = 18336,   mapsizeY = 18336,
                             chunkX   = 65536,   chunkY   = 65536 }


-- Talabec Dam --
WARCommander_ZoneInfo[132] = { offsetX  = 28487,   offsetY  = 29289, -- Talabec Dam ??
                             mapsizeX = 21440,   mapsizeY = 21440,
                             chunkX   = 65536,   chunkY   = 65536 }

-- High Pass Cemetery --
WARCommander_ZoneInfo[139] = { offsetX  = 32730,   offsetY  = 33701, -- High Pass Cemetery ??
                             mapsizeX = 9216,   mapsizeY = 9216,
                             chunkX   = 65536,   chunkY   = 65536 }


                      
--- Tier 4 
                             
                             
-- Howling Gorge --                             
WARCommander_ZoneInfo[44]  = { offsetX  = 26470,   offsetY  = 29102, -- Howling Gorge ??
                             mapsizeX = 17984,   mapsizeY = 17984,
                             chunkX   = 65536,   chunkY   = 65536 }

                             
-- Battle for Praag -- 
WARCommander_ZoneInfo[136] = { offsetX  = 35309,   offsetY  = 34963, -- Battle for Praag ??
                             mapsizeX = 19744,   mapsizeY = 19744,
                             chunkX   = 65536,   chunkY   = 65536 }

-- Serpent's Passage --                             
WARCommander_ZoneInfo[234] = { offsetX  = 37009,   offsetY  = 36096, -- Serpent's Passage ??
                             mapsizeX = 16704,   mapsizeY = 16704,
                             chunkX   = 65536,   chunkY   = 65536 }
                             
-- Dragon's Bane --
WARCommander_ZoneInfo[235] = { offsetX  = 29340,   offsetY  = 33540, -- Dragon's Bane ??
                             mapsizeX = 22848,   mapsizeY = 22848,
                             chunkX   = 65536,   chunkY   = 65536 }
                             
                                                        
-- Maw of Madness --
WARCommander_ZoneInfo[133] = { offsetX  = 31417,   offsetY  = 36843, -- Maw of Madness ??
                             mapsizeX = 16512,   mapsizeY = 16512,
                             chunkX   = 65536,   chunkY   = 65536 }

-- Caledor Woods --
WARCommander_ZoneInfo[237] = { offsetX  = 22913,   offsetY  = 30567, -- Caledor Woods ??
                             mapsizeX = 20608,   mapsizeY = 20608,
                             chunkX   = 65536,   chunkY   = 65536 }

-- Blood of the Black Cairn --
WARCommander_ZoneInfo[238] = { offsetX  = 23588,   offsetY  = 31368, -- Blood of the Black Cairn ??
                             mapsizeX = 18688,   mapsizeY = 18688,
                             chunkX   = 65536,   chunkY   = 65536 }
                             
-- Logrin's Forge --                            
WARCommander_ZoneInfo[39]  = { offsetX  = 23432,   offsetY  = 31086, -- Logrin's Forge ??
                             mapsizeX = 18400,   mapsizeY = 18400,
                             chunkX   = 65536,   chunkY   = 65536 }                             

-- Thunder Valley --                             
--WARCommander_ZoneInfo[34]  = { offsetX  = 34610,   offsetY  = 29975, -- Thunder Valley ??
WARCommander_ZoneInfo[34]  = { offsetX  = 34610,   offsetY  = 554266, -- Thunder Valley ??
                             mapsizeX = 20832,   mapsizeY = 20832,
                             chunkX   = 65536,   chunkY   = 65536 }
-- Grovod Caverns --                            
WARCommander_ZoneInfo[137] = { offsetX  = 45201,   offsetY  = 33638, -- Grovod Caverns ??
                             mapsizeX = 10624,   mapsizeY = 10624,
                             chunkX   = 65536,   chunkY   = 65536 }

                             
-- Reikland Hills --
WARCommander_ZoneInfo[134] = { offsetX  = 29635,   offsetY  = 35702, -- Reikland Hills ??
                             mapsizeX = 18880,   mapsizeY = 18880,
                             chunkX   = 65536,   chunkY   = 65536 }


-- Gromril Crossing --
WARCommander_ZoneInfo[43]  = { offsetX  = 20850,   offsetY  = 21538, 
                             mapsizeX = 21376,   mapsizeY = 21376,
                             chunkX   = 65536,   chunkY   = 65536 }
                             
-- Contested Altdorf

WARCommander_ZoneInfo[168] = { offsetX  = 14439,  offsetY  = 743177, -- Altdorf
                             mapsizeX = 41760,   mapsizeY = 41760, }
                             
                             
WARCommander_ZoneInfo[41]  = { offsetX  = 17253,  offsetY  = 293432, -- Altdorf War Quarter
                            mapsizeX = 32620,   mapsizeY = 32620, }      
                            
-- Contested IC 

WARCommander_ZoneInfo[167] = { offsetX  = 19103,  offsetY  = 220590, -- IC
                             mapsizeX = 44000,   mapsizeY = 44000, }
                             

WARCommander_ZoneInfo[42] = { offsetX  = 19198,  offsetY  = 28296, -- Undercroft
                             mapsizeX = 40178,   mapsizeY = 40178, }
                             
                           
                  
                  
---- Land of the Dead

-- Necropolis of Zandri

WARCommander_ZoneInfo[191] = { offsetX  = 196866,  offsetY  = 1490741,
                             mapsizeX = 65536,   mapsizeY = 65536, }
                                                          