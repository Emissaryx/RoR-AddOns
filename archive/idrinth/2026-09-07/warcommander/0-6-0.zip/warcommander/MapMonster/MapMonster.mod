<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
	<UiMod name="MapMonster" version="0.3" date="02/12/2008">
        <VersionSettings gameVersion="1.3.3" windowsVersion="1.0" savedVariablesVersion="1.0" />
		<Author name="Bloodscar" email="" />
		<Description text="Full featured Addon to manage all your MapPins" />
		<Dependencies>
			<Dependency name="EA_ChatWindow"/>
			<Dependency name="EA_ContextMenu"/>
			<Dependency name="EA_WorldMapWindow"/>
			<Dependency name="EASystem_Tooltips"/>
			<Dependency name="EA_HelpTips"/>
			<Dependency name="LibSlash"/>
			<Dependency name="LibDateTime-Modified"/>
			<!-- extra dependencies to make sure 
			all the textures are loaded first -->
			<Dependency name="EA_CraftingSystem"/>
			<Dependency name="EA_ScenarioSummaryWindow"/>
			<Dependency name="EATemplate_Icons"/>
			<Dependency name="EA_MenuBarWindow"/>
			<Dependency name="EATemplate_ParchmentWindowSkin"/>
		</Dependencies>
		<Files>
			<File name="Textures/Textures.xml" />
			<File name="Libs/LibStub.lua" />
			<File name="Libs/LibToolkit.lua" />
			<File name="Libs/AceLocale-3.0/AceLocale-3.0.lua" />
			<File name="Lang/enUS.lua" />
			<File name="Source/MapMonster.lua" />
			<File name="Source/MapMonster_Templates.xml" />
			<File name="Source/MapMonster_Tooltips.xml" />
			<File name="Source/MapMonster_Tooltips.lua" />
			<!--@alpha@
			<!--<File name="Source/MapMonster_Tools.lua" />-->
			@end-alpha@-->
			<File name="Source/MapMonster_ZoneData.lua" />
			<File name="Source/MapMonster_Zone.lua" />
			<File name="Source/MapMonster_Player.lua" />
			<File name="Source/MapMonster_Navigation.lua" />
			<File name="Source/MapMonster_Pins.lua" />
			<File name="Source/MapMonster_EditorWindow.lua" />
			<File name="Source/MapMonster_EditorWindow.xml" />
			<File name="Source/MapMonster_PinTypeEditorWindow.lua" />
			<File name="Source/MapMonster_PinTypeEditorWindow.xml" />
			<File name="Source/MapMonster_Calibrate.lua" />
			<File name="Source/MapMonster_Calibrate.xml" />
			<!--@alpha@
			
			@end-alpha@-->
		</Files>

		<OnInitialize>
			<CallFunction name="MapMonster.Initialize" />
			<CallFunction name="MapMonster_Calibrate.Initialize" />
		</OnInitialize>

		<OnUpdate>
			<CallFunction name="MapMonster_Tooltip_Update" />
		</OnUpdate>
		
		<SavedVariables>
			<SavedVariable name="MM_PinTypes" />
			<SavedVariable name="MM_PinStorage" />
			<SavedVariable name="MM_Settings" />
			<SavedVariable name="MapMonster.PinTypes" />
			<SavedVariable name="MapMonster.PinStorage" />
			<SavedVariable name="MapMonster.Settings" />
			<SavedVariable name="MapMonster_CalibratedOffset" />
			<SavedVariable name="MapMonster_CalibratedMapSize" />
			<!--@alpha@
			<!--<SavedVariable name="MapMonster_Tools.Positions" />-->
			@end-alpha@-->
		</SavedVariables>
	</UiMod>
</ModuleFile>