--------------------------------------------------------------------------------
-- Copyright (c) 2008 Bloodwalker <metagamegeek@gmail.com>
-- 
-- Permission is hereby granted, free of charge, to any person obtaining a copy
-- of this software and associated documentation files (the "Software"), to deal
-- in the Software without restriction, including without limitation the rights
-- to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
-- copies of the Software, and to permit persons to whom the Software is
-- furnished to do so, subject to the following conditions:

-- The above copyright notice and this permission notice shall be included in
-- all copies or substantial portions of the Software.

-- THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
-- IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
-- FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
-- AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
-- LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
-- OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
-- THE SOFTWARE.
--
--------------------------------------------------------------------------------
--
-- Starting points for zone offsets and mapsize taken from Nevir27's work on
-- LibSurveyor, all other data and code is original
--
--------------------------------------------------------------------------------
-- File:      Source/MapMonster_Player.lua
-- Date:      2009-01-24T18:58:55Z
-- Author:    Bloodwalker <metagamegeek@gmail.com>
-- Version:   Beta v0.3.11
-- Revision:  109
-- File Rev:  109
-- Copyright: 2008
--------------------------------------------------------------------------------
if not MapMonster or not MapMonster.CoreLoaded then return end --shortcut loading the file if the core didnt load
local LibToolkit = LibStub("LibToolkit-0.1")
--------------------------------------------------------------------------------
--#
--#			Local Definitions
--#
--------------------------------------------------------------------------------
local isLoading = true
local playerPosition = {}
local playerDirection = 0

--------------------------------------------------------------------------------
--#
--#			Global MapMonster Player Event Handlers and Functions
--#
--------------------------------------------------------------------------------
MapMonster.PlayerFileLoaded = true

function MapMonster.InitializePlayer()

	RegisterEventHandler(SystemData.Events.LOADING_BEGIN, "MapMonster.OnLoadingBegin")
	RegisterEventHandler(SystemData.Events.LOADING_END, "MapMonster.OnLoadingEnd")
	RegisterEventHandler(SystemData.Events.INTERFACE_RELOADED, "MapMonster.OnLoadingEnd")
	RegisterEventHandler(SystemData.Events.PLAYER_ZONE_CHANGED, "MapMonster.OnPlayerZoneChanged")
	RegisterEventHandler(SystemData.Events.PLAYER_POSITION_UPDATED, "MapMonster.OnPlayerPositionUpdated")

end

function MapMonster.ShutdownPlayer()

	UnregisterEventHandler(SystemData.Events.LOADING_BEGIN, "MapMonster.OnLoadingBegin")
	UnregisterEventHandler(SystemData.Events.LOADING_END, "MapMonster.OnLoadingEnd")
	UnregisterEventHandler(SystemData.Events.INTERFACE_RELOADED, "MapMonster.OnLoadingEnd")
	UnregisterEventHandler(SystemData.Events.PLAYER_ZONE_CHANGED, "MapMonster.OnPlayerZoneChanged")
	UnregisterEventHandler(SystemData.Events.PLAYER_POSITION_UPDATED, "MapMonster.OnPlayerPositionUpdated")

end

function MapMonster.OnPlayerPositionUpdated(worldX, worldY)
    
    -- update the player's current location
    local newPos = {
        zoneId = GameData.Player.zone,
        worldX = worldX,
        worldY = worldY,
    }
        
    -- Raw direction calculations
	if playerPosition.zoneId ~= newPos.zoneId then
		local zoneInfo = MapMonsterAPI.GetZoneData(fromPosition.zoneId)
		if not zoneInfo.sharedWorld or not zoneInfo.sharedWorld[toPosition.zoneId] then
			playerDirection = 0
		end
	else
		local fromX = playerPosition.worldX or 0
		local fromY = playerPosition.worldY or 0
		local toX, toY = newPos.worldX, newPos.worldY
		local angle = math.deg( math.atan2( (toY - fromY), (toX - fromX) ) )
		angle = angle + 90
		if angle < 0 then
			angle = angle + 360
		end

		playerDirection = tonumber(string.format("%.0f", angle))
	
	end
		
    playerPosition = newPos
    
end

function MapMonster.OnPlayerZoneChanged(zoneId)

	if (zoneId > 0 and not isLoading) then
		-- make sure we at least have a zoneId for wherever we are, even if we haven't moved yet
		playerPosition.zoneId = zoneId
		-- make sure to reset X,Y since there's no guarantee we're in the same part of the world
		playerPosition.worldX = nil
		playerPosition.worldY = nil
		-- post error msg if we dont have offset data for this zone
		if not MapMonsterAPI.GetZoneData(zoneId) then
			MapMonster.ERROR_CODE = 101
			local errorCode, errorMsg = MapMonsterAPI.GetError()
			d("Zone error for zone = " .. zoneId)
			MapMonster.print(errorMsg)
		end
	end

end

function MapMonster.OnLoadingBegin()
		isLoading = true
end

function MapMonster.OnLoadingEnd()
		isLoading = false
		-- PLAYER_ZONE_CHANGED not fired when its the first login of your session 
		-- so we make sure to have a good zone id by the time loading ends		
		playerPosition.zoneId = GameData.Player.zone
		
end


--------------------------------------------------------------------------------
--# Do not use this, only for map calibration functions
--#
--------------------------------------------------------------------------------
function MapMonster.GetTruePosition()
	return playerPosition
end
--------------------------------------------------------------------------------
--#
--#			MapMonster API Functions
--#
--------------------------------------------------------------------------------

--------------------------------------------------------------------------------
--#	Function: MapMonsterAPI.GetPlayerPosition()
--#		Returns the players current position in the world
--#
--#	Parameters:
--#		none
--#	Returns:
--#		table -(table) Returns a table containing the players most recent
--#						validated position
--#	Notes:
--#		Table includes, zoneId, world, and zone position if available
--#
--------------------------------------------------------------------------------
function MapMonsterAPI.GetPlayerPosition()

	--[===[@alpha@
	--d("Get Player Position")
	--@end-alpha@]===]
	if isLoading then
		MapMonster.ERROR_CODE = 102
		return false -- calling too early we have nothing
	end

	-- check for world pos data
	if (playerPosition.worldX == nil or playerPosition.worldY == nil ) then
		return { zoneId = playerPosition.zoneId } -- no world pos return just the zoneId
	end

	-- get the current position in the world
	local playerWorldPos = {zoneId = playerPosition.zoneId,
							worldX = LibToolkit.roundNum(playerPosition.worldX),
							worldY = LibToolkit.roundNum(playerPosition.worldY),}
	
	-- use the cached playerpos if we have it
	if playerPosition.zoneX and playerPosition.zoneY then
		playerWorldPos.zoneX = playerPosition.zoneX
		playerWorldPos.zoneY = playerPosition.zoneY
		return playerWorldPos
	end

	local function _trimWorldPos(oldPos, maxPos)
		local newPos = oldPos
		while newPos > maxPos do
			newPos = newPos - maxPos
		end
		return newPos
	end

	local zoneInfo = MapMonsterAPI.GetZoneData(playerPosition.zoneId)

	if zoneInfo.chunkX then
		playerWorldPos.worldX = _trimWorldPos(playerWorldPos.worldX, zoneInfo.chunkX)
		playerWorldPos.worldY = _trimWorldPos(playerWorldPos.worldY, zoneInfo.chunkY)
	end

	-- get the zone position
	local playerZonePos = MapMonsterAPI.WorldToZone(playerWorldPos)
		
	-- if we have zone position cache it and return it
	-- otherwise just return the world pos
	if playerZonePos then
		playerPosition.zoneX = playerZonePos.zoneX
		playerPosition.zoneY = playerZonePos.zoneY
		return playerZonePos
	else
		return playerWorldPos
	end

end

--------------------------------------------------------------------------------
--#	Function: MapMonsterAPI.GetPlayerDirection()
--#		Returns the direction the player is moving as compass direction in degrees
--#
--#	Parameters:
--#		none
--#	Returns:
--#		direction -(number) Compass direction the player last moved
--#	Notes:
--#		
--------------------------------------------------------------------------------
function MapMonsterAPI.GetPlayerDirection()

	return playerDirection

end
