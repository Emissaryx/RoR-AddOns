if not DuffTimer then DuffTimer={} end
if not DuffTimerSettings then DuffTimerSettings={} end
	
function DuffTimerSettings.OnShutdown()
	if DuffTimer.SavedSettings then DuffTimerSettings.SavedSettings = DuffTimer.SavedSettings end
end