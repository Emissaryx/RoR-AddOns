<?xml version="1.0" encoding="UTF-8"?>
<!--	Project: DuffTimer.	Project Author:  Thurwell	Project Date: 2009-02-23T01:54:29Z
	Project Revision: 102	Project Version: v2.0.15 
	File Author: Thurwell	File Revision: 102	File Date:	2009-02-23T01:54:29Z	-->
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
<UiMod name="DuffTimerSettings" version="1.0" date="01/2009">
<Author name="Thurwell" email="" />
	<Description text="Where dufftimer saves your settings" />

	<Files>
		<File name="DuffTimerSettings.lua" />
	</Files>

	<SavedVariables>
		<SavedVariable name="DuffTimerSettings.SavedSettings" />
	</SavedVariables>
	<OnShutdown>
		<CallFunction name="DuffTimerSettings.OnShutdown" />
	</OnShutdown>


</UiMod>
</ModuleFile>
