local T = LibStub("WAR-AceLocale-3.0"):NewLocale("BlackBox", "deDE")

if T then

-- Actual text displayed in the black box
T["Respawning..."]      = L"Ihr kehrt zur�ck in:"

-- Text displayed on the new 'bar'
T["Respawning in "]     = L"Ihr kehrt zur�ck in "

end