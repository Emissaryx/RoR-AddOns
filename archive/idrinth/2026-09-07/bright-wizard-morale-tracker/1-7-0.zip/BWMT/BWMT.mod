<?xml version="1.0" encoding="UTF-8"?>

<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" >
	<UiMod name="BWMT" version="1.7" date="17.06.2020" >

		<Author name="Cimba" email="" />
		
		<VersionSettings gameVersion="1.4.8" windowsVersion="1.0" savedVariablesVersion="1.4" />

		<Description text="Bright Wizard Morale Tracker" />

		<Dependencies>
		</Dependencies>

		<Files>
			<File name="BWMT.lua" />
		</Files>

		<OnInitialize>
			<CallFunction name="BWMT.OnInitialize" />
		</OnInitialize>

		<OnUpdate>
		</OnUpdate>

		<OnShutdown>
			<CallFunction name="BWMT.OnShutdown" />
		</OnShutdown>

		<SavedVariables>
			<SavedVariable name="BWMT.SavedSettings" global="false"/>
		</SavedVariables>	

	</UiMod>

</ModuleFile>