-- local constants
if not BWMT then BWMT = {} end
local lastMoraleLevel = 0;
local lastMoralePercent = 0;
local cooldown_threshold = 2;
local GetMoraleCooldown = GetMoraleCooldown
local TextLogGetEntry = TextLogGetEntry
local GetMoraleBarData = GetMoraleBarData
local GetAbilityData = GetAbilityData
local ConfigMorale = {}
local settings = {}


--Called when Addon loaded
function BWMT.OnInitialize()	
	if not BWMT.SavedSettings then BWMT.SetDefaults() end
	settings = BWMT.SavedSettings
	ConfigMorale = BWMT.SavedSettings.ConfigMorale
	
	-- Register events with client
	if settings.Spam == true 	then RegisterEventHandler(SystemData.Events.PLAYER_MORALE_UPDATED, 	"BWMT.PlayerMoraleUpdate") end
	if settings.ChatLog == true then RegisterEventHandler(TextLogGetUpdateEventId("Chat"), 			"BWMT.ChatLogUpdated") end

	
	--RegisterEventHandler(SystemData.Events.PLAYER_TARGET_UPDATED,"BWMT.PlayerTargetsUpdated")
	-- PlayerId = GameData.Player.worldObjNum -- dont need this at the moment

	--[[Events to check where the player is currently to select appropiate communication channels
	RegisterEventHandler(SystemData.Events.GROUP_UPDATED, "BWMT.CHECK_CHANNEL")
    RegisterEventHandler(SystemData.Events.GROUP_STATUS_UPDATED, "BWMT.CHECK_CHANNEL")
    RegisterEventHandler(SystemData.Events.BATTLEGROUP_UPDATED, "BWMT.CHECK_CHANNEL")
    RegisterEventHandler(SystemData.Events.BATTLEGROUP_MEMBER_UPDATED, "BWMT.CHECK_CHANNEL")
	RegisterEventHandler(SystemData.Events.LOADING_END, "BWMT.CHECK_CHANNEL")
	RegisterEventHandler(SystemData.Events.PLAYER_BEGIN_CAST, 
	--]]
end

function BWMT.SetDefaults()
	BWMT.SavedSettings = {}
	-- Turn on Morale Spam in chat by default
	BWMT.SavedSettings.Spam = true
	-- Turn on Chat Loggin by default
	BWMT.SavedSettings.ChatLog = true
	-- Parsing Group Effect Events by default off
	BWMT.SavedSettings.GroupEffects = false
	-- Parsing Player Effect Events by default off
	BWMT.SavedSettings.PlayerEffects = false
	BWMT.SavedSettings.PlayerTargetEffects = false
	-- Define which Morales should be spammed, default All
	BWMT.SavedSettings.ConfigMorale = {}
	BWMT.SavedSettings.ConfigMorale[0] = false
	for i=1,4 do
		BWMT.SavedSettings.ConfigMorale[i] = true
	end
end

-- Called when Addon is shutdown
function BWMT.OnShutdown()
	UnregisterEventHandler(SystemData.Events.PLAYER_MORALE_UPDATED, "BWMT.PlayerMoraleUpdate")
	UnregisterEventHandler(TextLogGetUpdateEventId("Chat"), "BWMT.ChatLogUpdated");
end

--Player Morale
function BWMT.PlayerMoraleUpdate(moralePercent, moraleLevel)
	moraleDiff = moralePercent - lastMoralePercent
	if (moraleLevel > 2 ) and (moraleDiff > 6) then
		text = BWMT.DisplayMorale(1,moraleLevel)
		SendChatText(towstring(text..". "..moralePercent.." % to M4"), L"")	
	elseif (moraleLevel > lastMoraleLevel) and (moraleLevel > 0) and (ConfigMorale[moraleLevel] == true) then
		text = BWMT.DisplayMorale(1,moraleLevel)
		SendChatText(towstring(text), L"")
	end
	lastMoraleLevel = moraleLevel
	lastMoralePercent = moralePercent
end

local textMarker = tostring("Morale Report");

function BWMT.ChatLogUpdated(updateType, filterType) -- basically stolen from Tether
	if (updateType ~= SystemData.TextLogUpdate.ADDED) then return end
	if (filterType == 4 or filterType == 16 or filterType == 9) then -- 4: Group, 16: Scneario Groups, --9: Guild Officer 
		local timestamp, channel, text = TextLogGetEntry("Chat", TextLogGetNumEntries("Chat") - 1)
		text = tostring(text)
		-- messages meant for teather are marked with textMarker
		local validMessage = string.find(text, textMarker); --d(validMessage)
		if validMessage then
			local moraleLevel = GetPlayerMoraleLevel()		
			SendChatText(towstring(BWMT.DisplayMorale(1,moraleLevel)), L"")	
		end
	end
end

-- function to display morale status in chat
function BWMT.DisplayMorale(minMorale,maxMorale)
	local coolDown, _ = GetMoraleCooldown(minMorale) -- returns the morale cool down, including global cool downs if its larger than the morale cool down
	local text = "/p "	
	
	for i=minMorale,maxMorale do
		local _, id = GetMoraleBarData (i)
		local iconNum = GetAbilityData(id).iconNum
		local icon = "<icon"..iconNum..">"
		text = text..icon
	end
	text = text.." M"..maxMorale
			
	if (coolDown < cooldown_threshold) then
		text = text.." ready"
	elseif (coolDown > cooldown_threshold) then
		text = text.. " up. Cooldown "..math.ceil(coolDown).. " seconds."
	end
	return text
end

------------------- A lot of config functions past this point -------------------

-- /script BWMT.StopSpam()
function BWMT.StopSpam()
	UnregisterEventHandler(SystemData.Events.PLAYER_MORALE_UPDATED, "BWMT.PlayerMoraleUpdate")
	BWMT.SavedSettings.Spam = false
end

-- /script BWMT.StartSpam()
function BWMT.StartSpam()
	RegisterEventHandler(SystemData.Events.PLAYER_MORALE_UPDATED, "BWMT.PlayerMoraleUpdate")
	BWMT.SavedSettings.Spam = true
end

-- /script BWMT.ConfigSpam(1, false)
function BWMT.ConfigSpam(ToBeConfigedMoraleLevel, TrueFalse) -- Value is either true or false
	if (TrueFalse == true) or (TrueFalse == false) then 
	ConfigMorale[ToBeConfigedMoraleLevel] = TrueFalse
	BWMT.SavedSettings.ConfigMorale = ConfigMorale
	end
end

-- /script BWMT.StopChatLog()
function BWMT.StopChatLog()
	UnregisterEventHandler(TextLogGetUpdateEventId("Chat"), "BWMT.ChatLogUpdated")
	BWMT.SavedSettings.ChatLog = false
end

-- /script BWMT.StartChatLog()
function BWMT.StartChatLog()
	RegisterEventHandler(TextLogGetUpdateEventId("Chat"), "BWMT.ChatLogUpdated")
	BWMT.SavedSettings.ChatLog = true
end