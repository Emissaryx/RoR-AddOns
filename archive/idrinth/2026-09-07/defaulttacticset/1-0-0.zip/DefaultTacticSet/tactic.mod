<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
		<UiMod name="Default Tactic Set" version="1.0" date="04/12/2015" >

				<Author name="tac" email="" />
				<Description text="" />
        
				<Files>
					<File name="tactic.lua" />
				</Files>
				
				<OnInitialize>
					<CallFunction name="tactic.init" />
				</OnInitialize>
		</UiMod>
</ModuleFile>