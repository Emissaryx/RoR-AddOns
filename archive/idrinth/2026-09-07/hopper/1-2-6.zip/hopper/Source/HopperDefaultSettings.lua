--[[
	This application is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    The applications is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with the applications.  If not, see <http://www.gnu.org/licenses/>.
--]]

if not Hopper then Hopper = {} end

Hopper.DefaultSettings 	=
{
	profile = {
		["debug"]								= false,
		["version"]								= 000000,
		
		["general-enable-addon"]				= true,
		["general-update-delay"]				= .5,
		["general-frame-alpha"]					= .5,
		
		["general-scenario-enable"]				= true,
		["general-warband-enable"]				= true,
		
		["hopper-fill-direction"]       		= "right",
	    ["hopper-frame-vertical-offset"]		= 0,
		["hopper-frame-horizontal-offset"]		= 0,
		
		["activegroup-status-color"]			= {85, 188, 70},
		
		["slot-open-status-color"]				= {85, 188, 70},
		["slot-closed-status-color"]			= {255, 0, 0},
		["slot-status-alpha"]					= 1.0,
		
		["anchor-point"]						= "center",
	    ["anchor-relpoint"]						= "center",
	    ["anchor-relwin"]						= "Root",
	    ["anchor-x"]                    		= 0,
	    ["anchor-y"]                    		= 0,
	    ["anchor-scale"]                		= 1.0,
	    ["anchor-dx"]                   		= 40,
	    ["anchor-dy"]                   		= 40,
	}
}