
	StopRes = {}
	StopRes.Settings = {} 
	StopRes.Settings.ressingstatus=false;
	StopRes.Settings.ResList = {
			[1598] = L"Rune Of Life"
	, 	[1908] = L"Gedup!"
	, 	[8248] = L"Breath Of Sigmar"
	, 	[8555] = L"Tzeentch Shall Remake You"
	, 	[9246] = L"Gift Of Life"
	, 	[9558] = L"Stand, Coward!"
									}
									



									
function StopRes.Initialize()

    RegisterEventHandler(SystemData.Events.PLAYER_END_CAST, "StopRes.EndCast")
    RegisterEventHandler(SystemData.Events.PLAYER_BEGIN_CAST, "StopRes.BeginCast")
		
end

function StopRes.Shutdown()

	UnregisterEventHandler(SystemData.Events.PLAYER_END_CAST, "StopRes.EndCast")
    UnregisterEventHandler(SystemData.Events.PLAYER_BEGIN_CAST, "StopRes.BeginCast")

end

function StopRes.OnTesting()
if not StopRes.Settings.ressingstatus then return end
if StopRes.Settings.ressingstatus then
	StopRes.ResCheck()
end
end


function StopRes.ResCheck()
	local tarHealth = TargetInfo:UnitHealth("selffriendlytarget")	

if StopRes.Settings.ressingstatus then
		if tarHealth ~= 0 then
			CancelSpell()
			StopRes.Settings.ressingstatus=false;
		end
end
end

function StopRes.BeginCast(abilityId)
local found=false;
		for k,v in pairs(StopRes.Settings.ResList) do
			if abilityId == k then
			found=true;
			end
		end
	if found then
	StopRes.Settings.ressingstatus=true;
	else return end
	
end

function StopRes.EndCast()
	if StopRes.Settings.ressingstatus then
	StopRes.Settings.ressingstatus=false;
	end
end
