local version 		= 1.0
Info_Points = {}

local PlayerName = wstring.sub(GameData.Player.name,1,-3)
local PlayerRealm = GameData.Player.realm

function Info_Points.OnInitialize()
if not InfoScroller.Settings.Renown then InfoScroller.Settings.Renown = true end
if not InfoScroller.Settings.Threshold_Renown then InfoScroller.Settings.Threshold_Renown = 0 end
if not InfoScroller.Settings.Influence then InfoScroller.Settings.Influence = true end
if not InfoScroller.Settings.Threshold_Influence then InfoScroller.Settings.Threshold_Influence = 0 end
if not InfoScroller.Settings.Experience then InfoScroller.Settings.Experience = true end
if not InfoScroller.Settings.Threshold_Experience then InfoScroller.Settings.Threshold_Experience = 0 end

	PlayerName = wstring.sub(GameData.Player.name,1,-3)
	PlayerRealm = GameData.Player.realm

--Renown Option tab
	local Renown = {name="+Renown",[1]={name="checkbox",title="Show Renown",save="Renown"},
									[2]={name="textbox",title="Renown Threshold",save="Threshold_Renown"}
		}
	table.insert(InfoScroller.Register,Renown)

--Influence option tab	
	local Influence = {name="+Influence",[1]={name="checkbox",title="Show Influence",save="Influence"},
									[2]={name="textbox",title="Influence Threshold",save="Threshold_Influence"}
		}
	table.insert(InfoScroller.Register,Influence)

--Experience Option tab
	local Experience = {name="+Experience",[1]={name="checkbox",title="Show Experience",save="Experience"},
									[2]={name="textbox",title="Experience Threshold",save="Threshold_Experience"}
		}
	table.insert(InfoScroller.Register,Experience)

RegisterEventHandler(TextLogGetUpdateEventId("Combat"), "Info_Points.OnCombatLogUpdated")
end

function InfoScroller.OnShutdown()	
	UnregisterEventHandler(TextLogGetUpdateEventId("Combat"), "Info_Points.OnCombatLogUpdated")
end

function Info_Points.OnCombatLogUpdated(updateType, filterType) 
	if( updateType == SystemData.TextLogUpdate.ADDED ) then 
	local currenttime, filterId, text = TextLogGetEntry( "Combat", TextLogGetNumEntries("Combat") - 1 )

		if filterType == SystemData.ChatLogFilters.RENOWN and InfoScroller.Settings.Renown == true then
		local Renown = -1
		Renown = text:match(L"You gain (.+) renown.") or -1
		local Type,Name = text:match(L" from ([%a]+) (.+).")
		if tonumber(InfoScroller.Settings.Threshold_Renown) > tonumber(Renown) then return end
		
			if (Type ~= nil) and (Name ~= nil) then			
			Info_Points.UpdateRenown(Name,Type,Renown)
				return					
			else
			Info_Points.UpdateRenown("","normal",Renown)	
			end				
		end

		if filterType == SystemData.ChatLogFilters.INFL and InfoScroller.Settings.Influence == true then
		local Influence = -1
		Influence = text:match(L"You gain (.+) influence.") or -1
		if tonumber(InfoScroller.Settings.Threshold_Influence) > tonumber(Influence) then return end
					Info_Points.UpdateInfluence(Influence)				
			end
		
		if filterType == SystemData.ChatLogFilters.EXP and InfoScroller.Settings.Experience == true then
		local Experience = -1
		Experience = text:match(L"You gain (.+) experience.") or -1
		if tonumber(InfoScroller.Settings.Threshold_Experience) > tonumber(Experience) then return end
			Info_Points.UpdateExperience(Experience)							
			end
	end
end

function Info_Points.UpdateRenown(Name,Type,Renown)
local C_Color = InfoScroller.Color[PlayerRealm]
local name = tostring(Name) or ""
local renown = tonumber(Renown) or nil
local type = tostring(Type)
	if type == "defending" or type == "capturing" then
		C_Color = {25,255,25}
	elseif type == "killing" then
		C_Color = InfoScroller.InvColor[PlayerRealm]
	end
	if renown then		
		if type ~= "normal" then
			InfoScroller.TicketOnQue({BGColor={r=230,g=50,b=250},[1]={text=L"    You Gained "..towstring(CreateHyperLink(L"0",towstring(renown)..L" Renown", {230,50,250},{}))..L" for "..towstring(type)..L" "..towstring(CreateHyperLink(L"0",towstring(name), C_Color,{})),color={r=255,g=255,b=255},texture={name="icon000045",width=16,height=16},font="font_clear_small_bold"}})
		else
			InfoScroller.TicketOnQue({BGColor={r=230,g=50,b=250},[1]={text=L"    You Gained "..towstring(CreateHyperLink(L"0",towstring(renown)..L" Renown.", {230,50,250},{})),color={r=255,g=255,b=255},texture={name="icon000045",width=16,height=16},font="font_clear_small_bold"}})		
		end
	end
end

function Info_Points.UpdateInfluence(Influence)
local INF = tonumber(Influence) or nil
	if INF then
		InfoScroller.TicketOnQue({BGColor={r=DefaultColor.COLOR_INFLUENCE_GAIN.r,g=DefaultColor.COLOR_INFLUENCE_GAIN.g,b=DefaultColor.COLOR_INFLUENCE_GAIN.b},[1]={text=L"    You Gained "..towstring(CreateHyperLink(L"0",towstring(INF)..L" Influence", {DefaultColor.COLOR_INFLUENCE_GAIN.r,DefaultColor.COLOR_INFLUENCE_GAIN.g,DefaultColor.COLOR_INFLUENCE_GAIN.b},{})),color={r=255,g=255,b=255},texture={name="icon000052",width=16,height=16},font="font_clear_small_bold"}})
	end
end

function Info_Points.UpdateExperience(Experience)
local EXP = tonumber(Experience) or nil
	if EXP then		
		InfoScroller.TicketOnQue({BGColor={r=DefaultColor.COLOR_EXPERIENCE_GAIN.r,g=DefaultColor.COLOR_EXPERIENCE_GAIN.g,b=DefaultColor.COLOR_EXPERIENCE_GAIN.b},[1]={text=L"    You Gained "..towstring(CreateHyperLink(L"0",towstring(EXP)..L" Experience", {DefaultColor.COLOR_EXPERIENCE_GAIN.r,DefaultColor.COLOR_EXPERIENCE_GAIN.g,DefaultColor.COLOR_EXPERIENCE_GAIN.b},{})),color={r=255,g=255,b=255},texture={name="icon000041",width=16,height=16},font="font_clear_small_bold"}})
	end
end