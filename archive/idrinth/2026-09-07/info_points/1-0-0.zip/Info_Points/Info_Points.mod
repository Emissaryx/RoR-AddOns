<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
    <UiMod name="Info_Points" version="1.0" date="11/12/2020">
        <Author name="Sullemunk" />
        <Description text="Info_Points, Shows renown, experience, influence on InfoScroller" />
         <Dependencies>		 
            <Dependency name="InfoScroller" optional="false"  />
			<Dependency name="EA_ChatWindow" />		
		</Dependencies>
        <Files>
				<File name="Info_Points.lua" />
        </Files>
        <OnInitialize>
            <CallFunction name="Info_Points.OnInitialize" />
        </OnInitialize>
		
		<SavedVariables>		
		</SavedVariables>
        <OnUpdate>
    	 </OnUpdate>	
        <OnShutdown>
			<CallFunction name="InfoScroller.OnShutdown" />
		</OnShutdown>
    </UiMod>
</ModuleFile>