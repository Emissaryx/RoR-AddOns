TurretScrap = {}
Upgrades = 0
local version = 0.2
local CurrentCareer = GameData.Player.career.id

TurretScrap.BuffIDS = {[1070]=true,[1072]=true}
TurretScrap.Texture = {[23]="Cog",[67]="Tent"}


function TurretScrap.Initialize()
CurrentCareer = GameData.Player.career.id
if (CurrentCareer == 23 or CurrentCareer == 67) then

CreateWindow("TurretScrapWindow",false)
LayoutEditor.RegisterWindow( "TurretScrapWindow", L"TurretScrap", L"Witchbrew counter", true, true, true, nil )
TextLogAddEntry("Chat", 0, L"<icon57> TurretScrap "..towstring(version)..L" Loaded.")
RegisterEventHandler(SystemData.Events.PLAYER_EFFECTS_UPDATED, "TurretScrap.CheckBuffs")

WindowSetShowing( "TurretScrapWindowBG2",CurrentCareer == 67)

for i=1,8 do
DynamicImageSetTexture( "TurretScrapWindow_"..i.."Cog",TurretScrap.Texture[CurrentCareer],42,42 )
DynamicImageSetTextureSlice("TurretScrapWindow_"..i.."Cog",TurretScrap.Texture[CurrentCareer]..i)	
end
end
TurretScrap.CheckBuffs()
end

function TurretScrap.CheckBuffs()
	local WBisACTIVE = false
	Upgrades = 0
	local myBuffs = GetBuffs(GameData.BuffTargetType.SELF)
	if( myBuffs == nil ) then return end
	for myBuffId, myBuff in pairs( myBuffs ) do
	local myCurrentBuff = myBuffs[myBuffId]

	if TurretScrap.BuffIDS[myCurrentBuff.abilityId] == true then	 
	WBisACTIVE = true 
	Upgrades = myCurrentBuff.stackCount
	
	LabelSetText("TurretScrapCD",towstring(myCurrentBuff.stackCount))
	end		
	end	
	
	if WBisACTIVE == true then
	
	WindowSetShowing("TurretScrapCD",Upgrades < 8 )
	WindowSetShowing("TurretScrapWindow",true)
		for i=1,8 do
		if i <= Upgrades then
		WindowSetShowing("TurretScrapWindow_"..i,true)
		else
			WindowSetShowing("TurretScrapWindow_"..i,false)
		end
	end
	
	else
	WindowSetShowing("TurretScrapWindow",false)
	end
	
end
