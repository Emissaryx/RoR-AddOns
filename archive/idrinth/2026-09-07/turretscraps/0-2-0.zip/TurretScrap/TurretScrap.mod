<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
    <UiMod name="TurretScrap" version="0.2" date="30/01/2020">
        <Author name="Sullemunk" />
        <Description text="Engineer and Magus Turret stack tracker" />
 
        <Files>
            <File name="TurretScrap.lua" />
			<File name="TurretScrap.xml" />
        </Files>

        <OnInitialize>
            <CallFunction name="TurretScrap.Initialize" />
        </OnInitialize>

		<OnUpdate>
    	</OnUpdate>
		
        <OnShutdown />
    </UiMod>
</ModuleFile>