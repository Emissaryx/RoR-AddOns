if not OilTimer then OilTimer = {} end

local hp = 0;
local hp2 = 0;
local TIME_DELAY2 = 1;
local timeLeft2 = 1;
local oiltimer = -1;
local tolocal = false
local message = ""
local color = 0
local a1 = {}
local a2 = {}
local r, g, b = 0, 0, 0

local function Print(str)
	EA_ChatWindow.Print(towstring(str));
end

function OnInitialize()

	--TargetInfo:UpdateFromClient()
	--OilTimer.OnTargetUpdated( "selfhostiletarget" , TargetInfo:UnitEntityId( "selfhostiletarget" ), TargetInfo:UnitType( "selfhostiletarget" ) )
	
	RegisterEventHandler(TextLogGetUpdateEventId("Chat"), "OilTimer.OnChatLogUpdated")
	RegisterEventHandler( SystemData.Events.PLAYER_TARGET_UPDATED, "OilTimer.OnTargetUpdated" )
	if LibSlash then
		LibSlash.RegisterSlashCmd("ot", function(args) SlashCmd(args) end);
		Print("<LINK data=\"\" text=\"[Oil Timer]\" color=\"50,255,10\"> Addon initialized. Target Oil and when it dies timer will start. Use /ot to toggle show timer to /1 or only to you.");
	else
		Print("<LINK data=\"\" text=\"[Oil Timer]\" color=\"50,255,10\"> Addon initialized. Target Oil and when it dies timer will start.")
	end
end

function SlashCmd(args)
	tolocal = not tolocal
	if tolocal == true then
		Print("<LINK data=\"\" text=\"Now OIL timer goes to /1 !!!\" color=\"50,255,10\">")
	else
		Print("<LINK data=\"\" text=\"Now OIL timer shows only to you.\" color=\"50,255,10\">")
	end
end

function OnShutdown()
	UnregisterEventHandler(TextLogGetUpdateEventId("Chat"), "OilTimer.OnChatLogUpdated")
	UnregisterEventHandler( SystemData.Events.PLAYER_TARGET_UPDATED, "OilTimer.OnTargetUpdated" )
end

function timerUpdate(elapsed)
	timeLeft2 = timeLeft2 - elapsed;
	if (timeLeft2 > 0) then
	        return;
	end
	if tolocal == true then
		if (oiltimer == 0) then
			r = math.random(255)
			g = math.random(255)
			b = math.random(255)
			message = L"/1 <LINK data=\"\" text=\"OIL!!!\" color=\"" .. r .. L",".. g .. L"," .. b .. L"\">"
			SendChatText( message, L"" );
		end
		if oiltimer > 0 and oiltimer < 6 then
			message = L"/1 <LINK data=\"\" text=\"Oil in " .. oiltimer .. L" sec\" color=\"" .. color .. L",0,0\">"
			SendChatText( message, L"" );
			color = color + 20
		end
		if (oiltimer == 10) then
			message = L"/1 <LINK data=\"\" text=\"Oil in 10 sec\" color=\"135,0,0\">"
			SendChatText( message, L"" );
		end
		if (oiltimer == 30) then
			message = L"/1 <LINK data=\"\" text=\"Oil in 30 sec\" color=\"50,255,10\">"
			SendChatText( message, L"" );
		end
		if (oiltimer == 60) then
			message = L"/1 <LINK data=\"\" text=\"Oil in 1 min\" color=\"50,255,10\">"
			SendChatText( message, L"" );
		end
			if (oiltimer == 90) then
			message = L"/1 <LINK data=\"\" text=\"Oil in 1 min 30 sec\" color=\"50,255,10\">"
			SendChatText( message, L"" );
		end
		if (oiltimer == 120) then
			message = L"/1 <LINK data=\"\" text=\"Oil in 2 min\" color=\"50,255,10\">"
			SendChatText( message, L"" );
		end
	else
		if (oiltimer == 1) then Print(L"<LINK data=\"\" text=\"Oil in 1 sec\" color=\"255,0,0\">") end
		if (oiltimer == 5) then Print(L"<LINK data=\"\" text=\"Oil in 5 sec\" color=\"245,50,50\">") end
		if (oiltimer == 10) then Print(L"<LINK data=\"\" text=\"Oil in 10 sec\" color=\"235,100,100\">") end
		if (oiltimer == 30) then Print(L"<LINK data=\"\" text=\"Oil in 30 sec\" color=\"50,255,10\">") end
		if (oiltimer == 60) then Print(L"<LINK data=\"\" text=\"Oil in 1 min\" color=\"50,255,10\">") end
		if (oiltimer == 90) then Print(L"<LINK data=\"\" text=\"Oil in 1 min 30 sec\" color=\"50,255,10\">") end
		if (oiltimer == 120) then Print(L"<LINK data=\"\" text=\"Oil in 2 min\" color=\"50,255,10\">") end
	end
	if (oiltimer > -1) then
		oiltimer = oiltimer - 1;
	end
	timeLeft2 = TIME_DELAY2;
end

function OilTimer.OnTargetUpdated( targetClassification, targetId, targetType )
	TargetInfo:UpdateFromClient()
	local tn = TargetInfo:UnitName( "selfhostiletarget" )
	local tn2 = TargetInfo:UnitName( "selffriendlytarget" )
	if tn:find(L" Oil") then
		if hp > 0 and TargetInfo:UnitHealth( "selfhostiletarget" ) == 0 then
			oiltimer = 170;
			EA_ChatWindow.Print(L">>> Oil countdown started <<<")
			color = 155
		end
		hp = TargetInfo:UnitHealth( "selfhostiletarget" )
	else
		hp = 0
	end
	if tn2:find(L" Oil") then
		if hp2 > 0 and TargetInfo:UnitHealth( "selffriendlytarget" ) == 0 then
			oiltimer = 170;
			EA_ChatWindow.Print(L">>> Oil countdown started <<<")
			color = 155
		end
		hp2 = TargetInfo:UnitHealth( "selffriendlytarget" )
	else
		hp2 = 0
	end

	--EA_ChatWindow.Print(tn .. hp)
end

function OilTimer.OnChatLogUpdated(updateType, filterType)
	if( updateType == SystemData.TextLogUpdate.ADDED ) then 			
		if filterType == SystemData.ChatLogFilters.RVR then
			local _, filterId, text = TextLogGetEntry( "Chat", TextLogGetNumEntries("Chat") - 1 )
			if text:find(L" ram") or text:find(L" Ram") then
				--message = L"/wb <icon192><icon192><icon192> " .. towstring(text) .. L" <icon192><icon192><icon192>"
				--SendChatText( message, L"" );
				Print("<icon192><icon192><icon192> " .. tostring(text) .. " <icon192><icon192><icon192>")
				--PlaySound(218)
			end
--[[			if text:find(L"started the siege") then
				message = L"/g <icon192><icon192><icon192> " .. towstring(text) .. L" <icon192><icon192><icon192>"
				SendChatText( message, L"" );
				--Print("<icon192><icon192><icon192> " .. tostring(text) .. " <icon192><icon192><icon192>")
				--PlaySound(218)
			end]]--
		end
		if filterType == SystemData.ChatLogFilters.CHANNEL_9 then
			local _, filterId, text = TextLogGetEntry( "Chat", TextLogGetNumEntries("Chat") - 1 )
			local text2 = towstring(text)
			if text2:match(L"SoR_+[^%.]+_Keep:([^%.]+).") then	
				local SoR_KEEP_SPLIT_TEXT_STREAM = StringSplit(tostring(text2), ":")
				local KEEP1_ID = tonumber(SoR_KEEP_SPLIT_TEXT_STREAM[3])
				local KEEP2_ID = tonumber(SoR_KEEP_SPLIT_TEXT_STREAM[12])
				local KEEP1_Door1 = tonumber(SoR_KEEP_SPLIT_TEXT_STREAM[9])			
				local KEEP1_Door2 = tonumber(SoR_KEEP_SPLIT_TEXT_STREAM[8])			
				local KEEP2_Door1 = tonumber(SoR_KEEP_SPLIT_TEXT_STREAM[18])								
				local KEEP2_Door2 = tonumber(SoR_KEEP_SPLIT_TEXT_STREAM[17])
				local KEEP1_Lord = tonumber(SoR_KEEP_SPLIT_TEXT_STREAM[10])								
				local KEEP2_Lord = tonumber(SoR_KEEP_SPLIT_TEXT_STREAM[19])			
				local found = false
				if (KEEP1_Door1 < 99 or (KEEP1_Door2 >= 0 and KEEP1_Door2 < 99) or KEEP1_Lord < 99) and a1[KEEP1_ID] == true then
					--message = L"/wb <icon192><icon192><icon192>" .. tostring(GetKeepName(KEEP1_ID)) .. L" under attack! <icon192><icon192><icon192>"
					--SendChatText( message, L"" );
					Print("<icon192><icon192><icon192>" .. tostring(GetKeepName(KEEP1_ID)) .. " under attack! <icon192><icon192><icon192>")
					PlaySound(218)
					a1[KEEP1_ID] = false
					--AB_util.print(tostring(GetKeepName(KEEP1_ID)) .. " under attack!")
				end
				if (KEEP2_Door1 < 99 or (KEEP2_Door2 >= 0 and KEEP2_Door2 < 99) or KEEP2_Lord < 99) and a2[KEEP2_ID] == true then
					--message = L"/wb <icon192><icon192><icon192>" .. tostring(GetKeepName(KEEP2_ID)) .. L" under attack! <icon192><icon192><icon192>"
					--SendChatText( message, L"" );
					Print("<icon192><icon192><icon192>" .. tostring(GetKeepName(KEEP2_ID)) .. " under attack! <icon192><icon192><icon192>")
					PlaySound(218)
					a2[KEEP2_ID] = false
					--AB_util.print(tostring(GetKeepName(KEEP2_ID)) .. " under attack!")
				end
				if (KEEP1_Door1 == 100 and (KEEP1_Door2 < 0 or KEEP1_Door2 == 100) and KEEP1_Lord == 100) then
					a1[KEEP1_ID] = true
				end
				if (KEEP2_Door1 == 100 and (KEEP2_Door2 < 0 or KEEP2_Door2 == 100) and KEEP2_Lord == 100) then
					a2[KEEP2_ID] = true
				end
			end
		end
	end
end
