<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
	<UiMod name="OilTimer" version="0.8" date="12/03/2020" >
		<Author name="Botanich" />
		<Description text="Oil cooldown tracking." />
		<VersionSettings gameVersion="1.4.8" windowsVersion="0.1" />
		<Dependencies>
			<Dependency name="LibSlash" optional="false" forceEnable="true" />
		</Dependencies>

		<Files>
            <File name="OilTimer.lua" />
        </Files>
		
		<OnInitialize>
			<CallFunction name="OnInitialize" />
		</OnInitialize>
		
		<OnUpdate>
			<CallFunction name="timerUpdate"/>
		</OnUpdate>
		
		<OnShutdown>
			<CallFunction name="OnShutdown" />
		</OnShutdown>

		<WARInfo>    
		  <Categories>
			<Category name="RVR" />
		  </Categories>
		</WARInfo>
	</UiMod>
</ModuleFile>
