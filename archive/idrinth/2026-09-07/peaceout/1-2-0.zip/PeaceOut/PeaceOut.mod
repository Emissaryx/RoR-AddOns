<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
    <UiMod name="PeaceOut" version="1.2" date="11/1/2024">
	<VersionSettings gameVersion="1.4.8" windowsVersion="1.0" savedVariablesVersion="1.0" />
        <Author name="NigelTufnel" email="adam.dew@gmail.com" />
        <Description text="Peace Out provides a logout dialog to give more direct feel to the logoff/exit process. 2024 update by Ninjas" />
		<Dependencies />
        <Files>
            <File name="PeaceOut.lua" />
            <File name="PeaceOut.xml" />
        </Files>
        <OnInitialize>
            <CallFunction name="PeaceOut.Init" />
        </OnInitialize>
		<SavedVariables>
			<SavedVariable name="PeaceOut.settings"/>
		</SavedVariables>
		<OnUpdate />
        <OnShutdown />
    </UiMod>
</ModuleFile>