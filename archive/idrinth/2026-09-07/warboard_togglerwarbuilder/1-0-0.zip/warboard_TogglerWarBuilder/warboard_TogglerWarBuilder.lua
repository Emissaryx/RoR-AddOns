if not warboard_TogglerWarbuilder then warboard_TogglerWarbuilder = {} end
local warboard_TogglerWarbuilder = warboard_TogglerWarbuilder
local modName = "warboard_TogglerWarBuilder"
local modLabel = "WarBuilder"

function warboard_TogglerWarbuilder.Initialize()
	if LibWBToggler.CreateToggler(modName, modLabel, "WarbuilderIcon", 0, 0) then
        -- Ensure label text is wstring and auto-size to avoid cropping
        LabelSetText(modName.."Label", towstring(modLabel))
        LabelSetWordWrap(modName.."Label", false)
        local tw, th = LabelGetTextDimensions(modName.."Label")
        local pad = 12
        local labelW = math.max(130, (tw or 0) + pad)
        WindowSetDimensions(modName.."Label", labelW, 30)
        local containerW = math.max(170, labelW + 40)
        WindowSetDimensions(modName, containerW, 30)

		WindowSetDimensions(modName, 130, 30)
		WindowSetDimensions(modName.."Label", 100, 30)
		LibWBToggler.RegisterEvent(modName, "OnLButtonUp", "warboard_TogglerWarbuilderConfig")
		LibWBToggler.RegisterEvent(modName, "OnRButtonUp", "warboard_TogglerWarbuilderConfigr")
		LibWBToggler.RegisterEvent(modName, "OnMouseOver", "warboard_TogglerWarbuilder.ShowStatus")
	end
end

function warboard_TogglerWarbuilderConfig()
	Warbuilder.Command("0")
end
function warboard_TogglerWarbuilderConfigr()
	Warbuilder.Command()
end

function warboard_TogglerWarbuilder.ShowStatus()
	Tooltips.CreateTextOnlyTooltip(modName, nil)
	Tooltips.AnchorTooltip(WarBoard.GetModToolTipAnchor(modName))
	Tooltips.SetTooltipText(1, 1, L"WarBuilder")
	Tooltips.SetTooltipText(2, 1, L"Left Click:")
	Tooltips.SetTooltipText(2, 3, L"Open Current Spec")
	Tooltips.SetTooltipText(3, 1, L"Right Click:")
	Tooltips.SetTooltipText(3, 3, L"Open Empty")
	Tooltips.Finalize()
end