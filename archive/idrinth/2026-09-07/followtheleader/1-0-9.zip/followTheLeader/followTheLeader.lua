--[[
    followTheLeader Addon
    - Left-click: Targets and follows the current effective leader (fixed > dynamic).
    - Right-click: Follows your current friendly player target (if valid).
    - Middle-click: Toggles fixed leader mode for current target.
    - Hotbar macro: Supports two-click target/follow from an action bar.
    - Auto-updates in group, warband, or scenario context. Optional tracking/one-click follow.
--]]

followTheLeader = {}
followTheLeader.version = "1.0.9"
followTheLeader.isUpdatePending = false
followTheLeader.inScenarioMode = false
followTheLeader.playerCanonicalName = L""
followTheLeader.megaphoneRealmLeaderName = L""
followTheLeader.megaphoneEditBoxName = nil
followTheLeader.megaphoneRealmLeaderLast = L""
followTheLeader.megaphonePollFrameCounter = 0
followTheLeader.hotbarMacroId = nil
followTheLeader.hotbarArmedLeaderName = L""
followTheLeader.hotbarActionMode = ""
followTheLeader.hotbarButtonKey = ""
followTheLeader.targetEventRegistered = false
local FTL_MACRO_NAME = "FollowTheLeader"
local FTL_MACRO_TEXT = "/script followTheLeader.HotbarAction()"
local FTL_MACRO_ICON = 20070
local FTL_MACRO_ACTION_TYPE = 4
local MEGAPHONE_POLL_INTERVAL_FRAMES = 12
local MEGAPHONE_MISSING_POLL_INTERVAL_FRAMES = 120

local function FollowTheLeader_IsMegaphoneWindowVisible(mainWindow)
    if type(mainWindow) ~= "string" or mainWindow == "" then
        return false
    end
    if type(WindowGetShowing) ~= "function" then
        return false
    end
    local ok, showing = pcall(WindowGetShowing, mainWindow)
    if not ok then
        return false
    end
    return showing and true or false
end

-- String/wstring helpers (be conservative; WAR engine wstring may differ)
function followTheLeader.ToStr(x)
    if x == nil then return "" end
    if type(x) == "string" then return x end
    if type(WStringToString) == "function" then
        local ok, s = pcall(WStringToString, x)
        if ok and type(s) == "string" then return s end
    end
    return tostring(x)
end

-- Helper function for conditional debug messages
local function DebugPrint(msg)
    if followTheLeader.settings and followTheLeader.settings.debug then
        TextLogAddEntry("Chat", 0, towstring("[FTL-Debug] " .. followTheLeader.ToStr(msg)))
    end
end

-- Hotbar macro behavior:
-- The WAR client follows only the current friendly target; '/follow <name>' is not a named follow command.
-- When the wanted leader is not targeted, placed macro buttons are armed as native target actions.
-- After PLAYER_TARGET_UPDATED confirms the leader is targeted, the hotbar button is restored to the script macro
-- so the next press sends /follow.

-- Cached helpers for player/target lookups
function followTheLeader.RefreshPlayerNameCache()
    if GameData and GameData.Player and GameData.Player.name and GameData.Player.name ~= L"" then
        followTheLeader.playerCanonicalName = followTheLeader.FixName(GameData.Player.name)
    else
        followTheLeader.playerCanonicalName = L""
    end
end

function followTheLeader.GetPlayerCanonicalName()
    if followTheLeader.playerCanonicalName == nil or followTheLeader.playerCanonicalName == L"" then
        followTheLeader.RefreshPlayerNameCache()
    end
    return followTheLeader.playerCanonicalName or L""
end

function followTheLeader.GetFriendlyTargetInfo()
    TargetInfo:UpdateFromClient()
    local target = TargetInfo.m_Units[TargetInfo.FRIENDLY_TARGET]

    if target and target.career and target.career > 0 and target.name and target.name ~= L"" then
        local canonicalName = followTheLeader.FixName(target.name)
        local playerName = followTheLeader.GetPlayerCanonicalName()
        if canonicalName ~= L"" and canonicalName ~= playerName then
            return target, canonicalName
        end
    end

    return nil, L""
end

local function FollowTheLeader_GetMegaphoneEditBoxName()
    local megaphone = rawget(_G, "Megaphone")
    if type(megaphone) ~= "table" then
        followTheLeader.megaphoneEditBoxName = nil
        return nil
    end

    if followTheLeader.megaphoneEditBoxName ~= nil then
        return followTheLeader.megaphoneEditBoxName
    end

    local windows = rawget(megaphone, "Windows")
    if type(windows) ~= "table" then
        return nil
    end

    local mainWindow = windows.Main
    if type(mainWindow) ~= "string" or mainWindow == "" then
        return nil
    end

    local editBoxName = mainWindow .. "RealmLeaderEditBox"
    followTheLeader.megaphoneEditBoxName = editBoxName
    return editBoxName
end

local function FollowTheLeader_ReadMegaphoneCandidate()
    local megaphone = rawget(_G, "Megaphone")
    local mainWindow = nil
    if type(megaphone) == "table" and type(megaphone.Windows) == "table" then
        mainWindow = megaphone.Windows.Main
    end

    if mainWindow and FollowTheLeader_IsMegaphoneWindowVisible(mainWindow) then
        return followTheLeader.megaphoneRealmLeaderLast or L""
    end

    local editBoxName = FollowTheLeader_GetMegaphoneEditBoxName()
    if editBoxName == nil then
        return L""
    end

    if type(TextEditBoxGetText) ~= "function" then
        return L""
    end

    if type(DoesWindowExist) == "function" then
        local ok, exists = pcall(DoesWindowExist, editBoxName)
        if ok and not exists then
            return L""
        end
    end

    local ok, value = pcall(TextEditBoxGetText, editBoxName)
    if not ok or value == nil then
        return L""
    end

    local candidate = followTheLeader.FixName(value)
    if candidate == L"" then
        return L""
    end

    local selfName = followTheLeader.GetPlayerCanonicalName()
    if candidate == selfName then
        return L""
    end

    return candidate
end

function followTheLeader.GetMegaphoneRealmLeader()
    if not (followTheLeader.settings and followTheLeader.settings.useRealmLeaderFallback) then
        return L""
    end

    local candidate = FollowTheLeader_ReadMegaphoneCandidate()
    if candidate == L"" then
        return L""
    end

    local megaphone = rawget(_G, "Megaphone")
    if type(megaphone) == "table" then
        local tryCapture = rawget(megaphone, "TryCaptureRealmLeaderFromTargets")
        if type(tryCapture) == "function" then
            pcall(tryCapture, false)
        end
    end

    return candidate
end

function followTheLeader.PollMegaphoneRealmLeader()
    if not followTheLeader.settings then
        return
    end

    if not followTheLeader.settings.useRealmLeaderFallback then
        if followTheLeader.megaphoneRealmLeaderLast ~= L"" then
            followTheLeader.megaphoneRealmLeaderLast = L""
            followTheLeader.RequestUpdate()
        end
        return
    end

    local candidate = FollowTheLeader_ReadMegaphoneCandidate()
    if candidate ~= followTheLeader.megaphoneRealmLeaderLast then
        followTheLeader.megaphoneRealmLeaderLast = candidate
        followTheLeader.RequestUpdate()
    end
end

local function FollowTheLeader_ShouldPollMegaphone()
    if not (followTheLeader.settings and followTheLeader.settings.useRealmLeaderFallback) then
        return false
    end
    if followTheLeader.fixedLeaderName and followTheLeader.fixedLeaderName ~= L"" then
        return false
    end
    if followTheLeader.dynamicLeaderName and followTheLeader.dynamicLeaderName ~= L"" then
        return false
    end
    return true
end

-- Runs every frame via the mod's OnUpdate handler
function followTheLeader.OnFrameUpdate()
    local shouldForcePoll = followTheLeader.isUpdatePending
    local shouldPollMegaphone = FollowTheLeader_ShouldPollMegaphone()
    if shouldPollMegaphone then
        local interval = MEGAPHONE_POLL_INTERVAL_FRAMES
        if rawget(_G, "Megaphone") == nil and followTheLeader.megaphoneRealmLeaderLast == L"" then
            interval = MEGAPHONE_MISSING_POLL_INTERVAL_FRAMES
        end
        followTheLeader.megaphonePollFrameCounter = (followTheLeader.megaphonePollFrameCounter or 0) + 1
        if shouldForcePoll or followTheLeader.megaphonePollFrameCounter >= interval then
            followTheLeader.megaphonePollFrameCounter = 0
            followTheLeader.PollMegaphoneRealmLeader()
        end
    elseif shouldForcePoll then
        followTheLeader.megaphonePollFrameCounter = 0
        if followTheLeader.settings and not followTheLeader.settings.useRealmLeaderFallback then
            followTheLeader.PollMegaphoneRealmLeader()
        end
    else
        followTheLeader.megaphonePollFrameCounter = 0
        return
    end
    if followTheLeader.isUpdatePending then
        followTheLeader.isUpdatePending = false
        followTheLeader.Update()
    end
end

-- Request a UI update on the next frame
function followTheLeader.RequestUpdate()
    followTheLeader.isUpdatePending = true
end

local WINDOW_NAME = "followTheLeaderWindow"
local SCENARIO_CONTEXT_STUB = { isInWarband = false, isInParty = false, partyData = nil, isPlayerLeader = false }

function followTheLeader.OnScenarioBegin()
    followTheLeader.inScenarioMode = true
    followTheLeader.RequestUpdate()
end

function followTheLeader.OnScenarioEnd()
    followTheLeader.inScenarioMode = false
    followTheLeader.RequestUpdate()
end

-- Capitalizes the first letter of a name, makes the rest lowercase
function followTheLeader.CapitalizeName(name)
    if not name or name == "" then return "" end
    return string.upper(string.sub(name, 1, 1)) .. string.lower(string.sub(name, 2))
end

function followTheLeader.FormatPlayerLink(name, color)
    local strName = followTheLeader.ToStr(name)
    if not strName or strName == "" then
        return nil
    end

    local colorStr = color or "255,255,0"
    local displayName = "@" .. followTheLeader.CapitalizeName(strName)
    local linkText = string.format("<LINK data=\"PLAYER:%s\" color=\"%s\" text=\"%s\">", strName, colorStr, displayName)
    return towstring(linkText)
end

function followTheLeader.GetLinkedNameForChat(name)
    local link = followTheLeader.FormatPlayerLink(name)
    if link then
        return link
    end

    local strName = followTheLeader.ToStr(name)
    if strName ~= "" then
        return towstring(strName)
    end

    return L""
end

function followTheLeader.IsPlayerTrulyInParty(partyData)
    if not partyData or not next(partyData) then
        return false
    end
    for _, memberData in ipairs(partyData) do
        if memberData and memberData.name and memberData.name ~= L"" then
            return true
        end
    end
    return false
end

-- Helper function to follow the current friendly target
function followTheLeader.FollowCurrentTarget(cachedCanonicalTarget)
    local canonicalTarget = cachedCanonicalTarget
    if canonicalTarget == nil then
        local _
        _, canonicalTarget = followTheLeader.GetFriendlyTargetInfo()
    end
    if canonicalTarget ~= L"" then
        SendChatText( L"/follow ", L"" )
    end
    if followTheLeader.settings and followTheLeader.settings.trackstate then
        followTheLeader.TrackState(canonicalTarget)
    end
end

-- Creates the macro used as the script half of the action-bar target/follow sequence.
function followTheLeader.UpdateMacro(macroName, macroText, macroIcon)
    if type(GetMacrosData) ~= "function" or type(SetMacroData) ~= "function" then
        followTheLeader.hotbarMacroId = nil
        return false
    end

    local macros = GetMacrosData()
    local macroSlot = nil

    for i = 1, #macros do
        if macros[i].name == towstring(macroName) then
            macroSlot = i
            break
        elseif macros[i].iconNum == 0 and macroSlot == nil then
            macroSlot = i
        end
    end

    if macroSlot ~= nil then
        SetMacroData(towstring(macroName), towstring(macroText), macroIcon, macroSlot)
        followTheLeader.hotbarMacroId = macroSlot
        return true
    end

    followTheLeader.hotbarMacroId = nil
    return false
end

local function FollowTheLeader_GetPlacedMacroButtons()
    local macroId = followTheLeader.hotbarMacroId
    local buttons = {}
    local names = {}

    if not macroId or type(ActionBars) ~= "table" or type(ActionBars.m_Bars) ~= "table" then
        return buttons, ""
    end

    for barIndex = 1, #ActionBars.m_Bars do
        local bar = ActionBars.m_Bars[barIndex]
        if bar and type(bar.m_Buttons) == "table" then
            for buttonIndex = 1, #bar.m_Buttons do
                local button = bar.m_Buttons[buttonIndex]
                if button
                    and button.m_ActionType == FTL_MACRO_ACTION_TYPE
                    and button.m_ActionId == macroId
                    and button.m_Name then
                        buttons[#buttons + 1] = button
                        names[#names + 1] = followTheLeader.ToStr(button.m_Name)
                end
            end
        end
    end

    return buttons, table.concat(names, "|")
end

local function FollowTheLeader_SetHotbarButtons(buttons, action, actionId, data)
    if type(WindowSetGameActionData) ~= "function" then
        return 0
    end

    for index = 1, #buttons do
        WindowSetGameActionData(buttons[index].m_Name .. "Action", action, actionId, data)
    end
    return #buttons
end

local function FollowTheLeader_RefreshTargetEventSubscription(hasPlacedMacro)
    local shouldRegister = (followTheLeader.settings and followTheLeader.settings.trackstate) or hasPlacedMacro
    if shouldRegister and not followTheLeader.targetEventRegistered then
        RegisterEventHandler(SystemData.Events.PLAYER_TARGET_UPDATED, "followTheLeader.OnTargetUpdated")
        followTheLeader.targetEventRegistered = true
    elseif not shouldRegister and followTheLeader.targetEventRegistered then
        UnregisterEventHandler(SystemData.Events.PLAYER_TARGET_UPDATED, "followTheLeader.OnTargetUpdated")
        followTheLeader.targetEventRegistered = false
    end
end

local function FollowTheLeader_RestoreHotbarMacro(buttons, buttonKey)
    local macroId = followTheLeader.hotbarMacroId
    if not macroId then
        followTheLeader.hotbarArmedLeaderName = L""
        followTheLeader.hotbarActionMode = ""
        followTheLeader.hotbarButtonKey = buttonKey or ""
        return
    end

    if followTheLeader.hotbarActionMode ~= "macro"
        or followTheLeader.hotbarArmedLeaderName ~= L""
        or followTheLeader.hotbarButtonKey ~= buttonKey then
            FollowTheLeader_SetHotbarButtons(buttons, FTL_MACRO_ACTION_TYPE, macroId, L"")
    end
    followTheLeader.hotbarArmedLeaderName = L""
    followTheLeader.hotbarActionMode = "macro"
    followTheLeader.hotbarButtonKey = buttonKey or ""
end

local function FollowTheLeader_ArmHotbarTarget(buttons, buttonKey, leaderName)
    if not leaderName or leaderName == L"" then
        FollowTheLeader_RestoreHotbarMacro(buttons, buttonKey)
        return
    end

    if followTheLeader.hotbarActionMode ~= "target"
        or followTheLeader.hotbarArmedLeaderName ~= leaderName
        or followTheLeader.hotbarButtonKey ~= buttonKey then
            FollowTheLeader_SetHotbarButtons(buttons, GameData.PlayerActions.SET_TARGET, 0, leaderName)
    end
    followTheLeader.hotbarArmedLeaderName = leaderName
    followTheLeader.hotbarActionMode = "target"
    followTheLeader.hotbarButtonKey = buttonKey or ""
end

function followTheLeader.RefreshHotbarAction(cachedCanonicalTarget)
    local buttons, buttonKey = FollowTheLeader_GetPlacedMacroButtons()
    local hasPlacedMacro = (#buttons > 0)
    FollowTheLeader_RefreshTargetEventSubscription(hasPlacedMacro)

    if not hasPlacedMacro then
        followTheLeader.hotbarArmedLeaderName = L""
        followTheLeader.hotbarActionMode = ""
        followTheLeader.hotbarButtonKey = ""
        return
    end

    local leaderName = followTheLeader.leaderName or L""
    if leaderName == L"" then
        FollowTheLeader_RestoreHotbarMacro(buttons, buttonKey)
        return
    end

    local canonicalTarget = cachedCanonicalTarget
    if canonicalTarget == nil then
        local _
        _, canonicalTarget = followTheLeader.GetFriendlyTargetInfo()
    end

    if canonicalTarget ~= L"" and canonicalTarget == leaderName then
        FollowTheLeader_RestoreHotbarMacro(buttons, buttonKey)
    else
        FollowTheLeader_ArmHotbarTarget(buttons, buttonKey, leaderName)
    end
end

function followTheLeader.Initialize()
    followTheLeader.leaderName = L""
    followTheLeader.lastPrintedLeaderName = L""
    followTheLeader.fixedLeaderName = L""
    followTheLeader.fixedLeaderDisplayName = L""
    followTheLeader.dynamicLeaderName = L""
    followTheLeader.dynamicLeaderNilCycles = 0
    followTheLeader.persistentLeaderName = L""
    followTheLeader.megaphoneRealmLeaderName = L""
    followTheLeader.megaphoneEditBoxName = nil
    followTheLeader.megaphoneRealmLeaderLast = L""
    followTheLeader.megaphonePollFrameCounter = 0
    followTheLeader.hotbarArmedLeaderName = L""
    followTheLeader.hotbarActionMode = ""
    followTheLeader.hotbarButtonKey = ""
    followTheLeader.targetEventRegistered = false

    followTheLeader.RefreshPlayerNameCache()

    CreateWindow (WINDOW_NAME, true)
    WindowSetShowing(WINDOW_NAME, true)

    LayoutEditor.RegisterWindow( WINDOW_NAME,
        L"followTheLeaderWindow",
        L"followTheLeaderWindow",
        true, false,
        true, nil )
    ButtonSetText (WINDOW_NAME, L"Follow Target")

    -- initialize settings
    if followTheLeader.settings == nil then
        followTheLeader.settings = {}
        followTheLeader.settings.version = followTheLeader.version
        followTheLeader.settings.oneclickfollow = true
        followTheLeader.settings.trackstate = false
        followTheLeader.settings.debug = false
        followTheLeader.settings.useRealmLeaderFallback = true -- default to Megaphone fallback so new installs auto-follow when Megaphone is present
    elseif followTheLeader.settings.debug == nil then
        followTheLeader.settings.debug = false
    end
    if followTheLeader.settings.useRealmLeaderFallback == nil then
        followTheLeader.settings.useRealmLeaderFallback = true -- migrate older saves to default-on without clobbering explicit toggles
    end

    RegisterEventHandler( SystemData.Events.GROUP_SET_LEADER,                 "followTheLeader.RequestUpdate")
    RegisterEventHandler( SystemData.Events.GROUP_PLAYER_ADDED,               "followTheLeader.RequestUpdate")
    RegisterEventHandler( SystemData.Events.PLAYER_GROUP_LEADER_STATUS_UPDATED,  "followTheLeader.RequestUpdate")
    RegisterEventHandler( SystemData.Events.GROUP_ACCEPT_INVITATION,          "followTheLeader.RequestUpdate")
    RegisterEventHandler( SystemData.Events.BATTLEGROUP_ACCEPT_INVITATION,      "followTheLeader.RequestUpdate")
    RegisterEventHandler( SystemData.Events.GROUP_SETTINGS_UPDATED,           "followTheLeader.RequestUpdate")
    RegisterEventHandler( SystemData.Events.GROUP_LEAVE,                      "followTheLeader.RequestUpdate")
    RegisterEventHandler( SystemData.Events.SCENARIO_PLAYERS_LIST_UPDATED,    "followTheLeader.RequestUpdate")
    RegisterEventHandler( SystemData.Events.SCENARIO_BEGIN,                   "followTheLeader.OnScenarioBegin")
    RegisterEventHandler( SystemData.Events.SCENARIO_END,                     "followTheLeader.OnScenarioEnd")

    if followTheLeader.settings and followTheLeader.settings.trackstate then
        followTheLeader.StateTrackingSet(true)
    end

    local mainCmdSuccess = LibSlash.RegisterSlashCmd("followtheleader", function(msg) followTheLeader.slash(msg) end)
    DebugPrint("Registering '/followtheleader'... Success: " .. tostring(mainCmdSuccess))

    local aliasCmdSuccess = LibSlash.RegisterSlashCmd("ftl", function(msg) followTheLeader.slash(msg) end)
    DebugPrint("Registering '/ftl' as alias... Success: " .. tostring(aliasCmdSuccess))

    local macroReady = followTheLeader.UpdateMacro(FTL_MACRO_NAME, FTL_MACRO_TEXT, FTL_MACRO_ICON)

    TextLogAddEntry("Chat", SystemData.ChatLogFilters.BATTLEGROUP, L"<icon00044> followTheLeader v" .. towstring(followTheLeader.version) .. L" initialized.")
    if macroReady then
        TextLogAddEntry("Chat", SystemData.ChatLogFilters.BATTLEGROUP, L"<icon00044> followTheLeader macro ready; drag FollowTheLeader to a hotbar slot.")
    else
        TextLogAddEntry("Chat", SystemData.ChatLogFilters.BATTLEGROUP, L"<icon00044> followTheLeader: Macro not created; free a macro slot and reload the UI.")
    end

    followTheLeader.Update()
end


function followTheLeader.slash(msg)
    local msgstr = followTheLeader.ToStr(msg or "")
    DebugPrint("Main slash command '/followtheleader' EXECUTED with args: '" .. msgstr .. "'")
    if followTheLeader.settings == nil then followTheLeader.settings = {} end

    local cmd, param = msgstr:match("^(%S+)%s*(.*)$")
    if not cmd then cmd = msgstr:lower() else cmd = cmd:lower() end
    if not param then param = "" end

    if cmd == "set" then
        local nameToSet
        local displayName
        if param ~= "" then
            -- Normalize user-provided name same as target-derived names
            nameToSet = followTheLeader.FixName(param)
            -- Keep a prettified display string for UI while retaining canonical name for targeting
            displayName = towstring(followTheLeader.CapitalizeName(followTheLeader.ToStr(nameToSet)))
        else
            local _, canonicalTarget = followTheLeader.GetFriendlyTargetInfo()
            if canonicalTarget ~= L"" then
                nameToSet = canonicalTarget
                displayName = nameToSet
            else
                followTheLeader.UnsetFixedLeader()
                return
            end
        end

        -- Toggle off if trying to set the already fixed leader
        if nameToSet ~= L"" then
            if followTheLeader.fixedLeaderName and nameToSet == followTheLeader.fixedLeaderName then
                followTheLeader.UnsetFixedLeader()
                return
            end
            -- Prevent setting yourself as the fixed leader
            local selfName = followTheLeader.GetPlayerCanonicalName()
            if nameToSet == selfName then
                TextLogAddEntry("Chat", SystemData.ChatLogFilters.BATTLEGROUP, L"<icon00044> followTheLeader: Cannot set yourself as fixed leader.")
                followTheLeader.UnsetFixedLeader()
                return
            end
            followTheLeader.fixedLeaderName = nameToSet
            followTheLeader.fixedLeaderDisplayName = displayName
            local chatName = (displayName ~= L"" and displayName or nameToSet)
            TextLogAddEntry("Chat", SystemData.ChatLogFilters.BATTLEGROUP, L"<icon00044> followTheLeader: Fixed leader set to: " .. followTheLeader.GetLinkedNameForChat(chatName))
            followTheLeader.RequestUpdate()
        end
    elseif cmd == "unset" then
        followTheLeader.UnsetFixedLeader()
    elseif cmd == "oneclick" then
        followTheLeader.settings.oneclickfollow = not followTheLeader.settings.oneclickfollow
        TextLogAddEntry("Chat", SystemData.ChatLogFilters.BATTLEGROUP, L"One click follow: "..towstring(tostring(followTheLeader.settings.oneclickfollow)))
        followTheLeader.RequestUpdate()
    elseif cmd == "trackstate" then
        followTheLeader.settings.trackstate = not followTheLeader.settings.trackstate
        followTheLeader.StateTrackingSet(followTheLeader.settings.trackstate)
        TextLogAddEntry("Chat", SystemData.ChatLogFilters.BATTLEGROUP, L"Track follow state: "..towstring(tostring(followTheLeader.settings.trackstate)))
        followTheLeader.RequestUpdate()
    elseif cmd == "rlfallback" then
        local desired = nil
        if param ~= "" then
            local lower = string.lower(param)
            if lower == "on" or lower == "true" or lower == "1" then
                desired = true
            elseif lower == "off" or lower == "false" or lower == "0" then
                desired = false
            end
        end
        if desired == nil then
            followTheLeader.settings.useRealmLeaderFallback = not followTheLeader.settings.useRealmLeaderFallback
        else
            followTheLeader.settings.useRealmLeaderFallback = desired
        end
        local status = followTheLeader.settings.useRealmLeaderFallback and "enabled" or "disabled"
        TextLogAddEntry("Chat", SystemData.ChatLogFilters.BATTLEGROUP, L"Megaphone RL fallback: " .. towstring(status))
        followTheLeader.RequestUpdate()
    elseif cmd == "debug" then
        followTheLeader.settings.debug = not followTheLeader.settings.debug
        local status = followTheLeader.settings.debug and "enabled" or "disabled"
        TextLogAddEntry("Chat", 0, towstring("followTheLeader: Debug mode " .. status .. "."))
    else
        TextLogAddEntry("Chat", SystemData.ChatLogFilters.BATTLEGROUP, L"Follow the leader status:")
        if followTheLeader.fixedLeaderName and followTheLeader.fixedLeaderName ~= L"" then
            local disp = (followTheLeader.fixedLeaderDisplayName and followTheLeader.fixedLeaderDisplayName ~= L"") and followTheLeader.fixedLeaderDisplayName or followTheLeader.fixedLeaderName
            TextLogAddEntry("Chat", SystemData.ChatLogFilters.BATTLEGROUP, L"Fixed leader: " .. followTheLeader.GetLinkedNameForChat(disp))
        else
        TextLogAddEntry("Chat", SystemData.ChatLogFilters.BATTLEGROUP, L"Fixed leader: None")
        end
        TextLogAddEntry("Chat", SystemData.ChatLogFilters.BATTLEGROUP, L"One click follow: "..towstring(tostring(followTheLeader.settings.oneclickfollow)))
        TextLogAddEntry("Chat", SystemData.ChatLogFilters.BATTLEGROUP, L"Track follow state: "..towstring(tostring(followTheLeader.settings.trackstate)))
        TextLogAddEntry("Chat", SystemData.ChatLogFilters.BATTLEGROUP, L"Megaphone RL fallback: "..towstring(tostring(followTheLeader.settings.useRealmLeaderFallback)))
        TextLogAddEntry("Chat", SystemData.ChatLogFilters.BATTLEGROUP, L"Commands: set [name], unset, oneclick, trackstate, rlfallback [on|off], debug.")
    end
end


function followTheLeader.StateTrackingSet(enable)
    if enable then
        followTheLeader.TrackState()
        followTheLeader.RefreshHotbarAction()
    else
        followTheLeader.Update()
    end
end

function followTheLeader.CollectGroupContext()
    local context = {}
    context.isInWarband = IsWarBandActive()
    context.partyData = PartyUtils.GetPartyData()
    context.isInParty = followTheLeader.IsPlayerTrulyInParty(context.partyData)
    context.isPlayerLeader = (GameData and GameData.Player and GameData.Player.isGroupLeader) or false
    return context
end

local function FollowTheLeader_GetGroupContext(existingContext)
    if existingContext then
        return existingContext
    end
    if followTheLeader.inScenarioMode then
        if GameData and GameData.Player then
            SCENARIO_CONTEXT_STUB.isPlayerLeader = GameData.Player.isGroupLeader or false
        else
            SCENARIO_CONTEXT_STUB.isPlayerLeader = false
        end
        return SCENARIO_CONTEXT_STUB
    end
    return followTheLeader.CollectGroupContext()
end

function followTheLeader.GetDynamicLeaderName(context)
    local ctx = FollowTheLeader_GetGroupContext(context)
    local selfName = followTheLeader.GetPlayerCanonicalName()

    if ctx.isInWarband then
        local leaderInfo = PartyUtils.GetWarbandLeader()
        if leaderInfo and leaderInfo.name then
            local potentialLeaderName = followTheLeader.FixName(leaderInfo.name)
            if potentialLeaderName ~= L"" and potentialLeaderName ~= selfName then
                return potentialLeaderName
            end
        end
    elseif ctx.isInParty and ctx.partyData then
        for _, memberData in ipairs(ctx.partyData) do
            if memberData and memberData.isGroupLeader and memberData.name and memberData.name ~= L"" then
                local potentialLeaderName = followTheLeader.FixName(memberData.name)
                if potentialLeaderName ~= selfName then
                    return potentialLeaderName
                end
                break
            end
        end
    end

    return L""
end

function followTheLeader.GetScenarioLeader()
    if not followTheLeader.inScenarioMode then
        return L""
    end

    local persistent = followTheLeader.persistentLeaderName
    if not persistent or persistent == L"" then
        return L""
    end

    local scdata = GameData.GetScenarioPlayerGroups()
    if scdata == nil then
        return L""
    end

    for _, player in ipairs(scdata) do
        if player.name and followTheLeader.FixName(player.name) == persistent then
            return persistent
        end
    end

    return L""
end

-- Determines the effective leader and updates UI text and internal state accordingly
function followTheLeader.Update()
    local currentDynamicLeader
    local context = nil
    followTheLeader.megaphoneRealmLeaderName = L""

    if followTheLeader.inScenarioMode then
        currentDynamicLeader = followTheLeader.GetScenarioLeader()
    else
        context = followTheLeader.CollectGroupContext()
        currentDynamicLeader = followTheLeader.GetDynamicLeaderName(context)
        followTheLeader.persistentLeaderName = currentDynamicLeader
    end

    if currentDynamicLeader ~= L"" then
        followTheLeader.dynamicLeaderNilCycles = 0
        followTheLeader.dynamicLeaderName = currentDynamicLeader
    else
        local ctx = FollowTheLeader_GetGroupContext(context)
        if (ctx.isInWarband or ctx.isInParty or followTheLeader.inScenarioMode) and not ctx.isPlayerLeader then
            followTheLeader.dynamicLeaderNilCycles = followTheLeader.dynamicLeaderNilCycles + 1
        else
            followTheLeader.dynamicLeaderNilCycles = 3
        end

        if followTheLeader.dynamicLeaderNilCycles >= 3 then
            followTheLeader.dynamicLeaderName = L""
            if not followTheLeader.inScenarioMode then
                followTheLeader.persistentLeaderName = L""
            end
        end
    end

    local fallbackLeader = L""
    local hasFixedLeader = followTheLeader.fixedLeaderName and followTheLeader.fixedLeaderName ~= L""
    local hasDynamicLeader = followTheLeader.dynamicLeaderName and followTheLeader.dynamicLeaderName ~= L""
    if (not hasFixedLeader) and (not hasDynamicLeader) then
        fallbackLeader = followTheLeader.GetMegaphoneRealmLeader()
        if fallbackLeader ~= L"" then
            followTheLeader.megaphoneRealmLeaderName = fallbackLeader
        end
    end

    local effectiveLeader = followTheLeader.fixedLeaderName
    if not effectiveLeader or effectiveLeader == L"" then
        effectiveLeader = followTheLeader.dynamicLeaderName
        if (not effectiveLeader or effectiveLeader == L"") and fallbackLeader ~= L"" then
            effectiveLeader = fallbackLeader
        end
    end

    if followTheLeader.leaderName ~= effectiveLeader then
        followTheLeader.leaderName = effectiveLeader or L""
        followTheLeader.SetLeaderName(followTheLeader.leaderName)

        if effectiveLeader and effectiveLeader ~= L"" and
            followTheLeader.fixedLeaderName == L"" and
            effectiveLeader == followTheLeader.dynamicLeaderName and
            effectiveLeader ~= followTheLeader.lastPrintedLeaderName then
                local groupType = L"Group"
                local ctxForGroup = FollowTheLeader_GetGroupContext(context)
                if ctxForGroup.isInWarband then groupType = L"Warband" end
                if followTheLeader.inScenarioMode and followTheLeader.persistentLeaderName ~= L"" then groupType = L"Scenario" end
                TextLogAddEntry("Chat", SystemData.ChatLogFilters.BATTLEGROUP, L"<icon00044> " .. groupType .. L" leader: " .. followTheLeader.GetLinkedNameForChat(effectiveLeader))
                followTheLeader.lastPrintedLeaderName = effectiveLeader
        elseif fallbackLeader ~= L"" and effectiveLeader == fallbackLeader and effectiveLeader ~= followTheLeader.lastPrintedLeaderName then
                TextLogAddEntry("Chat", SystemData.ChatLogFilters.BATTLEGROUP, L"<icon00044> Megaphone RL fallback: " .. followTheLeader.GetLinkedNameForChat(effectiveLeader))
                followTheLeader.lastPrintedLeaderName = effectiveLeader
        end
    end

    if followTheLeader.settings.trackstate then
        followTheLeader.TrackState()
    else
        local leaderToDisplay = followTheLeader.GetEffectiveLeaderDisplayName()

        if leaderToDisplay and leaderToDisplay ~= L"" then
            local prefix = L"Follow "
            if followTheLeader.megaphoneRealmLeaderName and followTheLeader.megaphoneRealmLeaderName ~= L"" and followTheLeader.leaderName == followTheLeader.megaphoneRealmLeaderName then
                prefix = L"Follow RL "
            end
            ButtonSetText(WINDOW_NAME, prefix .. leaderToDisplay)
        else
            ButtonSetText(WINDOW_NAME, L"Follow Target")
        end
    end

    followTheLeader.RefreshHotbarAction()
end


function followTheLeader.SetLeaderName (playerName)
    local nameToSet = playerName or L""
    WindowSetGameActionData (WINDOW_NAME, GameData.PlayerActions.SET_TARGET, 0, nameToSet)
end

function followTheLeader.OnTargetUpdated()
    local _, canonicalTarget = followTheLeader.GetFriendlyTargetInfo()
    followTheLeader.RefreshHotbarAction(canonicalTarget)

    if followTheLeader.settings and followTheLeader.settings.trackstate then
        followTheLeader.TrackState(canonicalTarget)
    end
end

function followTheLeader.TrackState(cachedCanonicalTarget)
    if not followTheLeader.settings then return end
    if followTheLeader.leaderName and followTheLeader.leaderName ~= L"" then
        local displayName = followTheLeader.GetEffectiveLeaderDisplayName()
        local isFallback = (followTheLeader.megaphoneRealmLeaderName and followTheLeader.megaphoneRealmLeaderName ~= L"" and followTheLeader.leaderName == followTheLeader.megaphoneRealmLeaderName)
        local shouldFollow = followTheLeader.settings.oneclickfollow
        if not shouldFollow then
            local canonicalTarget = cachedCanonicalTarget
            if canonicalTarget == nil then
                local _
                _, canonicalTarget = followTheLeader.GetFriendlyTargetInfo()
            end
            shouldFollow = (canonicalTarget ~= L"" and canonicalTarget == followTheLeader.leaderName)
        end
        local prefix = shouldFollow and L"Follow " or L"Target "
        if shouldFollow and isFallback then
            prefix = L"Follow RL "
        end
        ButtonSetText(WINDOW_NAME, prefix .. displayName)
    else
        ButtonSetText(WINDOW_NAME, L"Follow Target")
    end
end

function followTheLeader.OnMouseOver()
    local anchor = { Point="right", RelativeTo=SystemData.ActiveWindow.name, RelativePoint="left", XOffset=20, YOffset=0 }
    Tooltips.CreateTextOnlyTooltip( SystemData.ActiveWindow.name )

    local hasLeader = followTheLeader.leaderName and followTheLeader.leaderName ~= L""
    local _, canonicalTarget = followTheLeader.GetFriendlyTargetInfo()
    local hasTarget = canonicalTarget ~= L""
    local fixedName = followTheLeader.fixedLeaderName or L""
    local fixedDisplay = (followTheLeader.fixedLeaderDisplayName and followTheLeader.fixedLeaderDisplayName ~= L"") and followTheLeader.fixedLeaderDisplayName or fixedName
    local dynamicLeaderName = followTheLeader.dynamicLeaderName
    local targetIsEffectiveLeader = hasTarget and (canonicalTarget == followTheLeader.leaderName)
    local isFallbackLeader = (followTheLeader.megaphoneRealmLeaderName and followTheLeader.megaphoneRealmLeaderName ~= L"" and followTheLeader.leaderName == followTheLeader.megaphoneRealmLeaderName)
    local leaderDisplay = followTheLeader.GetEffectiveLeaderDisplayName()
    local tooltipText
    if hasLeader then
        local leaderLabel = leaderDisplay
        if isFallbackLeader then
            leaderLabel = L"RL " .. leaderLabel
        end
        tooltipText = L"LClick to target/follow " .. leaderLabel .. L"."
        if hasTarget and not targetIsEffectiveLeader then
            tooltipText = tooltipText .. L"\n" .. L"RClick to follow current target."
        end
    else
        if hasTarget then
            tooltipText = L"LClick/RClick to follow current target."
        else
            tooltipText = L"LClick to follow current target."
        end
    end

    local mClickText = nil
    if hasTarget then
        local targetIsDynamicLeader = (dynamicLeaderName ~= L"" and canonicalTarget == dynamicLeaderName)
        if fixedName ~= L"" and (canonicalTarget == fixedName or targetIsDynamicLeader) then
            mClickText = L"MClick to unset " .. fixedDisplay .. L" as fixed leader."
        elseif canonicalTarget ~= fixedName then
            mClickText = L"MClick to set " .. canonicalTarget .. L" as fixed leader."
        end
    elseif fixedName ~= L"" then
        mClickText = L"MClick to unset " .. fixedDisplay .. L" as fixed leader."
    end

    if mClickText then
        tooltipText = tooltipText .. L"\n" .. mClickText
    end

    Tooltips.SetTooltipText( 1, 1, tooltipText)
    Tooltips.Finalize();
    Tooltips.AnchorTooltip( anchor )
end

function followTheLeader.HotbarAction()
    if followTheLeader.leaderName and followTheLeader.leaderName ~= L"" then
        local _, canonicalTarget = followTheLeader.GetFriendlyTargetInfo()
        local targetIsLeader = (canonicalTarget ~= L"" and canonicalTarget == followTheLeader.leaderName)

        if targetIsLeader then
            SendChatText(L"/follow", L"")
        else
            followTheLeader.RefreshHotbarAction(canonicalTarget)
        end

        if followTheLeader.settings and followTheLeader.settings.trackstate then
            followTheLeader.RequestUpdate()
        end
    else
        local _, canonicalTarget = followTheLeader.GetFriendlyTargetInfo()
        followTheLeader.RefreshHotbarAction(canonicalTarget)
        followTheLeader.FollowCurrentTarget(canonicalTarget)
    end
end

function followTheLeader.OnLButtonUp()
    if followTheLeader.leaderName and followTheLeader.leaderName ~= L"" then
        local _, canonicalTarget = followTheLeader.GetFriendlyTargetInfo()
        local targetIsLeader = (canonicalTarget ~= L"" and canonicalTarget == followTheLeader.leaderName)

        if not targetIsLeader then
            SendChatText(L"/target " .. followTheLeader.leaderName, L"")
        end

        local shouldFollow = targetIsLeader
        if not shouldFollow and followTheLeader.settings and followTheLeader.settings.oneclickfollow then
            shouldFollow = true
        end

        if shouldFollow then
            SendChatText(L"/follow", L"")
        end

        if followTheLeader.settings and followTheLeader.settings.trackstate then
            followTheLeader.RequestUpdate()
        end
    else
        followTheLeader.FollowCurrentTarget()
    end
end
function followTheLeader.OnRButtonUp()
    PlaySound(GameData.Sound.BUTTON_CLICK)
    local _, canonicalTarget = followTheLeader.GetFriendlyTargetInfo()
    followTheLeader.FollowCurrentTarget(canonicalTarget)
end

function followTheLeader.UnsetFixedLeader()
    if followTheLeader.fixedLeaderName and followTheLeader.fixedLeaderName ~= L"" then
        TextLogAddEntry("Chat", SystemData.ChatLogFilters.BATTLEGROUP, L"<icon00044> followTheLeader: Fixed leader unset.")
        followTheLeader.fixedLeaderName = L""
        followTheLeader.fixedLeaderDisplayName = L""
        followTheLeader.lastPrintedLeaderName = L""
        followTheLeader.RequestUpdate()
    end
end

function followTheLeader.OnMButtonUp()
    PlaySound(GameData.Sound.BUTTON_CLICK)
    local _, canonicalTarget = followTheLeader.GetFriendlyTargetInfo()
    local fixedName = followTheLeader.fixedLeaderName
    local dynamicLeaderName = followTheLeader.dynamicLeaderName

    if canonicalTarget ~= L"" and canonicalTarget ~= fixedName and not (fixedName ~= L"" and canonicalTarget == dynamicLeaderName) then
        followTheLeader.slash("set")
    else
        followTheLeader.UnsetFixedLeader()
    end
end
-- Normalizes a player name: trims whitespace and strips any caret '^' suffix; returns towstring
function followTheLeader.FixName(str)
    if (str == nil) then
        return L""
    end
    local normalStr = followTheLeader.ToStr(str)
    local pos = string.find(normalStr, "^", 1, true)
    if (pos) then
        normalStr = string.sub(normalStr, 1, pos - 1)
    end
    normalStr = normalStr:gsub("^%s+", ""):gsub("%s+$", "")
    return towstring(normalStr)
end

-- Returns a display-friendly leader name while keeping canonical values for targeting
function followTheLeader.GetEffectiveLeaderDisplayName()
    if followTheLeader.fixedLeaderName and followTheLeader.fixedLeaderName ~= L"" then
        if followTheLeader.fixedLeaderDisplayName and followTheLeader.fixedLeaderDisplayName ~= L"" then
            return followTheLeader.fixedLeaderDisplayName
        end
        return followTheLeader.fixedLeaderName
    end
    if followTheLeader.dynamicLeaderName and followTheLeader.dynamicLeaderName ~= L"" then
        return followTheLeader.dynamicLeaderName
    end
    if followTheLeader.megaphoneRealmLeaderName and followTheLeader.megaphoneRealmLeaderName ~= L"" then
        return followTheLeader.megaphoneRealmLeaderName
    end
    return L""
end
