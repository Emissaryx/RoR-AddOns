# followTheLeader

followTheLeader adds a small movable button for quickly following the right friendly player in Return of Reckoning.

It is mainly for party and warband play. The button can follow your warband leader, group leader, a fixed leader you choose, or your current friendly target. During scenarios it can keep using the leader it knew before entering, if that player is also in the scenario.

## What It Follows

Leader priority is:

1. Fixed leader set by you.
2. Detected warband or group leader.
3. Megaphone realm-leader fallback, if enabled and no fixed or detected leader is available.
4. Your current friendly target, when no leader is known or when right-clicking.

## Controls

- Left-click follows the current leader.
- If no leader is known, left-click follows your current friendly player target.
- Right-click always follows your current friendly player target.
- Middle-click sets your current friendly target as fixed leader, or unsets the fixed leader.
- Move or scale the button through the layout editor.
- Optional: drag the `FollowTheLeader` macro to a hotbar slot if you want action-bar use.

## Settings

- One-click follow is on by default.
- Track-state mode is off by default. When enabled, the button text can change between `Target <name>` and `Follow <name>`.
- Megaphone realm-leader fallback is on by default, but only used when no fixed, group, warband, or remembered scenario leader is available.
- Settings are saved per character.

## Slash Commands

Both `/followtheleader` and `/ftl` work.

- `/ftl` shows current status.
- `/ftl set` sets your current friendly target as fixed leader.
- `/ftl set <name>` sets a named fixed leader.
- `/ftl unset` clears the fixed leader.
- `/ftl oneclick` toggles one-click follow.
- `/ftl trackstate` toggles target/follow button text tracking.
- `/ftl rlfallback [on|off]` toggles or sets Megaphone realm-leader fallback.
- `/ftl debug` toggles debug chat output.

## Notes

The game follows your current friendly target. followTheLeader handles the targeting step and then sends `/follow`.

The optional hotbar macro uses two presses when the leader is not already targeted: one to target the leader, then one to follow.

## Changelog

This changelog is based on downloaded release files and local code comparison.

### 1.0.8 - 2026-05-15 - Wholdar

- Added Megaphone realm-leader fallback and `/ftl rlfallback [on|off]`.
- Added optional `FollowTheLeader` hotbar macro support.
- Improved fixed leader display, player-name handling, self-target checks, and clickable chat names.
- Reduced background fallback and target-state work.
- Fixed the manifest XML author field and updated the addon description.

### 1.0.7 - 2025-08-02 - Wholdar

- Added fixed leader mode with middle-click support.
- Added `/ftl`, `/ftl set [name]`, `/ftl unset`, and `/ftl debug`.
- Added scenario persistence for the last known group or warband leader.
- Improved leader targeting, friendly-target checks, and stale leader handling.

### 1.0.6 - 2025-07-01 - Wholdar

- Debounced group and warband updates through `OnFrameUpdate`.
- Reduced button text flicker during noisy group updates.

### 1.0.5 - 2025-07-01 - Wholdar

- Added `GROUP_LEAVE` handling so leader state clears when leaving a group.

### 1.0.4 - 2025-07-01 - Wholdar

- Added group leader support outside warbands.
- Updated button text and left-click behavior to work for both group and warband leaders.
- Improved name normalization.

### 1.0.3 - 2025-04-09 - Wholdar

- Kept the button useful outside warbands.
- Added left-click follow for the current friendly target when no leader is active.
- Reduced repeated leader announcements.

### 1.0.2 - 2017-08-11 - nyan

- Removed the accidental `ATemplate_DefaultWindowSkin` dependency.
- No Lua or XML behavior changed from `1.0.1`.

### 1.0.1 - 2017-07-20 - nyan

- Added saved settings, `/followtheleader`, one-click follow, and track-state mode.
- Changed the button layer from `popup` to `background`.
- Added a default center anchor.
- Hid the leader button when you are the current warband leader.

### 1.0.0 - 2017-07-16 - nyan

- First public release.
- Added the movable follow button.
- Added warband leader targeting and right-click follow for your current friendly target.
