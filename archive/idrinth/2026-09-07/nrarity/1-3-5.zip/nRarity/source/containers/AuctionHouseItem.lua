local AuctionHouseItem = nRarity.Container:new("AuctionHouseItem", "EA_AuctionHouseWindow")

-- constants
local ICON_NAME = "AuctionHouseWindowCreateAuctionItemImage"

-- locals
local itemData

-- setup the function hooks for auction actions
function AuctionHouseItem:initHooks()

	self:hook("AuctionHouseWindow", "OnShown", self.showBorders, true)
	self:hook("CreateAuctionWindow", "UpdateForItem", self.updateForItem, false)
	self:hook("CreateAuctionWindow", "Clear", self.clear, false)
end

-- create borders for the auctioned item
function AuctionHouseItem:initIcons()

	self.icons[1] = ICON_NAME
end

-- return item info for an index of self.border
function AuctionHouseItem:getItemData(slot)
	return itemData
end

-- item data changed
function AuctionHouseItem:updateForItem(itemDataPassed)
	itemData = itemDataPassed

	self:setRarity()
end

-- item data removed
function AuctionHouseItem:clear()
	itemData = nil

	self:setRarity()
end

-- set event handlers for a border
function AuctionHouseItem:setEventHandlers(border)
	border:registerCoreEventHandler("OnLButtonDown", "CreateAuctionWindow.ItemSlotLButtonDown")
	border:registerCoreEventHandler("OnLButtonUp", "CreateAuctionWindow.ItemSlotLButtonUp")
	border:registerCoreEventHandler("OnRButtonUp", "CreateAuctionWindow.ItemSlotRButtonUp")
	border:registerCoreEventHandler("OnMouseOver", "CreateAuctionWindow.ItemSlotMouseOver")
end
