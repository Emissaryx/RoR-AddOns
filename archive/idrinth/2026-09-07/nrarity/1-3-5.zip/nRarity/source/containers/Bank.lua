local Bank = nRarity.Container:new("Bank", "EA_BankWindow")
Bank:setParentFrameName("BankWindow")

-- setup the bank hooks
function Bank:initHooks()
	self:hook("BankWindow", "OnShown", self.showBorders, true)
	self:hook("BankWindow", "UpdateBankSlots", self.setRarity, true)
	self:hook("BankWindow", "SwitchTabs", self.setRarity, true)
end

-- create borders for each of the bank slots
function Bank:initIcons()
	local anchorName
	for slot = 1, 80 do
			anchorName = "BankWindowSlotsButton"..slot
			if DoesWindowExist(anchorName) then
				WindowSetId(anchorName, slot)
				self.icons[slot] = anchorName
			end
	end
end

function BankWindow_EquipmentMouseOver( )
	local buttonIndex = WindowGetId(SystemData.MouseOverWindow.name)
	local slot        = BankWindow.GetSlotNumberForButtonIndex( buttonIndex )  
    local itemData    = BankWindow.GetItem( slot ) 
	
    if not DataUtils.IsValidItem( itemData ) then
        Tooltips.ClearTooltip()
    else 
        Tooltips.CreateAndTintItemTooltip( itemData, 
                                           SystemData.MouseOverWindow.name,
                                           Tooltips.ANCHOR_WINDOW_RIGHT, 
                                           Tooltips.ENABLE_COMPARISON )
    end
end

-- return item info for an index of self.border
function Bank:getItemData(slot)
	return DataUtils.GetBankData()[((BankWindow.currentTabNumber - 1)* 80) + slot]
end

-- set event handlers for a border
function Bank:setEventHandlers(border)
	border:registerCoreEventHandler("OnMouseOver", "BankWindow_EquipmentMouseOver")
end
