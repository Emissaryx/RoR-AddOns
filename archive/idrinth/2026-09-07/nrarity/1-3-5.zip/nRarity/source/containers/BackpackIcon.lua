local BackpackIcon = nRarity.Container:new("BackpackIcon", "EA_BackpackWindow")

-- setup the function hooks for standard UI actions
function BackpackIcon:initHooks()

	self:hook("EA_Window_Backpack", "OnShown", self.showBorders, true)
	self:hook("EA_Window_Backpack", "GrowBackpack", self.reInitShowBorders, true)
	self:hook("EA_Window_Backpack", "OnInventorySlotUpdated", self.EA_Window_Backpack_OnInventorySlotUpdated)
end

-- create borders for each of the backpack icon view slots
function BackpackIcon:initIcons()

	local pocket, pocketName, buttonIndex, anchorName
	for slot = 1, EA_Window_Backpack.NUM_INVENTORY_SLOTS do

		-- determine the name of the icon button
		pocket = EA_Window_Backpack.GetPocketNumberForSlot(slot)
		pocketName = EA_Window_Backpack.GetPocketName(pocket)
		buttonIndex = slot - EA_Window_Backpack.pockets[pocket].firstSlotID  + 1
		anchorName = pocketName.."ButtonsButton"..tostring(buttonIndex)

		-- set the icon
		if DoesWindowExist(anchorName) then
			self.icons[slot] = anchorName
		end
	end
end

-- return item info for an index of self.borders
function BackpackIcon:getItemData(slot)
	return DataUtils.GetItems()[slot]
end

-- post hook for bag changes
function BackpackIcon:EA_Window_Backpack_OnInventorySlotUpdated(updatedSlots, ...)

	-- process the updates
	self:setRarity(updatedSlots)
end
