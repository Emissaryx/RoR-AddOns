local AuctionHouse = nRarity.Container:new("AuctionHouse", "EA_AuctionHouseWindow")

-- setup the function hooks for auction actions
function AuctionHouse:initHooks()

	self:hook("AuctionHouseWindow", "OnShown", self.showBorders, true)
	self:hook("AuctionListWindow", "Populate", self.setRarity, true)
end

-- create borders for the auctioned item
function AuctionHouse:initIcons()

	local anchorName

	-- create borders for item slots
	for row = 1, AuctionListWindow.MAX_VISIBLE_ROWS do
		anchorName = "AuctionHouseWindowSearchResultsListRow"..row.."Icon"
		if DoesWindowExist(anchorName) then
			self.icons[row] = anchorName
		end
	end
end

-- return item info for an index of self.border
function AuctionHouse:getItemData(slot)
	local currentWindowData = AuctionListDataManager.GetCurrentWindowData()

	if currentWindowData and currentWindowData.searchResultsData and AuctionHouseWindowSearchResultsList.PopulatorIndices then
		local itemIndex = AuctionHouseWindowSearchResultsList.PopulatorIndices[slot]
		if itemIndex then
			local searchData = currentWindowData.searchResultsData[itemIndex]
			if searchData then
				return searchData.itemData
			end
		end
	end

	return nil
end

-- set event handlers for a border
function AuctionHouse:setEventHandlers(border)
	border:registerCoreEventHandler("OnMouseOver", "AuctionListWindow.OnMouseOverIcon")
end
