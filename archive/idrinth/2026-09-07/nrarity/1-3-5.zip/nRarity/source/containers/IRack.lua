-- this addon is very problematic:
--  ItemRack.MouseOverSlot cannot be hooked for some reason - it does a return?
--  the mouseoverend is not mapped to any function, so mouseover highlighting is not handled

nRarity.IRack = nRarity.Container:new("ItemRack", "oldMouseOverSlot")
local IRack = nRarity.IRack

-- setup the function hooks for standard UI actions
function IRack:initHooks()

	-- item equipped
	self:hook("ItemRack", "Equipped", "ItemRack_Equipped")
end

-- create borders for each of the IRack view slots
function IRack:initIcons()

	-- create borders for alternate equipment icons
	for slot=1, 10 do

		-- create the icon
		self:addIcon(slot, "nRarity_CharacterWindowDefaultButton", "ItemRackEQShow1EquipmentSlot"..slot, "ItemRackEQShow1")
	end
end

-- return item info for an index of self.border
function IRack:getItemInfo(slot)

	if ItemRack.equipmentData and ItemRack.equipmentData[slot] then
		return ItemRack.equipmentData[slot]
	end

	return nil
end

-- item equipped
function IRack:ItemRack_Equipped(...)
	self.hooked.ItemRack_Equipped(...)

	-- update all item rarities as we don't know which item was equipped
	self:setItemInfo()
end
