<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
    <UiMod name="CanvasByEgyptianKozi" version="1.1.0" date="2026-07-18">
        <VersionSettings gameVersion="1.4.8" windowsVersion="1.0" savedVariablesVersion="1.0" />
        <Author name="EgyptianKozi" email="" />
        <Description text="Warband tactical map canvas. The warband leader Shift-drags on the world map to draw lines/arrows; strokes are broadcast over warband chat (hidden WBC: packets) and rendered live on every member's map. /canvas for options." />
        <Dependencies>
            <Dependency name="EA_ChatWindow" />
            <Dependency name="LibSlash" optional="true" forceEnable="true" />
        </Dependencies>
        <SavedVariables>
            <SavedVariable name="CanvasByEgyptianKozi.Settings" />
        </SavedVariables>
        <Files>
            <File name="CanvasByEgyptianKozi.xml" />
            <File name="CanvasByEgyptianKozi.lua" />
        </Files>
        <OnInitialize>
            <CreateWindow name="WarbandCanvasOverlay" show="false" />
            <CreateWindow name="CanvasHUD" show="false" />
            <CallFunction name="CanvasByEgyptianKozi.Initialize" />
        </OnInitialize>
        <OnUpdate>
            <CallFunction name="CanvasByEgyptianKozi.OnUpdate" />
        </OnUpdate>
        <WARInfo>
            <Categories>
                <Category name="RVR" />
                <Category name="GROUPING" />
            </Categories>
            <Careers>
                <Career name="BLACKGUARD" />
                <Career name="WITCH_ELF" />
                <Career name="DISCIPLE" />
                <Career name="SORCERER" />
                <Career name="IRON_BREAKER" />
                <Career name="SLAYER" />
                <Career name="RUNE_PRIEST" />
                <Career name="ENGINEER" />
                <Career name="BLACK_ORC" />
                <Career name="CHOPPA" />
                <Career name="SHAMAN" />
                <Career name="SQUIG_HERDER" />
                <Career name="WITCH_HUNTER" />
                <Career name="KNIGHT" />
                <Career name="BRIGHT_WIZARD" />
                <Career name="WARRIOR_PRIEST" />
                <Career name="CHOSEN" />
                <Career name="MARAUDER" />
                <Career name="ZEALOT" />
                <Career name="MAGUS" />
                <Career name="SWORDMASTER" />
                <Career name="SHADOW_WARRIOR" />
                <Career name="WHITE_LION" />
                <Career name="ARCHMAGE" />
            </Careers>
        </WARInfo>
    </UiMod>
</ModuleFile>
